package ch.qos.logback.core.status;

public abstract interface StatusListener
{
  public abstract void addStatusEvent(Status paramStatus);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\status\StatusListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */