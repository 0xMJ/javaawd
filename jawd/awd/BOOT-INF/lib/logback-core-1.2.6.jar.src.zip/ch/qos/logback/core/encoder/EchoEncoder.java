/*    */ package ch.qos.logback.core.encoder;
/*    */ 
/*    */ import ch.qos.logback.core.CoreConstants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EchoEncoder<E>
/*    */   extends EncoderBase<E>
/*    */ {
/*    */   String fileHeader;
/*    */   String fileFooter;
/*    */   
/*    */   public byte[] encode(E event)
/*    */   {
/* 24 */     String val = event + CoreConstants.LINE_SEPARATOR;
/* 25 */     return val.getBytes();
/*    */   }
/*    */   
/*    */   public byte[] footerBytes() {
/* 29 */     if (this.fileFooter == null) {
/* 30 */       return null;
/*    */     }
/* 32 */     return this.fileFooter.getBytes();
/*    */   }
/*    */   
/*    */   public byte[] headerBytes() {
/* 36 */     if (this.fileHeader == null) {
/* 37 */       return null;
/*    */     }
/* 39 */     return this.fileHeader.getBytes();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\encoder\EchoEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */