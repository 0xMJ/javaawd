/*    */ package ch.qos.logback.core.joran.spi;
/*    */ 
/*    */ import ch.qos.logback.core.status.StatusManager;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLUtil
/*    */ {
/*    */   public static final int ILL_FORMED = 1;
/*    */   public static final int UNRECOVERABLE_ERROR = 2;
/*    */   
/*    */   public static int checkIfWellFormed(URL url, StatusManager sm)
/*    */   {
/* 26 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\joran\spi\XMLUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */