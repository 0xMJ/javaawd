package ch.qos.logback.core.net;

import java.io.IOException;

public abstract interface ObjectWriter
{
  public abstract void write(Object paramObject)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\net\ObjectWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */