package ch.qos.logback.core.rolling.helper;

public enum CompressionMode
{
  NONE,  GZ,  ZIP;
  
  private CompressionMode() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\rolling\helper\CompressionMode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */