package ch.qos.logback.core.spi;

public abstract interface PropertyDefiner
  extends ContextAware
{
  public abstract String getPropertyValue();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\spi\PropertyDefiner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */