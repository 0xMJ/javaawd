package ch.qos.logback.core.rolling.helper;

public abstract interface MonoTypedConverter
{
  public abstract boolean isApplicable(Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\rolling\helper\MonoTypedConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */