package ch.qos.logback.core.db.dialect;

public abstract interface SQLDialect
{
  public abstract String getSelectInsertId();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\db\dialect\SQLDialect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */