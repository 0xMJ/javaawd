package ch.qos.logback.core.net.ssl;

public abstract interface SSLComponent
{
  public abstract SSLConfiguration getSsl();
  
  public abstract void setSsl(SSLConfiguration paramSSLConfiguration);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\net\ssl\SSLComponent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */