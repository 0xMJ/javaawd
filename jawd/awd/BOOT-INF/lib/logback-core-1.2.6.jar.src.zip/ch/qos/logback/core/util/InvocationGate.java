package ch.qos.logback.core.util;

public abstract interface InvocationGate
{
  public static final long TIME_UNAVAILABLE = -1L;
  
  public abstract boolean isTooSoon(long paramLong);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\util\InvocationGate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */