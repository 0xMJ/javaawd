/*     */ package ch.qos.logback.core.net.server;
/*     */ 
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConcurrentServerRunner<T extends Client>
/*     */   extends ContextAwareBase
/*     */   implements Runnable, ServerRunner<T>
/*     */ {
/*  49 */   private final Lock clientsLock = new ReentrantLock();
/*     */   
/*  51 */   private final Collection<T> clients = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */   private final ServerListener<T> listener;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Executor executor;
/*     */   
/*     */ 
/*     */   private boolean running;
/*     */   
/*     */ 
/*     */ 
/*     */   public ConcurrentServerRunner(ServerListener<T> listener, Executor executor)
/*     */   {
/*  68 */     this.listener = listener;
/*  69 */     this.executor = executor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isRunning()
/*     */   {
/*  76 */     return this.running;
/*     */   }
/*     */   
/*     */   protected void setRunning(boolean running) {
/*  80 */     this.running = running;
/*     */   }
/*     */   
/*     */ 
/*     */   public void stop()
/*     */     throws IOException
/*     */   {
/*  87 */     this.listener.close();
/*  88 */     accept(new ClientVisitor() {
/*     */       public void visit(T client) {
/*  90 */         client.close();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void accept(ClientVisitor<T> visitor)
/*     */   {
/*  99 */     Collection<T> clients = copyClients();
/* 100 */     for (T client : clients) {
/*     */       try {
/* 102 */         visitor.visit(client);
/*     */       } catch (RuntimeException ex) {
/* 104 */         addError(client + ": " + ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Collection<T> copyClients()
/*     */   {
/* 115 */     this.clientsLock.lock();
/*     */     try {
/* 117 */       Collection<T> copy = new ArrayList(this.clients);
/* 118 */       return copy;
/*     */     } finally {
/* 120 */       this.clientsLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/* 128 */     setRunning(true);
/*     */     try {
/* 130 */       addInfo("listening on " + this.listener);
/* 131 */       while (!Thread.currentThread().isInterrupted()) {
/* 132 */         T client = this.listener.acceptClient();
/* 133 */         if (!configureClient(client)) {
/* 134 */           addError(client + ": connection dropped");
/* 135 */           client.close();
/*     */         }
/*     */         else {
/*     */           try {
/* 139 */             this.executor.execute(new ClientWrapper(client));
/*     */           } catch (RejectedExecutionException ex) {
/* 141 */             addError(client + ": connection dropped");
/* 142 */             client.close();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (InterruptedException localInterruptedException) {}catch (Exception ex) {
/* 148 */       addError("listener: " + ex);
/*     */     }
/*     */     
/* 151 */     setRunning(false);
/* 152 */     addInfo("shutting down");
/* 153 */     this.listener.close();
/*     */   }
/*     */   
/*     */   protected abstract boolean configureClient(T paramT);
/*     */   
/*     */   /* Error */
/*     */   private void addClient(T client)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 6	ch/qos/logback/core/net/server/ConcurrentServerRunner:clientsLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   4: invokeinterface 31 1 0
/*     */     //   9: aload_0
/*     */     //   10: getfield 9	ch/qos/logback/core/net/server/ConcurrentServerRunner:clients	Ljava/util/Collection;
/*     */     //   13: aload_1
/*     */     //   14: invokeinterface 51 2 0
/*     */     //   19: pop
/*     */     //   20: aload_0
/*     */     //   21: getfield 6	ch/qos/logback/core/net/server/ConcurrentServerRunner:clientsLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   24: invokeinterface 33 1 0
/*     */     //   29: goto +15 -> 44
/*     */     //   32: astore_2
/*     */     //   33: aload_0
/*     */     //   34: getfield 6	ch/qos/logback/core/net/server/ConcurrentServerRunner:clientsLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   37: invokeinterface 33 1 0
/*     */     //   42: aload_2
/*     */     //   43: athrow
/*     */     //   44: return
/*     */     // Line number table:
/*     */     //   Java source line #173	-> byte code offset #0
/*     */     //   Java source line #175	-> byte code offset #9
/*     */     //   Java source line #177	-> byte code offset #20
/*     */     //   Java source line #178	-> byte code offset #29
/*     */     //   Java source line #177	-> byte code offset #32
/*     */     //   Java source line #179	-> byte code offset #44
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	45	0	this	ConcurrentServerRunner<T>
/*     */     //   0	45	1	client	T
/*     */     //   32	11	2	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   9	20	32	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void removeClient(T client)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 6	ch/qos/logback/core/net/server/ConcurrentServerRunner:clientsLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   4: invokeinterface 31 1 0
/*     */     //   9: aload_0
/*     */     //   10: getfield 9	ch/qos/logback/core/net/server/ConcurrentServerRunner:clients	Ljava/util/Collection;
/*     */     //   13: aload_1
/*     */     //   14: invokeinterface 52 2 0
/*     */     //   19: pop
/*     */     //   20: aload_0
/*     */     //   21: getfield 6	ch/qos/logback/core/net/server/ConcurrentServerRunner:clientsLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   24: invokeinterface 33 1 0
/*     */     //   29: goto +15 -> 44
/*     */     //   32: astore_2
/*     */     //   33: aload_0
/*     */     //   34: getfield 6	ch/qos/logback/core/net/server/ConcurrentServerRunner:clientsLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   37: invokeinterface 33 1 0
/*     */     //   42: aload_2
/*     */     //   43: athrow
/*     */     //   44: return
/*     */     // Line number table:
/*     */     //   Java source line #186	-> byte code offset #0
/*     */     //   Java source line #188	-> byte code offset #9
/*     */     //   Java source line #190	-> byte code offset #20
/*     */     //   Java source line #191	-> byte code offset #29
/*     */     //   Java source line #190	-> byte code offset #32
/*     */     //   Java source line #192	-> byte code offset #44
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	45	0	this	ConcurrentServerRunner<T>
/*     */     //   0	45	1	client	T
/*     */     //   32	11	2	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   9	20	32	finally
/*     */   }
/*     */   
/*     */   private class ClientWrapper
/*     */     implements Client
/*     */   {
/*     */     private final T delegate;
/*     */     
/*     */     public ClientWrapper()
/*     */     {
/* 203 */       this.delegate = client;
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     public void run()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: getfield 1	ch/qos/logback/core/net/server/ConcurrentServerRunner$ClientWrapper:this$0	Lch/qos/logback/core/net/server/ConcurrentServerRunner;
/*     */       //   4: aload_0
/*     */       //   5: getfield 3	ch/qos/logback/core/net/server/ConcurrentServerRunner$ClientWrapper:delegate	Lch/qos/logback/core/net/server/Client;
/*     */       //   8: invokestatic 4	ch/qos/logback/core/net/server/ConcurrentServerRunner:access$000	(Lch/qos/logback/core/net/server/ConcurrentServerRunner;Lch/qos/logback/core/net/server/Client;)V
/*     */       //   11: aload_0
/*     */       //   12: getfield 3	ch/qos/logback/core/net/server/ConcurrentServerRunner$ClientWrapper:delegate	Lch/qos/logback/core/net/server/Client;
/*     */       //   15: invokeinterface 5 1 0
/*     */       //   20: aload_0
/*     */       //   21: getfield 1	ch/qos/logback/core/net/server/ConcurrentServerRunner$ClientWrapper:this$0	Lch/qos/logback/core/net/server/ConcurrentServerRunner;
/*     */       //   24: aload_0
/*     */       //   25: getfield 3	ch/qos/logback/core/net/server/ConcurrentServerRunner$ClientWrapper:delegate	Lch/qos/logback/core/net/server/Client;
/*     */       //   28: invokestatic 6	ch/qos/logback/core/net/server/ConcurrentServerRunner:access$100	(Lch/qos/logback/core/net/server/ConcurrentServerRunner;Lch/qos/logback/core/net/server/Client;)V
/*     */       //   31: goto +17 -> 48
/*     */       //   34: astore_1
/*     */       //   35: aload_0
/*     */       //   36: getfield 1	ch/qos/logback/core/net/server/ConcurrentServerRunner$ClientWrapper:this$0	Lch/qos/logback/core/net/server/ConcurrentServerRunner;
/*     */       //   39: aload_0
/*     */       //   40: getfield 3	ch/qos/logback/core/net/server/ConcurrentServerRunner$ClientWrapper:delegate	Lch/qos/logback/core/net/server/Client;
/*     */       //   43: invokestatic 6	ch/qos/logback/core/net/server/ConcurrentServerRunner:access$100	(Lch/qos/logback/core/net/server/ConcurrentServerRunner;Lch/qos/logback/core/net/server/Client;)V
/*     */       //   46: aload_1
/*     */       //   47: athrow
/*     */       //   48: return
/*     */       // Line number table:
/*     */       //   Java source line #207	-> byte code offset #0
/*     */       //   Java source line #209	-> byte code offset #11
/*     */       //   Java source line #211	-> byte code offset #20
/*     */       //   Java source line #212	-> byte code offset #31
/*     */       //   Java source line #211	-> byte code offset #34
/*     */       //   Java source line #213	-> byte code offset #48
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	49	0	this	ConcurrentServerRunner<T>.ClientWrapper
/*     */       //   34	13	1	localObject	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   11	20	34	finally
/*     */     }
/*     */     
/*     */     public void close()
/*     */     {
/* 216 */       this.delegate.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\net\server\ConcurrentServerRunner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */