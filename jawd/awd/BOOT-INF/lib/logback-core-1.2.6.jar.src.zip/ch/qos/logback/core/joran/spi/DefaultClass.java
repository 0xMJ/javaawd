package ch.qos.logback.core.joran.spi;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.METHOD})
public @interface DefaultClass
{
  Class<?> value();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\joran\spi\DefaultClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */