/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.encoder.Encoder;
/*     */ import ch.qos.logback.core.encoder.LayoutWrappingEncoder;
/*     */ import ch.qos.logback.core.spi.DeferredProcessingAware;
/*     */ import ch.qos.logback.core.status.ErrorStatus;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OutputStreamAppender<E>
/*     */   extends UnsynchronizedAppenderBase<E>
/*     */ {
/*     */   protected Encoder<E> encoder;
/*  47 */   protected final ReentrantLock lock = new ReentrantLock(false);
/*     */   
/*     */ 
/*     */ 
/*     */   private OutputStream outputStream;
/*     */   
/*     */ 
/*  54 */   boolean immediateFlush = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OutputStream getOutputStream()
/*     */   {
/*  62 */     return this.outputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/*  70 */     int errors = 0;
/*  71 */     if (this.encoder == null) {
/*  72 */       addStatus(new ErrorStatus("No encoder set for the appender named \"" + this.name + "\".", this));
/*  73 */       errors++;
/*     */     }
/*     */     
/*  76 */     if (this.outputStream == null) {
/*  77 */       addStatus(new ErrorStatus("No output stream set for the appender named \"" + this.name + "\".", this));
/*  78 */       errors++;
/*     */     }
/*     */     
/*  81 */     if (errors == 0) {
/*  82 */       super.start();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setLayout(Layout<E> layout) {
/*  87 */     addWarn("This appender no longer admits a layout as a sub-component, set an encoder instead.");
/*  88 */     addWarn("To ensure compatibility, wrapping your layout in LayoutWrappingEncoder.");
/*  89 */     addWarn("See also http://logback.qos.ch/codes.html#layoutInsteadOfEncoder for details");
/*  90 */     LayoutWrappingEncoder<E> lwe = new LayoutWrappingEncoder();
/*  91 */     lwe.setLayout(layout);
/*  92 */     lwe.setContext(this.context);
/*  93 */     this.encoder = lwe;
/*     */   }
/*     */   
/*     */   protected void append(E eventObject)
/*     */   {
/*  98 */     if (!isStarted()) {
/*  99 */       return;
/*     */     }
/*     */     
/* 102 */     subAppend(eventObject);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void stop()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 5	ch/qos/logback/core/OutputStreamAppender:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*     */     //   4: invokevirtual 32	java/util/concurrent/locks/ReentrantLock:lock	()V
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual 33	ch/qos/logback/core/OutputStreamAppender:closeOutputStream	()V
/*     */     //   11: aload_0
/*     */     //   12: invokespecial 34	ch/qos/logback/core/UnsynchronizedAppenderBase:stop	()V
/*     */     //   15: aload_0
/*     */     //   16: getfield 5	ch/qos/logback/core/OutputStreamAppender:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*     */     //   19: invokevirtual 35	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*     */     //   22: goto +13 -> 35
/*     */     //   25: astore_1
/*     */     //   26: aload_0
/*     */     //   27: getfield 5	ch/qos/logback/core/OutputStreamAppender:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*     */     //   30: invokevirtual 35	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*     */     //   33: aload_1
/*     */     //   34: athrow
/*     */     //   35: return
/*     */     // Line number table:
/*     */     //   Java source line #113	-> byte code offset #0
/*     */     //   Java source line #115	-> byte code offset #7
/*     */     //   Java source line #116	-> byte code offset #11
/*     */     //   Java source line #118	-> byte code offset #15
/*     */     //   Java source line #119	-> byte code offset #22
/*     */     //   Java source line #118	-> byte code offset #25
/*     */     //   Java source line #120	-> byte code offset #35
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	36	0	this	OutputStreamAppender<E>
/*     */     //   25	9	1	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	15	25	finally
/*     */   }
/*     */   
/*     */   protected void closeOutputStream()
/*     */   {
/* 126 */     if (this.outputStream != null) {
/*     */       try
/*     */       {
/* 129 */         encoderClose();
/* 130 */         this.outputStream.close();
/* 131 */         this.outputStream = null;
/*     */       } catch (IOException e) {
/* 133 */         addStatus(new ErrorStatus("Could not close output stream for OutputStreamAppender.", this, e));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void encoderClose() {
/* 139 */     if ((this.encoder != null) && (this.outputStream != null)) {
/*     */       try {
/* 141 */         byte[] footer = this.encoder.footerBytes();
/* 142 */         writeBytes(footer);
/*     */       } catch (IOException ioe) {
/* 144 */         this.started = false;
/* 145 */         addStatus(new ErrorStatus("Failed to write footer for appender named [" + this.name + "].", this, ioe));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutputStream(OutputStream outputStream)
/*     */   {
/* 161 */     this.lock.lock();
/*     */     try
/*     */     {
/* 164 */       closeOutputStream();
/* 165 */       this.outputStream = outputStream;
/* 166 */       if (this.encoder == null) {
/* 167 */         addWarn("Encoder has not been set. Cannot invoke its init method.");
/* 168 */         return;
/*     */       }
/*     */       
/* 171 */       encoderInit();
/*     */     } finally {
/* 173 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   void encoderInit() {
/* 178 */     if ((this.encoder != null) && (this.outputStream != null))
/*     */       try {
/* 180 */         byte[] header = this.encoder.headerBytes();
/* 181 */         writeBytes(header);
/*     */       } catch (IOException ioe) {
/* 183 */         this.started = false;
/* 184 */         addStatus(new ErrorStatus("Failed to initialize encoder for appender named [" + this.name + "].", this, ioe));
/*     */       }
/*     */   }
/*     */   
/*     */   protected void writeOut(E event) throws IOException {
/* 189 */     byte[] byteArray = this.encoder.encode(event);
/* 190 */     writeBytes(byteArray);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void writeBytes(byte[] byteArray)
/*     */     throws IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ifnull +8 -> 9
/*     */     //   4: aload_1
/*     */     //   5: arraylength
/*     */     //   6: ifne +4 -> 10
/*     */     //   9: return
/*     */     //   10: aload_0
/*     */     //   11: getfield 5	ch/qos/logback/core/OutputStreamAppender:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*     */     //   14: invokevirtual 32	java/util/concurrent/locks/ReentrantLock:lock	()V
/*     */     //   17: aload_0
/*     */     //   18: getfield 7	ch/qos/logback/core/OutputStreamAppender:outputStream	Ljava/io/OutputStream;
/*     */     //   21: aload_1
/*     */     //   22: invokevirtual 51	java/io/OutputStream:write	([B)V
/*     */     //   25: aload_0
/*     */     //   26: getfield 6	ch/qos/logback/core/OutputStreamAppender:immediateFlush	Z
/*     */     //   29: ifeq +10 -> 39
/*     */     //   32: aload_0
/*     */     //   33: getfield 7	ch/qos/logback/core/OutputStreamAppender:outputStream	Ljava/io/OutputStream;
/*     */     //   36: invokevirtual 52	java/io/OutputStream:flush	()V
/*     */     //   39: aload_0
/*     */     //   40: getfield 5	ch/qos/logback/core/OutputStreamAppender:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*     */     //   43: invokevirtual 35	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*     */     //   46: goto +13 -> 59
/*     */     //   49: astore_2
/*     */     //   50: aload_0
/*     */     //   51: getfield 5	ch/qos/logback/core/OutputStreamAppender:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*     */     //   54: invokevirtual 35	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*     */     //   57: aload_2
/*     */     //   58: athrow
/*     */     //   59: return
/*     */     // Line number table:
/*     */     //   Java source line #194	-> byte code offset #0
/*     */     //   Java source line #195	-> byte code offset #9
/*     */     //   Java source line #197	-> byte code offset #10
/*     */     //   Java source line #199	-> byte code offset #17
/*     */     //   Java source line #200	-> byte code offset #25
/*     */     //   Java source line #201	-> byte code offset #32
/*     */     //   Java source line #204	-> byte code offset #39
/*     */     //   Java source line #205	-> byte code offset #46
/*     */     //   Java source line #204	-> byte code offset #49
/*     */     //   Java source line #206	-> byte code offset #59
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	60	0	this	OutputStreamAppender<E>
/*     */     //   0	60	1	byteArray	byte[]
/*     */     //   49	9	2	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   17	39	49	finally
/*     */   }
/*     */   
/*     */   protected void subAppend(E event)
/*     */   {
/* 217 */     if (!isStarted()) {
/* 218 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 222 */       if ((event instanceof DeferredProcessingAware)) {
/* 223 */         ((DeferredProcessingAware)event).prepareForDeferredProcessing();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 230 */       byte[] byteArray = this.encoder.encode(event);
/* 231 */       writeBytes(byteArray);
/*     */ 
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/* 236 */       this.started = false;
/* 237 */       addStatus(new ErrorStatus("IO failure in appender", this, ioe));
/*     */     }
/*     */   }
/*     */   
/*     */   public Encoder<E> getEncoder() {
/* 242 */     return this.encoder;
/*     */   }
/*     */   
/*     */   public void setEncoder(Encoder<E> encoder) {
/* 246 */     this.encoder = encoder;
/*     */   }
/*     */   
/*     */   public boolean isImmediateFlush() {
/* 250 */     return this.immediateFlush;
/*     */   }
/*     */   
/*     */   public void setImmediateFlush(boolean immediateFlush) {
/* 254 */     this.immediateFlush = immediateFlush;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\OutputStreamAppender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */