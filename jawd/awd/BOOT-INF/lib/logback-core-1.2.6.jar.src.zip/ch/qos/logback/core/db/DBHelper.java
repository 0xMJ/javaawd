/*    */ package ch.qos.logback.core.db;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DBHelper
/*    */ {
/*    */   public static void closeConnection(Connection connection)
/*    */   {
/* 27 */     if (connection != null) {
/*    */       try {
/* 29 */         connection.close();
/*    */       }
/*    */       catch (SQLException localSQLException) {}
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public static void closeStatement(Statement statement)
/*    */   {
/* 38 */     if (statement != null) {
/*    */       try {
/* 40 */         statement.close();
/*    */       }
/*    */       catch (SQLException localSQLException) {}
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\db\DBHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */