package ch.qos.logback.core.helpers;

import ch.qos.logback.core.AppenderBase;

public final class NOPAppender<E>
  extends AppenderBase<E>
{
  protected void append(E eventObject) {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\helpers\NOPAppender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */