package ch.qos.logback.core.net.server;

public abstract interface ClientVisitor<T extends Client>
{
  public abstract void visit(T paramT);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-core-1.2.6.jar!\ch\qos\logback\core\net\server\ClientVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */