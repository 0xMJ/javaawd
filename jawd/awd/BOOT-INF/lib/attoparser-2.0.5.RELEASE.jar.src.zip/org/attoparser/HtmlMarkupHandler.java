/*     */ package org.attoparser;
/*     */ 
/*     */ import org.attoparser.config.ParseConfiguration;
/*     */ import org.attoparser.config.ParseConfiguration.ElementBalancing;
/*     */ import org.attoparser.select.ParseSelection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HtmlMarkupHandler
/*     */   extends AbstractMarkupHandler
/*     */ {
/*  38 */   private static final char[] HEAD_BUFFER = "head".toCharArray();
/*  39 */   private static final char[] BODY_BUFFER = "body".toCharArray();
/*     */   
/*     */   private final IMarkupHandler next;
/*     */   
/*  43 */   private ParseStatus status = null;
/*  44 */   private boolean autoOpenEnabled = false;
/*  45 */   private boolean autoCloseEnabled = false;
/*  46 */   private HtmlElement currentElement = null;
/*     */   
/*  48 */   private int markupLevel = 0;
/*     */   
/*  50 */   private boolean htmlElementHandled = false;
/*  51 */   private boolean headElementHandled = false;
/*  52 */   private boolean bodyElementHandled = false;
/*     */   
/*     */ 
/*     */ 
/*     */   HtmlMarkupHandler(IMarkupHandler next)
/*     */   {
/*  58 */     if (next == null) {
/*  59 */       throw new IllegalArgumentException("Chained handler cannot be null");
/*     */     }
/*  61 */     this.next = next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParseStatus(ParseStatus status)
/*     */   {
/*  69 */     this.status = status;
/*  70 */     this.next.setParseStatus(status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParseSelection(ParseSelection selection)
/*     */   {
/*  78 */     this.next.setParseSelection(selection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParseConfiguration(ParseConfiguration parseConfiguration)
/*     */   {
/*  87 */     this.autoOpenEnabled = (ParseConfiguration.ElementBalancing.AUTO_OPEN_CLOSE == parseConfiguration.getElementBalancing());
/*     */     
/*     */ 
/*  90 */     this.autoCloseEnabled = ((ParseConfiguration.ElementBalancing.AUTO_OPEN_CLOSE == parseConfiguration.getElementBalancing()) || (ParseConfiguration.ElementBalancing.AUTO_CLOSE == parseConfiguration.getElementBalancing()));
/*     */     
/*  92 */     this.next.setParseConfiguration(parseConfiguration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentStart(long startTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 104 */     this.next.handleDocumentStart(startTimeNanos, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 115 */     this.next.handleDocumentEnd(endTimeNanos, totalTimeNanos, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleXmlDeclaration(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int versionOffset, int versionLen, int versionLine, int versionCol, int encodingOffset, int encodingLen, int encodingLine, int encodingCol, int standaloneOffset, int standaloneLen, int standaloneLine, int standaloneCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 132 */     this.next.handleXmlDeclaration(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, versionOffset, versionLen, versionLine, versionCol, encodingOffset, encodingLen, encodingLine, encodingCol, standaloneOffset, standaloneLen, standaloneLine, standaloneCol, outerOffset, outerLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocType(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int elementNameOffset, int elementNameLen, int elementNameLine, int elementNameCol, int typeOffset, int typeLen, int typeLine, int typeCol, int publicIdOffset, int publicIdLen, int publicIdLine, int publicIdCol, int systemIdOffset, int systemIdLen, int systemIdLine, int systemIdCol, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, int outerOffset, int outerLen, int outerLine, int outerCol)
/*     */     throws ParseException
/*     */   {
/* 158 */     this.next.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, publicIdOffset, publicIdLen, publicIdLine, publicIdCol, systemIdOffset, systemIdLen, systemIdLine, systemIdCol, internalSubsetOffset, internalSubsetLen, internalSubsetLine, internalSubsetCol, outerOffset, outerLen, outerLine, outerCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCDATASection(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 181 */     this.next.handleCDATASection(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 195 */     this.next.handleComment(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 208 */     this.next.handleText(buffer, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 221 */     this.currentElement = HtmlElements.forName(buffer, nameOffset, nameLen);
/* 222 */     this.currentElement.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 233 */     if (this.currentElement == null) {
/* 234 */       throw new IllegalStateException("Cannot end element: no current element");
/*     */     }
/*     */     
/* 237 */     HtmlElement element = this.currentElement;
/* 238 */     this.currentElement = null;
/*     */     
/*     */ 
/* 241 */     element.handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 255 */     this.currentElement = HtmlElements.forName(buffer, nameOffset, nameLen);
/*     */     
/* 257 */     if (this.autoOpenEnabled) {
/* 258 */       if ((this.markupLevel == 0) && (this.currentElement == HtmlElements.HTML)) {
/* 259 */         this.htmlElementHandled = true;
/* 260 */       } else if ((this.markupLevel == 1) && (this.htmlElementHandled) && (this.currentElement == HtmlElements.HEAD)) {
/* 261 */         this.headElementHandled = true;
/* 262 */       } else if ((this.markupLevel == 1) && (this.htmlElementHandled) && (this.currentElement == HtmlElements.BODY)) {
/* 263 */         if (!this.headElementHandled)
/*     */         {
/* 265 */           HtmlElement headElement = HtmlElements.forName(HEAD_BUFFER, 0, HEAD_BUFFER.length);
/* 266 */           headElement.handleAutoOpenElementStart(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 267 */           headElement.handleAutoOpenElementEnd(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 268 */           headElement.handleAutoCloseElementStart(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 269 */           headElement.handleAutoCloseElementEnd(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 270 */           this.headElementHandled = true;
/*     */         }
/* 272 */         this.bodyElementHandled = true;
/*     */       }
/*     */     }
/*     */     
/* 276 */     this.currentElement.handleOpenElementStart(buffer, nameOffset, nameLen, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 287 */     if (this.currentElement == null) {
/* 288 */       throw new IllegalStateException("Cannot end element: no current element");
/*     */     }
/*     */     
/* 291 */     this.markupLevel += 1;
/*     */     
/* 293 */     HtmlElement element = this.currentElement;
/* 294 */     this.currentElement = null;
/*     */     
/*     */ 
/* 297 */     element.handleOpenElementEnd(buffer, nameOffset, nameLen, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 310 */     this.currentElement = HtmlElements.forName(buffer, nameOffset, nameLen);
/*     */     
/* 312 */     if (this.autoOpenEnabled) {
/* 313 */       if ((this.markupLevel == 0) && (this.currentElement == HtmlElements.HTML)) {
/* 314 */         this.htmlElementHandled = true;
/* 315 */       } else if ((this.markupLevel == 1) && (this.htmlElementHandled) && (this.currentElement == HtmlElements.HEAD)) {
/* 316 */         this.headElementHandled = true;
/* 317 */       } else if ((this.markupLevel == 1) && (this.htmlElementHandled) && (this.currentElement == HtmlElements.BODY)) {
/* 318 */         if (!this.headElementHandled)
/*     */         {
/* 320 */           HtmlElement headElement = HtmlElements.forName(HEAD_BUFFER, 0, HEAD_BUFFER.length);
/* 321 */           headElement.handleAutoOpenElementStart(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 322 */           headElement.handleAutoOpenElementEnd(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 323 */           headElement.handleAutoCloseElementStart(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 324 */           headElement.handleAutoCloseElementEnd(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 325 */           this.headElementHandled = true;
/*     */         }
/* 327 */         this.bodyElementHandled = true;
/*     */       }
/*     */     }
/*     */     
/* 331 */     this.currentElement.handleAutoOpenElementStart(buffer, nameOffset, nameLen, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 342 */     if (this.currentElement == null) {
/* 343 */       throw new IllegalStateException("Cannot end element: no current element");
/*     */     }
/*     */     
/* 346 */     this.markupLevel += 1;
/*     */     
/* 348 */     HtmlElement element = this.currentElement;
/* 349 */     this.currentElement = null;
/*     */     
/*     */ 
/* 352 */     element.handleAutoOpenElementEnd(buffer, nameOffset, nameLen, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 366 */     this.markupLevel -= 1;
/*     */     
/* 368 */     this.currentElement = HtmlElements.forName(buffer, nameOffset, nameLen);
/*     */     
/* 370 */     if ((this.autoOpenEnabled) && 
/* 371 */       (this.markupLevel == 0) && (this.htmlElementHandled) && (this.currentElement == HtmlElements.HTML)) {
/* 372 */       if (!this.headElementHandled)
/*     */       {
/* 374 */         HtmlElement headElement = HtmlElements.forName(HEAD_BUFFER, 0, HEAD_BUFFER.length);
/* 375 */         headElement.handleAutoOpenElementStart(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 376 */         headElement.handleAutoOpenElementEnd(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 377 */         headElement.handleAutoCloseElementStart(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 378 */         headElement.handleAutoCloseElementEnd(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 379 */         this.headElementHandled = true;
/*     */       }
/* 381 */       if (!this.bodyElementHandled)
/*     */       {
/* 383 */         HtmlElement headElement = HtmlElements.forName(BODY_BUFFER, 0, BODY_BUFFER.length);
/* 384 */         headElement.handleAutoOpenElementStart(BODY_BUFFER, 0, BODY_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 385 */         headElement.handleAutoOpenElementEnd(BODY_BUFFER, 0, BODY_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 386 */         headElement.handleAutoCloseElementStart(BODY_BUFFER, 0, BODY_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 387 */         headElement.handleAutoCloseElementEnd(BODY_BUFFER, 0, BODY_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 388 */         this.bodyElementHandled = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 393 */     this.currentElement.handleCloseElementStart(buffer, nameOffset, nameLen, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 404 */     if (this.currentElement == null) {
/* 405 */       throw new IllegalStateException("Cannot end element: no current element");
/*     */     }
/*     */     
/* 408 */     HtmlElement element = this.currentElement;
/* 409 */     this.currentElement = null;
/*     */     
/*     */ 
/* 412 */     element.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 426 */     this.markupLevel -= 1;
/*     */     
/* 428 */     this.currentElement = HtmlElements.forName(buffer, nameOffset, nameLen);
/*     */     
/* 430 */     if ((this.autoOpenEnabled) && 
/* 431 */       (this.markupLevel == 0) && (this.htmlElementHandled) && (this.currentElement == HtmlElements.HTML)) {
/* 432 */       if (!this.headElementHandled)
/*     */       {
/* 434 */         HtmlElement headElement = HtmlElements.forName(HEAD_BUFFER, 0, HEAD_BUFFER.length);
/* 435 */         headElement.handleAutoOpenElementStart(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 436 */         headElement.handleAutoOpenElementEnd(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 437 */         headElement.handleAutoCloseElementStart(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 438 */         headElement.handleAutoCloseElementEnd(HEAD_BUFFER, 0, HEAD_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 439 */         this.headElementHandled = true;
/*     */       }
/* 441 */       if (!this.bodyElementHandled)
/*     */       {
/* 443 */         HtmlElement headElement = HtmlElements.forName(BODY_BUFFER, 0, BODY_BUFFER.length);
/* 444 */         headElement.handleAutoOpenElementStart(BODY_BUFFER, 0, BODY_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 445 */         headElement.handleAutoOpenElementEnd(BODY_BUFFER, 0, BODY_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 446 */         headElement.handleAutoCloseElementStart(BODY_BUFFER, 0, BODY_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 447 */         headElement.handleAutoCloseElementEnd(BODY_BUFFER, 0, BODY_BUFFER.length, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/* 448 */         this.bodyElementHandled = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 453 */     this.currentElement.handleAutoCloseElementStart(buffer, nameOffset, nameLen, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 464 */     if (this.currentElement == null) {
/* 465 */       throw new IllegalStateException("Cannot end element: no current element");
/*     */     }
/*     */     
/* 468 */     HtmlElement element = this.currentElement;
/* 469 */     this.currentElement = null;
/*     */     
/*     */ 
/* 472 */     element.handleAutoCloseElementEnd(buffer, nameOffset, nameLen, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 486 */     this.currentElement = HtmlElements.forName(buffer, nameOffset, nameLen);
/* 487 */     this.currentElement.handleUnmatchedCloseElementStart(buffer, nameOffset, nameLen, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 498 */     if (this.currentElement == null) {
/* 499 */       throw new IllegalStateException("Cannot end element: no current element");
/*     */     }
/*     */     
/* 502 */     HtmlElement element = this.currentElement;
/* 503 */     this.currentElement = null;
/*     */     
/*     */ 
/* 506 */     element.handleUnmatchedCloseElementEnd(buffer, nameOffset, nameLen, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws ParseException
/*     */   {
/* 525 */     if (this.currentElement == null) {
/* 526 */       throw new IllegalStateException("Cannot handle attribute: no current element");
/*     */     }
/*     */     
/* 529 */     this.currentElement.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 546 */     if (this.currentElement == null) {
/* 547 */       throw new IllegalStateException("Cannot handle attribute: no current element");
/*     */     }
/*     */     
/* 550 */     this.currentElement.handleInnerWhiteSpace(buffer, offset, len, line, col, this.next, this.status, this.autoOpenEnabled, this.autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleProcessingInstruction(char[] buffer, int targetOffset, int targetLen, int targetLine, int targetCol, int contentOffset, int contentLen, int contentLine, int contentCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 566 */     this.next.handleProcessingInstruction(buffer, targetOffset, targetLen, targetLine, targetCol, contentOffset, contentLen, contentLine, contentCol, outerOffset, outerLen, line, col);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\HtmlMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */