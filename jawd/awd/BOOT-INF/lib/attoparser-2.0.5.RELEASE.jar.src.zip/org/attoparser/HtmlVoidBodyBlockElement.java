/*    */ package org.attoparser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HtmlVoidBodyBlockElement
/*    */   extends HtmlVoidAutoOpenCloseElement
/*    */ {
/* 33 */   private static final String[] ARRAY_HTML_BODY = { "html", "body" };
/* 34 */   private static final String[] ARRAY_P_HEAD = { "p", "head" };
/* 35 */   private static final String[] AUTO_CLOSE_LIMITS = { "script", "template", "element", "decorator", "content", "shadow" };
/*    */   
/*    */   HtmlVoidBodyBlockElement(String name) {
/* 38 */     super(name, ARRAY_HTML_BODY, null, ARRAY_P_HEAD, AUTO_CLOSE_LIMITS);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\HtmlVoidBodyBlockElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */