/*    */ package org.attoparser.select;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MarkupSelectorOrItem
/*    */   implements IMarkupSelectorItem
/*    */ {
/*    */   final IMarkupSelectorItem left;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   final IMarkupSelectorItem right;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   MarkupSelectorOrItem(IMarkupSelectorItem left, IMarkupSelectorItem right)
/*    */   {
/* 35 */     if (((right.anyLevel()) && (!left.anyLevel())) || ((!right.anyLevel()) && (left.anyLevel()))) {
/* 36 */       throw new IllegalArgumentException("Left and right items must have the same value for ''anyLevel': " + left.toString() + " && " + right.toString());
/*    */     }
/* 38 */     this.left = left;
/* 39 */     this.right = right;
/*    */   }
/*    */   
/*    */   public boolean anyLevel()
/*    */   {
/* 44 */     return this.left.anyLevel();
/*    */   }
/*    */   
/*    */   public boolean matchesText(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*    */   {
/* 49 */     return (this.left.matchesText(markupBlockIndex, markupBlockMatchingCounter)) || 
/* 50 */       (this.right.matchesText(markupBlockIndex, markupBlockMatchingCounter));
/*    */   }
/*    */   
/*    */   public boolean matchesComment(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*    */   {
/* 55 */     return (this.left.matchesComment(markupBlockIndex, markupBlockMatchingCounter)) || 
/* 56 */       (this.right.matchesComment(markupBlockIndex, markupBlockMatchingCounter));
/*    */   }
/*    */   
/*    */   public boolean matchesCDATASection(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*    */   {
/* 61 */     return (this.left.matchesCDATASection(markupBlockIndex, markupBlockMatchingCounter)) || 
/* 62 */       (this.right.matchesCDATASection(markupBlockIndex, markupBlockMatchingCounter));
/*    */   }
/*    */   
/*    */   public boolean matchesDocTypeClause(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*    */   {
/* 67 */     return (this.left.matchesDocTypeClause(markupBlockIndex, markupBlockMatchingCounter)) || 
/* 68 */       (this.right.matchesDocTypeClause(markupBlockIndex, markupBlockMatchingCounter));
/*    */   }
/*    */   
/*    */   public boolean matchesXmlDeclaration(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*    */   {
/* 73 */     return (this.left.matchesXmlDeclaration(markupBlockIndex, markupBlockMatchingCounter)) || 
/* 74 */       (this.right.matchesXmlDeclaration(markupBlockIndex, markupBlockMatchingCounter));
/*    */   }
/*    */   
/*    */   public boolean matchesProcessingInstruction(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*    */   {
/* 79 */     return (this.left.matchesProcessingInstruction(markupBlockIndex, markupBlockMatchingCounter)) || 
/* 80 */       (this.right.matchesProcessingInstruction(markupBlockIndex, markupBlockMatchingCounter));
/*    */   }
/*    */   
/*    */   public boolean matchesElement(int markupBlockIndex, SelectorElementBuffer elementBuffer, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter) {
/* 84 */     return (this.left.matchesElement(markupBlockIndex, elementBuffer, markupBlockMatchingCounter)) || 
/* 85 */       (this.right.matchesElement(markupBlockIndex, elementBuffer, markupBlockMatchingCounter));
/*    */   }
/*    */   
/*    */   public String toString() {
/* 89 */     return "(" + this.left.toString() + " || " + this.right + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\select\MarkupSelectorOrItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */