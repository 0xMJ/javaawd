/*     */ package org.attoparser.select;
/*     */ 
/*     */ import org.attoparser.AbstractChainedMarkupHandler;
/*     */ import org.attoparser.IMarkupHandler;
/*     */ import org.attoparser.ParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AttributeSelectionMarkingMarkupHandler
/*     */   extends AbstractChainedMarkupHandler
/*     */ {
/*  49 */   private static final char[] INNER_WHITESPACE_BUFFER = " ".toCharArray();
/*     */   
/*     */   private final char[] selectorAttributeName;
/*     */   
/*     */   private final int selectorAttributeNameLen;
/*     */   
/*     */   private ParseSelection selection;
/*  56 */   private boolean lastWasInnerWhiteSpace = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private char[] selectorAttributeBuffer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AttributeSelectionMarkingMarkupHandler(String selectorAttributeName, IMarkupHandler handler)
/*     */   {
/*  71 */     super(handler);
/*     */     
/*  73 */     if ((selectorAttributeName == null) || (selectorAttributeName.trim().length() == 0)) {
/*  74 */       throw new IllegalArgumentException("Selector attribute name cannot be null or empty");
/*     */     }
/*     */     
/*  77 */     this.selectorAttributeName = selectorAttributeName.toCharArray();
/*  78 */     this.selectorAttributeNameLen = this.selectorAttributeName.length;
/*  79 */     this.selectorAttributeBuffer = new char[this.selectorAttributeNameLen + 20];
/*  80 */     System.arraycopy(this.selectorAttributeName, 0, this.selectorAttributeBuffer, 0, this.selectorAttributeNameLen);
/*  81 */     this.selectorAttributeBuffer[this.selectorAttributeNameLen] = '=';
/*  82 */     this.selectorAttributeBuffer[(this.selectorAttributeNameLen + 1)] = '"';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setParseSelection(ParseSelection selection)
/*     */   {
/*  89 */     this.selection = selection;
/*  90 */     super.setParseSelection(selection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws ParseException
/*     */   {
/* 106 */     this.lastWasInnerWhiteSpace = false;
/* 107 */     getNext().handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 123 */     if (this.selection.isMatchingAny())
/*     */     {
/* 125 */       if (!this.lastWasInnerWhiteSpace) {
/* 126 */         getNext().handleInnerWhiteSpace(INNER_WHITESPACE_BUFFER, 0, INNER_WHITESPACE_BUFFER.length, line, col);
/* 127 */         this.lastWasInnerWhiteSpace = true;
/*     */       }
/*     */       
/* 130 */       String selectorValues = this.selection.toString();
/*     */       
/* 132 */       int selectorValuesLen = selectorValues.length();
/* 133 */       checkSelectorAttributeLen(selectorValuesLen);
/*     */       
/* 135 */       selectorValues.getChars(0, selectorValuesLen, this.selectorAttributeBuffer, this.selectorAttributeNameLen + 2);
/* 136 */       this.selectorAttributeBuffer[(this.selectorAttributeNameLen + 2 + selectorValuesLen)] = '"';
/*     */       
/* 138 */       getNext().handleAttribute(this.selectorAttributeBuffer, 0, this.selectorAttributeNameLen, line, col, this.selectorAttributeNameLen, 1, line, col, this.selectorAttributeNameLen + 2, selectorValuesLen, this.selectorAttributeNameLen + 1, selectorValuesLen + 2, line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */     this.lastWasInnerWhiteSpace = false;
/* 148 */     getNext().handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 159 */     if (this.selection.isMatchingAny())
/*     */     {
/* 161 */       if (!this.lastWasInnerWhiteSpace) {
/* 162 */         getNext().handleInnerWhiteSpace(INNER_WHITESPACE_BUFFER, 0, INNER_WHITESPACE_BUFFER.length, line, col);
/* 163 */         this.lastWasInnerWhiteSpace = true;
/*     */       }
/*     */       
/* 166 */       String selectorValues = this.selection.toString();
/*     */       
/* 168 */       int selectorValuesLen = selectorValues.length();
/* 169 */       checkSelectorAttributeLen(selectorValuesLen);
/*     */       
/* 171 */       selectorValues.getChars(0, selectorValuesLen, this.selectorAttributeBuffer, this.selectorAttributeNameLen + 2);
/* 172 */       this.selectorAttributeBuffer[(this.selectorAttributeNameLen + 2 + selectorValuesLen)] = '"';
/*     */       
/* 174 */       getNext().handleAttribute(this.selectorAttributeBuffer, 0, this.selectorAttributeNameLen, line, col, this.selectorAttributeNameLen, 1, line, col, this.selectorAttributeNameLen + 2, selectorValuesLen, this.selectorAttributeNameLen + 1, selectorValuesLen + 2, line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 183 */     this.lastWasInnerWhiteSpace = false;
/* 184 */     getNext().handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 194 */     this.lastWasInnerWhiteSpace = true;
/* 195 */     getNext().handleInnerWhiteSpace(buffer, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void checkSelectorAttributeLen(int valueLen)
/*     */   {
/* 202 */     int totalLenRequired = this.selectorAttributeNameLen + 3 + valueLen;
/* 203 */     if (this.selectorAttributeBuffer.length < totalLenRequired) {
/* 204 */       char[] newSelectorAttributeBuffer = new char[totalLenRequired];
/* 205 */       System.arraycopy(this.selectorAttributeBuffer, 0, newSelectorAttributeBuffer, 0, this.selectorAttributeBuffer.length);
/* 206 */       this.selectorAttributeBuffer = newSelectorAttributeBuffer;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\select\AttributeSelectionMarkingMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */