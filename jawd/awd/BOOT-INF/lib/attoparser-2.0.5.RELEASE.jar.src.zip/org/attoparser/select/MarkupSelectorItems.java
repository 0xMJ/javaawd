/*     */ package org.attoparser.select;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MarkupSelectorItems
/*     */ {
/*  37 */   private static final SelectorRepository NO_REFERENCE_RESOLVER_REPOSITORY = new SelectorRepository();
/*  38 */   private static final ConcurrentHashMap<IMarkupSelectorReferenceResolver, SelectorRepository> REPOSITORIES_BY_REFERENCE_RESOLVER = new ConcurrentHashMap(20);
/*     */   
/*     */ 
/*     */   private static final String selectorPatternStr = "^(/{1,2})([^/\\s]*?)(\\[(?:.*)\\])?$";
/*     */   
/*     */ 
/*  44 */   private static final Pattern selectorPattern = Pattern.compile("^(/{1,2})([^/\\s]*?)(\\[(?:.*)\\])?$");
/*     */   private static final String modifiersPatternStr = "^(?:\\[(.*?)\\])(\\[(?:.*)\\])?$";
/*  46 */   private static final Pattern modifiersPattern = Pattern.compile("^(?:\\[(.*?)\\])(\\[(?:.*)\\])?$");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static List<IMarkupSelectorItem> forSelector(boolean html, String selector, IMarkupSelectorReferenceResolver referenceResolver)
/*     */   {
/*  54 */     if (isEmptyOrWhitespace(selector)) {
/*  55 */       throw new IllegalArgumentException("Selector cannot be null");
/*     */     }
/*     */     ConcurrentHashMap<String, List<IMarkupSelectorItem>> map;
/*     */     ConcurrentHashMap<String, List<IMarkupSelectorItem>> map;
/*  59 */     if (referenceResolver == null) {
/*  60 */       map = NO_REFERENCE_RESOLVER_REPOSITORY.getMap(html);
/*     */     } else {
/*  62 */       if ((!REPOSITORIES_BY_REFERENCE_RESOLVER.containsKey(referenceResolver)) && 
/*  63 */         (REPOSITORIES_BY_REFERENCE_RESOLVER.size() < 1000))
/*     */       {
/*  65 */         REPOSITORIES_BY_REFERENCE_RESOLVER.putIfAbsent(referenceResolver, new SelectorRepository());
/*     */       }
/*     */       
/*  68 */       map = ((SelectorRepository)REPOSITORIES_BY_REFERENCE_RESOLVER.get(referenceResolver)).getMap(html);
/*     */     }
/*     */     
/*  71 */     List<IMarkupSelectorItem> items = (List)map.get(selector);
/*  72 */     if (items != null) {
/*  73 */       return items;
/*     */     }
/*     */     
/*  76 */     items = Collections.unmodifiableList(parseSelector(html, selector, referenceResolver));
/*     */     
/*  78 */     if (map.size() < 1000) {
/*  79 */       map.putIfAbsent(selector, items);
/*     */     }
/*     */     
/*  82 */     return items;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static final class SelectorRepository
/*     */   {
/*     */     private static final int SELECTOR_ITEMS_MAX_SIZE = 1000;
/*     */     
/*  91 */     private final ConcurrentHashMap<String, List<IMarkupSelectorItem>> CASE_INSENSITIVE_SELECTOR_ITEMS = new ConcurrentHashMap(20);
/*     */     
/*  93 */     private final ConcurrentHashMap<String, List<IMarkupSelectorItem>> CASE_SENSITIVE_SELECTOR_ITEMS = new ConcurrentHashMap(20);
/*     */     
/*     */ 
/*     */     ConcurrentHashMap<String, List<IMarkupSelectorItem>> getMap(boolean html)
/*     */     {
/*  98 */       return html ? this.CASE_INSENSITIVE_SELECTOR_ITEMS : this.CASE_SENSITIVE_SELECTOR_ITEMS;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static List<IMarkupSelectorItem> parseSelector(boolean html, String selector, IMarkupSelectorReferenceResolver referenceResolver)
/*     */   {
/* 111 */     return parseSelector(html, selector, null, null, referenceResolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static List<IMarkupSelectorItem> parseSelector(boolean html, String selector, MarkupSelectorItem.IAttributeCondition initialAttributeCondition, MarkupSelectorItem.IndexCondition initialIndexCondition, IMarkupSelectorReferenceResolver referenceResolver)
/*     */   {
/* 127 */     String selectorSpecStr = selector.trim();
/* 128 */     if (!selectorSpecStr.startsWith("/"))
/*     */     {
/* 130 */       selectorSpecStr = "//" + selectorSpecStr;
/*     */     }
/*     */     
/* 133 */     int selectorSpecStrLen = selectorSpecStr.length();
/* 134 */     int firstNonSlash = 0;
/* 135 */     while ((firstNonSlash < selectorSpecStrLen) && (selectorSpecStr.charAt(firstNonSlash) == '/')) {
/* 136 */       firstNonSlash++;
/*     */     }
/*     */     
/* 139 */     if (firstNonSlash >= selectorSpecStrLen) {
/* 140 */       throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": '/' should be followed by further selector specification");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 146 */     int selEnd = selectorSpecStr.substring(firstNonSlash).indexOf('/');
/* 147 */     List<IMarkupSelectorItem> result; List<IMarkupSelectorItem> result; if (selEnd != -1) {
/* 148 */       String tail = selectorSpecStr.substring(firstNonSlash).substring(selEnd);
/* 149 */       selectorSpecStr = selectorSpecStr.substring(0, firstNonSlash + selEnd);
/* 150 */       result = parseSelector(html, tail, referenceResolver);
/*     */     } else {
/* 152 */       result = new ArrayList(3);
/*     */     }
/*     */     
/* 155 */     Matcher matcher = selectorPattern.matcher(selectorSpecStr);
/* 156 */     if (!matcher.matches()) {
/* 157 */       throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: ((/|//)?selector)?([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 162 */     String rootGroup = matcher.group(1);
/* 163 */     String selectorNameGroup = matcher.group(2);
/* 164 */     String modifiersGroup = matcher.group(3);
/*     */     
/* 166 */     if (rootGroup == null) {
/* 167 */       throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: ((/|//)?selector)?([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */     }
/*     */     
/*     */ 
/*     */     boolean anyLevel;
/*     */     
/* 173 */     if ("//".equals(rootGroup)) {
/* 174 */       anyLevel = true; } else { boolean anyLevel;
/* 175 */       if ("/".equals(rootGroup)) {
/* 176 */         anyLevel = false;
/*     */       } else {
/* 178 */         throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: ((/|//)?selector)?([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */       }
/*     */     }
/*     */     
/*     */     boolean anyLevel;
/* 183 */     if (selectorNameGroup == null) {
/* 184 */       throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: ((/|//)?selector)?([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 196 */     String path = selectorNameGroup;
/*     */     
/*     */ 
/* 199 */     MarkupSelectorItem.IndexCondition index = initialIndexCondition;
/* 200 */     MarkupSelectorItem.IAttributeCondition attributeCondition = initialAttributeCondition;
/*     */     
/*     */ 
/*     */ 
/* 204 */     int idModifierPos = html ? path.indexOf("#") : -1;
/*     */     
/* 206 */     int classModifierPos = html ? path.indexOf(".") : -1;
/* 207 */     int referenceModifierPos = path.indexOf("%");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 214 */     if (idModifierPos != -1) {
/* 215 */       if ((classModifierPos != -1) || (referenceModifierPos != -1)) {
/* 216 */         throw new IllegalArgumentException("More than one modifier (id, class, reference) have been specified at selector expression \"" + selector + "\", which is forbidden.");
/*     */       }
/*     */       
/*     */ 
/* 220 */       String selectorPathIdModifier = path.substring(idModifierPos + "#".length());
/* 221 */       path = path.substring(0, idModifierPos);
/* 222 */       if (isEmptyOrWhitespace(selectorPathIdModifier)) {
/* 223 */         throw new IllegalArgumentException("Empty id modifier in selector expression \"" + selector + "\", which is forbidden.");
/*     */       }
/*     */       
/*     */ 
/* 227 */       MarkupSelectorItem.AttributeCondition newAttributeCondition = new MarkupSelectorItem.AttributeCondition("id", MarkupSelectorItem.AttributeCondition.Operator.EQUALS, selectorPathIdModifier);
/*     */       
/*     */ 
/* 230 */       if (attributeCondition == null) {
/* 231 */         attributeCondition = newAttributeCondition;
/*     */       } else {
/* 233 */         attributeCondition = new MarkupSelectorItem.AttributeConditionRelation(MarkupSelectorItem.AttributeConditionRelation.Type.AND, attributeCondition, newAttributeCondition);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 243 */     if (classModifierPos != -1) {
/* 244 */       if ((idModifierPos != -1) || (referenceModifierPos != -1)) {
/* 245 */         throw new IllegalArgumentException("More than one modifier (id, class, reference) have been specified at selector expression \"" + selector + "\", which is forbidden.");
/*     */       }
/*     */       
/*     */ 
/* 249 */       String selectorPathClassModifier = path.substring(classModifierPos + ".".length());
/* 250 */       path = path.substring(0, classModifierPos);
/* 251 */       if (isEmptyOrWhitespace(selectorPathClassModifier)) {
/* 252 */         throw new IllegalArgumentException("Empty id modifier in selector expression \"" + selector + "\", which is forbidden.");
/*     */       }
/*     */       
/*     */ 
/* 256 */       MarkupSelectorItem.AttributeCondition newAttributeCondition = new MarkupSelectorItem.AttributeCondition("class", MarkupSelectorItem.AttributeCondition.Operator.EQUALS, selectorPathClassModifier);
/*     */       
/*     */ 
/* 259 */       if (attributeCondition == null) {
/* 260 */         attributeCondition = newAttributeCondition;
/*     */       } else {
/* 262 */         attributeCondition = new MarkupSelectorItem.AttributeConditionRelation(MarkupSelectorItem.AttributeConditionRelation.Type.AND, attributeCondition, newAttributeCondition);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 272 */     String selectorPathReferenceModifier = null;
/* 273 */     if (referenceModifierPos != -1) {
/* 274 */       if ((idModifierPos != -1) || (classModifierPos != -1)) {
/* 275 */         throw new IllegalArgumentException("More than one modifier (id, class, reference) have been specified at selector expression \"" + selector + "\", which is forbidden.");
/*     */       }
/*     */       
/*     */ 
/* 279 */       selectorPathReferenceModifier = path.substring(referenceModifierPos + "%".length());
/* 280 */       path = path.substring(0, referenceModifierPos);
/* 281 */       if (isEmptyOrWhitespace(selectorPathReferenceModifier)) {
/* 282 */         throw new IllegalArgumentException("Empty id modifier in selector expression \"" + selector + "\", which is forbidden.");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 295 */     boolean contentSelector = "content()".equals(path);
/* 296 */     boolean textSelector = "text()".equals(path);
/* 297 */     boolean commentSelector = "comment()".equals(path);
/* 298 */     boolean cdataSectionSelector = "cdata()".equals(path);
/* 299 */     boolean docTypeClauseSelector = "doctype()".equals(path);
/* 300 */     boolean xmlDeclarationSelector = "xmldecl()".equals(path);
/* 301 */     boolean processingInstructionSelector = "procinstr()".equals(path);
/*     */     
/* 303 */     boolean isNonElementSelector = (contentSelector) || (textSelector) || (commentSelector) || (cdataSectionSelector) || (docTypeClauseSelector) || (xmlDeclarationSelector) || (processingInstructionSelector);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 312 */     String caseSensitiveSelectorPath = isEmptyOrWhitespace(path) ? null : isNonElementSelector ? null : path;
/*     */     
/*     */ 
/*     */ 
/* 316 */     String selectorPath = html ? caseSensitiveSelectorPath.toLowerCase() : caseSensitiveSelectorPath == null ? null : caseSensitiveSelectorPath;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 323 */     if (modifiersGroup != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 331 */       String remainingModifiers = modifiersGroup;
/*     */       
/* 333 */       while (remainingModifiers != null)
/*     */       {
/*     */ 
/* 336 */         Matcher modifiersMatcher = modifiersPattern.matcher(remainingModifiers);
/* 337 */         if (!modifiersMatcher.matches()) {
/* 338 */           throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: ((/|//)?selector)?([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 343 */         String currentModifier = modifiersMatcher.group(1);
/* 344 */         remainingModifiers = modifiersMatcher.group(2);
/*     */         
/* 346 */         MarkupSelectorItem.IndexCondition newIndex = parseIndex(currentModifier);
/*     */         
/* 348 */         if (newIndex != null)
/*     */         {
/* 350 */           if (remainingModifiers != null)
/*     */           {
/* 352 */             throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: ((/|//)?selector)?([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 357 */           if (index != null)
/*     */           {
/* 359 */             throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": cannot combine two different index modifiers (probably one was specified in the expression itself, and the other one comes from a reference resolver).");
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 365 */           index = newIndex;
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 371 */           MarkupSelectorItem.IAttributeCondition newAttributeCondition = parseAttributeCondition(html, selector, currentModifier);
/* 372 */           if (newAttributeCondition == null) {
/* 373 */             throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: (/|//)(selector)([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 378 */           if (attributeCondition == null) {
/* 379 */             attributeCondition = newAttributeCondition;
/*     */           } else {
/* 381 */             attributeCondition = new MarkupSelectorItem.AttributeConditionRelation(MarkupSelectorItem.AttributeConditionRelation.Type.AND, attributeCondition, newAttributeCondition);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 392 */     IMarkupSelectorItem thisItem = new MarkupSelectorItem(html, anyLevel, contentSelector, textSelector, commentSelector, cdataSectionSelector, docTypeClauseSelector, xmlDeclarationSelector, processingInstructionSelector, selectorPath, index, attributeCondition);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 398 */     if ((referenceResolver != null) && ((selectorPathReferenceModifier != null) || (selectorPath != null)))
/*     */     {
/* 400 */       if (selectorPathReferenceModifier != null)
/*     */       {
/*     */ 
/* 403 */         String resolvedSelector = referenceResolver.resolveSelectorFromReference(selectorPathReferenceModifier);
/*     */         
/* 405 */         if (resolvedSelector != null)
/*     */         {
/* 407 */           if (resolvedSelector.startsWith("//")) {
/* 408 */             if (!anyLevel) {
/* 409 */               resolvedSelector = resolvedSelector.substring(1);
/*     */             }
/* 411 */           } else if (resolvedSelector.startsWith("/")) {
/* 412 */             if (anyLevel) {
/* 413 */               resolvedSelector = "/" + resolvedSelector;
/*     */             }
/* 415 */           } else if (!anyLevel) {
/* 416 */             resolvedSelector = "/" + resolvedSelector;
/*     */           }
/*     */           
/*     */ 
/* 420 */           List<IMarkupSelectorItem> parsedReference = parseSelector(html, resolvedSelector, null);
/* 421 */           if ((parsedReference != null) && (parsedReference.size() > 1))
/*     */           {
/* 423 */             throw new IllegalArgumentException("Invalid selector resolved by reference resolver of class " + referenceResolver.getClass().getName() + "  for selector " + selectorPath + ": resolved selector has more than one level, which is forbidden.");
/*     */           }
/*     */           
/* 426 */           if ((parsedReference != null) && (parsedReference.size() == 1)) {
/* 427 */             thisItem = new MarkupSelectorAndItem(thisItem, (IMarkupSelectorItem)parsedReference.get(0));
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 436 */         String resolvedSelector = referenceResolver.resolveSelectorFromReference(caseSensitiveSelectorPath);
/*     */         
/* 438 */         if (resolvedSelector != null)
/*     */         {
/* 440 */           if (resolvedSelector.startsWith("//")) {
/* 441 */             if (!anyLevel) {
/* 442 */               resolvedSelector = resolvedSelector.substring(1);
/*     */             }
/* 444 */           } else if (resolvedSelector.startsWith("/")) {
/* 445 */             if (anyLevel) {
/* 446 */               resolvedSelector = "/" + resolvedSelector;
/*     */             }
/* 448 */           } else if (!anyLevel) {
/* 449 */             resolvedSelector = "/" + resolvedSelector;
/*     */           }
/*     */           
/*     */ 
/* 453 */           List<IMarkupSelectorItem> parsedReference = parseSelector(html, resolvedSelector, attributeCondition, index, null);
/* 454 */           if ((parsedReference != null) && (parsedReference.size() > 1))
/*     */           {
/* 456 */             throw new IllegalArgumentException("Invalid selector resolved by reference resolver of class " + referenceResolver.getClass().getName() + "  for selector " + selectorPath + ": resolved selector has more than one level, which is forbidden.");
/*     */           }
/*     */           
/* 459 */           if ((parsedReference != null) && (parsedReference.size() == 1)) {
/* 460 */             thisItem = new MarkupSelectorOrItem(thisItem, (IMarkupSelectorItem)parsedReference.get(0));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 469 */     result.add(0, thisItem);
/*     */     
/* 471 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static MarkupSelectorItem.IndexCondition parseIndex(String indexGroup)
/*     */   {
/* 480 */     if ("odd()".equals(indexGroup.toLowerCase())) {
/* 481 */       return MarkupSelectorItem.IndexCondition.INDEX_CONDITION_ODD;
/*     */     }
/* 483 */     if ("even()".equals(indexGroup.toLowerCase())) {
/* 484 */       return MarkupSelectorItem.IndexCondition.INDEX_CONDITION_EVEN;
/*     */     }
/*     */     
/* 487 */     if (indexGroup.charAt(0) == '>') {
/*     */       try
/*     */       {
/* 490 */         return new MarkupSelectorItem.IndexCondition(MarkupSelectorItem.IndexCondition.IndexConditionType.MORE_THAN, Integer.valueOf(indexGroup.substring(1).trim()).intValue());
/*     */       } catch (Exception ignored) {
/* 492 */         return null;
/*     */       }
/*     */     }
/* 495 */     if (indexGroup.charAt(0) == '<') {
/*     */       try
/*     */       {
/* 498 */         return new MarkupSelectorItem.IndexCondition(MarkupSelectorItem.IndexCondition.IndexConditionType.LESS_THAN, Integer.valueOf(indexGroup.substring(1).trim()).intValue());
/*     */       } catch (Exception ignored) {
/* 500 */         return null;
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 506 */       return new MarkupSelectorItem.IndexCondition(MarkupSelectorItem.IndexCondition.IndexConditionType.VALUE, Integer.valueOf(indexGroup.trim()).intValue());
/*     */     } catch (Exception ignored) {}
/* 508 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static MarkupSelectorItem.IAttributeCondition parseAttributeCondition(boolean html, String selectorSpec, String attrGroup)
/*     */   {
/* 518 */     String text = attrGroup.trim();
/* 519 */     if ((text.startsWith("(")) && (text.endsWith(")"))) {
/* 520 */       text = text.substring(1, text.length() - 1);
/*     */     }
/*     */     
/* 523 */     int textLen = text.length();
/* 524 */     if (isEmptyOrWhitespace(text)) {
/* 525 */       throw new IllegalArgumentException("Invalid syntax in selector: \"" + selectorSpec + "\"");
/*     */     }
/*     */     
/*     */ 
/* 529 */     boolean inDoubleLiteral = false;
/* 530 */     boolean inSimpleLiteral = false;
/* 531 */     int nestingLevel = 0;
/* 532 */     int i = 0;
/* 533 */     while (i < textLen)
/*     */     {
/* 535 */       char c = text.charAt(i);
/* 536 */       if ((c == '\'') && (!inDoubleLiteral)) {
/* 537 */         inSimpleLiteral = !inSimpleLiteral;
/* 538 */         i++;
/*     */ 
/*     */       }
/* 541 */       else if ((c == '"') && (!inSimpleLiteral)) {
/* 542 */         inDoubleLiteral = !inDoubleLiteral;
/* 543 */         i++;
/*     */       }
/*     */       else {
/* 546 */         if ((!inSimpleLiteral) && (!inDoubleLiteral)) {
/* 547 */           if (c == '(') {
/* 548 */             nestingLevel++;
/* 549 */             continue;
/*     */           }
/* 551 */           if (c == ')') {
/* 552 */             nestingLevel--;
/* 553 */             continue;
/*     */           }
/* 555 */           if ((nestingLevel == 0) && (i + 4 < textLen) && 
/* 556 */             (Character.isWhitespace(c)) && 
/* 557 */             ((text.charAt(i + 1) == 'a') || (text.charAt(i + 1) == 'A')) && 
/* 558 */             ((text.charAt(i + 2) == 'n') || (text.charAt(i + 2) == 'N')) && 
/* 559 */             ((text.charAt(i + 3) == 'd') || (text.charAt(i + 3) == 'D')) && 
/* 560 */             (Character.isWhitespace(text.charAt(i + 4))))
/*     */           {
/*     */ 
/* 563 */             MarkupSelectorItem.IAttributeCondition left = parseAttributeCondition(html, selectorSpec, text.substring(0, i));
/*     */             
/* 565 */             MarkupSelectorItem.IAttributeCondition right = parseAttributeCondition(html, selectorSpec, text.substring(i + 5, textLen));
/* 566 */             return new MarkupSelectorItem.AttributeConditionRelation(MarkupSelectorItem.AttributeConditionRelation.Type.AND, left, right);
/*     */           }
/*     */           
/*     */ 
/* 570 */           if ((nestingLevel == 0) && (i + 3 < textLen) && 
/* 571 */             (Character.isWhitespace(c)) && 
/* 572 */             ((text.charAt(i + 1) == 'o') || (text.charAt(i + 1) == 'O')) && 
/* 573 */             ((text.charAt(i + 2) == 'r') || (text.charAt(i + 2) == 'R')) && 
/* 574 */             (Character.isWhitespace(text.charAt(i + 3))))
/*     */           {
/*     */ 
/* 577 */             MarkupSelectorItem.IAttributeCondition left = parseAttributeCondition(html, selectorSpec, text.substring(0, i));
/*     */             
/* 579 */             MarkupSelectorItem.IAttributeCondition right = parseAttributeCondition(html, selectorSpec, text.substring(i + 4, textLen));
/* 580 */             return new MarkupSelectorItem.AttributeConditionRelation(MarkupSelectorItem.AttributeConditionRelation.Type.OR, left, right);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 586 */         i++;
/*     */       }
/*     */     }
/*     */     
/* 590 */     return parseSimpleAttributeCondition(html, selectorSpec, text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static MarkupSelectorItem.AttributeCondition parseSimpleAttributeCondition(boolean html, String selectorSpec, String attributeSpec)
/*     */   {
/* 599 */     String[] fragments = tokenizeAttributeSpec(attributeSpec);
/*     */     
/* 601 */     String attrName = fragments[0];
/* 602 */     if (attrName.startsWith("@")) {
/* 603 */       attrName = attrName.substring(1);
/*     */     }
/* 605 */     attrName = html ? attrName.toLowerCase() : attrName;
/*     */     
/* 607 */     MarkupSelectorItem.AttributeCondition.Operator operator = parseAttributeOperator(fragments[1]);
/*     */     
/* 609 */     String attrValue = fragments[2];
/* 610 */     if (attrValue != null) {
/* 611 */       if (((!attrValue.startsWith("\"")) || (!attrValue.endsWith("\""))) && ((!attrValue.startsWith("'")) || (!attrValue.endsWith("'")))) {
/* 612 */         throw new IllegalArgumentException("Invalid syntax in selector: \"" + selectorSpec + "\"");
/*     */       }
/*     */       
/* 615 */       return new MarkupSelectorItem.AttributeCondition(attrName, operator, attrValue.substring(1, attrValue.length() - 1));
/*     */     }
/* 617 */     return new MarkupSelectorItem.AttributeCondition(attrName, operator, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String[] tokenizeAttributeSpec(String specification)
/*     */   {
/* 624 */     int equalsPos = specification.indexOf('=');
/* 625 */     if (equalsPos == -1) {
/* 626 */       if (specification.charAt(0) == '!') {
/* 627 */         return new String[] { specification.substring(1).trim(), "!", null };
/*     */       }
/* 629 */       return new String[] { specification.trim(), "", null };
/*     */     }
/* 631 */     char cprev = specification.charAt(equalsPos - 1);
/* 632 */     switch (cprev) {
/*     */     case '!': 
/* 634 */       return new String[] {specification
/* 635 */         .substring(0, equalsPos - 1).trim(), "!=", specification
/* 636 */         .substring(equalsPos + 1).trim() };
/*     */     case '^': 
/* 638 */       return new String[] {specification
/* 639 */         .substring(0, equalsPos - 1).trim(), "^=", specification
/* 640 */         .substring(equalsPos + 1).trim() };
/*     */     case '$': 
/* 642 */       return new String[] {specification
/* 643 */         .substring(0, equalsPos - 1).trim(), "$=", specification
/* 644 */         .substring(equalsPos + 1).trim() };
/*     */     case '*': 
/* 646 */       return new String[] {specification
/* 647 */         .substring(0, equalsPos - 1).trim(), "*=", specification
/* 648 */         .substring(equalsPos + 1).trim() };
/*     */     }
/* 650 */     return new String[] {specification
/* 651 */       .substring(0, equalsPos).trim(), "=", specification
/* 652 */       .substring(equalsPos + 1).trim() };
/*     */   }
/*     */   
/*     */ 
/*     */   private static MarkupSelectorItem.AttributeCondition.Operator parseAttributeOperator(String operatorStr)
/*     */   {
/* 658 */     if (operatorStr == null) {
/* 659 */       return null;
/*     */     }
/* 661 */     if ("=".equals(operatorStr)) {
/* 662 */       return MarkupSelectorItem.AttributeCondition.Operator.EQUALS;
/*     */     }
/* 664 */     if ("!=".equals(operatorStr)) {
/* 665 */       return MarkupSelectorItem.AttributeCondition.Operator.NOT_EQUALS;
/*     */     }
/* 667 */     if ("^=".equals(operatorStr)) {
/* 668 */       return MarkupSelectorItem.AttributeCondition.Operator.STARTS_WITH;
/*     */     }
/* 670 */     if ("$=".equals(operatorStr)) {
/* 671 */       return MarkupSelectorItem.AttributeCondition.Operator.ENDS_WITH;
/*     */     }
/* 673 */     if ("*=".equals(operatorStr)) {
/* 674 */       return MarkupSelectorItem.AttributeCondition.Operator.CONTAINS;
/*     */     }
/* 676 */     if ("!".equals(operatorStr)) {
/* 677 */       return MarkupSelectorItem.AttributeCondition.Operator.NOT_EXISTS;
/*     */     }
/* 679 */     if ("".equals(operatorStr)) {
/* 680 */       return MarkupSelectorItem.AttributeCondition.Operator.EXISTS;
/*     */     }
/* 682 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isEmptyOrWhitespace(String target)
/*     */   {
/* 690 */     if (target == null) {
/* 691 */       return true;
/*     */     }
/* 693 */     int targetLen = target.length();
/* 694 */     if (targetLen == 0) {
/* 695 */       return true;
/*     */     }
/* 697 */     char c0 = target.charAt(0);
/* 698 */     if (((c0 >= 'a') && (c0 <= 'z')) || ((c0 >= 'A') && (c0 <= 'Z')))
/*     */     {
/* 700 */       return false;
/*     */     }
/* 702 */     for (int i = 0; i < targetLen; i++) {
/* 703 */       char c = target.charAt(i);
/* 704 */       if ((c != ' ') && (!Character.isWhitespace(c))) {
/* 705 */         return false;
/*     */       }
/*     */     }
/* 708 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\select\MarkupSelectorItems.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */