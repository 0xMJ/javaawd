/*      */ package org.attoparser.select;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import org.attoparser.AbstractMarkupHandler;
/*      */ import org.attoparser.IMarkupHandler;
/*      */ import org.attoparser.ParseException;
/*      */ import org.attoparser.ParseStatus;
/*      */ import org.attoparser.config.ParseConfiguration;
/*      */ import org.attoparser.config.ParseConfiguration.ParsingMode;
/*      */ import org.attoparser.discard.DiscardMarkupHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class BlockSelectorMarkupHandler
/*      */   extends AbstractMarkupHandler
/*      */ {
/*  117 */   private static final DiscardMarkupHandler DISCARD_MARKUP_HANDLER = new DiscardMarkupHandler();
/*      */   
/*      */   private final IMarkupHandler selectedHandler;
/*      */   
/*      */   private final IMarkupHandler nonSelectedHandler;
/*      */   
/*      */   private ParseSelection selection;
/*  124 */   private int selectionIndex = -1;
/*      */   
/*      */ 
/*      */   private final IMarkupSelectorReferenceResolver referenceResolver;
/*      */   
/*      */ 
/*      */   private final SelectorElementBuffer elementBuffer;
/*      */   
/*      */ 
/*      */   private IMarkupHandler documentStartEndHandler;
/*      */   
/*      */ 
/*      */   private final int selectorsLen;
/*      */   
/*      */ 
/*      */   private final String[] selectors;
/*      */   
/*      */ 
/*      */   private final boolean[] selectorMatches;
/*      */   
/*      */ 
/*      */   private final MarkupSelectorFilter[] selectorFilters;
/*      */   
/*      */ 
/*      */   private boolean insideAllSelectorMatchingBlock;
/*      */   
/*      */ 
/*      */   private boolean someSelectorsMatch;
/*      */   
/*      */ 
/*      */   private int markupLevel;
/*      */   
/*      */ 
/*      */   private int[] matchingMarkupLevelsPerSelector;
/*      */   
/*      */   private static final int MARKUP_BLOCKS_LEN = 10;
/*      */   
/*      */   private int[] markupBlocks;
/*      */   
/*      */   private int markupBlockIndex;
/*      */   
/*      */ 
/*      */   public BlockSelectorMarkupHandler(IMarkupHandler selectedHandler, String selector)
/*      */   {
/*  168 */     this(selectedHandler, DISCARD_MARKUP_HANDLER, new String[] { selector }, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BlockSelectorMarkupHandler(IMarkupHandler selectedHandler, String selector, IMarkupSelectorReferenceResolver referenceResolver)
/*      */   {
/*  190 */     this(selectedHandler, DISCARD_MARKUP_HANDLER, new String[] { selector }, referenceResolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BlockSelectorMarkupHandler(IMarkupHandler selectedHandler, IMarkupHandler nonSelectedHandler, String selector)
/*      */   {
/*  207 */     this(selectedHandler, nonSelectedHandler, new String[] { selector }, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BlockSelectorMarkupHandler(IMarkupHandler selectedHandler, IMarkupHandler nonSelectedHandler, String selector, IMarkupSelectorReferenceResolver referenceResolver)
/*      */   {
/*  226 */     this(selectedHandler, nonSelectedHandler, new String[] { selector }, referenceResolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BlockSelectorMarkupHandler(IMarkupHandler selectedHandler, String[] selectors)
/*      */   {
/*  247 */     this(selectedHandler, DISCARD_MARKUP_HANDLER, selectors, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BlockSelectorMarkupHandler(IMarkupHandler selectedHandler, String[] selectors, IMarkupSelectorReferenceResolver referenceResolver)
/*      */   {
/*  269 */     this(selectedHandler, DISCARD_MARKUP_HANDLER, selectors, referenceResolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BlockSelectorMarkupHandler(IMarkupHandler selectedHandler, IMarkupHandler nonSelectedHandler, String[] selectors)
/*      */   {
/*  286 */     this(selectedHandler, nonSelectedHandler, selectors, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BlockSelectorMarkupHandler(IMarkupHandler selectedHandler, IMarkupHandler nonSelectedHandler, String[] selectors, IMarkupSelectorReferenceResolver referenceResolver)
/*      */   {
/*  310 */     if ((selectors == null) || (selectors.length == 0)) {
/*  311 */       throw new IllegalArgumentException("Selector array cannot be null or empty");
/*      */     }
/*  313 */     for (String selector : selectors) {
/*  314 */       if ((selector == null) || (selector.trim().length() == 0)) {
/*  315 */         throw new IllegalArgumentException("Selector array contains at least one null or empty item, which is forbidden");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  320 */     this.selectedHandler = selectedHandler;
/*  321 */     this.nonSelectedHandler = nonSelectedHandler;
/*      */     
/*      */ 
/*  324 */     this.documentStartEndHandler = this.selectedHandler;
/*      */     
/*  326 */     this.referenceResolver = referenceResolver;
/*      */     
/*  328 */     this.selectors = selectors;
/*  329 */     this.selectorsLen = selectors.length;
/*      */     
/*      */ 
/*  332 */     this.selectorMatches = new boolean[this.selectors.length];
/*  333 */     Arrays.fill(this.selectorMatches, false);
/*      */     
/*      */ 
/*  336 */     this.someSelectorsMatch = false;
/*      */     
/*  338 */     this.insideAllSelectorMatchingBlock = false;
/*      */     
/*  340 */     this.selectorFilters = new MarkupSelectorFilter[this.selectorsLen];
/*      */     
/*      */ 
/*  343 */     this.elementBuffer = new SelectorElementBuffer();
/*      */     
/*  345 */     this.markupLevel = 0;
/*  346 */     this.matchingMarkupLevelsPerSelector = new int[this.selectorsLen];
/*  347 */     Arrays.fill(this.matchingMarkupLevelsPerSelector, Integer.MAX_VALUE);
/*      */     
/*  349 */     this.markupBlockIndex = 0;
/*  350 */     this.markupBlocks = new int[10];
/*  351 */     this.markupBlocks[this.markupLevel] = this.markupBlockIndex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDocumentStartEndHandler(IMarkupHandler documentStartEndHandler)
/*      */   {
/*  375 */     if (documentStartEndHandler == null) {
/*  376 */       throw new IllegalArgumentException("Handler cannot be null");
/*      */     }
/*  378 */     this.documentStartEndHandler = documentStartEndHandler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParseConfiguration(ParseConfiguration parseConfiguration)
/*      */   {
/*  395 */     boolean html = ParseConfiguration.ParsingMode.HTML == parseConfiguration.getMode();
/*      */     
/*  397 */     for (int i = 0; i < this.selectorsLen; i++)
/*      */     {
/*      */ 
/*  400 */       List<IMarkupSelectorItem> selectorItems = MarkupSelectorItems.forSelector(html, this.selectors[i], this.referenceResolver);
/*      */       
/*  402 */       this.selectorFilters[i] = new MarkupSelectorFilter(null, (IMarkupSelectorItem)selectorItems.get(0));
/*  403 */       MarkupSelectorFilter last = this.selectorFilters[i];
/*  404 */       for (int j = 1; j < selectorItems.size(); j++) {
/*  405 */         last = new MarkupSelectorFilter(last, (IMarkupSelectorItem)selectorItems.get(j));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  415 */     this.selectedHandler.setParseConfiguration(parseConfiguration);
/*  416 */     if (this.nonSelectedHandler != this.selectedHandler) {
/*  417 */       this.nonSelectedHandler.setParseConfiguration(parseConfiguration);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParseStatus(ParseStatus status)
/*      */   {
/*  427 */     this.selectedHandler.setParseStatus(status);
/*  428 */     if (this.nonSelectedHandler != this.selectedHandler) {
/*  429 */       this.nonSelectedHandler.setParseStatus(status);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParseSelection(ParseSelection selection)
/*      */   {
/*  438 */     if (this.selection == null) {
/*  439 */       this.selection = selection;
/*      */     }
/*  441 */     if (this.selectionIndex == -1) {
/*  442 */       this.selectionIndex = this.selection.subscribeLevel();
/*      */     }
/*  444 */     this.selectedHandler.setParseSelection(selection);
/*  445 */     if (this.nonSelectedHandler != this.selectedHandler) {
/*  446 */       this.nonSelectedHandler.setParseSelection(selection);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleDocumentStart(long startTimeNanos, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  464 */     this.selection.levels[this.selectionIndex].selectors = this.selectors;
/*      */     
/*  466 */     this.documentStartEndHandler.handleDocumentStart(startTimeNanos, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  476 */     this.documentStartEndHandler.handleDocumentEnd(endTimeNanos, totalTimeNanos, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleXmlDeclaration(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int versionOffset, int versionLen, int versionLine, int versionCol, int encodingOffset, int encodingLen, int encodingLine, int encodingCol, int standaloneOffset, int standaloneLen, int standaloneLine, int standaloneCol, int outerOffset, int outerLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  500 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/*  502 */       this.someSelectorsMatch = false;
/*  503 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/*  505 */         if (this.matchingMarkupLevelsPerSelector[i] > this.markupLevel)
/*      */         {
/*  507 */           this.selectorMatches[i] = this.selectorFilters[i].matchXmlDeclaration(true, this.markupLevel, this.markupBlocks[this.markupLevel]);
/*  508 */           if (this.selectorMatches[i] != 0) {
/*  509 */             this.someSelectorsMatch = true;
/*      */           }
/*      */         } else {
/*  512 */           this.selectorMatches[i] = true;
/*  513 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  518 */       if (this.someSelectorsMatch) {
/*  519 */         markCurrentSelection();
/*  520 */         this.selectedHandler.handleXmlDeclaration(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, versionOffset, versionLen, versionLine, versionCol, encodingOffset, encodingLen, encodingLine, encodingCol, standaloneOffset, standaloneLen, standaloneLine, standaloneCol, outerOffset, outerLen, line, col);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  526 */         unmarkCurrentSelection();
/*  527 */         return;
/*      */       }
/*      */       
/*  530 */       unmarkCurrentSelection();
/*  531 */       this.nonSelectedHandler.handleXmlDeclaration(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, versionOffset, versionLen, versionLine, versionCol, encodingOffset, encodingLen, encodingLine, encodingCol, standaloneOffset, standaloneLen, standaloneLine, standaloneCol, outerOffset, outerLen, line, col);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  537 */       return;
/*      */     }
/*      */     
/*      */ 
/*  541 */     markCurrentSelection();
/*  542 */     this.selectedHandler.handleXmlDeclaration(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, versionOffset, versionLen, versionLine, versionCol, encodingOffset, encodingLen, encodingLine, encodingCol, standaloneOffset, standaloneLen, standaloneLine, standaloneCol, outerOffset, outerLen, line, col);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  548 */     unmarkCurrentSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleDocType(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int elementNameOffset, int elementNameLen, int elementNameLine, int elementNameCol, int typeOffset, int typeLen, int typeLine, int typeCol, int publicIdOffset, int publicIdLen, int publicIdLine, int publicIdCol, int systemIdOffset, int systemIdLen, int systemIdLine, int systemIdCol, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, int outerOffset, int outerLen, int outerLine, int outerCol)
/*      */     throws ParseException
/*      */   {
/*  574 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/*  576 */       this.someSelectorsMatch = false;
/*  577 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/*  579 */         if (this.matchingMarkupLevelsPerSelector[i] > this.markupLevel)
/*      */         {
/*  581 */           this.selectorMatches[i] = this.selectorFilters[i].matchDocTypeClause(true, this.markupLevel, this.markupBlocks[this.markupLevel]);
/*  582 */           if (this.selectorMatches[i] != 0) {
/*  583 */             this.someSelectorsMatch = true;
/*      */           }
/*      */         } else {
/*  586 */           this.selectorMatches[i] = true;
/*  587 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  592 */       if (this.someSelectorsMatch) {
/*  593 */         markCurrentSelection();
/*  594 */         this.selectedHandler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, publicIdOffset, publicIdLen, publicIdLine, publicIdCol, systemIdOffset, systemIdLen, systemIdLine, systemIdCol, internalSubsetOffset, internalSubsetLen, internalSubsetLine, internalSubsetCol, outerOffset, outerLen, outerLine, outerCol);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  603 */         unmarkCurrentSelection();
/*  604 */         return;
/*      */       }
/*      */       
/*  607 */       unmarkCurrentSelection();
/*  608 */       this.nonSelectedHandler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, publicIdOffset, publicIdLen, publicIdLine, publicIdCol, systemIdOffset, systemIdLen, systemIdLine, systemIdCol, internalSubsetOffset, internalSubsetLen, internalSubsetLine, internalSubsetCol, outerOffset, outerLen, outerLine, outerCol);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  617 */       return;
/*      */     }
/*      */     
/*      */ 
/*  621 */     markCurrentSelection();
/*  622 */     this.selectedHandler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, publicIdOffset, publicIdLen, publicIdLine, publicIdCol, systemIdOffset, systemIdLen, systemIdLine, systemIdCol, internalSubsetOffset, internalSubsetLen, internalSubsetLine, internalSubsetCol, outerOffset, outerLen, outerLine, outerCol);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  631 */     unmarkCurrentSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleCDATASection(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  652 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/*  654 */       this.someSelectorsMatch = false;
/*  655 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/*  657 */         if (this.matchingMarkupLevelsPerSelector[i] > this.markupLevel)
/*      */         {
/*  659 */           this.selectorMatches[i] = this.selectorFilters[i].matchCDATASection(true, this.markupLevel, this.markupBlocks[this.markupLevel]);
/*  660 */           if (this.selectorMatches[i] != 0) {
/*  661 */             this.someSelectorsMatch = true;
/*      */           }
/*      */         } else {
/*  664 */           this.selectorMatches[i] = true;
/*  665 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  670 */       if (this.someSelectorsMatch) {
/*  671 */         markCurrentSelection();
/*  672 */         this.selectedHandler.handleCDATASection(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*      */         
/*      */ 
/*  675 */         unmarkCurrentSelection();
/*  676 */         return;
/*      */       }
/*      */       
/*  679 */       unmarkCurrentSelection();
/*  680 */       this.nonSelectedHandler.handleCDATASection(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*      */       
/*      */ 
/*  683 */       return;
/*      */     }
/*      */     
/*      */ 
/*  687 */     markCurrentSelection();
/*  688 */     this.selectedHandler.handleCDATASection(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*  689 */     unmarkCurrentSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  709 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/*  711 */       this.someSelectorsMatch = false;
/*  712 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/*  714 */         if (this.matchingMarkupLevelsPerSelector[i] > this.markupLevel)
/*      */         {
/*  716 */           this.selectorMatches[i] = this.selectorFilters[i].matchText(true, this.markupLevel, this.markupBlocks[this.markupLevel]);
/*  717 */           if (this.selectorMatches[i] != 0) {
/*  718 */             this.someSelectorsMatch = true;
/*      */           }
/*      */         } else {
/*  721 */           this.selectorMatches[i] = true;
/*  722 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  727 */       if (this.someSelectorsMatch) {
/*  728 */         markCurrentSelection();
/*  729 */         this.selectedHandler.handleText(buffer, offset, len, line, col);
/*  730 */         unmarkCurrentSelection();
/*  731 */         return;
/*      */       }
/*      */       
/*  734 */       unmarkCurrentSelection();
/*  735 */       this.nonSelectedHandler.handleText(buffer, offset, len, line, col);
/*  736 */       return;
/*      */     }
/*      */     
/*      */ 
/*  740 */     markCurrentSelection();
/*  741 */     this.selectedHandler.handleText(buffer, offset, len, line, col);
/*  742 */     unmarkCurrentSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  764 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/*  766 */       this.someSelectorsMatch = false;
/*  767 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/*  769 */         if (this.matchingMarkupLevelsPerSelector[i] > this.markupLevel)
/*      */         {
/*  771 */           this.selectorMatches[i] = this.selectorFilters[i].matchComment(true, this.markupLevel, this.markupBlocks[this.markupLevel]);
/*  772 */           if (this.selectorMatches[i] != 0) {
/*  773 */             this.someSelectorsMatch = true;
/*      */           }
/*      */         } else {
/*  776 */           this.selectorMatches[i] = true;
/*  777 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  782 */       if (this.someSelectorsMatch) {
/*  783 */         markCurrentSelection();
/*  784 */         this.selectedHandler.handleComment(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*      */         
/*  786 */         unmarkCurrentSelection();
/*  787 */         return;
/*      */       }
/*      */       
/*  790 */       unmarkCurrentSelection();
/*  791 */       this.nonSelectedHandler.handleComment(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*      */       
/*  793 */       return;
/*      */     }
/*      */     
/*      */ 
/*  797 */     markCurrentSelection();
/*  798 */     this.selectedHandler.handleComment(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*      */     
/*  800 */     unmarkCurrentSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*      */     throws ParseException
/*      */   {
/*  824 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/*  826 */       this.elementBuffer.bufferAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  831 */       return;
/*      */     }
/*      */     
/*      */ 
/*  835 */     this.selectedHandler.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  854 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/*  856 */       this.elementBuffer.bufferElementStart(buffer, nameOffset, nameLen, line, col, true, minimized);
/*  857 */       return;
/*      */     }
/*      */     
/*  860 */     markCurrentSelection();
/*  861 */     this.selectedHandler.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  875 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/*  877 */       this.elementBuffer.bufferElementEnd(buffer, nameOffset, nameLen, line, col);
/*      */       
/*  879 */       this.someSelectorsMatch = false;
/*  880 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/*  882 */         if (this.matchingMarkupLevelsPerSelector[i] > this.markupLevel)
/*      */         {
/*  884 */           this.selectorMatches[i] = this.selectorFilters[i].matchStandaloneElement(true, this.markupLevel, this.markupBlocks[this.markupLevel], this.elementBuffer);
/*  885 */           if (this.selectorMatches[i] != 0) {
/*  886 */             this.someSelectorsMatch = true;
/*      */           }
/*      */         } else {
/*  889 */           this.selectorMatches[i] = true;
/*  890 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  895 */       if (this.someSelectorsMatch) {
/*  896 */         markCurrentSelection();
/*  897 */         this.elementBuffer.flushBuffer(this.selectedHandler, false);
/*  898 */         unmarkCurrentSelection();
/*  899 */         return;
/*      */       }
/*      */       
/*  902 */       unmarkCurrentSelection();
/*  903 */       this.elementBuffer.flushBuffer(this.nonSelectedHandler, false);
/*  904 */       return;
/*      */     }
/*      */     
/*      */ 
/*  908 */     this.selectedHandler.handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col);
/*  909 */     unmarkCurrentSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  922 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/*  924 */       this.elementBuffer.bufferElementStart(buffer, nameOffset, nameLen, line, col, false, false);
/*  925 */       return;
/*      */     }
/*      */     
/*  928 */     markCurrentSelection();
/*  929 */     this.selectedHandler.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  942 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/*  944 */       this.elementBuffer.bufferElementEnd(buffer, nameOffset, nameLen, line, col);
/*      */       
/*  946 */       this.someSelectorsMatch = false;
/*  947 */       for (int i = 0; i < this.selectorsLen; i++) {
/*  948 */         if (this.matchingMarkupLevelsPerSelector[i] > this.markupLevel)
/*      */         {
/*  950 */           this.selectorMatches[i] = this.selectorFilters[i].matchOpenElement(true, this.markupLevel, this.markupBlocks[this.markupLevel], this.elementBuffer);
/*  951 */           if (this.selectorMatches[i] != 0) {
/*  952 */             this.someSelectorsMatch = true;
/*  953 */             this.matchingMarkupLevelsPerSelector[i] = this.markupLevel;
/*      */           }
/*      */         } else {
/*  956 */           this.selectorMatches[i] = true;
/*  957 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/*  961 */       if (this.someSelectorsMatch)
/*      */       {
/*      */ 
/*  964 */         updateInsideAllSelectorMatchingBlockFlag();
/*      */         
/*  966 */         this.markupLevel += 1;
/*      */         
/*  968 */         checkSizeOfMarkupBlocksStructure(this.markupLevel);
/*  969 */         this.markupBlocks[this.markupLevel] = (++this.markupBlockIndex);
/*      */         
/*  971 */         markCurrentSelection();
/*  972 */         this.elementBuffer.flushBuffer(this.selectedHandler, false);
/*  973 */         unmarkCurrentSelection();
/*      */         
/*  975 */         return;
/*      */       }
/*      */       
/*      */ 
/*  979 */       this.markupLevel += 1;
/*      */       
/*  981 */       checkSizeOfMarkupBlocksStructure(this.markupLevel);
/*  982 */       this.markupBlocks[this.markupLevel] = (++this.markupBlockIndex);
/*      */       
/*  984 */       unmarkCurrentSelection();
/*  985 */       this.elementBuffer.flushBuffer(this.nonSelectedHandler, false);
/*      */       
/*  987 */       return;
/*      */     }
/*      */     
/*      */ 
/*  991 */     this.markupLevel += 1;
/*      */     
/*  993 */     checkSizeOfMarkupBlocksStructure(this.markupLevel);
/*  994 */     this.markupBlocks[this.markupLevel] = (++this.markupBlockIndex);
/*      */     
/*  996 */     this.selectedHandler.handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*  997 */     unmarkCurrentSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/* 1010 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/* 1012 */       this.elementBuffer.bufferElementStart(buffer, nameOffset, nameLen, line, col, false, false);
/* 1013 */       return;
/*      */     }
/*      */     
/* 1016 */     markCurrentSelection();
/* 1017 */     this.selectedHandler.handleAutoOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/* 1030 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/* 1032 */       this.elementBuffer.bufferElementEnd(buffer, nameOffset, nameLen, line, col);
/*      */       
/* 1034 */       this.someSelectorsMatch = false;
/* 1035 */       for (int i = 0; i < this.selectorsLen; i++) {
/* 1036 */         if (this.matchingMarkupLevelsPerSelector[i] > this.markupLevel)
/*      */         {
/* 1038 */           this.selectorMatches[i] = this.selectorFilters[i].matchOpenElement(true, this.markupLevel, this.markupBlocks[this.markupLevel], this.elementBuffer);
/* 1039 */           if (this.selectorMatches[i] != 0) {
/* 1040 */             this.someSelectorsMatch = true;
/* 1041 */             this.matchingMarkupLevelsPerSelector[i] = this.markupLevel;
/*      */           }
/*      */         } else {
/* 1044 */           this.selectorMatches[i] = true;
/* 1045 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/* 1049 */       if (this.someSelectorsMatch)
/*      */       {
/*      */ 
/* 1052 */         updateInsideAllSelectorMatchingBlockFlag();
/*      */         
/* 1054 */         this.markupLevel += 1;
/*      */         
/* 1056 */         checkSizeOfMarkupBlocksStructure(this.markupLevel);
/* 1057 */         this.markupBlocks[this.markupLevel] = (++this.markupBlockIndex);
/*      */         
/* 1059 */         markCurrentSelection();
/* 1060 */         this.elementBuffer.flushBuffer(this.selectedHandler, true);
/* 1061 */         unmarkCurrentSelection();
/*      */         
/* 1063 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1067 */       this.markupLevel += 1;
/*      */       
/* 1069 */       checkSizeOfMarkupBlocksStructure(this.markupLevel);
/* 1070 */       this.markupBlocks[this.markupLevel] = (++this.markupBlockIndex);
/*      */       
/* 1072 */       unmarkCurrentSelection();
/* 1073 */       this.elementBuffer.flushBuffer(this.nonSelectedHandler, true);
/*      */       
/* 1075 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1079 */     this.markupLevel += 1;
/*      */     
/* 1081 */     checkSizeOfMarkupBlocksStructure(this.markupLevel);
/* 1082 */     this.markupBlocks[this.markupLevel] = (++this.markupBlockIndex);
/*      */     
/* 1084 */     this.selectedHandler.handleAutoOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/* 1085 */     unmarkCurrentSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/* 1098 */     this.markupLevel -= 1;
/* 1099 */     for (int i = 0; i < this.selectorsLen; i++) {
/* 1100 */       this.selectorFilters[i].removeMatchesForLevel(this.markupLevel);
/*      */     }
/*      */     
/* 1103 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/* 1105 */       this.someSelectorsMatch = false;
/* 1106 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/* 1108 */         this.selectorMatches[i] = (this.matchingMarkupLevelsPerSelector[i] <= this.markupLevel ? 1 : false);
/* 1109 */         if (this.selectorMatches[i] != 0) {
/* 1110 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/* 1114 */       if (this.someSelectorsMatch) {
/* 1115 */         markCurrentSelection();
/* 1116 */         this.selectedHandler.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/* 1117 */         return;
/*      */       }
/*      */       
/* 1120 */       unmarkCurrentSelection();
/* 1121 */       this.nonSelectedHandler.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/* 1122 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1126 */     markCurrentSelection();
/* 1127 */     this.selectedHandler.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/* 1140 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/* 1142 */       this.someSelectorsMatch = false;
/* 1143 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/* 1145 */         this.selectorMatches[i] = (this.matchingMarkupLevelsPerSelector[i] <= this.markupLevel ? 1 : false);
/* 1146 */         if (this.selectorMatches[i] != 0) {
/* 1147 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/* 1151 */       for (int i = 0; i < this.selectorsLen; i++) {
/* 1152 */         if (this.matchingMarkupLevelsPerSelector[i] == this.markupLevel) {
/* 1153 */           this.insideAllSelectorMatchingBlock = false;
/* 1154 */           this.matchingMarkupLevelsPerSelector[i] = Integer.MAX_VALUE;
/*      */         }
/*      */       }
/*      */       
/* 1158 */       if (this.someSelectorsMatch) {
/* 1159 */         this.selectedHandler.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/* 1160 */         unmarkCurrentSelection();
/* 1161 */         return;
/*      */       }
/*      */       
/* 1164 */       unmarkCurrentSelection();
/* 1165 */       this.nonSelectedHandler.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/* 1166 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1170 */     for (int i = 0; i < this.selectorsLen; i++) {
/* 1171 */       if (this.matchingMarkupLevelsPerSelector[i] == this.markupLevel) {
/* 1172 */         this.insideAllSelectorMatchingBlock = false;
/* 1173 */         this.matchingMarkupLevelsPerSelector[i] = Integer.MAX_VALUE;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1178 */     this.selectedHandler.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/* 1179 */     unmarkCurrentSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/* 1192 */     this.markupLevel -= 1;
/* 1193 */     for (int i = 0; i < this.selectorsLen; i++) {
/* 1194 */       this.selectorFilters[i].removeMatchesForLevel(this.markupLevel);
/*      */     }
/*      */     
/* 1197 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/* 1199 */       this.someSelectorsMatch = false;
/* 1200 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/* 1202 */         this.selectorMatches[i] = (this.matchingMarkupLevelsPerSelector[i] <= this.markupLevel ? 1 : false);
/* 1203 */         if (this.selectorMatches[i] != 0) {
/* 1204 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/* 1208 */       if (this.someSelectorsMatch) {
/* 1209 */         markCurrentSelection();
/* 1210 */         this.selectedHandler.handleAutoCloseElementStart(buffer, nameOffset, nameLen, line, col);
/* 1211 */         return;
/*      */       }
/*      */       
/* 1214 */       unmarkCurrentSelection();
/* 1215 */       this.nonSelectedHandler.handleAutoCloseElementStart(buffer, nameOffset, nameLen, line, col);
/* 1216 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1220 */     markCurrentSelection();
/* 1221 */     this.selectedHandler.handleAutoCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/* 1234 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/* 1236 */       this.someSelectorsMatch = false;
/* 1237 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/* 1239 */         this.selectorMatches[i] = (this.matchingMarkupLevelsPerSelector[i] <= this.markupLevel ? 1 : false);
/* 1240 */         if (this.selectorMatches[i] != 0) {
/* 1241 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/* 1245 */       for (int i = 0; i < this.selectorsLen; i++) {
/* 1246 */         if (this.matchingMarkupLevelsPerSelector[i] == this.markupLevel) {
/* 1247 */           this.insideAllSelectorMatchingBlock = false;
/* 1248 */           this.matchingMarkupLevelsPerSelector[i] = Integer.MAX_VALUE;
/*      */         }
/*      */       }
/*      */       
/* 1252 */       if (this.someSelectorsMatch) {
/* 1253 */         this.selectedHandler.handleAutoCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/* 1254 */         unmarkCurrentSelection();
/* 1255 */         return;
/*      */       }
/*      */       
/* 1258 */       unmarkCurrentSelection();
/* 1259 */       this.nonSelectedHandler.handleAutoCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/* 1260 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1264 */     for (int i = 0; i < this.selectorsLen; i++) {
/* 1265 */       if (this.matchingMarkupLevelsPerSelector[i] == this.markupLevel) {
/* 1266 */         this.insideAllSelectorMatchingBlock = false;
/* 1267 */         this.matchingMarkupLevelsPerSelector[i] = Integer.MAX_VALUE;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1272 */     this.selectedHandler.handleAutoCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/* 1273 */     unmarkCurrentSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleUnmatchedCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/* 1286 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/* 1288 */       this.someSelectorsMatch = false;
/* 1289 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/* 1291 */         this.selectorMatches[i] = (this.matchingMarkupLevelsPerSelector[i] <= this.markupLevel ? 1 : false);
/* 1292 */         if (this.selectorMatches[i] != 0) {
/* 1293 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/* 1297 */       if (this.someSelectorsMatch) {
/* 1298 */         markCurrentSelection();
/* 1299 */         this.selectedHandler.handleUnmatchedCloseElementStart(buffer, nameOffset, nameLen, line, col);
/* 1300 */         return;
/*      */       }
/*      */       
/* 1303 */       unmarkCurrentSelection();
/* 1304 */       this.nonSelectedHandler.handleUnmatchedCloseElementStart(buffer, nameOffset, nameLen, line, col);
/* 1305 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1309 */     markCurrentSelection();
/* 1310 */     this.selectedHandler.handleUnmatchedCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleUnmatchedCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/* 1323 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/* 1325 */       this.someSelectorsMatch = false;
/* 1326 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/* 1328 */         this.selectorMatches[i] = (this.matchingMarkupLevelsPerSelector[i] <= this.markupLevel ? 1 : false);
/* 1329 */         if (this.selectorMatches[i] != 0) {
/* 1330 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/* 1334 */       if (this.someSelectorsMatch) {
/* 1335 */         this.selectedHandler.handleUnmatchedCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/* 1336 */         unmarkCurrentSelection();
/* 1337 */         return;
/*      */       }
/*      */       
/* 1340 */       unmarkCurrentSelection();
/* 1341 */       this.nonSelectedHandler.handleUnmatchedCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/* 1342 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1346 */     this.selectedHandler.handleUnmatchedCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/* 1347 */     unmarkCurrentSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*      */     throws ParseException
/*      */   {
/* 1361 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/* 1363 */       this.elementBuffer.bufferElementInnerWhiteSpace(buffer, offset, len, line, col);
/* 1364 */       return;
/*      */     }
/*      */     
/* 1367 */     this.selectedHandler.handleInnerWhiteSpace(buffer, offset, len, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleProcessingInstruction(char[] buffer, int targetOffset, int targetLen, int targetLine, int targetCol, int contentOffset, int contentLen, int contentLine, int contentCol, int outerOffset, int outerLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/* 1389 */     if (!this.insideAllSelectorMatchingBlock)
/*      */     {
/* 1391 */       this.someSelectorsMatch = false;
/* 1392 */       for (int i = 0; i < this.selectorsLen; i++)
/*      */       {
/* 1394 */         if (this.matchingMarkupLevelsPerSelector[i] > this.markupLevel)
/*      */         {
/* 1396 */           this.selectorMatches[i] = this.selectorFilters[i].matchProcessingInstruction(true, this.markupLevel, this.markupBlocks[this.markupLevel]);
/* 1397 */           if (this.selectorMatches[i] != 0) {
/* 1398 */             this.someSelectorsMatch = true;
/*      */           }
/*      */         } else {
/* 1401 */           this.selectorMatches[i] = true;
/* 1402 */           this.someSelectorsMatch = true;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1407 */       if (this.someSelectorsMatch) {
/* 1408 */         markCurrentSelection();
/* 1409 */         this.selectedHandler.handleProcessingInstruction(buffer, targetOffset, targetLen, targetLine, targetCol, contentOffset, contentLen, contentLine, contentCol, outerOffset, outerLen, line, col);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1414 */         unmarkCurrentSelection();
/* 1415 */         return;
/*      */       }
/*      */       
/* 1418 */       unmarkCurrentSelection();
/* 1419 */       this.nonSelectedHandler.handleProcessingInstruction(buffer, targetOffset, targetLen, targetLine, targetCol, contentOffset, contentLen, contentLine, contentCol, outerOffset, outerLen, line, col);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1424 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1428 */     markCurrentSelection();
/* 1429 */     this.selectedHandler.handleProcessingInstruction(buffer, targetOffset, targetLen, targetLine, targetCol, contentOffset, contentLen, contentLine, contentCol, outerOffset, outerLen, line, col);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1434 */     unmarkCurrentSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void markCurrentSelection()
/*      */   {
/* 1447 */     this.selection.levels[this.selectionIndex].selection = this.selectorMatches;
/*      */   }
/*      */   
/*      */   private void unmarkCurrentSelection() {
/* 1451 */     this.selection.levels[this.selectionIndex].selection = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkSizeOfMarkupBlocksStructure(int markupLevel)
/*      */   {
/* 1462 */     if (markupLevel >= this.markupBlocks.length) {
/* 1463 */       int newLen = Math.max(markupLevel + 1, this.markupBlocks.length + 10);
/* 1464 */       int[] newMarkupBlocks = new int[newLen];
/* 1465 */       Arrays.fill(newMarkupBlocks, 0);
/* 1466 */       System.arraycopy(this.markupBlocks, 0, newMarkupBlocks, 0, this.markupBlocks.length);
/* 1467 */       this.markupBlocks = newMarkupBlocks;
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateInsideAllSelectorMatchingBlockFlag()
/*      */   {
/* 1473 */     for (int i = 0; i < this.selectorsLen; i++) {
/* 1474 */       if (this.selectorMatches[i] == 0) {
/* 1475 */         this.insideAllSelectorMatchingBlock = false;
/* 1476 */         return;
/*      */       }
/*      */     }
/* 1479 */     this.insideAllSelectorMatchingBlock = true;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\select\BlockSelectorMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */