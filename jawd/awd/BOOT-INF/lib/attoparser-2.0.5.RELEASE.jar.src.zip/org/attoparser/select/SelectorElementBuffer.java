/*     */ package org.attoparser.select;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.attoparser.IMarkupHandler;
/*     */ import org.attoparser.ParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SelectorElementBuffer
/*     */ {
/*     */   private static final int DEFAULT_ELEMENT_NAME_SIZE = 10;
/*     */   private static final int DEFAULT_ATTRIBUTES_SIZE = 8;
/*     */   private static final int DEFAULT_ATTRIBUTES_INC = 4;
/*     */   private static final int DEFAULT_ATTRIBUTE_BUFFER_SIZE = 40;
/*     */   private static final int DEFAULT_INNER_WHITE_SPACE_BUFFER_SIZE = 1;
/*     */   boolean standalone;
/*     */   boolean minimized;
/*     */   char[] elementName;
/*     */   int elementNameLen;
/*     */   int elementNameLine;
/*     */   int elementNameCol;
/*     */   int elementEndLine;
/*     */   int elementEndCol;
/*     */   int attributeCount;
/*     */   char[][] attributeBuffers;
/*     */   int[] attributeNameLens;
/*     */   int[] attributeOperatorLens;
/*     */   int[] attributeValueContentOffsets;
/*     */   int[] attributeValueContentLens;
/*     */   int[] attributeValueOuterLens;
/*     */   int[] attributeNameLines;
/*     */   int[] attributeNameCols;
/*     */   int[] attributeOperatorLines;
/*     */   int[] attributeOperatorCols;
/*     */   int[] attributeValueLines;
/*     */   int[] attributeValueCols;
/*     */   int elementInnerWhiteSpaceCount;
/*     */   char[][] elementInnerWhiteSpaceBuffers;
/*     */   int[] elementInnerWhiteSpaceLens;
/*     */   int[] elementInnerWhiteSpaceLines;
/*     */   int[] elementInnerWhiteSpaceCols;
/*     */   
/*     */   SelectorElementBuffer()
/*     */   {
/*  85 */     this.standalone = false;
/*  86 */     this.minimized = false;
/*     */     
/*  88 */     this.elementName = new char[10];
/*  89 */     this.elementNameLen = 0;
/*     */     
/*  91 */     this.elementNameLine = 0;
/*  92 */     this.elementNameCol = 0;
/*     */     
/*  94 */     this.elementEndLine = 0;
/*  95 */     this.elementEndCol = 0;
/*     */     
/*     */ 
/*  98 */     this.attributeCount = 0;
/*     */     
/* 100 */     this.attributeBuffers = new char[8][];
/* 101 */     Arrays.fill(this.attributeBuffers, null);
/*     */     
/* 103 */     this.attributeNameLens = new int[8];
/* 104 */     Arrays.fill(this.attributeNameLens, 0);
/*     */     
/* 106 */     this.attributeOperatorLens = new int[8];
/* 107 */     Arrays.fill(this.attributeOperatorLens, 0);
/*     */     
/* 109 */     this.attributeValueContentOffsets = new int[8];
/* 110 */     this.attributeValueContentLens = new int[8];
/* 111 */     Arrays.fill(this.attributeValueContentOffsets, 0);
/* 112 */     Arrays.fill(this.attributeValueContentLens, 0);
/*     */     
/* 114 */     this.attributeValueOuterLens = new int[8];
/* 115 */     Arrays.fill(this.attributeValueOuterLens, 0);
/*     */     
/* 117 */     this.attributeNameLines = new int[8];
/* 118 */     Arrays.fill(this.attributeNameLines, 0);
/* 119 */     this.attributeNameCols = new int[8];
/* 120 */     Arrays.fill(this.attributeNameCols, 0);
/*     */     
/* 122 */     this.attributeOperatorLines = new int[8];
/* 123 */     Arrays.fill(this.attributeOperatorLines, 0);
/* 124 */     this.attributeOperatorCols = new int[8];
/* 125 */     Arrays.fill(this.attributeOperatorCols, 0);
/*     */     
/* 127 */     this.attributeValueLines = new int[8];
/* 128 */     Arrays.fill(this.attributeValueLines, 0);
/* 129 */     this.attributeValueCols = new int[8];
/* 130 */     Arrays.fill(this.attributeValueCols, 0);
/*     */     
/*     */ 
/* 133 */     this.elementInnerWhiteSpaceCount = 0;
/*     */     
/* 135 */     this.elementInnerWhiteSpaceBuffers = new char[9][];
/* 136 */     Arrays.fill(this.elementInnerWhiteSpaceBuffers, null);
/*     */     
/* 138 */     this.elementInnerWhiteSpaceLens = new int[9];
/* 139 */     Arrays.fill(this.elementInnerWhiteSpaceLens, 0);
/*     */     
/* 141 */     this.elementInnerWhiteSpaceLines = new int[9];
/* 142 */     Arrays.fill(this.elementInnerWhiteSpaceLines, 0);
/* 143 */     this.elementInnerWhiteSpaceCols = new int[9];
/* 144 */     Arrays.fill(this.elementInnerWhiteSpaceCols, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void bufferElementStart(char[] buffer, int offset, int len, int line, int col, boolean standalone, boolean minimized)
/*     */   {
/* 153 */     if (len > this.elementName.length) {
/* 154 */       this.elementName = new char[len];
/*     */     }
/* 156 */     System.arraycopy(buffer, offset, this.elementName, 0, len);
/* 157 */     this.elementNameLen = len;
/*     */     
/* 159 */     this.elementNameLine = line;
/* 160 */     this.elementNameCol = col;
/*     */     
/* 162 */     this.elementEndLine = 0;
/* 163 */     this.elementEndCol = 0;
/*     */     
/* 165 */     this.standalone = standalone;
/* 166 */     this.minimized = minimized;
/*     */     
/* 168 */     this.attributeCount = 0;
/* 169 */     this.elementInnerWhiteSpaceCount = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void bufferAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */   {
/* 183 */     if (this.attributeCount >= this.attributeBuffers.length)
/*     */     {
/*     */ 
/* 186 */       char[][] newAttributeBuffers = new char[this.attributeCount + 4][];
/* 187 */       Arrays.fill(newAttributeBuffers, null);
/* 188 */       System.arraycopy(this.attributeBuffers, 0, newAttributeBuffers, 0, this.attributeCount);
/* 189 */       this.attributeBuffers = newAttributeBuffers;
/*     */       
/* 191 */       int[] newAttributeNameLens = new int[this.attributeCount + 4];
/* 192 */       Arrays.fill(newAttributeNameLens, 0);
/* 193 */       System.arraycopy(this.attributeNameLens, 0, newAttributeNameLens, 0, this.attributeCount);
/* 194 */       this.attributeNameLens = newAttributeNameLens;
/*     */       
/* 196 */       int[] newAttributeOperatorLens = new int[this.attributeCount + 4];
/* 197 */       Arrays.fill(newAttributeOperatorLens, 0);
/* 198 */       System.arraycopy(this.attributeOperatorLens, 0, newAttributeOperatorLens, 0, this.attributeCount);
/* 199 */       this.attributeOperatorLens = newAttributeOperatorLens;
/*     */       
/* 201 */       int[] newAttributeValueContentOffsets = new int[this.attributeCount + 4];
/* 202 */       int[] newAttributeValueContentLens = new int[this.attributeCount + 4];
/* 203 */       Arrays.fill(newAttributeValueContentOffsets, 0);
/* 204 */       Arrays.fill(newAttributeValueContentLens, 0);
/* 205 */       System.arraycopy(this.attributeValueContentOffsets, 0, newAttributeValueContentOffsets, 0, this.attributeCount);
/* 206 */       System.arraycopy(this.attributeValueContentLens, 0, newAttributeValueContentLens, 0, this.attributeCount);
/* 207 */       this.attributeValueContentOffsets = newAttributeValueContentOffsets;
/* 208 */       this.attributeValueContentLens = newAttributeValueContentLens;
/*     */       
/* 210 */       int[] newAttributeValueOuterLens = new int[this.attributeCount + 4];
/* 211 */       Arrays.fill(newAttributeValueOuterLens, 0);
/* 212 */       System.arraycopy(this.attributeValueOuterLens, 0, newAttributeValueOuterLens, 0, this.attributeCount);
/* 213 */       this.attributeValueOuterLens = newAttributeValueOuterLens;
/*     */       
/* 215 */       int[] newAttributeNameLines = new int[this.attributeCount + 4];
/* 216 */       int[] newAttributeNameCols = new int[this.attributeCount + 4];
/* 217 */       System.arraycopy(this.attributeNameLines, 0, newAttributeNameLines, 0, this.attributeCount);
/* 218 */       System.arraycopy(this.attributeNameCols, 0, newAttributeNameCols, 0, this.attributeCount);
/* 219 */       this.attributeNameLines = newAttributeNameLines;
/* 220 */       this.attributeNameCols = newAttributeNameCols;
/*     */       
/* 222 */       int[] newAttributeOperatorLines = new int[this.attributeCount + 4];
/* 223 */       int[] newAttributeOperatorCols = new int[this.attributeCount + 4];
/* 224 */       System.arraycopy(this.attributeOperatorLines, 0, newAttributeOperatorLines, 0, this.attributeCount);
/* 225 */       System.arraycopy(this.attributeOperatorCols, 0, newAttributeOperatorCols, 0, this.attributeCount);
/* 226 */       this.attributeOperatorLines = newAttributeOperatorLines;
/* 227 */       this.attributeOperatorCols = newAttributeOperatorCols;
/*     */       
/* 229 */       int[] newAttributeValueLines = new int[this.attributeCount + 4];
/* 230 */       int[] newAttributeValueCols = new int[this.attributeCount + 4];
/* 231 */       System.arraycopy(this.attributeValueLines, 0, newAttributeValueLines, 0, this.attributeCount);
/* 232 */       System.arraycopy(this.attributeValueCols, 0, newAttributeValueCols, 0, this.attributeCount);
/* 233 */       this.attributeValueLines = newAttributeValueLines;
/* 234 */       this.attributeValueCols = newAttributeValueCols;
/*     */     }
/*     */     
/*     */ 
/* 238 */     int requiredLen = nameLen + operatorLen + valueOuterLen;
/*     */     
/* 240 */     if ((this.attributeBuffers[this.attributeCount] == null) || (this.attributeBuffers[this.attributeCount].length < requiredLen))
/*     */     {
/*     */ 
/* 243 */       this.attributeBuffers[this.attributeCount] = new char[Math.max(requiredLen, 40)];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 248 */     boolean isContinuous = (nameOffset + nameLen == operatorOffset) && (operatorOffset + operatorLen == valueOuterOffset) && (valueOuterOffset <= valueContentOffset) && (valueOuterOffset + valueOuterLen >= valueContentOffset + valueContentLen);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 253 */     if (isContinuous) {
/* 254 */       System.arraycopy(buffer, nameOffset, this.attributeBuffers[this.attributeCount], 0, requiredLen);
/*     */     } else {
/* 256 */       System.arraycopy(buffer, nameOffset, this.attributeBuffers[this.attributeCount], 0, nameLen);
/* 257 */       System.arraycopy(buffer, operatorOffset, this.attributeBuffers[this.attributeCount], nameLen, operatorLen);
/* 258 */       System.arraycopy(buffer, valueOuterOffset, this.attributeBuffers[this.attributeCount], nameLen + operatorLen, valueOuterLen);
/*     */     }
/*     */     
/* 261 */     this.attributeNameLens[this.attributeCount] = nameLen;
/* 262 */     this.attributeOperatorLens[this.attributeCount] = operatorLen;
/*     */     
/* 264 */     this.attributeValueContentOffsets[this.attributeCount] = (nameLen + operatorLen + (valueContentOffset - valueOuterOffset));
/* 265 */     this.attributeValueContentLens[this.attributeCount] = valueContentLen;
/* 266 */     this.attributeValueOuterLens[this.attributeCount] = valueOuterLen;
/*     */     
/* 268 */     this.attributeNameLines[this.attributeCount] = nameLine;
/* 269 */     this.attributeNameCols[this.attributeCount] = nameCol;
/*     */     
/* 271 */     this.attributeOperatorLines[this.attributeCount] = operatorLine;
/* 272 */     this.attributeOperatorCols[this.attributeCount] = operatorCol;
/*     */     
/* 274 */     this.attributeValueLines[this.attributeCount] = valueLine;
/* 275 */     this.attributeValueCols[this.attributeCount] = valueCol;
/*     */     
/* 277 */     this.attributeCount += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void bufferElementEnd(char[] buffer, int offset, int len, int line, int col)
/*     */   {
/* 285 */     this.elementEndLine = line;
/* 286 */     this.elementEndCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void bufferElementInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*     */   {
/* 294 */     if (this.elementInnerWhiteSpaceCount >= this.elementInnerWhiteSpaceBuffers.length)
/*     */     {
/*     */ 
/* 297 */       char[][] newElementInnerWhiteSpaceBuffers = new char[this.elementInnerWhiteSpaceCount + 4][];
/* 298 */       Arrays.fill(newElementInnerWhiteSpaceBuffers, null);
/* 299 */       System.arraycopy(this.elementInnerWhiteSpaceBuffers, 0, newElementInnerWhiteSpaceBuffers, 0, this.elementInnerWhiteSpaceCount);
/* 300 */       this.elementInnerWhiteSpaceBuffers = newElementInnerWhiteSpaceBuffers;
/*     */       
/* 302 */       int[] newElementInnerWhiteSpaceLens = new int[this.elementInnerWhiteSpaceCount + 4];
/* 303 */       System.arraycopy(this.elementInnerWhiteSpaceLens, 0, newElementInnerWhiteSpaceLens, 0, this.elementInnerWhiteSpaceCount);
/* 304 */       this.elementInnerWhiteSpaceLens = newElementInnerWhiteSpaceLens;
/*     */       
/* 306 */       int[] newElementInnerWhiteSpaceLines = new int[this.elementInnerWhiteSpaceCount + 4];
/* 307 */       int[] newElementInnerWhiteSpaceCols = new int[this.elementInnerWhiteSpaceCount + 4];
/* 308 */       System.arraycopy(this.elementInnerWhiteSpaceLines, 0, newElementInnerWhiteSpaceLines, 0, this.elementInnerWhiteSpaceCount);
/* 309 */       System.arraycopy(this.elementInnerWhiteSpaceCols, 0, newElementInnerWhiteSpaceCols, 0, this.elementInnerWhiteSpaceCount);
/* 310 */       this.elementInnerWhiteSpaceLines = newElementInnerWhiteSpaceLines;
/* 311 */       this.elementInnerWhiteSpaceCols = newElementInnerWhiteSpaceCols;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 316 */     if ((this.elementInnerWhiteSpaceBuffers[this.elementInnerWhiteSpaceCount] == null) || (this.elementInnerWhiteSpaceBuffers[this.elementInnerWhiteSpaceCount].length < len))
/*     */     {
/*     */ 
/* 319 */       this.elementInnerWhiteSpaceBuffers[this.elementInnerWhiteSpaceCount] = new char[Math.max(len, 1)];
/*     */     }
/*     */     
/* 322 */     System.arraycopy(buffer, offset, this.elementInnerWhiteSpaceBuffers[this.elementInnerWhiteSpaceCount], 0, len);
/*     */     
/* 324 */     this.elementInnerWhiteSpaceLens[this.elementInnerWhiteSpaceCount] = len;
/*     */     
/* 326 */     this.elementInnerWhiteSpaceLines[this.elementInnerWhiteSpaceCount] = line;
/* 327 */     this.elementInnerWhiteSpaceCols[this.elementInnerWhiteSpaceCount] = col;
/*     */     
/* 329 */     this.elementInnerWhiteSpaceCount += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void flushBuffer(IMarkupHandler handler, boolean autoOpen)
/*     */     throws ParseException
/*     */   {
/* 337 */     if (this.standalone) {
/* 338 */       handler.handleStandaloneElementStart(this.elementName, 0, this.elementNameLen, this.minimized, this.elementNameLine, this.elementNameCol);
/*     */     }
/* 340 */     else if (autoOpen) {
/* 341 */       handler.handleAutoOpenElementStart(this.elementName, 0, this.elementNameLen, this.elementNameLine, this.elementNameCol);
/*     */     }
/*     */     else {
/* 344 */       handler.handleOpenElementStart(this.elementName, 0, this.elementNameLen, this.elementNameLine, this.elementNameCol);
/*     */     }
/*     */     
/*     */ 
/* 348 */     for (int i = 0; i < this.attributeCount; i++)
/*     */     {
/* 350 */       handler.handleInnerWhiteSpace(this.elementInnerWhiteSpaceBuffers[i], 0, this.elementInnerWhiteSpaceLens[i], this.elementInnerWhiteSpaceLines[i], this.elementInnerWhiteSpaceCols[i]);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 355 */       handler.handleAttribute(this.attributeBuffers[i], 0, this.attributeNameLens[i], this.attributeNameLines[i], this.attributeNameCols[i], this.attributeNameLens[i], this.attributeOperatorLens[i], this.attributeOperatorLines[i], this.attributeOperatorCols[i], this.attributeValueContentOffsets[i], this.attributeValueContentLens[i], this.attributeNameLens[i] + this.attributeOperatorLens[i], this.attributeValueOuterLens[i], this.attributeValueLines[i], this.attributeValueCols[i]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 364 */     if (this.elementInnerWhiteSpaceCount - this.attributeCount > 0)
/*     */     {
/* 366 */       for (int i = this.attributeCount; i < this.elementInnerWhiteSpaceCount; i++)
/*     */       {
/* 368 */         handler.handleInnerWhiteSpace(this.elementInnerWhiteSpaceBuffers[i], 0, this.elementInnerWhiteSpaceLens[i], this.elementInnerWhiteSpaceLines[i], this.elementInnerWhiteSpaceCols[i]);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 377 */     if (this.standalone) {
/* 378 */       handler.handleStandaloneElementEnd(this.elementName, 0, this.elementNameLen, this.minimized, this.elementEndLine, this.elementEndCol);
/*     */     }
/* 380 */     else if (autoOpen) {
/* 381 */       handler.handleAutoOpenElementEnd(this.elementName, 0, this.elementNameLen, this.elementEndLine, this.elementEndCol);
/*     */     }
/*     */     else {
/* 384 */       handler.handleOpenElementEnd(this.elementName, 0, this.elementNameLen, this.elementEndLine, this.elementEndCol);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\select\SelectorElementBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */