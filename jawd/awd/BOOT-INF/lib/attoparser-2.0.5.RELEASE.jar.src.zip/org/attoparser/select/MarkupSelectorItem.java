/*     */ package org.attoparser.select;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.attoparser.util.TextUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MarkupSelectorItem
/*     */   implements IMarkupSelectorItem
/*     */ {
/*     */   static final String CONTENT_SELECTOR = "content()";
/*     */   static final String TEXT_SELECTOR = "text()";
/*     */   static final String COMMENT_SELECTOR = "comment()";
/*     */   static final String CDATA_SECTION_SELECTOR = "cdata()";
/*     */   static final String DOC_TYPE_CLAUSE_SELECTOR = "doctype()";
/*     */   static final String XML_DECLARATION_SELECTOR = "xmldecl()";
/*     */   static final String PROCESSING_INSTRUCTION_SELECTOR = "procinstr()";
/*     */   static final String ID_MODIFIER_SEPARATOR = "#";
/*     */   static final String CLASS_MODIFIER_SEPARATOR = ".";
/*     */   static final String REFERENCE_MODIFIER_SEPARATOR = "%";
/*     */   static final String ID_ATTRIBUTE_NAME = "id";
/*     */   static final String CLASS_ATTRIBUTE_NAME = "class";
/*     */   static final String ODD_SELECTOR = "odd()";
/*     */   static final String EVEN_SELECTOR = "even()";
/*     */   private final boolean html;
/*     */   private final boolean anyLevel;
/*     */   private final boolean contentSelector;
/*     */   private final boolean textSelector;
/*     */   private final boolean commentSelector;
/*     */   private final boolean cdataSectionSelector;
/*     */   private final boolean docTypeClauseSelector;
/*     */   private final boolean xmlDeclarationSelector;
/*     */   private final boolean processingInstructionSelector;
/*     */   private final String selectorPath;
/*     */   private final int selectorPathLen;
/*     */   private final IndexCondition index;
/*     */   private final IAttributeCondition attributeCondition;
/*     */   private final boolean requiresAttributesInElement;
/*     */   
/*     */   MarkupSelectorItem(boolean html, boolean anyLevel, boolean contentSelector, boolean textSelector, boolean commentSelector, boolean cdataSectionSelector, boolean docTypeClauseSelector, boolean xmlDeclarationSelector, boolean processingInstructionSelector, String selectorPath, IndexCondition index, IAttributeCondition attributeCondition)
/*     */   {
/*  80 */     this.html = html;
/*  81 */     this.anyLevel = anyLevel;
/*  82 */     this.contentSelector = contentSelector;
/*  83 */     this.textSelector = textSelector;
/*  84 */     this.commentSelector = commentSelector;
/*  85 */     this.cdataSectionSelector = cdataSectionSelector;
/*  86 */     this.docTypeClauseSelector = docTypeClauseSelector;
/*  87 */     this.xmlDeclarationSelector = xmlDeclarationSelector;
/*  88 */     this.processingInstructionSelector = processingInstructionSelector;
/*  89 */     this.selectorPath = selectorPath;
/*  90 */     this.selectorPathLen = (selectorPath != null ? selectorPath.length() : 0);
/*  91 */     this.index = index;
/*  92 */     this.attributeCondition = attributeCondition;
/*     */     
/*     */ 
/*     */ 
/*  96 */     this.requiresAttributesInElement = computeRequiresAttributesInElement(this.attributeCondition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static boolean computeRequiresAttributesInElement(IAttributeCondition attributeCondition)
/*     */   {
/* 103 */     if (attributeCondition == null) {
/* 104 */       return false;
/*     */     }
/*     */     
/* 107 */     if ((attributeCondition instanceof AttributeConditionRelation)) {
/* 108 */       AttributeConditionRelation relation = (AttributeConditionRelation)attributeCondition;
/*     */       
/* 110 */       return (computeRequiresAttributesInElement(relation.left)) || (computeRequiresAttributesInElement(relation.right));
/*     */     }
/*     */     
/* 113 */     AttributeCondition attrCondition = (AttributeCondition)attributeCondition;
/* 114 */     return (!attrCondition.operator.equals(MarkupSelectorItem.AttributeCondition.Operator.NOT_EQUALS)) && 
/* 115 */       (!attrCondition.operator.equals(MarkupSelectorItem.AttributeCondition.Operator.NOT_EXISTS));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 124 */     StringBuilder strBuilder = new StringBuilder();
/*     */     
/* 126 */     if (this.anyLevel) {
/* 127 */       strBuilder.append("//");
/*     */     } else {
/* 129 */       strBuilder.append("/");
/*     */     }
/*     */     
/* 132 */     if (this.selectorPath != null) {
/* 133 */       strBuilder.append(this.selectorPath);
/* 134 */     } else if (this.contentSelector) {
/* 135 */       strBuilder.append("content()");
/* 136 */     } else if (this.textSelector) {
/* 137 */       strBuilder.append("text()");
/* 138 */     } else if (this.commentSelector) {
/* 139 */       strBuilder.append("comment()");
/* 140 */     } else if (this.cdataSectionSelector) {
/* 141 */       strBuilder.append("cdata()");
/* 142 */     } else if (this.docTypeClauseSelector) {
/* 143 */       strBuilder.append("doctype()");
/* 144 */     } else if (this.xmlDeclarationSelector) {
/* 145 */       strBuilder.append("xmldecl()");
/* 146 */     } else if (this.processingInstructionSelector) {
/* 147 */       strBuilder.append("procinstr()");
/*     */     } else {
/* 149 */       strBuilder.append("*");
/*     */     }
/*     */     
/* 152 */     if (this.attributeCondition != null) {
/* 153 */       strBuilder.append("[");
/* 154 */       strBuilder.append(toStringAttributeCondition(this.attributeCondition, false));
/* 155 */       strBuilder.append("]");
/*     */     }
/*     */     
/* 158 */     if (this.index != null) {
/* 159 */       strBuilder.append("[");
/* 160 */       switch (this.index.type) {
/*     */       case VALUE: 
/* 162 */         strBuilder.append(this.index.value);
/* 163 */         break;
/*     */       case LESS_THAN: 
/* 165 */         strBuilder.append("<").append(this.index.value);
/* 166 */         break;
/*     */       case MORE_THAN: 
/* 168 */         strBuilder.append(">").append(this.index.value);
/* 169 */         break;
/*     */       case EVEN: 
/* 171 */         strBuilder.append("even()");
/* 172 */         break;
/*     */       case ODD: 
/* 174 */         strBuilder.append("odd()");
/*     */       }
/*     */       
/* 177 */       strBuilder.append("]");
/*     */     }
/*     */     
/* 180 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   private static String toStringAttributeCondition(IAttributeCondition attributeCondition, boolean outputParenthesis)
/*     */   {
/* 186 */     if ((attributeCondition instanceof AttributeConditionRelation)) {
/* 187 */       AttributeConditionRelation relation = (AttributeConditionRelation)attributeCondition;
/* 188 */       if (outputParenthesis) {
/* 189 */         return "(" + toStringAttributeCondition(relation.left, true) + " " + relation.type + " " + toStringAttributeCondition(relation.right, true) + ")";
/*     */       }
/* 191 */       return toStringAttributeCondition(relation.left, true) + " " + relation.type + " " + toStringAttributeCondition(relation.right, true);
/*     */     }
/*     */     
/* 194 */     AttributeCondition attrCondition = (AttributeCondition)attributeCondition;
/* 195 */     return attrCondition.name + attrCondition.operator.text + (attrCondition.value != null ? "'" + attrCondition.value + "'" : "");
/*     */   }
/*     */   
/*     */ 
/*     */   static abstract interface IAttributeCondition {}
/*     */   
/*     */ 
/*     */   static final class AttributeCondition
/*     */     implements MarkupSelectorItem.IAttributeCondition
/*     */   {
/*     */     final String name;
/*     */     
/*     */     final Operator operator;
/*     */     
/*     */     final String value;
/*     */     
/*     */     static enum Operator
/*     */     {
/* 213 */       EQUALS("="),  NOT_EQUALS("!="),  STARTS_WITH("^="),  ENDS_WITH("$="),  EXISTS("*"),  NOT_EXISTS("!"),  CONTAINS("*=");
/*     */       
/*     */       private String text;
/*     */       
/* 217 */       private Operator(String text) { this.text = text; }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     AttributeCondition(String name, Operator operator, String value)
/*     */     {
/* 228 */       this.name = name;
/* 229 */       this.operator = operator;
/* 230 */       this.value = value;
/*     */     } }
/*     */   
/*     */   static final class AttributeConditionRelation implements MarkupSelectorItem.IAttributeCondition { final Type type;
/*     */     final MarkupSelectorItem.IAttributeCondition left;
/*     */     final MarkupSelectorItem.IAttributeCondition right;
/*     */     
/* 237 */     static enum Type { AND,  OR;
/*     */       
/*     */ 
/*     */       private Type() {}
/*     */     }
/*     */     
/*     */     AttributeConditionRelation(Type type, MarkupSelectorItem.IAttributeCondition left, MarkupSelectorItem.IAttributeCondition right)
/*     */     {
/* 245 */       this.type = type;
/* 246 */       this.left = left;
/* 247 */       this.right = right;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static final class IndexCondition
/*     */   {
/*     */     static enum IndexConditionType
/*     */     {
/* 257 */       VALUE,  LESS_THAN,  MORE_THAN,  EVEN,  ODD;
/* 258 */       private IndexConditionType() {} } static IndexCondition INDEX_CONDITION_ODD = new IndexCondition(IndexConditionType.ODD, -1);
/* 259 */     static IndexCondition INDEX_CONDITION_EVEN = new IndexCondition(IndexConditionType.EVEN, -1);
/*     */     
/*     */     final IndexConditionType type;
/*     */     final int value;
/*     */     
/*     */     IndexCondition(IndexConditionType type, int value)
/*     */     {
/* 266 */       this.type = type;
/* 267 */       this.value = value;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean anyLevel()
/*     */   {
/* 290 */     return this.anyLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean matchesText(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*     */   {
/* 297 */     return ((this.contentSelector) || (this.textSelector)) && ((this.index == null) || (matchesIndex(markupBlockIndex, markupBlockMatchingCounter, this.index)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matchesComment(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*     */   {
/* 305 */     return ((this.contentSelector) || (this.commentSelector)) && ((this.index == null) || (matchesIndex(markupBlockIndex, markupBlockMatchingCounter, this.index)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matchesCDATASection(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*     */   {
/* 313 */     return ((this.contentSelector) || (this.cdataSectionSelector)) && ((this.index == null) || (matchesIndex(markupBlockIndex, markupBlockMatchingCounter, this.index)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matchesDocTypeClause(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*     */   {
/* 321 */     return ((this.contentSelector) || (this.docTypeClauseSelector)) && ((this.index == null) || (matchesIndex(markupBlockIndex, markupBlockMatchingCounter, this.index)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matchesXmlDeclaration(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*     */   {
/* 329 */     return ((this.contentSelector) || (this.xmlDeclarationSelector)) && ((this.index == null) || (matchesIndex(markupBlockIndex, markupBlockMatchingCounter, this.index)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matchesProcessingInstruction(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*     */   {
/* 337 */     return ((this.contentSelector) || (this.processingInstructionSelector)) && ((this.index == null) || (matchesIndex(markupBlockIndex, markupBlockMatchingCounter, this.index)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matchesElement(int markupBlockIndex, SelectorElementBuffer elementBuffer, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter)
/*     */   {
/* 345 */     if ((this.textSelector) || (this.commentSelector) || (this.cdataSectionSelector) || (this.docTypeClauseSelector) || (this.xmlDeclarationSelector) || (this.processingInstructionSelector))
/*     */     {
/* 347 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 352 */     if ((!this.contentSelector) && (this.requiresAttributesInElement) && (elementBuffer.attributeCount == 0)) {
/* 353 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 358 */     if ((!this.contentSelector) && (this.selectorPath != null)) {
/* 359 */       if (!TextUtil.equals(!this.html, this.selectorPath, 0, this.selectorPathLen, elementBuffer.elementName, 0, elementBuffer.elementNameLen))
/*     */       {
/*     */ 
/*     */ 
/* 363 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 367 */     if ((!this.contentSelector) && (this.attributeCondition != null) && 
/* 368 */       (!matchesAttributeCondition(this.html, elementBuffer, this.attributeCondition))) {
/* 369 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 376 */     if ((this.index != null) && 
/* 377 */       (!matchesIndex(markupBlockIndex, markupBlockMatchingCounter, this.index))) {
/* 378 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 382 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean matchesAttributeCondition(boolean html, SelectorElementBuffer elementBuffer, IAttributeCondition attributeCondition)
/*     */   {
/* 391 */     if ((attributeCondition instanceof AttributeConditionRelation)) {
/* 392 */       AttributeConditionRelation relation = (AttributeConditionRelation)attributeCondition;
/* 393 */       switch (relation.type) {
/*     */       case AND: 
/* 395 */         return (matchesAttributeCondition(html, elementBuffer, relation.left)) && 
/* 396 */           (matchesAttributeCondition(html, elementBuffer, relation.right));
/*     */       case OR: 
/* 398 */         return (matchesAttributeCondition(html, elementBuffer, relation.left)) || 
/* 399 */           (matchesAttributeCondition(html, elementBuffer, relation.right));
/*     */       }
/*     */       
/*     */     }
/* 403 */     AttributeCondition attrCondition = (AttributeCondition)attributeCondition;
/* 404 */     return matchesAttribute(html, elementBuffer, attrCondition.name, attrCondition.operator, attrCondition.value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean matchesAttribute(boolean html, SelectorElementBuffer elementBuffer, String attrName, MarkupSelectorItem.AttributeCondition.Operator attrOperator, String attrValue)
/*     */   {
/* 414 */     boolean found = false;
/* 415 */     for (int i = 0; i < elementBuffer.attributeCount; i++)
/*     */     {
/* 417 */       if (TextUtil.equals(!html, attrName, 0, attrName
/*     */       
/* 419 */         .length(), elementBuffer.attributeBuffers[i], 0, elementBuffer.attributeNameLens[i]))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 427 */         found = true;
/*     */         
/* 429 */         if ((html) && ("class".equals(attrName)))
/*     */         {
/*     */ 
/*     */ 
/* 433 */           if (matchesClassAttributeValue(attrOperator, attrValue, elementBuffer.attributeBuffers[i], elementBuffer.attributeValueContentOffsets[i], elementBuffer.attributeValueContentLens[i]))
/*     */           {
/*     */ 
/* 436 */             return true;
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 441 */         else if (matchesAttributeValue(attrOperator, attrValue, elementBuffer.attributeBuffers[i], elementBuffer.attributeValueContentOffsets[i], elementBuffer.attributeValueContentLens[i]))
/*     */         {
/*     */ 
/* 444 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 452 */     if (found)
/*     */     {
/* 454 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 458 */     return MarkupSelectorItem.AttributeCondition.Operator.NOT_EXISTS.equals(attrOperator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean matchesAttributeValue(MarkupSelectorItem.AttributeCondition.Operator attrOperator, String attrValue, char[] elementAttrValueBuffer, int elementAttrValueOffset, int elementAttrValueLen)
/*     */   {
/* 470 */     switch (attrOperator)
/*     */     {
/*     */ 
/*     */     case EQUALS: 
/* 474 */       return TextUtil.equals(true, attrValue, 0, attrValue
/* 475 */         .length(), elementAttrValueBuffer, elementAttrValueOffset, elementAttrValueLen);
/*     */     
/*     */ 
/*     */ 
/*     */     case NOT_EQUALS: 
/* 480 */       return !TextUtil.equals(true, attrValue, 0, attrValue
/* 481 */         .length(), elementAttrValueBuffer, elementAttrValueOffset, elementAttrValueLen);
/*     */     
/*     */ 
/*     */     case STARTS_WITH: 
/* 485 */       return TextUtil.startsWith(true, elementAttrValueBuffer, elementAttrValueOffset, elementAttrValueLen, attrValue, 0, attrValue
/*     */       
/* 487 */         .length());
/*     */     
/*     */     case ENDS_WITH: 
/* 490 */       return TextUtil.endsWith(true, elementAttrValueBuffer, elementAttrValueOffset, elementAttrValueLen, attrValue, 0, attrValue
/*     */       
/* 492 */         .length());
/*     */     
/*     */     case CONTAINS: 
/* 495 */       return TextUtil.contains(true, elementAttrValueBuffer, elementAttrValueOffset, elementAttrValueLen, attrValue, 0, attrValue
/*     */       
/* 497 */         .length());
/*     */     
/*     */ 
/*     */     case EXISTS: 
/* 501 */       return true;
/*     */     
/*     */ 
/*     */     case NOT_EXISTS: 
/* 505 */       return false;
/*     */     }
/*     */     
/* 508 */     throw new IllegalArgumentException("Unknown operator: " + attrOperator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean matchesClassAttributeValue(MarkupSelectorItem.AttributeCondition.Operator attrOperator, String attrValue, char[] elementAttrValueBuffer, int elementAttrValueOffset, int elementAttrValueLen)
/*     */   {
/* 520 */     if (elementAttrValueLen == 0) {
/* 521 */       return isEmptyOrWhitespace(attrValue);
/*     */     }
/*     */     
/* 524 */     int i = 0;
/*     */     
/* 526 */     while ((i < elementAttrValueLen) && (Character.isWhitespace(elementAttrValueBuffer[(elementAttrValueOffset + i)]))) { i++;
/*     */     }
/* 528 */     if (i == elementAttrValueLen) {
/* 529 */       return isEmptyOrWhitespace(attrValue);
/*     */     }
/* 532 */     for (; 
/* 532 */         i < elementAttrValueLen; 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 542 */         goto 108)
/*     */     {
/* 534 */       int lastOffset = elementAttrValueOffset + i;
/*     */       
/* 536 */       while ((i < elementAttrValueLen) && (!Character.isWhitespace(elementAttrValueBuffer[(elementAttrValueOffset + i)]))) { i++;
/*     */       }
/* 538 */       if (matchesAttributeValue(attrOperator, attrValue, elementAttrValueBuffer, lastOffset, elementAttrValueOffset + i - lastOffset)) {
/* 539 */         return true;
/*     */       }
/*     */       
/* 542 */       if ((i < elementAttrValueLen) && (Character.isWhitespace(elementAttrValueBuffer[(elementAttrValueOffset + i)]))) { i++;
/*     */       }
/*     */     }
/*     */     
/* 546 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean matchesIndex(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter, IndexCondition indexCondition)
/*     */   {
/* 559 */     if (markupBlockMatchingCounter.counters == null) {
/* 560 */       markupBlockMatchingCounter.indexes = new int[4];
/* 561 */       markupBlockMatchingCounter.counters = new int[4];
/* 562 */       Arrays.fill(markupBlockMatchingCounter.indexes, -1);
/* 563 */       Arrays.fill(markupBlockMatchingCounter.counters, -1);
/*     */     }
/*     */     
/*     */ 
/* 567 */     int i = 0;
/* 568 */     while ((i < markupBlockMatchingCounter.indexes.length) && (markupBlockMatchingCounter.indexes[i] >= 0) && (markupBlockMatchingCounter.indexes[i] != markupBlockIndex))
/*     */     {
/* 570 */       i++;
/*     */     }
/*     */     
/* 573 */     if (i == markupBlockMatchingCounter.indexes.length) {
/* 574 */       int[] newMarkupBlockMatchingIndexes = new int[markupBlockMatchingCounter.indexes.length + 4];
/* 575 */       int[] newMarkupBlockMatchingCounters = new int[markupBlockMatchingCounter.counters.length + 4];
/* 576 */       Arrays.fill(newMarkupBlockMatchingIndexes, -1);
/* 577 */       Arrays.fill(newMarkupBlockMatchingCounters, -1);
/* 578 */       System.arraycopy(markupBlockMatchingCounter.indexes, 0, newMarkupBlockMatchingIndexes, 0, markupBlockMatchingCounter.indexes.length);
/* 579 */       System.arraycopy(markupBlockMatchingCounter.counters, 0, newMarkupBlockMatchingCounters, 0, markupBlockMatchingCounter.counters.length);
/* 580 */       markupBlockMatchingCounter.indexes = newMarkupBlockMatchingIndexes;
/* 581 */       markupBlockMatchingCounter.counters = newMarkupBlockMatchingCounters;
/*     */     }
/*     */     
/*     */ 
/* 585 */     if (markupBlockMatchingCounter.indexes[i] == -1) {
/* 586 */       markupBlockMatchingCounter.indexes[i] = markupBlockIndex;
/* 587 */       markupBlockMatchingCounter.counters[i] = 0;
/*     */     } else {
/* 589 */       markupBlockMatchingCounter.counters[i] += 1;
/*     */     }
/*     */     
/* 592 */     switch (indexCondition.type) {
/*     */     case VALUE: 
/* 594 */       if (indexCondition.value != markupBlockMatchingCounter.counters[i]) {
/* 595 */         return false;
/*     */       }
/*     */       break;
/*     */     case LESS_THAN: 
/* 599 */       if (indexCondition.value <= markupBlockMatchingCounter.counters[i]) {
/* 600 */         return false;
/*     */       }
/*     */       break;
/*     */     case MORE_THAN: 
/* 604 */       if (indexCondition.value >= markupBlockMatchingCounter.counters[i]) {
/* 605 */         return false;
/*     */       }
/*     */       break;
/*     */     case EVEN: 
/* 609 */       if (markupBlockMatchingCounter.counters[i] % 2 != 0) {
/* 610 */         return false;
/*     */       }
/*     */       break;
/*     */     case ODD: 
/* 614 */       if (markupBlockMatchingCounter.counters[i] % 2 == 0) {
/* 615 */         return false;
/*     */       }
/*     */       break;
/*     */     }
/*     */     
/* 620 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isEmptyOrWhitespace(String target)
/*     */   {
/* 628 */     if (target == null) {
/* 629 */       return true;
/*     */     }
/* 631 */     int targetLen = target.length();
/* 632 */     if (targetLen == 0) {
/* 633 */       return true;
/*     */     }
/* 635 */     char c0 = target.charAt(0);
/* 636 */     if (((c0 >= 'a') && (c0 <= 'z')) || ((c0 >= 'A') && (c0 <= 'Z')))
/*     */     {
/* 638 */       return false;
/*     */     }
/* 640 */     for (int i = 0; i < targetLen; i++) {
/* 641 */       char c = target.charAt(i);
/* 642 */       if ((c != ' ') && (!Character.isWhitespace(c))) {
/* 643 */         return false;
/*     */       }
/*     */     }
/* 646 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\select\MarkupSelectorItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */