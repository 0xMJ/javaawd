/*     */ package org.attoparser.select;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MarkupSelectorFilter
/*     */ {
/*     */   private final MarkupSelectorFilter prev;
/*     */   private MarkupSelectorFilter next;
/*     */   private final IMarkupSelectorItem markupSelectorItem;
/*     */   private static final int MATCHED_MARKUP_LEVELS_LEN = 10;
/*     */   private boolean[] matchedMarkupLevels;
/*     */   private boolean matchesThisLevel;
/*  43 */   private final MarkupBlockMatchingCounter markupBlockMatchingCounter = new MarkupBlockMatchingCounter();
/*     */   
/*     */   static final class MarkupBlockMatchingCounter { static final int DEFAULT_COUNTER_SIZE = 4;
/*  46 */     int[] indexes = null;
/*  47 */     int[] counters = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   MarkupSelectorFilter(MarkupSelectorFilter prev, IMarkupSelectorItem markupSelectorItem)
/*     */   {
/*  56 */     this.prev = prev;
/*  57 */     if (this.prev != null) {
/*  58 */       this.prev.next = this;
/*     */     }
/*     */     
/*  61 */     this.matchedMarkupLevels = new boolean[10];
/*  62 */     Arrays.fill(this.matchedMarkupLevels, false);
/*     */     
/*  64 */     this.markupSelectorItem = markupSelectorItem;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean matchXmlDeclaration(boolean blockMatching, int markupLevel, int markupBlockIndex)
/*     */   {
/*  82 */     checkMarkupLevel(markupLevel);
/*     */     
/*  84 */     if ((this.markupSelectorItem.anyLevel()) || (markupLevel == 0) || ((this.prev != null) && (this.prev.matchedMarkupLevels[(markupLevel - 1)] != 0)))
/*     */     {
/*     */ 
/*  87 */       this.matchesThisLevel = this.markupSelectorItem.matchesXmlDeclaration(markupBlockIndex, this.markupBlockMatchingCounter);
/*     */       
/*  89 */       if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */       {
/*     */ 
/*  92 */         if (this.next != null) {
/*  93 */           return this.next.matchXmlDeclaration(blockMatching, markupLevel, markupBlockIndex);
/*     */         }
/*  95 */         return blockMatching ? true : this.matchesThisLevel;
/*     */       }
/*  97 */       if (this.matchesThisLevel)
/*     */       {
/*     */ 
/*     */ 
/* 101 */         return this.next == null;
/*     */       }
/*     */       
/*     */     }
/* 105 */     else if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */     {
/*     */ 
/* 108 */       if (this.next != null) {
/* 109 */         return this.next.matchXmlDeclaration(blockMatching, markupLevel, markupBlockIndex);
/*     */       }
/* 111 */       return blockMatching;
/*     */     }
/*     */     
/*     */ 
/* 115 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean matchDocTypeClause(boolean blockMatching, int markupLevel, int markupBlockIndex)
/*     */   {
/* 133 */     checkMarkupLevel(markupLevel);
/*     */     
/* 135 */     if ((this.markupSelectorItem.anyLevel()) || (markupLevel == 0) || ((this.prev != null) && (this.prev.matchedMarkupLevels[(markupLevel - 1)] != 0)))
/*     */     {
/*     */ 
/* 138 */       this.matchesThisLevel = this.markupSelectorItem.matchesDocTypeClause(markupBlockIndex, this.markupBlockMatchingCounter);
/*     */       
/* 140 */       if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */       {
/*     */ 
/* 143 */         if (this.next != null) {
/* 144 */           return this.next.matchDocTypeClause(blockMatching, markupLevel, markupBlockIndex);
/*     */         }
/* 146 */         return blockMatching ? true : this.matchesThisLevel;
/*     */       }
/* 148 */       if (this.matchesThisLevel)
/*     */       {
/*     */ 
/*     */ 
/* 152 */         return this.next == null;
/*     */       }
/*     */       
/*     */     }
/* 156 */     else if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */     {
/*     */ 
/* 159 */       if (this.next != null) {
/* 160 */         return this.next.matchDocTypeClause(blockMatching, markupLevel, markupBlockIndex);
/*     */       }
/* 162 */       return blockMatching;
/*     */     }
/*     */     
/*     */ 
/* 166 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean matchCDATASection(boolean blockMatching, int markupLevel, int markupBlockIndex)
/*     */   {
/* 184 */     checkMarkupLevel(markupLevel);
/*     */     
/* 186 */     if ((this.markupSelectorItem.anyLevel()) || (markupLevel == 0) || ((this.prev != null) && (this.prev.matchedMarkupLevels[(markupLevel - 1)] != 0)))
/*     */     {
/*     */ 
/* 189 */       this.matchesThisLevel = this.markupSelectorItem.matchesCDATASection(markupBlockIndex, this.markupBlockMatchingCounter);
/*     */       
/* 191 */       if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */       {
/*     */ 
/* 194 */         if (this.next != null) {
/* 195 */           return this.next.matchCDATASection(blockMatching, markupLevel, markupBlockIndex);
/*     */         }
/* 197 */         return blockMatching ? true : this.matchesThisLevel;
/*     */       }
/* 199 */       if (this.matchesThisLevel)
/*     */       {
/*     */ 
/*     */ 
/* 203 */         return this.next == null;
/*     */       }
/*     */       
/*     */     }
/* 207 */     else if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */     {
/*     */ 
/* 210 */       if (this.next != null) {
/* 211 */         return this.next.matchCDATASection(blockMatching, markupLevel, markupBlockIndex);
/*     */       }
/* 213 */       return blockMatching;
/*     */     }
/*     */     
/*     */ 
/* 217 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean matchText(boolean blockMatching, int markupLevel, int markupBlockIndex)
/*     */   {
/* 235 */     checkMarkupLevel(markupLevel);
/*     */     
/* 237 */     if ((this.markupSelectorItem.anyLevel()) || (markupLevel == 0) || ((this.prev != null) && (this.prev.matchedMarkupLevels[(markupLevel - 1)] != 0)))
/*     */     {
/*     */ 
/* 240 */       this.matchesThisLevel = this.markupSelectorItem.matchesText(markupBlockIndex, this.markupBlockMatchingCounter);
/*     */       
/* 242 */       if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */       {
/*     */ 
/* 245 */         if (this.next != null) {
/* 246 */           return this.next.matchText(blockMatching, markupLevel, markupBlockIndex);
/*     */         }
/* 248 */         return blockMatching ? true : this.matchesThisLevel;
/*     */       }
/* 250 */       if (this.matchesThisLevel)
/*     */       {
/*     */ 
/*     */ 
/* 254 */         return this.next == null;
/*     */       }
/*     */       
/*     */     }
/* 258 */     else if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */     {
/*     */ 
/* 261 */       if (this.next != null) {
/* 262 */         return this.next.matchText(blockMatching, markupLevel, markupBlockIndex);
/*     */       }
/* 264 */       return blockMatching;
/*     */     }
/*     */     
/*     */ 
/* 268 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean matchComment(boolean blockMatching, int markupLevel, int markupBlockIndex)
/*     */   {
/* 286 */     checkMarkupLevel(markupLevel);
/*     */     
/* 288 */     if ((this.markupSelectorItem.anyLevel()) || (markupLevel == 0) || ((this.prev != null) && (this.prev.matchedMarkupLevels[(markupLevel - 1)] != 0)))
/*     */     {
/*     */ 
/* 291 */       this.matchesThisLevel = this.markupSelectorItem.matchesComment(markupBlockIndex, this.markupBlockMatchingCounter);
/*     */       
/* 293 */       if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */       {
/*     */ 
/* 296 */         if (this.next != null) {
/* 297 */           return this.next.matchComment(blockMatching, markupLevel, markupBlockIndex);
/*     */         }
/* 299 */         return blockMatching ? true : this.matchesThisLevel;
/*     */       }
/* 301 */       if (this.matchesThisLevel)
/*     */       {
/*     */ 
/*     */ 
/* 305 */         return this.next == null;
/*     */       }
/*     */       
/*     */     }
/* 309 */     else if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */     {
/*     */ 
/* 312 */       if (this.next != null) {
/* 313 */         return this.next.matchComment(blockMatching, markupLevel, markupBlockIndex);
/*     */       }
/* 315 */       return blockMatching;
/*     */     }
/*     */     
/*     */ 
/* 319 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int markupLevelCheckerIndex;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean matchStandaloneElement(boolean blockMatching, int markupLevel, int markupBlockIndex, SelectorElementBuffer elementBuffer)
/*     */   {
/* 339 */     checkMarkupLevel(markupLevel);
/*     */     
/* 341 */     if ((this.markupSelectorItem.anyLevel()) || (markupLevel == 0) || ((this.prev != null) && (this.prev.matchedMarkupLevels[(markupLevel - 1)] != 0)))
/*     */     {
/*     */ 
/* 344 */       this.matchesThisLevel = this.markupSelectorItem.matchesElement(markupBlockIndex, elementBuffer, this.markupBlockMatchingCounter);
/*     */       
/* 346 */       if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */       {
/*     */ 
/* 349 */         if (this.next != null) {
/* 350 */           return this.next.matchStandaloneElement(blockMatching, markupLevel, markupBlockIndex, elementBuffer);
/*     */         }
/* 352 */         return blockMatching ? true : this.matchesThisLevel;
/*     */       }
/* 354 */       if (this.matchesThisLevel)
/*     */       {
/*     */ 
/*     */ 
/* 358 */         return this.next == null;
/*     */       }
/*     */       
/*     */     }
/* 362 */     else if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */     {
/*     */ 
/* 365 */       if (this.next != null) {
/* 366 */         return this.next.matchStandaloneElement(blockMatching, markupLevel, markupBlockIndex, elementBuffer);
/*     */       }
/* 368 */       return blockMatching;
/*     */     }
/*     */     
/*     */ 
/* 372 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean matchOpenElement(boolean blockMatching, int markupLevel, int markupBlockIndex, SelectorElementBuffer elementBuffer)
/*     */   {
/* 382 */     checkMarkupLevel(markupLevel);
/*     */     
/* 384 */     if ((this.markupSelectorItem.anyLevel()) || (markupLevel == 0) || ((this.prev != null) && (this.prev.matchedMarkupLevels[(markupLevel - 1)] != 0)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 390 */       this.matchesThisLevel = this.markupSelectorItem.matchesElement(markupBlockIndex, elementBuffer, this.markupBlockMatchingCounter);
/*     */       
/* 392 */       if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 399 */         this.matchedMarkupLevels[markupLevel] = this.matchesThisLevel;
/*     */         
/* 401 */         if (this.next != null) {
/* 402 */           return this.next.matchOpenElement(blockMatching, markupLevel, markupBlockIndex, elementBuffer);
/*     */         }
/* 404 */         return blockMatching ? true : this.matchesThisLevel;
/*     */       }
/* 406 */       if (this.matchesThisLevel)
/*     */       {
/*     */ 
/*     */ 
/* 410 */         this.matchedMarkupLevels[markupLevel] = true;
/* 411 */         return this.next == null;
/*     */       }
/*     */       
/*     */     }
/* 415 */     else if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */     {
/*     */ 
/* 418 */       if (this.next != null) {
/* 419 */         return this.next.matchOpenElement(blockMatching, markupLevel, markupBlockIndex, elementBuffer);
/*     */       }
/* 421 */       return blockMatching;
/*     */     }
/*     */     
/*     */ 
/* 425 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean matchProcessingInstruction(boolean blockMatching, int markupLevel, int markupBlockIndex)
/*     */   {
/* 442 */     checkMarkupLevel(markupLevel);
/*     */     
/* 444 */     if ((this.markupSelectorItem.anyLevel()) || (markupLevel == 0) || ((this.prev != null) && (this.prev.matchedMarkupLevels[(markupLevel - 1)] != 0)))
/*     */     {
/*     */ 
/* 447 */       this.matchesThisLevel = this.markupSelectorItem.matchesProcessingInstruction(markupBlockIndex, this.markupBlockMatchingCounter);
/*     */       
/* 449 */       if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */       {
/*     */ 
/* 452 */         if (this.next != null) {
/* 453 */           return this.next.matchProcessingInstruction(blockMatching, markupLevel, markupBlockIndex);
/*     */         }
/* 455 */         return blockMatching ? true : this.matchesThisLevel;
/*     */       }
/* 457 */       if (this.matchesThisLevel)
/*     */       {
/*     */ 
/*     */ 
/* 461 */         return this.next == null;
/*     */       }
/*     */       
/*     */     }
/* 465 */     else if (matchesPreviousOrCurrentLevel(markupLevel))
/*     */     {
/*     */ 
/* 468 */       if (this.next != null) {
/* 469 */         return this.next.matchProcessingInstruction(blockMatching, markupLevel, markupBlockIndex);
/*     */       }
/* 471 */       return blockMatching;
/*     */     }
/*     */     
/*     */ 
/* 475 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkMarkupLevel(int markupLevel)
/*     */   {
/* 489 */     if (markupLevel >= this.matchedMarkupLevels.length) {
/* 490 */       int newLen = Math.max(markupLevel + 1, this.matchedMarkupLevels.length + 10);
/* 491 */       boolean[] newMatchedMarkupLevels = new boolean[newLen];
/* 492 */       Arrays.fill(newMatchedMarkupLevels, false);
/* 493 */       System.arraycopy(this.matchedMarkupLevels, 0, newMatchedMarkupLevels, 0, this.matchedMarkupLevels.length);
/* 494 */       this.matchedMarkupLevels = newMatchedMarkupLevels;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void removeMatchesForLevel(int markupLevel)
/*     */   {
/* 502 */     if (this.matchedMarkupLevels.length > markupLevel) {
/* 503 */       this.matchedMarkupLevels[markupLevel] = false;
/*     */     }
/*     */     
/* 506 */     if (this.next == null) {
/* 507 */       return;
/*     */     }
/*     */     
/* 510 */     this.next.removeMatchesForLevel(markupLevel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean matchesPreviousOrCurrentLevel(int markupLevel)
/*     */   {
/* 517 */     this.markupLevelCheckerIndex = markupLevel;
/* 518 */     while ((this.markupLevelCheckerIndex >= 0) && (this.matchedMarkupLevels[this.markupLevelCheckerIndex] == 0)) this.markupLevelCheckerIndex -= 1;
/* 519 */     return this.markupLevelCheckerIndex >= 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\select\MarkupSelectorFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */