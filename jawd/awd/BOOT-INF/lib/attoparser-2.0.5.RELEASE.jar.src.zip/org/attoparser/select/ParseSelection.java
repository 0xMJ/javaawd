/*     */ package org.attoparser.select;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParseSelection
/*     */ {
/*  46 */   private int levelCounter = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ParseSelectionLevel[] levels;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int subscribeLevel()
/*     */   {
/*  63 */     ParseSelectionLevel[] newLevels = new ParseSelectionLevel[this.levelCounter + 1];
/*  64 */     if (this.levels != null) {
/*  65 */       System.arraycopy(this.levels, 0, newLevels, 0, this.levelCounter);
/*     */     }
/*  67 */     this.levels = newLevels;
/*  68 */     this.levels[this.levelCounter] = new ParseSelectionLevel(null);
/*  69 */     return this.levelCounter++;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSelectionLevels()
/*     */   {
/*  84 */     return this.levelCounter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getSelectors(int level)
/*     */   {
/*  99 */     if (level >= this.levelCounter) {
/* 100 */       throw new IllegalArgumentException("Cannot return current selection: max level is " + this.levelCounter + " (specified: " + level + ")");
/*     */     }
/*     */     
/* 103 */     if (this.levels == null) {
/* 104 */       return null;
/*     */     }
/* 106 */     return this.levels[level].selectors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getCurrentSelection(int level)
/*     */   {
/* 125 */     if (level >= this.levelCounter) {
/* 126 */       throw new IllegalArgumentException("Cannot return current selection: max level is " + this.levelCounter + " (specified: " + level + ")");
/*     */     }
/*     */     
/* 129 */     if (this.levels == null) {
/* 130 */       return null;
/*     */     }
/* 132 */     return this.levels[level].getCurrentSelection();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMatchingAny(int level)
/*     */   {
/* 145 */     if (level >= this.levelCounter) {
/* 146 */       throw new IllegalArgumentException("Cannot return current selection: max level is " + this.levelCounter + " (specified: " + level + ")");
/*     */     }
/*     */     
/* 149 */     if (this.levels == null) {
/* 150 */       return false;
/*     */     }
/* 152 */     return this.levels[level].isSelectionActive();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMatchingAny()
/*     */   {
/* 164 */     if (this.levels == null) {
/* 165 */       return false;
/*     */     }
/* 167 */     int i = 0;
/* 168 */     int n = this.levelCounter;
/* 169 */     while (n-- != 0) {
/* 170 */       if (this.levels[i].isSelectionActive()) {
/* 171 */         return true;
/*     */       }
/* 173 */       i++;
/*     */     }
/* 175 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 181 */     if (this.levels.length == 0) {
/* 182 */       return "";
/*     */     }
/* 184 */     StringBuilder strBuilder = new StringBuilder(40);
/* 185 */     strBuilder.append(this.levels[0]);
/* 186 */     if (this.levels.length > 1) {
/* 187 */       for (int i = 1; i < this.levels.length; i++) {
/* 188 */         strBuilder.append(" -> ");
/* 189 */         strBuilder.append(this.levels[i]);
/*     */       }
/*     */     }
/* 192 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static final class ParseSelectionLevel
/*     */   {
/*     */     String[] selectors;
/*     */     
/*     */ 
/*     */     boolean[] selection;
/*     */     
/*     */ 
/*     */ 
/*     */     String[] getCurrentSelection()
/*     */     {
/* 208 */       if (this.selection == null) {
/* 209 */         return null;
/*     */       }
/*     */       
/* 212 */       int size = 0;
/* 213 */       int i = 0;
/* 214 */       int n = this.selectors.length;
/* 215 */       while (n-- != 0) {
/* 216 */         if (this.selection[i] != 0) {
/* 217 */           size++;
/*     */         }
/* 219 */         i++;
/*     */       }
/*     */       
/* 222 */       if (size == this.selectors.length)
/*     */       {
/* 224 */         return this.selectors;
/*     */       }
/*     */       
/* 227 */       String[] currentSelection = new String[size];
/* 228 */       int j = 0;
/* 229 */       i = 0;
/* 230 */       n = this.selectors.length;
/* 231 */       while (n-- != 0) {
/* 232 */         if (this.selection[i] != 0) {
/* 233 */           currentSelection[(j++)] = this.selectors[i];
/*     */         }
/* 235 */         i++;
/*     */       }
/*     */       
/* 238 */       return currentSelection;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean isSelectionActive()
/*     */     {
/* 244 */       if (this.selection == null) {
/* 245 */         return false;
/*     */       }
/* 247 */       int i = 0;
/* 248 */       int n = this.selectors.length;
/* 249 */       while (n-- != 0) {
/* 250 */         if (this.selection[i] != 0) {
/* 251 */           return true;
/*     */         }
/* 253 */         i++;
/*     */       }
/* 255 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 262 */       StringBuilder strBuilder = new StringBuilder(20);
/* 263 */       strBuilder.append('[');
/* 264 */       if (this.selection != null) {
/* 265 */         for (int i = 0; i < this.selectors.length; i++) {
/* 266 */           if (this.selection[i] != 0) {
/* 267 */             if (strBuilder.length() > 1) {
/* 268 */               strBuilder.append(',');
/*     */             }
/* 270 */             strBuilder.append(this.selectors[i]);
/*     */           }
/*     */         }
/*     */       }
/* 274 */       strBuilder.append(']');
/*     */       
/* 276 */       return strBuilder.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\select\ParseSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */