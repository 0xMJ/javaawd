package org.attoparser.select;

abstract interface IMarkupSelectorItem
{
  public abstract boolean anyLevel();
  
  public abstract boolean matchesText(int paramInt, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
  
  public abstract boolean matchesComment(int paramInt, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
  
  public abstract boolean matchesCDATASection(int paramInt, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
  
  public abstract boolean matchesDocTypeClause(int paramInt, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
  
  public abstract boolean matchesXmlDeclaration(int paramInt, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
  
  public abstract boolean matchesProcessingInstruction(int paramInt, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
  
  public abstract boolean matchesElement(int paramInt, SelectorElementBuffer paramSelectorElementBuffer, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\select\IMarkupSelectorItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */