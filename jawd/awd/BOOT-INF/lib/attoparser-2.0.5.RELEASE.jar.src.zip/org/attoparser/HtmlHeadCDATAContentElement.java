/*    */ package org.attoparser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HtmlHeadCDATAContentElement
/*    */   extends HtmlAutoOpenCDATAContentElement
/*    */ {
/* 36 */   private static final String[] ARRAY_HTML_HEAD = { "html", "head" };
/*    */   
/*    */   public HtmlHeadCDATAContentElement(String name) {
/* 39 */     super(name, ARRAY_HTML_HEAD, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\HtmlHeadCDATAContentElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */