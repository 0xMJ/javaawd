/*      */ package org.attoparser.util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class TextUtil
/*      */ {
/*      */   public static boolean equals(boolean caseSensitive, CharSequence text1, CharSequence text2)
/*      */   {
/*   49 */     if (text1 == null) {
/*   50 */       throw new IllegalArgumentException("First text being compared cannot be null");
/*      */     }
/*   52 */     if (text2 == null) {
/*   53 */       throw new IllegalArgumentException("Second text being compared cannot be null");
/*      */     }
/*      */     
/*   56 */     if (text1 == text2) {
/*   57 */       return true;
/*      */     }
/*      */     
/*   60 */     if (((text1 instanceof String)) && ((text2 instanceof String))) {
/*   61 */       return caseSensitive ? text1.equals(text2) : ((String)text1).equalsIgnoreCase((String)text2);
/*      */     }
/*      */     
/*   64 */     return equals(caseSensitive, text1, 0, text1.length(), text2, 0, text2.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equals(boolean caseSensitive, CharSequence text1, char[] text2)
/*      */   {
/*   80 */     return equals(caseSensitive, text1, 0, text1.length(), text2, 0, text2.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equals(boolean caseSensitive, char[] text1, char[] text2)
/*      */   {
/*   95 */     if (text1 == text2) {
/*   96 */       return true;
/*      */     }
/*   98 */     return equals(caseSensitive, text1, 0, text1.length, text2, 0, text2.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equals(boolean caseSensitive, char[] text1, int text1Offset, int text1Len, char[] text2, int text2Offset, int text2Len)
/*      */   {
/*  122 */     if (text1 == null) {
/*  123 */       throw new IllegalArgumentException("First text buffer being compared cannot be null");
/*      */     }
/*  125 */     if (text2 == null) {
/*  126 */       throw new IllegalArgumentException("Second text buffer being compared cannot be null");
/*      */     }
/*      */     
/*  129 */     if (text1Len != text2Len) {
/*  130 */       return false;
/*      */     }
/*      */     
/*  133 */     if ((text1 == text2) && (text1Offset == text2Offset) && (text1Len == text2Len)) {
/*  134 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  139 */     int n = text1Len;
/*  140 */     int i = 0;
/*      */     
/*  142 */     while (n-- != 0)
/*      */     {
/*  144 */       char c1 = text1[(text1Offset + i)];
/*  145 */       char c2 = text2[(text2Offset + i)];
/*      */       
/*  147 */       if (c1 != c2)
/*      */       {
/*  149 */         if (caseSensitive) {
/*  150 */           return false;
/*      */         }
/*      */         
/*  153 */         c1 = Character.toUpperCase(c1);
/*  154 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  156 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  160 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  161 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  168 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  172 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equals(boolean caseSensitive, CharSequence text1, int text1Offset, int text1Len, char[] text2, int text2Offset, int text2Len)
/*      */   {
/*  197 */     if (text1 == null) {
/*  198 */       throw new IllegalArgumentException("First text being compared cannot be null");
/*      */     }
/*  200 */     if (text2 == null) {
/*  201 */       throw new IllegalArgumentException("Second text buffer being compared cannot be null");
/*      */     }
/*      */     
/*  204 */     if (text1Len != text2Len) {
/*  205 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  210 */     int n = text1Len;
/*  211 */     int i = 0;
/*      */     
/*  213 */     while (n-- != 0)
/*      */     {
/*  215 */       char c1 = text1.charAt(text1Offset + i);
/*  216 */       char c2 = text2[(text2Offset + i)];
/*      */       
/*  218 */       if (c1 != c2)
/*      */       {
/*  220 */         if (caseSensitive) {
/*  221 */           return false;
/*      */         }
/*      */         
/*  224 */         c1 = Character.toUpperCase(c1);
/*  225 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  227 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  231 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  232 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  239 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  243 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equals(boolean caseSensitive, CharSequence text1, int text1Offset, int text1Len, CharSequence text2, int text2Offset, int text2Len)
/*      */   {
/*  268 */     if (text1 == null) {
/*  269 */       throw new IllegalArgumentException("First text being compared cannot be null");
/*      */     }
/*  271 */     if (text2 == null) {
/*  272 */       throw new IllegalArgumentException("Second text being compared cannot be null");
/*      */     }
/*      */     
/*  275 */     if (text1Len != text2Len) {
/*  276 */       return false;
/*      */     }
/*      */     
/*  279 */     if ((text1 == text2) && (text1Offset == text2Offset) && (text1Len == text2Len)) {
/*  280 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  285 */     int n = text1Len;
/*  286 */     int i = 0;
/*      */     
/*  288 */     while (n-- != 0)
/*      */     {
/*  290 */       char c1 = text1.charAt(text1Offset + i);
/*  291 */       char c2 = text2.charAt(text2Offset + i);
/*      */       
/*  293 */       if (c1 != c2)
/*      */       {
/*  295 */         if (caseSensitive) {
/*  296 */           return false;
/*      */         }
/*      */         
/*  299 */         c1 = Character.toUpperCase(c1);
/*  300 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  302 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  306 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  307 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  314 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  318 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, CharSequence text, CharSequence prefix)
/*      */   {
/*  339 */     if (text == null) {
/*  340 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  342 */     if (prefix == null) {
/*  343 */       throw new IllegalArgumentException("Prefix cannot be null");
/*      */     }
/*      */     
/*  346 */     if (((text instanceof String)) && ((prefix instanceof String))) {
/*  347 */       return caseSensitive ? ((String)text).startsWith((String)prefix) : startsWith(caseSensitive, text, 0, text.length(), prefix, 0, prefix.length());
/*      */     }
/*      */     
/*  350 */     return startsWith(caseSensitive, text, 0, text.length(), prefix, 0, prefix.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, CharSequence text, char[] prefix)
/*      */   {
/*  366 */     return startsWith(caseSensitive, text, 0, text.length(), prefix, 0, prefix.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, char[] text, char[] prefix)
/*      */   {
/*  381 */     return startsWith(caseSensitive, text, 0, text.length, prefix, 0, prefix.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, char[] text, int textOffset, int textLen, char[] prefix, int prefixOffset, int prefixLen)
/*      */   {
/*  405 */     if (text == null) {
/*  406 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  408 */     if (prefix == null) {
/*  409 */       throw new IllegalArgumentException("Prefix cannot be null");
/*      */     }
/*      */     
/*  412 */     if (textLen < prefixLen) {
/*  413 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  418 */     int n = prefixLen;
/*  419 */     int i = 0;
/*      */     
/*  421 */     while (n-- != 0)
/*      */     {
/*  423 */       char c1 = text[(textOffset + i)];
/*  424 */       char c2 = prefix[(prefixOffset + i)];
/*      */       
/*  426 */       if (c1 != c2)
/*      */       {
/*  428 */         if (caseSensitive) {
/*  429 */           return false;
/*      */         }
/*      */         
/*  432 */         c1 = Character.toUpperCase(c1);
/*  433 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  435 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  439 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  440 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  447 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  451 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, CharSequence text, int textOffset, int textLen, char[] prefix, int prefixOffset, int prefixLen)
/*      */   {
/*  476 */     if (text == null) {
/*  477 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  479 */     if (prefix == null) {
/*  480 */       throw new IllegalArgumentException("Prefix cannot be null");
/*      */     }
/*      */     
/*  483 */     if (textLen < prefixLen) {
/*  484 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  489 */     int n = prefixLen;
/*  490 */     int i = 0;
/*      */     
/*  492 */     while (n-- != 0)
/*      */     {
/*  494 */       char c1 = text.charAt(textOffset + i);
/*  495 */       char c2 = prefix[(prefixOffset + i)];
/*      */       
/*  497 */       if (c1 != c2)
/*      */       {
/*  499 */         if (caseSensitive) {
/*  500 */           return false;
/*      */         }
/*      */         
/*  503 */         c1 = Character.toUpperCase(c1);
/*  504 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  506 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  510 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  511 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  518 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  522 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, char[] text, int textOffset, int textLen, CharSequence prefix, int prefixOffset, int prefixLen)
/*      */   {
/*  547 */     if (text == null) {
/*  548 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  550 */     if (prefix == null) {
/*  551 */       throw new IllegalArgumentException("Prefix cannot be null");
/*      */     }
/*      */     
/*  554 */     if (textLen < prefixLen) {
/*  555 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  560 */     int n = prefixLen;
/*  561 */     int i = 0;
/*      */     
/*  563 */     while (n-- != 0)
/*      */     {
/*  565 */       char c1 = text[(textOffset + i)];
/*  566 */       char c2 = prefix.charAt(prefixOffset + i);
/*      */       
/*  568 */       if (c1 != c2)
/*      */       {
/*  570 */         if (caseSensitive) {
/*  571 */           return false;
/*      */         }
/*      */         
/*  574 */         c1 = Character.toUpperCase(c1);
/*  575 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  577 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  581 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  582 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  589 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  593 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, CharSequence text, int textOffset, int textLen, CharSequence prefix, int prefixOffset, int prefixLen)
/*      */   {
/*  618 */     if (text == null) {
/*  619 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  621 */     if (prefix == null) {
/*  622 */       throw new IllegalArgumentException("Prefix cannot be null");
/*      */     }
/*      */     
/*  625 */     if (textLen < prefixLen) {
/*  626 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  631 */     int n = prefixLen;
/*  632 */     int i = 0;
/*      */     
/*  634 */     while (n-- != 0)
/*      */     {
/*  636 */       char c1 = text.charAt(textOffset + i);
/*  637 */       char c2 = prefix.charAt(prefixOffset + i);
/*      */       
/*  639 */       if (c1 != c2)
/*      */       {
/*  641 */         if (caseSensitive) {
/*  642 */           return false;
/*      */         }
/*      */         
/*  645 */         c1 = Character.toUpperCase(c1);
/*  646 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  648 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  652 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  653 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  660 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  664 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, CharSequence text, CharSequence suffix)
/*      */   {
/*  685 */     if (text == null) {
/*  686 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  688 */     if (suffix == null) {
/*  689 */       throw new IllegalArgumentException("Suffix cannot be null");
/*      */     }
/*      */     
/*  692 */     if (((text instanceof String)) && ((suffix instanceof String))) {
/*  693 */       return caseSensitive ? ((String)text).endsWith((String)suffix) : endsWith(caseSensitive, text, 0, text.length(), suffix, 0, suffix.length());
/*      */     }
/*      */     
/*  696 */     return endsWith(caseSensitive, text, 0, text.length(), suffix, 0, suffix.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, CharSequence text, char[] suffix)
/*      */   {
/*  712 */     return endsWith(caseSensitive, text, 0, text.length(), suffix, 0, suffix.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, char[] text, char[] suffix)
/*      */   {
/*  727 */     return endsWith(caseSensitive, text, 0, text.length, suffix, 0, suffix.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, char[] text, int textOffset, int textLen, char[] suffix, int suffixOffset, int suffixLen)
/*      */   {
/*  751 */     if (text == null) {
/*  752 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  754 */     if (suffix == null) {
/*  755 */       throw new IllegalArgumentException("Suffix cannot be null");
/*      */     }
/*      */     
/*  758 */     if (textLen < suffixLen) {
/*  759 */       return false;
/*      */     }
/*      */     
/*  762 */     int textReverseOffset = textOffset + textLen - 1;
/*  763 */     int suffixReverseOffset = suffixOffset + suffixLen - 1;
/*      */     
/*      */ 
/*      */ 
/*  767 */     int n = suffixLen;
/*  768 */     int i = 0;
/*      */     
/*  770 */     while (n-- != 0)
/*      */     {
/*  772 */       char c1 = text[(textReverseOffset - i)];
/*  773 */       char c2 = suffix[(suffixReverseOffset - i)];
/*      */       
/*  775 */       if (c1 != c2)
/*      */       {
/*  777 */         if (caseSensitive) {
/*  778 */           return false;
/*      */         }
/*      */         
/*  781 */         c1 = Character.toUpperCase(c1);
/*  782 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  784 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  788 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  789 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  796 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  800 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, CharSequence text, int textOffset, int textLen, char[] suffix, int suffixOffset, int suffixLen)
/*      */   {
/*  825 */     if (text == null) {
/*  826 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  828 */     if (suffix == null) {
/*  829 */       throw new IllegalArgumentException("Suffix cannot be null");
/*      */     }
/*      */     
/*  832 */     if (textLen < suffixLen) {
/*  833 */       return false;
/*      */     }
/*      */     
/*  836 */     int textReverseOffset = textOffset + textLen - 1;
/*  837 */     int suffixReverseOffset = suffixOffset + suffixLen - 1;
/*      */     
/*      */ 
/*      */ 
/*  841 */     int n = suffixLen;
/*  842 */     int i = 0;
/*      */     
/*  844 */     while (n-- != 0)
/*      */     {
/*  846 */       char c1 = text.charAt(textReverseOffset - i);
/*  847 */       char c2 = suffix[(suffixReverseOffset - i)];
/*      */       
/*  849 */       if (c1 != c2)
/*      */       {
/*  851 */         if (caseSensitive) {
/*  852 */           return false;
/*      */         }
/*      */         
/*  855 */         c1 = Character.toUpperCase(c1);
/*  856 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  858 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  862 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  863 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  870 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  874 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, char[] text, int textOffset, int textLen, CharSequence suffix, int suffixOffset, int suffixLen)
/*      */   {
/*  899 */     if (text == null) {
/*  900 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  902 */     if (suffix == null) {
/*  903 */       throw new IllegalArgumentException("Suffix cannot be null");
/*      */     }
/*      */     
/*  906 */     if (textLen < suffixLen) {
/*  907 */       return false;
/*      */     }
/*      */     
/*  910 */     int textReverseOffset = textOffset + textLen - 1;
/*  911 */     int suffixReverseOffset = suffixOffset + suffixLen - 1;
/*      */     
/*      */ 
/*      */ 
/*  915 */     int n = suffixLen;
/*  916 */     int i = 0;
/*      */     
/*  918 */     while (n-- != 0)
/*      */     {
/*  920 */       char c1 = text[(textReverseOffset - i)];
/*  921 */       char c2 = suffix.charAt(suffixReverseOffset - i);
/*      */       
/*  923 */       if (c1 != c2)
/*      */       {
/*  925 */         if (caseSensitive) {
/*  926 */           return false;
/*      */         }
/*      */         
/*  929 */         c1 = Character.toUpperCase(c1);
/*  930 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  932 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  936 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  937 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  944 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  948 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, CharSequence text, int textOffset, int textLen, CharSequence suffix, int suffixOffset, int suffixLen)
/*      */   {
/*  973 */     if (text == null) {
/*  974 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  976 */     if (suffix == null) {
/*  977 */       throw new IllegalArgumentException("Suffix cannot be null");
/*      */     }
/*      */     
/*  980 */     if (textLen < suffixLen) {
/*  981 */       return false;
/*      */     }
/*      */     
/*  984 */     int textReverseOffset = textOffset + textLen - 1;
/*  985 */     int suffixReverseOffset = suffixOffset + suffixLen - 1;
/*      */     
/*      */ 
/*      */ 
/*  989 */     int n = suffixLen;
/*  990 */     int i = 0;
/*      */     
/*  992 */     while (n-- != 0)
/*      */     {
/*  994 */       char c1 = text.charAt(textReverseOffset - i);
/*  995 */       char c2 = suffix.charAt(suffixReverseOffset - i);
/*      */       
/*  997 */       if (c1 != c2)
/*      */       {
/*  999 */         if (caseSensitive) {
/* 1000 */           return false;
/*      */         }
/*      */         
/* 1003 */         c1 = Character.toUpperCase(c1);
/* 1004 */         c2 = Character.toUpperCase(c2);
/*      */         
/* 1006 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/* 1010 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/* 1011 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1018 */       i++;
/*      */     }
/*      */     
/*      */ 
/* 1022 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, CharSequence text, CharSequence fragment)
/*      */   {
/* 1043 */     if (text == null) {
/* 1044 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/* 1046 */     if (fragment == null) {
/* 1047 */       throw new IllegalArgumentException("Fragment cannot be null");
/*      */     }
/*      */     
/* 1050 */     if (((text instanceof String)) && ((fragment instanceof String)))
/*      */     {
/*      */ 
/*      */ 
/* 1054 */       return caseSensitive ? ((String)text).contains(fragment) : contains(caseSensitive, text, 0, text.length(), fragment, 0, fragment.length());
/*      */     }
/*      */     
/* 1057 */     return contains(caseSensitive, text, 0, text.length(), fragment, 0, fragment.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, CharSequence text, char[] fragment)
/*      */   {
/* 1073 */     return contains(caseSensitive, text, 0, text.length(), fragment, 0, fragment.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, char[] text, char[] fragment)
/*      */   {
/* 1088 */     return contains(caseSensitive, text, 0, text.length, fragment, 0, fragment.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, char[] text, int textOffset, int textLen, char[] fragment, int fragmentOffset, int fragmentLen)
/*      */   {
/* 1112 */     if (text == null) {
/* 1113 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/* 1115 */     if (fragment == null) {
/* 1116 */       throw new IllegalArgumentException("Fragment cannot be null");
/*      */     }
/*      */     
/* 1119 */     if (textLen < fragmentLen) {
/* 1120 */       return false;
/*      */     }
/* 1122 */     if (fragmentLen == 0) {
/* 1123 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1128 */     int i = 0; for (int j = 0; i < textLen; i++)
/*      */     {
/* 1130 */       char c1 = text[(textOffset + i)];
/* 1131 */       char c2 = fragment[(fragmentOffset + j)];
/*      */       
/* 1133 */       if (c1 == c2) {
/* 1134 */         j++; if (j == fragmentLen) {
/* 1135 */           return true;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1140 */         if (!caseSensitive)
/*      */         {
/* 1142 */           c1 = Character.toUpperCase(c1);
/* 1143 */           c2 = Character.toUpperCase(c2);
/* 1144 */           if (c1 == c2) {
/* 1145 */             j++; if (j != fragmentLen) continue;
/* 1146 */             return true;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1153 */           if (Character.toLowerCase(c1) == Character.toLowerCase(c2)) {
/* 1154 */             j++; if (j != fragmentLen) continue;
/* 1155 */             return true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1162 */         if (j > 0)
/*      */         {
/* 1164 */           i -= j;
/*      */         }
/*      */         
/* 1167 */         j = 0;
/*      */       }
/*      */     }
/*      */     
/* 1171 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, CharSequence text, int textOffset, int textLen, char[] fragment, int fragmentOffset, int fragmentLen)
/*      */   {
/* 1196 */     if (text == null) {
/* 1197 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/* 1199 */     if (fragment == null) {
/* 1200 */       throw new IllegalArgumentException("Fragment cannot be null");
/*      */     }
/*      */     
/* 1203 */     if (textLen < fragmentLen) {
/* 1204 */       return false;
/*      */     }
/* 1206 */     if (fragmentLen == 0) {
/* 1207 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1212 */     int i = 0; for (int j = 0; i < textLen; i++)
/*      */     {
/* 1214 */       char c1 = text.charAt(textOffset + i);
/* 1215 */       char c2 = fragment[(fragmentOffset + j)];
/*      */       
/* 1217 */       if (c1 == c2) {
/* 1218 */         j++; if (j == fragmentLen) {
/* 1219 */           return true;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1224 */         if (!caseSensitive)
/*      */         {
/* 1226 */           c1 = Character.toUpperCase(c1);
/* 1227 */           c2 = Character.toUpperCase(c2);
/* 1228 */           if (c1 == c2) {
/* 1229 */             j++; if (j != fragmentLen) continue;
/* 1230 */             return true;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1237 */           if (Character.toLowerCase(c1) == Character.toLowerCase(c2)) {
/* 1238 */             j++; if (j != fragmentLen) continue;
/* 1239 */             return true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1246 */         if (j > 0)
/*      */         {
/* 1248 */           i -= j;
/*      */         }
/*      */         
/* 1251 */         j = 0;
/*      */       }
/*      */     }
/*      */     
/* 1255 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, char[] text, int textOffset, int textLen, CharSequence fragment, int fragmentOffset, int fragmentLen)
/*      */   {
/* 1280 */     if (text == null) {
/* 1281 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/* 1283 */     if (fragment == null) {
/* 1284 */       throw new IllegalArgumentException("Fragment cannot be null");
/*      */     }
/*      */     
/* 1287 */     if (textLen < fragmentLen) {
/* 1288 */       return false;
/*      */     }
/* 1290 */     if (fragmentLen == 0) {
/* 1291 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1296 */     int i = 0; for (int j = 0; i < textLen; i++)
/*      */     {
/* 1298 */       char c1 = text[(textOffset + i)];
/* 1299 */       char c2 = fragment.charAt(fragmentOffset + j);
/*      */       
/* 1301 */       if (c1 == c2) {
/* 1302 */         j++; if (j == fragmentLen) {
/* 1303 */           return true;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1308 */         if (!caseSensitive)
/*      */         {
/* 1310 */           c1 = Character.toUpperCase(c1);
/* 1311 */           c2 = Character.toUpperCase(c2);
/* 1312 */           if (c1 == c2) {
/* 1313 */             j++; if (j != fragmentLen) continue;
/* 1314 */             return true;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1321 */           if (Character.toLowerCase(c1) == Character.toLowerCase(c2)) {
/* 1322 */             j++; if (j != fragmentLen) continue;
/* 1323 */             return true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1330 */         if (j > 0)
/*      */         {
/* 1332 */           i -= j;
/*      */         }
/*      */         
/* 1335 */         j = 0;
/*      */       }
/*      */     }
/*      */     
/* 1339 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, CharSequence text, int textOffset, int textLen, CharSequence fragment, int fragmentOffset, int fragmentLen)
/*      */   {
/* 1364 */     if (text == null) {
/* 1365 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/* 1367 */     if (fragment == null) {
/* 1368 */       throw new IllegalArgumentException("Fragment cannot be null");
/*      */     }
/*      */     
/* 1371 */     if (textLen < fragmentLen) {
/* 1372 */       return false;
/*      */     }
/* 1374 */     if (fragmentLen == 0) {
/* 1375 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1380 */     int i = 0; for (int j = 0; i < textLen; i++)
/*      */     {
/* 1382 */       char c1 = text.charAt(textOffset + i);
/* 1383 */       char c2 = fragment.charAt(fragmentOffset + j);
/*      */       
/* 1385 */       if (c1 == c2) {
/* 1386 */         j++; if (j == fragmentLen) {
/* 1387 */           return true;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1392 */         if (!caseSensitive)
/*      */         {
/* 1394 */           c1 = Character.toUpperCase(c1);
/* 1395 */           c2 = Character.toUpperCase(c2);
/* 1396 */           if (c1 == c2) {
/* 1397 */             j++; if (j != fragmentLen) continue;
/* 1398 */             return true;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1405 */           if (Character.toLowerCase(c1) == Character.toLowerCase(c2)) {
/* 1406 */             j++; if (j != fragmentLen) continue;
/* 1407 */             return true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1414 */         if (j > 0)
/*      */         {
/* 1416 */           i -= j;
/*      */         }
/*      */         
/* 1419 */         j = 0;
/*      */       }
/*      */     }
/*      */     
/* 1423 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compareTo(boolean caseSensitive, CharSequence text1, CharSequence text2)
/*      */   {
/* 1460 */     if (text1 == null) {
/* 1461 */       throw new IllegalArgumentException("First text being compared cannot be null");
/*      */     }
/* 1463 */     if (text2 == null) {
/* 1464 */       throw new IllegalArgumentException("Second text being compared cannot be null");
/*      */     }
/*      */     
/* 1467 */     if (((text1 instanceof String)) && ((text2 instanceof String))) {
/* 1468 */       return caseSensitive ? ((String)text1).compareTo((String)text2) : ((String)text1).compareToIgnoreCase((String)text2);
/*      */     }
/*      */     
/* 1471 */     return compareTo(caseSensitive, text1, 0, text1.length(), text2, 0, text2.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compareTo(boolean caseSensitive, CharSequence text1, char[] text2)
/*      */   {
/* 1503 */     return compareTo(caseSensitive, text1, 0, text1.length(), text2, 0, text2.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compareTo(boolean caseSensitive, char[] text1, char[] text2)
/*      */   {
/* 1534 */     return compareTo(caseSensitive, text1, 0, text1.length, text2, 0, text2.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compareTo(boolean caseSensitive, char[] text1, int text1Offset, int text1Len, char[] text2, int text2Offset, int text2Len)
/*      */   {
/* 1573 */     if (text1 == null) {
/* 1574 */       throw new IllegalArgumentException("First text buffer being compared cannot be null");
/*      */     }
/* 1576 */     if (text2 == null) {
/* 1577 */       throw new IllegalArgumentException("Second text buffer being compared cannot be null");
/*      */     }
/*      */     
/* 1580 */     if ((text1 == text2) && (text1Offset == text2Offset) && (text1Len == text2Len)) {
/* 1581 */       return 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1586 */     int n = Math.min(text1Len, text2Len);
/* 1587 */     int i = 0;
/*      */     
/* 1589 */     while (n-- != 0)
/*      */     {
/* 1591 */       char c1 = text1[(text1Offset + i)];
/* 1592 */       char c2 = text2[(text2Offset + i)];
/*      */       
/* 1594 */       if (c1 != c2)
/*      */       {
/* 1596 */         if (caseSensitive) {
/* 1597 */           return c1 - c2;
/*      */         }
/*      */         
/* 1600 */         c1 = Character.toUpperCase(c1);
/* 1601 */         c2 = Character.toUpperCase(c2);
/*      */         
/* 1603 */         if (c1 != c2)
/*      */         {
/* 1605 */           c1 = Character.toLowerCase(c1);
/* 1606 */           c2 = Character.toLowerCase(c2);
/* 1607 */           if (c1 != c2) {
/* 1608 */             return c1 - c2;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1615 */       i++;
/*      */     }
/*      */     
/*      */ 
/* 1619 */     return text1Len - text2Len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compareTo(boolean caseSensitive, CharSequence text1, int text1Offset, int text1Len, char[] text2, int text2Offset, int text2Len)
/*      */   {
/* 1659 */     if (text1 == null) {
/* 1660 */       throw new IllegalArgumentException("First text being compared cannot be null");
/*      */     }
/* 1662 */     if (text2 == null) {
/* 1663 */       throw new IllegalArgumentException("Second text buffer being compared cannot be null");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1668 */     int n = Math.min(text1Len, text2Len);
/* 1669 */     int i = 0;
/*      */     
/* 1671 */     while (n-- != 0)
/*      */     {
/* 1673 */       char c1 = text1.charAt(text1Offset + i);
/* 1674 */       char c2 = text2[(text2Offset + i)];
/*      */       
/* 1676 */       if (c1 != c2)
/*      */       {
/* 1678 */         if (caseSensitive) {
/* 1679 */           return c1 - c2;
/*      */         }
/*      */         
/* 1682 */         c1 = Character.toUpperCase(c1);
/* 1683 */         c2 = Character.toUpperCase(c2);
/*      */         
/* 1685 */         if (c1 != c2)
/*      */         {
/* 1687 */           c1 = Character.toLowerCase(c1);
/* 1688 */           c2 = Character.toLowerCase(c2);
/* 1689 */           if (c1 != c2) {
/* 1690 */             return c1 - c2;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1697 */       i++;
/*      */     }
/*      */     
/*      */ 
/* 1701 */     return text1Len - text2Len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compareTo(boolean caseSensitive, CharSequence text1, int text1Offset, int text1Len, CharSequence text2, int text2Offset, int text2Len)
/*      */   {
/* 1741 */     if (text1 == null) {
/* 1742 */       throw new IllegalArgumentException("First text being compared cannot be null");
/*      */     }
/* 1744 */     if (text2 == null) {
/* 1745 */       throw new IllegalArgumentException("Second text being compared cannot be null");
/*      */     }
/*      */     
/* 1748 */     if ((text1 == text2) && (text1Offset == text2Offset) && (text1Len == text2Len)) {
/* 1749 */       return 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1754 */     int n = Math.min(text1Len, text2Len);
/* 1755 */     int i = 0;
/*      */     
/* 1757 */     while (n-- != 0)
/*      */     {
/* 1759 */       char c1 = text1.charAt(text1Offset + i);
/* 1760 */       char c2 = text2.charAt(text2Offset + i);
/*      */       
/* 1762 */       if (c1 != c2)
/*      */       {
/* 1764 */         if (caseSensitive) {
/* 1765 */           return c1 - c2;
/*      */         }
/*      */         
/* 1768 */         c1 = Character.toUpperCase(c1);
/* 1769 */         c2 = Character.toUpperCase(c2);
/*      */         
/* 1771 */         if (c1 != c2)
/*      */         {
/* 1773 */           c1 = Character.toLowerCase(c1);
/* 1774 */           c2 = Character.toLowerCase(c2);
/* 1775 */           if (c1 != c2) {
/* 1776 */             return c1 - c2;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1783 */       i++;
/*      */     }
/*      */     
/*      */ 
/* 1787 */     return text1Len - text2Len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, char[][] values, char[] text, int textOffset, int textLen)
/*      */   {
/* 1820 */     if (values == null) {
/* 1821 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 1823 */     return binarySearch(caseSensitive, values, 0, values.length, text, textOffset, textLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, char[][] values, CharSequence text, int textOffset, int textLen)
/*      */   {
/* 1852 */     if (values == null) {
/* 1853 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 1855 */     return binarySearch(caseSensitive, values, 0, values.length, text, textOffset, textLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, CharSequence[] values, char[] text, int textOffset, int textLen)
/*      */   {
/* 1884 */     if (values == null) {
/* 1885 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 1887 */     return binarySearch(caseSensitive, values, 0, values.length, text, textOffset, textLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, CharSequence[] values, CharSequence text, int textOffset, int textLen)
/*      */   {
/* 1916 */     if (values == null) {
/* 1917 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 1919 */     return binarySearch(caseSensitive, values, 0, values.length, text, textOffset, textLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, char[][] values, int valuesOffset, int valuesLen, char[] text, int textOffset, int textLen)
/*      */   {
/* 1952 */     if (values == null) {
/* 1953 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 1955 */     if (text == null) {
/* 1956 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*      */     
/* 1959 */     int low = valuesOffset;
/* 1960 */     int high = valuesOffset + valuesLen - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1965 */     while (low <= high)
/*      */     {
/* 1967 */       int mid = low + high >>> 1;
/* 1968 */       char[] midVal = values[mid];
/*      */       
/* 1970 */       int cmp = compareTo(caseSensitive, midVal, 0, midVal.length, text, textOffset, textLen);
/*      */       
/* 1972 */       if (cmp < 0) {
/* 1973 */         low = mid + 1;
/* 1974 */       } else if (cmp > 0) {
/* 1975 */         high = mid - 1;
/*      */       }
/*      */       else {
/* 1978 */         return mid;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1983 */     return -(low + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, char[][] values, int valuesOffset, int valuesLen, CharSequence text, int textOffset, int textLen)
/*      */   {
/* 2016 */     if (values == null) {
/* 2017 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 2019 */     if (text == null) {
/* 2020 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*      */     
/* 2023 */     int low = valuesOffset;
/* 2024 */     int high = valuesOffset + valuesLen - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2029 */     while (low <= high)
/*      */     {
/* 2031 */       int mid = low + high >>> 1;
/* 2032 */       char[] midVal = values[mid];
/*      */       
/* 2034 */       int cmp = compareTo(caseSensitive, text, textOffset, textLen, midVal, 0, midVal.length);
/*      */       
/* 2036 */       if (cmp > 0) {
/* 2037 */         low = mid + 1;
/* 2038 */       } else if (cmp < 0) {
/* 2039 */         high = mid - 1;
/*      */       }
/*      */       else {
/* 2042 */         return mid;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2047 */     return -(low + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, CharSequence[] values, int valuesOffset, int valuesLen, char[] text, int textOffset, int textLen)
/*      */   {
/* 2080 */     if (values == null) {
/* 2081 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 2083 */     if (text == null) {
/* 2084 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*      */     
/* 2087 */     int low = valuesOffset;
/* 2088 */     int high = valuesOffset + valuesLen - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2093 */     while (low <= high)
/*      */     {
/* 2095 */       int mid = low + high >>> 1;
/* 2096 */       CharSequence midVal = values[mid];
/*      */       
/* 2098 */       int cmp = compareTo(caseSensitive, midVal, 0, midVal.length(), text, textOffset, textLen);
/*      */       
/* 2100 */       if (cmp < 0) {
/* 2101 */         low = mid + 1;
/* 2102 */       } else if (cmp > 0) {
/* 2103 */         high = mid - 1;
/*      */       }
/*      */       else {
/* 2106 */         return mid;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2111 */     return -(low + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, CharSequence[] values, int valuesOffset, int valuesLen, CharSequence text, int textOffset, int textLen)
/*      */   {
/* 2144 */     if (values == null) {
/* 2145 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 2147 */     if (text == null) {
/* 2148 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*      */     
/* 2151 */     int low = valuesOffset;
/* 2152 */     int high = valuesOffset + valuesLen - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2157 */     while (low <= high)
/*      */     {
/* 2159 */       int mid = low + high >>> 1;
/* 2160 */       CharSequence midVal = values[mid];
/*      */       
/* 2162 */       int cmp = compareTo(caseSensitive, text, textOffset, textLen, midVal, 0, midVal.length());
/*      */       
/* 2164 */       if (cmp > 0) {
/* 2165 */         low = mid + 1;
/* 2166 */       } else if (cmp < 0) {
/* 2167 */         high = mid - 1;
/*      */       }
/*      */       else {
/* 2170 */         return mid;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2175 */     return -(low + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int hashCode(char[] text, int textOffset, int textLen)
/*      */   {
/* 2199 */     int h = 0;
/* 2200 */     int off = textOffset;
/* 2201 */     for (int i = 0; i < textLen; i++) {
/* 2202 */       h = 31 * h + text[(off++)];
/*      */     }
/* 2204 */     return h;
/*      */   }
/*      */   
/*      */   public static int hashCode(CharSequence text)
/*      */   {
/* 2209 */     return hashCodePart(0, text);
/*      */   }
/*      */   
/*      */   public static int hashCode(CharSequence text, int beginIndex, int endIndex)
/*      */   {
/* 2214 */     return hashCodePart(0, text, beginIndex, endIndex);
/*      */   }
/*      */   
/*      */   public static int hashCode(CharSequence text0, CharSequence text1)
/*      */   {
/* 2219 */     return hashCodePart(hashCodePart(0, text0), text1);
/*      */   }
/*      */   
/*      */   public static int hashCode(CharSequence text0, CharSequence text1, CharSequence text2)
/*      */   {
/* 2224 */     return hashCodePart(hashCodePart(hashCodePart(0, text0), text1), text2);
/*      */   }
/*      */   
/*      */   public static int hashCode(CharSequence text0, CharSequence text1, CharSequence text2, CharSequence text3)
/*      */   {
/* 2229 */     return hashCodePart(hashCodePart(hashCodePart(hashCodePart(0, text0), text1), text2), text3);
/*      */   }
/*      */   
/*      */   public static int hashCode(CharSequence text0, CharSequence text1, CharSequence text2, CharSequence text3, CharSequence text4)
/*      */   {
/* 2234 */     return hashCodePart(hashCodePart(hashCodePart(hashCodePart(hashCodePart(0, text0), text1), text2), text3), text4);
/*      */   }
/*      */   
/*      */ 
/*      */   private static int hashCodePart(int h, CharSequence text)
/*      */   {
/* 2240 */     return hashCodePart(h, text, 0, text.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int hashCodePart(int h, CharSequence text, int beginIndex, int endIndex)
/*      */   {
/* 2255 */     if ((h == 0) && (beginIndex == 0) && (endIndex == text.length()) && ((text instanceof String))) {
/* 2256 */       return text.hashCode();
/*      */     }
/* 2258 */     int hh = h;
/* 2259 */     for (int i = beginIndex; i < endIndex; i++) {
/* 2260 */       hh = 31 * hh + text.charAt(i);
/*      */     }
/* 2262 */     return hh;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\util\TextUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */