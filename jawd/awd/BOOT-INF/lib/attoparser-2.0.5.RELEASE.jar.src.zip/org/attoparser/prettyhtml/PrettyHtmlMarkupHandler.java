/*     */ package org.attoparser.prettyhtml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.attoparser.AbstractMarkupHandler;
/*     */ import org.attoparser.ParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrettyHtmlMarkupHandler
/*     */   extends AbstractMarkupHandler
/*     */ {
/*     */   private static final String OPEN_TAG_START = "&lt;";
/*     */   private static final String OPEN_TAG_END = "&gt;";
/*     */   private static final String CLOSE_TAG_START = "&lt;/";
/*     */   private static final String CLOSE_TAG_END = "&gt;";
/*     */   private static final String MINIMIZED_TAG_END = "/&gt;";
/*     */   private static final String DOCUMENT_STYLES = "\nbody {\n    font-family: 'Bitstream Vera Sans Mono', 'Courier New', Courier, monospace;\n    font-size: 13px;\n    background: rgb(53, 39, 38);\n}\n";
/*     */   private static final String FRAGMENT_STYLES = "\n@@ .element {\n    color: #8bd1ff;\n}\n@@ .element-auto {\n    color: yellow;\n}\n@@ .element-unmatched {\n    color: red;\n}\n@@ .attr-name {\n    font-weight: normal;\n    color: white;\n}\n@@ .attr-value {\n    font-weight: normal;\n    color: #99cc33;\n}\n@@ .doctype {\n    font-weight: bold;\n    font-style: italics;\n    color: #8bd1ff;\n}\n@@ .comment {\n    font-style: italic;\n    color: #b58900;\n}\n@@ .cdata {\n    font-style: italic;\n    color: #b58900;\n}\n@@ .xml-declaration {\n    font-weight: bold;\n    color: olivedrab;\n}\n@@ .processing-instruction {\n    color: white;\n    background: black;\n}\n@@ .text {\n    color: #b9bdb6;\n}\n\n";
/*     */   private static final String STYLE_DOCTYPE = "doctype";
/*     */   private static final String STYLE_COMMENT = "comment";
/*     */   private static final String STYLE_CDATA = "cdata";
/*     */   private static final String STYLE_XML_DECLARATION = "xml-declaration";
/*     */   private static final String STYLE_PROCESSING_INSTRUCTION = "processing-instruction";
/*     */   private static final String STYLE_ELEMENT = "element";
/*     */   private static final String STYLE_ELEMENT_AUTO = "element-auto";
/*     */   private static final String STYLE_ELEMENT_UNMATCHED = "element-unmatched";
/*     */   private static final String STYLE_ATTR_NAME = "attr-name";
/*     */   private static final String STYLE_ATTR_VALUE = "attr-value";
/*     */   private static final String STYLE_TEXT = "text";
/*     */   private static final String TAG_FORMAT_START = "<span class=\"%1$s\">";
/*     */   private static final String TAG_FORMAT_END = "</span>";
/*     */   private final String documentName;
/*     */   private final String documentId;
/*     */   private final Writer writer;
/*     */   
/*     */   public PrettyHtmlMarkupHandler(Writer writer)
/*     */   {
/* 160 */     this(null, writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrettyHtmlMarkupHandler(String documentName, Writer writer)
/*     */   {
/* 175 */     if (writer == null) {
/* 176 */       throw new IllegalArgumentException("Writer cannot be null");
/*     */     }
/*     */     
/*     */ 
/* 180 */     this.documentName = (documentName == null ? String.valueOf(System.identityHashCode(this)) : documentName);
/* 181 */     this.documentId = tokenify(this.documentName);
/* 182 */     this.writer = writer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeEscaped(char[] buffer, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 191 */     int maxi = offset + len;
/* 192 */     for (int i = offset; i < maxi; i++) {
/* 193 */       char c = buffer[i];
/* 194 */       if (c == '\n') {
/* 195 */         this.writer.write("<br />");
/* 196 */       } else if (c == ' ') {
/* 197 */         this.writer.write("&nbsp;");
/* 198 */       } else if (c == '\t') {
/* 199 */         this.writer.write("&nbsp;&nbsp;&nbsp;&nbsp;");
/* 200 */       } else if (c == '<') {
/* 201 */         this.writer.write("&lt;");
/* 202 */       } else if (c == '>') {
/* 203 */         this.writer.write("&gt;");
/* 204 */       } else if (c == '&') {
/* 205 */         this.writer.write("&amp;");
/* 206 */       } else if (c == '"') {
/* 207 */         this.writer.write("&quot;");
/* 208 */       } else if (c == '\'') {
/* 209 */         this.writer.write("&#39;");
/*     */       } else {
/* 211 */         this.writer.write(c);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void openStyle(String style)
/*     */     throws IOException
/*     */   {
/* 220 */     openStyles(Collections.singletonList(style));
/*     */   }
/*     */   
/*     */   private void openStyles(List<String> styles) throws IOException {
/* 224 */     StringBuilder strBuilder = new StringBuilder();
/* 225 */     Iterator<String> stylesIter = styles.iterator();
/* 226 */     strBuilder.append((String)stylesIter.next());
/* 227 */     while (stylesIter.hasNext()) {
/* 228 */       strBuilder.append(' ');
/* 229 */       strBuilder.append((String)stylesIter.next());
/*     */     }
/* 231 */     this.writer.write(String.format("<span class=\"%1$s\">", new Object[] { strBuilder.toString() }));
/*     */   }
/*     */   
/*     */   private void closeStyle() throws IOException {
/* 235 */     this.writer.write("</span>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String tokenify(String text)
/*     */   {
/* 242 */     StringBuilder strBuilder = new StringBuilder();
/* 243 */     for (int i = 0; i < text.length(); i++) {
/* 244 */       char c = text.charAt(i);
/* 245 */       if (((c >= 'a') && (c <= 'z')) || ((c >= 'A') && (c <= 'Z')) || ((c >= '0') && (c <= '9'))) {
/* 246 */         strBuilder.append(c);
/*     */       }
/*     */     }
/* 249 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentStart(long startTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 262 */       this.writer.write("<!DOCTYPE html>\n");
/* 263 */       this.writer.write("<html>\n");
/* 264 */       this.writer.write("<head>\n");
/* 265 */       this.writer.write("<title>Parser output: " + this.documentName + "</title>\n");
/* 266 */       this.writer.write("<style>\nbody {\n    font-family: 'Bitstream Vera Sans Mono', 'Courier New', Courier, monospace;\n    font-size: 13px;\n    background: rgb(53, 39, 38);\n}\n</style>\n");
/* 267 */       this.writer.write("</head>\n");
/* 268 */       this.writer.write("<body>\n");
/*     */       
/* 270 */       this.writer.write("<div class=\"atto_source\" id=\"atto_source_" + this.documentId + "\">\n");
/* 271 */       this.writer.write("<style>\n" + "\n@@ .element {\n    color: #8bd1ff;\n}\n@@ .element-auto {\n    color: yellow;\n}\n@@ .element-unmatched {\n    color: red;\n}\n@@ .attr-name {\n    font-weight: normal;\n    color: white;\n}\n@@ .attr-value {\n    font-weight: normal;\n    color: #99cc33;\n}\n@@ .doctype {\n    font-weight: bold;\n    font-style: italics;\n    color: #8bd1ff;\n}\n@@ .comment {\n    font-style: italic;\n    color: #b58900;\n}\n@@ .cdata {\n    font-style: italic;\n    color: #b58900;\n}\n@@ .xml-declaration {\n    font-weight: bold;\n    color: olivedrab;\n}\n@@ .processing-instruction {\n    color: white;\n    background: black;\n}\n@@ .text {\n    color: #b9bdb6;\n}\n\n".replaceAll("@@", new StringBuilder().append("#atto_source_content_").append(this.documentId).toString()) + "</style>\n");
/* 272 */       this.writer.write("<div class=\"atto_source_content\" id=\"atto_source_content_" + this.documentId + "\">");
/*     */     }
/*     */     catch (Exception e) {
/* 275 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 289 */       this.writer.write("</div>");
/*     */       
/* 291 */       this.writer.write("</body>\n");
/* 292 */       this.writer.write("</html>\n");
/*     */     }
/*     */     catch (Exception e) {
/* 295 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 313 */       openStyle("element");
/* 314 */       this.writer.write("&lt;");
/* 315 */       this.writer.write(buffer, nameOffset, nameLen);
/*     */     }
/*     */     catch (Exception e) {
/* 318 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 334 */       this.writer.write(minimized ? "/&gt;" : "&gt;");
/* 335 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 338 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 355 */       openStyle("element");
/* 356 */       this.writer.write("&lt;");
/* 357 */       this.writer.write(buffer, nameOffset, nameLen);
/*     */     }
/*     */     catch (Exception e) {
/* 360 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 375 */       this.writer.write("&gt;");
/* 376 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 379 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 396 */       openStyle("element-auto");
/* 397 */       this.writer.write("&lt;");
/* 398 */       this.writer.write(buffer, nameOffset, nameLen);
/*     */     }
/*     */     catch (Exception e) {
/* 401 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 416 */       this.writer.write("&gt;");
/* 417 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 420 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 437 */       openStyle("element");
/* 438 */       this.writer.write("&lt;/");
/* 439 */       this.writer.write(buffer, nameOffset, nameLen);
/*     */     }
/*     */     catch (Exception e) {
/* 442 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 457 */       this.writer.write("&gt;");
/* 458 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 461 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 478 */       openStyle("element-auto");
/* 479 */       this.writer.write("&lt;/");
/* 480 */       this.writer.write(buffer, nameOffset, nameLen);
/*     */     }
/*     */     catch (Exception e) {
/* 483 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 498 */       this.writer.write("&gt;");
/* 499 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 502 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 519 */       openStyle("element-unmatched");
/* 520 */       this.writer.write("&lt;/");
/* 521 */       this.writer.write(buffer, nameOffset, nameLen);
/*     */     }
/*     */     catch (Exception e) {
/* 524 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 539 */       this.writer.write("&gt;");
/* 540 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 543 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 565 */       openStyle("attr-name");
/* 566 */       this.writer.write(buffer, nameOffset, nameLen);
/* 567 */       closeStyle();
/*     */       
/* 569 */       this.writer.write(buffer, operatorOffset, operatorLen);
/*     */       
/* 571 */       openStyle("attr-value");
/* 572 */       writeEscaped(buffer, valueOuterOffset, valueOuterLen);
/* 573 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 576 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 591 */       this.writer.write(buffer, offset, len);
/*     */     }
/*     */     catch (Exception e) {
/* 594 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 611 */       openStyle("text");
/* 612 */       writeEscaped(buffer, offset, len);
/* 613 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 616 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 633 */       openStyle("comment");
/* 634 */       this.writer.write("&lt;!--");
/* 635 */       writeEscaped(buffer, contentOffset, contentLen);
/* 636 */       this.writer.write("--&gt;");
/* 637 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 640 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCDATASection(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 656 */       openStyle("cdata");
/* 657 */       this.writer.write("&lt;![CDATA[");
/* 658 */       writeEscaped(buffer, contentOffset, contentLen);
/* 659 */       this.writer.write("]]&gt;");
/* 660 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 663 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleXmlDeclaration(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int versionOffset, int versionLen, int versionLine, int versionCol, int encodingOffset, int encodingLen, int encodingLine, int encodingCol, int standaloneOffset, int standaloneLen, int standaloneLine, int standaloneCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 688 */       int outerContentEnd = outerOffset + outerLen - 2;
/*     */       
/* 690 */       openStyle("xml-declaration");
/* 691 */       this.writer.write("&lt;");
/* 692 */       this.writer.write(63);
/* 693 */       this.writer.write(buffer, keywordOffset, keywordLen);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 698 */       int lastStructureEnd = keywordOffset + keywordLen;
/* 699 */       int thisStructureOffset = versionOffset;
/* 700 */       int thisStructureLen = versionLen;
/* 701 */       int thisStructureEnd = thisStructureOffset + thisStructureLen;
/*     */       
/* 703 */       this.writer.write(buffer, lastStructureEnd, thisStructureOffset - lastStructureEnd);
/* 704 */       this.writer.write(buffer, thisStructureOffset, thisStructureLen);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 709 */       if (encodingLen > 0)
/*     */       {
/* 711 */         lastStructureEnd = thisStructureEnd;
/* 712 */         thisStructureOffset = encodingOffset;
/* 713 */         thisStructureLen = encodingLen;
/* 714 */         thisStructureEnd = thisStructureOffset + thisStructureLen;
/*     */         
/* 716 */         this.writer.write(buffer, lastStructureEnd, thisStructureOffset - lastStructureEnd);
/* 717 */         this.writer.write(buffer, thisStructureOffset, thisStructureLen);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 725 */       if (standaloneLen > 0)
/*     */       {
/* 727 */         lastStructureEnd = thisStructureEnd;
/* 728 */         thisStructureOffset = standaloneOffset;
/* 729 */         thisStructureLen = standaloneLen;
/* 730 */         thisStructureEnd = thisStructureOffset + thisStructureLen;
/*     */         
/* 732 */         this.writer.write(buffer, lastStructureEnd, thisStructureOffset - lastStructureEnd);
/* 733 */         this.writer.write(buffer, thisStructureOffset, thisStructureLen);
/*     */       }
/*     */       
/*     */ 
/* 737 */       this.writer.write(buffer, thisStructureEnd, outerContentEnd - thisStructureEnd);
/*     */       
/* 739 */       this.writer.write(63);
/* 740 */       this.writer.write("&gt;");
/* 741 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 744 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocType(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int elementNameOffset, int elementNameLen, int elementNameLine, int elementNameCol, int typeOffset, int typeLen, int typeLine, int typeCol, int publicIdOffset, int publicIdLen, int publicIdLine, int publicIdCol, int systemIdOffset, int systemIdLen, int systemIdLine, int systemIdCol, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, int outerOffset, int outerLen, int outerLine, int outerCol)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 774 */       openStyle("doctype");
/* 775 */       this.writer.write("&lt;");
/* 776 */       this.writer.write(buffer, outerOffset + 1, outerLen - 2);
/* 777 */       this.writer.write("&gt;");
/* 778 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 781 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleProcessingInstruction(char[] buffer, int targetOffset, int targetLen, int targetLine, int targetCol, int contentOffset, int contentLen, int contentLine, int contentCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 803 */       openStyle("processing-instruction");
/* 804 */       this.writer.write("&lt;");
/* 805 */       this.writer.write(63);
/* 806 */       this.writer.write(buffer, targetOffset, targetLen);
/* 807 */       if (contentLen > 0) {
/* 808 */         this.writer.write(buffer, targetOffset + targetLen, contentOffset - (targetOffset + targetLen));
/* 809 */         this.writer.write(buffer, contentOffset, contentLen);
/*     */       } else {
/* 811 */         this.writer.write(buffer, targetOffset + targetLen, outerOffset + outerLen - 2 - (targetOffset + targetLen));
/*     */       }
/* 813 */       this.writer.write(63);
/* 814 */       this.writer.write("&gt;");
/* 815 */       closeStyle();
/*     */     }
/*     */     catch (Exception e) {
/* 818 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\prettyhtml\PrettyHtmlMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */