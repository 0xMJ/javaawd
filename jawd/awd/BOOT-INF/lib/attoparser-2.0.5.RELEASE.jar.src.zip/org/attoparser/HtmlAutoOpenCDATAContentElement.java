/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HtmlAutoOpenCDATAContentElement
/*     */   extends HtmlCDATAContentElement
/*     */ {
/*     */   private final char[][] autoOpenParents;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final char[][] autoOpenLimits;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HtmlAutoOpenCDATAContentElement(String name, String[] autoOpenParents, String[] autoOpenLimits)
/*     */   {
/*  43 */     super(name);
/*     */     
/*  45 */     if (autoOpenParents == null) {
/*  46 */       throw new IllegalArgumentException("The array of auto-open parents cannot be null");
/*     */     }
/*     */     
/*  49 */     char[][] autoOpenParentsCharArray = new char[autoOpenParents.length][];
/*  50 */     for (int i = 0; i < autoOpenParentsCharArray.length; i++) {
/*  51 */       autoOpenParentsCharArray[i] = autoOpenParents[i].toCharArray();
/*     */     }
/*     */     
/*     */     char[][] autoOpenLimitsCharArray;
/*  55 */     if (autoOpenLimits != null) {
/*  56 */       char[][] autoOpenLimitsCharArray = new char[autoOpenLimits.length][];
/*  57 */       for (int i = 0; i < autoOpenLimitsCharArray.length; i++) {
/*  58 */         autoOpenLimitsCharArray[i] = autoOpenLimits[i].toCharArray();
/*     */       }
/*     */     } else {
/*  61 */       autoOpenLimitsCharArray = null;
/*     */     }
/*     */     
/*  64 */     this.autoOpenParents = autoOpenParentsCharArray;
/*  65 */     this.autoOpenLimits = autoOpenLimitsCharArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled)
/*     */     throws ParseException
/*     */   {
/*  80 */     if ((autoOpenEnabled) && (!status.isAutoOpenCloseDone())) {
/*  81 */       status.setAutoOpenRequired(this.autoOpenParents, this.autoOpenLimits);
/*  82 */       return;
/*     */     }
/*     */     
/*  85 */     super.handleOpenElementStart(buffer, nameOffset, nameLen, line, col, handler, status, autoOpenEnabled, autoCloseEnabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled)
/*     */     throws ParseException
/*     */   {
/* 103 */     if ((autoOpenEnabled) && (!status.isAutoOpenCloseDone())) {
/* 104 */       status.setAutoOpenRequired(this.autoOpenParents, this.autoOpenLimits);
/* 105 */       return;
/*     */     }
/*     */     
/* 108 */     super.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col, handler, status, autoOpenEnabled, autoCloseEnabled);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\HtmlAutoOpenCDATAContentElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */