/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HtmlVoidAutoOpenCloseElement
/*     */   extends HtmlVoidAutoCloseElement
/*     */ {
/*     */   private final char[][] autoOpenParents;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final char[][] autoOpenLimits;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   HtmlVoidAutoOpenCloseElement(String name, String[] autoOpenParents, String[] autoOpenLimits, String[] autoCloseElements, String[] autoCloseLimits)
/*     */   {
/*  44 */     super(name, autoCloseElements, autoCloseLimits);
/*     */     
/*  46 */     if (autoOpenParents == null) {
/*  47 */       throw new IllegalArgumentException("The array of auto-open parents cannot be null");
/*     */     }
/*     */     
/*  50 */     char[][] autoOpenParentsCharArray = new char[autoOpenParents.length][];
/*  51 */     for (int i = 0; i < autoOpenParentsCharArray.length; i++) {
/*  52 */       autoOpenParentsCharArray[i] = autoOpenParents[i].toCharArray();
/*     */     }
/*     */     
/*     */     char[][] autoOpenLimitsCharArray;
/*  56 */     if (autoOpenLimits != null) {
/*  57 */       char[][] autoOpenLimitsCharArray = new char[autoOpenLimits.length][];
/*  58 */       for (int i = 0; i < autoOpenLimitsCharArray.length; i++) {
/*  59 */         autoOpenLimitsCharArray[i] = autoOpenLimits[i].toCharArray();
/*     */       }
/*     */     } else {
/*  62 */       autoOpenLimitsCharArray = null;
/*     */     }
/*     */     
/*  65 */     this.autoOpenParents = autoOpenParentsCharArray;
/*  66 */     this.autoOpenLimits = autoOpenLimitsCharArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled)
/*     */     throws ParseException
/*     */   {
/*  86 */     status.setAvoidStacking(true);
/*     */     
/*  88 */     if (((autoOpenEnabled) || (autoCloseEnabled)) && (!status.isAutoOpenCloseDone())) {
/*  89 */       if (autoCloseEnabled) {
/*  90 */         status.setAutoCloseRequired(this.autoCloseRequired, this.autoCloseLimits);
/*     */       }
/*  92 */       if (autoOpenEnabled) {
/*  93 */         status.setAutoOpenRequired(this.autoOpenParents, this.autoOpenLimits);
/*     */       }
/*  95 */       return;
/*     */     }
/*     */     
/*  98 */     handler.handleStandaloneElementStart(buffer, nameOffset, nameLen, false, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled)
/*     */     throws ParseException
/*     */   {
/* 115 */     status.setAvoidStacking(true);
/*     */     
/* 117 */     if (((autoOpenEnabled) || (autoCloseEnabled)) && (!status.isAutoOpenCloseDone())) {
/* 118 */       if (autoCloseEnabled) {
/* 119 */         status.setAutoCloseRequired(this.autoCloseRequired, this.autoCloseLimits);
/*     */       }
/* 121 */       if (autoOpenEnabled) {
/* 122 */         status.setAutoOpenRequired(this.autoOpenParents, this.autoOpenLimits);
/*     */       }
/* 124 */       return;
/*     */     }
/*     */     
/* 127 */     handler.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\HtmlVoidAutoOpenCloseElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */