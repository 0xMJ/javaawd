package org.attoparser;

public abstract interface IXMLDeclarationHandler
{
  public abstract void handleXmlDeclaration(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14, int paramInt15, int paramInt16, int paramInt17, int paramInt18, int paramInt19, int paramInt20)
    throws ParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\IXMLDeclarationHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */