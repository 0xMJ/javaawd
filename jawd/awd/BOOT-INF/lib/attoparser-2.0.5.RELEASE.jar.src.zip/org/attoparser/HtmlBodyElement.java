/*    */ package org.attoparser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HtmlBodyElement
/*    */   extends HtmlAutoOpenCloseElement
/*    */ {
/* 32 */   private static final String[] ARRAY_HTML_BODY = { "html", "body" };
/* 33 */   private static final String[] ARRAY_HEAD = { "head" };
/* 34 */   private static final String[] AUTO_CLOSE_LIMITS = { "script", "template", "element", "decorator", "content", "shadow" };
/*    */   
/*    */   HtmlBodyElement(String name) {
/* 37 */     super(name, ARRAY_HTML_BODY, null, ARRAY_HEAD, AUTO_CLOSE_LIMITS);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\HtmlBodyElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */