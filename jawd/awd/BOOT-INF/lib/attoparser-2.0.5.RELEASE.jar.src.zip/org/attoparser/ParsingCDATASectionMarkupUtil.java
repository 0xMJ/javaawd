/*    */ package org.attoparser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ParsingCDATASectionMarkupUtil
/*    */ {
/*    */   public static void parseCDATASection(char[] buffer, int offset, int len, int line, int col, ICDATASectionHandler handler)
/*    */     throws ParseException
/*    */   {
/* 49 */     if ((len < 12) || (!isCDATASectionStart(buffer, offset, offset + len)) || (!isCDATASectionEnd(buffer, offset + len - 3, offset + len))) {
/* 50 */       throw new ParseException("Could not parse as a well-formed CDATA Section: \"" + new String(buffer, offset, len) + "\"", line, col);
/*    */     }
/*    */     
/*    */ 
/* 54 */     int contentOffset = offset + 9;
/* 55 */     int contentLen = len - 12;
/*    */     
/* 57 */     handler.handleCDATASection(buffer, contentOffset, contentLen, offset, len, line, col);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static boolean isCDATASectionStart(char[] buffer, int offset, int maxi)
/*    */   {
/* 69 */     return (maxi - offset > 8) && (buffer[offset] == '<') && (buffer[(offset + 1)] == '!') && (buffer[(offset + 2)] == '[') && ((buffer[(offset + 3)] == 'C') || (buffer[(offset + 3)] == 'c')) && ((buffer[(offset + 4)] == 'D') || (buffer[(offset + 4)] == 'd')) && ((buffer[(offset + 5)] == 'A') || (buffer[(offset + 5)] == 'a')) && ((buffer[(offset + 6)] == 'T') || (buffer[(offset + 6)] == 't')) && ((buffer[(offset + 7)] == 'A') || (buffer[(offset + 7)] == 'a')) && (buffer[(offset + 8)] == '[');
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static boolean isCDATASectionEnd(char[] buffer, int offset, int maxi)
/*    */   {
/* 83 */     return (maxi - offset > 2) && (buffer[offset] == ']') && (buffer[(offset + 1)] == ']') && (buffer[(offset + 2)] == '>');
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\ParsingCDATASectionMarkupUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */