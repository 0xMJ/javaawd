/*     */ package org.attoparser.trace;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.attoparser.AbstractMarkupHandler;
/*     */ import org.attoparser.ParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TraceBuilderMarkupHandler
/*     */   extends AbstractMarkupHandler
/*     */ {
/*  57 */   private final List<MarkupTraceEvent> trace = new ArrayList(20);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<MarkupTraceEvent> getTrace()
/*     */   {
/*  82 */     return Collections.unmodifiableList(this.trace);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentStart(long startTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/*  91 */     this.trace.add(new MarkupTraceEvent.DocumentStartTraceEvent(startTimeNanos, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 100 */     this.trace.add(new MarkupTraceEvent.DocumentEndTraceEvent(endTimeNanos, totalTimeNanos, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 111 */     String elementName = new String(buffer, nameOffset, nameLen);
/* 112 */     if (minimized) {
/* 113 */       this.trace.add(new MarkupTraceEvent.StandaloneElementStartTraceEvent(elementName, line, col));
/*     */     } else {
/* 115 */       this.trace.add(new MarkupTraceEvent.NonMinimizedStandaloneElementStartTraceEvent(elementName, line, col));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 127 */     String elementName = new String(buffer, nameOffset, nameLen);
/* 128 */     if (minimized) {
/* 129 */       this.trace.add(new MarkupTraceEvent.StandaloneElementEndTraceEvent(elementName, line, col));
/*     */     } else {
/* 131 */       this.trace.add(new MarkupTraceEvent.NonMinimizedStandaloneElementEndTraceEvent(elementName, line, col));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 144 */     String elementName = new String(buffer, nameOffset, nameLen);
/* 145 */     this.trace.add(new MarkupTraceEvent.OpenElementStartTraceEvent(elementName, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 157 */     String elementName = new String(buffer, nameOffset, nameLen);
/* 158 */     this.trace.add(new MarkupTraceEvent.OpenElementEndTraceEvent(elementName, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 170 */     String elementName = new String(buffer, nameOffset, nameLen);
/* 171 */     this.trace.add(new MarkupTraceEvent.AutoOpenElementStartTraceEvent(elementName, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 183 */     String elementName = new String(buffer, nameOffset, nameLen);
/* 184 */     this.trace.add(new MarkupTraceEvent.AutoOpenElementEndTraceEvent(elementName, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 196 */     String elementName = new String(buffer, nameOffset, nameLen);
/* 197 */     this.trace.add(new MarkupTraceEvent.CloseElementStartTraceEvent(elementName, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 209 */     String elementName = new String(buffer, nameOffset, nameLen);
/* 210 */     this.trace.add(new MarkupTraceEvent.CloseElementEndTraceEvent(elementName, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 222 */     String elementName = new String(buffer, nameOffset, nameLen);
/* 223 */     this.trace.add(new MarkupTraceEvent.AutoCloseElementStartTraceEvent(elementName, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 235 */     String elementName = new String(buffer, nameOffset, nameLen);
/* 236 */     this.trace.add(new MarkupTraceEvent.AutoCloseElementEndTraceEvent(elementName, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 248 */     String elementName = new String(buffer, nameOffset, nameLen);
/* 249 */     this.trace.add(new MarkupTraceEvent.UnmatchedCloseElementStartTraceEvent(elementName, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 261 */     String elementName = new String(buffer, nameOffset, nameLen);
/* 262 */     this.trace.add(new MarkupTraceEvent.UnmatchedCloseElementEndTraceEvent(elementName, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws ParseException
/*     */   {
/* 280 */     String attributeName = new String(buffer, nameOffset, nameLen);
/* 281 */     String operator = new String(buffer, operatorOffset, operatorLen);
/* 282 */     String value = new String(buffer, valueOuterOffset, valueOuterLen);
/*     */     
/* 284 */     this.trace.add(new MarkupTraceEvent.AttributeTraceEvent(attributeName, nameLine, nameCol, operator, operatorLine, operatorCol, value, valueLine, valueCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 295 */     String content = new String(buffer, offset, len);
/* 296 */     this.trace.add(new MarkupTraceEvent.TextTraceEvent(content, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 308 */     String content = new String(buffer, contentOffset, contentLen);
/* 309 */     this.trace.add(new MarkupTraceEvent.CommentTraceEvent(content, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCDATASection(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 320 */     String content = new String(buffer, contentOffset, contentLen);
/* 321 */     this.trace.add(new MarkupTraceEvent.CDATASectionTraceEvent(content, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleXmlDeclaration(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int versionOffset, int versionLen, int versionLine, int versionCol, int encodingOffset, int encodingLen, int encodingLine, int encodingCol, int standaloneOffset, int standaloneLen, int standaloneLine, int standaloneCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 342 */     String keyword = new String(buffer, keywordOffset, keywordLen);
/* 343 */     String version = new String(buffer, versionOffset, versionLen);
/*     */     
/*     */ 
/*     */ 
/* 347 */     String encoding = encodingOffset > 0 ? new String(buffer, encodingOffset, encodingLen) : null;
/*     */     
/*     */ 
/*     */ 
/* 351 */     String standalone = standaloneOffset > 0 ? new String(buffer, standaloneOffset, standaloneLen) : null;
/*     */     
/* 353 */     this.trace.add(new MarkupTraceEvent.XmlDeclarationTraceEvent(keyword, keywordLine, keywordCol, version, versionLine, versionCol, encoding, encodingLine, encodingCol, standalone, standaloneLine, standaloneCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 375 */     String content = new String(buffer, offset, len);
/* 376 */     this.trace.add(new MarkupTraceEvent.InnerWhiteSpaceTraceEvent(content, line, col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocType(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int elementNameOffset, int elementNameLen, int elementNameLine, int elementNameCol, int typeOffset, int typeLen, int typeLine, int typeCol, int publicIdOffset, int publicIdLen, int publicIdLine, int publicIdCol, int systemIdOffset, int systemIdLen, int systemIdLine, int systemIdCol, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, int outerOffset, int outerLen, int outerLine, int outerCol)
/*     */     throws ParseException
/*     */   {
/* 400 */     String keyword = new String(buffer, keywordOffset, keywordLen);
/* 401 */     String elementName = new String(buffer, elementNameOffset, elementNameLen);
/* 402 */     String type = new String(buffer, typeOffset, typeLen);
/* 403 */     String publicId = publicIdOffset <= 0 ? null : new String(buffer, publicIdOffset, publicIdLen);
/* 404 */     String systemId = systemIdOffset <= 0 ? null : new String(buffer, systemIdOffset, systemIdLen);
/* 405 */     String internalSubset = internalSubsetOffset <= 0 ? null : new String(buffer, internalSubsetOffset, internalSubsetLen);
/*     */     
/* 407 */     this.trace.add(new MarkupTraceEvent.DocTypeTraceEvent(keyword, keywordLine, keywordCol, elementName, elementNameLine, elementNameCol, type, typeLine, typeCol, publicId, publicIdLine, publicIdCol, systemId, systemIdLine, systemIdCol, internalSubset, internalSubsetLine, internalSubsetCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleProcessingInstruction(char[] buffer, int targetOffset, int targetLen, int targetLine, int targetCol, int contentOffset, int contentLen, int contentLine, int contentCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 432 */     String target = new String(buffer, targetOffset, targetLen);
/* 433 */     String content = contentOffset <= 0 ? null : new String(buffer, contentOffset, contentLen);
/*     */     
/* 435 */     this.trace.add(new MarkupTraceEvent.ProcessingInstructionTraceEvent(target, targetLine, targetCol, content, contentLine, contentCol));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\trace\TraceBuilderMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */