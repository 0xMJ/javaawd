/*     */ package org.attoparser.trace;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MarkupTraceEvent
/*     */ {
/*     */   private final EventType eventType;
/*     */   final String[] contents;
/*     */   final int[] lines;
/*     */   final int[] cols;
/*     */   
/*     */   public static enum EventType
/*     */   {
/*  45 */     DOCUMENT_START("DS"),  DOCUMENT_END("DE"), 
/*     */     
/*  47 */     STANDALONE_ELEMENT_START("SES"),  STANDALONE_ELEMENT_END("SEE"), 
/*  48 */     NON_MINIMIZED_STANDALONE_ELEMENT_START("NSES"),  NON_MINIMIZED_STANDALONE_ELEMENT_END("NSEE"), 
/*     */     
/*  50 */     OPEN_ELEMENT_START("OES"),  OPEN_ELEMENT_END("OEE"), 
/*  51 */     AUTO_OPEN_ELEMENT_START("AOES"),  AUTO_OPEN_ELEMENT_END("AOEE"), 
/*     */     
/*  53 */     CLOSE_ELEMENT_START("CES"),  CLOSE_ELEMENT_END("CEE"), 
/*  54 */     AUTO_CLOSE_ELEMENT_START("ACES"),  AUTO_CLOSE_ELEMENT_END("ACEE"), 
/*  55 */     UNMATCHED_CLOSE_ELEMENT_START("UCES"),  UNMATCHED_CLOSE_ELEMENT_END("UCEE"), 
/*     */     
/*  57 */     ATTRIBUTE("A"),  INNER_WHITE_SPACE("IWS"), 
/*     */     
/*  59 */     TEXT("T"),  COMMENT("C"),  CDATA_SECTION("CD"),  XML_DECLARATION("XD"),  DOC_TYPE("DT"),  PROCESSING_INSTRUCTION("P");
/*     */     
/*     */     private String stringRepresentation;
/*     */     
/*     */     private EventType(String stringRepresentation)
/*     */     {
/*  65 */       this.stringRepresentation = stringRepresentation;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  69 */       return this.stringRepresentation;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MarkupTraceEvent(EventType eventType, int[] lines, int[] cols, String... contents)
/*     */   {
/*  90 */     if (eventType == null) {
/*  91 */       throw new IllegalArgumentException("Event type cannot be null");
/*     */     }
/*     */     
/*  94 */     this.eventType = eventType;
/*  95 */     this.contents = contents;
/*  96 */     this.lines = lines;
/*  97 */     this.cols = cols;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EventType getEventType()
/*     */   {
/* 110 */     return this.eventType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 119 */     StringBuilder strBuilder = new StringBuilder();
/*     */     
/* 121 */     strBuilder.append(this.eventType);
/*     */     int i;
/* 123 */     if (this.contents != null) { if (((this.lines != null ? 1 : 0) & (this.lines.length == this.contents.length ? 1 : 0)) != 0)
/*     */       {
/* 125 */         for (i = 0; i < this.contents.length; i++) {
/* 126 */           strBuilder.append('(');
/* 127 */           if (this.contents[i] != null) {
/* 128 */             strBuilder.append(this.contents[i]);
/*     */           }
/* 130 */           strBuilder.append(')');
/* 131 */           strBuilder.append('{');
/* 132 */           strBuilder.append(String.valueOf(this.lines[i]));
/* 133 */           strBuilder.append(',');
/* 134 */           strBuilder.append(String.valueOf(this.cols[i]));
/* 135 */           strBuilder.append('}');
/*     */         }
/*     */         
/* 138 */         return strBuilder.toString();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 143 */     if (this.contents != null) {
/* 144 */       for (String contentItem : this.contents) {
/* 145 */         strBuilder.append('(');
/* 146 */         if (contentItem != null) {
/* 147 */           strBuilder.append(contentItem);
/*     */         }
/* 149 */         strBuilder.append(')');
/*     */       }
/*     */     }
/*     */     
/* 153 */     strBuilder.append('{');
/* 154 */     strBuilder.append(String.valueOf(this.lines[0]));
/* 155 */     strBuilder.append(',');
/* 156 */     strBuilder.append(String.valueOf(this.cols[0]));
/* 157 */     strBuilder.append('}');
/*     */     
/* 159 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matchesTypeAndContent(MarkupTraceEvent event)
/*     */   {
/* 174 */     if (this == event) {
/* 175 */       return true;
/*     */     }
/* 177 */     if (event == null) {
/* 178 */       return false;
/*     */     }
/* 180 */     if (this.eventType == null) {
/* 181 */       if (event.eventType != null) {
/* 182 */         return false;
/*     */       }
/* 184 */     } else if (!this.eventType.equals(event.eventType)) {
/* 185 */       return false;
/*     */     }
/* 187 */     if (this.contents == null) {
/* 188 */       if (event.contents != null) {
/* 189 */         return false;
/*     */       }
/* 191 */     } else if (!Arrays.equals(this.contents, event.contents)) {
/* 192 */       return false;
/*     */     }
/* 194 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 202 */     int result = this.eventType.hashCode();
/* 203 */     result = 31 * result + Arrays.hashCode(this.contents);
/* 204 */     result = 31 * result + Arrays.hashCode(this.lines);
/* 205 */     result = 31 * result + Arrays.hashCode(this.cols);
/* 206 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 212 */     if (this == o) {
/* 213 */       return true;
/*     */     }
/* 215 */     if ((o == null) || (getClass() != o.getClass())) {
/* 216 */       return false;
/*     */     }
/*     */     
/* 219 */     MarkupTraceEvent that = (MarkupTraceEvent)o;
/*     */     
/* 221 */     if (!Arrays.equals(this.cols, that.cols)) {
/* 222 */       return false;
/*     */     }
/* 224 */     if (!Arrays.equals(this.contents, that.contents)) {
/* 225 */       return false;
/*     */     }
/* 227 */     if (!Arrays.equals(this.lines, that.lines)) {
/* 228 */       return false;
/*     */     }
/*     */     
/* 231 */     return this.eventType == that.eventType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class DocumentStartTraceEvent
/*     */     extends MarkupTraceEvent
/*     */   {
/*     */     public DocumentStartTraceEvent(long startTimeNanos, int line, int col)
/*     */     {
/* 243 */       super(new int[] { line }, new int[] { col }, new String[] { String.valueOf(startTimeNanos) }, null);
/*     */     }
/*     */     
/*     */     public long getStartTimeNanos() {
/* 247 */       return Long.parseLong(this.contents[0]);
/*     */     }
/*     */     
/*     */     public int getLine() {
/* 251 */       return this.lines[0];
/*     */     }
/*     */     
/*     */     public int getCol() {
/* 255 */       return this.cols[0];
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class DocumentEndTraceEvent extends MarkupTraceEvent
/*     */   {
/*     */     public DocumentEndTraceEvent(long endTimeNanos, long totalTimeNanos, int line, int col)
/*     */     {
/* 263 */       super(new int[] { line }, new int[] { col }, new String[] { String.valueOf(endTimeNanos), String.valueOf(totalTimeNanos) }, null);
/*     */     }
/*     */     
/*     */     public long getStartTimeNanos() {
/* 267 */       return Long.parseLong(this.contents[0]);
/*     */     }
/*     */     
/*     */     public long getTotalTimeNanos() {
/* 271 */       return Long.parseLong(this.contents[1]);
/*     */     }
/*     */     
/*     */     public int getLine() {
/* 275 */       return this.lines[0];
/*     */     }
/*     */     
/*     */     public int getCol() {
/* 279 */       return this.cols[0];
/*     */     }
/*     */   }
/*     */   
/*     */   static abstract class AbstractContentTraceEvent extends MarkupTraceEvent
/*     */   {
/*     */     protected AbstractContentTraceEvent(MarkupTraceEvent.EventType type, String content, int line, int col)
/*     */     {
/* 287 */       super(new int[] { line }, new int[] { col }, new String[] { content }, null);
/* 288 */       if (content == null) {
/* 289 */         throw new IllegalArgumentException("Contentn cannot be null");
/*     */       }
/*     */     }
/*     */     
/*     */     public String getContent() {
/* 294 */       return this.contents[0];
/*     */     }
/*     */     
/*     */     public int getLine() {
/* 298 */       return this.lines[0];
/*     */     }
/*     */     
/*     */     public int getCol() {
/* 302 */       return this.cols[0];
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class TextTraceEvent extends MarkupTraceEvent.AbstractContentTraceEvent
/*     */   {
/*     */     public TextTraceEvent(String content, int line, int col) {
/* 309 */       super(content, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class CommentTraceEvent extends MarkupTraceEvent.AbstractContentTraceEvent {
/*     */     public CommentTraceEvent(String content, int line, int col) {
/* 315 */       super(content, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class CDATASectionTraceEvent extends MarkupTraceEvent.AbstractContentTraceEvent {
/*     */     public CDATASectionTraceEvent(String content, int line, int col) {
/* 321 */       super(content, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class InnerWhiteSpaceTraceEvent extends MarkupTraceEvent.AbstractContentTraceEvent {
/*     */     public InnerWhiteSpaceTraceEvent(String content, int line, int col) {
/* 327 */       super(content, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   static abstract class AbstractElementTraceEvent extends MarkupTraceEvent
/*     */   {
/*     */     protected AbstractElementTraceEvent(MarkupTraceEvent.EventType type, String elementName, int line, int col) {
/* 334 */       super(new int[] { line }, new int[] { col }, new String[] { elementName }, null);
/* 335 */       if ((elementName == null) || (elementName.trim().equals(""))) {
/* 336 */         throw new IllegalArgumentException("Element name cannot be null or empty");
/*     */       }
/*     */     }
/*     */     
/*     */     public String getElementName() {
/* 341 */       return this.contents[0];
/*     */     }
/*     */     
/*     */     public int getLine() {
/* 345 */       return this.lines[0];
/*     */     }
/*     */     
/*     */     public int getCol() {
/* 349 */       return this.cols[0];
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class StandaloneElementStartTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent
/*     */   {
/*     */     public StandaloneElementStartTraceEvent(String elementName, int line, int col) {
/* 356 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class StandaloneElementEndTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public StandaloneElementEndTraceEvent(String elementName, int line, int col) {
/* 362 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class NonMinimizedStandaloneElementStartTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public NonMinimizedStandaloneElementStartTraceEvent(String elementName, int line, int col) {
/* 368 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class NonMinimizedStandaloneElementEndTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public NonMinimizedStandaloneElementEndTraceEvent(String elementName, int line, int col) {
/* 374 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class OpenElementStartTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public OpenElementStartTraceEvent(String elementName, int line, int col) {
/* 380 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class OpenElementEndTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public OpenElementEndTraceEvent(String elementName, int line, int col) {
/* 386 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class AutoOpenElementStartTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public AutoOpenElementStartTraceEvent(String elementName, int line, int col) {
/* 392 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class AutoOpenElementEndTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public AutoOpenElementEndTraceEvent(String elementName, int line, int col) {
/* 398 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class CloseElementStartTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public CloseElementStartTraceEvent(String elementName, int line, int col) {
/* 404 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class CloseElementEndTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public CloseElementEndTraceEvent(String elementName, int line, int col) {
/* 410 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class AutoCloseElementStartTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public AutoCloseElementStartTraceEvent(String elementName, int line, int col) {
/* 416 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class AutoCloseElementEndTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public AutoCloseElementEndTraceEvent(String elementName, int line, int col) {
/* 422 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class UnmatchedCloseElementStartTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public UnmatchedCloseElementStartTraceEvent(String elementName, int line, int col) {
/* 428 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class UnmatchedCloseElementEndTraceEvent extends MarkupTraceEvent.AbstractElementTraceEvent {
/*     */     public UnmatchedCloseElementEndTraceEvent(String elementName, int line, int col) {
/* 434 */       super(elementName, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class AttributeTraceEvent
/*     */     extends MarkupTraceEvent
/*     */   {
/*     */     public AttributeTraceEvent(String name, int nameLine, int nameCol, String operator, int operatorLine, int operatorCol, String outerValue, int valueLine, int valueCol)
/*     */     {
/* 447 */       super(new int[] { nameLine, operatorLine, valueLine }, new int[] { nameCol, operatorCol, valueCol }, new String[] { name, operator, outerValue }, null);
/* 448 */       if ((name == null) || (name.trim().equals(""))) {
/* 449 */         throw new IllegalArgumentException("Attribute name cannot be null or empty");
/*     */       }
/*     */     }
/*     */     
/*     */     public String getName() {
/* 454 */       return this.contents[0];
/*     */     }
/*     */     
/*     */     public String getOperator() {
/* 458 */       return this.contents[1];
/*     */     }
/*     */     
/*     */     public String getOuterValue() {
/* 462 */       return this.contents[2];
/*     */     }
/*     */     
/*     */     public int getNameLine() {
/* 466 */       return this.lines[0];
/*     */     }
/*     */     
/*     */     public int getNameCol() {
/* 470 */       return this.cols[0];
/*     */     }
/*     */     
/*     */     public int getOperatorLine() {
/* 474 */       return this.lines[1];
/*     */     }
/*     */     
/*     */     public int getOperatorCol() {
/* 478 */       return this.cols[1];
/*     */     }
/*     */     
/*     */     public int getOuterValueLine() {
/* 482 */       return this.lines[2];
/*     */     }
/*     */     
/*     */     public int getOuterValueCol() {
/* 486 */       return this.cols[2];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class XmlDeclarationTraceEvent
/*     */     extends MarkupTraceEvent
/*     */   {
/*     */     public XmlDeclarationTraceEvent(String keyword, int keywordLine, int keywordCol, String version, int versionLine, int versionCol, String encoding, int encodingLine, int encodingCol, String standalone, int standaloneLine, int standaloneCol)
/*     */     {
/* 502 */       super(new int[] { keywordLine, versionLine, encodingLine, standaloneLine }, new int[] { keywordCol, versionCol, encodingCol, standaloneCol }, new String[] { keyword, version, encoding, standalone }, null);
/*     */       
/*     */ 
/*     */ 
/* 506 */       if ((keyword == null) || (keyword.trim().equals(""))) {
/* 507 */         throw new IllegalArgumentException("Keyword cannot be null or empty");
/*     */       }
/*     */     }
/*     */     
/*     */     public String getKeyword() {
/* 512 */       return this.contents[0];
/*     */     }
/*     */     
/*     */     public String getVersion() {
/* 516 */       return this.contents[1];
/*     */     }
/*     */     
/*     */     public String getEncoding() {
/* 520 */       return this.contents[2];
/*     */     }
/*     */     
/*     */     public String getStandalone() {
/* 524 */       return this.contents[3];
/*     */     }
/*     */     
/*     */     public int getKeywordLine() {
/* 528 */       return this.lines[0];
/*     */     }
/*     */     
/*     */     public int getVersionLine() {
/* 532 */       return this.lines[1];
/*     */     }
/*     */     
/*     */     public int getEncodingLine() {
/* 536 */       return this.lines[2];
/*     */     }
/*     */     
/*     */     public int getStandaloneLine() {
/* 540 */       return this.lines[3];
/*     */     }
/*     */     
/*     */     public int getKeywordCol() {
/* 544 */       return this.lines[0];
/*     */     }
/*     */     
/*     */     public int getVersionCol() {
/* 548 */       return this.lines[1];
/*     */     }
/*     */     
/*     */     public int getEncodingCol() {
/* 552 */       return this.lines[2];
/*     */     }
/*     */     
/*     */     public int getStandaloneCol() {
/* 556 */       return this.lines[3];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class DocTypeTraceEvent
/*     */     extends MarkupTraceEvent
/*     */   {
/*     */     public DocTypeTraceEvent(String keyword, int keywordLine, int keywordCol, String elementName, int elementNameLine, int elementNameCol, String type, int typeLine, int typeCol, String publicId, int publicIdLine, int publicIdCol, String systemId, int systemIdLine, int systemIdCol, String internalSubset, int internalSubsetLine, int internalSubsetCol)
/*     */     {
/* 576 */       super(new int[] { keywordLine, elementNameLine, typeLine, publicIdLine, systemIdLine, internalSubsetLine }, new int[] { keywordCol, elementNameCol, typeCol, publicIdCol, systemIdCol, internalSubsetCol }, new String[] { keyword, elementName, type, publicId, systemId, internalSubset }, null);
/*     */       
/*     */ 
/*     */ 
/* 580 */       if ((keyword == null) || (keyword.trim().equals(""))) {
/* 581 */         throw new IllegalArgumentException("Keyword cannot be null or empty");
/*     */       }
/*     */     }
/*     */     
/*     */     public String getKeyword() {
/* 586 */       return this.contents[0];
/*     */     }
/*     */     
/*     */     public String getElementName() {
/* 590 */       return this.contents[1];
/*     */     }
/*     */     
/*     */     public String getType() {
/* 594 */       return this.contents[2];
/*     */     }
/*     */     
/*     */     public String getPublicId() {
/* 598 */       return this.contents[3];
/*     */     }
/*     */     
/*     */     public String getSystemId() {
/* 602 */       return this.contents[4];
/*     */     }
/*     */     
/*     */     public String getInternalSubset() {
/* 606 */       return this.contents[5];
/*     */     }
/*     */     
/*     */     public int getKeywordLine() {
/* 610 */       return this.lines[0];
/*     */     }
/*     */     
/*     */     public int getElementNameLine() {
/* 614 */       return this.lines[1];
/*     */     }
/*     */     
/*     */     public int getTypeLine() {
/* 618 */       return this.lines[2];
/*     */     }
/*     */     
/*     */     public int getPublicIdLine() {
/* 622 */       return this.lines[3];
/*     */     }
/*     */     
/*     */     public int getSystemIdLine() {
/* 626 */       return this.lines[4];
/*     */     }
/*     */     
/*     */     public int getInternalSubsetLine() {
/* 630 */       return this.lines[5];
/*     */     }
/*     */     
/*     */     public int getKeywordCol() {
/* 634 */       return this.lines[0];
/*     */     }
/*     */     
/*     */     public int getElementNameCol() {
/* 638 */       return this.lines[1];
/*     */     }
/*     */     
/*     */     public int getTypeCol() {
/* 642 */       return this.lines[2];
/*     */     }
/*     */     
/*     */     public int getPublicIdCol() {
/* 646 */       return this.lines[3];
/*     */     }
/*     */     
/*     */     public int getSystemIdCol() {
/* 650 */       return this.lines[4];
/*     */     }
/*     */     
/*     */     public int getInternalSubsetCol() {
/* 654 */       return this.lines[5];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class ProcessingInstructionTraceEvent
/*     */     extends MarkupTraceEvent
/*     */   {
/*     */     public ProcessingInstructionTraceEvent(String target, int targetLine, int targetCol, String content, int contentLine, int contentCol)
/*     */     {
/* 667 */       super(new int[] { targetLine, contentLine }, new int[] { targetCol, contentCol }, new String[] { target, content }, null);
/*     */       
/*     */ 
/*     */ 
/* 671 */       if ((target == null) || (target.trim().equals(""))) {
/* 672 */         throw new IllegalArgumentException("Target cannot be null or empty");
/*     */       }
/*     */     }
/*     */     
/*     */     public String getTarget() {
/* 677 */       return this.contents[0];
/*     */     }
/*     */     
/*     */     public String getContent() {
/* 681 */       return this.contents[1];
/*     */     }
/*     */     
/*     */     public int getTargetLine() {
/* 685 */       return this.lines[0];
/*     */     }
/*     */     
/*     */     public int getContentLine() {
/* 689 */       return this.lines[1];
/*     */     }
/*     */     
/*     */     public int getTargetCol() {
/* 693 */       return this.lines[0];
/*     */     }
/*     */     
/*     */     public int getContentCol() {
/* 697 */       return this.lines[1];
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\trace\MarkupTraceEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */