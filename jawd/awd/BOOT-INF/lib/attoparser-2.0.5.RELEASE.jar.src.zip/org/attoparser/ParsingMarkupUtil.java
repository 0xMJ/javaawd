/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParsingMarkupUtil
/*     */ {
/*     */   static int findNextStructureEndAvoidQuotes(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/*  47 */     boolean inQuotes = false;
/*  48 */     boolean inApos = false;
/*     */     
/*     */ 
/*     */ 
/*  52 */     int colIndex = offset;
/*     */     
/*  54 */     int i = offset;
/*  55 */     int n = maxi - offset;
/*     */     
/*  57 */     while (n-- != 0)
/*     */     {
/*  59 */       char c = text[i];
/*     */       
/*  61 */       if (c == '\n') {
/*  62 */         colIndex = i;
/*  63 */         locator[1] = 0;
/*  64 */         locator[0] += 1;
/*  65 */       } else if ((c == '"') && (!inApos)) {
/*  66 */         inQuotes = !inQuotes;
/*  67 */       } else if ((c == '\'') && (!inQuotes)) {
/*  68 */         inApos = !inApos;
/*  69 */       } else if ((c == '>') && (!inQuotes) && (!inApos)) {
/*  70 */         locator[1] += i - colIndex;
/*  71 */         return i;
/*     */       }
/*     */       
/*  74 */       i++;
/*     */     }
/*     */     
/*     */ 
/*  78 */     locator[1] += maxi - colIndex;
/*  79 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextStructureEndDontAvoidQuotes(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/*  90 */     int colIndex = offset;
/*     */     
/*  92 */     int i = offset;
/*  93 */     int n = maxi - offset;
/*     */     
/*  95 */     while (n-- != 0)
/*     */     {
/*  97 */       char c = text[i];
/*     */       
/*  99 */       if (c == '\n') {
/* 100 */         colIndex = i;
/* 101 */         locator[1] = 0;
/* 102 */         locator[0] += 1;
/* 103 */       } else if (c == '>') {
/* 104 */         locator[1] += i - colIndex;
/* 105 */         return i;
/*     */       }
/*     */       
/* 108 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 112 */     locator[1] += maxi - colIndex;
/* 113 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextStructureStart(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 124 */     int colIndex = offset;
/*     */     
/* 126 */     int i = offset;
/* 127 */     int n = maxi - offset;
/*     */     
/* 129 */     while (n-- != 0)
/*     */     {
/* 131 */       char c = text[i];
/*     */       
/* 133 */       if (c == '\n') {
/* 134 */         colIndex = i;
/* 135 */         locator[1] = 0;
/* 136 */         locator[0] += 1;
/* 137 */       } else if (c == '<') {
/* 138 */         locator[1] += i - colIndex;
/* 139 */         return i;
/*     */       }
/*     */       
/* 142 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 146 */     locator[1] += maxi - colIndex;
/* 147 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextWhitespaceCharWildcard(char[] text, int offset, int maxi, boolean avoidQuotes, int[] locator)
/*     */   {
/* 156 */     boolean inQuotes = false;
/* 157 */     boolean inApos = false;
/*     */     
/*     */ 
/*     */ 
/* 161 */     int i = offset;
/* 162 */     int n = maxi - offset;
/*     */     
/* 164 */     while (n-- != 0)
/*     */     {
/* 166 */       char c = text[i];
/*     */       
/* 168 */       if ((avoidQuotes) && (!inApos) && (c == '"')) {
/* 169 */         inQuotes = !inQuotes;
/* 170 */       } else if ((avoidQuotes) && (!inQuotes) && (c == '\'')) {
/* 171 */         inApos = !inApos;
/* 172 */       } else if ((!inQuotes) && (!inApos)) { if ((c != ' ') && (c != '\n') && (c != '\t') && (c != '\r') && (c != '\f') && (c != '\013') && (c != '\034') && (c != '\035') && (c != '\036') && (c != '\037')) { if (c > '')
/*     */           {
/* 174 */             if (!Character.isWhitespace(c)) {} }
/* 175 */         } else { return i;
/*     */         }
/*     */       }
/* 178 */       ParsingLocatorUtil.countChar(locator, c);
/*     */       
/* 180 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 184 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextNonWhitespaceCharWildcard(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 196 */     int i = offset;
/* 197 */     int n = maxi - offset;
/*     */     
/* 199 */     while (n-- != 0)
/*     */     {
/* 201 */       char c = text[i];
/* 202 */       if ((c != ' ') && (c != '\n') && (c != '\t') && (c != '\r') && (c != '\f') && (c != '\013') && (c != '\034') && (c != '\035') && (c != '\036') && (c != '\037')) if (c <= '') break label111;
/*     */       label111:
/* 204 */       boolean isWhitespace = Character.isWhitespace(c);
/*     */       
/* 206 */       if (!isWhitespace) {
/* 207 */         return i;
/*     */       }
/*     */       
/* 210 */       ParsingLocatorUtil.countChar(locator, c);
/*     */       
/* 212 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 216 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextOperatorCharWildcard(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 227 */     int i = offset;
/* 228 */     int n = maxi - offset;
/*     */     
/* 230 */     while (n-- != 0)
/*     */     {
/* 232 */       char c = text[i];
/*     */       
/* 234 */       if ((c != '=') && (c != ' ') && (c != '\n') && (c != '\t') && (c != '\r') && (c != '\f') && (c != '\013') && (c != '\034') && (c != '\035') && (c != '\036') && (c != '\037')) { if (c > '')
/*     */         {
/* 236 */           if (!Character.isWhitespace(c)) {} }
/* 237 */       } else { return i;
/*     */       }
/*     */       
/* 240 */       ParsingLocatorUtil.countChar(locator, c);
/*     */       
/* 242 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 246 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextNonOperatorCharWildcard(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 257 */     int i = offset;
/* 258 */     int n = maxi - offset;
/*     */     
/* 260 */     while (n-- != 0)
/*     */     {
/* 262 */       char c = text[i];
/*     */       
/* 264 */       if ((c != '=') && (c != ' ') && (c != '\n') && (c != '\t') && (c != '\r') && (c != '\f') && (c != '\013') && (c != '\034') && (c != '\035') && (c != '\036') && (c != '\037') && ((c <= '') || 
/*     */       
/* 266 */         (!Character.isWhitespace(c)))) {
/* 267 */         return i;
/*     */       }
/*     */       
/* 270 */       ParsingLocatorUtil.countChar(locator, c);
/*     */       
/* 272 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 276 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextAnyCharAvoidQuotesWildcard(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 285 */     boolean inQuotes = false;
/* 286 */     boolean inApos = false;
/*     */     
/*     */ 
/*     */ 
/* 290 */     int i = offset;
/* 291 */     int n = maxi - offset;
/*     */     
/* 293 */     while (n-- != 0)
/*     */     {
/* 295 */       char c = text[i];
/*     */       
/* 297 */       if ((!inApos) && (c == '"')) {
/* 298 */         if (inQuotes) {
/* 299 */           ParsingLocatorUtil.countChar(locator, c);
/* 300 */           i++;
/* 301 */           return i < maxi ? i : -1;
/*     */         }
/* 303 */         inQuotes = true;
/* 304 */       } else if ((!inQuotes) && (c == '\'')) {
/* 305 */         if (inApos) {
/* 306 */           ParsingLocatorUtil.countChar(locator, c);
/* 307 */           i++;
/* 308 */           return i < maxi ? i : -1;
/*     */         }
/* 310 */         inApos = true;
/* 311 */       } else if ((!inQuotes) && (!inApos)) {
/* 312 */         return i;
/*     */       }
/*     */       
/* 315 */       ParsingLocatorUtil.countChar(locator, c);
/*     */       
/* 317 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 321 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findCharacterSequence(char[] text, int offset, int maxi, int[] locator, char[] charSeq)
/*     */   {
/* 332 */     if ((charSeq == null) || (charSeq.length == 0)) {
/* 333 */       return offset;
/*     */     }
/*     */     
/* 336 */     char c1 = charSeq[0];
/*     */     
/*     */ 
/* 339 */     int i = offset;
/* 340 */     int n = maxi - offset;
/*     */     
/* 342 */     while (n-- != 0)
/*     */     {
/* 344 */       char c = text[i];
/*     */       
/* 346 */       if (c == c1)
/*     */       {
/*     */ 
/* 349 */         for (int j = 1; 
/* 350 */             (j < charSeq.length) && (i + j < maxi); j++) {
/* 351 */           if (text[(i + j)] != charSeq[j]) {
/*     */             break;
/*     */           }
/*     */         }
/* 355 */         if (j >= charSeq.length) {
/* 356 */           return i;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 361 */       ParsingLocatorUtil.countChar(locator, c);
/*     */       
/* 363 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 367 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\ParsingMarkupUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */