/*    */ package org.attoparser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParsingLocatorUtil
/*    */ {
/*    */   public static void countChar(int[] locator, char c)
/*    */   {
/* 33 */     if (c == '\n') {
/* 34 */       locator[0] += 1;
/* 35 */       locator[1] = 1;
/* 36 */       return;
/*    */     }
/* 38 */     locator[1] += 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\ParsingLocatorUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */