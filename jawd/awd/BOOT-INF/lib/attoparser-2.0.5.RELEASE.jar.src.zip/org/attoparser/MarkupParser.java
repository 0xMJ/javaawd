/*     */ package org.attoparser;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Arrays;
/*     */ import org.attoparser.config.ParseConfiguration;
/*     */ import org.attoparser.config.ParseConfiguration.ParsingMode;
/*     */ import org.attoparser.select.ParseSelection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MarkupParser
/*     */   implements IMarkupParser
/*     */ {
/*     */   public static final int DEFAULT_BUFFER_SIZE = 4096;
/*     */   public static final int DEFAULT_POOL_SIZE = 2;
/*     */   private final ParseConfiguration configuration;
/*     */   private final BufferPool pool;
/*     */   
/*     */   public MarkupParser(ParseConfiguration configuration)
/*     */   {
/* 130 */     this(configuration, 2, 4096);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MarkupParser(ParseConfiguration configuration, int poolSize, int bufferSize)
/*     */   {
/* 161 */     this.configuration = configuration;
/* 162 */     this.pool = new BufferPool(poolSize, bufferSize, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parse(String document, IMarkupHandler handler)
/*     */     throws ParseException
/*     */   {
/* 172 */     if (document == null) {
/* 173 */       throw new IllegalArgumentException("Document cannot be null");
/*     */     }
/* 175 */     parse(new StringReader(document), handler);
/*     */   }
/*     */   
/*     */   public void parse(char[] document, IMarkupHandler handler)
/*     */     throws ParseException
/*     */   {
/* 181 */     if (document == null) {
/* 182 */       throw new IllegalArgumentException("Document cannot be null");
/*     */     }
/* 184 */     parse(document, 0, document.length, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void parse(char[] document, int offset, int len, IMarkupHandler handler)
/*     */     throws ParseException
/*     */   {
/* 192 */     if (document == null) {
/* 193 */       throw new IllegalArgumentException("Document cannot be null");
/*     */     }
/* 195 */     if ((offset < 0) || (len < 0)) {
/* 196 */       throw new IllegalArgumentException("Neither document offset (" + offset + ") nor document length (" + len + ") can be less than zero");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 201 */     if (handler == null) {
/* 202 */       throw new IllegalArgumentException("Handler cannot be null");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 207 */     IMarkupHandler markupHandler = ParseConfiguration.ParsingMode.HTML.equals(this.configuration.getMode()) ? new HtmlMarkupHandler(handler) : handler;
/*     */     
/*     */ 
/*     */ 
/* 211 */     markupHandler = new MarkupEventProcessorHandler(markupHandler);
/*     */     
/* 213 */     markupHandler.setParseConfiguration(this.configuration);
/*     */     
/* 215 */     ParseStatus status = new ParseStatus();
/* 216 */     markupHandler.setParseStatus(status);
/*     */     
/* 218 */     ParseSelection selection = new ParseSelection();
/* 219 */     markupHandler.setParseSelection(selection);
/*     */     
/*     */ 
/* 222 */     parseDocument(document, offset, len, markupHandler, status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parse(Reader reader, IMarkupHandler handler)
/*     */     throws ParseException
/*     */   {
/* 232 */     if (reader == null) {
/* 233 */       throw new IllegalArgumentException("Reader cannot be null");
/*     */     }
/*     */     
/* 236 */     if (handler == null) {
/* 237 */       throw new IllegalArgumentException("Handler cannot be null");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 242 */     IMarkupHandler markupHandler = ParseConfiguration.ParsingMode.HTML.equals(this.configuration.getMode()) ? new HtmlMarkupHandler(handler) : handler;
/*     */     
/*     */ 
/*     */ 
/* 246 */     markupHandler = new MarkupEventProcessorHandler(markupHandler);
/*     */     
/* 248 */     markupHandler.setParseConfiguration(this.configuration);
/*     */     
/* 250 */     ParseStatus status = new ParseStatus();
/* 251 */     markupHandler.setParseStatus(status);
/*     */     
/* 253 */     ParseSelection selection = new ParseSelection();
/* 254 */     markupHandler.setParseSelection(selection);
/*     */     
/*     */ 
/* 257 */     parseDocument(reader, this.pool.poolBufferSize, markupHandler, status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void parseDocument(Reader reader, int suggestedBufferSize, IMarkupHandler handler, ParseStatus status)
/*     */     throws ParseException
/*     */   {
/* 275 */     long parsingStartTimeNanos = System.nanoTime();
/*     */     
/* 277 */     char[] buffer = null;
/*     */     
/*     */     try
/*     */     {
/* 281 */       handler.handleDocumentStart(parsingStartTimeNanos, 1, 1);
/*     */       
/* 283 */       int bufferSize = suggestedBufferSize;
/* 284 */       buffer = this.pool.allocateBuffer(bufferSize);
/*     */       
/* 286 */       int bufferContentSize = reader.read(buffer);
/*     */       
/* 288 */       boolean cont = bufferContentSize != -1;
/*     */       
/* 290 */       status.offset = -1;
/* 291 */       status.line = 1;
/* 292 */       status.col = 1;
/* 293 */       status.inStructure = false;
/* 294 */       status.parsingDisabled = true;
/* 295 */       status.parsingDisabledLimitSequence = null;
/* 296 */       status.autoCloseRequired = null;
/* 297 */       status.autoCloseLimits = null;
/*     */       
/* 299 */       while (cont)
/*     */       {
/* 301 */         parseBuffer(buffer, 0, bufferContentSize, handler, status);
/*     */         
/* 303 */         int readOffset = 0;
/* 304 */         int readLen = bufferSize;
/*     */         
/* 306 */         if (status.offset == 0)
/*     */         {
/* 308 */           if (bufferContentSize == bufferSize)
/*     */           {
/*     */ 
/* 311 */             char[] newBuffer = null;
/*     */             try
/*     */             {
/* 314 */               bufferSize *= 2;
/*     */               
/* 316 */               newBuffer = this.pool.allocateBuffer(bufferSize);
/* 317 */               System.arraycopy(buffer, 0, newBuffer, 0, bufferContentSize);
/*     */               
/* 319 */               this.pool.releaseBuffer(buffer);
/*     */               
/* 321 */               buffer = newBuffer;
/*     */             }
/*     */             catch (Exception ignored) {
/* 324 */               this.pool.releaseBuffer(newBuffer);
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 331 */           readOffset = bufferContentSize;
/* 332 */           readLen = bufferSize - readOffset;
/*     */         }
/* 334 */         else if (status.offset < bufferContentSize)
/*     */         {
/* 336 */           System.arraycopy(buffer, status.offset, buffer, 0, bufferContentSize - status.offset);
/*     */           
/* 338 */           readOffset = bufferContentSize - status.offset;
/* 339 */           readLen = bufferSize - readOffset;
/*     */           
/* 341 */           status.offset = 0;
/* 342 */           bufferContentSize = readOffset;
/*     */         }
/*     */         
/*     */ 
/* 346 */         int read = reader.read(buffer, readOffset, readLen);
/* 347 */         if (read != -1) {
/* 348 */           bufferContentSize = readOffset + read;
/*     */         } else {
/* 350 */           cont = false;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 357 */       int lastLine = status.line;
/* 358 */       int lastCol = status.col;
/*     */       
/* 360 */       int lastStart = status.offset;
/* 361 */       int lastLen = bufferContentSize - lastStart;
/*     */       
/* 363 */       if (lastLen > 0)
/*     */       {
/* 365 */         if (status.inStructure) {
/* 366 */           throw new ParseException("Incomplete structure: \"" + new String(buffer, lastStart, lastLen) + "\"", status.line, status.col);
/*     */         }
/*     */         
/*     */ 
/* 370 */         handler.handleText(buffer, lastStart, lastLen, status.line, status.col);
/*     */         
/*     */ 
/*     */ 
/* 374 */         for (int i = lastStart; i < lastStart + lastLen; i++) {
/* 375 */           char c = buffer[i];
/* 376 */           if (c == '\n') {
/* 377 */             lastLine++;
/* 378 */             lastCol = 1;
/*     */           } else {
/* 380 */             lastCol++;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 387 */       long parsingEndTimeNanos = System.nanoTime();
/* 388 */       handler.handleDocumentEnd(parsingEndTimeNanos, parsingEndTimeNanos - parsingStartTimeNanos, lastLine, lastCol); return;
/*     */     }
/*     */     catch (ParseException e) {
/* 391 */       throw e;
/*     */     } catch (Exception e) {
/* 393 */       throw new ParseException(e);
/*     */     } finally {
/* 395 */       this.pool.releaseBuffer(buffer);
/*     */       try {
/* 397 */         reader.close();
/*     */       }
/*     */       catch (Throwable localThrowable1) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void parseDocument(char[] buffer, int offset, int len, IMarkupHandler handler, ParseStatus status)
/*     */     throws ParseException
/*     */   {
/* 423 */     long parsingStartTimeNanos = System.nanoTime();
/*     */     
/*     */     try
/*     */     {
/* 427 */       handler.handleDocumentStart(parsingStartTimeNanos, 1, 1);
/*     */       
/* 429 */       status.offset = -1;
/* 430 */       status.line = 1;
/* 431 */       status.col = 1;
/* 432 */       status.inStructure = false;
/* 433 */       status.parsingDisabled = true;
/* 434 */       status.parsingDisabledLimitSequence = null;
/* 435 */       status.autoCloseRequired = null;
/* 436 */       status.autoCloseLimits = null;
/*     */       
/* 438 */       parseBuffer(buffer, offset, len, handler, status);
/*     */       
/*     */ 
/*     */ 
/* 442 */       int lastLine = status.line;
/* 443 */       int lastCol = status.col;
/*     */       
/* 445 */       int lastStart = status.offset;
/* 446 */       int lastLen = offset + len - lastStart;
/*     */       
/* 448 */       if (lastLen > 0)
/*     */       {
/* 450 */         if (status.inStructure) {
/* 451 */           throw new ParseException("Incomplete structure: \"" + new String(buffer, lastStart, lastLen) + "\"", status.line, status.col);
/*     */         }
/*     */         
/*     */ 
/* 455 */         handler.handleText(buffer, lastStart, lastLen, status.line, status.col);
/*     */         
/*     */ 
/*     */ 
/* 459 */         for (int i = lastStart; i < lastStart + lastLen; i++) {
/* 460 */           char c = buffer[i];
/* 461 */           if (c == '\n') {
/* 462 */             lastLine++;
/* 463 */             lastCol = 1;
/*     */           } else {
/* 465 */             lastCol++;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 472 */       long parsingEndTimeNanos = System.nanoTime();
/* 473 */       handler.handleDocumentEnd(parsingEndTimeNanos, parsingEndTimeNanos - parsingStartTimeNanos, lastLine, lastCol);
/*     */     }
/*     */     catch (ParseException e) {
/* 476 */       throw e;
/*     */     } catch (Exception e) {
/* 478 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parseBuffer(char[] buffer, int offset, int len, IMarkupHandler handler, ParseStatus status)
/*     */     throws ParseException
/*     */   {
/* 503 */     int[] locator = { status.line, status.col };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 508 */     int maxi = offset + len;
/* 509 */     int i = offset;
/* 510 */     int current = i;
/*     */     
/*     */ 
/*     */ 
/* 514 */     boolean inOpenElement = false;
/* 515 */     boolean inCloseElement = false;
/* 516 */     boolean inComment = false;
/* 517 */     boolean inCdata = false;
/* 518 */     boolean inDocType = false;
/* 519 */     boolean inXmlDeclaration = false;
/* 520 */     boolean inProcessingInstruction = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 525 */     while (i < maxi)
/*     */     {
/* 527 */       int currentLine = locator[0];
/* 528 */       int currentCol = locator[1];
/*     */       
/* 530 */       if (status.parsingDisabledLimitSequence != null)
/*     */       {
/*     */ 
/*     */ 
/* 534 */         int sequenceIndex = ParsingMarkupUtil.findCharacterSequence(buffer, i, maxi, locator, status.parsingDisabledLimitSequence);
/* 535 */         if (sequenceIndex == -1)
/*     */         {
/*     */ 
/* 538 */           if (this.configuration.isTextSplittable()) {
/* 539 */             handler.handleText(buffer, current, len - current, currentLine, currentCol);
/*     */             
/* 541 */             current = len;
/*     */           }
/*     */           
/* 544 */           status.offset = current;
/* 545 */           status.line = currentLine;
/* 546 */           status.col = currentCol;
/* 547 */           status.inStructure = false;
/* 548 */           return;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 557 */         handler.handleText(buffer, current, sequenceIndex - current, currentLine, currentCol);
/* 558 */         status.parsingDisabledLimitSequence = null;
/* 559 */         status.parsingDisabled = true;
/*     */         
/* 561 */         current = sequenceIndex;
/* 562 */         i = current;
/*     */       }
/*     */       
/*     */ 
/* 566 */       boolean inStructure = (inOpenElement) || (inCloseElement) || (inComment) || (inCdata) || (inDocType) || (inXmlDeclaration) || (inProcessingInstruction);
/*     */       
/*     */ 
/* 569 */       if (!inStructure)
/*     */       {
/* 571 */         int tagStart = ParsingMarkupUtil.findNextStructureStart(buffer, i, maxi, locator);
/*     */         
/* 573 */         if (tagStart == -1)
/*     */         {
/* 575 */           if (this.configuration.isTextSplittable())
/*     */           {
/* 577 */             handler.handleText(buffer, current, len - current, currentLine, currentCol);
/* 578 */             if (status.parsingDisabledLimitSequence != null) {
/* 579 */               status.parsingDisabled = false;
/*     */             }
/*     */             
/* 582 */             current = len;
/*     */           }
/*     */           
/*     */ 
/* 586 */           status.offset = current;
/* 587 */           status.line = currentLine;
/* 588 */           status.col = currentCol;
/* 589 */           status.inStructure = false;
/* 590 */           return;
/*     */         }
/*     */         
/*     */ 
/* 594 */         inOpenElement = ParsingElementMarkupUtil.isOpenElementStart(buffer, tagStart, maxi);
/* 595 */         if (!inOpenElement) {
/* 596 */           inCloseElement = ParsingElementMarkupUtil.isCloseElementStart(buffer, tagStart, maxi);
/* 597 */           if (!inCloseElement) {
/* 598 */             inComment = ParsingCommentMarkupUtil.isCommentStart(buffer, tagStart, maxi);
/* 599 */             if (!inComment) {
/* 600 */               inCdata = ParsingCDATASectionMarkupUtil.isCDATASectionStart(buffer, tagStart, maxi);
/* 601 */               if (!inCdata) {
/* 602 */                 inDocType = ParsingDocTypeMarkupUtil.isDocTypeStart(buffer, tagStart, maxi);
/* 603 */                 if (!inDocType) {
/* 604 */                   inXmlDeclaration = ParsingXmlDeclarationMarkupUtil.isXmlDeclarationStart(buffer, tagStart, maxi);
/* 605 */                   if (!inXmlDeclaration) {
/* 606 */                     inProcessingInstruction = ParsingProcessingInstructionUtil.isProcessingInstructionStart(buffer, tagStart, maxi);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 614 */         inStructure = (inOpenElement) || (inCloseElement) || (inComment) || (inCdata) || (inDocType) || (inXmlDeclaration) || (inProcessingInstruction);
/*     */         
/*     */ 
/*     */ 
/* 618 */         while (!inStructure)
/*     */         {
/*     */ 
/*     */ 
/* 622 */           ParsingLocatorUtil.countChar(locator, buffer[tagStart]);
/* 623 */           tagStart = ParsingMarkupUtil.findNextStructureStart(buffer, tagStart + 1, maxi, locator);
/*     */           
/* 625 */           if (tagStart == -1) {
/* 626 */             status.offset = current;
/* 627 */             status.line = currentLine;
/* 628 */             status.col = currentCol;
/* 629 */             status.inStructure = false;
/* 630 */             return;
/*     */           }
/*     */           
/* 633 */           inOpenElement = ParsingElementMarkupUtil.isOpenElementStart(buffer, tagStart, maxi);
/* 634 */           if (!inOpenElement) {
/* 635 */             inCloseElement = ParsingElementMarkupUtil.isCloseElementStart(buffer, tagStart, maxi);
/* 636 */             if (!inCloseElement) {
/* 637 */               inComment = ParsingCommentMarkupUtil.isCommentStart(buffer, tagStart, maxi);
/* 638 */               if (!inComment) {
/* 639 */                 inCdata = ParsingCDATASectionMarkupUtil.isCDATASectionStart(buffer, tagStart, maxi);
/* 640 */                 if (!inCdata) {
/* 641 */                   inDocType = ParsingDocTypeMarkupUtil.isDocTypeStart(buffer, tagStart, maxi);
/* 642 */                   if (!inDocType) {
/* 643 */                     inXmlDeclaration = ParsingXmlDeclarationMarkupUtil.isXmlDeclarationStart(buffer, tagStart, maxi);
/* 644 */                     if (!inXmlDeclaration) {
/* 645 */                       inProcessingInstruction = ParsingProcessingInstructionUtil.isProcessingInstructionStart(buffer, tagStart, maxi);
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */           
/* 653 */           inStructure = (inOpenElement) || (inCloseElement) || (inComment) || (inCdata) || (inDocType) || (inXmlDeclaration) || (inProcessingInstruction);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 659 */         if (tagStart > current)
/*     */         {
/*     */ 
/* 662 */           handler.handleText(buffer, current, tagStart - current, currentLine, currentCol);
/*     */           
/*     */ 
/*     */ 
/* 666 */           if (status.parsingDisabledLimitSequence != null) {
/* 667 */             status.parsingDisabled = false;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 672 */         current = tagStart;
/* 673 */         i = current;
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 680 */         boolean avoidQuotes = (inOpenElement) || (inCloseElement) || (inDocType) || (inXmlDeclaration);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 689 */         int tagEnd = avoidQuotes ? ParsingMarkupUtil.findNextStructureEndAvoidQuotes(buffer, i, maxi, locator) : inDocType ? ParsingDocTypeMarkupUtil.findNextDocTypeStructureEnd(buffer, i, maxi, locator) : ParsingMarkupUtil.findNextStructureEndDontAvoidQuotes(buffer, i, maxi, locator);
/*     */         
/* 691 */         if (tagEnd < 0)
/*     */         {
/* 693 */           status.offset = current;
/* 694 */           status.line = currentLine;
/* 695 */           status.col = currentCol;
/* 696 */           status.inStructure = true;
/* 697 */           return;
/*     */         }
/*     */         
/*     */ 
/* 701 */         if (inOpenElement)
/*     */         {
/*     */ 
/* 704 */           if (buffer[(tagEnd - 1)] == '/')
/*     */           {
/* 706 */             ParsingElementMarkupUtil.parseStandaloneElement(buffer, current, tagEnd - current + 1, currentLine, currentCol, handler);
/*     */           }
/*     */           else
/*     */           {
/* 710 */             ParsingElementMarkupUtil.parseOpenElement(buffer, current, tagEnd - current + 1, currentLine, currentCol, handler);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 715 */           if (status.parsingDisabledLimitSequence != null) {
/* 716 */             status.parsingDisabled = false;
/*     */           }
/*     */           
/* 719 */           inOpenElement = false;
/*     */         }
/* 721 */         else if (inCloseElement)
/*     */         {
/*     */ 
/*     */ 
/* 725 */           ParsingElementMarkupUtil.parseCloseElement(buffer, current, tagEnd - current + 1, currentLine, currentCol, handler);
/*     */           
/*     */ 
/* 728 */           if (status.parsingDisabledLimitSequence != null) {
/* 729 */             status.parsingDisabled = false;
/*     */           }
/*     */           
/* 732 */           inCloseElement = false;
/*     */         }
/* 734 */         else if (inComment)
/*     */         {
/*     */ 
/* 737 */           while ((tagEnd - current < 6) || (buffer[(tagEnd - 1)] != '-') || (buffer[(tagEnd - 2)] != '-'))
/*     */           {
/*     */ 
/* 740 */             ParsingLocatorUtil.countChar(locator, buffer[tagEnd]);
/* 741 */             tagEnd = ParsingMarkupUtil.findNextStructureEndDontAvoidQuotes(buffer, tagEnd + 1, maxi, locator);
/*     */             
/* 743 */             if (tagEnd == -1) {
/* 744 */               status.offset = current;
/* 745 */               status.line = currentLine;
/* 746 */               status.col = currentCol;
/* 747 */               status.inStructure = true;
/* 748 */               return;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 753 */           ParsingCommentMarkupUtil.parseComment(buffer, current, tagEnd - current + 1, currentLine, currentCol, handler);
/*     */           
/* 755 */           if (status.parsingDisabledLimitSequence != null) {
/* 756 */             status.parsingDisabled = false;
/*     */           }
/*     */           
/* 759 */           inComment = false;
/*     */         }
/* 761 */         else if (inCdata)
/*     */         {
/*     */ 
/* 764 */           while ((tagEnd - current < 11) || (buffer[(tagEnd - 1)] != ']') || (buffer[(tagEnd - 2)] != ']'))
/*     */           {
/*     */ 
/* 767 */             ParsingLocatorUtil.countChar(locator, buffer[tagEnd]);
/* 768 */             tagEnd = ParsingMarkupUtil.findNextStructureEndDontAvoidQuotes(buffer, tagEnd + 1, maxi, locator);
/*     */             
/* 770 */             if (tagEnd == -1) {
/* 771 */               status.offset = current;
/* 772 */               status.line = currentLine;
/* 773 */               status.col = currentCol;
/* 774 */               status.inStructure = true;
/* 775 */               return;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 780 */           ParsingCDATASectionMarkupUtil.parseCDATASection(buffer, current, tagEnd - current + 1, currentLine, currentCol, handler);
/*     */           
/* 782 */           if (status.parsingDisabledLimitSequence != null) {
/* 783 */             status.parsingDisabled = false;
/*     */           }
/*     */           
/* 786 */           inCdata = false;
/*     */         }
/* 788 */         else if (inDocType)
/*     */         {
/*     */ 
/* 791 */           ParsingDocTypeMarkupUtil.parseDocType(buffer, current, tagEnd - current + 1, currentLine, currentCol, handler);
/*     */           
/*     */ 
/* 794 */           if (status.parsingDisabledLimitSequence != null) {
/* 795 */             status.parsingDisabled = false;
/*     */           }
/*     */           
/* 798 */           inDocType = false;
/*     */         }
/* 800 */         else if (inXmlDeclaration)
/*     */         {
/*     */ 
/* 803 */           ParsingXmlDeclarationMarkupUtil.parseXmlDeclaration(buffer, current, tagEnd - current + 1, currentLine, currentCol, handler);
/*     */           
/*     */ 
/* 806 */           if (status.parsingDisabledLimitSequence != null) {
/* 807 */             status.parsingDisabled = false;
/*     */           }
/*     */           
/* 810 */           inXmlDeclaration = false;
/*     */         }
/* 812 */         else if (inProcessingInstruction)
/*     */         {
/*     */ 
/* 815 */           while ((tagEnd - current < 5) || (buffer[(tagEnd - 1)] != '?'))
/*     */           {
/*     */ 
/* 818 */             ParsingLocatorUtil.countChar(locator, buffer[tagEnd]);
/* 819 */             tagEnd = ParsingMarkupUtil.findNextStructureEndDontAvoidQuotes(buffer, tagEnd + 1, maxi, locator);
/*     */             
/* 821 */             if (tagEnd == -1) {
/* 822 */               status.offset = current;
/* 823 */               status.line = currentLine;
/* 824 */               status.col = currentCol;
/* 825 */               status.inStructure = true;
/* 826 */               return;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 831 */           ParsingProcessingInstructionUtil.parseProcessingInstruction(buffer, current, tagEnd - current + 1, currentLine, currentCol, handler);
/*     */           
/*     */ 
/* 834 */           if (status.parsingDisabledLimitSequence != null) {
/* 835 */             status.parsingDisabled = false;
/*     */           }
/*     */           
/* 838 */           inProcessingInstruction = false;
/*     */         }
/*     */         else
/*     */         {
/* 842 */           throw new IllegalStateException("Illegal parsing state: structure is not of a recognized type");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 848 */         ParsingLocatorUtil.countChar(locator, buffer[tagEnd]);
/*     */         
/* 850 */         current = tagEnd + 1;
/* 851 */         i = current;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 857 */     status.offset = current;
/* 858 */     status.line = locator[0];
/* 859 */     status.col = locator[1];
/* 860 */     status.inStructure = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class BufferPool
/*     */   {
/*     */     private final char[][] pool;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private final boolean[] allocated;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private final int poolBufferSize;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private BufferPool(int poolSize, int poolBufferSize)
/*     */     {
/* 888 */       this.pool = new char[poolSize][];
/* 889 */       this.allocated = new boolean[poolSize];
/* 890 */       this.poolBufferSize = poolBufferSize;
/*     */       
/* 892 */       for (int i = 0; i < this.pool.length; i++) {
/* 893 */         this.pool[i] = new char[this.poolBufferSize];
/*     */       }
/* 895 */       Arrays.fill(this.allocated, false);
/*     */     }
/*     */     
/*     */     private synchronized char[] allocateBuffer(int bufferSize)
/*     */     {
/* 900 */       if (bufferSize != this.poolBufferSize)
/*     */       {
/*     */ 
/* 903 */         return new char[bufferSize];
/*     */       }
/* 905 */       for (int i = 0; i < this.pool.length; i++) {
/* 906 */         if (this.allocated[i] == 0) {
/* 907 */           this.allocated[i] = true;
/* 908 */           return this.pool[i];
/*     */         }
/*     */       }
/* 911 */       return new char[bufferSize];
/*     */     }
/*     */     
/*     */     private synchronized void releaseBuffer(char[] buffer) {
/* 915 */       if (buffer == null) {
/* 916 */         return;
/*     */       }
/* 918 */       if (buffer.length != this.poolBufferSize)
/*     */       {
/* 920 */         return;
/*     */       }
/* 922 */       for (int i = 0; i < this.pool.length; i++) {
/* 923 */         if (this.pool[i] == buffer)
/*     */         {
/* 925 */           this.allocated[i] = false;
/* 926 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\MarkupParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */