/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParsingXmlDeclarationMarkupUtil
/*     */ {
/*     */   public static void parseXmlDeclaration(char[] buffer, int offset, int len, int line, int col, IXMLDeclarationHandler handler)
/*     */     throws ParseException
/*     */   {
/*  54 */     if ((len < 7) || (!isXmlDeclarationStart(buffer, offset, offset + len)) || (!isXmlDeclarationEnd(buffer, offset + len - 2, offset + len))) {
/*  55 */       throw new ParseException("Could not parse as a well-formed XML Declaration: \"" + new String(buffer, offset, len) + "\"", line, col);
/*     */     }
/*     */     
/*     */ 
/*  59 */     int internalOffset = offset + 2;
/*  60 */     int internalLen = len - 4;
/*     */     
/*  62 */     int maxi = internalOffset + internalLen;
/*     */     
/*  64 */     int[] locator = { line, col + 2 };
/*     */     
/*  66 */     int keywordLine = locator[0];
/*  67 */     int keywordCol = locator[1];
/*     */     
/*  69 */     int i = internalOffset;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */     int keywordEnd = ParsingMarkupUtil.findNextWhitespaceCharWildcard(buffer, i, maxi, false, locator);
/*     */     
/*  78 */     if (keywordEnd == -1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  83 */       throw new ParseException("XML Declaration must at least contain a \"version\" attribute: \"" + new String(buffer, offset, len) + "\"", line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */     int keywordOffset = i;
/*  91 */     int keywordLen = keywordEnd - keywordOffset;
/*     */     
/*  93 */     i = keywordEnd;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     int contentOffset = ParsingMarkupUtil.findNextNonWhitespaceCharWildcard(buffer, i, maxi, locator);
/*     */     
/* 103 */     if (contentOffset == -1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 108 */       throw new ParseException("XML Declaration must at least contain a \"version\" attribute: \"" + new String(buffer, offset, len) + "\"", line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 114 */     int contentLen = maxi - contentOffset;
/*     */     
/* 116 */     XmlDeclarationAttributeProcessor attHandling = new XmlDeclarationAttributeProcessor(offset, len, line, col);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 121 */     ParsingAttributeSequenceUtil.parseAttributeSequence(buffer, contentOffset, contentLen, locator[0], locator[1], attHandling);
/*     */     
/*     */ 
/* 124 */     ParsingMarkupUtil.findNextStructureEndAvoidQuotes(buffer, contentOffset, maxi, locator);
/*     */     
/* 126 */     attHandling.finalChecks(locator, buffer);
/*     */     
/*     */ 
/* 129 */     handler.handleXmlDeclaration(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, attHandling.versionOffset, attHandling.versionLen, attHandling.versionLine, attHandling.versionCol, attHandling.encodingOffset, attHandling.encodingLen, attHandling.encodingLine, attHandling.encodingCol, attHandling.standaloneOffset, attHandling.standaloneLen, attHandling.standaloneLine, attHandling.standaloneCol, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean isXmlDeclarationStart(char[] buffer, int offset, int maxi)
/*     */   {
/* 151 */     if ((maxi - offset > 5) && (buffer[offset] == '<') && (buffer[(offset + 1)] == '?') && (buffer[(offset + 2)] == 'x') && (buffer[(offset + 3)] == 'm') && (buffer[(offset + 4)] == 'l')) {} return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */       (Character.isWhitespace(buffer[(offset + 5)])) || ((maxi - offset > 6) && (buffer[(offset + 5)] == '?') && (buffer[(offset + 6)] == '>'));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static boolean isXmlDeclarationEnd(char[] buffer, int offset, int maxi)
/*     */   {
/* 164 */     return (maxi - offset > 1) && (buffer[offset] == '?') && (buffer[(offset + 1)] == '>');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class XmlDeclarationAttributeProcessor
/*     */     implements IAttributeSequenceHandler
/*     */   {
/*     */     private final int outerOffset;
/*     */     
/*     */ 
/*     */     private final int outerLen;
/*     */     
/*     */ 
/*     */     private final int outerLine;
/*     */     
/*     */ 
/*     */     private final int outerCol;
/*     */     
/*     */ 
/* 185 */     static final char[] VERSION = "version".toCharArray();
/* 186 */     boolean versionPresent = false;
/* 187 */     int versionOffset = 0;
/* 188 */     int versionLen = 0;
/* 189 */     int versionLine = -1;
/* 190 */     int versionCol = -1;
/*     */     
/* 192 */     static final char[] ENCODING = "encoding".toCharArray();
/* 193 */     boolean encodingPresent = false;
/* 194 */     int encodingOffset = 0;
/* 195 */     int encodingLen = 0;
/* 196 */     int encodingLine = -1;
/* 197 */     int encodingCol = -1;
/*     */     
/* 199 */     static final char[] STANDALONE = "standalone".toCharArray();
/* 200 */     boolean standalonePresent = false;
/* 201 */     int standaloneOffset = 0;
/* 202 */     int standaloneLen = 0;
/* 203 */     int standaloneLine = -1;
/* 204 */     int standaloneCol = -1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     XmlDeclarationAttributeProcessor(int outerOffset, int outerLen, int outerLine, int outerCol)
/*     */     {
/* 211 */       this.outerOffset = outerOffset;
/* 212 */       this.outerLen = outerLen;
/* 213 */       this.outerLine = outerLine;
/* 214 */       this.outerCol = outerCol;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */       throws ParseException
/*     */     {
/* 228 */       if (charArrayEquals(buffer, nameOffset, nameLen, VERSION, 0, VERSION.length)) {
/* 229 */         if (this.versionPresent) {
/* 230 */           throw new ParseException("XML Declaration can declare only one \"version\" attribute: \"" + new String(buffer, this.outerOffset, this.outerLen) + "\"", this.outerLine, this.outerCol);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 235 */         if ((this.encodingPresent) || (this.standalonePresent)) {
/* 236 */           throw new ParseException("XML Declaration must declare \"version\" as its first attribute: \"" + new String(buffer, this.outerOffset, this.outerLen) + "\"", this.outerLine, this.outerCol);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 241 */         this.versionOffset = valueContentOffset;
/* 242 */         this.versionLen = valueContentLen;
/* 243 */         this.versionLine = valueLine;
/* 244 */         this.versionCol = valueCol;
/* 245 */         this.versionPresent = true;
/* 246 */         return;
/*     */       }
/*     */       
/* 249 */       if (charArrayEquals(buffer, nameOffset, nameLen, ENCODING, 0, ENCODING.length)) {
/* 250 */         if (this.encodingPresent) {
/* 251 */           throw new ParseException("XML Declaration can declare only one \"encoding\" attribute: \"" + new String(buffer, this.outerOffset, this.outerLen) + "\"", this.outerLine, this.outerCol);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 256 */         if (!this.versionPresent) {
/* 257 */           throw new ParseException("XML Declaration must declare \"encoding\" after \"version\": \"" + new String(buffer, this.outerOffset, this.outerLen) + "\"", this.outerLine, this.outerCol);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 262 */         if (this.standalonePresent) {
/* 263 */           throw new ParseException("XML Declaration must declare \"encoding\" before \"standalone\": \"" + new String(buffer, this.outerOffset, this.outerLen) + "\"", this.outerLine, this.outerCol);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 268 */         this.encodingOffset = valueContentOffset;
/* 269 */         this.encodingLen = valueContentLen;
/* 270 */         this.encodingLine = valueLine;
/* 271 */         this.encodingCol = valueCol;
/* 272 */         this.encodingPresent = true;
/* 273 */         return;
/*     */       }
/*     */       
/* 276 */       if (charArrayEquals(buffer, nameOffset, nameLen, STANDALONE, 0, STANDALONE.length)) {
/* 277 */         if (this.standalonePresent) {
/* 278 */           throw new ParseException("XML Declaration can declare only one \"standalone\" attribute: \"" + new String(buffer, this.outerOffset, this.outerLen) + "\"", this.outerLine, this.outerCol);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 283 */         this.standaloneOffset = valueContentOffset;
/* 284 */         this.standaloneLen = valueContentLen;
/* 285 */         this.standaloneLine = valueLine;
/* 286 */         this.standaloneCol = valueCol;
/* 287 */         this.standalonePresent = true;
/* 288 */         return;
/*     */       }
/*     */       
/* 291 */       throw new ParseException("XML Declaration does not allow attribute with name \"" + new String(buffer, nameOffset, nameLen) + "\". Only \"version\", \"encoding\" and \"standalone\" are allowed (in that order): \"" + new String(buffer, this.outerOffset, this.outerLen) + "\"", this.outerLine, this.outerCol);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*     */       throws ParseException
/*     */     {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void finalChecks(int[] locator, char[] buffer)
/*     */       throws ParseException
/*     */     {
/* 311 */       if (!this.versionPresent) {
/* 312 */         throw new ParseException("Attribute \"version\" is required in XML Declaration: \"" + new String(buffer, this.outerOffset, this.outerLen) + "\"", this.outerLine, this.outerLine);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 317 */       if (!this.standalonePresent) {
/* 318 */         this.standaloneLine = locator[0];
/* 319 */         this.standaloneCol = locator[1];
/*     */       }
/* 321 */       if (!this.encodingPresent) {
/* 322 */         if (!this.standalonePresent) {
/* 323 */           this.encodingLine = locator[0];
/* 324 */           this.encodingCol = locator[1];
/*     */         } else {
/* 326 */           this.encodingLine = this.standaloneLine;
/* 327 */           this.encodingCol = this.standaloneCol;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private static boolean charArrayEquals(char[] arr1, int arr1Offset, int arr1Len, char[] arr2, int arr2Offset, int arr2Len)
/*     */     {
/* 338 */       if (arr1Len != arr2Len) {
/* 339 */         return false;
/*     */       }
/* 341 */       for (int i = 0; i < arr1Len; i++) {
/* 342 */         if (arr1[(arr1Offset + i)] != arr2[(arr2Offset + i)]) {
/* 343 */           return false;
/*     */         }
/*     */       }
/* 346 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\ParsingXmlDeclarationMarkupUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */