/*     */ package org.attoparser.output;
/*     */ 
/*     */ import java.io.Writer;
/*     */ import org.attoparser.AbstractMarkupHandler;
/*     */ import org.attoparser.ParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OutputMarkupHandler
/*     */   extends AbstractMarkupHandler
/*     */ {
/*     */   private final Writer writer;
/*     */   
/*     */   public OutputMarkupHandler(Writer writer)
/*     */   {
/*  76 */     if (writer == null) {
/*  77 */       throw new IllegalArgumentException("Writer cannot be null");
/*     */     }
/*  79 */     this.writer = writer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/*  92 */       this.writer.write(buffer, offset, len);
/*     */     } catch (Exception e) {
/*  94 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 110 */       this.writer.write(buffer, outerOffset, outerLen);
/*     */     } catch (Exception e) {
/* 112 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCDATASection(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 127 */       this.writer.write(buffer, outerOffset, outerLen);
/*     */     } catch (Exception e) {
/* 129 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int offset, int len, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 143 */       this.writer.write(60);
/* 144 */       this.writer.write(buffer, offset, len);
/*     */     } catch (Exception e) {
/* 146 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int offset, int len, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 160 */       if (minimized) {
/* 161 */         this.writer.write(47);
/*     */       }
/* 163 */       this.writer.write(62);
/*     */     } catch (Exception e) {
/* 165 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 179 */       this.writer.write(60);
/* 180 */       this.writer.write(buffer, offset, len);
/*     */     } catch (Exception e) {
/* 182 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 196 */       this.writer.write(62);
/*     */     } catch (Exception e) {
/* 198 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementStart(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementEnd(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 231 */       this.writer.write("</");
/* 232 */       this.writer.write(buffer, offset, len);
/*     */     } catch (Exception e) {
/* 234 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 248 */       this.writer.write(62);
/*     */     } catch (Exception e) {
/* 250 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementStart(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementEnd(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementStart(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 287 */     handleCloseElementStart(buffer, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementEnd(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 299 */     handleCloseElementEnd(buffer, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 313 */       this.writer.write(buffer, nameOffset, nameLen);
/* 314 */       this.writer.write(buffer, operatorOffset, operatorLen);
/* 315 */       this.writer.write(buffer, valueOuterOffset, valueOuterLen);
/*     */     } catch (Exception e) {
/* 317 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 333 */       this.writer.write(buffer, offset, len);
/*     */     } catch (Exception e) {
/* 335 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocType(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int elementNameOffset, int elementNameLen, int elementNameLine, int elementNameCol, int typeOffset, int typeLen, int typeLine, int typeCol, int publicIdOffset, int publicIdLen, int publicIdLine, int publicIdCol, int systemIdOffset, int systemIdLen, int systemIdLine, int systemIdCol, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, int outerOffset, int outerLen, int outerLine, int outerCol)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 362 */       this.writer.write(buffer, outerOffset, outerLen);
/*     */     } catch (Exception e) {
/* 364 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleXmlDeclaration(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int versionOffset, int versionLen, int versionLine, int versionCol, int encodingOffset, int encodingLen, int encodingLine, int encodingCol, int standaloneOffset, int standaloneLen, int standaloneLine, int standaloneCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 388 */       this.writer.write(buffer, outerOffset, outerLen);
/*     */     } catch (Exception e) {
/* 390 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleProcessingInstruction(char[] buffer, int targetOffset, int targetLen, int targetLine, int targetCol, int contentOffset, int contentLen, int contentLine, int contentCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 412 */       this.writer.write(buffer, outerOffset, outerLen);
/*     */     } catch (Exception e) {
/* 414 */       throw new ParseException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\output\OutputMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */