/*    */ package org.attoparser.output;
/*    */ 
/*    */ import java.io.Writer;
/*    */ import org.attoparser.AbstractMarkupHandler;
/*    */ import org.attoparser.ParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TextOutputMarkupHandler
/*    */   extends AbstractMarkupHandler
/*    */ {
/*    */   private final Writer writer;
/*    */   
/*    */   public TextOutputMarkupHandler(Writer writer)
/*    */   {
/* 70 */     if (writer == null) {
/* 71 */       throw new IllegalArgumentException("Writer cannot be null");
/*    */     }
/* 73 */     this.writer = writer;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*    */     throws ParseException
/*    */   {
/*    */     try
/*    */     {
/* 86 */       this.writer.write(buffer, offset, len);
/*    */     } catch (Exception e) {
/* 88 */       throw new ParseException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\output\TextOutputMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */