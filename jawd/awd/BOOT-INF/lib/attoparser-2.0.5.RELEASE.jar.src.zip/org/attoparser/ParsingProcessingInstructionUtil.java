/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParsingProcessingInstructionUtil
/*     */ {
/*     */   public static void parseProcessingInstruction(char[] buffer, int offset, int len, int line, int col, IProcessingInstructionHandler handler)
/*     */     throws ParseException
/*     */   {
/*  50 */     if ((len < 4) || (!isProcessingInstructionStart(buffer, offset, offset + len)) || (!isProcessingInstructionEnd(buffer, offset + len - 2, offset + len))) {
/*  51 */       throw new ParseException("Could not parse as a well-formed Processing Instruction: \"" + new String(buffer, offset, len) + "\"", line, col);
/*     */     }
/*     */     
/*     */ 
/*  55 */     int contentOffset = offset + 2;
/*  56 */     int contentLen = len - 4;
/*     */     
/*  58 */     int maxi = contentOffset + contentLen;
/*     */     
/*  60 */     int[] locator = { line, col + 2 };
/*     */     
/*  62 */     int i = contentOffset;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */     int targetEnd = ParsingMarkupUtil.findNextWhitespaceCharWildcard(buffer, i, maxi, false, locator);
/*     */     
/*  71 */     if (targetEnd == -1)
/*     */     {
/*     */ 
/*  74 */       handler.handleProcessingInstruction(buffer, i, maxi - i, line, col + 2, 0, 0, locator[0], locator[1], offset, len, line, col);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  88 */     int targetOffset = i;
/*  89 */     int targetLen = targetEnd - targetOffset;
/*     */     
/*  91 */     i = targetEnd;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     int contentStart = ParsingMarkupUtil.findNextNonWhitespaceCharWildcard(buffer, i, maxi, locator);
/*     */     
/* 101 */     if (contentStart == -1)
/*     */     {
/*     */ 
/* 104 */       handler.handleProcessingInstruction(buffer, targetOffset, targetLen, line, col + 2, 0, 0, locator[0], locator[1], offset, len, line, col);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 117 */     handler.handleProcessingInstruction(buffer, targetOffset, targetLen, line, col + 2, contentStart, maxi - contentStart, locator[0], locator[1], offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean isProcessingInstructionStart(char[] buffer, int offset, int maxi)
/*     */   {
/* 132 */     int len = maxi - offset;
/*     */     
/* 134 */     if (len > 5)
/*     */     {
/*     */ 
/* 137 */       if ((buffer[offset] == '<') && (buffer[(offset + 1)] == '?') && (buffer[(offset + 2)] != ' ')) {} return 
/*     */       
/* 139 */         (!Character.isWhitespace(buffer[(offset + 2)])) && ((buffer[(offset + 2)] != 'x') || (buffer[(offset + 3)] != 'm') || (buffer[(offset + 4)] != 'l') || 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 144 */         (!Character.isWhitespace(buffer[(offset + 5)])));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 149 */     if ((len > 2) && (buffer[offset] == '<') && (buffer[(offset + 1)] == '?') && (buffer[(offset + 2)] != ' ')) {} return 
/*     */     
/*     */ 
/* 152 */       !Character.isWhitespace(buffer[(offset + 2)]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static boolean isProcessingInstructionEnd(char[] buffer, int offset, int maxi)
/*     */   {
/* 159 */     return (maxi - offset > 1) && (buffer[offset] == '?') && (buffer[(offset + 1)] == '>');
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\ParsingProcessingInstructionUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */