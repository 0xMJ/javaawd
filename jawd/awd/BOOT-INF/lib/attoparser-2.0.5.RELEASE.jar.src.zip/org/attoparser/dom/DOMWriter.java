/*     */ package org.attoparser.dom;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMWriter
/*     */ {
/*     */   public static void write(INode node, Writer writer)
/*     */     throws IOException
/*     */   {
/*  45 */     if (node == null) {
/*  46 */       return;
/*     */     }
/*     */     
/*  49 */     if ((node instanceof Text)) {
/*  50 */       writeText((Text)node, writer);
/*  51 */       return;
/*     */     }
/*  53 */     if ((node instanceof Element)) {
/*  54 */       writeElement((Element)node, writer);
/*  55 */       return;
/*     */     }
/*  57 */     if ((node instanceof Comment)) {
/*  58 */       writeComment((Comment)node, writer);
/*  59 */       return;
/*     */     }
/*  61 */     if ((node instanceof CDATASection)) {
/*  62 */       writeCDATASection((CDATASection)node, writer);
/*  63 */       return;
/*     */     }
/*  65 */     if ((node instanceof DocType)) {
/*  66 */       writeDocType((DocType)node, writer);
/*  67 */       return;
/*     */     }
/*  69 */     if ((node instanceof Document)) {
/*  70 */       writeDocument((Document)node, writer);
/*  71 */       return;
/*     */     }
/*  73 */     if ((node instanceof XmlDeclaration)) {
/*  74 */       writeXmlDeclaration((XmlDeclaration)node, writer);
/*  75 */       return;
/*     */     }
/*  77 */     if ((node instanceof ProcessingInstruction)) {
/*  78 */       writeProcessingInstruction((ProcessingInstruction)node, writer);
/*  79 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeCDATASection(CDATASection cdataSection, Writer writer)
/*     */     throws IOException
/*     */   {
/*  89 */     writer.write("<![CDATA[");
/*  90 */     writer.write(cdataSection.getContent());
/*  91 */     writer.write("]]>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void writeComment(Comment comment, Writer writer)
/*     */     throws IOException
/*     */   {
/*  99 */     writer.write("<!--");
/* 100 */     writer.write(comment.getContent());
/* 101 */     writer.write("-->");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void writeDocType(DocType docType, Writer writer)
/*     */     throws IOException
/*     */   {
/* 109 */     writer.write("<!DOCTYPE ");
/* 110 */     writer.write(docType.getRootElementName());
/*     */     
/* 112 */     String publicId = docType.getPublicId();
/* 113 */     String systemId = docType.getSystemId();
/* 114 */     String internalSubset = docType.getInternalSubset();
/*     */     
/* 116 */     if ((publicId != null) || (systemId != null))
/*     */     {
/* 118 */       String type = publicId == null ? "SYSTEM" : "PUBLIC";
/*     */       
/* 120 */       writer.write(32);
/* 121 */       writer.write(type);
/*     */       
/* 123 */       if (publicId != null) {
/* 124 */         writer.write(32);
/* 125 */         writer.write(34);
/* 126 */         writer.write(publicId);
/* 127 */         writer.write(34);
/*     */       }
/*     */       
/* 130 */       if (systemId != null) {
/* 131 */         writer.write(32);
/* 132 */         writer.write(34);
/* 133 */         writer.write(systemId);
/* 134 */         writer.write(34);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 139 */     if (internalSubset != null) {
/* 140 */       writer.write(32);
/* 141 */       writer.write(91);
/* 142 */       writer.write(internalSubset);
/* 143 */       writer.write(93);
/*     */     }
/*     */     
/* 146 */     writer.write(62);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void writeDocument(Document document, Writer writer)
/*     */     throws IOException
/*     */   {
/* 154 */     if (!document.hasChildren()) {
/* 155 */       return;
/*     */     }
/*     */     
/* 158 */     for (INode child : document.getChildren()) {
/* 159 */       write(child, writer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void writeElement(Element element, Writer writer)
/*     */     throws IOException
/*     */   {
/* 168 */     writer.write(60);
/* 169 */     writer.write(element.getElementName());
/*     */     Map<String, String> attributes;
/* 171 */     if (element.hasAttributes()) {
/* 172 */       attributes = element.getAttributeMap();
/* 173 */       for (Map.Entry<String, String> attributeEntry : attributes.entrySet()) {
/* 174 */         writer.write(32);
/* 175 */         writer.write((String)attributeEntry.getKey());
/* 176 */         writer.write(61);
/* 177 */         writer.write(34);
/* 178 */         writer.write((String)attributeEntry.getValue());
/* 179 */         writer.write(34);
/*     */       }
/*     */     }
/*     */     
/* 183 */     if (!element.hasChildren()) {
/* 184 */       writer.write(47);
/* 185 */       writer.write(62);
/* 186 */       return;
/*     */     }
/*     */     
/* 189 */     writer.write(62);
/*     */     
/* 191 */     for (INode child : element.getChildren()) {
/* 192 */       write(child, writer);
/*     */     }
/*     */     
/*     */ 
/* 196 */     writer.write(60);
/* 197 */     writer.write(47);
/* 198 */     writer.write(element.getElementName());
/* 199 */     writer.write(62);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void writeProcessingInstruction(ProcessingInstruction processingInstruction, Writer writer)
/*     */     throws IOException
/*     */   {
/* 208 */     writer.write(60);
/* 209 */     writer.write(63);
/* 210 */     writer.write(processingInstruction.getTarget());
/*     */     
/* 212 */     String content = processingInstruction.getContent();
/* 213 */     if (content != null) {
/* 214 */       writer.write(32);
/* 215 */       writer.write(content);
/*     */     }
/*     */     
/* 218 */     writer.write(63);
/* 219 */     writer.write(62);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void writeText(Text text, Writer writer)
/*     */     throws IOException
/*     */   {
/* 227 */     validateNotNull(text, "Text node cannot be null");
/* 228 */     validateNotNull(writer, "Writer cannot be null");
/*     */     
/* 230 */     writer.write(text.getContent());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void writeXmlDeclaration(XmlDeclaration xmlDeclaration, Writer writer)
/*     */     throws IOException
/*     */   {
/* 238 */     validateNotNull(xmlDeclaration, "XML declaration cannot be null");
/* 239 */     validateNotNull(writer, "Writer cannot be null");
/*     */     
/* 241 */     writer.write("<?xml version=\"");
/* 242 */     writer.write(xmlDeclaration.getVersion());
/* 243 */     writer.write(34);
/*     */     
/* 245 */     String encoding = xmlDeclaration.getEncoding();
/* 246 */     if (encoding != null) {
/* 247 */       writer.write(" encoding=\"");
/* 248 */       writer.write(encoding);
/* 249 */       writer.write(34);
/*     */     }
/*     */     
/* 252 */     String standalone = xmlDeclaration.getStandalone();
/* 253 */     if (standalone != null) {
/* 254 */       writer.write(" standalone=\"");
/* 255 */       writer.write(standalone);
/* 256 */       writer.write(34);
/*     */     }
/*     */     
/* 259 */     writer.write(63);
/* 260 */     writer.write(62);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void validateNotNull(Object obj, String message)
/*     */   {
/* 274 */     if (obj == null) {
/* 275 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\DOMWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */