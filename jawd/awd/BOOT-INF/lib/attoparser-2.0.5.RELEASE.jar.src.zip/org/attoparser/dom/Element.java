/*     */ package org.attoparser.dom;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Element
/*     */   extends AbstractNestableNode
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8980986739486971174L;
/*     */   private String elementName;
/*  46 */   private Map<String, String> attributes = null;
/*  47 */   private int attributesLen = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element(String name)
/*     */   {
/*  54 */     if (name == null) {
/*  55 */       throw new IllegalArgumentException("Element name cannot be null");
/*     */     }
/*  57 */     this.elementName = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getElementName()
/*     */   {
/*  64 */     return this.elementName;
/*     */   }
/*     */   
/*     */   public void setElementName(String name) {
/*  68 */     if (name == null) {
/*  69 */       throw new IllegalArgumentException("Element name cannot be null");
/*     */     }
/*  71 */     this.elementName = name;
/*     */   }
/*     */   
/*     */   public boolean elementNameMatches(String name) {
/*  75 */     return this.elementName.equals(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int numAttributes()
/*     */   {
/*  90 */     return this.attributesLen;
/*     */   }
/*     */   
/*     */   public boolean hasAttributes()
/*     */   {
/*  95 */     return this.attributesLen != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasAttribute(String attributeName)
/*     */   {
/* 102 */     if (this.attributesLen > 0) {
/* 103 */       return this.attributes.containsKey(attributeName);
/*     */     }
/* 105 */     return false;
/*     */   }
/*     */   
/*     */   public String getAttributeValue(String attributeName)
/*     */   {
/* 110 */     if (this.attributesLen > 0) {
/* 111 */       return (String)this.attributes.get(attributeName);
/*     */     }
/* 113 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, String> getAttributeMap()
/*     */   {
/* 120 */     if (this.attributesLen > 0) {
/* 121 */       return Collections.unmodifiableMap(this.attributes);
/*     */     }
/* 123 */     return Collections.emptyMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addAttribute(String attributeName, String attributeValue)
/*     */   {
/* 131 */     if (this.attributesLen == 0) {
/* 132 */       this.attributes = new LinkedHashMap();
/*     */     }
/* 134 */     this.attributes.put(attributeName, attributeValue);
/* 135 */     this.attributesLen += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addAttributes(Map<String, String> newAttributes)
/*     */   {
/* 142 */     if (newAttributes != null) {
/* 143 */       if (this.attributesLen == 0) {
/* 144 */         this.attributes = new LinkedHashMap();
/*     */       }
/* 146 */       this.attributes.putAll(newAttributes);
/* 147 */       this.attributesLen += newAttributes.size();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeAttribute(String attributeName)
/*     */   {
/* 157 */     if (this.attributesLen > 0)
/*     */     {
/* 159 */       if (this.attributes.containsKey(attributeName)) {
/* 160 */         this.attributes.remove(attributeName);
/* 161 */         this.attributesLen -= 1;
/* 162 */         if (this.attributesLen == 0) {
/* 163 */           this.attributes = null;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearAttributes()
/*     */   {
/* 175 */     this.attributes = null;
/* 176 */     this.attributesLen = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element cloneNode(INestableNode parent)
/*     */   {
/* 191 */     Element element = new Element(this.elementName);
/* 192 */     element.addAttributes(this.attributes);
/* 193 */     for (INode child : getChildren()) {
/* 194 */       INode clonedChild = child.cloneNode(element);
/* 195 */       element.addChild(clonedChild);
/*     */     }
/* 197 */     element.setLine(getLine());
/* 198 */     element.setCol(getCol());
/* 199 */     element.setParent(parent);
/* 200 */     return element;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\Element.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */