/*     */ package org.attoparser.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.attoparser.util.TextUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StructureTextsRepository
/*     */ {
/*  41 */   private static final String[] STANDARD_ATTRIBUTE_NAMES = { "abbr", "accept", "accept-charset", "accesskey", "action", "align", "alt", "archive", "autocomplete", "autofocus", "autoplay", "axis", "border", "cellpadding", "cellspacing", "challenge", "char", "charoff", "charset", "checked", "cite", "class", "classid", "codebase", "codetype", "cols", "colspan", "command", "content", "contenteditable", "contextmenu", "controls", "coords", "data", "datetime", "declare", "default", "defer", "dir", "disabled", "draggable", "dropzone", "enctype", "for", "form", "formaction", "formenctype", "formmethod", "formnovalidate", "formtarget", "frame", "headers", "height", "hidden", "high", "href", "hreflang", "http-equiv", "icon", "id", "ismap", "keytype", "kind", "label", "lang", "list", "longdesc", "loop", "low", "max", "maxlength", "media", "method", "min", "multiple", "muted", "name", "nohref", "novalidate", "onabort", "onafterprint", "onbeforeprint", "onbeforeunload", "onblur", "oncanplay", "oncanplaythrough", "onchange", "onclick", "oncontextmenu", "oncuechange", "ondblclick", "ondrag", "ondragend", "ondragenter", "ondragleave", "ondragover", "ondragstart", "ondrop", "ondurationchange", "onemptied", "onended", "onerror", "onfocus", "onformchange", "onforminput", "onhaschange", "oninput", "oninvalid", "onkeydown", "onkeypress", "onkeyup", "onload", "onloadeddata", "onloadedmetadata", "onloadstart", "onmessage", "onmousedown", "onmousemove", "onmouseout", "onmouseover", "onmouseup", "onmousewheel", "onoffline", "ononline", "onpagehide", "onpageshow", "onpause", "onplay", "onplaying", "onpopstate", "onprogress", "onratechange", "onredo", "onreset", "onresize", "onscroll", "onseeked", "onseeking", "onselect", "onstalled", "onstorage", "onsubmit", "onsuspend", "ontimeupdate", "onundo", "onunload", "onvolumechange", "onwaiting", "open", "optimum", "pattern", "placeholder", "poster", "preload", "profile", "radiogroup", "readonly", "rel", "required", "rev", "rows", "rowspan", "rules", "scheme", "scope", "selected", "shape", "size", "span", "spellcheck", "src", "srclang", "standby", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "valuetype", "width", "xml:lang", "xml:space", "xmlns" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   private static final String[] STANDARD_ELEMENT_NAMES = { "a", "abbr", "address", "area", "article", "aside", "audio", "b", "base", "bdi", "bdo", "blockquote", "body", "br", "button", "canvas", "caption", "cite", "code", "col", "colgroup", "command", "datalist", "dd", "del", "details", "dfn", "dialog", "div", "dl", "dt", "em", "embed", "fieldset", "figcaption", "figure", "footer", "form", "g", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "iframe", "img", "input", "ins", "kbd", "keygen", "label", "legend", "li", "link", "main", "map", "mark", "menu", "menuitem", "meta", "meter", "nav", "noscript", "object", "ol", "optgroup", "option", "output", "p", "param", "pre", "progress", "rb", "rp", "rt", "rtc", "ruby", "s", "samp", "script", "section", "select", "small", "source", "span", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "textarea", "tfoot", "th", "thead", "time", "title", "tr", "track", "u", "ul", "var", "video", "wbr" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String[] ALL_STANDARD_NAMES;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 117 */     Set<String> allStandardNamesSet = new HashSet((STANDARD_ELEMENT_NAMES.length + STANDARD_ATTRIBUTE_NAMES.length + 1) * 2, 1.0F);
/* 118 */     allStandardNamesSet.addAll(Arrays.asList(STANDARD_ELEMENT_NAMES));
/* 119 */     allStandardNamesSet.addAll(Arrays.asList(STANDARD_ATTRIBUTE_NAMES));
/* 120 */     for (String str : STANDARD_ELEMENT_NAMES) {
/* 121 */       allStandardNamesSet.add(str.toUpperCase());
/*     */     }
/* 123 */     for (String str : STANDARD_ATTRIBUTE_NAMES) {
/* 124 */       allStandardNamesSet.add(str.toUpperCase());
/*     */     }
/*     */     
/*     */ 
/* 128 */     Object allStandardNamesList = new ArrayList(allStandardNamesSet);
/* 129 */     Collections.sort((List)allStandardNamesList);
/*     */     
/*     */ 
/* 132 */     ALL_STANDARD_NAMES = (String[])((List)allStandardNamesList).toArray(new String[((List)allStandardNamesList).size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String getStructureName(char[] buffer, int offset, int len)
/*     */   {
/* 141 */     int index = TextUtil.binarySearch(true, ALL_STANDARD_NAMES, buffer, offset, len);
/* 142 */     if (index < 0) {
/* 143 */       return new String(buffer, offset, len);
/*     */     }
/*     */     
/* 146 */     return ALL_STANDARD_NAMES[index];
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\StructureTextsRepository.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */