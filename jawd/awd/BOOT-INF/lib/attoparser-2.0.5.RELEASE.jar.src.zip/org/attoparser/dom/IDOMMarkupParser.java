package org.attoparser.dom;

import java.io.Reader;
import org.attoparser.ParseException;

public abstract interface IDOMMarkupParser
{
  public abstract Document parse(String paramString)
    throws ParseException;
  
  public abstract Document parse(char[] paramArrayOfChar)
    throws ParseException;
  
  public abstract Document parse(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract Document parse(Reader paramReader)
    throws ParseException;
  
  public abstract Document parse(String paramString1, String paramString2)
    throws ParseException;
  
  public abstract Document parse(String paramString, char[] paramArrayOfChar)
    throws ParseException;
  
  public abstract Document parse(String paramString, char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract Document parse(String paramString, Reader paramReader)
    throws ParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\IDOMMarkupParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */