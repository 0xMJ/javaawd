/*     */ package org.attoparser.dom;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocType
/*     */   extends AbstractNode
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 763084654353190744L;
/*     */   private String rootElementName;
/*     */   private String publicId;
/*     */   private String systemId;
/*     */   private String internalSubset;
/*     */   
/*     */   public DocType(String rootElementName, String publicId, String systemId, String internalSubset)
/*     */   {
/*  53 */     if (rootElementName == null) {
/*  54 */       throw new IllegalArgumentException("Root element name cannot be null");
/*     */     }
/*  56 */     this.rootElementName = rootElementName;
/*  57 */     this.publicId = publicId;
/*  58 */     this.systemId = systemId;
/*  59 */     this.internalSubset = internalSubset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getRootElementName()
/*     */   {
/*  66 */     return this.rootElementName;
/*     */   }
/*     */   
/*     */   public void setRootElementName(String rootElementName) {
/*  70 */     if (rootElementName == null) {
/*  71 */       throw new IllegalArgumentException("Root element name cannot be null");
/*     */     }
/*  73 */     this.rootElementName = rootElementName;
/*     */   }
/*     */   
/*     */   public String getPublicId()
/*     */   {
/*  78 */     return this.publicId;
/*     */   }
/*     */   
/*     */   public void setPublicId(String publicId) {
/*  82 */     this.publicId = publicId;
/*     */   }
/*     */   
/*     */   public String getSystemId()
/*     */   {
/*  87 */     return this.systemId;
/*     */   }
/*     */   
/*     */   public void setSystemId(String systemId) {
/*  91 */     this.systemId = systemId;
/*     */   }
/*     */   
/*     */   public String getInternalSubset()
/*     */   {
/*  96 */     return this.internalSubset;
/*     */   }
/*     */   
/*     */   public void setInternalSubset(String internalSubset) {
/* 100 */     this.internalSubset = internalSubset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public DocType cloneNode(INestableNode parent)
/*     */   {
/* 107 */     DocType docType = new DocType(this.rootElementName, this.publicId, this.systemId, this.internalSubset);
/* 108 */     docType.setLine(getLine());
/* 109 */     docType.setCol(getCol());
/* 110 */     docType.setParent(parent);
/* 111 */     return docType;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\DocType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */