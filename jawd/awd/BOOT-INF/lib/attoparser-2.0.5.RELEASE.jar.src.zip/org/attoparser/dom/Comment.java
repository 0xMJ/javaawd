/*    */ package org.attoparser.dom;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Comment
/*    */   extends AbstractNode
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -5222507854714214977L;
/*    */   private String content;
/*    */   
/*    */   public Comment(String content)
/*    */   {
/* 47 */     if (content == null) {
/* 48 */       throw new IllegalArgumentException("Content cannot be null");
/*    */     }
/* 50 */     this.content = content;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getContent()
/*    */   {
/* 57 */     return this.content;
/*    */   }
/*    */   
/*    */   public void setContent(String content)
/*    */   {
/* 62 */     if (content == null) {
/* 63 */       throw new IllegalArgumentException("Content cannot be null");
/*    */     }
/* 65 */     this.content = content;
/*    */   }
/*    */   
/*    */   public void setContent(char[] buffer, int offset, int len)
/*    */   {
/* 70 */     this.content = new String(buffer, offset, len);
/*    */   }
/*    */   
/*    */ 
/*    */   public Comment cloneNode(INestableNode parent)
/*    */   {
/* 76 */     Comment comment = new Comment(this.content);
/* 77 */     comment.setLine(getLine());
/* 78 */     comment.setCol(getCol());
/* 79 */     comment.setParent(parent);
/* 80 */     return comment;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\Comment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */