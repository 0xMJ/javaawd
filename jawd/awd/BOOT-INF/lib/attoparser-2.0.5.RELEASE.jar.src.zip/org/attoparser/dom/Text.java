/*    */ package org.attoparser.dom;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Text
/*    */   extends AbstractNode
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6449838157196892217L;
/*    */   private String content;
/*    */   
/*    */   public Text(String content)
/*    */   {
/* 47 */     if (content == null) {
/* 48 */       throw new IllegalArgumentException("Content cannot be null");
/*    */     }
/* 50 */     this.content = content;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getContent()
/*    */   {
/* 56 */     return this.content;
/*    */   }
/*    */   
/*    */   public void setContent(String content)
/*    */   {
/* 61 */     if (content == null) {
/* 62 */       throw new IllegalArgumentException("Content cannot be null");
/*    */     }
/* 64 */     this.content = content;
/*    */   }
/*    */   
/*    */   public void setContent(char[] buffer, int offset, int len)
/*    */   {
/* 69 */     this.content = new String(buffer, offset, len);
/*    */   }
/*    */   
/*    */ 
/*    */   public Text cloneNode(INestableNode parent)
/*    */   {
/* 75 */     Text text = new Text(this.content);
/* 76 */     text.setLine(getLine());
/* 77 */     text.setCol(getCol());
/* 78 */     text.setParent(parent);
/* 79 */     return text;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\Text.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */