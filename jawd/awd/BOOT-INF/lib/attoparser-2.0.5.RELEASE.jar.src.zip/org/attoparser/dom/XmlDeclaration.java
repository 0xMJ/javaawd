/*    */ package org.attoparser.dom;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlDeclaration
/*    */   extends AbstractNode
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 8210232665354213283L;
/*    */   private String version;
/*    */   private String encoding;
/*    */   private String standalone;
/*    */   
/*    */   public XmlDeclaration(String version, String encoding, String standalone)
/*    */   {
/* 51 */     if (version == null) {
/* 52 */       throw new IllegalArgumentException("Version cannot be null");
/*    */     }
/* 54 */     this.version = version;
/* 55 */     this.encoding = encoding;
/* 56 */     this.standalone = standalone;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getVersion()
/*    */   {
/* 63 */     return this.version;
/*    */   }
/*    */   
/*    */   public void setVersion(String version) {
/* 67 */     if (version == null) {
/* 68 */       throw new IllegalArgumentException("Version cannot be null");
/*    */     }
/* 70 */     this.version = version;
/*    */   }
/*    */   
/*    */   public String getEncoding()
/*    */   {
/* 75 */     return this.encoding;
/*    */   }
/*    */   
/*    */   public void setEncoding(String encoding) {
/* 79 */     this.encoding = encoding;
/*    */   }
/*    */   
/*    */   public String getStandalone()
/*    */   {
/* 84 */     return this.standalone;
/*    */   }
/*    */   
/*    */   public void setStandalone(String standalone) {
/* 88 */     this.standalone = standalone;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public XmlDeclaration cloneNode(INestableNode parent)
/*    */   {
/* 95 */     XmlDeclaration xmlDeclaration = new XmlDeclaration(this.version, this.encoding, this.standalone);
/* 96 */     xmlDeclaration.setLine(getLine());
/* 97 */     xmlDeclaration.setCol(getCol());
/* 98 */     xmlDeclaration.setParent(parent);
/* 99 */     return xmlDeclaration;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\XmlDeclaration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */