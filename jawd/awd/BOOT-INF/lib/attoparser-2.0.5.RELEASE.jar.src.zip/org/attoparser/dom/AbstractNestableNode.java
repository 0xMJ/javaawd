/*     */ package org.attoparser.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractNestableNode
/*     */   extends AbstractNode
/*     */   implements INestableNode
/*     */ {
/*  39 */   private List<INode> children = null;
/*  40 */   private int childrenLen = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasChildren()
/*     */   {
/*  55 */     return this.childrenLen != 0;
/*     */   }
/*     */   
/*     */   public int numChildren()
/*     */   {
/*  60 */     return this.childrenLen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<INode> getChildren()
/*     */   {
/*  67 */     if (this.childrenLen == 0) {
/*  68 */       return Collections.emptyList();
/*     */     }
/*  70 */     return Collections.unmodifiableList(this.children);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends INode> List<T> getChildrenOfType(Class<T> type)
/*     */   {
/*  76 */     if (this.childrenLen == 0) {
/*  77 */       return Collections.emptyList();
/*     */     }
/*  79 */     List<T> selectedChildren = new ArrayList(5);
/*  80 */     for (INode child : this.children) {
/*  81 */       if (type.isInstance(child)) {
/*  82 */         selectedChildren.add(child);
/*     */       }
/*     */     }
/*  85 */     return Collections.unmodifiableList(selectedChildren);
/*     */   }
/*     */   
/*     */ 
/*     */   public INode getFirstChild()
/*     */   {
/*  91 */     if (this.childrenLen == 0) {
/*  92 */       return null;
/*     */     }
/*  94 */     return (INode)this.children.get(0);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends INode> T getFirstChildOfType(Class<T> type)
/*     */   {
/* 100 */     if (this.childrenLen == 0) {
/* 101 */       return null;
/*     */     }
/* 103 */     for (INode child : this.children) {
/* 104 */       if (type.isInstance(child)) {
/* 105 */         return child;
/*     */       }
/*     */     }
/* 108 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addChild(INode newChild)
/*     */   {
/* 116 */     if (newChild != null)
/*     */     {
/* 118 */       if (this.childrenLen == 0) {
/* 119 */         this.children = new ArrayList(5);
/*     */       }
/* 121 */       this.children.add(newChild);
/* 122 */       this.childrenLen += 1;
/*     */       
/* 124 */       newChild.setParent(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void insertChild(int index, INode newChild)
/*     */   {
/* 133 */     if (newChild != null)
/*     */     {
/* 135 */       if (this.childrenLen == 0) {
/* 136 */         this.children = new ArrayList(5);
/*     */       }
/*     */       
/* 139 */       if (index <= this.childrenLen)
/*     */       {
/* 141 */         this.children.add(index, newChild);
/* 142 */         this.childrenLen += 1;
/*     */         
/* 144 */         newChild.setParent(this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void insertChildBefore(INode before, INode newChild)
/*     */   {
/* 155 */     if (newChild != null)
/*     */     {
/* 157 */       if (this.childrenLen > 0) {
/* 158 */         for (int i = 0; i < this.childrenLen; i++) {
/* 159 */           INode currentChild = (INode)this.children.get(i);
/* 160 */           if (currentChild == before) {
/* 161 */             insertChild(i, newChild);
/* 162 */             return;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void insertChildAfter(INode after, INode newChild)
/*     */   {
/* 174 */     if (newChild != null)
/*     */     {
/* 176 */       if (this.childrenLen > 0) {
/* 177 */         for (int i = 0; i < this.childrenLen; i++) {
/* 178 */           INode currentChild = (INode)this.children.get(i);
/* 179 */           if (currentChild == after) {
/* 180 */             insertChild(i + 1, newChild);
/* 181 */             return;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void removeChild(INode child)
/*     */   {
/* 193 */     if ((child != null) && (child.getParent() == this))
/*     */     {
/* 195 */       Iterator<INode> childrenIter = this.children.iterator();
/* 196 */       while (childrenIter.hasNext()) {
/* 197 */         INode nodeChild = (INode)childrenIter.next();
/* 198 */         if (nodeChild == child) {
/* 199 */           childrenIter.remove();
/* 200 */           this.childrenLen -= 1;
/* 201 */           break;
/*     */         }
/*     */       }
/* 204 */       if (this.childrenLen == 0) {
/* 205 */         this.children = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void clearChildren()
/*     */   {
/* 215 */     this.children = null;
/* 216 */     this.childrenLen = 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\AbstractNestableNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */