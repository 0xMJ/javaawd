/*    */ package org.attoparser.dom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractNode
/*    */   implements INode
/*    */ {
/* 32 */   private Integer line = null;
/* 33 */   private Integer col = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private INestableNode parent;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean hasLine()
/*    */   {
/* 46 */     return this.line != null;
/*    */   }
/*    */   
/*    */   public Integer getLine() {
/* 50 */     return this.line;
/*    */   }
/*    */   
/*    */   public void setLine(Integer line) {
/* 54 */     this.line = line;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean hasCol()
/*    */   {
/* 60 */     return this.col != null;
/*    */   }
/*    */   
/*    */   public Integer getCol() {
/* 64 */     return this.col;
/*    */   }
/*    */   
/*    */   public void setCol(Integer col) {
/* 68 */     this.col = col;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean hasParent()
/*    */   {
/* 74 */     return this.parent != null;
/*    */   }
/*    */   
/*    */   public INestableNode getParent() {
/* 78 */     return this.parent;
/*    */   }
/*    */   
/*    */   public void setParent(INestableNode parent) {
/* 82 */     this.parent = parent;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\AbstractNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */