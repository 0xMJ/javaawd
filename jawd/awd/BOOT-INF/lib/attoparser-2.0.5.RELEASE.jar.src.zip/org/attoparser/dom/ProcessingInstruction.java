/*    */ package org.attoparser.dom;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProcessingInstruction
/*    */   extends AbstractNode
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 7832638382597687056L;
/*    */   private String target;
/*    */   private String content;
/*    */   
/*    */   public ProcessingInstruction(String target, String content)
/*    */   {
/* 47 */     if (target == null) {
/* 48 */       throw new IllegalArgumentException("Target cannot be null");
/*    */     }
/* 50 */     this.target = target;
/* 51 */     this.content = content;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getTarget()
/*    */   {
/* 57 */     return this.target;
/*    */   }
/*    */   
/*    */   public void setTarget(String target) {
/* 61 */     if (target == null) {
/* 62 */       throw new IllegalArgumentException("Target cannot be null");
/*    */     }
/* 64 */     this.target = target;
/*    */   }
/*    */   
/*    */   public String getContent()
/*    */   {
/* 69 */     return this.content;
/*    */   }
/*    */   
/*    */   public void setContent(String content) {
/* 73 */     this.content = content;
/*    */   }
/*    */   
/*    */   public ProcessingInstruction cloneNode(INestableNode parent)
/*    */   {
/* 78 */     ProcessingInstruction processingInstruction = new ProcessingInstruction(this.target, this.content);
/* 79 */     processingInstruction.setLine(getLine());
/* 80 */     processingInstruction.setCol(getCol());
/* 81 */     processingInstruction.setParent(parent);
/* 82 */     return processingInstruction;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\ProcessingInstruction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */