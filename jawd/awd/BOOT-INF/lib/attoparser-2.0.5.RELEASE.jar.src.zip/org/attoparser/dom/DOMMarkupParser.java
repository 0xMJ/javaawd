/*     */ package org.attoparser.dom;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import org.attoparser.MarkupParser;
/*     */ import org.attoparser.ParseException;
/*     */ import org.attoparser.config.ParseConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMMarkupParser
/*     */   implements IDOMMarkupParser
/*     */ {
/*     */   private final MarkupParser markupParser;
/*     */   
/*     */   public DOMMarkupParser(ParseConfiguration configuration)
/*     */   {
/* 100 */     if (configuration == null) {
/* 101 */       throw new IllegalArgumentException("Configuration cannot be null");
/*     */     }
/* 103 */     this.markupParser = new MarkupParser(configuration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Document parse(String document)
/*     */     throws ParseException
/*     */   {
/* 112 */     return parse(null, document);
/*     */   }
/*     */   
/*     */   public Document parse(char[] document)
/*     */     throws ParseException
/*     */   {
/* 118 */     return parse(null, document);
/*     */   }
/*     */   
/*     */   public Document parse(char[] document, int offset, int len)
/*     */     throws ParseException
/*     */   {
/* 124 */     return parse(null, document, offset, len);
/*     */   }
/*     */   
/*     */   public Document parse(Reader reader)
/*     */     throws ParseException
/*     */   {
/* 130 */     return parse(null, reader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Document parse(String documentName, String document)
/*     */     throws ParseException
/*     */   {
/* 139 */     DOMBuilderMarkupHandler domHandler = new DOMBuilderMarkupHandler(documentName);
/* 140 */     this.markupParser.parse(document, domHandler);
/* 141 */     return domHandler.getDocument();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Document parse(String documentName, char[] document)
/*     */     throws ParseException
/*     */   {
/* 149 */     DOMBuilderMarkupHandler domHandler = new DOMBuilderMarkupHandler(documentName);
/* 150 */     this.markupParser.parse(document, domHandler);
/* 151 */     return domHandler.getDocument();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Document parse(String documentName, char[] document, int offset, int len)
/*     */     throws ParseException
/*     */   {
/* 159 */     DOMBuilderMarkupHandler domHandler = new DOMBuilderMarkupHandler(documentName);
/* 160 */     this.markupParser.parse(document, offset, len, domHandler);
/* 161 */     return domHandler.getDocument();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Document parse(String documentName, Reader reader)
/*     */     throws ParseException
/*     */   {
/* 169 */     DOMBuilderMarkupHandler domHandler = new DOMBuilderMarkupHandler(documentName);
/* 170 */     this.markupParser.parse(reader, domHandler);
/* 171 */     return domHandler.getDocument();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\DOMMarkupParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */