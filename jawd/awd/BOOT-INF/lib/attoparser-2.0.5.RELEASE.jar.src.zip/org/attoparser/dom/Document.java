/*    */ package org.attoparser.dom;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Document
/*    */   extends AbstractNestableNode
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 43 */   private String documentName = null;
/*    */   
/*    */ 
/*    */   public Document(String documentName)
/*    */   {
/* 48 */     this.documentName = documentName;
/*    */   }
/*    */   
/*    */   public String getDocumentName()
/*    */   {
/* 53 */     return this.documentName;
/*    */   }
/*    */   
/*    */   public void setDocumentName(String documentName)
/*    */   {
/* 58 */     this.documentName = documentName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Document cloneNode(INestableNode parent)
/*    */   {
/* 65 */     Document document = new Document(this.documentName);
/* 66 */     document.setLine(getLine());
/* 67 */     document.setCol(getCol());
/* 68 */     document.setParent(parent);
/* 69 */     return document;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\Document.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */