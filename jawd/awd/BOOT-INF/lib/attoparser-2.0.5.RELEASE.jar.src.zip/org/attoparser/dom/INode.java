package org.attoparser.dom;

public abstract interface INode
{
  public abstract boolean hasLine();
  
  public abstract Integer getLine();
  
  public abstract void setLine(Integer paramInteger);
  
  public abstract boolean hasCol();
  
  public abstract Integer getCol();
  
  public abstract void setCol(Integer paramInteger);
  
  public abstract boolean hasParent();
  
  public abstract INestableNode getParent();
  
  public abstract void setParent(INestableNode paramINestableNode);
  
  public abstract INode cloneNode(INestableNode paramINestableNode);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\INode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */