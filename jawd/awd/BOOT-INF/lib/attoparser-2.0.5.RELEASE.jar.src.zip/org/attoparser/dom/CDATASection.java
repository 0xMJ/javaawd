/*    */ package org.attoparser.dom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CDATASection
/*    */   extends Text
/*    */ {
/*    */   private static final long serialVersionUID = -131121996532074777L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CDATASection(String content)
/*    */   {
/* 39 */     super(content);
/*    */   }
/*    */   
/*    */   public CDATASection cloneNode(INestableNode parent)
/*    */   {
/* 44 */     CDATASection cdataSection = new CDATASection(getContent());
/* 45 */     cdataSection.setLine(getLine());
/* 46 */     cdataSection.setCol(getCol());
/* 47 */     cdataSection.setParent(parent);
/* 48 */     return cdataSection;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\CDATASection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */