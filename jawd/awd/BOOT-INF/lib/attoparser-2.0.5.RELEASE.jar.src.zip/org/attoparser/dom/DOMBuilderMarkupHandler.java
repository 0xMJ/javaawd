/*     */ package org.attoparser.dom;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.attoparser.AbstractMarkupHandler;
/*     */ import org.attoparser.ParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DOMBuilderMarkupHandler
/*     */   extends AbstractMarkupHandler
/*     */ {
/*     */   private final String documentName;
/*  72 */   private Document document = null;
/*  73 */   private boolean parsingFinished = false;
/*  74 */   private long parsingStartTimeNanos = -1L;
/*  75 */   private long parsingEndTimeNanos = -1L;
/*  76 */   private long parsingTotalTimeNanos = -1L;
/*     */   
/*  78 */   private INestableNode currentParent = null;
/*     */   
/*     */ 
/*  81 */   private String currentElementName = null;
/*  82 */   private Map<String, String> currentElementAttributes = null;
/*  83 */   private int currentElementLine = -1;
/*  84 */   private int currentElementCol = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMBuilderMarkupHandler()
/*     */   {
/*  94 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DOMBuilderMarkupHandler(String documentName)
/*     */   {
/* 108 */     this.documentName = (documentName == null ? String.valueOf(System.identityHashCode(this)) : documentName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Document getDocument()
/*     */   {
/* 121 */     return this.document;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getParsingStartTimeNanos()
/*     */   {
/* 134 */     return this.parsingStartTimeNanos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getParsingEndTimeNanos()
/*     */   {
/* 145 */     return this.parsingEndTimeNanos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getParsingTotalTimeNanos()
/*     */   {
/* 156 */     return this.parsingTotalTimeNanos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isParsingFinished()
/*     */   {
/* 168 */     return this.parsingFinished;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentStart(long startTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 180 */     this.document = new Document(this.documentName);
/* 181 */     this.parsingStartTimeNanos = startTimeNanos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 193 */     this.parsingEndTimeNanos = endTimeNanos;
/* 194 */     this.parsingTotalTimeNanos = totalTimeNanos;
/*     */     
/* 196 */     this.parsingFinished = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleXmlDeclaration(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int versionOffset, int versionLen, int versionLine, int versionCol, int encodingOffset, int encodingLen, int encodingLine, int encodingCol, int standaloneOffset, int standaloneLen, int standaloneLine, int standaloneCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 220 */     String version = new String(buffer, versionOffset, versionLen);
/*     */     
/*     */ 
/*     */ 
/* 224 */     String encoding = encodingOffset > 0 ? new String(buffer, encodingOffset, encodingLen) : null;
/*     */     
/*     */ 
/*     */ 
/* 228 */     String standalone = standaloneOffset > 0 ? new String(buffer, standaloneOffset, standaloneLen) : null;
/*     */     
/* 230 */     XmlDeclaration xmlDeclaration = new XmlDeclaration(version, encoding, standalone);
/* 231 */     xmlDeclaration.setLine(Integer.valueOf(line));
/* 232 */     xmlDeclaration.setLine(Integer.valueOf(col));
/*     */     
/* 234 */     if (this.currentParent == null) {
/* 235 */       this.document.addChild(xmlDeclaration);
/*     */     } else {
/* 237 */       this.currentParent.addChild(xmlDeclaration);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocType(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int elementNameOffset, int elementNameLen, int elementNameLine, int elementNameCol, int typeOffset, int typeLen, int typeLine, int typeCol, int publicIdOffset, int publicIdLen, int publicIdLine, int publicIdCol, int systemIdOffset, int systemIdLen, int systemIdLine, int systemIdCol, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, int outerOffset, int outerLen, int outerLine, int outerCol)
/*     */     throws ParseException
/*     */   {
/* 263 */     String elementName = new String(buffer, elementNameOffset, elementNameLen);
/* 264 */     String publicId = publicIdOffset <= 0 ? null : new String(buffer, publicIdOffset, publicIdLen);
/* 265 */     String systemId = systemIdOffset <= 0 ? null : new String(buffer, systemIdOffset, systemIdLen);
/*     */     
/* 267 */     String internalSubset = internalSubsetOffset <= 0 ? null : new String(buffer, internalSubsetOffset, internalSubsetLen);
/*     */     
/* 269 */     DocType docType = new DocType(elementName, publicId, systemId, internalSubset);
/* 270 */     docType.setLine(Integer.valueOf(outerLine));
/* 271 */     docType.setLine(Integer.valueOf(outerCol));
/*     */     
/* 273 */     if (this.currentParent == null) {
/* 274 */       this.document.addChild(docType);
/*     */     } else {
/* 276 */       this.currentParent.addChild(docType);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCDATASection(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 291 */     CDATASection cdataSection = new CDATASection(new String(buffer, contentOffset, contentLen));
/* 292 */     cdataSection.setLine(Integer.valueOf(line));
/* 293 */     cdataSection.setLine(Integer.valueOf(col));
/*     */     
/* 295 */     if (this.currentParent == null) {
/* 296 */       this.document.addChild(cdataSection);
/*     */     } else {
/* 298 */       this.currentParent.addChild(cdataSection);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 313 */     Comment comment = new Comment(new String(buffer, contentOffset, contentLen));
/* 314 */     comment.setLine(Integer.valueOf(line));
/* 315 */     comment.setLine(Integer.valueOf(col));
/*     */     
/* 317 */     if (this.currentParent == null) {
/* 318 */       this.document.addChild(comment);
/*     */     } else {
/* 320 */       this.currentParent.addChild(comment);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 334 */     Text text = new Text(new String(buffer, offset, len));
/* 335 */     text.setLine(Integer.valueOf(line));
/* 336 */     text.setLine(Integer.valueOf(col));
/*     */     
/* 338 */     if (this.currentParent == null) {
/* 339 */       this.document.addChild(text);
/*     */     } else {
/* 341 */       this.currentParent.addChild(text);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 355 */     this.currentElementName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/* 356 */     this.currentElementAttributes = null;
/* 357 */     this.currentElementLine = line;
/* 358 */     this.currentElementCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 371 */     Element element = new Element(this.currentElementName);
/* 372 */     element.addAttributes(this.currentElementAttributes);
/* 373 */     element.setLine(Integer.valueOf(this.currentElementLine));
/* 374 */     element.setLine(Integer.valueOf(this.currentElementCol));
/*     */     
/* 376 */     if (this.currentParent == null) {
/* 377 */       this.document.addChild(element);
/*     */     } else {
/* 379 */       this.currentParent.addChild(element);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 393 */     this.currentElementName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/* 394 */     this.currentElementAttributes = null;
/* 395 */     this.currentElementLine = line;
/* 396 */     this.currentElementCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 409 */     Element element = new Element(this.currentElementName);
/* 410 */     element.addAttributes(this.currentElementAttributes);
/* 411 */     element.setLine(Integer.valueOf(this.currentElementLine));
/* 412 */     element.setLine(Integer.valueOf(this.currentElementCol));
/*     */     
/* 414 */     if (this.currentParent == null) {
/* 415 */       this.document.addChild(element);
/*     */     } else {
/* 417 */       this.currentParent.addChild(element);
/*     */     }
/* 419 */     this.currentParent = element;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 432 */     this.currentElementName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/* 433 */     this.currentElementAttributes = null;
/* 434 */     this.currentElementLine = line;
/* 435 */     this.currentElementCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 448 */     Element element = new Element(this.currentElementName);
/* 449 */     element.addAttributes(this.currentElementAttributes);
/* 450 */     element.setLine(Integer.valueOf(this.currentElementLine));
/* 451 */     element.setLine(Integer.valueOf(this.currentElementCol));
/*     */     
/* 453 */     if (this.currentParent == null) {
/* 454 */       this.document.addChild(element);
/*     */     } else {
/* 456 */       this.currentParent.addChild(element);
/*     */     }
/* 458 */     this.currentParent = element;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 471 */     this.currentElementName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/* 472 */     this.currentElementAttributes = null;
/* 473 */     this.currentElementLine = line;
/* 474 */     this.currentElementCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 487 */     this.currentParent = this.currentParent.getParent();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 501 */     this.currentElementName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/* 502 */     this.currentElementAttributes = null;
/* 503 */     this.currentElementLine = line;
/* 504 */     this.currentElementCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 517 */     this.currentParent = this.currentParent.getParent();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementEnd(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws ParseException
/*     */   {
/* 563 */     String attributeName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/*     */     
/* 565 */     String attributeValue = valueContentLen <= 0 ? "" : new String(buffer, valueContentOffset, valueContentLen);
/*     */     
/* 567 */     if (this.currentElementAttributes == null) {
/* 568 */       this.currentElementAttributes = new LinkedHashMap(5, 1.0F);
/*     */     }
/*     */     
/* 571 */     this.currentElementAttributes.put(attributeName, attributeValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleProcessingInstruction(char[] buffer, int targetOffset, int targetLen, int targetLine, int targetCol, int contentOffset, int contentLen, int contentLine, int contentCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 601 */     String target = new String(buffer, targetOffset, targetLen);
/* 602 */     String content = contentOffset <= 0 ? null : new String(buffer, contentOffset, contentLen);
/*     */     
/* 604 */     ProcessingInstruction processingInstruction = new ProcessingInstruction(target, content);
/*     */     
/* 606 */     processingInstruction.setLine(Integer.valueOf(line));
/* 607 */     processingInstruction.setLine(Integer.valueOf(col));
/*     */     
/* 609 */     if (this.currentParent == null) {
/* 610 */       this.document.addChild(processingInstruction);
/*     */     } else {
/* 612 */       this.currentParent.addChild(processingInstruction);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\DOMBuilderMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */