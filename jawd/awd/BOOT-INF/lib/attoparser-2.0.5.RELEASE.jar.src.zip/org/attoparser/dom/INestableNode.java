package org.attoparser.dom;

import java.util.List;

public abstract interface INestableNode
  extends INode
{
  public abstract boolean hasChildren();
  
  public abstract int numChildren();
  
  public abstract List<INode> getChildren();
  
  public abstract <T extends INode> List<T> getChildrenOfType(Class<T> paramClass);
  
  public abstract INode getFirstChild();
  
  public abstract <T extends INode> T getFirstChildOfType(Class<T> paramClass);
  
  public abstract void addChild(INode paramINode);
  
  public abstract void insertChild(int paramInt, INode paramINode);
  
  public abstract void insertChildBefore(INode paramINode1, INode paramINode2);
  
  public abstract void insertChildAfter(INode paramINode1, INode paramINode2);
  
  public abstract void removeChild(INode paramINode);
  
  public abstract void clearChildren();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\dom\INestableNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */