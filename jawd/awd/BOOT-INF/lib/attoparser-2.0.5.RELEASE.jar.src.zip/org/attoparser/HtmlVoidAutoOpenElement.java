/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HtmlVoidAutoOpenElement
/*     */   extends HtmlVoidElement
/*     */ {
/*     */   private final char[][] autoOpenParents;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final char[][] autoOpenLimits;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   HtmlVoidAutoOpenElement(String name, String[] autoOpenParents, String[] autoOpenLimits)
/*     */   {
/*  42 */     super(name);
/*     */     
/*  44 */     if (autoOpenParents == null) {
/*  45 */       throw new IllegalArgumentException("The array of auto-open parents cannot be null");
/*     */     }
/*     */     
/*  48 */     char[][] autoOpenParentsCharArray = new char[autoOpenParents.length][];
/*  49 */     for (int i = 0; i < autoOpenParentsCharArray.length; i++) {
/*  50 */       autoOpenParentsCharArray[i] = autoOpenParents[i].toCharArray();
/*     */     }
/*     */     
/*     */     char[][] autoOpenLimitsCharArray;
/*  54 */     if (autoOpenLimits != null) {
/*  55 */       char[][] autoOpenLimitsCharArray = new char[autoOpenLimits.length][];
/*  56 */       for (int i = 0; i < autoOpenLimitsCharArray.length; i++) {
/*  57 */         autoOpenLimitsCharArray[i] = autoOpenLimits[i].toCharArray();
/*     */       }
/*     */     } else {
/*  60 */       autoOpenLimitsCharArray = null;
/*     */     }
/*     */     
/*  63 */     this.autoOpenParents = autoOpenParentsCharArray;
/*  64 */     this.autoOpenLimits = autoOpenLimitsCharArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled)
/*     */     throws ParseException
/*     */   {
/*  84 */     status.setAvoidStacking(true);
/*     */     
/*  86 */     if ((autoOpenEnabled) && (!status.isAutoOpenCloseDone())) {
/*  87 */       status.setAutoOpenRequired(this.autoOpenParents, this.autoOpenLimits);
/*  88 */       return;
/*     */     }
/*     */     
/*  91 */     handler.handleStandaloneElementStart(buffer, nameOffset, nameLen, false, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled)
/*     */     throws ParseException
/*     */   {
/* 108 */     status.setAvoidStacking(true);
/*     */     
/* 110 */     if ((autoOpenEnabled) && (status.isAutoOpenCloseDone())) {
/* 111 */       status.setAutoOpenRequired(this.autoOpenParents, this.autoOpenLimits);
/* 112 */       return;
/*     */     }
/*     */     
/* 115 */     handler.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\HtmlVoidAutoOpenElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */