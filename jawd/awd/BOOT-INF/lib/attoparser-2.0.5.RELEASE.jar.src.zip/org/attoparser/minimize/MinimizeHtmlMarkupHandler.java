/*     */ package org.attoparser.minimize;
/*     */ 
/*     */ import org.attoparser.AbstractChainedMarkupHandler;
/*     */ import org.attoparser.IMarkupHandler;
/*     */ import org.attoparser.ParseException;
/*     */ import org.attoparser.config.ParseConfiguration;
/*     */ import org.attoparser.config.ParseConfiguration.ParsingMode;
/*     */ import org.attoparser.util.TextUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MinimizeHtmlMarkupHandler
/*     */   extends AbstractChainedMarkupHandler
/*     */ {
/*     */   public static enum MinimizeMode
/*     */   {
/*  98 */     ONLY_WHITE_SPACE(false, false, false, false),  COMPLETE(true, true, true, true);
/*     */     
/*     */     private boolean removeComments;
/*     */     private boolean unquoteAttributes;
/*     */     private boolean unminimizeStandalones;
/*     */     private boolean minimizeBooleanAttributes;
/*     */     
/*     */     private MinimizeMode(boolean removeComments, boolean unquoteAttributes, boolean unminimizeStandalones, boolean minimizeBooleanAttributes)
/*     */     {
/* 107 */       this.removeComments = removeComments;
/* 108 */       this.unquoteAttributes = unquoteAttributes;
/* 109 */       this.unminimizeStandalones = unminimizeStandalones;
/* 110 */       this.minimizeBooleanAttributes = minimizeBooleanAttributes;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */   private static final String[] BLOCK_ELEMENTS = { "address", "article", "aside", "audio", "base", "blockquote", "body", "canvas", "caption", "col", "colgroup", "dd", "div", "dl", "dt", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "li", "link", "meta", "noscript", "ol", "option", "output", "p", "pre", "script", "section", "style", "table", "tbody", "td", "tfoot", "th", "thead", "title", "tr", "ul", "video" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */   private static final String[] PREFORMATTED_ELEMENTS = { "pre", "script", "style", "textarea" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 137 */   private static final String[] BOOLEAN_ATTRIBUTE_NAMES = { "allowfullscreen", "async", "autofocus", "autoplay", "checked", "compact", "controls", "declare", "default", "defaultchecked", "defaultmuted", "defaultselected", "defer", "disabled", "draggable", "enabled", "formnovalidate", "hidden", "indeterminate", "inert", "ismap", "itemscope", "loop", "multiple", "muted", "nohref", "noresize", "noshade", "novalidate", "nowrap", "open", "pauseonexit", "readonly", "required", "reversed", "scoped", "seamless", "selected", "sortable", "spellcheck", "translate", "truespeed", "typemustmatch", "visible" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */   private static final char[] SIZE_ONE_WHITE_SPACE = { ' ' };
/* 150 */   private static final char[] ATTRIBUTE_OPERATOR = { '=' };
/*     */   
/*     */   private final MinimizeMode minimizeMode;
/*     */   
/* 154 */   private char[] internalBuffer = new char[30];
/* 155 */   private boolean lastTextEndedInWhiteSpace = false;
/* 156 */   private boolean lastOpenElementWasBlock = false;
/* 157 */   private boolean lastClosedElementWasBlock = false;
/* 158 */   private boolean lastVisibleEventWasElement = false;
/* 159 */   private boolean pendingInterBlockElementWhiteSpace = false;
/* 160 */   private boolean inPreformattedElement = false;
/*     */   
/* 162 */   private int pendingEventLine = 1;
/* 163 */   private int pendingEventCol = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MinimizeHtmlMarkupHandler(MinimizeMode minimizeMode, IMarkupHandler next)
/*     */   {
/* 180 */     super(next);
/*     */     
/* 182 */     if (minimizeMode == null) {
/* 183 */       throw new IllegalArgumentException("Minimize mode cannot be null");
/*     */     }
/*     */     
/* 186 */     this.minimizeMode = minimizeMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParseConfiguration(ParseConfiguration parseConfiguration)
/*     */   {
/* 194 */     if (!ParseConfiguration.ParsingMode.HTML.equals(parseConfiguration.getMode()))
/*     */     {
/*     */ 
/* 197 */       throw new IllegalArgumentException("The " + getClass().getName() + " handler can only be used when parsing in HTML mode. Current parsing mode is " + parseConfiguration.getMode());
/*     */     }
/*     */     
/* 200 */     super.setParseConfiguration(parseConfiguration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentStart(long startTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 211 */     getNext().handleDocumentStart(startTimeNanos, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 221 */     getNext().handleDocumentEnd(endTimeNanos, totalTimeNanos, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 233 */     if (len == 0) {
/* 234 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 239 */     flushPendingInterBlockElementWhiteSpace(false);
/*     */     
/*     */ 
/* 242 */     if (this.inPreformattedElement) {
/* 243 */       this.lastTextEndedInWhiteSpace = false;
/* 244 */       this.lastVisibleEventWasElement = false;
/* 245 */       getNext().handleText(buffer, offset, len, line, col);
/* 246 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 254 */     boolean wasWhiteSpace = this.lastTextEndedInWhiteSpace;
/* 255 */     boolean shouldCompress = false;
/* 256 */     boolean isAllWhiteSpace = true;
/* 257 */     int i = offset;
/* 258 */     int n = len;
/* 259 */     while (((!shouldCompress) || (isAllWhiteSpace)) && (n-- != 0)) {
/* 260 */       if (isWhitespace(buffer[i])) {
/* 261 */         if ((wasWhiteSpace) || (buffer[i] != ' ')) {
/* 262 */           shouldCompress = true;
/*     */         }
/* 264 */         wasWhiteSpace = true;
/*     */       } else {
/* 266 */         wasWhiteSpace = false;
/* 267 */         isAllWhiteSpace = false;
/*     */       }
/* 269 */       i++;
/*     */     }
/*     */     
/* 272 */     if (!shouldCompress)
/*     */     {
/*     */ 
/* 275 */       this.lastTextEndedInWhiteSpace = isWhitespace(buffer[(offset + len - 1)]);
/*     */       
/*     */ 
/*     */ 
/* 279 */       if ((this.lastVisibleEventWasElement) && (isAllWhiteSpace)) {
/* 280 */         this.pendingInterBlockElementWhiteSpace = true;
/* 281 */         this.pendingEventLine = line;
/* 282 */         this.pendingEventCol = col;
/* 283 */         this.lastVisibleEventWasElement = false;
/* 284 */         return;
/*     */       }
/*     */       
/*     */ 
/* 288 */       this.lastVisibleEventWasElement = false;
/*     */       
/*     */ 
/* 291 */       getNext().handleText(buffer, offset, len, line, col);
/*     */       
/* 293 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 301 */     if (this.internalBuffer.length < len)
/*     */     {
/* 303 */       this.internalBuffer = new char[len];
/*     */     }
/*     */     
/* 306 */     wasWhiteSpace = this.lastTextEndedInWhiteSpace;
/* 307 */     int internalBufferSize = 0;
/*     */     
/*     */ 
/*     */ 
/* 311 */     i = offset;
/* 312 */     n = len;
/* 313 */     while (n-- != 0) {
/* 314 */       char c = buffer[(i++)];
/* 315 */       if (isWhitespace(c)) {
/* 316 */         if (!wasWhiteSpace)
/*     */         {
/*     */ 
/*     */ 
/* 320 */           wasWhiteSpace = true;
/* 321 */           this.internalBuffer[(internalBufferSize++)] = ' ';
/*     */         }
/*     */       } else {
/* 324 */         wasWhiteSpace = false;
/*     */         
/* 326 */         this.internalBuffer[(internalBufferSize++)] = c;
/*     */       }
/*     */     }
/*     */     
/* 330 */     if (internalBufferSize > 0)
/*     */     {
/*     */ 
/* 333 */       this.lastTextEndedInWhiteSpace = wasWhiteSpace;
/*     */       
/*     */ 
/*     */ 
/* 337 */       if ((this.lastVisibleEventWasElement) && (isAllWhiteSpace)) {
/* 338 */         this.pendingInterBlockElementWhiteSpace = true;
/* 339 */         this.pendingEventLine = line;
/* 340 */         this.pendingEventCol = col;
/* 341 */         this.lastVisibleEventWasElement = false;
/* 342 */         return;
/*     */       }
/*     */       
/*     */ 
/* 346 */       this.lastVisibleEventWasElement = false;
/*     */       
/*     */ 
/* 349 */       getNext().handleText(this.internalBuffer, 0, internalBufferSize, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void flushPendingInterBlockElementWhiteSpace(boolean ignore)
/*     */     throws ParseException
/*     */   {
/* 357 */     if (this.pendingInterBlockElementWhiteSpace) {
/* 358 */       this.pendingInterBlockElementWhiteSpace = false;
/* 359 */       if (!ignore) {
/* 360 */         getNext().handleText(SIZE_ONE_WHITE_SPACE, 0, 1, this.pendingEventLine, this.pendingEventCol);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 377 */     if (!this.minimizeMode.removeComments)
/*     */     {
/*     */ 
/* 380 */       flushPendingInterBlockElementWhiteSpace(false);
/*     */       
/* 382 */       this.lastVisibleEventWasElement = false;
/* 383 */       this.lastTextEndedInWhiteSpace = false;
/*     */       
/* 385 */       getNext().handleComment(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCDATASection(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 403 */     flushPendingInterBlockElementWhiteSpace(false);
/*     */     
/* 405 */     this.lastVisibleEventWasElement = false;
/* 406 */     this.lastTextEndedInWhiteSpace = false;
/*     */     
/* 408 */     getNext().handleCDATASection(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 420 */     this.lastTextEndedInWhiteSpace = false;
/*     */     
/*     */ 
/*     */ 
/* 424 */     boolean ignorePendingWhiteSpace = ((this.lastClosedElementWasBlock) || (this.lastOpenElementWasBlock)) && (isBlockElement(buffer, nameOffset, nameLen));
/* 425 */     flushPendingInterBlockElementWhiteSpace(ignorePendingWhiteSpace);
/*     */     
/* 427 */     if (this.minimizeMode.unminimizeStandalones) {
/* 428 */       getNext().handleStandaloneElementStart(buffer, nameOffset, nameLen, false, line, col);
/*     */     } else {
/* 430 */       getNext().handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 443 */     this.lastTextEndedInWhiteSpace = false;
/* 444 */     this.lastClosedElementWasBlock = isBlockElement(buffer, nameOffset, nameLen);
/* 445 */     this.lastOpenElementWasBlock = false;
/* 446 */     this.lastVisibleEventWasElement = true;
/*     */     
/* 448 */     if (this.minimizeMode.unminimizeStandalones) {
/* 449 */       getNext().handleStandaloneElementEnd(buffer, nameOffset, nameLen, false, line, col);
/*     */     } else {
/* 451 */       getNext().handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 464 */     this.lastTextEndedInWhiteSpace = false;
/*     */     
/*     */ 
/*     */ 
/* 468 */     boolean ignorePendingWhiteSpace = ((this.lastClosedElementWasBlock) || (this.lastOpenElementWasBlock)) && (isBlockElement(buffer, nameOffset, nameLen));
/* 469 */     flushPendingInterBlockElementWhiteSpace(ignorePendingWhiteSpace);
/*     */     
/* 471 */     if (isPreformattedElement(buffer, nameOffset, nameLen)) {
/* 472 */       this.inPreformattedElement = true;
/*     */     }
/*     */     
/* 475 */     getNext().handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 487 */     this.lastTextEndedInWhiteSpace = false;
/* 488 */     this.lastOpenElementWasBlock = isBlockElement(buffer, nameOffset, nameLen);
/* 489 */     this.lastClosedElementWasBlock = false;
/* 490 */     this.lastVisibleEventWasElement = true;
/*     */     
/* 492 */     getNext().handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 504 */     this.lastTextEndedInWhiteSpace = false;
/*     */     
/*     */ 
/*     */ 
/* 508 */     boolean ignorePendingWhiteSpace = ((this.lastClosedElementWasBlock) || (this.lastOpenElementWasBlock)) && (isBlockElement(buffer, nameOffset, nameLen));
/* 509 */     flushPendingInterBlockElementWhiteSpace(ignorePendingWhiteSpace);
/*     */     
/* 511 */     if (isPreformattedElement(buffer, nameOffset, nameLen)) {
/* 512 */       this.inPreformattedElement = true;
/*     */     }
/*     */     
/* 515 */     getNext().handleAutoOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 527 */     this.lastTextEndedInWhiteSpace = false;
/* 528 */     this.lastOpenElementWasBlock = isBlockElement(buffer, nameOffset, nameLen);
/* 529 */     this.lastClosedElementWasBlock = false;
/* 530 */     this.lastVisibleEventWasElement = true;
/*     */     
/* 532 */     getNext().handleAutoOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 543 */     this.lastTextEndedInWhiteSpace = false;
/*     */     
/*     */ 
/*     */ 
/* 547 */     boolean ignorePendingWhiteSpace = (this.lastClosedElementWasBlock) && (isBlockElement(buffer, nameOffset, nameLen));
/* 548 */     flushPendingInterBlockElementWhiteSpace(ignorePendingWhiteSpace);
/*     */     
/* 550 */     if (isPreformattedElement(buffer, nameOffset, nameLen)) {
/* 551 */       this.inPreformattedElement = false;
/*     */     }
/*     */     
/* 554 */     getNext().handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 566 */     this.lastTextEndedInWhiteSpace = false;
/* 567 */     this.lastClosedElementWasBlock = isBlockElement(buffer, nameOffset, nameLen);
/* 568 */     this.lastOpenElementWasBlock = false;
/* 569 */     this.lastVisibleEventWasElement = true;
/*     */     
/* 571 */     getNext().handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 584 */     this.lastTextEndedInWhiteSpace = false;
/*     */     
/*     */ 
/*     */ 
/* 588 */     boolean ignorePendingWhiteSpace = (this.lastClosedElementWasBlock) && (isBlockElement(buffer, nameOffset, nameLen));
/* 589 */     flushPendingInterBlockElementWhiteSpace(ignorePendingWhiteSpace);
/*     */     
/* 591 */     getNext().handleAutoCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 605 */     this.lastTextEndedInWhiteSpace = false;
/* 606 */     this.lastClosedElementWasBlock = isBlockElement(buffer, nameOffset, nameLen);
/* 607 */     this.lastOpenElementWasBlock = false;
/* 608 */     this.lastVisibleEventWasElement = true;
/*     */     
/* 610 */     getNext().handleAutoCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 623 */     this.lastTextEndedInWhiteSpace = false;
/*     */     
/*     */ 
/*     */ 
/* 627 */     boolean ignorePendingWhiteSpace = (this.lastClosedElementWasBlock) && (isBlockElement(buffer, nameOffset, nameLen));
/* 628 */     flushPendingInterBlockElementWhiteSpace(ignorePendingWhiteSpace);
/*     */     
/* 630 */     getNext().handleUnmatchedCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 643 */     this.lastTextEndedInWhiteSpace = false;
/* 644 */     this.lastClosedElementWasBlock = isBlockElement(buffer, nameOffset, nameLen);
/* 645 */     this.lastOpenElementWasBlock = false;
/* 646 */     this.lastVisibleEventWasElement = true;
/*     */     
/* 648 */     getNext().handleUnmatchedCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws ParseException
/*     */   {
/* 662 */     getNext().handleInnerWhiteSpace(SIZE_ONE_WHITE_SPACE, 0, SIZE_ONE_WHITE_SPACE.length, this.pendingEventLine, this.pendingEventCol);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 670 */     boolean isMinimizableBooleanAttribute = (this.minimizeMode.minimizeBooleanAttributes) && (isBooleanAttribute(buffer, nameOffset, nameLen)) && (TextUtil.equals(false, buffer, nameOffset, nameLen, buffer, valueContentOffset, valueContentLen));
/*     */     
/* 672 */     if (isMinimizableBooleanAttribute)
/*     */     {
/* 674 */       getNext().handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, 0, 0, operatorLine, operatorCol, 0, 0, 0, 0, operatorLen, operatorCol);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 680 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 686 */     boolean canRemoveAttributeQuotes = (this.minimizeMode.unquoteAttributes) && (canAttributeValueBeUnquoted(buffer, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen));
/*     */     
/*     */ 
/* 689 */     if ((operatorLen <= 1) && (!canRemoveAttributeQuotes))
/*     */     {
/*     */ 
/* 692 */       getNext().handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 698 */       int requiredLen = nameLen + 1 + valueOuterLen;
/* 699 */       if (this.internalBuffer.length < requiredLen) {
/* 700 */         this.internalBuffer = new char[requiredLen];
/*     */       }
/*     */       
/* 703 */       System.arraycopy(buffer, nameOffset, this.internalBuffer, 0, nameLen);
/* 704 */       System.arraycopy(ATTRIBUTE_OPERATOR, 0, this.internalBuffer, nameLen, ATTRIBUTE_OPERATOR.length);
/*     */       
/* 706 */       if (canRemoveAttributeQuotes)
/*     */       {
/* 708 */         System.arraycopy(buffer, valueContentOffset, this.internalBuffer, nameLen + ATTRIBUTE_OPERATOR.length, valueContentLen);
/*     */         
/* 710 */         getNext().handleAttribute(this.internalBuffer, 0, nameLen, nameLine, nameCol, nameLen, ATTRIBUTE_OPERATOR.length, operatorLine, operatorCol, nameLen + ATTRIBUTE_OPERATOR.length, valueContentLen, nameLen + ATTRIBUTE_OPERATOR.length, valueContentLen, valueLine, valueCol);
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 720 */         System.arraycopy(buffer, valueOuterOffset, this.internalBuffer, nameLen + ATTRIBUTE_OPERATOR.length, valueOuterLen);
/*     */         
/* 722 */         getNext().handleAttribute(this.internalBuffer, 0, nameLen, nameLine, nameCol, nameLen, ATTRIBUTE_OPERATOR.length, operatorLine, operatorCol, nameLen + ATTRIBUTE_OPERATOR.length + (valueOuterOffset - valueContentOffset), valueContentLen, nameLen + ATTRIBUTE_OPERATOR.length, valueOuterLen, valueLine, valueCol);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 746 */     this.pendingEventLine = line;
/* 747 */     this.pendingEventCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocType(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int elementNameOffset, int elementNameLen, int elementNameLine, int elementNameCol, int typeOffset, int typeLen, int typeLine, int typeCol, int publicIdOffset, int publicIdLen, int publicIdLine, int publicIdCol, int systemIdOffset, int systemIdLen, int systemIdLine, int systemIdCol, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, int outerOffset, int outerLen, int outerLine, int outerCol)
/*     */     throws ParseException
/*     */   {
/* 773 */     flushPendingInterBlockElementWhiteSpace(false);
/*     */     
/* 775 */     this.lastVisibleEventWasElement = false;
/* 776 */     this.lastTextEndedInWhiteSpace = false;
/*     */     
/* 778 */     getNext().handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, publicIdOffset, publicIdLen, publicIdLine, publicIdCol, systemIdOffset, systemIdLen, systemIdLine, systemIdCol, internalSubsetOffset, internalSubsetLen, internalSubsetLine, internalSubsetCol, outerOffset, outerLen, outerLine, outerCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleXmlDeclaration(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int versionOffset, int versionLen, int versionLine, int versionCol, int encodingOffset, int encodingLen, int encodingLine, int encodingCol, int standaloneOffset, int standaloneLen, int standaloneLine, int standaloneCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 805 */     flushPendingInterBlockElementWhiteSpace(false);
/*     */     
/* 807 */     this.lastVisibleEventWasElement = false;
/* 808 */     this.lastTextEndedInWhiteSpace = false;
/*     */     
/* 810 */     getNext().handleXmlDeclaration(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, versionOffset, versionLen, versionLine, versionCol, encodingOffset, encodingLen, encodingLine, encodingCol, standaloneOffset, standaloneLen, standaloneLine, standaloneCol, outerOffset, outerLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleProcessingInstruction(char[] buffer, int targetOffset, int targetLen, int targetLine, int targetCol, int contentOffset, int contentLen, int contentLine, int contentCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 834 */     flushPendingInterBlockElementWhiteSpace(false);
/*     */     
/* 836 */     this.lastVisibleEventWasElement = false;
/* 837 */     this.lastTextEndedInWhiteSpace = false;
/*     */     
/* 839 */     getNext().handleProcessingInstruction(buffer, targetOffset, targetLen, targetLine, targetCol, contentOffset, contentLen, contentLine, contentCol, outerOffset, outerLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean canAttributeValueBeUnquoted(char[] buffer, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen)
/*     */   {
/* 855 */     if ((valueContentLen == 0) || (valueOuterLen == valueContentLen))
/*     */     {
/* 857 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 862 */     int i = valueContentOffset;
/* 863 */     int n = valueContentLen;
/*     */     
/* 865 */     while (n-- != 0)
/*     */     {
/* 867 */       char c = buffer[i];
/*     */       
/* 869 */       if (((c < 'a') || (c > 'z')) && ((c < 'A') || (c > 'Z')) && ((c < '0') || (c > '9'))) {
/* 870 */         return false;
/*     */       }
/*     */       
/* 873 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 877 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean isWhitespace(char c)
/*     */   {
/* 883 */     if ((c != ' ') && (c != '\n') && (c != '\t') && (c != '\r') && (c != '\f') && (c != '\013') && (c != '\034') && (c != '\035') && (c != '\036') && (c != '\037')) if (c <= '') break label77; label77: return 
/*     */     
/* 885 */       Character.isWhitespace(c);
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean isBlockElement(char[] buffer, int nameOffset, int nameLen)
/*     */   {
/* 891 */     return TextUtil.binarySearch(false, BLOCK_ELEMENTS, buffer, nameOffset, nameLen) >= 0;
/*     */   }
/*     */   
/*     */   private static boolean isPreformattedElement(char[] buffer, int nameOffset, int nameLen)
/*     */   {
/* 896 */     int i = 0;
/* 897 */     int n = PREFORMATTED_ELEMENTS.length;
/* 898 */     while (n-- != 0) {
/* 899 */       if (TextUtil.compareTo(false, PREFORMATTED_ELEMENTS[i], 0, PREFORMATTED_ELEMENTS[i].length(), buffer, nameOffset, nameLen) == 0) {
/* 900 */         return true;
/*     */       }
/* 902 */       i++;
/*     */     }
/* 904 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean isBooleanAttribute(char[] buffer, int nameOffset, int nameLen)
/*     */   {
/* 909 */     return TextUtil.binarySearch(false, BOOLEAN_ATTRIBUTE_NAMES, buffer, nameOffset, nameLen) >= 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\minimize\MinimizeHtmlMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */