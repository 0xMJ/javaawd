/*      */ package org.attoparser.config;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ParseConfiguration
/*      */   implements Serializable, Cloneable
/*      */ {
/*      */   public static enum ElementBalancing
/*      */   {
/*   99 */     NO_BALANCING, 
/*  100 */     REQUIRE_BALANCED, 
/*  101 */     AUTO_OPEN_CLOSE, 
/*  102 */     AUTO_CLOSE;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private ElementBalancing() {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  113 */   private ParsingMode mode = ParsingMode.XML;
/*  114 */   private boolean caseSensitive = true;
/*      */   
/*  116 */   private boolean textSplittable = false;
/*      */   
/*  118 */   private ElementBalancing elementBalancing = ElementBalancing.NO_BALANCING;
/*      */   
/*  120 */   private boolean noUnmatchedCloseElementsRequired = false;
/*  121 */   private boolean xmlWellFormedAttributeValuesRequired = false;
/*  122 */   private boolean uniqueAttributesInElementRequired = false;
/*      */   
/*  124 */   private PrologParseConfiguration prologParseConfiguration = new PrologParseConfiguration();
/*  125 */   private UniqueRootElementPresence uniqueRootElementPresence = UniqueRootElementPresence.DEPENDS_ON_PROLOG_DOCTYPE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  133 */   private static final ParseConfiguration DEFAULT_HTML_PARSE_CONFIGURATION = new ParseConfiguration();
/*  134 */   static { DEFAULT_HTML_PARSE_CONFIGURATION.setMode(ParsingMode.HTML);
/*  135 */     DEFAULT_HTML_PARSE_CONFIGURATION.setTextSplittable(false);
/*  136 */     DEFAULT_HTML_PARSE_CONFIGURATION.setElementBalancing(ElementBalancing.AUTO_CLOSE);
/*  137 */     DEFAULT_HTML_PARSE_CONFIGURATION.setNoUnmatchedCloseElementsRequired(false);
/*  138 */     DEFAULT_HTML_PARSE_CONFIGURATION.setUniqueAttributesInElementRequired(false);
/*  139 */     DEFAULT_HTML_PARSE_CONFIGURATION.setXmlWellFormedAttributeValuesRequired(false);
/*  140 */     DEFAULT_HTML_PARSE_CONFIGURATION.setUniqueRootElementPresence(UniqueRootElementPresence.NOT_VALIDATED);
/*  141 */     DEFAULT_HTML_PARSE_CONFIGURATION.getPrologParseConfiguration().setValidateProlog(false);
/*  142 */     DEFAULT_HTML_PARSE_CONFIGURATION.getPrologParseConfiguration().setPrologPresence(PrologPresence.ALLOWED);
/*  143 */     DEFAULT_HTML_PARSE_CONFIGURATION.getPrologParseConfiguration().setXmlDeclarationPresence(PrologPresence.ALLOWED);
/*  144 */     DEFAULT_HTML_PARSE_CONFIGURATION.getPrologParseConfiguration().setDoctypePresence(PrologPresence.ALLOWED);
/*  145 */     DEFAULT_HTML_PARSE_CONFIGURATION.getPrologParseConfiguration().setRequireDoctypeKeywordsUpperCase(false);
/*      */     
/*      */ 
/*  148 */     DEFAULT_XML_PARSE_CONFIGURATION = new ParseConfiguration();
/*  149 */     DEFAULT_XML_PARSE_CONFIGURATION.setMode(ParsingMode.XML);
/*  150 */     DEFAULT_XML_PARSE_CONFIGURATION.setTextSplittable(false);
/*  151 */     DEFAULT_XML_PARSE_CONFIGURATION.setElementBalancing(ElementBalancing.REQUIRE_BALANCED);
/*  152 */     DEFAULT_XML_PARSE_CONFIGURATION.setNoUnmatchedCloseElementsRequired(true);
/*  153 */     DEFAULT_XML_PARSE_CONFIGURATION.setUniqueAttributesInElementRequired(true);
/*  154 */     DEFAULT_XML_PARSE_CONFIGURATION.setXmlWellFormedAttributeValuesRequired(true);
/*  155 */     DEFAULT_XML_PARSE_CONFIGURATION.setUniqueRootElementPresence(UniqueRootElementPresence.DEPENDS_ON_PROLOG_DOCTYPE);
/*  156 */     DEFAULT_XML_PARSE_CONFIGURATION.getPrologParseConfiguration().setValidateProlog(true);
/*  157 */     DEFAULT_XML_PARSE_CONFIGURATION.getPrologParseConfiguration().setPrologPresence(PrologPresence.ALLOWED);
/*  158 */     DEFAULT_XML_PARSE_CONFIGURATION.getPrologParseConfiguration().setXmlDeclarationPresence(PrologPresence.ALLOWED);
/*  159 */     DEFAULT_XML_PARSE_CONFIGURATION.getPrologParseConfiguration().setDoctypePresence(PrologPresence.ALLOWED);
/*  160 */     DEFAULT_XML_PARSE_CONFIGURATION.getPrologParseConfiguration().setRequireDoctypeKeywordsUpperCase(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ParseConfiguration htmlConfiguration()
/*      */   {
/*      */     try
/*      */     {
/*  185 */       return DEFAULT_HTML_PARSE_CONFIGURATION.clone();
/*      */     }
/*      */     catch (CloneNotSupportedException e) {
/*  188 */       throw new IllegalStateException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ParseConfiguration xmlConfiguration()
/*      */   {
/*      */     try
/*      */     {
/*  218 */       return DEFAULT_XML_PARSE_CONFIGURATION.clone();
/*      */     }
/*      */     catch (CloneNotSupportedException e) {
/*  221 */       throw new IllegalStateException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ParsingMode getMode()
/*      */   {
/*  253 */     return this.mode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMode(ParsingMode mode)
/*      */   {
/*  270 */     this.mode = mode;
/*  271 */     if (ParsingMode.HTML.equals(this.mode))
/*      */     {
/*  273 */       this.caseSensitive = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCaseSensitive()
/*      */   {
/*  293 */     return this.caseSensitive;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCaseSensitive(boolean caseSensitive)
/*      */   {
/*  310 */     if ((caseSensitive) && (ParsingMode.HTML.equals(this.mode))) {
/*  311 */       throw new IllegalArgumentException("Cannot set parser as case-sensitive for HTML mode. Use XML mode instead.");
/*      */     }
/*      */     
/*  314 */     this.caseSensitive = caseSensitive;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isTextSplittable()
/*      */   {
/*  332 */     return this.textSplittable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextSplittable(boolean textSplittable)
/*      */   {
/*  348 */     this.textSplittable = textSplittable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final long serialVersionUID = 5191449744126332911L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ElementBalancing getElementBalancing()
/*      */   {
/*  389 */     return this.elementBalancing;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setElementBalancing(ElementBalancing elementBalancing)
/*      */   {
/*  428 */     this.elementBalancing = elementBalancing;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PrologParseConfiguration getPrologParseConfiguration()
/*      */   {
/*  443 */     return this.prologParseConfiguration;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isNoUnmatchedCloseElementsRequired()
/*      */   {
/*  458 */     return this.noUnmatchedCloseElementsRequired;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNoUnmatchedCloseElementsRequired(boolean noUnmatchedCloseElementsRequired)
/*      */   {
/*  473 */     this.noUnmatchedCloseElementsRequired = noUnmatchedCloseElementsRequired;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isXmlWellFormedAttributeValuesRequired()
/*      */   {
/*  492 */     return this.xmlWellFormedAttributeValuesRequired;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setXmlWellFormedAttributeValuesRequired(boolean xmlWellFormedAttributeValuesRequired)
/*      */   {
/*  510 */     this.xmlWellFormedAttributeValuesRequired = xmlWellFormedAttributeValuesRequired;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUniqueAttributesInElementRequired()
/*      */   {
/*  524 */     return this.uniqueAttributesInElementRequired;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUniqueAttributesInElementRequired(boolean uniqueAttributesInElementRequired)
/*      */   {
/*  536 */     this.uniqueAttributesInElementRequired = uniqueAttributesInElementRequired;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final ParseConfiguration DEFAULT_XML_PARSE_CONFIGURATION;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UniqueRootElementPresence getUniqueRootElementPresence()
/*      */   {
/*  581 */     return this.uniqueRootElementPresence;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUniqueRootElementPresence(UniqueRootElementPresence uniqueRootElementPresence)
/*      */   {
/*  624 */     validateNotNull(uniqueRootElementPresence, "The \"unique root element presence\" configuration value cannot be null");
/*  625 */     this.uniqueRootElementPresence = uniqueRootElementPresence;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ParseConfiguration clone()
/*      */     throws CloneNotSupportedException
/*      */   {
/*  634 */     ParseConfiguration conf = (ParseConfiguration)super.clone();
/*  635 */     conf.mode = this.mode;
/*  636 */     conf.caseSensitive = this.caseSensitive;
/*  637 */     conf.elementBalancing = this.elementBalancing;
/*  638 */     conf.uniqueAttributesInElementRequired = this.uniqueAttributesInElementRequired;
/*  639 */     conf.xmlWellFormedAttributeValuesRequired = this.xmlWellFormedAttributeValuesRequired;
/*  640 */     conf.uniqueRootElementPresence = this.uniqueRootElementPresence;
/*  641 */     conf.prologParseConfiguration = this.prologParseConfiguration.clone();
/*  642 */     return conf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static enum ParsingMode
/*      */   {
/*  656 */     HTML,  XML;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private ParsingMode() {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static enum PrologPresence
/*      */   {
/*  671 */     REQUIRED(true, false, false), 
/*  672 */     ALLOWED(false, true, false), 
/*  673 */     FORBIDDEN(false, false, true);
/*      */     
/*      */     private final boolean required;
/*      */     private final boolean allowed;
/*      */     private final boolean forbidden;
/*      */     
/*      */     private PrologPresence(boolean required, boolean allowed, boolean forbidden)
/*      */     {
/*  681 */       this.required = required;
/*  682 */       this.allowed = allowed;
/*  683 */       this.forbidden = forbidden;
/*      */     }
/*      */     
/*      */     public boolean isRequired() {
/*  687 */       return this.required;
/*      */     }
/*      */     
/*      */     public boolean isAllowed() {
/*  691 */       return this.allowed;
/*      */     }
/*      */     
/*      */     public boolean isForbidden() {
/*  695 */       return this.forbidden;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static enum UniqueRootElementPresence
/*      */   {
/*  718 */     REQUIRED_ALWAYS(true, false), 
/*  719 */     DEPENDS_ON_PROLOG_DOCTYPE(false, true), 
/*  720 */     NOT_VALIDATED(false, false);
/*      */     
/*      */     private final boolean requiredAlways;
/*      */     private final boolean dependsOnPrologDoctype;
/*      */     
/*      */     private UniqueRootElementPresence(boolean requiredAlways, boolean dependsOnPrologDoctype)
/*      */     {
/*  727 */       this.requiredAlways = requiredAlways;
/*  728 */       this.dependsOnPrologDoctype = dependsOnPrologDoctype;
/*      */     }
/*      */     
/*      */     public boolean isRequiredAlways() {
/*  732 */       return this.requiredAlways;
/*      */     }
/*      */     
/*      */     public boolean isDependsOnPrologDoctype() {
/*  736 */       return this.dependsOnPrologDoctype;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class PrologParseConfiguration
/*      */     implements Serializable, Cloneable
/*      */   {
/*      */     private static final long serialVersionUID = -4291053503740751549L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  776 */     private boolean validateProlog = false;
/*  777 */     private ParseConfiguration.PrologPresence prologPresence = ParseConfiguration.PrologPresence.ALLOWED;
/*  778 */     private ParseConfiguration.PrologPresence xmlDeclarationPresence = ParseConfiguration.PrologPresence.ALLOWED;
/*  779 */     private ParseConfiguration.PrologPresence doctypePresence = ParseConfiguration.PrologPresence.ALLOWED;
/*  780 */     private boolean requireDoctypeKeywordsUpperCase = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isValidateProlog()
/*      */     {
/*  833 */       return this.validateProlog;
/*      */     }
/*      */     
/*      */     public void setValidateProlog(boolean validateProlog) {
/*  837 */       this.validateProlog = validateProlog;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public ParseConfiguration.PrologPresence getPrologPresence()
/*      */     {
/*  850 */       return this.prologPresence;
/*      */     }
/*      */     
/*      */     public void setPrologPresence(ParseConfiguration.PrologPresence prologPresence) {
/*  854 */       ParseConfiguration.validateNotNull(this.prologPresence, "Prolog presence cannot be null");
/*  855 */       this.prologPresence = prologPresence;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public ParseConfiguration.PrologPresence getXmlDeclarationPresence()
/*      */     {
/*  868 */       return this.xmlDeclarationPresence;
/*      */     }
/*      */     
/*      */     public void setXmlDeclarationPresence(ParseConfiguration.PrologPresence xmlDeclarationPresence) {
/*  872 */       ParseConfiguration.validateNotNull(this.prologPresence, "XML Declaration presence cannot be null");
/*  873 */       this.xmlDeclarationPresence = xmlDeclarationPresence;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public ParseConfiguration.PrologPresence getDoctypePresence()
/*      */     {
/*  886 */       return this.doctypePresence;
/*      */     }
/*      */     
/*      */     public void setDoctypePresence(ParseConfiguration.PrologPresence doctypePresence) {
/*  890 */       ParseConfiguration.validateNotNull(this.prologPresence, "DOCTYPE presence cannot be null");
/*  891 */       this.doctypePresence = doctypePresence;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isRequireDoctypeKeywordsUpperCase()
/*      */     {
/*  909 */       return this.requireDoctypeKeywordsUpperCase;
/*      */     }
/*      */     
/*      */     public void setRequireDoctypeKeywordsUpperCase(boolean requireDoctypeKeywordsUpperCase) {
/*  913 */       this.requireDoctypeKeywordsUpperCase = requireDoctypeKeywordsUpperCase;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void validateConfiguration()
/*      */     {
/*  955 */       if (!this.validateProlog)
/*      */       {
/*  957 */         return;
/*      */       }
/*      */       
/*  960 */       if (ParseConfiguration.PrologPresence.FORBIDDEN.equals(this.prologPresence)) {
/*  961 */         if ((!ParseConfiguration.PrologPresence.FORBIDDEN.equals(this.xmlDeclarationPresence)) || 
/*  962 */           (!ParseConfiguration.PrologPresence.FORBIDDEN.equals(this.doctypePresence))) {}
/*      */       }
/*      */       else
/*      */       {
/*  966 */         if ((ParseConfiguration.PrologPresence.REQUIRED.equals(this.xmlDeclarationPresence)) || 
/*  967 */           (ParseConfiguration.PrologPresence.REQUIRED.equals(this.doctypePresence))) {
/*  968 */           return;
/*      */         }
/*  970 */         if ((ParseConfiguration.PrologPresence.ALLOWED.equals(this.prologPresence)) && (
/*  971 */           (!ParseConfiguration.PrologPresence.FORBIDDEN.equals(this.xmlDeclarationPresence)) || 
/*  972 */           (!ParseConfiguration.PrologPresence.FORBIDDEN.equals(this.doctypePresence)))) {
/*  973 */           return;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  978 */       throw new IllegalArgumentException("Prolog parsing configuration is not valid: Prolog presence: " + this.prologPresence + ", XML Declaration presence: " + this.xmlDeclarationPresence + ", DOCTYPE presence: " + this.doctypePresence);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public PrologParseConfiguration clone()
/*      */       throws CloneNotSupportedException
/*      */     {
/*  990 */       PrologParseConfiguration conf = (PrologParseConfiguration)super.clone();
/*  991 */       conf.validateProlog = this.validateProlog;
/*  992 */       conf.prologPresence = this.prologPresence;
/*  993 */       conf.doctypePresence = this.doctypePresence;
/*  994 */       conf.xmlDeclarationPresence = this.xmlDeclarationPresence;
/*  995 */       conf.requireDoctypeKeywordsUpperCase = this.requireDoctypeKeywordsUpperCase;
/*  996 */       return conf;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void validateNotNull(Object obj, String message)
/*      */   {
/* 1005 */     if (obj == null) {
/* 1006 */       throw new IllegalArgumentException(message);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\config\ParseConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */