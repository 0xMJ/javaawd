package org.attoparser;

public abstract interface IElementHandler
  extends IAttributeSequenceHandler
{
  public abstract void handleStandaloneElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleStandaloneElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleOpenElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleOpenElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleAutoOpenElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleAutoOpenElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleCloseElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleCloseElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleAutoCloseElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleAutoCloseElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleUnmatchedCloseElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleUnmatchedCloseElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\IElementHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */