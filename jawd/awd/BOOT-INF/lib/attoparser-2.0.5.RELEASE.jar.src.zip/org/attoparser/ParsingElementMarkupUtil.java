/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParsingElementMarkupUtil
/*     */ {
/*     */   public static void parseStandaloneElement(char[] buffer, int offset, int len, int line, int col, IMarkupHandler markupHandler)
/*     */     throws ParseException
/*     */   {
/*  49 */     if ((len < 4) || (!isOpenElementStart(buffer, offset, offset + len)) || (!isElementEnd(buffer, offset + len - 2, offset + len, true))) {
/*  50 */       throw new ParseException("Could not parse as a well-formed standalone element: \"" + new String(buffer, offset, len) + "\"", line, col);
/*     */     }
/*     */     
/*     */ 
/*  54 */     int contentOffset = offset + 1;
/*  55 */     int contentLen = len - 3;
/*     */     
/*  57 */     int maxi = contentOffset + contentLen;
/*     */     
/*  59 */     int[] locator = { line, col + 1 };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */     int elementNameEnd = ParsingMarkupUtil.findNextWhitespaceCharWildcard(buffer, contentOffset, maxi, true, locator);
/*     */     
/*  68 */     if (elementNameEnd == -1)
/*     */     {
/*     */ 
/*  71 */       markupHandler.handleStandaloneElementStart(buffer, contentOffset, contentLen, true, line, col);
/*     */       
/*     */ 
/*     */ 
/*  75 */       markupHandler.handleStandaloneElementEnd(buffer, contentOffset, contentLen, true, locator[0], locator[1]);
/*     */       
/*     */ 
/*     */ 
/*  79 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  84 */     markupHandler.handleStandaloneElementStart(buffer, contentOffset, elementNameEnd - contentOffset, true, line, col);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */     ParsingAttributeSequenceUtil.parseAttributeSequence(buffer, elementNameEnd, maxi - elementNameEnd, locator[0], locator[1], markupHandler);
/*     */     
/*     */ 
/*     */ 
/*  94 */     ParsingMarkupUtil.findNextStructureEndAvoidQuotes(buffer, elementNameEnd, maxi, locator);
/*     */     
/*  96 */     markupHandler.handleStandaloneElementEnd(buffer, contentOffset, elementNameEnd - contentOffset, true, locator[0], locator[1]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void parseOpenElement(char[] buffer, int offset, int len, int line, int col, IMarkupHandler markupHandler)
/*     */     throws ParseException
/*     */   {
/* 112 */     if ((len < 3) || (!isOpenElementStart(buffer, offset, offset + len)) || (!isElementEnd(buffer, offset + len - 1, offset + len, false))) {
/* 113 */       throw new ParseException("Could not parse as a well-formed open element: \"" + new String(buffer, offset, len) + "\"", line, col);
/*     */     }
/*     */     
/*     */ 
/* 117 */     int contentOffset = offset + 1;
/* 118 */     int contentLen = len - 2;
/*     */     
/* 120 */     int maxi = contentOffset + contentLen;
/*     */     
/* 122 */     int[] locator = { line, col + 1 };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */     int elementNameEnd = ParsingMarkupUtil.findNextWhitespaceCharWildcard(buffer, contentOffset, maxi, true, locator);
/*     */     
/* 131 */     if (elementNameEnd == -1)
/*     */     {
/*     */ 
/* 134 */       markupHandler.handleOpenElementStart(buffer, contentOffset, contentLen, line, col);
/*     */       
/*     */ 
/*     */ 
/* 138 */       markupHandler.handleOpenElementEnd(buffer, contentOffset, contentLen, locator[0], locator[1]);
/*     */       
/*     */ 
/*     */ 
/* 142 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 147 */     markupHandler.handleOpenElementStart(buffer, contentOffset, elementNameEnd - contentOffset, line, col);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */     ParsingAttributeSequenceUtil.parseAttributeSequence(buffer, elementNameEnd, maxi - elementNameEnd, locator[0], locator[1], markupHandler);
/*     */     
/*     */ 
/*     */ 
/* 157 */     ParsingMarkupUtil.findNextStructureEndAvoidQuotes(buffer, elementNameEnd, maxi, locator);
/*     */     
/* 159 */     markupHandler.handleOpenElementEnd(buffer, contentOffset, elementNameEnd - contentOffset, locator[0], locator[1]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void parseCloseElement(char[] buffer, int offset, int len, int line, int col, IMarkupHandler markupHandler)
/*     */     throws ParseException
/*     */   {
/* 175 */     if ((len < 4) || (!isCloseElementStart(buffer, offset, offset + len)) || (!isElementEnd(buffer, offset + len - 1, offset + len, false))) {
/* 176 */       throw new ParseException("Could not parse as a well-formed close element: \"" + new String(buffer, offset, len) + "\"", line, col);
/*     */     }
/*     */     
/*     */ 
/* 180 */     int contentOffset = offset + 2;
/* 181 */     int contentLen = len - 3;
/*     */     
/* 183 */     int maxi = contentOffset + contentLen;
/*     */     
/* 185 */     int[] locator = { line, col + 2 };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */     int elementNameEnd = ParsingMarkupUtil.findNextWhitespaceCharWildcard(buffer, contentOffset, maxi, true, locator);
/*     */     
/* 194 */     if (elementNameEnd == -1)
/*     */     {
/*     */ 
/* 197 */       markupHandler.handleCloseElementStart(buffer, contentOffset, contentLen, line, col);
/*     */       
/*     */ 
/*     */ 
/* 201 */       markupHandler.handleCloseElementEnd(buffer, contentOffset, contentLen, locator[0], locator[1]);
/*     */       
/*     */ 
/*     */ 
/* 205 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 210 */     markupHandler.handleCloseElementStart(buffer, contentOffset, elementNameEnd - contentOffset, line, col);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 215 */     int currentArtifactLine = locator[0];
/* 216 */     int currentArtifactCol = locator[1];
/*     */     
/*     */ 
/* 219 */     int wsEnd = ParsingMarkupUtil.findNextNonWhitespaceCharWildcard(buffer, elementNameEnd, maxi, locator);
/*     */     
/* 221 */     if (wsEnd != -1)
/*     */     {
/*     */ 
/* 224 */       throw new ParseException("Could not parse as a well-formed closing element \"</" + new String(buffer, contentOffset, contentLen) + ">\": No attributes are allowed here", line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 231 */     markupHandler.handleInnerWhiteSpace(buffer, elementNameEnd, maxi - elementNameEnd, currentArtifactLine, currentArtifactCol);
/*     */     
/*     */ 
/* 234 */     markupHandler.handleCloseElementEnd(buffer, contentOffset, elementNameEnd - contentOffset, locator[0], locator[1]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean isOpenElementStart(char[] buffer, int offset, int maxi)
/*     */   {
/* 247 */     int len = maxi - offset;
/*     */     
/* 249 */     if ((len > 1) && (buffer[offset] == '<')) {} return 
/*     */     
/* 251 */       isElementName(buffer, offset + 1, maxi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static boolean isCloseElementStart(char[] buffer, int offset, int maxi)
/*     */   {
/* 258 */     int len = maxi - offset;
/*     */     
/* 260 */     if ((len > 2) && (buffer[offset] == '<') && (buffer[(offset + 1)] == '/')) {} return 
/*     */     
/*     */ 
/* 263 */       isElementName(buffer, offset + 2, maxi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static boolean isElementEnd(char[] buffer, int offset, int maxi, boolean minimized)
/*     */   {
/* 270 */     int len = maxi - offset;
/*     */     
/* 272 */     if (len < 1) {
/* 273 */       return false;
/*     */     }
/*     */     
/* 276 */     if (minimized) {
/* 277 */       if ((len < 2) || (buffer[offset] != '/')) {
/* 278 */         return false;
/*     */       }
/* 280 */       return buffer[(offset + 1)] == '>';
/*     */     }
/*     */     
/* 283 */     return buffer[offset] == '>';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isElementName(char[] buffer, int offset, int maxi)
/*     */   {
/* 293 */     int len = maxi - offset;
/*     */     
/* 295 */     if ((len > 1) && (buffer[offset] == '!')) {
/* 296 */       if (len > 8) {
/* 297 */         return (buffer[(offset + 1)] != '-') && (buffer[(offset + 1)] != '!') && (buffer[(offset + 1)] != '/') && (buffer[(offset + 1)] != '?') && (buffer[(offset + 1)] != '[') && (((buffer[(offset + 1)] != 'D') && (buffer[(offset + 1)] != 'd')) || ((buffer[(offset + 2)] != 'O') && (buffer[(offset + 2)] != 'o')) || ((buffer[(offset + 3)] != 'C') && (buffer[(offset + 3)] != 'c')) || ((buffer[(offset + 4)] != 'T') && (buffer[(offset + 4)] != 't')) || ((buffer[(offset + 5)] != 'Y') && (buffer[(offset + 5)] != 'y')) || ((buffer[(offset + 6)] != 'P') && (buffer[(offset + 6)] != 'p')) || ((buffer[(offset + 7)] != 'E') && (buffer[(offset + 7)] != 'e')) || (
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 307 */           (!Character.isWhitespace(buffer[(offset + 8)])) && (buffer[(offset + 8)] != '>')));
/*     */       }
/* 309 */       if ((buffer[(offset + 1)] != '-') && (buffer[(offset + 1)] != '!') && (buffer[(offset + 1)] != '/') && (buffer[(offset + 1)] != '?') && (buffer[(offset + 1)] != '[')) {} return 
/*     */       
/* 311 */         !Character.isWhitespace(buffer[(offset + 1)]);
/*     */     }
/* 313 */     if ((len > 0) && (buffer[offset] != '-') && (buffer[offset] != '!') && (buffer[offset] != '/') && (buffer[offset] != '?') && (buffer[offset] != '[')) {} return 
/*     */     
/*     */ 
/* 316 */       !Character.isWhitespace(buffer[offset]);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\ParsingElementMarkupUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */