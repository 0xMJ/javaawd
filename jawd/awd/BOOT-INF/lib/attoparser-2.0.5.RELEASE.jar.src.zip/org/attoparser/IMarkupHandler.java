package org.attoparser;

import org.attoparser.config.ParseConfiguration;
import org.attoparser.select.ParseSelection;

public abstract interface IMarkupHandler
  extends IDocumentHandler, IXMLDeclarationHandler, IDocTypeHandler, ICDATASectionHandler, ICommentHandler, ITextHandler, IElementHandler, IProcessingInstructionHandler
{
  public abstract void setParseConfiguration(ParseConfiguration paramParseConfiguration);
  
  public abstract void setParseStatus(ParseStatus paramParseStatus);
  
  public abstract void setParseSelection(ParseSelection paramParseSelection);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\IMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */