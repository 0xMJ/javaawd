/*     */ package org.attoparser;
/*     */ 
/*     */ import org.attoparser.util.TextUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HtmlCDATAContentElement
/*     */   extends HtmlElement
/*     */ {
/*  38 */   private static final char[] ELEMENT_SCRIPT_NAME = "script".toCharArray();
/*  39 */   private static final char[] ATTRIBUTE_TYPE_NAME = "type".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*  43 */   private static final char[] ATTRIBUTE_TYPE_JAVASCRIPT_VALUE = "javascript".toCharArray();
/*  44 */   private static final char[] ATTRIBUTE_TYPE_ECMASCRIPT_VALUE = "ecmascript".toCharArray();
/*  45 */   private static final char[] ATTRIBUTE_TYPE_TEXT_JAVASCRIPT_VALUE = "text/javascript".toCharArray();
/*  46 */   private static final char[] ATTRIBUTE_TYPE_TEXT_ECMASCRIPT_VALUE = "text/ecmascript".toCharArray();
/*  47 */   private static final char[] ATTRIBUTE_TYPE_APPLICATION_JAVASCRIPT_VALUE = "application/javascript".toCharArray();
/*  48 */   private static final char[] ATTRIBUTE_TYPE_APPLICATION_ECMASCRIPT_VALUE = "application/ecmascript".toCharArray();
/*     */   
/*     */   private final char[] nameLower;
/*     */   
/*     */   private final char[] nameUpper;
/*     */   private final char[] limitSequenceLower;
/*     */   private final char[] limitSequenceUpper;
/*     */   
/*     */   public HtmlCDATAContentElement(String name)
/*     */   {
/*  58 */     super(name);
/*     */     
/*     */ 
/*  61 */     String nameLower = name.toLowerCase();
/*  62 */     String nameUppoer = name.toUpperCase();
/*     */     
/*  64 */     this.nameLower = nameLower.toCharArray();
/*  65 */     this.nameUpper = nameUppoer.toCharArray();
/*     */     
/*  67 */     this.limitSequenceLower = ("</" + nameLower + ">").toCharArray();
/*  68 */     this.limitSequenceUpper = ("</" + nameUppoer + ">").toCharArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled)
/*     */     throws ParseException
/*     */   {
/*  85 */     status.shouldDisableParsing = true;
/*     */     
/*  87 */     handler.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled)
/*     */     throws ParseException
/*     */   {
/* 104 */     handler.handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */     
/* 106 */     if (status.shouldDisableParsing)
/*     */     {
/* 108 */       status.setParsingDisabled(computeLimitSequence(buffer, nameOffset, nameLen));
/*     */       
/* 110 */       status.shouldDisableParsing = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled)
/*     */     throws ParseException
/*     */   {
/* 132 */     if (TextUtil.equals(false, buffer, nameOffset, nameLen, ATTRIBUTE_TYPE_NAME, 0, ATTRIBUTE_TYPE_NAME.length))
/*     */     {
/* 134 */       if (TextUtil.equals(true, this.nameLower, 0, this.nameLower.length, ELEMENT_SCRIPT_NAME, 0, ELEMENT_SCRIPT_NAME.length))
/*     */       {
/*     */ 
/*     */ 
/* 138 */         status.shouldDisableParsing = false;
/*     */         
/* 140 */         if ((TextUtil.endsWith(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_JAVASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_JAVASCRIPT_VALUE.length)) || 
/* 141 */           (TextUtil.endsWith(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_ECMASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_ECMASCRIPT_VALUE.length)))
/*     */         {
/*     */ 
/* 144 */           if ((TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_JAVASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_JAVASCRIPT_VALUE.length)) || 
/* 145 */             (TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_ECMASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_ECMASCRIPT_VALUE.length)))
/*     */           {
/* 147 */             status.shouldDisableParsing = true;
/*     */           }
/* 149 */           else if ((TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_TEXT_JAVASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_TEXT_JAVASCRIPT_VALUE.length)) || 
/* 150 */             (TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_TEXT_ECMASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_TEXT_ECMASCRIPT_VALUE.length)))
/*     */           {
/* 152 */             status.shouldDisableParsing = true;
/*     */           }
/* 154 */           else if ((TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_APPLICATION_JAVASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_APPLICATION_JAVASCRIPT_VALUE.length)) || 
/* 155 */             (TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_APPLICATION_ECMASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_APPLICATION_ECMASCRIPT_VALUE.length)))
/*     */           {
/* 157 */             status.shouldDisableParsing = true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 165 */     handler.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private char[] computeLimitSequence(char[] buffer, int nameOffset, int nameLen)
/*     */   {
/* 177 */     if (TextUtil.equals(true, this.nameLower, 0, this.nameLower.length, buffer, nameOffset, nameLen)) {
/* 178 */       return this.limitSequenceLower;
/*     */     }
/*     */     
/* 181 */     if (TextUtil.equals(true, this.nameUpper, 0, this.nameUpper.length, buffer, nameOffset, nameLen)) {
/* 182 */       return this.limitSequenceUpper;
/*     */     }
/*     */     
/* 185 */     char[] limitSeq = new char[nameLen + 3];
/* 186 */     limitSeq[0] = '<';
/* 187 */     limitSeq[1] = '/';
/* 188 */     System.arraycopy(buffer, nameOffset, limitSeq, 2, nameLen);
/* 189 */     limitSeq[(nameLen + 2)] = '>';
/* 190 */     return limitSeq;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\HtmlCDATAContentElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */