package org.attoparser.simple;

import java.util.Map;
import org.attoparser.ParseException;

public abstract interface ISimpleMarkupHandler
{
  public abstract void handleDocumentStart(long paramLong, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract void handleDocumentEnd(long paramLong1, long paramLong2, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract void handleXmlDeclaration(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract void handleDocType(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract void handleCDATASection(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleComment(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleText(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
  
  public abstract void handleStandaloneElement(String paramString, Map<String, String> paramMap, boolean paramBoolean, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract void handleOpenElement(String paramString, Map<String, String> paramMap, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract void handleAutoOpenElement(String paramString, Map<String, String> paramMap, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract void handleCloseElement(String paramString, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract void handleAutoCloseElement(String paramString, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract void handleUnmatchedCloseElement(String paramString, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract void handleProcessingInstruction(String paramString1, String paramString2, int paramInt1, int paramInt2)
    throws ParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\simple\ISimpleMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */