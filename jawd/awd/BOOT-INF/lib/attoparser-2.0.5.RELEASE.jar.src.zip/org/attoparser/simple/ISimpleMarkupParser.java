package org.attoparser.simple;

import java.io.Reader;
import org.attoparser.ParseException;

public abstract interface ISimpleMarkupParser
{
  public abstract void parse(String paramString, ISimpleMarkupHandler paramISimpleMarkupHandler)
    throws ParseException;
  
  public abstract void parse(char[] paramArrayOfChar, ISimpleMarkupHandler paramISimpleMarkupHandler)
    throws ParseException;
  
  public abstract void parse(char[] paramArrayOfChar, int paramInt1, int paramInt2, ISimpleMarkupHandler paramISimpleMarkupHandler)
    throws ParseException;
  
  public abstract void parse(Reader paramReader, ISimpleMarkupHandler paramISimpleMarkupHandler)
    throws ParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\simple\ISimpleMarkupParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */