/*     */ package org.attoparser.simple;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.attoparser.AbstractMarkupHandler;
/*     */ import org.attoparser.ParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SimplifierMarkupHandler
/*     */   extends AbstractMarkupHandler
/*     */ {
/*     */   private final ISimpleMarkupHandler handler;
/*     */   private String currentElementName;
/*     */   private Map<String, String> currentElementAttributes;
/*     */   private int currentElementLine;
/*     */   private int currentElementCol;
/*     */   
/*     */   public SimplifierMarkupHandler(ISimpleMarkupHandler handler)
/*     */   {
/*  92 */     if (handler == null) {
/*  93 */       throw new IllegalArgumentException("Delegate handler cannot be null");
/*     */     }
/*  95 */     this.handler = handler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentStart(long startTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 107 */     this.handler.handleDocumentStart(startTimeNanos, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 119 */     this.handler.handleDocumentEnd(endTimeNanos, totalTimeNanos, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleXmlDeclaration(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int versionOffset, int versionLen, int versionLine, int versionCol, int encodingOffset, int encodingLen, int encodingLine, int encodingCol, int standaloneOffset, int standaloneLen, int standaloneLine, int standaloneCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 140 */     String version = new String(buffer, versionOffset, versionLen);
/*     */     
/*     */ 
/*     */ 
/* 144 */     String encoding = encodingOffset > 0 ? new String(buffer, encodingOffset, encodingLen) : null;
/*     */     
/*     */ 
/*     */ 
/* 148 */     String standalone = standaloneOffset > 0 ? new String(buffer, standaloneOffset, standaloneLen) : null;
/*     */     
/* 150 */     this.handler.handleXmlDeclaration(version, encoding, standalone, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocType(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int elementNameOffset, int elementNameLen, int elementNameLine, int elementNameCol, int typeOffset, int typeLen, int typeLine, int typeCol, int publicIdOffset, int publicIdLen, int publicIdLine, int publicIdCol, int systemIdOffset, int systemIdLen, int systemIdLine, int systemIdCol, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, int outerOffset, int outerLen, int outerLine, int outerCol)
/*     */     throws ParseException
/*     */   {
/* 175 */     this.handler.handleDocType(new String(buffer, elementNameOffset, elementNameLen), 
/*     */     
/* 177 */       publicIdOffset <= 0 ? null : new String(buffer, publicIdOffset, publicIdLen), 
/* 178 */       systemIdOffset <= 0 ? null : new String(buffer, systemIdOffset, systemIdLen), 
/* 179 */       internalSubsetOffset <= 0 ? null : new String(buffer, internalSubsetOffset, internalSubsetLen), outerLine, outerCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCDATASection(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 194 */     this.handler.handleCDATASection(buffer, contentOffset, contentLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 208 */     this.handler.handleComment(buffer, contentOffset, contentLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 221 */     this.handler.handleText(buffer, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 237 */     this.currentElementName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/* 238 */     this.currentElementAttributes = null;
/* 239 */     this.currentElementLine = line;
/* 240 */     this.currentElementCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 253 */     this.handler.handleStandaloneElement(this.currentElementName, this.currentElementAttributes, minimized, this.currentElementLine, this.currentElementCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 267 */     this.currentElementName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/* 268 */     this.currentElementAttributes = null;
/* 269 */     this.currentElementLine = line;
/* 270 */     this.currentElementCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 283 */     this.handler.handleOpenElement(this.currentElementName, this.currentElementAttributes, this.currentElementLine, this.currentElementCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 296 */     this.currentElementName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/* 297 */     this.currentElementAttributes = null;
/* 298 */     this.currentElementLine = line;
/* 299 */     this.currentElementCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 312 */     this.handler.handleAutoOpenElement(this.currentElementName, this.currentElementAttributes, this.currentElementLine, this.currentElementCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 325 */     this.currentElementName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/* 326 */     this.currentElementAttributes = null;
/* 327 */     this.currentElementLine = line;
/* 328 */     this.currentElementCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 341 */     this.handler.handleCloseElement(this.currentElementName, this.currentElementLine, this.currentElementCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 355 */     this.currentElementName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/* 356 */     this.currentElementAttributes = null;
/* 357 */     this.currentElementLine = line;
/* 358 */     this.currentElementCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 371 */     this.handler.handleAutoCloseElement(this.currentElementName, this.currentElementLine, this.currentElementCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 385 */     this.currentElementName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/* 386 */     this.currentElementAttributes = null;
/* 387 */     this.currentElementLine = line;
/* 388 */     this.currentElementCol = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 401 */     this.handler.handleUnmatchedCloseElement(this.currentElementName, this.currentElementLine, this.currentElementCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws ParseException
/*     */   {
/* 420 */     String attributeName = StructureTextsRepository.getStructureName(buffer, nameOffset, nameLen);
/*     */     
/* 422 */     String attributeValue = valueContentLen <= 0 ? "" : new String(buffer, valueContentOffset, valueContentLen);
/*     */     
/* 424 */     if (this.currentElementAttributes == null) {
/* 425 */       this.currentElementAttributes = new LinkedHashMap(3, 1.0F);
/*     */     }
/*     */     
/* 428 */     this.currentElementAttributes.put(attributeName, attributeValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleProcessingInstruction(char[] buffer, int targetOffset, int targetLen, int targetLine, int targetCol, int contentOffset, int contentLen, int contentLine, int contentCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 458 */     this.handler.handleProcessingInstruction(new String(buffer, targetOffset, targetLen), 
/*     */     
/* 460 */       contentOffset <= 0 ? null : new String(buffer, contentOffset, contentLen), line, col);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\simple\SimplifierMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */