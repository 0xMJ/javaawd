package org.attoparser.simple;

import java.util.Map;
import org.attoparser.ParseException;

public abstract class AbstractSimpleMarkupHandler
  implements ISimpleMarkupHandler
{
  public void handleDocumentStart(long startTimeNanos, int line, int col)
    throws ParseException
  {}
  
  public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
    throws ParseException
  {}
  
  public void handleXmlDeclaration(String version, String encoding, String standalone, int line, int col)
    throws ParseException
  {}
  
  public void handleDocType(String elementName, String publicId, String systemId, String internalSubset, int line, int col)
    throws ParseException
  {}
  
  public void handleCDATASection(char[] buffer, int offset, int len, int line, int col)
    throws ParseException
  {}
  
  public void handleComment(char[] buffer, int offset, int len, int line, int col)
    throws ParseException
  {}
  
  public void handleText(char[] buffer, int offset, int len, int line, int col)
    throws ParseException
  {}
  
  public void handleStandaloneElement(String elementName, Map<String, String> attributes, boolean minimized, int line, int col)
    throws ParseException
  {}
  
  public void handleOpenElement(String elementName, Map<String, String> attributes, int line, int col)
    throws ParseException
  {}
  
  public void handleAutoOpenElement(String elementName, Map<String, String> attributes, int line, int col)
    throws ParseException
  {}
  
  public void handleCloseElement(String elementName, int line, int col)
    throws ParseException
  {}
  
  public void handleAutoCloseElement(String elementName, int line, int col)
    throws ParseException
  {}
  
  public void handleUnmatchedCloseElement(String elementName, int line, int col)
    throws ParseException
  {}
  
  public void handleProcessingInstruction(String target, String content, int line, int col)
    throws ParseException
  {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\simple\AbstractSimpleMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */