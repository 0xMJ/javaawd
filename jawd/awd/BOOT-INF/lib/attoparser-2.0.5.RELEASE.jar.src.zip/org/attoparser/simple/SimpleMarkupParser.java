/*     */ package org.attoparser.simple;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import org.attoparser.MarkupParser;
/*     */ import org.attoparser.ParseException;
/*     */ import org.attoparser.config.ParseConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SimpleMarkupParser
/*     */   implements ISimpleMarkupParser
/*     */ {
/*     */   private final MarkupParser markupParser;
/*     */   
/*     */   public SimpleMarkupParser(ParseConfiguration configuration)
/*     */   {
/* 115 */     if (configuration == null) {
/* 116 */       throw new IllegalArgumentException("Configuration cannot be null");
/*     */     }
/* 118 */     this.markupParser = new MarkupParser(configuration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parse(String document, ISimpleMarkupHandler handler)
/*     */     throws ParseException
/*     */   {
/* 128 */     if (handler == null) {
/* 129 */       throw new IllegalArgumentException("Handler cannot be null");
/*     */     }
/*     */     
/* 132 */     this.markupParser.parse(document, new SimplifierMarkupHandler(handler));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void parse(char[] document, ISimpleMarkupHandler handler)
/*     */     throws ParseException
/*     */   {
/* 140 */     if (handler == null) {
/* 141 */       throw new IllegalArgumentException("Handler cannot be null");
/*     */     }
/*     */     
/* 144 */     this.markupParser.parse(document, new SimplifierMarkupHandler(handler));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parse(char[] document, int offset, int len, ISimpleMarkupHandler handler)
/*     */     throws ParseException
/*     */   {
/* 153 */     if (handler == null) {
/* 154 */       throw new IllegalArgumentException("Handler cannot be null");
/*     */     }
/*     */     
/* 157 */     this.markupParser.parse(document, offset, len, new SimplifierMarkupHandler(handler));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parse(Reader reader, ISimpleMarkupHandler handler)
/*     */     throws ParseException
/*     */   {
/* 166 */     if (handler == null) {
/* 167 */       throw new IllegalArgumentException("Handler cannot be null");
/*     */     }
/*     */     
/* 170 */     this.markupParser.parse(reader, new SimplifierMarkupHandler(handler));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\simple\SimpleMarkupParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */