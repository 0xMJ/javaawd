/*     */ package org.attoparser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.attoparser.util.TextUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HtmlElements
/*     */ {
/*  50 */   private static final HtmlElementRepository ELEMENTS = new HtmlElementRepository();
/*     */   
/*     */ 
/*     */ 
/*     */   static final Set<HtmlElement> ALL_STANDARD_ELEMENTS;
/*     */   
/*     */ 
/*     */ 
/*  58 */   static final HtmlElement HTML = new HtmlElement("html");
/*     */   
/*     */ 
/*  61 */   static final HtmlElement HEAD = new HtmlAutoOpenElement("head", new String[] { "html" }, null);
/*  62 */   static final HtmlElement TITLE = new HtmlHeadElement("title");
/*  63 */   static final HtmlElement BASE = new HtmlVoidHeadElement("base");
/*  64 */   static final HtmlElement LINK = new HtmlVoidHeadElement("link");
/*  65 */   static final HtmlElement META = new HtmlVoidHeadElement("meta");
/*  66 */   static final HtmlElement STYLE = new HtmlHeadCDATAContentElement("style");
/*     */   
/*     */ 
/*  69 */   static final HtmlElement SCRIPT = new HtmlHeadCDATAContentElement("script");
/*  70 */   static final HtmlElement NOSCRIPT = new HtmlHeadElement("noscript");
/*     */   
/*     */ 
/*  73 */   static final HtmlElement BODY = new HtmlAutoOpenCloseElement("body", new String[] { "html" }, null, new String[] { "head" }, null);
/*  74 */   static final HtmlElement ARTICLE = new HtmlBodyBlockElement("article");
/*  75 */   static final HtmlElement SECTION = new HtmlBodyBlockElement("section");
/*  76 */   static final HtmlElement NAV = new HtmlBodyBlockElement("nav");
/*  77 */   static final HtmlElement ASIDE = new HtmlBodyBlockElement("aside");
/*  78 */   static final HtmlElement H1 = new HtmlBodyBlockElement("h1");
/*  79 */   static final HtmlElement H2 = new HtmlBodyBlockElement("h2");
/*  80 */   static final HtmlElement H3 = new HtmlBodyBlockElement("h3");
/*  81 */   static final HtmlElement H4 = new HtmlBodyBlockElement("h4");
/*  82 */   static final HtmlElement H5 = new HtmlBodyBlockElement("h5");
/*  83 */   static final HtmlElement H6 = new HtmlBodyBlockElement("h6");
/*  84 */   static final HtmlElement HGROUP = new HtmlBodyBlockElement("hgroup");
/*  85 */   static final HtmlElement HEADER = new HtmlBodyBlockElement("header");
/*  86 */   static final HtmlElement FOOTER = new HtmlBodyBlockElement("footer");
/*  87 */   static final HtmlElement ADDRESS = new HtmlBodyBlockElement("address");
/*  88 */   static final HtmlElement MAIN = new HtmlBodyBlockElement("main");
/*     */   
/*     */ 
/*  91 */   static final HtmlElement P = new HtmlBodyBlockElement("p");
/*  92 */   static final HtmlElement HR = new HtmlVoidBodyBlockElement("hr");
/*  93 */   static final HtmlElement PRE = new HtmlBodyBlockElement("pre");
/*  94 */   static final HtmlElement BLOCKQUOTE = new HtmlBodyBlockElement("blockquote");
/*  95 */   static final HtmlElement OL = new HtmlBodyBlockElement("ol");
/*  96 */   static final HtmlElement UL = new HtmlBodyBlockElement("ul");
/*  97 */   static final HtmlElement LI = new HtmlBodyAutoCloseElement("li", new String[] { "li" }, new String[] { "ul", "ol" });
/*  98 */   static final HtmlElement DL = new HtmlBodyBlockElement("dl");
/*  99 */   static final HtmlElement DT = new HtmlBodyAutoCloseElement("dt", new String[] { "dt", "dd" }, new String[] { "dl" });
/* 100 */   static final HtmlElement DD = new HtmlBodyAutoCloseElement("dd", new String[] { "dt", "dd" }, new String[] { "dl" });
/* 101 */   static final HtmlElement FIGURE = new HtmlBodyElement("figure");
/* 102 */   static final HtmlElement FIGCAPTION = new HtmlBodyElement("figcaption");
/* 103 */   static final HtmlElement DIV = new HtmlBodyBlockElement("div");
/*     */   
/*     */ 
/* 106 */   static final HtmlElement A = new HtmlBodyElement("a");
/* 107 */   static final HtmlElement EM = new HtmlBodyElement("em");
/* 108 */   static final HtmlElement STRONG = new HtmlBodyElement("strong");
/* 109 */   static final HtmlElement SMALL = new HtmlBodyElement("small");
/* 110 */   static final HtmlElement S = new HtmlBodyElement("s");
/* 111 */   static final HtmlElement CITE = new HtmlBodyElement("cite");
/* 112 */   static final HtmlElement G = new HtmlBodyElement("g");
/* 113 */   static final HtmlElement DFN = new HtmlBodyElement("dfn");
/* 114 */   static final HtmlElement ABBR = new HtmlBodyElement("abbr");
/* 115 */   static final HtmlElement TIME = new HtmlBodyElement("time");
/* 116 */   static final HtmlElement CODE = new HtmlBodyElement("code");
/* 117 */   static final HtmlElement VAR = new HtmlBodyElement("var");
/* 118 */   static final HtmlElement SAMP = new HtmlBodyElement("samp");
/* 119 */   static final HtmlElement KBD = new HtmlBodyElement("kbd");
/* 120 */   static final HtmlElement SUB = new HtmlBodyElement("sub");
/* 121 */   static final HtmlElement SUP = new HtmlBodyElement("sup");
/* 122 */   static final HtmlElement I = new HtmlBodyElement("i");
/* 123 */   static final HtmlElement B = new HtmlBodyElement("b");
/* 124 */   static final HtmlElement U = new HtmlBodyElement("u");
/* 125 */   static final HtmlElement MARK = new HtmlBodyElement("mark");
/* 126 */   static final HtmlElement RUBY = new HtmlBodyElement("ruby");
/* 127 */   static final HtmlElement RB = new HtmlBodyAutoCloseElement("rb", new String[] { "rb", "rt", "rtc", "rp" }, new String[] { "ruby" });
/* 128 */   static final HtmlElement RT = new HtmlBodyAutoCloseElement("rt", new String[] { "rb", "rt", "rp" }, new String[] { "ruby", "rtc" });
/* 129 */   static final HtmlElement RTC = new HtmlBodyAutoCloseElement("rtc", new String[] { "rb", "rt", "rtc", "rp" }, new String[] { "ruby" });
/* 130 */   static final HtmlElement RP = new HtmlBodyAutoCloseElement("rp", new String[] { "rb", "rt", "rp" }, new String[] { "ruby", "rtc" });
/* 131 */   static final HtmlElement BDI = new HtmlBodyElement("bdi");
/* 132 */   static final HtmlElement BDO = new HtmlBodyElement("bdo");
/* 133 */   static final HtmlElement SPAN = new HtmlBodyElement("span");
/* 134 */   static final HtmlElement BR = new HtmlVoidBodyElement("br");
/* 135 */   static final HtmlElement WBR = new HtmlVoidBodyElement("wbr");
/*     */   
/*     */ 
/* 138 */   static final HtmlElement INS = new HtmlBodyElement("ins");
/* 139 */   static final HtmlElement DEL = new HtmlBodyElement("del");
/*     */   
/*     */ 
/* 142 */   static final HtmlElement IMG = new HtmlVoidBodyElement("img");
/* 143 */   static final HtmlElement IFRAME = new HtmlBodyElement("iframe");
/* 144 */   static final HtmlElement EMBED = new HtmlVoidBodyElement("embed");
/* 145 */   static final HtmlElement OBJECT = new HtmlHeadElement("object");
/* 146 */   static final HtmlElement PARAM = new HtmlVoidBodyElement("param");
/* 147 */   static final HtmlElement VIDEO = new HtmlBodyElement("video");
/* 148 */   static final HtmlElement AUDIO = new HtmlBodyElement("audio");
/* 149 */   static final HtmlElement SOURCE = new HtmlVoidBodyElement("source");
/* 150 */   static final HtmlElement TRACK = new HtmlVoidBodyElement("track");
/* 151 */   static final HtmlElement CANVAS = new HtmlBodyElement("canvas");
/* 152 */   static final HtmlElement MAP = new HtmlBodyElement("map");
/* 153 */   static final HtmlElement AREA = new HtmlVoidBodyElement("area");
/*     */   
/*     */ 
/* 156 */   static final HtmlElement TABLE = new HtmlBodyBlockElement("table");
/* 157 */   static final HtmlElement CAPTION = new HtmlBodyAutoCloseElement("caption", new String[] { "tr", "td", "th", "thead", "tfoot", "tbody", "caption", "colgroup" }, new String[] { "table" });
/* 158 */   static final HtmlElement COLGROUP = new HtmlBodyAutoCloseElement("colgroup", new String[] { "tr", "td", "th", "thead", "tfoot", "tbody", "caption", "colgroup" }, new String[] { "table" });
/* 159 */   static final HtmlElement COL = new HtmlVoidAutoOpenCloseElement("col", new String[] { "colgroup" }, new String[] { "colgroup" }, new String[] { "tr", "td", "th", "thead", "tfoot", "tbody", "caption" }, new String[] { "table" });
/* 160 */   static final HtmlElement TBODY = new HtmlBodyAutoCloseElement("tbody", new String[] { "tr", "td", "th", "thead", "tfoot", "tbody", "caption", "colgroup" }, new String[] { "table" });
/* 161 */   static final HtmlElement THEAD = new HtmlBodyAutoCloseElement("thead", new String[] { "tr", "td", "th", "thead", "tfoot", "tbody", "caption", "colgroup" }, new String[] { "table" });
/* 162 */   static final HtmlElement TFOOT = new HtmlBodyAutoCloseElement("tfoot", new String[] { "tr", "td", "th", "thead", "tfoot", "tbody", "caption", "colgroup" }, new String[] { "table" });
/* 163 */   static final HtmlElement TR = new HtmlAutoOpenCloseElement("tr", new String[] { "tbody" }, new String[] { "thead", "tfoot", "tbody" }, new String[] { "tr", "td", "th", "caption", "colgroup" }, new String[] { "table", "thead", "tbody", "tfoot" });
/* 164 */   static final HtmlElement TD = new HtmlBodyAutoCloseElement("td", new String[] { "td", "th" }, new String[] { "tr" });
/* 165 */   static final HtmlElement TH = new HtmlBodyAutoCloseElement("th", new String[] { "td", "th" }, new String[] { "tr" });
/*     */   
/*     */ 
/* 168 */   static final HtmlElement FORM = new HtmlBodyBlockElement("form");
/* 169 */   static final HtmlElement FIELDSET = new HtmlBodyBlockElement("fieldset");
/* 170 */   static final HtmlElement LEGEND = new HtmlBodyElement("legend");
/* 171 */   static final HtmlElement LABEL = new HtmlBodyElement("label");
/* 172 */   static final HtmlElement INPUT = new HtmlVoidBodyElement("input");
/* 173 */   static final HtmlElement BUTTON = new HtmlBodyElement("button");
/* 174 */   static final HtmlElement SELECT = new HtmlBodyElement("select");
/* 175 */   static final HtmlElement DATALIST = new HtmlBodyElement("datalist");
/* 176 */   static final HtmlElement OPTGROUP = new HtmlBodyAutoCloseElement("optgroup", new String[] { "optgroup", "option" }, new String[] { "select" });
/* 177 */   static final HtmlElement OPTION = new HtmlBodyAutoCloseElement("option", new String[] { "option" }, new String[] { "select", "optgroup", "datalist" });
/* 178 */   static final HtmlElement TEXTAREA = new HtmlBodyElement("textarea");
/* 179 */   static final HtmlElement KEYGEN = new HtmlVoidBodyElement("keygen");
/* 180 */   static final HtmlElement OUTPUT = new HtmlBodyElement("output");
/* 181 */   static final HtmlElement PROGRESS = new HtmlBodyElement("progress");
/* 182 */   static final HtmlElement METER = new HtmlBodyElement("meter");
/*     */   
/*     */ 
/* 185 */   static final HtmlElement DETAILS = new HtmlBodyElement("details");
/* 186 */   static final HtmlElement SUMMARY = new HtmlBodyElement("summary");
/* 187 */   static final HtmlElement COMMAND = new HtmlBodyElement("command");
/* 188 */   static final HtmlElement MENU = new HtmlBodyBlockElement("menu");
/* 189 */   static final HtmlElement MENUITEM = new HtmlVoidBodyElement("menuitem");
/* 190 */   static final HtmlElement DIALOG = new HtmlBodyElement("dialog");
/*     */   
/*     */ 
/* 193 */   static final HtmlElement TEMPLATE = new HtmlHeadElement("template");
/* 194 */   static final HtmlElement ELEMENT = new HtmlHeadElement("element");
/* 195 */   static final HtmlElement DECORATOR = new HtmlHeadElement("decorator");
/* 196 */   static final HtmlElement CONTENT = new HtmlHeadElement("content");
/* 197 */   static final HtmlElement SHADOW = new HtmlHeadElement("shadow");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 204 */     ALL_STANDARD_ELEMENTS = Collections.unmodifiableSet(new LinkedHashSet(Arrays.asList(new HtmlElement[] { HTML, HEAD, TITLE, BASE, LINK, META, STYLE, SCRIPT, NOSCRIPT, BODY, ARTICLE, SECTION, NAV, ASIDE, H1, H2, H3, H4, H5, H6, HGROUP, HEADER, FOOTER, ADDRESS, P, HR, PRE, BLOCKQUOTE, OL, UL, LI, DL, DT, DD, FIGURE, FIGCAPTION, DIV, A, EM, STRONG, SMALL, S, CITE, G, DFN, ABBR, TIME, CODE, VAR, SAMP, KBD, SUB, SUP, I, B, U, MARK, RUBY, RB, RT, RTC, RP, BDI, BDO, SPAN, BR, WBR, INS, DEL, IMG, IFRAME, EMBED, OBJECT, PARAM, VIDEO, AUDIO, SOURCE, TRACK, CANVAS, MAP, AREA, TABLE, CAPTION, COLGROUP, COL, TBODY, THEAD, TFOOT, TR, TD, TH, FORM, FIELDSET, LEGEND, LABEL, INPUT, BUTTON, SELECT, DATALIST, OPTGROUP, OPTION, TEXTAREA, KEYGEN, OUTPUT, PROGRESS, METER, DETAILS, SUMMARY, COMMAND, MENU, MENUITEM, DIALOG, MAIN, TEMPLATE, ELEMENT, DECORATOR, CONTENT, SHADOW })));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 222 */     for (HtmlElement element : ALL_STANDARD_ELEMENTS) {
/* 223 */       ELEMENTS.storeStandardElement(element);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static HtmlElement forName(char[] elementNameBuffer, int offset, int len)
/*     */   {
/* 234 */     if (elementNameBuffer == null) {
/* 235 */       throw new IllegalArgumentException("Buffer cannot be null");
/*     */     }
/* 237 */     return ELEMENTS.getElement(elementNameBuffer, offset, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class HtmlElementRepository
/*     */   {
/*     */     private final List<HtmlElement> standardRepository;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private final List<HtmlElement> repository;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 262 */     private final ReadWriteLock lock = new ReentrantReadWriteLock(true);
/* 263 */     private final Lock readLock = this.lock.readLock();
/* 264 */     private final Lock writeLock = this.lock.writeLock();
/*     */     
/*     */     HtmlElementRepository()
/*     */     {
/* 268 */       this.standardRepository = new ArrayList(150);
/* 269 */       this.repository = new ArrayList(150);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     HtmlElement getElement(char[] text, int offset, int len)
/*     */     {
/* 280 */       int index = binarySearch(this.standardRepository, text, offset, len);
/*     */       
/* 282 */       if (index >= 0) {
/* 283 */         return (HtmlElement)this.standardRepository.get(index);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 291 */       this.readLock.lock();
/*     */       HtmlElement localHtmlElement;
/*     */       try {
/* 294 */         index = binarySearch(this.repository, text, offset, len);
/*     */         
/* 296 */         if (index >= 0) {
/* 297 */           return (HtmlElement)this.repository.get(index);
/*     */         }
/*     */       }
/*     */       finally {
/* 301 */         this.readLock.unlock();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 308 */       this.writeLock.lock();
/*     */       try {
/* 310 */         return storeElement(text, offset, len);
/*     */       } finally {
/* 312 */         this.writeLock.unlock();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private HtmlElement storeElement(char[] text, int offset, int len)
/*     */     {
/* 320 */       int index = binarySearch(this.repository, text, offset, len);
/* 321 */       if (index >= 0)
/*     */       {
/* 323 */         return (HtmlElement)this.repository.get(index);
/*     */       }
/*     */       
/* 326 */       HtmlElement element = new HtmlElement(new String(text, offset, len).toLowerCase());
/*     */       
/*     */ 
/* 329 */       this.repository.add((index + 1) * -1, element);
/*     */       
/* 331 */       return element;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private HtmlElement storeStandardElement(HtmlElement element)
/*     */     {
/* 341 */       this.standardRepository.add(element);
/* 342 */       this.repository.add(element);
/* 343 */       Collections.sort(this.standardRepository, ElementComparator.INSTANCE);
/* 344 */       Collections.sort(this.repository, ElementComparator.INSTANCE);
/*     */       
/* 346 */       return element;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private static int binarySearch(List<HtmlElement> values, char[] text, int offset, int len)
/*     */     {
/* 355 */       int low = 0;
/* 356 */       int high = values.size() - 1;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 361 */       while (low <= high)
/*     */       {
/* 363 */         int mid = low + high >>> 1;
/* 364 */         char[] midVal = ((HtmlElement)values.get(mid)).name;
/*     */         
/* 366 */         int cmp = TextUtil.compareTo(false, midVal, 0, midVal.length, text, offset, len);
/*     */         
/* 368 */         if (cmp < 0) {
/* 369 */           low = mid + 1;
/* 370 */         } else if (cmp > 0) {
/* 371 */           high = mid - 1;
/*     */         }
/*     */         else {
/* 374 */           return mid;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 379 */       return -(low + 1);
/*     */     }
/*     */     
/*     */ 
/*     */     private static class ElementComparator
/*     */       implements Comparator<HtmlElement>
/*     */     {
/* 386 */       private static ElementComparator INSTANCE = new ElementComparator();
/*     */       
/*     */       public int compare(HtmlElement o1, HtmlElement o2) {
/* 389 */         return TextUtil.compareTo(false, o1.name, o2.name);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\HtmlElements.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */