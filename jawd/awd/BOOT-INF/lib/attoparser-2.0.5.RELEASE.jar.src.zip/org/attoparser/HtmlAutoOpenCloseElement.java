/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HtmlAutoOpenCloseElement
/*     */   extends HtmlAutoCloseElement
/*     */ {
/*     */   private final char[][] autoOpenParents;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final char[][] autoOpenLimits;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   HtmlAutoOpenCloseElement(String name, String[] autoOpenParents, String[] autoOpenLimits, String[] autoCloseElements, String[] autoCloseLimits)
/*     */   {
/*  45 */     super(name, autoCloseElements, autoCloseLimits);
/*     */     
/*  47 */     if (autoOpenParents == null) {
/*  48 */       throw new IllegalArgumentException("The array of auto-open parents cannot be null");
/*     */     }
/*     */     
/*  51 */     char[][] autoOpenParentsCharArray = new char[autoOpenParents.length][];
/*  52 */     for (int i = 0; i < autoOpenParentsCharArray.length; i++) {
/*  53 */       autoOpenParentsCharArray[i] = autoOpenParents[i].toCharArray();
/*     */     }
/*     */     
/*     */     char[][] autoOpenLimitsCharArray;
/*  57 */     if (autoOpenLimits != null) {
/*  58 */       char[][] autoOpenLimitsCharArray = new char[autoOpenLimits.length][];
/*  59 */       for (int i = 0; i < autoOpenLimitsCharArray.length; i++) {
/*  60 */         autoOpenLimitsCharArray[i] = autoOpenLimits[i].toCharArray();
/*     */       }
/*     */     } else {
/*  63 */       autoOpenLimitsCharArray = null;
/*     */     }
/*     */     
/*  66 */     this.autoOpenParents = autoOpenParentsCharArray;
/*  67 */     this.autoOpenLimits = autoOpenLimitsCharArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled)
/*     */     throws ParseException
/*     */   {
/*  82 */     if (((autoOpenEnabled) || (autoCloseEnabled)) && (!status.isAutoOpenCloseDone())) {
/*  83 */       if (autoCloseEnabled) {
/*  84 */         status.setAutoCloseRequired(this.autoCloseRequired, this.autoCloseLimits);
/*     */       }
/*  86 */       if (autoOpenEnabled) {
/*  87 */         status.setAutoOpenRequired(this.autoOpenParents, this.autoOpenLimits);
/*     */       }
/*  89 */       return;
/*     */     }
/*     */     
/*  92 */     handler.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled)
/*     */     throws ParseException
/*     */   {
/* 109 */     if (((autoOpenEnabled) || (autoCloseEnabled)) && (!status.isAutoOpenCloseDone())) {
/* 110 */       if (autoCloseEnabled) {
/* 111 */         status.setAutoCloseRequired(this.autoCloseRequired, this.autoCloseLimits);
/*     */       }
/* 113 */       if (autoOpenEnabled) {
/* 114 */         status.setAutoOpenRequired(this.autoOpenParents, this.autoOpenLimits);
/*     */       }
/* 116 */       return;
/*     */     }
/*     */     
/* 119 */     handler.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\HtmlAutoOpenCloseElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */