/*     */ package org.attoparser;
/*     */ 
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AttoParser
/*     */ {
/*     */   public static final String VERSION;
/*     */   public static final String BUILD_TIMESTAMP;
/*     */   public static final int VERSION_MAJOR;
/*     */   public static final int VERSION_MINOR;
/*     */   public static final int VERSION_BUILD;
/*     */   public static final String VERSION_TYPE;
/*     */   
/*     */   static
/*     */   {
/*  48 */     String version = null;
/*  49 */     String buildTimestamp = null;
/*     */     try {
/*  51 */       Properties properties = new Properties();
/*  52 */       properties.load(ClassLoaderUtils.loadResourceAsStream("org/attoparser/attoparser.properties"));
/*  53 */       version = properties.getProperty("version");
/*  54 */       buildTimestamp = properties.getProperty("build.date");
/*     */     }
/*     */     catch (Exception localException1) {}
/*     */     
/*     */ 
/*  59 */     VERSION = version;
/*  60 */     BUILD_TIMESTAMP = buildTimestamp;
/*     */     
/*  62 */     if ((VERSION == null) || (VERSION.trim().length() == 0))
/*     */     {
/*  64 */       VERSION_MAJOR = 0;
/*  65 */       VERSION_MINOR = 0;
/*  66 */       VERSION_BUILD = 0;
/*  67 */       VERSION_TYPE = "UNKNOWN";
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/*  73 */         String versionRemainder = VERSION;
/*     */         
/*  75 */         int separatorIdx = versionRemainder.indexOf('.');
/*  76 */         VERSION_MAJOR = Integer.parseInt(versionRemainder.substring(0, separatorIdx));
/*  77 */         versionRemainder = versionRemainder.substring(separatorIdx + 1);
/*     */         
/*  79 */         separatorIdx = versionRemainder.indexOf('.');
/*  80 */         VERSION_MINOR = Integer.parseInt(versionRemainder.substring(0, separatorIdx));
/*  81 */         versionRemainder = versionRemainder.substring(separatorIdx + 1);
/*     */         
/*  83 */         separatorIdx = versionRemainder.indexOf('.');
/*  84 */         if (separatorIdx < 0) {
/*  85 */           separatorIdx = versionRemainder.indexOf('-');
/*     */         }
/*  87 */         VERSION_BUILD = Integer.parseInt(versionRemainder.substring(0, separatorIdx));
/*  88 */         VERSION_TYPE = versionRemainder.substring(separatorIdx + 1);
/*     */       }
/*     */       catch (Exception e) {
/*  91 */         throw new ExceptionInInitializerError("Exception during initialization of AttoParser versioning utilities. Identified AttoParser version is '" + VERSION + "', which does not follow the {major}.{minor}.{build}[.|-]{type} scheme");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isVersionStableRelease()
/*     */   {
/* 103 */     return "RELEASE".equals(VERSION_TYPE);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\AttoParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */