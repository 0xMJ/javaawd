/*      */ package org.attoparser;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import org.attoparser.config.ParseConfiguration;
/*      */ import org.attoparser.config.ParseConfiguration.ElementBalancing;
/*      */ import org.attoparser.config.ParseConfiguration.PrologParseConfiguration;
/*      */ import org.attoparser.config.ParseConfiguration.PrologPresence;
/*      */ import org.attoparser.config.ParseConfiguration.UniqueRootElementPresence;
/*      */ import org.attoparser.util.TextUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class MarkupEventProcessorHandler
/*      */   extends AbstractChainedMarkupHandler
/*      */ {
/*      */   private static final int DEFAULT_STACK_LEN = 10;
/*      */   private static final int DEFAULT_ATTRIBUTE_NAMES_LEN = 3;
/*      */   private ParseStatus status;
/*      */   private boolean useStack;
/*      */   private boolean autoOpen;
/*      */   private boolean autoClose;
/*      */   private boolean requireBalancedElements;
/*      */   private boolean requireNoUnmatchedCloseElements;
/*      */   private ParseConfiguration.PrologParseConfiguration prologParseConfiguration;
/*      */   private ParseConfiguration.UniqueRootElementPresence uniqueRootElementPresence;
/*      */   private boolean caseSensitive;
/*      */   private boolean requireWellFormedAttributeValues;
/*      */   private boolean requireUniqueAttributesInElement;
/*      */   private boolean validateProlog;
/*      */   private boolean prologPresenceForbidden;
/*      */   private boolean xmlDeclarationPresenceForbidden;
/*      */   private boolean doctypePresenceForbidden;
/*      */   private StructureNamesRepository structureNamesRepository;
/*      */   private char[][] elementStack;
/*      */   private int elementStackSize;
/*   82 */   private boolean validPrologXmlDeclarationRead = false;
/*   83 */   private boolean validPrologDocTypeRead = false;
/*   84 */   private boolean elementRead = false;
/*   85 */   private char[] rootElementName = null;
/*   86 */   private char[][] currentElementAttributeNames = null;
/*   87 */   private int currentElementAttributeNamesSize = 0;
/*      */   
/*      */ 
/*   90 */   private boolean closeElementIsMatched = true;
/*      */   
/*      */ 
/*      */   MarkupEventProcessorHandler(IMarkupHandler handler)
/*      */   {
/*   95 */     super(handler);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParseStatus(ParseStatus status)
/*      */   {
/*  106 */     this.status = status;
/*  107 */     super.setParseStatus(status);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParseConfiguration(ParseConfiguration parseConfiguration)
/*      */   {
/*  116 */     this.caseSensitive = parseConfiguration.isCaseSensitive();
/*      */     
/*      */ 
/*      */ 
/*  120 */     this.useStack = ((ParseConfiguration.ElementBalancing.NO_BALANCING != parseConfiguration.getElementBalancing()) || (parseConfiguration.isUniqueAttributesInElementRequired()) || (parseConfiguration.isNoUnmatchedCloseElementsRequired()) || (ParseConfiguration.UniqueRootElementPresence.NOT_VALIDATED != parseConfiguration.getUniqueRootElementPresence()));
/*      */     
/*      */ 
/*      */ 
/*  124 */     this.autoOpen = (ParseConfiguration.ElementBalancing.AUTO_OPEN_CLOSE == parseConfiguration.getElementBalancing());
/*      */     
/*      */ 
/*  127 */     this.autoClose = ((ParseConfiguration.ElementBalancing.AUTO_OPEN_CLOSE == parseConfiguration.getElementBalancing()) || (ParseConfiguration.ElementBalancing.AUTO_CLOSE == parseConfiguration.getElementBalancing()));
/*      */     
/*      */ 
/*  130 */     this.requireBalancedElements = (ParseConfiguration.ElementBalancing.REQUIRE_BALANCED == parseConfiguration.getElementBalancing());
/*  131 */     this.requireNoUnmatchedCloseElements = ((this.requireBalancedElements) || (parseConfiguration.isNoUnmatchedCloseElementsRequired()));
/*      */     
/*  133 */     this.prologParseConfiguration = parseConfiguration.getPrologParseConfiguration();
/*      */     
/*  135 */     this.prologParseConfiguration.validateConfiguration();
/*      */     
/*  137 */     this.uniqueRootElementPresence = parseConfiguration.getUniqueRootElementPresence();
/*  138 */     this.requireWellFormedAttributeValues = parseConfiguration.isXmlWellFormedAttributeValuesRequired();
/*  139 */     this.requireUniqueAttributesInElement = parseConfiguration.isUniqueAttributesInElementRequired();
/*      */     
/*  141 */     this.validateProlog = this.prologParseConfiguration.isValidateProlog();
/*  142 */     this.prologPresenceForbidden = this.prologParseConfiguration.getPrologPresence().isForbidden();
/*  143 */     this.xmlDeclarationPresenceForbidden = this.prologParseConfiguration.getXmlDeclarationPresence().isRequired();
/*  144 */     this.doctypePresenceForbidden = this.prologParseConfiguration.getDoctypePresence().isRequired();
/*      */     
/*  146 */     if (this.useStack)
/*      */     {
/*  148 */       this.elementStack = new char[10][];
/*  149 */       this.elementStackSize = 0;
/*      */       
/*  151 */       this.structureNamesRepository = new StructureNamesRepository();
/*      */     }
/*      */     else
/*      */     {
/*  155 */       this.elementStack = null;
/*  156 */       this.elementStackSize = 0;
/*  157 */       this.structureNamesRepository = null;
/*      */     }
/*      */     
/*      */ 
/*  161 */     super.setParseConfiguration(parseConfiguration);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  171 */     if ((this.requireBalancedElements) && (this.elementStackSize > 0)) {
/*  172 */       char[] popped = popFromStack();
/*  173 */       throw new ParseException("Malformed markup: element \"" + new String(popped, 0, popped.length) + "\" is never closed (no closing tag at the end of document)");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  179 */     if ((!this.elementRead) && (((this.validPrologDocTypeRead) && 
/*  180 */       (this.uniqueRootElementPresence.isDependsOnPrologDoctype())) || 
/*  181 */       (this.uniqueRootElementPresence.isRequiredAlways()))) {
/*  182 */       throw new ParseException("Malformed markup: no root element present");
/*      */     }
/*      */     
/*      */ 
/*  186 */     if (this.useStack) {
/*  187 */       cleanStack(line, col);
/*      */     }
/*      */     
/*  190 */     getNext().handleDocumentEnd(endTimeNanos, totalTimeNanos, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleXmlDeclaration(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int versionOffset, int versionLen, int versionLine, int versionCol, int encodingOffset, int encodingLen, int encodingLine, int encodingCol, int standaloneOffset, int standaloneLen, int standaloneLine, int standaloneCol, int outerOffset, int outerLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  211 */     if ((this.validateProlog) && ((this.prologPresenceForbidden) || (this.xmlDeclarationPresenceForbidden))) {
/*  212 */       throw new ParseException("An XML Declaration has been found, but it wasn't allowed", line, col);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  217 */     if (this.validateProlog)
/*      */     {
/*  219 */       if (this.validPrologXmlDeclarationRead) {
/*  220 */         throw new ParseException("Malformed markup: Only one XML Declaration can appear in document", line, col);
/*      */       }
/*      */       
/*      */ 
/*  224 */       if (this.validPrologDocTypeRead) {
/*  225 */         throw new ParseException("Malformed markup: XML Declaration must appear before DOCTYPE", line, col);
/*      */       }
/*      */       
/*      */ 
/*  229 */       if (this.elementRead) {
/*  230 */         throw new ParseException("Malformed markup: XML Declaration must appear before any elements in document", line, col);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  238 */     if (this.validateProlog) {
/*  239 */       this.validPrologXmlDeclarationRead = true;
/*      */     }
/*      */     
/*  242 */     getNext().handleXmlDeclaration(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, versionOffset, versionLen, versionLine, versionCol, encodingOffset, encodingLen, encodingLine, encodingCol, standaloneOffset, standaloneLen, standaloneLine, standaloneCol, outerOffset, outerLen, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  258 */     if (this.useStack)
/*      */     {
/*  260 */       if (this.elementStackSize == 0) {
/*  261 */         checkValidRootElement(buffer, nameOffset, nameLen, line, col);
/*      */       }
/*      */       
/*  264 */       if (this.requireUniqueAttributesInElement) {
/*  265 */         this.currentElementAttributeNames = null;
/*  266 */         this.currentElementAttributeNamesSize = 0;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  279 */     this.status.autoOpenCloseDone = false;
/*  280 */     this.status.autoOpenParents = null;
/*  281 */     this.status.autoOpenLimits = null;
/*  282 */     this.status.autoCloseRequired = null;
/*  283 */     this.status.autoCloseLimits = null;
/*  284 */     this.status.avoidStacking = true;
/*      */     
/*  286 */     getNext().handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*      */     
/*  288 */     if (this.useStack) {
/*  289 */       if ((this.status.autoOpenParents != null) || (this.status.autoCloseRequired != null)) {
/*  290 */         if (this.status.autoCloseRequired != null)
/*      */         {
/*  292 */           autoClose(this.status.autoCloseRequired, this.status.autoCloseLimits, line, col);
/*      */         }
/*  294 */         if (this.status.autoOpenParents != null)
/*      */         {
/*  296 */           autoOpen(this.status.autoOpenParents, this.status.autoOpenLimits, line, col);
/*      */         }
/*      */         
/*  299 */         this.status.autoOpenCloseDone = true;
/*  300 */         getNext().handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*      */       }
/*  302 */       if (!this.status.avoidStacking) {
/*  303 */         pushToStack(buffer, nameOffset, nameLen);
/*      */       }
/*      */     }
/*  306 */     else if ((this.status.autoOpenParents != null) || (this.status.autoCloseRequired != null))
/*      */     {
/*      */ 
/*  309 */       this.status.autoOpenCloseDone = true;
/*  310 */       getNext().handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*      */     }
/*      */     
/*      */ 
/*  314 */     this.status.autoOpenCloseDone = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  326 */     this.elementRead = true;
/*  327 */     getNext().handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  338 */     if (this.useStack)
/*      */     {
/*  340 */       if (this.elementStackSize == 0) {
/*  341 */         checkValidRootElement(buffer, nameOffset, nameLen, line, col);
/*      */       }
/*      */       
/*  344 */       if (this.requireUniqueAttributesInElement) {
/*  345 */         this.currentElementAttributeNames = null;
/*  346 */         this.currentElementAttributeNamesSize = 0;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  357 */     this.status.autoOpenCloseDone = false;
/*  358 */     this.status.autoOpenParents = null;
/*  359 */     this.status.autoOpenLimits = null;
/*  360 */     this.status.autoCloseRequired = null;
/*  361 */     this.status.autoCloseLimits = null;
/*  362 */     this.status.avoidStacking = false;
/*      */     
/*  364 */     getNext().handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*      */     
/*  366 */     if (this.useStack) {
/*  367 */       if ((this.status.autoOpenParents != null) || (this.status.autoCloseRequired != null)) {
/*  368 */         if (this.status.autoCloseRequired != null)
/*      */         {
/*  370 */           autoClose(this.status.autoCloseRequired, this.status.autoCloseLimits, line, col);
/*      */         }
/*  372 */         if (this.status.autoOpenParents != null)
/*      */         {
/*  374 */           autoOpen(this.status.autoOpenParents, this.status.autoOpenLimits, line, col);
/*      */         }
/*      */         
/*  377 */         this.status.autoOpenCloseDone = true;
/*  378 */         getNext().handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*      */       }
/*  380 */       if (!this.status.avoidStacking)
/*      */       {
/*  382 */         pushToStack(buffer, nameOffset, nameLen);
/*      */       }
/*      */     }
/*  385 */     else if ((this.status.autoOpenParents != null) || (this.status.autoCloseRequired != null))
/*      */     {
/*      */ 
/*  388 */       this.status.autoOpenCloseDone = true;
/*  389 */       getNext().handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  401 */     this.elementRead = true;
/*  402 */     getNext().handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  413 */     throw new IllegalStateException("handleAutoOpenElementStart should never be called on MarkupEventProcessor, as these events should originate in this class");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  424 */     throw new IllegalStateException("handleAutoOpenElementEnd should never be called on MarkupEventProcessor, as these events should originate in this class");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  436 */     if (this.useStack)
/*      */     {
/*      */ 
/*  439 */       this.closeElementIsMatched = checkStackForElement(buffer, nameOffset, nameLen, line, col);
/*      */       
/*  441 */       if (this.requireUniqueAttributesInElement) {
/*  442 */         this.currentElementAttributeNames = null;
/*  443 */         this.currentElementAttributeNamesSize = 0;
/*      */       }
/*      */       
/*  446 */       if (this.closeElementIsMatched) {
/*  447 */         getNext().handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*  448 */         return;
/*      */       }
/*  450 */       getNext().handleUnmatchedCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*  451 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  456 */     getNext().handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  466 */     this.elementRead = true;
/*      */     
/*  468 */     if ((this.useStack) && (!this.closeElementIsMatched)) {
/*  469 */       getNext().handleUnmatchedCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*  470 */       return;
/*      */     }
/*      */     
/*  473 */     getNext().handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  484 */     throw new IllegalStateException("handleAutoCloseElementStart should never be called on MarkupEventProcessor, as these events should originate in this class");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  495 */     throw new IllegalStateException("handleAutoCloseElementEnd should never be called on MarkupEventProcessor, as these events should originate in this class");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleUnmatchedCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  507 */     throw new IllegalStateException("handleUnmatchedCloseElementStart should never be called on MarkupEventProcessor, as these events should originate in this class");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleUnmatchedCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  518 */     throw new IllegalStateException("handleUnmatchedCloseElementEnd should never be called on MarkupEventProcessor, as these events should originate in this class");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*      */     throws ParseException
/*      */   {
/*  535 */     if ((this.useStack) && (this.requireUniqueAttributesInElement))
/*      */     {
/*      */ 
/*  538 */       if (this.currentElementAttributeNames == null)
/*      */       {
/*  540 */         this.currentElementAttributeNames = new char[3][];
/*      */       }
/*  542 */       for (int i = 0; i < this.currentElementAttributeNamesSize; i++)
/*      */       {
/*  544 */         if (TextUtil.equals(this.caseSensitive, this.currentElementAttributeNames[i], 0, this.currentElementAttributeNames[i].length, buffer, nameOffset, nameLen))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  549 */           throw new ParseException("Malformed markup: Attribute \"" + new String(buffer, nameOffset, nameLen) + "\" appears more than once in element", nameLine, nameCol);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  557 */       if (this.currentElementAttributeNamesSize == this.currentElementAttributeNames.length)
/*      */       {
/*  559 */         char[][] newCurrentElementAttributeNames = new char[this.currentElementAttributeNames.length + 3][];
/*  560 */         System.arraycopy(this.currentElementAttributeNames, 0, newCurrentElementAttributeNames, 0, this.currentElementAttributeNames.length);
/*  561 */         this.currentElementAttributeNames = newCurrentElementAttributeNames;
/*      */       }
/*      */       
/*      */ 
/*  565 */       this.currentElementAttributeNames[this.currentElementAttributeNamesSize] = this.structureNamesRepository.getStructureName(buffer, nameOffset, nameLen);
/*      */       
/*  567 */       this.currentElementAttributeNamesSize += 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  572 */     if (this.requireWellFormedAttributeValues)
/*      */     {
/*      */ 
/*  575 */       if (operatorLen == 0) {
/*  576 */         throw new ParseException("Malformed markup: Attribute \"" + new String(buffer, nameOffset, nameLen) + "\" must include an equals (=) sign and a value surrounded by quotes", operatorLine, operatorCol);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  584 */       if ((valueOuterLen == 0) || (valueOuterLen == valueContentLen)) {
/*  585 */         throw new ParseException("Malformed markup: Value for attribute \"" + new String(buffer, nameOffset, nameLen) + "\" must be surrounded by quotes", valueLine, valueCol);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  593 */     getNext().handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleDocType(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int elementNameOffset, int elementNameLen, int elementNameLine, int elementNameCol, int typeOffset, int typeLen, int typeLine, int typeCol, int publicIdOffset, int publicIdLen, int publicIdLine, int publicIdCol, int systemIdOffset, int systemIdLen, int systemIdLine, int systemIdCol, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, int outerOffset, int outerLen, int outerLine, int outerCol)
/*      */     throws ParseException
/*      */   {
/*  622 */     if (this.validateProlog)
/*      */     {
/*  624 */       if ((this.prologPresenceForbidden) || (this.doctypePresenceForbidden)) {
/*  625 */         throw new ParseException("A DOCTYPE clause has been found, but it wasn't allowed", outerLine, outerCol);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  630 */       if (this.validPrologDocTypeRead) {
/*  631 */         throw new ParseException("Malformed markup: Only one DOCTYPE clause can appear in document", outerLine, outerCol);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  636 */       if (this.elementRead) {
/*  637 */         throw new ParseException("Malformed markup: DOCTYPE must appear before any elements in document", outerLine, outerCol);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  643 */       if (this.prologParseConfiguration.isRequireDoctypeKeywordsUpperCase())
/*      */       {
/*  645 */         if (keywordLen > 0) {
/*  646 */           int maxi = keywordOffset + keywordLen;
/*  647 */           for (int i = keywordOffset; i < maxi; i++) {
/*  648 */             if (Character.isLowerCase(buffer[i])) {
/*  649 */               throw new ParseException("Malformed markup: DOCTYPE requires upper-case keywords (\"" + new String(buffer, keywordOffset, keywordLen) + "\" was found)", outerLine, outerCol);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  657 */         if (typeLen > 0) {
/*  658 */           int maxi = typeOffset + typeLen;
/*  659 */           for (int i = typeOffset; i < maxi; i++) {
/*  660 */             if (Character.isLowerCase(buffer[i])) {
/*  661 */               throw new ParseException("Malformed markup: DOCTYPE requires upper-case keywords (\"" + new String(buffer, typeOffset, typeLen) + "\" was found)", outerLine, outerCol);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  673 */     if (this.useStack)
/*      */     {
/*      */ 
/*  676 */       this.rootElementName = this.structureNamesRepository.getStructureName(buffer, elementNameOffset, elementNameLen);
/*      */     }
/*      */     
/*      */ 
/*  680 */     if (this.validateProlog) {
/*  681 */       this.validPrologDocTypeRead = true;
/*      */     }
/*      */     
/*  684 */     getNext().handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, publicIdOffset, publicIdLen, publicIdLine, publicIdCol, systemIdOffset, systemIdLen, systemIdLine, systemIdCol, internalSubsetOffset, internalSubsetLen, internalSubsetLine, internalSubsetCol, outerOffset, outerLen, outerLine, outerCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkValidRootElement(char[] buffer, int offset, int len, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  704 */     if (!this.validateProlog)
/*      */     {
/*  706 */       if ((this.elementRead) && (this.uniqueRootElementPresence.isRequiredAlways()))
/*      */       {
/*      */ 
/*  709 */         throw new ParseException("Malformed markup: Only one root element is allowed", line, col);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  715 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  722 */     if (this.validPrologDocTypeRead)
/*      */     {
/*  724 */       if (this.elementRead)
/*      */       {
/*      */ 
/*  727 */         throw new ParseException("Malformed markup: Only one root element (with name \"" + new String(this.rootElementName) + "\" is allowed", line, col);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  732 */       if (!TextUtil.equals(this.caseSensitive, this.rootElementName, 0, this.rootElementName.length, buffer, offset, len)) {
/*  733 */         throw new ParseException("Malformed markup: Root element should be \"" + new String(this.rootElementName) + "\", but \"" + new String(buffer, offset, len) + "\" has been found", line, col);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean checkStackForElement(char[] buffer, int offset, int len, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  749 */     int peekDelta = 0;
/*  750 */     char[] peek = peekFromStack(peekDelta);
/*      */     
/*  752 */     while (peek != null)
/*      */     {
/*  754 */       if (TextUtil.equals(this.caseSensitive, peek, 0, peek.length, buffer, offset, len))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  759 */         for (int i = 0; i < peekDelta; i++) {
/*  760 */           peek = popFromStack();
/*  761 */           if (this.autoClose) {
/*  762 */             getNext().handleAutoCloseElementStart(peek, 0, peek.length, line, col);
/*  763 */             getNext().handleAutoCloseElementEnd(peek, 0, peek.length, line, col);
/*      */           }
/*      */           else {
/*  766 */             throw new ParseException("Malformed markup: element \"" + new String(peek, 0, peek.length) + "\" is never closed", line, col);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  772 */         popFromStack();
/*      */         
/*  774 */         return true;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  780 */       if (this.requireBalancedElements) {
/*  781 */         throw new ParseException("Malformed markup: element \"" + new String(peek, 0, peek.length) + "\" is never closed", line, col);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  787 */       peek = peekFromStack(++peekDelta);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  792 */     if (this.requireNoUnmatchedCloseElements) {
/*  793 */       throw new ParseException("Malformed markup: closing element \"" + new String(buffer, offset, len) + "\" is never open", line, col);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  800 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void cleanStack(int line, int col)
/*      */     throws ParseException
/*      */   {
/*  810 */     if (this.elementStackSize > 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  815 */       char[] popped = popFromStack();
/*      */       
/*  817 */       while (popped != null)
/*      */       {
/*  819 */         if (this.autoClose) {
/*  820 */           getNext().handleAutoCloseElementStart(popped, 0, popped.length, line, col);
/*  821 */           getNext().handleAutoCloseElementEnd(popped, 0, popped.length, line, col);
/*      */         }
/*      */         else {
/*  824 */           throw new ParseException("Malformed markup: element \"" + new String(popped, 0, popped.length) + "\" is never closed", line, col);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  830 */         popped = popFromStack();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void autoClose(char[][] autoCloseElements, char[][] autoCloseLimits, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  844 */     int peekDelta = 0;
/*  845 */     int unstackCount = 0;
/*  846 */     char[] peek = peekFromStack(peekDelta);
/*      */     
/*      */ 
/*      */ 
/*  850 */     while (peek != null)
/*      */     {
/*  852 */       if (autoCloseLimits != null)
/*      */       {
/*  854 */         int i = 0;
/*  855 */         int n = autoCloseLimits.length;
/*  856 */         while (n-- != 0) {
/*  857 */           if (TextUtil.equals(this.caseSensitive, autoCloseLimits[i], peek))
/*      */           {
/*  859 */             peek = null;
/*  860 */             break;
/*      */           }
/*  862 */           i++;
/*      */         }
/*      */       }
/*      */       
/*  866 */       if (peek != null)
/*      */       {
/*      */ 
/*  869 */         int i = 0;
/*  870 */         int n = autoCloseElements.length;
/*  871 */         while (n-- != 0) {
/*  872 */           if (TextUtil.equals(this.caseSensitive, autoCloseElements[i], peek))
/*      */           {
/*  874 */             unstackCount = peekDelta + 1;
/*  875 */             break;
/*      */           }
/*  877 */           i++;
/*      */         }
/*      */         
/*      */ 
/*  881 */         peek = peekFromStack(++peekDelta);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  888 */     int n = unstackCount;
/*  889 */     while (n-- != 0)
/*      */     {
/*  891 */       peek = popFromStack();
/*      */       
/*  893 */       if (this.requireBalancedElements) {
/*  894 */         throw new ParseException("Malformed markup: element \"" + new String(peek, 0, peek.length) + "\" is not closed where it should be", line, col);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  900 */       if (this.autoClose) {
/*  901 */         getNext().handleAutoCloseElementStart(peek, 0, peek.length, line, col);
/*  902 */         getNext().handleAutoCloseElementEnd(peek, 0, peek.length, line, col);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void autoOpen(char[][] autoOpenParents, char[][] autoOpenLimits, int line, int col)
/*      */     throws ParseException
/*      */   {
/*  915 */     if (!this.autoOpen)
/*      */     {
/*  917 */       return;
/*      */     }
/*      */     
/*  920 */     int parentInsertCount = 0;
/*      */     
/*      */ 
/*  923 */     if (autoOpenLimits == null)
/*      */     {
/*      */ 
/*  926 */       if (this.elementStackSize >= autoOpenParents.length)
/*      */       {
/*      */ 
/*  929 */         return;
/*      */       }
/*      */       
/*  932 */       char[] peek = peekFromStack(0);
/*      */       
/*  934 */       if (peek == null)
/*      */       {
/*      */ 
/*  937 */         parentInsertCount = autoOpenParents.length;
/*      */       }
/*      */       else
/*      */       {
/*  941 */         int n = autoOpenParents.length;
/*  942 */         while ((peek != null) && (n-- != 0)) {
/*  943 */           if (TextUtil.equals(this.caseSensitive, autoOpenParents[n], peek))
/*      */           {
/*  945 */             parentInsertCount = autoOpenParents.length - n - 1;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  952 */       if (parentInsertCount == 0)
/*      */       {
/*  954 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  962 */       char[] peek = peekFromStack(0);
/*      */       
/*  964 */       if (peek != null)
/*      */       {
/*      */ 
/*  967 */         int i = 0;
/*  968 */         int n = autoOpenLimits.length;
/*  969 */         while (n-- != 0) {
/*  970 */           if (TextUtil.equals(this.caseSensitive, autoOpenLimits[i], peek))
/*      */           {
/*  972 */             return;
/*      */           }
/*  974 */           i++;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  980 */       parentInsertCount = autoOpenParents.length;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  988 */     int n = parentInsertCount;
/*  989 */     int i = autoOpenParents.length - parentInsertCount;
/*      */     
/*  991 */     while (n-- != 0)
/*      */     {
/*  993 */       getNext().handleAutoOpenElementStart(autoOpenParents[i], 0, autoOpenParents[i].length, line, col);
/*  994 */       getNext().handleAutoOpenElementEnd(autoOpenParents[i], 0, autoOpenParents[i].length, line, col);
/*      */       
/*  996 */       pushToStack(autoOpenParents[i], 0, autoOpenParents[i].length);
/*      */       
/*  998 */       i++;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void pushToStack(char[] buffer, int offset, int len)
/*      */   {
/* 1009 */     if (this.elementStackSize == this.elementStack.length) {
/* 1010 */       growStack();
/*      */     }
/*      */     
/*      */ 
/* 1014 */     this.elementStack[this.elementStackSize] = this.structureNamesRepository.getStructureName(buffer, offset, len);
/*      */     
/* 1016 */     this.elementStackSize += 1;
/*      */   }
/*      */   
/*      */ 
/*      */   private char[] peekFromStack(int delta)
/*      */   {
/* 1022 */     if (this.elementStackSize <= delta) {
/* 1023 */       return null;
/*      */     }
/* 1025 */     return this.elementStack[(this.elementStackSize - 1 - delta)];
/*      */   }
/*      */   
/*      */   private char[] popFromStack()
/*      */   {
/* 1030 */     if (this.elementStackSize == 0) {
/* 1031 */       return null;
/*      */     }
/* 1033 */     char[] popped = this.elementStack[(this.elementStackSize - 1)];
/* 1034 */     this.elementStack[(this.elementStackSize - 1)] = null;
/* 1035 */     this.elementStackSize -= 1;
/* 1036 */     return popped;
/*      */   }
/*      */   
/*      */ 
/*      */   private void growStack()
/*      */   {
/* 1042 */     int newStackLen = this.elementStack.length + 10;
/* 1043 */     char[][] newStack = new char[newStackLen][];
/* 1044 */     System.arraycopy(this.elementStack, 0, newStack, 0, this.elementStack.length);
/* 1045 */     this.elementStack = newStack;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class StructureNamesRepository
/*      */   {
/*      */     private static final int REPOSITORY_INITIAL_LEN = 100;
/*      */     
/*      */ 
/*      */ 
/*      */     private static final int REPOSITORY_INITIAL_INC = 20;
/*      */     
/*      */ 
/*      */ 
/*      */     private char[][] repository;
/*      */     
/*      */ 
/*      */ 
/*      */     private int repositorySize;
/*      */     
/*      */ 
/*      */ 
/*      */     StructureNamesRepository()
/*      */     {
/* 1071 */       this.repository = new char[100][];
/* 1072 */       this.repositorySize = 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     char[] getStructureName(char[] text, int offset, int len)
/*      */     {
/* 1079 */       int index = TextUtil.binarySearch(true, this.repository, 0, this.repositorySize, text, offset, len);
/*      */       
/* 1081 */       if (index >= 0) {
/* 1082 */         return this.repository[index];
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1088 */       return storeStructureName(index, text, offset, len);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private char[] storeStructureName(int index, char[] text, int offset, int len)
/*      */     {
/* 1095 */       if (this.repositorySize == this.repository.length)
/*      */       {
/* 1097 */         char[][] newRepository = new char[this.repository.length + 20][];
/* 1098 */         Arrays.fill(newRepository, null);
/* 1099 */         System.arraycopy(this.repository, 0, newRepository, 0, this.repositorySize);
/* 1100 */         this.repository = newRepository;
/*      */       }
/*      */       
/*      */ 
/* 1104 */       int insertionIndex = (index + 1) * -1;
/*      */       
/*      */ 
/*      */ 
/* 1108 */       char[] structureName = MarkupEventProcessorHandler.StandardNamesRepository.getStructureName(text, offset, len);
/*      */       
/*      */ 
/* 1111 */       System.arraycopy(this.repository, insertionIndex, this.repository, insertionIndex + 1, this.repositorySize - insertionIndex);
/* 1112 */       this.repository[insertionIndex] = structureName;
/* 1113 */       this.repositorySize += 1;
/*      */       
/* 1115 */       return structureName;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class StandardNamesRepository
/*      */   {
/*      */     private static final char[][] REPOSITORY;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     static
/*      */     {
/* 1136 */       List<String> names = new ArrayList(150);
/*      */       
/* 1138 */       names.addAll(HtmlNames.ALL_STANDARD_ELEMENT_NAMES);
/*      */       
/* 1140 */       for (String name : HtmlNames.ALL_STANDARD_ELEMENT_NAMES) {
/* 1141 */         names.add(name.toUpperCase());
/*      */       }
/*      */       
/* 1144 */       names.addAll(HtmlNames.ALL_STANDARD_ATTRIBUTE_NAMES);
/*      */       
/* 1146 */       for (String name : HtmlNames.ALL_STANDARD_ATTRIBUTE_NAMES) {
/* 1147 */         names.add(name.toUpperCase());
/*      */       }
/* 1149 */       Collections.sort(names);
/*      */       
/* 1151 */       REPOSITORY = new char[names.size()][];
/*      */       
/* 1153 */       for (int i = 0; i < names.size(); i++) {
/* 1154 */         String name = (String)names.get(i);
/* 1155 */         REPOSITORY[i] = name.toCharArray();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     static char[] getStructureName(char[] text, int offset, int len)
/*      */     {
/* 1163 */       int index = TextUtil.binarySearch(true, REPOSITORY, text, offset, len);
/*      */       
/* 1165 */       if (index < 0) {
/* 1166 */         char[] structureName = new char[len];
/* 1167 */         System.arraycopy(text, offset, structureName, 0, len);
/* 1168 */         return structureName;
/*      */       }
/*      */       
/* 1171 */       return REPOSITORY[index];
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\MarkupEventProcessorHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */