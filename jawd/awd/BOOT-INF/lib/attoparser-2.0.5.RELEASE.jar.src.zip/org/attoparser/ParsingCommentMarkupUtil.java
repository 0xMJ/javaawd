/*    */ package org.attoparser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ParsingCommentMarkupUtil
/*    */ {
/*    */   public static void parseComment(char[] buffer, int offset, int len, int line, int col, ICommentHandler handler)
/*    */     throws ParseException
/*    */   {
/* 46 */     if ((len < 7) || (!isCommentStart(buffer, offset, offset + len)) || (!isCommentEnd(buffer, offset + len - 3, offset + len))) {
/* 47 */       throw new ParseException("Could not parse as a well-formed Comment: \"" + new String(buffer, offset, len) + "\"", line, col);
/*    */     }
/*    */     
/*    */ 
/* 51 */     int contentOffset = offset + 4;
/* 52 */     int contentLen = len - 7;
/*    */     
/* 54 */     handler.handleComment(buffer, contentOffset, contentLen, offset, len, line, col);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static boolean isCommentStart(char[] buffer, int offset, int maxi)
/*    */   {
/* 66 */     return (maxi - offset > 3) && (buffer[offset] == '<') && (buffer[(offset + 1)] == '!') && (buffer[(offset + 2)] == '-') && (buffer[(offset + 3)] == '-');
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static boolean isCommentEnd(char[] buffer, int offset, int maxi)
/*    */   {
/* 75 */     return (maxi - offset > 2) && (buffer[offset] == '-') && (buffer[(offset + 1)] == '-') && (buffer[(offset + 2)] == '>');
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\ParsingCommentMarkupUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */