package org.attoparser;

import java.io.Reader;

public abstract interface IMarkupParser
{
  public abstract void parse(String paramString, IMarkupHandler paramIMarkupHandler)
    throws ParseException;
  
  public abstract void parse(char[] paramArrayOfChar, IMarkupHandler paramIMarkupHandler)
    throws ParseException;
  
  public abstract void parse(char[] paramArrayOfChar, int paramInt1, int paramInt2, IMarkupHandler paramIMarkupHandler)
    throws ParseException;
  
  public abstract void parse(Reader paramReader, IMarkupHandler paramIMarkupHandler)
    throws ParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\IMarkupParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */