package org.attoparser;

public abstract interface ITextHandler
{
  public abstract void handleText(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws ParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\ITextHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */