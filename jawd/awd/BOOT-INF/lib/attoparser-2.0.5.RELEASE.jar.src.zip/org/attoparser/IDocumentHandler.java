package org.attoparser;

public abstract interface IDocumentHandler
{
  public abstract void handleDocumentStart(long paramLong, int paramInt1, int paramInt2)
    throws ParseException;
  
  public abstract void handleDocumentEnd(long paramLong1, long paramLong2, int paramInt1, int paramInt2)
    throws ParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\IDocumentHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */