/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParsingDocTypeMarkupUtil
/*     */ {
/*  32 */   private static final char[] DOCTYPE_TYPE_PUBLIC_UPPER = "PUBLIC".toCharArray();
/*  33 */   private static final char[] DOCTYPE_TYPE_PUBLIC_LOWER = "public".toCharArray();
/*  34 */   private static final char[] DOCTYPE_TYPE_SYSTEM_UPPER = "SYSTEM".toCharArray();
/*  35 */   private static final char[] DOCTYPE_TYPE_SYSTEM_LOWER = "system".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void parseDocType(char[] buffer, int offset, int len, int line, int col, IDocTypeHandler handler)
/*     */     throws ParseException
/*     */   {
/*  55 */     if ((len < 10) || (!isDocTypeStart(buffer, offset, offset + len)) || (!isDocTypeEnd(buffer, offset + len - 1, offset + len))) {
/*  56 */       throw new ParseException("Could not parse as a well-formed DOCTYPE clause: \"" + new String(buffer, offset, len) + "\"", line, col);
/*     */     }
/*     */     
/*     */ 
/*  60 */     int contentOffset = offset + 2;
/*  61 */     int contentLen = len - 3;
/*     */     
/*     */ 
/*  64 */     int internalSubsetLastChar = findInternalSubsetEndChar(buffer, contentOffset, contentLen);
/*     */     
/*  66 */     if (internalSubsetLastChar == -1) {
/*  67 */       doParseDetailedDocTypeWithInternalSubset(buffer, contentOffset, contentLen, offset, len, line, col, 0, 0, 0, 0, handler);
/*     */       
/*     */ 
/*  70 */       return;
/*     */     }
/*     */     
/*  73 */     int maxi = contentOffset + contentLen;
/*     */     
/*  75 */     int[] locator = { line, col + 2 };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */     int internalSubsetStart = findInternalSubsetStartCharWildcard(buffer, contentOffset, maxi, locator);
/*     */     
/*  84 */     if (internalSubsetStart == -1)
/*     */     {
/*  86 */       throw new ParseException("Could not parse as a well-formed DOCTYPE clause: \"" + new String(buffer, offset, len) + "\"", line, col);
/*     */     }
/*     */     
/*     */ 
/*  90 */     doParseDetailedDocTypeWithInternalSubset(buffer, contentOffset, internalSubsetStart - contentOffset, offset, len, line, col, internalSubsetStart + 1, internalSubsetLastChar - internalSubsetStart - 1, locator[0], locator[1], handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void doParseDetailedDocTypeWithInternalSubset(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, IDocTypeHandler handler)
/*     */     throws ParseException
/*     */   {
/* 114 */     int maxi = contentOffset + contentLen;
/*     */     
/* 116 */     int[] locator = { line, col + 2 };
/*     */     
/* 118 */     int i = contentOffset;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     int keywordEnd = ParsingMarkupUtil.findNextWhitespaceCharWildcard(buffer, i, maxi, false, locator);
/*     */     
/* 127 */     if (keywordEnd == -1)
/*     */     {
/*     */ 
/* 130 */       handler.handleDocType(buffer, i, maxi - i, line, col + 2, 0, 0, locator[0], locator[1], 0, 0, locator[0], locator[1], 0, 0, locator[0], locator[1], 0, 0, locator[0], locator[1], internalSubsetOffset, internalSubsetLen, 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */         Math.max(locator[0], internalSubsetLine), 
/* 144 */         Math.max(locator[1], internalSubsetCol), outerOffset, outerLen, line, col);
/*     */       
/*     */ 
/* 147 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 153 */     int keywordOffset = i;
/* 154 */     int keywordLen = keywordEnd - keywordOffset;
/* 155 */     int keywordLine = line;
/* 156 */     int keywordCol = col + 2;
/*     */     
/* 158 */     i = keywordEnd;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 165 */     int currentDocTypeLine = locator[0];
/* 166 */     int currentDocTypeCol = locator[1];
/*     */     
/*     */ 
/* 169 */     int elementNameStart = ParsingMarkupUtil.findNextNonWhitespaceCharWildcard(buffer, i, maxi, locator);
/*     */     
/* 171 */     if (elementNameStart == -1)
/*     */     {
/*     */ 
/* 174 */       handler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, 0, 0, currentDocTypeLine, currentDocTypeCol, 0, 0, currentDocTypeLine, currentDocTypeCol, 0, 0, currentDocTypeLine, currentDocTypeCol, 0, 0, currentDocTypeLine, currentDocTypeCol, internalSubsetOffset, internalSubsetLen, 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 187 */         Math.max(currentDocTypeLine, internalSubsetLine), 
/* 188 */         Math.max(currentDocTypeCol, internalSubsetCol), outerOffset, outerLen, line, col);
/*     */       
/*     */ 
/* 191 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 196 */     i = elementNameStart;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 204 */     currentDocTypeLine = locator[0];
/* 205 */     currentDocTypeCol = locator[1];
/*     */     
/*     */ 
/* 208 */     int elementNameEnd = ParsingMarkupUtil.findNextWhitespaceCharWildcard(buffer, i, maxi, false, locator);
/*     */     
/* 210 */     if (elementNameEnd == -1)
/*     */     {
/*     */ 
/* 213 */       handler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, i, maxi - i, currentDocTypeLine, currentDocTypeCol, 0, 0, locator[0], locator[1], 0, 0, locator[0], locator[1], 0, 0, locator[0], locator[1], internalSubsetOffset, internalSubsetLen, 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 226 */         Math.max(locator[0], internalSubsetLine), 
/* 227 */         Math.max(locator[1], internalSubsetCol), outerOffset, outerLen, line, col);
/*     */       
/*     */ 
/* 230 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 236 */     int elementNameOffset = elementNameStart;
/* 237 */     int elementNameLen = elementNameEnd - elementNameOffset;
/* 238 */     int elementNameLine = currentDocTypeLine;
/* 239 */     int elementNameCol = currentDocTypeCol;
/*     */     
/* 241 */     i = elementNameEnd;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 248 */     currentDocTypeLine = locator[0];
/* 249 */     currentDocTypeCol = locator[1];
/*     */     
/*     */ 
/* 252 */     int typeStart = ParsingMarkupUtil.findNextNonWhitespaceCharWildcard(buffer, i, maxi, locator);
/*     */     
/* 254 */     if (typeStart == -1)
/*     */     {
/*     */ 
/* 257 */       handler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, 0, 0, locator[0], locator[1], 0, 0, locator[0], locator[1], 0, 0, locator[0], locator[1], internalSubsetOffset, internalSubsetLen, 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 270 */         Math.max(locator[0], internalSubsetLine), 
/* 271 */         Math.max(locator[1], internalSubsetCol), outerOffset, outerLen, line, col);
/*     */       
/*     */ 
/* 274 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 279 */     i = typeStart;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 287 */     currentDocTypeLine = locator[0];
/* 288 */     currentDocTypeCol = locator[1];
/*     */     
/*     */ 
/* 291 */     int typeEnd = ParsingMarkupUtil.findNextWhitespaceCharWildcard(buffer, i, maxi, true, locator);
/*     */     
/* 293 */     if (typeEnd == -1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 299 */       throw new ParseException("Could not parse as a well-formed DOCTYPE clause \"" + new String(buffer, outerOffset, outerLen) + "\": If a type is specified (PUBLIC or SYSTEM), at least a public or a system ID has to be specified", line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 309 */     int typeOffset = typeStart;
/* 310 */     int typeLen = typeEnd - typeOffset;
/* 311 */     int typeLine = currentDocTypeLine;
/* 312 */     int typeCol = currentDocTypeCol;
/*     */     
/* 314 */     i = typeEnd;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 322 */     if (!isValidDocTypeType(buffer, typeOffset, typeLen))
/*     */     {
/* 324 */       throw new ParseException("Could not parse as a well-formed DOCTYPE clause \"" + new String(buffer, outerOffset, outerLen) + "\": DOCTYPE type must be either \"PUBLIC\" or \"SYSTEM\"", line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 332 */     boolean isTypePublic = (buffer[typeOffset] == DOCTYPE_TYPE_PUBLIC_UPPER[0]) || (buffer[typeOffset] == DOCTYPE_TYPE_PUBLIC_LOWER[0]);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 340 */     currentDocTypeLine = locator[0];
/* 341 */     currentDocTypeCol = locator[1];
/*     */     
/*     */ 
/* 344 */     int spec1Start = ParsingMarkupUtil.findNextNonWhitespaceCharWildcard(buffer, i, maxi, locator);
/*     */     
/* 346 */     if (spec1Start == -1)
/*     */     {
/*     */ 
/*     */ 
/* 350 */       throw new ParseException("Could not parse as a well-formed DOCTYPE clause \"" + new String(buffer, outerOffset, outerLen) + "\": If a type is specified (PUBLIC or SYSTEM), at least a public or a system ID has to be specified", line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 359 */     i = spec1Start;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 367 */     currentDocTypeLine = locator[0];
/* 368 */     currentDocTypeCol = locator[1];
/*     */     
/*     */ 
/* 371 */     int spec1End = ParsingMarkupUtil.findNextWhitespaceCharWildcard(buffer, i, maxi, true, locator);
/*     */     
/* 373 */     if (spec1End == -1)
/*     */     {
/*     */ 
/* 376 */       if (!isValidDocTypeSpec(buffer, i, maxi - i))
/*     */       {
/*     */ 
/* 379 */         throw new ParseException("Could not parse as a well-formed DOCTYPE clause \"" + new String(buffer, outerOffset, outerLen) + "\": Public and Systen IDs must be surrounded by quotes (\")", line, col);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 387 */       if (isTypePublic)
/*     */       {
/*     */ 
/* 390 */         handler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, i + 1, maxi - (i + 2), currentDocTypeLine, currentDocTypeCol, 0, 0, locator[0], locator[1], internalSubsetOffset, internalSubsetLen, 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 403 */           Math.max(locator[0], internalSubsetLine), 
/* 404 */           Math.max(locator[1], internalSubsetCol), outerOffset, outerLen, line, col);
/*     */         
/*     */ 
/* 407 */         return;
/*     */       }
/*     */       
/*     */ 
/* 411 */       handler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, 0, 0, currentDocTypeLine, currentDocTypeCol, i + 1, maxi - (i + 2), currentDocTypeLine, currentDocTypeCol, internalSubsetOffset, internalSubsetLen, 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 424 */         Math.max(locator[0], internalSubsetLine), 
/* 425 */         Math.max(locator[1], internalSubsetCol), outerOffset, outerLen, line, col);
/*     */       
/*     */ 
/* 428 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 434 */     int spec1Offset = spec1Start;
/* 435 */     int spec1Len = spec1End - spec1Offset;
/* 436 */     int spec1Line = currentDocTypeLine;
/* 437 */     int spec1Col = currentDocTypeCol;
/*     */     
/* 439 */     i = spec1End;
/*     */     
/*     */ 
/* 442 */     if (!isValidDocTypeSpec(buffer, spec1Offset, spec1Len))
/*     */     {
/*     */ 
/* 445 */       throw new ParseException("Could not parse as a well-formed DOCTYPE clause \"" + new String(buffer, outerOffset, outerLen) + "\": Public and Systen IDs must be surrounded by quotes (\")", line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 458 */     currentDocTypeLine = locator[0];
/* 459 */     currentDocTypeCol = locator[1];
/*     */     
/*     */ 
/* 462 */     int spec2Start = ParsingMarkupUtil.findNextNonWhitespaceCharWildcard(buffer, i, maxi, locator);
/*     */     
/* 464 */     if (spec2Start == -1)
/*     */     {
/*     */ 
/* 467 */       if (isTypePublic)
/*     */       {
/*     */ 
/* 470 */         handler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, spec1Offset + 1, spec1Len - 2, spec1Line, spec1Col, 0, 0, locator[0], locator[1], internalSubsetOffset, internalSubsetLen, 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 483 */           Math.max(locator[0], internalSubsetLine), 
/* 484 */           Math.max(locator[1], internalSubsetCol), outerOffset, outerLen, line, col);
/*     */         
/*     */ 
/* 487 */         return;
/*     */       }
/*     */       
/*     */ 
/* 491 */       handler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, 0, 0, spec1Line, spec1Col, spec1Offset + 1, spec1Len - 2, spec1Line, spec1Col, internalSubsetOffset, internalSubsetLen, 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 504 */         Math.max(locator[0], internalSubsetLine), 
/* 505 */         Math.max(locator[1], internalSubsetCol), outerOffset, outerLen, line, col);
/*     */       
/*     */ 
/* 508 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 513 */     i = spec2Start;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 521 */     currentDocTypeLine = locator[0];
/* 522 */     currentDocTypeCol = locator[1];
/*     */     
/*     */ 
/* 525 */     int spec2End = ParsingMarkupUtil.findNextWhitespaceCharWildcard(buffer, i, maxi, true, locator);
/*     */     
/* 527 */     if (spec2End == -1)
/*     */     {
/*     */ 
/* 530 */       if (!isValidDocTypeSpec(buffer, i, maxi - i))
/*     */       {
/*     */ 
/* 533 */         throw new ParseException("Could not parse as a well-formed DOCTYPE clause \"" + new String(buffer, outerOffset, outerLen) + "\": Public and Systen IDs must be surrounded by quotes (\")", line, col);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 543 */       if (!isTypePublic)
/*     */       {
/*     */ 
/* 546 */         throw new ParseException("Could not parse as a well-formed DOCTYPE clause \"" + new String(buffer, outerOffset, outerLen) + "\": type SYSTEM only allows specifying one element (a system ID)", line, col);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 554 */       handler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, spec1Offset + 1, spec1Len - 2, spec1Line, spec1Col, i + 1, maxi - (i + 2), currentDocTypeLine, currentDocTypeCol, internalSubsetOffset, internalSubsetLen, 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 567 */         Math.max(locator[0], internalSubsetLine), 
/* 568 */         Math.max(locator[1], internalSubsetCol), outerOffset, outerLen, line, col);
/*     */       
/*     */ 
/* 571 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 577 */     int spec2Offset = spec2Start;
/* 578 */     int spec2Len = spec2End - spec2Offset;
/* 579 */     int spec2Line = currentDocTypeLine;
/* 580 */     int spec2Col = currentDocTypeCol;
/*     */     
/* 582 */     i = spec2End;
/*     */     
/*     */ 
/* 585 */     if (!isValidDocTypeSpec(buffer, spec2Start, spec2Len))
/*     */     {
/*     */ 
/* 588 */       throw new ParseException("Could not parse as a well-formed DOCTYPE clause \"" + new String(buffer, outerOffset, outerLen) + "\": Public and Systen IDs must be surrounded by quotes (\")", line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 597 */     if (!isTypePublic)
/*     */     {
/*     */ 
/* 600 */       throw new ParseException("Could not parse as a well-formed DOCTYPE clause \"" + new String(buffer, outerOffset, outerLen) + "\": type SYSTEM only allows specifying one element (a system ID)", line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 613 */     currentDocTypeLine = locator[0];
/* 614 */     currentDocTypeCol = locator[1];
/*     */     
/*     */ 
/* 617 */     int clauseEndStart = ParsingMarkupUtil.findNextNonWhitespaceCharWildcard(buffer, i, maxi, locator);
/*     */     
/* 619 */     if (clauseEndStart != -1)
/*     */     {
/*     */ 
/*     */ 
/* 623 */       throw new ParseException("Could not parse as a well-formed DOCTYPE clause \"" + new String(buffer, outerOffset, outerLen) + "\": More elements found than allowed", line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 634 */     handler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, spec1Offset + 1, spec1Len - 2, spec1Line, spec1Col, spec2Offset + 1, spec2Len - 2, spec2Line, spec2Col, internalSubsetOffset, internalSubsetLen, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 647 */       Math.max(locator[0], internalSubsetLine), 
/* 648 */       Math.max(locator[1], internalSubsetCol), outerOffset, outerLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean isDocTypeStart(char[] buffer, int offset, int maxi)
/*     */   {
/* 667 */     if ((maxi - offset > 9) && (buffer[offset] == '<') && (buffer[(offset + 1)] == '!') && ((buffer[(offset + 2)] == 'D') || (buffer[(offset + 2)] == 'd')) && ((buffer[(offset + 3)] == 'O') || (buffer[(offset + 3)] == 'o')) && ((buffer[(offset + 4)] == 'C') || (buffer[(offset + 4)] == 'c')) && ((buffer[(offset + 5)] == 'T') || (buffer[(offset + 5)] == 't')) && ((buffer[(offset + 6)] == 'Y') || (buffer[(offset + 6)] == 'y')) && ((buffer[(offset + 7)] == 'P') || (buffer[(offset + 7)] == 'p')) && ((buffer[(offset + 8)] == 'E') || (buffer[(offset + 8)] == 'e'))) {} return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 677 */       (Character.isWhitespace(buffer[(offset + 9)])) || (buffer[(offset + 9)] == '>');
/*     */   }
/*     */   
/*     */ 
/*     */   static boolean isDocTypeEnd(char[] buffer, int offset, int maxi)
/*     */   {
/* 683 */     return (maxi - offset > 0) && (buffer[offset] == '>');
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean isValidDocTypeType(char[] buffer, int offset, int len)
/*     */   {
/* 689 */     if (len != 6) {
/* 690 */       return false;
/*     */     }
/*     */     
/* 693 */     if ((buffer[offset] == DOCTYPE_TYPE_PUBLIC_UPPER[0]) || (buffer[offset] == DOCTYPE_TYPE_PUBLIC_LOWER[0])) {
/* 694 */       for (int i = 1; i < 6; i++) {
/* 695 */         if ((buffer[(offset + i)] != DOCTYPE_TYPE_PUBLIC_UPPER[i]) && (buffer[(offset + i)] != DOCTYPE_TYPE_PUBLIC_LOWER[i])) {
/* 696 */           return false;
/*     */         }
/*     */       }
/* 699 */       return true; }
/* 700 */     if ((buffer[offset] == DOCTYPE_TYPE_SYSTEM_UPPER[0]) || (buffer[offset] == DOCTYPE_TYPE_SYSTEM_LOWER[0])) {
/* 701 */       for (int i = 1; i < 6; i++) {
/* 702 */         if ((buffer[(offset + i)] != DOCTYPE_TYPE_SYSTEM_UPPER[i]) && (buffer[(offset + i)] != DOCTYPE_TYPE_SYSTEM_LOWER[i])) {
/* 703 */           return false;
/*     */         }
/*     */       }
/* 706 */       return true;
/*     */     }
/* 708 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isValidDocTypeSpec(char[] buffer, int offset, int len)
/*     */   {
/* 716 */     return (len >= 2) && (((buffer[offset] == '"') && (buffer[(offset + len - 1)] == '"')) || ((buffer[offset] == '\'') && (buffer[(offset + len - 1)] == '\'')));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static int findInternalSubsetEndChar(char[] buffer, int offset, int len)
/*     */   {
/* 723 */     int maxi = offset + len;
/*     */     
/* 725 */     for (int i = maxi - 1; i > offset; i--)
/*     */     {
/* 727 */       char c = buffer[i];
/* 728 */       if (!Character.isWhitespace(c)) {
/* 729 */         if (c == ']') {
/* 730 */           return i;
/*     */         }
/* 732 */         return -1;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 737 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int findInternalSubsetStartCharWildcard(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 746 */     boolean inQuotes = false;
/* 747 */     boolean inApos = false;
/*     */     
/* 749 */     for (int i = offset; i < maxi; i++)
/*     */     {
/* 751 */       char c = text[i];
/*     */       
/* 753 */       if ((!inApos) && (c == '"')) {
/* 754 */         inQuotes = !inQuotes;
/* 755 */       } else if ((!inQuotes) && (c == '\'')) {
/* 756 */         inApos = !inApos;
/* 757 */       } else if ((!inQuotes) && (!inApos) && (c == '[')) {
/* 758 */         return i;
/*     */       }
/*     */       
/* 761 */       ParsingLocatorUtil.countChar(locator, c);
/*     */     }
/*     */     
/*     */ 
/* 765 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextDocTypeStructureEnd(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 775 */     boolean inQuotes = false;
/* 776 */     boolean inApos = false;
/* 777 */     int bracketLevel = 0;
/*     */     
/* 779 */     for (int i = offset; i < maxi; i++)
/*     */     {
/* 781 */       char c = text[i];
/*     */       
/* 783 */       if ((!inApos) && (c == '"')) {
/* 784 */         inQuotes = !inQuotes;
/* 785 */       } else if ((!inQuotes) && (c == '\'')) {
/* 786 */         inApos = !inApos;
/* 787 */       } else if ((!inQuotes) && (!inApos) && (c == '[')) {
/* 788 */         bracketLevel++;
/* 789 */       } else if ((!inQuotes) && (!inApos) && (c == ']')) {
/* 790 */         bracketLevel--;
/* 791 */       } else if ((!inQuotes) && (!inApos) && (bracketLevel == 0) && (c == '>')) {
/* 792 */         return i;
/*     */       }
/*     */       
/* 795 */       ParsingLocatorUtil.countChar(locator, c);
/*     */     }
/*     */     
/*     */ 
/* 799 */     if (bracketLevel != 0)
/*     */     {
/* 801 */       return -2;
/*     */     }
/*     */     
/* 804 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\ParsingDocTypeMarkupUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */