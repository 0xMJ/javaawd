/*     */ package org.attoparser;
/*     */ 
/*     */ import org.attoparser.config.ParseConfiguration;
/*     */ import org.attoparser.select.ParseSelection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractChainedMarkupHandler
/*     */   extends AbstractMarkupHandler
/*     */ {
/*     */   private final IMarkupHandler next;
/*     */   
/*     */   protected AbstractChainedMarkupHandler(IMarkupHandler next)
/*     */   {
/*  67 */     if (next == null) {
/*  68 */       throw new IllegalArgumentException("Next handler cannot be null");
/*     */     }
/*  70 */     this.next = next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final IMarkupHandler getNext()
/*     */   {
/*  82 */     return this.next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setParseConfiguration(ParseConfiguration parseConfiguration)
/*     */   {
/*  89 */     this.next.setParseConfiguration(parseConfiguration);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setParseStatus(ParseStatus status)
/*     */   {
/*  95 */     this.next.setParseStatus(status);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setParseSelection(ParseSelection selection)
/*     */   {
/* 101 */     this.next.setParseSelection(selection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentStart(long startTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 110 */     this.next.handleDocumentStart(startTimeNanos, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 117 */     this.next.handleDocumentEnd(endTimeNanos, totalTimeNanos, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleXmlDeclaration(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int versionOffset, int versionLen, int versionLine, int versionCol, int encodingOffset, int encodingLen, int encodingLine, int encodingCol, int standaloneOffset, int standaloneLen, int standaloneLine, int standaloneCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 135 */     this.next.handleXmlDeclaration(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, versionOffset, versionLen, versionLine, versionCol, encodingOffset, encodingLen, encodingLine, encodingCol, standaloneOffset, standaloneLen, standaloneLine, standaloneCol, outerOffset, outerLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocType(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int elementNameOffset, int elementNameLen, int elementNameLine, int elementNameCol, int typeOffset, int typeLen, int typeLine, int typeCol, int publicIdOffset, int publicIdLen, int publicIdLine, int publicIdCol, int systemIdOffset, int systemIdLen, int systemIdLine, int systemIdCol, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, int outerOffset, int outerLen, int outerLine, int outerCol)
/*     */     throws ParseException
/*     */   {
/* 163 */     this.next.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, publicIdOffset, publicIdLen, publicIdLine, publicIdCol, systemIdOffset, systemIdLen, systemIdLine, systemIdCol, internalSubsetOffset, internalSubsetLen, internalSubsetLine, internalSubsetCol, outerOffset, outerLen, outerLine, outerCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCDATASection(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 182 */     this.next.handleCDATASection(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 193 */     this.next.handleComment(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 203 */     this.next.handleText(buffer, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 212 */     this.next.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 220 */     this.next.handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 230 */     this.next.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 238 */     this.next.handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 248 */     this.next.handleAutoOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 256 */     this.next.handleAutoOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 266 */     this.next.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 274 */     this.next.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 284 */     this.next.handleAutoCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 292 */     this.next.handleAutoCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 302 */     this.next.handleUnmatchedCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 311 */     this.next.handleUnmatchedCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws ParseException
/*     */   {
/* 326 */     this.next.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 341 */     this.next.handleInnerWhiteSpace(buffer, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleProcessingInstruction(char[] buffer, int targetOffset, int targetLen, int targetLine, int targetCol, int contentOffset, int contentLen, int contentLine, int contentCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 355 */     this.next.handleProcessingInstruction(buffer, targetOffset, targetLen, targetLine, targetCol, contentOffset, contentLen, contentLine, contentCol, outerOffset, outerLen, line, col);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\AbstractChainedMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */