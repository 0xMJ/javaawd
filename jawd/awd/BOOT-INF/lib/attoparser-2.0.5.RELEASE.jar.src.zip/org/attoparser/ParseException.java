/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = -7951733720511589140L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Integer line;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Integer col;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParseException()
/*     */   {
/*  45 */     this.line = null;
/*  46 */     this.col = null;
/*     */   }
/*     */   
/*     */   public ParseException(String message, Throwable throwable)
/*     */   {
/*  51 */     super(message(message, throwable), throwable);
/*     */     
/*  53 */     if ((throwable != null) && ((throwable instanceof ParseException))) {
/*  54 */       this.line = ((ParseException)throwable).getLine();
/*  55 */       this.col = ((ParseException)throwable).getCol();
/*     */     } else {
/*  57 */       this.line = null;
/*  58 */       this.col = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public ParseException(String message)
/*     */   {
/*  64 */     super(message);
/*  65 */     this.line = null;
/*  66 */     this.col = null;
/*     */   }
/*     */   
/*     */   public ParseException(Throwable throwable)
/*     */   {
/*  71 */     super(message(null, throwable), throwable);
/*     */     
/*  73 */     if ((throwable != null) && ((throwable instanceof ParseException))) {
/*  74 */       this.line = ((ParseException)throwable).getLine();
/*  75 */       this.col = ((ParseException)throwable).getCol();
/*     */     } else {
/*  77 */       this.line = null;
/*  78 */       this.col = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ParseException(int line, int col)
/*     */   {
/*  85 */     super(messagePrefix(line, col));
/*  86 */     this.line = Integer.valueOf(line);
/*  87 */     this.col = Integer.valueOf(col);
/*     */   }
/*     */   
/*     */   public ParseException(String message, Throwable throwable, int line, int col) {
/*  91 */     super(messagePrefix(line, col) + " " + message, throwable);
/*  92 */     this.line = Integer.valueOf(line);
/*  93 */     this.col = Integer.valueOf(col);
/*     */   }
/*     */   
/*     */   public ParseException(String message, int line, int col) {
/*  97 */     super(messagePrefix(line, col) + " " + message);
/*  98 */     this.line = Integer.valueOf(line);
/*  99 */     this.col = Integer.valueOf(col);
/*     */   }
/*     */   
/*     */   public ParseException(Throwable throwable, int line, int col) {
/* 103 */     super(messagePrefix(line, col), throwable);
/* 104 */     this.line = Integer.valueOf(line);
/* 105 */     this.col = Integer.valueOf(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String messagePrefix(int line, int col)
/*     */   {
/* 112 */     return "(Line = " + line + ", Column = " + col + ")";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String message(String message, Throwable throwable)
/*     */   {
/* 119 */     if ((throwable != null) && ((throwable instanceof ParseException)))
/*     */     {
/* 121 */       ParseException exception = (ParseException)throwable;
/* 122 */       if ((exception.getLine() != null) && (exception.getCol() != null)) {
/* 123 */         return 
/* 124 */           "(Line = " + exception.getLine() + ", Column = " + exception.getCol() + ")" + (message != null ? " " + message : throwable.getMessage());
/*     */       }
/*     */     }
/*     */     
/* 128 */     if (message != null) {
/* 129 */       return message;
/*     */     }
/* 131 */     if (throwable != null) {
/* 132 */       return throwable.getMessage();
/*     */     }
/* 134 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getLine()
/*     */   {
/* 143 */     return this.line;
/*     */   }
/*     */   
/*     */   public Integer getCol() {
/* 147 */     return this.col;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\attoparser-2.0.5.RELEASE.jar!\org\attoparser\ParseException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */