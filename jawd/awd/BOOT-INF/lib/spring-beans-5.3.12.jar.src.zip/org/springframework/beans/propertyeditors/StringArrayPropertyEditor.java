/*     */ package org.springframework.beans.propertyeditors;
/*     */ 
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringArrayPropertyEditor
/*     */   extends PropertyEditorSupport
/*     */ {
/*     */   public static final String DEFAULT_SEPARATOR = ",";
/*     */   private final String separator;
/*     */   @Nullable
/*     */   private final String charsToDelete;
/*     */   private final boolean emptyArrayAsNull;
/*     */   private final boolean trimValues;
/*     */   
/*     */   public StringArrayPropertyEditor()
/*     */   {
/*  61 */     this(",", null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringArrayPropertyEditor(String separator)
/*     */   {
/*  70 */     this(separator, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringArrayPropertyEditor(String separator, boolean emptyArrayAsNull)
/*     */   {
/*  80 */     this(separator, null, emptyArrayAsNull);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringArrayPropertyEditor(String separator, boolean emptyArrayAsNull, boolean trimValues)
/*     */   {
/*  92 */     this(separator, null, emptyArrayAsNull, trimValues);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringArrayPropertyEditor(String separator, @Nullable String charsToDelete, boolean emptyArrayAsNull)
/*     */   {
/* 105 */     this(separator, charsToDelete, emptyArrayAsNull, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringArrayPropertyEditor(String separator, @Nullable String charsToDelete, boolean emptyArrayAsNull, boolean trimValues)
/*     */   {
/* 122 */     this.separator = separator;
/* 123 */     this.charsToDelete = charsToDelete;
/* 124 */     this.emptyArrayAsNull = emptyArrayAsNull;
/* 125 */     this.trimValues = trimValues;
/*     */   }
/*     */   
/*     */   public void setAsText(String text) throws IllegalArgumentException
/*     */   {
/* 130 */     String[] array = StringUtils.delimitedListToStringArray(text, this.separator, this.charsToDelete);
/* 131 */     if ((this.emptyArrayAsNull) && (array.length == 0)) {
/* 132 */       setValue(null);
/*     */     }
/*     */     else {
/* 135 */       if (this.trimValues) {
/* 136 */         array = StringUtils.trimArrayElements(array);
/*     */       }
/* 138 */       setValue(array);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getAsText()
/*     */   {
/* 144 */     return StringUtils.arrayToDelimitedString(ObjectUtils.toObjectArray(getValue()), this.separator);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\propertyeditors\StringArrayPropertyEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */