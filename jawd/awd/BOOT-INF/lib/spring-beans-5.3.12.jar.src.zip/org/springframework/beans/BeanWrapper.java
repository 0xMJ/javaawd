package org.springframework.beans;

import java.beans.PropertyDescriptor;

public abstract interface BeanWrapper
  extends ConfigurablePropertyAccessor
{
  public abstract void setAutoGrowCollectionLimit(int paramInt);
  
  public abstract int getAutoGrowCollectionLimit();
  
  public abstract Object getWrappedInstance();
  
  public abstract Class<?> getWrappedClass();
  
  public abstract PropertyDescriptor[] getPropertyDescriptors();
  
  public abstract PropertyDescriptor getPropertyDescriptor(String paramString)
    throws InvalidPropertyException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\BeanWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */