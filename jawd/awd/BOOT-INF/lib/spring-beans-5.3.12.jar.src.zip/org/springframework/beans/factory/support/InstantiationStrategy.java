package org.springframework.beans.factory.support;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.lang.Nullable;

public abstract interface InstantiationStrategy
{
  public abstract Object instantiate(RootBeanDefinition paramRootBeanDefinition, @Nullable String paramString, BeanFactory paramBeanFactory)
    throws BeansException;
  
  public abstract Object instantiate(RootBeanDefinition paramRootBeanDefinition, @Nullable String paramString, BeanFactory paramBeanFactory, Constructor<?> paramConstructor, Object... paramVarArgs)
    throws BeansException;
  
  public abstract Object instantiate(RootBeanDefinition paramRootBeanDefinition, @Nullable String paramString, BeanFactory paramBeanFactory, @Nullable Object paramObject, Method paramMethod, Object... paramVarArgs)
    throws BeansException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\support\InstantiationStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */