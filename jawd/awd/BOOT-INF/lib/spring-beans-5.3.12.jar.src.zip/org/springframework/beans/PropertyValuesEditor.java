/*    */ package org.springframework.beans;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.propertyeditors.PropertiesEditor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyValuesEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/* 39 */   private final PropertiesEditor propertiesEditor = new PropertiesEditor();
/*    */   
/*    */   public void setAsText(String text) throws IllegalArgumentException
/*    */   {
/* 43 */     this.propertiesEditor.setAsText(text);
/* 44 */     Properties props = (Properties)this.propertiesEditor.getValue();
/* 45 */     setValue(new MutablePropertyValues(props));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\PropertyValuesEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */