package org.springframework.beans.factory.parsing;

import org.springframework.core.io.Resource;
import org.springframework.lang.Nullable;

@FunctionalInterface
public abstract interface SourceExtractor
{
  @Nullable
  public abstract Object extractSource(Object paramObject, @Nullable Resource paramResource);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\parsing\SourceExtractor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */