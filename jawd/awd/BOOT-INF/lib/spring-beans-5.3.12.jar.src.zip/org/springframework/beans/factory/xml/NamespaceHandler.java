package org.springframework.beans.factory.xml;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanDefinitionHolder;
import org.springframework.lang.Nullable;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public abstract interface NamespaceHandler
{
  public abstract void init();
  
  @Nullable
  public abstract BeanDefinition parse(Element paramElement, ParserContext paramParserContext);
  
  @Nullable
  public abstract BeanDefinitionHolder decorate(Node paramNode, BeanDefinitionHolder paramBeanDefinitionHolder, ParserContext paramParserContext);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\xml\NamespaceHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */