package org.springframework.beans.factory;

public abstract interface InitializingBean
{
  public abstract void afterPropertiesSet()
    throws Exception;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\InitializingBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */