/*    */ package org.springframework.beans.propertyeditors;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.util.Currency;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CurrencyEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String text)
/*    */     throws IllegalArgumentException
/*    */   {
/* 34 */     setValue(Currency.getInstance(text));
/*    */   }
/*    */   
/*    */   public String getAsText()
/*    */   {
/* 39 */     Currency value = (Currency)getValue();
/* 40 */     return value != null ? value.getCurrencyCode() : "";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\propertyeditors\CurrencyEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */