package org.springframework.beans.factory.annotation;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.core.type.MethodMetadata;
import org.springframework.lang.Nullable;

public abstract interface AnnotatedBeanDefinition
  extends BeanDefinition
{
  public abstract AnnotationMetadata getMetadata();
  
  @Nullable
  public abstract MethodMetadata getFactoryMethodMetadata();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\annotation\AnnotatedBeanDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */