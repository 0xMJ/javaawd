/*     */ package org.springframework.beans.factory;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface ObjectProvider<T>
/*     */   extends ObjectFactory<T>, Iterable<T>
/*     */ {
/*     */   public abstract T getObject(Object... paramVarArgs)
/*     */     throws BeansException;
/*     */   
/*     */   @Nullable
/*     */   public abstract T getIfAvailable()
/*     */     throws BeansException;
/*     */   
/*     */   public T getIfAvailable(Supplier<T> defaultSupplier)
/*     */     throws BeansException
/*     */   {
/*  77 */     T dependency = getIfAvailable();
/*  78 */     return dependency != null ? dependency : defaultSupplier.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void ifAvailable(Consumer<T> dependencyConsumer)
/*     */     throws BeansException
/*     */   {
/*  91 */     T dependency = getIfAvailable();
/*  92 */     if (dependency != null) {
/*  93 */       dependencyConsumer.accept(dependency);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public abstract T getIfUnique()
/*     */     throws BeansException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T getIfUnique(Supplier<T> defaultSupplier)
/*     */     throws BeansException
/*     */   {
/* 121 */     T dependency = getIfUnique();
/* 122 */     return dependency != null ? dependency : defaultSupplier.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void ifUnique(Consumer<T> dependencyConsumer)
/*     */     throws BeansException
/*     */   {
/* 135 */     T dependency = getIfUnique();
/* 136 */     if (dependency != null) {
/* 137 */       dependencyConsumer.accept(dependency);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<T> iterator()
/*     */   {
/* 149 */     return stream().iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Stream<T> stream()
/*     */   {
/* 160 */     throw new UnsupportedOperationException("Multi element access not supported");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Stream<T> orderedStream()
/*     */   {
/* 176 */     throw new UnsupportedOperationException("Ordered element access not supported");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\ObjectProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */