package org.springframework.beans.factory;

import org.springframework.beans.BeansException;

@FunctionalInterface
public abstract interface ObjectFactory<T>
{
  public abstract T getObject()
    throws BeansException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\ObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */