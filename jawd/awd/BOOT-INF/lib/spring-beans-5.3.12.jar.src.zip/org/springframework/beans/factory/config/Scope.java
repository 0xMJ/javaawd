package org.springframework.beans.factory.config;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.lang.Nullable;

public abstract interface Scope
{
  public abstract Object get(String paramString, ObjectFactory<?> paramObjectFactory);
  
  @Nullable
  public abstract Object remove(String paramString);
  
  public abstract void registerDestructionCallback(String paramString, Runnable paramRunnable);
  
  @Nullable
  public abstract Object resolveContextualObject(String paramString);
  
  @Nullable
  public abstract String getConversationId();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\config\Scope.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */