package org.springframework.beans;

import org.springframework.lang.Nullable;

public abstract interface Mergeable
{
  public abstract boolean isMergeEnabled();
  
  public abstract Object merge(@Nullable Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\Mergeable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */