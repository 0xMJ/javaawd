/*     */ package org.springframework.beans.factory.support;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RootBeanDefinition
/*     */   extends AbstractBeanDefinition
/*     */ {
/*     */   @Nullable
/*     */   private BeanDefinitionHolder decoratedDefinition;
/*     */   @Nullable
/*     */   private AnnotatedElement qualifiedElement;
/*     */   volatile boolean stale;
/*  67 */   boolean allowCaching = true;
/*     */   
/*     */ 
/*     */   boolean isFactoryMethodUnique;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   volatile ResolvableType targetType;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   volatile Class<?> resolvedTargetType;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   volatile Boolean isFactoryBean;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   volatile ResolvableType factoryMethodReturnType;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   volatile Method factoryMethodToIntrospect;
/*     */   
/*     */   @Nullable
/*     */   volatile String resolvedDestroyMethodName;
/*     */   
/*  95 */   final Object constructorArgumentLock = new Object();
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   Executable resolvedConstructorOrFactoryMethod;
/*     */   
/*     */ 
/* 102 */   boolean constructorArgumentsResolved = false;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   Object[] resolvedConstructorArguments;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   Object[] preparedConstructorArguments;
/*     */   
/*     */ 
/* 113 */   final Object postProcessingLock = new Object();
/*     */   
/*     */ 
/* 116 */   boolean postProcessed = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   volatile Boolean beforeInstantiationResolved;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Set<Member> externallyManagedConfigMembers;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Set<String> externallyManagedInitMethods;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Set<String> externallyManagedDestroyMethods;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RootBeanDefinition() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RootBeanDefinition(@Nullable Class<?> beanClass)
/*     */   {
/* 151 */     setBeanClass(beanClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> RootBeanDefinition(@Nullable Class<T> beanClass, @Nullable Supplier<T> instanceSupplier)
/*     */   {
/* 165 */     setBeanClass(beanClass);
/* 166 */     setInstanceSupplier(instanceSupplier);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> RootBeanDefinition(@Nullable Class<T> beanClass, String scope, @Nullable Supplier<T> instanceSupplier)
/*     */   {
/* 181 */     setBeanClass(beanClass);
/* 182 */     setScope(scope);
/* 183 */     setInstanceSupplier(instanceSupplier);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RootBeanDefinition(@Nullable Class<?> beanClass, int autowireMode, boolean dependencyCheck)
/*     */   {
/* 196 */     setBeanClass(beanClass);
/* 197 */     setAutowireMode(autowireMode);
/* 198 */     if ((dependencyCheck) && (getResolvedAutowireMode() != 3)) {
/* 199 */       setDependencyCheck(1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RootBeanDefinition(@Nullable Class<?> beanClass, @Nullable ConstructorArgumentValues cargs, @Nullable MutablePropertyValues pvs)
/*     */   {
/* 213 */     super(cargs, pvs);
/* 214 */     setBeanClass(beanClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RootBeanDefinition(String beanClassName)
/*     */   {
/* 224 */     setBeanClassName(beanClassName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RootBeanDefinition(String beanClassName, ConstructorArgumentValues cargs, MutablePropertyValues pvs)
/*     */   {
/* 236 */     super(cargs, pvs);
/* 237 */     setBeanClassName(beanClassName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RootBeanDefinition(RootBeanDefinition original)
/*     */   {
/* 246 */     super(original);
/* 247 */     this.decoratedDefinition = original.decoratedDefinition;
/* 248 */     this.qualifiedElement = original.qualifiedElement;
/* 249 */     this.allowCaching = original.allowCaching;
/* 250 */     this.isFactoryMethodUnique = original.isFactoryMethodUnique;
/* 251 */     this.targetType = original.targetType;
/* 252 */     this.factoryMethodToIntrospect = original.factoryMethodToIntrospect;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   RootBeanDefinition(BeanDefinition original)
/*     */   {
/* 261 */     super(original);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getParentName()
/*     */   {
/* 267 */     return null;
/*     */   }
/*     */   
/*     */   public void setParentName(@Nullable String parentName)
/*     */   {
/* 272 */     if (parentName != null) {
/* 273 */       throw new IllegalArgumentException("Root bean cannot be changed into a child bean with parent reference");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDecoratedDefinition(@Nullable BeanDefinitionHolder decoratedDefinition)
/*     */   {
/* 281 */     this.decoratedDefinition = decoratedDefinition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public BeanDefinitionHolder getDecoratedDefinition()
/*     */   {
/* 289 */     return this.decoratedDefinition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setQualifiedElement(@Nullable AnnotatedElement qualifiedElement)
/*     */   {
/* 300 */     this.qualifiedElement = qualifiedElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public AnnotatedElement getQualifiedElement()
/*     */   {
/* 310 */     return this.qualifiedElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetType(ResolvableType targetType)
/*     */   {
/* 318 */     this.targetType = targetType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetType(@Nullable Class<?> targetType)
/*     */   {
/* 326 */     this.targetType = (targetType != null ? ResolvableType.forClass(targetType) : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Class<?> getTargetType()
/*     */   {
/* 336 */     if (this.resolvedTargetType != null) {
/* 337 */       return this.resolvedTargetType;
/*     */     }
/* 339 */     ResolvableType targetType = this.targetType;
/* 340 */     return targetType != null ? targetType.resolve() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResolvableType getResolvableType()
/*     */   {
/* 355 */     ResolvableType targetType = this.targetType;
/* 356 */     if (targetType != null) {
/* 357 */       return targetType;
/*     */     }
/* 359 */     ResolvableType returnType = this.factoryMethodReturnType;
/* 360 */     if (returnType != null) {
/* 361 */       return returnType;
/*     */     }
/* 363 */     Method factoryMethod = this.factoryMethodToIntrospect;
/* 364 */     if (factoryMethod != null) {
/* 365 */       return ResolvableType.forMethodReturnType(factoryMethod);
/*     */     }
/* 367 */     return super.getResolvableType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Constructor<?>[] getPreferredConstructors()
/*     */   {
/* 379 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUniqueFactoryMethodName(String name)
/*     */   {
/* 386 */     Assert.hasText(name, "Factory method name must not be empty");
/* 387 */     setFactoryMethodName(name);
/* 388 */     this.isFactoryMethodUnique = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNonUniqueFactoryMethodName(String name)
/*     */   {
/* 396 */     Assert.hasText(name, "Factory method name must not be empty");
/* 397 */     setFactoryMethodName(name);
/* 398 */     this.isFactoryMethodUnique = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isFactoryMethod(Method candidate)
/*     */   {
/* 405 */     return candidate.getName().equals(getFactoryMethodName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResolvedFactoryMethod(@Nullable Method method)
/*     */   {
/* 414 */     this.factoryMethodToIntrospect = method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Method getResolvedFactoryMethod()
/*     */   {
/* 423 */     return this.factoryMethodToIntrospect;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void registerExternallyManagedConfigMember(Member configMember)
/*     */   {
/* 430 */     synchronized (this.postProcessingLock) {
/* 431 */       if (this.externallyManagedConfigMembers == null) {
/* 432 */         this.externallyManagedConfigMembers = new LinkedHashSet(1);
/*     */       }
/* 434 */       this.externallyManagedConfigMembers.add(configMember);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isExternallyManagedConfigMember(Member configMember)
/*     */   {
/* 442 */     synchronized (this.postProcessingLock) {
/* 443 */       return (this.externallyManagedConfigMembers != null) && 
/* 444 */         (this.externallyManagedConfigMembers.contains(configMember));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<Member> getExternallyManagedConfigMembers()
/*     */   {
/* 453 */     synchronized (this.postProcessingLock) {
/* 454 */       return this.externallyManagedConfigMembers != null ? 
/* 455 */         Collections.unmodifiableSet(new LinkedHashSet(this.externallyManagedConfigMembers)) : 
/* 456 */         Collections.emptySet();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void registerExternallyManagedInitMethod(String initMethod)
/*     */   {
/* 464 */     synchronized (this.postProcessingLock) {
/* 465 */       if (this.externallyManagedInitMethods == null) {
/* 466 */         this.externallyManagedInitMethods = new LinkedHashSet(1);
/*     */       }
/* 468 */       this.externallyManagedInitMethods.add(initMethod);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isExternallyManagedInitMethod(String initMethod)
/*     */   {
/* 476 */     synchronized (this.postProcessingLock) {
/* 477 */       return (this.externallyManagedInitMethods != null) && 
/* 478 */         (this.externallyManagedInitMethods.contains(initMethod));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> getExternallyManagedInitMethods()
/*     */   {
/* 487 */     synchronized (this.postProcessingLock) {
/* 488 */       return this.externallyManagedInitMethods != null ? 
/* 489 */         Collections.unmodifiableSet(new LinkedHashSet(this.externallyManagedInitMethods)) : 
/* 490 */         Collections.emptySet();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void registerExternallyManagedDestroyMethod(String destroyMethod)
/*     */   {
/* 498 */     synchronized (this.postProcessingLock) {
/* 499 */       if (this.externallyManagedDestroyMethods == null) {
/* 500 */         this.externallyManagedDestroyMethods = new LinkedHashSet(1);
/*     */       }
/* 502 */       this.externallyManagedDestroyMethods.add(destroyMethod);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isExternallyManagedDestroyMethod(String destroyMethod)
/*     */   {
/* 510 */     synchronized (this.postProcessingLock) {
/* 511 */       return (this.externallyManagedDestroyMethods != null) && 
/* 512 */         (this.externallyManagedDestroyMethods.contains(destroyMethod));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> getExternallyManagedDestroyMethods()
/*     */   {
/* 521 */     synchronized (this.postProcessingLock) {
/* 522 */       return this.externallyManagedDestroyMethods != null ? 
/* 523 */         Collections.unmodifiableSet(new LinkedHashSet(this.externallyManagedDestroyMethods)) : 
/* 524 */         Collections.emptySet();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public RootBeanDefinition cloneBeanDefinition()
/*     */   {
/* 531 */     return new RootBeanDefinition(this);
/*     */   }
/*     */   
/*     */   public boolean equals(@Nullable Object other)
/*     */   {
/* 536 */     return (this == other) || (((other instanceof RootBeanDefinition)) && (super.equals(other)));
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 541 */     return "Root bean: " + super.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\support\RootBeanDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */