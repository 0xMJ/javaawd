package org.springframework.beans.factory.config;

import org.springframework.lang.Nullable;

public abstract interface SingletonBeanRegistry
{
  public abstract void registerSingleton(String paramString, Object paramObject);
  
  @Nullable
  public abstract Object getSingleton(String paramString);
  
  public abstract boolean containsSingleton(String paramString);
  
  public abstract String[] getSingletonNames();
  
  public abstract int getSingletonCount();
  
  public abstract Object getSingletonMutex();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\config\SingletonBeanRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */