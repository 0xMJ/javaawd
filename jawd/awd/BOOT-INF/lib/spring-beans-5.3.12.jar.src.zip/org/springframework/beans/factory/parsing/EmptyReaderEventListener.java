package org.springframework.beans.factory.parsing;

public class EmptyReaderEventListener
  implements ReaderEventListener
{
  public void defaultsRegistered(DefaultsDefinition defaultsDefinition) {}
  
  public void componentRegistered(ComponentDefinition componentDefinition) {}
  
  public void aliasRegistered(AliasDefinition aliasDefinition) {}
  
  public void importProcessed(ImportDefinition importDefinition) {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\parsing\EmptyReaderEventListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */