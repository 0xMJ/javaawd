/*     */ package org.springframework.beans.factory.groovy;
/*     */ 
/*     */ import groovy.lang.Closure;
/*     */ import groovy.lang.GroovyObjectSupport;
/*     */ import groovy.lang.Reference;
/*     */ import groovy.transform.Generated;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.codehaus.groovy.runtime.GStringImpl;
/*     */ import org.codehaus.groovy.runtime.GeneratedClosure;
/*     */ import org.codehaus.groovy.runtime.ScriptBytecodeAdapter;
/*     */ import org.codehaus.groovy.runtime.callsite.CallSite;
/*     */ import org.codehaus.groovy.runtime.typehandling.DefaultTypeTransformation;
/*     */ import org.codehaus.groovy.runtime.typehandling.ShortTypeHandling;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GroovyDynamicElementReader
/*     */   extends GroovyObjectSupport
/*     */ {
/*     */   private final String rootNamespace;
/*     */   private final Map<String, String> xmlNamespaces;
/*     */   private final BeanDefinitionParserDelegate delegate;
/*     */   private final GroovyBeanDefinitionWrapper beanDefinition;
/*     */   protected final boolean decorating;
/*     */   private boolean callAfterInvocation;
/*     */   
/*     */   public GroovyDynamicElementReader(String namespace, Map<String, String> namespaceMap, BeanDefinitionParserDelegate delegate, GroovyBeanDefinitionWrapper beanDefinition, boolean decorating)
/*     */   {
/*  50 */     boolean bool1 = true;this.callAfterInvocation = bool1;
/*  51 */     String str = namespace;this.rootNamespace = str;
/*  52 */     Map localMap = namespaceMap;this.xmlNamespaces = localMap;
/*  53 */     BeanDefinitionParserDelegate localBeanDefinitionParserDelegate = delegate;this.delegate = localBeanDefinitionParserDelegate;
/*  54 */     GroovyBeanDefinitionWrapper localGroovyBeanDefinitionWrapper = beanDefinition;this.beanDefinition = localGroovyBeanDefinitionWrapper;
/*  55 */     boolean bool2 = decorating;this.decorating = bool2;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object invokeMethod(String name, Object args)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: new 51	groovy/lang/Reference
/*     */     //   4: dup_x1
/*     */     //   5: swap
/*     */     //   6: invokespecial 54	groovy/lang/Reference:<init>	(Ljava/lang/Object;)V
/*     */     //   9: astore_3
/*     */     //   10: aload_2
/*     */     //   11: new 51	groovy/lang/Reference
/*     */     //   14: dup_x1
/*     */     //   15: swap
/*     */     //   16: invokespecial 54	groovy/lang/Reference:<init>	(Ljava/lang/Object;)V
/*     */     //   19: astore 4
/*     */     //   21: nop
/*     */     //   22: invokestatic 28	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:$getCallSiteArray	()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
/*     */     //   25: astore 5
/*     */     //   27: aload 5
/*     */     //   29: ldc 55
/*     */     //   31: aaload
/*     */     //   32: aload_3
/*     */     //   33: invokevirtual 59	groovy/lang/Reference:get	()Ljava/lang/Object;
/*     */     //   36: checkcast 61	java/lang/String
/*     */     //   39: ldc 63
/*     */     //   41: invokeinterface 69 3 0
/*     */     //   46: invokestatic 75	org/codehaus/groovy/runtime/typehandling/DefaultTypeTransformation:booleanUnbox	(Ljava/lang/Object;)Z
/*     */     //   49: ifeq +159 -> 208
/*     */     //   52: aload 5
/*     */     //   54: ldc 76
/*     */     //   56: aaload
/*     */     //   57: aload 4
/*     */     //   59: invokevirtual 59	groovy/lang/Reference:get	()Ljava/lang/Object;
/*     */     //   62: checkcast 78	java/lang/Object
/*     */     //   65: iconst_0
/*     */     //   66: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
/*     */     //   69: invokeinterface 69 3 0
/*     */     //   74: astore 6
/*     */     //   76: aload 6
/*     */     //   78: pop
/*     */     //   79: aload 5
/*     */     //   81: ldc 85
/*     */     //   83: aaload
/*     */     //   84: ldc 87
/*     */     //   86: invokeinterface 91 2 0
/*     */     //   91: astore 7
/*     */     //   93: aload 7
/*     */     //   95: aconst_null
/*     */     //   96: aload 6
/*     */     //   98: ldc 93
/*     */     //   100: checkcast 61	java/lang/String
/*     */     //   103: invokestatic 99	org/codehaus/groovy/runtime/ScriptBytecodeAdapter:setProperty	(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   106: aload 7
/*     */     //   108: pop
/*     */     //   109: aload_0
/*     */     //   110: astore 8
/*     */     //   112: aload 8
/*     */     //   114: aconst_null
/*     */     //   115: aload 6
/*     */     //   117: ldc 100
/*     */     //   119: checkcast 61	java/lang/String
/*     */     //   122: invokestatic 99	org/codehaus/groovy/runtime/ScriptBytecodeAdapter:setProperty	(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   125: aload 8
/*     */     //   127: pop
/*     */     //   128: aload 5
/*     */     //   130: ldc 101
/*     */     //   132: aaload
/*     */     //   133: aload 6
/*     */     //   135: invokeinterface 103 2 0
/*     */     //   140: astore 9
/*     */     //   142: aload 9
/*     */     //   144: pop
/*     */     //   145: aload_0
/*     */     //   146: getfield 33	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:callAfterInvocation	Z
/*     */     //   149: ifeq +53 -> 202
/*     */     //   152: getstatic 105	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:__$stMC	Z
/*     */     //   155: ifne +12 -> 167
/*     */     //   158: invokestatic 111	org/codehaus/groovy/runtime/BytecodeInterface8:disabledStandardMetaClass	()Z
/*     */     //   161: ifne +6 -> 167
/*     */     //   164: goto +18 -> 182
/*     */     //   167: aload 5
/*     */     //   169: ldc 112
/*     */     //   171: aaload
/*     */     //   172: aload_0
/*     */     //   173: invokeinterface 116 2 0
/*     */     //   178: pop
/*     */     //   179: goto +10 -> 189
/*     */     //   182: aload 0
/*     */     //   184: invokevirtual 119	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:afterInvocation	()V
/*     */     //   187: aconst_null
/*     */     //   188: pop
/*     */     //   189: iconst_0
/*     */     //   190: istore 10
/*     */     //   192: iload 10
/*     */     //   194: aload_0
/*     */     //   195: swap
/*     */     //   196: putfield 33	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:callAfterInvocation	Z
/*     */     //   199: iload 10
/*     */     //   201: pop
/*     */     //   202: aload 9
/*     */     //   204: areturn
/*     */     //   205: nop
/*     */     //   206: nop
/*     */     //   207: athrow
/*     */     //   208: aload 5
/*     */     //   210: ldc 120
/*     */     //   212: aaload
/*     */     //   213: ldc 122
/*     */     //   215: invokeinterface 125 2 0
/*     */     //   220: ldc 122
/*     */     //   222: invokestatic 129	org/codehaus/groovy/runtime/ScriptBytecodeAdapter:castToType	(Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
/*     */     //   225: checkcast 122	groovy/xml/StreamingMarkupBuilder
/*     */     //   228: new 51	groovy/lang/Reference
/*     */     //   231: dup_x1
/*     */     //   232: swap
/*     */     //   233: invokespecial 54	groovy/lang/Reference:<init>	(Ljava/lang/Object;)V
/*     */     //   236: astore 11
/*     */     //   238: aload 11
/*     */     //   240: pop
/*     */     //   241: aload_0
/*     */     //   242: getfield 35	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:rootNamespace	Ljava/lang/String;
/*     */     //   245: new 51	groovy/lang/Reference
/*     */     //   248: dup_x1
/*     */     //   249: swap
/*     */     //   250: invokespecial 54	groovy/lang/Reference:<init>	(Ljava/lang/Object;)V
/*     */     //   253: astore 12
/*     */     //   255: aload 12
/*     */     //   257: pop
/*     */     //   258: aload_0
/*     */     //   259: getfield 37	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:xmlNamespaces	Ljava/util/Map;
/*     */     //   262: new 51	groovy/lang/Reference
/*     */     //   265: dup_x1
/*     */     //   266: swap
/*     */     //   267: invokespecial 54	groovy/lang/Reference:<init>	(Ljava/lang/Object;)V
/*     */     //   270: astore 13
/*     */     //   272: aload 13
/*     */     //   274: pop
/*     */     //   275: new 131	org/springframework/beans/factory/groovy/GroovyDynamicElementReader$_invokeMethod_closure1
/*     */     //   278: dup
/*     */     //   279: aload_0
/*     */     //   280: aload_0
/*     */     //   281: aload 13
/*     */     //   283: aload 4
/*     */     //   285: aload 11
/*     */     //   287: aload 12
/*     */     //   289: aload_3
/*     */     //   290: invokespecial 134	org/springframework/beans/factory/groovy/GroovyDynamicElementReader$_invokeMethod_closure1:<init>	(Ljava/lang/Object;Ljava/lang/Object;Lgroovy/lang/Reference;Lgroovy/lang/Reference;Lgroovy/lang/Reference;Lgroovy/lang/Reference;Lgroovy/lang/Reference;)V
/*     */     //   293: astore 14
/*     */     //   295: aload 14
/*     */     //   297: pop
/*     */     //   298: aload 5
/*     */     //   300: ldc -121
/*     */     //   302: aaload
/*     */     //   303: ldc 87
/*     */     //   305: invokeinterface 91 2 0
/*     */     //   310: astore 15
/*     */     //   312: aload 15
/*     */     //   314: aconst_null
/*     */     //   315: aload 14
/*     */     //   317: ldc 93
/*     */     //   319: checkcast 61	java/lang/String
/*     */     //   322: invokestatic 99	org/codehaus/groovy/runtime/ScriptBytecodeAdapter:setProperty	(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   325: aload 15
/*     */     //   327: pop
/*     */     //   328: aload 11
/*     */     //   330: invokevirtual 59	groovy/lang/Reference:get	()Ljava/lang/Object;
/*     */     //   333: checkcast 122	groovy/xml/StreamingMarkupBuilder
/*     */     //   336: astore 16
/*     */     //   338: aload 16
/*     */     //   340: aconst_null
/*     */     //   341: aload 14
/*     */     //   343: ldc 100
/*     */     //   345: checkcast 61	java/lang/String
/*     */     //   348: invokestatic 99	org/codehaus/groovy/runtime/ScriptBytecodeAdapter:setProperty	(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   351: aload 16
/*     */     //   353: pop
/*     */     //   354: aload 5
/*     */     //   356: ldc -120
/*     */     //   358: aaload
/*     */     //   359: aload 11
/*     */     //   361: invokevirtual 59	groovy/lang/Reference:get	()Ljava/lang/Object;
/*     */     //   364: checkcast 122	groovy/xml/StreamingMarkupBuilder
/*     */     //   367: aload 14
/*     */     //   369: invokeinterface 69 3 0
/*     */     //   374: astore 17
/*     */     //   376: aload 17
/*     */     //   378: pop
/*     */     //   379: aload 5
/*     */     //   381: ldc -119
/*     */     //   383: aaload
/*     */     //   384: ldc -117
/*     */     //   386: invokeinterface 125 2 0
/*     */     //   391: astore 18
/*     */     //   393: aload 18
/*     */     //   395: pop
/*     */     //   396: aload 5
/*     */     //   398: ldc -116
/*     */     //   400: aaload
/*     */     //   401: aload 17
/*     */     //   403: aload 18
/*     */     //   405: invokeinterface 69 3 0
/*     */     //   410: pop
/*     */     //   411: aload 5
/*     */     //   413: ldc -115
/*     */     //   415: aaload
/*     */     //   416: aload 5
/*     */     //   418: ldc -114
/*     */     //   420: aaload
/*     */     //   421: aload 5
/*     */     //   423: ldc -113
/*     */     //   425: aaload
/*     */     //   426: aload_0
/*     */     //   427: getfield 39	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:delegate	Lorg/springframework/beans/factory/xml/BeanDefinitionParserDelegate;
/*     */     //   430: invokeinterface 91 2 0
/*     */     //   435: aload 5
/*     */     //   437: ldc -112
/*     */     //   439: aaload
/*     */     //   440: aload 18
/*     */     //   442: invokeinterface 103 2 0
/*     */     //   447: invokeinterface 69 3 0
/*     */     //   452: invokeinterface 91 2 0
/*     */     //   457: ldc -110
/*     */     //   459: invokestatic 129	org/codehaus/groovy/runtime/ScriptBytecodeAdapter:castToType	(Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
/*     */     //   462: checkcast 146	org/w3c/dom/Element
/*     */     //   465: astore 19
/*     */     //   467: aload 19
/*     */     //   469: pop
/*     */     //   470: aload 5
/*     */     //   472: ldc -109
/*     */     //   474: aaload
/*     */     //   475: aload_0
/*     */     //   476: getfield 39	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:delegate	Lorg/springframework/beans/factory/xml/BeanDefinitionParserDelegate;
/*     */     //   479: aload 19
/*     */     //   481: invokeinterface 69 3 0
/*     */     //   486: pop
/*     */     //   487: aload_0
/*     */     //   488: getfield 43	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:decorating	Z
/*     */     //   491: ifeq +86 -> 577
/*     */     //   494: aload 5
/*     */     //   496: ldc -108
/*     */     //   498: aaload
/*     */     //   499: aload_0
/*     */     //   500: getfield 41	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:beanDefinition	Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   503: invokeinterface 91 2 0
/*     */     //   508: ldc -106
/*     */     //   510: invokestatic 129	org/codehaus/groovy/runtime/ScriptBytecodeAdapter:castToType	(Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
/*     */     //   513: checkcast 150	org/springframework/beans/factory/config/BeanDefinitionHolder
/*     */     //   516: astore 20
/*     */     //   518: aload 20
/*     */     //   520: pop
/*     */     //   521: aload 5
/*     */     //   523: ldc -105
/*     */     //   525: aaload
/*     */     //   526: aload_0
/*     */     //   527: getfield 39	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:delegate	Lorg/springframework/beans/factory/xml/BeanDefinitionParserDelegate;
/*     */     //   530: aload 19
/*     */     //   532: aload 20
/*     */     //   534: aconst_null
/*     */     //   535: invokeinterface 154 5 0
/*     */     //   540: astore 21
/*     */     //   542: aload 21
/*     */     //   544: ldc -106
/*     */     //   546: invokestatic 129	org/codehaus/groovy/runtime/ScriptBytecodeAdapter:castToType	(Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
/*     */     //   549: checkcast 150	org/springframework/beans/factory/config/BeanDefinitionHolder
/*     */     //   552: astore 20
/*     */     //   554: aload 21
/*     */     //   556: pop
/*     */     //   557: aload 5
/*     */     //   559: ldc -101
/*     */     //   561: aaload
/*     */     //   562: aload_0
/*     */     //   563: getfield 41	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:beanDefinition	Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   566: aload 20
/*     */     //   568: invokeinterface 69 3 0
/*     */     //   573: pop
/*     */     //   574: goto +49 -> 623
/*     */     //   577: aload 5
/*     */     //   579: ldc -100
/*     */     //   581: aaload
/*     */     //   582: aload_0
/*     */     //   583: getfield 39	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:delegate	Lorg/springframework/beans/factory/xml/BeanDefinitionParserDelegate;
/*     */     //   586: aload 19
/*     */     //   588: invokeinterface 69 3 0
/*     */     //   593: astore 22
/*     */     //   595: aload 22
/*     */     //   597: pop
/*     */     //   598: aload 22
/*     */     //   600: invokestatic 75	org/codehaus/groovy/runtime/typehandling/DefaultTypeTransformation:booleanUnbox	(Ljava/lang/Object;)Z
/*     */     //   603: ifeq +20 -> 623
/*     */     //   606: aload 5
/*     */     //   608: ldc -99
/*     */     //   610: aaload
/*     */     //   611: aload_0
/*     */     //   612: getfield 41	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:beanDefinition	Lorg/springframework/beans/factory/groovy/GroovyBeanDefinitionWrapper;
/*     */     //   615: aload 22
/*     */     //   617: invokeinterface 69 3 0
/*     */     //   622: pop
/*     */     //   623: aload_0
/*     */     //   624: getfield 33	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:callAfterInvocation	Z
/*     */     //   627: ifeq +53 -> 680
/*     */     //   630: getstatic 105	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:__$stMC	Z
/*     */     //   633: ifne +12 -> 645
/*     */     //   636: invokestatic 111	org/codehaus/groovy/runtime/BytecodeInterface8:disabledStandardMetaClass	()Z
/*     */     //   639: ifne +6 -> 645
/*     */     //   642: goto +18 -> 660
/*     */     //   645: aload 5
/*     */     //   647: ldc -98
/*     */     //   649: aaload
/*     */     //   650: aload_0
/*     */     //   651: invokeinterface 116 2 0
/*     */     //   656: pop
/*     */     //   657: goto +10 -> 667
/*     */     //   660: aload 0
/*     */     //   662: invokevirtual 119	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:afterInvocation	()V
/*     */     //   665: aconst_null
/*     */     //   666: pop
/*     */     //   667: iconst_0
/*     */     //   668: istore 23
/*     */     //   670: iload 23
/*     */     //   672: aload_0
/*     */     //   673: swap
/*     */     //   674: putfield 33	org/springframework/beans/factory/groovy/GroovyDynamicElementReader:callAfterInvocation	Z
/*     */     //   677: iload 23
/*     */     //   679: pop
/*     */     //   680: aload 19
/*     */     //   682: areturn
/*     */     //   683: nop
/*     */     //   684: athrow
/*     */     // Line number table:
/*     */     //   Java source line #61	-> byte code offset #27
/*     */     //   Java source line #62	-> byte code offset #52
/*     */     //   Java source line #63	-> byte code offset #79
/*     */     //   Java source line #64	-> byte code offset #109
/*     */     //   Java source line #65	-> byte code offset #128
/*     */     //   Java source line #67	-> byte code offset #145
/*     */     //   Java source line #68	-> byte code offset #152
/*     */     //   Java source line #68	-> byte code offset #182
/*     */     //   Java source line #69	-> byte code offset #189
/*     */     //   Java source line #70	-> byte code offset #202
/*     */     //   Java source line #71	-> byte code offset #202
/*     */     //   Java source line #72	-> byte code offset #205
/*     */     //   Java source line #75	-> byte code offset #208
/*     */     //   Java source line #76	-> byte code offset #241
/*     */     //   Java source line #77	-> byte code offset #258
/*     */     //   Java source line #79	-> byte code offset #275
/*     */     //   Java source line #90	-> byte code offset #298
/*     */     //   Java source line #91	-> byte code offset #328
/*     */     //   Java source line #92	-> byte code offset #354
/*     */     //   Java source line #93	-> byte code offset #379
/*     */     //   Java source line #94	-> byte code offset #396
/*     */     //   Java source line #96	-> byte code offset #411
/*     */     //   Java source line #97	-> byte code offset #470
/*     */     //   Java source line #98	-> byte code offset #487
/*     */     //   Java source line #99	-> byte code offset #494
/*     */     //   Java source line #100	-> byte code offset #521
/*     */     //   Java source line #101	-> byte code offset #557
/*     */     //   Java source line #102	-> byte code offset #574
/*     */     //   Java source line #104	-> byte code offset #577
/*     */     //   Java source line #105	-> byte code offset #598
/*     */     //   Java source line #106	-> byte code offset #606
/*     */     //   Java source line #107	-> byte code offset #623
/*     */     //   Java source line #108	-> byte code offset #623
/*     */     //   Java source line #109	-> byte code offset #623
/*     */     //   Java source line #110	-> byte code offset #630
/*     */     //   Java source line #110	-> byte code offset #660
/*     */     //   Java source line #111	-> byte code offset #667
/*     */     //   Java source line #112	-> byte code offset #680
/*     */     //   Java source line #113	-> byte code offset #680
/*     */     //   Java source line #114	-> byte code offset #683
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	683	0	this	GroovyDynamicElementReader
/*     */     //   0	1	1	name	String
/*     */     //   0	11	2	args	Object
/*     */     //   1	682	3	name	Reference
/*     */     //   11	672	4	args	Reference
/*     */     //   76	129	6	callable	Object
/*     */     //   142	63	9	result	Object
/*     */     //   238	445	11	builder	Reference
/*     */     //   255	428	12	myNamespace	Reference
/*     */     //   272	411	13	myNamespaces	Reference
/*     */     //   295	388	14	callable	Object
/*     */     //   376	307	17	writable	Object
/*     */     //   393	290	18	sw	Object
/*     */     //   467	216	19	element	org.w3c.dom.Element
/*     */     //   518	56	20	holder	org.springframework.beans.factory.config.BeanDefinitionHolder
/*     */     //   595	28	22	beanDefinition	Object
/*     */   }
/*     */   
/*     */   public final class _invokeMethod_closure1
/*     */     extends Closure
/*     */     implements GeneratedClosure
/*     */   {
/*     */     public _invokeMethod_closure1(Object _thisObject, Reference myNamespaces, Reference args, Reference builder, Reference myNamespace, Reference name)
/*     */     {
/*     */       super(_thisObject);
/*     */       Reference localReference1 = myNamespaces;
/*     */       this.myNamespaces = localReference1;
/*     */       Reference localReference2 = args;
/*     */       this.args = localReference2;
/*     */       Reference localReference3 = builder;
/*     */       this.builder = localReference3;
/*     */       Reference localReference4 = myNamespace;
/*     */       this.myNamespace = localReference4;
/*     */       Reference localReference5 = name;
/*     */       this.name = localReference5;
/*     */     }
/*     */     
/*     */     public Object doCall(Object it)
/*     */     {
/*  80 */       CallSite[] arrayOfCallSite = $getCallSiteArray();Object namespace = null; for (Iterator localIterator = (Iterator)ScriptBytecodeAdapter.castToType(arrayOfCallSite[0].call(this.myNamespaces.get()), Iterator.class); localIterator.hasNext();) { namespace = localIterator.next();
/*  81 */         arrayOfCallSite[1].call(arrayOfCallSite[2].callGroovyObjectGetProperty(this), ScriptBytecodeAdapter.createMap(new Object[] { arrayOfCallSite[3].callGetProperty(namespace), arrayOfCallSite[4].callGetProperty(namespace) })); }
/*     */       Object localObject2;
/*  83 */       if (((DefaultTypeTransformation.booleanUnbox(this.args.get())) && ((arrayOfCallSite[5].call(this.args.get(), Integer.valueOf(-1)) instanceof Closure)) ? 1 : 0) != 0) {
/*  84 */         Object localObject1 = arrayOfCallSite[6].callGetProperty(Closure.class);ScriptBytecodeAdapter.setProperty(localObject1, null, arrayOfCallSite[7].call(this.args.get(), Integer.valueOf(-1)), (String)"resolveStrategy");
/*  85 */         localObject2 = this.builder.get();ScriptBytecodeAdapter.setProperty(localObject2, null, arrayOfCallSite[8].call(this.args.get(), Integer.valueOf(-1)), (String)"delegate");
/*     */       }
/*  87 */       return ScriptBytecodeAdapter.invokeMethodN(_invokeMethod_closure1.class, ScriptBytecodeAdapter.getProperty(_invokeMethod_closure1.class, arrayOfCallSite[9].callGroovyObjectGetProperty(this), (String)ShortTypeHandling.castToString(new GStringImpl(new Object[] { this.myNamespace.get() }, new String[] { "", "" }))), (String)ShortTypeHandling.castToString(new GStringImpl(new Object[] { this.name.get() }, new String[] { "", "" })), ScriptBytecodeAdapter.despreadList(new Object[0], new Object[] { this.args.get() }, new int[] { 0 }));
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     @Generated
/*     */     public Object getMyNamespaces()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: nop
/*     */       //   1: invokestatic 29	org/springframework/beans/factory/groovy/GroovyDynamicElementReader$_invokeMethod_closure1:$getCallSiteArray	()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
/*     */       //   4: astore_1
/*     */       //   5: aload_0
/*     */       //   6: getfield 34	org/springframework/beans/factory/groovy/GroovyDynamicElementReader$_invokeMethod_closure1:myNamespaces	Lgroovy/lang/Reference;
/*     */       //   9: invokevirtual 56	groovy/lang/Reference:get	()Ljava/lang/Object;
/*     */       //   12: areturn
/*     */       //   13: nop
/*     */       //   14: athrow
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	13	0	this	_invokeMethod_closure1
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     @Generated
/*     */     public Object getArgs()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: nop
/*     */       //   1: invokestatic 29	org/springframework/beans/factory/groovy/GroovyDynamicElementReader$_invokeMethod_closure1:$getCallSiteArray	()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
/*     */       //   4: astore_1
/*     */       //   5: aload_0
/*     */       //   6: getfield 36	org/springframework/beans/factory/groovy/GroovyDynamicElementReader$_invokeMethod_closure1:args	Lgroovy/lang/Reference;
/*     */       //   9: invokevirtual 56	groovy/lang/Reference:get	()Ljava/lang/Object;
/*     */       //   12: areturn
/*     */       //   13: nop
/*     */       //   14: athrow
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	13	0	this	_invokeMethod_closure1
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     @Generated
/*     */     public groovy.xml.StreamingMarkupBuilder getBuilder()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: nop
/*     */       //   1: invokestatic 29	org/springframework/beans/factory/groovy/GroovyDynamicElementReader$_invokeMethod_closure1:$getCallSiteArray	()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
/*     */       //   4: astore_1
/*     */       //   5: aload_0
/*     */       //   6: getfield 38	org/springframework/beans/factory/groovy/GroovyDynamicElementReader$_invokeMethod_closure1:builder	Lgroovy/lang/Reference;
/*     */       //   9: invokevirtual 56	groovy/lang/Reference:get	()Ljava/lang/Object;
/*     */       //   12: ldc -96
/*     */       //   14: invokestatic 69	org/codehaus/groovy/runtime/ScriptBytecodeAdapter:castToType	(Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
/*     */       //   17: checkcast 160	groovy/xml/StreamingMarkupBuilder
/*     */       //   20: areturn
/*     */       //   21: nop
/*     */       //   22: athrow
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	21	0	this	_invokeMethod_closure1
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     @Generated
/*     */     public Object getMyNamespace()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: nop
/*     */       //   1: invokestatic 29	org/springframework/beans/factory/groovy/GroovyDynamicElementReader$_invokeMethod_closure1:$getCallSiteArray	()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
/*     */       //   4: astore_1
/*     */       //   5: aload_0
/*     */       //   6: getfield 40	org/springframework/beans/factory/groovy/GroovyDynamicElementReader$_invokeMethod_closure1:myNamespace	Lgroovy/lang/Reference;
/*     */       //   9: invokevirtual 56	groovy/lang/Reference:get	()Ljava/lang/Object;
/*     */       //   12: areturn
/*     */       //   13: nop
/*     */       //   14: athrow
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	13	0	this	_invokeMethod_closure1
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     @Generated
/*     */     public String getName()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: nop
/*     */       //   1: invokestatic 29	org/springframework/beans/factory/groovy/GroovyDynamicElementReader$_invokeMethod_closure1:$getCallSiteArray	()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
/*     */       //   4: astore_1
/*     */       //   5: aload_0
/*     */       //   6: getfield 42	org/springframework/beans/factory/groovy/GroovyDynamicElementReader$_invokeMethod_closure1:name	Lgroovy/lang/Reference;
/*     */       //   9: invokevirtual 56	groovy/lang/Reference:get	()Ljava/lang/Object;
/*     */       //   12: invokestatic 135	org/codehaus/groovy/runtime/typehandling/ShortTypeHandling:castToString	(Ljava/lang/Object;)Ljava/lang/String;
/*     */       //   15: checkcast 114	java/lang/String
/*     */       //   18: areturn
/*     */       //   19: nop
/*     */       //   20: athrow
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	19	0	this	_invokeMethod_closure1
/*     */     }
/*     */     
/*     */     @Generated
/*     */     public Object doCall()
/*     */     {
/*     */       CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */       return doCall(null);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void afterInvocation()
/*     */   {
/* 123 */     CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\groovy\GroovyDynamicElementReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */