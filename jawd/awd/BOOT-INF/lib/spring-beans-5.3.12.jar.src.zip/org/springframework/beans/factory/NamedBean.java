package org.springframework.beans.factory;

public abstract interface NamedBean
{
  public abstract String getBeanName();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\NamedBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */