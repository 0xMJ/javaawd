/*    */ package org.springframework.beans.factory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanCreationNotAllowedException
/*    */   extends BeanCreationException
/*    */ {
/*    */   public BeanCreationNotAllowedException(String beanName, String msg)
/*    */   {
/* 36 */     super(beanName, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\BeanCreationNotAllowedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */