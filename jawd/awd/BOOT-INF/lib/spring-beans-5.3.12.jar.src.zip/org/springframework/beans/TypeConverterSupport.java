/*    */ package org.springframework.beans;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.core.convert.ConversionException;
/*    */ import org.springframework.core.convert.ConverterNotFoundException;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TypeConverterSupport
/*    */   extends PropertyEditorRegistrySupport
/*    */   implements TypeConverter
/*    */ {
/*    */   @Nullable
/*    */   TypeConverterDelegate typeConverterDelegate;
/*    */   
/*    */   @Nullable
/*    */   public <T> T convertIfNecessary(@Nullable Object value, @Nullable Class<T> requiredType)
/*    */     throws TypeMismatchException
/*    */   {
/* 45 */     return (T)convertIfNecessary(value, requiredType, TypeDescriptor.valueOf(requiredType));
/*    */   }
/*    */   
/*    */ 
/*    */   @Nullable
/*    */   public <T> T convertIfNecessary(@Nullable Object value, @Nullable Class<T> requiredType, @Nullable MethodParameter methodParam)
/*    */     throws TypeMismatchException
/*    */   {
/* 53 */     return (T)convertIfNecessary(value, requiredType, methodParam != null ? new TypeDescriptor(methodParam) : 
/* 54 */       TypeDescriptor.valueOf(requiredType));
/*    */   }
/*    */   
/*    */ 
/*    */   @Nullable
/*    */   public <T> T convertIfNecessary(@Nullable Object value, @Nullable Class<T> requiredType, @Nullable Field field)
/*    */     throws TypeMismatchException
/*    */   {
/* 62 */     return (T)convertIfNecessary(value, requiredType, field != null ? new TypeDescriptor(field) : 
/* 63 */       TypeDescriptor.valueOf(requiredType));
/*    */   }
/*    */   
/*    */ 
/*    */   @Nullable
/*    */   public <T> T convertIfNecessary(@Nullable Object value, @Nullable Class<T> requiredType, @Nullable TypeDescriptor typeDescriptor)
/*    */     throws TypeMismatchException
/*    */   {
/* 71 */     Assert.state(this.typeConverterDelegate != null, "No TypeConverterDelegate");
/*    */     try {
/* 73 */       return (T)this.typeConverterDelegate.convertIfNecessary(null, null, value, requiredType, typeDescriptor);
/*    */     }
/*    */     catch (ConverterNotFoundException|IllegalStateException ex) {
/* 76 */       throw new ConversionNotSupportedException(value, requiredType, ex);
/*    */     }
/*    */     catch (ConversionException|IllegalArgumentException ex) {
/* 79 */       throw new TypeMismatchException(value, requiredType, ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\TypeConverterSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */