package org.springframework.beans.support;

public abstract interface SortDefinition
{
  public abstract String getProperty();
  
  public abstract boolean isIgnoreCase();
  
  public abstract boolean isAscending();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\support\SortDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */