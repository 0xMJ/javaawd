package org.springframework.beans.factory.xml;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.lang.Nullable;
import org.w3c.dom.Element;

public abstract interface BeanDefinitionParser
{
  @Nullable
  public abstract BeanDefinition parse(Element paramElement, ParserContext paramParserContext);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\xml\BeanDefinitionParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */