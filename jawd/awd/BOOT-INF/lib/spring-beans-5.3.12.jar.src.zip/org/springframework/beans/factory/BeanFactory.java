package org.springframework.beans.factory;

import org.springframework.beans.BeansException;
import org.springframework.core.ResolvableType;
import org.springframework.lang.Nullable;

public abstract interface BeanFactory
{
  public static final String FACTORY_BEAN_PREFIX = "&";
  
  public abstract Object getBean(String paramString)
    throws BeansException;
  
  public abstract <T> T getBean(String paramString, Class<T> paramClass)
    throws BeansException;
  
  public abstract Object getBean(String paramString, Object... paramVarArgs)
    throws BeansException;
  
  public abstract <T> T getBean(Class<T> paramClass)
    throws BeansException;
  
  public abstract <T> T getBean(Class<T> paramClass, Object... paramVarArgs)
    throws BeansException;
  
  public abstract <T> ObjectProvider<T> getBeanProvider(Class<T> paramClass);
  
  public abstract <T> ObjectProvider<T> getBeanProvider(ResolvableType paramResolvableType);
  
  public abstract boolean containsBean(String paramString);
  
  public abstract boolean isSingleton(String paramString)
    throws NoSuchBeanDefinitionException;
  
  public abstract boolean isPrototype(String paramString)
    throws NoSuchBeanDefinitionException;
  
  public abstract boolean isTypeMatch(String paramString, ResolvableType paramResolvableType)
    throws NoSuchBeanDefinitionException;
  
  public abstract boolean isTypeMatch(String paramString, Class<?> paramClass)
    throws NoSuchBeanDefinitionException;
  
  @Nullable
  public abstract Class<?> getType(String paramString)
    throws NoSuchBeanDefinitionException;
  
  @Nullable
  public abstract Class<?> getType(String paramString, boolean paramBoolean)
    throws NoSuchBeanDefinitionException;
  
  public abstract String[] getAliases(String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\BeanFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */