/*    */ package org.springframework.beans.factory.support;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ImplicitlyAppearedSingletonException
/*    */   extends IllegalStateException
/*    */ {
/*    */   public ImplicitlyAppearedSingletonException()
/*    */   {
/* 31 */     super("About-to-be-created singleton instance implicitly appeared through the creation of the factory bean that its bean definition points to");
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\support\ImplicitlyAppearedSingletonException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */