/*     */ package org.springframework.beans.factory.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.parsing.EmptyReaderEventListener;
/*     */ import org.springframework.beans.factory.parsing.FailFastProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.NullSourceExtractor;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.ReaderEventListener;
/*     */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ import org.springframework.core.io.DescriptiveResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.EncodedResource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.xml.SimpleSaxErrorHandler;
/*     */ import org.springframework.util.xml.XmlValidationModeDetector;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlBeanDefinitionReader
/*     */   extends AbstractBeanDefinitionReader
/*     */ {
/*     */   public static final int VALIDATION_NONE = 0;
/*     */   public static final int VALIDATION_AUTO = 1;
/*     */   public static final int VALIDATION_DTD = 2;
/*     */   public static final int VALIDATION_XSD = 3;
/* 103 */   private static final Constants constants = new Constants(XmlBeanDefinitionReader.class);
/*     */   
/* 105 */   private int validationMode = 1;
/*     */   
/* 107 */   private boolean namespaceAware = false;
/*     */   
/* 109 */   private Class<? extends BeanDefinitionDocumentReader> documentReaderClass = DefaultBeanDefinitionDocumentReader.class;
/*     */   
/*     */ 
/* 112 */   private ProblemReporter problemReporter = new FailFastProblemReporter();
/*     */   
/* 114 */   private ReaderEventListener eventListener = new EmptyReaderEventListener();
/*     */   
/* 116 */   private SourceExtractor sourceExtractor = new NullSourceExtractor();
/*     */   
/*     */   @Nullable
/*     */   private NamespaceHandlerResolver namespaceHandlerResolver;
/*     */   
/* 121 */   private DocumentLoader documentLoader = new DefaultDocumentLoader();
/*     */   
/*     */   @Nullable
/*     */   private EntityResolver entityResolver;
/*     */   
/* 126 */   private ErrorHandler errorHandler = new SimpleSaxErrorHandler(this.logger);
/*     */   
/* 128 */   private final XmlValidationModeDetector validationModeDetector = new XmlValidationModeDetector();
/*     */   
/* 130 */   private final ThreadLocal<Set<EncodedResource>> resourcesCurrentlyBeingLoaded = new NamedThreadLocal("XML bean definition resources currently being loaded")
/*     */   {
/*     */     protected Set<EncodedResource> initialValue()
/*     */     {
/* 134 */       return new HashSet(4);
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XmlBeanDefinitionReader(BeanDefinitionRegistry registry)
/*     */   {
/* 145 */     super(registry);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidating(boolean validating)
/*     */   {
/* 157 */     this.validationMode = (validating ? 1 : 0);
/* 158 */     this.namespaceAware = (!validating);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidationModeName(String validationModeName)
/*     */   {
/* 166 */     setValidationMode(constants.asNumber(validationModeName).intValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidationMode(int validationMode)
/*     */   {
/* 176 */     this.validationMode = validationMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getValidationMode()
/*     */   {
/* 183 */     return this.validationMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNamespaceAware(boolean namespaceAware)
/*     */   {
/* 194 */     this.namespaceAware = namespaceAware;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isNamespaceAware()
/*     */   {
/* 201 */     return this.namespaceAware;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProblemReporter(@Nullable ProblemReporter problemReporter)
/*     */   {
/* 211 */     this.problemReporter = (problemReporter != null ? problemReporter : new FailFastProblemReporter());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEventListener(@Nullable ReaderEventListener eventListener)
/*     */   {
/* 221 */     this.eventListener = (eventListener != null ? eventListener : new EmptyReaderEventListener());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSourceExtractor(@Nullable SourceExtractor sourceExtractor)
/*     */   {
/* 231 */     this.sourceExtractor = (sourceExtractor != null ? sourceExtractor : new NullSourceExtractor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNamespaceHandlerResolver(@Nullable NamespaceHandlerResolver namespaceHandlerResolver)
/*     */   {
/* 240 */     this.namespaceHandlerResolver = namespaceHandlerResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDocumentLoader(@Nullable DocumentLoader documentLoader)
/*     */   {
/* 249 */     this.documentLoader = (documentLoader != null ? documentLoader : new DefaultDocumentLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEntityResolver(@Nullable EntityResolver entityResolver)
/*     */   {
/* 258 */     this.entityResolver = entityResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected EntityResolver getEntityResolver()
/*     */   {
/* 266 */     if (this.entityResolver == null)
/*     */     {
/* 268 */       ResourceLoader resourceLoader = getResourceLoader();
/* 269 */       if (resourceLoader != null) {
/* 270 */         this.entityResolver = new ResourceEntityResolver(resourceLoader);
/*     */       }
/*     */       else {
/* 273 */         this.entityResolver = new DelegatingEntityResolver(getBeanClassLoader());
/*     */       }
/*     */     }
/* 276 */     return this.entityResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setErrorHandler(ErrorHandler errorHandler)
/*     */   {
/* 288 */     this.errorHandler = errorHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDocumentReaderClass(Class<? extends BeanDefinitionDocumentReader> documentReaderClass)
/*     */   {
/* 298 */     this.documentReaderClass = documentReaderClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int loadBeanDefinitions(Resource resource)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 310 */     return loadBeanDefinitions(new EncodedResource(resource));
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int loadBeanDefinitions(EncodedResource encodedResource)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 45
/*     */     //   3: invokestatic 46	org/springframework/util/Assert:notNull	(Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: aload_0
/*     */     //   7: getfield 21	org/springframework/beans/factory/xml/XmlBeanDefinitionReader:logger	Lorg/apache/commons/logging/Log;
/*     */     //   10: invokeinterface 47 1 0
/*     */     //   15: ifeq +31 -> 46
/*     */     //   18: aload_0
/*     */     //   19: getfield 21	org/springframework/beans/factory/xml/XmlBeanDefinitionReader:logger	Lorg/apache/commons/logging/Log;
/*     */     //   22: new 48	java/lang/StringBuilder
/*     */     //   25: dup
/*     */     //   26: invokespecial 49	java/lang/StringBuilder:<init>	()V
/*     */     //   29: ldc 50
/*     */     //   31: invokevirtual 51	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   34: aload_1
/*     */     //   35: invokevirtual 52	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   38: invokevirtual 53	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   41: invokeinterface 54 2 0
/*     */     //   46: aload_0
/*     */     //   47: getfield 29	org/springframework/beans/factory/xml/XmlBeanDefinitionReader:resourcesCurrentlyBeingLoaded	Ljava/lang/ThreadLocal;
/*     */     //   50: invokevirtual 55	java/lang/ThreadLocal:get	()Ljava/lang/Object;
/*     */     //   53: checkcast 56	java/util/Set
/*     */     //   56: astore_2
/*     */     //   57: aload_2
/*     */     //   58: aload_1
/*     */     //   59: invokeinterface 57 2 0
/*     */     //   64: ifne +35 -> 99
/*     */     //   67: new 58	org/springframework/beans/factory/BeanDefinitionStoreException
/*     */     //   70: dup
/*     */     //   71: new 48	java/lang/StringBuilder
/*     */     //   74: dup
/*     */     //   75: invokespecial 49	java/lang/StringBuilder:<init>	()V
/*     */     //   78: ldc 59
/*     */     //   80: invokevirtual 51	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   83: aload_1
/*     */     //   84: invokevirtual 52	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   87: ldc 60
/*     */     //   89: invokevirtual 51	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   92: invokevirtual 53	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   95: invokespecial 61	org/springframework/beans/factory/BeanDefinitionStoreException:<init>	(Ljava/lang/String;)V
/*     */     //   98: athrow
/*     */     //   99: aload_1
/*     */     //   100: invokevirtual 62	org/springframework/core/io/support/EncodedResource:getResource	()Lorg/springframework/core/io/Resource;
/*     */     //   103: invokeinterface 63 1 0
/*     */     //   108: astore_3
/*     */     //   109: aconst_null
/*     */     //   110: astore 4
/*     */     //   112: new 64	org/xml/sax/InputSource
/*     */     //   115: dup
/*     */     //   116: aload_3
/*     */     //   117: invokespecial 65	org/xml/sax/InputSource:<init>	(Ljava/io/InputStream;)V
/*     */     //   120: astore 5
/*     */     //   122: aload_1
/*     */     //   123: invokevirtual 66	org/springframework/core/io/support/EncodedResource:getEncoding	()Ljava/lang/String;
/*     */     //   126: ifnull +12 -> 138
/*     */     //   129: aload 5
/*     */     //   131: aload_1
/*     */     //   132: invokevirtual 66	org/springframework/core/io/support/EncodedResource:getEncoding	()Ljava/lang/String;
/*     */     //   135: invokevirtual 67	org/xml/sax/InputSource:setEncoding	(Ljava/lang/String;)V
/*     */     //   138: aload_0
/*     */     //   139: aload 5
/*     */     //   141: aload_1
/*     */     //   142: invokevirtual 62	org/springframework/core/io/support/EncodedResource:getResource	()Lorg/springframework/core/io/Resource;
/*     */     //   145: invokevirtual 68	org/springframework/beans/factory/xml/XmlBeanDefinitionReader:doLoadBeanDefinitions	(Lorg/xml/sax/InputSource;Lorg/springframework/core/io/Resource;)I
/*     */     //   148: istore 6
/*     */     //   150: aload_3
/*     */     //   151: ifnull +31 -> 182
/*     */     //   154: aload 4
/*     */     //   156: ifnull +22 -> 178
/*     */     //   159: aload_3
/*     */     //   160: invokevirtual 69	java/io/InputStream:close	()V
/*     */     //   163: goto +19 -> 182
/*     */     //   166: astore 7
/*     */     //   168: aload 4
/*     */     //   170: aload 7
/*     */     //   172: invokevirtual 71	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   175: goto +7 -> 182
/*     */     //   178: aload_3
/*     */     //   179: invokevirtual 69	java/io/InputStream:close	()V
/*     */     //   182: aload_2
/*     */     //   183: aload_1
/*     */     //   184: invokeinterface 72 2 0
/*     */     //   189: pop
/*     */     //   190: aload_2
/*     */     //   191: invokeinterface 73 1 0
/*     */     //   196: ifeq +10 -> 206
/*     */     //   199: aload_0
/*     */     //   200: getfield 29	org/springframework/beans/factory/xml/XmlBeanDefinitionReader:resourcesCurrentlyBeingLoaded	Ljava/lang/ThreadLocal;
/*     */     //   203: invokevirtual 74	java/lang/ThreadLocal:remove	()V
/*     */     //   206: iload 6
/*     */     //   208: ireturn
/*     */     //   209: astore 5
/*     */     //   211: aload 5
/*     */     //   213: astore 4
/*     */     //   215: aload 5
/*     */     //   217: athrow
/*     */     //   218: astore 8
/*     */     //   220: aload_3
/*     */     //   221: ifnull +31 -> 252
/*     */     //   224: aload 4
/*     */     //   226: ifnull +22 -> 248
/*     */     //   229: aload_3
/*     */     //   230: invokevirtual 69	java/io/InputStream:close	()V
/*     */     //   233: goto +19 -> 252
/*     */     //   236: astore 9
/*     */     //   238: aload 4
/*     */     //   240: aload 9
/*     */     //   242: invokevirtual 71	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   245: goto +7 -> 252
/*     */     //   248: aload_3
/*     */     //   249: invokevirtual 69	java/io/InputStream:close	()V
/*     */     //   252: aload 8
/*     */     //   254: athrow
/*     */     //   255: astore_3
/*     */     //   256: new 58	org/springframework/beans/factory/BeanDefinitionStoreException
/*     */     //   259: dup
/*     */     //   260: new 48	java/lang/StringBuilder
/*     */     //   263: dup
/*     */     //   264: invokespecial 49	java/lang/StringBuilder:<init>	()V
/*     */     //   267: ldc 76
/*     */     //   269: invokevirtual 51	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   272: aload_1
/*     */     //   273: invokevirtual 62	org/springframework/core/io/support/EncodedResource:getResource	()Lorg/springframework/core/io/Resource;
/*     */     //   276: invokevirtual 52	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   279: invokevirtual 53	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   282: aload_3
/*     */     //   283: invokespecial 77	org/springframework/beans/factory/BeanDefinitionStoreException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   286: athrow
/*     */     //   287: astore 10
/*     */     //   289: aload_2
/*     */     //   290: aload_1
/*     */     //   291: invokeinterface 72 2 0
/*     */     //   296: pop
/*     */     //   297: aload_2
/*     */     //   298: invokeinterface 73 1 0
/*     */     //   303: ifeq +10 -> 313
/*     */     //   306: aload_0
/*     */     //   307: getfield 29	org/springframework/beans/factory/xml/XmlBeanDefinitionReader:resourcesCurrentlyBeingLoaded	Ljava/lang/ThreadLocal;
/*     */     //   310: invokevirtual 74	java/lang/ThreadLocal:remove	()V
/*     */     //   313: aload 10
/*     */     //   315: athrow
/*     */     // Line number table:
/*     */     //   Java source line #321	-> byte code offset #0
/*     */     //   Java source line #322	-> byte code offset #6
/*     */     //   Java source line #323	-> byte code offset #18
/*     */     //   Java source line #326	-> byte code offset #46
/*     */     //   Java source line #328	-> byte code offset #57
/*     */     //   Java source line #329	-> byte code offset #67
/*     */     //   Java source line #333	-> byte code offset #99
/*     */     //   Java source line #334	-> byte code offset #112
/*     */     //   Java source line #335	-> byte code offset #122
/*     */     //   Java source line #336	-> byte code offset #129
/*     */     //   Java source line #338	-> byte code offset #138
/*     */     //   Java source line #339	-> byte code offset #150
/*     */     //   Java source line #345	-> byte code offset #182
/*     */     //   Java source line #346	-> byte code offset #190
/*     */     //   Java source line #347	-> byte code offset #199
/*     */     //   Java source line #338	-> byte code offset #206
/*     */     //   Java source line #333	-> byte code offset #209
/*     */     //   Java source line #339	-> byte code offset #218
/*     */     //   Java source line #340	-> byte code offset #255
/*     */     //   Java source line #341	-> byte code offset #256
/*     */     //   Java source line #342	-> byte code offset #273
/*     */     //   Java source line #345	-> byte code offset #287
/*     */     //   Java source line #346	-> byte code offset #297
/*     */     //   Java source line #347	-> byte code offset #306
/*     */     //   Java source line #349	-> byte code offset #313
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	316	0	this	XmlBeanDefinitionReader
/*     */     //   0	316	1	encodedResource	EncodedResource
/*     */     //   56	242	2	currentResources	Set<EncodedResource>
/*     */     //   108	141	3	inputStream	InputStream
/*     */     //   255	28	3	ex	IOException
/*     */     //   110	129	4	localThrowable3	Throwable
/*     */     //   120	20	5	inputSource	InputSource
/*     */     //   209	7	5	localThrowable1	Throwable
/*     */     //   148	59	6	i	int
/*     */     //   166	5	7	localThrowable	Throwable
/*     */     //   218	35	8	localObject1	Object
/*     */     //   236	5	9	localThrowable2	Throwable
/*     */     //   287	27	10	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   159	163	166	java/lang/Throwable
/*     */     //   112	150	209	java/lang/Throwable
/*     */     //   112	150	218	finally
/*     */     //   209	220	218	finally
/*     */     //   229	233	236	java/lang/Throwable
/*     */     //   99	182	255	java/io/IOException
/*     */     //   209	255	255	java/io/IOException
/*     */     //   99	182	287	finally
/*     */     //   209	289	287	finally
/*     */   }
/*     */   
/*     */   public int loadBeanDefinitions(InputSource inputSource)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 359 */     return loadBeanDefinitions(inputSource, "resource loaded through SAX InputSource");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int loadBeanDefinitions(InputSource inputSource, @Nullable String resourceDescription)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 373 */     return doLoadBeanDefinitions(inputSource, new DescriptiveResource(resourceDescription));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int doLoadBeanDefinitions(InputSource inputSource, Resource resource)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/*     */     try
/*     */     {
/* 390 */       Document doc = doLoadDocument(inputSource, resource);
/* 391 */       int count = registerBeanDefinitions(doc, resource);
/* 392 */       if (this.logger.isDebugEnabled()) {
/* 393 */         this.logger.debug("Loaded " + count + " bean definitions from " + resource);
/*     */       }
/* 395 */       return count;
/*     */     }
/*     */     catch (BeanDefinitionStoreException ex) {
/* 398 */       throw ex;
/*     */     }
/*     */     catch (SAXParseException ex)
/*     */     {
/* 402 */       throw new XmlBeanDefinitionStoreException(resource.getDescription(), "Line " + ex.getLineNumber() + " in XML document from " + resource + " is invalid", ex);
/*     */     }
/*     */     catch (SAXException ex) {
/* 405 */       throw new XmlBeanDefinitionStoreException(resource.getDescription(), "XML document from " + resource + " is invalid", ex);
/*     */     }
/*     */     catch (ParserConfigurationException ex)
/*     */     {
/* 409 */       throw new BeanDefinitionStoreException(resource.getDescription(), "Parser configuration exception parsing XML from " + resource, ex);
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 413 */       throw new BeanDefinitionStoreException(resource.getDescription(), "IOException parsing XML document from " + resource, ex);
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 417 */       throw new BeanDefinitionStoreException(resource.getDescription(), "Unexpected exception parsing XML document from " + resource, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Document doLoadDocument(InputSource inputSource, Resource resource)
/*     */     throws Exception
/*     */   {
/* 432 */     return this.documentLoader.loadDocument(inputSource, getEntityResolver(), this.errorHandler, 
/* 433 */       getValidationModeForResource(resource), isNamespaceAware());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getValidationModeForResource(Resource resource)
/*     */   {
/* 445 */     int validationModeToUse = getValidationMode();
/* 446 */     if (validationModeToUse != 1) {
/* 447 */       return validationModeToUse;
/*     */     }
/* 449 */     int detectedMode = detectValidationMode(resource);
/* 450 */     if (detectedMode != 1) {
/* 451 */       return detectedMode;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 456 */     return 3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int detectValidationMode(Resource resource)
/*     */   {
/* 467 */     if (resource.isOpen()) {
/* 468 */       throw new BeanDefinitionStoreException("Passed-in Resource [" + resource + "] contains an open stream: cannot determine validation mode automatically. Either pass in a Resource that is able to create fresh streams, or explicitly specify the validationMode on your XmlBeanDefinitionReader instance.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 477 */       inputStream = resource.getInputStream();
/*     */     } catch (IOException ex) {
/*     */       InputStream inputStream;
/* 480 */       throw new BeanDefinitionStoreException("Unable to determine validation mode for [" + resource + "]: cannot open InputStream. Did you attempt to load directly from a SAX InputSource without specifying the validationMode on your XmlBeanDefinitionReader instance?", ex);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*     */       InputStream inputStream;
/*     */       
/* 487 */       return this.validationModeDetector.detectValidationMode(inputStream);
/*     */     }
/*     */     catch (IOException ex) {
/* 490 */       throw new BeanDefinitionStoreException("Unable to determine validation mode for [" + resource + "]: an error occurred whilst reading from the InputStream.", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int registerBeanDefinitions(Document doc, Resource resource)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 509 */     BeanDefinitionDocumentReader documentReader = createBeanDefinitionDocumentReader();
/* 510 */     int countBefore = getRegistry().getBeanDefinitionCount();
/* 511 */     documentReader.registerBeanDefinitions(doc, createReaderContext(resource));
/* 512 */     return getRegistry().getBeanDefinitionCount() - countBefore;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BeanDefinitionDocumentReader createBeanDefinitionDocumentReader()
/*     */   {
/* 522 */     return (BeanDefinitionDocumentReader)BeanUtils.instantiateClass(this.documentReaderClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public XmlReaderContext createReaderContext(Resource resource)
/*     */   {
/* 529 */     return new XmlReaderContext(resource, this.problemReporter, this.eventListener, this.sourceExtractor, this, 
/* 530 */       getNamespaceHandlerResolver());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamespaceHandlerResolver getNamespaceHandlerResolver()
/*     */   {
/* 538 */     if (this.namespaceHandlerResolver == null) {
/* 539 */       this.namespaceHandlerResolver = createDefaultNamespaceHandlerResolver();
/*     */     }
/* 541 */     return this.namespaceHandlerResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected NamespaceHandlerResolver createDefaultNamespaceHandlerResolver()
/*     */   {
/* 550 */     ClassLoader cl = getResourceLoader() != null ? getResourceLoader().getClassLoader() : getBeanClassLoader();
/* 551 */     return new DefaultNamespaceHandlerResolver(cl);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\xml\XmlBeanDefinitionReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */