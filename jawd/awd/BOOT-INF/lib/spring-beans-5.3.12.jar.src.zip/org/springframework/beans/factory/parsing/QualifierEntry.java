/*    */ package org.springframework.beans.factory.parsing;
/*    */ 
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QualifierEntry
/*    */   implements ParseState.Entry
/*    */ {
/*    */   private final String typeName;
/*    */   
/*    */   public QualifierEntry(String typeName)
/*    */   {
/* 37 */     if (!StringUtils.hasText(typeName)) {
/* 38 */       throw new IllegalArgumentException("Invalid qualifier type '" + typeName + "'");
/*    */     }
/* 40 */     this.typeName = typeName;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 46 */     return "Qualifier '" + this.typeName + "'";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\parsing\QualifierEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */