package org.springframework.beans.factory.config;

import org.springframework.beans.BeansException;
import org.springframework.lang.Nullable;

public abstract interface BeanExpressionResolver
{
  @Nullable
  public abstract Object evaluate(@Nullable String paramString, BeanExpressionContext paramBeanExpressionContext)
    throws BeansException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\config\BeanExpressionResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */