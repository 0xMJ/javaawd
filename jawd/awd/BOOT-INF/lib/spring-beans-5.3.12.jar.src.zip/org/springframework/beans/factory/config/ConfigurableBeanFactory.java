package org.springframework.beans.factory.config;

import java.beans.PropertyEditor;
import java.security.AccessControlContext;
import org.springframework.beans.PropertyEditorRegistrar;
import org.springframework.beans.PropertyEditorRegistry;
import org.springframework.beans.TypeConverter;
import org.springframework.beans.factory.BeanDefinitionStoreException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.HierarchicalBeanFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.metrics.ApplicationStartup;
import org.springframework.lang.Nullable;
import org.springframework.util.StringValueResolver;

public abstract interface ConfigurableBeanFactory
  extends HierarchicalBeanFactory, SingletonBeanRegistry
{
  public static final String SCOPE_SINGLETON = "singleton";
  public static final String SCOPE_PROTOTYPE = "prototype";
  
  public abstract void setParentBeanFactory(BeanFactory paramBeanFactory)
    throws IllegalStateException;
  
  public abstract void setBeanClassLoader(@Nullable ClassLoader paramClassLoader);
  
  @Nullable
  public abstract ClassLoader getBeanClassLoader();
  
  public abstract void setTempClassLoader(@Nullable ClassLoader paramClassLoader);
  
  @Nullable
  public abstract ClassLoader getTempClassLoader();
  
  public abstract void setCacheBeanMetadata(boolean paramBoolean);
  
  public abstract boolean isCacheBeanMetadata();
  
  public abstract void setBeanExpressionResolver(@Nullable BeanExpressionResolver paramBeanExpressionResolver);
  
  @Nullable
  public abstract BeanExpressionResolver getBeanExpressionResolver();
  
  public abstract void setConversionService(@Nullable ConversionService paramConversionService);
  
  @Nullable
  public abstract ConversionService getConversionService();
  
  public abstract void addPropertyEditorRegistrar(PropertyEditorRegistrar paramPropertyEditorRegistrar);
  
  public abstract void registerCustomEditor(Class<?> paramClass, Class<? extends PropertyEditor> paramClass1);
  
  public abstract void copyRegisteredEditorsTo(PropertyEditorRegistry paramPropertyEditorRegistry);
  
  public abstract void setTypeConverter(TypeConverter paramTypeConverter);
  
  public abstract TypeConverter getTypeConverter();
  
  public abstract void addEmbeddedValueResolver(StringValueResolver paramStringValueResolver);
  
  public abstract boolean hasEmbeddedValueResolver();
  
  @Nullable
  public abstract String resolveEmbeddedValue(String paramString);
  
  public abstract void addBeanPostProcessor(BeanPostProcessor paramBeanPostProcessor);
  
  public abstract int getBeanPostProcessorCount();
  
  public abstract void registerScope(String paramString, Scope paramScope);
  
  public abstract String[] getRegisteredScopeNames();
  
  @Nullable
  public abstract Scope getRegisteredScope(String paramString);
  
  public abstract void setApplicationStartup(ApplicationStartup paramApplicationStartup);
  
  public abstract ApplicationStartup getApplicationStartup();
  
  public abstract AccessControlContext getAccessControlContext();
  
  public abstract void copyConfigurationFrom(ConfigurableBeanFactory paramConfigurableBeanFactory);
  
  public abstract void registerAlias(String paramString1, String paramString2)
    throws BeanDefinitionStoreException;
  
  public abstract void resolveAliases(StringValueResolver paramStringValueResolver);
  
  public abstract BeanDefinition getMergedBeanDefinition(String paramString)
    throws NoSuchBeanDefinitionException;
  
  public abstract boolean isFactoryBean(String paramString)
    throws NoSuchBeanDefinitionException;
  
  public abstract void setCurrentlyInCreation(String paramString, boolean paramBoolean);
  
  public abstract boolean isCurrentlyInCreation(String paramString);
  
  public abstract void registerDependentBean(String paramString1, String paramString2);
  
  public abstract String[] getDependentBeans(String paramString);
  
  public abstract String[] getDependenciesForBean(String paramString);
  
  public abstract void destroyBean(String paramString, Object paramObject);
  
  public abstract void destroyScopedBean(String paramString);
  
  public abstract void destroySingletons();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\config\ConfigurableBeanFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */