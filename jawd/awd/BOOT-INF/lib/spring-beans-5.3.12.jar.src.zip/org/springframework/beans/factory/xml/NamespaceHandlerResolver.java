package org.springframework.beans.factory.xml;

import org.springframework.lang.Nullable;

@FunctionalInterface
public abstract interface NamespaceHandlerResolver
{
  @Nullable
  public abstract NamespaceHandler resolve(String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\xml\NamespaceHandlerResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */