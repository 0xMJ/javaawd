/*    */ package org.springframework.beans.factory.support;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ManagedArray
/*    */   extends ManagedList<Object>
/*    */ {
/*    */   @Nullable
/*    */   volatile Class<?> resolvedElementType;
/*    */   
/*    */   public ManagedArray(String elementTypeName, int size)
/*    */   {
/* 43 */     super(size);
/* 44 */     Assert.notNull(elementTypeName, "elementTypeName must not be null");
/* 45 */     setElementTypeName(elementTypeName);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\support\ManagedArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */