/*    */ package org.springframework.beans.factory.serviceloader;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.ServiceLoader;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServiceFactoryBean
/*    */   extends AbstractServiceLoaderBasedFactoryBean
/*    */   implements BeanClassLoaderAware
/*    */ {
/*    */   protected Object getObjectToExpose(ServiceLoader<?> serviceLoader)
/*    */   {
/* 38 */     Iterator<?> it = serviceLoader.iterator();
/* 39 */     if (!it.hasNext())
/*    */     {
/* 41 */       throw new IllegalStateException("ServiceLoader could not find service for type [" + getServiceType() + "]");
/*    */     }
/* 43 */     return it.next();
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Class<?> getObjectType()
/*    */   {
/* 49 */     return getServiceType();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\serviceloader\ServiceFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */