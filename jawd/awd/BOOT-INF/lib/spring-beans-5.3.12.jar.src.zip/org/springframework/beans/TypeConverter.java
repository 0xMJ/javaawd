/*     */ package org.springframework.beans;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface TypeConverter
/*     */ {
/*     */   @Nullable
/*     */   public abstract <T> T convertIfNecessary(@Nullable Object paramObject, @Nullable Class<T> paramClass)
/*     */     throws TypeMismatchException;
/*     */   
/*     */   @Nullable
/*     */   public abstract <T> T convertIfNecessary(@Nullable Object paramObject, @Nullable Class<T> paramClass, @Nullable MethodParameter paramMethodParameter)
/*     */     throws TypeMismatchException;
/*     */   
/*     */   @Nullable
/*     */   public abstract <T> T convertIfNecessary(@Nullable Object paramObject, @Nullable Class<T> paramClass, @Nullable Field paramField)
/*     */     throws TypeMismatchException;
/*     */   
/*     */   @Nullable
/*     */   public <T> T convertIfNecessary(@Nullable Object value, @Nullable Class<T> requiredType, @Nullable TypeDescriptor typeDescriptor)
/*     */     throws TypeMismatchException
/*     */   {
/* 117 */     throw new UnsupportedOperationException("TypeDescriptor resolution not supported");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\TypeConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */