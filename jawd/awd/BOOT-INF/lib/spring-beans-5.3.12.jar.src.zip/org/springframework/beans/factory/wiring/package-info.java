package org.springframework.beans.factory.wiring;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;

@NonNullApi
@NonNullFields
abstract interface package-info {}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\wiring\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */