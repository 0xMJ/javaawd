/*    */ package org.springframework.beans.factory.support;
/*    */ 
/*    */ import org.springframework.beans.FatalBeanException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanDefinitionValidationException
/*    */   extends FatalBeanException
/*    */ {
/*    */   public BeanDefinitionValidationException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public BeanDefinitionValidationException(String msg, Throwable cause)
/*    */   {
/* 46 */     super(msg, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\support\BeanDefinitionValidationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */