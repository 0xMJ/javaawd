package org.springframework.beans.factory.config;

import org.springframework.beans.BeansException;

@FunctionalInterface
public abstract interface BeanFactoryPostProcessor
{
  public abstract void postProcessBeanFactory(ConfigurableListableBeanFactory paramConfigurableListableBeanFactory)
    throws BeansException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\config\BeanFactoryPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */