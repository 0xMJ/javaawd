/*     */ package org.springframework.beans.factory.config;
/*     */ 
/*     */ import org.springframework.beans.BeanMetadataElement;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.core.AttributeAccessor;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface BeanDefinition
/*     */   extends AttributeAccessor, BeanMetadataElement
/*     */ {
/*     */   public static final String SCOPE_SINGLETON = "singleton";
/*     */   public static final String SCOPE_PROTOTYPE = "prototype";
/*     */   public static final int ROLE_APPLICATION = 0;
/*     */   public static final int ROLE_SUPPORT = 1;
/*     */   public static final int ROLE_INFRASTRUCTURE = 2;
/*     */   
/*     */   public abstract void setParentName(@Nullable String paramString);
/*     */   
/*     */   @Nullable
/*     */   public abstract String getParentName();
/*     */   
/*     */   public abstract void setBeanClassName(@Nullable String paramString);
/*     */   
/*     */   @Nullable
/*     */   public abstract String getBeanClassName();
/*     */   
/*     */   public abstract void setScope(@Nullable String paramString);
/*     */   
/*     */   @Nullable
/*     */   public abstract String getScope();
/*     */   
/*     */   public abstract void setLazyInit(boolean paramBoolean);
/*     */   
/*     */   public abstract boolean isLazyInit();
/*     */   
/*     */   public abstract void setDependsOn(@Nullable String... paramVarArgs);
/*     */   
/*     */   @Nullable
/*     */   public abstract String[] getDependsOn();
/*     */   
/*     */   public abstract void setAutowireCandidate(boolean paramBoolean);
/*     */   
/*     */   public abstract boolean isAutowireCandidate();
/*     */   
/*     */   public abstract void setPrimary(boolean paramBoolean);
/*     */   
/*     */   public abstract boolean isPrimary();
/*     */   
/*     */   public abstract void setFactoryBeanName(@Nullable String paramString);
/*     */   
/*     */   @Nullable
/*     */   public abstract String getFactoryBeanName();
/*     */   
/*     */   public abstract void setFactoryMethodName(@Nullable String paramString);
/*     */   
/*     */   @Nullable
/*     */   public abstract String getFactoryMethodName();
/*     */   
/*     */   public abstract ConstructorArgumentValues getConstructorArgumentValues();
/*     */   
/*     */   public boolean hasConstructorArgumentValues()
/*     */   {
/* 230 */     return !getConstructorArgumentValues().isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract MutablePropertyValues getPropertyValues();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasPropertyValues()
/*     */   {
/* 245 */     return !getPropertyValues().isEmpty();
/*     */   }
/*     */   
/*     */   public abstract void setInitMethodName(@Nullable String paramString);
/*     */   
/*     */   @Nullable
/*     */   public abstract String getInitMethodName();
/*     */   
/*     */   public abstract void setDestroyMethodName(@Nullable String paramString);
/*     */   
/*     */   @Nullable
/*     */   public abstract String getDestroyMethodName();
/*     */   
/*     */   public abstract void setRole(int paramInt);
/*     */   
/*     */   public abstract int getRole();
/*     */   
/*     */   public abstract void setDescription(@Nullable String paramString);
/*     */   
/*     */   @Nullable
/*     */   public abstract String getDescription();
/*     */   
/*     */   public abstract ResolvableType getResolvableType();
/*     */   
/*     */   public abstract boolean isSingleton();
/*     */   
/*     */   public abstract boolean isPrototype();
/*     */   
/*     */   public abstract boolean isAbstract();
/*     */   
/*     */   @Nullable
/*     */   public abstract String getResourceDescription();
/*     */   
/*     */   @Nullable
/*     */   public abstract BeanDefinition getOriginatingBeanDefinition();
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\config\BeanDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */