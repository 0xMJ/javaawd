package org.springframework.beans;

import java.beans.PropertyEditor;
import org.springframework.lang.Nullable;

public abstract interface PropertyEditorRegistry
{
  public abstract void registerCustomEditor(Class<?> paramClass, PropertyEditor paramPropertyEditor);
  
  public abstract void registerCustomEditor(@Nullable Class<?> paramClass, @Nullable String paramString, PropertyEditor paramPropertyEditor);
  
  @Nullable
  public abstract PropertyEditor findCustomEditor(@Nullable Class<?> paramClass, @Nullable String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\PropertyEditorRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */