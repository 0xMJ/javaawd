package org.springframework.beans.factory;

import java.lang.annotation.Annotation;
import java.util.Map;
import org.springframework.beans.BeansException;
import org.springframework.core.ResolvableType;
import org.springframework.lang.Nullable;

public abstract interface ListableBeanFactory
  extends BeanFactory
{
  public abstract boolean containsBeanDefinition(String paramString);
  
  public abstract int getBeanDefinitionCount();
  
  public abstract String[] getBeanDefinitionNames();
  
  public abstract <T> ObjectProvider<T> getBeanProvider(Class<T> paramClass, boolean paramBoolean);
  
  public abstract <T> ObjectProvider<T> getBeanProvider(ResolvableType paramResolvableType, boolean paramBoolean);
  
  public abstract String[] getBeanNamesForType(ResolvableType paramResolvableType);
  
  public abstract String[] getBeanNamesForType(ResolvableType paramResolvableType, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract String[] getBeanNamesForType(@Nullable Class<?> paramClass);
  
  public abstract String[] getBeanNamesForType(@Nullable Class<?> paramClass, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract <T> Map<String, T> getBeansOfType(@Nullable Class<T> paramClass)
    throws BeansException;
  
  public abstract <T> Map<String, T> getBeansOfType(@Nullable Class<T> paramClass, boolean paramBoolean1, boolean paramBoolean2)
    throws BeansException;
  
  public abstract String[] getBeanNamesForAnnotation(Class<? extends Annotation> paramClass);
  
  public abstract Map<String, Object> getBeansWithAnnotation(Class<? extends Annotation> paramClass)
    throws BeansException;
  
  @Nullable
  public abstract <A extends Annotation> A findAnnotationOnBean(String paramString, Class<A> paramClass)
    throws NoSuchBeanDefinitionException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\ListableBeanFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */