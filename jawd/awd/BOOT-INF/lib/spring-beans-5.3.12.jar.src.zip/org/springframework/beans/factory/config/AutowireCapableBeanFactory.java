package org.springframework.beans.factory.config;

import java.util.Set;
import org.springframework.beans.BeansException;
import org.springframework.beans.TypeConverter;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.lang.Nullable;

public abstract interface AutowireCapableBeanFactory
  extends BeanFactory
{
  public static final int AUTOWIRE_NO = 0;
  public static final int AUTOWIRE_BY_NAME = 1;
  public static final int AUTOWIRE_BY_TYPE = 2;
  public static final int AUTOWIRE_CONSTRUCTOR = 3;
  @Deprecated
  public static final int AUTOWIRE_AUTODETECT = 4;
  public static final String ORIGINAL_INSTANCE_SUFFIX = ".ORIGINAL";
  
  public abstract <T> T createBean(Class<T> paramClass)
    throws BeansException;
  
  public abstract void autowireBean(Object paramObject)
    throws BeansException;
  
  public abstract Object configureBean(Object paramObject, String paramString)
    throws BeansException;
  
  public abstract Object createBean(Class<?> paramClass, int paramInt, boolean paramBoolean)
    throws BeansException;
  
  public abstract Object autowire(Class<?> paramClass, int paramInt, boolean paramBoolean)
    throws BeansException;
  
  public abstract void autowireBeanProperties(Object paramObject, int paramInt, boolean paramBoolean)
    throws BeansException;
  
  public abstract void applyBeanPropertyValues(Object paramObject, String paramString)
    throws BeansException;
  
  public abstract Object initializeBean(Object paramObject, String paramString)
    throws BeansException;
  
  public abstract Object applyBeanPostProcessorsBeforeInitialization(Object paramObject, String paramString)
    throws BeansException;
  
  public abstract Object applyBeanPostProcessorsAfterInitialization(Object paramObject, String paramString)
    throws BeansException;
  
  public abstract void destroyBean(Object paramObject);
  
  public abstract <T> NamedBeanHolder<T> resolveNamedBean(Class<T> paramClass)
    throws BeansException;
  
  public abstract Object resolveBeanByName(String paramString, DependencyDescriptor paramDependencyDescriptor)
    throws BeansException;
  
  @Nullable
  public abstract Object resolveDependency(DependencyDescriptor paramDependencyDescriptor, @Nullable String paramString)
    throws BeansException;
  
  @Nullable
  public abstract Object resolveDependency(DependencyDescriptor paramDependencyDescriptor, @Nullable String paramString, @Nullable Set<String> paramSet, @Nullable TypeConverter paramTypeConverter)
    throws BeansException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\config\AutowireCapableBeanFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */