/*    */ package org.springframework.beans;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Spliterator;
/*    */ import java.util.Spliterators;
/*    */ import java.util.stream.Stream;
/*    */ import java.util.stream.StreamSupport;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface PropertyValues
/*    */   extends Iterable<PropertyValue>
/*    */ {
/*    */   public Iterator<PropertyValue> iterator()
/*    */   {
/* 45 */     return Arrays.asList(getPropertyValues()).iterator();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Spliterator<PropertyValue> spliterator()
/*    */   {
/* 54 */     return Spliterators.spliterator(getPropertyValues(), 0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Stream<PropertyValue> stream()
/*    */   {
/* 62 */     return StreamSupport.stream(spliterator(), false);
/*    */   }
/*    */   
/*    */   public abstract PropertyValue[] getPropertyValues();
/*    */   
/*    */   @Nullable
/*    */   public abstract PropertyValue getPropertyValue(String paramString);
/*    */   
/*    */   public abstract PropertyValues changesSince(PropertyValues paramPropertyValues);
/*    */   
/*    */   public abstract boolean contains(String paramString);
/*    */   
/*    */   public abstract boolean isEmpty();
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\PropertyValues.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */