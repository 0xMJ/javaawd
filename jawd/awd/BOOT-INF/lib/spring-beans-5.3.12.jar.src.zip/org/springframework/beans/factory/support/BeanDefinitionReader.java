package org.springframework.beans.factory.support;

import org.springframework.beans.factory.BeanDefinitionStoreException;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.lang.Nullable;

public abstract interface BeanDefinitionReader
{
  public abstract BeanDefinitionRegistry getRegistry();
  
  @Nullable
  public abstract ResourceLoader getResourceLoader();
  
  @Nullable
  public abstract ClassLoader getBeanClassLoader();
  
  public abstract BeanNameGenerator getBeanNameGenerator();
  
  public abstract int loadBeanDefinitions(Resource paramResource)
    throws BeanDefinitionStoreException;
  
  public abstract int loadBeanDefinitions(Resource... paramVarArgs)
    throws BeanDefinitionStoreException;
  
  public abstract int loadBeanDefinitions(String paramString)
    throws BeanDefinitionStoreException;
  
  public abstract int loadBeanDefinitions(String... paramVarArgs)
    throws BeanDefinitionStoreException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-beans-5.3.12.jar!\org\springframework\beans\factory\support\BeanDefinitionReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */