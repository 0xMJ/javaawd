/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericApplicationListenerAdapter
/*     */   implements GenericApplicationListener
/*     */ {
/*  41 */   private static final Map<Class<?>, ResolvableType> eventTypeCache = new ConcurrentReferenceHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   private final ApplicationListener<ApplicationEvent> delegate;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private final ResolvableType declaredEventType;
/*     */   
/*     */ 
/*     */ 
/*     */   public GenericApplicationListenerAdapter(ApplicationListener<?> delegate)
/*     */   {
/*  56 */     Assert.notNull(delegate, "Delegate listener must not be null");
/*  57 */     this.delegate = delegate;
/*  58 */     this.declaredEventType = resolveDeclaredEventType(this.delegate);
/*     */   }
/*     */   
/*     */ 
/*     */   public void onApplicationEvent(ApplicationEvent event)
/*     */   {
/*  64 */     this.delegate.onApplicationEvent(event);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean supportsEventType(ResolvableType eventType)
/*     */   {
/*  70 */     if ((this.delegate instanceof GenericApplicationListener)) {
/*  71 */       return ((GenericApplicationListener)this.delegate).supportsEventType(eventType);
/*     */     }
/*  73 */     if ((this.delegate instanceof SmartApplicationListener)) {
/*  74 */       Class<? extends ApplicationEvent> eventClass = eventType.resolve();
/*  75 */       return (eventClass != null) && (((SmartApplicationListener)this.delegate).supportsEventType(eventClass));
/*     */     }
/*     */     
/*  78 */     return (this.declaredEventType == null) || (this.declaredEventType.isAssignableFrom(eventType));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean supportsSourceType(@Nullable Class<?> sourceType)
/*     */   {
/*  84 */     return (!(this.delegate instanceof SmartApplicationListener)) || 
/*  85 */       (((SmartApplicationListener)this.delegate).supportsSourceType(sourceType));
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  90 */     return (this.delegate instanceof Ordered) ? ((Ordered)this.delegate).getOrder() : Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   public String getListenerId()
/*     */   {
/*  95 */     return (this.delegate instanceof SmartApplicationListener) ? ((SmartApplicationListener)this.delegate)
/*  96 */       .getListenerId() : "";
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static ResolvableType resolveDeclaredEventType(ApplicationListener<ApplicationEvent> listener)
/*     */   {
/* 102 */     ResolvableType declaredEventType = resolveDeclaredEventType(listener.getClass());
/* 103 */     if ((declaredEventType == null) || (declaredEventType.isAssignableFrom(ApplicationEvent.class))) {
/* 104 */       Class<?> targetClass = AopUtils.getTargetClass(listener);
/* 105 */       if (targetClass != listener.getClass()) {
/* 106 */         declaredEventType = resolveDeclaredEventType(targetClass);
/*     */       }
/*     */     }
/* 109 */     return declaredEventType;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   static ResolvableType resolveDeclaredEventType(Class<?> listenerType) {
/* 114 */     ResolvableType eventType = (ResolvableType)eventTypeCache.get(listenerType);
/* 115 */     if (eventType == null) {
/* 116 */       eventType = ResolvableType.forClass(listenerType).as(ApplicationListener.class).getGeneric(new int[0]);
/* 117 */       eventTypeCache.put(listenerType, eventType);
/*     */     }
/* 119 */     return eventType != ResolvableType.NONE ? eventType : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\event\GenericApplicationListenerAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */