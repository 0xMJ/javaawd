package org.springframework.context.annotation;

public enum AdviceMode
{
  PROXY,  ASPECTJ;
  
  private AdviceMode() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\AdviceMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */