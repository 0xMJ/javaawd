/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractResourceBasedMessageSource
/*     */   extends AbstractMessageSource
/*     */ {
/*  40 */   private final Set<String> basenameSet = new LinkedHashSet(4);
/*     */   
/*     */   @Nullable
/*     */   private String defaultEncoding;
/*     */   
/*  45 */   private boolean fallbackToSystemLocale = true;
/*     */   
/*     */   @Nullable
/*     */   private Locale defaultLocale;
/*     */   
/*  50 */   private long cacheMillis = -1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBasename(String basename)
/*     */   {
/*  66 */     setBasenames(new String[] { basename });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBasenames(String... basenames)
/*     */   {
/*  86 */     this.basenameSet.clear();
/*  87 */     addBasenames(basenames);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addBasenames(String... basenames)
/*     */   {
/* 100 */     if (!ObjectUtils.isEmpty(basenames)) {
/* 101 */       for (String basename : basenames) {
/* 102 */         Assert.hasText(basename, "Basename must not be empty");
/* 103 */         this.basenameSet.add(basename.trim());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> getBasenameSet()
/*     */   {
/* 116 */     return this.basenameSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultEncoding(@Nullable String defaultEncoding)
/*     */   {
/* 129 */     this.defaultEncoding = defaultEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getDefaultEncoding()
/*     */   {
/* 138 */     return this.defaultEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFallbackToSystemLocale(boolean fallbackToSystemLocale)
/*     */   {
/* 153 */     this.fallbackToSystemLocale = fallbackToSystemLocale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected boolean isFallbackToSystemLocale()
/*     */   {
/* 164 */     return this.fallbackToSystemLocale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultLocale(@Nullable Locale defaultLocale)
/*     */   {
/* 178 */     this.defaultLocale = defaultLocale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Locale getDefaultLocale()
/*     */   {
/* 191 */     if (this.defaultLocale != null) {
/* 192 */       return this.defaultLocale;
/*     */     }
/* 194 */     if (this.fallbackToSystemLocale) {
/* 195 */       return Locale.getDefault();
/*     */     }
/* 197 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheSeconds(int cacheSeconds)
/*     */   {
/* 221 */     this.cacheMillis = (cacheSeconds * 1000L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheMillis(long cacheMillis)
/*     */   {
/* 243 */     this.cacheMillis = cacheMillis;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected long getCacheMillis()
/*     */   {
/* 251 */     return this.cacheMillis;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\support\AbstractResourceBasedMessageSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */