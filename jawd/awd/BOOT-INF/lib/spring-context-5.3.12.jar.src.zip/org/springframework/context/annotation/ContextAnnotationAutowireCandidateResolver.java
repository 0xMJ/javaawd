/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.annotation.QualifierAnnotationAutowireCandidateResolver;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextAnnotationAutowireCandidateResolver
/*     */   extends QualifierAnnotationAutowireCandidateResolver
/*     */ {
/*     */   @Nullable
/*     */   public Object getLazyResolutionProxyIfNecessary(DependencyDescriptor descriptor, @Nullable String beanName)
/*     */   {
/*  54 */     return isLazy(descriptor) ? buildLazyResolutionProxy(descriptor, beanName) : null;
/*     */   }
/*     */   
/*     */   protected boolean isLazy(DependencyDescriptor descriptor) {
/*  58 */     for (Annotation ann : descriptor.getAnnotations()) {
/*  59 */       Lazy lazy = (Lazy)AnnotationUtils.getAnnotation(ann, Lazy.class);
/*  60 */       if ((lazy != null) && (lazy.value())) {
/*  61 */         return true;
/*     */       }
/*     */     }
/*  64 */     MethodParameter methodParam = descriptor.getMethodParameter();
/*  65 */     if (methodParam != null) {
/*  66 */       Method method = methodParam.getMethod();
/*  67 */       if ((method == null) || (Void.TYPE == method.getReturnType())) {
/*  68 */         Lazy lazy = (Lazy)AnnotationUtils.getAnnotation(methodParam.getAnnotatedElement(), Lazy.class);
/*  69 */         if ((lazy != null) && (lazy.value())) {
/*  70 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*  74 */     return false;
/*     */   }
/*     */   
/*     */   protected Object buildLazyResolutionProxy(final DependencyDescriptor descriptor, @Nullable final String beanName) {
/*  78 */     BeanFactory beanFactory = getBeanFactory();
/*  79 */     Assert.state(beanFactory instanceof DefaultListableBeanFactory, "BeanFactory needs to be a DefaultListableBeanFactory");
/*     */     
/*  81 */     final DefaultListableBeanFactory dlbf = (DefaultListableBeanFactory)beanFactory;
/*     */     
/*  83 */     TargetSource ts = new TargetSource()
/*     */     {
/*     */       public Class<?> getTargetClass() {
/*  86 */         return descriptor.getDependencyType();
/*     */       }
/*     */       
/*     */       public boolean isStatic() {
/*  90 */         return false;
/*     */       }
/*     */       
/*     */       public Object getTarget() {
/*  94 */         Set<String> autowiredBeanNames = beanName != null ? new LinkedHashSet(1) : null;
/*  95 */         Object target = dlbf.doResolveDependency(descriptor, beanName, autowiredBeanNames, null);
/*  96 */         Class<?> type; if (target == null) {
/*  97 */           type = getTargetClass();
/*  98 */           if (Map.class == type) {
/*  99 */             return Collections.emptyMap();
/*     */           }
/* 101 */           if (List.class == type) {
/* 102 */             return Collections.emptyList();
/*     */           }
/* 104 */           if ((Set.class == type) || (Collection.class == type)) {
/* 105 */             return Collections.emptySet();
/*     */           }
/* 107 */           throw new NoSuchBeanDefinitionException(descriptor.getResolvableType(), "Optional dependency not present for lazy injection point");
/*     */         }
/*     */         
/* 110 */         if (autowiredBeanNames != null) {
/* 111 */           for (String autowiredBeanName : autowiredBeanNames) {
/* 112 */             if (dlbf.containsBean(autowiredBeanName)) {
/* 113 */               dlbf.registerDependentBean(autowiredBeanName, beanName);
/*     */             }
/*     */           }
/*     */         }
/* 117 */         return target;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public void releaseTarget(Object target) {}
/* 123 */     };
/* 124 */     ProxyFactory pf = new ProxyFactory();
/* 125 */     pf.setTargetSource(ts);
/* 126 */     Class<?> dependencyType = descriptor.getDependencyType();
/* 127 */     if (dependencyType.isInterface()) {
/* 128 */       pf.addInterface(dependencyType);
/*     */     }
/* 130 */     return pf.getProxy(dlbf.getBeanClassLoader());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\ContextAnnotationAutowireCandidateResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */