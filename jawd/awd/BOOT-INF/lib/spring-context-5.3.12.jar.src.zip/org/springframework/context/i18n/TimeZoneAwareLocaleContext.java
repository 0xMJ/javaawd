package org.springframework.context.i18n;

import java.util.TimeZone;
import org.springframework.lang.Nullable;

public abstract interface TimeZoneAwareLocaleContext
  extends LocaleContext
{
  @Nullable
  public abstract TimeZone getTimeZone();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\i18n\TimeZoneAwareLocaleContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */