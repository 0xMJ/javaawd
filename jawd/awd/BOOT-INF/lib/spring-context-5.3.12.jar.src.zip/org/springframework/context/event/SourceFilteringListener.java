/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SourceFilteringListener
/*     */   implements GenericApplicationListener
/*     */ {
/*     */   private final Object source;
/*     */   @Nullable
/*     */   private GenericApplicationListener delegate;
/*     */   
/*     */   public SourceFilteringListener(Object source, ApplicationListener<?> delegate)
/*     */   {
/*  53 */     this.source = source;
/*  54 */     this.delegate = ((delegate instanceof GenericApplicationListener) ? (GenericApplicationListener)delegate : new GenericApplicationListenerAdapter(delegate));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SourceFilteringListener(Object source)
/*     */   {
/*  66 */     this.source = source;
/*     */   }
/*     */   
/*     */ 
/*     */   public void onApplicationEvent(ApplicationEvent event)
/*     */   {
/*  72 */     if (event.getSource() == this.source) {
/*  73 */       onApplicationEventInternal(event);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean supportsEventType(ResolvableType eventType)
/*     */   {
/*  79 */     return (this.delegate == null) || (this.delegate.supportsEventType(eventType));
/*     */   }
/*     */   
/*     */   public boolean supportsSourceType(@Nullable Class<?> sourceType)
/*     */   {
/*  84 */     return (sourceType != null) && (sourceType.isInstance(this.source));
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  89 */     return this.delegate != null ? this.delegate.getOrder() : Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   public String getListenerId()
/*     */   {
/*  94 */     return this.delegate != null ? this.delegate.getListenerId() : "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void onApplicationEventInternal(ApplicationEvent event)
/*     */   {
/* 105 */     if (this.delegate == null) {
/* 106 */       throw new IllegalStateException("Must specify a delegate object or override the onApplicationEventInternal method");
/*     */     }
/*     */     
/* 109 */     this.delegate.onApplicationEvent(event);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\event\SourceFilteringListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */