/*    */ package org.springframework.context.config;
/*    */ 
/*    */ import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PropertyPlaceholderBeanDefinitionParser
/*    */   extends AbstractPropertyLoadingBeanDefinitionParser
/*    */ {
/*    */   private static final String SYSTEM_PROPERTIES_MODE_ATTRIBUTE = "system-properties-mode";
/*    */   private static final String SYSTEM_PROPERTIES_MODE_DEFAULT = "ENVIRONMENT";
/*    */   
/*    */   protected Class<?> getBeanClass(Element element)
/*    */   {
/* 48 */     if ("ENVIRONMENT".equals(element.getAttribute("system-properties-mode"))) {
/* 49 */       return PropertySourcesPlaceholderConfigurer.class;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 55 */     return PropertyPlaceholderConfigurer.class;
/*    */   }
/*    */   
/*    */   protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
/*    */   {
/* 60 */     super.doParse(element, parserContext, builder);
/*    */     
/* 62 */     builder.addPropertyValue("ignoreUnresolvablePlaceholders", 
/* 63 */       Boolean.valueOf(element.getAttribute("ignore-unresolvable")));
/*    */     
/* 65 */     String systemPropertiesModeName = element.getAttribute("system-properties-mode");
/* 66 */     if ((StringUtils.hasLength(systemPropertiesModeName)) && 
/* 67 */       (!systemPropertiesModeName.equals("ENVIRONMENT"))) {
/* 68 */       builder.addPropertyValue("systemPropertiesModeName", "SYSTEM_PROPERTIES_MODE_" + systemPropertiesModeName);
/*    */     }
/*    */     
/* 71 */     if (element.hasAttribute("value-separator")) {
/* 72 */       builder.addPropertyValue("valueSeparator", element.getAttribute("value-separator"));
/*    */     }
/* 74 */     if (element.hasAttribute("trim-values")) {
/* 75 */       builder.addPropertyValue("trimValues", element.getAttribute("trim-values"));
/*    */     }
/* 77 */     if (element.hasAttribute("null-value")) {
/* 78 */       builder.addPropertyValue("nullValue", element.getAttribute("null-value"));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\config\PropertyPlaceholderBeanDefinitionParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */