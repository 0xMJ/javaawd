/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.context.event.EventListenerFactory;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.stereotype.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ConfigurationClassUtils
/*     */ {
/*     */   public static final String CONFIGURATION_CLASS_FULL = "full";
/*     */   public static final String CONFIGURATION_CLASS_LITE = "lite";
/*  59 */   public static final String CONFIGURATION_CLASS_ATTRIBUTE = Conventions.getQualifiedAttributeName(ConfigurationClassPostProcessor.class, "configurationClass");
/*     */   
/*     */ 
/*  62 */   private static final String ORDER_ATTRIBUTE = Conventions.getQualifiedAttributeName(ConfigurationClassPostProcessor.class, "order");
/*     */   
/*     */ 
/*  65 */   private static final Log logger = LogFactory.getLog(ConfigurationClassUtils.class);
/*     */   
/*  67 */   private static final Set<String> candidateIndicators = new HashSet(8);
/*     */   
/*     */   static {
/*  70 */     candidateIndicators.add(Component.class.getName());
/*  71 */     candidateIndicators.add(ComponentScan.class.getName());
/*  72 */     candidateIndicators.add(Import.class.getName());
/*  73 */     candidateIndicators.add(ImportResource.class.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean checkConfigurationClassCandidate(BeanDefinition beanDef, MetadataReaderFactory metadataReaderFactory)
/*     */   {
/*  88 */     String className = beanDef.getBeanClassName();
/*  89 */     if ((className == null) || (beanDef.getFactoryMethodName() != null)) {
/*  90 */       return false;
/*     */     }
/*     */     
/*     */     AnnotationMetadata metadata;
/*  94 */     if (((beanDef instanceof AnnotatedBeanDefinition)) && 
/*  95 */       (className.equals(((AnnotatedBeanDefinition)beanDef).getMetadata().getClassName())))
/*     */     {
/*  97 */       metadata = ((AnnotatedBeanDefinition)beanDef).getMetadata();
/*     */     } else { AnnotationMetadata metadata;
/*  99 */       if (((beanDef instanceof AbstractBeanDefinition)) && (((AbstractBeanDefinition)beanDef).hasBeanClass()))
/*     */       {
/*     */ 
/* 102 */         Class<?> beanClass = ((AbstractBeanDefinition)beanDef).getBeanClass();
/* 103 */         if ((BeanFactoryPostProcessor.class.isAssignableFrom(beanClass)) || 
/* 104 */           (BeanPostProcessor.class.isAssignableFrom(beanClass)) || 
/* 105 */           (AopInfrastructureBean.class.isAssignableFrom(beanClass)) || 
/* 106 */           (EventListenerFactory.class.isAssignableFrom(beanClass))) {
/* 107 */           return false;
/*     */         }
/* 109 */         metadata = AnnotationMetadata.introspect(beanClass);
/*     */       }
/*     */       else {
/*     */         try {
/* 113 */           MetadataReader metadataReader = metadataReaderFactory.getMetadataReader(className);
/* 114 */           metadata = metadataReader.getAnnotationMetadata();
/*     */         } catch (IOException ex) {
/*     */           AnnotationMetadata metadata;
/* 117 */           if (logger.isDebugEnabled()) {
/* 118 */             logger.debug("Could not find class file for introspecting configuration annotations: " + className, ex);
/*     */           }
/*     */           
/* 121 */           return false;
/*     */         }
/*     */       } }
/*     */     AnnotationMetadata metadata;
/* 125 */     Map<String, Object> config = metadata.getAnnotationAttributes(Configuration.class.getName());
/* 126 */     if ((config != null) && (!Boolean.FALSE.equals(config.get("proxyBeanMethods")))) {
/* 127 */       beanDef.setAttribute(CONFIGURATION_CLASS_ATTRIBUTE, "full");
/*     */     }
/* 129 */     else if ((config != null) || (isConfigurationCandidate(metadata))) {
/* 130 */       beanDef.setAttribute(CONFIGURATION_CLASS_ATTRIBUTE, "lite");
/*     */     }
/*     */     else {
/* 133 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 137 */     Integer order = getOrder(metadata);
/* 138 */     if (order != null) {
/* 139 */       beanDef.setAttribute(ORDER_ATTRIBUTE, order);
/*     */     }
/*     */     
/* 142 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isConfigurationCandidate(AnnotationMetadata metadata)
/*     */   {
/* 154 */     if (metadata.isInterface()) {
/* 155 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 159 */     for (String indicator : candidateIndicators) {
/* 160 */       if (metadata.isAnnotated(indicator)) {
/* 161 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 166 */     return hasBeanMethods(metadata);
/*     */   }
/*     */   
/*     */   static boolean hasBeanMethods(AnnotationMetadata metadata) {
/*     */     try {
/* 171 */       return metadata.hasAnnotatedMethods(Bean.class.getName());
/*     */     }
/*     */     catch (Throwable ex) {
/* 174 */       if (logger.isDebugEnabled())
/* 175 */         logger.debug("Failed to introspect @Bean methods on class [" + metadata.getClassName() + "]: " + ex);
/*     */     }
/* 177 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public static Integer getOrder(AnnotationMetadata metadata)
/*     */   {
/* 190 */     Map<String, Object> orderAttributes = metadata.getAnnotationAttributes(Order.class.getName());
/* 191 */     return orderAttributes != null ? (Integer)orderAttributes.get("value") : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getOrder(BeanDefinition beanDef)
/*     */   {
/* 203 */     Integer order = (Integer)beanDef.getAttribute(ORDER_ATTRIBUTE);
/* 204 */     return order != null ? order.intValue() : Integer.MAX_VALUE;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\ConfigurationClassUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */