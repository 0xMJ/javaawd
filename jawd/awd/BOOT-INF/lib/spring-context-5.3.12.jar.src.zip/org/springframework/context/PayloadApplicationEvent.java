/*    */ package org.springframework.context;
/*    */ 
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.ResolvableTypeProvider;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PayloadApplicationEvent<T>
/*    */   extends ApplicationEvent
/*    */   implements ResolvableTypeProvider
/*    */ {
/*    */   private final T payload;
/*    */   
/*    */   public PayloadApplicationEvent(Object source, T payload)
/*    */   {
/* 47 */     super(source);
/* 48 */     Assert.notNull(payload, "Payload must not be null");
/* 49 */     this.payload = payload;
/*    */   }
/*    */   
/*    */ 
/*    */   public ResolvableType getResolvableType()
/*    */   {
/* 55 */     return ResolvableType.forClassWithGenerics(getClass(), new ResolvableType[] { ResolvableType.forInstance(getPayload()) });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public T getPayload()
/*    */   {
/* 62 */     return (T)this.payload;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\PayloadApplicationEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */