/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.aop.framework.AopProxyUtils;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractApplicationEventMulticaster
/*     */   implements ApplicationEventMulticaster, BeanClassLoaderAware, BeanFactoryAware
/*     */ {
/*  67 */   private final DefaultListenerRetriever defaultRetriever = new DefaultListenerRetriever(null);
/*     */   
/*  69 */   final Map<ListenerCacheKey, CachedListenerRetriever> retrieverCache = new ConcurrentHashMap(64);
/*     */   
/*     */   @Nullable
/*     */   private ClassLoader beanClassLoader;
/*     */   
/*     */   @Nullable
/*     */   private ConfigurableBeanFactory beanFactory;
/*     */   
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/*  80 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  85 */     if (!(beanFactory instanceof ConfigurableBeanFactory)) {
/*  86 */       throw new IllegalStateException("Not running in a ConfigurableBeanFactory: " + beanFactory);
/*     */     }
/*  88 */     this.beanFactory = ((ConfigurableBeanFactory)beanFactory);
/*  89 */     if (this.beanClassLoader == null) {
/*  90 */       this.beanClassLoader = this.beanFactory.getBeanClassLoader();
/*     */     }
/*     */   }
/*     */   
/*     */   private ConfigurableBeanFactory getBeanFactory() {
/*  95 */     if (this.beanFactory == null) {
/*  96 */       throw new IllegalStateException("ApplicationEventMulticaster cannot retrieve listener beans because it is not associated with a BeanFactory");
/*     */     }
/*     */     
/*  99 */     return this.beanFactory;
/*     */   }
/*     */   
/*     */ 
/*     */   public void addApplicationListener(ApplicationListener<?> listener)
/*     */   {
/* 105 */     synchronized (this.defaultRetriever)
/*     */     {
/*     */ 
/* 108 */       Object singletonTarget = AopProxyUtils.getSingletonTarget(listener);
/* 109 */       if ((singletonTarget instanceof ApplicationListener)) {
/* 110 */         this.defaultRetriever.applicationListeners.remove(singletonTarget);
/*     */       }
/* 112 */       this.defaultRetriever.applicationListeners.add(listener);
/* 113 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void addApplicationListenerBean(String listenerBeanName)
/*     */   {
/* 119 */     synchronized (this.defaultRetriever) {
/* 120 */       this.defaultRetriever.applicationListenerBeans.add(listenerBeanName);
/* 121 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeApplicationListener(ApplicationListener<?> listener)
/*     */   {
/* 127 */     synchronized (this.defaultRetriever) {
/* 128 */       this.defaultRetriever.applicationListeners.remove(listener);
/* 129 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeApplicationListenerBean(String listenerBeanName)
/*     */   {
/* 135 */     synchronized (this.defaultRetriever) {
/* 136 */       this.defaultRetriever.applicationListenerBeans.remove(listenerBeanName);
/* 137 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeApplicationListeners(Predicate<ApplicationListener<?>> predicate)
/*     */   {
/* 143 */     synchronized (this.defaultRetriever) {
/* 144 */       this.defaultRetriever.applicationListeners.removeIf(predicate);
/* 145 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeApplicationListenerBeans(Predicate<String> predicate)
/*     */   {
/* 151 */     synchronized (this.defaultRetriever) {
/* 152 */       this.defaultRetriever.applicationListenerBeans.removeIf(predicate);
/* 153 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeAllListeners()
/*     */   {
/* 159 */     synchronized (this.defaultRetriever) {
/* 160 */       this.defaultRetriever.applicationListeners.clear();
/* 161 */       this.defaultRetriever.applicationListenerBeans.clear();
/* 162 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected Collection<ApplicationListener<?>> getApplicationListeners()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 5	org/springframework/context/event/AbstractApplicationEventMulticaster:defaultRetriever	Lorg/springframework/context/event/AbstractApplicationEventMulticaster$DefaultListenerRetriever;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 5	org/springframework/context/event/AbstractApplicationEventMulticaster:defaultRetriever	Lorg/springframework/context/event/AbstractApplicationEventMulticaster$DefaultListenerRetriever;
/*     */     //   11: invokevirtual 31	org/springframework/context/event/AbstractApplicationEventMulticaster$DefaultListenerRetriever:getApplicationListeners	()Ljava/util/Collection;
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: areturn
/*     */     //   17: astore_2
/*     */     //   18: aload_1
/*     */     //   19: monitorexit
/*     */     //   20: aload_2
/*     */     //   21: athrow
/*     */     // Line number table:
/*     */     //   Java source line #173	-> byte code offset #0
/*     */     //   Java source line #174	-> byte code offset #7
/*     */     //   Java source line #175	-> byte code offset #17
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	22	0	this	AbstractApplicationEventMulticaster
/*     */     //   5	14	1	Ljava/lang/Object;	Object
/*     */     //   17	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	16	17	finally
/*     */     //   17	20	17	finally
/*     */   }
/*     */   
/*     */   protected Collection<ApplicationListener<?>> getApplicationListeners(ApplicationEvent event, ResolvableType eventType)
/*     */   {
/* 190 */     Object source = event.getSource();
/* 191 */     Class<?> sourceType = source != null ? source.getClass() : null;
/* 192 */     ListenerCacheKey cacheKey = new ListenerCacheKey(eventType, sourceType);
/*     */     
/*     */ 
/* 195 */     CachedListenerRetriever newRetriever = null;
/*     */     
/*     */ 
/* 198 */     CachedListenerRetriever existingRetriever = (CachedListenerRetriever)this.retrieverCache.get(cacheKey);
/* 199 */     if (existingRetriever == null)
/*     */     {
/* 201 */       if ((this.beanClassLoader == null) || (
/* 202 */         (ClassUtils.isCacheSafe(event.getClass(), this.beanClassLoader)) && ((sourceType == null) || 
/* 203 */         (ClassUtils.isCacheSafe(sourceType, this.beanClassLoader))))) {
/* 204 */         newRetriever = new CachedListenerRetriever(null);
/* 205 */         existingRetriever = (CachedListenerRetriever)this.retrieverCache.putIfAbsent(cacheKey, newRetriever);
/* 206 */         if (existingRetriever != null) {
/* 207 */           newRetriever = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 212 */     if (existingRetriever != null) {
/* 213 */       Collection<ApplicationListener<?>> result = existingRetriever.getApplicationListeners();
/* 214 */       if (result != null) {
/* 215 */         return result;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 221 */     return retrieveApplicationListeners(eventType, sourceType, newRetriever);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Collection<ApplicationListener<?>> retrieveApplicationListeners(ResolvableType eventType, @Nullable Class<?> sourceType, @Nullable CachedListenerRetriever retriever)
/*     */   {
/* 234 */     List<ApplicationListener<?>> allListeners = new ArrayList();
/* 235 */     Set<ApplicationListener<?>> filteredListeners = retriever != null ? new LinkedHashSet() : null;
/* 236 */     Set<String> filteredListenerBeans = retriever != null ? new LinkedHashSet() : null;
/*     */     
/*     */     Set<String> listenerBeans;
/*     */     
/* 240 */     synchronized (this.defaultRetriever) {
/* 241 */       Set<ApplicationListener<?>> listeners = new LinkedHashSet(this.defaultRetriever.applicationListeners);
/* 242 */       listenerBeans = new LinkedHashSet(this.defaultRetriever.applicationListenerBeans);
/*     */     }
/*     */     
/*     */     Set<String> listenerBeans;
/*     */     Set<ApplicationListener<?>> listeners;
/* 247 */     for (??? = listeners.iterator(); ((Iterator)???).hasNext();) { listener = (ApplicationListener)((Iterator)???).next();
/* 248 */       if (supportsEvent((ApplicationListener)listener, eventType, sourceType)) {
/* 249 */         if (retriever != null) {
/* 250 */           filteredListeners.add(listener);
/*     */         }
/* 252 */         allListeners.add(listener);
/*     */       }
/*     */     }
/*     */     
/*     */     Object listener;
/*     */     ConfigurableBeanFactory beanFactory;
/* 258 */     if (!listenerBeans.isEmpty()) {
/* 259 */       beanFactory = getBeanFactory();
/* 260 */       for (listener = listenerBeans.iterator(); ((Iterator)listener).hasNext();) { String listenerBeanName = (String)((Iterator)listener).next();
/*     */         try {
/* 262 */           if (supportsEvent(beanFactory, listenerBeanName, eventType))
/*     */           {
/* 264 */             ApplicationListener<?> listener = (ApplicationListener)beanFactory.getBean(listenerBeanName, ApplicationListener.class);
/* 265 */             if ((!allListeners.contains(listener)) && (supportsEvent(listener, eventType, sourceType))) {
/* 266 */               if (retriever != null) {
/* 267 */                 if (beanFactory.isSingleton(listenerBeanName)) {
/* 268 */                   filteredListeners.add(listener);
/*     */                 }
/*     */                 else {
/* 271 */                   filteredListenerBeans.add(listenerBeanName);
/*     */                 }
/*     */               }
/* 274 */               allListeners.add(listener);
/*     */             }
/*     */             
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 281 */             Object listener = beanFactory.getSingleton(listenerBeanName);
/* 282 */             if (retriever != null) {
/* 283 */               filteredListeners.remove(listener);
/*     */             }
/* 285 */             allListeners.remove(listener);
/*     */           }
/*     */         }
/*     */         catch (NoSuchBeanDefinitionException localNoSuchBeanDefinitionException) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 295 */     AnnotationAwareOrderComparator.sort(allListeners);
/* 296 */     if (retriever != null) {
/* 297 */       if (filteredListenerBeans.isEmpty()) {
/* 298 */         retriever.applicationListeners = new LinkedHashSet(allListeners);
/* 299 */         retriever.applicationListenerBeans = filteredListenerBeans;
/*     */       }
/*     */       else {
/* 302 */         retriever.applicationListeners = filteredListeners;
/* 303 */         retriever.applicationListenerBeans = filteredListenerBeans;
/*     */       }
/*     */     }
/* 306 */     return allListeners;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean supportsEvent(ConfigurableBeanFactory beanFactory, String listenerBeanName, ResolvableType eventType)
/*     */   {
/* 326 */     Class<?> listenerType = beanFactory.getType(listenerBeanName);
/* 327 */     if ((listenerType == null) || (GenericApplicationListener.class.isAssignableFrom(listenerType)) || 
/* 328 */       (SmartApplicationListener.class.isAssignableFrom(listenerType))) {
/* 329 */       return true;
/*     */     }
/* 331 */     if (!supportsEvent(listenerType, eventType)) {
/* 332 */       return false;
/*     */     }
/*     */     try {
/* 335 */       BeanDefinition bd = beanFactory.getMergedBeanDefinition(listenerBeanName);
/* 336 */       ResolvableType genericEventType = bd.getResolvableType().as(ApplicationListener.class).getGeneric(new int[0]);
/* 337 */       return (genericEventType == ResolvableType.NONE) || (genericEventType.isAssignableFrom(eventType));
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {}
/*     */     
/* 341 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean supportsEvent(Class<?> listenerType, ResolvableType eventType)
/*     */   {
/* 357 */     ResolvableType declaredEventType = GenericApplicationListenerAdapter.resolveDeclaredEventType(listenerType);
/* 358 */     return (declaredEventType == null) || (declaredEventType.isAssignableFrom(eventType));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean supportsEvent(ApplicationListener<?> listener, ResolvableType eventType, @Nullable Class<?> sourceType)
/*     */   {
/* 376 */     GenericApplicationListener smartListener = (listener instanceof GenericApplicationListener) ? (GenericApplicationListener)listener : new GenericApplicationListenerAdapter(listener);
/*     */     
/* 378 */     return (smartListener.supportsEventType(eventType)) && (smartListener.supportsSourceType(sourceType));
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class ListenerCacheKey
/*     */     implements Comparable<ListenerCacheKey>
/*     */   {
/*     */     private final ResolvableType eventType;
/*     */     
/*     */     @Nullable
/*     */     private final Class<?> sourceType;
/*     */     
/*     */ 
/*     */     public ListenerCacheKey(ResolvableType eventType, @Nullable Class<?> sourceType)
/*     */     {
/* 393 */       Assert.notNull(eventType, "Event type must not be null");
/* 394 */       this.eventType = eventType;
/* 395 */       this.sourceType = sourceType;
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other)
/*     */     {
/* 400 */       if (this == other) {
/* 401 */         return true;
/*     */       }
/* 403 */       if (!(other instanceof ListenerCacheKey)) {
/* 404 */         return false;
/*     */       }
/* 406 */       ListenerCacheKey otherKey = (ListenerCacheKey)other;
/* 407 */       return (this.eventType.equals(otherKey.eventType)) && 
/* 408 */         (ObjectUtils.nullSafeEquals(this.sourceType, otherKey.sourceType));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 413 */       return this.eventType.hashCode() * 29 + ObjectUtils.nullSafeHashCode(this.sourceType);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 418 */       return "ListenerCacheKey [eventType = " + this.eventType + ", sourceType = " + this.sourceType + "]";
/*     */     }
/*     */     
/*     */     public int compareTo(ListenerCacheKey other)
/*     */     {
/* 423 */       int result = this.eventType.toString().compareTo(other.eventType.toString());
/* 424 */       if (result == 0) {
/* 425 */         if (this.sourceType == null) {
/* 426 */           return other.sourceType == null ? 0 : -1;
/*     */         }
/* 428 */         if (other.sourceType == null) {
/* 429 */           return 1;
/*     */         }
/* 431 */         result = this.sourceType.getName().compareTo(other.sourceType.getName());
/*     */       }
/* 433 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class CachedListenerRetriever
/*     */   {
/*     */     @Nullable
/*     */     public volatile Set<ApplicationListener<?>> applicationListeners;
/*     */     
/*     */     @Nullable
/*     */     public volatile Set<String> applicationListenerBeans;
/*     */     
/*     */ 
/*     */     private CachedListenerRetriever() {}
/*     */     
/*     */ 
/*     */     @Nullable
/*     */     public Collection<ApplicationListener<?>> getApplicationListeners()
/*     */     {
/* 453 */       Set<ApplicationListener<?>> applicationListeners = this.applicationListeners;
/* 454 */       Set<String> applicationListenerBeans = this.applicationListenerBeans;
/* 455 */       if ((applicationListeners == null) || (applicationListenerBeans == null))
/*     */       {
/* 457 */         return null;
/*     */       }
/*     */       
/*     */ 
/* 461 */       List<ApplicationListener<?>> allListeners = new ArrayList(applicationListeners.size() + applicationListenerBeans.size());
/* 462 */       allListeners.addAll(applicationListeners);
/* 463 */       BeanFactory beanFactory; if (!applicationListenerBeans.isEmpty()) {
/* 464 */         beanFactory = AbstractApplicationEventMulticaster.this.getBeanFactory();
/* 465 */         for (String listenerBeanName : applicationListenerBeans) {
/*     */           try {
/* 467 */             allListeners.add(beanFactory.getBean(listenerBeanName, ApplicationListener.class));
/*     */           }
/*     */           catch (NoSuchBeanDefinitionException localNoSuchBeanDefinitionException) {}
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 475 */       if (!applicationListenerBeans.isEmpty()) {
/* 476 */         AnnotationAwareOrderComparator.sort(allListeners);
/*     */       }
/* 478 */       return allListeners;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class DefaultListenerRetriever
/*     */   {
/* 488 */     public final Set<ApplicationListener<?>> applicationListeners = new LinkedHashSet();
/*     */     
/* 490 */     public final Set<String> applicationListenerBeans = new LinkedHashSet();
/*     */     
/*     */     private DefaultListenerRetriever() {}
/*     */     
/* 494 */     public Collection<ApplicationListener<?>> getApplicationListeners() { List<ApplicationListener<?>> allListeners = new ArrayList(this.applicationListeners.size() + this.applicationListenerBeans.size());
/* 495 */       allListeners.addAll(this.applicationListeners);
/* 496 */       BeanFactory beanFactory; if (!this.applicationListenerBeans.isEmpty()) {
/* 497 */         beanFactory = AbstractApplicationEventMulticaster.this.getBeanFactory();
/* 498 */         for (String listenerBeanName : this.applicationListenerBeans) {
/*     */           try
/*     */           {
/* 501 */             ApplicationListener<?> listener = (ApplicationListener)beanFactory.getBean(listenerBeanName, ApplicationListener.class);
/* 502 */             if (!allListeners.contains(listener)) {
/* 503 */               allListeners.add(listener);
/*     */             }
/*     */           }
/*     */           catch (NoSuchBeanDefinitionException localNoSuchBeanDefinitionException) {}
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 512 */       AnnotationAwareOrderComparator.sort(allListeners);
/* 513 */       return allListeners;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\event\AbstractApplicationEventMulticaster.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */