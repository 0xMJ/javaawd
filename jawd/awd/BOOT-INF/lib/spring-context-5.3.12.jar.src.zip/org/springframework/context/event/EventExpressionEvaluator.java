/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.expression.AnnotatedElementKey;
/*    */ import org.springframework.context.expression.BeanFactoryResolver;
/*    */ import org.springframework.context.expression.CachedExpressionEvaluator;
/*    */ import org.springframework.context.expression.CachedExpressionEvaluator.ExpressionKey;
/*    */ import org.springframework.context.expression.MethodBasedEvaluationContext;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EventExpressionEvaluator
/*    */   extends CachedExpressionEvaluator
/*    */ {
/* 42 */   private final Map<CachedExpressionEvaluator.ExpressionKey, Expression> conditionCache = new ConcurrentHashMap(64);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean condition(String conditionExpression, ApplicationEvent event, Method targetMethod, AnnotatedElementKey methodKey, Object[] args, @Nullable BeanFactory beanFactory)
/*    */   {
/* 52 */     EventExpressionRootObject root = new EventExpressionRootObject(event, args);
/*    */     
/* 54 */     MethodBasedEvaluationContext evaluationContext = new MethodBasedEvaluationContext(root, targetMethod, args, getParameterNameDiscoverer());
/* 55 */     if (beanFactory != null) {
/* 56 */       evaluationContext.setBeanResolver(new BeanFactoryResolver(beanFactory));
/*    */     }
/*    */     
/* 59 */     return Boolean.TRUE.equals(getExpression(this.conditionCache, methodKey, conditionExpression).getValue(evaluationContext, Boolean.class));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\event\EventExpressionEvaluator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */