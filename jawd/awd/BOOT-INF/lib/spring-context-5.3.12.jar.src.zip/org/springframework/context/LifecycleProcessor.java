package org.springframework.context;

public abstract interface LifecycleProcessor
  extends Lifecycle
{
  public abstract void onRefresh();
  
  public abstract void onClose();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\LifecycleProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */