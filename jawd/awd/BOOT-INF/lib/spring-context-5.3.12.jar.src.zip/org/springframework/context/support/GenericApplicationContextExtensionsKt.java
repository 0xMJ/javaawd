/*    */ package org.springframework.context.support;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import kotlin.Deprecated;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.ReplaceWith;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv={1, 1, 18}, bv={1, 0, 3}, k=2, d1={"\000:\n\000\n\002\030\002\n\000\n\002\030\002\n\002\020\002\n\002\030\002\n\002\b\002\n\002\020\000\n\000\n\002\020\021\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\004\032!\020\000\032\0020\0012\027\020\002\032\023\022\004\022\0020\001\022\004\022\0020\0040\003¢\006\002\b\005H\007\0322\020\006\032\0020\004\"\n\b\000\020\007\030\001*\0020\b*\0020\0012\022\020\t\032\n\022\006\b\001\022\0020\0130\n\"\0020\013H\b¢\006\002\020\f\032H\020\006\032\0020\004\"\n\b\000\020\007\030\001*\0020\b*\0020\0012\022\020\t\032\n\022\006\b\001\022\0020\0130\n\"\0020\0132\024\b\004\020\r\032\016\022\004\022\0020\016\022\004\022\002H\0070\003H\b¢\006\002\020\017\032:\020\006\032\0020\004\"\n\b\000\020\007\030\001*\0020\b*\0020\0012\006\020\020\032\0020\0212\022\020\t\032\n\022\006\b\001\022\0020\0130\n\"\0020\013H\b¢\006\002\020\022\032P\020\006\032\0020\004\"\n\b\000\020\007\030\001*\0020\b*\0020\0012\006\020\023\032\0020\0212\022\020\t\032\n\022\006\b\001\022\0020\0130\n\"\0020\0132\024\b\004\020\r\032\016\022\004\022\0020\016\022\004\022\002H\0070\003H\b¢\006\002\020\024¨\006\025"}, d2={"GenericApplicationContext", "Lorg/springframework/context/support/GenericApplicationContext;", "configure", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "registerBean", "T", "", "customizers", "", "Lorg/springframework/beans/factory/config/BeanDefinitionCustomizer;", "(Lorg/springframework/context/support/GenericApplicationContext;[Lorg/springframework/beans/factory/config/BeanDefinitionCustomizer;)V", "function", "Lorg/springframework/context/ApplicationContext;", "(Lorg/springframework/context/support/GenericApplicationContext;[Lorg/springframework/beans/factory/config/BeanDefinitionCustomizer;Lkotlin/jvm/functions/Function1;)V", "beanName", "", "(Lorg/springframework/context/support/GenericApplicationContext;Ljava/lang/String;[Lorg/springframework/beans/factory/config/BeanDefinitionCustomizer;)V", "name", "(Lorg/springframework/context/support/GenericApplicationContext;Ljava/lang/String;[Lorg/springframework/beans/factory/config/BeanDefinitionCustomizer;Lkotlin/jvm/functions/Function1;)V", "spring-context"})
/*    */ public final class GenericApplicationContextExtensionsKt
/*    */ {
/*    */   /**
/*    */    * @deprecated
/*    */    */
/*    */   @Deprecated(message="Use regular apply method instead.", replaceWith=@ReplaceWith(imports={}, expression="GenericApplicationContext().apply(configure)"))
/*    */   @NotNull
/*    */   public static final GenericApplicationContext GenericApplicationContext(@NotNull Function1<? super GenericApplicationContext, Unit> configure)
/*    */   {
/* 78 */     Intrinsics.checkParameterIsNotNull(configure, "configure");GenericApplicationContext localGenericApplicationContext = new GenericApplicationContext();int i = 0;int j = 0;configure.invoke(localGenericApplicationContext);return localGenericApplicationContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\support\GenericApplicationContextExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */