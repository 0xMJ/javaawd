/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.Aware;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ParserStrategyUtils
/*     */ {
/*     */   static <T> T instantiateClass(Class<?> clazz, Class<T> assignableTo, Environment environment, ResourceLoader resourceLoader, BeanDefinitionRegistry registry)
/*     */   {
/*  58 */     Assert.notNull(clazz, "Class must not be null");
/*  59 */     Assert.isAssignable(assignableTo, clazz);
/*  60 */     if (clazz.isInterface()) {
/*  61 */       throw new BeanInstantiationException(clazz, "Specified class is an interface");
/*     */     }
/*     */     
/*  64 */     ClassLoader classLoader = (registry instanceof ConfigurableBeanFactory) ? ((ConfigurableBeanFactory)registry).getBeanClassLoader() : resourceLoader.getClassLoader();
/*  65 */     T instance = createInstance(clazz, environment, resourceLoader, registry, classLoader);
/*  66 */     invokeAwareMethods(instance, environment, resourceLoader, registry, classLoader);
/*  67 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static Object createInstance(Class<?> clazz, Environment environment, ResourceLoader resourceLoader, BeanDefinitionRegistry registry, @Nullable ClassLoader classLoader)
/*     */   {
/*  74 */     Constructor<?>[] constructors = clazz.getDeclaredConstructors();
/*  75 */     if ((constructors.length == 1) && (constructors[0].getParameterCount() > 0)) {
/*     */       try {
/*  77 */         Constructor<?> constructor = constructors[0];
/*  78 */         Object[] args = resolveArgs(constructor.getParameterTypes(), environment, resourceLoader, registry, classLoader);
/*     */         
/*  80 */         return BeanUtils.instantiateClass(constructor, args);
/*     */       }
/*     */       catch (Exception ex) {
/*  83 */         throw new BeanInstantiationException(clazz, "No suitable constructor found", ex);
/*     */       }
/*     */     }
/*  86 */     return BeanUtils.instantiateClass(clazz);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static Object[] resolveArgs(Class<?>[] parameterTypes, Environment environment, ResourceLoader resourceLoader, BeanDefinitionRegistry registry, @Nullable ClassLoader classLoader)
/*     */   {
/*  93 */     Object[] parameters = new Object[parameterTypes.length];
/*  94 */     for (int i = 0; i < parameterTypes.length; i++) {
/*  95 */       parameters[i] = resolveParameter(parameterTypes[i], environment, resourceLoader, registry, classLoader);
/*     */     }
/*     */     
/*  98 */     return parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private static Object resolveParameter(Class<?> parameterType, Environment environment, ResourceLoader resourceLoader, BeanDefinitionRegistry registry, @Nullable ClassLoader classLoader)
/*     */   {
/* 106 */     if (parameterType == Environment.class) {
/* 107 */       return environment;
/*     */     }
/* 109 */     if (parameterType == ResourceLoader.class) {
/* 110 */       return resourceLoader;
/*     */     }
/* 112 */     if (parameterType == BeanFactory.class) {
/* 113 */       return (registry instanceof BeanFactory) ? registry : null;
/*     */     }
/* 115 */     if (parameterType == ClassLoader.class) {
/* 116 */       return classLoader;
/*     */     }
/* 118 */     throw new IllegalStateException("Illegal method parameter type: " + parameterType.getName());
/*     */   }
/*     */   
/*     */ 
/*     */   private static void invokeAwareMethods(Object parserStrategyBean, Environment environment, ResourceLoader resourceLoader, BeanDefinitionRegistry registry, @Nullable ClassLoader classLoader)
/*     */   {
/* 124 */     if ((parserStrategyBean instanceof Aware)) {
/* 125 */       if (((parserStrategyBean instanceof BeanClassLoaderAware)) && (classLoader != null)) {
/* 126 */         ((BeanClassLoaderAware)parserStrategyBean).setBeanClassLoader(classLoader);
/*     */       }
/* 128 */       if (((parserStrategyBean instanceof BeanFactoryAware)) && ((registry instanceof BeanFactory))) {
/* 129 */         ((BeanFactoryAware)parserStrategyBean).setBeanFactory((BeanFactory)registry);
/*     */       }
/* 131 */       if ((parserStrategyBean instanceof EnvironmentAware)) {
/* 132 */         ((EnvironmentAware)parserStrategyBean).setEnvironment(environment);
/*     */       }
/* 134 */       if ((parserStrategyBean instanceof ResourceLoaderAware)) {
/* 135 */         ((ResourceLoaderAware)parserStrategyBean).setResourceLoader(resourceLoader);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\ParserStrategyUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */