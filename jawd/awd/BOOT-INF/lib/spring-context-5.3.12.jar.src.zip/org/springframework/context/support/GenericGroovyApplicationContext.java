/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import groovy.lang.GroovyObject;
/*     */ import groovy.lang.GroovySystem;
/*     */ import groovy.lang.MetaClass;
/*     */ import groovy.lang.MetaClassRegistry;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.groovy.GroovyBeanDefinitionReader;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericGroovyApplicationContext
/*     */   extends GenericApplicationContext
/*     */   implements GroovyObject
/*     */ {
/* 121 */   private final GroovyBeanDefinitionReader reader = new GroovyBeanDefinitionReader(this);
/*     */   
/* 123 */   private final BeanWrapper contextWrapper = new BeanWrapperImpl(this);
/*     */   
/* 125 */   private MetaClass metaClass = GroovySystem.getMetaClassRegistry().getMetaClass(getClass());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GenericGroovyApplicationContext() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GenericGroovyApplicationContext(Resource... resources)
/*     */   {
/* 141 */     load(resources);
/* 142 */     refresh();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GenericGroovyApplicationContext(String... resourceLocations)
/*     */   {
/* 151 */     load(resourceLocations);
/* 152 */     refresh();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GenericGroovyApplicationContext(Class<?> relativeClass, String... resourceNames)
/*     */   {
/* 163 */     load(relativeClass, resourceNames);
/* 164 */     refresh();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final GroovyBeanDefinitionReader getReader()
/*     */   {
/* 176 */     return this.reader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnvironment(ConfigurableEnvironment environment)
/*     */   {
/* 185 */     super.setEnvironment(environment);
/* 186 */     this.reader.setEnvironment(getEnvironment());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load(Resource... resources)
/*     */   {
/* 196 */     this.reader.loadBeanDefinitions(resources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load(String... resourceLocations)
/*     */   {
/* 206 */     this.reader.loadBeanDefinitions(resourceLocations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void load(Class<?> relativeClass, String... resourceNames)
/*     */   {
/* 218 */     Resource[] resources = new Resource[resourceNames.length];
/* 219 */     for (int i = 0; i < resourceNames.length; i++) {
/* 220 */       resources[i] = new ClassPathResource(resourceNames[i], relativeClass);
/*     */     }
/* 222 */     load(resources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMetaClass(MetaClass metaClass)
/*     */   {
/* 230 */     this.metaClass = metaClass;
/*     */   }
/*     */   
/*     */   public MetaClass getMetaClass()
/*     */   {
/* 235 */     return this.metaClass;
/*     */   }
/*     */   
/*     */   public Object invokeMethod(String name, Object args)
/*     */   {
/* 240 */     return this.metaClass.invokeMethod(this, name, args);
/*     */   }
/*     */   
/*     */   public void setProperty(String property, Object newValue)
/*     */   {
/* 245 */     if ((newValue instanceof BeanDefinition)) {
/* 246 */       registerBeanDefinition(property, (BeanDefinition)newValue);
/*     */     }
/*     */     else {
/* 249 */       this.metaClass.setProperty(this, property, newValue);
/*     */     }
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Object getProperty(String property)
/*     */   {
/* 256 */     if (containsBean(property)) {
/* 257 */       return getBean(property);
/*     */     }
/* 259 */     if (this.contextWrapper.isReadableProperty(property)) {
/* 260 */       return this.contextWrapper.getPropertyValue(property);
/*     */     }
/* 262 */     throw new NoSuchBeanDefinitionException(property);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\support\GenericGroovyApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */