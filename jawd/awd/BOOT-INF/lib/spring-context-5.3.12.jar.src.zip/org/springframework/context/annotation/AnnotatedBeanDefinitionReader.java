/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionCustomizer;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateQualifier;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotatedBeanDefinitionReader
/*     */ {
/*     */   private final BeanDefinitionRegistry registry;
/*  53 */   private BeanNameGenerator beanNameGenerator = AnnotationBeanNameGenerator.INSTANCE;
/*     */   
/*  55 */   private ScopeMetadataResolver scopeMetadataResolver = new AnnotationScopeMetadataResolver();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ConditionEvaluator conditionEvaluator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotatedBeanDefinitionReader(BeanDefinitionRegistry registry)
/*     */   {
/*  71 */     this(registry, getOrCreateEnvironment(registry));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotatedBeanDefinitionReader(BeanDefinitionRegistry registry, Environment environment)
/*     */   {
/*  84 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/*  85 */     Assert.notNull(environment, "Environment must not be null");
/*  86 */     this.registry = registry;
/*  87 */     this.conditionEvaluator = new ConditionEvaluator(registry, environment, null);
/*  88 */     AnnotationConfigUtils.registerAnnotationConfigProcessors(this.registry);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final BeanDefinitionRegistry getRegistry()
/*     */   {
/*  96 */     return this.registry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 106 */     this.conditionEvaluator = new ConditionEvaluator(this.registry, environment, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeanNameGenerator(@Nullable BeanNameGenerator beanNameGenerator)
/*     */   {
/* 114 */     this.beanNameGenerator = (beanNameGenerator != null ? beanNameGenerator : AnnotationBeanNameGenerator.INSTANCE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScopeMetadataResolver(@Nullable ScopeMetadataResolver scopeMetadataResolver)
/*     */   {
/* 123 */     this.scopeMetadataResolver = (scopeMetadataResolver != null ? scopeMetadataResolver : new AnnotationScopeMetadataResolver());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void register(Class<?>... componentClasses)
/*     */   {
/* 136 */     for (Class<?> componentClass : componentClasses) {
/* 137 */       registerBean(componentClass);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerBean(Class<?> beanClass)
/*     */   {
/* 147 */     doRegisterBean(beanClass, null, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerBean(Class<?> beanClass, @Nullable String name)
/*     */   {
/* 159 */     doRegisterBean(beanClass, name, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerBean(Class<?> beanClass, Class<? extends Annotation>... qualifiers)
/*     */   {
/* 171 */     doRegisterBean(beanClass, null, qualifiers, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerBean(Class<?> beanClass, @Nullable String name, Class<? extends Annotation>... qualifiers)
/*     */   {
/* 187 */     doRegisterBean(beanClass, name, qualifiers, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> void registerBean(Class<T> beanClass, @Nullable Supplier<T> supplier)
/*     */   {
/* 200 */     doRegisterBean(beanClass, null, null, supplier, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> void registerBean(Class<T> beanClass, @Nullable String name, @Nullable Supplier<T> supplier)
/*     */   {
/* 215 */     doRegisterBean(beanClass, name, null, supplier, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> void registerBean(Class<T> beanClass, @Nullable String name, @Nullable Supplier<T> supplier, BeanDefinitionCustomizer... customizers)
/*     */   {
/* 233 */     doRegisterBean(beanClass, name, null, supplier, customizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private <T> void doRegisterBean(Class<T> beanClass, @Nullable String name, @Nullable Class<? extends Annotation>[] qualifiers, @Nullable Supplier<T> supplier, @Nullable BeanDefinitionCustomizer[] customizers)
/*     */   {
/* 253 */     AnnotatedGenericBeanDefinition abd = new AnnotatedGenericBeanDefinition(beanClass);
/* 254 */     if (this.conditionEvaluator.shouldSkip(abd.getMetadata())) {
/* 255 */       return;
/*     */     }
/*     */     
/* 258 */     abd.setInstanceSupplier(supplier);
/* 259 */     ScopeMetadata scopeMetadata = this.scopeMetadataResolver.resolveScopeMetadata(abd);
/* 260 */     abd.setScope(scopeMetadata.getScopeName());
/* 261 */     String beanName = name != null ? name : this.beanNameGenerator.generateBeanName(abd, this.registry);
/*     */     
/* 263 */     AnnotationConfigUtils.processCommonDefinitionAnnotations(abd);
/* 264 */     if (qualifiers != null) {
/* 265 */       for (Class<? extends Annotation> qualifier : qualifiers) {
/* 266 */         if (Primary.class == qualifier) {
/* 267 */           abd.setPrimary(true);
/*     */         }
/* 269 */         else if (Lazy.class == qualifier) {
/* 270 */           abd.setLazyInit(true);
/*     */         }
/*     */         else {
/* 273 */           abd.addQualifier(new AutowireCandidateQualifier(qualifier));
/*     */         }
/*     */       }
/*     */     }
/* 277 */     if (customizers != null) {
/* 278 */       for (BeanDefinitionCustomizer customizer : customizers) {
/* 279 */         customizer.customize(abd);
/*     */       }
/*     */     }
/*     */     
/* 283 */     BeanDefinitionHolder definitionHolder = new BeanDefinitionHolder(abd, beanName);
/* 284 */     definitionHolder = AnnotationConfigUtils.applyScopedProxyMode(scopeMetadata, definitionHolder, this.registry);
/* 285 */     BeanDefinitionReaderUtils.registerBeanDefinition(definitionHolder, this.registry);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Environment getOrCreateEnvironment(BeanDefinitionRegistry registry)
/*     */   {
/* 294 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/* 295 */     if ((registry instanceof EnvironmentCapable)) {
/* 296 */       return ((EnvironmentCapable)registry).getEnvironment();
/*     */     }
/* 298 */     return new StandardEnvironment();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\AnnotatedBeanDefinitionReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */