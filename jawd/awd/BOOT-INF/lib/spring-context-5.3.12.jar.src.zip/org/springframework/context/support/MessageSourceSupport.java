/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MessageSourceSupport
/*     */ {
/*  44 */   private static final MessageFormat INVALID_MESSAGE_FORMAT = new MessageFormat("");
/*     */   
/*     */ 
/*  47 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  49 */   private boolean alwaysUseMessageFormat = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */   private final Map<String, Map<Locale, MessageFormat>> messageFormatsPerMessage = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlwaysUseMessageFormat(boolean alwaysUseMessageFormat)
/*     */   {
/*  75 */     this.alwaysUseMessageFormat = alwaysUseMessageFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isAlwaysUseMessageFormat()
/*     */   {
/*  83 */     return this.alwaysUseMessageFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String renderDefaultMessage(String defaultMessage, @Nullable Object[] args, Locale locale)
/*     */   {
/* 102 */     return formatMessage(defaultMessage, args, locale);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected String formatMessage(String msg, @Nullable Object[] args, Locale locale)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokevirtual 10	org/springframework/context/support/MessageSourceSupport:isAlwaysUseMessageFormat	()Z
/*     */     //   4: ifne +12 -> 16
/*     */     //   7: aload_2
/*     */     //   8: invokestatic 11	org/springframework/util/ObjectUtils:isEmpty	([Ljava/lang/Object;)Z
/*     */     //   11: ifeq +5 -> 16
/*     */     //   14: aload_1
/*     */     //   15: areturn
/*     */     //   16: aconst_null
/*     */     //   17: astore 4
/*     */     //   19: aload_0
/*     */     //   20: getfield 8	org/springframework/context/support/MessageSourceSupport:messageFormatsPerMessage	Ljava/util/Map;
/*     */     //   23: dup
/*     */     //   24: astore 5
/*     */     //   26: monitorenter
/*     */     //   27: aload_0
/*     */     //   28: getfield 8	org/springframework/context/support/MessageSourceSupport:messageFormatsPerMessage	Ljava/util/Map;
/*     */     //   31: aload_1
/*     */     //   32: invokeinterface 12 2 0
/*     */     //   37: checkcast 13	java/util/Map
/*     */     //   40: astore 6
/*     */     //   42: aload 6
/*     */     //   44: ifnull +19 -> 63
/*     */     //   47: aload 6
/*     */     //   49: aload_3
/*     */     //   50: invokeinterface 12 2 0
/*     */     //   55: checkcast 14	java/text/MessageFormat
/*     */     //   58: astore 4
/*     */     //   60: goto +25 -> 85
/*     */     //   63: new 6	java/util/HashMap
/*     */     //   66: dup
/*     */     //   67: invokespecial 7	java/util/HashMap:<init>	()V
/*     */     //   70: astore 6
/*     */     //   72: aload_0
/*     */     //   73: getfield 8	org/springframework/context/support/MessageSourceSupport:messageFormatsPerMessage	Ljava/util/Map;
/*     */     //   76: aload_1
/*     */     //   77: aload 6
/*     */     //   79: invokeinterface 15 3 0
/*     */     //   84: pop
/*     */     //   85: aload 4
/*     */     //   87: ifnonnull +42 -> 129
/*     */     //   90: aload_0
/*     */     //   91: aload_1
/*     */     //   92: aload_3
/*     */     //   93: invokevirtual 16	org/springframework/context/support/MessageSourceSupport:createMessageFormat	(Ljava/lang/String;Ljava/util/Locale;)Ljava/text/MessageFormat;
/*     */     //   96: astore 4
/*     */     //   98: goto +20 -> 118
/*     */     //   101: astore 7
/*     */     //   103: aload_0
/*     */     //   104: invokevirtual 10	org/springframework/context/support/MessageSourceSupport:isAlwaysUseMessageFormat	()Z
/*     */     //   107: ifeq +6 -> 113
/*     */     //   110: aload 7
/*     */     //   112: athrow
/*     */     //   113: getstatic 18	org/springframework/context/support/MessageSourceSupport:INVALID_MESSAGE_FORMAT	Ljava/text/MessageFormat;
/*     */     //   116: astore 4
/*     */     //   118: aload 6
/*     */     //   120: aload_3
/*     */     //   121: aload 4
/*     */     //   123: invokeinterface 15 3 0
/*     */     //   128: pop
/*     */     //   129: aload 5
/*     */     //   131: monitorexit
/*     */     //   132: goto +11 -> 143
/*     */     //   135: astore 8
/*     */     //   137: aload 5
/*     */     //   139: monitorexit
/*     */     //   140: aload 8
/*     */     //   142: athrow
/*     */     //   143: aload 4
/*     */     //   145: getstatic 18	org/springframework/context/support/MessageSourceSupport:INVALID_MESSAGE_FORMAT	Ljava/text/MessageFormat;
/*     */     //   148: if_acmpne +5 -> 153
/*     */     //   151: aload_1
/*     */     //   152: areturn
/*     */     //   153: aload 4
/*     */     //   155: dup
/*     */     //   156: astore 5
/*     */     //   158: monitorenter
/*     */     //   159: aload 4
/*     */     //   161: aload_0
/*     */     //   162: aload_2
/*     */     //   163: aload_3
/*     */     //   164: invokevirtual 19	org/springframework/context/support/MessageSourceSupport:resolveArguments	([Ljava/lang/Object;Ljava/util/Locale;)[Ljava/lang/Object;
/*     */     //   167: invokevirtual 20	java/text/MessageFormat:format	(Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   170: aload 5
/*     */     //   172: monitorexit
/*     */     //   173: areturn
/*     */     //   174: astore 9
/*     */     //   176: aload 5
/*     */     //   178: monitorexit
/*     */     //   179: aload 9
/*     */     //   181: athrow
/*     */     // Line number table:
/*     */     //   Java source line #116	-> byte code offset #0
/*     */     //   Java source line #117	-> byte code offset #14
/*     */     //   Java source line #119	-> byte code offset #16
/*     */     //   Java source line #120	-> byte code offset #19
/*     */     //   Java source line #121	-> byte code offset #27
/*     */     //   Java source line #122	-> byte code offset #42
/*     */     //   Java source line #123	-> byte code offset #47
/*     */     //   Java source line #126	-> byte code offset #63
/*     */     //   Java source line #127	-> byte code offset #72
/*     */     //   Java source line #129	-> byte code offset #85
/*     */     //   Java source line #131	-> byte code offset #90
/*     */     //   Java source line #141	-> byte code offset #98
/*     */     //   Java source line #133	-> byte code offset #101
/*     */     //   Java source line #136	-> byte code offset #103
/*     */     //   Java source line #137	-> byte code offset #110
/*     */     //   Java source line #140	-> byte code offset #113
/*     */     //   Java source line #142	-> byte code offset #118
/*     */     //   Java source line #144	-> byte code offset #129
/*     */     //   Java source line #145	-> byte code offset #143
/*     */     //   Java source line #146	-> byte code offset #151
/*     */     //   Java source line #148	-> byte code offset #153
/*     */     //   Java source line #149	-> byte code offset #159
/*     */     //   Java source line #150	-> byte code offset #174
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	182	0	this	MessageSourceSupport
/*     */     //   0	182	1	msg	String
/*     */     //   0	182	2	args	Object[]
/*     */     //   0	182	3	locale	Locale
/*     */     //   17	143	4	messageFormat	MessageFormat
/*     */     //   24	114	5	Ljava/lang/Object;	Object
/*     */     //   156	21	5	Ljava/lang/Object;	Object
/*     */     //   40	79	6	messageFormatsPerLocale	Map<Locale, MessageFormat>
/*     */     //   101	10	7	ex	IllegalArgumentException
/*     */     //   135	6	8	localObject1	Object
/*     */     //   174	6	9	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   90	98	101	java/lang/IllegalArgumentException
/*     */     //   27	132	135	finally
/*     */     //   135	140	135	finally
/*     */     //   159	173	174	finally
/*     */     //   174	179	174	finally
/*     */   }
/*     */   
/*     */   protected MessageFormat createMessageFormat(String msg, Locale locale)
/*     */   {
/* 160 */     return new MessageFormat(msg, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object[] resolveArguments(@Nullable Object[] args, Locale locale)
/*     */   {
/* 172 */     return args != null ? args : new Object[0];
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\support\MessageSourceSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */