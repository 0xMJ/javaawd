/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import org.springframework.beans.factory.parsing.Location;
/*    */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*    */ import org.springframework.core.type.MethodMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class ConfigurationMethod
/*    */ {
/*    */   protected final MethodMetadata metadata;
/*    */   protected final ConfigurationClass configurationClass;
/*    */   
/*    */   public ConfigurationMethod(MethodMetadata metadata, ConfigurationClass configurationClass)
/*    */   {
/* 37 */     this.metadata = metadata;
/* 38 */     this.configurationClass = configurationClass;
/*    */   }
/*    */   
/*    */   public MethodMetadata getMetadata()
/*    */   {
/* 43 */     return this.metadata;
/*    */   }
/*    */   
/*    */   public ConfigurationClass getConfigurationClass() {
/* 47 */     return this.configurationClass;
/*    */   }
/*    */   
/*    */   public Location getResourceLocation() {
/* 51 */     return new Location(this.configurationClass.getResource(), this.metadata);
/*    */   }
/*    */   
/*    */ 
/*    */   void validate(ProblemReporter problemReporter) {}
/*    */   
/*    */   public String toString()
/*    */   {
/* 59 */     return String.format("[%s:name=%s,declaringClass=%s]", new Object[] {
/* 60 */       getClass().getSimpleName(), getMetadata().getMethodName(), getMetadata().getDeclaringClassName() });
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\ConfigurationMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */