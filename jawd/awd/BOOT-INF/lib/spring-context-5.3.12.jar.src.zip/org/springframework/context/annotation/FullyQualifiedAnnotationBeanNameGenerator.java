/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FullyQualifiedAnnotationBeanNameGenerator
/*    */   extends AnnotationBeanNameGenerator
/*    */ {
/* 51 */   public static final FullyQualifiedAnnotationBeanNameGenerator INSTANCE = new FullyQualifiedAnnotationBeanNameGenerator();
/*    */   
/*    */ 
/*    */ 
/*    */   protected String buildDefaultBeanName(BeanDefinition definition)
/*    */   {
/* 57 */     String beanClassName = definition.getBeanClassName();
/* 58 */     Assert.state(beanClassName != null, "No bean class name set");
/* 59 */     return beanClassName;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\FullyQualifiedAnnotationBeanNameGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */