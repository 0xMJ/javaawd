/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.env.Profiles;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ProfileCondition
/*    */   implements Condition
/*    */ {
/*    */   public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 36 */     MultiValueMap<String, Object> attrs = metadata.getAllAnnotationAttributes(Profile.class.getName());
/* 37 */     if (attrs != null) {
/* 38 */       for (Object value : (List)attrs.get("value")) {
/* 39 */         if (context.getEnvironment().acceptsProfiles(Profiles.of((String[])value))) {
/* 40 */           return true;
/*    */         }
/*    */       }
/* 43 */       return false;
/*    */     }
/* 45 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\ProfileCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */