package org.springframework.context;

import org.springframework.beans.factory.Aware;
import org.springframework.core.io.ResourceLoader;

public abstract interface ResourceLoaderAware
  extends Aware
{
  public abstract void setResourceLoader(ResourceLoader paramResourceLoader);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\ResourceLoaderAware.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */