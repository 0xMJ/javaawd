/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EventExpressionRootObject
/*    */ {
/*    */   private final ApplicationEvent event;
/*    */   private final Object[] args;
/*    */   
/*    */   public EventExpressionRootObject(ApplicationEvent event, Object[] args)
/*    */   {
/* 34 */     this.event = event;
/* 35 */     this.args = args;
/*    */   }
/*    */   
/*    */   public ApplicationEvent getEvent() {
/* 39 */     return this.event;
/*    */   }
/*    */   
/*    */   public Object[] getArgs() {
/* 43 */     return this.args;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\event\EventExpressionRootObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */