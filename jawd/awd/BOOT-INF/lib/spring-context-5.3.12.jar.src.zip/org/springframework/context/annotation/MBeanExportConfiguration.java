/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.jmx.MBeanServerNotFoundException;
/*     */ import org.springframework.jmx.export.annotation.AnnotationMBeanExporter;
/*     */ import org.springframework.jmx.support.RegistrationPolicy;
/*     */ import org.springframework.jmx.support.WebSphereMBeanServerFactoryBean;
/*     */ import org.springframework.jndi.JndiLocatorDelegate;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods=false)
/*     */ @Role(2)
/*     */ public class MBeanExportConfiguration
/*     */   implements ImportAware, EnvironmentAware, BeanFactoryAware
/*     */ {
/*     */   private static final String MBEAN_EXPORTER_BEAN_NAME = "mbeanExporter";
/*     */   @Nullable
/*     */   private AnnotationAttributes enableMBeanExport;
/*     */   @Nullable
/*     */   private Environment environment;
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */   
/*     */   public void setImportMetadata(AnnotationMetadata importMetadata)
/*     */   {
/*  70 */     Map<String, Object> map = importMetadata.getAnnotationAttributes(EnableMBeanExport.class.getName());
/*  71 */     this.enableMBeanExport = AnnotationAttributes.fromMap(map);
/*  72 */     if (this.enableMBeanExport == null)
/*     */     {
/*  74 */       throw new IllegalArgumentException("@EnableMBeanExport is not present on importing class " + importMetadata.getClassName());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/*  80 */     this.environment = environment;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  85 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */   @Bean(name={"mbeanExporter"})
/*     */   @Role(2)
/*     */   public AnnotationMBeanExporter mbeanExporter()
/*     */   {
/*  92 */     AnnotationMBeanExporter exporter = new AnnotationMBeanExporter();
/*  93 */     Assert.state(this.enableMBeanExport != null, "No EnableMBeanExport annotation found");
/*  94 */     setupDomain(exporter, this.enableMBeanExport);
/*  95 */     setupServer(exporter, this.enableMBeanExport);
/*  96 */     setupRegistrationPolicy(exporter, this.enableMBeanExport);
/*  97 */     return exporter;
/*     */   }
/*     */   
/*     */   private void setupDomain(AnnotationMBeanExporter exporter, AnnotationAttributes enableMBeanExport) {
/* 101 */     String defaultDomain = enableMBeanExport.getString("defaultDomain");
/* 102 */     if ((StringUtils.hasLength(defaultDomain)) && (this.environment != null)) {
/* 103 */       defaultDomain = this.environment.resolvePlaceholders(defaultDomain);
/*     */     }
/* 105 */     if (StringUtils.hasText(defaultDomain)) {
/* 106 */       exporter.setDefaultDomain(defaultDomain);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setupServer(AnnotationMBeanExporter exporter, AnnotationAttributes enableMBeanExport) {
/* 111 */     String server = enableMBeanExport.getString("server");
/* 112 */     if ((StringUtils.hasLength(server)) && (this.environment != null)) {
/* 113 */       server = this.environment.resolvePlaceholders(server);
/*     */     }
/* 115 */     if (StringUtils.hasText(server)) {
/* 116 */       Assert.state(this.beanFactory != null, "No BeanFactory set");
/* 117 */       exporter.setServer((MBeanServer)this.beanFactory.getBean(server, MBeanServer.class));
/*     */     }
/*     */     else {
/* 120 */       SpecificPlatform specificPlatform = SpecificPlatform.get();
/* 121 */       if (specificPlatform != null) {
/* 122 */         MBeanServer mbeanServer = specificPlatform.getMBeanServer();
/* 123 */         if (mbeanServer != null) {
/* 124 */           exporter.setServer(mbeanServer);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void setupRegistrationPolicy(AnnotationMBeanExporter exporter, AnnotationAttributes enableMBeanExport) {
/* 131 */     RegistrationPolicy registrationPolicy = (RegistrationPolicy)enableMBeanExport.getEnum("registration");
/* 132 */     exporter.setRegistrationPolicy(registrationPolicy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract enum SpecificPlatform
/*     */   {
/* 144 */     WEBLOGIC("weblogic.management.Helper"), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 159 */     WEBSPHERE("com.ibm.websphere.management.AdminServiceFactory");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private final String identifyingClass;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private SpecificPlatform(String identifyingClass)
/*     */     {
/* 171 */       this.identifyingClass = identifyingClass;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public abstract MBeanServer getMBeanServer();
/*     */     
/*     */     @Nullable
/*     */     public static SpecificPlatform get() {
/* 179 */       ClassLoader classLoader = MBeanExportConfiguration.class.getClassLoader();
/* 180 */       for (SpecificPlatform environment : values()) {
/* 181 */         if (ClassUtils.isPresent(environment.identifyingClass, classLoader)) {
/* 182 */           return environment;
/*     */         }
/*     */       }
/* 185 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\MBeanExportConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */