/*     */ package org.springframework.context.expression;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CachedExpressionEvaluator
/*     */ {
/*     */   private final SpelExpressionParser parser;
/*  41 */   private final ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CachedExpressionEvaluator(SpelExpressionParser parser)
/*     */   {
/*  48 */     Assert.notNull(parser, "SpelExpressionParser must not be null");
/*  49 */     this.parser = parser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected CachedExpressionEvaluator()
/*     */   {
/*  56 */     this(new SpelExpressionParser());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SpelExpressionParser getParser()
/*     */   {
/*  64 */     return this.parser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ParameterNameDiscoverer getParameterNameDiscoverer()
/*     */   {
/*  72 */     return this.parameterNameDiscoverer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Expression getExpression(Map<ExpressionKey, Expression> cache, AnnotatedElementKey elementKey, String expression)
/*     */   {
/*  86 */     ExpressionKey expressionKey = createKey(elementKey, expression);
/*  87 */     Expression expr = (Expression)cache.get(expressionKey);
/*  88 */     if (expr == null) {
/*  89 */       expr = getParser().parseExpression(expression);
/*  90 */       cache.put(expressionKey, expr);
/*     */     }
/*  92 */     return expr;
/*     */   }
/*     */   
/*     */   private ExpressionKey createKey(AnnotatedElementKey elementKey, String expression) {
/*  96 */     return new ExpressionKey(elementKey, expression);
/*     */   }
/*     */   
/*     */ 
/*     */   protected static class ExpressionKey
/*     */     implements Comparable<ExpressionKey>
/*     */   {
/*     */     private final AnnotatedElementKey element;
/*     */     
/*     */     private final String expression;
/*     */     
/*     */ 
/*     */     protected ExpressionKey(AnnotatedElementKey element, String expression)
/*     */     {
/* 110 */       Assert.notNull(element, "AnnotatedElementKey must not be null");
/* 111 */       Assert.notNull(expression, "Expression must not be null");
/* 112 */       this.element = element;
/* 113 */       this.expression = expression;
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other)
/*     */     {
/* 118 */       if (this == other) {
/* 119 */         return true;
/*     */       }
/* 121 */       if (!(other instanceof ExpressionKey)) {
/* 122 */         return false;
/*     */       }
/* 124 */       ExpressionKey otherKey = (ExpressionKey)other;
/* 125 */       return (this.element.equals(otherKey.element)) && 
/* 126 */         (ObjectUtils.nullSafeEquals(this.expression, otherKey.expression));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 131 */       return this.element.hashCode() * 29 + this.expression.hashCode();
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 136 */       return this.element + " with expression \"" + this.expression + "\"";
/*     */     }
/*     */     
/*     */     public int compareTo(ExpressionKey other)
/*     */     {
/* 141 */       int result = this.element.toString().compareTo(other.element.toString());
/* 142 */       if (result == 0) {
/* 143 */         result = this.expression.compareTo(other.expression);
/*     */       }
/* 145 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\expression\CachedExpressionEvaluator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */