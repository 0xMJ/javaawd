/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import kotlin.Deprecated;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.ReplaceWith;
/*    */ import kotlin.Unit;
/*    */ import kotlin.jvm.functions.Function1;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv={1, 1, 18}, bv={1, 0, 3}, k=2, d1={"\000\026\n\000\n\002\030\002\n\000\n\002\030\002\n\002\020\002\n\002\030\002\n\000\032!\020\000\032\0020\0012\027\020\002\032\023\022\004\022\0020\001\022\004\022\0020\0040\003¢\006\002\b\005H\007¨\006\006"}, d2={"AnnotationConfigApplicationContext", "Lorg/springframework/context/annotation/AnnotationConfigApplicationContext;", "configure", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "spring-context"})
/*    */ public final class AnnotationConfigApplicationContextExtensionsKt
/*    */ {
/*    */   /**
/*    */    * @deprecated
/*    */    */
/*    */   @Deprecated(message="Use regular apply method instead.", replaceWith=@ReplaceWith(imports={}, expression="AnnotationConfigApplicationContext().apply(configure)"))
/*    */   @NotNull
/*    */   public static final AnnotationConfigApplicationContext AnnotationConfigApplicationContext(@NotNull Function1<? super AnnotationConfigApplicationContext, Unit> configure)
/*    */   {
/* 28 */     Intrinsics.checkParameterIsNotNull(configure, "configure");AnnotationConfigApplicationContext localAnnotationConfigApplicationContext = new AnnotationConfigApplicationContext();int i = 0;int j = 0;configure.invoke(localAnnotationConfigApplicationContext);return localAnnotationConfigApplicationContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\AnnotationConfigApplicationContextExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */