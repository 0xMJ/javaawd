package org.springframework.context.event;

import java.util.function.Predicate;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.ResolvableType;
import org.springframework.lang.Nullable;

public abstract interface ApplicationEventMulticaster
{
  public abstract void addApplicationListener(ApplicationListener<?> paramApplicationListener);
  
  public abstract void addApplicationListenerBean(String paramString);
  
  public abstract void removeApplicationListener(ApplicationListener<?> paramApplicationListener);
  
  public abstract void removeApplicationListenerBean(String paramString);
  
  public abstract void removeApplicationListeners(Predicate<ApplicationListener<?>> paramPredicate);
  
  public abstract void removeApplicationListenerBeans(Predicate<String> paramPredicate);
  
  public abstract void removeAllListeners();
  
  public abstract void multicastEvent(ApplicationEvent paramApplicationEvent);
  
  public abstract void multicastEvent(ApplicationEvent paramApplicationEvent, @Nullable ResolvableType paramResolvableType);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\event\ApplicationEventMulticaster.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */