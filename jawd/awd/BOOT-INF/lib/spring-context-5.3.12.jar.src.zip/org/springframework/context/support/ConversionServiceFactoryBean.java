/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.support.ConversionServiceFactory;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.core.convert.support.GenericConversionService;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConversionServiceFactoryBean
/*     */   implements FactoryBean<ConversionService>, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private Set<?> converters;
/*     */   @Nullable
/*     */   private GenericConversionService conversionService;
/*     */   
/*     */   public void setConverters(Set<?> converters)
/*     */   {
/*  67 */     this.converters = converters;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */   {
/*  72 */     this.conversionService = createConversionService();
/*  73 */     ConversionServiceFactory.registerConverters(this.converters, this.conversionService);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected GenericConversionService createConversionService()
/*     */   {
/*  83 */     return new DefaultConversionService();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public ConversionService getObject()
/*     */   {
/*  92 */     return this.conversionService;
/*     */   }
/*     */   
/*     */   public Class<? extends ConversionService> getObjectType()
/*     */   {
/*  97 */     return GenericConversionService.class;
/*     */   }
/*     */   
/*     */   public boolean isSingleton()
/*     */   {
/* 102 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\support\ConversionServiceFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */