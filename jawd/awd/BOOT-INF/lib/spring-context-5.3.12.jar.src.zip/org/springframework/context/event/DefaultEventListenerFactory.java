/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultEventListenerFactory
/*    */   implements EventListenerFactory, Ordered
/*    */ {
/* 36 */   private int order = Integer.MAX_VALUE;
/*    */   
/*    */   public void setOrder(int order)
/*    */   {
/* 40 */     this.order = order;
/*    */   }
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 45 */     return this.order;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean supportsMethod(Method method)
/*    */   {
/* 51 */     return true;
/*    */   }
/*    */   
/*    */   public ApplicationListener<?> createApplicationListener(String beanName, Class<?> type, Method method)
/*    */   {
/* 56 */     return new ApplicationListenerMethodAdapter(beanName, type, method);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\event\DefaultEventListenerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */