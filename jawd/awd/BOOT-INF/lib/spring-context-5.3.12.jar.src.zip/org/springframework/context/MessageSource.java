package org.springframework.context;

import java.util.Locale;
import org.springframework.lang.Nullable;

public abstract interface MessageSource
{
  @Nullable
  public abstract String getMessage(String paramString1, @Nullable Object[] paramArrayOfObject, @Nullable String paramString2, Locale paramLocale);
  
  public abstract String getMessage(String paramString, @Nullable Object[] paramArrayOfObject, Locale paramLocale)
    throws NoSuchMessageException;
  
  public abstract String getMessage(MessageSourceResolvable paramMessageSourceResolvable, Locale paramLocale)
    throws NoSuchMessageException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\MessageSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */