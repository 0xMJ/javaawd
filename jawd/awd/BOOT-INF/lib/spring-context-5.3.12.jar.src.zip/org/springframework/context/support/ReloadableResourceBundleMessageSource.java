/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.ResourcePropertiesPersister;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.PropertiesPersister;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReloadableResourceBundleMessageSource
/*     */   extends AbstractResourceBasedMessageSource
/*     */   implements ResourceLoaderAware
/*     */ {
/*     */   private static final String PROPERTIES_SUFFIX = ".properties";
/*     */   private static final String XML_SUFFIX = ".xml";
/*     */   @Nullable
/*     */   private Properties fileEncodings;
/*  99 */   private boolean concurrentRefresh = true;
/*     */   
/* 101 */   private PropertiesPersister propertiesPersister = ResourcePropertiesPersister.INSTANCE;
/*     */   
/* 103 */   private ResourceLoader resourceLoader = new DefaultResourceLoader();
/*     */   
/*     */ 
/* 106 */   private final ConcurrentMap<String, Map<Locale, List<String>>> cachedFilenames = new ConcurrentHashMap();
/*     */   
/*     */ 
/* 109 */   private final ConcurrentMap<String, PropertiesHolder> cachedProperties = new ConcurrentHashMap();
/*     */   
/*     */ 
/* 112 */   private final ConcurrentMap<Locale, PropertiesHolder> cachedMergedProperties = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileEncodings(Properties fileEncodings)
/*     */   {
/* 126 */     this.fileEncodings = fileEncodings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConcurrentRefresh(boolean concurrentRefresh)
/*     */   {
/* 141 */     this.concurrentRefresh = concurrentRefresh;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPropertiesPersister(@Nullable PropertiesPersister propertiesPersister)
/*     */   {
/* 150 */     this.propertiesPersister = (propertiesPersister != null ? propertiesPersister : ResourcePropertiesPersister.INSTANCE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceLoader(@Nullable ResourceLoader resourceLoader)
/*     */   {
/* 165 */     this.resourceLoader = (resourceLoader != null ? resourceLoader : new DefaultResourceLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String resolveCodeWithoutArguments(String code, Locale locale)
/*     */   {
/*     */     PropertiesHolder propHolder;
/*     */     
/*     */ 
/* 175 */     if (getCacheMillis() < 0L) {
/* 176 */       propHolder = getMergedProperties(locale);
/* 177 */       String result = propHolder.getProperty(code);
/* 178 */       if (result != null) {
/* 179 */         return result;
/*     */       }
/*     */     }
/*     */     else {
/* 183 */       for (String basename : getBasenameSet()) {
/* 184 */         List<String> filenames = calculateAllFilenames(basename, locale);
/* 185 */         for (String filename : filenames) {
/* 186 */           PropertiesHolder propHolder = getProperties(filename);
/* 187 */           String result = propHolder.getProperty(code);
/* 188 */           if (result != null) {
/* 189 */             return result;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 194 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected MessageFormat resolveCode(String code, Locale locale)
/*     */   {
/*     */     PropertiesHolder propHolder;
/*     */     
/* 204 */     if (getCacheMillis() < 0L) {
/* 205 */       propHolder = getMergedProperties(locale);
/* 206 */       MessageFormat result = propHolder.getMessageFormat(code, locale);
/* 207 */       if (result != null) {
/* 208 */         return result;
/*     */       }
/*     */     }
/*     */     else {
/* 212 */       for (String basename : getBasenameSet()) {
/* 213 */         List<String> filenames = calculateAllFilenames(basename, locale);
/* 214 */         for (String filename : filenames) {
/* 215 */           PropertiesHolder propHolder = getProperties(filename);
/* 216 */           MessageFormat result = propHolder.getMessageFormat(code, locale);
/* 217 */           if (result != null) {
/* 218 */             return result;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 223 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PropertiesHolder getMergedProperties(Locale locale)
/*     */   {
/* 236 */     PropertiesHolder mergedHolder = (PropertiesHolder)this.cachedMergedProperties.get(locale);
/* 237 */     if (mergedHolder != null) {
/* 238 */       return mergedHolder;
/*     */     }
/*     */     
/* 241 */     Properties mergedProps = newProperties();
/* 242 */     long latestTimestamp = -1L;
/* 243 */     String[] basenames = StringUtils.toStringArray(getBasenameSet());
/* 244 */     for (int i = basenames.length - 1; i >= 0; i--) {
/* 245 */       List<String> filenames = calculateAllFilenames(basenames[i], locale);
/* 246 */       for (int j = filenames.size() - 1; j >= 0; j--) {
/* 247 */         String filename = (String)filenames.get(j);
/* 248 */         PropertiesHolder propHolder = getProperties(filename);
/* 249 */         if (propHolder.getProperties() != null) {
/* 250 */           mergedProps.putAll(propHolder.getProperties());
/* 251 */           if (propHolder.getFileTimestamp() > latestTimestamp) {
/* 252 */             latestTimestamp = propHolder.getFileTimestamp();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 258 */     mergedHolder = new PropertiesHolder(mergedProps, latestTimestamp);
/* 259 */     PropertiesHolder existing = (PropertiesHolder)this.cachedMergedProperties.putIfAbsent(locale, mergedHolder);
/* 260 */     if (existing != null) {
/* 261 */       mergedHolder = existing;
/*     */     }
/* 263 */     return mergedHolder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<String> calculateAllFilenames(String basename, Locale locale)
/*     */   {
/* 277 */     Map<Locale, List<String>> localeMap = (Map)this.cachedFilenames.get(basename);
/* 278 */     if (localeMap != null) {
/* 279 */       List<String> filenames = (List)localeMap.get(locale);
/* 280 */       if (filenames != null) {
/* 281 */         return filenames;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 286 */     List<String> filenames = new ArrayList(7);
/* 287 */     filenames.addAll(calculateFilenamesForLocale(basename, locale));
/*     */     
/*     */ 
/* 290 */     Locale defaultLocale = getDefaultLocale();
/* 291 */     if ((defaultLocale != null) && (!defaultLocale.equals(locale))) {
/* 292 */       List<String> fallbackFilenames = calculateFilenamesForLocale(basename, defaultLocale);
/* 293 */       for (String fallbackFilename : fallbackFilenames) {
/* 294 */         if (!filenames.contains(fallbackFilename))
/*     */         {
/* 296 */           filenames.add(fallbackFilename);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 302 */     filenames.add(basename);
/*     */     
/* 304 */     if (localeMap == null) {
/* 305 */       localeMap = new ConcurrentHashMap();
/* 306 */       Map<Locale, List<String>> existing = (Map)this.cachedFilenames.putIfAbsent(basename, localeMap);
/* 307 */       if (existing != null) {
/* 308 */         localeMap = existing;
/*     */       }
/*     */     }
/* 311 */     localeMap.put(locale, filenames);
/* 312 */     return filenames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<String> calculateFilenamesForLocale(String basename, Locale locale)
/*     */   {
/* 326 */     List<String> result = new ArrayList(3);
/* 327 */     String language = locale.getLanguage();
/* 328 */     String country = locale.getCountry();
/* 329 */     String variant = locale.getVariant();
/* 330 */     StringBuilder temp = new StringBuilder(basename);
/*     */     
/* 332 */     temp.append('_');
/* 333 */     if (language.length() > 0) {
/* 334 */       temp.append(language);
/* 335 */       result.add(0, temp.toString());
/*     */     }
/*     */     
/* 338 */     temp.append('_');
/* 339 */     if (country.length() > 0) {
/* 340 */       temp.append(country);
/* 341 */       result.add(0, temp.toString());
/*     */     }
/*     */     
/* 344 */     if ((variant.length() > 0) && ((language.length() > 0) || (country.length() > 0))) {
/* 345 */       temp.append('_').append(variant);
/* 346 */       result.add(0, temp.toString());
/*     */     }
/*     */     
/* 349 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PropertiesHolder getProperties(String filename)
/*     */   {
/* 360 */     PropertiesHolder propHolder = (PropertiesHolder)this.cachedProperties.get(filename);
/* 361 */     long originalTimestamp = -2L;
/*     */     
/* 363 */     if (propHolder != null) {
/* 364 */       originalTimestamp = propHolder.getRefreshTimestamp();
/* 365 */       if ((originalTimestamp == -1L) || (originalTimestamp > System.currentTimeMillis() - getCacheMillis()))
/*     */       {
/* 367 */         return propHolder;
/*     */       }
/*     */     }
/*     */     else {
/* 371 */       propHolder = new PropertiesHolder();
/* 372 */       PropertiesHolder existingHolder = (PropertiesHolder)this.cachedProperties.putIfAbsent(filename, propHolder);
/* 373 */       if (existingHolder != null) {
/* 374 */         propHolder = existingHolder;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 379 */     if ((this.concurrentRefresh) && (propHolder.getRefreshTimestamp() >= 0L))
/*     */     {
/* 381 */       if (!propHolder.refreshLock.tryLock())
/*     */       {
/*     */ 
/* 384 */         return propHolder;
/*     */       }
/*     */     }
/*     */     else {
/* 388 */       propHolder.refreshLock.lock();
/*     */     }
/*     */     try {
/* 391 */       PropertiesHolder existingHolder = (PropertiesHolder)this.cachedProperties.get(filename);
/* 392 */       PropertiesHolder localPropertiesHolder1; if ((existingHolder != null) && (existingHolder.getRefreshTimestamp() > originalTimestamp)) {
/* 393 */         return existingHolder;
/*     */       }
/* 395 */       return refreshProperties(filename, propHolder);
/*     */     }
/*     */     finally {
/* 398 */       propHolder.refreshLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PropertiesHolder refreshProperties(String filename, @Nullable PropertiesHolder propHolder)
/*     */   {
/* 410 */     long refreshTimestamp = getCacheMillis() < 0L ? -1L : System.currentTimeMillis();
/*     */     
/* 412 */     Resource resource = this.resourceLoader.getResource(filename + ".properties");
/* 413 */     if (!resource.exists()) {
/* 414 */       resource = this.resourceLoader.getResource(filename + ".xml");
/*     */     }
/*     */     
/* 417 */     if (resource.exists()) {
/* 418 */       long fileTimestamp = -1L;
/* 419 */       if (getCacheMillis() >= 0L) {
/*     */         try
/*     */         {
/* 422 */           fileTimestamp = resource.lastModified();
/* 423 */           if ((propHolder != null) && (propHolder.getFileTimestamp() == fileTimestamp)) {
/* 424 */             if (this.logger.isDebugEnabled()) {
/* 425 */               this.logger.debug("Re-caching properties for filename [" + filename + "] - file hasn't been modified");
/*     */             }
/* 427 */             propHolder.setRefreshTimestamp(refreshTimestamp);
/* 428 */             return propHolder;
/*     */           }
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/* 433 */           if (this.logger.isDebugEnabled()) {
/* 434 */             this.logger.debug(resource + " could not be resolved in the file system - assuming that it hasn't changed", ex);
/*     */           }
/* 436 */           fileTimestamp = -1L;
/*     */         }
/*     */       }
/*     */       try {
/* 440 */         Properties props = loadProperties(resource, filename);
/* 441 */         propHolder = new PropertiesHolder(props, fileTimestamp);
/*     */       }
/*     */       catch (IOException ex) {
/* 444 */         if (this.logger.isWarnEnabled()) {
/* 445 */           this.logger.warn("Could not parse properties file [" + resource.getFilename() + "]", ex);
/*     */         }
/*     */         
/* 448 */         propHolder = new PropertiesHolder();
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 454 */       if (this.logger.isDebugEnabled()) {
/* 455 */         this.logger.debug("No properties file found for [" + filename + "] - neither plain properties nor XML");
/*     */       }
/*     */       
/* 458 */       propHolder = new PropertiesHolder();
/*     */     }
/*     */     
/* 461 */     propHolder.setRefreshTimestamp(refreshTimestamp);
/* 462 */     this.cachedProperties.put(filename, propHolder);
/* 463 */     return propHolder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Properties loadProperties(Resource resource, String filename)
/*     */     throws IOException
/*     */   {
/* 474 */     Properties props = newProperties();
/* 475 */     InputStream is = resource.getInputStream();Throwable localThrowable3 = null;
/* 476 */     try { String resourceFilename = resource.getFilename();
/* 477 */       String encoding; if ((resourceFilename != null) && (resourceFilename.endsWith(".xml"))) {
/* 478 */         if (this.logger.isDebugEnabled()) {
/* 479 */           this.logger.debug("Loading properties [" + resource.getFilename() + "]");
/*     */         }
/* 481 */         this.propertiesPersister.loadFromXml(props, is);
/*     */       }
/*     */       else {
/* 484 */         encoding = null;
/* 485 */         if (this.fileEncodings != null) {
/* 486 */           encoding = this.fileEncodings.getProperty(filename);
/*     */         }
/* 488 */         if (encoding == null) {
/* 489 */           encoding = getDefaultEncoding();
/*     */         }
/* 491 */         if (encoding != null) {
/* 492 */           if (this.logger.isDebugEnabled()) {
/* 493 */             this.logger.debug("Loading properties [" + resource.getFilename() + "] with encoding '" + encoding + "'");
/*     */           }
/* 495 */           this.propertiesPersister.load(props, new InputStreamReader(is, encoding));
/*     */         }
/*     */         else {
/* 498 */           if (this.logger.isDebugEnabled()) {
/* 499 */             this.logger.debug("Loading properties [" + resource.getFilename() + "]");
/*     */           }
/* 501 */           this.propertiesPersister.load(props, is);
/*     */         }
/*     */       }
/* 504 */       return props;
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 475 */       localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 505 */       if (is != null) { if (localThrowable3 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else { is.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Properties newProperties()
/*     */   {
/* 518 */     return new Properties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearCache()
/*     */   {
/* 527 */     this.logger.debug("Clearing entire resource bundle cache");
/* 528 */     this.cachedProperties.clear();
/* 529 */     this.cachedMergedProperties.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearCacheIncludingAncestors()
/*     */   {
/* 537 */     clearCache();
/* 538 */     if ((getParentMessageSource() instanceof ReloadableResourceBundleMessageSource)) {
/* 539 */       ((ReloadableResourceBundleMessageSource)getParentMessageSource()).clearCacheIncludingAncestors();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 546 */     return getClass().getName() + ": basenames=" + getBasenameSet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected class PropertiesHolder
/*     */   {
/*     */     @Nullable
/*     */     private final Properties properties;
/*     */     
/*     */ 
/*     */ 
/*     */     private final long fileTimestamp;
/*     */     
/*     */ 
/*     */ 
/* 563 */     private volatile long refreshTimestamp = -2L;
/*     */     
/* 565 */     private final ReentrantLock refreshLock = new ReentrantLock();
/*     */     
/*     */ 
/* 568 */     private final ConcurrentMap<String, Map<Locale, MessageFormat>> cachedMessageFormats = new ConcurrentHashMap();
/*     */     
/*     */     public PropertiesHolder()
/*     */     {
/* 572 */       this.properties = null;
/* 573 */       this.fileTimestamp = -1L;
/*     */     }
/*     */     
/*     */     public PropertiesHolder(Properties properties, long fileTimestamp) {
/* 577 */       this.properties = properties;
/* 578 */       this.fileTimestamp = fileTimestamp;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Properties getProperties() {
/* 583 */       return this.properties;
/*     */     }
/*     */     
/*     */     public long getFileTimestamp() {
/* 587 */       return this.fileTimestamp;
/*     */     }
/*     */     
/*     */     public void setRefreshTimestamp(long refreshTimestamp) {
/* 591 */       this.refreshTimestamp = refreshTimestamp;
/*     */     }
/*     */     
/*     */     public long getRefreshTimestamp() {
/* 595 */       return this.refreshTimestamp;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public String getProperty(String code) {
/* 600 */       if (this.properties == null) {
/* 601 */         return null;
/*     */       }
/* 603 */       return this.properties.getProperty(code);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public MessageFormat getMessageFormat(String code, Locale locale) {
/* 608 */       if (this.properties == null) {
/* 609 */         return null;
/*     */       }
/* 611 */       Map<Locale, MessageFormat> localeMap = (Map)this.cachedMessageFormats.get(code);
/* 612 */       if (localeMap != null) {
/* 613 */         MessageFormat result = (MessageFormat)localeMap.get(locale);
/* 614 */         if (result != null) {
/* 615 */           return result;
/*     */         }
/*     */       }
/* 618 */       String msg = this.properties.getProperty(code);
/* 619 */       if (msg != null) {
/* 620 */         if (localeMap == null) {
/* 621 */           localeMap = new ConcurrentHashMap();
/* 622 */           Map<Locale, MessageFormat> existing = (Map)this.cachedMessageFormats.putIfAbsent(code, localeMap);
/* 623 */           if (existing != null) {
/* 624 */             localeMap = existing;
/*     */           }
/*     */         }
/* 627 */         MessageFormat result = ReloadableResourceBundleMessageSource.this.createMessageFormat(msg, locale);
/* 628 */         localeMap.put(locale, result);
/* 629 */         return result;
/*     */       }
/* 631 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\support\ReloadableResourceBundleMessageSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */