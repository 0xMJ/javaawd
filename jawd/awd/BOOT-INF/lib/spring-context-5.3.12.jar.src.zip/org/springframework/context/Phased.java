package org.springframework.context;

public abstract interface Phased
{
  public abstract int getPhase();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\Phased.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */