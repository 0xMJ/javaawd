/*    */ package org.springframework.context;
/*    */ 
/*    */ import java.time.Clock;
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ApplicationEvent
/*    */   extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 7099057708183571937L;
/*    */   private final long timestamp;
/*    */   
/*    */   public ApplicationEvent(Object source)
/*    */   {
/* 48 */     super(source);
/* 49 */     this.timestamp = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ApplicationEvent(Object source, Clock clock)
/*    */   {
/* 63 */     super(source);
/* 64 */     this.timestamp = clock.millis();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final long getTimestamp()
/*    */   {
/* 74 */     return this.timestamp;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\ApplicationEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */