/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.DecoratingClassLoader;
/*     */ import org.springframework.core.OverridingClassLoader;
/*     */ import org.springframework.core.SmartClassLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ContextTypeMatchClassLoader
/*     */   extends DecoratingClassLoader
/*     */   implements SmartClassLoader
/*     */ {
/*     */   private static Method findLoadedClassMethod;
/*     */   
/*     */   static
/*     */   {
/*  44 */     ClassLoader.registerAsParallelCapable();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  52 */       findLoadedClassMethod = ClassLoader.class.getDeclaredMethod("findLoadedClass", new Class[] { String.class });
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/*  55 */       throw new IllegalStateException("Invalid [java.lang.ClassLoader] class: no 'findLoadedClass' method defined!");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  61 */   private final Map<String, byte[]> bytesCache = new ConcurrentHashMap(256);
/*     */   
/*     */   public ContextTypeMatchClassLoader(@Nullable ClassLoader parent)
/*     */   {
/*  65 */     super(parent);
/*     */   }
/*     */   
/*     */   public Class<?> loadClass(String name) throws ClassNotFoundException
/*     */   {
/*  70 */     return new ContextOverridingClassLoader(getParent()).loadClass(name);
/*     */   }
/*     */   
/*     */   public boolean isClassReloadable(Class<?> clazz)
/*     */   {
/*  75 */     return clazz.getClassLoader() instanceof ContextOverridingClassLoader;
/*     */   }
/*     */   
/*     */   public Class<?> publicDefineClass(String name, byte[] b, @Nullable ProtectionDomain protectionDomain)
/*     */   {
/*  80 */     return defineClass(name, b, 0, b.length, protectionDomain);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private class ContextOverridingClassLoader
/*     */     extends OverridingClassLoader
/*     */   {
/*     */     public ContextOverridingClassLoader(ClassLoader parent)
/*     */     {
/*  91 */       super();
/*     */     }
/*     */     
/*     */     protected boolean isEligibleForOverriding(String className)
/*     */     {
/*  96 */       if ((isExcluded(className)) || (ContextTypeMatchClassLoader.this.isExcluded(className))) {
/*  97 */         return false;
/*     */       }
/*  99 */       ReflectionUtils.makeAccessible(ContextTypeMatchClassLoader.findLoadedClassMethod);
/* 100 */       ClassLoader parent = getParent();
/* 101 */       while (parent != null) {
/* 102 */         if (ReflectionUtils.invokeMethod(ContextTypeMatchClassLoader.findLoadedClassMethod, parent, new Object[] { className }) != null) {
/* 103 */           return false;
/*     */         }
/* 105 */         parent = parent.getParent();
/*     */       }
/* 107 */       return true;
/*     */     }
/*     */     
/*     */     protected Class<?> loadClassForOverriding(String name) throws ClassNotFoundException
/*     */     {
/* 112 */       byte[] bytes = (byte[])ContextTypeMatchClassLoader.this.bytesCache.get(name);
/* 113 */       if (bytes == null) {
/* 114 */         bytes = loadBytesForClass(name);
/* 115 */         if (bytes != null) {
/* 116 */           ContextTypeMatchClassLoader.this.bytesCache.put(name, bytes);
/*     */         }
/*     */         else {
/* 119 */           return null;
/*     */         }
/*     */       }
/* 122 */       return defineClass(name, bytes, 0, bytes.length);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\support\ContextTypeMatchClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */