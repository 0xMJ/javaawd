package org.springframework.context.annotation;

import org.springframework.beans.factory.config.BeanDefinition;

@FunctionalInterface
public abstract interface ScopeMetadataResolver
{
  public abstract ScopeMetadata resolveScopeMetadata(BeanDefinition paramBeanDefinition);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\ScopeMetadataResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */