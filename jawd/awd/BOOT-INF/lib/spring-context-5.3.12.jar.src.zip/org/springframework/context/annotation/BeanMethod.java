/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import org.springframework.beans.factory.parsing.Problem;
/*    */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.core.type.MethodMetadata;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BeanMethod
/*    */   extends ConfigurationMethod
/*    */ {
/*    */   BeanMethod(MethodMetadata metadata, ConfigurationClass configurationClass)
/*    */   {
/* 39 */     super(metadata, configurationClass);
/*    */   }
/*    */   
/*    */   public void validate(ProblemReporter problemReporter)
/*    */   {
/* 44 */     if (getMetadata().isStatic())
/*    */     {
/* 46 */       return;
/*    */     }
/*    */     
/* 49 */     if ((this.configurationClass.getMetadata().isAnnotated(Configuration.class.getName())) && 
/* 50 */       (!getMetadata().isOverridable()))
/*    */     {
/* 52 */       problemReporter.error(new NonOverridableMethodError());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(@Nullable Object obj)
/*    */   {
/* 59 */     return (this == obj) || (((obj instanceof BeanMethod)) && 
/* 60 */       (this.metadata.equals(((BeanMethod)obj).metadata)));
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 65 */     return this.metadata.hashCode();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 70 */     return "BeanMethod: " + this.metadata;
/*    */   }
/*    */   
/*    */   private class NonOverridableMethodError extends Problem
/*    */   {
/*    */     NonOverridableMethodError() {
/* 76 */       super(BeanMethod.this
/* 77 */         .getResourceLocation());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\BeanMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */