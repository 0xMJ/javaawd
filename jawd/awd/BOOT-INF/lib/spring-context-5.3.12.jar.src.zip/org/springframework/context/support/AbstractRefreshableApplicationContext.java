/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRefreshableApplicationContext
/*     */   extends AbstractApplicationContext
/*     */ {
/*     */   @Nullable
/*     */   private Boolean allowBeanDefinitionOverriding;
/*     */   @Nullable
/*     */   private Boolean allowCircularReferences;
/*     */   @Nullable
/*     */   private volatile DefaultListableBeanFactory beanFactory;
/*     */   
/*     */   public AbstractRefreshableApplicationContext() {}
/*     */   
/*     */   public AbstractRefreshableApplicationContext(@Nullable ApplicationContext parent)
/*     */   {
/*  89 */     super(parent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowBeanDefinitionOverriding(boolean allowBeanDefinitionOverriding)
/*     */   {
/* 100 */     this.allowBeanDefinitionOverriding = Boolean.valueOf(allowBeanDefinitionOverriding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowCircularReferences(boolean allowCircularReferences)
/*     */   {
/* 111 */     this.allowCircularReferences = Boolean.valueOf(allowCircularReferences);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void refreshBeanFactory()
/*     */     throws BeansException
/*     */   {
/* 122 */     if (hasBeanFactory()) {
/* 123 */       destroyBeans();
/* 124 */       closeBeanFactory();
/*     */     }
/*     */     try {
/* 127 */       DefaultListableBeanFactory beanFactory = createBeanFactory();
/* 128 */       beanFactory.setSerializationId(getId());
/* 129 */       customizeBeanFactory(beanFactory);
/* 130 */       loadBeanDefinitions(beanFactory);
/* 131 */       this.beanFactory = beanFactory;
/*     */     }
/*     */     catch (IOException ex) {
/* 134 */       throw new ApplicationContextException("I/O error parsing bean definition source for " + getDisplayName(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void cancelRefresh(BeansException ex)
/*     */   {
/* 140 */     DefaultListableBeanFactory beanFactory = this.beanFactory;
/* 141 */     if (beanFactory != null) {
/* 142 */       beanFactory.setSerializationId(null);
/*     */     }
/* 144 */     super.cancelRefresh(ex);
/*     */   }
/*     */   
/*     */   protected final void closeBeanFactory()
/*     */   {
/* 149 */     DefaultListableBeanFactory beanFactory = this.beanFactory;
/* 150 */     if (beanFactory != null) {
/* 151 */       beanFactory.setSerializationId(null);
/* 152 */       this.beanFactory = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final boolean hasBeanFactory()
/*     */   {
/* 161 */     return this.beanFactory != null;
/*     */   }
/*     */   
/*     */   public final ConfigurableListableBeanFactory getBeanFactory()
/*     */   {
/* 166 */     DefaultListableBeanFactory beanFactory = this.beanFactory;
/* 167 */     if (beanFactory == null) {
/* 168 */       throw new IllegalStateException("BeanFactory not initialized or already closed - call 'refresh' before accessing beans via the ApplicationContext");
/*     */     }
/*     */     
/* 171 */     return beanFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void assertBeanFactoryActive() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DefaultListableBeanFactory createBeanFactory()
/*     */   {
/* 197 */     return new DefaultListableBeanFactory(getInternalParentBeanFactory());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void customizeBeanFactory(DefaultListableBeanFactory beanFactory)
/*     */   {
/* 215 */     if (this.allowBeanDefinitionOverriding != null) {
/* 216 */       beanFactory.setAllowBeanDefinitionOverriding(this.allowBeanDefinitionOverriding.booleanValue());
/*     */     }
/* 218 */     if (this.allowCircularReferences != null) {
/* 219 */       beanFactory.setAllowCircularReferences(this.allowCircularReferences.booleanValue());
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void loadBeanDefinitions(DefaultListableBeanFactory paramDefaultListableBeanFactory)
/*     */     throws BeansException, IOException;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\support\AbstractRefreshableApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */