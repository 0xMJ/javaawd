package org.springframework.context;

import org.springframework.beans.factory.HierarchicalBeanFactory;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.core.env.EnvironmentCapable;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.lang.Nullable;

public abstract interface ApplicationContext
  extends EnvironmentCapable, ListableBeanFactory, HierarchicalBeanFactory, MessageSource, ApplicationEventPublisher, ResourcePatternResolver
{
  @Nullable
  public abstract String getId();
  
  public abstract String getApplicationName();
  
  public abstract String getDisplayName();
  
  public abstract long getStartupDate();
  
  @Nullable
  public abstract ApplicationContext getParent();
  
  public abstract AutowireCapableBeanFactory getAutowireCapableBeanFactory()
    throws IllegalStateException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\ApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */