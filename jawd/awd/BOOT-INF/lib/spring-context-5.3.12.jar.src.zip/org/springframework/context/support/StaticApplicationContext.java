/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StaticApplicationContext
/*     */   extends GenericApplicationContext
/*     */ {
/*     */   private final StaticMessageSource staticMessageSource;
/*     */   
/*     */   public StaticApplicationContext()
/*     */     throws BeansException
/*     */   {
/*  54 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StaticApplicationContext(@Nullable ApplicationContext parent)
/*     */     throws BeansException
/*     */   {
/*  65 */     super(parent);
/*     */     
/*     */ 
/*  68 */     this.staticMessageSource = new StaticMessageSource();
/*  69 */     getBeanFactory().registerSingleton("messageSource", this.staticMessageSource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void assertBeanFactoryActive() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final StaticMessageSource getStaticMessageSource()
/*     */   {
/*  86 */     return this.staticMessageSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerSingleton(String name, Class<?> clazz)
/*     */     throws BeansException
/*     */   {
/*  95 */     GenericBeanDefinition bd = new GenericBeanDefinition();
/*  96 */     bd.setBeanClass(clazz);
/*  97 */     getDefaultListableBeanFactory().registerBeanDefinition(name, bd);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerSingleton(String name, Class<?> clazz, MutablePropertyValues pvs)
/*     */     throws BeansException
/*     */   {
/* 106 */     GenericBeanDefinition bd = new GenericBeanDefinition();
/* 107 */     bd.setBeanClass(clazz);
/* 108 */     bd.setPropertyValues(pvs);
/* 109 */     getDefaultListableBeanFactory().registerBeanDefinition(name, bd);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerPrototype(String name, Class<?> clazz)
/*     */     throws BeansException
/*     */   {
/* 118 */     GenericBeanDefinition bd = new GenericBeanDefinition();
/* 119 */     bd.setScope("prototype");
/* 120 */     bd.setBeanClass(clazz);
/* 121 */     getDefaultListableBeanFactory().registerBeanDefinition(name, bd);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerPrototype(String name, Class<?> clazz, MutablePropertyValues pvs)
/*     */     throws BeansException
/*     */   {
/* 130 */     GenericBeanDefinition bd = new GenericBeanDefinition();
/* 131 */     bd.setScope("prototype");
/* 132 */     bd.setBeanClass(clazz);
/* 133 */     bd.setPropertyValues(pvs);
/* 134 */     getDefaultListableBeanFactory().registerBeanDefinition(name, bd);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMessage(String code, Locale locale, String defaultMessage)
/*     */   {
/* 145 */     getStaticMessageSource().addMessage(code, locale, defaultMessage);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\support\StaticApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */