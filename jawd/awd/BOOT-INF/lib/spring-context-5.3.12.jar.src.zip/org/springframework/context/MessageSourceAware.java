package org.springframework.context;

import org.springframework.beans.factory.Aware;

public abstract interface MessageSourceAware
  extends Aware
{
  public abstract void setMessageSource(MessageSource paramMessageSource);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\MessageSourceAware.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */