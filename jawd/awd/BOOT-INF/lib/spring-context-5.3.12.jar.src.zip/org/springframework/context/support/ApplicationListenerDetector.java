/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.MergedBeanDefinitionPostProcessor;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.event.ApplicationEventMulticaster;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ApplicationListenerDetector
/*     */   implements DestructionAwareBeanPostProcessor, MergedBeanDefinitionPostProcessor
/*     */ {
/*  48 */   private static final Log logger = LogFactory.getLog(ApplicationListenerDetector.class);
/*     */   
/*     */   private final transient AbstractApplicationContext applicationContext;
/*     */   
/*  52 */   private final transient Map<String, Boolean> singletonNames = new ConcurrentHashMap(256);
/*     */   
/*     */   public ApplicationListenerDetector(AbstractApplicationContext applicationContext)
/*     */   {
/*  56 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */ 
/*     */   public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName)
/*     */   {
/*  62 */     if (ApplicationListener.class.isAssignableFrom(beanType)) {
/*  63 */       this.singletonNames.put(beanName, Boolean.valueOf(beanDefinition.isSingleton()));
/*     */     }
/*     */   }
/*     */   
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */   {
/*  69 */     return bean;
/*     */   }
/*     */   
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */   {
/*  74 */     if ((bean instanceof ApplicationListener))
/*     */     {
/*  76 */       Boolean flag = (Boolean)this.singletonNames.get(beanName);
/*  77 */       if (Boolean.TRUE.equals(flag))
/*     */       {
/*  79 */         this.applicationContext.addApplicationListener((ApplicationListener)bean);
/*     */       }
/*  81 */       else if (Boolean.FALSE.equals(flag)) {
/*  82 */         if ((logger.isWarnEnabled()) && (!this.applicationContext.containsBean(beanName)))
/*     */         {
/*  84 */           logger.warn("Inner bean '" + beanName + "' implements ApplicationListener interface but is not reachable for event multicasting by its containing ApplicationContext because it does not have singleton scope. Only top-level listener beans are allowed to be of non-singleton scope.");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*  89 */         this.singletonNames.remove(beanName);
/*     */       }
/*     */     }
/*  92 */     return bean;
/*     */   }
/*     */   
/*     */   public void postProcessBeforeDestruction(Object bean, String beanName)
/*     */   {
/*  97 */     if ((bean instanceof ApplicationListener)) {
/*     */       try {
/*  99 */         ApplicationEventMulticaster multicaster = this.applicationContext.getApplicationEventMulticaster();
/* 100 */         multicaster.removeApplicationListener((ApplicationListener)bean);
/* 101 */         multicaster.removeApplicationListenerBean(beanName);
/*     */       }
/*     */       catch (IllegalStateException localIllegalStateException) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean requiresDestruction(Object bean)
/*     */   {
/* 111 */     return bean instanceof ApplicationListener;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(@Nullable Object other)
/*     */   {
/* 117 */     return (this == other) || (((other instanceof ApplicationListenerDetector)) && (this.applicationContext == ((ApplicationListenerDetector)other).applicationContext));
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 123 */     return ObjectUtils.nullSafeHashCode(this.applicationContext);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\support\ApplicationListenerDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */