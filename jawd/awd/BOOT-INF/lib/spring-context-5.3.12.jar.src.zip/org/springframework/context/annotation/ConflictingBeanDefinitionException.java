/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConflictingBeanDefinitionException
/*    */   extends IllegalStateException
/*    */ {
/*    */   public ConflictingBeanDefinitionException(String message)
/*    */   {
/* 30 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\ConflictingBeanDefinitionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */