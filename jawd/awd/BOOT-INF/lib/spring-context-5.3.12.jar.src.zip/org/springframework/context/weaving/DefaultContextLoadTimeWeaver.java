/*     */ package org.springframework.context.weaving;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.ReflectiveLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.glassfish.GlassFishLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.jboss.JBossLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.tomcat.TomcatLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.weblogic.WebLogicLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.websphere.WebSphereLoadTimeWeaver;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultContextLoadTimeWeaver
/*     */   implements LoadTimeWeaver, BeanClassLoaderAware, DisposableBean
/*     */ {
/*  61 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private LoadTimeWeaver loadTimeWeaver;
/*     */   
/*     */ 
/*     */   public DefaultContextLoadTimeWeaver() {}
/*     */   
/*     */   public DefaultContextLoadTimeWeaver(ClassLoader beanClassLoader)
/*     */   {
/*  71 */     setBeanClassLoader(beanClassLoader);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/*  77 */     LoadTimeWeaver serverSpecificLoadTimeWeaver = createServerSpecificLoadTimeWeaver(classLoader);
/*  78 */     if (serverSpecificLoadTimeWeaver != null) {
/*  79 */       if (this.logger.isDebugEnabled()) {
/*  80 */         this.logger.debug("Determined server-specific load-time weaver: " + serverSpecificLoadTimeWeaver
/*  81 */           .getClass().getName());
/*     */       }
/*  83 */       this.loadTimeWeaver = serverSpecificLoadTimeWeaver;
/*     */     }
/*  85 */     else if (InstrumentationLoadTimeWeaver.isInstrumentationAvailable()) {
/*  86 */       this.logger.debug("Found Spring's JVM agent for instrumentation");
/*  87 */       this.loadTimeWeaver = new InstrumentationLoadTimeWeaver(classLoader);
/*     */     }
/*     */     else {
/*     */       try {
/*  91 */         this.loadTimeWeaver = new ReflectiveLoadTimeWeaver(classLoader);
/*  92 */         if (this.logger.isDebugEnabled()) {
/*  93 */           this.logger.debug("Using reflective load-time weaver for class loader: " + this.loadTimeWeaver
/*  94 */             .getInstrumentableClassLoader().getClass().getName());
/*     */         }
/*     */       }
/*     */       catch (IllegalStateException ex) {
/*  98 */         throw new IllegalStateException(ex.getMessage() + " Specify a custom LoadTimeWeaver or start your Java virtual machine with Spring's agent: -javaagent:spring-instrument-{version}.jar");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected LoadTimeWeaver createServerSpecificLoadTimeWeaver(ClassLoader classLoader)
/*     */   {
/* 112 */     String name = classLoader.getClass().getName();
/*     */     try {
/* 114 */       if (name.startsWith("org.apache.catalina")) {
/* 115 */         return new TomcatLoadTimeWeaver(classLoader);
/*     */       }
/* 117 */       if (name.startsWith("org.glassfish")) {
/* 118 */         return new GlassFishLoadTimeWeaver(classLoader);
/*     */       }
/* 120 */       if (name.startsWith("org.jboss.modules")) {
/* 121 */         return new JBossLoadTimeWeaver(classLoader);
/*     */       }
/* 123 */       if (name.startsWith("com.ibm.ws.classloader")) {
/* 124 */         return new WebSphereLoadTimeWeaver(classLoader);
/*     */       }
/* 126 */       if (name.startsWith("weblogic")) {
/* 127 */         return new WebLogicLoadTimeWeaver(classLoader);
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 131 */       if (this.logger.isInfoEnabled()) {
/* 132 */         this.logger.info("Could not obtain server-specific LoadTimeWeaver: " + ex.getMessage());
/*     */       }
/*     */     }
/* 135 */     return null;
/*     */   }
/*     */   
/*     */   public void destroy()
/*     */   {
/* 140 */     if ((this.loadTimeWeaver instanceof InstrumentationLoadTimeWeaver)) {
/* 141 */       if (this.logger.isDebugEnabled()) {
/* 142 */         this.logger.debug("Removing all registered transformers for class loader: " + this.loadTimeWeaver
/* 143 */           .getInstrumentableClassLoader().getClass().getName());
/*     */       }
/* 145 */       ((InstrumentationLoadTimeWeaver)this.loadTimeWeaver).removeTransformers();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void addTransformer(ClassFileTransformer transformer)
/*     */   {
/* 152 */     Assert.state(this.loadTimeWeaver != null, "Not initialized");
/* 153 */     this.loadTimeWeaver.addTransformer(transformer);
/*     */   }
/*     */   
/*     */   public ClassLoader getInstrumentableClassLoader()
/*     */   {
/* 158 */     Assert.state(this.loadTimeWeaver != null, "Not initialized");
/* 159 */     return this.loadTimeWeaver.getInstrumentableClassLoader();
/*     */   }
/*     */   
/*     */   public ClassLoader getThrowawayClassLoader()
/*     */   {
/* 164 */     Assert.state(this.loadTimeWeaver != null, "Not initialized");
/* 165 */     return this.loadTimeWeaver.getThrowawayClassLoader();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\weaving\DefaultContextLoadTimeWeaver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */