/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface DeferredImportSelector
/*     */   extends ImportSelector
/*     */ {
/*     */   @Nullable
/*     */   public Class<? extends Group> getImportGroup()
/*     */   {
/*  48 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract interface Group
/*     */   {
/*     */     public abstract void process(AnnotationMetadata paramAnnotationMetadata, DeferredImportSelector paramDeferredImportSelector);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract Iterable<Entry> selectImports();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static class Entry
/*     */     {
/*     */       private final AnnotationMetadata metadata;
/*     */       
/*     */ 
/*     */ 
/*     */       private final String importClassName;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       public Entry(AnnotationMetadata metadata, String importClassName)
/*     */       {
/*  82 */         this.metadata = metadata;
/*  83 */         this.importClassName = importClassName;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       public AnnotationMetadata getMetadata()
/*     */       {
/*  91 */         return this.metadata;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public String getImportClassName()
/*     */       {
/*  98 */         return this.importClassName;
/*     */       }
/*     */       
/*     */       public boolean equals(@Nullable Object other)
/*     */       {
/* 103 */         if (this == other) {
/* 104 */           return true;
/*     */         }
/* 106 */         if ((other == null) || (getClass() != other.getClass())) {
/* 107 */           return false;
/*     */         }
/* 109 */         Entry entry = (Entry)other;
/* 110 */         return (this.metadata.equals(entry.metadata)) && (this.importClassName.equals(entry.importClassName));
/*     */       }
/*     */       
/*     */       public int hashCode()
/*     */       {
/* 115 */         return this.metadata.hashCode() * 31 + this.importClassName.hashCode();
/*     */       }
/*     */       
/*     */       public String toString()
/*     */       {
/* 120 */         return this.importClassName;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\annotation\DeferredImportSelector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */