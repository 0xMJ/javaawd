/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.ObjectFactory;
/*     */ import org.springframework.beans.factory.config.Scope;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleThreadScope
/*     */   implements Scope
/*     */ {
/*  56 */   private static final Log logger = LogFactory.getLog(SimpleThreadScope.class);
/*     */   
/*  58 */   private final ThreadLocal<Map<String, Object>> threadScope = new NamedThreadLocal("SimpleThreadScope")
/*     */   {
/*     */     protected Map<String, Object> initialValue()
/*     */     {
/*  62 */       return new HashMap();
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */   public Object get(String name, ObjectFactory<?> objectFactory)
/*     */   {
/*  69 */     Map<String, Object> scope = (Map)this.threadScope.get();
/*     */     
/*     */ 
/*  72 */     Object scopedObject = scope.get(name);
/*  73 */     if (scopedObject == null) {
/*  74 */       scopedObject = objectFactory.getObject();
/*  75 */       scope.put(name, scopedObject);
/*     */     }
/*  77 */     return scopedObject;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Object remove(String name)
/*     */   {
/*  83 */     Map<String, Object> scope = (Map)this.threadScope.get();
/*  84 */     return scope.remove(name);
/*     */   }
/*     */   
/*     */   public void registerDestructionCallback(String name, Runnable callback)
/*     */   {
/*  89 */     logger.warn("SimpleThreadScope does not support destruction callbacks. Consider using RequestScope in a web environment.");
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   public Object resolveContextualObject(String key)
/*     */   {
/*  96 */     return null;
/*     */   }
/*     */   
/*     */   public String getConversationId()
/*     */   {
/* 101 */     return Thread.currentThread().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\support\SimpleThreadScope.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */