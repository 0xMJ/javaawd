/*    */ package org.springframework.context;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public abstract interface MessageSourceResolvable
/*    */ {
/*    */   @Nullable
/*    */   public abstract String[] getCodes();
/*    */   
/*    */   @Nullable
/*    */   public Object[] getArguments()
/*    */   {
/* 52 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   public String getDefaultMessage()
/*    */   {
/* 66 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\MessageSourceResolvable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */