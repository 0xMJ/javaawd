/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.core.ResolvableType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface GenericApplicationListener
/*    */   extends SmartApplicationListener
/*    */ {
/*    */   public boolean supportsEventType(Class<? extends ApplicationEvent> eventType)
/*    */   {
/* 47 */     return supportsEventType(ResolvableType.forClass(eventType));
/*    */   }
/*    */   
/*    */   public abstract boolean supportsEventType(ResolvableType paramResolvableType);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\event\GenericApplicationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */