/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.xml.ResourceEntityResolver;
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractXmlApplicationContext
/*     */   extends AbstractRefreshableConfigApplicationContext
/*     */ {
/*  48 */   private boolean validating = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractXmlApplicationContext() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractXmlApplicationContext(@Nullable ApplicationContext parent)
/*     */   {
/*  62 */     super(parent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValidating(boolean validating)
/*     */   {
/*  70 */     this.validating = validating;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void loadBeanDefinitions(DefaultListableBeanFactory beanFactory)
/*     */     throws BeansException, IOException
/*     */   {
/*  83 */     XmlBeanDefinitionReader beanDefinitionReader = new XmlBeanDefinitionReader(beanFactory);
/*     */     
/*     */ 
/*     */ 
/*  87 */     beanDefinitionReader.setEnvironment(getEnvironment());
/*  88 */     beanDefinitionReader.setResourceLoader(this);
/*  89 */     beanDefinitionReader.setEntityResolver(new ResourceEntityResolver(this));
/*     */     
/*     */ 
/*     */ 
/*  93 */     initBeanDefinitionReader(beanDefinitionReader);
/*  94 */     loadBeanDefinitions(beanDefinitionReader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initBeanDefinitionReader(XmlBeanDefinitionReader reader)
/*     */   {
/* 106 */     reader.setValidating(this.validating);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void loadBeanDefinitions(XmlBeanDefinitionReader reader)
/*     */     throws BeansException, IOException
/*     */   {
/* 122 */     Resource[] configResources = getConfigResources();
/* 123 */     if (configResources != null) {
/* 124 */       reader.loadBeanDefinitions(configResources);
/*     */     }
/* 126 */     String[] configLocations = getConfigLocations();
/* 127 */     if (configLocations != null) {
/* 128 */       reader.loadBeanDefinitions(configLocations);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Resource[] getConfigResources()
/*     */   {
/* 142 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\context\support\AbstractXmlApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */