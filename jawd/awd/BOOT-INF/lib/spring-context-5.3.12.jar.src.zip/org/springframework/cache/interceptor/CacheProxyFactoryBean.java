/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.framework.AbstractSingletonProxyFactoryBean;
/*     */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.cache.CacheManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheProxyFactoryBean
/*     */   extends AbstractSingletonProxyFactoryBean
/*     */   implements BeanFactoryAware, SmartInitializingSingleton
/*     */ {
/*  52 */   private final CacheInterceptor cacheInterceptor = new CacheInterceptor();
/*     */   
/*  54 */   private Pointcut pointcut = Pointcut.TRUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheOperationSources(CacheOperationSource... cacheOperationSources)
/*     */   {
/*  62 */     this.cacheInterceptor.setCacheOperationSources(cacheOperationSources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeyGenerator(KeyGenerator keyGenerator)
/*     */   {
/*  73 */     this.cacheInterceptor.setKeyGenerator(keyGenerator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheResolver(CacheResolver cacheResolver)
/*     */   {
/*  85 */     this.cacheInterceptor.setCacheResolver(cacheResolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheManager(CacheManager cacheManager)
/*     */   {
/*  95 */     this.cacheInterceptor.setCacheManager(cacheManager);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPointcut(Pointcut pointcut)
/*     */   {
/* 106 */     this.pointcut = pointcut;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 111 */     this.cacheInterceptor.setBeanFactory(beanFactory);
/*     */   }
/*     */   
/*     */   public void afterSingletonsInstantiated()
/*     */   {
/* 116 */     this.cacheInterceptor.afterSingletonsInstantiated();
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object createMainInterceptor()
/*     */   {
/* 122 */     this.cacheInterceptor.afterPropertiesSet();
/* 123 */     return new DefaultPointcutAdvisor(this.pointcut, this.cacheInterceptor);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\interceptor\CacheProxyFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */