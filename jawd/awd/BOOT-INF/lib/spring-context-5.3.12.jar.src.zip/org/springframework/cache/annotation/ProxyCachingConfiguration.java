/*    */ package org.springframework.cache.annotation;
/*    */ 
/*    */ import org.springframework.cache.interceptor.BeanFactoryCacheOperationSourceAdvisor;
/*    */ import org.springframework.cache.interceptor.CacheInterceptor;
/*    */ import org.springframework.cache.interceptor.CacheOperationSource;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @Role(2)
/*    */ public class ProxyCachingConfiguration
/*    */   extends AbstractCachingConfiguration
/*    */ {
/*    */   @Bean(name={"org.springframework.cache.config.internalCacheAdvisor"})
/*    */   @Role(2)
/*    */   public BeanFactoryCacheOperationSourceAdvisor cacheAdvisor(CacheOperationSource cacheOperationSource, CacheInterceptor cacheInterceptor)
/*    */   {
/* 47 */     BeanFactoryCacheOperationSourceAdvisor advisor = new BeanFactoryCacheOperationSourceAdvisor();
/* 48 */     advisor.setCacheOperationSource(cacheOperationSource);
/* 49 */     advisor.setAdvice(cacheInterceptor);
/* 50 */     if (this.enableCaching != null) {
/* 51 */       advisor.setOrder(((Integer)this.enableCaching.getNumber("order")).intValue());
/*    */     }
/* 53 */     return advisor;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   public CacheOperationSource cacheOperationSource() {
/* 59 */     return new AnnotationCacheOperationSource();
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @Role(2)
/*    */   public CacheInterceptor cacheInterceptor(CacheOperationSource cacheOperationSource) {
/* 65 */     CacheInterceptor interceptor = new CacheInterceptor();
/* 66 */     interceptor.configure(this.errorHandler, this.keyGenerator, this.cacheResolver, this.cacheManager);
/* 67 */     interceptor.setCacheOperationSource(cacheOperationSource);
/* 68 */     return interceptor;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\annotation\ProxyCachingConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */