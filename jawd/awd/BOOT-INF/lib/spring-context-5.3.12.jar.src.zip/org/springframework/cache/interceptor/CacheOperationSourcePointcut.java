/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.aop.support.StaticMethodMatcherPointcut;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class CacheOperationSourcePointcut
/*    */   extends StaticMethodMatcherPointcut
/*    */   implements Serializable
/*    */ {
/*    */   protected CacheOperationSourcePointcut()
/*    */   {
/* 41 */     setClassFilter(new CacheOperationSourceClassFilter(null));
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean matches(Method method, Class<?> targetClass)
/*    */   {
/* 47 */     CacheOperationSource cas = getCacheOperationSource();
/* 48 */     return (cas != null) && (!CollectionUtils.isEmpty(cas.getCacheOperations(method, targetClass)));
/*    */   }
/*    */   
/*    */   public boolean equals(@Nullable Object other)
/*    */   {
/* 53 */     if (this == other) {
/* 54 */       return true;
/*    */     }
/* 56 */     if (!(other instanceof CacheOperationSourcePointcut)) {
/* 57 */       return false;
/*    */     }
/* 59 */     CacheOperationSourcePointcut otherPc = (CacheOperationSourcePointcut)other;
/* 60 */     return ObjectUtils.nullSafeEquals(getCacheOperationSource(), otherPc.getCacheOperationSource());
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 65 */     return CacheOperationSourcePointcut.class.hashCode();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 70 */     return getClass().getName() + ": " + getCacheOperationSource();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   protected abstract CacheOperationSource getCacheOperationSource();
/*    */   
/*    */ 
/*    */ 
/*    */   private class CacheOperationSourceClassFilter
/*    */     implements ClassFilter
/*    */   {
/*    */     private CacheOperationSourceClassFilter() {}
/*    */     
/*    */ 
/*    */ 
/*    */     public boolean matches(Class<?> clazz)
/*    */     {
/* 90 */       if (CacheManager.class.isAssignableFrom(clazz)) {
/* 91 */         return false;
/*    */       }
/* 93 */       CacheOperationSource cas = CacheOperationSourcePointcut.this.getCacheOperationSource();
/* 94 */       return (cas == null) || (cas.isCandidateClass(clazz));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\interceptor\CacheOperationSourcePointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */