package org.springframework.cache;

import java.util.Collection;
import org.springframework.lang.Nullable;

public abstract interface CacheManager
{
  @Nullable
  public abstract Cache getCache(String paramString);
  
  public abstract Collection<String> getCacheNames();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\CacheManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */