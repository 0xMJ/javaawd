/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public abstract interface CacheOperationInvoker
/*    */ {
/*    */   @Nullable
/*    */   public abstract Object invoke()
/*    */     throws CacheOperationInvoker.ThrowableWrapper;
/*    */   
/*    */   public static class ThrowableWrapper
/*    */     extends RuntimeException
/*    */   {
/*    */     private final Throwable original;
/*    */     
/*    */     public ThrowableWrapper(Throwable original)
/*    */     {
/* 54 */       super(original);
/* 55 */       this.original = original;
/*    */     }
/*    */     
/*    */     public Throwable getOriginal() {
/* 59 */       return this.original;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\interceptor\CacheOperationInvoker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */