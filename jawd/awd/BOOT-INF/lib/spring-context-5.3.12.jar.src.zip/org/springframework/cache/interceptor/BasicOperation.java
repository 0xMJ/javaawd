package org.springframework.cache.interceptor;

import java.util.Set;

public abstract interface BasicOperation
{
  public abstract Set<String> getCacheNames();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\interceptor\BasicOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */