/*    */ package org.springframework.cache.support;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import org.springframework.cache.Cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleCacheManager
/*    */   extends AbstractCacheManager
/*    */ {
/* 38 */   private Collection<? extends Cache> caches = Collections.emptySet();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setCaches(Collection<? extends Cache> caches)
/*    */   {
/* 46 */     this.caches = caches;
/*    */   }
/*    */   
/*    */   protected Collection<? extends Cache> loadCaches()
/*    */   {
/* 51 */     return this.caches;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\support\SimpleCacheManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */