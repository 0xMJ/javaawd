/*     */ package org.springframework.cache.support;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.Cache.ValueRetrievalException;
/*     */ import org.springframework.cache.Cache.ValueWrapper;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoOpCache
/*     */   implements Cache
/*     */ {
/*     */   private final String name;
/*     */   
/*     */   public NoOpCache(String name)
/*     */   {
/*  45 */     Assert.notNull(name, "Cache name must not be null");
/*  46 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getName()
/*     */   {
/*  52 */     return this.name;
/*     */   }
/*     */   
/*     */   public Object getNativeCache()
/*     */   {
/*  57 */     return this;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Cache.ValueWrapper get(Object key)
/*     */   {
/*  63 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public <T> T get(Object key, @Nullable Class<T> type)
/*     */   {
/*  69 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public <T> T get(Object key, Callable<T> valueLoader)
/*     */   {
/*     */     try {
/*  76 */       return (T)valueLoader.call();
/*     */     }
/*     */     catch (Exception ex) {
/*  79 */       throw new Cache.ValueRetrievalException(key, valueLoader, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void put(Object key, @Nullable Object value) {}
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   public Cache.ValueWrapper putIfAbsent(Object key, @Nullable Object value)
/*     */   {
/*  90 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void evict(Object key) {}
/*     */   
/*     */ 
/*     */   public boolean evictIfPresent(Object key)
/*     */   {
/*  99 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void clear() {}
/*     */   
/*     */ 
/*     */   public boolean invalidate()
/*     */   {
/* 108 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\support\NoOpCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */