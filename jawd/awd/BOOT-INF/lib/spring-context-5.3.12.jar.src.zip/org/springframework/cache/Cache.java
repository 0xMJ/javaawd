/*     */ package org.springframework.cache;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface Cache
/*     */ {
/*     */   public abstract String getName();
/*     */   
/*     */   public abstract Object getNativeCache();
/*     */   
/*     */   @Nullable
/*     */   public abstract ValueWrapper get(Object paramObject);
/*     */   
/*     */   @Nullable
/*     */   public abstract <T> T get(Object paramObject, @Nullable Class<T> paramClass);
/*     */   
/*     */   @Nullable
/*     */   public abstract <T> T get(Object paramObject, Callable<T> paramCallable);
/*     */   
/*     */   public abstract void put(Object paramObject1, @Nullable Object paramObject2);
/*     */   
/*     */   @Nullable
/*     */   public ValueWrapper putIfAbsent(Object key, @Nullable Object value)
/*     */   {
/* 146 */     ValueWrapper existingValue = get(key);
/* 147 */     if (existingValue == null) {
/* 148 */       put(key, value);
/*     */     }
/* 150 */     return existingValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void evict(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evictIfPresent(Object key)
/*     */   {
/* 181 */     evict(key);
/* 182 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void clear();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean invalidate()
/*     */   {
/* 205 */     clear();
/* 206 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class ValueRetrievalException
/*     */     extends RuntimeException
/*     */   {
/*     */     @Nullable
/*     */     private final Object key;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ValueRetrievalException(@Nullable Object key, Callable<?> loader, Throwable ex)
/*     */     {
/* 236 */       super(ex);
/* 237 */       this.key = key;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Object getKey() {
/* 242 */       return this.key;
/*     */     }
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static abstract interface ValueWrapper
/*     */   {
/*     */     @Nullable
/*     */     public abstract Object get();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\Cache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */