/*    */ package org.springframework.cache.annotation;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Collection;
/*    */ import org.springframework.cache.interceptor.CacheOperation;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface CacheAnnotationParser
/*    */ {
/*    */   public boolean isCandidateClass(Class<?> targetClass)
/*    */   {
/* 55 */     return true;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public abstract Collection<CacheOperation> parseCacheAnnotations(Class<?> paramClass);
/*    */   
/*    */   @Nullable
/*    */   public abstract Collection<CacheOperation> parseCacheAnnotations(Method paramMethod);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\annotation\CacheAnnotationParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */