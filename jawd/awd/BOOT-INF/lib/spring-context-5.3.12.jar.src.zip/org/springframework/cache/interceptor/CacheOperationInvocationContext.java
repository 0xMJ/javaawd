package org.springframework.cache.interceptor;

import java.lang.reflect.Method;

public abstract interface CacheOperationInvocationContext<O extends BasicOperation>
{
  public abstract O getOperation();
  
  public abstract Object getTarget();
  
  public abstract Method getMethod();
  
  public abstract Object[] getArgs();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\interceptor\CacheOperationInvocationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */