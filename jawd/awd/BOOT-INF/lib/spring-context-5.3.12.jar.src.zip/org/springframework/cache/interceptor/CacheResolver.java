package org.springframework.cache.interceptor;

import java.util.Collection;
import org.springframework.cache.Cache;

@FunctionalInterface
public abstract interface CacheResolver
{
  public abstract Collection<? extends Cache> resolveCaches(CacheOperationInvocationContext<?> paramCacheOperationInvocationContext);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\interceptor\CacheResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */