/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CacheOperation
/*     */   implements BasicOperation
/*     */ {
/*     */   private final String name;
/*     */   private final Set<String> cacheNames;
/*     */   private final String key;
/*     */   private final String keyGenerator;
/*     */   private final String cacheManager;
/*     */   private final String cacheResolver;
/*     */   private final String condition;
/*     */   private final String toString;
/*     */   
/*     */   protected CacheOperation(Builder b)
/*     */   {
/*  58 */     this.name = b.name;
/*  59 */     this.cacheNames = b.cacheNames;
/*  60 */     this.key = b.key;
/*  61 */     this.keyGenerator = b.keyGenerator;
/*  62 */     this.cacheManager = b.cacheManager;
/*  63 */     this.cacheResolver = b.cacheResolver;
/*  64 */     this.condition = b.condition;
/*  65 */     this.toString = b.getOperationDescription().toString();
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  70 */     return this.name;
/*     */   }
/*     */   
/*     */   public Set<String> getCacheNames()
/*     */   {
/*  75 */     return this.cacheNames;
/*     */   }
/*     */   
/*     */   public String getKey() {
/*  79 */     return this.key;
/*     */   }
/*     */   
/*     */   public String getKeyGenerator() {
/*  83 */     return this.keyGenerator;
/*     */   }
/*     */   
/*     */   public String getCacheManager() {
/*  87 */     return this.cacheManager;
/*     */   }
/*     */   
/*     */   public String getCacheResolver() {
/*  91 */     return this.cacheResolver;
/*     */   }
/*     */   
/*     */   public String getCondition() {
/*  95 */     return this.condition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(@Nullable Object other)
/*     */   {
/* 105 */     return ((other instanceof CacheOperation)) && (toString().equals(other.toString()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 114 */     return toString().hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String toString()
/*     */   {
/* 126 */     return this.toString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract class Builder
/*     */   {
/* 136 */     private String name = "";
/*     */     
/* 138 */     private Set<String> cacheNames = Collections.emptySet();
/*     */     
/* 140 */     private String key = "";
/*     */     
/* 142 */     private String keyGenerator = "";
/*     */     
/* 144 */     private String cacheManager = "";
/*     */     
/* 146 */     private String cacheResolver = "";
/*     */     
/* 148 */     private String condition = "";
/*     */     
/*     */     public void setName(String name) {
/* 151 */       Assert.hasText(name, "Name must not be empty");
/* 152 */       this.name = name;
/*     */     }
/*     */     
/*     */     public void setCacheName(String cacheName) {
/* 156 */       Assert.hasText(cacheName, "Cache name must not be empty");
/* 157 */       this.cacheNames = Collections.singleton(cacheName);
/*     */     }
/*     */     
/*     */     public void setCacheNames(String... cacheNames) {
/* 161 */       this.cacheNames = new LinkedHashSet(cacheNames.length);
/* 162 */       for (String cacheName : cacheNames) {
/* 163 */         Assert.hasText(cacheName, "Cache name must be non-empty if specified");
/* 164 */         this.cacheNames.add(cacheName);
/*     */       }
/*     */     }
/*     */     
/*     */     public Set<String> getCacheNames() {
/* 169 */       return this.cacheNames;
/*     */     }
/*     */     
/*     */     public void setKey(String key) {
/* 173 */       Assert.notNull(key, "Key must not be null");
/* 174 */       this.key = key;
/*     */     }
/*     */     
/*     */     public String getKey() {
/* 178 */       return this.key;
/*     */     }
/*     */     
/*     */     public String getKeyGenerator() {
/* 182 */       return this.keyGenerator;
/*     */     }
/*     */     
/*     */     public String getCacheManager() {
/* 186 */       return this.cacheManager;
/*     */     }
/*     */     
/*     */     public String getCacheResolver() {
/* 190 */       return this.cacheResolver;
/*     */     }
/*     */     
/*     */     public void setKeyGenerator(String keyGenerator) {
/* 194 */       Assert.notNull(keyGenerator, "KeyGenerator name must not be null");
/* 195 */       this.keyGenerator = keyGenerator;
/*     */     }
/*     */     
/*     */     public void setCacheManager(String cacheManager) {
/* 199 */       Assert.notNull(cacheManager, "CacheManager name must not be null");
/* 200 */       this.cacheManager = cacheManager;
/*     */     }
/*     */     
/*     */     public void setCacheResolver(String cacheResolver) {
/* 204 */       Assert.notNull(cacheResolver, "CacheResolver name must not be null");
/* 205 */       this.cacheResolver = cacheResolver;
/*     */     }
/*     */     
/*     */     public void setCondition(String condition) {
/* 209 */       Assert.notNull(condition, "Condition must not be null");
/* 210 */       this.condition = condition;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected StringBuilder getOperationDescription()
/*     */     {
/* 218 */       StringBuilder result = new StringBuilder(getClass().getSimpleName());
/* 219 */       result.append('[').append(this.name);
/* 220 */       result.append("] caches=").append(this.cacheNames);
/* 221 */       result.append(" | key='").append(this.key);
/* 222 */       result.append("' | keyGenerator='").append(this.keyGenerator);
/* 223 */       result.append("' | cacheManager='").append(this.cacheManager);
/* 224 */       result.append("' | cacheResolver='").append(this.cacheResolver);
/* 225 */       result.append("' | condition='").append(this.condition).append('\'');
/* 226 */       return result;
/*     */     }
/*     */     
/*     */     public abstract CacheOperation build();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\interceptor\CacheOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */