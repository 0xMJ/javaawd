/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeCacheOperationSource
/*    */   implements CacheOperationSource, Serializable
/*    */ {
/*    */   private final CacheOperationSource[] cacheOperationSources;
/*    */   
/*    */   public CompositeCacheOperationSource(CacheOperationSource... cacheOperationSources)
/*    */   {
/* 46 */     Assert.notEmpty(cacheOperationSources, "CacheOperationSource array must not be empty");
/* 47 */     this.cacheOperationSources = cacheOperationSources;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final CacheOperationSource[] getCacheOperationSources()
/*    */   {
/* 55 */     return this.cacheOperationSources;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isCandidateClass(Class<?> targetClass)
/*    */   {
/* 61 */     for (CacheOperationSource source : this.cacheOperationSources) {
/* 62 */       if (source.isCandidateClass(targetClass)) {
/* 63 */         return true;
/*    */       }
/*    */     }
/* 66 */     return false;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Collection<CacheOperation> getCacheOperations(Method method, @Nullable Class<?> targetClass)
/*    */   {
/* 72 */     Collection<CacheOperation> ops = null;
/* 73 */     for (CacheOperationSource source : this.cacheOperationSources) {
/* 74 */       Collection<CacheOperation> cacheOperations = source.getCacheOperations(method, targetClass);
/* 75 */       if (cacheOperations != null) {
/* 76 */         if (ops == null) {
/* 77 */           ops = new ArrayList();
/*    */         }
/* 79 */         ops.addAll(cacheOperations);
/*    */       }
/*    */     }
/* 82 */     return ops;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\interceptor\CompositeCacheOperationSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */