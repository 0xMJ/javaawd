/*     */ package org.springframework.cache.support;
/*     */ 
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.Cache.ValueWrapper;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractValueAdaptingCache
/*     */   implements Cache
/*     */ {
/*     */   private final boolean allowNullValues;
/*     */   
/*     */   protected AbstractValueAdaptingCache(boolean allowNullValues)
/*     */   {
/*  44 */     this.allowNullValues = allowNullValues;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isAllowNullValues()
/*     */   {
/*  52 */     return this.allowNullValues;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Cache.ValueWrapper get(Object key)
/*     */   {
/*  58 */     return toValueWrapper(lookup(key));
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   public <T> T get(Object key, @Nullable Class<T> type)
/*     */   {
/*  65 */     Object value = fromStoreValue(lookup(key));
/*  66 */     if ((value != null) && (type != null) && (!type.isInstance(value)))
/*     */     {
/*  68 */       throw new IllegalStateException("Cached value is not of required type [" + type.getName() + "]: " + value);
/*     */     }
/*  70 */     return (T)value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected abstract Object lookup(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object fromStoreValue(@Nullable Object storeValue)
/*     */   {
/*  90 */     if ((this.allowNullValues) && (storeValue == NullValue.INSTANCE)) {
/*  91 */       return null;
/*     */     }
/*  93 */     return storeValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object toStoreValue(@Nullable Object userValue)
/*     */   {
/* 103 */     if (userValue == null) {
/* 104 */       if (this.allowNullValues) {
/* 105 */         return NullValue.INSTANCE;
/*     */       }
/*     */       
/* 108 */       throw new IllegalArgumentException("Cache '" + getName() + "' is configured to not allow null values but null was provided");
/*     */     }
/* 110 */     return userValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Cache.ValueWrapper toValueWrapper(@Nullable Object storeValue)
/*     */   {
/* 122 */     return storeValue != null ? new SimpleValueWrapper(fromStoreValue(storeValue)) : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\support\AbstractValueAdaptingCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */