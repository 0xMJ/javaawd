/*     */ package org.springframework.cache.support;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCacheManager
/*     */   implements CacheManager, InitializingBean
/*     */ {
/*  42 */   private final ConcurrentMap<String, Cache> cacheMap = new ConcurrentHashMap(16);
/*     */   
/*  44 */   private volatile Set<String> cacheNames = Collections.emptySet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/*  51 */     initializeCaches();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initializeCaches()
/*     */   {
/*  62 */     Collection<? extends Cache> caches = loadCaches();
/*     */     
/*  64 */     synchronized (this.cacheMap) {
/*  65 */       this.cacheNames = Collections.emptySet();
/*  66 */       this.cacheMap.clear();
/*  67 */       Set<String> cacheNames = new LinkedHashSet(caches.size());
/*  68 */       for (Cache cache : caches) {
/*  69 */         String name = cache.getName();
/*  70 */         this.cacheMap.put(name, decorateCache(cache));
/*  71 */         cacheNames.add(name);
/*     */       }
/*  73 */       this.cacheNames = Collections.unmodifiableSet(cacheNames);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Collection<? extends Cache> loadCaches();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Cache getCache(String name)
/*     */   {
/*  91 */     Cache cache = (Cache)this.cacheMap.get(name);
/*  92 */     if (cache != null) {
/*  93 */       return cache;
/*     */     }
/*     */     
/*     */ 
/*  97 */     Cache missingCache = getMissingCache(name);
/*  98 */     if (missingCache != null)
/*     */     {
/* 100 */       synchronized (this.cacheMap) {
/* 101 */         cache = (Cache)this.cacheMap.get(name);
/* 102 */         if (cache == null) {
/* 103 */           cache = decorateCache(missingCache);
/* 104 */           this.cacheMap.put(name, cache);
/* 105 */           updateCacheNames(name);
/*     */         }
/*     */       }
/*     */     }
/* 109 */     return cache;
/*     */   }
/*     */   
/*     */   public Collection<String> getCacheNames()
/*     */   {
/* 114 */     return this.cacheNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected final Cache lookupCache(String name)
/*     */   {
/* 132 */     return (Cache)this.cacheMap.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void addCache(Cache cache)
/*     */   {
/* 142 */     String name = cache.getName();
/* 143 */     synchronized (this.cacheMap) {
/* 144 */       if (this.cacheMap.put(name, decorateCache(cache)) == null) {
/* 145 */         updateCacheNames(name);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateCacheNames(String name)
/*     */   {
/* 158 */     Set<String> cacheNames = new LinkedHashSet(this.cacheNames);
/* 159 */     cacheNames.add(name);
/* 160 */     this.cacheNames = Collections.unmodifiableSet(cacheNames);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Cache decorateCache(Cache cache)
/*     */   {
/* 173 */     return cache;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Cache getMissingCache(String name)
/*     */   {
/* 191 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\support\AbstractCacheManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */