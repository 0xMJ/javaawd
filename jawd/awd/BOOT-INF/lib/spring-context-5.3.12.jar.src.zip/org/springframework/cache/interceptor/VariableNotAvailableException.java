/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import org.springframework.expression.EvaluationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class VariableNotAvailableException
/*    */   extends EvaluationException
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   public VariableNotAvailableException(String name)
/*    */   {
/* 35 */     super("Variable not available");
/* 36 */     this.name = name;
/*    */   }
/*    */   
/*    */   public final String getName()
/*    */   {
/* 41 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\interceptor\VariableNotAvailableException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */