/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleKey
/*    */   implements Serializable
/*    */ {
/* 42 */   public static final SimpleKey EMPTY = new SimpleKey(new Object[0]);
/*    */   
/*    */ 
/*    */ 
/*    */   private final Object[] params;
/*    */   
/*    */ 
/*    */ 
/*    */   private transient int hashCode;
/*    */   
/*    */ 
/*    */ 
/*    */   public SimpleKey(Object... elements)
/*    */   {
/* 56 */     Assert.notNull(elements, "Elements must not be null");
/* 57 */     this.params = ((Object[])elements.clone());
/*    */     
/* 59 */     this.hashCode = Arrays.deepHashCode(this.params);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(@Nullable Object other)
/*    */   {
/* 65 */     return (this == other) || (((other instanceof SimpleKey)) && 
/* 66 */       (Arrays.deepEquals(this.params, ((SimpleKey)other).params)));
/*    */   }
/*    */   
/*    */ 
/*    */   public final int hashCode()
/*    */   {
/* 72 */     return this.hashCode;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 77 */     return getClass().getSimpleName() + " [" + StringUtils.arrayToCommaDelimitedString(this.params) + "]";
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 81 */     ois.defaultReadObject();
/*    */     
/* 83 */     this.hashCode = Arrays.deepHashCode(this.params);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\cache\interceptor\SimpleKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */