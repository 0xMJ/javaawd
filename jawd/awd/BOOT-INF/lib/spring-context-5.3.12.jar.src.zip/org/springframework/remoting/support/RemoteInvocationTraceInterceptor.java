/*     */ package org.springframework.remoting.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RemoteInvocationTraceInterceptor
/*     */   implements MethodInterceptor
/*     */ {
/*  49 */   protected static final Log logger = LogFactory.getLog(RemoteInvocationTraceInterceptor.class);
/*     */   
/*     */ 
/*     */   private final String exporterNameClause;
/*     */   
/*     */ 
/*     */ 
/*     */   public RemoteInvocationTraceInterceptor()
/*     */   {
/*  58 */     this.exporterNameClause = "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RemoteInvocationTraceInterceptor(String exporterName)
/*     */   {
/*  67 */     this.exporterNameClause = (exporterName + " ");
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*  74 */     Method method = invocation.getMethod();
/*  75 */     if (logger.isDebugEnabled()) {
/*  76 */       logger.debug("Incoming " + this.exporterNameClause + "remote call: " + 
/*  77 */         ClassUtils.getQualifiedMethodName(method));
/*     */     }
/*     */     try {
/*  80 */       Object retVal = invocation.proceed();
/*  81 */       if (logger.isDebugEnabled()) {
/*  82 */         logger.debug("Finished processing of " + this.exporterNameClause + "remote call: " + 
/*  83 */           ClassUtils.getQualifiedMethodName(method));
/*     */       }
/*  85 */       return retVal;
/*     */     }
/*     */     catch (Throwable ex) {
/*  88 */       if (((ex instanceof RuntimeException)) || ((ex instanceof Error))) {
/*  89 */         if (logger.isWarnEnabled()) {
/*  90 */           logger.warn("Processing of " + this.exporterNameClause + "remote call resulted in fatal exception: " + 
/*  91 */             ClassUtils.getQualifiedMethodName(method), ex);
/*     */         }
/*     */         
/*     */       }
/*  95 */       else if (logger.isInfoEnabled()) {
/*  96 */         logger.info("Processing of " + this.exporterNameClause + "remote call resulted in exception: " + 
/*  97 */           ClassUtils.getQualifiedMethodName(method), ex);
/*     */       }
/*     */       
/* 100 */       throw ex;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\support\RemoteInvocationTraceInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */