/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class JndiRmiProxyFactoryBean
/*     */   extends JndiRmiClientInterceptor
/*     */   implements FactoryBean<Object>, BeanClassLoaderAware
/*     */ {
/*  70 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   
/*     */   private Object serviceProxy;
/*     */   
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/*  77 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet() throws NamingException
/*     */   {
/*  82 */     super.afterPropertiesSet();
/*  83 */     Class<?> ifc = getServiceInterface();
/*  84 */     Assert.notNull(ifc, "Property 'serviceInterface' is required");
/*  85 */     this.serviceProxy = new ProxyFactory(ifc, this).getProxy(this.beanClassLoader);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getObject()
/*     */   {
/*  91 */     return this.serviceProxy;
/*     */   }
/*     */   
/*     */   public Class<?> getObjectType()
/*     */   {
/*  96 */     return getServiceInterface();
/*     */   }
/*     */   
/*     */   public boolean isSingleton()
/*     */   {
/* 101 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\rmi\JndiRmiProxyFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */