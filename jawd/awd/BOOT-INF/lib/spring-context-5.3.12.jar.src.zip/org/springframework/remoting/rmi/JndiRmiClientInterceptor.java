/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jndi.JndiObjectLocator;
/*     */ import org.springframework.jndi.JndiTemplate;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteInvocationFailureException;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.support.DefaultRemoteInvocationFactory;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class JndiRmiClientInterceptor
/*     */   extends JndiObjectLocator
/*     */   implements MethodInterceptor, InitializingBean
/*     */ {
/*     */   private Class<?> serviceInterface;
/*  82 */   private RemoteInvocationFactory remoteInvocationFactory = new DefaultRemoteInvocationFactory();
/*     */   
/*  84 */   private boolean lookupStubOnStartup = true;
/*     */   
/*  86 */   private boolean cacheStub = true;
/*     */   
/*  88 */   private boolean refreshStubOnConnectFailure = false;
/*     */   
/*  90 */   private boolean exposeAccessContext = false;
/*     */   
/*     */   private Object cachedStub;
/*     */   
/*  94 */   private final Object stubMonitor = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServiceInterface(Class<?> serviceInterface)
/*     */   {
/* 104 */     Assert.notNull(serviceInterface, "'serviceInterface' must not be null");
/* 105 */     Assert.isTrue(serviceInterface.isInterface(), "'serviceInterface' must be an interface");
/* 106 */     this.serviceInterface = serviceInterface;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Class<?> getServiceInterface()
/*     */   {
/* 113 */     return this.serviceInterface;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteInvocationFactory(RemoteInvocationFactory remoteInvocationFactory)
/*     */   {
/* 123 */     this.remoteInvocationFactory = remoteInvocationFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RemoteInvocationFactory getRemoteInvocationFactory()
/*     */   {
/* 130 */     return this.remoteInvocationFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLookupStubOnStartup(boolean lookupStubOnStartup)
/*     */   {
/* 140 */     this.lookupStubOnStartup = lookupStubOnStartup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheStub(boolean cacheStub)
/*     */   {
/* 151 */     this.cacheStub = cacheStub;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRefreshStubOnConnectFailure(boolean refreshStubOnConnectFailure)
/*     */   {
/* 166 */     this.refreshStubOnConnectFailure = refreshStubOnConnectFailure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExposeAccessContext(boolean exposeAccessContext)
/*     */   {
/* 178 */     this.exposeAccessContext = exposeAccessContext;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */     throws NamingException
/*     */   {
/* 184 */     super.afterPropertiesSet();
/* 185 */     prepare();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prepare()
/*     */     throws RemoteLookupFailureException
/*     */   {
/* 196 */     if (this.lookupStubOnStartup) {
/* 197 */       Object remoteObj = lookupStub();
/* 198 */       if (this.logger.isDebugEnabled()) {
/* 199 */         if ((remoteObj instanceof RmiInvocationHandler)) {
/* 200 */           this.logger.debug("JNDI RMI object [" + getJndiName() + "] is an RMI invoker");
/*     */         }
/* 202 */         else if (getServiceInterface() != null) {
/* 203 */           boolean isImpl = getServiceInterface().isInstance(remoteObj);
/* 204 */           this.logger.debug("Using service interface [" + getServiceInterface().getName() + "] for JNDI RMI object [" + 
/* 205 */             getJndiName() + "] - " + (!isImpl ? "not " : "") + "directly implemented");
/*     */         }
/*     */       }
/*     */       
/* 209 */       if (this.cacheStub) {
/* 210 */         this.cachedStub = remoteObj;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object lookupStub()
/*     */     throws RemoteLookupFailureException
/*     */   {
/*     */     try
/*     */     {
/* 228 */       return lookup();
/*     */     }
/*     */     catch (NamingException ex) {
/* 231 */       throw new RemoteLookupFailureException("JNDI lookup for RMI service [" + getJndiName() + "] failed", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getStub()
/*     */     throws NamingException, RemoteLookupFailureException
/*     */   {
/* 247 */     if ((!this.cacheStub) || ((this.lookupStubOnStartup) && (!this.refreshStubOnConnectFailure))) {
/* 248 */       return this.cachedStub != null ? this.cachedStub : lookupStub();
/*     */     }
/*     */     
/* 251 */     synchronized (this.stubMonitor) {
/* 252 */       if (this.cachedStub == null) {
/* 253 */         this.cachedStub = lookupStub();
/*     */       }
/* 255 */       return this.cachedStub;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 277 */       stub = getStub();
/*     */     } catch (NamingException ex) {
/*     */       Object stub;
/* 280 */       throw new RemoteLookupFailureException("JNDI lookup for RMI service [" + getJndiName() + "] failed", ex);
/*     */     }
/*     */     Object stub;
/* 283 */     Context ctx = this.exposeAccessContext ? getJndiTemplate().getContext() : null;
/*     */     try {
/* 285 */       return doInvoke(invocation, stub);
/*     */     }
/*     */     catch (RemoteConnectFailureException ex) {
/* 288 */       return handleRemoteConnectFailure(invocation, ex);
/*     */     } catch (RemoteException ex) {
/*     */       Object localObject2;
/* 291 */       if (isConnectFailure(ex)) {
/* 292 */         return handleRemoteConnectFailure(invocation, ex);
/*     */       }
/*     */       
/* 295 */       throw ex;
/*     */     }
/*     */     finally
/*     */     {
/* 299 */       getJndiTemplate().releaseContext(ctx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isConnectFailure(RemoteException ex)
/*     */   {
/* 311 */     return RmiClientInterceptorUtils.isConnectFailure(ex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object handleRemoteConnectFailure(MethodInvocation invocation, Exception ex)
/*     */     throws Throwable
/*     */   {
/* 324 */     if (this.refreshStubOnConnectFailure) {
/* 325 */       if (this.logger.isDebugEnabled()) {
/* 326 */         this.logger.debug("Could not connect to RMI service [" + getJndiName() + "] - retrying", ex);
/*     */       }
/* 328 */       else if (this.logger.isInfoEnabled()) {
/* 329 */         this.logger.info("Could not connect to RMI service [" + getJndiName() + "] - retrying");
/*     */       }
/* 331 */       return refreshAndRetry(invocation);
/*     */     }
/*     */     
/* 334 */     throw ex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object refreshAndRetry(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 349 */     synchronized (this.stubMonitor) {
/* 350 */       this.cachedStub = null;
/* 351 */       Object freshStub = lookupStub();
/* 352 */       if (this.cacheStub)
/* 353 */         this.cachedStub = freshStub;
/*     */     }
/*     */     Object freshStub;
/* 356 */     return doInvoke(invocation, freshStub);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object doInvoke(MethodInvocation invocation, Object stub)
/*     */     throws Throwable
/*     */   {
/* 369 */     if ((stub instanceof RmiInvocationHandler)) {
/*     */       try
/*     */       {
/* 372 */         return doInvoke(invocation, (RmiInvocationHandler)stub);
/*     */       }
/*     */       catch (RemoteException ex) {
/* 375 */         throw convertRmiAccessException(ex, invocation.getMethod());
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 378 */         throw ex.getTargetException();
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 382 */         throw new RemoteInvocationFailureException("Invocation of method [" + invocation.getMethod() + "] failed in RMI service [" + getJndiName() + "]", ex);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 388 */       return RmiClientInterceptorUtils.invokeRemoteMethod(invocation, stub);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 391 */       Throwable targetEx = ex.getTargetException();
/* 392 */       if ((targetEx instanceof RemoteException)) {
/* 393 */         throw convertRmiAccessException((RemoteException)targetEx, invocation.getMethod());
/*     */       }
/*     */       
/* 396 */       throw targetEx;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation methodInvocation, RmiInvocationHandler invocationHandler)
/*     */     throws RemoteException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 417 */     if (AopUtils.isToStringMethod(methodInvocation.getMethod())) {
/* 418 */       return "RMI invoker proxy for service URL [" + getJndiName() + "]";
/*     */     }
/*     */     
/* 421 */     return invocationHandler.invoke(createRemoteInvocation(methodInvocation));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RemoteInvocation createRemoteInvocation(MethodInvocation methodInvocation)
/*     */   {
/* 437 */     return getRemoteInvocationFactory().createRemoteInvocation(methodInvocation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Exception convertRmiAccessException(RemoteException ex, Method method)
/*     */   {
/* 449 */     return RmiClientInterceptorUtils.convertRmiAccessException(method, ex, isConnectFailure(ex), getJndiName());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\rmi\JndiRmiClientInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */