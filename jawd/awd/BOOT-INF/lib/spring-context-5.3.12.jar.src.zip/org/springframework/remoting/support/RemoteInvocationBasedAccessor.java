/*    */ package org.springframework.remoting.support;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RemoteInvocationBasedAccessor
/*    */   extends UrlBasedRemoteAccessor
/*    */ {
/* 39 */   private RemoteInvocationFactory remoteInvocationFactory = new DefaultRemoteInvocationFactory();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setRemoteInvocationFactory(RemoteInvocationFactory remoteInvocationFactory)
/*    */   {
/* 49 */     this.remoteInvocationFactory = (remoteInvocationFactory != null ? remoteInvocationFactory : new DefaultRemoteInvocationFactory());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public RemoteInvocationFactory getRemoteInvocationFactory()
/*    */   {
/* 57 */     return this.remoteInvocationFactory;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected RemoteInvocation createRemoteInvocation(MethodInvocation methodInvocation)
/*    */   {
/* 73 */     return getRemoteInvocationFactory().createRemoteInvocation(methodInvocation);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   protected Object recreateRemoteInvocationResult(RemoteInvocationResult result)
/*    */     throws Throwable
/*    */   {
/* 88 */     return result.recreate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\support\RemoteInvocationBasedAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */