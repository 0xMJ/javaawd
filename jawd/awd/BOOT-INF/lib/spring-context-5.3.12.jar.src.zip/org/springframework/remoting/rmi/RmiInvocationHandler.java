package org.springframework.remoting.rmi;

import java.lang.reflect.InvocationTargetException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import org.springframework.lang.Nullable;
import org.springframework.remoting.support.RemoteInvocation;

@Deprecated
public abstract interface RmiInvocationHandler
  extends Remote
{
  @Nullable
  public abstract String getTargetInterfaceName()
    throws RemoteException;
  
  @Nullable
  public abstract Object invoke(RemoteInvocation paramRemoteInvocation)
    throws RemoteException, NoSuchMethodException, IllegalAccessException, InvocationTargetException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\rmi\RmiInvocationHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */