/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Properties;
/*     */ import javax.naming.NamingException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jndi.JndiTemplate;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class JndiRmiServiceExporter
/*     */   extends RmiBasedExporter
/*     */   implements InitializingBean, DisposableBean
/*     */ {
/*     */   @Nullable
/*     */   private static Method exportObject;
/*     */   @Nullable
/*     */   private static Method unexportObject;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  84 */       Class<?> portableRemoteObject = JndiRmiServiceExporter.class.getClassLoader().loadClass("javax.rmi.PortableRemoteObject");
/*  85 */       exportObject = portableRemoteObject.getMethod("exportObject", new Class[] { Remote.class });
/*  86 */       unexportObject = portableRemoteObject.getMethod("unexportObject", new Class[] { Remote.class });
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  90 */       exportObject = null;
/*  91 */       unexportObject = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  96 */   private JndiTemplate jndiTemplate = new JndiTemplate();
/*     */   
/*     */ 
/*     */ 
/*     */   private String jndiName;
/*     */   
/*     */ 
/*     */   private Remote exportedObject;
/*     */   
/*     */ 
/*     */ 
/*     */   public void setJndiTemplate(JndiTemplate jndiTemplate)
/*     */   {
/* 109 */     this.jndiTemplate = (jndiTemplate != null ? jndiTemplate : new JndiTemplate());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJndiEnvironment(Properties jndiEnvironment)
/*     */   {
/* 118 */     this.jndiTemplate = new JndiTemplate(jndiEnvironment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setJndiName(String jndiName)
/*     */   {
/* 125 */     this.jndiName = jndiName;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */     throws NamingException, RemoteException
/*     */   {
/* 131 */     prepare();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prepare()
/*     */     throws NamingException, RemoteException
/*     */   {
/* 140 */     if (this.jndiName == null) {
/* 141 */       throw new IllegalArgumentException("Property 'jndiName' is required");
/*     */     }
/*     */     
/*     */ 
/* 145 */     this.exportedObject = getObjectToExport();
/* 146 */     invokePortableRemoteObject(exportObject);
/*     */     
/* 148 */     rebind();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rebind()
/*     */     throws NamingException
/*     */   {
/* 157 */     if (this.logger.isDebugEnabled()) {
/* 158 */       this.logger.debug("Binding RMI service to JNDI location [" + this.jndiName + "]");
/*     */     }
/* 160 */     this.jndiTemplate.rebind(this.jndiName, this.exportedObject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */     throws NamingException, RemoteException
/*     */   {
/* 168 */     if (this.logger.isDebugEnabled()) {
/* 169 */       this.logger.debug("Unbinding RMI service from JNDI location [" + this.jndiName + "]");
/*     */     }
/* 171 */     this.jndiTemplate.unbind(this.jndiName);
/* 172 */     invokePortableRemoteObject(unexportObject);
/*     */   }
/*     */   
/*     */   private void invokePortableRemoteObject(@Nullable Method method) throws RemoteException
/*     */   {
/* 177 */     if (method != null) {
/*     */       try {
/* 179 */         method.invoke(null, new Object[] { this.exportedObject });
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 182 */         Throwable targetEx = ex.getTargetException();
/* 183 */         if ((targetEx instanceof RemoteException)) {
/* 184 */           throw ((RemoteException)targetEx);
/*     */         }
/* 186 */         ReflectionUtils.rethrowRuntimeException(targetEx);
/*     */       }
/*     */       catch (Throwable ex) {
/* 189 */         throw new IllegalStateException("PortableRemoteObject invocation failed", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\rmi\JndiRmiServiceExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */