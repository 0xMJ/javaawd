/*    */ package org.springframework.remoting.rmi;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.rmi.RemoteException;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.remoting.support.RemoteInvocation;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ class RmiInvocationWrapper
/*    */   implements RmiInvocationHandler
/*    */ {
/*    */   private final Object wrappedObject;
/*    */   private final RmiBasedExporter rmiExporter;
/*    */   
/*    */   public RmiInvocationWrapper(Object wrappedObject, RmiBasedExporter rmiExporter)
/*    */   {
/* 51 */     Assert.notNull(wrappedObject, "Object to wrap is required");
/* 52 */     Assert.notNull(rmiExporter, "RMI exporter is required");
/* 53 */     this.wrappedObject = wrappedObject;
/* 54 */     this.rmiExporter = rmiExporter;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   public String getTargetInterfaceName()
/*    */   {
/* 65 */     Class<?> ifc = this.rmiExporter.getServiceInterface();
/* 66 */     return ifc != null ? ifc.getName() : null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   public Object invoke(RemoteInvocation invocation)
/*    */     throws RemoteException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*    */   {
/* 78 */     return this.rmiExporter.invoke(invocation, this.wrappedObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\rmi\RmiInvocationWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */