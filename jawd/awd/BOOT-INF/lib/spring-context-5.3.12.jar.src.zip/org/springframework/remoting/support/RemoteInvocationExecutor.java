package org.springframework.remoting.support;

import java.lang.reflect.InvocationTargetException;

public abstract interface RemoteInvocationExecutor
{
  public abstract Object invoke(RemoteInvocation paramRemoteInvocation, Object paramObject)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\support\RemoteInvocationExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */