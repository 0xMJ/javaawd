/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.rmi.Naming;
/*     */ import java.rmi.NotBoundException;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.rmi.registry.Registry;
/*     */ import java.rmi.server.RMIClientSocketFactory;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteInvocationFailureException;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.support.RemoteInvocationBasedAccessor;
/*     */ import org.springframework.remoting.support.RemoteInvocationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class RmiClientInterceptor
/*     */   extends RemoteInvocationBasedAccessor
/*     */   implements MethodInterceptor
/*     */ {
/*  76 */   private boolean lookupStubOnStartup = true;
/*     */   
/*  78 */   private boolean cacheStub = true;
/*     */   
/*  80 */   private boolean refreshStubOnConnectFailure = false;
/*     */   
/*     */   private RMIClientSocketFactory registryClientSocketFactory;
/*     */   
/*     */   private Remote cachedStub;
/*     */   
/*  86 */   private final Object stubMonitor = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLookupStubOnStartup(boolean lookupStubOnStartup)
/*     */   {
/*  96 */     this.lookupStubOnStartup = lookupStubOnStartup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheStub(boolean cacheStub)
/*     */   {
/* 107 */     this.cacheStub = cacheStub;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRefreshStubOnConnectFailure(boolean refreshStubOnConnectFailure)
/*     */   {
/* 122 */     this.refreshStubOnConnectFailure = refreshStubOnConnectFailure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRegistryClientSocketFactory(RMIClientSocketFactory registryClientSocketFactory)
/*     */   {
/* 131 */     this.registryClientSocketFactory = registryClientSocketFactory;
/*     */   }
/*     */   
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 137 */     super.afterPropertiesSet();
/* 138 */     prepare();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prepare()
/*     */     throws RemoteLookupFailureException
/*     */   {
/* 149 */     if (this.lookupStubOnStartup) {
/* 150 */       Remote remoteObj = lookupStub();
/* 151 */       if (this.logger.isDebugEnabled()) {
/* 152 */         if ((remoteObj instanceof RmiInvocationHandler)) {
/* 153 */           this.logger.debug("RMI stub [" + getServiceUrl() + "] is an RMI invoker");
/*     */         }
/* 155 */         else if (getServiceInterface() != null) {
/* 156 */           boolean isImpl = getServiceInterface().isInstance(remoteObj);
/* 157 */           this.logger.debug("Using service interface [" + getServiceInterface().getName() + "] for RMI stub [" + 
/* 158 */             getServiceUrl() + "] - " + (!isImpl ? "not " : "") + "directly implemented");
/*     */         }
/*     */       }
/*     */       
/* 162 */       if (this.cacheStub) {
/* 163 */         this.cachedStub = remoteObj;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Remote lookupStub()
/*     */     throws RemoteLookupFailureException
/*     */   {
/*     */     try
/*     */     {
/* 181 */       Remote stub = null;
/* 182 */       if (this.registryClientSocketFactory != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 187 */         URL url = new URL(null, getServiceUrl(), new DummyURLStreamHandler(null));
/* 188 */         String protocol = url.getProtocol();
/* 189 */         if ((protocol != null) && (!"rmi".equals(protocol))) {
/* 190 */           throw new MalformedURLException("Invalid URL scheme '" + protocol + "'");
/*     */         }
/* 192 */         String host = url.getHost();
/* 193 */         int port = url.getPort();
/* 194 */         String name = url.getPath();
/* 195 */         if ((name != null) && (name.startsWith("/"))) {
/* 196 */           name = name.substring(1);
/*     */         }
/* 198 */         Registry registry = LocateRegistry.getRegistry(host, port, this.registryClientSocketFactory);
/* 199 */         stub = registry.lookup(name);
/*     */       }
/*     */       else
/*     */       {
/* 203 */         stub = Naming.lookup(getServiceUrl());
/*     */       }
/* 205 */       if (this.logger.isDebugEnabled()) {
/* 206 */         this.logger.debug("Located RMI stub with URL [" + getServiceUrl() + "]");
/*     */       }
/* 208 */       return stub;
/*     */     }
/*     */     catch (MalformedURLException ex) {
/* 211 */       throw new RemoteLookupFailureException("Service URL [" + getServiceUrl() + "] is invalid", ex);
/*     */     }
/*     */     catch (NotBoundException ex)
/*     */     {
/* 215 */       throw new RemoteLookupFailureException("Could not find RMI service [" + getServiceUrl() + "] in RMI registry", ex);
/*     */     }
/*     */     catch (RemoteException ex) {
/* 218 */       throw new RemoteLookupFailureException("Lookup of RMI stub failed", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Remote getStub()
/*     */     throws RemoteLookupFailureException
/*     */   {
/* 234 */     if ((!this.cacheStub) || ((this.lookupStubOnStartup) && (!this.refreshStubOnConnectFailure))) {
/* 235 */       return this.cachedStub != null ? this.cachedStub : lookupStub();
/*     */     }
/*     */     
/* 238 */     synchronized (this.stubMonitor) {
/* 239 */       if (this.cachedStub == null) {
/* 240 */         this.cachedStub = lookupStub();
/*     */       }
/* 242 */       return this.cachedStub;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 262 */     Remote stub = getStub();
/*     */     try {
/* 264 */       return doInvoke(invocation, stub);
/*     */     }
/*     */     catch (RemoteConnectFailureException ex) {
/* 267 */       return handleRemoteConnectFailure(invocation, ex);
/*     */     }
/*     */     catch (RemoteException ex) {
/* 270 */       if (isConnectFailure(ex)) {
/* 271 */         return handleRemoteConnectFailure(invocation, ex);
/*     */       }
/*     */       
/* 274 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isConnectFailure(RemoteException ex)
/*     */   {
/* 287 */     return RmiClientInterceptorUtils.isConnectFailure(ex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Object handleRemoteConnectFailure(MethodInvocation invocation, Exception ex)
/*     */     throws Throwable
/*     */   {
/* 304 */     if (this.refreshStubOnConnectFailure) {
/* 305 */       String msg = "Could not connect to RMI service [" + getServiceUrl() + "] - retrying";
/* 306 */       if (this.logger.isDebugEnabled()) {
/* 307 */         this.logger.warn(msg, ex);
/*     */       }
/* 309 */       else if (this.logger.isWarnEnabled()) {
/* 310 */         this.logger.warn(msg);
/*     */       }
/* 312 */       return refreshAndRetry(invocation);
/*     */     }
/*     */     
/* 315 */     throw ex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object refreshAndRetry(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 329 */     Remote freshStub = null;
/* 330 */     synchronized (this.stubMonitor) {
/* 331 */       this.cachedStub = null;
/* 332 */       freshStub = lookupStub();
/* 333 */       if (this.cacheStub) {
/* 334 */         this.cachedStub = freshStub;
/*     */       }
/*     */     }
/* 337 */     return doInvoke(invocation, freshStub);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object doInvoke(MethodInvocation invocation, Remote stub)
/*     */     throws Throwable
/*     */   {
/* 349 */     if ((stub instanceof RmiInvocationHandler)) {
/*     */       try
/*     */       {
/* 352 */         return doInvoke(invocation, (RmiInvocationHandler)stub);
/*     */       }
/*     */       catch (RemoteException ex) {
/* 355 */         throw RmiClientInterceptorUtils.convertRmiAccessException(invocation
/* 356 */           .getMethod(), ex, isConnectFailure(ex), getServiceUrl());
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 359 */         Throwable exToThrow = ex.getTargetException();
/* 360 */         RemoteInvocationUtils.fillInClientStackTraceIfPossible(exToThrow);
/* 361 */         throw exToThrow;
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 365 */         throw new RemoteInvocationFailureException("Invocation of method [" + invocation.getMethod() + "] failed in RMI service [" + getServiceUrl() + "]", ex);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 371 */       return RmiClientInterceptorUtils.invokeRemoteMethod(invocation, stub);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 374 */       Throwable targetEx = ex.getTargetException();
/* 375 */       if ((targetEx instanceof RemoteException)) {
/* 376 */         RemoteException rex = (RemoteException)targetEx;
/* 377 */         throw RmiClientInterceptorUtils.convertRmiAccessException(invocation
/* 378 */           .getMethod(), rex, isConnectFailure(rex), getServiceUrl());
/*     */       }
/*     */       
/* 381 */       throw targetEx;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object doInvoke(MethodInvocation methodInvocation, RmiInvocationHandler invocationHandler)
/*     */     throws RemoteException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 403 */     if (AopUtils.isToStringMethod(methodInvocation.getMethod())) {
/* 404 */       return "RMI invoker proxy for service URL [" + getServiceUrl() + "]";
/*     */     }
/*     */     
/* 407 */     return invocationHandler.invoke(createRemoteInvocation(methodInvocation));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class DummyURLStreamHandler
/*     */     extends URLStreamHandler
/*     */   {
/*     */     protected URLConnection openConnection(URL url)
/*     */       throws IOException
/*     */     {
/* 420 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\rmi\RmiClientInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */