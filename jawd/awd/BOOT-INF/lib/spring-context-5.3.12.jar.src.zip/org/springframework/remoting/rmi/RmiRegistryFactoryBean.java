/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.rmi.registry.Registry;
/*     */ import java.rmi.server.RMIClientSocketFactory;
/*     */ import java.rmi.server.RMIServerSocketFactory;
/*     */ import java.rmi.server.UnicastRemoteObject;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class RmiRegistryFactoryBean
/*     */   implements FactoryBean<Registry>, InitializingBean, DisposableBean
/*     */ {
/*  68 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private String host;
/*     */   
/*  72 */   private int port = 1099;
/*     */   
/*     */   private RMIClientSocketFactory clientSocketFactory;
/*     */   
/*     */   private RMIServerSocketFactory serverSocketFactory;
/*     */   
/*     */   private Registry registry;
/*     */   
/*  80 */   private boolean alwaysCreate = false;
/*     */   
/*  82 */   private boolean created = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHost(String host)
/*     */   {
/*  91 */     this.host = host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getHost()
/*     */   {
/*  98 */     return this.host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 107 */     this.port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 114 */     return this.port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setClientSocketFactory(RMIClientSocketFactory clientSocketFactory)
/*     */   {
/* 127 */     this.clientSocketFactory = clientSocketFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServerSocketFactory(RMIServerSocketFactory serverSocketFactory)
/*     */   {
/* 140 */     this.serverSocketFactory = serverSocketFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlwaysCreate(boolean alwaysCreate)
/*     */   {
/* 151 */     this.alwaysCreate = alwaysCreate;
/*     */   }
/*     */   
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 158 */     if ((this.clientSocketFactory instanceof RMIServerSocketFactory)) {
/* 159 */       this.serverSocketFactory = ((RMIServerSocketFactory)this.clientSocketFactory);
/*     */     }
/* 161 */     if (((this.clientSocketFactory != null) && (this.serverSocketFactory == null)) || ((this.clientSocketFactory == null) && (this.serverSocketFactory != null)))
/*     */     {
/* 163 */       throw new IllegalArgumentException("Both RMIClientSocketFactory and RMIServerSocketFactory or none required");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 168 */     this.registry = getRegistry(this.host, this.port, this.clientSocketFactory, this.serverSocketFactory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Registry getRegistry(String registryHost, int registryPort, @Nullable RMIClientSocketFactory clientSocketFactory, @Nullable RMIServerSocketFactory serverSocketFactory)
/*     */     throws RemoteException
/*     */   {
/* 186 */     if (registryHost != null)
/*     */     {
/* 188 */       if (this.logger.isDebugEnabled()) {
/* 189 */         this.logger.debug("Looking for RMI registry at port '" + registryPort + "' of host [" + registryHost + "]");
/*     */       }
/* 191 */       Registry reg = LocateRegistry.getRegistry(registryHost, registryPort, clientSocketFactory);
/* 192 */       testRegistry(reg);
/* 193 */       return reg;
/*     */     }
/*     */     
/*     */ 
/* 197 */     return getRegistry(registryPort, clientSocketFactory, serverSocketFactory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Registry getRegistry(int registryPort, @Nullable RMIClientSocketFactory clientSocketFactory, @Nullable RMIServerSocketFactory serverSocketFactory)
/*     */     throws RemoteException
/*     */   {
/* 213 */     if (clientSocketFactory != null) {
/* 214 */       if (this.alwaysCreate) {
/* 215 */         this.logger.debug("Creating new RMI registry");
/* 216 */         this.created = true;
/* 217 */         return LocateRegistry.createRegistry(registryPort, clientSocketFactory, serverSocketFactory);
/*     */       }
/* 219 */       if (this.logger.isDebugEnabled()) {
/* 220 */         this.logger.debug("Looking for RMI registry at port '" + registryPort + "', using custom socket factory");
/*     */       }
/* 222 */       synchronized (LocateRegistry.class)
/*     */       {
/*     */         try {
/* 225 */           Registry reg = LocateRegistry.getRegistry(null, registryPort, clientSocketFactory);
/* 226 */           testRegistry(reg);
/* 227 */           return reg;
/*     */         }
/*     */         catch (RemoteException ex) {
/* 230 */           this.logger.trace("RMI registry access threw exception", ex);
/* 231 */           this.logger.debug("Could not detect RMI registry - creating new one");
/*     */           
/* 233 */           this.created = true;
/* 234 */           return LocateRegistry.createRegistry(registryPort, clientSocketFactory, serverSocketFactory);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 240 */     return getRegistry(registryPort);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Registry getRegistry(int registryPort)
/*     */     throws RemoteException
/*     */   {
/* 251 */     if (this.alwaysCreate) {
/* 252 */       this.logger.debug("Creating new RMI registry");
/* 253 */       this.created = true;
/* 254 */       return LocateRegistry.createRegistry(registryPort);
/*     */     }
/* 256 */     if (this.logger.isDebugEnabled()) {
/* 257 */       this.logger.debug("Looking for RMI registry at port '" + registryPort + "'");
/*     */     }
/* 259 */     synchronized (LocateRegistry.class)
/*     */     {
/*     */       try {
/* 262 */         Registry reg = LocateRegistry.getRegistry(registryPort);
/* 263 */         testRegistry(reg);
/* 264 */         return reg;
/*     */       }
/*     */       catch (RemoteException ex) {
/* 267 */         this.logger.trace("RMI registry access threw exception", ex);
/* 268 */         this.logger.debug("Could not detect RMI registry - creating new one");
/*     */         
/* 270 */         this.created = true;
/* 271 */         return LocateRegistry.createRegistry(registryPort);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void testRegistry(Registry registry)
/*     */     throws RemoteException
/*     */   {
/* 285 */     registry.list();
/*     */   }
/*     */   
/*     */   public Registry getObject()
/*     */     throws Exception
/*     */   {
/* 291 */     return this.registry;
/*     */   }
/*     */   
/*     */   public Class<? extends Registry> getObjectType()
/*     */   {
/* 296 */     return this.registry != null ? this.registry.getClass() : Registry.class;
/*     */   }
/*     */   
/*     */   public boolean isSingleton()
/*     */   {
/* 301 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */     throws RemoteException
/*     */   {
/* 311 */     if (this.created) {
/* 312 */       this.logger.debug("Unexporting RMI registry");
/* 313 */       UnicastRemoteObject.unexportObject(this.registry, true);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\rmi\RmiRegistryFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */