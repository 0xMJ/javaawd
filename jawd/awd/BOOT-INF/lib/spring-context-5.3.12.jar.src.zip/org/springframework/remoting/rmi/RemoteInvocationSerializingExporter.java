/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.rmi.RemoteException;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationBasedExporter;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class RemoteInvocationSerializingExporter
/*     */   extends RemoteInvocationBasedExporter
/*     */   implements InitializingBean
/*     */ {
/*     */   public static final String CONTENT_TYPE_SERIALIZED_OBJECT = "application/x-java-serialized-object";
/*  60 */   private String contentType = "application/x-java-serialized-object";
/*     */   
/*  62 */   private boolean acceptProxyClasses = true;
/*     */   
/*     */ 
/*     */ 
/*     */   private Object proxy;
/*     */   
/*     */ 
/*     */ 
/*     */   public void setContentType(String contentType)
/*     */   {
/*  72 */     Assert.notNull(contentType, "'contentType' must not be null");
/*  73 */     this.contentType = contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getContentType()
/*     */   {
/*  80 */     return this.contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAcceptProxyClasses(boolean acceptProxyClasses)
/*     */   {
/*  88 */     this.acceptProxyClasses = acceptProxyClasses;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isAcceptProxyClasses()
/*     */   {
/*  95 */     return this.acceptProxyClasses;
/*     */   }
/*     */   
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 101 */     prepare();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void prepare()
/*     */   {
/* 108 */     this.proxy = getProxyForService();
/*     */   }
/*     */   
/*     */   protected final Object getProxy() {
/* 112 */     if (this.proxy == null) {
/* 113 */       throw new IllegalStateException(ClassUtils.getShortName(getClass()) + " has not been initialized");
/*     */     }
/* 115 */     return this.proxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ObjectInputStream createObjectInputStream(InputStream is)
/*     */     throws IOException
/*     */   {
/* 127 */     return new CodebaseAwareObjectInputStream(is, getBeanClassLoader(), isAcceptProxyClasses());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RemoteInvocation doReadRemoteInvocation(ObjectInputStream ois)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 146 */     Object obj = ois.readObject();
/* 147 */     if (!(obj instanceof RemoteInvocation))
/*     */     {
/* 149 */       throw new RemoteException("Deserialized object needs to be assignable to type [" + RemoteInvocation.class.getName() + "]: " + ClassUtils.getDescriptiveType(obj));
/*     */     }
/* 151 */     return (RemoteInvocation)obj;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ObjectOutputStream createObjectOutputStream(OutputStream os)
/*     */     throws IOException
/*     */   {
/* 163 */     return new ObjectOutputStream(os);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doWriteRemoteInvocationResult(RemoteInvocationResult result, ObjectOutputStream oos)
/*     */     throws IOException
/*     */   {
/* 180 */     oos.writeObject(result);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\rmi\RemoteInvocationSerializingExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */