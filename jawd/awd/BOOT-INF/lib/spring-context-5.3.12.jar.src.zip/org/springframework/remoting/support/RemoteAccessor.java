/*    */ package org.springframework.remoting.support;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RemoteAccessor
/*    */   extends RemotingSupport
/*    */ {
/*    */   private Class<?> serviceInterface;
/*    */   
/*    */   public void setServiceInterface(Class<?> serviceInterface)
/*    */   {
/* 51 */     Assert.notNull(serviceInterface, "'serviceInterface' must not be null");
/* 52 */     Assert.isTrue(serviceInterface.isInterface(), "'serviceInterface' must be an interface");
/* 53 */     this.serviceInterface = serviceInterface;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Class<?> getServiceInterface()
/*    */   {
/* 60 */     return this.serviceInterface;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\support\RemoteAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */