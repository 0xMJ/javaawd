/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.rmi.server.RMIClassLoader;
/*     */ import org.springframework.core.ConfigurableObjectInputStream;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class CodebaseAwareObjectInputStream
/*     */   extends ConfigurableObjectInputStream
/*     */ {
/*     */   private final String codebaseUrl;
/*     */   
/*     */   public CodebaseAwareObjectInputStream(InputStream in, String codebaseUrl)
/*     */     throws IOException
/*     */   {
/*  69 */     this(in, null, codebaseUrl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CodebaseAwareObjectInputStream(InputStream in, @Nullable ClassLoader classLoader, String codebaseUrl)
/*     */     throws IOException
/*     */   {
/*  84 */     super(in, classLoader);
/*  85 */     this.codebaseUrl = codebaseUrl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CodebaseAwareObjectInputStream(InputStream in, @Nullable ClassLoader classLoader, boolean acceptProxyClasses)
/*     */     throws IOException
/*     */   {
/* 100 */     super(in, classLoader, acceptProxyClasses);
/* 101 */     this.codebaseUrl = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> resolveFallbackIfPossible(String className, ClassNotFoundException ex)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 111 */     if (this.codebaseUrl == null) {
/* 112 */       throw ex;
/*     */     }
/* 114 */     return RMIClassLoader.loadClass(this.codebaseUrl, className);
/*     */   }
/*     */   
/*     */   protected ClassLoader getFallbackClassLoader() throws IOException
/*     */   {
/* 119 */     return RMIClassLoader.getClassLoader(this.codebaseUrl);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\rmi\CodebaseAwareObjectInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */