/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.rmi.AlreadyBoundException;
/*     */ import java.rmi.NoSuchObjectException;
/*     */ import java.rmi.NotBoundException;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.rmi.registry.Registry;
/*     */ import java.rmi.server.RMIClientSocketFactory;
/*     */ import java.rmi.server.RMIServerSocketFactory;
/*     */ import java.rmi.server.UnicastRemoteObject;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class RmiServiceExporter
/*     */   extends RmiBasedExporter
/*     */   implements InitializingBean, DisposableBean
/*     */ {
/*     */   private String serviceName;
/*  75 */   private int servicePort = 0;
/*     */   
/*     */   private RMIClientSocketFactory clientSocketFactory;
/*     */   
/*     */   private RMIServerSocketFactory serverSocketFactory;
/*     */   
/*     */   private Registry registry;
/*     */   
/*     */   private String registryHost;
/*     */   
/*  85 */   private int registryPort = 1099;
/*     */   
/*     */   private RMIClientSocketFactory registryClientSocketFactory;
/*     */   
/*     */   private RMIServerSocketFactory registryServerSocketFactory;
/*     */   
/*  91 */   private boolean alwaysCreateRegistry = false;
/*     */   
/*  93 */   private boolean replaceExistingBinding = true;
/*     */   
/*     */   private Remote exportedObject;
/*     */   
/*  97 */   private boolean createdRegistry = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServiceName(String serviceName)
/*     */   {
/* 105 */     this.serviceName = serviceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServicePort(int servicePort)
/*     */   {
/* 113 */     this.servicePort = servicePort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setClientSocketFactory(RMIClientSocketFactory clientSocketFactory)
/*     */   {
/* 126 */     this.clientSocketFactory = clientSocketFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServerSocketFactory(RMIServerSocketFactory serverSocketFactory)
/*     */   {
/* 139 */     this.serverSocketFactory = serverSocketFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRegistry(Registry registry)
/*     */   {
/* 157 */     this.registry = registry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRegistryHost(String registryHost)
/*     */   {
/* 166 */     this.registryHost = registryHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRegistryPort(int registryPort)
/*     */   {
/* 176 */     this.registryPort = registryPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRegistryClientSocketFactory(RMIClientSocketFactory registryClientSocketFactory)
/*     */   {
/* 189 */     this.registryClientSocketFactory = registryClientSocketFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRegistryServerSocketFactory(RMIServerSocketFactory registryServerSocketFactory)
/*     */   {
/* 202 */     this.registryServerSocketFactory = registryServerSocketFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlwaysCreateRegistry(boolean alwaysCreateRegistry)
/*     */   {
/* 213 */     this.alwaysCreateRegistry = alwaysCreateRegistry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReplaceExistingBinding(boolean replaceExistingBinding)
/*     */   {
/* 226 */     this.replaceExistingBinding = replaceExistingBinding;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */     throws RemoteException
/*     */   {
/* 232 */     prepare();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prepare()
/*     */     throws RemoteException
/*     */   {
/* 241 */     checkService();
/*     */     
/* 243 */     if (this.serviceName == null) {
/* 244 */       throw new IllegalArgumentException("Property 'serviceName' is required");
/*     */     }
/*     */     
/*     */ 
/* 248 */     if ((this.clientSocketFactory instanceof RMIServerSocketFactory)) {
/* 249 */       this.serverSocketFactory = ((RMIServerSocketFactory)this.clientSocketFactory);
/*     */     }
/* 251 */     if (((this.clientSocketFactory != null) && (this.serverSocketFactory == null)) || ((this.clientSocketFactory == null) && (this.serverSocketFactory != null)))
/*     */     {
/* 253 */       throw new IllegalArgumentException("Both RMIClientSocketFactory and RMIServerSocketFactory or none required");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 258 */     if ((this.registryClientSocketFactory instanceof RMIServerSocketFactory)) {
/* 259 */       this.registryServerSocketFactory = ((RMIServerSocketFactory)this.registryClientSocketFactory);
/*     */     }
/* 261 */     if ((this.registryClientSocketFactory == null) && (this.registryServerSocketFactory != null)) {
/* 262 */       throw new IllegalArgumentException("RMIServerSocketFactory without RMIClientSocketFactory for registry not supported");
/*     */     }
/*     */     
/*     */ 
/* 266 */     this.createdRegistry = false;
/*     */     
/*     */ 
/* 269 */     if (this.registry == null) {
/* 270 */       this.registry = getRegistry(this.registryHost, this.registryPort, this.registryClientSocketFactory, this.registryServerSocketFactory);
/*     */       
/* 272 */       this.createdRegistry = true;
/*     */     }
/*     */     
/*     */ 
/* 276 */     this.exportedObject = getObjectToExport();
/*     */     
/* 278 */     if (this.logger.isDebugEnabled()) {
/* 279 */       this.logger.debug("Binding service '" + this.serviceName + "' to RMI registry: " + this.registry);
/*     */     }
/*     */     
/*     */ 
/* 283 */     if (this.clientSocketFactory != null) {
/* 284 */       UnicastRemoteObject.exportObject(this.exportedObject, this.servicePort, this.clientSocketFactory, this.serverSocketFactory);
/*     */     }
/*     */     else
/*     */     {
/* 288 */       UnicastRemoteObject.exportObject(this.exportedObject, this.servicePort);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 293 */       if (this.replaceExistingBinding) {
/* 294 */         this.registry.rebind(this.serviceName, this.exportedObject);
/*     */       }
/*     */       else {
/* 297 */         this.registry.bind(this.serviceName, this.exportedObject);
/*     */       }
/*     */     }
/*     */     catch (AlreadyBoundException ex)
/*     */     {
/* 302 */       unexportObjectSilently();
/*     */       
/* 304 */       throw new IllegalStateException("Already an RMI object bound for name '" + this.serviceName + "': " + ex.toString());
/*     */     }
/*     */     catch (RemoteException ex)
/*     */     {
/* 308 */       unexportObjectSilently();
/* 309 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Registry getRegistry(String registryHost, int registryPort, @Nullable RMIClientSocketFactory clientSocketFactory, @Nullable RMIServerSocketFactory serverSocketFactory)
/*     */     throws RemoteException
/*     */   {
/* 328 */     if (registryHost != null)
/*     */     {
/* 330 */       if (this.logger.isDebugEnabled()) {
/* 331 */         this.logger.debug("Looking for RMI registry at port '" + registryPort + "' of host [" + registryHost + "]");
/*     */       }
/* 333 */       Registry reg = LocateRegistry.getRegistry(registryHost, registryPort, clientSocketFactory);
/* 334 */       testRegistry(reg);
/* 335 */       return reg;
/*     */     }
/*     */     
/*     */ 
/* 339 */     return getRegistry(registryPort, clientSocketFactory, serverSocketFactory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Registry getRegistry(int registryPort, @Nullable RMIClientSocketFactory clientSocketFactory, @Nullable RMIServerSocketFactory serverSocketFactory)
/*     */     throws RemoteException
/*     */   {
/* 355 */     if (clientSocketFactory != null) {
/* 356 */       if (this.alwaysCreateRegistry) {
/* 357 */         this.logger.debug("Creating new RMI registry");
/* 358 */         return LocateRegistry.createRegistry(registryPort, clientSocketFactory, serverSocketFactory);
/*     */       }
/* 360 */       if (this.logger.isDebugEnabled()) {
/* 361 */         this.logger.debug("Looking for RMI registry at port '" + registryPort + "', using custom socket factory");
/*     */       }
/* 363 */       synchronized (LocateRegistry.class)
/*     */       {
/*     */         try {
/* 366 */           Registry reg = LocateRegistry.getRegistry(null, registryPort, clientSocketFactory);
/* 367 */           testRegistry(reg);
/* 368 */           return reg;
/*     */         }
/*     */         catch (RemoteException ex) {
/* 371 */           this.logger.trace("RMI registry access threw exception", ex);
/* 372 */           this.logger.debug("Could not detect RMI registry - creating new one");
/*     */           
/* 374 */           return LocateRegistry.createRegistry(registryPort, clientSocketFactory, serverSocketFactory);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 380 */     return getRegistry(registryPort);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Registry getRegistry(int registryPort)
/*     */     throws RemoteException
/*     */   {
/* 391 */     if (this.alwaysCreateRegistry) {
/* 392 */       this.logger.debug("Creating new RMI registry");
/* 393 */       return LocateRegistry.createRegistry(registryPort);
/*     */     }
/* 395 */     if (this.logger.isDebugEnabled()) {
/* 396 */       this.logger.debug("Looking for RMI registry at port '" + registryPort + "'");
/*     */     }
/* 398 */     synchronized (LocateRegistry.class)
/*     */     {
/*     */       try {
/* 401 */         Registry reg = LocateRegistry.getRegistry(registryPort);
/* 402 */         testRegistry(reg);
/* 403 */         return reg;
/*     */       }
/*     */       catch (RemoteException ex) {
/* 406 */         this.logger.trace("RMI registry access threw exception", ex);
/* 407 */         this.logger.debug("Could not detect RMI registry - creating new one");
/*     */         
/* 409 */         return LocateRegistry.createRegistry(registryPort);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void testRegistry(Registry registry)
/*     */     throws RemoteException
/*     */   {
/* 423 */     registry.list();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */     throws RemoteException
/*     */   {
/* 432 */     if (this.logger.isDebugEnabled()) {
/* 433 */       this.logger.debug("Unbinding RMI service '" + this.serviceName + "' from registry" + (this.createdRegistry ? " at port '" + this.registryPort + "'" : ""));
/*     */     }
/*     */     try
/*     */     {
/* 437 */       this.registry.unbind(this.serviceName);
/*     */     }
/*     */     catch (NotBoundException ex) {
/* 440 */       if (this.logger.isInfoEnabled()) {
/* 441 */         this.logger.info("RMI service '" + this.serviceName + "' is not bound to registry" + (this.createdRegistry ? " at port '" + this.registryPort + "' anymore" : ""), ex);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 446 */       unexportObjectSilently();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void unexportObjectSilently()
/*     */   {
/*     */     try
/*     */     {
/* 455 */       UnicastRemoteObject.unexportObject(this.exportedObject, true);
/*     */     }
/*     */     catch (NoSuchObjectException ex) {
/* 458 */       if (this.logger.isInfoEnabled()) {
/* 459 */         this.logger.info("RMI object for service '" + this.serviceName + "' is not exported anymore", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\rmi\RmiServiceExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */