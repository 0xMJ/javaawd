/*    */ package org.springframework.remoting.rmi;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.rmi.Remote;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.remoting.support.RemoteInvocation;
/*    */ import org.springframework.remoting.support.RemoteInvocationBasedExporter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class RmiBasedExporter
/*    */   extends RemoteInvocationBasedExporter
/*    */ {
/*    */   protected Remote getObjectToExport()
/*    */   {
/* 53 */     if (((getService() instanceof Remote)) && (
/* 54 */       (getServiceInterface() == null) || (Remote.class.isAssignableFrom(getServiceInterface()))))
/*    */     {
/* 56 */       return (Remote)getService();
/*    */     }
/*    */     
/*    */ 
/* 60 */     if (this.logger.isDebugEnabled()) {
/* 61 */       this.logger.debug("RMI service [" + getService() + "] is an RMI invoker");
/*    */     }
/* 63 */     return new RmiInvocationWrapper(getProxyForService(), this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Object invoke(RemoteInvocation invocation, Object targetObject)
/*    */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*    */   {
/* 75 */     return super.invoke(invocation, targetObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\remoting\rmi\RmiBasedExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */