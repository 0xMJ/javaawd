/*     */ package org.springframework.jndi;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.beans.SimpleTypeConverter;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JndiObjectFactoryBean
/*     */   extends JndiObjectLocator
/*     */   implements FactoryBean<Object>, BeanFactoryAware, BeanClassLoaderAware
/*     */ {
/*     */   @Nullable
/*     */   private Class<?>[] proxyInterfaces;
/*     */   private boolean lookupOnStartup;
/*     */   private boolean cache;
/*     */   private boolean exposeAccessContext;
/*     */   @Nullable
/*     */   private Object defaultObject;
/*     */   @Nullable
/*     */   private ConfigurableBeanFactory beanFactory;
/*     */   
/*     */   public JndiObjectFactoryBean()
/*     */   {
/*  79 */     this.lookupOnStartup = true;
/*     */     
/*  81 */     this.cache = true;
/*     */     
/*  83 */     this.exposeAccessContext = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*  92 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Object jndiObject;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyInterface(Class<?> proxyInterface)
/*     */   {
/* 108 */     this.proxyInterfaces = new Class[] { proxyInterface };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyInterfaces(Class<?>... proxyInterfaces)
/*     */   {
/* 121 */     this.proxyInterfaces = proxyInterfaces;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLookupOnStartup(boolean lookupOnStartup)
/*     */   {
/* 133 */     this.lookupOnStartup = lookupOnStartup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCache(boolean cache)
/*     */   {
/* 146 */     this.cache = cache;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExposeAccessContext(boolean exposeAccessContext)
/*     */   {
/* 159 */     this.exposeAccessContext = exposeAccessContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultObject(Object defaultObject)
/*     */   {
/* 176 */     this.defaultObject = defaultObject;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 181 */     if ((beanFactory instanceof ConfigurableBeanFactory))
/*     */     {
/*     */ 
/* 184 */       this.beanFactory = ((ConfigurableBeanFactory)beanFactory);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 190 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws IllegalArgumentException, NamingException
/*     */   {
/* 199 */     super.afterPropertiesSet();
/*     */     
/* 201 */     if ((this.proxyInterfaces != null) || (!this.lookupOnStartup) || (!this.cache) || (this.exposeAccessContext))
/*     */     {
/* 203 */       if (this.defaultObject != null) {
/* 204 */         throw new IllegalArgumentException("'defaultObject' is not supported in combination with 'proxyInterface'");
/*     */       }
/*     */       
/*     */ 
/* 208 */       this.jndiObject = JndiObjectProxyFactory.createJndiObjectProxy(this);
/*     */     }
/*     */     else {
/* 211 */       if ((this.defaultObject != null) && (getExpectedType() != null) && 
/* 212 */         (!getExpectedType().isInstance(this.defaultObject)))
/*     */       {
/* 214 */         TypeConverter converter = this.beanFactory != null ? this.beanFactory.getTypeConverter() : new SimpleTypeConverter();
/*     */         try {
/* 216 */           this.defaultObject = converter.convertIfNecessary(this.defaultObject, getExpectedType());
/*     */ 
/*     */         }
/*     */         catch (TypeMismatchException ex)
/*     */         {
/* 221 */           throw new IllegalArgumentException("Default object [" + this.defaultObject + "] of type [" + this.defaultObject.getClass().getName() + "] is not of expected type [" + getExpectedType().getName() + "] and cannot be converted either", ex);
/*     */         }
/*     */       }
/*     */       
/* 225 */       this.jndiObject = lookupWithFallback();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object lookupWithFallback()
/*     */     throws NamingException
/*     */   {
/* 237 */     ClassLoader originalClassLoader = ClassUtils.overrideThreadContextClassLoader(this.beanClassLoader);
/*     */     try {
/* 239 */       return lookup();
/*     */ 
/*     */     }
/*     */     catch (TypeMismatchNamingException ex)
/*     */     {
/* 244 */       throw ex;
/*     */     }
/*     */     catch (NamingException ex) {
/* 247 */       if (this.defaultObject != null) {
/* 248 */         if (this.logger.isTraceEnabled()) {
/* 249 */           this.logger.trace("JNDI lookup failed - returning specified default object instead", ex);
/*     */         }
/* 251 */         else if (this.logger.isDebugEnabled()) {
/* 252 */           this.logger.debug("JNDI lookup failed - returning specified default object instead: " + ex);
/*     */         }
/* 254 */         return this.defaultObject;
/*     */       }
/* 256 */       throw ex;
/*     */     }
/*     */     finally {
/* 259 */       if (originalClassLoader != null) {
/* 260 */         Thread.currentThread().setContextClassLoader(originalClassLoader);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object getObject()
/*     */   {
/* 272 */     return this.jndiObject;
/*     */   }
/*     */   
/*     */   public Class<?> getObjectType()
/*     */   {
/* 277 */     if (this.proxyInterfaces != null) {
/* 278 */       if (this.proxyInterfaces.length == 1) {
/* 279 */         return this.proxyInterfaces[0];
/*     */       }
/* 281 */       if (this.proxyInterfaces.length > 1) {
/* 282 */         return createCompositeInterface(this.proxyInterfaces);
/*     */       }
/*     */     }
/* 285 */     if (this.jndiObject != null) {
/* 286 */       return this.jndiObject.getClass();
/*     */     }
/*     */     
/* 289 */     return getExpectedType();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 295 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> createCompositeInterface(Class<?>[] interfaces)
/*     */   {
/* 309 */     return ClassUtils.createCompositeInterface(interfaces, this.beanClassLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class JndiObjectProxyFactory
/*     */   {
/*     */     private static Object createJndiObjectProxy(JndiObjectFactoryBean jof)
/*     */       throws NamingException
/*     */     {
/* 320 */       JndiObjectTargetSource targetSource = new JndiObjectTargetSource();
/* 321 */       targetSource.setJndiTemplate(jof.getJndiTemplate());
/* 322 */       String jndiName = jof.getJndiName();
/* 323 */       Assert.state(jndiName != null, "No JNDI name specified");
/* 324 */       targetSource.setJndiName(jndiName);
/* 325 */       targetSource.setExpectedType(jof.getExpectedType());
/* 326 */       targetSource.setResourceRef(jof.isResourceRef());
/* 327 */       targetSource.setLookupOnStartup(jof.lookupOnStartup);
/* 328 */       targetSource.setCache(jof.cache);
/* 329 */       targetSource.afterPropertiesSet();
/*     */       
/*     */ 
/* 332 */       ProxyFactory proxyFactory = new ProxyFactory();
/* 333 */       if (jof.proxyInterfaces != null) {
/* 334 */         proxyFactory.setInterfaces(jof.proxyInterfaces);
/*     */       }
/*     */       else {
/* 337 */         Class<?> targetClass = targetSource.getTargetClass();
/* 338 */         if (targetClass == null) {
/* 339 */           throw new IllegalStateException("Cannot deactivate 'lookupOnStartup' without specifying a 'proxyInterface' or 'expectedType'");
/*     */         }
/*     */         
/* 342 */         Class<?>[] ifcs = ClassUtils.getAllInterfacesForClass(targetClass, jof.beanClassLoader);
/* 343 */         for (Class<?> ifc : ifcs) {
/* 344 */           if (Modifier.isPublic(ifc.getModifiers())) {
/* 345 */             proxyFactory.addInterface(ifc);
/*     */           }
/*     */         }
/*     */       }
/* 349 */       if (jof.exposeAccessContext) {
/* 350 */         proxyFactory.addAdvice(new JndiObjectFactoryBean.JndiContextExposingInterceptor(jof.getJndiTemplate()));
/*     */       }
/* 352 */       proxyFactory.setTargetSource(targetSource);
/* 353 */       return proxyFactory.getProxy(jof.beanClassLoader);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class JndiContextExposingInterceptor
/*     */     implements MethodInterceptor
/*     */   {
/*     */     private final JndiTemplate jndiTemplate;
/*     */     
/*     */ 
/*     */     public JndiContextExposingInterceptor(JndiTemplate jndiTemplate)
/*     */     {
/* 367 */       this.jndiTemplate = jndiTemplate;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Object invoke(MethodInvocation invocation) throws Throwable
/*     */     {
/* 373 */       Context ctx = isEligible(invocation.getMethod()) ? this.jndiTemplate.getContext() : null;
/*     */       try {
/* 375 */         return invocation.proceed();
/*     */       }
/*     */       finally {
/* 378 */         this.jndiTemplate.releaseContext(ctx);
/*     */       }
/*     */     }
/*     */     
/*     */     protected boolean isEligible(Method method) {
/* 383 */       return Object.class != method.getDeclaringClass();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jndi\JndiObjectFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */