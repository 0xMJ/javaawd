/*     */ package org.springframework.jndi.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.naming.NameNotFoundException;
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.jndi.JndiLocatorSupport;
/*     */ import org.springframework.jndi.TypeMismatchNamingException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleJndiBeanFactory
/*     */   extends JndiLocatorSupport
/*     */   implements BeanFactory
/*     */ {
/*  67 */   private final Set<String> shareableResources = new HashSet();
/*     */   
/*     */ 
/*  70 */   private final Map<String, Object> singletonObjects = new HashMap();
/*     */   
/*     */ 
/*  73 */   private final Map<String, Class<?>> resourceTypes = new HashMap();
/*     */   
/*     */   public SimpleJndiBeanFactory()
/*     */   {
/*  77 */     setResourceRef(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addShareableResource(String shareableResource)
/*     */   {
/*  88 */     this.shareableResources.add(shareableResource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShareableResources(String... shareableResources)
/*     */   {
/*  98 */     Collections.addAll(this.shareableResources, shareableResources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getBean(String name)
/*     */     throws BeansException
/*     */   {
/* 109 */     return getBean(name, Object.class);
/*     */   }
/*     */   
/*     */   public <T> T getBean(String name, Class<T> requiredType) throws BeansException
/*     */   {
/*     */     try {
/* 115 */       if (isSingleton(name)) {
/* 116 */         return (T)doGetSingleton(name, requiredType);
/*     */       }
/*     */       
/* 119 */       return (T)lookup(name, requiredType);
/*     */     }
/*     */     catch (NameNotFoundException ex)
/*     */     {
/* 123 */       throw new NoSuchBeanDefinitionException(name, "not found in JNDI environment");
/*     */     }
/*     */     catch (TypeMismatchNamingException ex) {
/* 126 */       throw new BeanNotOfRequiredTypeException(name, ex.getRequiredType(), ex.getActualType());
/*     */     }
/*     */     catch (NamingException ex) {
/* 129 */       throw new BeanDefinitionStoreException("JNDI environment", name, "JNDI lookup failed", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getBean(String name, @Nullable Object... args) throws BeansException
/*     */   {
/* 135 */     if (args != null) {
/* 136 */       throw new UnsupportedOperationException("SimpleJndiBeanFactory does not support explicit bean creation arguments");
/*     */     }
/*     */     
/* 139 */     return getBean(name);
/*     */   }
/*     */   
/*     */   public <T> T getBean(Class<T> requiredType) throws BeansException
/*     */   {
/* 144 */     return (T)getBean(requiredType.getSimpleName(), requiredType);
/*     */   }
/*     */   
/*     */   public <T> T getBean(Class<T> requiredType, @Nullable Object... args) throws BeansException
/*     */   {
/* 149 */     if (args != null) {
/* 150 */       throw new UnsupportedOperationException("SimpleJndiBeanFactory does not support explicit bean creation arguments");
/*     */     }
/*     */     
/* 153 */     return (T)getBean(requiredType);
/*     */   }
/*     */   
/*     */   public <T> ObjectProvider<T> getBeanProvider(final Class<T> requiredType)
/*     */   {
/* 158 */     new ObjectProvider()
/*     */     {
/*     */       public T getObject() throws BeansException {
/* 161 */         return (T)SimpleJndiBeanFactory.this.getBean(requiredType);
/*     */       }
/*     */       
/*     */       public T getObject(Object... args) throws BeansException {
/* 165 */         return (T)SimpleJndiBeanFactory.this.getBean(requiredType, args);
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public T getIfAvailable() throws BeansException {
/*     */         try {
/* 171 */           return (T)SimpleJndiBeanFactory.this.getBean(requiredType);
/*     */         }
/*     */         catch (NoUniqueBeanDefinitionException ex) {
/* 174 */           throw ex;
/*     */         }
/*     */         catch (NoSuchBeanDefinitionException ex) {}
/* 177 */         return null;
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public T getIfUnique() throws BeansException
/*     */       {
/*     */         try {
/* 184 */           return (T)SimpleJndiBeanFactory.this.getBean(requiredType);
/*     */         }
/*     */         catch (NoSuchBeanDefinitionException ex) {}
/* 187 */         return null;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> ObjectProvider<T> getBeanProvider(ResolvableType requiredType)
/*     */   {
/* 195 */     throw new UnsupportedOperationException("SimpleJndiBeanFactory does not support resolution by ResolvableType");
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean containsBean(String name)
/*     */   {
/* 201 */     if ((this.singletonObjects.containsKey(name)) || (this.resourceTypes.containsKey(name))) {
/* 202 */       return true;
/*     */     }
/*     */     try {
/* 205 */       doGetType(name);
/* 206 */       return true;
/*     */     }
/*     */     catch (NamingException ex) {}
/* 209 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isSingleton(String name)
/*     */     throws NoSuchBeanDefinitionException
/*     */   {
/* 215 */     return this.shareableResources.contains(name);
/*     */   }
/*     */   
/*     */   public boolean isPrototype(String name) throws NoSuchBeanDefinitionException
/*     */   {
/* 220 */     return !this.shareableResources.contains(name);
/*     */   }
/*     */   
/*     */   public boolean isTypeMatch(String name, ResolvableType typeToMatch) throws NoSuchBeanDefinitionException
/*     */   {
/* 225 */     Class<?> type = getType(name);
/* 226 */     return (type != null) && (typeToMatch.isAssignableFrom(type));
/*     */   }
/*     */   
/*     */   public boolean isTypeMatch(String name, @Nullable Class<?> typeToMatch) throws NoSuchBeanDefinitionException
/*     */   {
/* 231 */     Class<?> type = getType(name);
/* 232 */     return (typeToMatch == null) || ((type != null) && (typeToMatch.isAssignableFrom(type)));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getType(String name) throws NoSuchBeanDefinitionException
/*     */   {
/* 238 */     return getType(name, true);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getType(String name, boolean allowFactoryBeanInit) throws NoSuchBeanDefinitionException
/*     */   {
/*     */     try {
/* 245 */       return doGetType(name);
/*     */     }
/*     */     catch (NameNotFoundException ex) {
/* 248 */       throw new NoSuchBeanDefinitionException(name, "not found in JNDI environment");
/*     */     }
/*     */     catch (NamingException ex) {}
/* 251 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String[] getAliases(String name)
/*     */   {
/* 257 */     return new String[0];
/*     */   }
/*     */   
/*     */   private <T> T doGetSingleton(String name, @Nullable Class<T> requiredType)
/*     */     throws NamingException
/*     */   {
/* 263 */     synchronized (this.singletonObjects) {
/* 264 */       Object singleton = this.singletonObjects.get(name);
/* 265 */       if (singleton != null) {
/* 266 */         if ((requiredType != null) && (!requiredType.isInstance(singleton))) {
/* 267 */           throw new TypeMismatchNamingException(convertJndiName(name), requiredType, singleton.getClass());
/*     */         }
/* 269 */         return (T)singleton;
/*     */       }
/* 271 */       T jndiObject = lookup(name, requiredType);
/* 272 */       this.singletonObjects.put(name, jndiObject);
/* 273 */       return jndiObject;
/*     */     }
/*     */   }
/*     */   
/*     */   private Class<?> doGetType(String name) throws NamingException {
/* 278 */     if (isSingleton(name)) {
/* 279 */       return doGetSingleton(name, null).getClass();
/*     */     }
/*     */     
/* 282 */     synchronized (this.resourceTypes) {
/* 283 */       Class<?> type = (Class)this.resourceTypes.get(name);
/* 284 */       if (type == null) {
/* 285 */         type = lookup(name, null).getClass();
/* 286 */         this.resourceTypes.put(name, type);
/*     */       }
/* 288 */       return type;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jndi\support\SimpleJndiBeanFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */