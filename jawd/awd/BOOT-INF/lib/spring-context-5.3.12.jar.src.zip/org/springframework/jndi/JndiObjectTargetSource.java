/*     */ package org.springframework.jndi;
/*     */ 
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JndiObjectTargetSource
/*     */   extends JndiObjectLocator
/*     */   implements TargetSource
/*     */ {
/*  64 */   private boolean lookupOnStartup = true;
/*     */   
/*  66 */   private boolean cache = true;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Object cachedObject;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Class<?> targetClass;
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLookupOnStartup(boolean lookupOnStartup)
/*     */   {
/*  82 */     this.lookupOnStartup = lookupOnStartup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCache(boolean cache)
/*     */   {
/*  93 */     this.cache = cache;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet() throws NamingException
/*     */   {
/*  98 */     super.afterPropertiesSet();
/*  99 */     if (this.lookupOnStartup) {
/* 100 */       Object object = lookup();
/* 101 */       if (this.cache) {
/* 102 */         this.cachedObject = object;
/*     */       }
/*     */       else {
/* 105 */         this.targetClass = object.getClass();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   public Class<?> getTargetClass()
/*     */   {
/* 114 */     if (this.cachedObject != null) {
/* 115 */       return this.cachedObject.getClass();
/*     */     }
/* 117 */     if (this.targetClass != null) {
/* 118 */       return this.targetClass;
/*     */     }
/*     */     
/* 121 */     return getExpectedType();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isStatic()
/*     */   {
/* 127 */     return this.cachedObject != null;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   @Nullable
/*     */   public Object getTarget()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 2	org/springframework/jndi/JndiObjectTargetSource:lookupOnStartup	Z
/*     */     //   4: ifne +10 -> 14
/*     */     //   7: aload_0
/*     */     //   8: getfield 3	org/springframework/jndi/JndiObjectTargetSource:cache	Z
/*     */     //   11: ifne +22 -> 33
/*     */     //   14: aload_0
/*     */     //   15: getfield 6	org/springframework/jndi/JndiObjectTargetSource:cachedObject	Ljava/lang/Object;
/*     */     //   18: ifnull +10 -> 28
/*     */     //   21: aload_0
/*     */     //   22: getfield 6	org/springframework/jndi/JndiObjectTargetSource:cachedObject	Ljava/lang/Object;
/*     */     //   25: goto +7 -> 32
/*     */     //   28: aload_0
/*     */     //   29: invokevirtual 5	org/springframework/jndi/JndiObjectTargetSource:lookup	()Ljava/lang/Object;
/*     */     //   32: areturn
/*     */     //   33: aload_0
/*     */     //   34: dup
/*     */     //   35: astore_1
/*     */     //   36: monitorenter
/*     */     //   37: aload_0
/*     */     //   38: getfield 6	org/springframework/jndi/JndiObjectTargetSource:cachedObject	Ljava/lang/Object;
/*     */     //   41: ifnonnull +11 -> 52
/*     */     //   44: aload_0
/*     */     //   45: aload_0
/*     */     //   46: invokevirtual 5	org/springframework/jndi/JndiObjectTargetSource:lookup	()Ljava/lang/Object;
/*     */     //   49: putfield 6	org/springframework/jndi/JndiObjectTargetSource:cachedObject	Ljava/lang/Object;
/*     */     //   52: aload_0
/*     */     //   53: getfield 6	org/springframework/jndi/JndiObjectTargetSource:cachedObject	Ljava/lang/Object;
/*     */     //   56: aload_1
/*     */     //   57: monitorexit
/*     */     //   58: areturn
/*     */     //   59: astore_2
/*     */     //   60: aload_1
/*     */     //   61: monitorexit
/*     */     //   62: aload_2
/*     */     //   63: athrow
/*     */     //   64: astore_1
/*     */     //   65: new 11	org/springframework/jndi/JndiLookupFailureException
/*     */     //   68: dup
/*     */     //   69: ldc 12
/*     */     //   71: aload_1
/*     */     //   72: invokespecial 13	org/springframework/jndi/JndiLookupFailureException:<init>	(Ljava/lang/String;Ljavax/naming/NamingException;)V
/*     */     //   75: athrow
/*     */     // Line number table:
/*     */     //   Java source line #134	-> byte code offset #0
/*     */     //   Java source line #135	-> byte code offset #14
/*     */     //   Java source line #138	-> byte code offset #33
/*     */     //   Java source line #139	-> byte code offset #37
/*     */     //   Java source line #140	-> byte code offset #44
/*     */     //   Java source line #142	-> byte code offset #52
/*     */     //   Java source line #143	-> byte code offset #59
/*     */     //   Java source line #146	-> byte code offset #64
/*     */     //   Java source line #147	-> byte code offset #65
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	76	0	this	JndiObjectTargetSource
/*     */     //   64	8	1	ex	NamingException
/*     */     //   59	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   37	58	59	finally
/*     */     //   59	62	59	finally
/*     */     //   0	32	64	javax/naming/NamingException
/*     */     //   33	58	64	javax/naming/NamingException
/*     */     //   59	64	64	javax/naming/NamingException
/*     */   }
/*     */   
/*     */   public void releaseTarget(Object target) {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jndi\JndiObjectTargetSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */