package org.springframework.jndi;

import javax.naming.Context;
import javax.naming.NamingException;
import org.springframework.lang.Nullable;

@FunctionalInterface
public abstract interface JndiCallback<T>
{
  @Nullable
  public abstract T doInContext(Context paramContext)
    throws NamingException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jndi\JndiCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */