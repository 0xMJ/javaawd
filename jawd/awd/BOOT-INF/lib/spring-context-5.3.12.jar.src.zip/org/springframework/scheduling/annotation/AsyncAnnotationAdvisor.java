/*     */ package org.springframework.scheduling.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.function.Supplier;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
/*     */ import org.springframework.aop.support.AbstractPointcutAdvisor;
/*     */ import org.springframework.aop.support.ComposablePointcut;
/*     */ import org.springframework.aop.support.annotation.AnnotationMatchingPointcut;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.function.SingletonSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncAnnotationAdvisor
/*     */   extends AbstractPointcutAdvisor
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   private Advice advice;
/*     */   private Pointcut pointcut;
/*     */   
/*     */   public AsyncAnnotationAdvisor()
/*     */   {
/*  67 */     this((Supplier)null, (Supplier)null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncAnnotationAdvisor(@Nullable Executor executor, @Nullable AsyncUncaughtExceptionHandler exceptionHandler)
/*     */   {
/*  81 */     this(SingletonSupplier.ofNullable(executor), SingletonSupplier.ofNullable(exceptionHandler));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncAnnotationAdvisor(@Nullable Supplier<Executor> executor, @Nullable Supplier<AsyncUncaughtExceptionHandler> exceptionHandler)
/*     */   {
/*  97 */     Set<Class<? extends Annotation>> asyncAnnotationTypes = new LinkedHashSet(2);
/*  98 */     asyncAnnotationTypes.add(Async.class);
/*     */     try {
/* 100 */       asyncAnnotationTypes.add(
/* 101 */         ClassUtils.forName("javax.ejb.Asynchronous", AsyncAnnotationAdvisor.class.getClassLoader()));
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException) {}
/*     */     
/*     */ 
/* 106 */     this.advice = buildAdvice(executor, exceptionHandler);
/* 107 */     this.pointcut = buildPointcut(asyncAnnotationTypes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAsyncAnnotationType(Class<? extends Annotation> asyncAnnotationType)
/*     */   {
/* 121 */     Assert.notNull(asyncAnnotationType, "'asyncAnnotationType' must not be null");
/* 122 */     Set<Class<? extends Annotation>> asyncAnnotationTypes = new HashSet();
/* 123 */     asyncAnnotationTypes.add(asyncAnnotationType);
/* 124 */     this.pointcut = buildPointcut(asyncAnnotationTypes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 132 */     if ((this.advice instanceof BeanFactoryAware)) {
/* 133 */       ((BeanFactoryAware)this.advice).setBeanFactory(beanFactory);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Advice getAdvice()
/*     */   {
/* 140 */     return this.advice;
/*     */   }
/*     */   
/*     */   public Pointcut getPointcut()
/*     */   {
/* 145 */     return this.pointcut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Advice buildAdvice(@Nullable Supplier<Executor> executor, @Nullable Supplier<AsyncUncaughtExceptionHandler> exceptionHandler)
/*     */   {
/* 152 */     AnnotationAsyncExecutionInterceptor interceptor = new AnnotationAsyncExecutionInterceptor(null);
/* 153 */     interceptor.configure(executor, exceptionHandler);
/* 154 */     return interceptor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Pointcut buildPointcut(Set<Class<? extends Annotation>> asyncAnnotationTypes)
/*     */   {
/* 163 */     ComposablePointcut result = null;
/* 164 */     for (Class<? extends Annotation> asyncAnnotationType : asyncAnnotationTypes) {
/* 165 */       Pointcut cpc = new AnnotationMatchingPointcut(asyncAnnotationType, true);
/* 166 */       Pointcut mpc = new AnnotationMatchingPointcut(null, asyncAnnotationType, true);
/* 167 */       if (result == null) {
/* 168 */         result = new ComposablePointcut(cpc);
/*     */       }
/*     */       else {
/* 171 */         result.union(cpc);
/*     */       }
/* 173 */       result = result.union(mpc);
/*     */     }
/* 175 */     return result != null ? result : Pointcut.TRUE;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\scheduling\annotation\AsyncAnnotationAdvisor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */