/*     */ package org.springframework.format.datetime.joda;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Map;
/*     */ import org.joda.time.Duration;
/*     */ import org.joda.time.LocalDate;
/*     */ import org.joda.time.LocalDateTime;
/*     */ import org.joda.time.LocalTime;
/*     */ import org.joda.time.MonthDay;
/*     */ import org.joda.time.Period;
/*     */ import org.joda.time.ReadableInstant;
/*     */ import org.joda.time.YearMonth;
/*     */ import org.joda.time.format.DateTimeFormat;
/*     */ import org.joda.time.format.DateTimeFormatter;
/*     */ import org.springframework.format.FormatterRegistrar;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.format.annotation.DateTimeFormat.ISO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class JodaTimeFormatterRegistrar
/*     */   implements FormatterRegistrar
/*     */ {
/*     */   private static enum Type
/*     */   {
/*  63 */     DATE,  TIME,  DATE_TIME;
/*     */     
/*     */ 
/*     */     private Type() {}
/*     */   }
/*     */   
/*  69 */   private final Map<Type, DateTimeFormatter> formatters = new EnumMap(Type.class);
/*     */   
/*     */ 
/*     */   private final Map<Type, DateTimeFormatterFactory> factories;
/*     */   
/*     */ 
/*     */ 
/*     */   public JodaTimeFormatterRegistrar()
/*     */   {
/*  78 */     this.factories = new EnumMap(Type.class);
/*  79 */     for (Type type : Type.values()) {
/*  80 */       this.factories.put(type, new DateTimeFormatterFactory());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseIsoFormat(boolean useIsoFormat)
/*     */   {
/*  92 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE)).setIso(useIsoFormat ? DateTimeFormat.ISO.DATE : DateTimeFormat.ISO.NONE);
/*  93 */     ((DateTimeFormatterFactory)this.factories.get(Type.TIME)).setIso(useIsoFormat ? DateTimeFormat.ISO.TIME : DateTimeFormat.ISO.NONE);
/*  94 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE_TIME)).setIso(useIsoFormat ? DateTimeFormat.ISO.DATE_TIME : DateTimeFormat.ISO.NONE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateStyle(String dateStyle)
/*     */   {
/* 102 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE)).setStyle(dateStyle + "-");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeStyle(String timeStyle)
/*     */   {
/* 110 */     ((DateTimeFormatterFactory)this.factories.get(Type.TIME)).setStyle("-" + timeStyle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateTimeStyle(String dateTimeStyle)
/*     */   {
/* 119 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE_TIME)).setStyle(dateTimeStyle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateFormatter(DateTimeFormatter formatter)
/*     */   {
/* 133 */     this.formatters.put(Type.DATE, formatter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeFormatter(DateTimeFormatter formatter)
/*     */   {
/* 147 */     this.formatters.put(Type.TIME, formatter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateTimeFormatter(DateTimeFormatter formatter)
/*     */   {
/* 162 */     this.formatters.put(Type.DATE_TIME, formatter);
/*     */   }
/*     */   
/*     */ 
/*     */   public void registerFormatters(FormatterRegistry registry)
/*     */   {
/* 168 */     JodaTimeConverters.registerConverters(registry);
/*     */     
/* 170 */     DateTimeFormatter dateFormatter = getFormatter(Type.DATE);
/* 171 */     DateTimeFormatter timeFormatter = getFormatter(Type.TIME);
/* 172 */     DateTimeFormatter dateTimeFormatter = getFormatter(Type.DATE_TIME);
/*     */     
/* 174 */     addFormatterForFields(registry, new ReadablePartialPrinter(dateFormatter), new LocalDateParser(dateFormatter), new Class[] { LocalDate.class });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 179 */     addFormatterForFields(registry, new ReadablePartialPrinter(timeFormatter), new LocalTimeParser(timeFormatter), new Class[] { LocalTime.class });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 184 */     addFormatterForFields(registry, new ReadablePartialPrinter(dateTimeFormatter), new LocalDateTimeParser(dateTimeFormatter), new Class[] { LocalDateTime.class });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 189 */     addFormatterForFields(registry, new ReadableInstantPrinter(dateTimeFormatter), new DateTimeParser(dateTimeFormatter), new Class[] { ReadableInstant.class });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 196 */     if (this.formatters.containsKey(Type.DATE_TIME)) {
/* 197 */       addFormatterForFields(registry, new ReadableInstantPrinter(dateTimeFormatter), new DateTimeParser(dateTimeFormatter), new Class[] { Date.class, Calendar.class });
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 203 */     registry.addFormatterForFieldType(Period.class, new PeriodFormatter());
/* 204 */     registry.addFormatterForFieldType(Duration.class, new DurationFormatter());
/* 205 */     registry.addFormatterForFieldType(YearMonth.class, new YearMonthFormatter());
/* 206 */     registry.addFormatterForFieldType(MonthDay.class, new MonthDayFormatter());
/*     */     
/* 208 */     registry.addFormatterForFieldAnnotation(new JodaDateTimeFormatAnnotationFormatterFactory());
/*     */   }
/*     */   
/*     */   private DateTimeFormatter getFormatter(Type type) {
/* 212 */     DateTimeFormatter formatter = (DateTimeFormatter)this.formatters.get(type);
/* 213 */     if (formatter != null) {
/* 214 */       return formatter;
/*     */     }
/* 216 */     DateTimeFormatter fallbackFormatter = getFallbackFormatter(type);
/* 217 */     return ((DateTimeFormatterFactory)this.factories.get(type)).createDateTimeFormatter(fallbackFormatter);
/*     */   }
/*     */   
/*     */   private DateTimeFormatter getFallbackFormatter(Type type) {
/* 221 */     switch (type) {
/* 222 */     case DATE:  return DateTimeFormat.shortDate();
/* 223 */     case TIME:  return DateTimeFormat.shortTime(); }
/* 224 */     return DateTimeFormat.shortDateTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void addFormatterForFields(FormatterRegistry registry, Printer<?> printer, Parser<?> parser, Class<?>... fieldTypes)
/*     */   {
/* 231 */     for (Class<?> fieldType : fieldTypes) {
/* 232 */       registry.addFormatterForFieldType(fieldType, printer, parser);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\joda\JodaTimeFormatterRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */