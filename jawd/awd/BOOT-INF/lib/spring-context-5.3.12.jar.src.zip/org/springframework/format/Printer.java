package org.springframework.format;

import java.util.Locale;

@FunctionalInterface
public abstract interface Printer<T>
{
  public abstract String print(T paramT, Locale paramLocale);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\Printer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */