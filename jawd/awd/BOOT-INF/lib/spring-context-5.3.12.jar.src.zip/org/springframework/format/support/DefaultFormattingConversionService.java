/*     */ package org.springframework.format.support;
/*     */ 
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.datetime.DateFormatterRegistrar;
/*     */ import org.springframework.format.datetime.joda.JodaTimeFormatterRegistrar;
/*     */ import org.springframework.format.datetime.standard.DateTimeFormatterRegistrar;
/*     */ import org.springframework.format.number.NumberFormatAnnotationFormatterFactory;
/*     */ import org.springframework.format.number.money.CurrencyUnitFormatter;
/*     */ import org.springframework.format.number.money.Jsr354NumberFormatAnnotationFormatterFactory;
/*     */ import org.springframework.format.number.money.MonetaryAmountFormatter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultFormattingConversionService
/*     */   extends FormattingConversionService
/*     */ {
/*     */   private static final boolean jsr354Present;
/*     */   private static final boolean jodaTimePresent;
/*     */   
/*     */   static
/*     */   {
/*  54 */     ClassLoader classLoader = DefaultFormattingConversionService.class.getClassLoader();
/*  55 */     jsr354Present = ClassUtils.isPresent("javax.money.MonetaryAmount", classLoader);
/*  56 */     jodaTimePresent = ClassUtils.isPresent("org.joda.time.YearMonth", classLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultFormattingConversionService()
/*     */   {
/*  65 */     this(null, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultFormattingConversionService(boolean registerDefaultFormatters)
/*     */   {
/*  76 */     this(null, registerDefaultFormatters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultFormattingConversionService(@Nullable StringValueResolver embeddedValueResolver, boolean registerDefaultFormatters)
/*     */   {
/*  91 */     if (embeddedValueResolver != null) {
/*  92 */       setEmbeddedValueResolver(embeddedValueResolver);
/*     */     }
/*  94 */     DefaultConversionService.addDefaultConverters(this);
/*  95 */     if (registerDefaultFormatters) {
/*  96 */       addDefaultFormatters(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addDefaultFormatters(FormatterRegistry formatterRegistry)
/*     */   {
/* 110 */     formatterRegistry.addFormatterForFieldAnnotation(new NumberFormatAnnotationFormatterFactory());
/*     */     
/*     */ 
/* 113 */     if (jsr354Present) {
/* 114 */       formatterRegistry.addFormatter(new CurrencyUnitFormatter());
/* 115 */       formatterRegistry.addFormatter(new MonetaryAmountFormatter());
/* 116 */       formatterRegistry.addFormatterForFieldAnnotation(new Jsr354NumberFormatAnnotationFormatterFactory());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 122 */     new DateTimeFormatterRegistrar().registerFormatters(formatterRegistry);
/*     */     
/* 124 */     if (jodaTimePresent)
/*     */     {
/* 126 */       new JodaTimeFormatterRegistrar().registerFormatters(formatterRegistry);
/*     */     }
/*     */     else
/*     */     {
/* 130 */       new DateFormatterRegistrar().registerFormatters(formatterRegistry);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\support\DefaultFormattingConversionService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */