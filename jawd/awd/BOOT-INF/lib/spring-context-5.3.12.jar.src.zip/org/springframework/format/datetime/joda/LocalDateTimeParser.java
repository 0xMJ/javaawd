/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.util.Locale;
/*    */ import org.joda.time.LocalDateTime;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.format.Parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class LocalDateTimeParser
/*    */   implements Parser<LocalDateTime>
/*    */ {
/*    */   private final DateTimeFormatter formatter;
/*    */   
/*    */   public LocalDateTimeParser(DateTimeFormatter formatter)
/*    */   {
/* 46 */     this.formatter = formatter;
/*    */   }
/*    */   
/*    */   public LocalDateTime parse(String text, Locale locale)
/*    */     throws ParseException
/*    */   {
/* 52 */     return JodaTimeContextHolder.getFormatter(this.formatter, locale).parseLocalDateTime(text);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\joda\LocalDateTimeParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */