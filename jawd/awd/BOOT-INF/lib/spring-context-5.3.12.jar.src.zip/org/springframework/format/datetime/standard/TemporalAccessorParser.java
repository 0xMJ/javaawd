/*     */ package org.springframework.format.datetime.standard;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DateTimeParseException;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Locale;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemporalAccessorParser
/*     */   implements Parser<TemporalAccessor>
/*     */ {
/*     */   private final Class<? extends TemporalAccessor> temporalAccessorType;
/*     */   private final DateTimeFormatter formatter;
/*     */   @Nullable
/*     */   private final String[] fallbackPatterns;
/*     */   @Nullable
/*     */   private final Object source;
/*     */   
/*     */   public TemporalAccessorParser(Class<? extends TemporalAccessor> temporalAccessorType, DateTimeFormatter formatter)
/*     */   {
/*  70 */     this(temporalAccessorType, formatter, null, null);
/*     */   }
/*     */   
/*     */   TemporalAccessorParser(Class<? extends TemporalAccessor> temporalAccessorType, DateTimeFormatter formatter, @Nullable String[] fallbackPatterns, @Nullable Object source)
/*     */   {
/*  75 */     this.temporalAccessorType = temporalAccessorType;
/*  76 */     this.formatter = formatter;
/*  77 */     this.fallbackPatterns = fallbackPatterns;
/*  78 */     this.source = source;
/*     */   }
/*     */   
/*     */   public TemporalAccessor parse(String text, Locale locale) throws ParseException
/*     */   {
/*     */     try
/*     */     {
/*  85 */       return doParse(text, locale, this.formatter);
/*     */     }
/*     */     catch (DateTimeParseException ex) {
/*  88 */       if (!ObjectUtils.isEmpty(this.fallbackPatterns)) {
/*  89 */         for (String pattern : this.fallbackPatterns) {
/*     */           try {
/*  91 */             DateTimeFormatter fallbackFormatter = DateTimeFormatterUtils.createStrictDateTimeFormatter(pattern);
/*  92 */             return doParse(text, locale, fallbackFormatter);
/*     */           }
/*     */           catch (DateTimeParseException localDateTimeParseException1) {}
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 101 */       if (this.source != null)
/*     */       {
/*     */ 
/* 104 */         throw new DateTimeParseException(String.format("Unable to parse date time value \"%s\" using configuration from %s", new Object[] { text, this.source }), text, ex.getErrorIndex(), ex);
/*     */       }
/*     */       
/* 107 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */   private TemporalAccessor doParse(String text, Locale locale, DateTimeFormatter formatter) throws DateTimeParseException {
/* 112 */     DateTimeFormatter formatterToUse = DateTimeContextHolder.getFormatter(formatter, locale);
/* 113 */     if (LocalDate.class == this.temporalAccessorType) {
/* 114 */       return LocalDate.parse(text, formatterToUse);
/*     */     }
/* 116 */     if (LocalTime.class == this.temporalAccessorType) {
/* 117 */       return LocalTime.parse(text, formatterToUse);
/*     */     }
/* 119 */     if (LocalDateTime.class == this.temporalAccessorType) {
/* 120 */       return LocalDateTime.parse(text, formatterToUse);
/*     */     }
/* 122 */     if (ZonedDateTime.class == this.temporalAccessorType) {
/* 123 */       return ZonedDateTime.parse(text, formatterToUse);
/*     */     }
/* 125 */     if (OffsetDateTime.class == this.temporalAccessorType) {
/* 126 */       return OffsetDateTime.parse(text, formatterToUse);
/*     */     }
/* 128 */     if (OffsetTime.class == this.temporalAccessorType) {
/* 129 */       return OffsetTime.parse(text, formatterToUse);
/*     */     }
/*     */     
/* 132 */     throw new IllegalStateException("Unsupported TemporalAccessor type: " + this.temporalAccessorType);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\standard\TemporalAccessorParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */