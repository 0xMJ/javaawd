/*     */ package org.springframework.format.datetime.joda;
/*     */ 
/*     */ import java.util.TimeZone;
/*     */ import org.joda.time.DateTimeZone;
/*     */ import org.joda.time.format.DateTimeFormat;
/*     */ import org.joda.time.format.DateTimeFormatter;
/*     */ import org.joda.time.format.ISODateTimeFormat;
/*     */ import org.springframework.format.annotation.DateTimeFormat.ISO;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class DateTimeFormatterFactory
/*     */ {
/*     */   @Nullable
/*     */   private String pattern;
/*     */   @Nullable
/*     */   private DateTimeFormat.ISO iso;
/*     */   @Nullable
/*     */   private String style;
/*     */   @Nullable
/*     */   private TimeZone timeZone;
/*     */   
/*     */   public DateTimeFormatterFactory() {}
/*     */   
/*     */   public DateTimeFormatterFactory(String pattern)
/*     */   {
/*  74 */     this.pattern = pattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPattern(String pattern)
/*     */   {
/*  83 */     this.pattern = pattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIso(DateTimeFormat.ISO iso)
/*     */   {
/*  91 */     this.iso = iso;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStyle(String style)
/*     */   {
/* 108 */     this.style = style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeZone(TimeZone timeZone)
/*     */   {
/* 116 */     this.timeZone = timeZone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateTimeFormatter createDateTimeFormatter()
/*     */   {
/* 128 */     return createDateTimeFormatter(DateTimeFormat.mediumDateTime());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateTimeFormatter createDateTimeFormatter(DateTimeFormatter fallbackFormatter)
/*     */   {
/* 140 */     DateTimeFormatter dateTimeFormatter = null;
/* 141 */     if (StringUtils.hasLength(this.pattern)) {
/* 142 */       dateTimeFormatter = DateTimeFormat.forPattern(this.pattern);
/*     */     } else {
/* 144 */       if ((this.iso != null) && (this.iso != DateTimeFormat.ISO.NONE)) {}
/* 145 */       switch (this.iso) {
/*     */       case DATE: 
/* 147 */         dateTimeFormatter = ISODateTimeFormat.date();
/* 148 */         break;
/*     */       case TIME: 
/* 150 */         dateTimeFormatter = ISODateTimeFormat.time();
/* 151 */         break;
/*     */       case DATE_TIME: 
/* 153 */         dateTimeFormatter = ISODateTimeFormat.dateTime();
/* 154 */         break;
/*     */       default: 
/* 156 */         throw new IllegalStateException("Unsupported ISO format: " + this.iso);
/*     */         
/*     */ 
/* 159 */         if (StringUtils.hasLength(this.style))
/* 160 */           dateTimeFormatter = DateTimeFormat.forStyle(this.style);
/*     */         break; }
/*     */     }
/* 163 */     if ((dateTimeFormatter != null) && (this.timeZone != null)) {
/* 164 */       dateTimeFormatter = dateTimeFormatter.withZone(DateTimeZone.forTimeZone(this.timeZone));
/*     */     }
/* 166 */     return dateTimeFormatter != null ? dateTimeFormatter : fallbackFormatter;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\joda\DateTimeFormatterFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */