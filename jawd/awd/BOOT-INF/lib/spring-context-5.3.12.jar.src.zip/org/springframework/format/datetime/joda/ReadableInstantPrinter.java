/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.joda.time.ReadableInstant;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.format.Printer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class ReadableInstantPrinter
/*    */   implements Printer<ReadableInstant>
/*    */ {
/*    */   private final DateTimeFormatter formatter;
/*    */   
/*    */   public ReadableInstantPrinter(DateTimeFormatter formatter)
/*    */   {
/* 44 */     this.formatter = formatter;
/*    */   }
/*    */   
/*    */ 
/*    */   public String print(ReadableInstant instant, Locale locale)
/*    */   {
/* 50 */     return JodaTimeContextHolder.getFormatter(this.formatter, locale).print(instant);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\joda\ReadableInstantPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */