/*    */ package org.springframework.format.number.money;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.money.CurrencyUnit;
/*    */ import javax.money.Monetary;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CurrencyUnitFormatter
/*    */   implements Formatter<CurrencyUnit>
/*    */ {
/*    */   public String print(CurrencyUnit object, Locale locale)
/*    */   {
/* 37 */     return object.getCurrencyCode();
/*    */   }
/*    */   
/*    */   public CurrencyUnit parse(String text, Locale locale)
/*    */   {
/* 42 */     return Monetary.getCurrency(text, new String[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\number\money\CurrencyUnitFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */