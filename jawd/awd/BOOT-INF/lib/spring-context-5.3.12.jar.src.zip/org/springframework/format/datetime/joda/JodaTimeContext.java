/*     */ package org.springframework.format.datetime.joda;
/*     */ 
/*     */ import java.util.TimeZone;
/*     */ import org.joda.time.Chronology;
/*     */ import org.joda.time.DateTimeZone;
/*     */ import org.joda.time.format.DateTimeFormatter;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class JodaTimeContext
/*     */ {
/*     */   @Nullable
/*     */   private Chronology chronology;
/*     */   @Nullable
/*     */   private DateTimeZone timeZone;
/*     */   
/*     */   public void setChronology(@Nullable Chronology chronology)
/*     */   {
/*  55 */     this.chronology = chronology;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Chronology getChronology()
/*     */   {
/*  63 */     return this.chronology;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeZone(@Nullable DateTimeZone timeZone)
/*     */   {
/*  75 */     this.timeZone = timeZone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public DateTimeZone getTimeZone()
/*     */   {
/*  83 */     return this.timeZone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateTimeFormatter getFormatter(DateTimeFormatter formatter)
/*     */   {
/*  95 */     if (this.chronology != null) {
/*  96 */       formatter = formatter.withChronology(this.chronology);
/*     */     }
/*  98 */     if (this.timeZone != null) {
/*  99 */       formatter = formatter.withZone(this.timeZone);
/*     */     }
/*     */     else {
/* 102 */       LocaleContext localeContext = LocaleContextHolder.getLocaleContext();
/* 103 */       if ((localeContext instanceof TimeZoneAwareLocaleContext)) {
/* 104 */         TimeZone timeZone = ((TimeZoneAwareLocaleContext)localeContext).getTimeZone();
/* 105 */         if (timeZone != null) {
/* 106 */           formatter = formatter.withZone(DateTimeZone.forTimeZone(timeZone));
/*     */         }
/*     */       }
/*     */     }
/* 110 */     return formatter;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\joda\JodaTimeContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */