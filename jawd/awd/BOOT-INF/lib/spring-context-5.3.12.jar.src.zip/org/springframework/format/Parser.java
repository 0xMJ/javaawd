package org.springframework.format;

import java.text.ParseException;
import java.util.Locale;

@FunctionalInterface
public abstract interface Parser<T>
{
  public abstract T parse(String paramString, Locale paramLocale)
    throws ParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\Parser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */