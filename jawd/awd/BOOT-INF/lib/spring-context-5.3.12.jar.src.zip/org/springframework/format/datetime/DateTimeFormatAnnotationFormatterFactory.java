/*    */ package org.springframework.format.datetime;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Calendar;
/*    */ import java.util.Collections;
/*    */ import java.util.Date;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.springframework.context.support.EmbeddedValueResolutionSupport;
/*    */ import org.springframework.format.AnnotationFormatterFactory;
/*    */ import org.springframework.format.Formatter;
/*    */ import org.springframework.format.Parser;
/*    */ import org.springframework.format.Printer;
/*    */ import org.springframework.format.annotation.DateTimeFormat;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateTimeFormatAnnotationFormatterFactory
/*    */   extends EmbeddedValueResolutionSupport
/*    */   implements AnnotationFormatterFactory<DateTimeFormat>
/*    */ {
/*    */   private static final Set<Class<?>> FIELD_TYPES;
/*    */   
/*    */   static
/*    */   {
/* 49 */     Set<Class<?>> fieldTypes = new HashSet(4);
/* 50 */     fieldTypes.add(Date.class);
/* 51 */     fieldTypes.add(Calendar.class);
/* 52 */     fieldTypes.add(Long.class);
/* 53 */     FIELD_TYPES = Collections.unmodifiableSet(fieldTypes);
/*    */   }
/*    */   
/*    */ 
/*    */   public Set<Class<?>> getFieldTypes()
/*    */   {
/* 59 */     return FIELD_TYPES;
/*    */   }
/*    */   
/*    */   public Printer<?> getPrinter(DateTimeFormat annotation, Class<?> fieldType)
/*    */   {
/* 64 */     return getFormatter(annotation, fieldType);
/*    */   }
/*    */   
/*    */   public Parser<?> getParser(DateTimeFormat annotation, Class<?> fieldType)
/*    */   {
/* 69 */     return getFormatter(annotation, fieldType);
/*    */   }
/*    */   
/*    */   protected Formatter<Date> getFormatter(DateTimeFormat annotation, Class<?> fieldType) {
/* 73 */     DateFormatter formatter = new DateFormatter();
/* 74 */     formatter.setSource(annotation);
/* 75 */     formatter.setIso(annotation.iso());
/*    */     
/* 77 */     String style = resolveEmbeddedValue(annotation.style());
/* 78 */     if (StringUtils.hasLength(style)) {
/* 79 */       formatter.setStylePattern(style);
/*    */     }
/*    */     
/* 82 */     String pattern = resolveEmbeddedValue(annotation.pattern());
/* 83 */     if (StringUtils.hasLength(pattern)) {
/* 84 */       formatter.setPattern(pattern);
/*    */     }
/*    */     
/* 87 */     List<String> resolvedFallbackPatterns = new ArrayList();
/* 88 */     for (String fallbackPattern : annotation.fallbackPatterns()) {
/* 89 */       String resolvedFallbackPattern = resolveEmbeddedValue(fallbackPattern);
/* 90 */       if (StringUtils.hasLength(resolvedFallbackPattern)) {
/* 91 */         resolvedFallbackPatterns.add(resolvedFallbackPattern);
/*    */       }
/*    */     }
/* 94 */     if (!resolvedFallbackPatterns.isEmpty()) {
/* 95 */       formatter.setFallbackPatterns((String[])resolvedFallbackPatterns.toArray(new String[0]));
/*    */     }
/*    */     
/* 98 */     return formatter;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\DateTimeFormatAnnotationFormatterFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */