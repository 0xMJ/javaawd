package org.springframework.format;

import java.lang.annotation.Annotation;
import org.springframework.core.convert.converter.ConverterRegistry;

public abstract interface FormatterRegistry
  extends ConverterRegistry
{
  public abstract void addPrinter(Printer<?> paramPrinter);
  
  public abstract void addParser(Parser<?> paramParser);
  
  public abstract void addFormatter(Formatter<?> paramFormatter);
  
  public abstract void addFormatterForFieldType(Class<?> paramClass, Formatter<?> paramFormatter);
  
  public abstract void addFormatterForFieldType(Class<?> paramClass, Printer<?> paramPrinter, Parser<?> paramParser);
  
  public abstract void addFormatterForFieldAnnotation(AnnotationFormatterFactory<? extends Annotation> paramAnnotationFormatterFactory);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\FormatterRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */