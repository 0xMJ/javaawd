/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.util.Locale;
/*    */ import org.joda.time.DateTime;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.format.Parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class DateTimeParser
/*    */   implements Parser<DateTime>
/*    */ {
/*    */   private final DateTimeFormatter formatter;
/*    */   
/*    */   public DateTimeParser(DateTimeFormatter formatter)
/*    */   {
/* 45 */     this.formatter = formatter;
/*    */   }
/*    */   
/*    */   public DateTime parse(String text, Locale locale)
/*    */     throws ParseException
/*    */   {
/* 51 */     return JodaTimeContextHolder.getFormatter(this.formatter, locale).parseDateTime(text);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\joda\DateTimeParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */