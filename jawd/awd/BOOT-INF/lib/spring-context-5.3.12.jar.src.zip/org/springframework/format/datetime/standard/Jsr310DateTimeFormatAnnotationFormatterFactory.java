/*     */ package org.springframework.format.datetime.standard;
/*     */ 
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.context.support.EmbeddedValueResolutionSupport;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.format.annotation.DateTimeFormat;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jsr310DateTimeFormatAnnotationFormatterFactory
/*     */   extends EmbeddedValueResolutionSupport
/*     */   implements AnnotationFormatterFactory<DateTimeFormat>
/*     */ {
/*     */   private static final Set<Class<?>> FIELD_TYPES;
/*     */   
/*     */   static
/*     */   {
/*  56 */     Set<Class<?>> fieldTypes = new HashSet(8);
/*  57 */     fieldTypes.add(LocalDate.class);
/*  58 */     fieldTypes.add(LocalTime.class);
/*  59 */     fieldTypes.add(LocalDateTime.class);
/*  60 */     fieldTypes.add(ZonedDateTime.class);
/*  61 */     fieldTypes.add(OffsetDateTime.class);
/*  62 */     fieldTypes.add(OffsetTime.class);
/*  63 */     FIELD_TYPES = Collections.unmodifiableSet(fieldTypes);
/*     */   }
/*     */   
/*     */ 
/*     */   public final Set<Class<?>> getFieldTypes()
/*     */   {
/*  69 */     return FIELD_TYPES;
/*     */   }
/*     */   
/*     */   public Printer<?> getPrinter(DateTimeFormat annotation, Class<?> fieldType)
/*     */   {
/*  74 */     DateTimeFormatter formatter = getFormatter(annotation, fieldType);
/*     */     
/*     */ 
/*  77 */     if (formatter == DateTimeFormatter.ISO_DATE) {
/*  78 */       if (isLocal(fieldType)) {
/*  79 */         formatter = DateTimeFormatter.ISO_LOCAL_DATE;
/*     */       }
/*     */     }
/*  82 */     else if (formatter == DateTimeFormatter.ISO_TIME) {
/*  83 */       if (isLocal(fieldType)) {
/*  84 */         formatter = DateTimeFormatter.ISO_LOCAL_TIME;
/*     */       }
/*     */     }
/*  87 */     else if ((formatter == DateTimeFormatter.ISO_DATE_TIME) && 
/*  88 */       (isLocal(fieldType))) {
/*  89 */       formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
/*     */     }
/*     */     
/*     */ 
/*  93 */     return new TemporalAccessorPrinter(formatter);
/*     */   }
/*     */   
/*     */ 
/*     */   public Parser<?> getParser(DateTimeFormat annotation, Class<?> fieldType)
/*     */   {
/*  99 */     List<String> resolvedFallbackPatterns = new ArrayList();
/* 100 */     for (String fallbackPattern : annotation.fallbackPatterns()) {
/* 101 */       String resolvedFallbackPattern = resolveEmbeddedValue(fallbackPattern);
/* 102 */       if (StringUtils.hasLength(resolvedFallbackPattern)) {
/* 103 */         resolvedFallbackPatterns.add(resolvedFallbackPattern);
/*     */       }
/*     */     }
/*     */     
/* 107 */     DateTimeFormatter formatter = getFormatter(annotation, fieldType);
/* 108 */     return new TemporalAccessorParser(fieldType, formatter, 
/* 109 */       (String[])resolvedFallbackPatterns.toArray(new String[0]), annotation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DateTimeFormatter getFormatter(DateTimeFormat annotation, Class<?> fieldType)
/*     */   {
/* 119 */     DateTimeFormatterFactory factory = new DateTimeFormatterFactory();
/* 120 */     String style = resolveEmbeddedValue(annotation.style());
/* 121 */     if (StringUtils.hasLength(style)) {
/* 122 */       factory.setStylePattern(style);
/*     */     }
/* 124 */     factory.setIso(annotation.iso());
/* 125 */     String pattern = resolveEmbeddedValue(annotation.pattern());
/* 126 */     if (StringUtils.hasLength(pattern)) {
/* 127 */       factory.setPattern(pattern);
/*     */     }
/* 129 */     return factory.createDateTimeFormatter();
/*     */   }
/*     */   
/*     */   private boolean isLocal(Class<?> fieldType) {
/* 133 */     return fieldType.getSimpleName().startsWith("Local");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\standard\Jsr310DateTimeFormatAnnotationFormatterFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */