/*     */ package org.springframework.format.datetime;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.annotation.DateTimeFormat.ISO;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateFormatter
/*     */   implements Formatter<Date>
/*     */ {
/*  50 */   private static final TimeZone UTC = TimeZone.getTimeZone("UTC");
/*     */   private static final Map<DateTimeFormat.ISO, String> ISO_PATTERNS;
/*     */   @Nullable
/*     */   private Object source;
/*     */   
/*  55 */   static { Map<DateTimeFormat.ISO, String> formats = new EnumMap(DateTimeFormat.ISO.class);
/*  56 */     formats.put(DateTimeFormat.ISO.DATE, "yyyy-MM-dd");
/*  57 */     formats.put(DateTimeFormat.ISO.TIME, "HH:mm:ss.SSSXXX");
/*  58 */     formats.put(DateTimeFormat.ISO.DATE_TIME, "yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
/*  59 */     ISO_PATTERNS = Collections.unmodifiableMap(formats);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private String pattern;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private String[] fallbackPatterns;
/*     */   
/*     */ 
/*  72 */   private int style = 2;
/*     */   
/*     */   @Nullable
/*     */   private String stylePattern;
/*     */   
/*     */   @Nullable
/*     */   private DateTimeFormat.ISO iso;
/*     */   
/*     */   @Nullable
/*     */   private TimeZone timeZone;
/*     */   
/*  83 */   private boolean lenient = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateFormatter(String pattern)
/*     */   {
/*  96 */     this.pattern = pattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSource(Object source)
/*     */   {
/* 111 */     this.source = source;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPattern(String pattern)
/*     */   {
/* 119 */     this.pattern = pattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFallbackPatterns(String... fallbackPatterns)
/*     */   {
/* 131 */     this.fallbackPatterns = fallbackPatterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIso(DateTimeFormat.ISO iso)
/*     */   {
/* 140 */     this.iso = iso;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStyle(int style)
/*     */   {
/* 153 */     this.style = style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStylePattern(String stylePattern)
/*     */   {
/* 173 */     this.stylePattern = stylePattern;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTimeZone(TimeZone timeZone)
/*     */   {
/* 180 */     this.timeZone = timeZone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLenient(boolean lenient)
/*     */   {
/* 189 */     this.lenient = lenient;
/*     */   }
/*     */   
/*     */ 
/*     */   public String print(Date date, Locale locale)
/*     */   {
/* 195 */     return getDateFormat(locale).format(date);
/*     */   }
/*     */   
/*     */   public Date parse(String text, Locale locale) throws ParseException
/*     */   {
/*     */     try {
/* 201 */       return getDateFormat(locale).parse(text);
/*     */     }
/*     */     catch (ParseException ex) {
/* 204 */       if (!ObjectUtils.isEmpty(this.fallbackPatterns)) {
/* 205 */         for (String pattern : this.fallbackPatterns) {
/*     */           try {
/* 207 */             DateFormat dateFormat = configureDateFormat(new SimpleDateFormat(pattern, locale));
/*     */             
/* 209 */             if ((this.iso != null) && (this.iso != DateTimeFormat.ISO.NONE)) {
/* 210 */               dateFormat.setTimeZone(UTC);
/*     */             }
/* 212 */             return dateFormat.parse(text);
/*     */           }
/*     */           catch (ParseException localParseException1) {}
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 221 */       if (this.source != null)
/*     */       {
/*     */ 
/* 224 */         ParseException parseException = new ParseException(String.format("Unable to parse date time value \"%s\" using configuration from %s", new Object[] { text, this.source }), ex.getErrorOffset());
/* 225 */         parseException.initCause(ex);
/* 226 */         throw parseException;
/*     */       }
/*     */       
/* 229 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */   protected DateFormat getDateFormat(Locale locale)
/*     */   {
/* 235 */     return configureDateFormat(createDateFormat(locale));
/*     */   }
/*     */   
/*     */   private DateFormat configureDateFormat(DateFormat dateFormat) {
/* 239 */     if (this.timeZone != null) {
/* 240 */       dateFormat.setTimeZone(this.timeZone);
/*     */     }
/* 242 */     dateFormat.setLenient(this.lenient);
/* 243 */     return dateFormat;
/*     */   }
/*     */   
/*     */   private DateFormat createDateFormat(Locale locale) {
/* 247 */     if (StringUtils.hasLength(this.pattern)) {
/* 248 */       return new SimpleDateFormat(this.pattern, locale);
/*     */     }
/* 250 */     if ((this.iso != null) && (this.iso != DateTimeFormat.ISO.NONE)) {
/* 251 */       String pattern = (String)ISO_PATTERNS.get(this.iso);
/* 252 */       if (pattern == null) {
/* 253 */         throw new IllegalStateException("Unsupported ISO format " + this.iso);
/*     */       }
/* 255 */       SimpleDateFormat format = new SimpleDateFormat(pattern);
/* 256 */       format.setTimeZone(UTC);
/* 257 */       return format;
/*     */     }
/* 259 */     if (StringUtils.hasLength(this.stylePattern)) {
/* 260 */       int dateStyle = getStylePatternForChar(0);
/* 261 */       int timeStyle = getStylePatternForChar(1);
/* 262 */       if ((dateStyle != -1) && (timeStyle != -1)) {
/* 263 */         return DateFormat.getDateTimeInstance(dateStyle, timeStyle, locale);
/*     */       }
/* 265 */       if (dateStyle != -1) {
/* 266 */         return DateFormat.getDateInstance(dateStyle, locale);
/*     */       }
/* 268 */       if (timeStyle != -1) {
/* 269 */         return DateFormat.getTimeInstance(timeStyle, locale);
/*     */       }
/* 271 */       throw new IllegalStateException("Unsupported style pattern '" + this.stylePattern + "'");
/*     */     }
/*     */     
/* 274 */     return DateFormat.getDateInstance(this.style, locale);
/*     */   }
/*     */   
/*     */   private int getStylePatternForChar(int index) {
/* 278 */     if ((this.stylePattern != null) && (this.stylePattern.length() > index)) {
/* 279 */       switch (this.stylePattern.charAt(index)) {
/* 280 */       case 'S':  return 3;
/* 281 */       case 'M':  return 2;
/* 282 */       case 'L':  return 1;
/* 283 */       case 'F':  return 0;
/* 284 */       case '-':  return -1;
/*     */       }
/*     */     }
/* 287 */     throw new IllegalStateException("Unsupported style pattern '" + this.stylePattern + "'");
/*     */   }
/*     */   
/*     */   public DateFormatter() {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\DateFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */