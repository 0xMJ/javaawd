/*    */ package org.springframework.format.datetime.standard;
/*    */ 
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.util.Locale;
/*    */ import org.springframework.core.NamedThreadLocal;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DateTimeContextHolder
/*    */ {
/* 34 */   private static final ThreadLocal<DateTimeContext> dateTimeContextHolder = new NamedThreadLocal("DateTimeContext");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void resetDateTimeContext()
/*    */   {
/* 46 */     dateTimeContextHolder.remove();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void setDateTimeContext(@Nullable DateTimeContext dateTimeContext)
/*    */   {
/* 55 */     if (dateTimeContext == null) {
/* 56 */       resetDateTimeContext();
/*    */     }
/*    */     else {
/* 59 */       dateTimeContextHolder.set(dateTimeContext);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   public static DateTimeContext getDateTimeContext()
/*    */   {
/* 69 */     return (DateTimeContext)dateTimeContextHolder.get();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static DateTimeFormatter getFormatter(DateTimeFormatter formatter, @Nullable Locale locale)
/*    */   {
/* 80 */     DateTimeFormatter formatterToUse = locale != null ? formatter.withLocale(locale) : formatter;
/* 81 */     DateTimeContext context = getDateTimeContext();
/* 82 */     return context != null ? context.getFormatter(formatterToUse) : formatterToUse;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\standard\DateTimeContextHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */