/*    */ package org.springframework.format.number.money;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.money.MonetaryAmount;
/*    */ import javax.money.format.MonetaryAmountFormat;
/*    */ import javax.money.format.MonetaryFormats;
/*    */ import org.springframework.format.Formatter;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MonetaryAmountFormatter
/*    */   implements Formatter<MonetaryAmount>
/*    */ {
/*    */   @Nullable
/*    */   private String formatName;
/*    */   
/*    */   public MonetaryAmountFormatter() {}
/*    */   
/*    */   public MonetaryAmountFormatter(String formatName)
/*    */   {
/* 55 */     this.formatName = formatName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setFormatName(String formatName)
/*    */   {
/* 66 */     this.formatName = formatName;
/*    */   }
/*    */   
/*    */ 
/*    */   public String print(MonetaryAmount object, Locale locale)
/*    */   {
/* 72 */     return getMonetaryAmountFormat(locale).format(object);
/*    */   }
/*    */   
/*    */   public MonetaryAmount parse(String text, Locale locale)
/*    */   {
/* 77 */     return getMonetaryAmountFormat(locale).parse(text);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected MonetaryAmountFormat getMonetaryAmountFormat(Locale locale)
/*    */   {
/* 91 */     if (this.formatName != null) {
/* 92 */       return MonetaryFormats.getAmountFormat(this.formatName, new String[0]);
/*    */     }
/*    */     
/* 95 */     return MonetaryFormats.getAmountFormat(locale, new String[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\number\money\MonetaryAmountFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */