/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.format.Printer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class MillisecondInstantPrinter
/*    */   implements Printer<Long>
/*    */ {
/*    */   private final DateTimeFormatter formatter;
/*    */   
/*    */   public MillisecondInstantPrinter(DateTimeFormatter formatter)
/*    */   {
/* 43 */     this.formatter = formatter;
/*    */   }
/*    */   
/*    */ 
/*    */   public String print(Long instant, Locale locale)
/*    */   {
/* 49 */     return JodaTimeContextHolder.getFormatter(this.formatter, locale).print(instant.longValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\joda\MillisecondInstantPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */