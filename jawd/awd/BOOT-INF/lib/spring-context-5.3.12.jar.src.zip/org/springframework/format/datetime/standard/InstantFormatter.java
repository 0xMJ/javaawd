/*    */ package org.springframework.format.datetime.standard;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.time.Instant;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InstantFormatter
/*    */   implements Formatter<Instant>
/*    */ {
/*    */   public Instant parse(String text, Locale locale)
/*    */     throws ParseException
/*    */   {
/* 44 */     if ((text.length() > 0) && (Character.isAlphabetic(text.charAt(0))))
/*    */     {
/* 46 */       return Instant.from(DateTimeFormatter.RFC_1123_DATE_TIME.parse(text));
/*    */     }
/*    */     
/*    */ 
/* 50 */     return Instant.parse(text);
/*    */   }
/*    */   
/*    */ 
/*    */   public String print(Instant object, Locale locale)
/*    */   {
/* 56 */     return object.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\format\datetime\standard\InstantFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */