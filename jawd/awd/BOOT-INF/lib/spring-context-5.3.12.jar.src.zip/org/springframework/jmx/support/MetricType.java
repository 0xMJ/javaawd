package org.springframework.jmx.support;

public enum MetricType
{
  GAUGE,  COUNTER;
  
  private MetricType() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\support\MetricType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */