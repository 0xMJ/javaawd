package org.springframework.jmx.export;

import javax.management.ObjectName;

public abstract interface MBeanExporterListener
{
  public abstract void mbeanRegistered(ObjectName paramObjectName);
  
  public abstract void mbeanUnregistered(ObjectName paramObjectName);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\export\MBeanExporterListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */