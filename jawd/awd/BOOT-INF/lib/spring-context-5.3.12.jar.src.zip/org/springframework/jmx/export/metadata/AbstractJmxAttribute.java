/*    */ package org.springframework.jmx.export.metadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractJmxAttribute
/*    */ {
/* 27 */   private String description = "";
/*    */   
/* 29 */   private int currencyTimeLimit = -1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setDescription(String description)
/*    */   {
/* 36 */     this.description = description;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getDescription()
/*    */   {
/* 43 */     return this.description;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setCurrencyTimeLimit(int currencyTimeLimit)
/*    */   {
/* 50 */     this.currencyTimeLimit = currencyTimeLimit;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getCurrencyTimeLimit()
/*    */   {
/* 57 */     return this.currencyTimeLimit;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\export\metadata\AbstractJmxAttribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */