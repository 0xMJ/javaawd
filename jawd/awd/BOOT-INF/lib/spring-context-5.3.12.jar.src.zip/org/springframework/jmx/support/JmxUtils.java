/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import javax.management.DynamicMBean;
/*     */ import javax.management.JMX;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerFactory;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.jmx.MBeanServerNotFoundException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JmxUtils
/*     */ {
/*     */   public static final String IDENTITY_OBJECT_NAME_KEY = "identity";
/*     */   private static final String MBEAN_SUFFIX = "MBean";
/*  66 */   private static final Log logger = LogFactory.getLog(JmxUtils.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MBeanServer locateMBeanServer()
/*     */     throws MBeanServerNotFoundException
/*     */   {
/*  78 */     return locateMBeanServer(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MBeanServer locateMBeanServer(@Nullable String agentId)
/*     */     throws MBeanServerNotFoundException
/*     */   {
/*  93 */     MBeanServer server = null;
/*     */     
/*     */ 
/*  96 */     if (!"".equals(agentId)) {
/*  97 */       List<MBeanServer> servers = MBeanServerFactory.findMBeanServer(agentId);
/*  98 */       if (!CollectionUtils.isEmpty(servers))
/*     */       {
/* 100 */         if ((servers.size() > 1) && (logger.isInfoEnabled())) {
/* 101 */           logger.info("Found more than one MBeanServer instance" + (agentId != null ? " with agent id [" + agentId + "]" : "") + ". Returning first from list.");
/*     */         }
/*     */         
/*     */ 
/* 105 */         server = (MBeanServer)servers.get(0);
/*     */       }
/*     */     }
/*     */     
/* 109 */     if ((server == null) && (!StringUtils.hasLength(agentId))) {
/*     */       try
/*     */       {
/* 112 */         server = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/*     */       catch (SecurityException ex) {
/* 115 */         throw new MBeanServerNotFoundException("No specific MBeanServer found, and not allowed to obtain the Java platform MBeanServer", ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 120 */     if (server == null) {
/* 121 */       throw new MBeanServerNotFoundException("Unable to locate an MBeanServer instance" + (agentId != null ? " with agent id [" + agentId + "]" : ""));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 126 */     if (logger.isDebugEnabled()) {
/* 127 */       logger.debug("Found MBeanServer: " + server);
/*     */     }
/* 129 */     return server;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public static Class<?>[] parameterInfoToTypes(@Nullable MBeanParameterInfo[] paramInfo)
/*     */     throws ClassNotFoundException
/*     */   {
/* 143 */     return parameterInfoToTypes(paramInfo, ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public static Class<?>[] parameterInfoToTypes(@Nullable MBeanParameterInfo[] paramInfo, @Nullable ClassLoader classLoader)
/*     */     throws ClassNotFoundException
/*     */   {
/* 159 */     Class<?>[] types = null;
/* 160 */     if ((paramInfo != null) && (paramInfo.length > 0)) {
/* 161 */       types = new Class[paramInfo.length];
/* 162 */       for (int x = 0; x < paramInfo.length; x++) {
/* 163 */         types[x] = ClassUtils.forName(paramInfo[x].getType(), classLoader);
/*     */       }
/*     */     }
/* 166 */     return types;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getMethodSignature(Method method)
/*     */   {
/* 177 */     Class<?>[] types = method.getParameterTypes();
/* 178 */     String[] signature = new String[types.length];
/* 179 */     for (int x = 0; x < types.length; x++) {
/* 180 */       signature[x] = types[x].getName();
/*     */     }
/* 182 */     return signature;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getAttributeName(PropertyDescriptor property, boolean useStrictCasing)
/*     */   {
/* 196 */     if (useStrictCasing) {
/* 197 */       return StringUtils.capitalize(property.getName());
/*     */     }
/*     */     
/* 200 */     return property.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ObjectName appendIdentityToObjectName(ObjectName objectName, Object managedResource)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 221 */     Hashtable<String, String> keyProperties = objectName.getKeyPropertyList();
/* 222 */     keyProperties.put("identity", ObjectUtils.getIdentityHexString(managedResource));
/* 223 */     return ObjectNameManager.getInstance(objectName.getDomain(), keyProperties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getClassToExpose(Object managedBean)
/*     */   {
/* 237 */     return ClassUtils.getUserClass(managedBean);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getClassToExpose(Class<?> clazz)
/*     */   {
/* 251 */     return ClassUtils.getUserClass(clazz);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isMBean(@Nullable Class<?> clazz)
/*     */   {
/* 264 */     return (clazz != null) && (
/* 265 */       (DynamicMBean.class.isAssignableFrom(clazz)) || 
/* 266 */       (getMBeanInterface(clazz) != null) || (getMXBeanInterface(clazz) != null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public static Class<?> getMBeanInterface(@Nullable Class<?> clazz)
/*     */   {
/* 278 */     if ((clazz == null) || (clazz.getSuperclass() == null)) {
/* 279 */       return null;
/*     */     }
/* 281 */     String mbeanInterfaceName = clazz.getName() + "MBean";
/* 282 */     Class<?>[] implementedInterfaces = clazz.getInterfaces();
/* 283 */     for (Class<?> iface : implementedInterfaces) {
/* 284 */       if (iface.getName().equals(mbeanInterfaceName)) {
/* 285 */         return iface;
/*     */       }
/*     */     }
/* 288 */     return getMBeanInterface(clazz.getSuperclass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public static Class<?> getMXBeanInterface(@Nullable Class<?> clazz)
/*     */   {
/* 300 */     if ((clazz == null) || (clazz.getSuperclass() == null)) {
/* 301 */       return null;
/*     */     }
/* 303 */     Class<?>[] implementedInterfaces = clazz.getInterfaces();
/* 304 */     for (Class<?> iface : implementedInterfaces) {
/* 305 */       if (JMX.isMXBeanInterface(iface)) {
/* 306 */         return iface;
/*     */       }
/*     */     }
/* 309 */     return getMXBeanInterface(clazz.getSuperclass());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\support\JmxUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */