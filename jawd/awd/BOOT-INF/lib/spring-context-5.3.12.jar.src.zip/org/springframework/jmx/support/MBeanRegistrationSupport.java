/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanRegistrationSupport
/*     */ {
/*  75 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected MBeanServer server;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  86 */   private final Set<ObjectName> registeredBeans = new LinkedHashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */   private RegistrationPolicy registrationPolicy = RegistrationPolicy.FAIL_ON_EXISTING;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServer(@Nullable MBeanServer server)
/*     */   {
/* 101 */     this.server = server;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public final MBeanServer getServer()
/*     */   {
/* 109 */     return this.server;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRegistrationPolicy(RegistrationPolicy registrationPolicy)
/*     */   {
/* 119 */     Assert.notNull(registrationPolicy, "RegistrationPolicy must not be null");
/* 120 */     this.registrationPolicy = registrationPolicy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doRegister(Object mbean, ObjectName objectName)
/*     */     throws JMException
/*     */   {
/* 132 */     Assert.state(this.server != null, "No MBeanServer set");
/*     */     
/*     */ 
/* 135 */     synchronized (this.registeredBeans) {
/* 136 */       ObjectInstance registeredBean = null;
/*     */       try {
/* 138 */         registeredBean = this.server.registerMBean(mbean, objectName);
/*     */       }
/*     */       catch (InstanceAlreadyExistsException ex) {
/* 141 */         if (this.registrationPolicy == RegistrationPolicy.IGNORE_EXISTING) {
/* 142 */           if (this.logger.isDebugEnabled()) {
/* 143 */             this.logger.debug("Ignoring existing MBean at [" + objectName + "]");
/*     */           }
/*     */         }
/* 146 */         else if (this.registrationPolicy == RegistrationPolicy.REPLACE_EXISTING) {
/*     */           try {
/* 148 */             if (this.logger.isDebugEnabled()) {
/* 149 */               this.logger.debug("Replacing existing MBean at [" + objectName + "]");
/*     */             }
/* 151 */             this.server.unregisterMBean(objectName);
/* 152 */             registeredBean = this.server.registerMBean(mbean, objectName);
/*     */           }
/*     */           catch (InstanceNotFoundException ex2) {
/* 155 */             if (this.logger.isInfoEnabled()) {
/* 156 */               this.logger.info("Unable to replace existing MBean at [" + objectName + "]", ex2);
/*     */             }
/* 158 */             throw ex;
/*     */           }
/*     */           
/*     */         } else {
/* 162 */           throw ex;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 167 */       ObjectName actualObjectName = registeredBean != null ? registeredBean.getObjectName() : null;
/* 168 */       if (actualObjectName == null) {
/* 169 */         actualObjectName = objectName;
/*     */       }
/* 171 */       this.registeredBeans.add(actualObjectName);
/*     */     }
/*     */     ObjectName actualObjectName;
/* 174 */     onRegister(actualObjectName, mbean);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void unregisterBeans()
/*     */   {
/*     */     Set<ObjectName> snapshot;
/*     */     
/* 182 */     synchronized (this.registeredBeans) {
/* 183 */       snapshot = new LinkedHashSet(this.registeredBeans); }
/*     */     Set<ObjectName> snapshot;
/* 185 */     if (!snapshot.isEmpty()) {
/* 186 */       this.logger.debug("Unregistering JMX-exposed beans");
/* 187 */       for (??? = snapshot.iterator(); ((Iterator)???).hasNext();) { ObjectName objectName = (ObjectName)((Iterator)???).next();
/* 188 */         doUnregister(objectName);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doUnregister(ObjectName objectName)
/*     */   {
/* 198 */     Assert.state(this.server != null, "No MBeanServer set");
/* 199 */     boolean actuallyUnregistered = false;
/*     */     
/* 201 */     synchronized (this.registeredBeans) {
/* 202 */       if (this.registeredBeans.remove(objectName)) {
/*     */         try
/*     */         {
/* 205 */           if (this.server.isRegistered(objectName)) {
/* 206 */             this.server.unregisterMBean(objectName);
/* 207 */             actuallyUnregistered = true;
/*     */ 
/*     */           }
/* 210 */           else if (this.logger.isInfoEnabled()) {
/* 211 */             this.logger.info("Could not unregister MBean [" + objectName + "] as said MBean is not registered (perhaps already unregistered by an external process)");
/*     */           }
/*     */           
/*     */         }
/*     */         catch (JMException ex)
/*     */         {
/* 217 */           if (this.logger.isInfoEnabled()) {
/* 218 */             this.logger.info("Could not unregister MBean [" + objectName + "]", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 224 */     if (actuallyUnregistered) {
/* 225 */       onUnregister(objectName);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected final ObjectName[] getRegisteredObjectNames()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 7	org/springframework/jmx/support/MBeanRegistrationSupport:registeredBeans	Ljava/util/Set;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 7	org/springframework/jmx/support/MBeanRegistrationSupport:registeredBeans	Ljava/util/Set;
/*     */     //   11: iconst_0
/*     */     //   12: anewarray 43	javax/management/ObjectName
/*     */     //   15: invokeinterface 52 2 0
/*     */     //   20: checkcast 53	[Ljavax/management/ObjectName;
/*     */     //   23: aload_1
/*     */     //   24: monitorexit
/*     */     //   25: areturn
/*     */     //   26: astore_2
/*     */     //   27: aload_1
/*     */     //   28: monitorexit
/*     */     //   29: aload_2
/*     */     //   30: athrow
/*     */     // Line number table:
/*     */     //   Java source line #233	-> byte code offset #0
/*     */     //   Java source line #234	-> byte code offset #7
/*     */     //   Java source line #235	-> byte code offset #26
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	31	0	this	MBeanRegistrationSupport
/*     */     //   5	23	1	Ljava/lang/Object;	Object
/*     */     //   26	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	25	26	finally
/*     */     //   26	29	26	finally
/*     */   }
/*     */   
/*     */   protected void onRegister(ObjectName objectName, Object mbean)
/*     */   {
/* 247 */     onRegister(objectName);
/*     */   }
/*     */   
/*     */   protected void onRegister(ObjectName objectName) {}
/*     */   
/*     */   protected void onUnregister(ObjectName objectName) {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\support\MBeanRegistrationSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */