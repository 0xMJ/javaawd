/*     */ package org.springframework.jmx.export.assembler;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.management.Descriptor;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.modelmbean.ModelMBeanNotificationInfo;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jmx.export.metadata.InvalidMetadataException;
/*     */ import org.springframework.jmx.export.metadata.JmxAttributeSource;
/*     */ import org.springframework.jmx.export.metadata.JmxMetadataUtils;
/*     */ import org.springframework.jmx.export.metadata.ManagedAttribute;
/*     */ import org.springframework.jmx.export.metadata.ManagedMetric;
/*     */ import org.springframework.jmx.export.metadata.ManagedNotification;
/*     */ import org.springframework.jmx.export.metadata.ManagedOperation;
/*     */ import org.springframework.jmx.export.metadata.ManagedOperationParameter;
/*     */ import org.springframework.jmx.export.metadata.ManagedResource;
/*     */ import org.springframework.jmx.support.MetricType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MetadataMBeanInfoAssembler
/*     */   extends AbstractReflectiveMBeanInfoAssembler
/*     */   implements AutodetectCapableMBeanInfoAssembler, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private JmxAttributeSource attributeSource;
/*     */   
/*     */   public MetadataMBeanInfoAssembler() {}
/*     */   
/*     */   public MetadataMBeanInfoAssembler(JmxAttributeSource attributeSource)
/*     */   {
/*  79 */     Assert.notNull(attributeSource, "JmxAttributeSource must not be null");
/*  80 */     this.attributeSource = attributeSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttributeSource(JmxAttributeSource attributeSource)
/*     */   {
/*  90 */     Assert.notNull(attributeSource, "JmxAttributeSource must not be null");
/*  91 */     this.attributeSource = attributeSource;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */   {
/*  96 */     if (this.attributeSource == null) {
/*  97 */       throw new IllegalArgumentException("Property 'attributeSource' is required");
/*     */     }
/*     */   }
/*     */   
/*     */   private JmxAttributeSource obtainAttributeSource() {
/* 102 */     Assert.state(this.attributeSource != null, "No JmxAttributeSource set");
/* 103 */     return this.attributeSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkManagedBean(Object managedBean)
/*     */     throws IllegalArgumentException
/*     */   {
/* 113 */     if (AopUtils.isJdkDynamicProxy(managedBean)) {
/* 114 */       throw new IllegalArgumentException("MetadataMBeanInfoAssembler does not support JDK dynamic proxies - export the target beans directly or use CGLIB proxies instead");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean includeBean(Class<?> beanClass, String beanName)
/*     */   {
/* 128 */     return obtainAttributeSource().getManagedResource(getClassToExpose(beanClass)) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean includeReadAttribute(Method method, String beanKey)
/*     */   {
/* 139 */     return (hasManagedAttribute(method)) || (hasManagedMetric(method));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean includeWriteAttribute(Method method, String beanKey)
/*     */   {
/* 150 */     return hasManagedAttribute(method);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean includeOperation(Method method, String beanKey)
/*     */   {
/* 161 */     PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 162 */     return ((pd != null) && (hasManagedAttribute(method))) || (hasManagedOperation(method));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean hasManagedAttribute(Method method)
/*     */   {
/* 169 */     return obtainAttributeSource().getManagedAttribute(method) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean hasManagedMetric(Method method)
/*     */   {
/* 176 */     return obtainAttributeSource().getManagedMetric(method) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean hasManagedOperation(Method method)
/*     */   {
/* 184 */     return obtainAttributeSource().getManagedOperation(method) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDescription(Object managedBean, String beanKey)
/*     */   {
/* 194 */     ManagedResource mr = obtainAttributeSource().getManagedResource(getClassToExpose(managedBean));
/* 195 */     return mr != null ? mr.getDescription() : "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getAttributeDescription(PropertyDescriptor propertyDescriptor, String beanKey)
/*     */   {
/* 205 */     Method readMethod = propertyDescriptor.getReadMethod();
/* 206 */     Method writeMethod = propertyDescriptor.getWriteMethod();
/*     */     
/*     */ 
/* 209 */     ManagedAttribute getter = readMethod != null ? obtainAttributeSource().getManagedAttribute(readMethod) : null;
/*     */     
/* 211 */     ManagedAttribute setter = writeMethod != null ? obtainAttributeSource().getManagedAttribute(writeMethod) : null;
/*     */     
/* 213 */     if ((getter != null) && (StringUtils.hasText(getter.getDescription()))) {
/* 214 */       return getter.getDescription();
/*     */     }
/* 216 */     if ((setter != null) && (StringUtils.hasText(setter.getDescription()))) {
/* 217 */       return setter.getDescription();
/*     */     }
/*     */     
/* 220 */     ManagedMetric metric = readMethod != null ? obtainAttributeSource().getManagedMetric(readMethod) : null;
/* 221 */     if ((metric != null) && (StringUtils.hasText(metric.getDescription()))) {
/* 222 */       return metric.getDescription();
/*     */     }
/*     */     
/* 225 */     return propertyDescriptor.getDisplayName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getOperationDescription(Method method, String beanKey)
/*     */   {
/* 234 */     PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 235 */     if (pd != null) {
/* 236 */       ManagedAttribute ma = obtainAttributeSource().getManagedAttribute(method);
/* 237 */       if ((ma != null) && (StringUtils.hasText(ma.getDescription()))) {
/* 238 */         return ma.getDescription();
/*     */       }
/* 240 */       ManagedMetric metric = obtainAttributeSource().getManagedMetric(method);
/* 241 */       if ((metric != null) && (StringUtils.hasText(metric.getDescription()))) {
/* 242 */         return metric.getDescription();
/*     */       }
/* 244 */       return method.getName();
/*     */     }
/*     */     
/* 247 */     ManagedOperation mo = obtainAttributeSource().getManagedOperation(method);
/* 248 */     if ((mo != null) && (StringUtils.hasText(mo.getDescription()))) {
/* 249 */       return mo.getDescription();
/*     */     }
/* 251 */     return method.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanParameterInfo[] getOperationParameters(Method method, String beanKey)
/*     */   {
/* 262 */     ManagedOperationParameter[] params = obtainAttributeSource().getManagedOperationParameters(method);
/* 263 */     if (ObjectUtils.isEmpty(params)) {
/* 264 */       return super.getOperationParameters(method, beanKey);
/*     */     }
/*     */     
/* 267 */     MBeanParameterInfo[] parameterInfo = new MBeanParameterInfo[params.length];
/* 268 */     Class<?>[] methodParameters = method.getParameterTypes();
/* 269 */     for (int i = 0; i < params.length; i++) {
/* 270 */       ManagedOperationParameter param = params[i];
/* 271 */       parameterInfo[i] = new MBeanParameterInfo(param
/* 272 */         .getName(), methodParameters[i].getName(), param.getDescription());
/*     */     }
/* 274 */     return parameterInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelMBeanNotificationInfo[] getNotificationInfo(Object managedBean, String beanKey)
/*     */   {
/* 284 */     ManagedNotification[] notificationAttributes = obtainAttributeSource().getManagedNotifications(getClassToExpose(managedBean));
/* 285 */     ModelMBeanNotificationInfo[] notificationInfos = new ModelMBeanNotificationInfo[notificationAttributes.length];
/*     */     
/*     */ 
/* 288 */     for (int i = 0; i < notificationAttributes.length; i++) {
/* 289 */       ManagedNotification attribute = notificationAttributes[i];
/* 290 */       notificationInfos[i] = JmxMetadataUtils.convertToModelMBeanNotificationInfo(attribute);
/*     */     }
/*     */     
/* 293 */     return notificationInfos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void populateMBeanDescriptor(Descriptor desc, Object managedBean, String beanKey)
/*     */   {
/* 304 */     ManagedResource mr = obtainAttributeSource().getManagedResource(getClassToExpose(managedBean));
/* 305 */     if (mr == null)
/*     */     {
/* 307 */       throw new InvalidMetadataException("No ManagedResource attribute found for class: " + getClassToExpose(managedBean));
/*     */     }
/*     */     
/* 310 */     applyCurrencyTimeLimit(desc, mr.getCurrencyTimeLimit());
/*     */     
/* 312 */     if (mr.isLog()) {
/* 313 */       desc.setField("log", "true");
/*     */     }
/* 315 */     if (StringUtils.hasLength(mr.getLogFile())) {
/* 316 */       desc.setField("logFile", mr.getLogFile());
/*     */     }
/*     */     
/* 319 */     if (StringUtils.hasLength(mr.getPersistPolicy())) {
/* 320 */       desc.setField("persistPolicy", mr.getPersistPolicy());
/*     */     }
/* 322 */     if (mr.getPersistPeriod() >= 0) {
/* 323 */       desc.setField("persistPeriod", Integer.toString(mr.getPersistPeriod()));
/*     */     }
/* 325 */     if (StringUtils.hasLength(mr.getPersistName())) {
/* 326 */       desc.setField("persistName", mr.getPersistName());
/*     */     }
/* 328 */     if (StringUtils.hasLength(mr.getPersistLocation())) {
/* 329 */       desc.setField("persistLocation", mr.getPersistLocation());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void populateAttributeDescriptor(Descriptor desc, @Nullable Method getter, @Nullable Method setter, String beanKey)
/*     */   {
/* 341 */     if (getter != null) {
/* 342 */       ManagedMetric metric = obtainAttributeSource().getManagedMetric(getter);
/* 343 */       if (metric != null) {
/* 344 */         populateMetricDescriptor(desc, metric);
/* 345 */         return;
/*     */       }
/*     */     }
/*     */     
/* 349 */     ManagedAttribute gma = getter != null ? obtainAttributeSource().getManagedAttribute(getter) : null;
/* 350 */     ManagedAttribute sma = setter != null ? obtainAttributeSource().getManagedAttribute(setter) : null;
/* 351 */     populateAttributeDescriptor(desc, gma != null ? gma : ManagedAttribute.EMPTY, sma != null ? sma : ManagedAttribute.EMPTY);
/*     */   }
/*     */   
/*     */ 
/*     */   private void populateAttributeDescriptor(Descriptor desc, ManagedAttribute gma, ManagedAttribute sma)
/*     */   {
/* 357 */     applyCurrencyTimeLimit(desc, resolveIntDescriptor(gma.getCurrencyTimeLimit(), sma.getCurrencyTimeLimit()));
/*     */     
/* 359 */     Object defaultValue = resolveObjectDescriptor(gma.getDefaultValue(), sma.getDefaultValue());
/* 360 */     desc.setField("default", defaultValue);
/*     */     
/* 362 */     String persistPolicy = resolveStringDescriptor(gma.getPersistPolicy(), sma.getPersistPolicy());
/* 363 */     if (StringUtils.hasLength(persistPolicy)) {
/* 364 */       desc.setField("persistPolicy", persistPolicy);
/*     */     }
/* 366 */     int persistPeriod = resolveIntDescriptor(gma.getPersistPeriod(), sma.getPersistPeriod());
/* 367 */     if (persistPeriod >= 0) {
/* 368 */       desc.setField("persistPeriod", Integer.toString(persistPeriod));
/*     */     }
/*     */   }
/*     */   
/*     */   private void populateMetricDescriptor(Descriptor desc, ManagedMetric metric) {
/* 373 */     applyCurrencyTimeLimit(desc, metric.getCurrencyTimeLimit());
/*     */     
/* 375 */     if (StringUtils.hasLength(metric.getPersistPolicy())) {
/* 376 */       desc.setField("persistPolicy", metric.getPersistPolicy());
/*     */     }
/* 378 */     if (metric.getPersistPeriod() >= 0) {
/* 379 */       desc.setField("persistPeriod", Integer.toString(metric.getPersistPeriod()));
/*     */     }
/*     */     
/* 382 */     if (StringUtils.hasLength(metric.getDisplayName())) {
/* 383 */       desc.setField("displayName", metric.getDisplayName());
/*     */     }
/*     */     
/* 386 */     if (StringUtils.hasLength(metric.getUnit())) {
/* 387 */       desc.setField("units", metric.getUnit());
/*     */     }
/*     */     
/* 390 */     if (StringUtils.hasLength(metric.getCategory())) {
/* 391 */       desc.setField("metricCategory", metric.getCategory());
/*     */     }
/*     */     
/* 394 */     desc.setField("metricType", metric.getMetricType().toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void populateOperationDescriptor(Descriptor desc, Method method, String beanKey)
/*     */   {
/* 404 */     ManagedOperation mo = obtainAttributeSource().getManagedOperation(method);
/* 405 */     if (mo != null) {
/* 406 */       applyCurrencyTimeLimit(desc, mo.getCurrencyTimeLimit());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int resolveIntDescriptor(int getter, int setter)
/*     */   {
/* 420 */     return getter >= setter ? getter : setter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Object resolveObjectDescriptor(@Nullable Object getter, @Nullable Object setter)
/*     */   {
/* 433 */     return getter != null ? getter : setter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private String resolveStringDescriptor(@Nullable String getter, @Nullable String setter)
/*     */   {
/* 448 */     return StringUtils.hasLength(getter) ? getter : setter;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\export\assembler\MetadataMBeanInfoAssembler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */