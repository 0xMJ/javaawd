/*     */ package org.springframework.jmx.export.assembler;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.management.Descriptor;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.modelmbean.ModelMBeanAttributeInfo;
/*     */ import javax.management.modelmbean.ModelMBeanOperationInfo;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.jmx.support.JmxUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractReflectiveMBeanInfoAssembler
/*     */   extends AbstractMBeanInfoAssembler
/*     */ {
/*     */   protected static final String FIELD_GET_METHOD = "getMethod";
/*     */   protected static final String FIELD_SET_METHOD = "setMethod";
/*     */   protected static final String FIELD_ROLE = "role";
/*     */   protected static final String ROLE_GETTER = "getter";
/*     */   protected static final String ROLE_SETTER = "setter";
/*     */   protected static final String ROLE_OPERATION = "operation";
/*     */   protected static final String FIELD_VISIBILITY = "visibility";
/*     */   protected static final int ATTRIBUTE_OPERATION_VISIBILITY = 4;
/*     */   protected static final String FIELD_CLASS = "class";
/*     */   protected static final String FIELD_LOG = "log";
/*     */   protected static final String FIELD_LOG_FILE = "logFile";
/*     */   protected static final String FIELD_CURRENCY_TIME_LIMIT = "currencyTimeLimit";
/*     */   protected static final String FIELD_DEFAULT = "default";
/*     */   protected static final String FIELD_PERSIST_POLICY = "persistPolicy";
/*     */   protected static final String FIELD_PERSIST_PERIOD = "persistPeriod";
/*     */   protected static final String FIELD_PERSIST_LOCATION = "persistLocation";
/*     */   protected static final String FIELD_PERSIST_NAME = "persistName";
/*     */   protected static final String FIELD_DISPLAY_NAME = "displayName";
/*     */   protected static final String FIELD_UNITS = "units";
/*     */   protected static final String FIELD_METRIC_TYPE = "metricType";
/*     */   protected static final String FIELD_METRIC_CATEGORY = "metricCategory";
/*     */   @Nullable
/*     */   private Integer defaultCurrencyTimeLimit;
/* 182 */   private boolean useStrictCasing = true;
/*     */   
/* 184 */   private boolean exposeClassDescriptor = false;
/*     */   @Nullable
/* 186 */   private ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultCurrencyTimeLimit(@Nullable Integer defaultCurrencyTimeLimit)
/*     */   {
/* 211 */     this.defaultCurrencyTimeLimit = defaultCurrencyTimeLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Integer getDefaultCurrencyTimeLimit()
/*     */   {
/* 219 */     return this.defaultCurrencyTimeLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseStrictCasing(boolean useStrictCasing)
/*     */   {
/* 230 */     this.useStrictCasing = useStrictCasing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isUseStrictCasing()
/*     */   {
/* 237 */     return this.useStrictCasing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExposeClassDescriptor(boolean exposeClassDescriptor)
/*     */   {
/* 257 */     this.exposeClassDescriptor = exposeClassDescriptor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isExposeClassDescriptor()
/*     */   {
/* 264 */     return this.exposeClassDescriptor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParameterNameDiscoverer(@Nullable ParameterNameDiscoverer parameterNameDiscoverer)
/*     */   {
/* 273 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected ParameterNameDiscoverer getParameterNameDiscoverer()
/*     */   {
/* 282 */     return this.parameterNameDiscoverer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelMBeanAttributeInfo[] getAttributeInfo(Object managedBean, String beanKey)
/*     */     throws JMException
/*     */   {
/* 300 */     PropertyDescriptor[] props = BeanUtils.getPropertyDescriptors(getClassToExpose(managedBean));
/* 301 */     List<ModelMBeanAttributeInfo> infos = new ArrayList();
/*     */     
/* 303 */     for (PropertyDescriptor prop : props) {
/* 304 */       Method getter = prop.getReadMethod();
/* 305 */       if ((getter == null) || (getter.getDeclaringClass() != Object.class))
/*     */       {
/*     */ 
/* 308 */         if ((getter != null) && (!includeReadAttribute(getter, beanKey))) {
/* 309 */           getter = null;
/*     */         }
/*     */         
/* 312 */         Method setter = prop.getWriteMethod();
/* 313 */         if ((setter != null) && (!includeWriteAttribute(setter, beanKey))) {
/* 314 */           setter = null;
/*     */         }
/*     */         
/* 317 */         if ((getter != null) || (setter != null))
/*     */         {
/* 319 */           String attrName = JmxUtils.getAttributeName(prop, isUseStrictCasing());
/* 320 */           String description = getAttributeDescription(prop, beanKey);
/* 321 */           ModelMBeanAttributeInfo info = new ModelMBeanAttributeInfo(attrName, description, getter, setter);
/*     */           
/* 323 */           Descriptor desc = info.getDescriptor();
/* 324 */           if (getter != null) {
/* 325 */             desc.setField("getMethod", getter.getName());
/*     */           }
/* 327 */           if (setter != null) {
/* 328 */             desc.setField("setMethod", setter.getName());
/*     */           }
/*     */           
/* 331 */           populateAttributeDescriptor(desc, getter, setter, beanKey);
/* 332 */           info.setDescriptor(desc);
/* 333 */           infos.add(info);
/*     */         }
/*     */       }
/*     */     }
/* 337 */     return (ModelMBeanAttributeInfo[])infos.toArray(new ModelMBeanAttributeInfo[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelMBeanOperationInfo[] getOperationInfo(Object managedBean, String beanKey)
/*     */   {
/* 354 */     Method[] methods = getClassToExpose(managedBean).getMethods();
/* 355 */     List<ModelMBeanOperationInfo> infos = new ArrayList();
/*     */     
/* 357 */     for (Method method : methods) {
/* 358 */       if (!method.isSynthetic())
/*     */       {
/*     */ 
/* 361 */         if (Object.class != method.getDeclaringClass())
/*     */         {
/*     */ 
/*     */ 
/* 365 */           ModelMBeanOperationInfo info = null;
/* 366 */           PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 367 */           if ((pd != null) && (((method.equals(pd.getReadMethod())) && (includeReadAttribute(method, beanKey))) || (
/* 368 */             (method.equals(pd.getWriteMethod())) && (includeWriteAttribute(method, beanKey)))))
/*     */           {
/*     */ 
/* 371 */             info = createModelMBeanOperationInfo(method, pd.getName(), beanKey);
/* 372 */             Descriptor desc = info.getDescriptor();
/* 373 */             if (method.equals(pd.getReadMethod())) {
/* 374 */               desc.setField("role", "getter");
/*     */             }
/*     */             else {
/* 377 */               desc.setField("role", "setter");
/*     */             }
/* 379 */             desc.setField("visibility", Integer.valueOf(4));
/* 380 */             if (isExposeClassDescriptor()) {
/* 381 */               desc.setField("class", getClassForDescriptor(managedBean).getName());
/*     */             }
/* 383 */             info.setDescriptor(desc);
/*     */           }
/*     */           
/*     */ 
/* 387 */           if ((info == null) && (includeOperation(method, beanKey))) {
/* 388 */             info = createModelMBeanOperationInfo(method, method.getName(), beanKey);
/* 389 */             Descriptor desc = info.getDescriptor();
/* 390 */             desc.setField("role", "operation");
/* 391 */             if (isExposeClassDescriptor()) {
/* 392 */               desc.setField("class", getClassForDescriptor(managedBean).getName());
/*     */             }
/* 394 */             populateOperationDescriptor(desc, method, beanKey);
/* 395 */             info.setDescriptor(desc);
/*     */           }
/*     */           
/* 398 */           if (info != null)
/* 399 */             infos.add(info);
/*     */         }
/*     */       }
/*     */     }
/* 403 */     return (ModelMBeanOperationInfo[])infos.toArray(new ModelMBeanOperationInfo[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelMBeanOperationInfo createModelMBeanOperationInfo(Method method, String name, String beanKey)
/*     */   {
/* 417 */     MBeanParameterInfo[] params = getOperationParameters(method, beanKey);
/* 418 */     if (params.length == 0) {
/* 419 */       return new ModelMBeanOperationInfo(getOperationDescription(method, beanKey), method);
/*     */     }
/*     */     
/* 422 */     return new ModelMBeanOperationInfo(method.getName(), 
/* 423 */       getOperationDescription(method, beanKey), 
/* 424 */       getOperationParameters(method, beanKey), method
/* 425 */       .getReturnType().getName(), 3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> getClassForDescriptor(Object managedBean)
/*     */   {
/* 442 */     if (AopUtils.isJdkDynamicProxy(managedBean)) {
/* 443 */       return org.springframework.aop.framework.AopProxyUtils.proxiedUserInterfaces(managedBean)[0];
/*     */     }
/* 445 */     return getClassToExpose(managedBean);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract boolean includeReadAttribute(Method paramMethod, String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract boolean includeWriteAttribute(Method paramMethod, String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract boolean includeOperation(Method paramMethod, String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getAttributeDescription(PropertyDescriptor propertyDescriptor, String beanKey)
/*     */   {
/* 488 */     return propertyDescriptor.getDisplayName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getOperationDescription(Method method, String beanKey)
/*     */   {
/* 501 */     return method.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanParameterInfo[] getOperationParameters(Method method, String beanKey)
/*     */   {
/* 513 */     ParameterNameDiscoverer paramNameDiscoverer = getParameterNameDiscoverer();
/* 514 */     String[] paramNames = paramNameDiscoverer != null ? paramNameDiscoverer.getParameterNames(method) : null;
/* 515 */     if (paramNames == null) {
/* 516 */       return new MBeanParameterInfo[0];
/*     */     }
/*     */     
/* 519 */     MBeanParameterInfo[] info = new MBeanParameterInfo[paramNames.length];
/* 520 */     Class<?>[] typeParameters = method.getParameterTypes();
/* 521 */     for (int i = 0; i < info.length; i++) {
/* 522 */       info[i] = new MBeanParameterInfo(paramNames[i], typeParameters[i].getName(), paramNames[i]);
/*     */     }
/*     */     
/* 525 */     return info;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void populateMBeanDescriptor(Descriptor descriptor, Object managedBean, String beanKey)
/*     */   {
/* 541 */     applyDefaultCurrencyTimeLimit(descriptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void populateAttributeDescriptor(Descriptor desc, @Nullable Method getter, @Nullable Method setter, String beanKey)
/*     */   {
/* 560 */     applyDefaultCurrencyTimeLimit(desc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void populateOperationDescriptor(Descriptor desc, Method method, String beanKey)
/*     */   {
/* 576 */     applyDefaultCurrencyTimeLimit(desc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void applyDefaultCurrencyTimeLimit(Descriptor desc)
/*     */   {
/* 586 */     if (getDefaultCurrencyTimeLimit() != null) {
/* 587 */       desc.setField("currencyTimeLimit", getDefaultCurrencyTimeLimit().toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void applyCurrencyTimeLimit(Descriptor desc, int currencyTimeLimit)
/*     */   {
/* 603 */     if (currencyTimeLimit > 0)
/*     */     {
/* 605 */       desc.setField("currencyTimeLimit", Integer.toString(currencyTimeLimit));
/*     */     }
/* 607 */     else if (currencyTimeLimit == 0)
/*     */     {
/* 609 */       desc.setField("currencyTimeLimit", Integer.toString(Integer.MAX_VALUE));
/*     */     }
/*     */     else
/*     */     {
/* 613 */       applyDefaultCurrencyTimeLimit(desc);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\export\assembler\AbstractReflectiveMBeanInfoAssembler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */