/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.remote.JMXConnectorServer;
/*     */ import javax.management.remote.JMXConnectorServerFactory;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import javax.management.remote.MBeanServerForwarder;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jmx.JmxException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectorServerFactoryBean
/*     */   extends MBeanRegistrationSupport
/*     */   implements FactoryBean<JMXConnectorServer>, InitializingBean, DisposableBean
/*     */ {
/*     */   public static final String DEFAULT_SERVICE_URL = "service:jmx:jmxmp://localhost:9875";
/*  64 */   private String serviceUrl = "service:jmx:jmxmp://localhost:9875";
/*     */   
/*  66 */   private Map<String, Object> environment = new HashMap();
/*     */   
/*     */   @Nullable
/*     */   private MBeanServerForwarder forwarder;
/*     */   
/*     */   @Nullable
/*     */   private ObjectName objectName;
/*     */   
/*  74 */   private boolean threaded = false;
/*     */   
/*  76 */   private boolean daemon = false;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private JMXConnectorServer connectorServer;
/*     */   
/*     */ 
/*     */ 
/*     */   public void setServiceUrl(String serviceUrl)
/*     */   {
/*  86 */     this.serviceUrl = serviceUrl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnvironment(@Nullable Properties environment)
/*     */   {
/*  94 */     CollectionUtils.mergePropertiesIntoMap(environment, this.environment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnvironmentMap(@Nullable Map<String, ?> environment)
/*     */   {
/* 102 */     if (environment != null) {
/* 103 */       this.environment.putAll(environment);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setForwarder(MBeanServerForwarder forwarder)
/*     */   {
/* 111 */     this.forwarder = forwarder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setObjectName(Object objectName)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 121 */     this.objectName = ObjectNameManager.getInstance(objectName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setThreaded(boolean threaded)
/*     */   {
/* 128 */     this.threaded = threaded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDaemon(boolean daemon)
/*     */   {
/* 136 */     this.daemon = daemon;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws JMException, IOException
/*     */   {
/* 151 */     if (this.server == null) {
/* 152 */       this.server = JmxUtils.locateMBeanServer();
/*     */     }
/*     */     
/*     */ 
/* 156 */     JMXServiceURL url = new JMXServiceURL(this.serviceUrl);
/*     */     
/*     */ 
/* 159 */     this.connectorServer = JMXConnectorServerFactory.newJMXConnectorServer(url, this.environment, this.server);
/*     */     
/*     */ 
/* 162 */     if (this.forwarder != null) {
/* 163 */       this.connectorServer.setMBeanServerForwarder(this.forwarder);
/*     */     }
/*     */     
/*     */ 
/* 167 */     if (this.objectName != null) {
/* 168 */       doRegister(this.connectorServer, this.objectName);
/*     */     }
/*     */     try
/*     */     {
/* 172 */       if (this.threaded)
/*     */       {
/* 174 */         final JMXConnectorServer serverToStart = this.connectorServer;
/* 175 */         Thread connectorThread = new Thread()
/*     */         {
/*     */           public void run() {
/*     */             try {
/* 179 */               serverToStart.start();
/*     */             }
/*     */             catch (IOException ex) {
/* 182 */               throw new JmxException("Could not start JMX connector server after delay", ex);
/*     */             }
/*     */             
/*     */           }
/* 186 */         };
/* 187 */         connectorThread.setName("JMX Connector Thread [" + this.serviceUrl + "]");
/* 188 */         connectorThread.setDaemon(this.daemon);
/* 189 */         connectorThread.start();
/*     */       }
/*     */       else
/*     */       {
/* 193 */         this.connectorServer.start();
/*     */       }
/*     */       
/* 196 */       if (this.logger.isInfoEnabled()) {
/* 197 */         this.logger.info("JMX connector server started: " + this.connectorServer);
/*     */       }
/*     */       
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 203 */       unregisterBeans();
/* 204 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   public JMXConnectorServer getObject()
/*     */   {
/* 212 */     return this.connectorServer;
/*     */   }
/*     */   
/*     */   public Class<? extends JMXConnectorServer> getObjectType()
/*     */   {
/* 217 */     return this.connectorServer != null ? this.connectorServer.getClass() : JMXConnectorServer.class;
/*     */   }
/*     */   
/*     */   public boolean isSingleton()
/*     */   {
/* 222 */     return true;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void destroy()
/*     */     throws IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 20	org/springframework/jmx/support/ConnectorServerFactoryBean:connectorServer	Ljavax/management/remote/JMXConnectorServer;
/*     */     //   4: ifnull +53 -> 57
/*     */     //   7: aload_0
/*     */     //   8: getfield 35	org/springframework/jmx/support/ConnectorServerFactoryBean:logger	Lorg/apache/commons/logging/Log;
/*     */     //   11: invokeinterface 36 1 0
/*     */     //   16: ifeq +34 -> 50
/*     */     //   19: aload_0
/*     */     //   20: getfield 35	org/springframework/jmx/support/ConnectorServerFactoryBean:logger	Lorg/apache/commons/logging/Log;
/*     */     //   23: new 25	java/lang/StringBuilder
/*     */     //   26: dup
/*     */     //   27: invokespecial 26	java/lang/StringBuilder:<init>	()V
/*     */     //   30: ldc 44
/*     */     //   32: invokevirtual 28	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   35: aload_0
/*     */     //   36: getfield 20	org/springframework/jmx/support/ConnectorServerFactoryBean:connectorServer	Ljavax/management/remote/JMXConnectorServer;
/*     */     //   39: invokevirtual 38	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   42: invokevirtual 30	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   45: invokeinterface 39 2 0
/*     */     //   50: aload_0
/*     */     //   51: getfield 20	org/springframework/jmx/support/ConnectorServerFactoryBean:connectorServer	Ljavax/management/remote/JMXConnectorServer;
/*     */     //   54: invokevirtual 45	javax/management/remote/JMXConnectorServer:stop	()V
/*     */     //   57: aload_0
/*     */     //   58: invokevirtual 41	org/springframework/jmx/support/ConnectorServerFactoryBean:unregisterBeans	()V
/*     */     //   61: goto +10 -> 71
/*     */     //   64: astore_1
/*     */     //   65: aload_0
/*     */     //   66: invokevirtual 41	org/springframework/jmx/support/ConnectorServerFactoryBean:unregisterBeans	()V
/*     */     //   69: aload_1
/*     */     //   70: athrow
/*     */     //   71: return
/*     */     // Line number table:
/*     */     //   Java source line #234	-> byte code offset #0
/*     */     //   Java source line #235	-> byte code offset #7
/*     */     //   Java source line #236	-> byte code offset #19
/*     */     //   Java source line #238	-> byte code offset #50
/*     */     //   Java source line #242	-> byte code offset #57
/*     */     //   Java source line #243	-> byte code offset #61
/*     */     //   Java source line #242	-> byte code offset #64
/*     */     //   Java source line #243	-> byte code offset #69
/*     */     //   Java source line #244	-> byte code offset #71
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	72	0	this	ConnectorServerFactoryBean
/*     */     //   64	6	1	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	57	64	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\support\ConnectorServerFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */