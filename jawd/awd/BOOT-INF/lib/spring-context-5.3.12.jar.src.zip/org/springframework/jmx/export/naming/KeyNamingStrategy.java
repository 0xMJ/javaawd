/*     */ package org.springframework.jmx.export.naming;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.jmx.support.ObjectNameManager;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyNamingStrategy
/*     */   implements ObjectNamingStrategy, InitializingBean
/*     */ {
/*  60 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Properties mappings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Resource[] mappingLocations;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Properties mergedMappings;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMappings(Properties mappings)
/*     */   {
/*  90 */     this.mappings = mappings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMappingLocation(Resource location)
/*     */   {
/*  98 */     this.mappingLocations = new Resource[] { location };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMappingLocations(Resource... mappingLocations)
/*     */   {
/* 106 */     this.mappingLocations = mappingLocations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws IOException
/*     */   {
/* 117 */     this.mergedMappings = new Properties();
/* 118 */     CollectionUtils.mergePropertiesIntoMap(this.mappings, this.mergedMappings);
/*     */     
/* 120 */     if (this.mappingLocations != null) {
/* 121 */       for (Resource location : this.mappingLocations) {
/* 122 */         if (this.logger.isDebugEnabled()) {
/* 123 */           this.logger.debug("Loading JMX object name mappings file from " + location);
/*     */         }
/* 125 */         PropertiesLoaderUtils.fillProperties(this.mergedMappings, location);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getObjectName(Object managedBean, @Nullable String beanKey)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 137 */     Assert.notNull(beanKey, "KeyNamingStrategy requires bean key");
/* 138 */     String objectName = null;
/* 139 */     if (this.mergedMappings != null) {
/* 140 */       objectName = this.mergedMappings.getProperty(beanKey);
/*     */     }
/* 142 */     if (objectName == null) {
/* 143 */       objectName = beanKey;
/*     */     }
/* 145 */     return ObjectNameManager.getInstance(objectName);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\export\naming\KeyNamingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */