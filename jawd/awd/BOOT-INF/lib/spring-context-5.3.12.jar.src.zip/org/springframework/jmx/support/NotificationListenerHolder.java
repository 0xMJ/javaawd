/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.NotificationFilter;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectName;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NotificationListenerHolder
/*     */ {
/*     */   @Nullable
/*     */   private NotificationListener notificationListener;
/*     */   @Nullable
/*     */   private NotificationFilter notificationFilter;
/*     */   @Nullable
/*     */   private Object handback;
/*     */   @Nullable
/*     */   protected Set<Object> mappedObjectNames;
/*     */   
/*     */   public void setNotificationListener(@Nullable NotificationListener notificationListener)
/*     */   {
/*  62 */     this.notificationListener = notificationListener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public NotificationListener getNotificationListener()
/*     */   {
/*  70 */     return this.notificationListener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNotificationFilter(@Nullable NotificationFilter notificationFilter)
/*     */   {
/*  79 */     this.notificationFilter = notificationFilter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public NotificationFilter getNotificationFilter()
/*     */   {
/*  89 */     return this.notificationFilter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHandback(@Nullable Object handback)
/*     */   {
/* 100 */     this.handback = handback;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object getHandback()
/*     */   {
/* 112 */     return this.handback;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMappedObjectName(@Nullable Object mappedObjectName)
/*     */   {
/* 124 */     this.mappedObjectNames = (mappedObjectName != null ? new LinkedHashSet(Collections.singleton(mappedObjectName)) : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMappedObjectNames(Object... mappedObjectNames)
/*     */   {
/* 135 */     this.mappedObjectNames = new LinkedHashSet(Arrays.asList(mappedObjectNames));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public ObjectName[] getResolvedObjectNames()
/*     */     throws MalformedObjectNameException
/*     */   {
/* 146 */     if (this.mappedObjectNames == null) {
/* 147 */       return null;
/*     */     }
/* 149 */     ObjectName[] resolved = new ObjectName[this.mappedObjectNames.size()];
/* 150 */     int i = 0;
/* 151 */     for (Object objectName : this.mappedObjectNames) {
/* 152 */       resolved[i] = ObjectNameManager.getInstance(objectName);
/* 153 */       i++;
/*     */     }
/* 155 */     return resolved;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(@Nullable Object other)
/*     */   {
/* 161 */     if (this == other) {
/* 162 */       return true;
/*     */     }
/* 164 */     if (!(other instanceof NotificationListenerHolder)) {
/* 165 */       return false;
/*     */     }
/* 167 */     NotificationListenerHolder otherNlh = (NotificationListenerHolder)other;
/* 168 */     return (ObjectUtils.nullSafeEquals(this.notificationListener, otherNlh.notificationListener)) && 
/* 169 */       (ObjectUtils.nullSafeEquals(this.notificationFilter, otherNlh.notificationFilter)) && 
/* 170 */       (ObjectUtils.nullSafeEquals(this.handback, otherNlh.handback)) && 
/* 171 */       (ObjectUtils.nullSafeEquals(this.mappedObjectNames, otherNlh.mappedObjectNames));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 176 */     int hashCode = ObjectUtils.nullSafeHashCode(this.notificationListener);
/* 177 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.notificationFilter);
/* 178 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.handback);
/* 179 */     hashCode = 29 * hashCode + ObjectUtils.nullSafeHashCode(this.mappedObjectNames);
/* 180 */     return hashCode;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\support\NotificationListenerHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */