/*     */ package org.springframework.jmx.export.naming;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jmx.export.metadata.JmxAttributeSource;
/*     */ import org.springframework.jmx.export.metadata.ManagedResource;
/*     */ import org.springframework.jmx.support.ObjectNameManager;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MetadataNamingStrategy
/*     */   implements ObjectNamingStrategy, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private JmxAttributeSource attributeSource;
/*     */   @Nullable
/*     */   private String defaultDomain;
/*     */   
/*     */   public MetadataNamingStrategy() {}
/*     */   
/*     */   public MetadataNamingStrategy(JmxAttributeSource attributeSource)
/*     */   {
/*  76 */     Assert.notNull(attributeSource, "JmxAttributeSource must not be null");
/*  77 */     this.attributeSource = attributeSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttributeSource(JmxAttributeSource attributeSource)
/*     */   {
/*  86 */     Assert.notNull(attributeSource, "JmxAttributeSource must not be null");
/*  87 */     this.attributeSource = attributeSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultDomain(String defaultDomain)
/*     */   {
/*  98 */     this.defaultDomain = defaultDomain;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */   {
/* 103 */     if (this.attributeSource == null) {
/* 104 */       throw new IllegalArgumentException("Property 'attributeSource' is required");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getObjectName(Object managedBean, @Nullable String beanKey)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 115 */     Assert.state(this.attributeSource != null, "No JmxAttributeSource set");
/* 116 */     Class<?> managedClass = AopUtils.getTargetClass(managedBean);
/* 117 */     ManagedResource mr = this.attributeSource.getManagedResource(managedClass);
/*     */     
/*     */ 
/* 120 */     if ((mr != null) && (StringUtils.hasText(mr.getObjectName()))) {
/* 121 */       return ObjectNameManager.getInstance(mr.getObjectName());
/*     */     }
/*     */     
/* 124 */     Assert.state(beanKey != null, "No ManagedResource attribute and no bean key specified");
/*     */     try {
/* 126 */       return ObjectNameManager.getInstance(beanKey);
/*     */     }
/*     */     catch (MalformedObjectNameException ex) {
/* 129 */       String domain = this.defaultDomain;
/* 130 */       if (domain == null) {
/* 131 */         domain = ClassUtils.getPackageName(managedClass);
/*     */       }
/* 133 */       Hashtable<String, String> properties = new Hashtable();
/* 134 */       properties.put("type", ClassUtils.getShortName(managedClass));
/* 135 */       properties.put("name", beanKey);
/* 136 */       return ObjectNameManager.getInstance(domain, properties);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\export\naming\MetadataNamingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */