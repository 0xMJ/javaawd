/*    */ package org.springframework.jmx.export.naming;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import javax.management.MalformedObjectNameException;
/*    */ import javax.management.ObjectName;
/*    */ import org.springframework.jmx.support.ObjectNameManager;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IdentityNamingStrategy
/*    */   implements ObjectNamingStrategy
/*    */ {
/*    */   public static final String TYPE_KEY = "type";
/*    */   public static final String HASH_CODE_KEY = "hashCode";
/*    */   
/*    */   public ObjectName getObjectName(Object managedBean, @Nullable String beanKey)
/*    */     throws MalformedObjectNameException
/*    */   {
/* 59 */     String domain = ClassUtils.getPackageName(managedBean.getClass());
/* 60 */     Hashtable<String, String> keys = new Hashtable();
/* 61 */     keys.put("type", ClassUtils.getShortName(managedBean.getClass()));
/* 62 */     keys.put("hashCode", ObjectUtils.getIdentityHexString(managedBean));
/* 63 */     return ObjectNameManager.getInstance(domain, keys);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\export\naming\IdentityNamingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */