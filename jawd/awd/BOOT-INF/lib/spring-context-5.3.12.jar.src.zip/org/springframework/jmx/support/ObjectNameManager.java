/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObjectNameManager
/*     */ {
/*     */   public static ObjectName getInstance(Object objectName)
/*     */     throws MalformedObjectNameException
/*     */   {
/*  48 */     if ((objectName instanceof ObjectName)) {
/*  49 */       return (ObjectName)objectName;
/*     */     }
/*  51 */     if (!(objectName instanceof String))
/*     */     {
/*  53 */       throw new MalformedObjectNameException("Invalid ObjectName value type [" + objectName.getClass().getName() + "]: only ObjectName and String supported.");
/*     */     }
/*  55 */     return getInstance((String)objectName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ObjectName getInstance(String objectName)
/*     */     throws MalformedObjectNameException
/*     */   {
/*  67 */     return ObjectName.getInstance(objectName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ObjectName getInstance(String domainName, String key, String value)
/*     */     throws MalformedObjectNameException
/*     */   {
/*  84 */     return ObjectName.getInstance(domainName, key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ObjectName getInstance(String domainName, Hashtable<String, String> properties)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 100 */     return ObjectName.getInstance(domainName, properties);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\support\ObjectNameManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */