package org.springframework.jmx.export.metadata;

import java.lang.reflect.Method;
import org.springframework.lang.Nullable;

public abstract interface JmxAttributeSource
{
  @Nullable
  public abstract ManagedResource getManagedResource(Class<?> paramClass)
    throws InvalidMetadataException;
  
  @Nullable
  public abstract ManagedAttribute getManagedAttribute(Method paramMethod)
    throws InvalidMetadataException;
  
  @Nullable
  public abstract ManagedMetric getManagedMetric(Method paramMethod)
    throws InvalidMetadataException;
  
  @Nullable
  public abstract ManagedOperation getManagedOperation(Method paramMethod)
    throws InvalidMetadataException;
  
  public abstract ManagedOperationParameter[] getManagedOperationParameters(Method paramMethod)
    throws InvalidMetadataException;
  
  public abstract ManagedNotification[] getManagedNotifications(Class<?> paramClass)
    throws InvalidMetadataException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\export\metadata\JmxAttributeSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */