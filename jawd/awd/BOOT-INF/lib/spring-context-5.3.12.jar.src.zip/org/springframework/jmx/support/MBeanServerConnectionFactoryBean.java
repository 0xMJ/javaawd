/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.remote.JMXConnector;
/*     */ import javax.management.remote.JMXConnectorFactory;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.target.AbstractLazyCreationTargetSource;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanServerConnectionFactoryBean
/*     */   implements FactoryBean<MBeanServerConnection>, BeanClassLoaderAware, InitializingBean, DisposableBean
/*     */ {
/*     */   @Nullable
/*     */   private JMXServiceURL serviceUrl;
/*     */   private Map<String, Object> environment;
/*     */   private boolean connectOnStartup;
/*     */   
/*     */   public MBeanServerConnectionFactoryBean()
/*     */   {
/*  61 */     this.environment = new HashMap();
/*     */     
/*  63 */     this.connectOnStartup = true; }
/*     */   
/*     */   @Nullable
/*  66 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private JMXConnector connector;
/*     */   
/*     */   @Nullable
/*     */   private MBeanServerConnection connection;
/*     */   
/*     */   @Nullable
/*     */   private JMXConnectorLazyInitTargetSource connectorTargetSource;
/*     */   
/*     */ 
/*     */   public void setServiceUrl(String url)
/*     */     throws MalformedURLException
/*     */   {
/*  82 */     this.serviceUrl = new JMXServiceURL(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnvironment(Properties environment)
/*     */   {
/*  90 */     CollectionUtils.mergePropertiesIntoMap(environment, this.environment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnvironmentMap(@Nullable Map<String, ?> environment)
/*     */   {
/*  98 */     if (environment != null) {
/*  99 */       this.environment.putAll(environment);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectOnStartup(boolean connectOnStartup)
/*     */   {
/* 110 */     this.connectOnStartup = connectOnStartup;
/*     */   }
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 115 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws IOException
/*     */   {
/* 125 */     if (this.serviceUrl == null) {
/* 126 */       throw new IllegalArgumentException("Property 'serviceUrl' is required");
/*     */     }
/*     */     
/* 129 */     if (this.connectOnStartup) {
/* 130 */       connect();
/*     */     }
/*     */     else {
/* 133 */       createLazyConnection();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void connect()
/*     */     throws IOException
/*     */   {
/* 142 */     Assert.state(this.serviceUrl != null, "No JMXServiceURL set");
/* 143 */     this.connector = JMXConnectorFactory.connect(this.serviceUrl, this.environment);
/* 144 */     this.connection = this.connector.getMBeanServerConnection();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void createLazyConnection()
/*     */   {
/* 151 */     this.connectorTargetSource = new JMXConnectorLazyInitTargetSource(null);
/* 152 */     TargetSource connectionTargetSource = new MBeanServerConnectionLazyInitTargetSource(null);
/*     */     
/*     */ 
/* 155 */     this.connector = ((JMXConnector)new ProxyFactory(JMXConnector.class, this.connectorTargetSource).getProxy(this.beanClassLoader));
/*     */     
/* 157 */     this.connection = ((MBeanServerConnection)new ProxyFactory(MBeanServerConnection.class, connectionTargetSource).getProxy(this.beanClassLoader));
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   public MBeanServerConnection getObject()
/*     */   {
/* 164 */     return this.connection;
/*     */   }
/*     */   
/*     */   public Class<? extends MBeanServerConnection> getObjectType()
/*     */   {
/* 169 */     return this.connection != null ? this.connection.getClass() : MBeanServerConnection.class;
/*     */   }
/*     */   
/*     */   public boolean isSingleton()
/*     */   {
/* 174 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */     throws IOException
/*     */   {
/* 183 */     if ((this.connector != null) && ((this.connectorTargetSource == null) || 
/* 184 */       (this.connectorTargetSource.isInitialized()))) {
/* 185 */       this.connector.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class JMXConnectorLazyInitTargetSource
/*     */     extends AbstractLazyCreationTargetSource
/*     */   {
/*     */     private JMXConnectorLazyInitTargetSource() {}
/*     */     
/*     */ 
/*     */     protected Object createObject()
/*     */       throws Exception
/*     */     {
/* 200 */       Assert.state(MBeanServerConnectionFactoryBean.this.serviceUrl != null, "No JMXServiceURL set");
/* 201 */       return JMXConnectorFactory.connect(MBeanServerConnectionFactoryBean.this.serviceUrl, MBeanServerConnectionFactoryBean.this.environment);
/*     */     }
/*     */     
/*     */     public Class<?> getTargetClass()
/*     */     {
/* 206 */       return JMXConnector.class;
/*     */     }
/*     */   }
/*     */   
/*     */   private class MBeanServerConnectionLazyInitTargetSource
/*     */     extends AbstractLazyCreationTargetSource
/*     */   {
/*     */     private MBeanServerConnectionLazyInitTargetSource() {}
/*     */     
/*     */     protected Object createObject()
/*     */       throws Exception
/*     */     {
/* 218 */       Assert.state(MBeanServerConnectionFactoryBean.this.connector != null, "JMXConnector not initialized");
/* 219 */       return MBeanServerConnectionFactoryBean.this.connector.getMBeanServerConnection();
/*     */     }
/*     */     
/*     */     public Class<?> getTargetClass()
/*     */     {
/* 224 */       return MBeanServerConnection.class;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\support\MBeanServerConnectionFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */