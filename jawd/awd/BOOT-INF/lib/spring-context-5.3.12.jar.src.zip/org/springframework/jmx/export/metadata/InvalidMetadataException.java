/*    */ package org.springframework.jmx.export.metadata;
/*    */ 
/*    */ import org.springframework.jmx.JmxException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidMetadataException
/*    */   extends JmxException
/*    */ {
/*    */   public InvalidMetadataException(String msg)
/*    */   {
/* 39 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\export\metadata\InvalidMetadataException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */