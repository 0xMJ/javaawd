/*     */ package org.springframework.jmx.access;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.JMException;
/*     */ import javax.management.JMX;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.MBeanServerInvocationHandler;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.OperationsException;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeErrorException;
/*     */ import javax.management.RuntimeMBeanException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import javax.management.openmbean.CompositeData;
/*     */ import javax.management.openmbean.TabularData;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.jmx.support.JmxUtils;
/*     */ import org.springframework.jmx.support.ObjectNameManager;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanClientInterceptor
/*     */   implements MethodInterceptor, BeanClassLoaderAware, InitializingBean, DisposableBean
/*     */ {
/*  98 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private MBeanServerConnection server;
/*     */   
/*     */   @Nullable
/*     */   private JMXServiceURL serviceUrl;
/*     */   
/*     */   @Nullable
/*     */   private Map<String, ?> environment;
/*     */   
/*     */   @Nullable
/*     */   private String agentId;
/*     */   
/* 112 */   private boolean connectOnStartup = true;
/*     */   
/* 114 */   private boolean refreshOnConnectFailure = false;
/*     */   
/*     */   @Nullable
/*     */   private ObjectName objectName;
/*     */   
/* 119 */   private boolean useStrictCasing = true;
/*     */   
/*     */   @Nullable
/*     */   private Class<?> managementInterface;
/*     */   
/*     */   @Nullable
/* 125 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   
/* 127 */   private final ConnectorDelegate connector = new ConnectorDelegate();
/*     */   
/*     */   @Nullable
/*     */   private MBeanServerConnection serverToUse;
/*     */   
/*     */   @Nullable
/*     */   private MBeanServerInvocationHandler invocationHandler;
/*     */   
/* 135 */   private Map<String, MBeanAttributeInfo> allowedAttributes = Collections.emptyMap();
/*     */   
/* 137 */   private Map<MethodCacheKey, MBeanOperationInfo> allowedOperations = Collections.emptyMap();
/*     */   
/* 139 */   private final Map<Method, String[]> signatureCache = new HashMap();
/*     */   
/* 141 */   private final Object preparationMonitor = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServer(MBeanServerConnection server)
/*     */   {
/* 149 */     this.server = server;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setServiceUrl(String url)
/*     */     throws MalformedURLException
/*     */   {
/* 156 */     this.serviceUrl = new JMXServiceURL(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnvironment(@Nullable Map<String, ?> environment)
/*     */   {
/* 164 */     this.environment = environment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Map<String, ?> getEnvironment()
/*     */   {
/* 176 */     return this.environment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAgentId(String agentId)
/*     */   {
/* 188 */     this.agentId = agentId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectOnStartup(boolean connectOnStartup)
/*     */   {
/* 197 */     this.connectOnStartup = connectOnStartup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRefreshOnConnectFailure(boolean refreshOnConnectFailure)
/*     */   {
/* 207 */     this.refreshOnConnectFailure = refreshOnConnectFailure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setObjectName(Object objectName)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 215 */     this.objectName = ObjectNameManager.getInstance(objectName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseStrictCasing(boolean useStrictCasing)
/*     */   {
/* 226 */     this.useStrictCasing = useStrictCasing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setManagementInterface(@Nullable Class<?> managementInterface)
/*     */   {
/* 235 */     this.managementInterface = managementInterface;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected final Class<?> getManagementInterface()
/*     */   {
/* 244 */     return this.managementInterface;
/*     */   }
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader)
/*     */   {
/* 249 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 259 */     if ((this.server != null) && (this.refreshOnConnectFailure)) {
/* 260 */       throw new IllegalArgumentException("'refreshOnConnectFailure' does not work when setting a 'server' reference. Prefer 'serviceUrl' etc instead.");
/*     */     }
/*     */     
/* 263 */     if (this.connectOnStartup) {
/* 264 */       prepare();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prepare()
/*     */   {
/* 273 */     synchronized (this.preparationMonitor) {
/* 274 */       if (this.server != null) {
/* 275 */         this.serverToUse = this.server;
/*     */       }
/*     */       else {
/* 278 */         this.serverToUse = null;
/* 279 */         this.serverToUse = this.connector.connect(this.serviceUrl, this.environment, this.agentId);
/*     */       }
/* 281 */       this.invocationHandler = null;
/* 282 */       if (this.useStrictCasing) {
/* 283 */         Assert.state(this.objectName != null, "No ObjectName set");
/*     */         
/*     */ 
/* 286 */         this.invocationHandler = new MBeanServerInvocationHandler(this.serverToUse, this.objectName, (this.managementInterface != null) && (JMX.isMXBeanInterface(this.managementInterface)));
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 291 */         retrieveMBeanInfo(this.serverToUse);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void retrieveMBeanInfo(MBeanServerConnection server)
/*     */     throws MBeanInfoRetrievalException
/*     */   {
/*     */     try
/*     */     {
/* 302 */       MBeanInfo info = server.getMBeanInfo(this.objectName);
/*     */       
/* 304 */       MBeanAttributeInfo[] attributeInfo = info.getAttributes();
/* 305 */       this.allowedAttributes = CollectionUtils.newHashMap(attributeInfo.length);
/* 306 */       MBeanAttributeInfo[] arrayOfMBeanAttributeInfo1 = attributeInfo;int i = arrayOfMBeanAttributeInfo1.length; for (MBeanAttributeInfo localMBeanAttributeInfo1 = 0; localMBeanAttributeInfo1 < i; localMBeanAttributeInfo1++) { infoEle = arrayOfMBeanAttributeInfo1[localMBeanAttributeInfo1];
/* 307 */         this.allowedAttributes.put(infoEle.getName(), infoEle);
/*     */       }
/*     */       
/* 310 */       MBeanOperationInfo[] operationInfo = info.getOperations();
/* 311 */       this.allowedOperations = CollectionUtils.newHashMap(operationInfo.length);
/* 312 */       MBeanOperationInfo[] arrayOfMBeanOperationInfo1 = operationInfo;localMBeanAttributeInfo1 = arrayOfMBeanOperationInfo1.length; for (MBeanAttributeInfo infoEle = 0; infoEle < localMBeanAttributeInfo1; infoEle++) { MBeanOperationInfo infoEle = arrayOfMBeanOperationInfo1[infoEle];
/* 313 */         Class<?>[] paramTypes = JmxUtils.parameterInfoToTypes(infoEle.getSignature(), this.beanClassLoader);
/* 314 */         this.allowedOperations.put(new MethodCacheKey(infoEle.getName(), paramTypes), infoEle);
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 318 */       throw new MBeanInfoRetrievalException("Unable to locate class specified in method signature", ex);
/*     */     }
/*     */     catch (IntrospectionException ex) {
/* 321 */       throw new MBeanInfoRetrievalException("Unable to obtain MBean info for bean [" + this.objectName + "]", ex);
/*     */     }
/*     */     catch (InstanceNotFoundException ex)
/*     */     {
/* 325 */       throw new MBeanInfoRetrievalException("Unable to obtain MBean info for bean [" + this.objectName + "]: it is likely that this bean was unregistered during the proxy creation process", ex);
/*     */ 
/*     */     }
/*     */     catch (ReflectionException ex)
/*     */     {
/* 330 */       throw new MBeanInfoRetrievalException("Unable to read MBean info for bean [ " + this.objectName + "]", ex);
/*     */     }
/*     */     catch (IOException ex) {
/* 333 */       throw new MBeanInfoRetrievalException("An IOException occurred when communicating with the MBeanServer. It is likely that you are communicating with a remote MBeanServer. Check the inner exception for exact details.", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isPrepared()
/*     */   {
/* 344 */     synchronized (this.preparationMonitor) {
/* 345 */       return this.serverToUse != null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 362 */     synchronized (this.preparationMonitor) {
/* 363 */       if (!isPrepared()) {
/* 364 */         prepare();
/*     */       }
/*     */     }
/*     */     try {
/* 368 */       return doInvoke(invocation);
/*     */     }
/*     */     catch (MBeanConnectFailureException|IOException ex) {
/* 371 */       return handleConnectFailure(invocation, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object handleConnectFailure(MethodInvocation invocation, Exception ex)
/*     */     throws Throwable
/*     */   {
/* 389 */     if (this.refreshOnConnectFailure) {
/* 390 */       String msg = "Could not connect to JMX server - retrying";
/* 391 */       if (this.logger.isDebugEnabled()) {
/* 392 */         this.logger.warn(msg, ex);
/*     */       }
/* 394 */       else if (this.logger.isWarnEnabled()) {
/* 395 */         this.logger.warn(msg);
/*     */       }
/* 397 */       prepare();
/* 398 */       return doInvoke(invocation);
/*     */     }
/*     */     
/* 401 */     throw ex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object doInvoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 415 */     Method method = invocation.getMethod();
/*     */     try { Object result;
/*     */       Object result;
/* 418 */       if (this.invocationHandler != null) {
/* 419 */         result = this.invocationHandler.invoke(invocation.getThis(), method, invocation.getArguments());
/*     */       }
/*     */       else {
/* 422 */         PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 423 */         Object result; if (pd != null) {
/* 424 */           result = invokeAttribute(pd, invocation);
/*     */         }
/*     */         else {
/* 427 */           result = invokeOperation(method, invocation.getArguments());
/*     */         }
/*     */       }
/* 430 */       return convertResultValueIfNecessary(result, new MethodParameter(method, -1));
/*     */     }
/*     */     catch (MBeanException ex) {
/* 433 */       throw ex.getTargetException();
/*     */     }
/*     */     catch (RuntimeMBeanException ex) {
/* 436 */       throw ex.getTargetException();
/*     */     }
/*     */     catch (RuntimeErrorException ex) {
/* 439 */       throw ex.getTargetError();
/*     */     }
/*     */     catch (RuntimeOperationsException ex)
/*     */     {
/* 443 */       RuntimeException rex = ex.getTargetException();
/* 444 */       if ((rex instanceof RuntimeMBeanException)) {
/* 445 */         throw ((RuntimeMBeanException)rex).getTargetException();
/*     */       }
/* 447 */       if ((rex instanceof RuntimeErrorException)) {
/* 448 */         throw ((RuntimeErrorException)rex).getTargetError();
/*     */       }
/*     */       
/* 451 */       throw rex;
/*     */     }
/*     */     catch (OperationsException ex)
/*     */     {
/* 455 */       if (ReflectionUtils.declaresException(method, ex.getClass())) {
/* 456 */         throw ex;
/*     */       }
/*     */       
/* 459 */       throw new InvalidInvocationException(ex.getMessage());
/*     */     }
/*     */     catch (JMException ex)
/*     */     {
/* 463 */       if (ReflectionUtils.declaresException(method, ex.getClass())) {
/* 464 */         throw ex;
/*     */       }
/*     */       
/* 467 */       throw new InvocationFailureException("JMX access failed", ex);
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 471 */       if (ReflectionUtils.declaresException(method, ex.getClass())) {
/* 472 */         throw ex;
/*     */       }
/*     */       
/* 475 */       throw new MBeanConnectFailureException("I/O failure during JMX access", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private Object invokeAttribute(PropertyDescriptor pd, MethodInvocation invocation)
/*     */     throws JMException, IOException
/*     */   {
/* 484 */     Assert.state(this.serverToUse != null, "No MBeanServerConnection available");
/*     */     
/* 486 */     String attributeName = JmxUtils.getAttributeName(pd, this.useStrictCasing);
/* 487 */     MBeanAttributeInfo inf = (MBeanAttributeInfo)this.allowedAttributes.get(attributeName);
/*     */     
/*     */ 
/* 490 */     if (inf == null)
/*     */     {
/* 492 */       throw new InvalidInvocationException("Attribute '" + pd.getName() + "' is not exposed on the management interface");
/*     */     }
/*     */     
/* 495 */     if (invocation.getMethod().equals(pd.getReadMethod())) {
/* 496 */       if (inf.isReadable()) {
/* 497 */         return this.serverToUse.getAttribute(this.objectName, attributeName);
/*     */       }
/*     */       
/* 500 */       throw new InvalidInvocationException("Attribute '" + attributeName + "' is not readable");
/*     */     }
/*     */     
/* 503 */     if (invocation.getMethod().equals(pd.getWriteMethod())) {
/* 504 */       if (inf.isWritable()) {
/* 505 */         this.serverToUse.setAttribute(this.objectName, new Attribute(attributeName, invocation.getArguments()[0]));
/* 506 */         return null;
/*     */       }
/*     */       
/* 509 */       throw new InvalidInvocationException("Attribute '" + attributeName + "' is not writable");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 514 */     throw new IllegalStateException("Method [" + invocation.getMethod() + "] is neither a bean property getter nor a setter");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object invokeOperation(Method method, Object[] args)
/*     */     throws JMException, IOException
/*     */   {
/* 526 */     Assert.state(this.serverToUse != null, "No MBeanServerConnection available");
/*     */     
/* 528 */     MethodCacheKey key = new MethodCacheKey(method.getName(), method.getParameterTypes());
/* 529 */     MBeanOperationInfo info = (MBeanOperationInfo)this.allowedOperations.get(key);
/* 530 */     if (info == null) {
/* 531 */       throw new InvalidInvocationException("Operation '" + method.getName() + "' is not exposed on the management interface");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 536 */     synchronized (this.signatureCache) {
/* 537 */       String[] signature = (String[])this.signatureCache.get(method);
/* 538 */       if (signature == null) {
/* 539 */         signature = JmxUtils.getMethodSignature(method);
/* 540 */         this.signatureCache.put(method, signature);
/*     */       }
/*     */     }
/*     */     String[] signature;
/* 544 */     return this.serverToUse.invoke(this.objectName, method.getName(), args, signature);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object convertResultValueIfNecessary(@Nullable Object result, MethodParameter parameter)
/*     */   {
/* 557 */     Class<?> targetClass = parameter.getParameterType();
/*     */     try {
/* 559 */       if (result == null) {
/* 560 */         return null;
/*     */       }
/* 562 */       if (ClassUtils.isAssignableValue(targetClass, result)) {
/* 563 */         return result;
/*     */       }
/* 565 */       if ((result instanceof CompositeData)) {
/* 566 */         Method fromMethod = targetClass.getMethod("from", new Class[] { CompositeData.class });
/* 567 */         return ReflectionUtils.invokeMethod(fromMethod, null, new Object[] { result });
/*     */       }
/* 569 */       if ((result instanceof CompositeData[])) {
/* 570 */         CompositeData[] array = (CompositeData[])result;
/* 571 */         if (targetClass.isArray()) {
/* 572 */           return convertDataArrayToTargetArray(array, targetClass);
/*     */         }
/* 574 */         if (Collection.class.isAssignableFrom(targetClass))
/*     */         {
/* 576 */           Class<?> elementType = ResolvableType.forMethodParameter(parameter).asCollection().resolveGeneric(new int[0]);
/* 577 */           if (elementType != null) {
/* 578 */             return convertDataArrayToTargetCollection(array, targetClass, elementType);
/*     */           }
/*     */         }
/*     */       } else {
/* 582 */         if ((result instanceof TabularData)) {
/* 583 */           Method fromMethod = targetClass.getMethod("from", new Class[] { TabularData.class });
/* 584 */           return ReflectionUtils.invokeMethod(fromMethod, null, new Object[] { result });
/*     */         }
/* 586 */         if ((result instanceof TabularData[])) {
/* 587 */           TabularData[] array = (TabularData[])result;
/* 588 */           if (targetClass.isArray()) {
/* 589 */             return convertDataArrayToTargetArray(array, targetClass);
/*     */           }
/* 591 */           if (Collection.class.isAssignableFrom(targetClass))
/*     */           {
/* 593 */             Class<?> elementType = ResolvableType.forMethodParameter(parameter).asCollection().resolveGeneric(new int[0]);
/* 594 */             if (elementType != null) {
/* 595 */               return convertDataArrayToTargetCollection(array, targetClass, elementType);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 600 */       throw new InvocationFailureException("Incompatible result value [" + result + "] for target type [" + targetClass.getName() + "]");
/*     */ 
/*     */     }
/*     */     catch (NoSuchMethodException ex)
/*     */     {
/* 605 */       throw new InvocationFailureException("Could not obtain 'from(CompositeData)' / 'from(TabularData)' method on target type [" + targetClass.getName() + "] for conversion of MXBean data structure [" + result + "]");
/*     */     }
/*     */   }
/*     */   
/*     */   private Object convertDataArrayToTargetArray(Object[] array, Class<?> targetClass) throws NoSuchMethodException {
/* 610 */     Class<?> targetType = targetClass.getComponentType();
/* 611 */     Method fromMethod = targetType.getMethod("from", new Class[] { array.getClass().getComponentType() });
/* 612 */     Object resultArray = Array.newInstance(targetType, array.length);
/* 613 */     for (int i = 0; i < array.length; i++) {
/* 614 */       Array.set(resultArray, i, ReflectionUtils.invokeMethod(fromMethod, null, new Object[] { array[i] }));
/*     */     }
/* 616 */     return resultArray;
/*     */   }
/*     */   
/*     */   private Collection<?> convertDataArrayToTargetCollection(Object[] array, Class<?> collectionType, Class<?> elementType)
/*     */     throws NoSuchMethodException
/*     */   {
/* 622 */     Method fromMethod = elementType.getMethod("from", new Class[] { array.getClass().getComponentType() });
/* 623 */     Collection<Object> resultColl = CollectionFactory.createCollection(collectionType, Array.getLength(array));
/* 624 */     for (int i = 0; i < array.length; i++) {
/* 625 */       resultColl.add(ReflectionUtils.invokeMethod(fromMethod, null, new Object[] { array[i] }));
/*     */     }
/* 627 */     return resultColl;
/*     */   }
/*     */   
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 633 */     this.connector.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class MethodCacheKey
/*     */     implements Comparable<MethodCacheKey>
/*     */   {
/*     */     private final String name;
/*     */     
/*     */ 
/*     */ 
/*     */     private final Class<?>[] parameterTypes;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public MethodCacheKey(String name, @Nullable Class<?>[] parameterTypes)
/*     */     {
/* 654 */       this.name = name;
/* 655 */       this.parameterTypes = (parameterTypes != null ? parameterTypes : new Class[0]);
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other)
/*     */     {
/* 660 */       if (this == other) {
/* 661 */         return true;
/*     */       }
/* 663 */       if (!(other instanceof MethodCacheKey)) {
/* 664 */         return false;
/*     */       }
/* 666 */       MethodCacheKey otherKey = (MethodCacheKey)other;
/* 667 */       return (this.name.equals(otherKey.name)) && (Arrays.equals(this.parameterTypes, otherKey.parameterTypes));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 672 */       return this.name.hashCode();
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 677 */       return this.name + "(" + StringUtils.arrayToCommaDelimitedString(this.parameterTypes) + ")";
/*     */     }
/*     */     
/*     */     public int compareTo(MethodCacheKey other)
/*     */     {
/* 682 */       int result = this.name.compareTo(other.name);
/* 683 */       if (result != 0) {
/* 684 */         return result;
/*     */       }
/* 686 */       if (this.parameterTypes.length < other.parameterTypes.length) {
/* 687 */         return -1;
/*     */       }
/* 689 */       if (this.parameterTypes.length > other.parameterTypes.length) {
/* 690 */         return 1;
/*     */       }
/* 692 */       for (int i = 0; i < this.parameterTypes.length; i++) {
/* 693 */         result = this.parameterTypes[i].getName().compareTo(other.parameterTypes[i].getName());
/* 694 */         if (result != 0) {
/* 695 */           return result;
/*     */         }
/*     */       }
/* 698 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\access\MBeanClientInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */