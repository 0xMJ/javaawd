/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.management.MBeanServer;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jmx.MBeanServerNotFoundException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebSphereMBeanServerFactoryBean
/*     */   implements FactoryBean<MBeanServer>, InitializingBean
/*     */ {
/*     */   private static final String ADMIN_SERVICE_FACTORY_CLASS = "com.ibm.websphere.management.AdminServiceFactory";
/*     */   private static final String GET_MBEAN_FACTORY_METHOD = "getMBeanFactory";
/*     */   private static final String GET_MBEAN_SERVER_METHOD = "getMBeanServer";
/*     */   @Nullable
/*     */   private MBeanServer mbeanServer;
/*     */   
/*     */   public void afterPropertiesSet()
/*     */     throws MBeanServerNotFoundException
/*     */   {
/*     */     try
/*     */     {
/*  69 */       Class<?> adminServiceClass = getClass().getClassLoader().loadClass("com.ibm.websphere.management.AdminServiceFactory");
/*  70 */       Method getMBeanFactoryMethod = adminServiceClass.getMethod("getMBeanFactory", new Class[0]);
/*  71 */       Object mbeanFactory = getMBeanFactoryMethod.invoke(null, new Object[0]);
/*  72 */       Method getMBeanServerMethod = mbeanFactory.getClass().getMethod("getMBeanServer", new Class[0]);
/*  73 */       this.mbeanServer = ((MBeanServer)getMBeanServerMethod.invoke(mbeanFactory, new Object[0]));
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  76 */       throw new MBeanServerNotFoundException("Could not find WebSphere's AdminServiceFactory class", ex);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/*  80 */       throw new MBeanServerNotFoundException("WebSphere's AdminServiceFactory.getMBeanFactory/getMBeanServer method failed", ex.getTargetException());
/*     */     }
/*     */     catch (Exception ex) {
/*  83 */       throw new MBeanServerNotFoundException("Could not access WebSphere's AdminServiceFactory.getMBeanFactory/getMBeanServer method", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public MBeanServer getObject()
/*     */   {
/*  92 */     return this.mbeanServer;
/*     */   }
/*     */   
/*     */   public Class<? extends MBeanServer> getObjectType()
/*     */   {
/*  97 */     return this.mbeanServer != null ? this.mbeanServer.getClass() : MBeanServer.class;
/*     */   }
/*     */   
/*     */   public boolean isSingleton()
/*     */   {
/* 102 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\support\WebSphereMBeanServerFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */