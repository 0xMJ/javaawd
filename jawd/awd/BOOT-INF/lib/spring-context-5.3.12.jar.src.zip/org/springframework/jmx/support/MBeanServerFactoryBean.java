/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jmx.MBeanServerNotFoundException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanServerFactoryBean
/*     */   implements FactoryBean<MBeanServer>, InitializingBean, DisposableBean
/*     */ {
/*  58 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  60 */   private boolean locateExistingServerIfPossible = false;
/*     */   
/*     */   @Nullable
/*     */   private String agentId;
/*     */   
/*     */   @Nullable
/*     */   private String defaultDomain;
/*     */   
/*  68 */   private boolean registerWithFactory = true;
/*     */   
/*     */   @Nullable
/*     */   private MBeanServer server;
/*     */   
/*  73 */   private boolean newlyRegistered = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocateExistingServerIfPossible(boolean locateExistingServerIfPossible)
/*     */   {
/*  82 */     this.locateExistingServerIfPossible = locateExistingServerIfPossible;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAgentId(String agentId)
/*     */   {
/*  96 */     this.agentId = agentId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultDomain(String defaultDomain)
/*     */   {
/* 108 */     this.defaultDomain = defaultDomain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRegisterWithFactory(boolean registerWithFactory)
/*     */   {
/* 120 */     this.registerWithFactory = registerWithFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws MBeanServerNotFoundException
/*     */   {
/* 130 */     if ((this.locateExistingServerIfPossible) || (this.agentId != null)) {
/*     */       try {
/* 132 */         this.server = locateMBeanServer(this.agentId);
/*     */ 
/*     */       }
/*     */       catch (MBeanServerNotFoundException ex)
/*     */       {
/* 137 */         if (this.agentId != null) {
/* 138 */           throw ex;
/*     */         }
/* 140 */         this.logger.debug("No existing MBeanServer found - creating new one");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 145 */     if (this.server == null) {
/* 146 */       this.server = createMBeanServer(this.defaultDomain, this.registerWithFactory);
/* 147 */       this.newlyRegistered = this.registerWithFactory;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanServer locateMBeanServer(@Nullable String agentId)
/*     */     throws MBeanServerNotFoundException
/*     */   {
/* 167 */     return JmxUtils.locateMBeanServer(agentId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MBeanServer createMBeanServer(@Nullable String defaultDomain, boolean registerWithFactory)
/*     */   {
/* 180 */     if (registerWithFactory) {
/* 181 */       return MBeanServerFactory.createMBeanServer(defaultDomain);
/*     */     }
/*     */     
/* 184 */     return MBeanServerFactory.newMBeanServer(defaultDomain);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public MBeanServer getObject()
/*     */   {
/* 192 */     return this.server;
/*     */   }
/*     */   
/*     */   public Class<? extends MBeanServer> getObjectType()
/*     */   {
/* 197 */     return this.server != null ? this.server.getClass() : MBeanServer.class;
/*     */   }
/*     */   
/*     */   public boolean isSingleton()
/*     */   {
/* 202 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 211 */     if (this.newlyRegistered) {
/* 212 */       MBeanServerFactory.releaseMBeanServer(this.server);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\support\MBeanServerFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */