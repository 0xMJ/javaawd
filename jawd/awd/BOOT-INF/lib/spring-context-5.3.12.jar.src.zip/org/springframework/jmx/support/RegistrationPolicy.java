package org.springframework.jmx.support;

public enum RegistrationPolicy
{
  FAIL_ON_EXISTING,  IGNORE_EXISTING,  REPLACE_EXISTING;
  
  private RegistrationPolicy() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\support\RegistrationPolicy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */