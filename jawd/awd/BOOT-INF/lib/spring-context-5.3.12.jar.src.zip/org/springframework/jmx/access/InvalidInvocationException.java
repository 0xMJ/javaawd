/*    */ package org.springframework.jmx.access;
/*    */ 
/*    */ import javax.management.JMRuntimeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidInvocationException
/*    */   extends JMRuntimeException
/*    */ {
/*    */   public InvalidInvocationException(String msg)
/*    */   {
/* 39 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\jmx\access\InvalidInvocationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */