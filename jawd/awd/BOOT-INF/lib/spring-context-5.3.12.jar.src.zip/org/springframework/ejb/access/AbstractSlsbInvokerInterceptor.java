/*     */ package org.springframework.ejb.access;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.jndi.JndiObjectLocator;
/*     */ import org.springframework.jndi.JndiTemplate;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSlsbInvokerInterceptor
/*     */   extends JndiObjectLocator
/*     */   implements MethodInterceptor
/*     */ {
/*  45 */   private boolean lookupHomeOnStartup = true;
/*     */   
/*  47 */   private boolean cacheHome = true;
/*     */   
/*  49 */   private boolean exposeAccessContext = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Object cachedHome;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Method createMethod;
/*     */   
/*     */ 
/*     */ 
/*  64 */   private final Object homeMonitor = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLookupHomeOnStartup(boolean lookupHomeOnStartup)
/*     */   {
/*  75 */     this.lookupHomeOnStartup = lookupHomeOnStartup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheHome(boolean cacheHome)
/*     */   {
/*  86 */     this.cacheHome = cacheHome;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExposeAccessContext(boolean exposeAccessContext)
/*     */   {
/*  98 */     this.exposeAccessContext = exposeAccessContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws NamingException
/*     */   {
/* 109 */     super.afterPropertiesSet();
/* 110 */     if (this.lookupHomeOnStartup)
/*     */     {
/* 112 */       refreshHome();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void refreshHome()
/*     */     throws NamingException
/*     */   {
/* 124 */     synchronized (this.homeMonitor) {
/* 125 */       Object home = lookup();
/* 126 */       if (this.cacheHome) {
/* 127 */         this.cachedHome = home;
/* 128 */         this.createMethod = getCreateMethod(home);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Method getCreateMethod(Object home)
/*     */     throws EjbAccessException
/*     */   {
/*     */     try
/*     */     {
/* 143 */       return home.getClass().getMethod("create", new Class[0]);
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/* 146 */       throw new EjbAccessException("EJB home [" + home + "] has no no-arg create() method");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getHome()
/*     */     throws NamingException
/*     */   {
/* 163 */     if ((!this.cacheHome) || ((this.lookupHomeOnStartup) && (!isHomeRefreshable()))) {
/* 164 */       return this.cachedHome != null ? this.cachedHome : lookup();
/*     */     }
/*     */     
/* 167 */     synchronized (this.homeMonitor) {
/* 168 */       if (this.cachedHome == null) {
/* 169 */         this.cachedHome = lookup();
/* 170 */         this.createMethod = getCreateMethod(this.cachedHome);
/*     */       }
/* 172 */       return this.cachedHome;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isHomeRefreshable()
/*     */   {
/* 182 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 193 */     Context ctx = this.exposeAccessContext ? getJndiTemplate().getContext() : null;
/*     */     try {
/* 195 */       return invokeInContext(invocation);
/*     */     }
/*     */     finally {
/* 198 */       getJndiTemplate().releaseContext(ctx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected abstract Object invokeInContext(MethodInvocation paramMethodInvocation)
/*     */     throws Throwable;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object create()
/*     */     throws NamingException, InvocationTargetException
/*     */   {
/*     */     try
/*     */     {
/* 222 */       Object home = getHome();
/* 223 */       Method createMethodToUse = this.createMethod;
/* 224 */       if (createMethodToUse == null) {
/* 225 */         createMethodToUse = getCreateMethod(home);
/*     */       }
/* 227 */       if (createMethodToUse == null) {
/* 228 */         return home;
/*     */       }
/*     */       
/* 231 */       return createMethodToUse.invoke(home, (Object[])null);
/*     */     }
/*     */     catch (IllegalAccessException ex) {
/* 234 */       throw new EjbAccessException("Could not access EJB home create() method", ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\ejb\access\AbstractSlsbInvokerInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */