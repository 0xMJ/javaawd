/*    */ package org.springframework.ejb.config;
/*    */ 
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.xml.AbstractSimpleBeanDefinitionParser;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.util.xml.DomUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractJndiLocatingBeanDefinitionParser
/*    */   extends AbstractSimpleBeanDefinitionParser
/*    */ {
/*    */   public static final String ENVIRONMENT = "environment";
/*    */   public static final String ENVIRONMENT_REF = "environment-ref";
/*    */   public static final String JNDI_ENVIRONMENT = "jndiEnvironment";
/*    */   
/*    */   protected boolean isEligibleAttribute(String attributeName)
/*    */   {
/* 52 */     return (super.isEligibleAttribute(attributeName)) && 
/* 53 */       (!"environment-ref".equals(attributeName)) && 
/* 54 */       (!"lazy-init".equals(attributeName));
/*    */   }
/*    */   
/*    */   protected void postProcess(BeanDefinitionBuilder definitionBuilder, Element element)
/*    */   {
/* 59 */     Object envValue = DomUtils.getChildElementValueByTagName(element, "environment");
/* 60 */     if (envValue != null)
/*    */     {
/* 62 */       definitionBuilder.addPropertyValue("jndiEnvironment", envValue);
/*    */     }
/*    */     else
/*    */     {
/* 66 */       String envRef = element.getAttribute("environment-ref");
/* 67 */       if (StringUtils.hasLength(envRef)) {
/* 68 */         definitionBuilder.addPropertyValue("jndiEnvironment", new RuntimeBeanReference(envRef));
/*    */       }
/*    */     }
/*    */     
/* 72 */     String lazyInit = element.getAttribute("lazy-init");
/* 73 */     if ((StringUtils.hasText(lazyInit)) && (!"default".equals(lazyInit))) {
/* 74 */       definitionBuilder.setLazyInit("true".equals(lazyInit));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\ejb\config\AbstractJndiLocatingBeanDefinitionParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */