/*     */ package org.springframework.ejb.access;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.ejb.CreateException;
/*     */ import javax.ejb.EJBLocalHome;
/*     */ import javax.ejb.EJBLocalObject;
/*     */ import javax.naming.NamingException;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalSlsbInvokerInterceptor
/*     */   extends AbstractSlsbInvokerInterceptor
/*     */ {
/*     */   private volatile boolean homeAsComponent;
/*     */   
/*     */   @Nullable
/*     */   public Object invokeInContext(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*  68 */     Object ejb = null;
/*     */     try {
/*  70 */       ejb = getSessionBeanInstance();
/*  71 */       Method method = invocation.getMethod();
/*  72 */       if (method.getDeclaringClass().isInstance(ejb))
/*     */       {
/*  74 */         return method.invoke(ejb, invocation.getArguments());
/*     */       }
/*     */       
/*     */ 
/*  78 */       Method ejbMethod = ejb.getClass().getMethod(method.getName(), method.getParameterTypes());
/*  79 */       return ejbMethod.invoke(ejb, invocation.getArguments());
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/*  83 */       Throwable targetEx = ex.getTargetException();
/*  84 */       if (this.logger.isDebugEnabled()) {
/*  85 */         this.logger.debug("Method of local EJB [" + getJndiName() + "] threw exception", targetEx);
/*     */       }
/*  87 */       if ((targetEx instanceof CreateException)) {
/*  88 */         throw new EjbAccessException("Could not create local EJB [" + getJndiName() + "]", targetEx);
/*     */       }
/*     */       
/*  91 */       throw targetEx;
/*     */     }
/*     */     catch (NamingException ex)
/*     */     {
/*  95 */       throw new EjbAccessException("Failed to locate local EJB [" + getJndiName() + "]", ex);
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/*  99 */       throw new EjbAccessException("Could not access method [" + invocation.getMethod().getName() + "] of local EJB [" + getJndiName() + "]", ex);
/*     */     }
/*     */     finally {
/* 102 */       if ((ejb instanceof EJBLocalObject)) {
/* 103 */         releaseSessionBeanInstance((EJBLocalObject)ejb);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Method getCreateMethod(Object home)
/*     */     throws EjbAccessException
/*     */   {
/* 113 */     if (this.homeAsComponent) {
/* 114 */       return null;
/*     */     }
/* 116 */     if (!(home instanceof EJBLocalHome))
/*     */     {
/* 118 */       this.homeAsComponent = true;
/* 119 */       return null;
/*     */     }
/* 121 */     return super.getCreateMethod(home);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getSessionBeanInstance()
/*     */     throws NamingException, InvocationTargetException
/*     */   {
/* 132 */     return newSessionBeanInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void releaseSessionBeanInstance(EJBLocalObject ejb)
/*     */   {
/* 142 */     removeSessionBeanInstance(ejb);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object newSessionBeanInstance()
/*     */     throws NamingException, InvocationTargetException
/*     */   {
/* 153 */     if (this.logger.isDebugEnabled()) {
/* 154 */       this.logger.debug("Trying to create reference to local EJB");
/*     */     }
/* 156 */     Object ejbInstance = create();
/* 157 */     if (this.logger.isDebugEnabled()) {
/* 158 */       this.logger.debug("Obtained reference to local EJB: " + ejbInstance);
/*     */     }
/* 160 */     return ejbInstance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void removeSessionBeanInstance(@Nullable EJBLocalObject ejb)
/*     */   {
/* 169 */     if ((ejb != null) && (!this.homeAsComponent)) {
/*     */       try {
/* 171 */         ejb.remove();
/*     */       }
/*     */       catch (Throwable ex) {
/* 174 */         this.logger.warn("Could not invoke 'remove' on local EJB proxy", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\ejb\access\LocalSlsbInvokerInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */