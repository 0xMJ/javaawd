/*     */ package org.springframework.ejb.access;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.ejb.EJBHome;
/*     */ import javax.ejb.EJBObject;
/*     */ import javax.naming.NamingException;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.rmi.RmiClientInterceptorUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRemoteSlsbInvokerInterceptor
/*     */   extends AbstractSlsbInvokerInterceptor
/*     */ {
/*  45 */   private boolean refreshHomeOnConnectFailure = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private volatile boolean homeAsComponent;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRefreshHomeOnConnectFailure(boolean refreshHomeOnConnectFailure)
/*     */   {
/*  63 */     this.refreshHomeOnConnectFailure = refreshHomeOnConnectFailure;
/*     */   }
/*     */   
/*     */   protected boolean isHomeRefreshable()
/*     */   {
/*  68 */     return this.refreshHomeOnConnectFailure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Method getCreateMethod(Object home)
/*     */     throws EjbAccessException
/*     */   {
/*  77 */     if (this.homeAsComponent) {
/*  78 */       return null;
/*     */     }
/*  80 */     if (!(home instanceof EJBHome))
/*     */     {
/*  82 */       this.homeAsComponent = true;
/*  83 */       return null;
/*     */     }
/*  85 */     return super.getCreateMethod(home);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object invokeInContext(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 101 */       return doInvoke(invocation);
/*     */     }
/*     */     catch (RemoteConnectFailureException ex) {
/* 104 */       return handleRemoteConnectFailure(invocation, ex);
/*     */     }
/*     */     catch (RemoteException ex) {
/* 107 */       if (isConnectFailure(ex)) {
/* 108 */         return handleRemoteConnectFailure(invocation, ex);
/*     */       }
/*     */       
/* 111 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isConnectFailure(RemoteException ex)
/*     */   {
/* 125 */     return RmiClientInterceptorUtils.isConnectFailure(ex);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object handleRemoteConnectFailure(MethodInvocation invocation, Exception ex) throws Throwable {
/* 130 */     if (this.refreshHomeOnConnectFailure) {
/* 131 */       if (this.logger.isDebugEnabled()) {
/* 132 */         this.logger.debug("Could not connect to remote EJB [" + getJndiName() + "] - retrying", ex);
/*     */       }
/* 134 */       else if (this.logger.isWarnEnabled()) {
/* 135 */         this.logger.warn("Could not connect to remote EJB [" + getJndiName() + "] - retrying");
/*     */       }
/* 137 */       return refreshAndRetry(invocation);
/*     */     }
/*     */     
/* 140 */     throw ex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object refreshAndRetry(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 155 */       refreshHome();
/*     */     }
/*     */     catch (NamingException ex) {
/* 158 */       throw new RemoteLookupFailureException("Failed to locate remote EJB [" + getJndiName() + "]", ex);
/*     */     }
/* 160 */     return doInvoke(invocation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected abstract Object doInvoke(MethodInvocation paramMethodInvocation)
/*     */     throws Throwable;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object newSessionBeanInstance()
/*     */     throws NamingException, InvocationTargetException
/*     */   {
/* 186 */     if (this.logger.isDebugEnabled()) {
/* 187 */       this.logger.debug("Trying to create reference to remote EJB");
/*     */     }
/* 189 */     Object ejbInstance = create();
/* 190 */     if (this.logger.isDebugEnabled()) {
/* 191 */       this.logger.debug("Obtained reference to remote EJB: " + ejbInstance);
/*     */     }
/* 193 */     return ejbInstance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void removeSessionBeanInstance(@Nullable EJBObject ejb)
/*     */   {
/* 203 */     if ((ejb != null) && (!this.homeAsComponent)) {
/*     */       try {
/* 205 */         ejb.remove();
/*     */       }
/*     */       catch (Throwable ex) {
/* 208 */         this.logger.warn("Could not invoke 'remove' on remote EJB proxy", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\ejb\access\AbstractRemoteSlsbInvokerInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */