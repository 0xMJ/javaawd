/*     */ package org.springframework.ejb.access;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.ejb.CreateException;
/*     */ import javax.ejb.EJBObject;
/*     */ import javax.naming.NamingException;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.rmi.RmiClientInterceptorUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleRemoteSlsbInvokerInterceptor
/*     */   extends AbstractRemoteSlsbInvokerInterceptor
/*     */   implements DisposableBean
/*     */ {
/*  68 */   private boolean cacheSessionBean = false;
/*     */   
/*     */   @Nullable
/*     */   private Object beanInstance;
/*     */   
/*  73 */   private final Object beanInstanceMonitor = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheSessionBean(boolean cacheSessionBean)
/*     */   {
/*  84 */     this.cacheSessionBean = cacheSessionBean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object doInvoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*  99 */     Object ejb = null;
/*     */     try {
/* 101 */       ejb = getSessionBeanInstance();
/* 102 */       return RmiClientInterceptorUtils.invokeRemoteMethod(invocation, ejb);
/*     */     }
/*     */     catch (NamingException ex) {
/* 105 */       throw new RemoteLookupFailureException("Failed to locate remote EJB [" + getJndiName() + "]", ex);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 108 */       Throwable targetEx = ex.getTargetException();
/* 109 */       if ((targetEx instanceof RemoteException)) {
/* 110 */         RemoteException rex = (RemoteException)targetEx;
/* 111 */         throw RmiClientInterceptorUtils.convertRmiAccessException(invocation
/* 112 */           .getMethod(), rex, isConnectFailure(rex), getJndiName());
/*     */       }
/* 114 */       if ((targetEx instanceof CreateException)) {
/* 115 */         throw RmiClientInterceptorUtils.convertRmiAccessException(invocation
/* 116 */           .getMethod(), targetEx, "Could not create remote EJB [" + getJndiName() + "]");
/*     */       }
/* 118 */       throw targetEx;
/*     */     }
/*     */     finally {
/* 121 */       if ((ejb instanceof EJBObject)) {
/* 122 */         releaseSessionBeanInstance((EJBObject)ejb);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getSessionBeanInstance()
/*     */     throws NamingException, InvocationTargetException
/*     */   {
/* 136 */     if (this.cacheSessionBean) {
/* 137 */       synchronized (this.beanInstanceMonitor) {
/* 138 */         if (this.beanInstance == null) {
/* 139 */           this.beanInstance = newSessionBeanInstance();
/*     */         }
/* 141 */         return this.beanInstance;
/*     */       }
/*     */     }
/*     */     
/* 145 */     return newSessionBeanInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void releaseSessionBeanInstance(EJBObject ejb)
/*     */   {
/* 156 */     if (!this.cacheSessionBean) {
/* 157 */       removeSessionBeanInstance(ejb);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void refreshHome()
/*     */     throws NamingException
/*     */   {
/* 166 */     super.refreshHome();
/* 167 */     if (this.cacheSessionBean) {
/* 168 */       synchronized (this.beanInstanceMonitor) {
/* 169 */         this.beanInstance = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 179 */     if (this.cacheSessionBean) {
/* 180 */       synchronized (this.beanInstanceMonitor) {
/* 181 */         if ((this.beanInstance instanceof EJBObject)) {
/* 182 */           removeSessionBeanInstance((EJBObject)this.beanInstance);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\ejb\access\SimpleRemoteSlsbInvokerInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */