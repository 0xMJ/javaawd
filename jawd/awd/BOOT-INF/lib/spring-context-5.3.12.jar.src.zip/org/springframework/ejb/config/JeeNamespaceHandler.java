/*    */ package org.springframework.ejb.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JeeNamespaceHandler
/*    */   extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init()
/*    */   {
/* 32 */     registerBeanDefinitionParser("jndi-lookup", new JndiLookupBeanDefinitionParser());
/* 33 */     registerBeanDefinitionParser("local-slsb", new LocalStatelessSessionBeanDefinitionParser());
/* 34 */     registerBeanDefinitionParser("remote-slsb", new RemoteStatelessSessionBeanDefinitionParser());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\ejb\config\JeeNamespaceHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */