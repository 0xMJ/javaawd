/*     */ package org.springframework.instrument.classloading;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.instrument.IllegalClassFormatException;
/*     */ import java.lang.instrument.Instrumentation;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.instrument.InstrumentationSavingAgent;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstrumentationLoadTimeWeaver
/*     */   implements LoadTimeWeaver
/*     */ {
/*  54 */   private static final boolean AGENT_CLASS_PRESENT = ClassUtils.isPresent("org.springframework.instrument.InstrumentationSavingAgent", InstrumentationLoadTimeWeaver.class
/*     */   
/*  56 */     .getClassLoader());
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private final ClassLoader classLoader;
/*     */   
/*     */   @Nullable
/*     */   private final Instrumentation instrumentation;
/*     */   
/*  65 */   private final List<ClassFileTransformer> transformers = new ArrayList(4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InstrumentationLoadTimeWeaver()
/*     */   {
/*  72 */     this(ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InstrumentationLoadTimeWeaver(@Nullable ClassLoader classLoader)
/*     */   {
/*  80 */     this.classLoader = classLoader;
/*  81 */     this.instrumentation = getInstrumentation();
/*     */   }
/*     */   
/*     */ 
/*     */   public void addTransformer(ClassFileTransformer transformer)
/*     */   {
/*  87 */     Assert.notNull(transformer, "Transformer must not be null");
/*  88 */     FilteringClassFileTransformer actualTransformer = new FilteringClassFileTransformer(transformer, this.classLoader);
/*     */     
/*  90 */     synchronized (this.transformers) {
/*  91 */       Assert.state(this.instrumentation != null, "Must start with Java agent to use InstrumentationLoadTimeWeaver. See Spring documentation.");
/*     */       
/*  93 */       this.instrumentation.addTransformer(actualTransformer);
/*  94 */       this.transformers.add(actualTransformer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassLoader getInstrumentableClassLoader()
/*     */   {
/* 105 */     Assert.state(this.classLoader != null, "No ClassLoader available");
/* 106 */     return this.classLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassLoader getThrowawayClassLoader()
/*     */   {
/* 114 */     return new SimpleThrowawayClassLoader(getInstrumentableClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void removeTransformers()
/*     */   {
/* 121 */     synchronized (this.transformers) {
/* 122 */       if ((this.instrumentation != null) && (!this.transformers.isEmpty())) {
/* 123 */         for (int i = this.transformers.size() - 1; i >= 0; i--) {
/* 124 */           this.instrumentation.removeTransformer((ClassFileTransformer)this.transformers.get(i));
/*     */         }
/* 126 */         this.transformers.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isInstrumentationAvailable()
/*     */   {
/* 137 */     return getInstrumentation() != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private static Instrumentation getInstrumentation()
/*     */   {
/* 147 */     if (AGENT_CLASS_PRESENT) {
/* 148 */       return InstrumentationAccessor.getInstrumentation();
/*     */     }
/*     */     
/* 151 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class InstrumentationAccessor
/*     */   {
/*     */     public static Instrumentation getInstrumentation()
/*     */     {
/* 162 */       return InstrumentationSavingAgent.getInstrumentation();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class FilteringClassFileTransformer
/*     */     implements ClassFileTransformer
/*     */   {
/*     */     private final ClassFileTransformer targetTransformer;
/*     */     
/*     */ 
/*     */     @Nullable
/*     */     private final ClassLoader targetClassLoader;
/*     */     
/*     */ 
/*     */     public FilteringClassFileTransformer(ClassFileTransformer targetTransformer, @Nullable ClassLoader targetClassLoader)
/*     */     {
/* 180 */       this.targetTransformer = targetTransformer;
/* 181 */       this.targetClassLoader = targetClassLoader;
/*     */     }
/*     */     
/*     */ 
/*     */     @Nullable
/*     */     public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer)
/*     */       throws IllegalClassFormatException
/*     */     {
/* 189 */       if (this.targetClassLoader != loader) {
/* 190 */         return null;
/*     */       }
/* 192 */       return this.targetTransformer.transform(loader, className, classBeingRedefined, protectionDomain, classfileBuffer);
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 198 */       return "FilteringClassFileTransformer for: " + this.targetTransformer.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\instrument\classloading\InstrumentationLoadTimeWeaver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */