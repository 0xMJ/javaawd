package org.springframework.instrument.classloading;

import java.lang.instrument.ClassFileTransformer;

public abstract interface LoadTimeWeaver
{
  public abstract void addTransformer(ClassFileTransformer paramClassFileTransformer);
  
  public abstract ClassLoader getInstrumentableClassLoader();
  
  public abstract ClassLoader getThrowawayClassLoader();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-context-5.3.12.jar!\org\springframework\instrument\classloading\LoadTimeWeaver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */