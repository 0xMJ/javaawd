package com.fasterxml.jackson.annotation;

public enum Nulls
{
  SET,  SKIP,  FAIL,  AS_EMPTY,  DEFAULT;
  
  private Nulls() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-annotations-2.12.5.jar!\com\fasterxml\jackson\annotation\Nulls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */