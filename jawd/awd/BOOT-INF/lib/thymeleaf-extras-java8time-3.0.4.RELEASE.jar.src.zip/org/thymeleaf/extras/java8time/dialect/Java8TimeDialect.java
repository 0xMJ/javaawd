/*    */ package org.thymeleaf.extras.java8time.dialect;
/*    */ 
/*    */ import org.thymeleaf.dialect.AbstractDialect;
/*    */ import org.thymeleaf.dialect.IExpressionObjectDialect;
/*    */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Java8TimeDialect
/*    */   extends AbstractDialect
/*    */   implements IExpressionObjectDialect
/*    */ {
/* 37 */   private final IExpressionObjectFactory JAVA8_TIME_EXPRESSION_OBJECTS_FACTORY = new Java8TimeExpressionFactory();
/*    */   
/*    */   public Java8TimeDialect() {
/* 40 */     super("java8time");
/*    */   }
/*    */   
/*    */   public IExpressionObjectFactory getExpressionObjectFactory()
/*    */   {
/* 45 */     return this.JAVA8_TIME_EXPRESSION_OBJECTS_FACTORY;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-extras-java8time-3.0.4.RELEASE.jar!\org\thymeleaf\extras\java8time\dialect\Java8TimeDialect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */