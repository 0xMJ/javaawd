/*     */ package org.thymeleaf.extras.java8time.util;
/*     */ 
/*     */ import java.time.ZoneId;
/*     */ import java.time.chrono.ChronoZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.FormatStyle;
/*     */ import java.time.temporal.ChronoField;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Locale;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemporalFormattingUtils
/*     */ {
/*  45 */   private static final DateTimeFormatter ISO8601_DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZZZ");
/*     */   
/*     */   private final Locale locale;
/*     */   private final ZoneId defaultZoneId;
/*     */   
/*     */   public TemporalFormattingUtils(Locale locale, ZoneId defaultZoneId)
/*     */   {
/*  52 */     Validate.notNull(locale, "Locale cannot be null");
/*  53 */     Validate.notNull(defaultZoneId, "ZoneId cannot be null");
/*  54 */     this.locale = locale;
/*  55 */     this.defaultZoneId = defaultZoneId;
/*     */   }
/*     */   
/*     */   public String format(Object target) {
/*  59 */     return formatDate(target);
/*     */   }
/*     */   
/*     */   public String format(Object target, Locale locale) {
/*  63 */     Validate.notNull(locale, "Locale cannot be null");
/*  64 */     return formatDate(target, null, locale);
/*     */   }
/*     */   
/*     */   public String format(Object target, String pattern) {
/*  68 */     return format(target, pattern, null);
/*     */   }
/*     */   
/*     */   public String format(Object target, String pattern, Locale locale) {
/*  72 */     Validate.notEmpty(pattern, "Pattern cannot be null or empty");
/*  73 */     return formatDate(target, pattern, locale);
/*     */   }
/*     */   
/*     */   public Integer day(Object target) {
/*  77 */     if (target == null) {
/*  78 */       return null;
/*     */     }
/*  80 */     TemporalAccessor time = TemporalObjects.temporal(target);
/*  81 */     return Integer.valueOf(time.get(ChronoField.DAY_OF_MONTH));
/*     */   }
/*     */   
/*     */   public Integer month(Object target) {
/*  85 */     if (target == null) {
/*  86 */       return null;
/*     */     }
/*  88 */     TemporalAccessor time = TemporalObjects.temporal(target);
/*  89 */     return Integer.valueOf(time.get(ChronoField.MONTH_OF_YEAR));
/*     */   }
/*     */   
/*     */   public String monthName(Object target) {
/*  93 */     return format(target, "MMMM");
/*     */   }
/*     */   
/*     */   public String monthNameShort(Object target) {
/*  97 */     return format(target, "MMM");
/*     */   }
/*     */   
/*     */   public Integer year(Object target) {
/* 101 */     if (target == null) {
/* 102 */       return null;
/*     */     }
/* 104 */     TemporalAccessor time = TemporalObjects.temporal(target);
/* 105 */     return Integer.valueOf(time.get(ChronoField.YEAR));
/*     */   }
/*     */   
/*     */   public Integer dayOfWeek(Object target) {
/* 109 */     if (target == null) {
/* 110 */       return null;
/*     */     }
/* 112 */     TemporalAccessor time = TemporalObjects.temporal(target);
/* 113 */     return Integer.valueOf(time.get(ChronoField.DAY_OF_WEEK));
/*     */   }
/*     */   
/*     */   public String dayOfWeekName(Object target) {
/* 117 */     return format(target, "EEEE");
/*     */   }
/*     */   
/*     */   public String dayOfWeekNameShort(Object target) {
/* 121 */     return format(target, "EEE");
/*     */   }
/*     */   
/*     */   public Integer hour(Object target) {
/* 125 */     if (target == null) {
/* 126 */       return null;
/*     */     }
/* 128 */     TemporalAccessor time = TemporalObjects.temporal(target);
/* 129 */     return Integer.valueOf(time.get(ChronoField.HOUR_OF_DAY));
/*     */   }
/*     */   
/*     */   public Integer minute(Object target) {
/* 133 */     if (target == null) {
/* 134 */       return null;
/*     */     }
/* 136 */     TemporalAccessor time = TemporalObjects.temporal(target);
/* 137 */     return Integer.valueOf(time.get(ChronoField.MINUTE_OF_HOUR));
/*     */   }
/*     */   
/*     */   public Integer second(Object target) {
/* 141 */     if (target == null) {
/* 142 */       return null;
/*     */     }
/* 144 */     TemporalAccessor time = TemporalObjects.temporal(target);
/* 145 */     return Integer.valueOf(time.get(ChronoField.SECOND_OF_MINUTE));
/*     */   }
/*     */   
/*     */   public Integer nanosecond(Object target) {
/* 149 */     if (target == null) {
/* 150 */       return null;
/*     */     }
/* 152 */     TemporalAccessor time = TemporalObjects.temporal(target);
/* 153 */     return Integer.valueOf(time.get(ChronoField.NANO_OF_SECOND));
/*     */   }
/*     */   
/*     */   public String formatISO(Object target) {
/* 157 */     if (target == null)
/* 158 */       return null;
/* 159 */     if ((target instanceof TemporalAccessor)) {
/* 160 */       ChronoZonedDateTime time = TemporalObjects.zonedTime(target, this.defaultZoneId);
/* 161 */       return ISO8601_DATE_TIME_FORMATTER.withLocale(this.locale).format(time);
/*     */     }
/*     */     
/* 164 */     throw new IllegalArgumentException("Cannot format object of class \"" + target.getClass().getName() + "\" as a date");
/*     */   }
/*     */   
/*     */   private String formatDate(Object target)
/*     */   {
/* 169 */     return formatDate(target, null, null);
/*     */   }
/*     */   
/*     */   private String formatDate(Object target, String pattern, Locale localeOverride) {
/* 173 */     if (target == null) {
/* 174 */       return null;
/*     */     }
/* 176 */     Locale formattingLocale = localeOverride != null ? localeOverride : this.locale;
/*     */     try
/*     */     {
/* 179 */       if (StringUtils.isEmptyOrWhitespace(pattern)) {
/* 180 */         DateTimeFormatter formatter = TemporalObjects.formatterFor(target, formattingLocale);
/* 181 */         return formatter.format(TemporalObjects.temporal(target));
/*     */       }
/* 183 */       DateTimeFormatter formatter = defaultOrPatternFormatted(pattern, formattingLocale);
/* 184 */       return formatter.format(TemporalObjects.zonedTime(target, this.defaultZoneId));
/*     */     }
/*     */     catch (Exception e) {
/* 187 */       throw new TemplateProcessingException("Error formatting date for locale " + formattingLocale, e);
/*     */     }
/*     */   }
/*     */   
/*     */   private DateTimeFormatter defaultOrPatternFormatted(String pattern, Locale locale)
/*     */   {
/* 193 */     switch (pattern) {
/* 194 */     case "SHORT":  return DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT).withLocale(locale);
/* 195 */     case "MEDIUM":  return DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM).withLocale(locale);
/* 196 */     case "LONG":  return DateTimeFormatter.ofLocalizedDateTime(FormatStyle.LONG).withLocale(locale);
/* 197 */     case "FULL":  return DateTimeFormatter.ofLocalizedDateTime(FormatStyle.FULL).withLocale(locale); }
/* 198 */     return DateTimeFormatter.ofPattern(pattern, locale);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-extras-java8time-3.0.4.RELEASE.jar!\org\thymeleaf\extras\java8time\util\TemporalFormattingUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */