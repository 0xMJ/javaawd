/*     */ package org.thymeleaf.extras.java8time.util;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.Temporal;
/*     */ import java.util.TimeZone;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemporalCreationUtils
/*     */ {
/*     */   public Temporal create(Object year, Object month, Object day)
/*     */   {
/*  52 */     return LocalDate.of(integer(year), integer(month), integer(day));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Temporal create(Object year, Object month, Object day, Object hour, Object minute)
/*     */   {
/*  62 */     return LocalDateTime.of(integer(year), integer(month), integer(day), integer(hour), integer(minute));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Temporal create(Object year, Object month, Object day, Object hour, Object minute, Object second)
/*     */   {
/*  72 */     return LocalDateTime.of(integer(year), integer(month), integer(day), 
/*  73 */       integer(hour), integer(minute), integer(second));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Temporal create(Object year, Object month, Object day, Object hour, Object minute, Object second, Object nanosecond)
/*     */   {
/*  83 */     return LocalDateTime.of(integer(year), integer(month), integer(day), 
/*  84 */       integer(hour), integer(minute), integer(second), integer(nanosecond));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Temporal createNow()
/*     */   {
/*  93 */     return LocalDateTime.now();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Temporal createNowForTimeZone(Object zoneId)
/*     */   {
/* 102 */     return ZonedDateTime.now(zoneId(zoneId));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Temporal createToday()
/*     */   {
/* 111 */     return LocalDate.now();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Temporal createTodayForTimeZone(Object zoneId)
/*     */   {
/* 120 */     return 
/* 121 */       ZonedDateTime.now(zoneId(zoneId)).withHour(0).withMinute(0).withSecond(0).withNano(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Temporal createDate(String isoDate)
/*     */   {
/* 130 */     return LocalDate.parse(isoDate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Temporal createDateTime(String isoDate)
/*     */   {
/* 139 */     return LocalDateTime.parse(isoDate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Temporal createDate(String isoDate, String pattern)
/*     */   {
/* 148 */     return LocalDate.parse(isoDate, DateTimeFormatter.ofPattern(pattern));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Temporal createDateTime(String isoDate, String pattern)
/*     */   {
/* 157 */     return LocalDateTime.parse(isoDate, DateTimeFormatter.ofPattern(pattern));
/*     */   }
/*     */   
/*     */   private int integer(Object number) {
/* 161 */     Validate.notNull(number, "Argument cannot be null");
/* 162 */     return EvaluationUtils.evaluateAsNumber(number).intValue();
/*     */   }
/*     */   
/*     */   private ZoneId zoneId(Object zoneId) {
/* 166 */     Validate.notNull(zoneId, "ZoneId cannot be null");
/* 167 */     if ((zoneId instanceof ZoneId))
/* 168 */       return (ZoneId)zoneId;
/* 169 */     if ((zoneId instanceof TimeZone)) {
/* 170 */       TimeZone timeZone = (TimeZone)zoneId;
/* 171 */       return timeZone.toZoneId();
/*     */     }
/* 173 */     return ZoneId.of(zoneId.toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-extras-java8time-3.0.4.RELEASE.jar!\org\thymeleaf\extras\java8time\util\TemporalCreationUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */