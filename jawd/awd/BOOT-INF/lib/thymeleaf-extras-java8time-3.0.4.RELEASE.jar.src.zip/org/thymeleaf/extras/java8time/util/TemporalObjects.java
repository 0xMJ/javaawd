/*     */ package org.thymeleaf.extras.java8time.util;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.Year;
/*     */ import java.time.YearMonth;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.time.chrono.ChronoZonedDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DateTimeFormatterBuilder;
/*     */ import java.time.format.FormatStyle;
/*     */ import java.time.format.TextStyle;
/*     */ import java.time.temporal.ChronoField;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Locale;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemporalObjects
/*     */ {
/*     */   public static DateTimeFormatter formatterFor(Object target, Locale locale)
/*     */   {
/*  53 */     Validate.notNull(target, "Target cannot be null");
/*  54 */     Validate.notNull(locale, "Locale cannot be null");
/*  55 */     if ((target instanceof Instant))
/*  56 */       return new DateTimeFormatterBuilder().appendInstant().toFormatter();
/*  57 */     if ((target instanceof LocalDate))
/*  58 */       return DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG).withLocale(locale);
/*  59 */     if ((target instanceof LocalDateTime))
/*  60 */       return DateTimeFormatter.ofLocalizedDateTime(FormatStyle.LONG, FormatStyle.MEDIUM).withLocale(locale);
/*  61 */     if ((target instanceof LocalTime))
/*  62 */       return DateTimeFormatter.ofLocalizedTime(FormatStyle.MEDIUM).withLocale(locale);
/*  63 */     if ((target instanceof OffsetDateTime))
/*  64 */       return 
/*     */       
/*     */ 
/*     */ 
/*  68 */         new DateTimeFormatterBuilder().appendLocalized(FormatStyle.LONG, FormatStyle.MEDIUM).appendLocalizedOffset(TextStyle.FULL).toFormatter().withLocale(locale);
/*  69 */     if ((target instanceof OffsetTime))
/*  70 */       return 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */         new DateTimeFormatterBuilder().appendValue(ChronoField.HOUR_OF_DAY).appendLiteral(':').appendValue(ChronoField.MINUTE_OF_HOUR).appendLiteral(':').appendValue(ChronoField.SECOND_OF_MINUTE).appendLocalizedOffset(TextStyle.FULL).toFormatter().withLocale(locale);
/*  79 */     if ((target instanceof Year))
/*  80 */       return 
/*     */       
/*  82 */         new DateTimeFormatterBuilder().appendValue(ChronoField.YEAR).toFormatter();
/*  83 */     if ((target instanceof YearMonth))
/*  84 */       return yearMonthFormatter(locale);
/*  85 */     if ((target instanceof ZonedDateTime)) {
/*  86 */       return DateTimeFormatter.ofLocalizedDateTime(FormatStyle.LONG).withLocale(locale);
/*     */     }
/*     */     
/*  89 */     throw new IllegalArgumentException("Cannot format object of class \"" + target.getClass().getName() + "\" as a date");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ChronoZonedDateTime zonedTime(Object target, ZoneId defaultZoneId)
/*     */   {
/* 100 */     Validate.notNull(target, "Target cannot be null");
/* 101 */     Validate.notNull(defaultZoneId, "ZoneId cannot be null");
/* 102 */     if ((target instanceof Instant))
/* 103 */       return ZonedDateTime.ofInstant((Instant)target, defaultZoneId);
/* 104 */     if ((target instanceof LocalDate))
/* 105 */       return ZonedDateTime.of((LocalDate)target, LocalTime.MIDNIGHT, defaultZoneId);
/* 106 */     if ((target instanceof LocalDateTime))
/* 107 */       return ZonedDateTime.of((LocalDateTime)target, defaultZoneId);
/* 108 */     if ((target instanceof LocalTime))
/* 109 */       return ZonedDateTime.of(LocalDate.now(), (LocalTime)target, defaultZoneId);
/* 110 */     if ((target instanceof OffsetDateTime))
/* 111 */       return ((OffsetDateTime)target).toZonedDateTime();
/* 112 */     if ((target instanceof OffsetTime)) {
/* 113 */       LocalTime localTime = ((OffsetTime)target).toLocalTime();
/* 114 */       return ZonedDateTime.of(LocalDate.now(), localTime, defaultZoneId); }
/* 115 */     if ((target instanceof Year)) {
/* 116 */       LocalDate localDate = ((Year)target).atDay(1);
/* 117 */       return ZonedDateTime.of(localDate, LocalTime.MIDNIGHT, defaultZoneId); }
/* 118 */     if ((target instanceof YearMonth)) {
/* 119 */       LocalDate localDate = ((YearMonth)target).atDay(1);
/* 120 */       return ZonedDateTime.of(localDate, LocalTime.MIDNIGHT, defaultZoneId); }
/* 121 */     if ((target instanceof ZonedDateTime)) {
/* 122 */       return (ChronoZonedDateTime)target;
/*     */     }
/*     */     
/* 125 */     throw new IllegalArgumentException("Cannot format object of class \"" + target.getClass().getName() + "\" as a date");
/*     */   }
/*     */   
/*     */   public static TemporalAccessor temporal(Object target)
/*     */   {
/* 130 */     Validate.notNull(target, "Target cannot be null");
/* 131 */     if ((target instanceof TemporalAccessor)) {
/* 132 */       return (TemporalAccessor)target;
/*     */     }
/*     */     
/* 135 */     throw new IllegalArgumentException("Cannot normalize class \"" + target.getClass().getName() + "\" as a date");
/*     */   }
/*     */   
/*     */   private static DateTimeFormatter yearMonthFormatter(Locale locale)
/*     */   {
/* 140 */     if (shouldDisplayYearBeforeMonth(locale)) {
/* 141 */       return 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 146 */         new DateTimeFormatterBuilder().appendValue(ChronoField.YEAR).appendLiteral(' ').appendText(ChronoField.MONTH_OF_YEAR).toFormatter().withLocale(locale);
/*     */     }
/* 148 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 153 */       new DateTimeFormatterBuilder().appendText(ChronoField.MONTH_OF_YEAR).appendLiteral(' ').appendValue(ChronoField.YEAR).toFormatter().withLocale(locale);
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean shouldDisplayYearBeforeMonth(Locale locale)
/*     */   {
/* 159 */     String country = locale.getCountry();
/* 160 */     switch (country) {
/*     */     case "BT": 
/*     */     case "CA": 
/*     */     case "CN": 
/*     */     case "KP": 
/*     */     case "KR": 
/*     */     case "TW": 
/*     */     case "HU": 
/*     */     case "IR": 
/*     */     case "JP": 
/*     */     case "LT": 
/*     */     case "MN": 
/* 172 */       return true;
/*     */     }
/* 174 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-extras-java8time-3.0.4.RELEASE.jar!\org\thymeleaf\extras\java8time\util\TemporalObjects.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */