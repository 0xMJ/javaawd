/*    */ package org.thymeleaf.extras.java8time.dialect;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*    */ import org.thymeleaf.extras.java8time.expression.Temporals;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Java8TimeExpressionFactory
/*    */   implements IExpressionObjectFactory
/*    */ {
/*    */   private static final String TEMPORAL_EVALUATION_VARIABLE_NAME = "temporals";
/* 36 */   private static final Set<String> ALL_EXPRESSION_OBJECT_NAMES = Collections.unmodifiableSet(new HashSet(
/* 37 */     Arrays.asList(new String[] { "temporals" })));
/*    */   
/*    */   public Set<String> getAllExpressionObjectNames()
/*    */   {
/* 41 */     return ALL_EXPRESSION_OBJECT_NAMES;
/*    */   }
/*    */   
/*    */   public Object buildObject(IExpressionContext context, String expressionObjectName)
/*    */   {
/* 46 */     if ("temporals".equals(expressionObjectName)) {
/* 47 */       return new Temporals(context.getLocale());
/*    */     }
/* 49 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isCacheable(String expressionObjectName)
/*    */   {
/* 54 */     return (expressionObjectName != null) && ("temporals".equals(expressionObjectName));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-extras-java8time-3.0.4.RELEASE.jar!\org\thymeleaf\extras\java8time\dialect\Java8TimeExpressionFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */