/*     */ package org.springframework.boot.jarmode.layertools;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.loader.jarmode.JarMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LayerToolsJarMode
/*     */   implements JarMode
/*     */ {
/*     */   public boolean accepts(String mode)
/*     */   {
/*  39 */     return "layertools".equalsIgnoreCase(mode);
/*     */   }
/*     */   
/*     */   public void run(String mode, String[] args)
/*     */   {
/*     */     try {
/*  45 */       new Runner().run(args);
/*     */     }
/*     */     catch (Exception ex) {
/*  48 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static class Runner
/*     */   {
/*     */     static Context contextOverride;
/*     */     private final List<Command> commands;
/*     */     private final HelpCommand help;
/*     */     
/*     */     Runner()
/*     */     {
/*  61 */       Context context = contextOverride != null ? contextOverride : new Context();
/*  62 */       this.commands = getCommands(context);
/*  63 */       this.help = new HelpCommand(context, this.commands);
/*     */     }
/*     */     
/*     */     private void run(String[] args) {
/*  67 */       run(dequeOf(args));
/*     */     }
/*     */     
/*     */     private void run(Deque<String> args) {
/*  71 */       if (!args.isEmpty()) {
/*  72 */         String commandName = (String)args.removeFirst();
/*  73 */         Command command = Command.find(this.commands, commandName);
/*  74 */         if (command != null) {
/*  75 */           runCommand(command, args);
/*  76 */           return;
/*     */         }
/*  78 */         printError("Unknown command \"" + commandName + "\"");
/*     */       }
/*  80 */       this.help.run(args);
/*     */     }
/*     */     
/*     */     private void runCommand(Command command, Deque<String> args) {
/*     */       try {
/*  85 */         command.run(args);
/*     */       }
/*     */       catch (UnknownOptionException ex) {
/*  88 */         printError("Unknown option \"" + ex.getMessage() + "\" for the " + command.getName() + " command");
/*  89 */         this.help.run(dequeOf(new String[] { command.getName() }));
/*     */       }
/*     */       catch (MissingValueException ex) {
/*  92 */         printError("Option \"" + ex.getMessage() + "\" for the " + command.getName() + " command requires a value");
/*     */         
/*  94 */         this.help.run(dequeOf(new String[] { command.getName() }));
/*     */       }
/*     */     }
/*     */     
/*     */     private void printError(String errorMessage) {
/*  99 */       System.out.println("Error: " + errorMessage);
/* 100 */       System.out.println();
/*     */     }
/*     */     
/*     */     private Deque<String> dequeOf(String... args) {
/* 104 */       return new ArrayDeque(Arrays.asList(args));
/*     */     }
/*     */     
/*     */     static List<Command> getCommands(Context context) {
/* 108 */       List<Command> commands = new ArrayList();
/* 109 */       commands.add(new ListCommand(context));
/* 110 */       commands.add(new ExtractCommand(context));
/* 111 */       return Collections.unmodifiableList(commands);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-jarmode-layertools-2.5.6.jar!\org\springframework\boot\jarmode\layertools\LayerToolsJarMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */