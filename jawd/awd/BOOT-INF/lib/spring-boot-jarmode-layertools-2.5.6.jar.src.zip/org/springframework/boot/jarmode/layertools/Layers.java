/*    */ package org.springframework.boot.jarmode.layertools;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.zip.ZipEntry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract interface Layers
/*    */   extends Iterable<String>
/*    */ {
/*    */   public abstract Iterator<String> iterator();
/*    */   
/*    */   public abstract String getLayer(ZipEntry paramZipEntry);
/*    */   
/*    */   public static Layers get(Context context)
/*    */   {
/* 51 */     IndexedLayers indexedLayers = IndexedLayers.get(context);
/* 52 */     if (indexedLayers == null) {
/* 53 */       throw new IllegalStateException("Failed to load layers.idx which is required by layertools");
/*    */     }
/* 55 */     return indexedLayers;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-jarmode-layertools-2.5.6.jar!\org\springframework\boot\jarmode\layertools\Layers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */