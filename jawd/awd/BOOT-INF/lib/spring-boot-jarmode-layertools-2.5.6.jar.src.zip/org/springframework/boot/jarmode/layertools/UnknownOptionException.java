/*    */ package org.springframework.boot.jarmode.layertools;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UnknownOptionException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final String optionName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   UnknownOptionException(String optionName)
/*    */   {
/* 29 */     this.optionName = optionName;
/*    */   }
/*    */   
/*    */   public String getMessage()
/*    */   {
/* 34 */     return "--" + this.optionName;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-jarmode-layertools-2.5.6.jar!\org\springframework\boot\jarmode\layertools\UnknownOptionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */