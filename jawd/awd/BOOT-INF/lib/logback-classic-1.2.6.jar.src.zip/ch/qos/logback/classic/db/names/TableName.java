package ch.qos.logback.classic.db.names;

public enum TableName
{
  LOGGING_EVENT,  LOGGING_EVENT_PROPERTY,  LOGGING_EVENT_EXCEPTION;
  
  private TableName() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-classic-1.2.6.jar!\ch\qos\logback\classic\db\names\TableName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */