package ch.qos.logback.classic.db.names;

public enum ColumnName
{
  EVENT_ID,  TIMESTMP,  FORMATTED_MESSAGE,  LOGGER_NAME,  LEVEL_STRING,  THREAD_NAME,  REFERENCE_FLAG,  ARG0,  ARG1,  ARG2,  ARG3,  CALLER_FILENAME,  CALLER_CLASS,  CALLER_METHOD,  CALLER_LINE,  MAPPED_KEY,  MAPPED_VALUE,  I,  TRACE_LINE;
  
  private ColumnName() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-classic-1.2.6.jar!\ch\qos\logback\classic\db\names\ColumnName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */