/*    */ package ch.qos.logback.classic.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerNameUtil
/*    */ {
/*    */   public static int getFirstSeparatorIndexOf(String name)
/*    */   {
/* 27 */     return getSeparatorIndexOf(name, 0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static int getSeparatorIndexOf(String name, int fromIndex)
/*    */   {
/* 39 */     int dotIndex = name.indexOf('.', fromIndex);
/* 40 */     int dollarIndex = name.indexOf('$', fromIndex);
/*    */     
/* 42 */     if ((dotIndex == -1) && (dollarIndex == -1))
/* 43 */       return -1;
/* 44 */     if (dotIndex == -1)
/* 45 */       return dollarIndex;
/* 46 */     if (dollarIndex == -1) {
/* 47 */       return dotIndex;
/*    */     }
/* 49 */     return dotIndex < dollarIndex ? dotIndex : dollarIndex;
/*    */   }
/*    */   
/*    */   public static List<String> computeNameParts(String loggerName) {
/* 53 */     List<String> partList = new ArrayList();
/*    */     
/* 55 */     int fromIndex = 0;
/*    */     for (;;) {
/* 57 */       int index = getSeparatorIndexOf(loggerName, fromIndex);
/* 58 */       if (index == -1) {
/* 59 */         partList.add(loggerName.substring(fromIndex));
/* 60 */         break;
/*    */       }
/* 62 */       partList.add(loggerName.substring(fromIndex, index));
/* 63 */       fromIndex = index + 1;
/*    */     }
/* 65 */     return partList;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-classic-1.2.6.jar!\ch\qos\logback\classic\util\LoggerNameUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */