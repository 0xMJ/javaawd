/*     */ package ch.qos.logback.classic.gaffer;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.jmx.JMXConfigurator;
/*     */ import ch.qos.logback.classic.jmx.MBeanUtil;
/*     */ import ch.qos.logback.classic.joran.ReconfigureOnChangeTask;
/*     */ import ch.qos.logback.classic.net.ReceiverBase;
/*     */ import ch.qos.logback.classic.turbo.TurboFilter;
/*     */ import ch.qos.logback.core.Appender;
/*     */ import ch.qos.logback.core.CoreConstants;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.LifeCycle;
/*     */ import ch.qos.logback.core.status.StatusListener;
/*     */ import ch.qos.logback.core.util.CachingDateFormatter;
/*     */ import ch.qos.logback.core.util.Duration;
/*     */ import groovy.lang.Closure;
/*     */ import groovy.lang.GroovyObject;
/*     */ import groovy.lang.MetaClass;
/*     */ import groovy.lang.Reference;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.codehaus.groovy.runtime.BytecodeInterface8;
/*     */ import org.codehaus.groovy.runtime.GStringImpl;
/*     */ import org.codehaus.groovy.runtime.GeneratedClosure;
/*     */ import org.codehaus.groovy.runtime.ScriptBytecodeAdapter;
/*     */ import org.codehaus.groovy.runtime.callsite.CallSite;
/*     */ import org.codehaus.groovy.runtime.typehandling.DefaultTypeTransformation;
/*     */ import org.codehaus.groovy.runtime.typehandling.ShortTypeHandling;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationDelegate
/*     */   extends ContextAwareBase
/*     */   implements GroovyObject
/*     */ {
/*     */   public Object getDeclaredOrigin()
/*     */   {
/*  52 */     CallSite[] arrayOfCallSite = $getCallSiteArray();return this;return null;
/*     */   }
/*     */   
/*     */   public void scan(String scanPeriodStr) {
/*  56 */     CallSite[] arrayOfCallSite = $getCallSiteArray(); if (DefaultTypeTransformation.booleanUnbox(scanPeriodStr)) {
/*  57 */       ReconfigureOnChangeTask rocTask = (ReconfigureOnChangeTask)ScriptBytecodeAdapter.castToType(arrayOfCallSite[0].callConstructor(ReconfigureOnChangeTask.class), ReconfigureOnChangeTask.class);
/*  58 */       arrayOfCallSite[1].call(rocTask, arrayOfCallSite[2].callGroovyObjectGetProperty(this));
/*  59 */       arrayOfCallSite[3].call(arrayOfCallSite[4].callGroovyObjectGetProperty(this), arrayOfCallSite[5].callGetProperty(CoreConstants.class), rocTask);
/*     */       try {
/*  61 */         try { Duration duration = (Duration)ScriptBytecodeAdapter.castToType(arrayOfCallSite[6].call(Duration.class, scanPeriodStr), Duration.class);
/*  62 */           ScheduledExecutorService scheduledExecutorService = (ScheduledExecutorService)ScriptBytecodeAdapter.castToType(arrayOfCallSite[7].call(arrayOfCallSite[8].callGroovyObjectGetProperty(this)), ScheduledExecutorService.class);
/*     */           
/*  64 */           ScheduledFuture scheduledFuture = (ScheduledFuture)ScriptBytecodeAdapter.castToType(arrayOfCallSite[9].call(scheduledExecutorService, rocTask, arrayOfCallSite[10].call(duration), arrayOfCallSite[11].call(duration), arrayOfCallSite[12].callGetProperty(TimeUnit.class)), ScheduledFuture.class);
/*  65 */           arrayOfCallSite[13].call(arrayOfCallSite[14].callGroovyObjectGetProperty(this), scheduledFuture);
/*  66 */           arrayOfCallSite[15].callCurrent(this, arrayOfCallSite[16].call("Setting ReconfigureOnChangeTask scanning period to ", duration));
/*     */         } catch (NumberFormatException nfe) {
/*  68 */           arrayOfCallSite[17].callCurrent(this, arrayOfCallSite[18].call(arrayOfCallSite[19].call("Error while converting [", scanPeriodStr), "] to long"), nfe);
/*     */         }
/*     */       } finally {}
/*     */     }
/*     */   }
/*     */   
/*  74 */   public void statusListener(Class listenerClass) { CallSite[] arrayOfCallSite = $getCallSiteArray();StatusListener statusListener = (StatusListener)ScriptBytecodeAdapter.castToType(arrayOfCallSite[20].call(listenerClass), StatusListener.class);
/*  75 */     arrayOfCallSite[21].call(arrayOfCallSite[22].callGetProperty(arrayOfCallSite[23].callGroovyObjectGetProperty(this)), statusListener);
/*  76 */     if ((statusListener instanceof ContextAware)) {
/*  77 */       arrayOfCallSite[24].call((ContextAware)ScriptBytecodeAdapter.castToType(statusListener, ContextAware.class), arrayOfCallSite[25].callGroovyObjectGetProperty(this));
/*     */     }
/*  79 */     if ((statusListener instanceof LifeCycle)) {
/*  80 */       arrayOfCallSite[26].call((LifeCycle)ScriptBytecodeAdapter.castToType(statusListener, LifeCycle.class));
/*     */     }
/*  82 */     arrayOfCallSite[27].callCurrent(this, new GStringImpl(new Object[] { arrayOfCallSite[28].callGetProperty(listenerClass) }, new String[] { "Added status listener of type [", "]" }));
/*     */   }
/*     */   
/*     */   public void conversionRule(String conversionWord, Class converterClass) {
/*  86 */     CallSite[] arrayOfCallSite = $getCallSiteArray();String converterClassName = (String)ShortTypeHandling.castToString(arrayOfCallSite[29].call(converterClass));
/*     */     
/*  88 */     Map ruleRegistry = (Map)ScriptBytecodeAdapter.castToType(arrayOfCallSite[30].call(arrayOfCallSite[31].callGroovyObjectGetProperty(this), arrayOfCallSite[32].callGetProperty(CoreConstants.class)), Map.class);
/*  89 */     if (ScriptBytecodeAdapter.compareEqual(ruleRegistry, null)) {
/*  90 */       Object localObject = arrayOfCallSite[33].callConstructor(HashMap.class);ruleRegistry = (Map)ScriptBytecodeAdapter.castToType(localObject, Map.class);
/*  91 */       arrayOfCallSite[34].call(arrayOfCallSite[35].callGroovyObjectGetProperty(this), arrayOfCallSite[36].callGetProperty(CoreConstants.class), ruleRegistry);
/*     */     }
/*     */     
/*  94 */     arrayOfCallSite[37].callCurrent(this, arrayOfCallSite[38].call(arrayOfCallSite[39].call(arrayOfCallSite[40].call(arrayOfCallSite[41].call("registering conversion word ", conversionWord), " with class ["), converterClassName), "]"));
/*  95 */     arrayOfCallSite[42].call(ruleRegistry, conversionWord, converterClassName);
/*     */   }
/*     */   
/*  98 */   public void root(Level level) { CallSite[] arrayOfCallSite = $getCallSiteArray();root(level, ScriptBytecodeAdapter.createList(new Object[0]));null; }
/*  99 */   public void root(Level level, List<String> appenderNames) { CallSite[] arrayOfCallSite = $getCallSiteArray(); if (ScriptBytecodeAdapter.compareEqual(level, null)) {
/* 100 */       arrayOfCallSite[43].callCurrent(this, "Root logger cannot be set to level null");
/*     */     } else
/* 102 */       arrayOfCallSite[44].callCurrent(this, arrayOfCallSite[45].callGetProperty(org.slf4j.Logger.class), level, appenderNames);
/*     */   }
/*     */   
/*     */   public void logger(String name, Level level) {
/* 106 */     CallSite[] arrayOfCallSite = $getCallSiteArray();logger(name, level, ScriptBytecodeAdapter.createList(new Object[0]), null);null;
/*     */   }
/*     */   
/*     */   class _logger_closure1 extends Closure implements GeneratedClosure {
/*     */     public _logger_closure1(Object _thisObject, Reference aName) { super(_thisObject);
/*     */       Reference localReference = aName;
/*     */       this.aName = localReference;
/*     */     }
/*     */     
/* 113 */     public Object doCall(Object it) { CallSite[] arrayOfCallSite = $getCallSiteArray();return Boolean.valueOf(ScriptBytecodeAdapter.compareEqual(arrayOfCallSite[0].callGetProperty(it), this.aName.get()));return null;
/*     */     }
/*     */     
/*     */     public Object getaName()
/*     */     {
/*     */       CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */       return this.aName.get();
/*     */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void logger(String name, Level level, List<String> appenderNames, Boolean additivity)
/*     */   {
/* 107 */     CallSite[] arrayOfCallSite = $getCallSiteArray(); Boolean localBoolean; if (DefaultTypeTransformation.booleanUnbox(name)) {
/* 108 */       ch.qos.logback.classic.Logger logger = (ch.qos.logback.classic.Logger)ScriptBytecodeAdapter.castToType(arrayOfCallSite[46].call((LoggerContext)ScriptBytecodeAdapter.castToType(arrayOfCallSite[47].callGroovyObjectGetProperty(this), LoggerContext.class), name), ch.qos.logback.classic.Logger.class);
/* 109 */       arrayOfCallSite[48].callCurrent(this, arrayOfCallSite[49].call(new GStringImpl(new Object[] { name }, new String[] { "Setting level of logger [", "] to " }), level));
/* 110 */       Level localLevel = level;ScriptBytecodeAdapter.setProperty(localLevel, null, logger, "level");
/*     */       
/* 112 */       Reference aName = new Reference(null); for (Iterator localIterator = (Iterator)ScriptBytecodeAdapter.castToType(arrayOfCallSite[50].call(appenderNames), Iterator.class); localIterator.hasNext();) { ((Reference)aName).set(localIterator.next());
/* 113 */         Appender appender = (Appender)ScriptBytecodeAdapter.castToType(arrayOfCallSite[51].call(this.appenderList, new _logger_closure1(this, aName)), Appender.class);
/* 114 */         if (ScriptBytecodeAdapter.compareNotEqual(appender, null)) {
/* 115 */           arrayOfCallSite[52].callCurrent(this, arrayOfCallSite[53].call(new GStringImpl(new Object[] { aName.get() }, new String[] { "Attaching appender named [", "] to " }), logger));
/* 116 */           arrayOfCallSite[54].call(logger, appender);
/*     */         } else {
/* 118 */           arrayOfCallSite[55].callCurrent(this, new GStringImpl(new Object[] { aName.get() }, new String[] { "Failed to find appender named [", "]" }));
/*     */         }
/*     */       }
/*     */       
/* 122 */       if (ScriptBytecodeAdapter.compareNotEqual(additivity, null)) {
/* 123 */         localBoolean = additivity;ScriptBytecodeAdapter.setProperty(localBoolean, null, logger, "additive");
/*     */       }
/*     */     } else {
/* 126 */       arrayOfCallSite[56].callCurrent(this, "No name attribute for logger");
/*     */     }
/*     */   }
/*     */   
/*     */   public void appender(String name, Class clazz, Closure closure) {
/* 131 */     CallSite[] arrayOfCallSite = $getCallSiteArray();arrayOfCallSite[57].callCurrent(this, arrayOfCallSite[58].call(arrayOfCallSite[59].call("About to instantiate appender of type [", arrayOfCallSite[60].callGetProperty(clazz)), "]"));
/* 132 */     Appender appender = (Appender)ScriptBytecodeAdapter.castToType(arrayOfCallSite[61].call(clazz), Appender.class);
/* 133 */     arrayOfCallSite[62].callCurrent(this, arrayOfCallSite[63].call(arrayOfCallSite[64].call("Naming appender as [", name), "]"));
/* 134 */     String str = name;ScriptBytecodeAdapter.setProperty(str, null, appender, "name");
/* 135 */     Object localObject1 = arrayOfCallSite[65].callGroovyObjectGetProperty(this);ScriptBytecodeAdapter.setProperty(localObject1, null, appender, "context");
/* 136 */     arrayOfCallSite[66].call(this.appenderList, appender);
/* 137 */     if (ScriptBytecodeAdapter.compareNotEqual(closure, null)) {
/* 138 */       AppenderDelegate ad = (AppenderDelegate)ScriptBytecodeAdapter.castToType(arrayOfCallSite[67].callConstructor(AppenderDelegate.class, appender, this.appenderList), AppenderDelegate.class);
/* 139 */       arrayOfCallSite[68].callCurrent(this, ad, appender);
/* 140 */       Object localObject2 = arrayOfCallSite[69].callGroovyObjectGetProperty(this);ScriptBytecodeAdapter.setGroovyObjectProperty(localObject2, ConfigurationDelegate.class, ad, "context");
/* 141 */       AppenderDelegate localAppenderDelegate1 = ad;ScriptBytecodeAdapter.setGroovyObjectProperty(localAppenderDelegate1, ConfigurationDelegate.class, closure, "delegate");
/* 142 */       Object localObject3 = arrayOfCallSite[70].callGetProperty(Closure.class);ScriptBytecodeAdapter.setGroovyObjectProperty(localObject3, ConfigurationDelegate.class, closure, "resolveStrategy");
/* 143 */       arrayOfCallSite[71].call(closure);
/*     */     }
/*     */     try {
/* 146 */       try { arrayOfCallSite[72].call(appender);
/*     */       } catch (RuntimeException e) {
/* 148 */         arrayOfCallSite[73].callCurrent(this, arrayOfCallSite[74].call(arrayOfCallSite[75].call("Failed to start apppender named [", name), "]"), e);
/*     */       }
/*     */     } finally {}
/*     */   }
/*     */   
/* 153 */   public void receiver(String name, Class aClass, Closure closure) { CallSite[] arrayOfCallSite = $getCallSiteArray();arrayOfCallSite[76].callCurrent(this, arrayOfCallSite[77].call(arrayOfCallSite[78].call("About to instantiate receiver of type [", arrayOfCallSite[79].callGetProperty(arrayOfCallSite[80].callGroovyObjectGetProperty(this))), "]"));
/* 154 */     ReceiverBase receiver = (ReceiverBase)ScriptBytecodeAdapter.castToType(arrayOfCallSite[81].call(aClass), ReceiverBase.class);
/* 155 */     Object localObject1 = arrayOfCallSite[82].callGroovyObjectGetProperty(this);ScriptBytecodeAdapter.setProperty(localObject1, null, receiver, "context");
/* 156 */     if (ScriptBytecodeAdapter.compareNotEqual(closure, null)) {
/* 157 */       ComponentDelegate componentDelegate = (ComponentDelegate)ScriptBytecodeAdapter.castToType(arrayOfCallSite[83].callConstructor(ComponentDelegate.class, receiver), ComponentDelegate.class);
/* 158 */       Object localObject2 = arrayOfCallSite[84].callGroovyObjectGetProperty(this);ScriptBytecodeAdapter.setGroovyObjectProperty(localObject2, ConfigurationDelegate.class, componentDelegate, "context");
/* 159 */       ComponentDelegate localComponentDelegate1 = componentDelegate;ScriptBytecodeAdapter.setGroovyObjectProperty(localComponentDelegate1, ConfigurationDelegate.class, closure, "delegate");
/* 160 */       Object localObject3 = arrayOfCallSite[85].callGetProperty(Closure.class);ScriptBytecodeAdapter.setGroovyObjectProperty(localObject3, ConfigurationDelegate.class, closure, "resolveStrategy");
/* 161 */       arrayOfCallSite[86].call(closure);
/*     */     }
/*     */     try {
/* 164 */       try { arrayOfCallSite[87].call(receiver);
/*     */       } catch (RuntimeException e) {
/* 166 */         arrayOfCallSite[88].callCurrent(this, arrayOfCallSite[89].call(arrayOfCallSite[90].call("Failed to start receiver of type [", arrayOfCallSite[91].call(aClass)), "]"), e);
/*     */       }
/*     */     } finally {}
/*     */   }
/*     */   
/* 171 */   private void copyContributions(AppenderDelegate appenderDelegate, Appender appender) { Reference appenderDelegate = new Reference(appenderDelegate);Reference appender = new Reference(appender);CallSite[] arrayOfCallSite = $getCallSiteArray(); if (((Appender)appender.get() instanceof ConfigurationContributor)) {
/* 172 */       ConfigurationContributor cc = (ConfigurationContributor)ScriptBytecodeAdapter.castToType((Appender)appender.get(), ConfigurationContributor.class);
/* 173 */       arrayOfCallSite[92].call(arrayOfCallSite[93].call(cc), new _copyContributions_closure2(this, appenderDelegate, appender)); } }
/*     */   class _copyContributions_closure2 extends Closure implements GeneratedClosure { public _copyContributions_closure2(Object _thisObject, Reference appenderDelegate, Reference appender) { super(_thisObject);
/*     */       Reference localReference1 = appenderDelegate;
/*     */       this.appenderDelegate = localReference1;
/*     */       Reference localReference2 = appender;
/*     */       this.appender = localReference2; } public Object doCall(Object oldName, Object newName) { CallSite[] arrayOfCallSite = $getCallSiteArray();Closure localClosure = ScriptBytecodeAdapter.getMethodPointer(this.appender.get(), (String)ShortTypeHandling.castToString(new GStringImpl(new Object[] { oldName }, new String[] { "", "" })));ScriptBytecodeAdapter.setProperty(localClosure, null, arrayOfCallSite[0].callGroovyObjectGetProperty(this.appenderDelegate.get()), (String)ShortTypeHandling.castToString(new GStringImpl(new Object[] { newName }, new String[] { "", "" })));return localClosure;return null; }
/*     */     
/*     */     public Object call(Object oldName, Object newName) { CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */       return arrayOfCallSite[1].callCurrent(this, oldName, newName);
/*     */       return null; }
/*     */     
/*     */     public AppenderDelegate getAppenderDelegate() { CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */       return (AppenderDelegate)ScriptBytecodeAdapter.castToType(this.appenderDelegate.get(), AppenderDelegate.class);
/*     */       return null; }
/*     */     public Appender getAppender() { CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */       return (Appender)ScriptBytecodeAdapter.castToType(this.appender.get(), Appender.class);
/*     */       return null; } }
/* 180 */   public void turboFilter(Class clazz, Closure closure) { CallSite[] arrayOfCallSite = $getCallSiteArray();arrayOfCallSite[94].callCurrent(this, arrayOfCallSite[95].call(arrayOfCallSite[96].call("About to instantiate turboFilter of type [", arrayOfCallSite[97].callGetProperty(clazz)), "]"));
/* 181 */     TurboFilter turboFilter = (TurboFilter)ScriptBytecodeAdapter.castToType(arrayOfCallSite[98].call(clazz), TurboFilter.class);
/* 182 */     Object localObject1 = arrayOfCallSite[99].callGroovyObjectGetProperty(this);ScriptBytecodeAdapter.setProperty(localObject1, null, turboFilter, "context");
/*     */     
/* 184 */     if (ScriptBytecodeAdapter.compareNotEqual(closure, null)) {
/* 185 */       ComponentDelegate componentDelegate = (ComponentDelegate)ScriptBytecodeAdapter.castToType(arrayOfCallSite[100].callConstructor(ComponentDelegate.class, turboFilter), ComponentDelegate.class);
/* 186 */       Object localObject2 = arrayOfCallSite[101].callGroovyObjectGetProperty(this);ScriptBytecodeAdapter.setGroovyObjectProperty(localObject2, ConfigurationDelegate.class, componentDelegate, "context");
/* 187 */       ComponentDelegate localComponentDelegate1 = componentDelegate;ScriptBytecodeAdapter.setGroovyObjectProperty(localComponentDelegate1, ConfigurationDelegate.class, closure, "delegate");
/* 188 */       Object localObject3 = arrayOfCallSite[102].callGetProperty(Closure.class);ScriptBytecodeAdapter.setGroovyObjectProperty(localObject3, ConfigurationDelegate.class, closure, "resolveStrategy");
/* 189 */       arrayOfCallSite[103].call(closure);
/*     */     }
/* 191 */     arrayOfCallSite[104].call(turboFilter);
/* 192 */     arrayOfCallSite[105].callCurrent(this, "Adding aforementioned turbo filter to context");
/* 193 */     arrayOfCallSite[106].call(arrayOfCallSite[107].callGroovyObjectGetProperty(this), turboFilter);
/*     */   }
/*     */   
/*     */   public String timestamp(String datePattern, long timeReference) {
/* 197 */     CallSite[] arrayOfCallSite = $getCallSiteArray();long now = DefaultTypeTransformation.longUnbox(Integer.valueOf(-1));
/*     */     Object localObject;
/* 199 */     if (ScriptBytecodeAdapter.compareEqual(Long.valueOf(timeReference), Integer.valueOf(-1))) {
/* 200 */       arrayOfCallSite[108].callCurrent(this, "Using current interpretation time, i.e. now, as time reference.");
/* 201 */       localObject = arrayOfCallSite[109].call(System.class);now = DefaultTypeTransformation.longUnbox(localObject);
/*     */     } else {
/* 203 */       long l1 = timeReference;now = l1;
/* 204 */       arrayOfCallSite[110].callCurrent(this, arrayOfCallSite[111].call(arrayOfCallSite[112].call("Using ", Long.valueOf(now)), " as time reference."));
/*     */     }
/* 206 */     CachingDateFormatter sdf = (CachingDateFormatter)ScriptBytecodeAdapter.castToType(arrayOfCallSite[113].callConstructor(CachingDateFormatter.class, datePattern), CachingDateFormatter.class);
/* 207 */     return (String)ShortTypeHandling.castToString(arrayOfCallSite[114].call(sdf, Long.valueOf(now)));return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void jmxConfigurator(String name)
/*     */   {
/* 218 */     CallSite[] arrayOfCallSite = $getCallSiteArray();Object objectName = null;
/* 219 */     Object contextName = arrayOfCallSite[115].callGetProperty(arrayOfCallSite[116].callGroovyObjectGetProperty(this));
/* 220 */     if (ScriptBytecodeAdapter.compareNotEqual(name, null))
/*     */       try {
/*     */         String str;
/* 223 */         try { localObject1 = arrayOfCallSite[117].callConstructor(ObjectName.class, name);objectName = localObject1;
/*     */         } catch (MalformedObjectNameException e) { Object localObject1;
/* 225 */           str = name;contextName = str;
/*     */         }
/*     */       } finally {}
/* 228 */     if (ScriptBytecodeAdapter.compareEqual(objectName, null)) {
/* 229 */       Object objectNameAsStr = arrayOfCallSite[118].call(MBeanUtil.class, contextName, JMXConfigurator.class);
/* 230 */       Object localObject3 = arrayOfCallSite[119].call(MBeanUtil.class, arrayOfCallSite[120].callGroovyObjectGetProperty(this), this, objectNameAsStr);objectName = localObject3;
/* 231 */       if (ScriptBytecodeAdapter.compareEqual(objectName, null)) {
/* 232 */         arrayOfCallSite[121].callCurrent(this, new GStringImpl(new Object[] { objectNameAsStr }, new String[] { "Failed to construct ObjectName for [", "]" }));
/* 233 */         return;
/*     */       }
/*     */     }
/*     */     
/* 237 */     Object platformMBeanServer = arrayOfCallSite[122].callGetProperty(ManagementFactory.class);
/* 238 */     if ((!DefaultTypeTransformation.booleanUnbox(arrayOfCallSite[123].call(MBeanUtil.class, platformMBeanServer, objectName)) ? 1 : 0) != 0) {
/* 239 */       JMXConfigurator jmxConfigurator = (JMXConfigurator)ScriptBytecodeAdapter.castToType(arrayOfCallSite[124].callConstructor(JMXConfigurator.class, ScriptBytecodeAdapter.createPojoWrapper((LoggerContext)ScriptBytecodeAdapter.castToType(arrayOfCallSite[125].callGroovyObjectGetProperty(this), LoggerContext.class), LoggerContext.class), platformMBeanServer, objectName), JMXConfigurator.class);
/*     */       try {
/* 241 */         try { arrayOfCallSite[126].call(platformMBeanServer, jmxConfigurator, objectName);
/*     */         } catch (Exception all) {
/* 243 */           arrayOfCallSite[127].callCurrent(this, "Failed to create mbean", all);
/*     */         }
/*     */       }
/*     */       finally {}
/*     */     }
/*     */   }
/*     */   
/*     */   public void scan()
/*     */   {
/*     */     CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */     if ((__$stMC) || (BytecodeInterface8.disabledStandardMetaClass()))
/*     */     {
/*     */       scan(null);
/*     */       null;
/*     */     }
/*     */     else
/*     */     {
/*     */       scan(null);
/*     */       null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void logger(String name, Level level, List<String> appenderNames)
/*     */   {
/*     */     CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */     logger(name, level, appenderNames, null);
/*     */     null;
/*     */   }
/*     */   
/*     */   public void appender(String name, Class clazz)
/*     */   {
/*     */     CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */     appender(name, clazz, null);
/*     */     null;
/*     */   }
/*     */   
/*     */   public void receiver(String name, Class aClass)
/*     */   {
/*     */     CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */     receiver(name, aClass, null);
/*     */     null;
/*     */   }
/*     */   
/*     */   public void turboFilter(Class clazz)
/*     */   {
/*     */     CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */     turboFilter(clazz, null);
/*     */     null;
/*     */   }
/*     */   
/*     */   public String timestamp(String datePattern)
/*     */   {
/*     */     CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */     if ((__$stMC) || (BytecodeInterface8.disabledStandardMetaClass())) {
/*     */       return timestamp(datePattern, DefaultTypeTransformation.longUnbox(Integer.valueOf(-1)));
/*     */     } else {
/*     */       return timestamp(datePattern, DefaultTypeTransformation.longUnbox(Integer.valueOf(-1)));
/*     */     }
/*     */     return null;
/*     */   }
/*     */   
/*     */   public void jmxConfigurator()
/*     */   {
/*     */     CallSite[] arrayOfCallSite = $getCallSiteArray();
/*     */     if ((__$stMC) || (BytecodeInterface8.disabledStandardMetaClass()))
/*     */     {
/*     */       jmxConfigurator(null);
/*     */       null;
/*     */     }
/*     */     else
/*     */     {
/*     */       jmxConfigurator(null);
/*     */       null;
/*     */     }
/*     */   }
/*     */   
/*     */   public List<Appender> getAppenderList()
/*     */   {
/*     */     return this.appenderList;
/*     */   }
/*     */   
/*     */   public void setAppenderList(List<Appender> paramList)
/*     */   {
/*     */     this.appenderList = paramList;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\logback-classic-1.2.6.jar!\ch\qos\logback\classic\gaffer\ConfigurationDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */