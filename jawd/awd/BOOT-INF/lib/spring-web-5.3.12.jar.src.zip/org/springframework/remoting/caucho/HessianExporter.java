/*     */ package org.springframework.remoting.caucho;
/*     */ 
/*     */ import com.caucho.hessian.io.AbstractHessianInput;
/*     */ import com.caucho.hessian.io.AbstractHessianOutput;
/*     */ import com.caucho.hessian.io.Hessian2Input;
/*     */ import com.caucho.hessian.io.Hessian2Output;
/*     */ import com.caucho.hessian.io.HessianDebugInputStream;
/*     */ import com.caucho.hessian.io.HessianDebugOutputStream;
/*     */ import com.caucho.hessian.io.HessianInput;
/*     */ import com.caucho.hessian.io.HessianOutput;
/*     */ import com.caucho.hessian.io.HessianRemoteResolver;
/*     */ import com.caucho.hessian.io.SerializerFactory;
/*     */ import com.caucho.hessian.server.HessianSkeleton;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.remoting.support.RemoteExporter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CommonsLogWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class HessianExporter
/*     */   extends RemoteExporter
/*     */   implements InitializingBean
/*     */ {
/*     */   public static final String CONTENT_TYPE_HESSIAN = "application/x-hessian";
/*  67 */   private SerializerFactory serializerFactory = new SerializerFactory();
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private HessianRemoteResolver remoteResolver;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private Log debugLogger;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private HessianSkeleton skeleton;
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSerializerFactory(@Nullable SerializerFactory serializerFactory)
/*     */   {
/*  86 */     this.serializerFactory = (serializerFactory != null ? serializerFactory : new SerializerFactory());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSendCollectionType(boolean sendCollectionType)
/*     */   {
/*  94 */     this.serializerFactory.setSendCollectionType(sendCollectionType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowNonSerializable(boolean allowNonSerializable)
/*     */   {
/* 102 */     this.serializerFactory.setAllowNonSerializable(allowNonSerializable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteResolver(HessianRemoteResolver remoteResolver)
/*     */   {
/* 110 */     this.remoteResolver = remoteResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDebug(boolean debug)
/*     */   {
/* 119 */     this.debugLogger = (debug ? this.logger : null);
/*     */   }
/*     */   
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 125 */     prepare();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void prepare()
/*     */   {
/* 132 */     checkService();
/* 133 */     checkServiceInterface();
/* 134 */     this.skeleton = new HessianSkeleton(getProxyForService(), getServiceInterface());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void invoke(InputStream inputStream, OutputStream outputStream)
/*     */     throws Throwable
/*     */   {
/* 145 */     Assert.notNull(this.skeleton, "Hessian exporter has not been initialized");
/* 146 */     doInvoke(this.skeleton, inputStream, outputStream);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doInvoke(HessianSkeleton skeleton, InputStream inputStream, OutputStream outputStream)
/*     */     throws Throwable
/*     */   {
/* 159 */     ClassLoader originalClassLoader = overrideThreadContextClassLoader();
/*     */     try {
/* 161 */       InputStream isToUse = inputStream;
/* 162 */       OutputStream osToUse = outputStream;
/*     */       
/* 164 */       if ((this.debugLogger != null) && (this.debugLogger.isDebugEnabled())) {
/* 165 */         PrintWriter debugWriter = new PrintWriter(new CommonsLogWriter(this.debugLogger));Throwable localThrowable3 = null;
/*     */         try {
/* 167 */           HessianDebugInputStream dis = new HessianDebugInputStream(inputStream, debugWriter);
/*     */           
/* 169 */           HessianDebugOutputStream dos = new HessianDebugOutputStream(outputStream, debugWriter);
/* 170 */           dis.startTop2();
/* 171 */           dos.startTop2();
/* 172 */           isToUse = dis;
/* 173 */           osToUse = dos;
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 165 */           localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/*     */ 
/* 174 */           if (debugWriter != null) if (localThrowable3 != null) try { debugWriter.close(); } catch (Throwable localThrowable2) {} else debugWriter.close();
/*     */         }
/*     */       }
/* 177 */       if (!isToUse.markSupported()) {
/* 178 */         isToUse = new BufferedInputStream(isToUse);
/* 179 */         isToUse.mark(1);
/*     */       }
/*     */       
/* 182 */       int code = isToUse.read();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 189 */       if (code == 72)
/*     */       {
/* 191 */         int major = isToUse.read();
/* 192 */         int minor = isToUse.read();
/* 193 */         if (major != 2) {
/* 194 */           throw new IOException("Version " + major + '.' + minor + " is not understood");
/*     */         }
/* 196 */         AbstractHessianInput in = new Hessian2Input(isToUse);
/* 197 */         Object out = new Hessian2Output(osToUse);
/* 198 */         in.readCall();
/*     */       }
/* 200 */       else if (code == 67)
/*     */       {
/* 202 */         isToUse.reset();
/* 203 */         AbstractHessianInput in = new Hessian2Input(isToUse);
/* 204 */         Object out = new Hessian2Output(osToUse);
/* 205 */         in.readCall();
/*     */       } else { Object out;
/* 207 */         if (code == 99)
/*     */         {
/* 209 */           int major = isToUse.read();
/* 210 */           int minor = isToUse.read();
/* 211 */           AbstractHessianInput in = new HessianInput(isToUse);
/* 212 */           Object out; if (major >= 2) {
/* 213 */             out = new Hessian2Output(osToUse);
/*     */           }
/*     */           else {
/* 216 */             out = new HessianOutput(osToUse);
/*     */           }
/*     */         }
/*     */         else {
/* 220 */           throw new IOException("Expected 'H'/'C' (Hessian 2.0) or 'c' (Hessian 1.0) in hessian input at " + code); } }
/*     */       AbstractHessianOutput out;
/*     */       AbstractHessianInput in;
/* 223 */       in.setSerializerFactory(this.serializerFactory);
/* 224 */       out.setSerializerFactory(this.serializerFactory);
/* 225 */       if (this.remoteResolver != null) {
/* 226 */         in.setRemoteResolver(this.remoteResolver);
/*     */       }
/*     */       try
/*     */       {
/* 230 */         skeleton.invoke(in, out);
/*     */         
/*     */         try
/*     */         {
/* 234 */           in.close();
/* 235 */           isToUse.close();
/*     */         }
/*     */         catch (IOException localIOException) {}
/*     */         
/*     */         try
/*     */         {
/* 241 */           out.close();
/* 242 */           osToUse.close();
/*     */         }
/*     */         catch (IOException localIOException1) {}
/*     */       }
/*     */       finally
/*     */       {
/*     */         try
/*     */         {
/* 234 */           in.close();
/* 235 */           isToUse.close();
/*     */         }
/*     */         catch (IOException localIOException2) {}
/*     */         
/*     */         try
/*     */         {
/* 241 */           out.close();
/* 242 */           osToUse.close();
/*     */ 
/*     */         }
/*     */         catch (IOException localIOException3) {}
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 250 */       resetThreadContextClassLoader(originalClassLoader);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\remoting\caucho\HessianExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */