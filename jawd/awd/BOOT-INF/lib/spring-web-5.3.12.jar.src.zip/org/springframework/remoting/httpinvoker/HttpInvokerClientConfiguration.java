package org.springframework.remoting.httpinvoker;

import org.springframework.lang.Nullable;

@Deprecated
public abstract interface HttpInvokerClientConfiguration
{
  public abstract String getServiceUrl();
  
  @Nullable
  public abstract String getCodebaseUrl();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\remoting\httpinvoker\HttpInvokerClientConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */