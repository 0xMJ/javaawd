/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.remoting.rmi.RemoteInvocationSerializingExporter;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ import org.springframework.web.HttpRequestHandler;
/*     */ import org.springframework.web.util.NestedServletException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class HttpInvokerServiceExporter
/*     */   extends RemoteInvocationSerializingExporter
/*     */   implements HttpRequestHandler
/*     */ {
/*     */   public void handleRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*     */     try
/*     */     {
/*  77 */       RemoteInvocation invocation = readRemoteInvocation(request);
/*  78 */       RemoteInvocationResult result = invokeAndCreateResult(invocation, getProxy());
/*  79 */       writeRemoteInvocationResult(request, response, result);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  82 */       throw new NestedServletException("Class not found during deserialization", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RemoteInvocation readRemoteInvocation(HttpServletRequest request)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  98 */     return readRemoteInvocation(request, request.getInputStream());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RemoteInvocation readRemoteInvocation(HttpServletRequest request, InputStream is)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 117 */     ObjectInputStream ois = createObjectInputStream(decorateInputStream(request, is));Throwable localThrowable3 = null;
/* 118 */     try { return doReadRemoteInvocation(ois);
/*     */     }
/*     */     catch (Throwable localThrowable4)
/*     */     {
/* 117 */       localThrowable3 = localThrowable4;throw localThrowable4;
/*     */     } finally {
/* 119 */       if (ois != null) { if (localThrowable3 != null) try { ois.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else { ois.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected InputStream decorateInputStream(HttpServletRequest request, InputStream is)
/*     */     throws IOException
/*     */   {
/* 133 */     return is;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeRemoteInvocationResult(HttpServletRequest request, HttpServletResponse response, RemoteInvocationResult result)
/*     */     throws IOException
/*     */   {
/* 147 */     response.setContentType(getContentType());
/* 148 */     writeRemoteInvocationResult(request, response, result, response.getOutputStream());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeRemoteInvocationResult(HttpServletRequest request, HttpServletResponse response, RemoteInvocationResult result, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 171 */     ObjectOutputStream oos = createObjectOutputStream(new FlushGuardedOutputStream(decorateOutputStream(request, response, os)));Throwable localThrowable3 = null;
/* 172 */     try { doWriteRemoteInvocationResult(result, oos);
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 170 */       localThrowable3 = localThrowable1;throw localThrowable1;
/*     */     }
/*     */     finally {
/* 173 */       if (oos != null) { if (localThrowable3 != null) try { oos.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else { oos.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected OutputStream decorateOutputStream(HttpServletRequest request, HttpServletResponse response, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 190 */     return os;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class FlushGuardedOutputStream
/*     */     extends FilterOutputStream
/*     */   {
/*     */     public FlushGuardedOutputStream(OutputStream out)
/*     */     {
/* 206 */       super();
/*     */     }
/*     */     
/*     */     public void flush()
/*     */       throws IOException
/*     */     {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\remoting\httpinvoker\HttpInvokerServiceExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */