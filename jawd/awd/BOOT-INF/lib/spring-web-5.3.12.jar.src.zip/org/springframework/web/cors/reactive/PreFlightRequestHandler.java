package org.springframework.web.cors.reactive;

import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

public abstract interface PreFlightRequestHandler
{
  public abstract Mono<Void> handlePreFlight(ServerWebExchange paramServerWebExchange);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\cors\reactive\PreFlightRequestHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */