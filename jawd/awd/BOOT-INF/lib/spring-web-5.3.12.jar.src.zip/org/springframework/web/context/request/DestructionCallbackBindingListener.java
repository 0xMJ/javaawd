/*    */ package org.springframework.web.context.request;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.servlet.http.HttpSessionBindingEvent;
/*    */ import javax.servlet.http.HttpSessionBindingListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DestructionCallbackBindingListener
/*    */   implements HttpSessionBindingListener, Serializable
/*    */ {
/*    */   private final Runnable destructionCallback;
/*    */   
/*    */   public DestructionCallbackBindingListener(Runnable destructionCallback)
/*    */   {
/* 45 */     this.destructionCallback = destructionCallback;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void valueBound(HttpSessionBindingEvent event) {}
/*    */   
/*    */ 
/*    */   public void valueUnbound(HttpSessionBindingEvent event)
/*    */   {
/* 55 */     this.destructionCallback.run();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\request\DestructionCallbackBindingListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */