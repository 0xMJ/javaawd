/*    */ package org.springframework.web.bind.support;
/*    */ 
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorFactory;
/*    */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*    */ import org.springframework.web.context.ContextLoader;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringWebConstraintValidatorFactory
/*    */   implements ConstraintValidatorFactory
/*    */ {
/*    */   public <T extends ConstraintValidator<?, ?>> T getInstance(Class<T> key)
/*    */   {
/* 44 */     return (ConstraintValidator)getWebApplicationContext().getAutowireCapableBeanFactory().createBean(key);
/*    */   }
/*    */   
/*    */ 
/*    */   public void releaseInstance(ConstraintValidator<?, ?> instance)
/*    */   {
/* 50 */     getWebApplicationContext().getAutowireCapableBeanFactory().destroyBean(instance);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected WebApplicationContext getWebApplicationContext()
/*    */   {
/* 62 */     WebApplicationContext wac = ContextLoader.getCurrentWebApplicationContext();
/* 63 */     if (wac == null) {
/* 64 */       throw new IllegalStateException("No WebApplicationContext registered for current thread - consider overriding SpringWebConstraintValidatorFactory.getWebApplicationContext()");
/*    */     }
/*    */     
/* 67 */     return wac;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\bind\support\SpringWebConstraintValidatorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */