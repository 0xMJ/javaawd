package org.springframework.web.context.request;

import org.springframework.lang.Nullable;

public abstract interface NativeWebRequest
  extends WebRequest
{
  public abstract Object getNativeRequest();
  
  @Nullable
  public abstract Object getNativeResponse();
  
  @Nullable
  public abstract <T> T getNativeRequest(@Nullable Class<T> paramClass);
  
  @Nullable
  public abstract <T> T getNativeResponse(@Nullable Class<T> paramClass);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\request\NativeWebRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */