/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OncePerRequestFilter
/*     */   extends GenericFilterBean
/*     */ {
/*     */   public static final String ALREADY_FILTERED_SUFFIX = ".FILTERED";
/*     */   
/*     */   public final void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/*  91 */     if ((!(request instanceof HttpServletRequest)) || (!(response instanceof HttpServletResponse))) {
/*  92 */       throw new ServletException("OncePerRequestFilter just supports HTTP requests");
/*     */     }
/*  94 */     HttpServletRequest httpRequest = (HttpServletRequest)request;
/*  95 */     HttpServletResponse httpResponse = (HttpServletResponse)response;
/*     */     
/*  97 */     String alreadyFilteredAttributeName = getAlreadyFilteredAttributeName();
/*  98 */     boolean hasAlreadyFilteredAttribute = request.getAttribute(alreadyFilteredAttributeName) != null;
/*     */     
/* 100 */     if ((skipDispatch(httpRequest)) || (shouldNotFilter(httpRequest)))
/*     */     {
/*     */ 
/* 103 */       filterChain.doFilter(request, response);
/*     */     }
/* 105 */     else if (hasAlreadyFilteredAttribute)
/*     */     {
/* 107 */       if (DispatcherType.ERROR.equals(request.getDispatcherType())) {
/* 108 */         doFilterNestedErrorDispatch(httpRequest, httpResponse, filterChain);
/* 109 */         return;
/*     */       }
/*     */       
/*     */ 
/* 113 */       filterChain.doFilter(request, response);
/*     */     }
/*     */     else
/*     */     {
/* 117 */       request.setAttribute(alreadyFilteredAttributeName, Boolean.TRUE);
/*     */       try {
/* 119 */         doFilterInternal(httpRequest, httpResponse, filterChain);
/*     */       }
/*     */       finally
/*     */       {
/* 123 */         request.removeAttribute(alreadyFilteredAttributeName);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean skipDispatch(HttpServletRequest request) {
/* 129 */     if ((isAsyncDispatch(request)) && (shouldNotFilterAsyncDispatch())) {
/* 130 */       return true;
/*     */     }
/* 132 */     if ((request.getAttribute("javax.servlet.error.request_uri") != null) && (shouldNotFilterErrorDispatch())) {
/* 133 */       return true;
/*     */     }
/* 135 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isAsyncDispatch(HttpServletRequest request)
/*     */   {
/* 148 */     return DispatcherType.ASYNC.equals(request.getDispatcherType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isAsyncStarted(HttpServletRequest request)
/*     */   {
/* 159 */     return WebAsyncUtils.getAsyncManager(request).isConcurrentHandlingStarted();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getAlreadyFilteredAttributeName()
/*     */   {
/* 172 */     String name = getFilterName();
/* 173 */     if (name == null) {
/* 174 */       name = getClass().getName();
/*     */     }
/* 176 */     return name + ".FILTERED";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean shouldNotFilter(HttpServletRequest request)
/*     */     throws ServletException
/*     */   {
/* 188 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean shouldNotFilterAsyncDispatch()
/*     */   {
/* 209 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean shouldNotFilterErrorDispatch()
/*     */   {
/* 220 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void doFilterInternal(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, FilterChain paramFilterChain)
/*     */     throws ServletException, IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doFilterNestedErrorDispatch(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 251 */     filterChain.doFilter(request, response);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\filter\OncePerRequestFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */