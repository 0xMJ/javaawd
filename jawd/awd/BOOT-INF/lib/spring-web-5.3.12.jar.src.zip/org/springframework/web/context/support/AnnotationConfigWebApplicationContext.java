/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.annotation.AnnotatedBeanDefinitionReader;
/*     */ import org.springframework.context.annotation.AnnotationConfigRegistry;
/*     */ import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
/*     */ import org.springframework.context.annotation.ScopeMetadataResolver;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationConfigWebApplicationContext
/*     */   extends AbstractRefreshableWebApplicationContext
/*     */   implements AnnotationConfigRegistry
/*     */ {
/*     */   @Nullable
/*     */   private BeanNameGenerator beanNameGenerator;
/*     */   @Nullable
/*     */   private ScopeMetadataResolver scopeMetadataResolver;
/*  95 */   private final Set<Class<?>> componentClasses = new LinkedHashSet();
/*     */   
/*  97 */   private final Set<String> basePackages = new LinkedHashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeanNameGenerator(@Nullable BeanNameGenerator beanNameGenerator)
/*     */   {
/* 108 */     this.beanNameGenerator = beanNameGenerator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected BeanNameGenerator getBeanNameGenerator()
/*     */   {
/* 117 */     return this.beanNameGenerator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScopeMetadataResolver(@Nullable ScopeMetadataResolver scopeMetadataResolver)
/*     */   {
/* 128 */     this.scopeMetadataResolver = scopeMetadataResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected ScopeMetadataResolver getScopeMetadataResolver()
/*     */   {
/* 137 */     return this.scopeMetadataResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void register(Class<?>... componentClasses)
/*     */   {
/* 154 */     Assert.notEmpty(componentClasses, "At least one component class must be specified");
/* 155 */     Collections.addAll(this.componentClasses, componentClasses);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void scan(String... basePackages)
/*     */   {
/* 170 */     Assert.notEmpty(basePackages, "At least one base package must be specified");
/* 171 */     Collections.addAll(this.basePackages, basePackages);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void loadBeanDefinitions(DefaultListableBeanFactory beanFactory)
/*     */   {
/* 199 */     AnnotatedBeanDefinitionReader reader = getAnnotatedBeanDefinitionReader(beanFactory);
/* 200 */     ClassPathBeanDefinitionScanner scanner = getClassPathBeanDefinitionScanner(beanFactory);
/*     */     
/* 202 */     BeanNameGenerator beanNameGenerator = getBeanNameGenerator();
/* 203 */     if (beanNameGenerator != null) {
/* 204 */       reader.setBeanNameGenerator(beanNameGenerator);
/* 205 */       scanner.setBeanNameGenerator(beanNameGenerator);
/* 206 */       beanFactory.registerSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator", beanNameGenerator);
/*     */     }
/*     */     
/* 209 */     ScopeMetadataResolver scopeMetadataResolver = getScopeMetadataResolver();
/* 210 */     if (scopeMetadataResolver != null) {
/* 211 */       reader.setScopeMetadataResolver(scopeMetadataResolver);
/* 212 */       scanner.setScopeMetadataResolver(scopeMetadataResolver);
/*     */     }
/*     */     
/* 215 */     if (!this.componentClasses.isEmpty()) {
/* 216 */       if (this.logger.isDebugEnabled()) {
/* 217 */         this.logger.debug("Registering component classes: [" + 
/* 218 */           StringUtils.collectionToCommaDelimitedString(this.componentClasses) + "]");
/*     */       }
/* 220 */       reader.register(ClassUtils.toClassArray(this.componentClasses));
/*     */     }
/*     */     
/* 223 */     if (!this.basePackages.isEmpty()) {
/* 224 */       if (this.logger.isDebugEnabled()) {
/* 225 */         this.logger.debug("Scanning base packages: [" + 
/* 226 */           StringUtils.collectionToCommaDelimitedString(this.basePackages) + "]");
/*     */       }
/* 228 */       scanner.scan(StringUtils.toStringArray(this.basePackages));
/*     */     }
/*     */     
/* 231 */     String[] configLocations = getConfigLocations();
/* 232 */     if (configLocations != null) {
/* 233 */       for (String configLocation : configLocations) {
/*     */         try {
/* 235 */           Class<?> clazz = ClassUtils.forName(configLocation, getClassLoader());
/* 236 */           if (this.logger.isTraceEnabled()) {
/* 237 */             this.logger.trace("Registering [" + configLocation + "]");
/*     */           }
/* 239 */           reader.register(new Class[] { clazz });
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 242 */           if (this.logger.isTraceEnabled()) {
/* 243 */             this.logger.trace("Could not load class for config location [" + configLocation + "] - trying package scan. " + ex);
/*     */           }
/*     */           
/* 246 */           int count = scanner.scan(new String[] { configLocation });
/* 247 */           if ((count == 0) && (this.logger.isDebugEnabled())) {
/* 248 */             this.logger.debug("No component classes found for specified class/package [" + configLocation + "]");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AnnotatedBeanDefinitionReader getAnnotatedBeanDefinitionReader(DefaultListableBeanFactory beanFactory)
/*     */   {
/* 267 */     return new AnnotatedBeanDefinitionReader(beanFactory, getEnvironment());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ClassPathBeanDefinitionScanner getClassPathBeanDefinitionScanner(DefaultListableBeanFactory beanFactory)
/*     */   {
/* 281 */     return new ClassPathBeanDefinitionScanner(beanFactory, true, getEnvironment());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\support\AnnotationConfigWebApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */