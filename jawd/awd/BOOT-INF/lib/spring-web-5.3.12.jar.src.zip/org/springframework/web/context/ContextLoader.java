/*     */ package org.springframework.web.context;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextLoader
/*     */ {
/*     */   public static final String CONTEXT_ID_PARAM = "contextId";
/*     */   public static final String CONFIG_LOCATION_PARAM = "contextConfigLocation";
/*     */   public static final String CONTEXT_CLASS_PARAM = "contextClass";
/*     */   public static final String CONTEXT_INITIALIZER_CLASSES_PARAM = "contextInitializerClasses";
/*     */   public static final String GLOBAL_INITIALIZER_CLASSES_PARAM = "globalInitializerClasses";
/*     */   private static final String INIT_PARAM_DELIMITERS = ",; \t\n";
/*     */   private static final String DEFAULT_STRATEGIES_PATH = "ContextLoader.properties";
/*     */   private static final Properties defaultStrategies;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 143 */       ClassPathResource resource = new ClassPathResource("ContextLoader.properties", ContextLoader.class);
/* 144 */       defaultStrategies = PropertiesLoaderUtils.loadProperties(resource);
/*     */     }
/*     */     catch (IOException ex) {
/* 147 */       throw new IllegalStateException("Could not load 'ContextLoader.properties': " + ex.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */   private static final Map<ClassLoader, WebApplicationContext> currentContextPerThread = new ConcurrentHashMap(1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private static volatile WebApplicationContext currentContext;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private WebApplicationContext context;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 173 */   private final List<ApplicationContextInitializer<ConfigurableApplicationContext>> contextInitializers = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContextLoader(WebApplicationContext context)
/*     */   {
/* 229 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContextInitializers(@Nullable ApplicationContextInitializer<?>... initializers)
/*     */   {
/* 242 */     if (initializers != null) {
/* 243 */       for (ApplicationContextInitializer<?> initializer : initializers) {
/* 244 */         this.contextInitializers.add(initializer);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebApplicationContext initWebApplicationContext(ServletContext servletContext)
/*     */   {
/* 262 */     if (servletContext.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE) != null) {
/* 263 */       throw new IllegalStateException("Cannot initialize context because there is already a root application context present - check whether you have multiple ContextLoader* definitions in your web.xml!");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 268 */     servletContext.log("Initializing Spring root WebApplicationContext");
/* 269 */     Log logger = LogFactory.getLog(ContextLoader.class);
/* 270 */     if (logger.isInfoEnabled()) {
/* 271 */       logger.info("Root WebApplicationContext: initialization started");
/*     */     }
/* 273 */     long startTime = System.currentTimeMillis();
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 278 */       if (this.context == null) {
/* 279 */         this.context = createWebApplicationContext(servletContext);
/*     */       }
/* 281 */       if ((this.context instanceof ConfigurableWebApplicationContext)) {
/* 282 */         ConfigurableWebApplicationContext cwac = (ConfigurableWebApplicationContext)this.context;
/* 283 */         if (!cwac.isActive())
/*     */         {
/*     */ 
/* 286 */           if (cwac.getParent() == null)
/*     */           {
/*     */ 
/* 289 */             ApplicationContext parent = loadParentContext(servletContext);
/* 290 */             cwac.setParent(parent);
/*     */           }
/* 292 */           configureAndRefreshWebApplicationContext(cwac, servletContext);
/*     */         }
/*     */       }
/* 295 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, this.context);
/*     */       
/* 297 */       ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 298 */       if (ccl == ContextLoader.class.getClassLoader()) {
/* 299 */         currentContext = this.context;
/*     */       }
/* 301 */       else if (ccl != null) {
/* 302 */         currentContextPerThread.put(ccl, this.context);
/*     */       }
/*     */       
/* 305 */       if (logger.isInfoEnabled()) {
/* 306 */         long elapsedTime = System.currentTimeMillis() - startTime;
/* 307 */         logger.info("Root WebApplicationContext initialized in " + elapsedTime + " ms");
/*     */       }
/*     */       
/* 310 */       return this.context;
/*     */     }
/*     */     catch (RuntimeException|Error ex) {
/* 313 */       logger.error("Context initialization failed", ex);
/* 314 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, ex);
/* 315 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected WebApplicationContext createWebApplicationContext(ServletContext sc)
/*     */   {
/* 332 */     Class<?> contextClass = determineContextClass(sc);
/* 333 */     if (!ConfigurableWebApplicationContext.class.isAssignableFrom(contextClass))
/*     */     {
/* 335 */       throw new ApplicationContextException("Custom context class [" + contextClass.getName() + "] is not of type [" + ConfigurableWebApplicationContext.class.getName() + "]");
/*     */     }
/* 337 */     return (ConfigurableWebApplicationContext)BeanUtils.instantiateClass(contextClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> determineContextClass(ServletContext servletContext)
/*     */   {
/* 349 */     String contextClassName = servletContext.getInitParameter("contextClass");
/* 350 */     if (contextClassName != null) {
/*     */       try {
/* 352 */         return ClassUtils.forName(contextClassName, ClassUtils.getDefaultClassLoader());
/*     */       }
/*     */       catch (ClassNotFoundException ex) {
/* 355 */         throw new ApplicationContextException("Failed to load custom context class [" + contextClassName + "]", ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 360 */     contextClassName = defaultStrategies.getProperty(WebApplicationContext.class.getName());
/*     */     try {
/* 362 */       return ClassUtils.forName(contextClassName, ContextLoader.class.getClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 365 */       throw new ApplicationContextException("Failed to load default context class [" + contextClassName + "]", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void configureAndRefreshWebApplicationContext(ConfigurableWebApplicationContext wac, ServletContext sc)
/*     */   {
/* 372 */     if (ObjectUtils.identityToString(wac).equals(wac.getId()))
/*     */     {
/*     */ 
/* 375 */       String idParam = sc.getInitParameter("contextId");
/* 376 */       if (idParam != null) {
/* 377 */         wac.setId(idParam);
/*     */       }
/*     */       else
/*     */       {
/* 381 */         wac.setId(ConfigurableWebApplicationContext.APPLICATION_CONTEXT_ID_PREFIX + 
/* 382 */           ObjectUtils.getDisplayString(sc.getContextPath()));
/*     */       }
/*     */     }
/*     */     
/* 386 */     wac.setServletContext(sc);
/* 387 */     String configLocationParam = sc.getInitParameter("contextConfigLocation");
/* 388 */     if (configLocationParam != null) {
/* 389 */       wac.setConfigLocation(configLocationParam);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 395 */     ConfigurableEnvironment env = wac.getEnvironment();
/* 396 */     if ((env instanceof ConfigurableWebEnvironment)) {
/* 397 */       ((ConfigurableWebEnvironment)env).initPropertySources(sc, null);
/*     */     }
/*     */     
/* 400 */     customizeContext(sc, wac);
/* 401 */     wac.refresh();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void customizeContext(ServletContext sc, ConfigurableWebApplicationContext wac)
/*     */   {
/* 423 */     List<Class<ApplicationContextInitializer<ConfigurableApplicationContext>>> initializerClasses = determineContextInitializerClasses(sc);
/*     */     
/* 425 */     for (Class<ApplicationContextInitializer<ConfigurableApplicationContext>> initializerClass : initializerClasses)
/*     */     {
/* 427 */       Class<?> initializerContextClass = GenericTypeResolver.resolveTypeArgument(initializerClass, ApplicationContextInitializer.class);
/* 428 */       if ((initializerContextClass != null) && (!initializerContextClass.isInstance(wac))) {
/* 429 */         throw new ApplicationContextException(String.format("Could not apply context initializer [%s] since its generic parameter [%s] is not assignable from the type of application context used by this context loader: [%s]", new Object[] {initializerClass
/*     */         
/*     */ 
/* 432 */           .getName(), initializerContextClass.getName(), wac
/* 433 */           .getClass().getName() }));
/*     */       }
/* 435 */       this.contextInitializers.add(BeanUtils.instantiateClass(initializerClass));
/*     */     }
/*     */     
/* 438 */     AnnotationAwareOrderComparator.sort(this.contextInitializers);
/* 439 */     for (ApplicationContextInitializer<ConfigurableApplicationContext> initializer : this.contextInitializers) {
/* 440 */       initializer.initialize(wac);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<Class<ApplicationContextInitializer<ConfigurableApplicationContext>>> determineContextInitializerClasses(ServletContext servletContext)
/*     */   {
/* 453 */     List<Class<ApplicationContextInitializer<ConfigurableApplicationContext>>> classes = new ArrayList();
/*     */     
/*     */ 
/* 456 */     String globalClassNames = servletContext.getInitParameter("globalInitializerClasses");
/* 457 */     String str1; String className; if (globalClassNames != null) {
/* 458 */       String[] arrayOfString1 = StringUtils.tokenizeToStringArray(globalClassNames, ",; \t\n");int i = arrayOfString1.length; for (str1 = 0; str1 < i; str1++) { className = arrayOfString1[str1];
/* 459 */         classes.add(loadInitializerClass(className));
/*     */       }
/*     */     }
/*     */     
/* 463 */     String localClassNames = servletContext.getInitParameter("contextInitializerClasses");
/* 464 */     if (localClassNames != null) {
/* 465 */       String[] arrayOfString2 = StringUtils.tokenizeToStringArray(localClassNames, ",; \t\n");str1 = arrayOfString2.length; for (className = 0; className < str1; className++) { String className = arrayOfString2[className];
/* 466 */         classes.add(loadInitializerClass(className));
/*     */       }
/*     */     }
/*     */     
/* 470 */     return classes;
/*     */   }
/*     */   
/*     */   private Class<ApplicationContextInitializer<ConfigurableApplicationContext>> loadInitializerClass(String className)
/*     */   {
/*     */     try {
/* 476 */       Class<?> clazz = ClassUtils.forName(className, ClassUtils.getDefaultClassLoader());
/* 477 */       if (!ApplicationContextInitializer.class.isAssignableFrom(clazz)) {
/* 478 */         throw new ApplicationContextException("Initializer class does not implement ApplicationContextInitializer interface: " + clazz);
/*     */       }
/*     */       
/* 481 */       return clazz;
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 484 */       throw new ApplicationContextException("Failed to load context initializer class [" + className + "]", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected ApplicationContext loadParentContext(ServletContext servletContext)
/*     */   {
/* 504 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public static WebApplicationContext getCurrentWebApplicationContext()
/*     */   {
/* 543 */     ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 544 */     if (ccl != null) {
/* 545 */       WebApplicationContext ccpt = (WebApplicationContext)currentContextPerThread.get(ccl);
/* 546 */       if (ccpt != null) {
/* 547 */         return ccpt;
/*     */       }
/*     */     }
/* 550 */     return currentContext;
/*     */   }
/*     */   
/*     */   public ContextLoader() {}
/*     */   
/*     */   /* Error */
/*     */   public void closeWebApplicationContext(ServletContext servletContext)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 103
/*     */     //   3: invokeinterface 13 2 0
/*     */     //   8: aload_0
/*     */     //   9: getfield 5	org/springframework/web/context/ContextLoader:context	Lorg/springframework/web/context/WebApplicationContext;
/*     */     //   12: instanceof 21
/*     */     //   15: ifeq +15 -> 30
/*     */     //   18: aload_0
/*     */     //   19: getfield 5	org/springframework/web/context/ContextLoader:context	Lorg/springframework/web/context/WebApplicationContext;
/*     */     //   22: checkcast 21	org/springframework/web/context/ConfigurableWebApplicationContext
/*     */     //   25: invokeinterface 104 1 0
/*     */     //   30: invokestatic 28	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   33: invokevirtual 29	java/lang/Thread:getContextClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   36: astore_2
/*     */     //   37: aload_2
/*     */     //   38: ldc 14
/*     */     //   40: invokevirtual 30	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   43: if_acmpne +10 -> 53
/*     */     //   46: aconst_null
/*     */     //   47: putstatic 31	org/springframework/web/context/ContextLoader:currentContext	Lorg/springframework/web/context/WebApplicationContext;
/*     */     //   50: goto +17 -> 67
/*     */     //   53: aload_2
/*     */     //   54: ifnull +13 -> 67
/*     */     //   57: getstatic 32	org/springframework/web/context/ContextLoader:currentContextPerThread	Ljava/util/Map;
/*     */     //   60: aload_2
/*     */     //   61: invokeinterface 105 2 0
/*     */     //   66: pop
/*     */     //   67: aload_1
/*     */     //   68: getstatic 7	org/springframework/web/context/WebApplicationContext:ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE	Ljava/lang/String;
/*     */     //   71: invokeinterface 106 2 0
/*     */     //   76: goto +56 -> 132
/*     */     //   79: astore_3
/*     */     //   80: invokestatic 28	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   83: invokevirtual 29	java/lang/Thread:getContextClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   86: astore 4
/*     */     //   88: aload 4
/*     */     //   90: ldc 14
/*     */     //   92: invokevirtual 30	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   95: if_acmpne +10 -> 105
/*     */     //   98: aconst_null
/*     */     //   99: putstatic 31	org/springframework/web/context/ContextLoader:currentContext	Lorg/springframework/web/context/WebApplicationContext;
/*     */     //   102: goto +19 -> 121
/*     */     //   105: aload 4
/*     */     //   107: ifnull +14 -> 121
/*     */     //   110: getstatic 32	org/springframework/web/context/ContextLoader:currentContextPerThread	Ljava/util/Map;
/*     */     //   113: aload 4
/*     */     //   115: invokeinterface 105 2 0
/*     */     //   120: pop
/*     */     //   121: aload_1
/*     */     //   122: getstatic 7	org/springframework/web/context/WebApplicationContext:ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE	Ljava/lang/String;
/*     */     //   125: invokeinterface 106 2 0
/*     */     //   130: aload_3
/*     */     //   131: athrow
/*     */     //   132: return
/*     */     // Line number table:
/*     */     //   Java source line #514	-> byte code offset #0
/*     */     //   Java source line #516	-> byte code offset #8
/*     */     //   Java source line #517	-> byte code offset #18
/*     */     //   Java source line #521	-> byte code offset #30
/*     */     //   Java source line #522	-> byte code offset #37
/*     */     //   Java source line #523	-> byte code offset #46
/*     */     //   Java source line #525	-> byte code offset #53
/*     */     //   Java source line #526	-> byte code offset #57
/*     */     //   Java source line #528	-> byte code offset #67
/*     */     //   Java source line #529	-> byte code offset #76
/*     */     //   Java source line #521	-> byte code offset #79
/*     */     //   Java source line #522	-> byte code offset #88
/*     */     //   Java source line #523	-> byte code offset #98
/*     */     //   Java source line #525	-> byte code offset #105
/*     */     //   Java source line #526	-> byte code offset #110
/*     */     //   Java source line #528	-> byte code offset #121
/*     */     //   Java source line #529	-> byte code offset #130
/*     */     //   Java source line #530	-> byte code offset #132
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	133	0	this	ContextLoader
/*     */     //   0	133	1	servletContext	ServletContext
/*     */     //   36	25	2	ccl	ClassLoader
/*     */     //   79	52	3	localObject	Object
/*     */     //   86	28	4	ccl	ClassLoader
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   8	30	79	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\ContextLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */