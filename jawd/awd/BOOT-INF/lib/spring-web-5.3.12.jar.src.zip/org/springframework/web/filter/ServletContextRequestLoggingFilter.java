/*    */ package org.springframework.web.filter;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletContextRequestLoggingFilter
/*    */   extends AbstractRequestLoggingFilter
/*    */ {
/*    */   protected void beforeRequest(HttpServletRequest request, String message)
/*    */   {
/* 41 */     getServletContext().log(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void afterRequest(HttpServletRequest request, String message)
/*    */   {
/* 49 */     getServletContext().log(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\filter\ServletContextRequestLoggingFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */