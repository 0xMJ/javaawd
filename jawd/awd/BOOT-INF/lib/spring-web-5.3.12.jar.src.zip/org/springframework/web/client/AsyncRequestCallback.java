package org.springframework.web.client;

import java.io.IOException;
import org.springframework.http.client.AsyncClientHttpRequest;

@FunctionalInterface
@Deprecated
public abstract interface AsyncRequestCallback
{
  public abstract void doWithRequest(AsyncClientHttpRequest paramAsyncClientHttpRequest)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\client\AsyncRequestCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */