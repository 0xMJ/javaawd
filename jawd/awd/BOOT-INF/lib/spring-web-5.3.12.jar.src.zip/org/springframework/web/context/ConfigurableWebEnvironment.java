package org.springframework.web.context;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.lang.Nullable;

public abstract interface ConfigurableWebEnvironment
  extends ConfigurableEnvironment
{
  public abstract void initPropertySources(@Nullable ServletContext paramServletContext, @Nullable ServletConfig paramServletConfig);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\ConfigurableWebEnvironment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */