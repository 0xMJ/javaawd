package org.springframework.web.bind.annotation;

public enum RequestMethod
{
  GET,  HEAD,  POST,  PUT,  PATCH,  DELETE,  OPTIONS,  TRACE;
  
  private RequestMethod() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\bind\annotation\RequestMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */