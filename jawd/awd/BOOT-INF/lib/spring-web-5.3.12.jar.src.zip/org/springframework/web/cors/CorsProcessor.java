package org.springframework.web.cors;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.lang.Nullable;

public abstract interface CorsProcessor
{
  public abstract boolean processRequest(@Nullable CorsConfiguration paramCorsConfiguration, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\cors\CorsProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */