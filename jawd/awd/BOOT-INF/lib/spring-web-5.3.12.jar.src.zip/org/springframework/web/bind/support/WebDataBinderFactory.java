package org.springframework.web.bind.support;

import org.springframework.lang.Nullable;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.context.request.NativeWebRequest;

public abstract interface WebDataBinderFactory
{
  public abstract WebDataBinder createBinder(NativeWebRequest paramNativeWebRequest, @Nullable Object paramObject, String paramString)
    throws Exception;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\bind\support\WebDataBinderFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */