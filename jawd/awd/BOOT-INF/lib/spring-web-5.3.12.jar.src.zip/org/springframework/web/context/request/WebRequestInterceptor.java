package org.springframework.web.context.request;

import org.springframework.lang.Nullable;
import org.springframework.ui.ModelMap;

public abstract interface WebRequestInterceptor
{
  public abstract void preHandle(WebRequest paramWebRequest)
    throws Exception;
  
  public abstract void postHandle(WebRequest paramWebRequest, @Nullable ModelMap paramModelMap)
    throws Exception;
  
  public abstract void afterCompletion(WebRequest paramWebRequest, @Nullable Exception paramException)
    throws Exception;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\request\WebRequestInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */