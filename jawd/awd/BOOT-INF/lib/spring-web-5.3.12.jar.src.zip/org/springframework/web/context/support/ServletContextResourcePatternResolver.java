/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.UrlResource;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletContextResourcePatternResolver
/*     */   extends PathMatchingResourcePatternResolver
/*     */ {
/*  49 */   private static final Log logger = LogFactory.getLog(ServletContextResourcePatternResolver.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletContextResourcePatternResolver(ServletContext servletContext)
/*     */   {
/*  58 */     super(new ServletContextResourceLoader(servletContext));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletContextResourcePatternResolver(ResourceLoader resourceLoader)
/*     */   {
/*  67 */     super(resourceLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<Resource> doFindPathMatchingFileResources(Resource rootDirResource, String subPattern)
/*     */     throws IOException
/*     */   {
/*  84 */     if ((rootDirResource instanceof ServletContextResource)) {
/*  85 */       ServletContextResource scResource = (ServletContextResource)rootDirResource;
/*  86 */       ServletContext sc = scResource.getServletContext();
/*  87 */       String fullPattern = scResource.getPath() + subPattern;
/*  88 */       Set<Resource> result = new LinkedHashSet(8);
/*  89 */       doRetrieveMatchingServletContextResources(sc, fullPattern, scResource.getPath(), result);
/*  90 */       return result;
/*     */     }
/*     */     
/*  93 */     return super.doFindPathMatchingFileResources(rootDirResource, subPattern);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doRetrieveMatchingServletContextResources(ServletContext servletContext, String fullPattern, String dir, Set<Resource> result)
/*     */     throws IOException
/*     */   {
/* 113 */     Set<String> candidates = servletContext.getResourcePaths(dir);
/* 114 */     boolean dirDepthNotFixed; String jarFilePath; String pathInJarFile; if (candidates != null) {
/* 115 */       dirDepthNotFixed = fullPattern.contains("**");
/* 116 */       int jarFileSep = fullPattern.indexOf("!/");
/* 117 */       jarFilePath = null;
/* 118 */       pathInJarFile = null;
/* 119 */       if ((jarFileSep > 0) && (jarFileSep + "!/".length() < fullPattern.length())) {
/* 120 */         jarFilePath = fullPattern.substring(0, jarFileSep);
/* 121 */         pathInJarFile = fullPattern.substring(jarFileSep + "!/".length());
/*     */       }
/* 123 */       for (String currPath : candidates) {
/* 124 */         if (!currPath.startsWith(dir))
/*     */         {
/*     */ 
/* 127 */           int dirIndex = currPath.indexOf(dir);
/* 128 */           if (dirIndex != -1) {
/* 129 */             currPath = currPath.substring(dirIndex);
/*     */           }
/*     */         }
/* 132 */         if ((currPath.endsWith("/")) && ((dirDepthNotFixed) || 
/* 133 */           (StringUtils.countOccurrencesOf(currPath, "/") <= StringUtils.countOccurrencesOf(fullPattern, "/"))))
/*     */         {
/*     */ 
/* 136 */           doRetrieveMatchingServletContextResources(servletContext, fullPattern, currPath, result);
/*     */         }
/* 138 */         if ((jarFilePath != null) && (getPathMatcher().match(jarFilePath, currPath)))
/*     */         {
/* 140 */           String absoluteJarPath = servletContext.getRealPath(currPath);
/* 141 */           if (absoluteJarPath != null) {
/* 142 */             doRetrieveMatchingJarEntries(absoluteJarPath, pathInJarFile, result);
/*     */           }
/*     */         }
/* 145 */         if (getPathMatcher().match(fullPattern, currPath)) {
/* 146 */           result.add(new ServletContextResource(servletContext, currPath));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void doRetrieveMatchingJarEntries(String jarFilePath, String entryPattern, Set<Resource> result)
/*     */   {
/* 159 */     if (logger.isDebugEnabled())
/* 160 */       logger.debug("Searching jar file [" + jarFilePath + "] for entries matching [" + entryPattern + "]");
/*     */     try {
/* 162 */       JarFile jarFile = new JarFile(jarFilePath);Throwable localThrowable3 = null;
/* 163 */       try { for (entries = jarFile.entries(); entries.hasMoreElements();) {
/* 164 */           JarEntry entry = (JarEntry)entries.nextElement();
/* 165 */           String entryPath = entry.getName();
/* 166 */           if (getPathMatcher().match(entryPattern, entryPath)) {
/* 167 */             result.add(new UrlResource("jar", "file:" + jarFilePath + "!/" + entryPath));
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/*     */         Enumeration<JarEntry> entries;
/* 162 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 172 */         if (jarFile != null) if (localThrowable3 != null) try { jarFile.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else jarFile.close();
/*     */       }
/* 174 */     } catch (IOException ex) { if (logger.isWarnEnabled()) {
/* 175 */         logger.warn("Cannot search for matching resources in jar file [" + jarFilePath + "] because the jar cannot be opened through the file system", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\support\ServletContextResourcePatternResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */