package org.springframework.web.cors.reactive;

import org.springframework.lang.Nullable;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.server.ServerWebExchange;

public abstract interface CorsProcessor
{
  public abstract boolean process(@Nullable CorsConfiguration paramCorsConfiguration, ServerWebExchange paramServerWebExchange);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\cors\reactive\CorsProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */