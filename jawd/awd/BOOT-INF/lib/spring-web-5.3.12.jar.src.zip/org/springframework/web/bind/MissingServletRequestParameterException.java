/*    */ package org.springframework.web.bind;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MissingServletRequestParameterException
/*    */   extends MissingRequestValueException
/*    */ {
/*    */   private final String parameterName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final String parameterType;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MissingServletRequestParameterException(String parameterName, String parameterType)
/*    */   {
/* 39 */     this(parameterName, parameterType, false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MissingServletRequestParameterException(String parameterName, String parameterType, boolean missingAfterConversion)
/*    */   {
/* 52 */     super("", missingAfterConversion);
/* 53 */     this.parameterName = parameterName;
/* 54 */     this.parameterType = parameterType;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 60 */     return 
/*    */     
/* 62 */       "Required request parameter '" + this.parameterName + "' for method parameter type " + this.parameterType + " is " + (isMissingAfterConversion() ? "present but converted to null" : "not present");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final String getParameterName()
/*    */   {
/* 69 */     return this.parameterName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final String getParameterType()
/*    */   {
/* 76 */     return this.parameterType;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\bind\MissingServletRequestParameterException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */