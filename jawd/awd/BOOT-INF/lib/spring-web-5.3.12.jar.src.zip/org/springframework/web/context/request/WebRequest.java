package org.springframework.web.context.request;

import java.security.Principal;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import org.springframework.lang.Nullable;

public abstract interface WebRequest
  extends RequestAttributes
{
  @Nullable
  public abstract String getHeader(String paramString);
  
  @Nullable
  public abstract String[] getHeaderValues(String paramString);
  
  public abstract Iterator<String> getHeaderNames();
  
  @Nullable
  public abstract String getParameter(String paramString);
  
  @Nullable
  public abstract String[] getParameterValues(String paramString);
  
  public abstract Iterator<String> getParameterNames();
  
  public abstract Map<String, String[]> getParameterMap();
  
  public abstract Locale getLocale();
  
  public abstract String getContextPath();
  
  @Nullable
  public abstract String getRemoteUser();
  
  @Nullable
  public abstract Principal getUserPrincipal();
  
  public abstract boolean isUserInRole(String paramString);
  
  public abstract boolean isSecure();
  
  public abstract boolean checkNotModified(long paramLong);
  
  public abstract boolean checkNotModified(String paramString);
  
  public abstract boolean checkNotModified(@Nullable String paramString, long paramLong);
  
  public abstract String getDescription(boolean paramBoolean);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\request\WebRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */