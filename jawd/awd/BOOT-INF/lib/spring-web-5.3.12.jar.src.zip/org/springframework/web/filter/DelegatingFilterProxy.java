/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingFilterProxy
/*     */   extends GenericFilterBean
/*     */ {
/*     */   @Nullable
/*     */   private String contextAttribute;
/*     */   @Nullable
/*     */   private WebApplicationContext webApplicationContext;
/*     */   @Nullable
/*     */   private String targetBeanName;
/*  94 */   private boolean targetFilterLifecycle = false;
/*     */   
/*     */   @Nullable
/*     */   private volatile Filter delegate;
/*     */   
/*  99 */   private final Object delegateMonitor = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DelegatingFilterProxy() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DelegatingFilterProxy(Filter delegate)
/*     */   {
/* 124 */     Assert.notNull(delegate, "Delegate Filter must not be null");
/* 125 */     this.delegate = delegate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DelegatingFilterProxy(String targetBeanName)
/*     */   {
/* 142 */     this(targetBeanName, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DelegatingFilterProxy(String targetBeanName, @Nullable WebApplicationContext wac)
/*     */   {
/* 166 */     Assert.hasText(targetBeanName, "Target Filter bean name must not be null or empty");
/* 167 */     setTargetBeanName(targetBeanName);
/* 168 */     this.webApplicationContext = wac;
/* 169 */     if (wac != null) {
/* 170 */       setEnvironment(wac.getEnvironment());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContextAttribute(@Nullable String contextAttribute)
/*     */   {
/* 179 */     this.contextAttribute = contextAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public String getContextAttribute()
/*     */   {
/* 188 */     return this.contextAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetBeanName(@Nullable String targetBeanName)
/*     */   {
/* 198 */     this.targetBeanName = targetBeanName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getTargetBeanName()
/*     */   {
/* 206 */     return this.targetBeanName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetFilterLifecycle(boolean targetFilterLifecycle)
/*     */   {
/* 218 */     this.targetFilterLifecycle = targetFilterLifecycle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isTargetFilterLifecycle()
/*     */   {
/* 226 */     return this.targetFilterLifecycle;
/*     */   }
/*     */   
/*     */   protected void initFilterBean()
/*     */     throws ServletException
/*     */   {
/* 232 */     synchronized (this.delegateMonitor) {
/* 233 */       if (this.delegate == null)
/*     */       {
/* 235 */         if (this.targetBeanName == null) {
/* 236 */           this.targetBeanName = getFilterName();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 241 */         WebApplicationContext wac = findWebApplicationContext();
/* 242 */         if (wac != null) {
/* 243 */           this.delegate = initDelegate(wac);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 254 */     Filter delegateToUse = this.delegate;
/* 255 */     if (delegateToUse == null) {
/* 256 */       synchronized (this.delegateMonitor) {
/* 257 */         delegateToUse = this.delegate;
/* 258 */         if (delegateToUse == null) {
/* 259 */           WebApplicationContext wac = findWebApplicationContext();
/* 260 */           if (wac == null) {
/* 261 */             throw new IllegalStateException("No WebApplicationContext found: no ContextLoaderListener or DispatcherServlet registered?");
/*     */           }
/*     */           
/* 264 */           delegateToUse = initDelegate(wac);
/*     */         }
/* 266 */         this.delegate = delegateToUse;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 271 */     invokeDelegate(delegateToUse, request, response, filterChain);
/*     */   }
/*     */   
/*     */   public void destroy()
/*     */   {
/* 276 */     Filter delegateToUse = this.delegate;
/* 277 */     if (delegateToUse != null) {
/* 278 */       destroyDelegate(delegateToUse);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected WebApplicationContext findWebApplicationContext()
/*     */   {
/* 301 */     if (this.webApplicationContext != null)
/*     */     {
/* 303 */       if ((this.webApplicationContext instanceof ConfigurableApplicationContext)) {
/* 304 */         ConfigurableApplicationContext cac = (ConfigurableApplicationContext)this.webApplicationContext;
/* 305 */         if (!cac.isActive())
/*     */         {
/* 307 */           cac.refresh();
/*     */         }
/*     */       }
/* 310 */       return this.webApplicationContext;
/*     */     }
/* 312 */     String attrName = getContextAttribute();
/* 313 */     if (attrName != null) {
/* 314 */       return WebApplicationContextUtils.getWebApplicationContext(getServletContext(), attrName);
/*     */     }
/*     */     
/* 317 */     return WebApplicationContextUtils.findWebApplicationContext(getServletContext());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Filter initDelegate(WebApplicationContext wac)
/*     */     throws ServletException
/*     */   {
/* 336 */     String targetBeanName = getTargetBeanName();
/* 337 */     Assert.state(targetBeanName != null, "No target bean name set");
/* 338 */     Filter delegate = (Filter)wac.getBean(targetBeanName, Filter.class);
/* 339 */     if (isTargetFilterLifecycle()) {
/* 340 */       delegate.init(getFilterConfig());
/*     */     }
/* 342 */     return delegate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void invokeDelegate(Filter delegate, ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 358 */     delegate.doFilter(request, response, filterChain);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void destroyDelegate(Filter delegate)
/*     */   {
/* 369 */     if (isTargetFilterLifecycle()) {
/* 370 */       delegate.destroy();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\filter\DelegatingFilterProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */