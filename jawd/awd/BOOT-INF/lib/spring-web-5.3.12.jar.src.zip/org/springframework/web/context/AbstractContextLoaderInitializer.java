/*    */ package org.springframework.web.context;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.context.ApplicationContextInitializer;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.WebApplicationInitializer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractContextLoaderInitializer
/*    */   implements WebApplicationInitializer
/*    */ {
/* 45 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   public void onStartup(ServletContext servletContext)
/*    */     throws ServletException
/*    */   {
/* 50 */     registerContextLoaderListener(servletContext);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void registerContextLoaderListener(ServletContext servletContext)
/*    */   {
/* 60 */     WebApplicationContext rootAppContext = createRootApplicationContext();
/* 61 */     if (rootAppContext != null) {
/* 62 */       ContextLoaderListener listener = new ContextLoaderListener(rootAppContext);
/* 63 */       listener.setContextInitializers(getRootApplicationContextInitializers());
/* 64 */       servletContext.addListener(listener);
/*    */     }
/*    */     else {
/* 67 */       this.logger.debug("No ContextLoaderListener registered, as createRootApplicationContext() did not return an application context");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   protected abstract WebApplicationContext createRootApplicationContext();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   protected ApplicationContextInitializer<?>[] getRootApplicationContextInitializers()
/*    */   {
/* 95 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\AbstractContextLoaderInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */