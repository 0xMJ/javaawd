/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpServerErrorException
/*     */   extends HttpStatusCodeException
/*     */ {
/*     */   private static final long serialVersionUID = -2915754006618138282L;
/*     */   
/*     */   public HttpServerErrorException(HttpStatus statusCode)
/*     */   {
/*  41 */     super(statusCode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public HttpServerErrorException(HttpStatus statusCode, String statusText)
/*     */   {
/*  48 */     super(statusCode, statusText);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpServerErrorException(HttpStatus statusCode, String statusText, @Nullable byte[] body, @Nullable Charset charset)
/*     */   {
/*  57 */     super(statusCode, statusText, body, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpServerErrorException(HttpStatus statusCode, String statusText, @Nullable HttpHeaders headers, @Nullable byte[] body, @Nullable Charset charset)
/*     */   {
/*  66 */     super(statusCode, statusText, headers, body, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpServerErrorException(String message, HttpStatus statusCode, String statusText, @Nullable HttpHeaders headers, @Nullable byte[] body, @Nullable Charset charset)
/*     */   {
/*  77 */     super(message, statusCode, statusText, headers, body, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpServerErrorException create(HttpStatus statusCode, String statusText, HttpHeaders headers, byte[] body, @Nullable Charset charset)
/*     */   {
/*  87 */     return create(null, statusCode, statusText, headers, body, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HttpServerErrorException create(@Nullable String message, HttpStatus statusCode, String statusText, HttpHeaders headers, byte[] body, @Nullable Charset charset)
/*     */   {
/*  98 */     switch (statusCode) {
/*     */     case INTERNAL_SERVER_ERROR: 
/* 100 */       return message != null ? new InternalServerError(message, statusText, headers, body, charset, null) : new InternalServerError(statusText, headers, body, charset, null);
/*     */     
/*     */ 
/*     */     case NOT_IMPLEMENTED: 
/* 104 */       return message != null ? new NotImplemented(message, statusText, headers, body, charset, null) : new NotImplemented(statusText, headers, body, charset, null);
/*     */     
/*     */ 
/*     */     case BAD_GATEWAY: 
/* 108 */       return message != null ? new BadGateway(message, statusText, headers, body, charset, null) : new BadGateway(statusText, headers, body, charset, null);
/*     */     
/*     */ 
/*     */     case SERVICE_UNAVAILABLE: 
/* 112 */       return message != null ? new ServiceUnavailable(message, statusText, headers, body, charset, null) : new ServiceUnavailable(statusText, headers, body, charset, null);
/*     */     
/*     */ 
/*     */     case GATEWAY_TIMEOUT: 
/* 116 */       return message != null ? new GatewayTimeout(message, statusText, headers, body, charset, null) : new GatewayTimeout(statusText, headers, body, charset, null);
/*     */     }
/*     */     
/*     */     
/* 120 */     return message != null ? new HttpServerErrorException(message, statusCode, statusText, headers, body, charset) : new HttpServerErrorException(statusCode, statusText, headers, body, charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class InternalServerError
/*     */     extends HttpServerErrorException
/*     */   {
/*     */     private InternalServerError(String statusText, HttpHeaders headers, byte[] body, @Nullable Charset charset)
/*     */     {
/* 137 */       super(statusText, headers, body, charset);
/*     */     }
/*     */     
/*     */ 
/*     */     private InternalServerError(String message, String statusText, HttpHeaders headers, byte[] body, @Nullable Charset charset)
/*     */     {
/* 143 */       super(HttpStatus.INTERNAL_SERVER_ERROR, statusText, headers, body, charset);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class NotImplemented
/*     */     extends HttpServerErrorException
/*     */   {
/*     */     private NotImplemented(String statusText, HttpHeaders headers, byte[] body, @Nullable Charset charset)
/*     */     {
/* 155 */       super(statusText, headers, body, charset);
/*     */     }
/*     */     
/*     */ 
/*     */     private NotImplemented(String message, String statusText, HttpHeaders headers, byte[] body, @Nullable Charset charset)
/*     */     {
/* 161 */       super(HttpStatus.NOT_IMPLEMENTED, statusText, headers, body, charset);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class BadGateway
/*     */     extends HttpServerErrorException
/*     */   {
/*     */     private BadGateway(String statusText, HttpHeaders headers, byte[] body, @Nullable Charset charset)
/*     */     {
/* 173 */       super(statusText, headers, body, charset);
/*     */     }
/*     */     
/*     */ 
/*     */     private BadGateway(String message, String statusText, HttpHeaders headers, byte[] body, @Nullable Charset charset)
/*     */     {
/* 179 */       super(HttpStatus.BAD_GATEWAY, statusText, headers, body, charset);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class ServiceUnavailable
/*     */     extends HttpServerErrorException
/*     */   {
/*     */     private ServiceUnavailable(String statusText, HttpHeaders headers, byte[] body, @Nullable Charset charset)
/*     */     {
/* 191 */       super(statusText, headers, body, charset);
/*     */     }
/*     */     
/*     */ 
/*     */     private ServiceUnavailable(String message, String statusText, HttpHeaders headers, byte[] body, @Nullable Charset charset)
/*     */     {
/* 197 */       super(HttpStatus.SERVICE_UNAVAILABLE, statusText, headers, body, charset);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class GatewayTimeout
/*     */     extends HttpServerErrorException
/*     */   {
/*     */     private GatewayTimeout(String statusText, HttpHeaders headers, byte[] body, @Nullable Charset charset)
/*     */     {
/* 209 */       super(statusText, headers, body, charset);
/*     */     }
/*     */     
/*     */ 
/*     */     private GatewayTimeout(String message, String statusText, HttpHeaders headers, byte[] body, @Nullable Charset charset)
/*     */     {
/* 215 */       super(HttpStatus.GATEWAY_TIMEOUT, statusText, headers, body, charset);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\client\HttpServerErrorException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */