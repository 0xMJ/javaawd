package org.springframework.web.accept;

import java.util.List;
import org.springframework.http.MediaType;

public abstract interface MediaTypeFileExtensionResolver
{
  public abstract List<String> resolveFileExtensions(MediaType paramMediaType);
  
  public abstract List<String> getAllFileExtensions();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\accept\MediaTypeFileExtensionResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */