package org.springframework.web.context.request.async;

import java.util.function.Consumer;
import org.springframework.lang.Nullable;
import org.springframework.web.context.request.NativeWebRequest;

public abstract interface AsyncWebRequest
  extends NativeWebRequest
{
  public abstract void setTimeout(@Nullable Long paramLong);
  
  public abstract void addTimeoutHandler(Runnable paramRunnable);
  
  public abstract void addErrorHandler(Consumer<Throwable> paramConsumer);
  
  public abstract void addCompletionHandler(Runnable paramRunnable);
  
  public abstract void startAsync();
  
  public abstract boolean isAsyncStarted();
  
  public abstract void dispatch();
  
  public abstract boolean isAsyncComplete();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\request\async\AsyncWebRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */