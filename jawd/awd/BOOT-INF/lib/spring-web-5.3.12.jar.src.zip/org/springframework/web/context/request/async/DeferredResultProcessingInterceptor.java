/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface DeferredResultProcessingInterceptor
/*     */ {
/*     */   public <T> void beforeConcurrentHandling(NativeWebRequest request, DeferredResult<T> deferredResult)
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */   public <T> void preProcess(NativeWebRequest request, DeferredResult<T> deferredResult)
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */   public <T> void postProcess(NativeWebRequest request, DeferredResult<T> deferredResult, Object concurrentResult)
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */   public <T> boolean handleTimeout(NativeWebRequest request, DeferredResult<T> deferredResult)
/*     */     throws Exception
/*     */   {
/* 104 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> boolean handleError(NativeWebRequest request, DeferredResult<T> deferredResult, Throwable t)
/*     */     throws Exception
/*     */   {
/* 124 */     return true;
/*     */   }
/*     */   
/*     */   public <T> void afterCompletion(NativeWebRequest request, DeferredResult<T> deferredResult)
/*     */     throws Exception
/*     */   {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\request\async\DeferredResultProcessingInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */