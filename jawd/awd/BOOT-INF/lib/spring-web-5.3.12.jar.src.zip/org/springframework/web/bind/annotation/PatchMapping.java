package org.springframework.web.bind.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.core.annotation.AliasFor;

@Target({java.lang.annotation.ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@RequestMapping(method={RequestMethod.PATCH})
public @interface PatchMapping
{
  @AliasFor(annotation=RequestMapping.class)
  String name() default "";
  
  @AliasFor(annotation=RequestMapping.class)
  String[] value() default {};
  
  @AliasFor(annotation=RequestMapping.class)
  String[] path() default {};
  
  @AliasFor(annotation=RequestMapping.class)
  String[] params() default {};
  
  @AliasFor(annotation=RequestMapping.class)
  String[] headers() default {};
  
  @AliasFor(annotation=RequestMapping.class)
  String[] consumes() default {};
  
  @AliasFor(annotation=RequestMapping.class)
  String[] produces() default {};
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\bind\annotation\PatchMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */