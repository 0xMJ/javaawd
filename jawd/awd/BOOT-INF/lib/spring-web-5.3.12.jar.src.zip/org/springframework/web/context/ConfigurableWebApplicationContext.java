/*    */ package org.springframework.web.context;
/*    */ 
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ConfigurableWebApplicationContext
/*    */   extends WebApplicationContext, ConfigurableApplicationContext
/*    */ {
/* 46 */   public static final String APPLICATION_CONTEXT_ID_PREFIX = WebApplicationContext.class.getName() + ":";
/*    */   public static final String SERVLET_CONFIG_BEAN_NAME = "servletConfig";
/*    */   
/*    */   public abstract void setServletContext(@Nullable ServletContext paramServletContext);
/*    */   
/*    */   public abstract void setServletConfig(@Nullable ServletConfig paramServletConfig);
/*    */   
/*    */   @Nullable
/*    */   public abstract ServletConfig getServletConfig();
/*    */   
/*    */   public abstract void setNamespace(@Nullable String paramString);
/*    */   
/*    */   @Nullable
/*    */   public abstract String getNamespace();
/*    */   
/*    */   public abstract void setConfigLocation(String paramString);
/*    */   
/*    */   public abstract void setConfigLocations(String... paramVarArgs);
/*    */   
/*    */   @Nullable
/*    */   public abstract String[] getConfigLocations();
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\ConfigurableWebApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */