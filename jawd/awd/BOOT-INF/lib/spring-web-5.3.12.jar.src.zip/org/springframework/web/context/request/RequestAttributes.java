package org.springframework.web.context.request;

import org.springframework.lang.Nullable;

public abstract interface RequestAttributes
{
  public static final int SCOPE_REQUEST = 0;
  public static final int SCOPE_SESSION = 1;
  public static final String REFERENCE_REQUEST = "request";
  public static final String REFERENCE_SESSION = "session";
  
  @Nullable
  public abstract Object getAttribute(String paramString, int paramInt);
  
  public abstract void setAttribute(String paramString, Object paramObject, int paramInt);
  
  public abstract void removeAttribute(String paramString, int paramInt);
  
  public abstract String[] getAttributeNames(int paramInt);
  
  public abstract void registerDestructionCallback(String paramString, Runnable paramRunnable, int paramInt);
  
  @Nullable
  public abstract Object resolveReference(String paramString);
  
  public abstract String getSessionId();
  
  public abstract Object getSessionMutex();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\web\context\request\RequestAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */