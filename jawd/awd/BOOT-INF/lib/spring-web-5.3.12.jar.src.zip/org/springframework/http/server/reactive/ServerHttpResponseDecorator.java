/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.ResponseCookie;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerHttpResponseDecorator
/*     */   implements ServerHttpResponse
/*     */ {
/*     */   private final ServerHttpResponse delegate;
/*     */   
/*     */   public ServerHttpResponseDecorator(ServerHttpResponse delegate)
/*     */   {
/*  46 */     Assert.notNull(delegate, "Delegate is required");
/*  47 */     this.delegate = delegate;
/*     */   }
/*     */   
/*     */   public ServerHttpResponse getDelegate()
/*     */   {
/*  52 */     return this.delegate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setStatusCode(@Nullable HttpStatus status)
/*     */   {
/*  60 */     return getDelegate().setStatusCode(status);
/*     */   }
/*     */   
/*     */   public HttpStatus getStatusCode()
/*     */   {
/*  65 */     return getDelegate().getStatusCode();
/*     */   }
/*     */   
/*     */   public HttpHeaders getHeaders()
/*     */   {
/*  70 */     return getDelegate().getHeaders();
/*     */   }
/*     */   
/*     */   public MultiValueMap<String, ResponseCookie> getCookies()
/*     */   {
/*  75 */     return getDelegate().getCookies();
/*     */   }
/*     */   
/*     */   public void addCookie(ResponseCookie cookie)
/*     */   {
/*  80 */     getDelegate().addCookie(cookie);
/*     */   }
/*     */   
/*     */   public DataBufferFactory bufferFactory()
/*     */   {
/*  85 */     return getDelegate().bufferFactory();
/*     */   }
/*     */   
/*     */   public void beforeCommit(Supplier<? extends Mono<Void>> action)
/*     */   {
/*  90 */     getDelegate().beforeCommit(action);
/*     */   }
/*     */   
/*     */   public boolean isCommitted()
/*     */   {
/*  95 */     return getDelegate().isCommitted();
/*     */   }
/*     */   
/*     */   public Mono<Void> writeWith(Publisher<? extends DataBuffer> body)
/*     */   {
/* 100 */     return getDelegate().writeWith(body);
/*     */   }
/*     */   
/*     */   public Mono<Void> writeAndFlushWith(Publisher<? extends Publisher<? extends DataBuffer>> body)
/*     */   {
/* 105 */     return getDelegate().writeAndFlushWith(body);
/*     */   }
/*     */   
/*     */   public Mono<Void> setComplete()
/*     */   {
/* 110 */     return getDelegate().setComplete();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> T getNativeResponse(ServerHttpResponse response)
/*     */   {
/* 123 */     if ((response instanceof AbstractServerHttpResponse)) {
/* 124 */       return (T)((AbstractServerHttpResponse)response).getNativeResponse();
/*     */     }
/* 126 */     if ((response instanceof ServerHttpResponseDecorator)) {
/* 127 */       return (T)getNativeResponse(((ServerHttpResponseDecorator)response).getDelegate());
/*     */     }
/*     */     
/*     */ 
/* 131 */     throw new IllegalArgumentException("Can't find native response in " + response.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 138 */     return getClass().getSimpleName() + " [delegate=" + getDelegate() + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\server\reactive\ServerHttpResponseDecorator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */