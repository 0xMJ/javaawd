package org.springframework.http.client.reactive;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;

@NonNullApi
@NonNullFields
abstract interface package-info {}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\client\reactive\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */