package org.springframework.http.client.reactive;

import java.net.URI;
import java.util.function.Function;
import org.springframework.http.HttpMethod;
import reactor.core.publisher.Mono;

public abstract interface ClientHttpConnector
{
  public abstract Mono<ClientHttpResponse> connect(HttpMethod paramHttpMethod, URI paramURI, Function<? super ClientHttpRequest, Mono<Void>> paramFunction);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\client\reactive\ClientHttpConnector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */