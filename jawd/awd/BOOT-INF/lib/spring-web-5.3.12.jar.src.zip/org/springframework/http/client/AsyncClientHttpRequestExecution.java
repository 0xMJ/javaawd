package org.springframework.http.client;

import java.io.IOException;
import org.springframework.http.HttpRequest;
import org.springframework.util.concurrent.ListenableFuture;

@Deprecated
public abstract interface AsyncClientHttpRequestExecution
{
  public abstract ListenableFuture<ClientHttpResponse> executeAsync(HttpRequest paramHttpRequest, byte[] paramArrayOfByte)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\client\AsyncClientHttpRequestExecution.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */