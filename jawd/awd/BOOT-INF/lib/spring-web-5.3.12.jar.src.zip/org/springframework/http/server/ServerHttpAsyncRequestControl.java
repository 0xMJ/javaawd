package org.springframework.http.server;

public abstract interface ServerHttpAsyncRequestControl
{
  public abstract void start();
  
  public abstract void start(long paramLong);
  
  public abstract boolean isStarted();
  
  public abstract void complete();
  
  public abstract boolean isCompleted();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\server\ServerHttpAsyncRequestControl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */