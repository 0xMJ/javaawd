/*     */ package org.springframework.http.server;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.Principal;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.InvalidMediaTypeException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletServerHttpRequest
/*     */   implements ServerHttpRequest
/*     */ {
/*     */   protected static final String FORM_CONTENT_TYPE = "application/x-www-form-urlencoded";
/*  61 */   protected static final Charset FORM_CHARSET = StandardCharsets.UTF_8;
/*     */   
/*     */ 
/*     */   private final HttpServletRequest servletRequest;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private URI uri;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private HttpHeaders headers;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private ServerHttpAsyncRequestControl asyncRequestControl;
/*     */   
/*     */ 
/*     */ 
/*     */   public ServletServerHttpRequest(HttpServletRequest servletRequest)
/*     */   {
/*  82 */     Assert.notNull(servletRequest, "HttpServletRequest must not be null");
/*  83 */     this.servletRequest = servletRequest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpServletRequest getServletRequest()
/*     */   {
/*  91 */     return this.servletRequest;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public HttpMethod getMethod()
/*     */   {
/*  97 */     return HttpMethod.resolve(this.servletRequest.getMethod());
/*     */   }
/*     */   
/*     */   public String getMethodValue()
/*     */   {
/* 102 */     return this.servletRequest.getMethod();
/*     */   }
/*     */   
/*     */   public URI getURI()
/*     */   {
/* 107 */     if (this.uri == null) {
/* 108 */       String urlString = null;
/* 109 */       boolean hasQuery = false;
/*     */       try {
/* 111 */         StringBuffer url = this.servletRequest.getRequestURL();
/* 112 */         String query = this.servletRequest.getQueryString();
/* 113 */         hasQuery = StringUtils.hasText(query);
/* 114 */         if (hasQuery) {
/* 115 */           url.append('?').append(query);
/*     */         }
/* 117 */         urlString = url.toString();
/* 118 */         this.uri = new URI(urlString);
/*     */       }
/*     */       catch (URISyntaxException ex) {
/* 121 */         if (!hasQuery) {
/* 122 */           throw new IllegalStateException("Could not resolve HttpServletRequest as URI: " + urlString, ex);
/*     */         }
/*     */         
/*     */         try
/*     */         {
/* 127 */           urlString = this.servletRequest.getRequestURL().toString();
/* 128 */           this.uri = new URI(urlString);
/*     */         }
/*     */         catch (URISyntaxException ex2) {
/* 131 */           throw new IllegalStateException("Could not resolve HttpServletRequest as URI: " + urlString, ex2);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 136 */     return this.uri;
/*     */   }
/*     */   
/*     */   public HttpHeaders getHeaders()
/*     */   {
/* 141 */     if (this.headers == null) {
/* 142 */       this.headers = new HttpHeaders();
/*     */       
/* 144 */       for (Enumeration<?> names = this.servletRequest.getHeaderNames(); names.hasMoreElements();) {
/* 145 */         String headerName = (String)names.nextElement();
/* 146 */         Enumeration<?> headerValues = this.servletRequest.getHeaders(headerName);
/* 147 */         while (headerValues.hasMoreElements()) {
/* 148 */           String headerValue = (String)headerValues.nextElement();
/* 149 */           this.headers.add(headerName, headerValue);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 156 */         MediaType contentType = this.headers.getContentType();
/* 157 */         if (contentType == null) {
/* 158 */           String requestContentType = this.servletRequest.getContentType();
/* 159 */           if (StringUtils.hasLength(requestContentType)) {
/* 160 */             contentType = MediaType.parseMediaType(requestContentType);
/* 161 */             this.headers.setContentType(contentType);
/*     */           }
/*     */         }
/* 164 */         if ((contentType != null) && (contentType.getCharset() == null)) {
/* 165 */           String requestEncoding = this.servletRequest.getCharacterEncoding();
/* 166 */           if (StringUtils.hasLength(requestEncoding)) {
/* 167 */             Charset charSet = Charset.forName(requestEncoding);
/* 168 */             Map<String, String> params = new LinkedCaseInsensitiveMap();
/* 169 */             params.putAll(contentType.getParameters());
/* 170 */             params.put("charset", charSet.toString());
/* 171 */             MediaType mediaType = new MediaType(contentType.getType(), contentType.getSubtype(), params);
/* 172 */             this.headers.setContentType(mediaType);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (InvalidMediaTypeException localInvalidMediaTypeException) {}
/*     */       
/*     */ 
/*     */ 
/* 180 */       if (this.headers.getContentLength() < 0L) {
/* 181 */         int requestContentLength = this.servletRequest.getContentLength();
/* 182 */         if (requestContentLength != -1) {
/* 183 */           this.headers.setContentLength(requestContentLength);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 188 */     return this.headers;
/*     */   }
/*     */   
/*     */   public Principal getPrincipal()
/*     */   {
/* 193 */     return this.servletRequest.getUserPrincipal();
/*     */   }
/*     */   
/*     */   public InetSocketAddress getLocalAddress()
/*     */   {
/* 198 */     return new InetSocketAddress(this.servletRequest.getLocalName(), this.servletRequest.getLocalPort());
/*     */   }
/*     */   
/*     */   public InetSocketAddress getRemoteAddress()
/*     */   {
/* 203 */     return new InetSocketAddress(this.servletRequest.getRemoteHost(), this.servletRequest.getRemotePort());
/*     */   }
/*     */   
/*     */   public InputStream getBody() throws IOException
/*     */   {
/* 208 */     if (isFormPost(this.servletRequest)) {
/* 209 */       return getBodyFromServletRequestParameters(this.servletRequest);
/*     */     }
/*     */     
/* 212 */     return this.servletRequest.getInputStream();
/*     */   }
/*     */   
/*     */ 
/*     */   public ServerHttpAsyncRequestControl getAsyncRequestControl(ServerHttpResponse response)
/*     */   {
/* 218 */     if (this.asyncRequestControl == null) {
/* 219 */       if (!(response instanceof ServletServerHttpResponse))
/*     */       {
/* 221 */         throw new IllegalArgumentException("Response must be a ServletServerHttpResponse: " + response.getClass());
/*     */       }
/* 223 */       ServletServerHttpResponse servletServerResponse = (ServletServerHttpResponse)response;
/* 224 */       this.asyncRequestControl = new ServletServerHttpAsyncRequestControl(this, servletServerResponse);
/*     */     }
/* 226 */     return this.asyncRequestControl;
/*     */   }
/*     */   
/*     */   private static boolean isFormPost(HttpServletRequest request)
/*     */   {
/* 231 */     String contentType = request.getContentType();
/* 232 */     return (contentType != null) && (contentType.contains("application/x-www-form-urlencoded")) && 
/* 233 */       (HttpMethod.POST.matches(request.getMethod()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static InputStream getBodyFromServletRequestParameters(HttpServletRequest request)
/*     */     throws IOException
/*     */   {
/* 243 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(1024);
/* 244 */     Writer writer = new OutputStreamWriter(bos, FORM_CHARSET);
/*     */     
/* 246 */     Map<String, String[]> form = request.getParameterMap();
/* 247 */     for (Iterator<Map.Entry<String, String[]>> entryIterator = form.entrySet().iterator(); entryIterator.hasNext();) {
/* 248 */       Map.Entry<String, String[]> entry = (Map.Entry)entryIterator.next();
/* 249 */       String name = (String)entry.getKey();
/* 250 */       List<String> values = Arrays.asList((Object[])entry.getValue());
/* 251 */       for (Iterator<String> valueIterator = values.iterator(); valueIterator.hasNext();) {
/* 252 */         String value = (String)valueIterator.next();
/* 253 */         writer.write(URLEncoder.encode(name, FORM_CHARSET.name()));
/* 254 */         if (value != null) {
/* 255 */           writer.write(61);
/* 256 */           writer.write(URLEncoder.encode(value, FORM_CHARSET.name()));
/* 257 */           if (valueIterator.hasNext()) {
/* 258 */             writer.write(38);
/*     */           }
/*     */         }
/*     */       }
/* 262 */       if (entryIterator.hasNext()) {
/* 263 */         writer.append('&');
/*     */       }
/*     */     }
/* 266 */     writer.flush();
/*     */     
/* 268 */     return new ByteArrayInputStream(bos.toByteArray());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\server\ServletServerHttpRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */