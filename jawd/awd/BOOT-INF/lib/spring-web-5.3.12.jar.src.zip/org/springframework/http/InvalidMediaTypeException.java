/*    */ package org.springframework.http;
/*    */ 
/*    */ import org.springframework.util.InvalidMimeTypeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidMediaTypeException
/*    */   extends IllegalArgumentException
/*    */ {
/*    */   private final String mediaType;
/*    */   
/*    */   public InvalidMediaTypeException(String mediaType, String message)
/*    */   {
/* 40 */     super("Invalid media type \"" + mediaType + "\": " + message);
/* 41 */     this.mediaType = mediaType;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   InvalidMediaTypeException(InvalidMimeTypeException ex)
/*    */   {
/* 48 */     super(ex.getMessage(), ex);
/* 49 */     this.mediaType = ex.getMimeType();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMediaType()
/*    */   {
/* 57 */     return this.mediaType;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\InvalidMediaTypeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */