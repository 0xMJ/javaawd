/*    */ package org.springframework.http.server;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface RequestPath
/*    */   extends PathContainer
/*    */ {
/*    */   public abstract PathContainer contextPath();
/*    */   
/*    */   public abstract PathContainer pathWithinApplication();
/*    */   
/*    */   public abstract RequestPath modifyContextPath(String paramString);
/*    */   
/*    */   public static RequestPath parse(URI uri, @Nullable String contextPath)
/*    */   {
/* 68 */     return parse(uri.getRawPath(), contextPath);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static RequestPath parse(String rawPath, @Nullable String contextPath)
/*    */   {
/* 79 */     return new DefaultRequestPath(rawPath, contextPath);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\server\RequestPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */