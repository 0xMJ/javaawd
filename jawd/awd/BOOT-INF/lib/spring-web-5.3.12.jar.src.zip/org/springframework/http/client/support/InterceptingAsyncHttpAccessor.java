/*    */ package org.springframework.http.client.support;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.http.client.AsyncClientHttpRequestFactory;
/*    */ import org.springframework.http.client.AsyncClientHttpRequestInterceptor;
/*    */ import org.springframework.http.client.InterceptingAsyncClientHttpRequestFactory;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class InterceptingAsyncHttpAccessor
/*    */   extends AsyncHttpAccessor
/*    */ {
/* 36 */   private List<AsyncClientHttpRequestInterceptor> interceptors = new ArrayList();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setInterceptors(List<AsyncClientHttpRequestInterceptor> interceptors)
/*    */   {
/* 45 */     this.interceptors = interceptors;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public List<AsyncClientHttpRequestInterceptor> getInterceptors()
/*    */   {
/* 52 */     return this.interceptors;
/*    */   }
/*    */   
/*    */ 
/*    */   public AsyncClientHttpRequestFactory getAsyncRequestFactory()
/*    */   {
/* 58 */     AsyncClientHttpRequestFactory delegate = super.getAsyncRequestFactory();
/* 59 */     if (!CollectionUtils.isEmpty(getInterceptors())) {
/* 60 */       return new InterceptingAsyncClientHttpRequestFactory(delegate, getInterceptors());
/*    */     }
/*    */     
/* 63 */     return delegate;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\client\support\InterceptingAsyncHttpAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */