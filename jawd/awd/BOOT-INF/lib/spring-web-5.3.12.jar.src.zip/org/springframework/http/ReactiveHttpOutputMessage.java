package org.springframework.http;

import java.util.function.Supplier;
import org.reactivestreams.Publisher;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import reactor.core.publisher.Mono;

public abstract interface ReactiveHttpOutputMessage
  extends HttpMessage
{
  public abstract DataBufferFactory bufferFactory();
  
  public abstract void beforeCommit(Supplier<? extends Mono<Void>> paramSupplier);
  
  public abstract boolean isCommitted();
  
  public abstract Mono<Void> writeWith(Publisher<? extends DataBuffer> paramPublisher);
  
  public abstract Mono<Void> writeAndFlushWith(Publisher<? extends Publisher<? extends DataBuffer>> paramPublisher);
  
  public abstract Mono<Void> setComplete();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\ReactiveHttpOutputMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */