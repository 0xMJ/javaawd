package org.springframework.http.codec;

import java.util.List;
import java.util.function.Consumer;
import org.springframework.core.codec.Decoder;
import org.springframework.core.codec.Encoder;
import org.springframework.lang.Nullable;

public abstract interface CodecConfigurer
{
  public abstract DefaultCodecs defaultCodecs();
  
  public abstract CustomCodecs customCodecs();
  
  public abstract void registerDefaults(boolean paramBoolean);
  
  public abstract List<HttpMessageReader<?>> getReaders();
  
  public abstract List<HttpMessageWriter<?>> getWriters();
  
  public abstract CodecConfigurer clone();
  
  public static abstract interface DefaultCodecConfig
  {
    @Nullable
    public abstract Integer maxInMemorySize();
    
    @Nullable
    public abstract Boolean isEnableLoggingRequestDetails();
  }
  
  public static abstract interface CustomCodecs
  {
    public abstract void register(Object paramObject);
    
    public abstract void registerWithDefaultConfig(Object paramObject);
    
    public abstract void registerWithDefaultConfig(Object paramObject, Consumer<CodecConfigurer.DefaultCodecConfig> paramConsumer);
    
    @Deprecated
    public abstract void decoder(Decoder<?> paramDecoder);
    
    @Deprecated
    public abstract void encoder(Encoder<?> paramEncoder);
    
    @Deprecated
    public abstract void reader(HttpMessageReader<?> paramHttpMessageReader);
    
    @Deprecated
    public abstract void writer(HttpMessageWriter<?> paramHttpMessageWriter);
    
    @Deprecated
    public abstract void withDefaultCodecConfig(Consumer<CodecConfigurer.DefaultCodecConfig> paramConsumer);
  }
  
  public static abstract interface DefaultCodecs
  {
    public abstract void jackson2JsonDecoder(Decoder<?> paramDecoder);
    
    public abstract void jackson2JsonEncoder(Encoder<?> paramEncoder);
    
    public abstract void jackson2SmileDecoder(Decoder<?> paramDecoder);
    
    public abstract void jackson2SmileEncoder(Encoder<?> paramEncoder);
    
    public abstract void protobufDecoder(Decoder<?> paramDecoder);
    
    public abstract void protobufEncoder(Encoder<?> paramEncoder);
    
    public abstract void jaxb2Decoder(Decoder<?> paramDecoder);
    
    public abstract void jaxb2Encoder(Encoder<?> paramEncoder);
    
    public abstract void kotlinSerializationJsonDecoder(Decoder<?> paramDecoder);
    
    public abstract void kotlinSerializationJsonEncoder(Encoder<?> paramEncoder);
    
    public abstract void configureDefaultCodec(Consumer<Object> paramConsumer);
    
    public abstract void maxInMemorySize(int paramInt);
    
    public abstract void enableLoggingRequestDetails(boolean paramBoolean);
  }
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\codec\CodecConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */