package org.springframework.http.client;

@FunctionalInterface
public abstract interface ClientHttpRequestInitializer
{
  public abstract void initialize(ClientHttpRequest paramClientHttpRequest);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\client\ClientHttpRequestInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */