/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Optional;
/*     */ import org.springframework.core.io.ByteArrayResource;
/*     */ import org.springframework.core.io.InputStreamResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.ContentDisposition;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.MediaTypeFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHttpMessageConverter
/*     */   extends AbstractHttpMessageConverter<Resource>
/*     */ {
/*     */   private final boolean supportsReadStreaming;
/*     */   
/*     */   public ResourceHttpMessageConverter()
/*     */   {
/*  56 */     super(MediaType.ALL);
/*  57 */     this.supportsReadStreaming = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHttpMessageConverter(boolean supportsReadStreaming)
/*     */   {
/*  67 */     super(MediaType.ALL);
/*  68 */     this.supportsReadStreaming = supportsReadStreaming;
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/*  74 */     return Resource.class.isAssignableFrom(clazz);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Resource readInternal(Class<? extends Resource> clazz, final HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/*  81 */     if ((this.supportsReadStreaming) && (InputStreamResource.class == clazz)) {
/*  82 */       new InputStreamResource(inputMessage.getBody())
/*     */       {
/*     */         public String getFilename() {
/*  85 */           return inputMessage.getHeaders().getContentDisposition().getFilename();
/*     */         }
/*     */         
/*     */         public long contentLength() throws IOException {
/*  89 */           long length = inputMessage.getHeaders().getContentLength();
/*  90 */           return length != -1L ? length : super.contentLength();
/*     */         }
/*     */       };
/*     */     }
/*  94 */     if ((Resource.class == clazz) || (ByteArrayResource.class.isAssignableFrom(clazz))) {
/*  95 */       byte[] body = StreamUtils.copyToByteArray(inputMessage.getBody());
/*  96 */       new ByteArrayResource(body)
/*     */       {
/*     */         @Nullable
/*     */         public String getFilename() {
/* 100 */           return inputMessage.getHeaders().getContentDisposition().getFilename();
/*     */         }
/*     */       };
/*     */     }
/*     */     
/* 105 */     throw new HttpMessageNotReadableException("Unsupported resource class: " + clazz, inputMessage);
/*     */   }
/*     */   
/*     */ 
/*     */   protected MediaType getDefaultContentType(Resource resource)
/*     */   {
/* 111 */     return (MediaType)MediaTypeFactory.getMediaType(resource).orElse(MediaType.APPLICATION_OCTET_STREAM);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Long getContentLength(Resource resource, @Nullable MediaType contentType)
/*     */     throws IOException
/*     */   {
/* 118 */     if (InputStreamResource.class == resource.getClass()) {
/* 119 */       return null;
/*     */     }
/* 121 */     long contentLength = resource.contentLength();
/* 122 */     return contentLength < 0L ? null : Long.valueOf(contentLength);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void writeInternal(Resource resource, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 129 */     writeContent(resource, outputMessage);
/*     */   }
/*     */   
/*     */   protected void writeContent(Resource resource, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException
/*     */   {
/*     */     try {
/* 135 */       InputStream in = resource.getInputStream();
/*     */       try {
/* 137 */         StreamUtils.copy(in, outputMessage.getBody());
/*     */ 
/*     */       }
/*     */       catch (NullPointerException localNullPointerException) {}finally
/*     */       {
/*     */         try
/*     */         {
/* 144 */           in.close();
/*     */         }
/*     */         catch (Throwable localThrowable2) {}
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */       return;
/*     */     }
/*     */     catch (FileNotFoundException localFileNotFoundException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\converter\ResourceHttpMessageConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */