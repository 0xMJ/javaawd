/*    */ package org.springframework.http.codec;
/*    */ 
/*    */ import org.springframework.core.codec.Decoder;
/*    */ import org.springframework.core.codec.Encoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ClientCodecConfigurer
/*    */   extends CodecConfigurer
/*    */ {
/*    */   public abstract ClientDefaultCodecs defaultCodecs();
/*    */   
/*    */   public abstract ClientCodecConfigurer clone();
/*    */   
/*    */   public static ClientCodecConfigurer create()
/*    */   {
/* 77 */     return (ClientCodecConfigurer)CodecConfigurerFactory.create(ClientCodecConfigurer.class);
/*    */   }
/*    */   
/*    */   public static abstract interface MultipartCodecs
/*    */   {
/*    */     public abstract MultipartCodecs encoder(Encoder<?> paramEncoder);
/*    */     
/*    */     public abstract MultipartCodecs writer(HttpMessageWriter<?> paramHttpMessageWriter);
/*    */   }
/*    */   
/*    */   public static abstract interface ClientDefaultCodecs
/*    */     extends CodecConfigurer.DefaultCodecs
/*    */   {
/*    */     public abstract ClientCodecConfigurer.MultipartCodecs multipartCodecs();
/*    */     
/*    */     public abstract void serverSentEventDecoder(Decoder<?> paramDecoder);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\codec\ClientCodecConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */