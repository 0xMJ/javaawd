package org.springframework.http.converter.protobuf;

import com.google.protobuf.ExtensionRegistry;

@Deprecated
public abstract interface ExtensionRegistryInitializer
{
  public abstract void initializeExtensionRegistry(ExtensionRegistry paramExtensionRegistry);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\converter\protobuf\ExtensionRegistryInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */