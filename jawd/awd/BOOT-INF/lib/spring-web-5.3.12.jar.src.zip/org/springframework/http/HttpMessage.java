package org.springframework.http;

public abstract interface HttpMessage
{
  public abstract HttpHeaders getHeaders();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\HttpMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */