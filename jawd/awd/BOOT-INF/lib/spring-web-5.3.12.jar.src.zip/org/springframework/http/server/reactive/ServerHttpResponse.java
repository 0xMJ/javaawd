/*    */ package org.springframework.http.server.reactive;
/*    */ 
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.ReactiveHttpOutputMessage;
/*    */ import org.springframework.http.ResponseCookie;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ServerHttpResponse
/*    */   extends ReactiveHttpOutputMessage
/*    */ {
/*    */   public abstract boolean setStatusCode(@Nullable HttpStatus paramHttpStatus);
/*    */   
/*    */   @Nullable
/*    */   public abstract HttpStatus getStatusCode();
/*    */   
/*    */   public boolean setRawStatusCode(@Nullable Integer value)
/*    */   {
/* 62 */     if (value == null) {
/* 63 */       return setStatusCode(null);
/*    */     }
/*    */     
/* 66 */     HttpStatus httpStatus = HttpStatus.resolve(value.intValue());
/* 67 */     if (httpStatus == null) {
/* 68 */       throw new IllegalStateException("Unresolvable HttpStatus for general ServerHttpResponse: " + value);
/*    */     }
/*    */     
/* 71 */     return setStatusCode(httpStatus);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   public Integer getRawStatusCode()
/*    */   {
/* 83 */     HttpStatus httpStatus = getStatusCode();
/* 84 */     return httpStatus != null ? Integer.valueOf(httpStatus.value()) : null;
/*    */   }
/*    */   
/*    */   public abstract MultiValueMap<String, ResponseCookie> getCookies();
/*    */   
/*    */   public abstract void addCookie(ResponseCookie paramResponseCookie);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\server\reactive\ServerHttpResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */