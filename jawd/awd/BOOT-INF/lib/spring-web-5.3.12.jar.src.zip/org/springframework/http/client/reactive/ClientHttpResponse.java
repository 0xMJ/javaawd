/*    */ package org.springframework.http.client.reactive;
/*    */ 
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.ReactiveHttpInputMessage;
/*    */ import org.springframework.http.ResponseCookie;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ClientHttpResponse
/*    */   extends ReactiveHttpInputMessage
/*    */ {
/*    */   public String getId()
/*    */   {
/* 40 */     return ObjectUtils.getIdentityHexString(this);
/*    */   }
/*    */   
/*    */   public abstract HttpStatus getStatusCode();
/*    */   
/*    */   public abstract int getRawStatusCode();
/*    */   
/*    */   public abstract MultiValueMap<String, ResponseCookie> getCookies();
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\client\reactive\ClientHttpResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */