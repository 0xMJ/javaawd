/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpRequest;
/*     */ import org.springframework.http.ReactiveHttpInputMessage;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface ServerHttpRequest
/*     */   extends HttpRequest, ReactiveHttpInputMessage
/*     */ {
/*     */   public abstract String getId();
/*     */   
/*     */   public abstract RequestPath getPath();
/*     */   
/*     */   public abstract MultiValueMap<String, String> getQueryParams();
/*     */   
/*     */   public abstract MultiValueMap<String, HttpCookie> getCookies();
/*     */   
/*     */   @Nullable
/*     */   public InetSocketAddress getLocalAddress()
/*     */   {
/*  78 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public InetSocketAddress getRemoteAddress()
/*     */   {
/*  86 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public SslInfo getSslInfo()
/*     */   {
/*  97 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Builder mutate()
/*     */   {
/* 106 */     return new DefaultServerHttpRequestBuilder(this);
/*     */   }
/*     */   
/*     */   public static abstract interface Builder
/*     */   {
/*     */     public abstract Builder method(HttpMethod paramHttpMethod);
/*     */     
/*     */     public abstract Builder uri(URI paramURI);
/*     */     
/*     */     public abstract Builder path(String paramString);
/*     */     
/*     */     public abstract Builder contextPath(String paramString);
/*     */     
/*     */     public abstract Builder header(String paramString, String... paramVarArgs);
/*     */     
/*     */     public abstract Builder headers(Consumer<HttpHeaders> paramConsumer);
/*     */     
/*     */     public abstract Builder sslInfo(SslInfo paramSslInfo);
/*     */     
/*     */     public abstract Builder remoteAddress(InetSocketAddress paramInetSocketAddress);
/*     */     
/*     */     public abstract ServerHttpRequest build();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\server\reactive\ServerHttpRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */