/*    */ package org.springframework.http.codec;
/*    */ 
/*    */ import org.springframework.core.codec.Encoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ServerCodecConfigurer
/*    */   extends CodecConfigurer
/*    */ {
/*    */   public abstract ServerDefaultCodecs defaultCodecs();
/*    */   
/*    */   public abstract ServerCodecConfigurer clone();
/*    */   
/*    */   public static ServerCodecConfigurer create()
/*    */   {
/* 76 */     return (ServerCodecConfigurer)CodecConfigurerFactory.create(ServerCodecConfigurer.class);
/*    */   }
/*    */   
/*    */   public static abstract interface ServerDefaultCodecs
/*    */     extends CodecConfigurer.DefaultCodecs
/*    */   {
/*    */     public abstract void multipartReader(HttpMessageReader<?> paramHttpMessageReader);
/*    */     
/*    */     public abstract void serverSentEventEncoder(Encoder<?> paramEncoder);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\codec\ServerCodecConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */