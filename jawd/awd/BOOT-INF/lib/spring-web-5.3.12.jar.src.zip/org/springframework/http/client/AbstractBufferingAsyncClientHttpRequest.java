/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.concurrent.ListenableFuture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ abstract class AbstractBufferingAsyncClientHttpRequest
/*    */   extends AbstractAsyncClientHttpRequest
/*    */ {
/* 37 */   private ByteArrayOutputStream bufferedOutput = new ByteArrayOutputStream(1024);
/*    */   
/*    */   protected OutputStream getBodyInternal(HttpHeaders headers)
/*    */     throws IOException
/*    */   {
/* 42 */     return this.bufferedOutput;
/*    */   }
/*    */   
/*    */   protected ListenableFuture<ClientHttpResponse> executeInternal(HttpHeaders headers) throws IOException
/*    */   {
/* 47 */     byte[] bytes = this.bufferedOutput.toByteArray();
/* 48 */     if (headers.getContentLength() < 0L) {
/* 49 */       headers.setContentLength(bytes.length);
/*    */     }
/* 51 */     ListenableFuture<ClientHttpResponse> result = executeInternal(headers, bytes);
/* 52 */     this.bufferedOutput = new ByteArrayOutputStream(0);
/* 53 */     return result;
/*    */   }
/*    */   
/*    */   protected abstract ListenableFuture<ClientHttpResponse> executeInternal(HttpHeaders paramHttpHeaders, byte[] paramArrayOfByte)
/*    */     throws IOException;
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\client\AbstractBufferingAsyncClientHttpRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */