/*     */ package org.springframework.http.server.reactive;
/*     */ 
/*     */ import java.util.function.Function;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.reactivestreams.Subscriber;
/*     */ import org.reactivestreams.Subscription;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.CoreSubscriber;
/*     */ import reactor.core.Scannable;
/*     */ import reactor.core.Scannable.Attr;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Operators;
/*     */ import reactor.util.context.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelSendOperator<T>
/*     */   extends Mono<Void>
/*     */   implements Scannable
/*     */ {
/*     */   private final Function<Publisher<T>, Publisher<Void>> writeFunction;
/*     */   private final Flux<T> source;
/*     */   
/*     */   public ChannelSendOperator(Publisher<? extends T> source, Function<Publisher<T>, Publisher<Void>> writeFunction)
/*     */   {
/*  57 */     this.source = Flux.from(source);
/*  58 */     this.writeFunction = writeFunction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object scanUnsafe(Scannable.Attr key)
/*     */   {
/*  66 */     if (key == Scannable.Attr.PREFETCH) {
/*  67 */       return Integer.valueOf(Integer.MAX_VALUE);
/*     */     }
/*  69 */     if (key == Scannable.Attr.PARENT) {
/*  70 */       return this.source;
/*     */     }
/*  72 */     return null;
/*     */   }
/*     */   
/*     */   public void subscribe(CoreSubscriber<? super Void> actual)
/*     */   {
/*  77 */     this.source.subscribe(new WriteBarrier(actual));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static enum State
/*     */   {
/*  84 */     NEW, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */     FIRST_SIGNAL_RECEIVED, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */     EMITTING_CACHED_SIGNALS, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */     READY_TO_WRITE;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private State() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class WriteBarrier
/*     */     implements CoreSubscriber<T>, Subscription, Publisher<T>
/*     */   {
/*     */     private final ChannelSendOperator<T>.WriteCompletionBarrier writeCompletionBarrier;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     @Nullable
/*     */     private Subscription subscription;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     @Nullable
/*     */     private T item;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     @Nullable
/*     */     private Throwable error;
/*     */     
/*     */ 
/*     */ 
/* 141 */     private boolean completed = false;
/*     */     
/*     */ 
/*     */     private long demandBeforeReadyToWrite;
/*     */     
/*     */ 
/* 147 */     private ChannelSendOperator.State state = ChannelSendOperator.State.NEW;
/*     */     
/*     */     @Nullable
/*     */     private Subscriber<? super T> writeSubscriber;
/*     */     
/*     */ 
/*     */     WriteBarrier()
/*     */     {
/* 155 */       this.writeCompletionBarrier = new ChannelSendOperator.WriteCompletionBarrier(ChannelSendOperator.this, completionSubscriber, this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public final void onSubscribe(Subscription s)
/*     */     {
/* 163 */       if (Operators.validate(this.subscription, s)) {
/* 164 */         this.subscription = s;
/* 165 */         this.writeCompletionBarrier.connect();
/* 166 */         s.request(1L);
/*     */       }
/*     */     }
/*     */     
/*     */     public final void onNext(T item)
/*     */     {
/* 172 */       if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 173 */         requiredWriteSubscriber().onNext(item);
/* 174 */         return;
/*     */       }
/*     */       
/* 177 */       synchronized (this) {
/* 178 */         if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 179 */           requiredWriteSubscriber().onNext(item);
/*     */         }
/* 181 */         else if (this.state == ChannelSendOperator.State.NEW) {
/* 182 */           this.item = item;
/* 183 */           this.state = ChannelSendOperator.State.FIRST_SIGNAL_RECEIVED;
/*     */           try
/*     */           {
/* 186 */             result = (Publisher)ChannelSendOperator.this.writeFunction.apply(this);
/*     */           } catch (Throwable ex) {
/*     */             Publisher<Void> result;
/* 189 */             this.writeCompletionBarrier.onError(ex); return;
/*     */           }
/*     */           Publisher<Void> result;
/* 192 */           result.subscribe(this.writeCompletionBarrier);
/*     */         }
/*     */         else {
/* 195 */           if (this.subscription != null) {
/* 196 */             this.subscription.cancel();
/*     */           }
/* 198 */           this.writeCompletionBarrier.onError(new IllegalStateException("Unexpected item."));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     private Subscriber<? super T> requiredWriteSubscriber() {
/* 204 */       Assert.state(this.writeSubscriber != null, "No write subscriber");
/* 205 */       return this.writeSubscriber;
/*     */     }
/*     */     
/*     */     public final void onError(Throwable ex)
/*     */     {
/* 210 */       if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 211 */         requiredWriteSubscriber().onError(ex);
/* 212 */         return;
/*     */       }
/* 214 */       synchronized (this) {
/* 215 */         if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 216 */           requiredWriteSubscriber().onError(ex);
/*     */         }
/* 218 */         else if (this.state == ChannelSendOperator.State.NEW) {
/* 219 */           this.state = ChannelSendOperator.State.FIRST_SIGNAL_RECEIVED;
/* 220 */           this.writeCompletionBarrier.onError(ex);
/*     */         }
/*     */         else {
/* 223 */           this.error = ex;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public final void onComplete()
/*     */     {
/* 230 */       if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 231 */         requiredWriteSubscriber().onComplete();
/* 232 */         return;
/*     */       }
/* 234 */       synchronized (this) {
/* 235 */         if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 236 */           requiredWriteSubscriber().onComplete();
/*     */         }
/* 238 */         else if (this.state == ChannelSendOperator.State.NEW) {
/* 239 */           this.completed = true;
/* 240 */           this.state = ChannelSendOperator.State.FIRST_SIGNAL_RECEIVED;
/*     */           try
/*     */           {
/* 243 */             result = (Publisher)ChannelSendOperator.this.writeFunction.apply(this);
/*     */           } catch (Throwable ex) {
/*     */             Publisher<Void> result;
/* 246 */             this.writeCompletionBarrier.onError(ex); return;
/*     */           }
/*     */           Publisher<Void> result;
/* 249 */           result.subscribe(this.writeCompletionBarrier);
/*     */         }
/*     */         else {
/* 252 */           this.completed = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public Context currentContext()
/*     */     {
/* 259 */       return this.writeCompletionBarrier.currentContext();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void request(long n)
/*     */     {
/* 267 */       Subscription s = this.subscription;
/* 268 */       if (s == null) {
/* 269 */         return;
/*     */       }
/* 271 */       if (this.state == ChannelSendOperator.State.READY_TO_WRITE) {
/* 272 */         s.request(n);
/* 273 */         return;
/*     */       }
/* 275 */       synchronized (this) {
/* 276 */         if (this.writeSubscriber != null) {
/* 277 */           if (this.state == ChannelSendOperator.State.EMITTING_CACHED_SIGNALS) {
/* 278 */             this.demandBeforeReadyToWrite = n;
/* 279 */             return;
/*     */           }
/*     */           try {
/* 282 */             this.state = ChannelSendOperator.State.EMITTING_CACHED_SIGNALS;
/* 283 */             if (emitCachedSignals())
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 292 */               this.state = ChannelSendOperator.State.READY_TO_WRITE;return;
/*     */             }
/* 286 */             n = n + this.demandBeforeReadyToWrite - 1L;
/* 287 */             if (n == 0L)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 292 */               this.state = ChannelSendOperator.State.READY_TO_WRITE;return; } } finally { this.state = ChannelSendOperator.State.READY_TO_WRITE;
/*     */           }
/*     */         }
/*     */       }
/* 296 */       s.request(n);
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     private boolean emitCachedSignals()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: getfield 33	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:error	Ljava/lang/Throwable;
/*     */       //   4: ifnull +32 -> 36
/*     */       //   7: aload_0
/*     */       //   8: invokespecial 15	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:requiredWriteSubscriber	()Lorg/reactivestreams/Subscriber;
/*     */       //   11: aload_0
/*     */       //   12: getfield 33	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:error	Ljava/lang/Throwable;
/*     */       //   15: invokeinterface 32 2 0
/*     */       //   20: aload_0
/*     */       //   21: invokespecial 1	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:releaseCachedItem	()V
/*     */       //   24: goto +10 -> 34
/*     */       //   27: astore_1
/*     */       //   28: aload_0
/*     */       //   29: invokespecial 1	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:releaseCachedItem	()V
/*     */       //   32: aload_1
/*     */       //   33: athrow
/*     */       //   34: iconst_1
/*     */       //   35: ireturn
/*     */       //   36: aload_0
/*     */       //   37: getfield 17	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:item	Ljava/lang/Object;
/*     */       //   40: astore_1
/*     */       //   41: aload_0
/*     */       //   42: aconst_null
/*     */       //   43: putfield 17	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:item	Ljava/lang/Object;
/*     */       //   46: aload_1
/*     */       //   47: ifnull +13 -> 60
/*     */       //   50: aload_0
/*     */       //   51: invokespecial 15	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:requiredWriteSubscriber	()Lorg/reactivestreams/Subscriber;
/*     */       //   54: aload_1
/*     */       //   55: invokeinterface 16 2 0
/*     */       //   60: aload_0
/*     */       //   61: getfield 4	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:completed	Z
/*     */       //   64: ifeq +14 -> 78
/*     */       //   67: aload_0
/*     */       //   68: invokespecial 15	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:requiredWriteSubscriber	()Lorg/reactivestreams/Subscriber;
/*     */       //   71: invokeinterface 34 1 0
/*     */       //   76: iconst_1
/*     */       //   77: ireturn
/*     */       //   78: iconst_0
/*     */       //   79: ireturn
/*     */       // Line number table:
/*     */       //   Java source line #300	-> byte code offset #0
/*     */       //   Java source line #302	-> byte code offset #7
/*     */       //   Java source line #305	-> byte code offset #20
/*     */       //   Java source line #306	-> byte code offset #24
/*     */       //   Java source line #305	-> byte code offset #27
/*     */       //   Java source line #306	-> byte code offset #32
/*     */       //   Java source line #307	-> byte code offset #34
/*     */       //   Java source line #309	-> byte code offset #36
/*     */       //   Java source line #310	-> byte code offset #41
/*     */       //   Java source line #311	-> byte code offset #46
/*     */       //   Java source line #312	-> byte code offset #50
/*     */       //   Java source line #314	-> byte code offset #60
/*     */       //   Java source line #315	-> byte code offset #67
/*     */       //   Java source line #316	-> byte code offset #76
/*     */       //   Java source line #318	-> byte code offset #78
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	80	0	this	ChannelSendOperator<T>.WriteBarrier
/*     */       //   27	6	1	localObject1	Object
/*     */       //   40	15	1	item	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   7	20	27	finally
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     public void cancel()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: getfield 10	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:subscription	Lorg/reactivestreams/Subscription;
/*     */       //   4: astore_1
/*     */       //   5: aload_1
/*     */       //   6: ifnull +28 -> 34
/*     */       //   9: aload_0
/*     */       //   10: aconst_null
/*     */       //   11: putfield 10	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:subscription	Lorg/reactivestreams/Subscription;
/*     */       //   14: aload_1
/*     */       //   15: invokeinterface 25 1 0
/*     */       //   20: aload_0
/*     */       //   21: invokespecial 1	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:releaseCachedItem	()V
/*     */       //   24: goto +10 -> 34
/*     */       //   27: astore_2
/*     */       //   28: aload_0
/*     */       //   29: invokespecial 1	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:releaseCachedItem	()V
/*     */       //   32: aload_2
/*     */       //   33: athrow
/*     */       //   34: return
/*     */       // Line number table:
/*     */       //   Java source line #323	-> byte code offset #0
/*     */       //   Java source line #324	-> byte code offset #5
/*     */       //   Java source line #325	-> byte code offset #9
/*     */       //   Java source line #327	-> byte code offset #14
/*     */       //   Java source line #330	-> byte code offset #20
/*     */       //   Java source line #331	-> byte code offset #24
/*     */       //   Java source line #330	-> byte code offset #27
/*     */       //   Java source line #331	-> byte code offset #32
/*     */       //   Java source line #333	-> byte code offset #34
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	35	0	this	ChannelSendOperator<T>.WriteBarrier
/*     */       //   4	11	1	s	Subscription
/*     */       //   27	6	2	localObject	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   14	20	27	finally
/*     */     }
/*     */     
/*     */     private void releaseCachedItem()
/*     */     {
/* 336 */       synchronized (this) {
/* 337 */         Object item = this.item;
/* 338 */         if ((item instanceof DataBuffer)) {
/* 339 */           DataBufferUtils.release((DataBuffer)item);
/*     */         }
/* 341 */         this.item = null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void subscribe(Subscriber<? super T> writeSubscriber)
/*     */     {
/* 350 */       synchronized (this) {
/* 351 */         Assert.state(this.writeSubscriber == null, "Only one write subscriber supported");
/* 352 */         this.writeSubscriber = writeSubscriber;
/* 353 */         if ((this.error != null) || (this.completed)) {
/* 354 */           this.writeSubscriber.onSubscribe(Operators.emptySubscription());
/* 355 */           emitCachedSignals();
/*     */         }
/*     */         else {
/* 358 */           this.writeSubscriber.onSubscribe(this);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private class WriteCompletionBarrier
/*     */     implements CoreSubscriber<Void>, Subscription
/*     */   {
/*     */     private final CoreSubscriber<? super Void> completionSubscriber;
/*     */     
/*     */ 
/*     */ 
/*     */     private final ChannelSendOperator<T>.WriteBarrier writeBarrier;
/*     */     
/*     */ 
/*     */ 
/*     */     @Nullable
/*     */     private Subscription subscription;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public WriteCompletionBarrier(ChannelSendOperator<T>.WriteBarrier subscriber)
/*     */     {
/* 386 */       this.completionSubscriber = subscriber;
/* 387 */       this.writeBarrier = writeBarrier;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void connect()
/*     */     {
/* 396 */       this.completionSubscriber.onSubscribe(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void onSubscribe(Subscription subscription)
/*     */     {
/* 403 */       this.subscription = subscription;
/* 404 */       subscription.request(Long.MAX_VALUE);
/*     */     }
/*     */     
/*     */     public void onNext(Void aVoid) {}
/*     */     
/*     */     /* Error */
/*     */     public void onError(Throwable ex)
/*     */     {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: getfield 3	org/springframework/http/server/reactive/ChannelSendOperator$WriteCompletionBarrier:completionSubscriber	Lreactor/core/CoreSubscriber;
/*     */       //   4: aload_1
/*     */       //   5: invokeinterface 11 2 0
/*     */       //   10: aload_0
/*     */       //   11: getfield 4	org/springframework/http/server/reactive/ChannelSendOperator$WriteCompletionBarrier:writeBarrier	Lorg/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier;
/*     */       //   14: invokestatic 12	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:access$100	(Lorg/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier;)V
/*     */       //   17: goto +13 -> 30
/*     */       //   20: astore_2
/*     */       //   21: aload_0
/*     */       //   22: getfield 4	org/springframework/http/server/reactive/ChannelSendOperator$WriteCompletionBarrier:writeBarrier	Lorg/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier;
/*     */       //   25: invokestatic 12	org/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier:access$100	(Lorg/springframework/http/server/reactive/ChannelSendOperator$WriteBarrier;)V
/*     */       //   28: aload_2
/*     */       //   29: athrow
/*     */       //   30: return
/*     */       // Line number table:
/*     */       //   Java source line #414	-> byte code offset #0
/*     */       //   Java source line #417	-> byte code offset #10
/*     */       //   Java source line #418	-> byte code offset #17
/*     */       //   Java source line #417	-> byte code offset #20
/*     */       //   Java source line #418	-> byte code offset #28
/*     */       //   Java source line #419	-> byte code offset #30
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	31	0	this	ChannelSendOperator<T>.WriteCompletionBarrier
/*     */       //   0	31	1	ex	Throwable
/*     */       //   20	9	2	localObject	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   0	10	20	finally
/*     */     }
/*     */     
/*     */     public void onComplete()
/*     */     {
/* 423 */       this.completionSubscriber.onComplete();
/*     */     }
/*     */     
/*     */     public Context currentContext()
/*     */     {
/* 428 */       return this.completionSubscriber.currentContext();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void request(long n) {}
/*     */     
/*     */ 
/*     */ 
/*     */     public void cancel()
/*     */     {
/* 439 */       this.writeBarrier.cancel();
/* 440 */       Subscription subscription = this.subscription;
/* 441 */       if (subscription != null) {
/* 442 */         subscription.cancel();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\server\reactive\ChannelSendOperator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */