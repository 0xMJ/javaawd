/*     */ package org.springframework.http.server;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface PathContainer
/*     */ {
/*     */   public abstract String value();
/*     */   
/*     */   public abstract List<Element> elements();
/*     */   
/*     */   public PathContainer subPath(int index)
/*     */   {
/*  53 */     return subPath(index, elements().size());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathContainer subPath(int startIndex, int endIndex)
/*     */   {
/*  64 */     return DefaultPathContainer.subPath(this, startIndex, endIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PathContainer parsePath(String path)
/*     */   {
/*  75 */     return DefaultPathContainer.createFromUrlPath(path, Options.HTTP_PATH);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PathContainer parsePath(String path, Options options)
/*     */   {
/*  87 */     return DefaultPathContainer.createFromUrlPath(path, options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Options
/*     */   {
/* 143 */     public static final Options HTTP_PATH = create('/', true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 151 */     public static final Options MESSAGE_ROUTE = create('.', false);
/*     */     
/*     */     private final char separator;
/*     */     private final boolean decodeAndParseSegments;
/*     */     
/*     */     private Options(char separator, boolean decodeAndParseSegments)
/*     */     {
/* 158 */       this.separator = separator;
/* 159 */       this.decodeAndParseSegments = decodeAndParseSegments;
/*     */     }
/*     */     
/*     */     public char separator() {
/* 163 */       return this.separator;
/*     */     }
/*     */     
/*     */     public boolean shouldDecodeAndParseSegments() {
/* 167 */       return this.decodeAndParseSegments;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static Options create(char separator, boolean decodeAndParseSegments)
/*     */     {
/* 179 */       return new Options(separator, decodeAndParseSegments);
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface PathSegment
/*     */     extends PathContainer.Element
/*     */   {
/*     */     public abstract String valueToMatch();
/*     */     
/*     */     public abstract char[] valueToMatchAsChars();
/*     */     
/*     */     public abstract MultiValueMap<String, String> parameters();
/*     */   }
/*     */   
/*     */   public static abstract interface Separator
/*     */     extends PathContainer.Element
/*     */   {}
/*     */   
/*     */   public static abstract interface Element
/*     */   {
/*     */     public abstract String value();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\server\PathContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */