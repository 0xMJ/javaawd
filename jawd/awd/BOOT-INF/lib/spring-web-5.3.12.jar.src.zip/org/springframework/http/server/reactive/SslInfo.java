package org.springframework.http.server.reactive;

import java.security.cert.X509Certificate;
import org.springframework.lang.Nullable;

public abstract interface SslInfo
{
  @Nullable
  public abstract String getSessionId();
  
  @Nullable
  public abstract X509Certificate[] getPeerCertificates();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\server\reactive\SslInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */