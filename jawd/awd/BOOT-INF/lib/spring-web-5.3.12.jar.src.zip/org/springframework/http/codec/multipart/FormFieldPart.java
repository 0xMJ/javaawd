package org.springframework.http.codec.multipart;

public abstract interface FormFieldPart
  extends Part
{
  public abstract String value();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\codec\multipart\FormFieldPart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */