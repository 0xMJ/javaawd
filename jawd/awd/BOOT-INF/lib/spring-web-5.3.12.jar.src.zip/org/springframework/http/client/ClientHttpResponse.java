package org.springframework.http.client;

import java.io.Closeable;
import java.io.IOException;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpStatus;

public abstract interface ClientHttpResponse
  extends HttpInputMessage, Closeable
{
  public abstract HttpStatus getStatusCode()
    throws IOException;
  
  public abstract int getRawStatusCode()
    throws IOException;
  
  public abstract String getStatusText()
    throws IOException;
  
  public abstract void close();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\client\ClientHttpResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */