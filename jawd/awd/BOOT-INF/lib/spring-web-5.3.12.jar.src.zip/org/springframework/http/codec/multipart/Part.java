package org.springframework.http.codec.multipart;

import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Flux;

public abstract interface Part
{
  public abstract String name();
  
  public abstract HttpHeaders headers();
  
  public abstract Flux<DataBuffer> content();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\codec\multipart\Part.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */