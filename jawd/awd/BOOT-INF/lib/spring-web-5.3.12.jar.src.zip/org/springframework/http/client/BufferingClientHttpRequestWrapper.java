/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BufferingClientHttpRequestWrapper
/*    */   extends AbstractBufferingClientHttpRequest
/*    */ {
/*    */   private final ClientHttpRequest request;
/*    */   
/*    */   BufferingClientHttpRequestWrapper(ClientHttpRequest request)
/*    */   {
/* 39 */     this.request = request;
/*    */   }
/*    */   
/*    */ 
/*    */   @Nullable
/*    */   public HttpMethod getMethod()
/*    */   {
/* 46 */     return this.request.getMethod();
/*    */   }
/*    */   
/*    */   public String getMethodValue()
/*    */   {
/* 51 */     return this.request.getMethodValue();
/*    */   }
/*    */   
/*    */   public URI getURI()
/*    */   {
/* 56 */     return this.request.getURI();
/*    */   }
/*    */   
/*    */   protected ClientHttpResponse executeInternal(HttpHeaders headers, byte[] bufferedOutput) throws IOException
/*    */   {
/* 61 */     this.request.getHeaders().putAll(headers);
/* 62 */     StreamUtils.copy(bufferedOutput, this.request.getBody());
/* 63 */     ClientHttpResponse response = this.request.execute();
/* 64 */     return new BufferingClientHttpResponseWrapper(response);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\client\BufferingClientHttpRequestWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */