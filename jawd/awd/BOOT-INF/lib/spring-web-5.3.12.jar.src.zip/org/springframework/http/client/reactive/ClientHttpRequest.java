package org.springframework.http.client.reactive;

import java.net.URI;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpMethod;
import org.springframework.http.ReactiveHttpOutputMessage;
import org.springframework.util.MultiValueMap;

public abstract interface ClientHttpRequest
  extends ReactiveHttpOutputMessage
{
  public abstract HttpMethod getMethod();
  
  public abstract URI getURI();
  
  public abstract MultiValueMap<String, HttpCookie> getCookies();
  
  public abstract <T> T getNativeRequest();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-web-5.3.12.jar!\org\springframework\http\client\reactive\ClientHttpRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */