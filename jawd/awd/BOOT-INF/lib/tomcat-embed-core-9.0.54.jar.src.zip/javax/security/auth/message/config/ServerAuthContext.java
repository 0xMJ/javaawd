package javax.security.auth.message.config;

import javax.security.auth.message.ServerAuth;

public abstract interface ServerAuthContext
  extends ServerAuth
{}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\security\auth\message\config\ServerAuthContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */