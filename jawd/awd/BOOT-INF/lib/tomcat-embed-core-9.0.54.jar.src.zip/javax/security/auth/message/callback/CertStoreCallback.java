/*    */ package javax.security.auth.message.callback;
/*    */ 
/*    */ import java.security.cert.CertStore;
/*    */ import javax.security.auth.callback.Callback;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CertStoreCallback
/*    */   implements Callback
/*    */ {
/*    */   private CertStore certStore;
/*    */   
/*    */   public void setCertStore(CertStore certStore)
/*    */   {
/* 35 */     this.certStore = certStore;
/*    */   }
/*    */   
/*    */   public CertStore getCertStore() {
/* 39 */     return this.certStore;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\security\auth\message\callback\CertStoreCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */