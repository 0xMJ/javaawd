/*    */ package javax.security.auth.message.callback;
/*    */ 
/*    */ import java.security.KeyStore;
/*    */ import javax.security.auth.callback.Callback;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrustStoreCallback
/*    */   implements Callback
/*    */ {
/*    */   private KeyStore trustStore;
/*    */   
/*    */   public void setTrustStore(KeyStore trustStore)
/*    */   {
/* 32 */     this.trustStore = trustStore;
/*    */   }
/*    */   
/*    */   public KeyStore getTrustStore() {
/* 36 */     return this.trustStore;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\security\auth\message\callback\TrustStoreCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */