/*    */ package javax.security.auth.message;
/*    */ 
/*    */ import javax.security.auth.login.LoginException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthException
/*    */   extends LoginException
/*    */ {
/*    */   private static final long serialVersionUID = -1156951780670243758L;
/*    */   
/*    */   public AuthException() {}
/*    */   
/*    */   public AuthException(String msg)
/*    */   {
/* 28 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\security\auth\message\AuthException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */