package javax.security.auth.message;

import javax.security.auth.Subject;

public abstract interface ClientAuth
{
  public abstract AuthStatus secureRequest(MessageInfo paramMessageInfo, Subject paramSubject)
    throws AuthException;
  
  public abstract AuthStatus validateResponse(MessageInfo paramMessageInfo, Subject paramSubject1, Subject paramSubject2)
    throws AuthException;
  
  public abstract void cleanSubject(MessageInfo paramMessageInfo, Subject paramSubject)
    throws AuthException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\security\auth\message\ClientAuth.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */