package javax.security.auth.message.config;

import javax.security.auth.message.MessageInfo;

public abstract interface AuthConfig
{
  public abstract String getMessageLayer();
  
  public abstract String getAppContext();
  
  public abstract String getAuthContextID(MessageInfo paramMessageInfo);
  
  public abstract void refresh();
  
  public abstract boolean isProtected();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\security\auth\message\config\AuthConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */