package javax.servlet;

import java.util.EventListener;

public abstract interface ServletRequestAttributeListener
  extends EventListener
{
  public void attributeAdded(ServletRequestAttributeEvent srae) {}
  
  public void attributeRemoved(ServletRequestAttributeEvent srae) {}
  
  public void attributeReplaced(ServletRequestAttributeEvent srae) {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\ServletRequestAttributeListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */