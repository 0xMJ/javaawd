package javax.servlet;

import java.util.Set;

public abstract interface ServletContainerInitializer
{
  public abstract void onStartup(Set<Class<?>> paramSet, ServletContext paramServletContext)
    throws ServletException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\ServletContainerInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */