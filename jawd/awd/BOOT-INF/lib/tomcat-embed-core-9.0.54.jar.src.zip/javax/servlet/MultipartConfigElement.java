/*     */ package javax.servlet;
/*     */ 
/*     */ import javax.servlet.annotation.MultipartConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipartConfigElement
/*     */ {
/*     */   private final String location;
/*     */   private final long maxFileSize;
/*     */   private final long maxRequestSize;
/*     */   private final int fileSizeThreshold;
/*     */   
/*     */   public MultipartConfigElement(String location)
/*     */   {
/*  43 */     if (location != null) {
/*  44 */       this.location = location;
/*     */     } else {
/*  46 */       this.location = "";
/*     */     }
/*  48 */     this.maxFileSize = -1L;
/*  49 */     this.maxRequestSize = -1L;
/*  50 */     this.fileSizeThreshold = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultipartConfigElement(String location, long maxFileSize, long maxRequestSize, int fileSizeThreshold)
/*     */   {
/*  67 */     if (location != null) {
/*  68 */       this.location = location;
/*     */     } else {
/*  70 */       this.location = "";
/*     */     }
/*  72 */     this.maxFileSize = maxFileSize;
/*  73 */     this.maxRequestSize = maxRequestSize;
/*     */     
/*     */ 
/*  76 */     if (fileSizeThreshold > 0) {
/*  77 */       this.fileSizeThreshold = fileSizeThreshold;
/*     */     } else {
/*  79 */       this.fileSizeThreshold = 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultipartConfigElement(MultipartConfig annotation)
/*     */   {
/*  90 */     this.location = annotation.location();
/*  91 */     this.maxFileSize = annotation.maxFileSize();
/*  92 */     this.maxRequestSize = annotation.maxRequestSize();
/*  93 */     this.fileSizeThreshold = annotation.fileSizeThreshold();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLocation()
/*     */   {
/* 102 */     return this.location;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMaxFileSize()
/*     */   {
/* 111 */     return this.maxFileSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMaxRequestSize()
/*     */   {
/* 120 */     return this.maxRequestSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFileSizeThreshold()
/*     */   {
/* 131 */     return this.fileSizeThreshold;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\MultipartConfigElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */