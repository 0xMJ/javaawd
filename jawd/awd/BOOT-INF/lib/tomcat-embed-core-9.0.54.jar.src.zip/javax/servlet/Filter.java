package javax.servlet;

import java.io.IOException;

public abstract interface Filter
{
  public void init(FilterConfig filterConfig)
    throws ServletException
  {}
  
  public abstract void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain)
    throws IOException, ServletException;
  
  public void destroy() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\Filter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */