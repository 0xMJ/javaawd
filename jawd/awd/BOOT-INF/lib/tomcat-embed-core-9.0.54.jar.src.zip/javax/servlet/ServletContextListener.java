package javax.servlet;

import java.util.EventListener;

public abstract interface ServletContextListener
  extends EventListener
{
  public void contextInitialized(ServletContextEvent sce) {}
  
  public void contextDestroyed(ServletContextEvent sce) {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\ServletContextListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */