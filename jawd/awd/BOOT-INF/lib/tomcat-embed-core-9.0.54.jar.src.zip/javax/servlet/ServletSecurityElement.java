/*     */ package javax.servlet;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.annotation.HttpConstraint;
/*     */ import javax.servlet.annotation.HttpMethodConstraint;
/*     */ import javax.servlet.annotation.ServletSecurity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletSecurityElement
/*     */   extends HttpConstraintElement
/*     */ {
/*  38 */   private final Map<String, HttpMethodConstraintElement> methodConstraints = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletSecurityElement() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletSecurityElement(HttpConstraintElement httpConstraintElement)
/*     */   {
/*  53 */     this(httpConstraintElement, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletSecurityElement(Collection<HttpMethodConstraintElement> httpMethodConstraints)
/*     */   {
/*  66 */     addHttpMethodConstraints(httpMethodConstraints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletSecurityElement(HttpConstraintElement httpConstraintElement, Collection<HttpMethodConstraintElement> httpMethodConstraints)
/*     */   {
/*  80 */     super(httpConstraintElement.getEmptyRoleSemantic(), httpConstraintElement
/*  81 */       .getTransportGuarantee(), httpConstraintElement
/*  82 */       .getRolesAllowed());
/*  83 */     addHttpMethodConstraints(httpMethodConstraints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletSecurityElement(ServletSecurity annotation)
/*     */   {
/*  93 */     this(new HttpConstraintElement(annotation.value().value(), annotation
/*  94 */       .value().transportGuarantee(), annotation
/*  95 */       .value().rolesAllowed()));
/*     */     
/*  97 */     List<HttpMethodConstraintElement> l = new ArrayList();
/*  98 */     HttpMethodConstraint[] constraints = annotation.httpMethodConstraints();
/*  99 */     if (constraints != null) {
/* 100 */       for (HttpMethodConstraint constraint : constraints)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 106 */         HttpMethodConstraintElement e = new HttpMethodConstraintElement(constraint.value(), new HttpConstraintElement(constraint.emptyRoleSemantic(), constraint.transportGuarantee(), constraint.rolesAllowed()));
/* 107 */         l.add(e);
/*     */       }
/*     */     }
/* 110 */     addHttpMethodConstraints(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<HttpMethodConstraintElement> getHttpMethodConstraints()
/*     */   {
/* 120 */     Collection<HttpMethodConstraintElement> result = new HashSet(this.methodConstraints.values());
/* 121 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<String> getMethodNames()
/*     */   {
/* 131 */     Collection<String> result = new HashSet(this.methodConstraints.keySet());
/* 132 */     return result;
/*     */   }
/*     */   
/*     */   private void addHttpMethodConstraints(Collection<HttpMethodConstraintElement> httpMethodConstraints)
/*     */   {
/* 137 */     if (httpMethodConstraints == null) {
/* 138 */       return;
/*     */     }
/* 140 */     for (HttpMethodConstraintElement constraint : httpMethodConstraints) {
/* 141 */       String method = constraint.getMethodName();
/* 142 */       if (this.methodConstraints.containsKey(method)) {
/* 143 */         throw new IllegalArgumentException("Duplicate method name: " + method);
/*     */       }
/*     */       
/* 146 */       this.methodConstraints.put(method, constraint);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\ServletSecurityElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */