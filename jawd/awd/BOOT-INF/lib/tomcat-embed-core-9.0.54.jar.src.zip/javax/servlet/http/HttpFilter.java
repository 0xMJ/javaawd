/*    */ package javax.servlet.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.GenericFilter;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HttpFilter
/*    */   extends GenericFilter
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 51 */     if (!(request instanceof HttpServletRequest)) {
/* 52 */       throw new ServletException(request + " not HttpServletRequest");
/*    */     }
/* 54 */     if (!(response instanceof HttpServletResponse)) {
/* 55 */       throw new ServletException(request + " not HttpServletResponse");
/*    */     }
/* 57 */     doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 97 */     chain.doFilter(request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\http\HttpFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */