package javax.servlet.http;

public abstract interface HttpUpgradeHandler
{
  public abstract void init(WebConnection paramWebConnection);
  
  public abstract void destroy();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\http\HttpUpgradeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */