/*     */ package javax.servlet.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import javax.servlet.ServletResponseWrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpServletResponseWrapper
/*     */   extends ServletResponseWrapper
/*     */   implements HttpServletResponse
/*     */ {
/*     */   public HttpServletResponseWrapper(HttpServletResponse response)
/*     */   {
/*  47 */     super(response);
/*     */   }
/*     */   
/*     */   private HttpServletResponse _getHttpServletResponse() {
/*  51 */     return (HttpServletResponse)super.getResponse();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCookie(Cookie cookie)
/*     */   {
/*  60 */     _getHttpServletResponse().addCookie(cookie);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsHeader(String name)
/*     */   {
/*  69 */     return _getHttpServletResponse().containsHeader(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String encodeURL(String url)
/*     */   {
/*  78 */     return _getHttpServletResponse().encodeURL(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String encodeRedirectURL(String url)
/*     */   {
/*  87 */     return _getHttpServletResponse().encodeRedirectURL(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public String encodeUrl(String url)
/*     */   {
/*  99 */     return _getHttpServletResponse().encodeUrl(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public String encodeRedirectUrl(String url)
/*     */   {
/* 111 */     return _getHttpServletResponse().encodeRedirectUrl(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sendError(int sc, String msg)
/*     */     throws IOException
/*     */   {
/* 120 */     _getHttpServletResponse().sendError(sc, msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sendError(int sc)
/*     */     throws IOException
/*     */   {
/* 129 */     _getHttpServletResponse().sendError(sc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sendRedirect(String location)
/*     */     throws IOException
/*     */   {
/* 138 */     _getHttpServletResponse().sendRedirect(location);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateHeader(String name, long date)
/*     */   {
/* 147 */     _getHttpServletResponse().setDateHeader(name, date);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDateHeader(String name, long date)
/*     */   {
/* 156 */     _getHttpServletResponse().addDateHeader(name, date);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeader(String name, String value)
/*     */   {
/* 165 */     _getHttpServletResponse().setHeader(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addHeader(String name, String value)
/*     */   {
/* 174 */     _getHttpServletResponse().addHeader(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIntHeader(String name, int value)
/*     */   {
/* 183 */     _getHttpServletResponse().setIntHeader(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIntHeader(String name, int value)
/*     */   {
/* 192 */     _getHttpServletResponse().addIntHeader(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatus(int sc)
/*     */   {
/* 201 */     _getHttpServletResponse().setStatus(sc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setStatus(int sc, String sm)
/*     */   {
/* 213 */     _getHttpServletResponse().setStatus(sc, sm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStatus()
/*     */   {
/* 227 */     return _getHttpServletResponse().getStatus();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHeader(String name)
/*     */   {
/* 241 */     return _getHttpServletResponse().getHeader(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<String> getHeaders(String name)
/*     */   {
/* 255 */     return _getHttpServletResponse().getHeaders(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<String> getHeaderNames()
/*     */   {
/* 269 */     return _getHttpServletResponse().getHeaderNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTrailerFields(Supplier<Map<String, String>> supplier)
/*     */   {
/* 283 */     _getHttpServletResponse().setTrailerFields(supplier);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Supplier<Map<String, String>> getTrailerFields()
/*     */   {
/* 297 */     return _getHttpServletResponse().getTrailerFields();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\http\HttpServletResponseWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */