/*      */ package javax.servlet.http;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Enumeration;
/*      */ import java.util.ResourceBundle;
/*      */ import javax.servlet.AsyncContext;
/*      */ import javax.servlet.AsyncEvent;
/*      */ import javax.servlet.AsyncListener;
/*      */ import javax.servlet.DispatcherType;
/*      */ import javax.servlet.GenericServlet;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.WriteListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class HttpServlet
/*      */   extends GenericServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   private static final String METHOD_DELETE = "DELETE";
/*      */   private static final String METHOD_HEAD = "HEAD";
/*      */   private static final String METHOD_GET = "GET";
/*      */   private static final String METHOD_OPTIONS = "OPTIONS";
/*      */   private static final String METHOD_POST = "POST";
/*      */   private static final String METHOD_PUT = "PUT";
/*      */   private static final String METHOD_TRACE = "TRACE";
/*      */   private static final String HEADER_IFMODSINCE = "If-Modified-Since";
/*      */   private static final String HEADER_LASTMOD = "Last-Modified";
/*      */   private static final String LSTRING_FILE = "javax.servlet.http.LocalStrings";
/*   94 */   private static final ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.http.LocalStrings");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doGet(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  172 */     String msg = lStrings.getString("http.method_get_not_supported");
/*  173 */     sendMethodNotAllowed(req, resp, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long getLastModified(HttpServletRequest req)
/*      */   {
/*  199 */     return -1L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doHead(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  237 */     if (DispatcherType.INCLUDE.equals(req.getDispatcherType())) {
/*  238 */       doGet(req, resp);
/*      */     } else {
/*  240 */       NoBodyResponse response = new NoBodyResponse(resp, null);
/*  241 */       doGet(req, response);
/*  242 */       if (req.isAsyncStarted()) {
/*  243 */         req.getAsyncContext().addListener(new NoBodyAsyncContextListener(response));
/*      */       } else {
/*  245 */         response.setContentLength();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doPost(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  311 */     String msg = lStrings.getString("http.method_post_not_supported");
/*  312 */     sendMethodNotAllowed(req, resp, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doPut(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  361 */     String msg = lStrings.getString("http.method_put_not_supported");
/*  362 */     sendMethodNotAllowed(req, resp, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doDelete(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  404 */     String msg = lStrings.getString("http.method_delete_not_supported");
/*  405 */     sendMethodNotAllowed(req, resp, msg);
/*      */   }
/*      */   
/*      */   private void sendMethodNotAllowed(HttpServletRequest req, HttpServletResponse resp, String msg) throws IOException
/*      */   {
/*  410 */     String protocol = req.getProtocol();
/*      */     
/*      */ 
/*  413 */     if ((protocol.length() == 0) || (protocol.endsWith("0.9")) || (protocol.endsWith("1.0"))) {
/*  414 */       resp.sendError(400, msg);
/*      */     } else {
/*  416 */       resp.sendError(405, msg);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static Method[] getAllDeclaredMethods(Class<?> c)
/*      */   {
/*  423 */     if (c.equals(HttpServlet.class)) {
/*  424 */       return null;
/*      */     }
/*      */     
/*  427 */     Method[] parentMethods = getAllDeclaredMethods(c.getSuperclass());
/*  428 */     Method[] thisMethods = c.getDeclaredMethods();
/*      */     
/*  430 */     if ((parentMethods != null) && (parentMethods.length > 0)) {
/*  431 */       Method[] allMethods = new Method[parentMethods.length + thisMethods.length];
/*  432 */       System.arraycopy(parentMethods, 0, allMethods, 0, parentMethods.length);
/*  433 */       System.arraycopy(thisMethods, 0, allMethods, parentMethods.length, thisMethods.length);
/*  434 */       thisMethods = allMethods;
/*      */     }
/*      */     
/*  437 */     return thisMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doOptions(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  476 */     Method[] methods = getAllDeclaredMethods(getClass());
/*      */     
/*  478 */     boolean ALLOW_GET = false;
/*  479 */     boolean ALLOW_HEAD = false;
/*  480 */     boolean ALLOW_POST = false;
/*  481 */     boolean ALLOW_PUT = false;
/*  482 */     boolean ALLOW_DELETE = false;
/*  483 */     boolean ALLOW_TRACE = true;
/*  484 */     boolean ALLOW_OPTIONS = true;
/*      */     
/*      */ 
/*  487 */     Class<?> clazz = null;
/*      */     try {
/*  489 */       clazz = Class.forName("org.apache.catalina.connector.RequestFacade");
/*  490 */       Method getAllowTrace = clazz.getMethod("getAllowTrace", (Class[])null);
/*  491 */       ALLOW_TRACE = ((Boolean)getAllowTrace.invoke(req, (Object[])null)).booleanValue();
/*      */     }
/*      */     catch (ClassNotFoundException|NoSuchMethodException|SecurityException|IllegalAccessException|IllegalArgumentException|InvocationTargetException localClassNotFoundException) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  498 */     for (int i = 0; i < methods.length; i++) {
/*  499 */       Method m = methods[i];
/*      */       
/*  501 */       if (m.getName().equals("doGet")) {
/*  502 */         ALLOW_GET = true;
/*  503 */         ALLOW_HEAD = true;
/*      */       }
/*  505 */       if (m.getName().equals("doPost")) {
/*  506 */         ALLOW_POST = true;
/*      */       }
/*  508 */       if (m.getName().equals("doPut")) {
/*  509 */         ALLOW_PUT = true;
/*      */       }
/*  511 */       if (m.getName().equals("doDelete")) {
/*  512 */         ALLOW_DELETE = true;
/*      */       }
/*      */     }
/*      */     
/*  516 */     String allow = null;
/*  517 */     if (ALLOW_GET) {
/*  518 */       allow = "GET";
/*      */     }
/*  520 */     if (ALLOW_HEAD) {
/*  521 */       if (allow == null) {
/*  522 */         allow = "HEAD";
/*      */       } else {
/*  524 */         allow = allow + ", HEAD";
/*      */       }
/*      */     }
/*  527 */     if (ALLOW_POST) {
/*  528 */       if (allow == null) {
/*  529 */         allow = "POST";
/*      */       } else {
/*  531 */         allow = allow + ", POST";
/*      */       }
/*      */     }
/*  534 */     if (ALLOW_PUT) {
/*  535 */       if (allow == null) {
/*  536 */         allow = "PUT";
/*      */       } else {
/*  538 */         allow = allow + ", PUT";
/*      */       }
/*      */     }
/*  541 */     if (ALLOW_DELETE) {
/*  542 */       if (allow == null) {
/*  543 */         allow = "DELETE";
/*      */       } else {
/*  545 */         allow = allow + ", DELETE";
/*      */       }
/*      */     }
/*  548 */     if (ALLOW_TRACE) {
/*  549 */       if (allow == null) {
/*  550 */         allow = "TRACE";
/*      */       } else {
/*  552 */         allow = allow + ", TRACE";
/*      */       }
/*      */     }
/*  555 */     if (ALLOW_OPTIONS) {
/*  556 */       if (allow == null) {
/*  557 */         allow = "OPTIONS";
/*      */       } else {
/*  559 */         allow = allow + ", OPTIONS";
/*      */       }
/*      */     }
/*      */     
/*  563 */     resp.setHeader("Allow", allow);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doTrace(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  596 */     String CRLF = "\r\n";
/*      */     
/*  598 */     StringBuilder buffer = new StringBuilder("TRACE ").append(req.getRequestURI()).append(" ").append(req.getProtocol());
/*      */     
/*  600 */     Enumeration<String> reqHeaderEnum = req.getHeaderNames();
/*      */     
/*  602 */     while (reqHeaderEnum.hasMoreElements()) {
/*  603 */       String headerName = (String)reqHeaderEnum.nextElement();
/*  604 */       buffer.append(CRLF).append(headerName).append(": ")
/*  605 */         .append(req.getHeader(headerName));
/*      */     }
/*      */     
/*  608 */     buffer.append(CRLF);
/*      */     
/*  610 */     int responseLength = buffer.length();
/*      */     
/*  612 */     resp.setContentType("message/http");
/*  613 */     resp.setContentLength(responseLength);
/*  614 */     ServletOutputStream out = resp.getOutputStream();
/*  615 */     out.print(buffer.toString());
/*  616 */     out.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void service(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  648 */     String method = req.getMethod();
/*      */     
/*  650 */     if (method.equals("GET")) {
/*  651 */       long lastModified = getLastModified(req);
/*  652 */       if (lastModified == -1L)
/*      */       {
/*      */ 
/*  655 */         doGet(req, resp);
/*      */       } else {
/*      */         long ifModifiedSince;
/*      */         try {
/*  659 */           ifModifiedSince = req.getDateHeader("If-Modified-Since");
/*      */         } catch (IllegalArgumentException iae) {
/*      */           long ifModifiedSince;
/*  662 */           ifModifiedSince = -1L;
/*      */         }
/*  664 */         if (ifModifiedSince < lastModified / 1000L * 1000L)
/*      */         {
/*      */ 
/*      */ 
/*  668 */           maybeSetLastModified(resp, lastModified);
/*  669 */           doGet(req, resp);
/*      */         } else {
/*  671 */           resp.setStatus(304);
/*      */         }
/*      */       }
/*      */     }
/*  675 */     else if (method.equals("HEAD")) {
/*  676 */       long lastModified = getLastModified(req);
/*  677 */       maybeSetLastModified(resp, lastModified);
/*  678 */       doHead(req, resp);
/*      */     }
/*  680 */     else if (method.equals("POST")) {
/*  681 */       doPost(req, resp);
/*      */     }
/*  683 */     else if (method.equals("PUT")) {
/*  684 */       doPut(req, resp);
/*      */     }
/*  686 */     else if (method.equals("DELETE")) {
/*  687 */       doDelete(req, resp);
/*      */     }
/*  689 */     else if (method.equals("OPTIONS")) {
/*  690 */       doOptions(req, resp);
/*      */     }
/*  692 */     else if (method.equals("TRACE")) {
/*  693 */       doTrace(req, resp);
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*  701 */       String errMsg = lStrings.getString("http.method_not_implemented");
/*  702 */       Object[] errArgs = new Object[1];
/*  703 */       errArgs[0] = method;
/*  704 */       errMsg = MessageFormat.format(errMsg, errArgs);
/*      */       
/*  706 */       resp.sendError(501, errMsg);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void maybeSetLastModified(HttpServletResponse resp, long lastModified)
/*      */   {
/*  720 */     if (resp.containsHeader("Last-Modified")) {
/*  721 */       return;
/*      */     }
/*  723 */     if (lastModified >= 0L) {
/*  724 */       resp.setDateHeader("Last-Modified", lastModified);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void service(ServletRequest req, ServletResponse res)
/*      */     throws ServletException, IOException
/*      */   {
/*      */     try
/*      */     {
/*  759 */       HttpServletRequest request = (HttpServletRequest)req;
/*  760 */       response = (HttpServletResponse)res;
/*      */     } catch (ClassCastException e) { HttpServletResponse response;
/*  762 */       throw new ServletException(lStrings.getString("http.non_http")); }
/*      */     HttpServletResponse response;
/*  764 */     HttpServletRequest request; service(request, response);
/*      */   }
/*      */   
/*      */ 
/*      */   private static class NoBodyResponse
/*      */     extends HttpServletResponseWrapper
/*      */   {
/*      */     private final HttpServlet.NoBodyOutputStream noBodyOutputStream;
/*      */     
/*      */     private ServletOutputStream originalOutputStream;
/*      */     
/*      */     private HttpServlet.NoBodyPrintWriter noBodyWriter;
/*      */     
/*      */     private boolean didSetContentLength;
/*      */     
/*      */     private NoBodyResponse(HttpServletResponse r)
/*      */     {
/*  781 */       super();
/*  782 */       this.noBodyOutputStream = new HttpServlet.NoBodyOutputStream(this, null);
/*      */     }
/*      */     
/*      */     private void setContentLength() {
/*  786 */       if (!this.didSetContentLength) {
/*  787 */         if (this.noBodyWriter != null) {
/*  788 */           this.noBodyWriter.flush();
/*      */         }
/*  790 */         super.setContentLengthLong(this.noBodyOutputStream.getWrittenByteCount());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void setContentLength(int len)
/*      */     {
/*  797 */       super.setContentLength(len);
/*  798 */       this.didSetContentLength = true;
/*      */     }
/*      */     
/*      */     public void setContentLengthLong(long len)
/*      */     {
/*  803 */       super.setContentLengthLong(len);
/*  804 */       this.didSetContentLength = true;
/*      */     }
/*      */     
/*      */     public void setHeader(String name, String value)
/*      */     {
/*  809 */       super.setHeader(name, value);
/*  810 */       checkHeader(name);
/*      */     }
/*      */     
/*      */     public void addHeader(String name, String value)
/*      */     {
/*  815 */       super.addHeader(name, value);
/*  816 */       checkHeader(name);
/*      */     }
/*      */     
/*      */     public void setIntHeader(String name, int value)
/*      */     {
/*  821 */       super.setIntHeader(name, value);
/*  822 */       checkHeader(name);
/*      */     }
/*      */     
/*      */     public void addIntHeader(String name, int value)
/*      */     {
/*  827 */       super.addIntHeader(name, value);
/*  828 */       checkHeader(name);
/*      */     }
/*      */     
/*      */     private void checkHeader(String name) {
/*  832 */       if ("content-length".equalsIgnoreCase(name)) {
/*  833 */         this.didSetContentLength = true;
/*      */       }
/*      */     }
/*      */     
/*      */     public ServletOutputStream getOutputStream() throws IOException
/*      */     {
/*  839 */       this.originalOutputStream = getResponse().getOutputStream();
/*  840 */       return this.noBodyOutputStream;
/*      */     }
/*      */     
/*      */     public PrintWriter getWriter()
/*      */       throws UnsupportedEncodingException
/*      */     {
/*  846 */       if (this.noBodyWriter == null) {
/*  847 */         this.noBodyWriter = new HttpServlet.NoBodyPrintWriter(this.noBodyOutputStream, getCharacterEncoding());
/*      */       }
/*  849 */       return this.noBodyWriter;
/*      */     }
/*      */     
/*      */     public void reset()
/*      */     {
/*  854 */       super.reset();
/*  855 */       resetBuffer();
/*  856 */       this.originalOutputStream = null;
/*      */     }
/*      */     
/*      */     public void resetBuffer()
/*      */     {
/*  861 */       this.noBodyOutputStream.resetBuffer();
/*  862 */       if (this.noBodyWriter != null) {
/*  863 */         this.noBodyWriter.resetBuffer();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class NoBodyOutputStream
/*      */     extends ServletOutputStream
/*      */   {
/*      */     private static final String LSTRING_FILE = "javax.servlet.http.LocalStrings";
/*      */     
/*  875 */     private static final ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.http.LocalStrings");
/*      */     
/*      */     private final HttpServlet.NoBodyResponse response;
/*  878 */     private boolean flushed = false;
/*  879 */     private long writtenByteCount = 0L;
/*      */     
/*      */     private NoBodyOutputStream(HttpServlet.NoBodyResponse response) {
/*  882 */       this.response = response;
/*      */     }
/*      */     
/*      */     private long getWrittenByteCount() {
/*  886 */       return this.writtenByteCount;
/*      */     }
/*      */     
/*      */     public void write(int b) throws IOException
/*      */     {
/*  891 */       this.writtenByteCount += 1L;
/*  892 */       checkCommit();
/*      */     }
/*      */     
/*      */     public void write(byte[] buf, int offset, int len) throws IOException
/*      */     {
/*  897 */       if (buf == null)
/*      */       {
/*  899 */         throw new NullPointerException(lStrings.getString("err.io.nullArray"));
/*      */       }
/*      */       
/*  902 */       if ((offset < 0) || (len < 0) || (offset + len > buf.length)) {
/*  903 */         String msg = lStrings.getString("err.io.indexOutOfBounds");
/*  904 */         Object[] msgArgs = new Object[3];
/*  905 */         msgArgs[0] = Integer.valueOf(offset);
/*  906 */         msgArgs[1] = Integer.valueOf(len);
/*  907 */         msgArgs[2] = Integer.valueOf(buf.length);
/*  908 */         msg = MessageFormat.format(msg, msgArgs);
/*  909 */         throw new IndexOutOfBoundsException(msg);
/*      */       }
/*      */       
/*  912 */       this.writtenByteCount += len;
/*  913 */       checkCommit();
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean isReady()
/*      */     {
/*  919 */       return true;
/*      */     }
/*      */     
/*      */     public void setWriteListener(WriteListener listener)
/*      */     {
/*  924 */       HttpServlet.NoBodyResponse.access$600(this.response).setWriteListener(listener);
/*      */     }
/*      */     
/*      */     private void checkCommit() throws IOException {
/*  928 */       if ((!this.flushed) && (this.writtenByteCount > this.response.getBufferSize())) {
/*  929 */         this.response.flushBuffer();
/*  930 */         this.flushed = true;
/*      */       }
/*      */     }
/*      */     
/*      */     private void resetBuffer() {
/*  935 */       if (this.flushed) {
/*  936 */         throw new IllegalStateException(lStrings.getString("err.state.commit"));
/*      */       }
/*  938 */       this.writtenByteCount = 0L;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class NoBodyPrintWriter
/*      */     extends PrintWriter
/*      */   {
/*      */     private final HttpServlet.NoBodyOutputStream out;
/*      */     
/*      */     private final String encoding;
/*      */     
/*      */     private PrintWriter pw;
/*      */     
/*      */ 
/*      */     public NoBodyPrintWriter(HttpServlet.NoBodyOutputStream out, String encoding)
/*      */       throws UnsupportedEncodingException
/*      */     {
/*  957 */       super();
/*  958 */       this.out = out;
/*  959 */       this.encoding = encoding;
/*      */       
/*  961 */       Writer osw = new OutputStreamWriter(out, encoding);
/*  962 */       this.pw = new PrintWriter(osw);
/*      */     }
/*      */     
/*      */     private void resetBuffer() {
/*  966 */       HttpServlet.NoBodyOutputStream.access$400(this.out);
/*      */       
/*  968 */       Writer osw = null;
/*      */       try {
/*  970 */         osw = new OutputStreamWriter(this.out, this.encoding);
/*      */       }
/*      */       catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  977 */       this.pw = new PrintWriter(osw);
/*      */     }
/*      */     
/*      */     public void flush()
/*      */     {
/*  982 */       this.pw.flush();
/*      */     }
/*      */     
/*      */     public void close()
/*      */     {
/*  987 */       this.pw.close();
/*      */     }
/*      */     
/*      */     public boolean checkError()
/*      */     {
/*  992 */       return this.pw.checkError();
/*      */     }
/*      */     
/*      */     public void write(int c)
/*      */     {
/*  997 */       this.pw.write(c);
/*      */     }
/*      */     
/*      */     public void write(char[] buf, int off, int len)
/*      */     {
/* 1002 */       this.pw.write(buf, off, len);
/*      */     }
/*      */     
/*      */     public void write(char[] buf)
/*      */     {
/* 1007 */       this.pw.write(buf);
/*      */     }
/*      */     
/*      */     public void write(String s, int off, int len)
/*      */     {
/* 1012 */       this.pw.write(s, off, len);
/*      */     }
/*      */     
/*      */     public void write(String s)
/*      */     {
/* 1017 */       this.pw.write(s);
/*      */     }
/*      */     
/*      */     public void print(boolean b)
/*      */     {
/* 1022 */       this.pw.print(b);
/*      */     }
/*      */     
/*      */     public void print(char c)
/*      */     {
/* 1027 */       this.pw.print(c);
/*      */     }
/*      */     
/*      */     public void print(int i)
/*      */     {
/* 1032 */       this.pw.print(i);
/*      */     }
/*      */     
/*      */     public void print(long l)
/*      */     {
/* 1037 */       this.pw.print(l);
/*      */     }
/*      */     
/*      */     public void print(float f)
/*      */     {
/* 1042 */       this.pw.print(f);
/*      */     }
/*      */     
/*      */     public void print(double d)
/*      */     {
/* 1047 */       this.pw.print(d);
/*      */     }
/*      */     
/*      */     public void print(char[] s)
/*      */     {
/* 1052 */       this.pw.print(s);
/*      */     }
/*      */     
/*      */     public void print(String s)
/*      */     {
/* 1057 */       this.pw.print(s);
/*      */     }
/*      */     
/*      */     public void print(Object obj)
/*      */     {
/* 1062 */       this.pw.print(obj);
/*      */     }
/*      */     
/*      */     public void println()
/*      */     {
/* 1067 */       this.pw.println();
/*      */     }
/*      */     
/*      */     public void println(boolean x)
/*      */     {
/* 1072 */       this.pw.println(x);
/*      */     }
/*      */     
/*      */     public void println(char x)
/*      */     {
/* 1077 */       this.pw.println(x);
/*      */     }
/*      */     
/*      */     public void println(int x)
/*      */     {
/* 1082 */       this.pw.println(x);
/*      */     }
/*      */     
/*      */     public void println(long x)
/*      */     {
/* 1087 */       this.pw.println(x);
/*      */     }
/*      */     
/*      */     public void println(float x)
/*      */     {
/* 1092 */       this.pw.println(x);
/*      */     }
/*      */     
/*      */     public void println(double x)
/*      */     {
/* 1097 */       this.pw.println(x);
/*      */     }
/*      */     
/*      */     public void println(char[] x)
/*      */     {
/* 1102 */       this.pw.println(x);
/*      */     }
/*      */     
/*      */     public void println(String x)
/*      */     {
/* 1107 */       this.pw.println(x);
/*      */     }
/*      */     
/*      */     public void println(Object x)
/*      */     {
/* 1112 */       this.pw.println(x);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class NoBodyAsyncContextListener
/*      */     implements AsyncListener
/*      */   {
/*      */     private final HttpServlet.NoBodyResponse noBodyResponse;
/*      */     
/*      */ 
/*      */     public NoBodyAsyncContextListener(HttpServlet.NoBodyResponse noBodyResponse)
/*      */     {
/* 1126 */       this.noBodyResponse = noBodyResponse;
/*      */     }
/*      */     
/*      */     public void onComplete(AsyncEvent event) throws IOException
/*      */     {
/* 1131 */       HttpServlet.NoBodyResponse.access$100(this.noBodyResponse);
/*      */     }
/*      */     
/*      */     public void onTimeout(AsyncEvent event)
/*      */       throws IOException
/*      */     {}
/*      */     
/*      */     public void onError(AsyncEvent event)
/*      */       throws IOException
/*      */     {}
/*      */     
/*      */     public void onStartAsync(AsyncEvent event)
/*      */       throws IOException
/*      */     {}
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\http\HttpServlet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */