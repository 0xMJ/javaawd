package javax.servlet.http;

public enum MappingMatch
{
  CONTEXT_ROOT,  DEFAULT,  EXACT,  EXTENSION,  PATH;
  
  private MappingMatch() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\http\MappingMatch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */