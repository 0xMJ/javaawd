package javax.servlet.http;

import java.util.EventListener;

public abstract interface HttpSessionActivationListener
  extends EventListener
{
  public void sessionWillPassivate(HttpSessionEvent se) {}
  
  public void sessionDidActivate(HttpSessionEvent se) {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\http\HttpSessionActivationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */