package javax.servlet.http;

import java.util.EventListener;

public abstract interface HttpSessionAttributeListener
  extends EventListener
{
  public void attributeAdded(HttpSessionBindingEvent se) {}
  
  public void attributeRemoved(HttpSessionBindingEvent se) {}
  
  public void attributeReplaced(HttpSessionBindingEvent se) {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\http\HttpSessionAttributeListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */