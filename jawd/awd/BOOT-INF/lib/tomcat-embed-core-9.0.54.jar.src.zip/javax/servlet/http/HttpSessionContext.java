package javax.servlet.http;

import java.util.Enumeration;

@Deprecated
public abstract interface HttpSessionContext
{
  @Deprecated
  public abstract HttpSession getSession(String paramString);
  
  @Deprecated
  public abstract Enumeration<String> getIds();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\http\HttpSessionContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */