/*     */ package javax.servlet.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Hashtable;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.ServletInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class HttpUtils
/*     */ {
/*     */   private static final String LSTRING_FILE = "javax.servlet.http.LocalStrings";
/*  39 */   private static final ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.http.LocalStrings");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Hashtable<String, String[]> parseQueryString(String s)
/*     */   {
/*  84 */     String[] valArray = null;
/*     */     
/*  86 */     if (s == null) {
/*  87 */       throw new IllegalArgumentException();
/*     */     }
/*  89 */     Hashtable<String, String[]> ht = new Hashtable();
/*  90 */     StringBuilder sb = new StringBuilder();
/*  91 */     StringTokenizer st = new StringTokenizer(s, "&");
/*  92 */     while (st.hasMoreTokens()) {
/*  93 */       String pair = st.nextToken();
/*  94 */       int pos = pair.indexOf('=');
/*  95 */       if (pos == -1)
/*     */       {
/*     */ 
/*  98 */         throw new IllegalArgumentException();
/*     */       }
/* 100 */       String key = parseName(pair.substring(0, pos), sb);
/* 101 */       String val = parseName(pair.substring(pos + 1), sb);
/* 102 */       if (ht.containsKey(key)) {
/* 103 */         String[] oldVals = (String[])ht.get(key);
/* 104 */         valArray = (String[])Arrays.copyOf(oldVals, oldVals.length + 1);
/* 105 */         valArray[oldVals.length] = val;
/*     */       } else {
/* 107 */         valArray = new String[1];
/* 108 */         valArray[0] = val;
/*     */       }
/* 110 */       ht.put(key, valArray);
/*     */     }
/* 112 */     return ht;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Hashtable<String, String[]> parsePostData(int len, ServletInputStream in)
/*     */   {
/* 161 */     if (len <= 0) {
/* 162 */       return new Hashtable();
/*     */     }
/*     */     
/* 165 */     if (in == null) {
/* 166 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*     */ 
/* 170 */     byte[] postedBytes = new byte[len];
/*     */     try {
/* 172 */       int offset = 0;
/*     */       do
/*     */       {
/* 175 */         int inputLen = in.read(postedBytes, offset, len - offset);
/* 176 */         if (inputLen <= 0) {
/* 177 */           String msg = lStrings.getString("err.io.short_read");
/* 178 */           throw new IllegalArgumentException(msg);
/*     */         }
/* 180 */         offset += inputLen;
/* 181 */       } while (len - offset > 0);
/*     */     }
/*     */     catch (IOException e) {
/* 184 */       throw new IllegalArgumentException(e.getMessage(), e);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 191 */       String postedBody = new String(postedBytes, 0, len, "8859_1");
/* 192 */       return parseQueryString(postedBody);
/*     */     }
/*     */     catch (UnsupportedEncodingException e)
/*     */     {
/* 196 */       throw new IllegalArgumentException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String parseName(String s, StringBuilder sb)
/*     */   {
/* 205 */     sb.setLength(0);
/* 206 */     for (int i = 0; i < s.length(); i++) {
/* 207 */       char c = s.charAt(i);
/* 208 */       switch (c) {
/*     */       case '+': 
/* 210 */         sb.append(' ');
/* 211 */         break;
/*     */       case '%': 
/*     */         try {
/* 214 */           sb.append((char)Integer.parseInt(s.substring(i + 1, i + 3), 16));
/*     */           
/* 216 */           i += 2;
/*     */         }
/*     */         catch (NumberFormatException e)
/*     */         {
/* 220 */           throw new IllegalArgumentException();
/*     */         } catch (StringIndexOutOfBoundsException e) {
/* 222 */           String rest = s.substring(i);
/* 223 */           sb.append(rest);
/* 224 */           if (rest.length() == 2) {
/* 225 */             i++;
/*     */           }
/*     */         }
/*     */       
/*     */ 
/*     */       default: 
/* 231 */         sb.append(c);
/*     */       }
/*     */       
/*     */     }
/* 235 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static StringBuffer getRequestURL(HttpServletRequest req)
/*     */   {
/* 262 */     StringBuffer url = new StringBuffer();
/* 263 */     String scheme = req.getScheme();
/* 264 */     int port = req.getServerPort();
/* 265 */     String urlPath = req.getRequestURI();
/*     */     
/* 267 */     url.append(scheme);
/* 268 */     url.append("://");
/* 269 */     url.append(req.getServerName());
/* 270 */     if (((scheme.equals("http")) && (port != 80)) || ((scheme.equals("https")) && (port != 443))) {
/* 271 */       url.append(':');
/* 272 */       url.append(req.getServerPort());
/*     */     }
/*     */     
/* 275 */     url.append(urlPath);
/* 276 */     return url;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\http\HttpUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */