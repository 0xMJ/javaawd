/*     */ package javax.servlet;
/*     */ 
/*     */ import java.io.CharConversionException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ServletOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   private static final String LSTRING_FILE = "javax.servlet.LocalStrings";
/*  39 */   private static final ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.LocalStrings");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void print(String s)
/*     */     throws IOException
/*     */   {
/*  58 */     if (s == null) {
/*  59 */       s = "null";
/*     */     }
/*  61 */     int len = s.length();
/*  62 */     byte[] buffer = new byte[len];
/*     */     
/*  64 */     for (int i = 0; i < len; i++) {
/*  65 */       char c = s.charAt(i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */       if ((c & 0xFF00) != 0) {
/*  74 */         String errMsg = lStrings.getString("err.not_iso8859_1");
/*  75 */         Object[] errArgs = new Object[1];
/*  76 */         errArgs[0] = Character.valueOf(c);
/*  77 */         errMsg = MessageFormat.format(errMsg, errArgs);
/*  78 */         throw new CharConversionException(errMsg);
/*     */       }
/*  80 */       buffer[i] = ((byte)(c & 0xFF));
/*     */     }
/*  82 */     write(buffer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void print(boolean b)
/*     */     throws IOException
/*     */   {
/*     */     String msg;
/*     */     
/*     */ 
/*     */     String msg;
/*     */     
/*     */ 
/*  96 */     if (b) {
/*  97 */       msg = lStrings.getString("value.true");
/*     */     } else {
/*  99 */       msg = lStrings.getString("value.false");
/*     */     }
/* 101 */     print(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void print(char c)
/*     */     throws IOException
/*     */   {
/* 114 */     print(String.valueOf(c));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void print(int i)
/*     */     throws IOException
/*     */   {
/* 127 */     print(String.valueOf(i));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void print(long l)
/*     */     throws IOException
/*     */   {
/* 140 */     print(String.valueOf(l));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void print(float f)
/*     */     throws IOException
/*     */   {
/* 153 */     print(String.valueOf(f));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void print(double d)
/*     */     throws IOException
/*     */   {
/* 166 */     print(String.valueOf(d));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void println()
/*     */     throws IOException
/*     */   {
/* 176 */     print("\r\n");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void println(String s)
/*     */     throws IOException
/*     */   {
/* 189 */     StringBuilder sb = new StringBuilder();
/* 190 */     sb.append(s);
/* 191 */     sb.append("\r\n");
/* 192 */     print(sb.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void println(boolean b)
/*     */     throws IOException
/*     */   {
/* 205 */     StringBuilder sb = new StringBuilder();
/* 206 */     if (b) {
/* 207 */       sb.append(lStrings.getString("value.true"));
/*     */     } else {
/* 209 */       sb.append(lStrings.getString("value.false"));
/*     */     }
/* 211 */     sb.append("\r\n");
/* 212 */     print(sb.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void println(char c)
/*     */     throws IOException
/*     */   {
/* 225 */     println(String.valueOf(c));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void println(int i)
/*     */     throws IOException
/*     */   {
/* 238 */     println(String.valueOf(i));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void println(long l)
/*     */     throws IOException
/*     */   {
/* 251 */     println(String.valueOf(l));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void println(float f)
/*     */     throws IOException
/*     */   {
/* 264 */     println(String.valueOf(f));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void println(double d)
/*     */     throws IOException
/*     */   {
/* 277 */     println(String.valueOf(d));
/*     */   }
/*     */   
/*     */   public abstract boolean isReady();
/*     */   
/*     */   public abstract void setWriteListener(WriteListener paramWriteListener);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\ServletOutputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */