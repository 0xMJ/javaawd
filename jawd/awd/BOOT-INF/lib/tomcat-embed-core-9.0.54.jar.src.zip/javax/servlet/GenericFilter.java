/*    */ package javax.servlet;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GenericFilter
/*    */   implements Filter, FilterConfig, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private volatile FilterConfig filterConfig;
/*    */   
/*    */   public String getInitParameter(String name)
/*    */   {
/* 41 */     return getFilterConfig().getInitParameter(name);
/*    */   }
/*    */   
/*    */ 
/*    */   public Enumeration<String> getInitParameterNames()
/*    */   {
/* 47 */     return getFilterConfig().getInitParameterNames();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FilterConfig getFilterConfig()
/*    */   {
/* 58 */     return this.filterConfig;
/*    */   }
/*    */   
/*    */ 
/*    */   public ServletContext getServletContext()
/*    */   {
/* 64 */     return getFilterConfig().getServletContext();
/*    */   }
/*    */   
/*    */   public void init(FilterConfig filterConfig)
/*    */     throws ServletException
/*    */   {
/* 70 */     this.filterConfig = filterConfig;
/* 71 */     init();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void init()
/*    */     throws ServletException
/*    */   {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFilterName()
/*    */   {
/* 89 */     return getFilterConfig().getFilterName();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\GenericFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */