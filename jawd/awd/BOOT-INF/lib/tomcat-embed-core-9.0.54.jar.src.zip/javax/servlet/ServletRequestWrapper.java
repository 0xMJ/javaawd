/*     */ package javax.servlet;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletRequestWrapper
/*     */   implements ServletRequest
/*     */ {
/*     */   private static final String LSTRING_FILE = "javax.servlet.LocalStrings";
/*  38 */   private static final ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.LocalStrings");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ServletRequest request;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletRequestWrapper(ServletRequest request)
/*     */   {
/*  50 */     if (request == null) {
/*  51 */       throw new IllegalArgumentException(lStrings.getString("wrapper.nullRequest"));
/*     */     }
/*  53 */     this.request = request;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletRequest getRequest()
/*     */   {
/*  61 */     return this.request;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequest(ServletRequest request)
/*     */   {
/*  71 */     if (request == null) {
/*  72 */       throw new IllegalArgumentException(lStrings.getString("wrapper.nullRequest"));
/*     */     }
/*  74 */     this.request = request;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getAttribute(String name)
/*     */   {
/*  83 */     return this.request.getAttribute(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getAttributeNames()
/*     */   {
/*  92 */     return this.request.getAttributeNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCharacterEncoding()
/*     */   {
/* 101 */     return this.request.getCharacterEncoding();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharacterEncoding(String enc)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 111 */     this.request.setCharacterEncoding(enc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getContentLength()
/*     */   {
/* 120 */     return this.request.getContentLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getContentLengthLong()
/*     */   {
/* 131 */     return this.request.getContentLengthLong();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 140 */     return this.request.getContentType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletInputStream getInputStream()
/*     */     throws IOException
/*     */   {
/* 149 */     return this.request.getInputStream();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 158 */     return this.request.getParameter(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String[]> getParameterMap()
/*     */   {
/* 167 */     return this.request.getParameterMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getParameterNames()
/*     */   {
/* 176 */     return this.request.getParameterNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getParameterValues(String name)
/*     */   {
/* 185 */     return this.request.getParameterValues(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProtocol()
/*     */   {
/* 194 */     return this.request.getProtocol();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getScheme()
/*     */   {
/* 203 */     return this.request.getScheme();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getServerName()
/*     */   {
/* 212 */     return this.request.getServerName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getServerPort()
/*     */   {
/* 221 */     return this.request.getServerPort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BufferedReader getReader()
/*     */     throws IOException
/*     */   {
/* 230 */     return this.request.getReader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRemoteAddr()
/*     */   {
/* 239 */     return this.request.getRemoteAddr();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRemoteHost()
/*     */   {
/* 248 */     return this.request.getRemoteHost();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttribute(String name, Object o)
/*     */   {
/* 257 */     this.request.setAttribute(name, o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeAttribute(String name)
/*     */   {
/* 266 */     this.request.removeAttribute(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Locale getLocale()
/*     */   {
/* 275 */     return this.request.getLocale();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<Locale> getLocales()
/*     */   {
/* 284 */     return this.request.getLocales();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSecure()
/*     */   {
/* 293 */     return this.request.isSecure();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestDispatcher getRequestDispatcher(String path)
/*     */   {
/* 302 */     return this.request.getRequestDispatcher(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public String getRealPath(String path)
/*     */   {
/* 314 */     return this.request.getRealPath(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRemotePort()
/*     */   {
/* 325 */     return this.request.getRemotePort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLocalName()
/*     */   {
/* 336 */     return this.request.getLocalName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLocalAddr()
/*     */   {
/* 347 */     return this.request.getLocalAddr();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLocalPort()
/*     */   {
/* 358 */     return this.request.getLocalPort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletContext getServletContext()
/*     */   {
/* 369 */     return this.request.getServletContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncContext startAsync()
/*     */     throws IllegalStateException
/*     */   {
/* 383 */     return this.request.startAsync();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncContext startAsync(ServletRequest servletRequest, ServletResponse servletResponse)
/*     */     throws IllegalStateException
/*     */   {
/* 402 */     return this.request.startAsync(servletRequest, servletResponse);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAsyncStarted()
/*     */   {
/* 413 */     return this.request.isAsyncStarted();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAsyncSupported()
/*     */   {
/* 424 */     return this.request.isAsyncSupported();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncContext getAsyncContext()
/*     */   {
/* 435 */     return this.request.getAsyncContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isWrapperFor(ServletRequest wrapped)
/*     */   {
/* 447 */     if (this.request == wrapped) {
/* 448 */       return true;
/*     */     }
/* 450 */     if ((this.request instanceof ServletRequestWrapper)) {
/* 451 */       return ((ServletRequestWrapper)this.request).isWrapperFor(wrapped);
/*     */     }
/* 453 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isWrapperFor(Class<?> wrappedType)
/*     */   {
/* 466 */     if (wrappedType.isAssignableFrom(this.request.getClass())) {
/* 467 */       return true;
/*     */     }
/* 469 */     if ((this.request instanceof ServletRequestWrapper)) {
/* 470 */       return ((ServletRequestWrapper)this.request).isWrapperFor(wrappedType);
/*     */     }
/* 472 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DispatcherType getDispatcherType()
/*     */   {
/* 483 */     return this.request.getDispatcherType();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\ServletRequestWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */