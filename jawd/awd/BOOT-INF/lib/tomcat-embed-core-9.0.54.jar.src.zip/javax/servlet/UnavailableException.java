/*     */ package javax.servlet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnavailableException
/*     */   extends ServletException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Servlet servlet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean permanent;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int seconds;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public UnavailableException(Servlet servlet, String msg)
/*     */   {
/*  70 */     super(msg);
/*  71 */     this.servlet = servlet;
/*  72 */     this.permanent = true;
/*  73 */     this.seconds = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public UnavailableException(int seconds, Servlet servlet, String msg)
/*     */   {
/*  91 */     super(msg);
/*  92 */     this.servlet = servlet;
/*  93 */     if (seconds <= 0) {
/*  94 */       this.seconds = -1;
/*     */     } else {
/*  96 */       this.seconds = seconds;
/*     */     }
/*  98 */     this.permanent = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnavailableException(String msg)
/*     */   {
/* 109 */     super(msg);
/* 110 */     this.seconds = 0;
/* 111 */     this.servlet = null;
/* 112 */     this.permanent = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnavailableException(String msg, int seconds)
/*     */   {
/* 135 */     super(msg);
/*     */     
/* 137 */     if (seconds <= 0) {
/* 138 */       this.seconds = -1;
/*     */     } else {
/* 140 */       this.seconds = seconds;
/*     */     }
/* 142 */     this.servlet = null;
/* 143 */     this.permanent = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPermanent()
/*     */   {
/* 156 */     return this.permanent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Servlet getServlet()
/*     */   {
/* 168 */     return this.servlet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUnavailableSeconds()
/*     */   {
/* 185 */     return this.permanent ? -1 : this.seconds;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\UnavailableException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */