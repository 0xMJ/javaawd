/*    */ package javax.servlet;
/*    */ 
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpMethodConstraintElement
/*    */   extends HttpConstraintElement
/*    */ {
/*    */   private static final String LSTRING_FILE = "javax.servlet.LocalStrings";
/* 32 */   private static final ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.LocalStrings");
/*    */   
/*    */ 
/*    */ 
/*    */   private final String methodName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public HttpMethodConstraintElement(String methodName)
/*    */   {
/* 43 */     if ((methodName == null) || (methodName.length() == 0)) {
/* 44 */       throw new IllegalArgumentException(lStrings.getString("httpMethodConstraintElement.invalidMethod"));
/*    */     }
/*    */     
/* 47 */     this.methodName = methodName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HttpMethodConstraintElement(String methodName, HttpConstraintElement constraint)
/*    */   {
/* 59 */     super(constraint.getEmptyRoleSemantic(), constraint
/* 60 */       .getTransportGuarantee(), constraint
/* 61 */       .getRolesAllowed());
/* 62 */     if ((methodName == null) || (methodName.length() == 0)) {
/* 63 */       throw new IllegalArgumentException(lStrings.getString("httpMethodConstraintElement.invalidMethod"));
/*    */     }
/*    */     
/* 66 */     this.methodName = methodName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMethodName()
/*    */   {
/* 76 */     return this.methodName;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\HttpMethodConstraintElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */