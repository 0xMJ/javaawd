/*    */ package javax.servlet;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletRequestEvent
/*    */   extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final transient ServletRequest request;
/*    */   
/*    */   public ServletRequestEvent(ServletContext sc, ServletRequest request)
/*    */   {
/* 41 */     super(sc);
/* 42 */     this.request = request;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ServletRequest getServletRequest()
/*    */   {
/* 50 */     return this.request;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ServletContext getServletContext()
/*    */   {
/* 58 */     return (ServletContext)super.getSource();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\ServletRequestEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */