package javax.servlet.descriptor;

import java.util.Collection;

public abstract interface JspConfigDescriptor
{
  public abstract Collection<TaglibDescriptor> getTaglibs();
  
  public abstract Collection<JspPropertyGroupDescriptor> getJspPropertyGroups();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\descriptor\JspConfigDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */