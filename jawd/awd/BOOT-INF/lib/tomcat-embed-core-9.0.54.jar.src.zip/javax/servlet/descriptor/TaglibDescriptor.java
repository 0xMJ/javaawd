package javax.servlet.descriptor;

public abstract interface TaglibDescriptor
{
  public abstract String getTaglibURI();
  
  public abstract String getTaglibLocation();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\descriptor\TaglibDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */