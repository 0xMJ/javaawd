package javax.servlet;

import java.io.IOException;
import java.util.EventListener;

public abstract interface WriteListener
  extends EventListener
{
  public abstract void onWritePossible()
    throws IOException;
  
  public abstract void onError(Throwable paramThrowable);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\WriteListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */