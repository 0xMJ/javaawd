/*     */ package javax.servlet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncEvent
/*     */ {
/*     */   private final AsyncContext context;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ServletRequest request;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ServletResponse response;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Throwable throwable;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncEvent(AsyncContext context)
/*     */   {
/*  36 */     this.context = context;
/*  37 */     this.request = null;
/*  38 */     this.response = null;
/*  39 */     this.throwable = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncEvent(AsyncContext context, ServletRequest request, ServletResponse response)
/*     */   {
/*  51 */     this.context = context;
/*  52 */     this.request = request;
/*  53 */     this.response = response;
/*  54 */     this.throwable = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncEvent(AsyncContext context, Throwable throwable)
/*     */   {
/*  64 */     this.context = context;
/*  65 */     this.throwable = throwable;
/*  66 */     this.request = null;
/*  67 */     this.response = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncEvent(AsyncContext context, ServletRequest request, ServletResponse response, Throwable throwable)
/*     */   {
/*  80 */     this.context = context;
/*  81 */     this.request = request;
/*  82 */     this.response = response;
/*  83 */     this.throwable = throwable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsyncContext getAsyncContext()
/*     */   {
/*  93 */     return this.context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletRequest getSuppliedRequest()
/*     */   {
/* 103 */     return this.request;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletResponse getSuppliedResponse()
/*     */   {
/* 113 */     return this.response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Throwable getThrowable()
/*     */   {
/* 123 */     return this.throwable;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\javax\servlet\AsyncEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */