/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerEvent;
/*     */ import org.apache.catalina.ContainerListener;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FrameworkListener
/*     */   implements LifecycleListener, ContainerListener
/*     */ {
/*  40 */   protected final ConcurrentHashMap<Context, LifecycleListener> contextListeners = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract LifecycleListener createLifecycleListener(Context paramContext);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void lifecycleEvent(LifecycleEvent event)
/*     */   {
/*  52 */     Lifecycle lifecycle = event.getLifecycle();
/*  53 */     if (("before_start".equals(event.getType())) && ((lifecycle instanceof Server)))
/*     */     {
/*  55 */       Server server = (Server)lifecycle;
/*  56 */       registerListenersForServer(server);
/*     */     }
/*     */   }
/*     */   
/*     */   public void containerEvent(ContainerEvent event)
/*     */   {
/*  62 */     String type = event.getType();
/*  63 */     if ("addChild".equals(type)) {
/*  64 */       processContainerAddChild((Container)event.getData());
/*  65 */     } else if ("removeChild".equals(type)) {
/*  66 */       processContainerRemoveChild((Container)event.getData());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void registerListenersForServer(Server server) {
/*  71 */     for (Service service : server.findServices()) {
/*  72 */       Engine engine = service.getContainer();
/*  73 */       if (engine != null) {
/*  74 */         engine.addContainerListener(this);
/*  75 */         registerListenersForEngine(engine);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void registerListenersForEngine(Engine engine) {
/*  81 */     for (Container hostContainer : engine.findChildren()) {
/*  82 */       Host host = (Host)hostContainer;
/*  83 */       host.addContainerListener(this);
/*  84 */       registerListenersForHost(host);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void registerListenersForHost(Host host) {
/*  89 */     for (Container contextContainer : host.findChildren()) {
/*  90 */       Context context = (Context)contextContainer;
/*  91 */       registerContextListener(context);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void registerContextListener(Context context) {
/*  96 */     LifecycleListener listener = createLifecycleListener(context);
/*  97 */     this.contextListeners.put(context, listener);
/*  98 */     context.addLifecycleListener(listener);
/*     */   }
/*     */   
/*     */   protected void processContainerAddChild(Container child) {
/* 102 */     if ((child instanceof Context)) {
/* 103 */       registerContextListener((Context)child);
/* 104 */     } else if ((child instanceof Engine)) {
/* 105 */       registerListenersForEngine((Engine)child);
/* 106 */     } else if ((child instanceof Host)) {
/* 107 */       registerListenersForHost((Host)child);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void processContainerRemoveChild(Container child) {
/* 112 */     if ((child instanceof Context)) {
/* 113 */       LifecycleListener listener = (LifecycleListener)this.contextListeners.remove(child);
/* 114 */       if (listener != null) {
/* 115 */         child.removeLifecycleListener(listener);
/*     */       }
/* 117 */     } else if (((child instanceof Host)) || ((child instanceof Engine))) {
/* 118 */       child.removeContainerListener(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\FrameworkListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */