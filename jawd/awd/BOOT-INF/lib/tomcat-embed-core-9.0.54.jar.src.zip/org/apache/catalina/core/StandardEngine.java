/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.File;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.catalina.AccessLog;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerEvent;
/*     */ import org.apache.catalina.ContainerListener;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.mapper.Mapper;
/*     */ import org.apache.catalina.realm.NullRealm;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardEngine
/*     */   extends ContainerBase
/*     */   implements Engine
/*     */ {
/*  56 */   private static final Log log = LogFactory.getLog(StandardEngine.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardEngine()
/*     */   {
/*  67 */     this.pipeline.setBasic(new StandardEngineValve());
/*     */     try
/*     */     {
/*  70 */       setJvmRoute(System.getProperty("jvmRoute"));
/*     */     } catch (Exception ex) {
/*  72 */       log.warn(sm.getString("standardEngine.jvmRouteFail"));
/*     */     }
/*     */     
/*  75 */     this.backgroundProcessorDelay = 10;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   private String defaultHost = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */   private Service service = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String jvmRouteId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */   private final AtomicReference<AccessLog> defaultAccessLog = new AtomicReference();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Realm getRealm()
/*     */   {
/* 118 */     Realm configured = super.getRealm();
/*     */     
/*     */ 
/* 121 */     if (configured == null) {
/* 122 */       configured = new NullRealm();
/* 123 */       setRealm(configured);
/*     */     }
/* 125 */     return configured;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDefaultHost()
/*     */   {
/* 134 */     return this.defaultHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultHost(String host)
/*     */   {
/* 146 */     String oldDefaultHost = this.defaultHost;
/* 147 */     if (host == null) {
/* 148 */       this.defaultHost = null;
/*     */     } else {
/* 150 */       this.defaultHost = host.toLowerCase(Locale.ENGLISH);
/*     */     }
/* 152 */     if (getState().isAvailable()) {
/* 153 */       this.service.getMapper().setDefaultHostName(host);
/*     */     }
/* 155 */     this.support.firePropertyChange("defaultHost", oldDefaultHost, this.defaultHost);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJvmRoute(String routeId)
/*     */   {
/* 169 */     this.jvmRouteId = routeId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getJvmRoute()
/*     */   {
/* 179 */     return this.jvmRouteId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Service getService()
/*     */   {
/* 188 */     return this.service;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setService(Service service)
/*     */   {
/* 199 */     this.service = service;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addChild(Container child)
/*     */   {
/* 214 */     if (!(child instanceof Host))
/*     */     {
/* 216 */       throw new IllegalArgumentException(sm.getString("standardEngine.notHost"));
/*     */     }
/* 218 */     super.addChild(child);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParent(Container container)
/*     */   {
/* 233 */     throw new IllegalArgumentException(sm.getString("standardEngine.notParent"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 242 */     getRealm();
/* 243 */     super.initInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 258 */     if (log.isInfoEnabled()) {
/* 259 */       log.info(sm.getString("standardEngine.start", new Object[] { ServerInfo.getServerInfo() }));
/*     */     }
/*     */     
/*     */ 
/* 263 */     super.startInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void logAccess(Request request, Response response, long time, boolean useDefault)
/*     */   {
/* 277 */     boolean logged = false;
/*     */     
/* 279 */     if (getAccessLog() != null) {
/* 280 */       this.accessLog.log(request, response, time);
/* 281 */       logged = true;
/*     */     }
/*     */     
/* 284 */     if ((!logged) && (useDefault)) {
/* 285 */       AccessLog newDefaultAccessLog = (AccessLog)this.defaultAccessLog.get();
/* 286 */       if (newDefaultAccessLog == null)
/*     */       {
/*     */ 
/* 289 */         Host host = (Host)findChild(getDefaultHost());
/* 290 */         Context context = null;
/* 291 */         if ((host != null) && (host.getState().isAvailable())) {
/* 292 */           newDefaultAccessLog = host.getAccessLog();
/*     */           
/* 294 */           if (newDefaultAccessLog != null) {
/* 295 */             if (this.defaultAccessLog.compareAndSet(null, newDefaultAccessLog))
/*     */             {
/* 297 */               AccessLogListener l = new AccessLogListener(this, host, null);
/*     */               
/* 299 */               l.install();
/*     */             }
/*     */           }
/*     */           else {
/* 303 */             context = (Context)host.findChild("");
/* 304 */             if ((context != null) && 
/* 305 */               (context.getState().isAvailable())) {
/* 306 */               newDefaultAccessLog = context.getAccessLog();
/* 307 */               if ((newDefaultAccessLog != null) && 
/* 308 */                 (this.defaultAccessLog.compareAndSet(null, newDefaultAccessLog)))
/*     */               {
/* 310 */                 AccessLogListener l = new AccessLogListener(this, null, context);
/*     */                 
/* 312 */                 l.install();
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 319 */         if (newDefaultAccessLog == null) {
/* 320 */           newDefaultAccessLog = new NoopAccessLog();
/* 321 */           if (this.defaultAccessLog.compareAndSet(null, newDefaultAccessLog))
/*     */           {
/* 323 */             AccessLogListener l = new AccessLogListener(this, host, context);
/*     */             
/* 325 */             l.install();
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 330 */       newDefaultAccessLog.log(request, response, time);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassLoader getParentClassLoader()
/*     */   {
/* 340 */     if (this.parentClassLoader != null) {
/* 341 */       return this.parentClassLoader;
/*     */     }
/* 343 */     if (this.service != null) {
/* 344 */       return this.service.getParentClassLoader();
/*     */     }
/* 346 */     return ClassLoader.getSystemClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */   public File getCatalinaBase()
/*     */   {
/* 352 */     if (this.service != null) {
/* 353 */       Server s = this.service.getServer();
/* 354 */       if (s != null) {
/* 355 */         File base = s.getCatalinaBase();
/* 356 */         if (base != null) {
/* 357 */           return base;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 362 */     return super.getCatalinaBase();
/*     */   }
/*     */   
/*     */ 
/*     */   public File getCatalinaHome()
/*     */   {
/* 368 */     if (this.service != null) {
/* 369 */       Server s = this.service.getServer();
/* 370 */       if (s != null) {
/* 371 */         File base = s.getCatalinaHome();
/* 372 */         if (base != null) {
/* 373 */           return base;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 378 */     return super.getCatalinaHome();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getObjectNameKeyProperties()
/*     */   {
/* 386 */     return "type=Engine";
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getDomainInternal()
/*     */   {
/* 392 */     return getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static final class NoopAccessLog
/*     */     implements AccessLog
/*     */   {
/*     */     public void log(Request request, Response response, long time) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setRequestAttributesEnabled(boolean requestAttributesEnabled) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean getRequestAttributesEnabled()
/*     */     {
/* 414 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected static final class AccessLogListener
/*     */     implements PropertyChangeListener, LifecycleListener, ContainerListener
/*     */   {
/*     */     private final StandardEngine engine;
/*     */     private final Host host;
/*     */     private final Context context;
/* 425 */     private volatile boolean disabled = false;
/*     */     
/*     */     public AccessLogListener(StandardEngine engine, Host host, Context context)
/*     */     {
/* 429 */       this.engine = engine;
/* 430 */       this.host = host;
/* 431 */       this.context = context;
/*     */     }
/*     */     
/*     */     public void install() {
/* 435 */       this.engine.addPropertyChangeListener(this);
/* 436 */       if (this.host != null) {
/* 437 */         this.host.addContainerListener(this);
/* 438 */         this.host.addLifecycleListener(this);
/*     */       }
/* 440 */       if (this.context != null) {
/* 441 */         this.context.addLifecycleListener(this);
/*     */       }
/*     */     }
/*     */     
/*     */     private void uninstall() {
/* 446 */       this.disabled = true;
/* 447 */       if (this.context != null) {
/* 448 */         this.context.removeLifecycleListener(this);
/*     */       }
/* 450 */       if (this.host != null) {
/* 451 */         this.host.removeLifecycleListener(this);
/* 452 */         this.host.removeContainerListener(this);
/*     */       }
/* 454 */       this.engine.removePropertyChangeListener(this);
/*     */     }
/*     */     
/*     */     public void lifecycleEvent(LifecycleEvent event)
/*     */     {
/* 459 */       if (this.disabled) {
/* 460 */         return;
/*     */       }
/*     */       
/* 463 */       String type = event.getType();
/* 464 */       if (("after_start".equals(type)) || 
/* 465 */         ("before_stop".equals(type)) || 
/* 466 */         ("before_destroy".equals(type)))
/*     */       {
/*     */ 
/*     */ 
/* 470 */         this.engine.defaultAccessLog.set(null);
/* 471 */         uninstall();
/*     */       }
/*     */     }
/*     */     
/*     */     public void propertyChange(PropertyChangeEvent evt)
/*     */     {
/* 477 */       if (this.disabled) {
/* 478 */         return;
/*     */       }
/* 480 */       if ("defaultHost".equals(evt.getPropertyName()))
/*     */       {
/*     */ 
/* 483 */         this.engine.defaultAccessLog.set(null);
/* 484 */         uninstall();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void containerEvent(ContainerEvent event)
/*     */     {
/* 491 */       if (this.disabled) {
/* 492 */         return;
/*     */       }
/* 494 */       if ("addChild".equals(event.getType())) {
/* 495 */         Context context = (Context)event.getData();
/* 496 */         if (context.getPath().isEmpty())
/*     */         {
/*     */ 
/* 499 */           this.engine.defaultAccessLog.set(null);
/* 500 */           uninstall();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\StandardEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */