/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.UDecoder;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLValve
/*     */   extends ValveBase
/*     */ {
/*  66 */   private static final Log log = LogFactory.getLog(SSLValve.class);
/*     */   
/*  68 */   private String sslClientCertHeader = "ssl_client_cert";
/*  69 */   private String sslClientEscapedCertHeader = "ssl_client_escaped_cert";
/*  70 */   private String sslCipherHeader = "ssl_cipher";
/*  71 */   private String sslSessionIdHeader = "ssl_session_id";
/*  72 */   private String sslCipherUserKeySizeHeader = "ssl_cipher_usekeysize";
/*     */   
/*     */   public SSLValve()
/*     */   {
/*  76 */     super(true);
/*     */   }
/*     */   
/*     */   public String getSslClientCertHeader()
/*     */   {
/*  81 */     return this.sslClientCertHeader;
/*     */   }
/*     */   
/*     */   public void setSslClientCertHeader(String sslClientCertHeader) {
/*  85 */     this.sslClientCertHeader = sslClientCertHeader;
/*     */   }
/*     */   
/*     */   public String getSslClientEscapedCertHeader() {
/*  89 */     return this.sslClientEscapedCertHeader;
/*     */   }
/*     */   
/*     */   public void setSslClientEscapedCertHeader(String sslClientEscapedCertHeader) {
/*  93 */     this.sslClientEscapedCertHeader = sslClientEscapedCertHeader;
/*     */   }
/*     */   
/*     */   public String getSslCipherHeader() {
/*  97 */     return this.sslCipherHeader;
/*     */   }
/*     */   
/*     */   public void setSslCipherHeader(String sslCipherHeader) {
/* 101 */     this.sslCipherHeader = sslCipherHeader;
/*     */   }
/*     */   
/*     */   public String getSslSessionIdHeader() {
/* 105 */     return this.sslSessionIdHeader;
/*     */   }
/*     */   
/*     */   public void setSslSessionIdHeader(String sslSessionIdHeader) {
/* 109 */     this.sslSessionIdHeader = sslSessionIdHeader;
/*     */   }
/*     */   
/*     */   public String getSslCipherUserKeySizeHeader() {
/* 113 */     return this.sslCipherUserKeySizeHeader;
/*     */   }
/*     */   
/*     */   public void setSslCipherUserKeySizeHeader(String sslCipherUserKeySizeHeader) {
/* 117 */     this.sslCipherUserKeySizeHeader = sslCipherUserKeySizeHeader;
/*     */   }
/*     */   
/*     */   public String mygetHeader(Request request, String header)
/*     */   {
/* 122 */     String strcert0 = request.getHeader(header);
/* 123 */     if (strcert0 == null) {
/* 124 */       return null;
/*     */     }
/*     */     
/* 127 */     if ("(null)".equals(strcert0)) {
/* 128 */       return null;
/*     */     }
/* 130 */     return strcert0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void invoke(Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/* 153 */     String headerEscapedValue = mygetHeader(request, this.sslClientEscapedCertHeader);
/* 154 */     String headerValue; if (headerEscapedValue != null) {
/* 155 */       headerValue = UDecoder.URLDecode(headerEscapedValue, null);
/*     */     } else {
/* 157 */       headerValue = mygetHeader(request, this.sslClientCertHeader);
/*     */     }
/* 159 */     if (headerValue != null) {
/* 160 */       headerValue = headerValue.trim();
/* 161 */       if (headerValue.length() > 27) {
/* 162 */         String body = headerValue.substring(27);
/* 163 */         String header = "-----BEGIN CERTIFICATE-----\n";
/* 164 */         String strcerts = header.concat(body);
/*     */         
/* 166 */         ByteArrayInputStream bais = new ByteArrayInputStream(strcerts.getBytes(StandardCharsets.ISO_8859_1));
/* 167 */         X509Certificate[] jsseCerts = null;
/* 168 */         String providerName = (String)request.getConnector().getProperty("clientCertProvider");
/*     */         try {
/*     */           CertificateFactory cf;
/*     */           CertificateFactory cf;
/* 172 */           if (providerName == null) {
/* 173 */             cf = CertificateFactory.getInstance("X.509");
/*     */           } else {
/* 175 */             cf = CertificateFactory.getInstance("X.509", providerName);
/*     */           }
/* 177 */           X509Certificate cert = (X509Certificate)cf.generateCertificate(bais);
/* 178 */           jsseCerts = new X509Certificate[1];
/* 179 */           jsseCerts[0] = cert;
/*     */         } catch (CertificateException e) {
/* 181 */           log.warn(sm.getString("sslValve.certError", new Object[] { strcerts }), e);
/*     */         } catch (NoSuchProviderException e) {
/* 183 */           log.error(sm.getString("sslValve.invalidProvider", new Object[] { providerName }), e);
/*     */         }
/*     */         
/* 186 */         request.setAttribute("javax.servlet.request.X509Certificate", jsseCerts);
/*     */       }
/*     */     }
/* 189 */     String headerValue = mygetHeader(request, this.sslCipherHeader);
/* 190 */     if (headerValue != null) {
/* 191 */       request.setAttribute("javax.servlet.request.cipher_suite", headerValue);
/*     */     }
/* 193 */     headerValue = mygetHeader(request, this.sslSessionIdHeader);
/* 194 */     if (headerValue != null) {
/* 195 */       request.setAttribute("javax.servlet.request.ssl_session_id", headerValue);
/*     */     }
/* 197 */     headerValue = mygetHeader(request, this.sslCipherUserKeySizeHeader);
/* 198 */     if (headerValue != null) {
/* 199 */       request.setAttribute("javax.servlet.request.key_size", Integer.valueOf(headerValue));
/*     */     }
/* 201 */     getNext().invoke(request, response);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\SSLValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */