/*    */ package org.apache.catalina.mbeans;
/*    */ 
/*    */ import org.apache.tomcat.util.modeler.ManagedBean;
/*    */ import org.apache.tomcat.util.modeler.Registry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemoryUserDatabaseMBean
/*    */   extends SparseUserDatabaseMBean
/*    */ {
/* 32 */   protected final ManagedBean managed = this.registry.findManagedBean("MemoryUserDatabase");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\MemoryUserDatabaseMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */