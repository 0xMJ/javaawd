/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AddDefaultCharsetFilter
/*     */   extends FilterBase
/*     */ {
/*  52 */   private final Log log = LogFactory.getLog(AddDefaultCharsetFilter.class);
/*     */   
/*     */   private static final String DEFAULT_ENCODING = "ISO-8859-1";
/*     */   private String encoding;
/*     */   
/*     */   public void setEncoding(String encoding)
/*     */   {
/*  59 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   protected Log getLogger()
/*     */   {
/*  64 */     return this.log;
/*     */   }
/*     */   
/*     */   public void init(FilterConfig filterConfig) throws ServletException
/*     */   {
/*  69 */     super.init(filterConfig);
/*  70 */     if ((this.encoding == null) || (this.encoding.length() == 0) || 
/*  71 */       (this.encoding.equalsIgnoreCase("default"))) {
/*  72 */       this.encoding = "ISO-8859-1";
/*  73 */     } else if (this.encoding.equalsIgnoreCase("system")) {
/*  74 */       this.encoding = Charset.defaultCharset().name();
/*  75 */     } else if (!Charset.isSupported(this.encoding)) {
/*  76 */       throw new IllegalArgumentException(sm.getString("addDefaultCharset.unsupportedCharset", new Object[] { this.encoding }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  86 */     if ((response instanceof HttpServletResponse)) {
/*  87 */       ResponseWrapper wrapped = new ResponseWrapper((HttpServletResponse)response, this.encoding);
/*     */       
/*  89 */       chain.doFilter(request, wrapped);
/*     */     } else {
/*  91 */       chain.doFilter(request, response);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class ResponseWrapper
/*     */     extends HttpServletResponseWrapper
/*     */   {
/*     */     private String encoding;
/*     */     
/*     */ 
/*     */     public ResponseWrapper(HttpServletResponse response, String encoding)
/*     */     {
/* 104 */       super();
/* 105 */       this.encoding = encoding;
/*     */     }
/*     */     
/*     */ 
/*     */     public void setContentType(String contentType)
/*     */     {
/* 111 */       if ((contentType != null) && (contentType.startsWith("text/"))) {
/* 112 */         if (!contentType.contains("charset=")) {
/* 113 */           super.setContentType(contentType + ";charset=" + this.encoding);
/*     */         } else {
/* 115 */           super.setContentType(contentType);
/* 116 */           this.encoding = getCharacterEncoding();
/*     */         }
/*     */       } else {
/* 119 */         super.setContentType(contentType);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void setHeader(String name, String value)
/*     */     {
/* 126 */       if (name.trim().equalsIgnoreCase("content-type")) {
/* 127 */         setContentType(value);
/*     */       } else {
/* 129 */         super.setHeader(name, value);
/*     */       }
/*     */     }
/*     */     
/*     */     public void addHeader(String name, String value)
/*     */     {
/* 135 */       if (name.trim().equalsIgnoreCase("content-type")) {
/* 136 */         setContentType(value);
/*     */       } else {
/* 138 */         super.addHeader(name, value);
/*     */       }
/*     */     }
/*     */     
/*     */     public void setCharacterEncoding(String charset)
/*     */     {
/* 144 */       super.setCharacterEncoding(charset);
/* 145 */       this.encoding = charset;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\filters\AddDefaultCharsetFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */