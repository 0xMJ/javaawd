/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.Cookie;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SavedRequest
/*     */ {
/*  49 */   private final List<Cookie> cookies = new ArrayList();
/*     */   
/*     */   public void addCookie(Cookie cookie) {
/*  52 */     this.cookies.add(cookie);
/*     */   }
/*     */   
/*     */   public Iterator<Cookie> getCookies() {
/*  56 */     return this.cookies.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private final Map<String, List<String>> headers = new HashMap();
/*     */   
/*     */   public void addHeader(String name, String value) {
/*  69 */     List<String> values = (List)this.headers.get(name);
/*  70 */     if (values == null) {
/*  71 */       values = new ArrayList();
/*  72 */       this.headers.put(name, values);
/*     */     }
/*  74 */     values.add(value);
/*     */   }
/*     */   
/*     */   public Iterator<String> getHeaderNames() {
/*  78 */     return this.headers.keySet().iterator();
/*     */   }
/*     */   
/*     */   public Iterator<String> getHeaderValues(String name) {
/*  82 */     List<String> values = (List)this.headers.get(name);
/*  83 */     if (values == null) {
/*  84 */       return Collections.emptyIterator();
/*     */     }
/*  86 */     return values.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */   private final List<Locale> locales = new ArrayList();
/*     */   
/*     */   public void addLocale(Locale locale) {
/*  97 */     this.locales.add(locale);
/*     */   }
/*     */   
/*     */   public Iterator<Locale> getLocales() {
/* 101 */     return this.locales.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private String method = null;
/*     */   
/*     */   public String getMethod() {
/* 111 */     return this.method;
/*     */   }
/*     */   
/*     */   public void setMethod(String method) {
/* 115 */     this.method = method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */   private String queryString = null;
/*     */   
/*     */   public String getQueryString() {
/* 125 */     return this.queryString;
/*     */   }
/*     */   
/*     */   public void setQueryString(String queryString) {
/* 129 */     this.queryString = queryString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */   private String requestURI = null;
/*     */   
/*     */   public String getRequestURI() {
/* 139 */     return this.requestURI;
/*     */   }
/*     */   
/*     */   public void setRequestURI(String requestURI) {
/* 143 */     this.requestURI = requestURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 151 */   private String decodedRequestURI = null;
/*     */   
/*     */   public String getDecodedRequestURI() {
/* 154 */     return this.decodedRequestURI;
/*     */   }
/*     */   
/*     */   public void setDecodedRequestURI(String decodedRequestURI) {
/* 158 */     this.decodedRequestURI = decodedRequestURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 165 */   private ByteChunk body = null;
/*     */   
/*     */   public ByteChunk getBody() {
/* 168 */     return this.body;
/*     */   }
/*     */   
/*     */   public void setBody(ByteChunk body) {
/* 172 */     this.body = body;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 178 */   private String contentType = null;
/*     */   
/*     */   public String getContentType() {
/* 181 */     return this.contentType;
/*     */   }
/*     */   
/*     */   public void setContentType(String contentType) {
/* 185 */     this.contentType = contentType;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\authenticator\SavedRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */