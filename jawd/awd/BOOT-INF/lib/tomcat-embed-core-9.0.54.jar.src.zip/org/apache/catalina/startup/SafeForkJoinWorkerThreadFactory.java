/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import java.util.concurrent.ForkJoinPool;
/*    */ import java.util.concurrent.ForkJoinPool.ForkJoinWorkerThreadFactory;
/*    */ import java.util.concurrent.ForkJoinWorkerThread;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SafeForkJoinWorkerThreadFactory
/*    */   implements ForkJoinPool.ForkJoinWorkerThreadFactory
/*    */ {
/*    */   public ForkJoinWorkerThread newThread(ForkJoinPool pool)
/*    */   {
/* 35 */     return new SafeForkJoinWorkerThread(pool);
/*    */   }
/*    */   
/*    */   private static class SafeForkJoinWorkerThread extends ForkJoinWorkerThread
/*    */   {
/*    */     protected SafeForkJoinWorkerThread(ForkJoinPool pool)
/*    */     {
/* 42 */       super();
/* 43 */       setContextClassLoader(ForkJoinPool.class.getClassLoader());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\SafeForkJoinWorkerThreadFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */