/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import org.apache.catalina.util.URLEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Substitution
/*     */ {
/*     */   public static abstract class SubstitutionElement
/*     */   {
/*     */     public abstract String evaluate(Matcher paramMatcher1, Matcher paramMatcher2, Resolver paramResolver);
/*     */   }
/*     */   
/*     */   public static class StaticElement
/*     */     extends Substitution.SubstitutionElement
/*     */   {
/*     */     public String value;
/*     */     
/*  37 */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) { return this.value; }
/*     */   }
/*     */   
/*     */   public class RewriteRuleBackReferenceElement extends Substitution.SubstitutionElement {
/*     */     public int n;
/*     */     
/*     */     public RewriteRuleBackReferenceElement() {}
/*     */     
/*     */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) {
/*  46 */       String result = rule.group(this.n);
/*  47 */       if (result == null) {
/*  48 */         result = "";
/*     */       }
/*  50 */       if (Substitution.this.escapeBackReferences)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*  55 */         return URLEncoder.DEFAULT.encode(result, resolver.getUriCharset());
/*     */       }
/*  57 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class RewriteCondBackReferenceElement extends Substitution.SubstitutionElement
/*     */   {
/*     */     public int n;
/*     */     
/*     */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) {
/*  66 */       return cond.group(this.n) == null ? "" : cond.group(this.n);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ServerVariableElement extends Substitution.SubstitutionElement {
/*     */     public String key;
/*     */     
/*     */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) {
/*  74 */       return resolver.resolve(this.key);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ServerVariableEnvElement extends Substitution.SubstitutionElement {
/*     */     public String key;
/*     */     
/*     */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) {
/*  82 */       return resolver.resolveEnv(this.key);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ServerVariableSslElement extends Substitution.SubstitutionElement {
/*     */     public String key;
/*     */     
/*     */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) {
/*  90 */       return resolver.resolveSsl(this.key);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ServerVariableHttpElement
/*     */     extends Substitution.SubstitutionElement {
/*     */     public String key;
/*     */     
/*  98 */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) { return resolver.resolveHttp(this.key); }
/*     */   }
/*     */   
/*     */   public class MapElement extends Substitution.SubstitutionElement { public MapElement() {}
/*     */     
/* 103 */     public RewriteMap map = null;
/* 104 */     public Substitution.SubstitutionElement[] defaultValue = null;
/* 105 */     public Substitution.SubstitutionElement[] key = null;
/*     */     
/*     */     public String evaluate(Matcher rule, Matcher cond, Resolver resolver) {
/* 108 */       String result = this.map.lookup(Substitution.this.evaluateSubstitution(this.key, rule, cond, resolver));
/* 109 */       if ((result == null) && (this.defaultValue != null)) {
/* 110 */         result = Substitution.this.evaluateSubstitution(this.defaultValue, rule, cond, resolver);
/*     */       }
/* 112 */       return result;
/*     */     }
/*     */   }
/*     */   
/* 116 */   protected SubstitutionElement[] elements = null;
/*     */   
/* 118 */   protected String sub = null;
/* 119 */   public String getSub() { return this.sub; }
/* 120 */   public void setSub(String sub) { this.sub = sub; }
/*     */   
/*     */   void setEscapeBackReferences(boolean escapeBackReferences)
/*     */   {
/* 124 */     this.escapeBackReferences = escapeBackReferences;
/*     */   }
/*     */   
/*     */   public void parse(Map<String, RewriteMap> maps) {
/* 128 */     this.elements = parseSubstitution(this.sub, maps);
/*     */   }
/*     */   
/*     */   private SubstitutionElement[] parseSubstitution(String sub, Map<String, RewriteMap> maps)
/*     */   {
/* 133 */     List<SubstitutionElement> elements = new ArrayList();
/* 134 */     int pos = 0;
/* 135 */     int percentPos = 0;
/* 136 */     int dollarPos = 0;
/* 137 */     int backslashPos = 0;
/*     */     
/* 139 */     while (pos < sub.length()) {
/* 140 */       percentPos = sub.indexOf('%', pos);
/* 141 */       dollarPos = sub.indexOf('$', pos);
/* 142 */       backslashPos = sub.indexOf('\\', pos);
/* 143 */       if ((percentPos == -1) && (dollarPos == -1) && (backslashPos == -1))
/*     */       {
/* 145 */         StaticElement newElement = new StaticElement();
/* 146 */         newElement.value = sub.substring(pos);
/* 147 */         pos = sub.length();
/* 148 */         elements.add(newElement);
/* 149 */       } else if (isFirstPos(backslashPos, new int[] { dollarPos, percentPos })) {
/* 150 */         if (backslashPos + 1 == sub.length()) {
/* 151 */           throw new IllegalArgumentException(sub);
/*     */         }
/* 153 */         StaticElement newElement = new StaticElement();
/* 154 */         newElement.value = (sub.substring(pos, backslashPos) + sub.substring(backslashPos + 1, backslashPos + 2));
/* 155 */         pos = backslashPos + 2;
/* 156 */         elements.add(newElement);
/* 157 */       } else if (isFirstPos(dollarPos, new int[] { percentPos }))
/*     */       {
/* 159 */         if (dollarPos + 1 == sub.length()) {
/* 160 */           throw new IllegalArgumentException(sub);
/*     */         }
/* 162 */         if (pos < dollarPos)
/*     */         {
/* 164 */           StaticElement newElement = new StaticElement();
/* 165 */           newElement.value = sub.substring(pos, dollarPos);
/* 166 */           pos = dollarPos;
/* 167 */           elements.add(newElement);
/*     */         }
/* 169 */         if (Character.isDigit(sub.charAt(dollarPos + 1)))
/*     */         {
/* 171 */           RewriteRuleBackReferenceElement newElement = new RewriteRuleBackReferenceElement();
/* 172 */           newElement.n = Character.digit(sub.charAt(dollarPos + 1), 10);
/* 173 */           pos = dollarPos + 2;
/* 174 */           elements.add(newElement);
/* 175 */         } else if (sub.charAt(dollarPos + 1) == '{')
/*     */         {
/* 177 */           MapElement newElement = new MapElement();
/* 178 */           int open = sub.indexOf('{', dollarPos);
/* 179 */           int colon = findMatchingColonOrBar(true, sub, open);
/* 180 */           int def = findMatchingColonOrBar(false, sub, open);
/* 181 */           int close = findMatchingBrace(sub, open);
/* 182 */           if ((-1 >= open) || (open >= colon) || (colon >= close)) {
/* 183 */             throw new IllegalArgumentException(sub);
/*     */           }
/* 185 */           newElement.map = ((RewriteMap)maps.get(sub.substring(open + 1, colon)));
/* 186 */           if (newElement.map == null) {
/* 187 */             throw new IllegalArgumentException(sub + ": No map: " + sub.substring(open + 1, colon));
/*     */           }
/* 189 */           String key = null;
/* 190 */           String defaultValue = null;
/* 191 */           if (def > -1) {
/* 192 */             if ((colon >= def) || (def >= close)) {
/* 193 */               throw new IllegalArgumentException(sub);
/*     */             }
/* 195 */             key = sub.substring(colon + 1, def);
/* 196 */             defaultValue = sub.substring(def + 1, close);
/*     */           } else {
/* 198 */             key = sub.substring(colon + 1, close);
/*     */           }
/* 200 */           newElement.key = parseSubstitution(key, maps);
/* 201 */           if (defaultValue != null) {
/* 202 */             newElement.defaultValue = parseSubstitution(defaultValue, maps);
/*     */           }
/* 204 */           pos = close + 1;
/* 205 */           elements.add(newElement);
/*     */         } else {
/* 207 */           throw new IllegalArgumentException(sub + ": missing digit or curly brace.");
/*     */         }
/*     */       }
/*     */       else {
/* 211 */         if (percentPos + 1 == sub.length()) {
/* 212 */           throw new IllegalArgumentException(sub);
/*     */         }
/* 214 */         if (pos < percentPos)
/*     */         {
/* 216 */           StaticElement newElement = new StaticElement();
/* 217 */           newElement.value = sub.substring(pos, percentPos);
/* 218 */           pos = percentPos;
/* 219 */           elements.add(newElement);
/*     */         }
/* 221 */         if (Character.isDigit(sub.charAt(percentPos + 1)))
/*     */         {
/* 223 */           RewriteCondBackReferenceElement newElement = new RewriteCondBackReferenceElement();
/* 224 */           newElement.n = Character.digit(sub.charAt(percentPos + 1), 10);
/* 225 */           pos = percentPos + 2;
/* 226 */           elements.add(newElement);
/* 227 */         } else if (sub.charAt(percentPos + 1) == '{')
/*     */         {
/* 229 */           SubstitutionElement newElement = null;
/* 230 */           int open = sub.indexOf('{', percentPos);
/* 231 */           int colon = findMatchingColonOrBar(true, sub, open);
/* 232 */           int close = findMatchingBrace(sub, open);
/* 233 */           if ((-1 >= open) || (open >= close)) {
/* 234 */             throw new IllegalArgumentException(sub);
/*     */           }
/* 236 */           if ((colon > -1) && (open < colon) && (colon < close)) {
/* 237 */             String type = sub.substring(open + 1, colon);
/* 238 */             if (type.equals("ENV")) {
/* 239 */               newElement = new ServerVariableEnvElement();
/* 240 */               ((ServerVariableEnvElement)newElement).key = sub.substring(colon + 1, close);
/* 241 */             } else if (type.equals("SSL")) {
/* 242 */               newElement = new ServerVariableSslElement();
/* 243 */               ((ServerVariableSslElement)newElement).key = sub.substring(colon + 1, close);
/* 244 */             } else if (type.equals("HTTP")) {
/* 245 */               newElement = new ServerVariableHttpElement();
/* 246 */               ((ServerVariableHttpElement)newElement).key = sub.substring(colon + 1, close);
/*     */             } else {
/* 248 */               throw new IllegalArgumentException(sub + ": Bad type: " + type);
/*     */             }
/*     */           } else {
/* 251 */             newElement = new ServerVariableElement();
/* 252 */             ((ServerVariableElement)newElement).key = sub.substring(open + 1, close);
/*     */           }
/* 254 */           pos = close + 1;
/* 255 */           elements.add(newElement);
/*     */         } else {
/* 257 */           throw new IllegalArgumentException(sub + ": missing digit or curly brace.");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 262 */     return (SubstitutionElement[])elements.toArray(new SubstitutionElement[0]);
/*     */   }
/*     */   
/*     */   private static int findMatchingBrace(String sub, int start)
/*     */   {
/* 267 */     int nesting = 1;
/* 268 */     for (int i = start + 1; i < sub.length(); i++) {
/* 269 */       char c = sub.charAt(i);
/* 270 */       if (c == '{') {
/* 271 */         char previousChar = sub.charAt(i - 1);
/* 272 */         if ((previousChar == '$') || (previousChar == '%')) {
/* 273 */           nesting++;
/*     */         }
/* 275 */       } else if (c == '}') {
/* 276 */         nesting--;
/* 277 */         if (nesting == 0) {
/* 278 */           return i;
/*     */         }
/*     */       }
/*     */     }
/* 282 */     return -1;
/*     */   }
/*     */   
/*     */   private static int findMatchingColonOrBar(boolean colon, String sub, int start) {
/* 286 */     int nesting = 0;
/* 287 */     for (int i = start + 1; i < sub.length(); i++) {
/* 288 */       char c = sub.charAt(i);
/* 289 */       if (c == '{') {
/* 290 */         char previousChar = sub.charAt(i - 1);
/* 291 */         if ((previousChar == '$') || (previousChar == '%')) {
/* 292 */           nesting++;
/*     */         }
/* 294 */       } else if (c == '}') {
/* 295 */         nesting--;
/* 296 */       } else if ((colon ? c == ':' : c == '|') && 
/* 297 */         (nesting == 0)) {
/* 298 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 302 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String evaluate(Matcher rule, Matcher cond, Resolver resolver)
/*     */   {
/* 313 */     return evaluateSubstitution(this.elements, rule, cond, resolver);
/*     */   }
/*     */   
/*     */   private String evaluateSubstitution(SubstitutionElement[] elements, Matcher rule, Matcher cond, Resolver resolver) {
/* 317 */     StringBuilder buf = new StringBuilder();
/* 318 */     for (SubstitutionElement element : elements) {
/* 319 */       buf.append(element.evaluate(rule, cond, resolver));
/*     */     }
/* 321 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean escapeBackReferences;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isFirstPos(int testPos, int... others)
/*     */   {
/* 337 */     if (testPos < 0) {
/* 338 */       return false;
/*     */     }
/* 340 */     for (int other : others) {
/* 341 */       if ((other >= 0) && (other < testPos)) {
/* 342 */         return false;
/*     */       }
/*     */     }
/* 345 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\rewrite\Substitution.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */