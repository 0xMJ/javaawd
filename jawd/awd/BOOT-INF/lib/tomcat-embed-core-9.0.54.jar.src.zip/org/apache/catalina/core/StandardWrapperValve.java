/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.UnavailableException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.connector.ClientAbortException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.valves.ValveBase;
/*     */ import org.apache.coyote.CloseNowException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.log.SystemLogHandler;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StandardWrapperValve
/*     */   extends ValveBase
/*     */ {
/*  52 */   private static final StringManager sm = StringManager.getManager(StandardWrapperValve.class);
/*     */   private volatile long processingTime;
/*     */   private volatile long maxTime;
/*     */   
/*     */   public StandardWrapperValve()
/*     */   {
/*  58 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   private volatile long minTime = Long.MAX_VALUE;
/*  70 */   private final AtomicInteger requestCount = new AtomicInteger(0);
/*  71 */   private final AtomicInteger errorCount = new AtomicInteger(0);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void invoke(Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/*  91 */     boolean unavailable = false;
/*  92 */     Throwable throwable = null;
/*     */     
/*  94 */     long t1 = System.currentTimeMillis();
/*  95 */     this.requestCount.incrementAndGet();
/*  96 */     StandardWrapper wrapper = (StandardWrapper)getContainer();
/*  97 */     Servlet servlet = null;
/*  98 */     Context context = (Context)wrapper.getParent();
/*     */     
/*     */ 
/* 101 */     if (!context.getState().isAvailable()) {
/* 102 */       response.sendError(503, sm
/* 103 */         .getString("standardContext.isUnavailable"));
/* 104 */       unavailable = true;
/*     */     }
/*     */     
/*     */ 
/* 108 */     if ((!unavailable) && (wrapper.isUnavailable())) {
/* 109 */       this.container.getLogger().info(sm.getString("standardWrapper.isUnavailable", new Object[] {wrapper
/* 110 */         .getName() }));
/* 111 */       long available = wrapper.getAvailable();
/* 112 */       if ((available > 0L) && (available < Long.MAX_VALUE)) {
/* 113 */         response.setDateHeader("Retry-After", available);
/* 114 */         response.sendError(503, sm
/* 115 */           .getString("standardWrapper.isUnavailable", new Object[] {wrapper
/* 116 */           .getName() }));
/* 117 */       } else if (available == Long.MAX_VALUE) {
/* 118 */         response.sendError(404, sm
/* 119 */           .getString("standardWrapper.notFound", new Object[] {wrapper
/* 120 */           .getName() }));
/*     */       }
/* 122 */       unavailable = true;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 127 */       if (!unavailable) {
/* 128 */         servlet = wrapper.allocate();
/*     */       }
/*     */     } catch (UnavailableException e) {
/* 131 */       this.container.getLogger().error(sm
/* 132 */         .getString("standardWrapper.allocateException", new Object[] {wrapper
/* 133 */         .getName() }), e);
/* 134 */       long available = wrapper.getAvailable();
/* 135 */       if ((available > 0L) && (available < Long.MAX_VALUE)) {
/* 136 */         response.setDateHeader("Retry-After", available);
/* 137 */         response.sendError(503, sm
/* 138 */           .getString("standardWrapper.isUnavailable", new Object[] {wrapper
/* 139 */           .getName() }));
/* 140 */       } else if (available == Long.MAX_VALUE) {
/* 141 */         response.sendError(404, sm
/* 142 */           .getString("standardWrapper.notFound", new Object[] {wrapper
/* 143 */           .getName() }));
/*     */       }
/*     */     } catch (ServletException e) {
/* 146 */       this.container.getLogger().error(sm.getString("standardWrapper.allocateException", new Object[] {wrapper
/* 147 */         .getName() }), StandardWrapper.getRootCause(e));
/* 148 */       throwable = e;
/* 149 */       exception(request, response, e);
/*     */     } catch (Throwable e) {
/* 151 */       ExceptionUtils.handleThrowable(e);
/* 152 */       this.container.getLogger().error(sm.getString("standardWrapper.allocateException", new Object[] {wrapper
/* 153 */         .getName() }), e);
/* 154 */       throwable = e;
/* 155 */       exception(request, response, e);
/* 156 */       servlet = null;
/*     */     }
/*     */     
/* 159 */     MessageBytes requestPathMB = request.getRequestPathMB();
/* 160 */     DispatcherType dispatcherType = DispatcherType.REQUEST;
/* 161 */     if (request.getDispatcherType() == DispatcherType.ASYNC) {
/* 162 */       dispatcherType = DispatcherType.ASYNC;
/*     */     }
/* 164 */     request.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", dispatcherType);
/* 165 */     request.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", requestPathMB);
/*     */     
/*     */ 
/*     */ 
/* 169 */     ApplicationFilterChain filterChain = ApplicationFilterFactory.createFilterChain(request, wrapper, servlet);
/*     */     
/*     */ 
/*     */ 
/* 173 */     Container container = this.container;
/*     */     try {
/* 175 */       if ((servlet != null) && (filterChain != null))
/*     */       {
/* 177 */         if (context.getSwallowOutput()) {
/*     */           try {
/* 179 */             SystemLogHandler.startCapture();
/* 180 */             if (request.isAsyncDispatching()) {
/* 181 */               request.getAsyncContextInternal().doInternalDispatch();
/*     */             } else
/* 183 */               filterChain.doFilter(request.getRequest(), response
/* 184 */                 .getResponse());
/*     */           } finally {
/*     */             String log;
/* 187 */             String log = SystemLogHandler.stopCapture();
/* 188 */             if ((log != null) && (log.length() > 0)) {
/* 189 */               context.getLogger().info(log);
/*     */             }
/*     */             
/*     */           }
/* 193 */         } else if (request.isAsyncDispatching()) {
/* 194 */           request.getAsyncContextInternal().doInternalDispatch();
/*     */         }
/*     */         else {
/* 197 */           filterChain.doFilter(request.getRequest(), response.getResponse());
/*     */         }
/*     */       }
/*     */     } catch (ClientAbortException|CloseNowException e) {
/*     */       long t2;
/*     */       long time;
/* 203 */       if (container.getLogger().isDebugEnabled()) {
/* 204 */         container.getLogger().debug(sm.getString("standardWrapper.serviceException", new Object[] {wrapper
/* 205 */           .getName(), context
/* 206 */           .getName() }), e);
/*     */       }
/* 208 */       throwable = e;
/* 209 */       exception(request, response, e); } catch (IOException e) { long t2;
/*     */       long time;
/* 211 */       container.getLogger().error(sm.getString("standardWrapper.serviceException", new Object[] {wrapper
/* 212 */         .getName(), context
/* 213 */         .getName() }), e);
/* 214 */       throwable = e;
/* 215 */       exception(request, response, e); } catch (UnavailableException e) { long t2;
/*     */       long time;
/* 217 */       container.getLogger().error(sm.getString("standardWrapper.serviceException", new Object[] {wrapper
/* 218 */         .getName(), context
/* 219 */         .getName() }), e);
/*     */       
/*     */ 
/* 222 */       wrapper.unavailable(e);
/* 223 */       long available = wrapper.getAvailable();
/* 224 */       if ((available > 0L) && (available < Long.MAX_VALUE)) {
/* 225 */         response.setDateHeader("Retry-After", available);
/* 226 */         response.sendError(503, sm
/* 227 */           .getString("standardWrapper.isUnavailable", new Object[] {wrapper
/* 228 */           .getName() }));
/* 229 */       } else if (available == Long.MAX_VALUE) {
/* 230 */         response.sendError(404, sm
/* 231 */           .getString("standardWrapper.notFound", new Object[] {wrapper
/* 232 */           .getName() }));
/*     */       }
/*     */     } catch (ServletException e) {
/*     */       long t2;
/*     */       long time;
/* 237 */       Throwable rootCause = StandardWrapper.getRootCause(e);
/* 238 */       if (!(rootCause instanceof ClientAbortException)) {
/* 239 */         container.getLogger().error(sm.getString("standardWrapper.serviceExceptionRoot", new Object[] {wrapper
/*     */         
/* 241 */           .getName(), context.getName(), e.getMessage() }), rootCause);
/*     */       }
/*     */       
/* 244 */       throwable = e;
/* 245 */       exception(request, response, e); } catch (Throwable e) { long t2;
/*     */       long time;
/* 247 */       ExceptionUtils.handleThrowable(e);
/* 248 */       container.getLogger().error(sm.getString("standardWrapper.serviceException", new Object[] {wrapper
/* 249 */         .getName(), context
/* 250 */         .getName() }), e);
/* 251 */       throwable = e;
/* 252 */       exception(request, response, e);
/*     */     } finally { long t2;
/*     */       long time;
/* 255 */       if (filterChain != null) {
/* 256 */         filterChain.release();
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 261 */         if (servlet != null) {
/* 262 */           wrapper.deallocate(servlet);
/*     */         }
/*     */       } catch (Throwable e) {
/* 265 */         ExceptionUtils.handleThrowable(e);
/* 266 */         container.getLogger().error(sm.getString("standardWrapper.deallocateException", new Object[] {wrapper
/* 267 */           .getName() }), e);
/* 268 */         if (throwable == null) {
/* 269 */           throwable = e;
/* 270 */           exception(request, response, e);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 277 */         if ((servlet != null) && 
/* 278 */           (wrapper.getAvailable() == Long.MAX_VALUE)) {
/* 279 */           wrapper.unload();
/*     */         }
/*     */       } catch (Throwable e) {
/* 282 */         ExceptionUtils.handleThrowable(e);
/* 283 */         container.getLogger().error(sm.getString("standardWrapper.unloadException", new Object[] {wrapper
/* 284 */           .getName() }), e);
/* 285 */         if (throwable == null) {
/* 286 */           exception(request, response, e);
/*     */         }
/*     */       }
/* 289 */       long t2 = System.currentTimeMillis();
/*     */       
/* 291 */       long time = t2 - t1;
/* 292 */       this.processingTime += time;
/* 293 */       if (time > this.maxTime) {
/* 294 */         this.maxTime = time;
/*     */       }
/* 296 */       if (time < this.minTime) {
/* 297 */         this.minTime = time;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void exception(Request request, Response response, Throwable exception)
/*     */   {
/* 318 */     request.setAttribute("javax.servlet.error.exception", exception);
/* 319 */     response.setStatus(500);
/* 320 */     response.setError();
/*     */   }
/*     */   
/*     */   public long getProcessingTime() {
/* 324 */     return this.processingTime;
/*     */   }
/*     */   
/*     */   public long getMaxTime() {
/* 328 */     return this.maxTime;
/*     */   }
/*     */   
/*     */   public long getMinTime() {
/* 332 */     return this.minTime;
/*     */   }
/*     */   
/*     */   public int getRequestCount() {
/* 336 */     return this.requestCount.get();
/*     */   }
/*     */   
/*     */   public int getErrorCount() {
/* 340 */     return this.errorCount.get();
/*     */   }
/*     */   
/*     */   public void incrementErrorCount() {
/* 344 */     this.errorCount.incrementAndGet();
/*     */   }
/*     */   
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\StandardWrapperValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */