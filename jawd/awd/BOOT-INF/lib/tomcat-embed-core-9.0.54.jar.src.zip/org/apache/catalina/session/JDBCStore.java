/*      */ package org.apache.catalina.session;
/*      */ 
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Driver;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import javax.naming.InitialContext;
/*      */ import javax.naming.NamingException;
/*      */ import javax.sql.DataSource;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Deprecated
/*      */ public class JDBCStore
/*      */   extends StoreBase
/*      */ {
/*   64 */   private String name = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final String storeName = "JDBCStore";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final String threadName = "JDBCStore";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   79 */   protected String connectionName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   85 */   protected String connectionPassword = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   90 */   protected String connectionURL = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   95 */   private Connection dbConnection = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  100 */   protected Driver driver = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  105 */   protected String driverName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  110 */   protected String dataSourceName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  115 */   private boolean localDataSource = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  120 */   protected DataSource dataSource = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  128 */   protected String sessionTable = "tomcat$sessions";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  133 */   protected String sessionAppCol = "app";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  138 */   protected String sessionIdCol = "id";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  143 */   protected String sessionDataCol = "data";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  148 */   protected String sessionValidCol = "valid";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  153 */   protected String sessionMaxInactiveCol = "maxinactive";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  158 */   protected String sessionLastAccessedCol = "lastaccess";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  166 */   protected PreparedStatement preparedSizeSql = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  171 */   protected PreparedStatement preparedSaveSql = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  176 */   protected PreparedStatement preparedClearSql = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  181 */   protected PreparedStatement preparedRemoveSql = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  186 */   protected PreparedStatement preparedLoadSql = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  195 */     if (this.name == null) {
/*  196 */       Container container = this.manager.getContext();
/*  197 */       String contextName = container.getName();
/*  198 */       if (!contextName.startsWith("/")) {
/*  199 */         contextName = "/" + contextName;
/*      */       }
/*  201 */       String hostName = "";
/*  202 */       String engineName = "";
/*      */       
/*  204 */       if (container.getParent() != null) {
/*  205 */         Container host = container.getParent();
/*  206 */         hostName = host.getName();
/*  207 */         if (host.getParent() != null) {
/*  208 */           engineName = host.getParent().getName();
/*      */         }
/*      */       }
/*  211 */       this.name = ("/" + engineName + "/" + hostName + contextName);
/*      */     }
/*  213 */     return this.name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getThreadName()
/*      */   {
/*  220 */     return "JDBCStore";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getStoreName()
/*      */   {
/*  228 */     return "JDBCStore";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDriverName(String driverName)
/*      */   {
/*  237 */     String oldDriverName = this.driverName;
/*  238 */     this.driverName = driverName;
/*  239 */     this.support.firePropertyChange("driverName", oldDriverName, this.driverName);
/*      */     
/*      */ 
/*  242 */     this.driverName = driverName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getDriverName()
/*      */   {
/*  249 */     return this.driverName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getConnectionName()
/*      */   {
/*  256 */     return this.connectionName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionName(String connectionName)
/*      */   {
/*  265 */     this.connectionName = connectionName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getConnectionPassword()
/*      */   {
/*  272 */     return this.connectionPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionPassword(String connectionPassword)
/*      */   {
/*  281 */     this.connectionPassword = connectionPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionURL(String connectionURL)
/*      */   {
/*  290 */     String oldConnString = this.connectionURL;
/*  291 */     this.connectionURL = connectionURL;
/*  292 */     this.support.firePropertyChange("connectionURL", oldConnString, this.connectionURL);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConnectionURL()
/*      */   {
/*  301 */     return this.connectionURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionTable(String sessionTable)
/*      */   {
/*  310 */     String oldSessionTable = this.sessionTable;
/*  311 */     this.sessionTable = sessionTable;
/*  312 */     this.support.firePropertyChange("sessionTable", oldSessionTable, this.sessionTable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionTable()
/*      */   {
/*  321 */     return this.sessionTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionAppCol(String sessionAppCol)
/*      */   {
/*  330 */     String oldSessionAppCol = this.sessionAppCol;
/*  331 */     this.sessionAppCol = sessionAppCol;
/*  332 */     this.support.firePropertyChange("sessionAppCol", oldSessionAppCol, this.sessionAppCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionAppCol()
/*      */   {
/*  341 */     return this.sessionAppCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionIdCol(String sessionIdCol)
/*      */   {
/*  350 */     String oldSessionIdCol = this.sessionIdCol;
/*  351 */     this.sessionIdCol = sessionIdCol;
/*  352 */     this.support.firePropertyChange("sessionIdCol", oldSessionIdCol, this.sessionIdCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionIdCol()
/*      */   {
/*  361 */     return this.sessionIdCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionDataCol(String sessionDataCol)
/*      */   {
/*  370 */     String oldSessionDataCol = this.sessionDataCol;
/*  371 */     this.sessionDataCol = sessionDataCol;
/*  372 */     this.support.firePropertyChange("sessionDataCol", oldSessionDataCol, this.sessionDataCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionDataCol()
/*      */   {
/*  381 */     return this.sessionDataCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionValidCol(String sessionValidCol)
/*      */   {
/*  390 */     String oldSessionValidCol = this.sessionValidCol;
/*  391 */     this.sessionValidCol = sessionValidCol;
/*  392 */     this.support.firePropertyChange("sessionValidCol", oldSessionValidCol, this.sessionValidCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionValidCol()
/*      */   {
/*  401 */     return this.sessionValidCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionMaxInactiveCol(String sessionMaxInactiveCol)
/*      */   {
/*  410 */     String oldSessionMaxInactiveCol = this.sessionMaxInactiveCol;
/*  411 */     this.sessionMaxInactiveCol = sessionMaxInactiveCol;
/*  412 */     this.support.firePropertyChange("sessionMaxInactiveCol", oldSessionMaxInactiveCol, this.sessionMaxInactiveCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionMaxInactiveCol()
/*      */   {
/*  421 */     return this.sessionMaxInactiveCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionLastAccessedCol(String sessionLastAccessedCol)
/*      */   {
/*  430 */     String oldSessionLastAccessedCol = this.sessionLastAccessedCol;
/*  431 */     this.sessionLastAccessedCol = sessionLastAccessedCol;
/*  432 */     this.support.firePropertyChange("sessionLastAccessedCol", oldSessionLastAccessedCol, this.sessionLastAccessedCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionLastAccessedCol()
/*      */   {
/*  441 */     return this.sessionLastAccessedCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDataSourceName(String dataSourceName)
/*      */   {
/*  450 */     if ((dataSourceName == null) || (dataSourceName.trim().isEmpty())) {
/*  451 */       this.manager.getContext().getLogger().warn(sm
/*  452 */         .getString(getStoreName() + ".missingDataSourceName"));
/*  453 */       return;
/*      */     }
/*  455 */     this.dataSourceName = dataSourceName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getDataSourceName()
/*      */   {
/*  462 */     return this.dataSourceName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getLocalDataSource()
/*      */   {
/*  469 */     return this.localDataSource;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocalDataSource(boolean localDataSource)
/*      */   {
/*  479 */     this.localDataSource = localDataSource;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String[] expiredKeys()
/*      */     throws IOException
/*      */   {
/*  487 */     return keys(true);
/*      */   }
/*      */   
/*      */   public String[] keys() throws IOException
/*      */   {
/*  492 */     return keys(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String[] keys(boolean expiredOnly)
/*      */     throws IOException
/*      */   {
/*  507 */     String[] keys = null;
/*  508 */     synchronized (this) {
/*  509 */       int numberOfTries = 2;
/*  510 */       while (numberOfTries > 0)
/*      */       {
/*  512 */         Connection _conn = getConnection();
/*  513 */         if (_conn == null) {
/*  514 */           return new String[0];
/*      */         }
/*      */         try
/*      */         {
/*  518 */           String keysSql = "SELECT " + this.sessionIdCol + " FROM " + this.sessionTable + " WHERE " + this.sessionAppCol + " = ?";
/*      */           
/*  520 */           if (expiredOnly) {
/*  521 */             keysSql = keysSql + " AND (" + this.sessionLastAccessedCol + " + " + this.sessionMaxInactiveCol + " * 1000 < ?)";
/*      */           }
/*      */           
/*  524 */           PreparedStatement preparedKeysSql = _conn.prepareStatement(keysSql);Throwable localThrowable6 = null;
/*  525 */           try { preparedKeysSql.setString(1, getName());
/*  526 */             if (expiredOnly) {
/*  527 */               preparedKeysSql.setLong(2, System.currentTimeMillis());
/*      */             }
/*  529 */             ResultSet rst = preparedKeysSql.executeQuery();Throwable localThrowable7 = null;
/*  530 */             try { List<String> tmpkeys = new ArrayList();
/*  531 */               if (rst != null) {
/*  532 */                 while (rst.next()) {
/*  533 */                   tmpkeys.add(rst.getString(1));
/*      */                 }
/*      */               }
/*  536 */               keys = (String[])tmpkeys.toArray(new String[0]);
/*      */               
/*  538 */               numberOfTries = 0;
/*      */             }
/*      */             catch (Throwable localThrowable1)
/*      */             {
/*  529 */               localThrowable7 = localThrowable1;throw localThrowable1;
/*      */             }
/*      */             finally {}
/*      */           }
/*      */           catch (Throwable localThrowable4)
/*      */           {
/*  524 */             localThrowable6 = localThrowable4;throw localThrowable4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  540 */             if (preparedKeysSql != null) if (localThrowable6 != null) try { preparedKeysSql.close(); } catch (Throwable localThrowable5) {} else preparedKeysSql.close();
/*      */           }
/*  542 */         } catch (SQLException e) { this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*  543 */           keys = new String[0];
/*      */           
/*  545 */           if (this.dbConnection != null) {
/*  546 */             close(this.dbConnection);
/*      */           }
/*      */         } finally {
/*  549 */           release(_conn);
/*      */         }
/*  551 */         numberOfTries--;
/*      */       }
/*      */     }
/*  554 */     return keys;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSize()
/*      */     throws IOException
/*      */   {
/*  568 */     int size = 0;
/*      */     
/*  570 */     synchronized (this) {
/*  571 */       int numberOfTries = 2;
/*  572 */       while (numberOfTries > 0) {
/*  573 */         Connection _conn = getConnection();
/*      */         
/*  575 */         if (_conn == null) {
/*  576 */           return size;
/*      */         }
/*      */         try
/*      */         {
/*  580 */           if (this.preparedSizeSql == null) {
/*  581 */             String sizeSql = "SELECT COUNT(" + this.sessionIdCol + ") FROM " + this.sessionTable + " WHERE " + this.sessionAppCol + " = ?";
/*      */             
/*      */ 
/*  584 */             this.preparedSizeSql = _conn.prepareStatement(sizeSql);
/*      */           }
/*      */           
/*  587 */           this.preparedSizeSql.setString(1, getName());
/*  588 */           ResultSet rst = this.preparedSizeSql.executeQuery();Throwable localThrowable3 = null;
/*  589 */           try { if (rst.next()) {
/*  590 */               size = rst.getInt(1);
/*      */             }
/*      */             
/*  593 */             numberOfTries = 0;
/*      */           }
/*      */           catch (Throwable localThrowable1)
/*      */           {
/*  588 */             localThrowable3 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*  594 */             if (rst != null) if (localThrowable3 != null) try { rst.close(); } catch (Throwable localThrowable2) {} else rst.close();
/*      */           }
/*  596 */         } catch (SQLException e) { this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*  597 */           if (this.dbConnection != null) {
/*  598 */             close(this.dbConnection);
/*      */           }
/*      */         } finally {
/*  601 */           release(_conn);
/*      */         }
/*  603 */         numberOfTries--;
/*      */       }
/*      */     }
/*  606 */     return size;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Session load(String id)
/*      */     throws ClassNotFoundException, IOException
/*      */   {
/*  620 */     StandardSession _session = null;
/*  621 */     org.apache.catalina.Context context = getManager().getContext();
/*  622 */     Log contextLog = context.getLogger();
/*      */     
/*  624 */     synchronized (this) {
/*  625 */       int numberOfTries = 2;
/*  626 */       while (numberOfTries > 0) {
/*  627 */         Connection _conn = getConnection();
/*  628 */         if (_conn == null) {
/*  629 */           return null;
/*      */         }
/*      */         
/*  632 */         ClassLoader oldThreadContextCL = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*      */         try
/*      */         {
/*  635 */           if (this.preparedLoadSql == null) {
/*  636 */             String loadSql = "SELECT " + this.sessionIdCol + ", " + this.sessionDataCol + " FROM " + this.sessionTable + " WHERE " + this.sessionIdCol + " = ? AND " + this.sessionAppCol + " = ?";
/*      */             
/*      */ 
/*      */ 
/*  640 */             this.preparedLoadSql = _conn.prepareStatement(loadSql);
/*      */           }
/*      */           
/*  643 */           this.preparedLoadSql.setString(1, id);
/*  644 */           this.preparedLoadSql.setString(2, getName());
/*  645 */           ResultSet rst = this.preparedLoadSql.executeQuery();Throwable localThrowable6 = null;
/*  646 */           try { if (rst.next())
/*      */             {
/*  648 */               ObjectInputStream ois = getObjectInputStream(rst.getBinaryStream(2));Throwable localThrowable7 = null;
/*  649 */               try { if (contextLog.isDebugEnabled()) {
/*  650 */                   contextLog.debug(sm.getString(
/*  651 */                     getStoreName() + ".loading", new Object[] { id, this.sessionTable }));
/*      */                 }
/*      */                 
/*  654 */                 _session = (StandardSession)this.manager.createEmptySession();
/*  655 */                 _session.readObjectData(ois);
/*  656 */                 _session.setManager(this.manager);
/*      */               }
/*      */               catch (Throwable localThrowable1)
/*      */               {
/*  647 */                 localThrowable7 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */ 
/*      */               }
/*      */               finally
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*  657 */                 if (ois != null) if (localThrowable7 != null) try { ois.close(); } catch (Throwable localThrowable2) { localThrowable7.addSuppressed(localThrowable2); } else ois.close();
/*  658 */               } } else if (context.getLogger().isDebugEnabled()) {
/*  659 */               contextLog.debug(getStoreName() + ": No persisted data object found");
/*      */             }
/*      */             
/*  662 */             numberOfTries = 0;
/*      */           }
/*      */           catch (Throwable localThrowable4)
/*      */           {
/*  645 */             localThrowable6 = localThrowable4;throw localThrowable4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  663 */             if (rst != null) if (localThrowable6 != null) try { rst.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else rst.close();
/*      */           }
/*  665 */         } catch (SQLException e) { contextLog.error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*  666 */           if (this.dbConnection != null) {
/*  667 */             close(this.dbConnection);
/*      */           }
/*      */         } finally {
/*  670 */           context.unbind(Globals.IS_SECURITY_ENABLED, oldThreadContextCL);
/*  671 */           release(_conn);
/*      */         }
/*  673 */         numberOfTries--;
/*      */       }
/*      */     }
/*      */     
/*  677 */     return _session;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(String id)
/*      */     throws IOException
/*      */   {
/*  692 */     synchronized (this) {
/*  693 */       int numberOfTries = 2;
/*  694 */       while (numberOfTries > 0) {
/*  695 */         Connection _conn = getConnection();
/*      */         
/*  697 */         if (_conn == null) {
/*  698 */           return;
/*      */         }
/*      */         try
/*      */         {
/*  702 */           remove(id, _conn);
/*      */           
/*  704 */           numberOfTries = 0;
/*      */         } catch (SQLException e) {
/*  706 */           this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*  707 */           if (this.dbConnection != null) {
/*  708 */             close(this.dbConnection);
/*      */           }
/*      */         } finally {
/*  711 */           release(_conn);
/*      */         }
/*  713 */         numberOfTries--;
/*      */       }
/*      */     }
/*      */     
/*  717 */     if (this.manager.getContext().getLogger().isDebugEnabled()) {
/*  718 */       this.manager.getContext().getLogger().debug(sm.getString(getStoreName() + ".removing", new Object[] { id, this.sessionTable }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void remove(String id, Connection _conn)
/*      */     throws SQLException
/*      */   {
/*  732 */     if (this.preparedRemoveSql == null) {
/*  733 */       String removeSql = "DELETE FROM " + this.sessionTable + " WHERE " + this.sessionIdCol + " = ?  AND " + this.sessionAppCol + " = ?";
/*      */       
/*      */ 
/*  736 */       this.preparedRemoveSql = _conn.prepareStatement(removeSql);
/*      */     }
/*      */     
/*  739 */     this.preparedRemoveSql.setString(1, id);
/*  740 */     this.preparedRemoveSql.setString(2, getName());
/*  741 */     this.preparedRemoveSql.execute();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clear()
/*      */     throws IOException
/*      */   {
/*  752 */     synchronized (this) {
/*  753 */       int numberOfTries = 2;
/*  754 */       while (numberOfTries > 0) {
/*  755 */         Connection _conn = getConnection();
/*  756 */         if (_conn == null) {
/*  757 */           return;
/*      */         }
/*      */         try
/*      */         {
/*  761 */           if (this.preparedClearSql == null) {
/*  762 */             String clearSql = "DELETE FROM " + this.sessionTable + " WHERE " + this.sessionAppCol + " = ?";
/*      */             
/*  764 */             this.preparedClearSql = _conn.prepareStatement(clearSql);
/*      */           }
/*      */           
/*  767 */           this.preparedClearSql.setString(1, getName());
/*  768 */           this.preparedClearSql.execute();
/*      */           
/*  770 */           numberOfTries = 0;
/*      */         } catch (SQLException e) {
/*  772 */           this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*  773 */           if (this.dbConnection != null) {
/*  774 */             close(this.dbConnection);
/*      */           }
/*      */         } finally {
/*  777 */           release(_conn);
/*      */         }
/*  779 */         numberOfTries--;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void save(Session session)
/*      */     throws IOException
/*      */   {
/*  792 */     ByteArrayOutputStream bos = null;
/*      */     
/*  794 */     synchronized (this) {
/*  795 */       int numberOfTries = 2;
/*  796 */       while (numberOfTries > 0) {
/*  797 */         Connection _conn = getConnection();
/*  798 */         if (_conn == null) {
/*  799 */           return;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/*  806 */           remove(session.getIdInternal(), _conn);
/*      */           
/*  808 */           bos = new ByteArrayOutputStream();
/*  809 */           ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(bos));Throwable localThrowable9 = null;
/*      */           try {
/*  811 */             ((StandardSession)session).writeObjectData(oos);
/*      */           }
/*      */           catch (Throwable localThrowable1)
/*      */           {
/*  809 */             localThrowable9 = localThrowable1;throw localThrowable1;
/*      */           }
/*      */           finally {
/*  812 */             if (oos != null) if (localThrowable9 != null) try { oos.close(); } catch (Throwable localThrowable2) {} else oos.close(); }
/*  813 */           byte[] obs = bos.toByteArray();
/*  814 */           int size = obs.length;
/*  815 */           ByteArrayInputStream bis = new ByteArrayInputStream(obs, 0, size);Throwable localThrowable10 = null;
/*  816 */           try { InputStream in = new BufferedInputStream(bis, size);Throwable localThrowable11 = null;
/*  817 */             try { if (this.preparedSaveSql == null) {
/*  818 */                 String saveSql = "INSERT INTO " + this.sessionTable + " (" + this.sessionIdCol + ", " + this.sessionAppCol + ", " + this.sessionDataCol + ", " + this.sessionValidCol + ", " + this.sessionMaxInactiveCol + ", " + this.sessionLastAccessedCol + ") VALUES (?, ?, ?, ?, ?, ?)";
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  824 */                 this.preparedSaveSql = _conn.prepareStatement(saveSql);
/*      */               }
/*      */               
/*  827 */               this.preparedSaveSql.setString(1, session.getIdInternal());
/*  828 */               this.preparedSaveSql.setString(2, getName());
/*  829 */               this.preparedSaveSql.setBinaryStream(3, in, size);
/*  830 */               this.preparedSaveSql.setString(4, session.isValid() ? "1" : "0");
/*  831 */               this.preparedSaveSql.setInt(5, session.getMaxInactiveInterval());
/*  832 */               this.preparedSaveSql.setLong(6, session.getLastAccessedTime());
/*  833 */               this.preparedSaveSql.execute();
/*      */               
/*  835 */               numberOfTries = 0;
/*      */             }
/*      */             catch (Throwable localThrowable4)
/*      */             {
/*  815 */               localThrowable11 = localThrowable4;throw localThrowable4; } finally {} } catch (Throwable localThrowable7) { localThrowable10 = localThrowable7;throw localThrowable7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  836 */             if (bis != null) if (localThrowable10 != null) try { bis.close(); } catch (Throwable localThrowable8) {} else bis.close();
/*      */           }
/*  838 */         } catch (SQLException e) { this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*  839 */           if (this.dbConnection != null) {
/*  840 */             close(this.dbConnection);
/*      */           }
/*      */         }
/*      */         catch (IOException localIOException) {}finally
/*      */         {
/*  845 */           release(_conn);
/*      */         }
/*  847 */         numberOfTries--;
/*      */       }
/*      */     }
/*      */     
/*  851 */     if (this.manager.getContext().getLogger().isDebugEnabled()) {
/*  852 */       this.manager.getContext().getLogger().debug(sm.getString(getStoreName() + ".saving", new Object[] {session
/*  853 */         .getIdInternal(), this.sessionTable }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Connection getConnection()
/*      */   {
/*  868 */     Connection conn = null;
/*      */     try {
/*  870 */       conn = open();
/*  871 */       if ((conn == null) || (conn.isClosed())) {
/*  872 */         this.manager.getContext().getLogger().info(sm.getString(getStoreName() + ".checkConnectionDBClosed"));
/*  873 */         conn = open();
/*  874 */         if ((conn == null) || (conn.isClosed())) {
/*  875 */           this.manager.getContext().getLogger().info(sm.getString(getStoreName() + ".checkConnectionDBReOpenFail"));
/*      */         }
/*      */       }
/*      */     } catch (SQLException ex) {
/*  879 */       this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".checkConnectionSQLException", new Object[] {ex
/*  880 */         .toString() }));
/*      */     }
/*      */     
/*  883 */     return conn;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Connection open()
/*      */     throws SQLException
/*      */   {
/*  897 */     if (this.dbConnection != null) {
/*  898 */       return this.dbConnection;
/*      */     }
/*      */     
/*  901 */     if ((this.dataSourceName != null) && (this.dataSource == null)) {
/*  902 */       org.apache.catalina.Context context = getManager().getContext();
/*  903 */       ClassLoader oldThreadContextCL = null;
/*  904 */       if (this.localDataSource) {
/*  905 */         oldThreadContextCL = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*      */       }
/*      */       
/*      */       try
/*      */       {
/*  910 */         javax.naming.Context initCtx = new InitialContext();
/*  911 */         javax.naming.Context envCtx = (javax.naming.Context)initCtx.lookup("java:comp/env");
/*  912 */         this.dataSource = ((DataSource)envCtx.lookup(this.dataSourceName));
/*      */       } catch (NamingException e) {
/*  914 */         context.getLogger().error(sm
/*  915 */           .getString(getStoreName() + ".wrongDataSource", new Object[] { this.dataSourceName }), e);
/*      */       }
/*      */       finally {
/*  918 */         if (this.localDataSource) {
/*  919 */           context.unbind(Globals.IS_SECURITY_ENABLED, oldThreadContextCL);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  924 */     if (this.dataSource != null) {
/*  925 */       return this.dataSource.getConnection();
/*      */     }
/*      */     
/*      */ 
/*  929 */     if (this.driver == null) {
/*      */       try {
/*  931 */         Class<?> clazz = Class.forName(this.driverName);
/*  932 */         this.driver = ((Driver)clazz.getConstructor(new Class[0]).newInstance(new Object[0]));
/*      */       } catch (ReflectiveOperationException e) {
/*  934 */         this.manager.getContext().getLogger().error(sm
/*  935 */           .getString(getStoreName() + ".checkConnectionClassNotFoundException", new Object[] {e
/*  936 */           .toString() }));
/*  937 */         throw new SQLException(e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  942 */     Properties props = new Properties();
/*  943 */     if (this.connectionName != null) {
/*  944 */       props.put("user", this.connectionName);
/*      */     }
/*  946 */     if (this.connectionPassword != null) {
/*  947 */       props.put("password", this.connectionPassword);
/*      */     }
/*  949 */     this.dbConnection = this.driver.connect(this.connectionURL, props);
/*  950 */     if (this.dbConnection == null) {
/*  951 */       throw new SQLException(sm.getString(getStoreName() + ".connectError", new Object[] { this.connectionURL }));
/*      */     }
/*  953 */     this.dbConnection.setAutoCommit(true);
/*  954 */     return this.dbConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void close(Connection dbConnection)
/*      */   {
/*  966 */     if (dbConnection == null) {
/*  967 */       return;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  972 */       this.preparedSizeSql.close();
/*      */     } catch (Throwable f) {
/*  974 */       ExceptionUtils.handleThrowable(f);
/*      */     }
/*  976 */     this.preparedSizeSql = null;
/*      */     try
/*      */     {
/*  979 */       this.preparedSaveSql.close();
/*      */     } catch (Throwable f) {
/*  981 */       ExceptionUtils.handleThrowable(f);
/*      */     }
/*  983 */     this.preparedSaveSql = null;
/*      */     try
/*      */     {
/*  986 */       this.preparedClearSql.close();
/*      */     } catch (Throwable f) {
/*  988 */       ExceptionUtils.handleThrowable(f);
/*      */     }
/*      */     try
/*      */     {
/*  992 */       this.preparedRemoveSql.close();
/*      */     } catch (Throwable f) {
/*  994 */       ExceptionUtils.handleThrowable(f);
/*      */     }
/*  996 */     this.preparedRemoveSql = null;
/*      */     try
/*      */     {
/*  999 */       this.preparedLoadSql.close();
/*      */     } catch (Throwable f) {
/* 1001 */       ExceptionUtils.handleThrowable(f);
/*      */     }
/* 1003 */     this.preparedLoadSql = null;
/*      */     
/*      */     try
/*      */     {
/* 1007 */       if (!dbConnection.getAutoCommit()) {
/* 1008 */         dbConnection.commit();
/*      */       }
/*      */     } catch (SQLException e) {
/* 1011 */       this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".commitSQLException"), e);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1016 */       dbConnection.close();
/*      */     } catch (SQLException e) {
/* 1018 */       this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".close", new Object[] { e.toString() }));
/*      */     } finally {
/* 1020 */       this.dbConnection = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void release(Connection conn)
/*      */   {
/* 1032 */     if (this.dataSource != null) {
/* 1033 */       close(conn);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void startInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1047 */     if (this.dataSourceName == null)
/*      */     {
/* 1049 */       this.dbConnection = getConnection();
/*      */     }
/*      */     
/* 1052 */     super.startInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1065 */     super.stopInternal();
/*      */     
/*      */ 
/* 1068 */     if (this.dbConnection != null) {
/*      */       try {
/* 1070 */         this.dbConnection.commit();
/*      */       }
/*      */       catch (SQLException localSQLException) {}
/*      */       
/* 1074 */       close(this.dbConnection);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\session\JDBCStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */