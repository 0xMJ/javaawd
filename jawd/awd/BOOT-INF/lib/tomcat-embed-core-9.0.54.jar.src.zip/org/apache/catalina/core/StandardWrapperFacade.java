/*    */ package org.apache.catalina.core;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardWrapperFacade
/*    */   implements ServletConfig
/*    */ {
/*    */   private final ServletConfig config;
/*    */   
/*    */   public StandardWrapperFacade(StandardWrapper config)
/*    */   {
/* 45 */     this.config = config;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 62 */   private ServletContext context = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getServletName()
/*    */   {
/* 70 */     return this.config.getServletName();
/*    */   }
/*    */   
/*    */ 
/*    */   public ServletContext getServletContext()
/*    */   {
/* 76 */     if (this.context == null) {
/* 77 */       this.context = this.config.getServletContext();
/* 78 */       if ((this.context instanceof ApplicationContext)) {
/* 79 */         this.context = ((ApplicationContext)this.context).getFacade();
/*    */       }
/*    */     }
/* 82 */     return this.context;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getInitParameter(String name)
/*    */   {
/* 88 */     return this.config.getInitParameter(name);
/*    */   }
/*    */   
/*    */ 
/*    */   public Enumeration<String> getInitParameterNames()
/*    */   {
/* 94 */     return this.config.getInitParameterNames();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\StandardWrapperFacade.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */