/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.CredentialHandler;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.ietf.jgss.GSSContext;
/*     */ import org.ietf.jgss.GSSCredential;
/*     */ import org.ietf.jgss.GSSException;
/*     */ import org.ietf.jgss.GSSName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CombinedRealm
/*     */   extends RealmBase
/*     */ {
/*  48 */   private static final Log log = LogFactory.getLog(CombinedRealm.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   protected final List<Realm> realms = new LinkedList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRealm(Realm theRealm)
/*     */   {
/*  61 */     this.realms.add(theRealm);
/*     */     
/*  63 */     if (log.isDebugEnabled()) {
/*  64 */       sm.getString("combinedRealm.addRealm", new Object[] {theRealm
/*  65 */         .getClass().getName(), 
/*  66 */         Integer.toString(this.realms.size()) });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName[] getRealms()
/*     */   {
/*  75 */     ObjectName[] result = new ObjectName[this.realms.size()];
/*  76 */     for (Realm realm : this.realms) {
/*  77 */       if ((realm instanceof RealmBase))
/*     */       {
/*  79 */         result[this.realms.indexOf(realm)] = ((RealmBase)realm).getObjectName();
/*     */       }
/*     */     }
/*  82 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Realm[] getNestedRealms()
/*     */   {
/*  89 */     return (Realm[])this.realms.toArray(new Realm[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realmName, String md5a2)
/*     */   {
/* 109 */     Principal authenticatedUser = null;
/*     */     
/* 111 */     for (Realm realm : this.realms) {
/* 112 */       if (log.isDebugEnabled()) {
/* 113 */         log.debug(sm.getString("combinedRealm.authStart", new Object[] { username, realm
/* 114 */           .getClass().getName() }));
/*     */       }
/*     */       
/* 117 */       authenticatedUser = realm.authenticate(username, clientDigest, nonce, nc, cnonce, qop, realmName, md5a2);
/*     */       
/*     */ 
/* 120 */       if (authenticatedUser == null) {
/* 121 */         if (log.isDebugEnabled()) {
/* 122 */           log.debug(sm.getString("combinedRealm.authFail", new Object[] { username, realm
/* 123 */             .getClass().getName() }));
/*     */         }
/*     */       } else {
/* 126 */         if (!log.isDebugEnabled()) break;
/* 127 */         log.debug(sm.getString("combinedRealm.authSuccess", new Object[] { username, realm
/* 128 */           .getClass().getName() })); break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 133 */     return authenticatedUser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username)
/*     */   {
/* 145 */     Principal authenticatedUser = null;
/*     */     
/* 147 */     for (Realm realm : this.realms) {
/* 148 */       if (log.isDebugEnabled()) {
/* 149 */         log.debug(sm.getString("combinedRealm.authStart", new Object[] { username, realm
/* 150 */           .getClass().getName() }));
/*     */       }
/*     */       
/* 153 */       authenticatedUser = realm.authenticate(username);
/*     */       
/* 155 */       if (authenticatedUser == null) {
/* 156 */         if (log.isDebugEnabled()) {
/* 157 */           log.debug(sm.getString("combinedRealm.authFail", new Object[] { username, realm
/* 158 */             .getClass().getName() }));
/*     */         }
/*     */       } else {
/* 161 */         if (!log.isDebugEnabled()) break;
/* 162 */         log.debug(sm.getString("combinedRealm.authSuccess", new Object[] { username, realm
/* 163 */           .getClass().getName() })); break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 168 */     return authenticatedUser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username, String credentials)
/*     */   {
/* 182 */     Principal authenticatedUser = null;
/*     */     
/* 184 */     for (Realm realm : this.realms) {
/* 185 */       if (log.isDebugEnabled()) {
/* 186 */         log.debug(sm.getString("combinedRealm.authStart", new Object[] { username, realm
/* 187 */           .getClass().getName() }));
/*     */       }
/*     */       
/* 190 */       authenticatedUser = realm.authenticate(username, credentials);
/*     */       
/* 192 */       if (authenticatedUser == null) {
/* 193 */         if (log.isDebugEnabled()) {
/* 194 */           log.debug(sm.getString("combinedRealm.authFail", new Object[] { username, realm
/* 195 */             .getClass().getName() }));
/*     */         }
/*     */       } else {
/* 198 */         if (!log.isDebugEnabled()) break;
/* 199 */         log.debug(sm.getString("combinedRealm.authSuccess", new Object[] { username, realm
/* 200 */           .getClass().getName() })); break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 205 */     return authenticatedUser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContainer(Container container)
/*     */   {
/* 216 */     for (Realm realm : this.realms)
/*     */     {
/* 218 */       if ((realm instanceof RealmBase)) {
/* 219 */         ((RealmBase)realm).setRealmPath(
/* 220 */           getRealmPath() + "/realm" + this.realms.indexOf(realm));
/*     */       }
/*     */       
/*     */ 
/* 224 */       realm.setContainer(container);
/*     */     }
/* 226 */     super.setContainer(container);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 241 */     Iterator<Realm> iter = this.realms.iterator();
/*     */     
/* 243 */     while (iter.hasNext()) {
/* 244 */       Realm realm = (Realm)iter.next();
/* 245 */       if ((realm instanceof Lifecycle)) {
/*     */         try {
/* 247 */           ((Lifecycle)realm).start();
/*     */         }
/*     */         catch (LifecycleException e) {
/* 250 */           iter.remove();
/* 251 */           log.error(sm.getString("combinedRealm.realmStartFail", new Object[] {realm
/* 252 */             .getClass().getName() }), e);
/*     */         }
/*     */       }
/*     */     }
/* 256 */     super.startInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 271 */     super.stopInternal();
/* 272 */     for (Realm realm : this.realms) {
/* 273 */       if ((realm instanceof Lifecycle)) {
/* 274 */         ((Lifecycle)realm).stop();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void destroyInternal()
/*     */     throws LifecycleException
/*     */   {
/* 285 */     for (Realm realm : this.realms) {
/* 286 */       if ((realm instanceof Lifecycle)) {
/* 287 */         ((Lifecycle)realm).destroy();
/*     */       }
/*     */     }
/* 290 */     super.destroyInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void backgroundProcess()
/*     */   {
/* 298 */     super.backgroundProcess();
/*     */     
/* 300 */     for (Realm r : this.realms) {
/* 301 */       r.backgroundProcess();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(X509Certificate[] certs)
/*     */   {
/* 314 */     Principal authenticatedUser = null;
/* 315 */     String username = null;
/* 316 */     if ((certs != null) && (certs.length > 0)) {
/* 317 */       username = certs[0].getSubjectDN().getName();
/*     */     }
/*     */     
/* 320 */     for (Realm realm : this.realms) {
/* 321 */       if (log.isDebugEnabled()) {
/* 322 */         log.debug(sm.getString("combinedRealm.authStart", new Object[] { username, realm
/* 323 */           .getClass().getName() }));
/*     */       }
/*     */       
/* 326 */       authenticatedUser = realm.authenticate(certs);
/*     */       
/* 328 */       if (authenticatedUser == null) {
/* 329 */         if (log.isDebugEnabled()) {
/* 330 */           log.debug(sm.getString("combinedRealm.authFail", new Object[] { username, realm
/* 331 */             .getClass().getName() }));
/*     */         }
/*     */       } else {
/* 334 */         if (!log.isDebugEnabled()) break;
/* 335 */         log.debug(sm.getString("combinedRealm.authSuccess", new Object[] { username, realm
/* 336 */           .getClass().getName() })); break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 341 */     return authenticatedUser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(GSSContext gssContext, boolean storeCred)
/*     */   {
/* 349 */     if (gssContext.isEstablished()) {
/* 350 */       Principal authenticatedUser = null;
/* 351 */       GSSName gssName = null;
/*     */       try {
/* 353 */         gssName = gssContext.getSrcName();
/*     */       } catch (GSSException e) {
/* 355 */         log.warn(sm.getString("realmBase.gssNameFail"), e);
/* 356 */         return null;
/*     */       }
/*     */       
/* 359 */       for (Realm realm : this.realms) {
/* 360 */         if (log.isDebugEnabled()) {
/* 361 */           log.debug(sm.getString("combinedRealm.authStart", new Object[] { gssName, realm
/* 362 */             .getClass().getName() }));
/*     */         }
/*     */         
/* 365 */         authenticatedUser = realm.authenticate(gssContext, storeCred);
/*     */         
/* 367 */         if (authenticatedUser == null) {
/* 368 */           if (log.isDebugEnabled()) {
/* 369 */             log.debug(sm.getString("combinedRealm.authFail", new Object[] { gssName, realm
/* 370 */               .getClass().getName() }));
/*     */           }
/*     */         } else {
/* 373 */           if (!log.isDebugEnabled()) break;
/* 374 */           log.debug(sm.getString("combinedRealm.authSuccess", new Object[] { gssName, realm
/* 375 */             .getClass().getName() })); break;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 380 */       return authenticatedUser;
/*     */     }
/*     */     
/*     */ 
/* 384 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(GSSName gssName, GSSCredential gssCredential)
/*     */   {
/* 392 */     Principal authenticatedUser = null;
/*     */     
/* 394 */     for (Realm realm : this.realms) {
/* 395 */       if (log.isDebugEnabled()) {
/* 396 */         log.debug(sm.getString("combinedRealm.authStart", new Object[] { gssName, realm
/* 397 */           .getClass().getName() }));
/*     */       }
/*     */       
/* 400 */       authenticatedUser = realm.authenticate(gssName, gssCredential);
/*     */       
/* 402 */       if (authenticatedUser == null) {
/* 403 */         if (log.isDebugEnabled()) {
/* 404 */           log.debug(sm.getString("combinedRealm.authFail", new Object[] { gssName, realm
/* 405 */             .getClass().getName() }));
/*     */         }
/*     */       } else {
/* 408 */         if (!log.isDebugEnabled()) break;
/* 409 */         log.debug(sm.getString("combinedRealm.authSuccess", new Object[] { gssName, realm
/* 410 */           .getClass().getName() })); break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 415 */     return authenticatedUser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasRole(Wrapper wrapper, Principal principal, String role)
/*     */   {
/* 423 */     for (Realm realm : this.realms) {
/* 424 */       if (realm.hasRole(wrapper, principal, role)) {
/* 425 */         return true;
/*     */       }
/*     */     }
/* 428 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPassword(String username)
/*     */   {
/* 437 */     UnsupportedOperationException uoe = new UnsupportedOperationException(sm.getString("combinedRealm.getPassword"));
/* 438 */     log.error(sm.getString("combinedRealm.unexpectedMethod"), uoe);
/* 439 */     throw uoe;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Principal getPrincipal(String username)
/*     */   {
/* 448 */     UnsupportedOperationException uoe = new UnsupportedOperationException(sm.getString("combinedRealm.getPrincipal"));
/* 449 */     log.error(sm.getString("combinedRealm.unexpectedMethod"), uoe);
/* 450 */     throw uoe;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAvailable()
/*     */   {
/* 456 */     for (Realm realm : this.realms) {
/* 457 */       if (!realm.isAvailable()) {
/* 458 */         return false;
/*     */       }
/*     */     }
/* 461 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCredentialHandler(CredentialHandler credentialHandler)
/*     */   {
/* 469 */     log.warn(sm.getString("combinedRealm.setCredentialHandler"));
/* 470 */     super.setCredentialHandler(credentialHandler);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\CombinedRealm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */