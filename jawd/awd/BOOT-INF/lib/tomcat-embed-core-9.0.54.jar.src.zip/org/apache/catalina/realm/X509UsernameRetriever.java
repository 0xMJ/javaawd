package org.apache.catalina.realm;

import java.security.cert.X509Certificate;

public abstract interface X509UsernameRetriever
{
  public abstract String getUsername(X509Certificate paramX509Certificate);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\X509UsernameRetriever.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */