/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.MultipartConfigElement;
/*     */ import javax.servlet.ServletRegistration.Dynamic;
/*     */ import javax.servlet.ServletSecurityElement;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.util.ParameterMap;
/*     */ import org.apache.tomcat.util.buf.UDecoder;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationServletRegistration
/*     */   implements ServletRegistration.Dynamic
/*     */ {
/*  42 */   private static final StringManager sm = StringManager.getManager(ApplicationServletRegistration.class);
/*     */   
/*     */   private final Wrapper wrapper;
/*     */   private final Context context;
/*     */   private ServletSecurityElement constraint;
/*     */   
/*     */   public ApplicationServletRegistration(Wrapper wrapper, Context context)
/*     */   {
/*  50 */     this.wrapper = wrapper;
/*  51 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getClassName()
/*     */   {
/*  57 */     return this.wrapper.getServletClass();
/*     */   }
/*     */   
/*     */   public String getInitParameter(String name)
/*     */   {
/*  62 */     return this.wrapper.findInitParameter(name);
/*     */   }
/*     */   
/*     */   public Map<String, String> getInitParameters()
/*     */   {
/*  67 */     ParameterMap<String, String> result = new ParameterMap();
/*     */     
/*  69 */     String[] parameterNames = this.wrapper.findInitParameters();
/*     */     
/*  71 */     for (String parameterName : parameterNames) {
/*  72 */       result.put(parameterName, this.wrapper.findInitParameter(parameterName));
/*     */     }
/*     */     
/*  75 */     result.setLocked(true);
/*  76 */     return result;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  81 */     return this.wrapper.getName();
/*     */   }
/*     */   
/*     */   public boolean setInitParameter(String name, String value)
/*     */   {
/*  86 */     if ((name == null) || (value == null))
/*     */     {
/*  88 */       throw new IllegalArgumentException(sm.getString("applicationFilterRegistration.nullInitParam", new Object[] { name, value }));
/*     */     }
/*     */     
/*  91 */     if (getInitParameter(name) != null) {
/*  92 */       return false;
/*     */     }
/*     */     
/*  95 */     this.wrapper.addInitParameter(name, value);
/*     */     
/*  97 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<String> setInitParameters(Map<String, String> initParameters)
/*     */   {
/* 103 */     Set<String> conflicts = new HashSet();
/*     */     
/* 105 */     for (Map.Entry<String, String> entry : initParameters.entrySet()) {
/* 106 */       if ((entry.getKey() == null) || (entry.getValue() == null)) {
/* 107 */         throw new IllegalArgumentException(sm.getString("applicationFilterRegistration.nullInitParams", new Object[] {entry
/*     */         
/* 109 */           .getKey(), entry.getValue() }));
/*     */       }
/* 111 */       if (getInitParameter((String)entry.getKey()) != null) {
/* 112 */         conflicts.add(entry.getKey());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 118 */     if (conflicts.isEmpty()) {
/* 119 */       for (Map.Entry<String, String> entry : initParameters.entrySet()) {
/* 120 */         setInitParameter((String)entry.getKey(), (String)entry.getValue());
/*     */       }
/*     */     }
/*     */     
/* 124 */     return conflicts;
/*     */   }
/*     */   
/*     */   public void setAsyncSupported(boolean asyncSupported)
/*     */   {
/* 129 */     this.wrapper.setAsyncSupported(asyncSupported);
/*     */   }
/*     */   
/*     */   public void setLoadOnStartup(int loadOnStartup)
/*     */   {
/* 134 */     this.wrapper.setLoadOnStartup(loadOnStartup);
/*     */   }
/*     */   
/*     */   public void setMultipartConfig(MultipartConfigElement multipartConfig)
/*     */   {
/* 139 */     this.wrapper.setMultipartConfigElement(multipartConfig);
/*     */   }
/*     */   
/*     */   public void setRunAsRole(String roleName)
/*     */   {
/* 144 */     this.wrapper.setRunAs(roleName);
/*     */   }
/*     */   
/*     */   public Set<String> setServletSecurity(ServletSecurityElement constraint)
/*     */   {
/* 149 */     if (constraint == null) {
/* 150 */       throw new IllegalArgumentException(sm.getString("applicationServletRegistration.setServletSecurity.iae", new Object[] {
/*     */       
/* 152 */         getName(), this.context.getName() }));
/*     */     }
/*     */     
/* 155 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP)) {
/* 156 */       throw new IllegalStateException(sm.getString("applicationServletRegistration.setServletSecurity.ise", new Object[] {
/*     */       
/* 158 */         getName(), this.context.getName() }));
/*     */     }
/*     */     
/* 161 */     this.constraint = constraint;
/* 162 */     return this.context.addServletSecurity(this, constraint);
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<String> addMapping(String... urlPatterns)
/*     */   {
/* 168 */     if (urlPatterns == null) {
/* 169 */       return Collections.emptySet();
/*     */     }
/*     */     
/* 172 */     Set<String> conflicts = new HashSet();
/*     */     
/* 174 */     for (String urlPattern : urlPatterns) {
/* 175 */       String wrapperName = this.context.findServletMapping(urlPattern);
/* 176 */       if (wrapperName != null) {
/* 177 */         Wrapper wrapper = (Wrapper)this.context.findChild(wrapperName);
/* 178 */         if (wrapper.isOverridable())
/*     */         {
/*     */ 
/* 181 */           this.context.removeServletMapping(urlPattern);
/*     */         } else {
/* 183 */           conflicts.add(urlPattern);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 188 */     if (!conflicts.isEmpty()) {
/* 189 */       return conflicts;
/*     */     }
/*     */     
/* 192 */     for (String urlPattern : urlPatterns) {
/* 193 */       this.context.addServletMappingDecoded(
/* 194 */         UDecoder.URLDecode(urlPattern, StandardCharsets.UTF_8), this.wrapper.getName());
/*     */     }
/*     */     
/* 197 */     if (this.constraint != null) {
/* 198 */       this.context.addServletSecurity(this, this.constraint);
/*     */     }
/*     */     
/* 201 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */ 
/*     */   public Collection<String> getMappings()
/*     */   {
/* 207 */     Set<String> result = new HashSet();
/* 208 */     String servletName = this.wrapper.getName();
/*     */     
/* 210 */     String[] urlPatterns = this.context.findServletMappings();
/* 211 */     for (String urlPattern : urlPatterns) {
/* 212 */       String name = this.context.findServletMapping(urlPattern);
/* 213 */       if (name.equals(servletName)) {
/* 214 */         result.add(urlPattern);
/*     */       }
/*     */     }
/* 217 */     return result;
/*     */   }
/*     */   
/*     */   public String getRunAsRole()
/*     */   {
/* 222 */     return this.wrapper.getRunAs();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\ApplicationServletRegistration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */