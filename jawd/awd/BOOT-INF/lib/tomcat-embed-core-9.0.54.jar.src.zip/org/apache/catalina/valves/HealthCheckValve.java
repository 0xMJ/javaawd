/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.util.LifecycleBase;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HealthCheckValve
/*     */   extends ValveBase
/*     */ {
/*     */   private static final String UP = "{\n  \"status\": \"UP\",\n  \"checks\": []\n}";
/*     */   private static final String DOWN = "{\n  \"status\": \"DOWN\",\n  \"checks\": []\n}";
/*  50 */   private String path = "/health";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  55 */   protected boolean context = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  60 */   protected boolean checkContainersAvailable = true;
/*     */   
/*     */   public HealthCheckValve() {
/*  63 */     super(true);
/*     */   }
/*     */   
/*     */   public final String getPath() {
/*  67 */     return this.path;
/*     */   }
/*     */   
/*     */   public final void setPath(String path) {
/*  71 */     this.path = path;
/*     */   }
/*     */   
/*     */   public boolean getCheckContainersAvailable() {
/*  75 */     return this.checkContainersAvailable;
/*     */   }
/*     */   
/*     */   public void setCheckContainersAvailable(boolean checkContainersAvailable) {
/*  79 */     this.checkContainersAvailable = checkContainersAvailable;
/*     */   }
/*     */   
/*     */   protected synchronized void startInternal() throws LifecycleException
/*     */   {
/*  84 */     super.startInternal();
/*  85 */     this.context = (getContainer() instanceof Context);
/*     */   }
/*     */   
/*     */ 
/*     */   public void invoke(Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/*  92 */     MessageBytes urlMB = this.context ? request.getRequestPathMB() : request.getDecodedRequestURIMB();
/*  93 */     if (urlMB.equals(this.path)) {
/*  94 */       response.setContentType("application/json");
/*  95 */       if ((!this.checkContainersAvailable) || (isAvailable(getContainer()))) {
/*  96 */         response.getOutputStream().print("{\n  \"status\": \"UP\",\n  \"checks\": []\n}");
/*     */       } else {
/*  98 */         response.setStatus(503);
/*  99 */         response.getOutputStream().print("{\n  \"status\": \"DOWN\",\n  \"checks\": []\n}");
/*     */       }
/*     */     } else {
/* 102 */       getNext().invoke(request, response);
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean isAvailable(Container container) {
/* 107 */     for (Container child : container.findChildren()) {
/* 108 */       if (!isAvailable(child)) {
/* 109 */         return false;
/*     */       }
/*     */     }
/* 112 */     if ((container instanceof LifecycleBase)) {
/* 113 */       return ((LifecycleBase)container).getState().isAvailable();
/*     */     }
/* 115 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\HealthCheckValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */