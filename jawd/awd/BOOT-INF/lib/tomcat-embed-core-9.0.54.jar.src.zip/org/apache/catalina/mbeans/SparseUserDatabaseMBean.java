/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*     */ import org.apache.tomcat.util.modeler.ManagedBean;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SparseUserDatabaseMBean
/*     */   extends BaseModelMBean
/*     */ {
/*  48 */   private static final StringManager sm = StringManager.getManager(SparseUserDatabaseMBean.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   protected final Registry registry = MBeanUtils.createRegistry();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */   protected final MBeanServer mserver = MBeanUtils.createServer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   protected final ManagedBean managed = this.registry.findManagedBean("SparseUserDatabase");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   protected final ManagedBean managedGroup = this.registry.findManagedBean("Group");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   protected final ManagedBean managedRole = this.registry.findManagedBean("Role");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   protected final ManagedBean managedUser = this.registry.findManagedBean("User");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getGroups()
/*     */   {
/*  94 */     UserDatabase database = (UserDatabase)this.resource;
/*  95 */     List<String> results = new ArrayList();
/*  96 */     Iterator<Group> groups = database.getGroups();
/*  97 */     while (groups.hasNext()) {
/*  98 */       Group group = (Group)groups.next();
/*  99 */       results.add(findGroup(group.getGroupname()));
/*     */     }
/* 101 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getRoles()
/*     */   {
/* 109 */     UserDatabase database = (UserDatabase)this.resource;
/* 110 */     List<String> results = new ArrayList();
/* 111 */     Iterator<Role> roles = database.getRoles();
/* 112 */     while (roles.hasNext()) {
/* 113 */       Role role = (Role)roles.next();
/* 114 */       results.add(findRole(role.getRolename()));
/*     */     }
/* 116 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getUsers()
/*     */   {
/* 124 */     UserDatabase database = (UserDatabase)this.resource;
/* 125 */     List<String> results = new ArrayList();
/* 126 */     Iterator<User> users = database.getUsers();
/* 127 */     while (users.hasNext()) {
/* 128 */       User user = (User)users.next();
/* 129 */       results.add(findUser(user.getUsername()));
/*     */     }
/* 131 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createGroup(String groupname, String description)
/*     */   {
/* 145 */     UserDatabase database = (UserDatabase)this.resource;
/* 146 */     Group group = database.createGroup(groupname, description);
/*     */     try {
/* 148 */       MBeanUtils.createMBean(group);
/*     */     } catch (Exception e) {
/* 150 */       throw new IllegalArgumentException(sm.getString("userMBean.createMBeanError.group", new Object[] { groupname }), e);
/*     */     }
/* 152 */     return findGroup(groupname);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createRole(String rolename, String description)
/*     */   {
/* 164 */     UserDatabase database = (UserDatabase)this.resource;
/* 165 */     Role role = database.createRole(rolename, description);
/*     */     try {
/* 167 */       MBeanUtils.createMBean(role);
/*     */     } catch (Exception e) {
/* 169 */       throw new IllegalArgumentException(sm.getString("userMBean.createMBeanError.role", new Object[] { rolename }), e);
/*     */     }
/* 171 */     return findRole(rolename);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createUser(String username, String password, String fullName)
/*     */   {
/* 184 */     UserDatabase database = (UserDatabase)this.resource;
/* 185 */     User user = database.createUser(username, password, fullName);
/*     */     try {
/* 187 */       MBeanUtils.createMBean(user);
/*     */     } catch (Exception e) {
/* 189 */       throw new IllegalArgumentException(sm.getString("userMBean.createMBeanError.user", new Object[] { username }), e);
/*     */     }
/* 191 */     return findUser(username);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String findGroup(String groupname)
/*     */   {
/* 203 */     UserDatabase database = (UserDatabase)this.resource;
/* 204 */     Group group = database.findGroup(groupname);
/* 205 */     if (group == null) {
/* 206 */       return null;
/*     */     }
/*     */     try {
/* 209 */       ObjectName oname = MBeanUtils.createObjectName(this.managedGroup.getDomain(), group);
/* 210 */       if ((database.isSparse()) && (!this.mserver.isRegistered(oname))) {
/* 211 */         MBeanUtils.createMBean(group);
/*     */       }
/* 213 */       return oname.toString();
/*     */     } catch (Exception e) {
/* 215 */       throw new IllegalArgumentException(sm.getString("userMBean.createError.group", new Object[] { groupname }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String findRole(String rolename)
/*     */   {
/* 228 */     UserDatabase database = (UserDatabase)this.resource;
/* 229 */     Role role = database.findRole(rolename);
/* 230 */     if (role == null) {
/* 231 */       return null;
/*     */     }
/*     */     try {
/* 234 */       ObjectName oname = MBeanUtils.createObjectName(this.managedRole.getDomain(), role);
/* 235 */       if ((database.isSparse()) && (!this.mserver.isRegistered(oname))) {
/* 236 */         MBeanUtils.createMBean(role);
/*     */       }
/* 238 */       return oname.toString();
/*     */     } catch (Exception e) {
/* 240 */       throw new IllegalArgumentException(sm.getString("userMBean.createError.role", new Object[] { rolename }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String findUser(String username)
/*     */   {
/* 254 */     UserDatabase database = (UserDatabase)this.resource;
/* 255 */     User user = database.findUser(username);
/* 256 */     if (user == null) {
/* 257 */       return null;
/*     */     }
/*     */     try {
/* 260 */       ObjectName oname = MBeanUtils.createObjectName(this.managedUser.getDomain(), user);
/* 261 */       if ((database.isSparse()) && (!this.mserver.isRegistered(oname))) {
/* 262 */         MBeanUtils.createMBean(user);
/*     */       }
/* 264 */       return oname.toString();
/*     */     } catch (Exception e) {
/* 266 */       throw new IllegalArgumentException(sm.getString("userMBean.createError.user", new Object[] { username }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeGroup(String groupname)
/*     */   {
/* 277 */     UserDatabase database = (UserDatabase)this.resource;
/* 278 */     Group group = database.findGroup(groupname);
/* 279 */     if (group == null) {
/* 280 */       return;
/*     */     }
/*     */     try {
/* 283 */       MBeanUtils.destroyMBean(group);
/* 284 */       database.removeGroup(group);
/*     */     } catch (Exception e) {
/* 286 */       throw new IllegalArgumentException(sm.getString("userMBean.destroyError.group", new Object[] { groupname }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRole(String rolename)
/*     */   {
/* 297 */     UserDatabase database = (UserDatabase)this.resource;
/* 298 */     Role role = database.findRole(rolename);
/* 299 */     if (role == null) {
/* 300 */       return;
/*     */     }
/*     */     try {
/* 303 */       MBeanUtils.destroyMBean(role);
/* 304 */       database.removeRole(role);
/*     */     } catch (Exception e) {
/* 306 */       throw new IllegalArgumentException(sm.getString("userMBean.destroyError.role", new Object[] { rolename }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeUser(String username)
/*     */   {
/* 317 */     UserDatabase database = (UserDatabase)this.resource;
/* 318 */     User user = database.findUser(username);
/* 319 */     if (user == null) {
/* 320 */       return;
/*     */     }
/*     */     try {
/* 323 */       MBeanUtils.destroyMBean(user);
/* 324 */       database.removeUser(user);
/*     */     } catch (Exception e) {
/* 326 */       throw new IllegalArgumentException(sm.getString("userMBean.destroyError.user", new Object[] { username }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void save()
/*     */   {
/*     */     try
/*     */     {
/* 336 */       UserDatabase database = (UserDatabase)this.resource;
/* 337 */       if (database.isSparse()) {
/* 338 */         ObjectName query = null;
/* 339 */         Set<ObjectName> results = null;
/*     */         
/*     */ 
/*     */ 
/* 343 */         query = new ObjectName("Users:type=Group,database=" + database.getId() + ",*");
/* 344 */         results = this.mserver.queryNames(query, null);
/* 345 */         for (ObjectName result : results) {
/* 346 */           this.mserver.unregisterMBean(result);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 351 */         query = new ObjectName("Users:type=Role,database=" + database.getId() + ",*");
/* 352 */         results = this.mserver.queryNames(query, null);
/* 353 */         for (ObjectName result : results) {
/* 354 */           this.mserver.unregisterMBean(result);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 359 */         query = new ObjectName("Users:type=User,database=" + database.getId() + ",*");
/* 360 */         results = this.mserver.queryNames(query, null);
/* 361 */         for (ObjectName result : results) {
/* 362 */           this.mserver.unregisterMBean(result);
/*     */         }
/*     */       }
/* 365 */       database.save();
/*     */     } catch (Exception e) {
/* 367 */       throw new IllegalArgumentException(sm.getString("userMBean.saveError"), e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\SparseUserDatabaseMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */