/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import org.apache.tomcat.util.digester.Digester;
/*    */ import org.apache.tomcat.util.digester.RuleSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CredentialHandlerRuleSet
/*    */   implements RuleSet
/*    */ {
/* 31 */   private static final int MAX_NESTED_LEVELS = Integer.getInteger("org.apache.catalina.startup.CredentialHandlerRuleSet.MAX_NESTED_LEVELS", 3)
/*    */   
/* 33 */     .intValue();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final String prefix;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CredentialHandlerRuleSet()
/*    */   {
/* 52 */     this("");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CredentialHandlerRuleSet(String prefix)
/*    */   {
/* 64 */     this.prefix = prefix;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addRuleInstances(Digester digester)
/*    */   {
/* 82 */     StringBuilder pattern = new StringBuilder(this.prefix);
/* 83 */     for (int i = 0; i < MAX_NESTED_LEVELS; i++) {
/* 84 */       if (i > 0) {
/* 85 */         pattern.append('/');
/*    */       }
/* 87 */       pattern.append("CredentialHandler");
/* 88 */       addRuleInstances(digester, pattern.toString(), i == 0 ? "setCredentialHandler" : "addCredentialHandler");
/*    */     }
/*    */   }
/*    */   
/*    */   private void addRuleInstances(Digester digester, String pattern, String methodName)
/*    */   {
/* 94 */     digester.addObjectCreate(pattern, null, "className");
/*    */     
/* 96 */     digester.addSetProperties(pattern);
/* 97 */     digester.addSetNext(pattern, methodName, "org.apache.catalina.CredentialHandler");
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\CredentialHandlerRuleSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */