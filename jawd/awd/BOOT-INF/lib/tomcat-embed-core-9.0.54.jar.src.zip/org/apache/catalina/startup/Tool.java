/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Tool
/*     */ {
/*  73 */   private static final Log log = LogFactory.getLog(Tool.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */   private static boolean ant = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */   private static final String catalinaHome = System.getProperty("catalina.home");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */   private static boolean common = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */   private static boolean server = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 106 */   private static boolean shared = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 121 */     if (catalinaHome == null) {
/* 122 */       log.error("Must set 'catalina.home' system property");
/* 123 */       System.exit(1);
/*     */     }
/*     */     
/*     */ 
/* 127 */     int index = 0;
/*     */     for (;;) {
/* 129 */       if (index == args.length) {
/* 130 */         usage();
/* 131 */         System.exit(1);
/*     */       }
/* 133 */       if ("-ant".equals(args[index])) {
/* 134 */         ant = true;
/* 135 */       } else if ("-common".equals(args[index])) {
/* 136 */         common = true;
/* 137 */       } else if ("-server".equals(args[index])) {
/* 138 */         server = true;
/* 139 */       } else { if (!"-shared".equals(args[index])) break;
/* 140 */         shared = true;
/*     */       }
/*     */       
/*     */ 
/* 144 */       index++;
/*     */     }
/* 146 */     if (index > args.length) {
/* 147 */       usage();
/* 148 */       System.exit(1);
/*     */     }
/*     */     
/*     */ 
/* 152 */     if (ant) {
/* 153 */       System.setProperty("ant.home", catalinaHome);
/*     */     }
/*     */     
/*     */ 
/* 157 */     ClassLoader classLoader = null;
/*     */     try {
/* 159 */       List<File> packed = new ArrayList();
/* 160 */       List<File> unpacked = new ArrayList();
/* 161 */       unpacked.add(new File(catalinaHome, "classes"));
/* 162 */       packed.add(new File(catalinaHome, "lib"));
/* 163 */       if (common) {
/* 164 */         unpacked.add(new File(catalinaHome, "common" + File.separator + "classes"));
/*     */         
/* 166 */         packed.add(new File(catalinaHome, "common" + File.separator + "lib"));
/*     */       }
/*     */       
/* 169 */       if (server) {
/* 170 */         unpacked.add(new File(catalinaHome, "server" + File.separator + "classes"));
/*     */         
/* 172 */         packed.add(new File(catalinaHome, "server" + File.separator + "lib"));
/*     */       }
/*     */       
/* 175 */       if (shared) {
/* 176 */         unpacked.add(new File(catalinaHome, "shared" + File.separator + "classes"));
/*     */         
/* 178 */         packed.add(new File(catalinaHome, "shared" + File.separator + "lib"));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 183 */       classLoader = ClassLoaderFactory.createClassLoader((File[])unpacked.toArray(new File[0]), 
/* 184 */         (File[])packed.toArray(new File[0]), null);
/*     */     }
/*     */     catch (Throwable t) {
/* 187 */       Bootstrap.handleThrowable(t);
/* 188 */       log.error("Class loader creation threw exception", t);
/* 189 */       System.exit(1);
/*     */     }
/* 191 */     Thread.currentThread().setContextClassLoader(classLoader);
/*     */     
/*     */ 
/* 194 */     Class<?> clazz = null;
/* 195 */     String className = args[(index++)];
/*     */     try {
/* 197 */       if (log.isDebugEnabled()) {
/* 198 */         log.debug("Loading application class " + className);
/*     */       }
/* 200 */       clazz = classLoader.loadClass(className);
/*     */     } catch (Throwable t) {
/* 202 */       Bootstrap.handleThrowable(t);
/* 203 */       log.error("Exception creating instance of " + className, t);
/* 204 */       System.exit(1);
/*     */     }
/*     */     
/* 207 */     Method method = null;
/* 208 */     String[] params = new String[args.length - index];
/* 209 */     System.arraycopy(args, index, params, 0, params.length);
/*     */     try {
/* 211 */       if (log.isDebugEnabled()) {
/* 212 */         log.debug("Identifying main() method");
/*     */       }
/* 214 */       String methodName = "main";
/* 215 */       Class<?>[] paramTypes = new Class[1];
/* 216 */       paramTypes[0] = params.getClass();
/* 217 */       method = clazz.getMethod(methodName, paramTypes);
/*     */     } catch (Throwable t) {
/* 219 */       Bootstrap.handleThrowable(t);
/* 220 */       log.error("Exception locating main() method", t);
/* 221 */       System.exit(1);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 226 */       if (log.isDebugEnabled()) {
/* 227 */         log.debug("Calling main() method");
/*     */       }
/* 229 */       Object[] paramValues = new Object[1];
/* 230 */       paramValues[0] = params;
/* 231 */       method.invoke(null, paramValues);
/*     */     } catch (Throwable t) {
/* 233 */       t = Bootstrap.unwrapInvocationTargetException(t);
/* 234 */       Bootstrap.handleThrowable(t);
/* 235 */       log.error("Exception calling main() method", t);
/* 236 */       System.exit(1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void usage()
/*     */   {
/* 247 */     log.info("Usage:  java org.apache.catalina.startup.Tool [<options>] <class> [<arguments>]");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\Tool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */