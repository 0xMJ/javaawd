/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import javax.naming.Context;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.catalina.CredentialHandler;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.naming.ContextBindings;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceRealm
/*     */   extends RealmBase
/*     */ {
/*  53 */   private String preparedRoles = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private String preparedCredentials = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */   protected String dataSourceName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */   protected boolean localDataSource = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */   protected String roleNameCol = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   protected String userCredCol = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */   protected String userNameCol = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */   protected String userRoleTable = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */   protected String userTable = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */   private volatile boolean connectionSuccess = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDataSourceName()
/*     */   {
/* 117 */     return this.dataSourceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataSourceName(String dataSourceName)
/*     */   {
/* 126 */     this.dataSourceName = dataSourceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getLocalDataSource()
/*     */   {
/* 133 */     return this.localDataSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocalDataSource(boolean localDataSource)
/*     */   {
/* 143 */     this.localDataSource = localDataSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getRoleNameCol()
/*     */   {
/* 150 */     return this.roleNameCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRoleNameCol(String roleNameCol)
/*     */   {
/* 159 */     this.roleNameCol = roleNameCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserCredCol()
/*     */   {
/* 166 */     return this.userCredCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserCredCol(String userCredCol)
/*     */   {
/* 175 */     this.userCredCol = userCredCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserNameCol()
/*     */   {
/* 182 */     return this.userNameCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserNameCol(String userNameCol)
/*     */   {
/* 191 */     this.userNameCol = userNameCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserRoleTable()
/*     */   {
/* 198 */     return this.userRoleTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserRoleTable(String userRoleTable)
/*     */   {
/* 207 */     this.userRoleTable = userRoleTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getUserTable()
/*     */   {
/* 214 */     return this.userTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserTable(String userTable)
/*     */   {
/* 223 */     this.userTable = userTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username, String credentials)
/*     */   {
/* 248 */     if ((username == null) || (credentials == null)) {
/* 249 */       return null;
/*     */     }
/*     */     
/* 252 */     Connection dbConnection = null;
/*     */     
/*     */ 
/* 255 */     dbConnection = open();
/* 256 */     if (dbConnection == null)
/*     */     {
/* 258 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 264 */       return authenticate(dbConnection, username, credentials);
/*     */     }
/*     */     finally
/*     */     {
/* 268 */       close(dbConnection);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAvailable()
/*     */   {
/* 275 */     return this.connectionSuccess;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Principal authenticate(Connection dbConnection, String username, String credentials)
/*     */   {
/* 299 */     if ((username == null) || (credentials == null)) {
/* 300 */       if (this.containerLog.isTraceEnabled()) {
/* 301 */         this.containerLog.trace(sm.getString("dataSourceRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/*     */       
/* 304 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 308 */     String dbCredentials = getPassword(dbConnection, username);
/*     */     
/* 310 */     if (dbCredentials == null)
/*     */     {
/*     */ 
/* 313 */       getCredentialHandler().mutate(credentials);
/*     */       
/* 315 */       if (this.containerLog.isTraceEnabled()) {
/* 316 */         this.containerLog.trace(sm.getString("dataSourceRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/*     */       
/* 319 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 323 */     boolean validated = getCredentialHandler().matches(credentials, dbCredentials);
/*     */     
/* 325 */     if (validated) {
/* 326 */       if (this.containerLog.isTraceEnabled()) {
/* 327 */         this.containerLog.trace(sm.getString("dataSourceRealm.authenticateSuccess", new Object[] { username }));
/*     */       }
/*     */     }
/*     */     else {
/* 331 */       if (this.containerLog.isTraceEnabled()) {
/* 332 */         this.containerLog.trace(sm.getString("dataSourceRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/*     */       
/* 335 */       return null;
/*     */     }
/*     */     
/* 338 */     ArrayList<String> list = getRoles(dbConnection, username);
/*     */     
/*     */ 
/* 341 */     return new GenericPrincipal(username, credentials, list);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void close(Connection dbConnection)
/*     */   {
/* 353 */     if (dbConnection == null) {
/* 354 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 359 */       if (!dbConnection.getAutoCommit()) {
/* 360 */         dbConnection.commit();
/*     */       }
/*     */     } catch (SQLException e) {
/* 363 */       this.containerLog.error(sm.getString("dataSourceRealm.commit"), e);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 368 */       dbConnection.close();
/*     */     } catch (SQLException e) {
/* 370 */       this.containerLog.error(sm.getString("dataSourceRealm.close"), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Connection open()
/*     */   {
/*     */     try
/*     */     {
/* 383 */       Context context = null;
/* 384 */       if (this.localDataSource) {
/* 385 */         context = ContextBindings.getClassLoader();
/* 386 */         context = (Context)context.lookup("comp/env");
/*     */       } else {
/* 388 */         context = getServer().getGlobalNamingContext();
/*     */       }
/* 390 */       DataSource dataSource = (DataSource)context.lookup(this.dataSourceName);
/* 391 */       Connection connection = dataSource.getConnection();
/* 392 */       this.connectionSuccess = true;
/* 393 */       return connection;
/*     */     } catch (Exception e) {
/* 395 */       this.connectionSuccess = false;
/*     */       
/* 397 */       this.containerLog.error(sm.getString("dataSourceRealm.exception"), e);
/*     */     }
/* 399 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPassword(String username)
/*     */   {
/* 408 */     Connection dbConnection = null;
/*     */     
/*     */ 
/* 411 */     dbConnection = open();
/* 412 */     if (dbConnection == null) {
/* 413 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 417 */       return getPassword(dbConnection, username);
/*     */     } finally {
/* 419 */       close(dbConnection);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected String getPassword(Connection dbConnection, String username)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_3
/*     */     //   2: aload_1
/*     */     //   3: aload_0
/*     */     //   4: getfield 3	org/apache/catalina/realm/DataSourceRealm:preparedCredentials	Ljava/lang/String;
/*     */     //   7: invokeinterface 48 2 0
/*     */     //   12: astore 4
/*     */     //   14: aconst_null
/*     */     //   15: astore 5
/*     */     //   17: aload 4
/*     */     //   19: iconst_1
/*     */     //   20: aload_2
/*     */     //   21: invokeinterface 49 3 0
/*     */     //   26: aload 4
/*     */     //   28: invokeinterface 50 1 0
/*     */     //   33: astore 6
/*     */     //   35: aconst_null
/*     */     //   36: astore 7
/*     */     //   38: aload 6
/*     */     //   40: invokeinterface 51 1 0
/*     */     //   45: ifeq +12 -> 57
/*     */     //   48: aload 6
/*     */     //   50: iconst_1
/*     */     //   51: invokeinterface 52 2 0
/*     */     //   56: astore_3
/*     */     //   57: aload_3
/*     */     //   58: ifnull +10 -> 68
/*     */     //   61: aload_3
/*     */     //   62: invokevirtual 53	java/lang/String:trim	()Ljava/lang/String;
/*     */     //   65: goto +4 -> 69
/*     */     //   68: aconst_null
/*     */     //   69: astore 8
/*     */     //   71: aload 6
/*     */     //   73: ifnull +37 -> 110
/*     */     //   76: aload 7
/*     */     //   78: ifnull +25 -> 103
/*     */     //   81: aload 6
/*     */     //   83: invokeinterface 54 1 0
/*     */     //   88: goto +22 -> 110
/*     */     //   91: astore 9
/*     */     //   93: aload 7
/*     */     //   95: aload 9
/*     */     //   97: invokevirtual 56	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   100: goto +10 -> 110
/*     */     //   103: aload 6
/*     */     //   105: invokeinterface 54 1 0
/*     */     //   110: aload 4
/*     */     //   112: ifnull +37 -> 149
/*     */     //   115: aload 5
/*     */     //   117: ifnull +25 -> 142
/*     */     //   120: aload 4
/*     */     //   122: invokeinterface 57 1 0
/*     */     //   127: goto +22 -> 149
/*     */     //   130: astore 9
/*     */     //   132: aload 5
/*     */     //   134: aload 9
/*     */     //   136: invokevirtual 56	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   139: goto +10 -> 149
/*     */     //   142: aload 4
/*     */     //   144: invokeinterface 57 1 0
/*     */     //   149: aload 8
/*     */     //   151: areturn
/*     */     //   152: astore 8
/*     */     //   154: aload 8
/*     */     //   156: astore 7
/*     */     //   158: aload 8
/*     */     //   160: athrow
/*     */     //   161: astore 10
/*     */     //   163: aload 6
/*     */     //   165: ifnull +37 -> 202
/*     */     //   168: aload 7
/*     */     //   170: ifnull +25 -> 195
/*     */     //   173: aload 6
/*     */     //   175: invokeinterface 54 1 0
/*     */     //   180: goto +22 -> 202
/*     */     //   183: astore 11
/*     */     //   185: aload 7
/*     */     //   187: aload 11
/*     */     //   189: invokevirtual 56	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   192: goto +10 -> 202
/*     */     //   195: aload 6
/*     */     //   197: invokeinterface 54 1 0
/*     */     //   202: aload 10
/*     */     //   204: athrow
/*     */     //   205: astore 6
/*     */     //   207: aload 6
/*     */     //   209: astore 5
/*     */     //   211: aload 6
/*     */     //   213: athrow
/*     */     //   214: astore 12
/*     */     //   216: aload 4
/*     */     //   218: ifnull +37 -> 255
/*     */     //   221: aload 5
/*     */     //   223: ifnull +25 -> 248
/*     */     //   226: aload 4
/*     */     //   228: invokeinterface 57 1 0
/*     */     //   233: goto +22 -> 255
/*     */     //   236: astore 13
/*     */     //   238: aload 5
/*     */     //   240: aload 13
/*     */     //   242: invokevirtual 56	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   245: goto +10 -> 255
/*     */     //   248: aload 4
/*     */     //   250: invokeinterface 57 1 0
/*     */     //   255: aload 12
/*     */     //   257: athrow
/*     */     //   258: astore 4
/*     */     //   260: aload_0
/*     */     //   261: getfield 15	org/apache/catalina/realm/DataSourceRealm:containerLog	Lorg/apache/juli/logging/Log;
/*     */     //   264: getstatic 17	org/apache/catalina/realm/DataSourceRealm:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   267: ldc 58
/*     */     //   269: iconst_1
/*     */     //   270: anewarray 19	java/lang/Object
/*     */     //   273: dup
/*     */     //   274: iconst_0
/*     */     //   275: aload_2
/*     */     //   276: aastore
/*     */     //   277: invokevirtual 20	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   280: aload 4
/*     */     //   282: invokeinterface 35 3 0
/*     */     //   287: aconst_null
/*     */     //   288: areturn
/*     */     // Line number table:
/*     */     //   Java source line #434	-> byte code offset #0
/*     */     //   Java source line #436	-> byte code offset #2
/*     */     //   Java source line #437	-> byte code offset #17
/*     */     //   Java source line #439	-> byte code offset #26
/*     */     //   Java source line #440	-> byte code offset #38
/*     */     //   Java source line #441	-> byte code offset #48
/*     */     //   Java source line #444	-> byte code offset #57
/*     */     //   Java source line #445	-> byte code offset #71
/*     */     //   Java source line #446	-> byte code offset #110
/*     */     //   Java source line #444	-> byte code offset #149
/*     */     //   Java source line #439	-> byte code offset #152
/*     */     //   Java source line #445	-> byte code offset #161
/*     */     //   Java source line #436	-> byte code offset #205
/*     */     //   Java source line #446	-> byte code offset #214
/*     */     //   Java source line #447	-> byte code offset #260
/*     */     //   Java source line #450	-> byte code offset #287
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	289	0	this	DataSourceRealm
/*     */     //   0	289	1	dbConnection	Connection
/*     */     //   0	289	2	username	String
/*     */     //   1	61	3	dbCredentials	String
/*     */     //   12	237	4	stmt	java.sql.PreparedStatement
/*     */     //   258	23	4	e	SQLException
/*     */     //   15	224	5	localThrowable6	Throwable
/*     */     //   33	163	6	rs	java.sql.ResultSet
/*     */     //   205	7	6	localThrowable4	Throwable
/*     */     //   36	150	7	localThrowable7	Throwable
/*     */     //   152	7	8	localThrowable2	Throwable
/*     */     //   152	7	8	localThrowable8	Throwable
/*     */     //   91	5	9	localThrowable	Throwable
/*     */     //   130	5	9	localThrowable1	Throwable
/*     */     //   161	42	10	localObject1	Object
/*     */     //   183	5	11	localThrowable3	Throwable
/*     */     //   214	42	12	localObject2	Object
/*     */     //   236	5	13	localThrowable5	Throwable
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   81	88	91	java/lang/Throwable
/*     */     //   120	127	130	java/lang/Throwable
/*     */     //   38	71	152	java/lang/Throwable
/*     */     //   38	71	161	finally
/*     */     //   152	163	161	finally
/*     */     //   173	180	183	java/lang/Throwable
/*     */     //   17	110	205	java/lang/Throwable
/*     */     //   152	205	205	java/lang/Throwable
/*     */     //   17	110	214	finally
/*     */     //   152	216	214	finally
/*     */     //   226	233	236	java/lang/Throwable
/*     */     //   2	149	258	java/sql/SQLException
/*     */     //   152	258	258	java/sql/SQLException
/*     */   }
/*     */   
/*     */   protected Principal getPrincipal(String username)
/*     */   {
/* 461 */     Connection dbConnection = open();
/* 462 */     if (dbConnection == null) {
/* 463 */       return new GenericPrincipal(username, null, null);
/*     */     }
/*     */     try {
/* 466 */       return new GenericPrincipal(username, 
/* 467 */         getPassword(dbConnection, username), 
/* 468 */         getRoles(dbConnection, username));
/*     */     } finally {
/* 470 */       close(dbConnection);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ArrayList<String> getRoles(String username)
/*     */   {
/* 482 */     Connection dbConnection = null;
/*     */     
/*     */ 
/* 485 */     dbConnection = open();
/* 486 */     if (dbConnection == null) {
/* 487 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 491 */       return getRoles(dbConnection, username);
/*     */     } finally {
/* 493 */       close(dbConnection);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected ArrayList<String> getRoles(Connection dbConnection, String username)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 59	org/apache/catalina/realm/DataSourceRealm:allRolesMode	Lorg/apache/catalina/realm/RealmBase$AllRolesMode;
/*     */     //   4: getstatic 60	org/apache/catalina/realm/RealmBase$AllRolesMode:STRICT_MODE	Lorg/apache/catalina/realm/RealmBase$AllRolesMode;
/*     */     //   7: if_acmpeq +12 -> 19
/*     */     //   10: aload_0
/*     */     //   11: invokespecial 61	org/apache/catalina/realm/DataSourceRealm:isRoleStoreDefined	()Z
/*     */     //   14: ifne +5 -> 19
/*     */     //   17: aconst_null
/*     */     //   18: areturn
/*     */     //   19: aconst_null
/*     */     //   20: astore_3
/*     */     //   21: aload_1
/*     */     //   22: aload_0
/*     */     //   23: getfield 2	org/apache/catalina/realm/DataSourceRealm:preparedRoles	Ljava/lang/String;
/*     */     //   26: invokeinterface 48 2 0
/*     */     //   31: astore 4
/*     */     //   33: aconst_null
/*     */     //   34: astore 5
/*     */     //   36: aload 4
/*     */     //   38: iconst_1
/*     */     //   39: aload_2
/*     */     //   40: invokeinterface 49 3 0
/*     */     //   45: aload 4
/*     */     //   47: invokeinterface 50 1 0
/*     */     //   52: astore 6
/*     */     //   54: aconst_null
/*     */     //   55: astore 7
/*     */     //   57: new 62	java/util/ArrayList
/*     */     //   60: dup
/*     */     //   61: invokespecial 63	java/util/ArrayList:<init>	()V
/*     */     //   64: astore_3
/*     */     //   65: aload 6
/*     */     //   67: invokeinterface 51 1 0
/*     */     //   72: ifeq +31 -> 103
/*     */     //   75: aload 6
/*     */     //   77: iconst_1
/*     */     //   78: invokeinterface 52 2 0
/*     */     //   83: astore 8
/*     */     //   85: aload 8
/*     */     //   87: ifnull +13 -> 100
/*     */     //   90: aload_3
/*     */     //   91: aload 8
/*     */     //   93: invokevirtual 53	java/lang/String:trim	()Ljava/lang/String;
/*     */     //   96: invokevirtual 64	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*     */     //   99: pop
/*     */     //   100: goto -35 -> 65
/*     */     //   103: aload_3
/*     */     //   104: astore 8
/*     */     //   106: aload 6
/*     */     //   108: ifnull +37 -> 145
/*     */     //   111: aload 7
/*     */     //   113: ifnull +25 -> 138
/*     */     //   116: aload 6
/*     */     //   118: invokeinterface 54 1 0
/*     */     //   123: goto +22 -> 145
/*     */     //   126: astore 9
/*     */     //   128: aload 7
/*     */     //   130: aload 9
/*     */     //   132: invokevirtual 56	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   135: goto +10 -> 145
/*     */     //   138: aload 6
/*     */     //   140: invokeinterface 54 1 0
/*     */     //   145: aload 4
/*     */     //   147: ifnull +37 -> 184
/*     */     //   150: aload 5
/*     */     //   152: ifnull +25 -> 177
/*     */     //   155: aload 4
/*     */     //   157: invokeinterface 57 1 0
/*     */     //   162: goto +22 -> 184
/*     */     //   165: astore 9
/*     */     //   167: aload 5
/*     */     //   169: aload 9
/*     */     //   171: invokevirtual 56	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   174: goto +10 -> 184
/*     */     //   177: aload 4
/*     */     //   179: invokeinterface 57 1 0
/*     */     //   184: aload 8
/*     */     //   186: areturn
/*     */     //   187: astore 8
/*     */     //   189: aload 8
/*     */     //   191: astore 7
/*     */     //   193: aload 8
/*     */     //   195: athrow
/*     */     //   196: astore 10
/*     */     //   198: aload 6
/*     */     //   200: ifnull +37 -> 237
/*     */     //   203: aload 7
/*     */     //   205: ifnull +25 -> 230
/*     */     //   208: aload 6
/*     */     //   210: invokeinterface 54 1 0
/*     */     //   215: goto +22 -> 237
/*     */     //   218: astore 11
/*     */     //   220: aload 7
/*     */     //   222: aload 11
/*     */     //   224: invokevirtual 56	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   227: goto +10 -> 237
/*     */     //   230: aload 6
/*     */     //   232: invokeinterface 54 1 0
/*     */     //   237: aload 10
/*     */     //   239: athrow
/*     */     //   240: astore 6
/*     */     //   242: aload 6
/*     */     //   244: astore 5
/*     */     //   246: aload 6
/*     */     //   248: athrow
/*     */     //   249: astore 12
/*     */     //   251: aload 4
/*     */     //   253: ifnull +37 -> 290
/*     */     //   256: aload 5
/*     */     //   258: ifnull +25 -> 283
/*     */     //   261: aload 4
/*     */     //   263: invokeinterface 57 1 0
/*     */     //   268: goto +22 -> 290
/*     */     //   271: astore 13
/*     */     //   273: aload 5
/*     */     //   275: aload 13
/*     */     //   277: invokevirtual 56	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   280: goto +10 -> 290
/*     */     //   283: aload 4
/*     */     //   285: invokeinterface 57 1 0
/*     */     //   290: aload 12
/*     */     //   292: athrow
/*     */     //   293: astore 4
/*     */     //   295: aload_0
/*     */     //   296: getfield 15	org/apache/catalina/realm/DataSourceRealm:containerLog	Lorg/apache/juli/logging/Log;
/*     */     //   299: getstatic 17	org/apache/catalina/realm/DataSourceRealm:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   302: ldc 65
/*     */     //   304: iconst_1
/*     */     //   305: anewarray 19	java/lang/Object
/*     */     //   308: dup
/*     */     //   309: iconst_0
/*     */     //   310: aload_2
/*     */     //   311: aastore
/*     */     //   312: invokevirtual 20	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   315: aload 4
/*     */     //   317: invokeinterface 35 3 0
/*     */     //   322: aconst_null
/*     */     //   323: areturn
/*     */     // Line number table:
/*     */     //   Java source line #508	-> byte code offset #0
/*     */     //   Java source line #511	-> byte code offset #17
/*     */     //   Java source line #514	-> byte code offset #19
/*     */     //   Java source line #516	-> byte code offset #21
/*     */     //   Java source line #517	-> byte code offset #36
/*     */     //   Java source line #519	-> byte code offset #45
/*     */     //   Java source line #520	-> byte code offset #57
/*     */     //   Java source line #522	-> byte code offset #65
/*     */     //   Java source line #523	-> byte code offset #75
/*     */     //   Java source line #524	-> byte code offset #85
/*     */     //   Java source line #525	-> byte code offset #90
/*     */     //   Java source line #527	-> byte code offset #100
/*     */     //   Java source line #528	-> byte code offset #103
/*     */     //   Java source line #529	-> byte code offset #106
/*     */     //   Java source line #530	-> byte code offset #145
/*     */     //   Java source line #528	-> byte code offset #184
/*     */     //   Java source line #519	-> byte code offset #187
/*     */     //   Java source line #529	-> byte code offset #196
/*     */     //   Java source line #516	-> byte code offset #240
/*     */     //   Java source line #530	-> byte code offset #249
/*     */     //   Java source line #531	-> byte code offset #295
/*     */     //   Java source line #534	-> byte code offset #322
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	324	0	this	DataSourceRealm
/*     */     //   0	324	1	dbConnection	Connection
/*     */     //   0	324	2	username	String
/*     */     //   20	84	3	list	ArrayList<String>
/*     */     //   31	253	4	stmt	java.sql.PreparedStatement
/*     */     //   293	23	4	e	SQLException
/*     */     //   34	240	5	localThrowable6	Throwable
/*     */     //   52	179	6	rs	java.sql.ResultSet
/*     */     //   240	7	6	localThrowable4	Throwable
/*     */     //   55	166	7	localThrowable7	Throwable
/*     */     //   83	102	8	role	String
/*     */     //   187	7	8	localThrowable2	Throwable
/*     */     //   126	5	9	localThrowable	Throwable
/*     */     //   165	5	9	localThrowable1	Throwable
/*     */     //   196	42	10	localObject1	Object
/*     */     //   218	5	11	localThrowable3	Throwable
/*     */     //   249	42	12	localObject2	Object
/*     */     //   271	5	13	localThrowable5	Throwable
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   116	123	126	java/lang/Throwable
/*     */     //   155	162	165	java/lang/Throwable
/*     */     //   57	106	187	java/lang/Throwable
/*     */     //   57	106	196	finally
/*     */     //   187	198	196	finally
/*     */     //   208	215	218	java/lang/Throwable
/*     */     //   36	145	240	java/lang/Throwable
/*     */     //   187	240	240	java/lang/Throwable
/*     */     //   36	145	249	finally
/*     */     //   187	251	249	finally
/*     */     //   261	268	271	java/lang/Throwable
/*     */     //   21	184	293	java/sql/SQLException
/*     */     //   187	293	293	java/sql/SQLException
/*     */   }
/*     */   
/*     */   private boolean isRoleStoreDefined()
/*     */   {
/* 539 */     return (this.userRoleTable != null) || (this.roleNameCol != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 557 */     StringBuilder temp = new StringBuilder("SELECT ");
/* 558 */     temp.append(this.roleNameCol);
/* 559 */     temp.append(" FROM ");
/* 560 */     temp.append(this.userRoleTable);
/* 561 */     temp.append(" WHERE ");
/* 562 */     temp.append(this.userNameCol);
/* 563 */     temp.append(" = ?");
/* 564 */     this.preparedRoles = temp.toString();
/*     */     
/*     */ 
/* 567 */     temp = new StringBuilder("SELECT ");
/* 568 */     temp.append(this.userCredCol);
/* 569 */     temp.append(" FROM ");
/* 570 */     temp.append(this.userTable);
/* 571 */     temp.append(" WHERE ");
/* 572 */     temp.append(this.userNameCol);
/* 573 */     temp.append(" = ?");
/* 574 */     this.preparedCredentials = temp.toString();
/*     */     
/* 576 */     super.startInternal();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\DataSourceRealm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */