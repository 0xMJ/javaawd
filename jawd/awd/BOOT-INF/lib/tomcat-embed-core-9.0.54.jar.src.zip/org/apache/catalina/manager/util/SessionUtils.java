/*     */ package org.apache.catalina.manager.util;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionUtils
/*     */ {
/*     */   private static final String STRUTS_LOCALE_KEY = "org.apache.struts.action.LOCALE";
/*     */   private static final String JSTL_LOCALE_KEY = "javax.servlet.jsp.jstl.fmt.locale";
/*     */   private static final String SPRING_LOCALE_KEY = "org.springframework.web.servlet.i18n.SessionLocaleResolver.LOCALE";
/*  58 */   private static final String[] LOCALE_TEST_ATTRIBUTES = { "org.apache.struts.action.LOCALE", "org.springframework.web.servlet.i18n.SessionLocaleResolver.LOCALE", "javax.servlet.jsp.jstl.fmt.locale", "Locale", "java.util.Locale" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */   private static final String[] USER_TEST_ATTRIBUTES = { "Login", "User", "userName", "UserName", "Utilisateur", "SPRING_SECURITY_LAST_USERNAME" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */   public static Locale guessLocaleFromSession(Session in_session) { return guessLocaleFromSession(in_session.getSession()); }
/*     */   
/*     */   public static Locale guessLocaleFromSession(HttpSession in_session) {
/*  80 */     if (null == in_session) {
/*  81 */       return null;
/*     */     }
/*     */     try {
/*  84 */       Locale locale = null;
/*     */       
/*     */ 
/*  87 */       for (String localeTestAttribute : LOCALE_TEST_ATTRIBUTES) {
/*  88 */         Object obj = in_session.getAttribute(localeTestAttribute);
/*  89 */         if ((obj instanceof Locale)) {
/*  90 */           locale = (Locale)obj;
/*  91 */           break;
/*     */         }
/*  93 */         obj = in_session.getAttribute(localeTestAttribute.toLowerCase(Locale.ENGLISH));
/*  94 */         if ((obj instanceof Locale)) {
/*  95 */           locale = (Locale)obj;
/*  96 */           break;
/*     */         }
/*  98 */         obj = in_session.getAttribute(localeTestAttribute.toUpperCase(Locale.ENGLISH));
/*  99 */         if ((obj instanceof Locale)) {
/* 100 */           locale = (Locale)obj;
/* 101 */           break;
/*     */         }
/*     */       }
/*     */       
/* 105 */       if (null != locale) {
/* 106 */         return locale;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 111 */       Object tapestryArray = new ArrayList();
/* 112 */       for (Object enumeration = in_session.getAttributeNames(); ((Enumeration)enumeration).hasMoreElements();) {
/* 113 */         String name = (String)((Enumeration)enumeration).nextElement();
/* 114 */         if ((name.contains("tapestry")) && (name.contains("engine")) && (null != in_session.getAttribute(name))) {
/* 115 */           ((List)tapestryArray).add(in_session.getAttribute(name));
/*     */         }
/*     */       }
/* 118 */       if (((List)tapestryArray).size() == 1)
/*     */       {
/* 120 */         Object probableEngine = ((List)tapestryArray).get(0);
/* 121 */         if (null != probableEngine) {
/*     */           try {
/* 123 */             Method readMethod = probableEngine.getClass().getMethod("getLocale", (Class[])null);
/*     */             
/* 125 */             Object possibleLocale = readMethod.invoke(probableEngine, (Object[])null);
/* 126 */             if ((possibleLocale instanceof Locale)) {
/* 127 */               locale = (Locale)possibleLocale;
/*     */             }
/*     */           }
/*     */           catch (Exception e) {
/* 131 */             Throwable t = ExceptionUtils.unwrapInvocationTargetException(e);
/* 132 */             ExceptionUtils.handleThrowable(t);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 138 */       if (null != locale) {
/* 139 */         return locale;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 144 */       Object localeArray = new ArrayList();
/* 145 */       for (Object enumeration = in_session.getAttributeNames(); ((Enumeration)enumeration).hasMoreElements();) {
/* 146 */         String name = (String)((Enumeration)enumeration).nextElement();
/* 147 */         Object obj = in_session.getAttribute(name);
/* 148 */         if ((obj instanceof Locale)) {
/* 149 */           ((List)localeArray).add(obj);
/*     */         }
/*     */       }
/* 152 */       if (((List)localeArray).size() == 1) {}
/* 153 */       return (Locale)((List)localeArray).get(0);
/*     */     }
/*     */     catch (IllegalStateException ise) {}
/*     */     
/*     */ 
/*     */ 
/* 159 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object guessUserFromSession(Session in_session)
/*     */   {
/* 169 */     if (null == in_session) {
/* 170 */       return null;
/*     */     }
/* 172 */     if (in_session.getPrincipal() != null) {
/* 173 */       return in_session.getPrincipal().getName();
/*     */     }
/* 175 */     HttpSession httpSession = in_session.getSession();
/* 176 */     if (httpSession == null) {
/* 177 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 181 */       Object user = null;
/*     */       
/* 183 */       for (String userTestAttribute : USER_TEST_ATTRIBUTES) {
/* 184 */         Object obj = httpSession.getAttribute(userTestAttribute);
/* 185 */         if (null != obj) {
/* 186 */           user = obj;
/* 187 */           break;
/*     */         }
/* 189 */         obj = httpSession.getAttribute(userTestAttribute.toLowerCase(Locale.ENGLISH));
/* 190 */         if (null != obj) {
/* 191 */           user = obj;
/* 192 */           break;
/*     */         }
/* 194 */         obj = httpSession.getAttribute(userTestAttribute.toUpperCase(Locale.ENGLISH));
/* 195 */         if (null != obj) {
/* 196 */           user = obj;
/* 197 */           break;
/*     */         }
/*     */       }
/*     */       
/* 201 */       if (null != user) {
/* 202 */         return user;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 207 */       Object principalArray = new ArrayList();
/* 208 */       for (Object enumeration = httpSession.getAttributeNames(); ((Enumeration)enumeration).hasMoreElements();) {
/* 209 */         String name = (String)((Enumeration)enumeration).nextElement();
/* 210 */         Object obj = httpSession.getAttribute(name);
/* 211 */         if (((obj instanceof Principal)) || ((obj instanceof Subject))) {
/* 212 */           ((List)principalArray).add(obj);
/*     */         }
/*     */       }
/* 215 */       if (((List)principalArray).size() == 1) {
/* 216 */         user = ((List)principalArray).get(0);
/*     */       }
/*     */       
/* 219 */       if (null != user) {
/* 220 */         return user;
/*     */       }
/*     */       
/* 223 */       return user;
/*     */     }
/*     */     catch (IllegalStateException ise) {}
/* 226 */     return null;
/*     */   }
/*     */   
/*     */   public static long getUsedTimeForSession(Session in_session)
/*     */   {
/*     */     try
/*     */     {
/* 233 */       return in_session.getThisAccessedTime() - in_session.getCreationTime();
/*     */     }
/*     */     catch (IllegalStateException ise) {}
/*     */     
/* 237 */     return -1L;
/*     */   }
/*     */   
/*     */   public static long getTTLForSession(Session in_session)
/*     */   {
/*     */     try {
/* 243 */       return 1000 * in_session.getMaxInactiveInterval() - (System.currentTimeMillis() - in_session.getThisAccessedTime());
/*     */     }
/*     */     catch (IllegalStateException ise) {}
/*     */     
/* 247 */     return -1L;
/*     */   }
/*     */   
/*     */   public static long getInactiveTimeForSession(Session in_session)
/*     */   {
/*     */     try {
/* 253 */       return System.currentTimeMillis() - in_session.getThisAccessedTime();
/*     */     }
/*     */     catch (IllegalStateException ise) {}
/*     */     
/* 257 */     return -1L;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\manager\util\SessionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */