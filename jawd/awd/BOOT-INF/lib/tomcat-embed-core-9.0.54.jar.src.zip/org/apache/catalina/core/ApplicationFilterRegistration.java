/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.FilterRegistration.Dynamic;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.util.ParameterMap;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationFilterRegistration
/*     */   implements FilterRegistration.Dynamic
/*     */ {
/*  40 */   private static final StringManager sm = StringManager.getManager(ApplicationFilterRegistration.class);
/*     */   
/*     */   private final FilterDef filterDef;
/*     */   private final Context context;
/*     */   
/*     */   public ApplicationFilterRegistration(FilterDef filterDef, Context context)
/*     */   {
/*  47 */     this.filterDef = filterDef;
/*  48 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMappingForServletNames(EnumSet<DispatcherType> dispatcherTypes, boolean isMatchAfter, String... servletNames)
/*     */   {
/*  57 */     FilterMap filterMap = new FilterMap();
/*     */     
/*  59 */     filterMap.setFilterName(this.filterDef.getFilterName());
/*     */     Object localObject;
/*  61 */     if (dispatcherTypes != null) {
/*  62 */       for (localObject = dispatcherTypes.iterator(); ((Iterator)localObject).hasNext();) { dispatcherType = (DispatcherType)((Iterator)localObject).next();
/*  63 */         filterMap.setDispatcher(dispatcherType.name());
/*     */       }
/*     */     }
/*     */     DispatcherType dispatcherType;
/*  67 */     if (servletNames != null) {
/*  68 */       localObject = servletNames;dispatcherType = localObject.length; for (DispatcherType localDispatcherType1 = 0; localDispatcherType1 < dispatcherType; localDispatcherType1++) { String servletName = localObject[localDispatcherType1];
/*  69 */         filterMap.addServletName(servletName);
/*     */       }
/*     */       
/*  72 */       if (isMatchAfter) {
/*  73 */         this.context.addFilterMap(filterMap);
/*     */       } else {
/*  75 */         this.context.addFilterMapBefore(filterMap);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMappingForUrlPatterns(EnumSet<DispatcherType> dispatcherTypes, boolean isMatchAfter, String... urlPatterns)
/*     */   {
/*  86 */     FilterMap filterMap = new FilterMap();
/*     */     
/*  88 */     filterMap.setFilterName(this.filterDef.getFilterName());
/*     */     Object localObject;
/*  90 */     if (dispatcherTypes != null) {
/*  91 */       for (localObject = dispatcherTypes.iterator(); ((Iterator)localObject).hasNext();) { dispatcherType = (DispatcherType)((Iterator)localObject).next();
/*  92 */         filterMap.setDispatcher(dispatcherType.name());
/*     */       }
/*     */     }
/*     */     DispatcherType dispatcherType;
/*  96 */     if (urlPatterns != null)
/*     */     {
/*  98 */       localObject = urlPatterns;dispatcherType = localObject.length; for (DispatcherType localDispatcherType1 = 0; localDispatcherType1 < dispatcherType; localDispatcherType1++) { String urlPattern = localObject[localDispatcherType1];
/*  99 */         filterMap.addURLPattern(urlPattern);
/*     */       }
/*     */       
/* 102 */       if (isMatchAfter) {
/* 103 */         this.context.addFilterMap(filterMap);
/*     */       } else {
/* 105 */         this.context.addFilterMapBefore(filterMap);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection<String> getServletNameMappings()
/*     */   {
/* 114 */     Collection<String> result = new HashSet();
/*     */     
/* 116 */     FilterMap[] filterMaps = this.context.findFilterMaps();
/*     */     
/* 118 */     for (FilterMap filterMap : filterMaps) {
/* 119 */       if (filterMap.getFilterName().equals(this.filterDef.getFilterName())) {
/* 120 */         result.addAll(Arrays.asList(filterMap.getServletNames()));
/*     */       }
/*     */     }
/* 123 */     return result;
/*     */   }
/*     */   
/*     */   public Collection<String> getUrlPatternMappings()
/*     */   {
/* 128 */     Collection<String> result = new HashSet();
/*     */     
/* 130 */     FilterMap[] filterMaps = this.context.findFilterMaps();
/*     */     
/* 132 */     for (FilterMap filterMap : filterMaps) {
/* 133 */       if (filterMap.getFilterName().equals(this.filterDef.getFilterName())) {
/* 134 */         result.addAll(Arrays.asList(filterMap.getURLPatterns()));
/*     */       }
/*     */     }
/* 137 */     return result;
/*     */   }
/*     */   
/*     */   public String getClassName()
/*     */   {
/* 142 */     return this.filterDef.getFilterClass();
/*     */   }
/*     */   
/*     */   public String getInitParameter(String name)
/*     */   {
/* 147 */     return (String)this.filterDef.getParameterMap().get(name);
/*     */   }
/*     */   
/*     */   public Map<String, String> getInitParameters()
/*     */   {
/* 152 */     ParameterMap<String, String> result = new ParameterMap();
/* 153 */     result.putAll(this.filterDef.getParameterMap());
/* 154 */     result.setLocked(true);
/* 155 */     return result;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 160 */     return this.filterDef.getFilterName();
/*     */   }
/*     */   
/*     */   public boolean setInitParameter(String name, String value)
/*     */   {
/* 165 */     if ((name == null) || (value == null))
/*     */     {
/* 167 */       throw new IllegalArgumentException(sm.getString("applicationFilterRegistration.nullInitParam", new Object[] { name, value }));
/*     */     }
/*     */     
/* 170 */     if (getInitParameter(name) != null) {
/* 171 */       return false;
/*     */     }
/*     */     
/* 174 */     this.filterDef.addInitParameter(name, value);
/*     */     
/* 176 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<String> setInitParameters(Map<String, String> initParameters)
/*     */   {
/* 182 */     Set<String> conflicts = new HashSet();
/*     */     
/* 184 */     for (Map.Entry<String, String> entry : initParameters.entrySet()) {
/* 185 */       if ((entry.getKey() == null) || (entry.getValue() == null)) {
/* 186 */         throw new IllegalArgumentException(sm.getString("applicationFilterRegistration.nullInitParams", new Object[] {entry
/*     */         
/* 188 */           .getKey(), entry.getValue() }));
/*     */       }
/* 190 */       if (getInitParameter((String)entry.getKey()) != null) {
/* 191 */         conflicts.add(entry.getKey());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 197 */     for (Map.Entry<String, String> entry : initParameters.entrySet()) {
/* 198 */       setInitParameter((String)entry.getKey(), (String)entry.getValue());
/*     */     }
/*     */     
/* 201 */     return conflicts;
/*     */   }
/*     */   
/*     */   public void setAsyncSupported(boolean asyncSupported)
/*     */   {
/* 206 */     this.filterDef.setAsyncSupported(Boolean.valueOf(asyncSupported).toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\ApplicationFilterRegistration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */