/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.BitSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class URLEncoder
/*     */   implements Cloneable
/*     */ {
/*  39 */   private static final char[] hexadecimal = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */   
/*     */ 
/*  42 */   public static final URLEncoder DEFAULT = new URLEncoder();
/*  43 */   public static final URLEncoder QUERY = new URLEncoder();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final BitSet safeCharacters;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  58 */     DEFAULT.addSafeCharacter('-');
/*  59 */     DEFAULT.addSafeCharacter('.');
/*  60 */     DEFAULT.addSafeCharacter('_');
/*  61 */     DEFAULT.addSafeCharacter('~');
/*     */     
/*  63 */     DEFAULT.addSafeCharacter('!');
/*  64 */     DEFAULT.addSafeCharacter('$');
/*  65 */     DEFAULT.addSafeCharacter('&');
/*  66 */     DEFAULT.addSafeCharacter('\'');
/*  67 */     DEFAULT.addSafeCharacter('(');
/*  68 */     DEFAULT.addSafeCharacter(')');
/*  69 */     DEFAULT.addSafeCharacter('*');
/*  70 */     DEFAULT.addSafeCharacter('+');
/*  71 */     DEFAULT.addSafeCharacter(',');
/*  72 */     DEFAULT.addSafeCharacter(';');
/*  73 */     DEFAULT.addSafeCharacter('=');
/*     */     
/*  75 */     DEFAULT.addSafeCharacter(':');
/*  76 */     DEFAULT.addSafeCharacter('@');
/*     */     
/*  78 */     DEFAULT.addSafeCharacter('/');
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */     QUERY.setEncodeSpaceAsPlus(true);
/*     */     
/*     */ 
/*  93 */     QUERY.addSafeCharacter('*');
/*  94 */     QUERY.addSafeCharacter('-');
/*  95 */     QUERY.addSafeCharacter('.');
/*  96 */     QUERY.addSafeCharacter('_');
/*  97 */     QUERY.addSafeCharacter('=');
/*  98 */     QUERY.addSafeCharacter('&');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 104 */   private boolean encodeSpaceAsPlus = false;
/*     */   
/*     */   public URLEncoder()
/*     */   {
/* 108 */     this(new BitSet(256));
/*     */     
/* 110 */     for (char i = 'a'; i <= 'z'; i = (char)(i + '\001')) {
/* 111 */       addSafeCharacter(i);
/*     */     }
/* 113 */     for (char i = 'A'; i <= 'Z'; i = (char)(i + '\001')) {
/* 114 */       addSafeCharacter(i);
/*     */     }
/* 116 */     for (char i = '0'; i <= '9'; i = (char)(i + '\001')) {
/* 117 */       addSafeCharacter(i);
/*     */     }
/*     */   }
/*     */   
/*     */   private URLEncoder(BitSet safeCharacters)
/*     */   {
/* 123 */     this.safeCharacters = safeCharacters;
/*     */   }
/*     */   
/*     */   public void addSafeCharacter(char c)
/*     */   {
/* 128 */     this.safeCharacters.set(c);
/*     */   }
/*     */   
/*     */   public void removeSafeCharacter(char c)
/*     */   {
/* 133 */     this.safeCharacters.clear(c);
/*     */   }
/*     */   
/*     */   public void setEncodeSpaceAsPlus(boolean encodeSpaceAsPlus)
/*     */   {
/* 138 */     this.encodeSpaceAsPlus = encodeSpaceAsPlus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String encode(String path, Charset charset)
/*     */   {
/* 152 */     int maxBytesPerChar = 10;
/* 153 */     StringBuilder rewrittenPath = new StringBuilder(path.length());
/* 154 */     ByteArrayOutputStream buf = new ByteArrayOutputStream(maxBytesPerChar);
/* 155 */     OutputStreamWriter writer = new OutputStreamWriter(buf, charset);
/*     */     
/* 157 */     for (int i = 0; i < path.length(); i++) {
/* 158 */       int c = path.charAt(i);
/* 159 */       if (this.safeCharacters.get(c)) {
/* 160 */         rewrittenPath.append((char)c);
/* 161 */       } else if ((this.encodeSpaceAsPlus) && (c == 32)) {
/* 162 */         rewrittenPath.append('+');
/*     */       }
/*     */       else {
/*     */         try {
/* 166 */           writer.write((char)c);
/* 167 */           writer.flush();
/*     */         } catch (IOException e) {
/* 169 */           buf.reset();
/* 170 */           continue;
/*     */         }
/* 172 */         byte[] ba = buf.toByteArray();
/* 173 */         for (byte toEncode : ba)
/*     */         {
/* 175 */           rewrittenPath.append('%');
/* 176 */           int low = toEncode & 0xF;
/* 177 */           int high = (toEncode & 0xF0) >> 4;
/* 178 */           rewrittenPath.append(hexadecimal[high]);
/* 179 */           rewrittenPath.append(hexadecimal[low]);
/*     */         }
/* 181 */         buf.reset();
/*     */       }
/*     */     }
/* 184 */     return rewrittenPath.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 190 */     URLEncoder result = new URLEncoder((BitSet)this.safeCharacters.clone());
/* 191 */     result.setEncodeSpaceAsPlus(this.encodeSpaceAsPlus);
/* 192 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\URLEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */