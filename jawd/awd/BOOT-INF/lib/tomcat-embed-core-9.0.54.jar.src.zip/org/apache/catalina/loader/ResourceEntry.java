/*    */ package org.apache.catalina.loader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceEntry
/*    */ {
/* 30 */   public long lastModified = -1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 36 */   public volatile Class<?> loadedClass = null;
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\loader\ResourceEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */