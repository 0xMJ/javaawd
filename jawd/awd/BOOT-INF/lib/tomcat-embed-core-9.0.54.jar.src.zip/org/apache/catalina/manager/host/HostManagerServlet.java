/*     */ package org.apache.catalina.manager.host;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.UnavailableException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerServlet;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.core.ContainerBase;
/*     */ import org.apache.catalina.core.StandardHost;
/*     */ import org.apache.catalina.startup.HostConfig;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.StringUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HostManagerServlet
/*     */   extends HttpServlet
/*     */   implements ContainerServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/* 102 */   protected transient Context context = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   protected int debug = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */   protected transient Host installedHost = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */   protected transient Engine engine = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.manager.host");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */   protected transient Wrapper wrapper = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Wrapper getWrapper()
/*     */   {
/* 144 */     return this.wrapper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWrapper(Wrapper wrapper)
/*     */   {
/* 156 */     this.wrapper = wrapper;
/* 157 */     if (wrapper == null) {
/* 158 */       this.context = null;
/* 159 */       this.installedHost = null;
/* 160 */       this.engine = null;
/*     */     } else {
/* 162 */       this.context = ((Context)wrapper.getParent());
/* 163 */       this.installedHost = ((Host)this.context.getParent());
/* 164 */       this.engine = ((Engine)this.installedHost.getParent());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/* 197 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager.host", request
/* 198 */       .getLocales());
/*     */     
/*     */ 
/* 201 */     String command = request.getPathInfo();
/* 202 */     if (command == null) {
/* 203 */       command = request.getServletPath();
/*     */     }
/* 205 */     String name = request.getParameter("name");
/*     */     
/*     */ 
/* 208 */     response.setContentType("text/plain; charset=utf-8");
/*     */     
/*     */ 
/*     */ 
/* 212 */     response.setHeader("X-Content-Type-Options", "nosniff");
/* 213 */     PrintWriter writer = response.getWriter();
/*     */     
/*     */ 
/* 216 */     if (command == null) {
/* 217 */       writer.println(smClient.getString("hostManagerServlet.noCommand"));
/* 218 */     } else if (command.equals("/add")) {
/* 219 */       add(request, writer, name, false, smClient);
/* 220 */     } else if (command.equals("/remove")) {
/* 221 */       remove(writer, name, smClient);
/* 222 */     } else if (command.equals("/list")) {
/* 223 */       list(writer, smClient);
/* 224 */     } else if (command.equals("/start")) {
/* 225 */       start(writer, name, smClient);
/* 226 */     } else if (command.equals("/stop")) {
/* 227 */       stop(writer, name, smClient);
/* 228 */     } else if (command.equals("/persist")) {
/* 229 */       persist(writer, smClient);
/*     */     } else {
/* 231 */       writer.println(smClient.getString("hostManagerServlet.unknownCommand", new Object[] { command }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 236 */     writer.flush();
/* 237 */     writer.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void add(HttpServletRequest request, PrintWriter writer, String name, boolean htmlMode, StringManager smClient)
/*     */   {
/* 252 */     String aliases = request.getParameter("aliases");
/* 253 */     String appBase = request.getParameter("appBase");
/* 254 */     boolean manager = booleanParameter(request, "manager", false, htmlMode);
/* 255 */     boolean autoDeploy = booleanParameter(request, "autoDeploy", true, htmlMode);
/* 256 */     boolean deployOnStartup = booleanParameter(request, "deployOnStartup", true, htmlMode);
/* 257 */     boolean deployXML = booleanParameter(request, "deployXML", true, htmlMode);
/* 258 */     boolean unpackWARs = booleanParameter(request, "unpackWARs", true, htmlMode);
/* 259 */     boolean copyXML = booleanParameter(request, "copyXML", false, htmlMode);
/* 260 */     add(writer, name, aliases, appBase, manager, autoDeploy, deployOnStartup, deployXML, unpackWARs, copyXML, smClient);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean booleanParameter(HttpServletRequest request, String parameter, boolean theDefault, boolean htmlMode)
/*     */   {
/* 280 */     String value = request.getParameter(parameter);
/* 281 */     boolean booleanValue = theDefault;
/* 282 */     if (value != null) {
/* 283 */       if (htmlMode) {
/* 284 */         if (value.equals("on")) {
/* 285 */           booleanValue = true;
/*     */         }
/* 287 */       } else if (theDefault) {
/* 288 */         if (value.equals("false")) {
/* 289 */           booleanValue = false;
/*     */         }
/* 291 */       } else if (value.equals("true")) {
/* 292 */         booleanValue = true;
/*     */       }
/* 294 */     } else if (htmlMode) {
/* 295 */       booleanValue = false;
/*     */     }
/* 297 */     return booleanValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void init()
/*     */     throws ServletException
/*     */   {
/* 305 */     if ((this.wrapper == null) || (this.context == null))
/*     */     {
/* 307 */       throw new UnavailableException(sm.getString("hostManagerServlet.noWrapper"));
/*     */     }
/*     */     
/*     */ 
/* 311 */     String value = null;
/*     */     try {
/* 313 */       value = getServletConfig().getInitParameter("debug");
/* 314 */       this.debug = Integer.parseInt(value);
/*     */     } catch (Throwable t) {
/* 316 */       ExceptionUtils.handleThrowable(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void add(PrintWriter writer, String name, String aliases, String appBase, boolean manager, boolean autoDeploy, boolean deployOnStartup, boolean deployXML, boolean unpackWARs, boolean copyXML, StringManager smClient)
/*     */   {
/* 350 */     if (this.debug >= 1) {
/* 351 */       log(sm.getString("hostManagerServlet.add", new Object[] { name }));
/*     */     }
/*     */     
/*     */ 
/* 355 */     if ((name == null) || (name.length() == 0)) {
/* 356 */       writer.println(smClient.getString("hostManagerServlet.invalidHostName", new Object[] { name }));
/*     */       
/* 358 */       return;
/*     */     }
/*     */     
/*     */ 
/* 362 */     if (this.engine.findChild(name) != null) {
/* 363 */       writer.println(smClient.getString("hostManagerServlet.alreadyHost", new Object[] { name }));
/*     */       
/* 365 */       return;
/*     */     }
/*     */     
/*     */ 
/* 369 */     File appBaseFile = null;
/* 370 */     File file = null;
/* 371 */     String applicationBase = appBase;
/* 372 */     if ((applicationBase == null) || (applicationBase.length() == 0)) {
/* 373 */       applicationBase = name;
/*     */     }
/* 375 */     file = new File(applicationBase);
/* 376 */     if (!file.isAbsolute()) {
/* 377 */       file = new File(this.engine.getCatalinaBase(), file.getPath());
/*     */     }
/*     */     try {
/* 380 */       appBaseFile = file.getCanonicalFile();
/*     */     } catch (IOException e) {
/* 382 */       appBaseFile = file;
/*     */     }
/* 384 */     if ((!appBaseFile.mkdirs()) && (!appBaseFile.isDirectory())) {
/* 385 */       writer.println(smClient.getString("hostManagerServlet.appBaseCreateFail", new Object[] {appBaseFile
/*     */       
/* 387 */         .toString(), name }));
/* 388 */       return;
/*     */     }
/*     */     
/*     */ 
/* 392 */     File configBaseFile = getConfigBase(name);
/*     */     
/*     */ 
/* 395 */     if (manager) {
/* 396 */       if (configBaseFile == null) {
/* 397 */         writer.println(smClient.getString("hostManagerServlet.configBaseCreateFail", new Object[] { name }));
/*     */         
/* 399 */         return;
/*     */       }
/* 401 */       try { InputStream is = getServletContext().getResourceAsStream("/WEB-INF/manager.xml");Throwable localThrowable3 = null;
/* 402 */         try { Path dest = new File(configBaseFile, "manager.xml").toPath();
/* 403 */           Files.copy(is, dest, new CopyOption[0]);
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 401 */           localThrowable3 = localThrowable1;throw localThrowable1;
/*     */         }
/*     */         finally {
/* 404 */           if (is != null) if (localThrowable3 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else is.close();
/* 405 */         } } catch (IOException e) { writer.println(smClient.getString("hostManagerServlet.managerXml"));
/* 406 */         return;
/*     */       }
/*     */     }
/*     */     
/* 410 */     StandardHost host = new StandardHost();
/* 411 */     host.setAppBase(applicationBase);
/* 412 */     host.setName(name);
/*     */     
/* 414 */     host.addLifecycleListener(new HostConfig());
/*     */     
/*     */ 
/* 417 */     if ((aliases != null) && (!aliases.isEmpty())) {
/* 418 */       StringTokenizer tok = new StringTokenizer(aliases, ", ");
/* 419 */       while (tok.hasMoreTokens()) {
/* 420 */         host.addAlias(tok.nextToken());
/*     */       }
/*     */     }
/* 423 */     host.setAutoDeploy(autoDeploy);
/* 424 */     host.setDeployOnStartup(deployOnStartup);
/* 425 */     host.setDeployXML(deployXML);
/* 426 */     host.setUnpackWARs(unpackWARs);
/* 427 */     host.setCopyXML(copyXML);
/*     */     
/*     */     try
/*     */     {
/* 431 */       this.engine.addChild(host);
/*     */     } catch (Exception e) {
/* 433 */       writer.println(smClient.getString("hostManagerServlet.exception", new Object[] {e
/* 434 */         .toString() }));
/* 435 */       return;
/*     */     }
/*     */     
/* 438 */     host = (StandardHost)this.engine.findChild(name);
/* 439 */     if (host != null) {
/* 440 */       writer.println(smClient.getString("hostManagerServlet.addSuccess", new Object[] { name }));
/*     */     }
/*     */     else {
/* 443 */       writer.println(smClient.getString("hostManagerServlet.addFailed", new Object[] { name }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void remove(PrintWriter writer, String name, StringManager smClient)
/*     */   {
/* 460 */     if (this.debug >= 1) {
/* 461 */       log(sm.getString("hostManagerServlet.remove", new Object[] { name }));
/*     */     }
/*     */     
/*     */ 
/* 465 */     if ((name == null) || (name.length() == 0)) {
/* 466 */       writer.println(smClient.getString("hostManagerServlet.invalidHostName", new Object[] { name }));
/*     */       
/* 468 */       return;
/*     */     }
/*     */     
/*     */ 
/* 472 */     if (this.engine.findChild(name) == null) {
/* 473 */       writer.println(smClient.getString("hostManagerServlet.noHost", new Object[] { name }));
/*     */       
/* 475 */       return;
/*     */     }
/*     */     
/*     */ 
/* 479 */     if (this.engine.findChild(name) == this.installedHost) {
/* 480 */       writer.println(smClient.getString("hostManagerServlet.cannotRemoveOwnHost", new Object[] { name }));
/*     */       
/* 482 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 488 */       Container child = this.engine.findChild(name);
/* 489 */       this.engine.removeChild(child);
/* 490 */       if ((child instanceof ContainerBase)) {
/* 491 */         child.destroy();
/*     */       }
/*     */     } catch (Exception e) {
/* 494 */       writer.println(smClient.getString("hostManagerServlet.exception", new Object[] {e
/* 495 */         .toString() }));
/* 496 */       return;
/*     */     }
/*     */     
/* 499 */     Host host = (StandardHost)this.engine.findChild(name);
/* 500 */     if (host == null) {
/* 501 */       writer.println(smClient.getString("hostManagerServlet.removeSuccess", new Object[] { name }));
/*     */     }
/*     */     else
/*     */     {
/* 505 */       writer.println(smClient.getString("hostManagerServlet.removeFailed", new Object[] { name }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void list(PrintWriter writer, StringManager smClient)
/*     */   {
/* 520 */     if (this.debug >= 1) {
/* 521 */       log(sm.getString("hostManagerServlet.list", new Object[] { this.engine.getName() }));
/*     */     }
/*     */     
/* 524 */     writer.println(smClient.getString("hostManagerServlet.listed", new Object[] {this.engine
/* 525 */       .getName() }));
/* 526 */     Container[] hosts = this.engine.findChildren();
/* 527 */     for (Container container : hosts) {
/* 528 */       Host host = (Host)container;
/* 529 */       String name = host.getName();
/* 530 */       String[] aliases = host.findAliases();
/* 531 */       writer.println(String.format("[%s]:[%s]", new Object[] { name, StringUtils.join(aliases) }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void start(PrintWriter writer, String name, StringManager smClient)
/*     */   {
/* 546 */     if (this.debug >= 1) {
/* 547 */       log(sm.getString("hostManagerServlet.start", new Object[] { name }));
/*     */     }
/*     */     
/*     */ 
/* 551 */     if ((name == null) || (name.length() == 0)) {
/* 552 */       writer.println(smClient.getString("hostManagerServlet.invalidHostName", new Object[] { name }));
/*     */       
/* 554 */       return;
/*     */     }
/*     */     
/* 557 */     Container host = this.engine.findChild(name);
/*     */     
/*     */ 
/* 560 */     if (host == null) {
/* 561 */       writer.println(smClient.getString("hostManagerServlet.noHost", new Object[] { name }));
/*     */       
/* 563 */       return;
/*     */     }
/*     */     
/*     */ 
/* 567 */     if (host == this.installedHost) {
/* 568 */       writer.println(smClient.getString("hostManagerServlet.cannotStartOwnHost", new Object[] { name }));
/*     */       
/* 570 */       return;
/*     */     }
/*     */     
/*     */ 
/* 574 */     if (host.getState().isAvailable()) {
/* 575 */       writer.println(smClient.getString("hostManagerServlet.alreadyStarted", new Object[] { name }));
/*     */       
/* 577 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 582 */       host.start();
/* 583 */       writer.println(smClient.getString("hostManagerServlet.started", new Object[] { name }));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 587 */       getServletContext().log(sm.getString("hostManagerServlet.startFailed", new Object[] { name }), e);
/* 588 */       writer.println(smClient.getString("hostManagerServlet.startFailed", new Object[] { name }));
/*     */       
/* 590 */       writer.println(smClient.getString("hostManagerServlet.exception", new Object[] {e
/* 591 */         .toString() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stop(PrintWriter writer, String name, StringManager smClient)
/*     */   {
/* 606 */     if (this.debug >= 1) {
/* 607 */       log(sm.getString("hostManagerServlet.stop", new Object[] { name }));
/*     */     }
/*     */     
/*     */ 
/* 611 */     if ((name == null) || (name.length() == 0)) {
/* 612 */       writer.println(smClient.getString("hostManagerServlet.invalidHostName", new Object[] { name }));
/*     */       
/* 614 */       return;
/*     */     }
/*     */     
/* 617 */     Container host = this.engine.findChild(name);
/*     */     
/*     */ 
/* 620 */     if (host == null) {
/* 621 */       writer.println(smClient.getString("hostManagerServlet.noHost", new Object[] { name }));
/*     */       
/* 623 */       return;
/*     */     }
/*     */     
/*     */ 
/* 627 */     if (host == this.installedHost) {
/* 628 */       writer.println(smClient.getString("hostManagerServlet.cannotStopOwnHost", new Object[] { name }));
/*     */       
/* 630 */       return;
/*     */     }
/*     */     
/*     */ 
/* 634 */     if (!host.getState().isAvailable()) {
/* 635 */       writer.println(smClient.getString("hostManagerServlet.alreadyStopped", new Object[] { name }));
/*     */       
/* 637 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 642 */       host.stop();
/* 643 */       writer.println(smClient.getString("hostManagerServlet.stopped", new Object[] { name }));
/*     */     }
/*     */     catch (Exception e) {
/* 646 */       getServletContext().log(sm.getString("hostManagerServlet.stopFailed", new Object[] { name }), e);
/*     */       
/* 648 */       writer.println(smClient.getString("hostManagerServlet.stopFailed", new Object[] { name }));
/*     */       
/* 650 */       writer.println(smClient.getString("hostManagerServlet.exception", new Object[] {e
/* 651 */         .toString() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void persist(PrintWriter writer, StringManager smClient)
/*     */   {
/* 664 */     if (this.debug >= 1) {
/* 665 */       log(sm.getString("hostManagerServlet.persist"));
/*     */     }
/*     */     try
/*     */     {
/* 669 */       MBeanServer platformMBeanServer = ManagementFactory.getPlatformMBeanServer();
/* 670 */       ObjectName oname = new ObjectName(this.engine.getDomain() + ":type=StoreConfig");
/* 671 */       platformMBeanServer.invoke(oname, "storeConfig", null, null);
/* 672 */       writer.println(smClient.getString("hostManagerServlet.persisted"));
/*     */     } catch (Exception e) {
/* 674 */       getServletContext().log(sm.getString("hostManagerServlet.persistFailed"), e);
/* 675 */       writer.println(smClient.getString("hostManagerServlet.persistFailed"));
/*     */       
/*     */ 
/* 678 */       if ((e instanceof InstanceNotFoundException)) {
/* 679 */         writer.println("Please enable StoreConfig to use this feature.");
/*     */       } else {
/* 681 */         writer.println(smClient.getString("hostManagerServlet.exception", new Object[] { e.toString() }));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected File getConfigBase(String hostName)
/*     */   {
/* 695 */     File configBase = new File(this.context.getCatalinaBase(), "conf");
/* 696 */     if (!configBase.exists()) {
/* 697 */       return null;
/*     */     }
/* 699 */     if (this.engine != null) {
/* 700 */       configBase = new File(configBase, this.engine.getName());
/*     */     }
/* 702 */     if (this.installedHost != null) {
/* 703 */       configBase = new File(configBase, hostName);
/*     */     }
/* 705 */     if ((!configBase.mkdirs()) && (!configBase.isDirectory())) {
/* 706 */       return null;
/*     */     }
/* 708 */     return configBase;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\manager\host\HostManagerServlet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */