package org.apache.catalina.startup;

import java.util.Enumeration;

public abstract interface UserDatabase
{
  public abstract UserConfig getUserConfig();
  
  public abstract void setUserConfig(UserConfig paramUserConfig);
  
  public abstract String getHome(String paramString);
  
  public abstract Enumeration<String> getUsers();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\UserDatabase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */