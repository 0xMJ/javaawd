/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.concurrent.Executor;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerEvent;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.coyote.ProtocolHandler;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.threads.ThreadPoolExecutor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThreadLocalLeakPreventionListener
/*     */   extends FrameworkListener
/*     */ {
/*  54 */   private static final Log log = LogFactory.getLog(ThreadLocalLeakPreventionListener.class);
/*     */   
/*  56 */   private volatile boolean serverStopping = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  61 */   protected static final StringManager sm = StringManager.getManager(ThreadLocalLeakPreventionListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void lifecycleEvent(LifecycleEvent event)
/*     */   {
/*     */     try
/*     */     {
/*  70 */       super.lifecycleEvent(event);
/*     */       
/*  72 */       Lifecycle lifecycle = event.getLifecycle();
/*  73 */       if (("before_stop".equals(event.getType())) && ((lifecycle instanceof Server)))
/*     */       {
/*     */ 
/*     */ 
/*  77 */         this.serverStopping = true;
/*     */       }
/*     */       
/*  80 */       if (("after_stop".equals(event.getType())) && ((lifecycle instanceof Context)))
/*     */       {
/*  82 */         stopIdleThreads((Context)lifecycle);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  86 */       String msg = sm.getString("threadLocalLeakPreventionListener.lifecycleEvent.error", new Object[] { event });
/*     */       
/*     */ 
/*  89 */       log.error(msg, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void containerEvent(ContainerEvent event)
/*     */   {
/*     */     try {
/*  96 */       super.containerEvent(event);
/*     */     }
/*     */     catch (Exception e) {
/*  99 */       String msg = sm.getString("threadLocalLeakPreventionListener.containerEvent.error", new Object[] { event });
/*     */       
/*     */ 
/* 102 */       log.error(msg, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void stopIdleThreads(Context context)
/*     */   {
/* 116 */     if (this.serverStopping) {
/* 117 */       return;
/*     */     }
/*     */     
/* 120 */     if ((!(context instanceof StandardContext)) || 
/* 121 */       (!((StandardContext)context).getRenewThreadsWhenStoppingContext())) {
/* 122 */       log.debug("Not renewing threads when the context is stopping. It is not configured to do it.");
/*     */       
/* 124 */       return;
/*     */     }
/*     */     
/* 127 */     Engine engine = (Engine)context.getParent().getParent();
/* 128 */     Service service = engine.getService();
/* 129 */     Connector[] connectors = service.findConnectors();
/* 130 */     if (connectors != null) {
/* 131 */       for (Connector connector : connectors) {
/* 132 */         ProtocolHandler handler = connector.getProtocolHandler();
/* 133 */         Executor executor = null;
/* 134 */         if (handler != null) {
/* 135 */           executor = handler.getExecutor();
/*     */         }
/*     */         
/* 138 */         if ((executor instanceof ThreadPoolExecutor)) {
/* 139 */           ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor)executor;
/*     */           
/* 141 */           threadPoolExecutor.contextStopping();
/* 142 */         } else if ((executor instanceof StandardThreadExecutor)) {
/* 143 */           StandardThreadExecutor stdThreadExecutor = (StandardThreadExecutor)executor;
/*     */           
/* 145 */           stdThreadExecutor.contextStopping();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected LifecycleListener createLifecycleListener(Context context)
/*     */   {
/* 154 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\ThreadLocalLeakPreventionListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */