/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.util.jar.JarEntry;
/*    */ import java.util.jar.Manifest;
/*    */ import org.apache.catalina.WebResource;
/*    */ import org.apache.catalina.WebResourceRoot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarResourceSet
/*    */   extends AbstractSingleArchiveResourceSet
/*    */ {
/*    */   public JarResourceSet() {}
/*    */   
/*    */   public JarResourceSet(WebResourceRoot root, String webAppMount, String base, String internalPath)
/*    */     throws IllegalArgumentException
/*    */   {
/* 59 */     super(root, webAppMount, base, internalPath);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected WebResource createArchiveResource(JarEntry jarEntry, String webAppPath, Manifest manifest)
/*    */   {
/* 66 */     return new JarResource(this, webAppPath, getBaseUrlString(), jarEntry);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\webresources\JarResourceSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */