package org.apache.catalina;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import org.apache.catalina.connector.Request;

public abstract interface Authenticator
{
  public abstract boolean authenticate(Request paramRequest, HttpServletResponse paramHttpServletResponse)
    throws IOException;
  
  public abstract void login(String paramString1, String paramString2, Request paramRequest)
    throws ServletException;
  
  public abstract void logout(Request paramRequest);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\Authenticator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */