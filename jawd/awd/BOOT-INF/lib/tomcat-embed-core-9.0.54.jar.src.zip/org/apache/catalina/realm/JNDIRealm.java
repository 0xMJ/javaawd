/*      */ package org.apache.catalina.realm;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.security.GeneralSecurityException;
/*      */ import java.security.KeyManagementException;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.Principal;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import javax.naming.AuthenticationException;
/*      */ import javax.naming.CommunicationException;
/*      */ import javax.naming.CompositeName;
/*      */ import javax.naming.InvalidNameException;
/*      */ import javax.naming.Name;
/*      */ import javax.naming.NameNotFoundException;
/*      */ import javax.naming.NameParser;
/*      */ import javax.naming.NamingEnumeration;
/*      */ import javax.naming.NamingException;
/*      */ import javax.naming.PartialResultException;
/*      */ import javax.naming.ServiceUnavailableException;
/*      */ import javax.naming.directory.Attribute;
/*      */ import javax.naming.directory.Attributes;
/*      */ import javax.naming.directory.DirContext;
/*      */ import javax.naming.directory.InitialDirContext;
/*      */ import javax.naming.directory.SearchControls;
/*      */ import javax.naming.directory.SearchResult;
/*      */ import javax.naming.ldap.InitialLdapContext;
/*      */ import javax.naming.ldap.LdapContext;
/*      */ import javax.naming.ldap.StartTlsRequest;
/*      */ import javax.naming.ldap.StartTlsResponse;
/*      */ import javax.net.ssl.HostnameVerifier;
/*      */ import javax.net.ssl.SSLContext;
/*      */ import javax.net.ssl.SSLParameters;
/*      */ import javax.net.ssl.SSLSession;
/*      */ import javax.net.ssl.SSLSocketFactory;
/*      */ import org.apache.catalina.CredentialHandler;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.tomcat.util.collections.SynchronizedStack;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.ietf.jgss.GSSContext;
/*      */ import org.ietf.jgss.GSSCredential;
/*      */ import org.ietf.jgss.GSSName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JNDIRealm
/*      */   extends RealmBase
/*      */ {
/*  191 */   protected String authentication = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  196 */   protected String connectionName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  201 */   protected String connectionPassword = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  206 */   protected String connectionURL = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  213 */   protected String contextFactory = "com.sun.jndi.ldap.LdapCtxFactory";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  218 */   protected String derefAliases = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String DEREF_ALIASES = "java.naming.ldap.derefAliases";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  230 */   protected String protocol = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  239 */   protected boolean adCompat = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  247 */   protected String referrals = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  252 */   protected String userBase = "";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  258 */   protected String userSearch = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  266 */   private boolean userSearchAsUser = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  271 */   protected boolean userSubtree = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  276 */   protected String userPassword = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  284 */   protected String userRoleAttribute = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  294 */   protected String[] userPatternArray = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  301 */   protected String userPattern = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  306 */   protected String roleBase = "";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  312 */   protected String userRoleName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  317 */   protected String roleName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  324 */   protected String roleSearch = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  329 */   protected boolean roleSubtree = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  334 */   protected boolean roleNested = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  342 */   protected boolean roleSearchAsUser = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String alternateURL;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  353 */   protected int connectionAttempt = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  358 */   protected String commonRole = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  364 */   protected String connectionTimeout = "5000";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  370 */   protected String readTimeout = "5000";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  376 */   protected long sizeLimit = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  382 */   protected int timeLimit = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  388 */   protected boolean useDelegatedCredential = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  396 */   protected String spnegoDelegationQop = "auth-conf";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  401 */   private boolean useStartTls = false;
/*      */   
/*  403 */   private StartTlsResponse tls = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  409 */   private String[] cipherSuitesArray = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  415 */   private HostnameVerifier hostnameVerifier = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  420 */   private SSLSocketFactory sslSocketFactory = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String sslSocketFactoryClassName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String cipherSuites;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String hostNameVerifierClassName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String sslProtocol;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  445 */   private boolean forceDnHexEscape = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  450 */   protected JNDIConnection singleConnection = new JNDIConnection();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  455 */   protected final Lock singleConnectionLock = new ReentrantLock();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  460 */   protected SynchronizedStack<JNDIConnection> connectionPool = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  465 */   protected int connectionPoolSize = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  472 */   protected boolean useContextClassLoader = true;
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getForceDnHexEscape()
/*      */   {
/*  478 */     return this.forceDnHexEscape;
/*      */   }
/*      */   
/*      */   public void setForceDnHexEscape(boolean forceDnHexEscape)
/*      */   {
/*  483 */     this.forceDnHexEscape = forceDnHexEscape;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAuthentication()
/*      */   {
/*  491 */     return this.authentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAuthentication(String authentication)
/*      */   {
/*  501 */     this.authentication = authentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConnectionName()
/*      */   {
/*  509 */     return this.connectionName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionName(String connectionName)
/*      */   {
/*  519 */     this.connectionName = connectionName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConnectionPassword()
/*      */   {
/*  527 */     return this.connectionPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionPassword(String connectionPassword)
/*      */   {
/*  537 */     this.connectionPassword = connectionPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConnectionURL()
/*      */   {
/*  545 */     return this.connectionURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionURL(String connectionURL)
/*      */   {
/*  555 */     this.connectionURL = connectionURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getContextFactory()
/*      */   {
/*  563 */     return this.contextFactory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContextFactory(String contextFactory)
/*      */   {
/*  573 */     this.contextFactory = contextFactory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDerefAliases()
/*      */   {
/*  581 */     return this.derefAliases;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDerefAliases(String derefAliases)
/*      */   {
/*  591 */     this.derefAliases = derefAliases;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProtocol()
/*      */   {
/*  599 */     return this.protocol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProtocol(String protocol)
/*      */   {
/*  609 */     this.protocol = protocol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAdCompat()
/*      */   {
/*  617 */     return this.adCompat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAdCompat(boolean adCompat)
/*      */   {
/*  627 */     this.adCompat = adCompat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReferrals()
/*      */   {
/*  635 */     return this.referrals;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReferrals(String referrals)
/*      */   {
/*  645 */     this.referrals = referrals;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserBase()
/*      */   {
/*  653 */     return this.userBase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserBase(String userBase)
/*      */   {
/*  663 */     this.userBase = userBase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserSearch()
/*      */   {
/*  671 */     return this.userSearch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserSearch(String userSearch)
/*      */   {
/*  681 */     this.userSearch = userSearch;
/*  682 */     this.singleConnection = create();
/*      */   }
/*      */   
/*      */   public boolean isUserSearchAsUser()
/*      */   {
/*  687 */     return this.userSearchAsUser;
/*      */   }
/*      */   
/*      */   public void setUserSearchAsUser(boolean userSearchAsUser)
/*      */   {
/*  692 */     this.userSearchAsUser = userSearchAsUser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUserSubtree()
/*      */   {
/*  700 */     return this.userSubtree;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserSubtree(boolean userSubtree)
/*      */   {
/*  710 */     this.userSubtree = userSubtree;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserRoleName()
/*      */   {
/*  718 */     return this.userRoleName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserRoleName(String userRoleName)
/*      */   {
/*  728 */     this.userRoleName = userRoleName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRoleBase()
/*      */   {
/*  736 */     return this.roleBase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoleBase(String roleBase)
/*      */   {
/*  746 */     this.roleBase = roleBase;
/*  747 */     this.singleConnection = create();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRoleName()
/*      */   {
/*  755 */     return this.roleName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoleName(String roleName)
/*      */   {
/*  765 */     this.roleName = roleName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRoleSearch()
/*      */   {
/*  773 */     return this.roleSearch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoleSearch(String roleSearch)
/*      */   {
/*  783 */     this.roleSearch = roleSearch;
/*  784 */     this.singleConnection = create();
/*      */   }
/*      */   
/*      */   public boolean isRoleSearchAsUser()
/*      */   {
/*  789 */     return this.roleSearchAsUser;
/*      */   }
/*      */   
/*      */   public void setRoleSearchAsUser(boolean roleSearchAsUser)
/*      */   {
/*  794 */     this.roleSearchAsUser = roleSearchAsUser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getRoleSubtree()
/*      */   {
/*  802 */     return this.roleSubtree;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoleSubtree(boolean roleSubtree)
/*      */   {
/*  812 */     this.roleSubtree = roleSubtree;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getRoleNested()
/*      */   {
/*  820 */     return this.roleNested;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoleNested(boolean roleNested)
/*      */   {
/*  830 */     this.roleNested = roleNested;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserPassword()
/*      */   {
/*  838 */     return this.userPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserPassword(String userPassword)
/*      */   {
/*  848 */     this.userPassword = userPassword;
/*      */   }
/*      */   
/*      */   public String getUserRoleAttribute()
/*      */   {
/*  853 */     return this.userRoleAttribute;
/*      */   }
/*      */   
/*      */   public void setUserRoleAttribute(String userRoleAttribute)
/*      */   {
/*  858 */     this.userRoleAttribute = userRoleAttribute;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getUserPattern()
/*      */   {
/*  865 */     return this.userPattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserPattern(String userPattern)
/*      */   {
/*  880 */     this.userPattern = userPattern;
/*  881 */     if (userPattern == null) {
/*  882 */       this.userPatternArray = null;
/*      */     } else {
/*  884 */       this.userPatternArray = parseUserPatternString(userPattern);
/*  885 */       this.singleConnection = create();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAlternateURL()
/*      */   {
/*  896 */     return this.alternateURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlternateURL(String alternateURL)
/*      */   {
/*  906 */     this.alternateURL = alternateURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCommonRole()
/*      */   {
/*  914 */     return this.commonRole;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCommonRole(String commonRole)
/*      */   {
/*  924 */     this.commonRole = commonRole;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConnectionTimeout()
/*      */   {
/*  932 */     return this.connectionTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionTimeout(String timeout)
/*      */   {
/*  942 */     this.connectionTimeout = timeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReadTimeout()
/*      */   {
/*  950 */     return this.readTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReadTimeout(String timeout)
/*      */   {
/*  960 */     this.readTimeout = timeout;
/*      */   }
/*      */   
/*      */   public long getSizeLimit()
/*      */   {
/*  965 */     return this.sizeLimit;
/*      */   }
/*      */   
/*      */   public void setSizeLimit(long sizeLimit)
/*      */   {
/*  970 */     this.sizeLimit = sizeLimit;
/*      */   }
/*      */   
/*      */   public int getTimeLimit()
/*      */   {
/*  975 */     return this.timeLimit;
/*      */   }
/*      */   
/*      */   public void setTimeLimit(int timeLimit)
/*      */   {
/*  980 */     this.timeLimit = timeLimit;
/*      */   }
/*      */   
/*      */   public boolean isUseDelegatedCredential()
/*      */   {
/*  985 */     return this.useDelegatedCredential;
/*      */   }
/*      */   
/*      */   public void setUseDelegatedCredential(boolean useDelegatedCredential)
/*      */   {
/*  990 */     this.useDelegatedCredential = useDelegatedCredential;
/*      */   }
/*      */   
/*      */   public String getSpnegoDelegationQop()
/*      */   {
/*  995 */     return this.spnegoDelegationQop;
/*      */   }
/*      */   
/*      */   public void setSpnegoDelegationQop(String spnegoDelegationQop)
/*      */   {
/* 1000 */     this.spnegoDelegationQop = spnegoDelegationQop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseStartTls()
/*      */   {
/* 1008 */     return this.useStartTls;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseStartTls(boolean useStartTls)
/*      */   {
/* 1020 */     this.useStartTls = useStartTls;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String[] getCipherSuitesArray()
/*      */   {
/* 1029 */     if ((this.cipherSuites == null) || (this.cipherSuitesArray != null)) {
/* 1030 */       return this.cipherSuitesArray;
/*      */     }
/* 1032 */     if (this.cipherSuites.trim().isEmpty()) {
/* 1033 */       this.containerLog.warn(sm.getString("jndiRealm.emptyCipherSuites"));
/* 1034 */       this.cipherSuitesArray = null;
/*      */     } else {
/* 1036 */       this.cipherSuitesArray = this.cipherSuites.trim().split("\\s*,\\s*");
/* 1037 */       this.containerLog.debug(sm.getString("jndiRealm.cipherSuites", new Object[] {
/* 1038 */         Arrays.toString(this.cipherSuitesArray) }));
/*      */     }
/* 1040 */     return this.cipherSuitesArray;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCipherSuites(String suites)
/*      */   {
/* 1052 */     this.cipherSuites = suites;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getConnectionPoolSize()
/*      */   {
/* 1061 */     return this.connectionPoolSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionPoolSize(int connectionPoolSize)
/*      */   {
/* 1070 */     this.connectionPoolSize = connectionPoolSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getHostnameVerifierClassName()
/*      */   {
/* 1080 */     if (this.hostnameVerifier == null) {
/* 1081 */       return "";
/*      */     }
/* 1083 */     return this.hostnameVerifier.getClass().getCanonicalName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHostnameVerifierClassName(String verifierClassName)
/*      */   {
/* 1096 */     if (verifierClassName != null) {
/* 1097 */       this.hostNameVerifierClassName = verifierClassName.trim();
/*      */     } else {
/* 1099 */       this.hostNameVerifierClassName = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HostnameVerifier getHostnameVerifier()
/*      */   {
/* 1109 */     if (this.hostnameVerifier != null) {
/* 1110 */       return this.hostnameVerifier;
/*      */     }
/* 1112 */     if ((this.hostNameVerifierClassName == null) || (this.hostNameVerifierClassName.equals(""))) {
/* 1113 */       return null;
/*      */     }
/*      */     try {
/* 1116 */       Object o = constructInstance(this.hostNameVerifierClassName);
/* 1117 */       if ((o instanceof HostnameVerifier)) {
/* 1118 */         this.hostnameVerifier = ((HostnameVerifier)o);
/* 1119 */         return this.hostnameVerifier;
/*      */       }
/* 1121 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidHostnameVerifier", new Object[] { this.hostNameVerifierClassName }));
/*      */ 
/*      */     }
/*      */     catch (ReflectiveOperationException|SecurityException e)
/*      */     {
/* 1126 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidHostnameVerifier", new Object[] { this.hostNameVerifierClassName }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslSocketFactoryClassName(String factoryClassName)
/*      */   {
/* 1143 */     this.sslSocketFactoryClassName = factoryClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSslProtocol(String protocol)
/*      */   {
/* 1154 */     this.sslProtocol = protocol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String[] getSupportedSslProtocols()
/*      */   {
/*      */     try
/*      */     {
/* 1164 */       SSLContext sslContext = SSLContext.getDefault();
/* 1165 */       return sslContext.getSupportedSSLParameters().getProtocols();
/*      */     } catch (NoSuchAlgorithmException e) {
/* 1167 */       throw new RuntimeException(sm.getString("jndiRealm.exception"), e);
/*      */     }
/*      */   }
/*      */   
/*      */   private Object constructInstance(String className)
/*      */     throws ReflectiveOperationException
/*      */   {
/* 1174 */     Class<?> clazz = Class.forName(className);
/* 1175 */     return clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseContextClassLoader(boolean useContext)
/*      */   {
/* 1186 */     this.useContextClassLoader = useContext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUseContextClassLoader()
/*      */   {
/* 1197 */     return this.useContextClassLoader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(String username, String credentials)
/*      */   {
/* 1220 */     ClassLoader ocl = null;
/* 1221 */     JNDIConnection connection = null;
/* 1222 */     Principal principal = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1229 */       if (!isUseContextClassLoader()) {
/* 1230 */         ocl = Thread.currentThread().getContextClassLoader();
/* 1231 */         Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
/*      */       }
/*      */       
/*      */ 
/* 1235 */       connection = get();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 1243 */         principal = authenticate(connection, username, credentials);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (NullPointerException|NamingException e)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1262 */         this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
/*      */         
/*      */ 
/* 1265 */         close(connection);
/* 1266 */         closePooledConnections();
/*      */         
/*      */ 
/* 1269 */         connection = get();
/*      */         
/*      */ 
/* 1272 */         principal = authenticate(connection, username, credentials);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1277 */       release(connection);
/*      */       
/*      */ 
/* 1280 */       return principal;
/*      */ 
/*      */     }
/*      */     catch (NamingException e)
/*      */     {
/* 1285 */       this.containerLog.error(sm.getString("jndiRealm.exception"), e);
/*      */       
/*      */ 
/* 1288 */       close(connection);
/* 1289 */       closePooledConnections();
/*      */       
/*      */ 
/* 1292 */       if (this.containerLog.isDebugEnabled()) {
/* 1293 */         this.containerLog.debug("Returning null principal.");
/*      */       }
/* 1295 */       return null;
/*      */     } finally {
/* 1297 */       if (!isUseContextClassLoader()) {
/* 1298 */         Thread.currentThread().setContextClassLoader(ocl);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(JNDIConnection connection, String username, String credentials)
/*      */     throws NamingException
/*      */   {
/* 1319 */     if ((username == null) || (username.equals("")) || (credentials == null) || (credentials.equals(""))) {
/* 1320 */       if (this.containerLog.isDebugEnabled()) {
/* 1321 */         this.containerLog.debug("username null or empty: returning null principal.");
/*      */       }
/* 1323 */       return null;
/*      */     }
/*      */     
/* 1326 */     ClassLoader ocl = null;
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1332 */       if (!isUseContextClassLoader()) {
/* 1333 */         ocl = Thread.currentThread().getContextClassLoader();
/* 1334 */         Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
/*      */       }
/*      */       User user;
/* 1337 */       if (this.userPatternArray != null) {
/* 1338 */         for (int curUserPattern = 0; curUserPattern < this.userPatternArray.length; curUserPattern++)
/*      */         {
/* 1340 */           user = getUser(connection, username, credentials, curUserPattern);
/* 1341 */           if (user != null) {
/*      */             try
/*      */             {
/* 1344 */               if (checkCredentials(connection.context, user, credentials))
/*      */               {
/* 1346 */                 List<String> roles = getRoles(connection, user);
/* 1347 */                 if (this.containerLog.isDebugEnabled()) {
/* 1348 */                   this.containerLog.debug("Found roles: " + roles.toString());
/*      */                 }
/* 1350 */                 return new GenericPrincipal(username, credentials, roles);
/*      */               }
/*      */             }
/*      */             catch (InvalidNameException ine) {
/* 1354 */               this.containerLog.warn(sm.getString("jndiRealm.exception"), ine);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1362 */         return null;
/*      */       }
/*      */       
/* 1365 */       User user = getUser(connection, username, credentials);
/* 1366 */       if (user == null) {
/* 1367 */         return null;
/*      */       }
/*      */       
/*      */ 
/* 1371 */       if (!checkCredentials(connection.context, user, credentials)) {
/* 1372 */         return null;
/*      */       }
/*      */       
/*      */ 
/* 1376 */       List<String> roles = getRoles(connection, user);
/* 1377 */       if (this.containerLog.isDebugEnabled()) {
/* 1378 */         this.containerLog.debug("Found roles: " + roles.toString());
/*      */       }
/*      */       
/*      */ 
/* 1382 */       return new GenericPrincipal(username, credentials, roles);
/*      */     }
/*      */     finally {
/* 1385 */       if (!isUseContextClassLoader()) {
/* 1386 */         Thread.currentThread().setContextClassLoader(ocl);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(String username)
/*      */   {
/* 1401 */     ClassLoader ocl = null;
/*      */     try {
/* 1403 */       if (!isUseContextClassLoader()) {
/* 1404 */         ocl = Thread.currentThread().getContextClassLoader();
/* 1405 */         Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
/*      */       }
/* 1407 */       return super.authenticate(username);
/*      */     } finally {
/* 1409 */       if (!isUseContextClassLoader()) {
/* 1410 */         Thread.currentThread().setContextClassLoader(ocl);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realm, String md5a2)
/*      */   {
/* 1426 */     ClassLoader ocl = null;
/*      */     try {
/* 1428 */       if (!isUseContextClassLoader()) {
/* 1429 */         ocl = Thread.currentThread().getContextClassLoader();
/* 1430 */         Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
/*      */       }
/* 1432 */       return super.authenticate(username, clientDigest, nonce, nc, cnonce, qop, realm, md5a2);
/*      */     } finally {
/* 1434 */       if (!isUseContextClassLoader()) {
/* 1435 */         Thread.currentThread().setContextClassLoader(ocl);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(X509Certificate[] certs)
/*      */   {
/* 1450 */     ClassLoader ocl = null;
/*      */     try {
/* 1452 */       if (!isUseContextClassLoader()) {
/* 1453 */         ocl = Thread.currentThread().getContextClassLoader();
/* 1454 */         Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
/*      */       }
/* 1456 */       return super.authenticate(certs);
/*      */     } finally {
/* 1458 */       if (!isUseContextClassLoader()) {
/* 1459 */         Thread.currentThread().setContextClassLoader(ocl);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(GSSContext gssContext, boolean storeCred)
/*      */   {
/* 1474 */     ClassLoader ocl = null;
/*      */     try {
/* 1476 */       if (!isUseContextClassLoader()) {
/* 1477 */         ocl = Thread.currentThread().getContextClassLoader();
/* 1478 */         Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
/*      */       }
/* 1480 */       return super.authenticate(gssContext, storeCred);
/*      */     } finally {
/* 1482 */       if (!isUseContextClassLoader()) {
/* 1483 */         Thread.currentThread().setContextClassLoader(ocl);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(GSSName gssName, GSSCredential gssCredential)
/*      */   {
/* 1498 */     ClassLoader ocl = null;
/*      */     try {
/* 1500 */       if (!isUseContextClassLoader()) {
/* 1501 */         ocl = Thread.currentThread().getContextClassLoader();
/* 1502 */         Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
/*      */       }
/* 1504 */       return super.authenticate(gssName, gssCredential);
/*      */     } finally {
/* 1506 */       if (!isUseContextClassLoader()) {
/* 1507 */         Thread.currentThread().setContextClassLoader(ocl);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected User getUser(JNDIConnection connection, String username)
/*      */     throws NamingException
/*      */   {
/* 1528 */     return getUser(connection, username, null, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected User getUser(JNDIConnection connection, String username, String credentials)
/*      */     throws NamingException
/*      */   {
/* 1546 */     return getUser(connection, username, credentials, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected User getUser(JNDIConnection connection, String username, String credentials, int curUserPattern)
/*      */     throws NamingException
/*      */   {
/* 1571 */     User user = null;
/*      */     
/*      */ 
/* 1574 */     List<String> list = new ArrayList();
/* 1575 */     if (this.userPassword != null) {
/* 1576 */       list.add(this.userPassword);
/*      */     }
/* 1578 */     if (this.userRoleName != null) {
/* 1579 */       list.add(this.userRoleName);
/*      */     }
/* 1581 */     if (this.userRoleAttribute != null) {
/* 1582 */       list.add(this.userRoleAttribute);
/*      */     }
/* 1584 */     String[] attrIds = new String[list.size()];
/* 1585 */     list.toArray(attrIds);
/*      */     
/*      */ 
/* 1588 */     if ((this.userPatternArray != null) && (curUserPattern >= 0)) {
/* 1589 */       user = getUserByPattern(connection, username, credentials, attrIds, curUserPattern);
/* 1590 */       if (this.containerLog.isDebugEnabled()) {
/* 1591 */         this.containerLog.debug("Found user by pattern [" + user + "]");
/*      */       }
/*      */     } else {
/* 1594 */       boolean thisUserSearchAsUser = isUserSearchAsUser();
/*      */       try {
/* 1596 */         if (thisUserSearchAsUser) {
/* 1597 */           userCredentialsAdd(connection.context, username, credentials);
/*      */         }
/* 1599 */         user = getUserBySearch(connection, username, attrIds);
/*      */       } finally {
/* 1601 */         if (thisUserSearchAsUser) {
/* 1602 */           userCredentialsRemove(connection.context);
/*      */         }
/*      */       }
/* 1605 */       if (this.containerLog.isDebugEnabled()) {
/* 1606 */         this.containerLog.debug("Found user by search [" + user + "]");
/*      */       }
/*      */     }
/* 1609 */     if ((this.userPassword == null) && (credentials != null) && (user != null))
/*      */     {
/*      */ 
/* 1612 */       return new User(user.getUserName(), user.getDN(), credentials, user.getRoles(), user.getUserRoleId());
/*      */     }
/*      */     
/* 1615 */     return user;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected User getUserByPattern(DirContext context, String username, String[] attrIds, String dn)
/*      */     throws NamingException
/*      */   {
/* 1636 */     if ((attrIds == null) || (attrIds.length == 0)) {
/* 1637 */       return new User(username, dn, null, null, null);
/*      */     }
/*      */     
/*      */ 
/* 1641 */     Attributes attrs = null;
/*      */     try {
/* 1643 */       attrs = context.getAttributes(dn, attrIds);
/*      */     } catch (NameNotFoundException e) {
/* 1645 */       return null;
/*      */     }
/* 1647 */     if (attrs == null) {
/* 1648 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1652 */     String password = null;
/* 1653 */     if (this.userPassword != null) {
/* 1654 */       password = getAttributeValue(this.userPassword, attrs);
/*      */     }
/*      */     
/* 1657 */     String userRoleAttrValue = null;
/* 1658 */     if (this.userRoleAttribute != null) {
/* 1659 */       userRoleAttrValue = getAttributeValue(this.userRoleAttribute, attrs);
/*      */     }
/*      */     
/*      */ 
/* 1663 */     ArrayList<String> roles = null;
/* 1664 */     if (this.userRoleName != null) {
/* 1665 */       roles = addAttributeValues(this.userRoleName, attrs, roles);
/*      */     }
/*      */     
/* 1668 */     return new User(username, dn, password, roles, userRoleAttrValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected User getUserByPattern(JNDIConnection connection, String username, String credentials, String[] attrIds, int curUserPattern)
/*      */     throws NamingException
/*      */   {
/* 1690 */     User user = null;
/*      */     
/* 1692 */     if ((username == null) || (this.userPatternArray[curUserPattern] == null)) {
/* 1693 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1699 */     String dn = connection.userPatternFormatArray[curUserPattern].format(new String[] {
/* 1700 */       doAttributeValueEscaping(username) });
/*      */     try
/*      */     {
/* 1703 */       user = getUserByPattern(connection.context, username, attrIds, dn);
/*      */     } catch (NameNotFoundException e) {
/* 1705 */       return null;
/*      */     }
/*      */     catch (NamingException e)
/*      */     {
/*      */       try {
/* 1710 */         userCredentialsAdd(connection.context, dn, credentials);
/*      */         
/* 1712 */         user = getUserByPattern(connection.context, username, attrIds, dn);
/*      */       } finally {
/* 1714 */         userCredentialsRemove(connection.context);
/*      */       }
/*      */     }
/* 1717 */     return user;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected User getUserBySearch(JNDIConnection connection, String username, String[] attrIds)
/*      */     throws NamingException
/*      */   {
/* 1735 */     if ((username == null) || (connection.userSearchFormat == null)) {
/* 1736 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1742 */     String filter = connection.userSearchFormat.format(new String[] { doFilterEscaping(username) });
/*      */     
/*      */ 
/* 1745 */     SearchControls constraints = new SearchControls();
/*      */     
/* 1747 */     if (this.userSubtree) {
/* 1748 */       constraints.setSearchScope(2);
/*      */     } else {
/* 1750 */       constraints.setSearchScope(1);
/*      */     }
/*      */     
/* 1753 */     constraints.setCountLimit(this.sizeLimit);
/* 1754 */     constraints.setTimeLimit(this.timeLimit);
/*      */     
/*      */ 
/* 1757 */     if (attrIds == null) {
/* 1758 */       attrIds = new String[0];
/*      */     }
/* 1760 */     constraints.setReturningAttributes(attrIds);
/*      */     
/* 1762 */     NamingEnumeration<SearchResult> results = connection.context.search(this.userBase, filter, constraints);
/*      */     try
/*      */     {
/*      */       User localUser2;
/*      */       try {
/* 1767 */         if ((results == null) || (!results.hasMore())) {
/* 1768 */           return null;
/*      */         }
/*      */       } catch (PartialResultException ex) {
/* 1771 */         if (!this.adCompat) {
/* 1772 */           throw ex;
/*      */         }
/* 1774 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1779 */       SearchResult result = (SearchResult)results.next();
/*      */       
/*      */       try
/*      */       {
/* 1783 */         if (results.hasMore()) {
/* 1784 */           if (this.containerLog.isInfoEnabled()) {
/* 1785 */             this.containerLog.info(sm.getString("jndiRealm.multipleEntries", new Object[] { username }));
/*      */           }
/* 1787 */           return null;
/*      */         }
/*      */       } catch (PartialResultException ex) {
/* 1790 */         if (!this.adCompat) {
/* 1791 */           throw ex;
/*      */         }
/*      */       }
/*      */       
/* 1795 */       String dn = getDistinguishedName(connection.context, this.userBase, result);
/*      */       
/* 1797 */       if (this.containerLog.isTraceEnabled()) {
/* 1798 */         this.containerLog.trace("  entry found for " + username + " with dn " + dn);
/*      */       }
/*      */       
/*      */ 
/* 1802 */       Attributes attrs = result.getAttributes();
/* 1803 */       if (attrs == null) {
/* 1804 */         return null;
/*      */       }
/*      */       
/*      */ 
/* 1808 */       String password = null;
/* 1809 */       if (this.userPassword != null) {
/* 1810 */         password = getAttributeValue(this.userPassword, attrs);
/*      */       }
/*      */       
/* 1813 */       String userRoleAttrValue = null;
/* 1814 */       if (this.userRoleAttribute != null) {
/* 1815 */         userRoleAttrValue = getAttributeValue(this.userRoleAttribute, attrs);
/*      */       }
/*      */       
/*      */ 
/* 1819 */       ArrayList<String> roles = null;
/* 1820 */       if (this.userRoleName != null) {
/* 1821 */         roles = addAttributeValues(this.userRoleName, attrs, roles);
/*      */       }
/*      */       
/* 1824 */       return new User(username, dn, password, roles, userRoleAttrValue);
/*      */     } finally {
/* 1826 */       if (results != null) {
/* 1827 */         results.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkCredentials(DirContext context, User user, String credentials)
/*      */     throws NamingException
/*      */   {
/* 1850 */     boolean validated = false;
/*      */     
/* 1852 */     if (this.userPassword == null) {
/* 1853 */       validated = bindAsUser(context, user, credentials);
/*      */     } else {
/* 1855 */       validated = compareCredentials(context, user, credentials);
/*      */     }
/*      */     
/* 1858 */     if (this.containerLog.isTraceEnabled()) {
/* 1859 */       if (validated) {
/* 1860 */         this.containerLog.trace(sm.getString("jndiRealm.authenticateSuccess", new Object[] { user.getUserName() }));
/*      */       } else {
/* 1862 */         this.containerLog.trace(sm.getString("jndiRealm.authenticateFailure", new Object[] { user.getUserName() }));
/*      */       }
/*      */     }
/* 1865 */     return validated;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean compareCredentials(DirContext context, User info, String credentials)
/*      */     throws NamingException
/*      */   {
/* 1881 */     if (this.containerLog.isTraceEnabled()) {
/* 1882 */       this.containerLog.trace("  validating credentials");
/*      */     }
/*      */     
/* 1885 */     if ((info == null) || (credentials == null)) {
/* 1886 */       return false;
/*      */     }
/*      */     
/* 1889 */     String password = info.getPassword();
/*      */     
/* 1891 */     return getCredentialHandler().matches(credentials, password);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean bindAsUser(DirContext context, User user, String credentials)
/*      */     throws NamingException
/*      */   {
/* 1906 */     if ((credentials == null) || (user == null)) {
/* 1907 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1912 */     String dn = user.getDN();
/* 1913 */     if (dn == null) {
/* 1914 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1918 */     if (this.containerLog.isTraceEnabled()) {
/* 1919 */       this.containerLog.trace("  validating credentials by binding as the user");
/*      */     }
/*      */     
/* 1922 */     userCredentialsAdd(context, dn, credentials);
/*      */     
/*      */ 
/* 1925 */     boolean validated = false;
/*      */     try {
/* 1927 */       if (this.containerLog.isTraceEnabled()) {
/* 1928 */         this.containerLog.trace("  binding as " + dn);
/*      */       }
/* 1930 */       context.getAttributes("", null);
/* 1931 */       validated = true;
/*      */     }
/*      */     catch (AuthenticationException e) {
/* 1934 */       if (this.containerLog.isTraceEnabled()) {
/* 1935 */         this.containerLog.trace("  bind attempt failed");
/*      */       }
/*      */     }
/*      */     
/* 1939 */     userCredentialsRemove(context);
/*      */     
/* 1941 */     return validated;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void userCredentialsAdd(DirContext context, String dn, String credentials)
/*      */     throws NamingException
/*      */   {
/* 1956 */     context.addToEnvironment("java.naming.security.principal", dn);
/* 1957 */     context.addToEnvironment("java.naming.security.credentials", credentials);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void userCredentialsRemove(DirContext context)
/*      */     throws NamingException
/*      */   {
/* 1971 */     if (this.connectionName != null) {
/* 1972 */       context.addToEnvironment("java.naming.security.principal", this.connectionName);
/*      */     } else {
/* 1974 */       context.removeFromEnvironment("java.naming.security.principal");
/*      */     }
/*      */     
/* 1977 */     if (this.connectionPassword != null) {
/* 1978 */       context.addToEnvironment("java.naming.security.credentials", this.connectionPassword);
/*      */     } else {
/* 1980 */       context.removeFromEnvironment("java.naming.security.credentials");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<String> getRoles(JNDIConnection connection, User user)
/*      */     throws NamingException
/*      */   {
/* 1998 */     if (user == null) {
/* 1999 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2004 */     String dn = user.getDN();
/*      */     
/*      */ 
/* 2007 */     String username = user.getUserName();
/* 2008 */     String userRoleId = user.getUserRoleId();
/*      */     
/* 2010 */     if ((dn == null) || (username == null)) {
/* 2011 */       return null;
/*      */     }
/*      */     
/* 2014 */     if (this.containerLog.isTraceEnabled()) {
/* 2015 */       this.containerLog.trace("  getRoles(" + dn + ")");
/*      */     }
/*      */     
/*      */ 
/* 2019 */     List<String> list = new ArrayList();
/* 2020 */     List<String> userRoles = user.getRoles();
/* 2021 */     if (userRoles != null) {
/* 2022 */       list.addAll(userRoles);
/*      */     }
/* 2024 */     if (this.commonRole != null) {
/* 2025 */       list.add(this.commonRole);
/*      */     }
/*      */     
/* 2028 */     if (this.containerLog.isTraceEnabled()) {
/* 2029 */       this.containerLog.trace("  Found " + list.size() + " user internal roles");
/* 2030 */       this.containerLog.trace("  Found user internal roles " + list.toString());
/*      */     }
/*      */     
/*      */ 
/* 2034 */     if ((connection.roleFormat == null) || (this.roleName == null)) {
/* 2035 */       return list;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2041 */     String filter = connection.roleFormat.format(new String[] {
/* 2042 */       doFilterEscaping(dn), 
/* 2043 */       doFilterEscaping(doAttributeValueEscaping(username)), 
/* 2044 */       doFilterEscaping(doAttributeValueEscaping(userRoleId)) });
/* 2045 */     SearchControls controls = new SearchControls();
/* 2046 */     if (this.roleSubtree) {
/* 2047 */       controls.setSearchScope(2);
/*      */     } else {
/* 2049 */       controls.setSearchScope(1);
/*      */     }
/* 2051 */     controls.setReturningAttributes(new String[] { this.roleName });
/*      */     
/* 2053 */     String base = null;
/* 2054 */     if (connection.roleBaseFormat != null) {
/* 2055 */       NameParser np = connection.context.getNameParser("");
/* 2056 */       Name name = np.parse(dn);
/* 2057 */       String[] nameParts = new String[name.size()];
/* 2058 */       for (int i = 0; i < name.size(); i++)
/*      */       {
/*      */ 
/* 2061 */         nameParts[i] = convertToHexEscape(name.get(i));
/*      */       }
/* 2063 */       base = connection.roleBaseFormat.format(nameParts);
/*      */     } else {
/* 2065 */       base = "";
/*      */     }
/*      */     
/*      */ 
/* 2069 */     NamingEnumeration<SearchResult> results = searchAsUser(connection.context, user, base, filter, controls, 
/* 2070 */       isRoleSearchAsUser());
/*      */     
/* 2072 */     if (results == null) {
/* 2073 */       return list;
/*      */     }
/*      */     
/* 2076 */     Map<String, String> groupMap = new HashMap();
/*      */     Attributes attrs;
/* 2078 */     try { while (results.hasMore()) {
/* 2079 */         SearchResult result = (SearchResult)results.next();
/* 2080 */         attrs = result.getAttributes();
/* 2081 */         if (attrs != null)
/*      */         {
/*      */ 
/* 2084 */           String dname = getDistinguishedName(connection.context, base, result);
/* 2085 */           String name = getAttributeValue(this.roleName, attrs);
/* 2086 */           if ((name != null) && (dname != null))
/* 2087 */             groupMap.put(dname, name);
/*      */         }
/*      */       }
/*      */     } catch (PartialResultException ex) {
/* 2091 */       if (!this.adCompat) {
/* 2092 */         throw ex;
/*      */       }
/*      */     } finally {
/* 2095 */       results.close();
/*      */     }
/*      */     
/* 2098 */     if (this.containerLog.isTraceEnabled()) {
/* 2099 */       Set<Map.Entry<String, String>> entries = groupMap.entrySet();
/* 2100 */       this.containerLog.trace("  Found " + entries.size() + " direct roles");
/* 2101 */       for (attrs = entries.iterator(); attrs.hasNext();) { entry = (Map.Entry)attrs.next();
/* 2102 */         this.containerLog.trace("  Found direct role " + (String)entry.getKey() + " -> " + (String)entry.getValue());
/*      */       }
/*      */     }
/*      */     
/*      */     Map.Entry<String, String> entry;
/* 2107 */     if (getRoleNested())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2113 */       Map<String, String> newGroups = new HashMap(groupMap);
/* 2114 */       while (!newGroups.isEmpty()) {
/* 2115 */         Map<String, String> newThisRound = new HashMap();
/*      */         
/* 2117 */         for (Map.Entry<String, String> group : newGroups.entrySet())
/*      */         {
/*      */ 
/*      */ 
/* 2121 */           filter = connection.roleFormat.format(new String[] {
/* 2122 */             doFilterEscaping((String)group.getKey()), 
/* 2123 */             doFilterEscaping(doAttributeValueEscaping((String)group.getValue())), 
/* 2124 */             doFilterEscaping(doAttributeValueEscaping((String)group.getValue())) });
/*      */           
/* 2126 */           if (this.containerLog.isTraceEnabled()) {
/* 2127 */             this.containerLog.trace("Perform a nested group search with base " + this.roleBase + " and filter " + filter);
/*      */           }
/*      */           
/*      */ 
/* 2131 */           results = searchAsUser(connection.context, user, base, filter, controls, isRoleSearchAsUser());
/*      */           try
/*      */           {
/* 2134 */             while (results.hasMore()) {
/* 2135 */               SearchResult result = (SearchResult)results.next();
/* 2136 */               Attributes attrs = result.getAttributes();
/* 2137 */               if (attrs != null)
/*      */               {
/*      */ 
/* 2140 */                 String dname = getDistinguishedName(connection.context, this.roleBase, result);
/* 2141 */                 String name = getAttributeValue(this.roleName, attrs);
/* 2142 */                 if ((name != null) && (dname != null) && (!groupMap.keySet().contains(dname))) {
/* 2143 */                   groupMap.put(dname, name);
/* 2144 */                   newThisRound.put(dname, name);
/*      */                   
/* 2146 */                   if (this.containerLog.isTraceEnabled())
/* 2147 */                     this.containerLog.trace("  Found nested role " + dname + " -> " + name);
/*      */                 }
/*      */               }
/*      */             }
/*      */           } catch (PartialResultException ex) {
/* 2152 */             if (!this.adCompat) {
/* 2153 */               throw ex;
/*      */             }
/*      */           } finally {
/* 2156 */             results.close();
/*      */           }
/*      */         }
/*      */         
/* 2160 */         newGroups = newThisRound;
/*      */       }
/*      */     }
/*      */     
/* 2164 */     list.addAll(groupMap.values());
/* 2165 */     return list;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private NamingEnumeration<SearchResult> searchAsUser(DirContext context, User user, String base, String filter, SearchControls controls, boolean searchAsUser)
/*      */     throws NamingException
/*      */   {
/*      */     try
/*      */     {
/* 2195 */       if (searchAsUser) {
/* 2196 */         userCredentialsAdd(context, user.getDN(), user.getPassword());
/*      */       }
/* 2198 */       results = context.search(base, filter, controls);
/*      */     } finally { NamingEnumeration<SearchResult> results;
/* 2200 */       if (searchAsUser)
/* 2201 */         userCredentialsRemove(context);
/*      */     }
/*      */     NamingEnumeration<SearchResult> results;
/* 2204 */     return results;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getAttributeValue(String attrId, Attributes attrs)
/*      */     throws NamingException
/*      */   {
/* 2218 */     if (this.containerLog.isTraceEnabled()) {
/* 2219 */       this.containerLog.trace("  retrieving attribute " + attrId);
/*      */     }
/*      */     
/* 2222 */     if ((attrId == null) || (attrs == null)) {
/* 2223 */       return null;
/*      */     }
/*      */     
/* 2226 */     Attribute attr = attrs.get(attrId);
/* 2227 */     if (attr == null) {
/* 2228 */       return null;
/*      */     }
/* 2230 */     Object value = attr.get();
/* 2231 */     if (value == null) {
/* 2232 */       return null;
/*      */     }
/* 2234 */     String valueString = null;
/* 2235 */     if ((value instanceof byte[])) {
/* 2236 */       valueString = new String((byte[])value);
/*      */     } else {
/* 2238 */       valueString = value.toString();
/*      */     }
/*      */     
/* 2241 */     return valueString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ArrayList<String> addAttributeValues(String attrId, Attributes attrs, ArrayList<String> values)
/*      */     throws NamingException
/*      */   {
/* 2257 */     if (this.containerLog.isTraceEnabled()) {
/* 2258 */       this.containerLog.trace("  retrieving values for attribute " + attrId);
/*      */     }
/* 2260 */     if ((attrId == null) || (attrs == null)) {
/* 2261 */       return values;
/*      */     }
/* 2263 */     if (values == null) {
/* 2264 */       values = new ArrayList();
/*      */     }
/* 2266 */     Attribute attr = attrs.get(attrId);
/* 2267 */     if (attr == null) {
/* 2268 */       return values;
/*      */     }
/* 2270 */     NamingEnumeration<?> e = attr.getAll();
/*      */     try {
/* 2272 */       while (e.hasMore()) {
/* 2273 */         String value = (String)e.next();
/* 2274 */         values.add(value);
/*      */       }
/*      */     } catch (PartialResultException ex) {
/* 2277 */       if (!this.adCompat) {
/* 2278 */         throw ex;
/*      */       }
/*      */     } finally {
/* 2281 */       e.close();
/*      */     }
/* 2283 */     return values;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void close(JNDIConnection connection)
/*      */   {
/* 2295 */     if ((connection == null) || (connection.context == null)) {
/* 2296 */       if (this.connectionPool == null) {
/* 2297 */         this.singleConnectionLock.unlock();
/*      */       }
/* 2299 */       return;
/*      */     }
/*      */     
/*      */ 
/* 2303 */     if (this.tls != null) {
/*      */       try {
/* 2305 */         this.tls.close();
/*      */       } catch (IOException e) {
/* 2307 */         this.containerLog.error(sm.getString("jndiRealm.tlsClose"), e);
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/* 2312 */       if (this.containerLog.isDebugEnabled()) {
/* 2313 */         this.containerLog.debug("Closing directory context");
/*      */       }
/* 2315 */       connection.context.close();
/*      */     } catch (NamingException e) {
/* 2317 */       this.containerLog.error(sm.getString("jndiRealm.close"), e);
/*      */     }
/* 2319 */     connection.context = null;
/*      */     
/* 2321 */     if (this.connectionPool == null) {
/* 2322 */       this.singleConnectionLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void closePooledConnections()
/*      */   {
/* 2331 */     if (this.connectionPool != null)
/*      */     {
/* 2333 */       synchronized (this.connectionPool) {
/* 2334 */         JNDIConnection connection = null;
/* 2335 */         while ((connection = (JNDIConnection)this.connectionPool.pop()) != null) {
/* 2336 */           close(connection);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getPassword(String username)
/*      */   {
/* 2350 */     String userPassword = getUserPassword();
/* 2351 */     if ((userPassword == null) || (userPassword.isEmpty())) {
/* 2352 */       return null;
/*      */     }
/*      */     
/* 2355 */     JNDIConnection connection = null;
/* 2356 */     User user = null;
/*      */     try
/*      */     {
/* 2359 */       connection = get();
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 2364 */         user = getUser(connection, username, null);
/*      */       }
/*      */       catch (NullPointerException|NamingException e) {
/* 2367 */         this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
/*      */         
/*      */ 
/* 2370 */         close(connection);
/* 2371 */         closePooledConnections();
/*      */         
/*      */ 
/* 2374 */         connection = get();
/*      */         
/*      */ 
/* 2377 */         user = getUser(connection, username, null);
/*      */       }
/*      */       
/*      */ 
/* 2381 */       release(connection);
/*      */       
/* 2383 */       if (user == null)
/*      */       {
/* 2385 */         return null;
/*      */       }
/*      */       
/* 2388 */       return user.getPassword();
/*      */     }
/*      */     catch (NamingException e)
/*      */     {
/* 2392 */       this.containerLog.error(sm.getString("jndiRealm.exception"), e); }
/* 2393 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Principal getPrincipal(String username)
/*      */   {
/* 2405 */     return getPrincipal(username, null);
/*      */   }
/*      */   
/*      */ 
/*      */   protected Principal getPrincipal(GSSName gssName, GSSCredential gssCredential)
/*      */   {
/* 2411 */     String name = gssName.toString();
/*      */     
/* 2413 */     if (isStripRealmForGss()) {
/* 2414 */       int i = name.indexOf('@');
/* 2415 */       if (i > 0)
/*      */       {
/* 2417 */         name = name.substring(0, i);
/*      */       }
/*      */     }
/*      */     
/* 2421 */     return getPrincipal(name, gssCredential);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Principal getPrincipal(String username, GSSCredential gssCredential)
/*      */   {
/* 2428 */     JNDIConnection connection = null;
/* 2429 */     Principal principal = null;
/*      */     
/*      */     try
/*      */     {
/* 2433 */       connection = get();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 2440 */         principal = getPrincipal(connection, username, gssCredential);
/*      */       }
/*      */       catch (CommunicationException|ServiceUnavailableException e)
/*      */       {
/* 2444 */         this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
/*      */         
/*      */ 
/* 2447 */         close(connection);
/* 2448 */         closePooledConnections();
/*      */         
/*      */ 
/* 2451 */         connection = get();
/*      */         
/*      */ 
/* 2454 */         principal = getPrincipal(connection, username, gssCredential);
/*      */       }
/*      */       
/*      */ 
/* 2458 */       release(connection);
/*      */       
/*      */ 
/* 2461 */       return principal;
/*      */     }
/*      */     catch (NamingException e)
/*      */     {
/* 2465 */       this.containerLog.error(sm.getString("jndiRealm.exception"), e);
/*      */       
/*      */ 
/* 2468 */       close(connection);
/* 2469 */       closePooledConnections();
/*      */     }
/*      */     
/* 2472 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Principal getPrincipal(JNDIConnection connection, String username, GSSCredential gssCredential)
/*      */     throws NamingException
/*      */   {
/* 2488 */     User user = null;
/* 2489 */     List<String> roles = null;
/* 2490 */     Hashtable<?, ?> preservedEnvironment = null;
/* 2491 */     DirContext context = connection.context;
/*      */     try
/*      */     {
/* 2494 */       if ((gssCredential != null) && (isUseDelegatedCredential()))
/*      */       {
/* 2496 */         preservedEnvironment = context.getEnvironment();
/*      */         
/* 2498 */         context.addToEnvironment("java.naming.security.authentication", "GSSAPI");
/* 2499 */         context.addToEnvironment("javax.security.sasl.server.authentication", "true");
/* 2500 */         context.addToEnvironment("javax.security.sasl.qop", this.spnegoDelegationQop);
/*      */       }
/*      */       
/*      */ 
/* 2504 */       user = getUser(connection, username);
/* 2505 */       if (user != null) {
/* 2506 */         roles = getRoles(connection, user);
/*      */       }
/*      */     } finally {
/* 2509 */       if ((gssCredential != null) && (isUseDelegatedCredential())) {
/* 2510 */         restoreEnvironmentParameter(context, "java.naming.security.authentication", preservedEnvironment);
/* 2511 */         restoreEnvironmentParameter(context, "javax.security.sasl.server.authentication", preservedEnvironment);
/* 2512 */         restoreEnvironmentParameter(context, "javax.security.sasl.qop", preservedEnvironment);
/*      */       }
/*      */     }
/*      */     
/* 2516 */     if (user != null) {
/* 2517 */       return new GenericPrincipal(user.getUserName(), user.getPassword(), roles, null, null, gssCredential);
/*      */     }
/*      */     
/* 2520 */     return null;
/*      */   }
/*      */   
/*      */   private void restoreEnvironmentParameter(DirContext context, String parameterName, Hashtable<?, ?> preservedEnvironment)
/*      */   {
/*      */     try
/*      */     {
/* 2527 */       context.removeFromEnvironment(parameterName);
/* 2528 */       if ((preservedEnvironment != null) && (preservedEnvironment.containsKey(parameterName))) {
/* 2529 */         context.addToEnvironment(parameterName, preservedEnvironment
/* 2530 */           .get(parameterName));
/*      */       }
/*      */     }
/*      */     catch (NamingException localNamingException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JNDIConnection get()
/*      */     throws NamingException
/*      */   {
/* 2545 */     JNDIConnection connection = null;
/*      */     
/* 2547 */     if (this.connectionPool != null) {
/* 2548 */       connection = (JNDIConnection)this.connectionPool.pop();
/* 2549 */       if (connection == null) {
/* 2550 */         connection = create();
/*      */       }
/*      */     } else {
/* 2553 */       this.singleConnectionLock.lock();
/* 2554 */       connection = this.singleConnection;
/*      */     }
/* 2556 */     if (connection.context == null) {
/* 2557 */       open(connection);
/*      */     }
/* 2559 */     return connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void release(JNDIConnection connection)
/*      */   {
/* 2569 */     if (this.connectionPool != null) {
/* 2570 */       if (!this.connectionPool.push(connection))
/*      */       {
/* 2572 */         close(connection);
/*      */       }
/*      */     } else {
/* 2575 */       this.singleConnectionLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JNDIConnection create()
/*      */   {
/* 2586 */     JNDIConnection connection = new JNDIConnection();
/* 2587 */     if (this.userSearch != null) {
/* 2588 */       connection.userSearchFormat = new MessageFormat(this.userSearch);
/*      */     }
/* 2590 */     if (this.userPattern != null) {
/* 2591 */       int len = this.userPatternArray.length;
/* 2592 */       connection.userPatternFormatArray = new MessageFormat[len];
/* 2593 */       for (int i = 0; i < len; i++) {
/* 2594 */         connection.userPatternFormatArray[i] = new MessageFormat(this.userPatternArray[i]);
/*      */       }
/*      */     }
/* 2597 */     if (this.roleBase != null) {
/* 2598 */       connection.roleBaseFormat = new MessageFormat(this.roleBase);
/*      */     }
/* 2600 */     if (this.roleSearch != null) {
/* 2601 */       connection.roleFormat = new MessageFormat(this.roleSearch);
/*      */     }
/* 2603 */     return connection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void open(JNDIConnection connection)
/*      */     throws NamingException
/*      */   {
/*      */     try
/*      */     {
/* 2615 */       connection.context = createDirContext(getDirectoryContextEnvironment());
/*      */     } catch (Exception e) {
/* 2617 */       if ((this.alternateURL == null) || (this.alternateURL.length() == 0))
/*      */       {
/* 2619 */         throw e;
/*      */       }
/* 2621 */       this.connectionAttempt = 1;
/*      */       
/* 2623 */       this.containerLog.info(sm.getString("jndiRealm.exception.retry"), e);
/*      */       
/* 2625 */       connection.context = createDirContext(getDirectoryContextEnvironment());
/*      */     }
/*      */     finally
/*      */     {
/* 2629 */       this.connectionAttempt = 0;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isAvailable()
/*      */   {
/* 2637 */     return (this.connectionPool != null) || (this.singleConnection.context != null);
/*      */   }
/*      */   
/*      */   private DirContext createDirContext(Hashtable<String, String> env) throws NamingException
/*      */   {
/* 2642 */     if (this.useStartTls) {
/* 2643 */       return createTlsDirContext(env);
/*      */     }
/* 2645 */     return new InitialDirContext(env);
/*      */   }
/*      */   
/*      */ 
/*      */   private SSLSocketFactory getSSLSocketFactory()
/*      */   {
/* 2651 */     if (this.sslSocketFactory != null)
/* 2652 */       return this.sslSocketFactory;
/*      */     SSLSocketFactory result;
/*      */     SSLSocketFactory result;
/* 2655 */     if ((this.sslSocketFactoryClassName != null) && (!this.sslSocketFactoryClassName.trim().equals(""))) {
/* 2656 */       result = createSSLSocketFactoryFromClassName(this.sslSocketFactoryClassName);
/*      */     } else {
/* 2658 */       result = createSSLContextFactoryFromProtocol(this.sslProtocol);
/*      */     }
/* 2660 */     this.sslSocketFactory = result;
/* 2661 */     return result;
/*      */   }
/*      */   
/*      */   private SSLSocketFactory createSSLSocketFactoryFromClassName(String className)
/*      */   {
/*      */     try {
/* 2667 */       Object o = constructInstance(className);
/* 2668 */       if ((o instanceof SSLSocketFactory)) {
/* 2669 */         return this.sslSocketFactory;
/*      */       }
/* 2671 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidSslSocketFactory", new Object[] { className }));
/*      */ 
/*      */     }
/*      */     catch (ReflectiveOperationException|SecurityException e)
/*      */     {
/* 2676 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidSslSocketFactory", new Object[] { className }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private SSLSocketFactory createSSLContextFactoryFromProtocol(String protocol)
/*      */   {
/*      */     try
/*      */     {
/*      */       SSLContext sslContext;
/* 2686 */       if (protocol != null) {
/* 2687 */         SSLContext sslContext = SSLContext.getInstance(protocol);
/* 2688 */         sslContext.init(null, null, null);
/*      */       } else {
/* 2690 */         sslContext = SSLContext.getDefault();
/*      */       }
/* 2692 */       return sslContext.getSocketFactory();
/*      */     } catch (NoSuchAlgorithmException|KeyManagementException e) {
/* 2694 */       List<String> allowedProtocols = Arrays.asList(getSupportedSslProtocols());
/* 2695 */       throw new IllegalArgumentException(sm.getString("jndiRealm.invalidSslProtocol", new Object[] { protocol, allowedProtocols }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private DirContext createTlsDirContext(Hashtable<String, String> env)
/*      */     throws NamingException
/*      */   {
/* 2712 */     Map<String, Object> savedEnv = new HashMap();
/* 2713 */     for (String key : Arrays.asList(new String[] { "java.naming.security.authentication", "java.naming.security.credentials", "java.naming.security.principal", "java.naming.security.protocol" }))
/*      */     {
/* 2715 */       Object entry = env.remove(key);
/* 2716 */       if (entry != null) {
/* 2717 */         savedEnv.put(key, entry);
/*      */       }
/*      */     }
/* 2720 */     Object result = null;
/*      */     try {
/* 2722 */       result = new InitialLdapContext(env, null);
/* 2723 */       this.tls = ((StartTlsResponse)((LdapContext)result).extendedOperation(new StartTlsRequest()));
/* 2724 */       if (getHostnameVerifier() != null) {
/* 2725 */         this.tls.setHostnameVerifier(getHostnameVerifier());
/*      */       }
/* 2727 */       if (getCipherSuitesArray() != null) {
/* 2728 */         this.tls.setEnabledCipherSuites(getCipherSuitesArray());
/*      */       }
/*      */       try {
/* 2731 */         SSLSession negotiate = this.tls.negotiate(getSSLSocketFactory());
/* 2732 */         this.containerLog.debug(sm.getString("jndiRealm.negotiatedTls", new Object[] { negotiate.getProtocol() }));
/*      */       } catch (IOException e) {
/* 2734 */         throw new NamingException(e.getMessage());
/*      */       }
/*      */     } finally { Map.Entry<String, Object> savedEntry;
/* 2737 */       if (result != null) {
/* 2738 */         for (Map.Entry<String, Object> savedEntry : savedEnv.entrySet()) {
/* 2739 */           ((LdapContext)result).addToEnvironment((String)savedEntry.getKey(), savedEntry.getValue());
/*      */         }
/*      */       }
/*      */     }
/* 2743 */     return (DirContext)result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Hashtable<String, String> getDirectoryContextEnvironment()
/*      */   {
/* 2754 */     Hashtable<String, String> env = new Hashtable();
/*      */     
/*      */ 
/* 2757 */     if ((this.containerLog.isDebugEnabled()) && (this.connectionAttempt == 0)) {
/* 2758 */       this.containerLog.debug("Connecting to URL " + this.connectionURL);
/* 2759 */     } else if ((this.containerLog.isDebugEnabled()) && (this.connectionAttempt > 0)) {
/* 2760 */       this.containerLog.debug("Connecting to URL " + this.alternateURL);
/*      */     }
/* 2762 */     env.put("java.naming.factory.initial", this.contextFactory);
/* 2763 */     if (this.connectionName != null) {
/* 2764 */       env.put("java.naming.security.principal", this.connectionName);
/*      */     }
/* 2766 */     if (this.connectionPassword != null) {
/* 2767 */       env.put("java.naming.security.credentials", this.connectionPassword);
/*      */     }
/* 2769 */     if ((this.connectionURL != null) && (this.connectionAttempt == 0)) {
/* 2770 */       env.put("java.naming.provider.url", this.connectionURL);
/* 2771 */     } else if ((this.alternateURL != null) && (this.connectionAttempt > 0)) {
/* 2772 */       env.put("java.naming.provider.url", this.alternateURL);
/*      */     }
/* 2774 */     if (this.authentication != null) {
/* 2775 */       env.put("java.naming.security.authentication", this.authentication);
/*      */     }
/* 2777 */     if (this.protocol != null) {
/* 2778 */       env.put("java.naming.security.protocol", this.protocol);
/*      */     }
/* 2780 */     if (this.referrals != null) {
/* 2781 */       env.put("java.naming.referral", this.referrals);
/*      */     }
/* 2783 */     if (this.derefAliases != null) {
/* 2784 */       env.put("java.naming.ldap.derefAliases", this.derefAliases);
/*      */     }
/* 2786 */     if (this.connectionTimeout != null) {
/* 2787 */       env.put("com.sun.jndi.ldap.connect.timeout", this.connectionTimeout);
/*      */     }
/* 2789 */     if (this.readTimeout != null) {
/* 2790 */       env.put("com.sun.jndi.ldap.read.timeout", this.readTimeout);
/*      */     }
/*      */     
/* 2793 */     return env;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void startInternal()
/*      */     throws LifecycleException
/*      */   {
/* 2810 */     if (this.connectionPoolSize != 1) {
/* 2811 */       this.connectionPool = new SynchronizedStack(128, this.connectionPoolSize);
/*      */     }
/*      */     
/*      */ 
/* 2815 */     ClassLoader ocl = null;
/* 2816 */     JNDIConnection connection = null;
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 2822 */       if (!isUseContextClassLoader()) {
/* 2823 */         ocl = Thread.currentThread().getContextClassLoader();
/* 2824 */         Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
/*      */       }
/* 2826 */       connection = get();
/*      */ 
/*      */     }
/*      */     catch (NamingException e)
/*      */     {
/*      */ 
/* 2832 */       this.containerLog.error(sm.getString("jndiRealm.open"), e);
/*      */     } finally {
/* 2834 */       release(connection);
/* 2835 */       if (!isUseContextClassLoader()) {
/* 2836 */         Thread.currentThread().setContextClassLoader(ocl);
/*      */       }
/*      */     }
/*      */     
/* 2840 */     super.startInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 2854 */     super.stopInternal();
/*      */     
/* 2856 */     if (this.connectionPool == null) {
/* 2857 */       this.singleConnectionLock.lock();
/* 2858 */       close(this.singleConnection);
/*      */     } else {
/* 2860 */       closePooledConnections();
/* 2861 */       this.connectionPool = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String[] parseUserPatternString(String userPatternString)
/*      */   {
/* 2878 */     if (userPatternString != null) {
/* 2879 */       List<String> pathList = new ArrayList();
/* 2880 */       int startParenLoc = userPatternString.indexOf('(');
/* 2881 */       if (startParenLoc == -1)
/*      */       {
/* 2883 */         return new String[] { userPatternString };
/*      */       }
/* 2885 */       int startingPoint = 0;
/* 2886 */       while (startParenLoc > -1) {
/* 2887 */         int endParenLoc = 0;
/*      */         
/*      */ 
/*      */ 
/* 2891 */         while ((userPatternString.charAt(startParenLoc + 1) == '|') || ((startParenLoc != 0) && 
/* 2892 */           (userPatternString.charAt(startParenLoc - 1) == '\\'))) {
/* 2893 */           startParenLoc = userPatternString.indexOf('(', startParenLoc + 1);
/*      */         }
/* 2895 */         endParenLoc = userPatternString.indexOf(')', startParenLoc + 1);
/*      */         
/* 2897 */         while (userPatternString.charAt(endParenLoc - 1) == '\\') {
/* 2898 */           endParenLoc = userPatternString.indexOf(')', endParenLoc + 1);
/*      */         }
/* 2900 */         String nextPathPart = userPatternString.substring(startParenLoc + 1, endParenLoc);
/* 2901 */         pathList.add(nextPathPart);
/* 2902 */         startingPoint = endParenLoc + 1;
/* 2903 */         startParenLoc = userPatternString.indexOf('(', startingPoint);
/*      */       }
/* 2905 */       return (String[])pathList.toArray(new String[0]);
/*      */     }
/* 2907 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected String doRFC2254Encoding(String inString)
/*      */   {
/* 2931 */     return doFilterEscaping(inString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String doFilterEscaping(String inString)
/*      */   {
/* 2952 */     if (inString == null) {
/* 2953 */       return null;
/*      */     }
/* 2955 */     StringBuilder buf = new StringBuilder(inString.length());
/* 2956 */     for (int i = 0; i < inString.length(); i++) {
/* 2957 */       char c = inString.charAt(i);
/* 2958 */       switch (c) {
/*      */       case '\\': 
/* 2960 */         buf.append("\\5c");
/* 2961 */         break;
/*      */       case '*': 
/* 2963 */         buf.append("\\2a");
/* 2964 */         break;
/*      */       case '(': 
/* 2966 */         buf.append("\\28");
/* 2967 */         break;
/*      */       case ')': 
/* 2969 */         buf.append("\\29");
/* 2970 */         break;
/*      */       case '\000': 
/* 2972 */         buf.append("\\00");
/* 2973 */         break;
/*      */       default: 
/* 2975 */         buf.append(c);
/*      */       }
/*      */       
/*      */     }
/* 2979 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getDistinguishedName(DirContext context, String base, SearchResult result)
/*      */     throws NamingException
/*      */   {
/* 2996 */     String resultName = result.getName();
/*      */     
/* 2998 */     if (result.isRelative()) {
/* 2999 */       if (this.containerLog.isTraceEnabled()) {
/* 3000 */         this.containerLog.trace("  search returned relative name: " + resultName);
/*      */       }
/* 3002 */       NameParser parser = context.getNameParser("");
/* 3003 */       Name contextName = parser.parse(context.getNameInNamespace());
/* 3004 */       Name baseName = parser.parse(base);
/*      */       
/*      */ 
/* 3007 */       Name entryName = parser.parse(new CompositeName(resultName).get(0));
/*      */       
/* 3009 */       Name name = contextName.addAll(baseName);
/* 3010 */       name = name.addAll(entryName);
/*      */     } else {
/* 3012 */       if (this.containerLog.isTraceEnabled()) {
/* 3013 */         this.containerLog.trace("  search returned absolute name: " + resultName);
/*      */       }
/*      */       try
/*      */       {
/* 3017 */         NameParser parser = context.getNameParser("");
/* 3018 */         URI userNameUri = new URI(resultName);
/* 3019 */         String pathComponent = userNameUri.getPath();
/*      */         
/* 3021 */         if (pathComponent.length() < 1) {
/* 3022 */           throw new InvalidNameException("Search returned unparseable absolute name: " + resultName);
/*      */         }
/* 3024 */         name = parser.parse(pathComponent.substring(1));
/*      */       } catch (URISyntaxException e) { Name name;
/* 3026 */         throw new InvalidNameException("Search returned unparseable absolute name: " + resultName);
/*      */       }
/*      */     }
/*      */     Name name;
/* 3030 */     if (getForceDnHexEscape())
/*      */     {
/* 3032 */       return convertToHexEscape(name.toString());
/*      */     }
/* 3034 */     return name.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String doAttributeValueEscaping(String input)
/*      */   {
/* 3047 */     if (input == null) {
/* 3048 */       return null;
/*      */     }
/* 3050 */     int len = input.length();
/* 3051 */     StringBuilder result = new StringBuilder();
/*      */     
/* 3053 */     for (int i = 0; i < len; i++) {
/* 3054 */       char c = input.charAt(i);
/* 3055 */       switch (c) {
/*      */       case ' ': 
/* 3057 */         if ((i == 0) || (i == len - 1)) {
/* 3058 */           result.append("\\20");
/*      */         } else {
/* 3060 */           result.append(c);
/*      */         }
/* 3062 */         break;
/*      */       
/*      */       case '#': 
/* 3065 */         if (i == 0) {
/* 3066 */           result.append("\\23");
/*      */         } else {
/* 3068 */           result.append(c);
/*      */         }
/* 3070 */         break;
/*      */       
/*      */       case '"': 
/* 3073 */         result.append("\\22");
/* 3074 */         break;
/*      */       
/*      */       case '+': 
/* 3077 */         result.append("\\2B");
/* 3078 */         break;
/*      */       
/*      */       case ',': 
/* 3081 */         result.append("\\2C");
/* 3082 */         break;
/*      */       
/*      */       case ';': 
/* 3085 */         result.append("\\3B");
/* 3086 */         break;
/*      */       
/*      */       case '<': 
/* 3089 */         result.append("\\3C");
/* 3090 */         break;
/*      */       
/*      */       case '>': 
/* 3093 */         result.append("\\3E");
/* 3094 */         break;
/*      */       
/*      */       case '\\': 
/* 3097 */         result.append("\\5C");
/* 3098 */         break;
/*      */       
/*      */       case '\000': 
/* 3101 */         result.append("\\00");
/* 3102 */         break;
/*      */       
/*      */       default: 
/* 3105 */         result.append(c);
/*      */       }
/*      */       
/*      */     }
/*      */     
/* 3110 */     return result.toString();
/*      */   }
/*      */   
/*      */   protected static String convertToHexEscape(String input)
/*      */   {
/* 3115 */     if (input.indexOf('\\') == -1)
/*      */     {
/* 3117 */       return input;
/*      */     }
/*      */     
/*      */ 
/* 3121 */     StringBuilder result = new StringBuilder(input.length() + 6);
/* 3122 */     boolean previousSlash = false;
/* 3123 */     for (int i = 0; i < input.length(); i++) {
/* 3124 */       char c = input.charAt(i);
/*      */       
/* 3126 */       if (previousSlash) {
/* 3127 */         switch (c) {
/*      */         case ' ': 
/* 3129 */           result.append("\\20");
/* 3130 */           break;
/*      */         
/*      */         case '"': 
/* 3133 */           result.append("\\22");
/* 3134 */           break;
/*      */         
/*      */         case '#': 
/* 3137 */           result.append("\\23");
/* 3138 */           break;
/*      */         
/*      */         case '+': 
/* 3141 */           result.append("\\2B");
/* 3142 */           break;
/*      */         
/*      */         case ',': 
/* 3145 */           result.append("\\2C");
/* 3146 */           break;
/*      */         
/*      */         case ';': 
/* 3149 */           result.append("\\3B");
/* 3150 */           break;
/*      */         
/*      */         case '<': 
/* 3153 */           result.append("\\3C");
/* 3154 */           break;
/*      */         
/*      */         case '=': 
/* 3157 */           result.append("\\3D");
/* 3158 */           break;
/*      */         
/*      */         case '>': 
/* 3161 */           result.append("\\3E");
/* 3162 */           break;
/*      */         
/*      */         case '\\': 
/* 3165 */           result.append("\\5C");
/* 3166 */           break;
/*      */         
/*      */         default: 
/* 3169 */           result.append('\\');
/* 3170 */           result.append(c);
/*      */         }
/* 3172 */         previousSlash = false;
/*      */       }
/* 3174 */       else if (c == '\\') {
/* 3175 */         previousSlash = true;
/*      */       } else {
/* 3177 */         result.append(c);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3182 */     if (previousSlash) {
/* 3183 */       result.append('\\');
/*      */     }
/*      */     
/* 3186 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */   protected static class User
/*      */   {
/*      */     private final String username;
/*      */     
/*      */     private final String dn;
/*      */     
/*      */     private final String password;
/*      */     
/*      */     private final List<String> roles;
/*      */     
/*      */     private final String userRoleId;
/*      */     
/*      */     public User(String username, String dn, String password, List<String> roles, String userRoleId)
/*      */     {
/* 3204 */       this.username = username;
/* 3205 */       this.dn = dn;
/* 3206 */       this.password = password;
/* 3207 */       if (roles == null) {
/* 3208 */         this.roles = Collections.emptyList();
/*      */       } else {
/* 3210 */         this.roles = Collections.unmodifiableList(roles);
/*      */       }
/* 3212 */       this.userRoleId = userRoleId;
/*      */     }
/*      */     
/*      */     public String getUserName() {
/* 3216 */       return this.username;
/*      */     }
/*      */     
/*      */     public String getDN() {
/* 3220 */       return this.dn;
/*      */     }
/*      */     
/*      */     public String getPassword() {
/* 3224 */       return this.password;
/*      */     }
/*      */     
/*      */     public List<String> getRoles() {
/* 3228 */       return this.roles;
/*      */     }
/*      */     
/*      */     public String getUserRoleId() {
/* 3232 */       return this.userRoleId;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static class JNDIConnection
/*      */   {
/* 3247 */     public MessageFormat userSearchFormat = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3253 */     public MessageFormat[] userPatternFormatArray = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3259 */     public MessageFormat roleBaseFormat = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3265 */     public MessageFormat roleFormat = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3270 */     public DirContext context = null;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\JNDIRealm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */