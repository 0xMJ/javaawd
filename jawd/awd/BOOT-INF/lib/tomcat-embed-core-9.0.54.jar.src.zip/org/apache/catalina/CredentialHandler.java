package org.apache.catalina;

public abstract interface CredentialHandler
{
  public abstract boolean matches(String paramString1, String paramString2);
  
  public abstract String mutate(String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\CredentialHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */