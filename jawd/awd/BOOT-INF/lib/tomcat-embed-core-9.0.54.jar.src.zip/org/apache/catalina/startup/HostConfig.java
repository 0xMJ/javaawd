/*      */ package org.apache.catalina.startup;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.nio.file.CopyOption;
/*      */ import java.nio.file.Files;
/*      */ import java.nio.file.Path;
/*      */ import java.security.CodeSource;
/*      */ import java.security.Permission;
/*      */ import java.security.PermissionCollection;
/*      */ import java.security.Policy;
/*      */ import java.security.cert.Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.SortedSet;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.jar.JarEntry;
/*      */ import java.util.jar.JarFile;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.management.ObjectName;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.DistributedManager;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleEvent;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.core.StandardContext;
/*      */ import org.apache.catalina.core.StandardHost;
/*      */ import org.apache.catalina.security.DeployXmlPermission;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.IOTools;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.UriUtil;
/*      */ import org.apache.tomcat.util.digester.Digester;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HostConfig
/*      */   implements LifecycleListener
/*      */ {
/*   86 */   private static final Log log = LogFactory.getLog(HostConfig.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   91 */   protected static final StringManager sm = StringManager.getManager(HostConfig.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final long FILE_MODIFICATION_RESOLUTION_MS = 1000L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  104 */   protected String contextClass = "org.apache.catalina.core.StandardContext";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  110 */   protected Host host = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  116 */   protected ObjectName oname = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  123 */   protected boolean deployXML = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  131 */   protected boolean copyXML = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  138 */   protected boolean unpackWARs = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  144 */   protected final Map<String, DeployedApplication> deployed = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  154 */   protected final ArrayList<String> serviced = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  162 */   private Set<String> servicedSet = Collections.newSetFromMap(new ConcurrentHashMap());
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  167 */   protected Digester digester = createDigester(this.contextClass);
/*  168 */   private final Object digesterLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  174 */   protected final Set<String> invalidWars = new HashSet();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getContextClass()
/*      */   {
/*  183 */     return this.contextClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContextClass(String contextClass)
/*      */   {
/*  194 */     String oldContextClass = this.contextClass;
/*  195 */     this.contextClass = contextClass;
/*      */     
/*  197 */     if (!oldContextClass.equals(contextClass)) {
/*  198 */       synchronized (this.digesterLock) {
/*  199 */         this.digester = createDigester(getContextClass());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDeployXML()
/*      */   {
/*  209 */     return this.deployXML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDeployXML(boolean deployXML)
/*      */   {
/*  219 */     this.deployXML = deployXML;
/*      */   }
/*      */   
/*      */   private boolean isDeployThisXML(File docBase, ContextName cn)
/*      */   {
/*  224 */     boolean deployThisXML = isDeployXML();
/*  225 */     if ((Globals.IS_SECURITY_ENABLED) && (!deployThisXML))
/*      */     {
/*      */ 
/*  228 */       Policy currentPolicy = Policy.getPolicy();
/*  229 */       if (currentPolicy != null) {
/*      */         try
/*      */         {
/*  232 */           URL contextRootUrl = docBase.toURI().toURL();
/*  233 */           CodeSource cs = new CodeSource(contextRootUrl, (Certificate[])null);
/*  234 */           PermissionCollection pc = currentPolicy.getPermissions(cs);
/*  235 */           Permission p = new DeployXmlPermission(cn.getBaseName());
/*  236 */           if (pc.implies(p)) {
/*  237 */             deployThisXML = true;
/*      */           }
/*      */         }
/*      */         catch (MalformedURLException e) {
/*  241 */           log.warn(sm.getString("hostConfig.docBaseUrlInvalid"), e);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  246 */     return deployThisXML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCopyXML()
/*      */   {
/*  254 */     return this.copyXML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCopyXML(boolean copyXML)
/*      */   {
/*  265 */     this.copyXML = copyXML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUnpackWARs()
/*      */   {
/*  274 */     return this.unpackWARs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUnpackWARs(boolean unpackWARs)
/*      */   {
/*  284 */     this.unpackWARs = unpackWARs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void lifecycleEvent(LifecycleEvent event)
/*      */   {
/*      */     try
/*      */     {
/*  301 */       this.host = ((Host)event.getLifecycle());
/*  302 */       if ((this.host instanceof StandardHost)) {
/*  303 */         setCopyXML(((StandardHost)this.host).isCopyXML());
/*  304 */         setDeployXML(((StandardHost)this.host).isDeployXML());
/*  305 */         setUnpackWARs(((StandardHost)this.host).isUnpackWARs());
/*  306 */         setContextClass(((StandardHost)this.host).getContextClass());
/*      */       }
/*      */     } catch (ClassCastException e) {
/*  309 */       log.error(sm.getString("hostConfig.cce", new Object[] { event.getLifecycle() }), e);
/*  310 */       return;
/*      */     }
/*      */     
/*      */ 
/*  314 */     if (event.getType().equals("periodic")) {
/*  315 */       check();
/*  316 */     } else if (event.getType().equals("before_start")) {
/*  317 */       beforeStart();
/*  318 */     } else if (event.getType().equals("start")) {
/*  319 */       start();
/*  320 */     } else if (event.getType().equals("stop")) {
/*  321 */       stop();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean tryAddServiced(String name)
/*      */   {
/*  335 */     if (this.servicedSet.add(name)) {
/*  336 */       synchronized (this) {
/*  337 */         this.serviced.add(name);
/*      */       }
/*  339 */       return true;
/*      */     }
/*  341 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void addServiced(String name)
/*      */   {
/*  357 */     this.servicedSet.add(name);
/*  358 */     synchronized (this) {
/*  359 */       this.serviced.add(name);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public boolean isServiced(String name)
/*      */   {
/*  376 */     return this.servicedSet.contains(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeServiced(String name)
/*      */   {
/*  385 */     this.servicedSet.remove(name);
/*  386 */     synchronized (this) {
/*  387 */       this.serviced.remove(name);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getDeploymentTime(String name)
/*      */   {
/*  399 */     DeployedApplication app = (DeployedApplication)this.deployed.get(name);
/*  400 */     if (app == null) {
/*  401 */       return 0L;
/*      */     }
/*      */     
/*  404 */     return app.timestamp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDeployed(String name)
/*      */   {
/*  417 */     return this.deployed.containsKey(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static Digester createDigester(String contextClassName)
/*      */   {
/*  431 */     Digester digester = new Digester();
/*  432 */     digester.setValidating(false);
/*      */     
/*  434 */     digester.addObjectCreate("Context", contextClassName, "className");
/*      */     
/*      */ 
/*  437 */     digester.addSetProperties("Context");
/*  438 */     return digester;
/*      */   }
/*      */   
/*      */   protected File returnCanonicalPath(String path) {
/*  442 */     File file = new File(path);
/*  443 */     if (!file.isAbsolute()) {
/*  444 */       file = new File(this.host.getCatalinaBase(), path);
/*      */     }
/*      */     try {
/*  447 */       return file.getCanonicalFile();
/*      */     } catch (IOException e) {}
/*  449 */     return file;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getConfigBaseName()
/*      */   {
/*  460 */     return this.host.getConfigBaseFile().getAbsolutePath();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployApps()
/*      */   {
/*  469 */     File appBase = this.host.getAppBaseFile();
/*  470 */     File configBase = this.host.getConfigBaseFile();
/*  471 */     String[] filteredAppPaths = filterAppPaths(appBase.list());
/*      */     
/*  473 */     deployDescriptors(configBase, configBase.list());
/*      */     
/*  475 */     deployWARs(appBase, filteredAppPaths);
/*      */     
/*  477 */     deployDirectories(appBase, filteredAppPaths);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String[] filterAppPaths(String[] unfilteredAppPaths)
/*      */   {
/*  490 */     Pattern filter = this.host.getDeployIgnorePattern();
/*  491 */     if ((filter == null) || (unfilteredAppPaths == null)) {
/*  492 */       return unfilteredAppPaths;
/*      */     }
/*      */     
/*  495 */     List<String> filteredList = new ArrayList();
/*  496 */     Matcher matcher = null;
/*  497 */     for (String appPath : unfilteredAppPaths) {
/*  498 */       if (matcher == null) {
/*  499 */         matcher = filter.matcher(appPath);
/*      */       } else {
/*  501 */         matcher.reset(appPath);
/*      */       }
/*  503 */       if (matcher.matches()) {
/*  504 */         if (log.isDebugEnabled()) {
/*  505 */           log.debug(sm.getString("hostConfig.ignorePath", new Object[] { appPath }));
/*      */         }
/*      */       } else {
/*  508 */         filteredList.add(appPath);
/*      */       }
/*      */     }
/*  511 */     return (String[])filteredList.toArray(new String[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployApps(String name)
/*      */   {
/*  526 */     File appBase = this.host.getAppBaseFile();
/*  527 */     File configBase = this.host.getConfigBaseFile();
/*  528 */     ContextName cn = new ContextName(name, false);
/*  529 */     String baseName = cn.getBaseName();
/*      */     
/*  531 */     if (deploymentExists(cn.getName())) {
/*  532 */       return;
/*      */     }
/*      */     
/*      */ 
/*  536 */     File xml = new File(configBase, baseName + ".xml");
/*  537 */     if (xml.exists()) {
/*  538 */       deployDescriptor(cn, xml);
/*  539 */       return;
/*      */     }
/*      */     
/*  542 */     File war = new File(appBase, baseName + ".war");
/*  543 */     if (war.exists()) {
/*  544 */       deployWAR(cn, war);
/*  545 */       return;
/*      */     }
/*      */     
/*  548 */     File dir = new File(appBase, baseName);
/*  549 */     if (dir.exists()) {
/*  550 */       deployDirectory(cn, dir);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployDescriptors(File configBase, String[] files)
/*      */   {
/*  562 */     if (files == null) {
/*  563 */       return;
/*      */     }
/*      */     
/*  566 */     ExecutorService es = this.host.getStartStopExecutor();
/*  567 */     List<Future<?>> results = new ArrayList();
/*      */     
/*  569 */     for (String file : files) {
/*  570 */       File contextXml = new File(configBase, file);
/*      */       
/*  572 */       if (file.toLowerCase(Locale.ENGLISH).endsWith(".xml")) {
/*  573 */         ContextName cn = new ContextName(file, true);
/*      */         
/*  575 */         if (tryAddServiced(cn.getName())) {
/*      */           try {
/*  577 */             if (deploymentExists(cn.getName())) {
/*  578 */               removeServiced(cn.getName());
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*  583 */               results.add(es.submit(new DeployDescriptor(this, cn, contextXml))); }
/*      */           } catch (Throwable t) {
/*  585 */             ExceptionUtils.handleThrowable(t);
/*  586 */             removeServiced(cn.getName());
/*  587 */             throw t;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  593 */     for (??? = results.iterator(); ((Iterator)???).hasNext();) { Object result = (Future)((Iterator)???).next();
/*      */       try {
/*  595 */         ((Future)result).get();
/*      */       } catch (Exception e) {
/*  597 */         log.error(sm.getString("hostConfig.deployDescriptor.threaded.error"), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployDescriptor(ContextName cn, File contextXml)
/*      */   {
/*  615 */     DeployedApplication deployedApp = new DeployedApplication(cn.getName(), true);
/*      */     
/*  617 */     long startTime = 0L;
/*      */     
/*  619 */     if (log.isInfoEnabled()) {
/*  620 */       startTime = System.currentTimeMillis();
/*  621 */       log.info(sm.getString("hostConfig.deployDescriptor", new Object[] { contextXml.getAbsolutePath() }));
/*      */     }
/*      */     
/*  624 */     Context context = null;
/*  625 */     boolean isExternalWar = false;
/*  626 */     boolean isExternal = false;
/*  627 */     File expandedDocBase = null;
/*      */     try {
/*  629 */       FileInputStream fis = new FileInputStream(contextXml);Throwable localThrowable4 = null;
/*  630 */       try { synchronized (this.digesterLock) {
/*      */           try {
/*  632 */             context = (Context)this.digester.parse(fis);
/*      */           } catch (Exception e) {
/*  634 */             log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { contextXml.getAbsolutePath() }), e);
/*      */           } finally {
/*  636 */             this.digester.reset();
/*  637 */             if (context == null) {
/*  638 */               context = new FailedContext();
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*  643 */         if (context.getPath() != null) {
/*  644 */           log.warn(sm.getString("hostConfig.deployDescriptor.path", new Object[] { context.getPath(), contextXml
/*  645 */             .getAbsolutePath() }));
/*      */         }
/*      */         
/*  648 */         Class<?> clazz = Class.forName(this.host.getConfigClass());
/*  649 */         LifecycleListener listener = (LifecycleListener)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*  650 */         context.addLifecycleListener(listener);
/*      */         
/*  652 */         context.setConfigFile(contextXml.toURI().toURL());
/*  653 */         context.setName(cn.getName());
/*  654 */         context.setPath(cn.getPath());
/*  655 */         context.setWebappVersion(cn.getVersion());
/*      */         
/*  657 */         if (context.getDocBase() != null) {
/*  658 */           File docBase = new File(context.getDocBase());
/*  659 */           if (!docBase.isAbsolute()) {
/*  660 */             docBase = new File(this.host.getAppBaseFile(), context.getDocBase());
/*      */           }
/*      */           
/*  663 */           if (!docBase.getCanonicalFile().toPath().startsWith(this.host.getAppBaseFile().toPath())) {
/*  664 */             isExternal = true;
/*  665 */             deployedApp.redeployResources.put(contextXml
/*  666 */               .getAbsolutePath(), Long.valueOf(contextXml.lastModified()));
/*  667 */             deployedApp.redeployResources.put(docBase
/*  668 */               .getAbsolutePath(), Long.valueOf(docBase.lastModified()));
/*  669 */             if (docBase.getAbsolutePath().toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/*  670 */               isExternalWar = true;
/*      */             }
/*      */             
/*  673 */             File war = new File(this.host.getAppBaseFile(), cn.getBaseName() + ".war");
/*  674 */             if (war.exists()) {
/*  675 */               log.warn(sm.getString("hostConfig.deployDescriptor.hiddenWar", new Object[] {contextXml
/*  676 */                 .getAbsolutePath(), war.getAbsolutePath() }));
/*      */             }
/*  678 */             File dir = new File(this.host.getAppBaseFile(), cn.getBaseName());
/*  679 */             if (dir.exists()) {
/*  680 */               log.warn(sm.getString("hostConfig.deployDescriptor.hiddenDir", new Object[] {contextXml
/*  681 */                 .getAbsolutePath(), dir.getAbsolutePath() }));
/*      */             }
/*      */           } else {
/*  684 */             log.warn(sm.getString("hostConfig.deployDescriptor.localDocBaseSpecified", new Object[] { docBase }));
/*      */             
/*  686 */             context.setDocBase(null);
/*      */           }
/*      */         }
/*      */         
/*  690 */         this.host.addChild(context);
/*      */       }
/*      */       catch (Throwable localThrowable2)
/*      */       {
/*  629 */         localThrowable4 = localThrowable2;throw localThrowable2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  691 */         if (fis != null) if (localThrowable4 != null) try { fis.close(); } catch (Throwable localThrowable3) { localThrowable4.addSuppressed(localThrowable3); } else fis.close(); } } catch (Throwable t) { boolean unpackWAR;
/*  692 */       File warDocBase; ExceptionUtils.handleThrowable(t);
/*  693 */       log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { contextXml.getAbsolutePath() }), t);
/*      */     }
/*      */     finally {
/*      */       boolean unpackWAR;
/*      */       File warDocBase;
/*  698 */       expandedDocBase = new File(this.host.getAppBaseFile(), cn.getBaseName());
/*  699 */       if ((context.getDocBase() != null) && (!context.getDocBase().toLowerCase(Locale.ENGLISH).endsWith(".war")))
/*      */       {
/*  701 */         expandedDocBase = new File(context.getDocBase());
/*  702 */         if (!expandedDocBase.isAbsolute())
/*      */         {
/*  704 */           expandedDocBase = new File(this.host.getAppBaseFile(), context.getDocBase());
/*      */         }
/*      */       }
/*      */       
/*  708 */       boolean unpackWAR = this.unpackWARs;
/*  709 */       if ((unpackWAR) && ((context instanceof StandardContext))) {
/*  710 */         unpackWAR = ((StandardContext)context).getUnpackWAR();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  715 */       if (isExternalWar) {
/*  716 */         if (unpackWAR) {
/*  717 */           deployedApp.redeployResources.put(expandedDocBase
/*  718 */             .getAbsolutePath(), Long.valueOf(expandedDocBase.lastModified()));
/*  719 */           addWatchedResources(deployedApp, expandedDocBase.getAbsolutePath(), context);
/*      */         } else {
/*  721 */           addWatchedResources(deployedApp, null, context);
/*      */         }
/*      */       }
/*      */       else {
/*  725 */         if (!isExternal) {
/*  726 */           File warDocBase = new File(expandedDocBase.getAbsolutePath() + ".war");
/*  727 */           if (warDocBase.exists()) {
/*  728 */             deployedApp.redeployResources.put(warDocBase
/*  729 */               .getAbsolutePath(), Long.valueOf(warDocBase.lastModified()));
/*      */           }
/*      */           else {
/*  732 */             deployedApp.redeployResources.put(warDocBase.getAbsolutePath(), Long.valueOf(0L));
/*      */           }
/*      */         }
/*  735 */         if (unpackWAR) {
/*  736 */           deployedApp.redeployResources.put(expandedDocBase
/*  737 */             .getAbsolutePath(), Long.valueOf(expandedDocBase.lastModified()));
/*  738 */           addWatchedResources(deployedApp, expandedDocBase.getAbsolutePath(), context);
/*      */         } else {
/*  740 */           addWatchedResources(deployedApp, null, context);
/*      */         }
/*  742 */         if (!isExternal)
/*      */         {
/*      */ 
/*  745 */           deployedApp.redeployResources.put(contextXml
/*  746 */             .getAbsolutePath(), Long.valueOf(contextXml.lastModified()));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  751 */       addGlobalRedeployResources(deployedApp);
/*      */     }
/*      */     
/*  754 */     if (this.host.findChild(context.getName()) != null) {
/*  755 */       this.deployed.put(context.getName(), deployedApp);
/*      */     }
/*      */     
/*  758 */     if (log.isInfoEnabled()) {
/*  759 */       log.info(sm.getString("hostConfig.deployDescriptor.finished", new Object[] {contextXml
/*  760 */         .getAbsolutePath(), Long.valueOf(System.currentTimeMillis() - startTime) }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployWARs(File appBase, String[] files)
/*      */   {
/*  772 */     if (files == null) {
/*  773 */       return;
/*      */     }
/*      */     
/*  776 */     ExecutorService es = this.host.getStartStopExecutor();
/*  777 */     List<Future<?>> results = new ArrayList();
/*      */     
/*  779 */     for (String file : files) {
/*  780 */       if (!file.equalsIgnoreCase("META-INF"))
/*      */       {
/*      */ 
/*  783 */         if (!file.equalsIgnoreCase("WEB-INF"))
/*      */         {
/*      */ 
/*      */ 
/*  787 */           File war = new File(appBase, file);
/*  788 */           if ((file.toLowerCase(Locale.ENGLISH).endsWith(".war")) && (war.isFile()) && (!this.invalidWars.contains(file))) {
/*  789 */             ContextName cn = new ContextName(file, true);
/*  790 */             if (tryAddServiced(cn.getName()))
/*      */               try {
/*  792 */                 if (deploymentExists(cn.getName())) {
/*  793 */                   DeployedApplication app = (DeployedApplication)this.deployed.get(cn.getName());
/*  794 */                   boolean unpackWAR = this.unpackWARs;
/*  795 */                   if ((unpackWAR) && ((this.host.findChild(cn.getName()) instanceof StandardContext))) {
/*  796 */                     unpackWAR = ((StandardContext)this.host.findChild(cn.getName())).getUnpackWAR();
/*      */                   }
/*  798 */                   if ((!unpackWAR) && (app != null))
/*      */                   {
/*      */ 
/*  801 */                     File dir = new File(appBase, cn.getBaseName());
/*  802 */                     if (dir.exists()) {
/*  803 */                       if (!app.loggedDirWarning) {
/*  804 */                         log.warn(sm.getString("hostConfig.deployWar.hiddenDir", new Object[] {dir
/*  805 */                           .getAbsoluteFile(), war.getAbsoluteFile() }));
/*  806 */                         app.loggedDirWarning = true;
/*      */                       }
/*      */                     } else {
/*  809 */                       app.loggedDirWarning = false;
/*      */                     }
/*      */                   }
/*  812 */                   removeServiced(cn.getName());
/*      */ 
/*      */ 
/*      */ 
/*      */                 }
/*  817 */                 else if (!validateContextPath(appBase, cn.getBaseName())) {
/*  818 */                   log.error(sm.getString("hostConfig.illegalWarName", new Object[] { file }));
/*  819 */                   this.invalidWars.add(file);
/*  820 */                   removeServiced(cn.getName());
/*      */ 
/*      */                 }
/*      */                 else
/*      */                 {
/*  825 */                   results.add(es.submit(new DeployWar(this, cn, war)));
/*      */                 }
/*  827 */               } catch (Throwable t) { ExceptionUtils.handleThrowable(t);
/*  828 */                 removeServiced(cn.getName());
/*  829 */                 throw t;
/*      */               }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  835 */     for (??? = results.iterator(); ((Iterator)???).hasNext();) { Object result = (Future)((Iterator)???).next();
/*      */       try {
/*  837 */         ((Future)result).get();
/*      */       } catch (Exception e) {
/*  839 */         log.error(sm.getString("hostConfig.deployWar.threaded.error"), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean validateContextPath(File appBase, String contextPath)
/*      */   {
/*  850 */     String canonicalDocBase = null;
/*      */     try
/*      */     {
/*  853 */       String canonicalAppBase = appBase.getCanonicalPath();
/*  854 */       StringBuilder docBase = new StringBuilder(canonicalAppBase);
/*  855 */       if (canonicalAppBase.endsWith(File.separator)) {
/*  856 */         docBase.append(contextPath.substring(1).replace('/', File.separatorChar));
/*      */       } else {
/*  858 */         docBase.append(contextPath.replace('/', File.separatorChar));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  863 */       canonicalDocBase = new File(docBase.toString()).getCanonicalPath();
/*      */       
/*      */ 
/*      */ 
/*  867 */       if (canonicalDocBase.endsWith(File.separator)) {
/*  868 */         docBase.append(File.separator);
/*      */       }
/*      */     } catch (IOException ioe) {
/*  871 */       return false;
/*      */     }
/*      */     
/*      */     StringBuilder docBase;
/*      */     
/*  876 */     return canonicalDocBase.equals(docBase.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployWAR(ContextName cn, File war)
/*      */   {
/*  890 */     File xml = new File(this.host.getAppBaseFile(), cn.getBaseName() + "/" + "META-INF/context.xml");
/*      */     
/*  892 */     File warTracker = new File(this.host.getAppBaseFile(), cn.getBaseName() + "/META-INF/war-tracker");
/*      */     
/*  894 */     boolean xmlInWar = false;
/*  895 */     try { JarFile jar = new JarFile(war);Throwable localThrowable19 = null;
/*  896 */       try { JarEntry entry = jar.getJarEntry("META-INF/context.xml");
/*  897 */         if (entry != null) {
/*  898 */           xmlInWar = true;
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable2)
/*      */       {
/*  895 */         localThrowable19 = localThrowable2;throw localThrowable2;
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*  900 */         if (jar != null) { if (localThrowable19 != null) try { jar.close(); } catch (Throwable localThrowable3) { localThrowable19.addSuppressed(localThrowable3); } else { jar.close();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException) {}
/*      */     
/*  907 */     boolean useXml = false;
/*      */     
/*      */ 
/*  910 */     if ((xml.exists()) && (this.unpackWARs) && ((!warTracker.exists()) || (warTracker.lastModified() == war.lastModified()))) {
/*  911 */       useXml = true;
/*      */     }
/*      */     
/*  914 */     Object context = null;
/*  915 */     boolean deployThisXML = isDeployThisXML(war, cn);
/*      */     Throwable localThrowable20;
/*      */     Throwable localThrowable25;
/*  918 */     try { if ((deployThisXML) && (useXml) && (!this.copyXML)) {
/*  919 */         synchronized (this.digesterLock) {
/*      */           try {
/*  921 */             context = (Context)this.digester.parse(xml);
/*      */           } catch (Exception e) {
/*  923 */             log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { war.getAbsolutePath() }), e);
/*      */           } finally {
/*  925 */             this.digester.reset();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  931 */         ((Context)context).setConfigFile(xml.toURI().toURL());
/*  932 */       } else if ((deployThisXML) && (xmlInWar)) {
/*  933 */         synchronized (this.digesterLock) {
/*  934 */           try { JarFile jar = new JarFile(war);localThrowable20 = null;
/*  935 */             try { JarEntry entry = jar.getJarEntry("META-INF/context.xml");
/*  936 */               InputStream istream = jar.getInputStream(entry);localThrowable25 = null;
/*  937 */               try { context = (Context)this.digester.parse(istream);
/*      */               }
/*      */               catch (Throwable localThrowable5)
/*      */               {
/*  936 */                 localThrowable25 = localThrowable5;throw localThrowable5;
/*      */               }
/*      */               finally {}
/*      */             }
/*      */             catch (Throwable localThrowable22)
/*      */             {
/*  934 */               localThrowable20 = localThrowable22;throw localThrowable22;
/*      */ 
/*      */             }
/*      */             finally
/*      */             {
/*  939 */               if (jar != null) if (localThrowable20 != null) try { jar.close(); } catch (Throwable localThrowable9) { localThrowable20.addSuppressed(localThrowable9); } else jar.close();
/*  940 */             } } catch (Exception e) { log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { war.getAbsolutePath() }), e);
/*      */           } finally {
/*  942 */             this.digester.reset();
/*  943 */             if (context == null) {
/*  944 */               context = new FailedContext();
/*      */             }
/*  946 */             ((Context)context).setConfigFile(UriUtil.buildJarUrl(war, "META-INF/context.xml"));
/*      */           }
/*      */         }
/*  949 */       } else if ((!deployThisXML) && (xmlInWar))
/*      */       {
/*      */ 
/*  952 */         log.error(sm.getString("hostConfig.deployDescriptor.blocked", new Object[] {cn
/*  953 */           .getPath(), "META-INF/context.xml", new File(this.host
/*  954 */           .getConfigBaseFile(), cn.getBaseName() + ".xml") }));
/*      */       } else {
/*  956 */         context = (Context)Class.forName(this.contextClass).getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */       }
/*      */     } catch (Throwable t) {
/*  959 */       ExceptionUtils.handleThrowable(t);
/*  960 */       log.error(sm.getString("hostConfig.deployWar.error", new Object[] { war.getAbsolutePath() }), t);
/*      */     } finally {
/*  962 */       if (context == null) {
/*  963 */         context = new FailedContext();
/*      */       }
/*      */     }
/*      */     
/*  967 */     boolean copyThisXml = false;
/*  968 */     if (deployThisXML) {
/*  969 */       if ((this.host instanceof StandardHost)) {
/*  970 */         copyThisXml = ((StandardHost)this.host).isCopyXML();
/*      */       }
/*      */       
/*      */ 
/*  974 */       if ((!copyThisXml) && ((context instanceof StandardContext))) {
/*  975 */         copyThisXml = ((StandardContext)context).getCopyXML();
/*      */       }
/*      */       
/*  978 */       if ((xmlInWar) && (copyThisXml))
/*      */       {
/*  980 */         xml = new File(this.host.getConfigBaseFile(), cn.getBaseName() + ".xml");
/*  981 */         try { JarFile jar = new JarFile(war);localThrowable20 = null;
/*  982 */           try { JarEntry entry = jar.getJarEntry("META-INF/context.xml");
/*  983 */             InputStream istream = jar.getInputStream(entry);localThrowable25 = null;
/*  984 */             try { OutputStream ostream = new FileOutputStream(xml);Throwable localThrowable26 = null;
/*  985 */               try { IOTools.flow(istream, ostream);
/*      */               }
/*      */               catch (Throwable localThrowable11)
/*      */               {
/*  983 */                 localThrowable26 = localThrowable11;throw localThrowable11; } finally {} } catch (Throwable localThrowable14) { localThrowable25 = localThrowable14;throw localThrowable14;
/*      */             }
/*      */             finally {}
/*      */           }
/*      */           catch (Throwable localThrowable24)
/*      */           {
/*  981 */             localThrowable20 = localThrowable24;throw localThrowable24;
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*  987 */             if (jar != null) if (localThrowable20 != null) try { jar.close(); } catch (Throwable localThrowable18) { localThrowable20.addSuppressed(localThrowable18); } else { jar.close();
/*      */               }
/*      */           }
/*      */         }
/*      */         catch (IOException localIOException1) {}
/*      */       }
/*      */     }
/*  994 */     DeployedApplication deployedApp = new DeployedApplication(cn.getName(), (xml.exists()) && (deployThisXML) && (copyThisXml));
/*      */     
/*  996 */     long startTime = 0L;
/*      */     
/*  998 */     if (log.isInfoEnabled()) {
/*  999 */       startTime = System.currentTimeMillis();
/* 1000 */       log.info(sm.getString("hostConfig.deployWar", new Object[] { war.getAbsolutePath() }));
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1005 */       deployedApp.redeployResources.put(war.getAbsolutePath(), Long.valueOf(war.lastModified()));
/*      */       
/* 1007 */       if ((deployThisXML) && (xml.exists()) && (copyThisXml)) {
/* 1008 */         deployedApp.redeployResources.put(xml.getAbsolutePath(), Long.valueOf(xml.lastModified()));
/*      */       }
/*      */       else {
/* 1011 */         deployedApp.redeployResources.put(new File(this.host
/* 1012 */           .getConfigBaseFile(), cn.getBaseName() + ".xml").getAbsolutePath(), 
/* 1013 */           Long.valueOf(0L));
/*      */       }
/*      */       
/* 1016 */       Class<?> clazz = Class.forName(this.host.getConfigClass());
/* 1017 */       LifecycleListener listener = (LifecycleListener)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 1018 */       ((Context)context).addLifecycleListener(listener);
/*      */       
/* 1020 */       ((Context)context).setName(cn.getName());
/* 1021 */       ((Context)context).setPath(cn.getPath());
/* 1022 */       ((Context)context).setWebappVersion(cn.getVersion());
/* 1023 */       ((Context)context).setDocBase(cn.getBaseName() + ".war");
/* 1024 */       this.host.addChild((Container)context); } catch (Throwable t) { boolean unpackWAR;
/*      */       File docBase;
/* 1026 */       ExceptionUtils.handleThrowable(t);
/* 1027 */       log.error(sm.getString("hostConfig.deployWar.error", new Object[] { war.getAbsolutePath() }), t);
/*      */     } finally {
/*      */       boolean unpackWAR;
/*      */       File docBase;
/* 1031 */       boolean unpackWAR = this.unpackWARs;
/* 1032 */       if ((unpackWAR) && ((context instanceof StandardContext))) {
/* 1033 */         unpackWAR = ((StandardContext)context).getUnpackWAR();
/*      */       }
/* 1035 */       if ((unpackWAR) && (((Context)context).getDocBase() != null)) {
/* 1036 */         File docBase = new File(this.host.getAppBaseFile(), cn.getBaseName());
/* 1037 */         deployedApp.redeployResources.put(docBase.getAbsolutePath(), Long.valueOf(docBase.lastModified()));
/* 1038 */         addWatchedResources(deployedApp, docBase.getAbsolutePath(), (Context)context);
/* 1039 */         if ((deployThisXML) && (!copyThisXml) && ((xmlInWar) || (xml.exists()))) {
/* 1040 */           deployedApp.redeployResources.put(xml.getAbsolutePath(), Long.valueOf(xml.lastModified()));
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1045 */         addWatchedResources(deployedApp, null, (Context)context);
/*      */       }
/*      */       
/*      */ 
/* 1049 */       addGlobalRedeployResources(deployedApp);
/*      */     }
/*      */     
/* 1052 */     this.deployed.put(cn.getName(), deployedApp);
/*      */     
/* 1054 */     if (log.isInfoEnabled()) {
/* 1055 */       log.info(sm.getString("hostConfig.deployWar.finished", new Object[] {war
/* 1056 */         .getAbsolutePath(), Long.valueOf(System.currentTimeMillis() - startTime) }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployDirectories(File appBase, String[] files)
/*      */   {
/* 1068 */     if (files == null) {
/* 1069 */       return;
/*      */     }
/*      */     
/* 1072 */     ExecutorService es = this.host.getStartStopExecutor();
/* 1073 */     List<Future<?>> results = new ArrayList();
/*      */     
/* 1075 */     for (String file : files) {
/* 1076 */       if (!file.equalsIgnoreCase("META-INF"))
/*      */       {
/*      */ 
/* 1079 */         if (!file.equalsIgnoreCase("WEB-INF"))
/*      */         {
/*      */ 
/*      */ 
/* 1083 */           File dir = new File(appBase, file);
/* 1084 */           if (dir.isDirectory()) {
/* 1085 */             ContextName cn = new ContextName(file, false);
/*      */             
/* 1087 */             if (tryAddServiced(cn.getName()))
/*      */               try {
/* 1089 */                 if (deploymentExists(cn.getName())) {
/* 1090 */                   removeServiced(cn.getName());
/*      */ 
/*      */                 }
/*      */                 else
/*      */                 {
/* 1095 */                   results.add(es.submit(new DeployDirectory(this, cn, dir))); }
/*      */               } catch (Throwable t) {
/* 1097 */                 ExceptionUtils.handleThrowable(t);
/* 1098 */                 removeServiced(cn.getName());
/* 1099 */                 throw t;
/*      */               }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1105 */     for (??? = results.iterator(); ((Iterator)???).hasNext();) { Object result = (Future)((Iterator)???).next();
/*      */       try {
/* 1107 */         ((Future)result).get();
/*      */       } catch (Exception e) {
/* 1109 */         log.error(sm.getString("hostConfig.deployDir.threaded.error"), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deployDirectory(ContextName cn, File dir)
/*      */   {
/* 1126 */     long startTime = 0L;
/*      */     
/* 1128 */     if (log.isInfoEnabled()) {
/* 1129 */       startTime = System.currentTimeMillis();
/* 1130 */       log.info(sm.getString("hostConfig.deployDir", new Object[] { dir.getAbsolutePath() }));
/*      */     }
/*      */     
/* 1133 */     Context context = null;
/* 1134 */     File xml = new File(dir, "META-INF/context.xml");
/* 1135 */     File xmlCopy = new File(this.host.getConfigBaseFile(), cn.getBaseName() + ".xml");
/*      */     
/*      */ 
/* 1138 */     boolean copyThisXml = isCopyXML();
/* 1139 */     boolean deployThisXML = isDeployThisXML(dir, cn);
/*      */     DeployedApplication deployedApp;
/*      */     try {
/* 1142 */       if ((deployThisXML) && (xml.exists())) {
/* 1143 */         synchronized (this.digesterLock) {
/*      */           try {
/* 1145 */             context = (Context)this.digester.parse(xml);
/*      */           } catch (Exception e) {
/* 1147 */             log.error(sm.getString("hostConfig.deployDescriptor.error", new Object[] { xml }), e);
/* 1148 */             context = new FailedContext();
/*      */           } finally {
/* 1150 */             this.digester.reset();
/* 1151 */             if (context == null) {
/* 1152 */               context = new FailedContext();
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 1157 */         if ((!copyThisXml) && ((context instanceof StandardContext)))
/*      */         {
/* 1159 */           copyThisXml = ((StandardContext)context).getCopyXML();
/*      */         }
/*      */         
/* 1162 */         if (copyThisXml) {
/* 1163 */           Files.copy(xml.toPath(), xmlCopy.toPath(), new CopyOption[0]);
/* 1164 */           context.setConfigFile(xmlCopy.toURI().toURL());
/*      */         } else {
/* 1166 */           context.setConfigFile(xml.toURI().toURL());
/*      */         }
/* 1168 */       } else if ((!deployThisXML) && (xml.exists()))
/*      */       {
/*      */ 
/* 1171 */         log.error(sm.getString("hostConfig.deployDescriptor.blocked", new Object[] { cn.getPath(), xml, xmlCopy }));
/* 1172 */         context = new FailedContext();
/*      */       } else {
/* 1174 */         context = (Context)Class.forName(this.contextClass).getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */       }
/*      */       
/* 1177 */       Class<?> clazz = Class.forName(this.host.getConfigClass());
/* 1178 */       LifecycleListener listener = (LifecycleListener)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 1179 */       context.addLifecycleListener(listener);
/*      */       
/* 1181 */       context.setName(cn.getName());
/* 1182 */       context.setPath(cn.getPath());
/* 1183 */       context.setWebappVersion(cn.getVersion());
/* 1184 */       context.setDocBase(cn.getBaseName());
/* 1185 */       this.host.addChild(context);
/*      */     } catch (Throwable t) { DeployedApplication deployedApp;
/* 1187 */       ExceptionUtils.handleThrowable(t);
/* 1188 */       log.error(sm.getString("hostConfig.deployDir.error", new Object[] { dir.getAbsolutePath() }), t);
/*      */     } finally { DeployedApplication deployedApp;
/* 1190 */       deployedApp = new DeployedApplication(cn.getName(), (xml.exists()) && (deployThisXML) && (copyThisXml));
/*      */       
/*      */ 
/*      */ 
/* 1194 */       deployedApp.redeployResources.put(dir.getAbsolutePath() + ".war", Long.valueOf(0L));
/* 1195 */       deployedApp.redeployResources.put(dir.getAbsolutePath(), Long.valueOf(dir.lastModified()));
/* 1196 */       if ((deployThisXML) && (xml.exists())) {
/* 1197 */         if (copyThisXml) {
/* 1198 */           deployedApp.redeployResources.put(xmlCopy.getAbsolutePath(), Long.valueOf(xmlCopy.lastModified()));
/*      */         } else {
/* 1200 */           deployedApp.redeployResources.put(xml.getAbsolutePath(), Long.valueOf(xml.lastModified()));
/*      */           
/*      */ 
/* 1203 */           deployedApp.redeployResources.put(xmlCopy.getAbsolutePath(), Long.valueOf(0L));
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1208 */         deployedApp.redeployResources.put(xmlCopy.getAbsolutePath(), Long.valueOf(0L));
/* 1209 */         if (!xml.exists()) {
/* 1210 */           deployedApp.redeployResources.put(xml.getAbsolutePath(), Long.valueOf(0L));
/*      */         }
/*      */       }
/* 1213 */       addWatchedResources(deployedApp, dir.getAbsolutePath(), context);
/*      */       
/*      */ 
/* 1216 */       addGlobalRedeployResources(deployedApp);
/*      */     }
/*      */     
/* 1219 */     this.deployed.put(cn.getName(), deployedApp);
/*      */     
/* 1221 */     if (log.isInfoEnabled()) {
/* 1222 */       log.info(sm.getString("hostConfig.deployDir.finished", new Object[] {dir
/* 1223 */         .getAbsolutePath(), Long.valueOf(System.currentTimeMillis() - startTime) }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean deploymentExists(String contextName)
/*      */   {
/* 1235 */     return (this.deployed.containsKey(contextName)) || (this.host.findChild(contextName) != null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addWatchedResources(DeployedApplication app, String docBase, Context context)
/*      */   {
/* 1249 */     File docBaseFile = null;
/* 1250 */     if (docBase != null) {
/* 1251 */       docBaseFile = new File(docBase);
/* 1252 */       if (!docBaseFile.isAbsolute()) {
/* 1253 */         docBaseFile = new File(this.host.getAppBaseFile(), docBase);
/*      */       }
/*      */     }
/* 1256 */     String[] watchedResources = context.findWatchedResources();
/* 1257 */     for (String watchedResource : watchedResources) {
/* 1258 */       File resource = new File(watchedResource);
/* 1259 */       if (!resource.isAbsolute()) {
/* 1260 */         if (docBase != null) {
/* 1261 */           resource = new File(docBaseFile, watchedResource);
/*      */         } else {
/* 1263 */           if (!log.isDebugEnabled()) continue;
/* 1264 */           log.debug("Ignoring non-existent WatchedResource '" + resource
/* 1265 */             .getAbsolutePath() + "'"); continue;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1270 */       if (log.isDebugEnabled()) {
/* 1271 */         log.debug("Watching WatchedResource '" + resource
/* 1272 */           .getAbsolutePath() + "'");
/*      */       }
/* 1274 */       app.reloadResources.put(resource.getAbsolutePath(), 
/* 1275 */         Long.valueOf(resource.lastModified()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void addGlobalRedeployResources(DeployedApplication app)
/*      */   {
/* 1283 */     File hostContextXml = new File(getConfigBaseName(), "context.xml.default");
/* 1284 */     if (hostContextXml.isFile()) {
/* 1285 */       app.redeployResources.put(hostContextXml.getAbsolutePath(), 
/* 1286 */         Long.valueOf(hostContextXml.lastModified()));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1291 */     File globalContextXml = returnCanonicalPath("conf/context.xml");
/* 1292 */     if (globalContextXml.isFile()) {
/* 1293 */       app.redeployResources.put(globalContextXml.getAbsolutePath(), 
/* 1294 */         Long.valueOf(globalContextXml.lastModified()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void checkResources(DeployedApplication app, boolean skipFileModificationResolutionCheck)
/*      */   {
/* 1312 */     String[] resources = (String[])app.redeployResources.keySet().toArray(new String[0]);
/*      */     
/*      */ 
/* 1315 */     long currentTimeWithResolutionOffset = System.currentTimeMillis() - 1000L;
/* 1316 */     for (int i = 0; i < resources.length; i++) {
/* 1317 */       resource = new File(resources[i]);
/* 1318 */       if (log.isDebugEnabled()) {
/* 1319 */         log.debug("Checking context[" + app.name + "] redeploy resource " + resource);
/*      */       }
/*      */       
/*      */ 
/* 1323 */       lastModified = ((Long)app.redeployResources.get(resources[i])).longValue();
/* 1324 */       if ((resource.exists()) || (lastModified == 0L))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1329 */         if ((resource.lastModified() != lastModified) && ((!this.host.getAutoDeploy()) || 
/* 1330 */           (resource.lastModified() < currentTimeWithResolutionOffset) || (skipFileModificationResolutionCheck)))
/*      */         {
/* 1332 */           if (resource.isDirectory())
/*      */           {
/* 1334 */             app.redeployResources.put(resources[i], 
/* 1335 */               Long.valueOf(resource.lastModified()));
/* 1336 */           } else { if (app.hasDescriptor)
/*      */             {
/* 1338 */               if (resource.getName().toLowerCase(Locale.ENGLISH).endsWith(".war"))
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/* 1343 */                 Context context = (Context)this.host.findChild(app.name);
/* 1344 */                 String docBase = context.getDocBase();
/* 1345 */                 if (!docBase.toLowerCase(Locale.ENGLISH).endsWith(".war"))
/*      */                 {
/* 1347 */                   File docBaseFile = new File(docBase);
/* 1348 */                   if (!docBaseFile.isAbsolute()) {
/* 1349 */                     docBaseFile = new File(this.host.getAppBaseFile(), docBase);
/*      */                   }
/*      */                   
/* 1352 */                   reload(app, docBaseFile, resource.getAbsolutePath());
/*      */                 } else {
/* 1354 */                   reload(app, null, null);
/*      */                 }
/*      */                 
/* 1357 */                 app.redeployResources.put(resources[i], 
/* 1358 */                   Long.valueOf(resource.lastModified()));
/* 1359 */                 app.timestamp = System.currentTimeMillis();
/* 1360 */                 boolean unpackWAR = this.unpackWARs;
/* 1361 */                 if ((unpackWAR) && ((context instanceof StandardContext))) {
/* 1362 */                   unpackWAR = ((StandardContext)context).getUnpackWAR();
/*      */                 }
/* 1364 */                 if (unpackWAR) {
/* 1365 */                   addWatchedResources(app, context.getDocBase(), context);
/*      */                 } else {
/* 1367 */                   addWatchedResources(app, null, context);
/*      */                 }
/* 1369 */                 return;
/*      */               }
/*      */             }
/*      */             
/* 1373 */             undeploy(app);
/* 1374 */             deleteRedeployResources(app, resources, i, false);
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*      */         try
/*      */         {
/* 1382 */           Thread.sleep(500L);
/*      */         }
/*      */         catch (InterruptedException localInterruptedException) {}
/*      */         
/*      */ 
/* 1387 */         if (!resource.exists())
/*      */         {
/*      */ 
/*      */ 
/* 1391 */           undeploy(app);
/* 1392 */           deleteRedeployResources(app, resources, i, true);
/* 1393 */           return;
/*      */         }
/*      */       } }
/* 1396 */     resources = (String[])app.reloadResources.keySet().toArray(new String[0]);
/* 1397 */     boolean update = false;
/* 1398 */     File resource = resources;long lastModified = resource.length; for (long l1 = 0; l1 < lastModified; l1++) { String s = resource[l1];
/* 1399 */       File resource = new File(s);
/* 1400 */       if (log.isDebugEnabled()) {
/* 1401 */         log.debug("Checking context[" + app.name + "] reload resource " + resource);
/*      */       }
/* 1403 */       long lastModified = ((Long)app.reloadResources.get(s)).longValue();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1408 */       if (((resource.lastModified() != lastModified) && (
/* 1409 */         (!this.host.getAutoDeploy()) || 
/* 1410 */         (resource.lastModified() < currentTimeWithResolutionOffset) || (skipFileModificationResolutionCheck))) || (update))
/*      */       {
/*      */ 
/* 1413 */         if (!update)
/*      */         {
/* 1415 */           reload(app, null, null);
/* 1416 */           update = true;
/*      */         }
/*      */         
/*      */ 
/* 1420 */         app.reloadResources.put(s, 
/* 1421 */           Long.valueOf(resource.lastModified()));
/*      */       }
/* 1423 */       app.timestamp = System.currentTimeMillis();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void reload(DeployedApplication app, File fileToRemove, String newDocBase)
/*      */   {
/* 1433 */     if (log.isInfoEnabled()) {
/* 1434 */       log.info(sm.getString("hostConfig.reload", new Object[] { app.name }));
/*      */     }
/* 1436 */     Context context = (Context)this.host.findChild(app.name);
/* 1437 */     if (context.getState().isAvailable()) {
/* 1438 */       if ((fileToRemove != null) && (newDocBase != null)) {
/* 1439 */         context.addLifecycleListener(new ExpandedDirectoryRemovalListener(fileToRemove, newDocBase));
/*      */       }
/*      */       
/*      */ 
/* 1443 */       context.reload();
/*      */     }
/*      */     else
/*      */     {
/* 1447 */       if ((fileToRemove != null) && (newDocBase != null)) {
/* 1448 */         ExpandWar.delete(fileToRemove);
/* 1449 */         context.setDocBase(newDocBase);
/*      */       }
/*      */       try {
/* 1452 */         context.start();
/*      */       } catch (Exception e) {
/* 1454 */         log.error(sm.getString("hostConfig.context.restart", new Object[] { app.name }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void undeploy(DeployedApplication app)
/*      */   {
/* 1461 */     if (log.isInfoEnabled()) {
/* 1462 */       log.info(sm.getString("hostConfig.undeploy", new Object[] { app.name }));
/*      */     }
/* 1464 */     Container context = this.host.findChild(app.name);
/*      */     try {
/* 1466 */       this.host.removeChild(context);
/*      */     } catch (Throwable t) {
/* 1468 */       ExceptionUtils.handleThrowable(t);
/* 1469 */       log.warn(sm
/* 1470 */         .getString("hostConfig.context.remove", new Object[] { app.name }), t);
/*      */     }
/* 1472 */     this.deployed.remove(app.name);
/*      */   }
/*      */   
/*      */ 
/*      */   private void deleteRedeployResources(DeployedApplication app, String[] resources, int i, boolean deleteReloadResources)
/*      */   {
/*      */     File current;
/*      */     
/* 1480 */     for (int j = i + 1; j < resources.length; j++) {
/* 1481 */       current = new File(resources[j]);
/*      */       
/* 1483 */       if (!"context.xml.default".equals(current.getName()))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1488 */         if (isDeletableResource(app, current)) {
/* 1489 */           if (log.isDebugEnabled()) {
/* 1490 */             log.debug("Delete " + current);
/*      */           }
/* 1492 */           ExpandWar.delete(current);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1497 */     if (deleteReloadResources) {
/* 1498 */       String[] resources2 = (String[])app.reloadResources.keySet().toArray(new String[0]);
/* 1499 */       for (String s : resources2) {
/* 1500 */         File current = new File(s);
/*      */         
/* 1502 */         if (!"context.xml.default".equals(current.getName()))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1507 */           if (isDeletableResource(app, current)) {
/* 1508 */             if (log.isDebugEnabled()) {
/* 1509 */               log.debug("Delete " + current);
/*      */             }
/* 1511 */             ExpandWar.delete(current);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isDeletableResource(DeployedApplication app, File resource)
/*      */   {
/* 1530 */     if (!resource.isAbsolute()) {
/* 1531 */       log.warn(sm.getString("hostConfig.resourceNotAbsolute", new Object[] { app.name, resource }));
/* 1532 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1538 */       canonicalLocation = resource.getParentFile().getCanonicalPath();
/*      */     } catch (IOException e) { String canonicalLocation;
/* 1540 */       log.warn(sm.getString("hostConfig.canonicalizing", new Object[] {resource
/* 1541 */         .getParentFile(), app.name }), e);
/* 1542 */       return false;
/*      */     }
/*      */     String canonicalLocation;
/*      */     try
/*      */     {
/* 1547 */       canonicalAppBase = this.host.getAppBaseFile().getCanonicalPath();
/*      */     } catch (IOException e) { String canonicalAppBase;
/* 1549 */       log.warn(sm.getString("hostConfig.canonicalizing", new Object[] {this.host
/* 1550 */         .getAppBaseFile(), app.name }), e);
/* 1551 */       return false;
/*      */     }
/*      */     String canonicalAppBase;
/* 1554 */     if (canonicalLocation.equals(canonicalAppBase))
/*      */     {
/* 1556 */       return true;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1561 */       canonicalConfigBase = this.host.getConfigBaseFile().getCanonicalPath();
/*      */     } catch (IOException e) { String canonicalConfigBase;
/* 1563 */       log.warn(sm.getString("hostConfig.canonicalizing", new Object[] {this.host
/* 1564 */         .getConfigBaseFile(), app.name }), e);
/* 1565 */       return false;
/*      */     }
/*      */     String canonicalConfigBase;
/* 1568 */     if ((canonicalLocation.equals(canonicalConfigBase)) && 
/* 1569 */       (resource.getName().endsWith(".xml")))
/*      */     {
/* 1571 */       return true;
/*      */     }
/*      */     
/*      */ 
/* 1575 */     return false;
/*      */   }
/*      */   
/*      */   public void beforeStart()
/*      */   {
/* 1580 */     if (this.host.getCreateDirs()) {
/* 1581 */       File[] dirs = { this.host.getAppBaseFile(), this.host.getConfigBaseFile() };
/* 1582 */       for (File dir : dirs) {
/* 1583 */         if ((!dir.mkdirs()) && (!dir.isDirectory())) {
/* 1584 */           log.error(sm.getString("hostConfig.createDirs", new Object[] { dir }));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void start()
/*      */   {
/* 1596 */     if (log.isDebugEnabled()) {
/* 1597 */       log.debug(sm.getString("hostConfig.start"));
/*      */     }
/*      */     try
/*      */     {
/* 1601 */       ObjectName hostON = this.host.getObjectName();
/*      */       
/* 1603 */       this.oname = new ObjectName(hostON.getDomain() + ":type=Deployer,host=" + this.host.getName());
/* 1604 */       Registry.getRegistry(null, null)
/* 1605 */         .registerComponent(this, this.oname, getClass().getName());
/*      */     } catch (Exception e) {
/* 1607 */       log.warn(sm.getString("hostConfig.jmx.register", new Object[] { this.oname }), e);
/*      */     }
/*      */     
/* 1610 */     if (!this.host.getAppBaseFile().isDirectory()) {
/* 1611 */       log.error(sm.getString("hostConfig.appBase", new Object[] { this.host.getName(), this.host
/* 1612 */         .getAppBaseFile().getPath() }));
/* 1613 */       this.host.setDeployOnStartup(false);
/* 1614 */       this.host.setAutoDeploy(false);
/*      */     }
/*      */     
/* 1617 */     if (this.host.getDeployOnStartup()) {
/* 1618 */       deployApps();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stop()
/*      */   {
/* 1628 */     if (log.isDebugEnabled()) {
/* 1629 */       log.debug(sm.getString("hostConfig.stop"));
/*      */     }
/*      */     
/* 1632 */     if (this.oname != null) {
/*      */       try {
/* 1634 */         Registry.getRegistry(null, null).unregisterComponent(this.oname);
/*      */       } catch (Exception e) {
/* 1636 */         log.warn(sm.getString("hostConfig.jmx.unregister", new Object[] { this.oname }), e);
/*      */       }
/*      */     }
/* 1639 */     this.oname = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void check()
/*      */   {
/* 1648 */     if (this.host.getAutoDeploy())
/*      */     {
/* 1650 */       DeployedApplication[] apps = (DeployedApplication[])this.deployed.values().toArray(new DeployedApplication[0]);
/* 1651 */       for (DeployedApplication app : apps) {
/* 1652 */         if (tryAddServiced(app.name)) {
/*      */           try {
/* 1654 */             checkResources(app, false);
/*      */           } finally {
/* 1656 */             removeServiced(app.name);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1662 */       if (this.host.getUndeployOldVersions()) {
/* 1663 */         checkUndeploy();
/*      */       }
/*      */       
/*      */ 
/* 1667 */       deployApps();
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void check(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: aload_1
/*      */     //   2: invokevirtual 130	org/apache/catalina/startup/HostConfig:tryAddServiced	(Ljava/lang/String;)Z
/*      */     //   5: ifeq +48 -> 53
/*      */     //   8: aload_0
/*      */     //   9: getfield 11	org/apache/catalina/startup/HostConfig:deployed	Ljava/util/Map;
/*      */     //   12: aload_1
/*      */     //   13: invokeinterface 75 2 0
/*      */     //   18: checkcast 76	org/apache/catalina/startup/HostConfig$DeployedApplication
/*      */     //   21: astore_2
/*      */     //   22: aload_2
/*      */     //   23: ifnull +9 -> 32
/*      */     //   26: aload_0
/*      */     //   27: aload_2
/*      */     //   28: iconst_1
/*      */     //   29: invokevirtual 327	org/apache/catalina/startup/HostConfig:checkResources	(Lorg/apache/catalina/startup/HostConfig$DeployedApplication;Z)V
/*      */     //   32: aload_0
/*      */     //   33: aload_1
/*      */     //   34: invokevirtual 330	org/apache/catalina/startup/HostConfig:deployApps	(Ljava/lang/String;)V
/*      */     //   37: aload_0
/*      */     //   38: aload_1
/*      */     //   39: invokevirtual 131	org/apache/catalina/startup/HostConfig:removeServiced	(Ljava/lang/String;)V
/*      */     //   42: goto +11 -> 53
/*      */     //   45: astore_3
/*      */     //   46: aload_0
/*      */     //   47: aload_1
/*      */     //   48: invokevirtual 131	org/apache/catalina/startup/HostConfig:removeServiced	(Ljava/lang/String;)V
/*      */     //   51: aload_3
/*      */     //   52: athrow
/*      */     //   53: return
/*      */     // Line number table:
/*      */     //   Java source line #1684	-> byte code offset #0
/*      */     //   Java source line #1686	-> byte code offset #8
/*      */     //   Java source line #1687	-> byte code offset #22
/*      */     //   Java source line #1688	-> byte code offset #26
/*      */     //   Java source line #1690	-> byte code offset #32
/*      */     //   Java source line #1692	-> byte code offset #37
/*      */     //   Java source line #1693	-> byte code offset #42
/*      */     //   Java source line #1692	-> byte code offset #45
/*      */     //   Java source line #1693	-> byte code offset #51
/*      */     //   Java source line #1695	-> byte code offset #53
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	54	0	this	HostConfig
/*      */     //   0	54	1	name	String
/*      */     //   21	7	2	app	DeployedApplication
/*      */     //   45	7	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   8	37	45	finally
/*      */   }
/*      */   
/*      */   public synchronized void checkUndeploy()
/*      */   {
/* 1702 */     if (this.deployed.size() < 2) {
/* 1703 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1707 */     SortedSet<String> sortedAppNames = new TreeSet(this.deployed.keySet());
/*      */     
/* 1709 */     Iterator<String> iter = sortedAppNames.iterator();
/*      */     
/* 1711 */     ContextName previous = new ContextName((String)iter.next(), false);
/*      */     do {
/* 1713 */       ContextName current = new ContextName((String)iter.next(), false);
/*      */       
/* 1715 */       if (current.getPath().equals(previous.getPath()))
/*      */       {
/*      */ 
/* 1718 */         Context previousContext = (Context)this.host.findChild(previous.getName());
/* 1719 */         Context currentContext = (Context)this.host.findChild(current.getName());
/* 1720 */         if ((previousContext != null) && (currentContext != null) && 
/* 1721 */           (currentContext.getState().isAvailable()) && 
/* 1722 */           (tryAddServiced(previous.getName()))) {
/*      */           try {
/* 1724 */             Manager manager = previousContext.getManager();
/* 1725 */             if (manager != null) { int sessionCount;
/*      */               int sessionCount;
/* 1727 */               if ((manager instanceof DistributedManager)) {
/* 1728 */                 sessionCount = ((DistributedManager)manager).getActiveSessionsFull();
/*      */               } else {
/* 1730 */                 sessionCount = manager.getActiveSessions();
/*      */               }
/* 1732 */               if (sessionCount == 0) {
/* 1733 */                 if (log.isInfoEnabled()) {
/* 1734 */                   log.info(sm.getString("hostConfig.undeployVersion", new Object[] { previous.getName() }));
/*      */                 }
/* 1736 */                 DeployedApplication app = (DeployedApplication)this.deployed.get(previous.getName());
/* 1737 */                 String[] resources = (String[])app.redeployResources.keySet().toArray(new String[0]);
/*      */                 
/*      */ 
/*      */ 
/* 1741 */                 undeploy(app);
/* 1742 */                 deleteRedeployResources(app, resources, -1, true);
/*      */               }
/*      */             }
/*      */           } finally {
/* 1746 */             removeServiced(previous.getName());
/*      */           }
/*      */         }
/*      */       }
/* 1750 */       previous = current;
/* 1751 */     } while (iter.hasNext());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void manageApp(Context context)
/*      */   {
/* 1761 */     String contextName = context.getName();
/*      */     
/* 1763 */     if (this.deployed.containsKey(contextName)) {
/* 1764 */       return;
/*      */     }
/*      */     
/* 1767 */     DeployedApplication deployedApp = new DeployedApplication(contextName, false);
/*      */     
/*      */ 
/*      */ 
/* 1771 */     boolean isWar = false;
/* 1772 */     if (context.getDocBase() != null) {
/* 1773 */       File docBase = new File(context.getDocBase());
/* 1774 */       if (!docBase.isAbsolute()) {
/* 1775 */         docBase = new File(this.host.getAppBaseFile(), context.getDocBase());
/*      */       }
/* 1777 */       deployedApp.redeployResources.put(docBase.getAbsolutePath(), 
/* 1778 */         Long.valueOf(docBase.lastModified()));
/* 1779 */       if (docBase.getAbsolutePath().toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/* 1780 */         isWar = true;
/*      */       }
/*      */     }
/* 1783 */     this.host.addChild(context);
/*      */     
/*      */ 
/* 1786 */     boolean unpackWAR = this.unpackWARs;
/* 1787 */     if ((unpackWAR) && ((context instanceof StandardContext))) {
/* 1788 */       unpackWAR = ((StandardContext)context).getUnpackWAR();
/*      */     }
/* 1790 */     if ((isWar) && (unpackWAR)) {
/* 1791 */       File docBase = new File(this.host.getAppBaseFile(), context.getBaseName());
/* 1792 */       deployedApp.redeployResources.put(docBase.getAbsolutePath(), 
/* 1793 */         Long.valueOf(docBase.lastModified()));
/* 1794 */       addWatchedResources(deployedApp, docBase.getAbsolutePath(), context);
/*      */     } else {
/* 1796 */       addWatchedResources(deployedApp, null, context);
/*      */     }
/* 1798 */     this.deployed.put(contextName, deployedApp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void unmanageApp(String contextName)
/*      */   {
/* 1811 */     this.deployed.remove(contextName);
/* 1812 */     this.host.removeChild(this.host.findChild(contextName));
/*      */   }
/*      */   
/*      */ 
/*      */   protected static class DeployedApplication
/*      */   {
/*      */     public final String name;
/*      */     
/*      */     public final boolean hasDescriptor;
/*      */     
/*      */     public DeployedApplication(String name, boolean hasDescriptor)
/*      */     {
/* 1824 */       this.name = name;
/* 1825 */       this.hasDescriptor = hasDescriptor;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1847 */     public final LinkedHashMap<String, Long> redeployResources = new LinkedHashMap();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1857 */     public final HashMap<String, Long> reloadResources = new HashMap();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1862 */     public long timestamp = System.currentTimeMillis();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1870 */     public boolean loggedDirWarning = false;
/*      */   }
/*      */   
/*      */   private static class DeployDescriptor implements Runnable
/*      */   {
/*      */     private HostConfig config;
/*      */     private ContextName cn;
/*      */     private File descriptor;
/*      */     
/*      */     public DeployDescriptor(HostConfig config, ContextName cn, File descriptor)
/*      */     {
/* 1881 */       this.config = config;
/* 1882 */       this.cn = cn;
/* 1883 */       this.descriptor = descriptor;
/*      */     }
/*      */     
/*      */     /* Error */
/*      */     public void run()
/*      */     {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: getfield 2	org/apache/catalina/startup/HostConfig$DeployDescriptor:config	Lorg/apache/catalina/startup/HostConfig;
/*      */       //   4: aload_0
/*      */       //   5: getfield 3	org/apache/catalina/startup/HostConfig$DeployDescriptor:cn	Lorg/apache/catalina/util/ContextName;
/*      */       //   8: aload_0
/*      */       //   9: getfield 4	org/apache/catalina/startup/HostConfig$DeployDescriptor:descriptor	Ljava/io/File;
/*      */       //   12: invokevirtual 5	org/apache/catalina/startup/HostConfig:deployDescriptor	(Lorg/apache/catalina/util/ContextName;Ljava/io/File;)V
/*      */       //   15: aload_0
/*      */       //   16: getfield 2	org/apache/catalina/startup/HostConfig$DeployDescriptor:config	Lorg/apache/catalina/startup/HostConfig;
/*      */       //   19: aload_0
/*      */       //   20: getfield 3	org/apache/catalina/startup/HostConfig$DeployDescriptor:cn	Lorg/apache/catalina/util/ContextName;
/*      */       //   23: invokevirtual 6	org/apache/catalina/util/ContextName:getName	()Ljava/lang/String;
/*      */       //   26: invokevirtual 7	org/apache/catalina/startup/HostConfig:removeServiced	(Ljava/lang/String;)V
/*      */       //   29: goto +20 -> 49
/*      */       //   32: astore_1
/*      */       //   33: aload_0
/*      */       //   34: getfield 2	org/apache/catalina/startup/HostConfig$DeployDescriptor:config	Lorg/apache/catalina/startup/HostConfig;
/*      */       //   37: aload_0
/*      */       //   38: getfield 3	org/apache/catalina/startup/HostConfig$DeployDescriptor:cn	Lorg/apache/catalina/util/ContextName;
/*      */       //   41: invokevirtual 6	org/apache/catalina/util/ContextName:getName	()Ljava/lang/String;
/*      */       //   44: invokevirtual 7	org/apache/catalina/startup/HostConfig:removeServiced	(Ljava/lang/String;)V
/*      */       //   47: aload_1
/*      */       //   48: athrow
/*      */       //   49: return
/*      */       // Line number table:
/*      */       //   Java source line #1889	-> byte code offset #0
/*      */       //   Java source line #1891	-> byte code offset #15
/*      */       //   Java source line #1892	-> byte code offset #29
/*      */       //   Java source line #1891	-> byte code offset #32
/*      */       //   Java source line #1892	-> byte code offset #47
/*      */       //   Java source line #1893	-> byte code offset #49
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	signature
/*      */       //   0	50	0	this	DeployDescriptor
/*      */       //   32	16	1	localObject	Object
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   0	15	32	finally
/*      */     }
/*      */   }
/*      */   
/*      */   private static class DeployWar
/*      */     implements Runnable
/*      */   {
/*      */     private HostConfig config;
/*      */     private ContextName cn;
/*      */     private File war;
/*      */     
/*      */     public DeployWar(HostConfig config, ContextName cn, File war)
/*      */     {
/* 1903 */       this.config = config;
/* 1904 */       this.cn = cn;
/* 1905 */       this.war = war;
/*      */     }
/*      */     
/*      */     /* Error */
/*      */     public void run()
/*      */     {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: getfield 2	org/apache/catalina/startup/HostConfig$DeployWar:config	Lorg/apache/catalina/startup/HostConfig;
/*      */       //   4: aload_0
/*      */       //   5: getfield 3	org/apache/catalina/startup/HostConfig$DeployWar:cn	Lorg/apache/catalina/util/ContextName;
/*      */       //   8: aload_0
/*      */       //   9: getfield 4	org/apache/catalina/startup/HostConfig$DeployWar:war	Ljava/io/File;
/*      */       //   12: invokevirtual 5	org/apache/catalina/startup/HostConfig:deployWAR	(Lorg/apache/catalina/util/ContextName;Ljava/io/File;)V
/*      */       //   15: aload_0
/*      */       //   16: getfield 2	org/apache/catalina/startup/HostConfig$DeployWar:config	Lorg/apache/catalina/startup/HostConfig;
/*      */       //   19: aload_0
/*      */       //   20: getfield 3	org/apache/catalina/startup/HostConfig$DeployWar:cn	Lorg/apache/catalina/util/ContextName;
/*      */       //   23: invokevirtual 6	org/apache/catalina/util/ContextName:getName	()Ljava/lang/String;
/*      */       //   26: invokevirtual 7	org/apache/catalina/startup/HostConfig:removeServiced	(Ljava/lang/String;)V
/*      */       //   29: goto +20 -> 49
/*      */       //   32: astore_1
/*      */       //   33: aload_0
/*      */       //   34: getfield 2	org/apache/catalina/startup/HostConfig$DeployWar:config	Lorg/apache/catalina/startup/HostConfig;
/*      */       //   37: aload_0
/*      */       //   38: getfield 3	org/apache/catalina/startup/HostConfig$DeployWar:cn	Lorg/apache/catalina/util/ContextName;
/*      */       //   41: invokevirtual 6	org/apache/catalina/util/ContextName:getName	()Ljava/lang/String;
/*      */       //   44: invokevirtual 7	org/apache/catalina/startup/HostConfig:removeServiced	(Ljava/lang/String;)V
/*      */       //   47: aload_1
/*      */       //   48: athrow
/*      */       //   49: return
/*      */       // Line number table:
/*      */       //   Java source line #1911	-> byte code offset #0
/*      */       //   Java source line #1913	-> byte code offset #15
/*      */       //   Java source line #1914	-> byte code offset #29
/*      */       //   Java source line #1913	-> byte code offset #32
/*      */       //   Java source line #1914	-> byte code offset #47
/*      */       //   Java source line #1915	-> byte code offset #49
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	signature
/*      */       //   0	50	0	this	DeployWar
/*      */       //   32	16	1	localObject	Object
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   0	15	32	finally
/*      */     }
/*      */   }
/*      */   
/*      */   private static class DeployDirectory
/*      */     implements Runnable
/*      */   {
/*      */     private HostConfig config;
/*      */     private ContextName cn;
/*      */     private File dir;
/*      */     
/*      */     public DeployDirectory(HostConfig config, ContextName cn, File dir)
/*      */     {
/* 1925 */       this.config = config;
/* 1926 */       this.cn = cn;
/* 1927 */       this.dir = dir;
/*      */     }
/*      */     
/*      */     /* Error */
/*      */     public void run()
/*      */     {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: getfield 2	org/apache/catalina/startup/HostConfig$DeployDirectory:config	Lorg/apache/catalina/startup/HostConfig;
/*      */       //   4: aload_0
/*      */       //   5: getfield 3	org/apache/catalina/startup/HostConfig$DeployDirectory:cn	Lorg/apache/catalina/util/ContextName;
/*      */       //   8: aload_0
/*      */       //   9: getfield 4	org/apache/catalina/startup/HostConfig$DeployDirectory:dir	Ljava/io/File;
/*      */       //   12: invokevirtual 5	org/apache/catalina/startup/HostConfig:deployDirectory	(Lorg/apache/catalina/util/ContextName;Ljava/io/File;)V
/*      */       //   15: aload_0
/*      */       //   16: getfield 2	org/apache/catalina/startup/HostConfig$DeployDirectory:config	Lorg/apache/catalina/startup/HostConfig;
/*      */       //   19: aload_0
/*      */       //   20: getfield 3	org/apache/catalina/startup/HostConfig$DeployDirectory:cn	Lorg/apache/catalina/util/ContextName;
/*      */       //   23: invokevirtual 6	org/apache/catalina/util/ContextName:getName	()Ljava/lang/String;
/*      */       //   26: invokevirtual 7	org/apache/catalina/startup/HostConfig:removeServiced	(Ljava/lang/String;)V
/*      */       //   29: goto +20 -> 49
/*      */       //   32: astore_1
/*      */       //   33: aload_0
/*      */       //   34: getfield 2	org/apache/catalina/startup/HostConfig$DeployDirectory:config	Lorg/apache/catalina/startup/HostConfig;
/*      */       //   37: aload_0
/*      */       //   38: getfield 3	org/apache/catalina/startup/HostConfig$DeployDirectory:cn	Lorg/apache/catalina/util/ContextName;
/*      */       //   41: invokevirtual 6	org/apache/catalina/util/ContextName:getName	()Ljava/lang/String;
/*      */       //   44: invokevirtual 7	org/apache/catalina/startup/HostConfig:removeServiced	(Ljava/lang/String;)V
/*      */       //   47: aload_1
/*      */       //   48: athrow
/*      */       //   49: return
/*      */       // Line number table:
/*      */       //   Java source line #1933	-> byte code offset #0
/*      */       //   Java source line #1935	-> byte code offset #15
/*      */       //   Java source line #1936	-> byte code offset #29
/*      */       //   Java source line #1935	-> byte code offset #32
/*      */       //   Java source line #1936	-> byte code offset #47
/*      */       //   Java source line #1937	-> byte code offset #49
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	signature
/*      */       //   0	50	0	this	DeployDirectory
/*      */       //   32	16	1	localObject	Object
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   0	15	32	finally
/*      */     }
/*      */   }
/*      */   
/*      */   private static class ExpandedDirectoryRemovalListener
/*      */     implements LifecycleListener
/*      */   {
/*      */     private final File toDelete;
/*      */     private final String newDocBase;
/*      */     
/*      */     public ExpandedDirectoryRemovalListener(File toDelete, String newDocBase)
/*      */     {
/* 1967 */       this.toDelete = toDelete;
/* 1968 */       this.newDocBase = newDocBase;
/*      */     }
/*      */     
/*      */     public void lifecycleEvent(LifecycleEvent event)
/*      */     {
/* 1973 */       if ("after_stop".equals(event.getType()))
/*      */       {
/* 1975 */         Context context = (Context)event.getLifecycle();
/*      */         
/*      */ 
/* 1978 */         ExpandWar.delete(this.toDelete);
/*      */         
/*      */ 
/* 1981 */         context.setDocBase(this.newDocBase);
/*      */         
/*      */ 
/*      */ 
/* 1985 */         context.removeLifecycleListener(this);
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\HostConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */