/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.WriteListener;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.CloseNowException;
/*     */ import org.apache.coyote.Constants;
/*     */ import org.apache.coyote.Response;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.buf.C2BConverter;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OutputBuffer
/*     */   extends Writer
/*     */ {
/*  52 */   private static final StringManager sm = StringManager.getManager(OutputBuffer.class);
/*     */   
/*     */ 
/*     */ 
/*     */   public static final int DEFAULT_BUFFER_SIZE = 8192;
/*     */   
/*     */ 
/*  59 */   private final Map<Charset, C2BConverter> encoders = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int defaultBufferSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ByteBuffer bb;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final CharBuffer cb;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */   private boolean initial = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   private long bytesWritten = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   private long charsWritten = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   private volatile boolean closed = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private boolean doFlush = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected C2BConverter conv;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Response coyoteResponse;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */   private volatile boolean suspended = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OutputBuffer(int size)
/*     */   {
/* 137 */     this.defaultBufferSize = size;
/* 138 */     this.bb = ByteBuffer.allocate(size);
/* 139 */     clear(this.bb);
/* 140 */     this.cb = CharBuffer.allocate(size);
/* 141 */     clear(this.cb);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResponse(Response coyoteResponse)
/*     */   {
/* 153 */     this.coyoteResponse = coyoteResponse;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSuspended()
/*     */   {
/* 163 */     return this.suspended;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSuspended(boolean suspended)
/*     */   {
/* 173 */     this.suspended = suspended;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isClosed()
/*     */   {
/* 183 */     return this.closed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void recycle()
/*     */   {
/* 194 */     this.initial = true;
/* 195 */     this.bytesWritten = 0L;
/* 196 */     this.charsWritten = 0L;
/*     */     
/* 198 */     if (this.bb.capacity() > 16 * this.defaultBufferSize)
/*     */     {
/* 200 */       this.bb = ByteBuffer.allocate(this.defaultBufferSize);
/*     */     }
/* 202 */     clear(this.bb);
/* 203 */     clear(this.cb);
/* 204 */     this.closed = false;
/* 205 */     this.suspended = false;
/* 206 */     this.doFlush = false;
/*     */     
/* 208 */     if (this.conv != null) {
/* 209 */       this.conv.recycle();
/* 210 */       this.conv = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 224 */     if (this.closed) {
/* 225 */       return;
/*     */     }
/* 227 */     if (this.suspended) {
/* 228 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 233 */     if (this.cb.remaining() > 0) {
/* 234 */       flushCharBuffer();
/*     */     }
/*     */     
/* 237 */     if ((!this.coyoteResponse.isCommitted()) && (this.coyoteResponse.getContentLengthLong() == -1L) && 
/* 238 */       (!this.coyoteResponse.getRequest().method().equals("HEAD")))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 244 */       if (!this.coyoteResponse.isCommitted()) {
/* 245 */         this.coyoteResponse.setContentLength(this.bb.remaining());
/*     */       }
/*     */     }
/*     */     
/* 249 */     if (this.coyoteResponse.getStatus() == 101) {
/* 250 */       doFlush(true);
/*     */     } else {
/* 252 */       doFlush(false);
/*     */     }
/* 254 */     this.closed = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 259 */     Request req = (Request)this.coyoteResponse.getRequest().getNote(1);
/* 260 */     req.inputBuffer.close();
/*     */     
/* 262 */     this.coyoteResponse.action(ActionCode.CLOSE, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 273 */     doFlush(true);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected void doFlush(boolean realFlush)
/*     */     throws IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 10	org/apache/catalina/connector/OutputBuffer:suspended	Z
/*     */     //   4: ifeq +4 -> 8
/*     */     //   7: return
/*     */     //   8: aload_0
/*     */     //   9: iconst_1
/*     */     //   10: putfield 9	org/apache/catalina/connector/OutputBuffer:doFlush	Z
/*     */     //   13: aload_0
/*     */     //   14: getfield 5	org/apache/catalina/connector/OutputBuffer:initial	Z
/*     */     //   17: ifeq +15 -> 32
/*     */     //   20: aload_0
/*     */     //   21: getfield 17	org/apache/catalina/connector/OutputBuffer:coyoteResponse	Lorg/apache/coyote/Response;
/*     */     //   24: invokevirtual 43	org/apache/coyote/Response:sendHeaders	()V
/*     */     //   27: aload_0
/*     */     //   28: iconst_0
/*     */     //   29: putfield 5	org/apache/catalina/connector/OutputBuffer:initial	Z
/*     */     //   32: aload_0
/*     */     //   33: getfield 16	org/apache/catalina/connector/OutputBuffer:cb	Ljava/nio/CharBuffer;
/*     */     //   36: invokevirtual 21	java/nio/CharBuffer:remaining	()I
/*     */     //   39: ifle +7 -> 46
/*     */     //   42: aload_0
/*     */     //   43: invokespecial 22	org/apache/catalina/connector/OutputBuffer:flushCharBuffer	()V
/*     */     //   46: aload_0
/*     */     //   47: getfield 13	org/apache/catalina/connector/OutputBuffer:bb	Ljava/nio/ByteBuffer;
/*     */     //   50: invokevirtual 31	java/nio/ByteBuffer:remaining	()I
/*     */     //   53: ifle +7 -> 60
/*     */     //   56: aload_0
/*     */     //   57: invokespecial 44	org/apache/catalina/connector/OutputBuffer:flushByteBuffer	()V
/*     */     //   60: aload_0
/*     */     //   61: iconst_0
/*     */     //   62: putfield 9	org/apache/catalina/connector/OutputBuffer:doFlush	Z
/*     */     //   65: goto +11 -> 76
/*     */     //   68: astore_2
/*     */     //   69: aload_0
/*     */     //   70: iconst_0
/*     */     //   71: putfield 9	org/apache/catalina/connector/OutputBuffer:doFlush	Z
/*     */     //   74: aload_2
/*     */     //   75: athrow
/*     */     //   76: iload_1
/*     */     //   77: ifeq +39 -> 116
/*     */     //   80: aload_0
/*     */     //   81: getfield 17	org/apache/catalina/connector/OutputBuffer:coyoteResponse	Lorg/apache/coyote/Response;
/*     */     //   84: getstatic 45	org/apache/coyote/ActionCode:CLIENT_FLUSH	Lorg/apache/coyote/ActionCode;
/*     */     //   87: aconst_null
/*     */     //   88: invokevirtual 42	org/apache/coyote/Response:action	(Lorg/apache/coyote/ActionCode;Ljava/lang/Object;)V
/*     */     //   91: aload_0
/*     */     //   92: getfield 17	org/apache/catalina/connector/OutputBuffer:coyoteResponse	Lorg/apache/coyote/Response;
/*     */     //   95: invokevirtual 46	org/apache/coyote/Response:isExceptionPresent	()Z
/*     */     //   98: ifeq +18 -> 116
/*     */     //   101: new 47	org/apache/catalina/connector/ClientAbortException
/*     */     //   104: dup
/*     */     //   105: aload_0
/*     */     //   106: getfield 17	org/apache/catalina/connector/OutputBuffer:coyoteResponse	Lorg/apache/coyote/Response;
/*     */     //   109: invokevirtual 48	org/apache/coyote/Response:getErrorException	()Ljava/lang/Exception;
/*     */     //   112: invokespecial 49	org/apache/catalina/connector/ClientAbortException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   115: athrow
/*     */     //   116: return
/*     */     // Line number table:
/*     */     //   Java source line #285	-> byte code offset #0
/*     */     //   Java source line #286	-> byte code offset #7
/*     */     //   Java source line #290	-> byte code offset #8
/*     */     //   Java source line #291	-> byte code offset #13
/*     */     //   Java source line #292	-> byte code offset #20
/*     */     //   Java source line #293	-> byte code offset #27
/*     */     //   Java source line #295	-> byte code offset #32
/*     */     //   Java source line #296	-> byte code offset #42
/*     */     //   Java source line #298	-> byte code offset #46
/*     */     //   Java source line #299	-> byte code offset #56
/*     */     //   Java source line #302	-> byte code offset #60
/*     */     //   Java source line #303	-> byte code offset #65
/*     */     //   Java source line #302	-> byte code offset #68
/*     */     //   Java source line #303	-> byte code offset #74
/*     */     //   Java source line #305	-> byte code offset #76
/*     */     //   Java source line #306	-> byte code offset #80
/*     */     //   Java source line #309	-> byte code offset #91
/*     */     //   Java source line #310	-> byte code offset #101
/*     */     //   Java source line #314	-> byte code offset #116
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	117	0	this	OutputBuffer
/*     */     //   0	117	1	realFlush	boolean
/*     */     //   68	7	2	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   8	60	68	finally
/*     */   }
/*     */   
/*     */   public void realWriteBytes(ByteBuffer buf)
/*     */     throws IOException
/*     */   {
/* 329 */     if (this.closed) {
/* 330 */       return;
/*     */     }
/* 332 */     if (this.coyoteResponse == null) {
/* 333 */       return;
/*     */     }
/*     */     
/*     */ 
/* 337 */     if (buf.remaining() > 0) {
/*     */       try
/*     */       {
/* 340 */         this.coyoteResponse.doWrite(buf);
/*     */ 
/*     */       }
/*     */       catch (CloseNowException e)
/*     */       {
/*     */ 
/* 346 */         this.closed = true;
/* 347 */         throw e;
/*     */ 
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 352 */         this.coyoteResponse.setErrorException(e);
/* 353 */         throw new ClientAbortException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 362 */     if (this.suspended) {
/* 363 */       return;
/*     */     }
/*     */     
/* 366 */     writeBytes(b, off, len);
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(ByteBuffer from)
/*     */     throws IOException
/*     */   {
/* 373 */     if (this.suspended) {
/* 374 */       return;
/*     */     }
/*     */     
/* 377 */     writeBytes(from);
/*     */   }
/*     */   
/*     */ 
/*     */   private void writeBytes(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 384 */     if (this.closed) {
/* 385 */       return;
/*     */     }
/*     */     
/* 388 */     append(b, off, len);
/* 389 */     this.bytesWritten += len;
/*     */     
/*     */ 
/*     */ 
/* 393 */     if (this.doFlush) {
/* 394 */       flushByteBuffer();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void writeBytes(ByteBuffer from)
/*     */     throws IOException
/*     */   {
/* 402 */     if (this.closed) {
/* 403 */       return;
/*     */     }
/*     */     
/* 406 */     append(from);
/* 407 */     this.bytesWritten += from.remaining();
/*     */     
/*     */ 
/*     */ 
/* 411 */     if (this.doFlush) {
/* 412 */       flushByteBuffer();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeByte(int b)
/*     */     throws IOException
/*     */   {
/* 420 */     if (this.suspended) {
/* 421 */       return;
/*     */     }
/*     */     
/* 424 */     if (isFull(this.bb)) {
/* 425 */       flushByteBuffer();
/*     */     }
/*     */     
/* 428 */     transfer((byte)b, this.bb);
/* 429 */     this.bytesWritten += 1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void realWriteChars(CharBuffer from)
/*     */     throws IOException
/*     */   {
/* 446 */     while (from.remaining() > 0) {
/* 447 */       this.conv.convert(from, this.bb);
/* 448 */       if (this.bb.remaining() == 0) {
/*     */         break;
/*     */       }
/*     */       
/* 452 */       if (from.remaining() > 0) {
/* 453 */         flushByteBuffer();
/* 454 */       } else if ((this.conv.isUndeflow()) && (this.bb.limit() > this.bb.capacity() - 4))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 463 */         flushByteBuffer();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(int c)
/*     */     throws IOException
/*     */   {
/* 472 */     if (this.suspended) {
/* 473 */       return;
/*     */     }
/*     */     
/* 476 */     if (isFull(this.cb)) {
/* 477 */       flushCharBuffer();
/*     */     }
/*     */     
/* 480 */     transfer((char)c, this.cb);
/* 481 */     this.charsWritten += 1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void write(char[] c)
/*     */     throws IOException
/*     */   {
/* 489 */     if (this.suspended) {
/* 490 */       return;
/*     */     }
/*     */     
/* 493 */     write(c, 0, c.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void write(char[] c, int off, int len)
/*     */     throws IOException
/*     */   {
/* 501 */     if (this.suspended) {
/* 502 */       return;
/*     */     }
/*     */     
/* 505 */     append(c, off, len);
/* 506 */     this.charsWritten += len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(String s, int off, int len)
/*     */     throws IOException
/*     */   {
/* 517 */     if (this.suspended) {
/* 518 */       return;
/*     */     }
/*     */     
/* 521 */     if (s == null) {
/* 522 */       throw new NullPointerException(sm.getString("outputBuffer.writeNull"));
/*     */     }
/*     */     
/* 525 */     int sOff = off;
/* 526 */     int sEnd = off + len;
/* 527 */     while (sOff < sEnd) {
/* 528 */       int n = transfer(s, sOff, sEnd - sOff, this.cb);
/* 529 */       sOff += n;
/* 530 */       if ((sOff < sEnd) && (isFull(this.cb))) {
/* 531 */         flushCharBuffer();
/*     */       }
/*     */     }
/*     */     
/* 535 */     this.charsWritten += len;
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(String s)
/*     */     throws IOException
/*     */   {
/* 542 */     if (this.suspended) {
/* 543 */       return;
/*     */     }
/*     */     
/* 546 */     if (s == null) {
/* 547 */       s = "null";
/*     */     }
/* 549 */     write(s, 0, s.length());
/*     */   }
/*     */   
/*     */   public void checkConverter() throws IOException
/*     */   {
/* 554 */     if (this.conv != null) {
/* 555 */       return;
/*     */     }
/*     */     
/* 558 */     Charset charset = null;
/*     */     
/* 560 */     if (this.coyoteResponse != null) {
/* 561 */       charset = this.coyoteResponse.getCharset();
/*     */     }
/*     */     
/* 564 */     if (charset == null) {
/* 565 */       if (this.coyoteResponse.getCharacterEncoding() != null)
/*     */       {
/*     */ 
/* 568 */         charset = B2CConverter.getCharset(this.coyoteResponse.getCharacterEncoding());
/*     */       }
/* 570 */       charset = Constants.DEFAULT_BODY_CHARSET;
/*     */     }
/*     */     
/* 573 */     this.conv = ((C2BConverter)this.encoders.get(charset));
/*     */     
/* 575 */     if (this.conv == null) {
/* 576 */       this.conv = createConverter(charset);
/* 577 */       this.encoders.put(charset, this.conv);
/*     */     }
/*     */   }
/*     */   
/*     */   private static C2BConverter createConverter(Charset charset) throws IOException
/*     */   {
/* 583 */     if (Globals.IS_SECURITY_ENABLED) {
/*     */       try {
/* 585 */         return (C2BConverter)AccessController.doPrivileged(new PrivilegedCreateConverter(charset));
/*     */       } catch (PrivilegedActionException ex) {
/* 587 */         Exception e = ex.getException();
/* 588 */         if ((e instanceof IOException)) {
/* 589 */           throw ((IOException)e);
/*     */         }
/* 591 */         throw new IOException(ex);
/*     */       }
/*     */     }
/*     */     
/* 595 */     return new C2BConverter(charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getContentWritten()
/*     */   {
/* 603 */     return this.bytesWritten + this.charsWritten;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNew()
/*     */   {
/* 613 */     return (this.bytesWritten == 0L) && (this.charsWritten == 0L);
/*     */   }
/*     */   
/*     */   public void setBufferSize(int size)
/*     */   {
/* 618 */     if (size > this.bb.capacity()) {
/* 619 */       this.bb = ByteBuffer.allocate(size);
/* 620 */       clear(this.bb);
/*     */     }
/*     */   }
/*     */   
/*     */   public void reset()
/*     */   {
/* 626 */     reset(false);
/*     */   }
/*     */   
/*     */   public void reset(boolean resetWriterStreamFlags) {
/* 630 */     clear(this.bb);
/* 631 */     clear(this.cb);
/* 632 */     this.bytesWritten = 0L;
/* 633 */     this.charsWritten = 0L;
/* 634 */     if (resetWriterStreamFlags) {
/* 635 */       if (this.conv != null) {
/* 636 */         this.conv.recycle();
/*     */       }
/* 638 */       this.conv = null;
/*     */     }
/* 640 */     this.initial = true;
/*     */   }
/*     */   
/*     */   public int getBufferSize()
/*     */   {
/* 645 */     return this.bb.capacity();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReady()
/*     */   {
/* 655 */     return this.coyoteResponse.isReady();
/*     */   }
/*     */   
/*     */   public void setWriteListener(WriteListener listener)
/*     */   {
/* 660 */     this.coyoteResponse.setWriteListener(listener);
/*     */   }
/*     */   
/*     */   public boolean isBlocking()
/*     */   {
/* 665 */     return this.coyoteResponse.getWriteListener() == null;
/*     */   }
/*     */   
/*     */   public void checkRegisterForWrite() {
/* 669 */     this.coyoteResponse.checkRegisterForWrite();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void append(byte[] src, int off, int len)
/*     */     throws IOException
/*     */   {
/* 681 */     if (this.bb.remaining() == 0) {
/* 682 */       appendByteArray(src, off, len);
/*     */     } else {
/* 684 */       int n = transfer(src, off, len, this.bb);
/* 685 */       len -= n;
/* 686 */       off += n;
/* 687 */       if ((len > 0) && (isFull(this.bb))) {
/* 688 */         flushByteBuffer();
/* 689 */         appendByteArray(src, off, len);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void append(char[] src, int off, int len)
/*     */     throws IOException
/*     */   {
/* 703 */     if (len <= this.cb.capacity() - this.cb.limit()) {
/* 704 */       transfer(src, off, len, this.cb);
/* 705 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 714 */     if (len + this.cb.limit() < 2 * this.cb.capacity())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 719 */       int n = transfer(src, off, len, this.cb);
/*     */       
/* 721 */       flushCharBuffer();
/*     */       
/* 723 */       transfer(src, off + n, len - n, this.cb);
/*     */     }
/*     */     else
/*     */     {
/* 727 */       flushCharBuffer();
/*     */       
/* 729 */       realWriteChars(CharBuffer.wrap(src, off, len));
/*     */     }
/*     */   }
/*     */   
/*     */   public void append(ByteBuffer from) throws IOException
/*     */   {
/* 735 */     if (this.bb.remaining() == 0) {
/* 736 */       appendByteBuffer(from);
/*     */     } else {
/* 738 */       transfer(from, this.bb);
/* 739 */       if ((from.hasRemaining()) && (isFull(this.bb))) {
/* 740 */         flushByteBuffer();
/* 741 */         appendByteBuffer(from);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void appendByteArray(byte[] src, int off, int len) throws IOException {
/* 747 */     if (len == 0) {
/* 748 */       return;
/*     */     }
/*     */     
/* 751 */     int limit = this.bb.capacity();
/* 752 */     while (len > limit) {
/* 753 */       realWriteBytes(ByteBuffer.wrap(src, off, limit));
/* 754 */       len -= limit;
/* 755 */       off += limit;
/*     */     }
/*     */     
/* 758 */     if (len > 0) {
/* 759 */       transfer(src, off, len, this.bb);
/*     */     }
/*     */   }
/*     */   
/*     */   private void appendByteBuffer(ByteBuffer from) throws IOException {
/* 764 */     if (from.remaining() == 0) {
/* 765 */       return;
/*     */     }
/*     */     
/* 768 */     int limit = this.bb.capacity();
/* 769 */     int fromLimit = from.limit();
/* 770 */     while (from.remaining() > limit) {
/* 771 */       from.limit(from.position() + limit);
/* 772 */       realWriteBytes(from.slice());
/* 773 */       from.position(from.limit());
/* 774 */       from.limit(fromLimit);
/*     */     }
/*     */     
/* 777 */     if (from.remaining() > 0) {
/* 778 */       transfer(from, this.bb);
/*     */     }
/*     */   }
/*     */   
/*     */   private void flushByteBuffer() throws IOException {
/* 783 */     realWriteBytes(this.bb.slice());
/* 784 */     clear(this.bb);
/*     */   }
/*     */   
/*     */   private void flushCharBuffer() throws IOException {
/* 788 */     realWriteChars(this.cb.slice());
/* 789 */     clear(this.cb);
/*     */   }
/*     */   
/*     */   private void transfer(byte b, ByteBuffer to) {
/* 793 */     toWriteMode(to);
/* 794 */     to.put(b);
/* 795 */     toReadMode(to);
/*     */   }
/*     */   
/*     */   private void transfer(char b, CharBuffer to) {
/* 799 */     toWriteMode(to);
/* 800 */     to.put(b);
/* 801 */     toReadMode(to);
/*     */   }
/*     */   
/*     */   private int transfer(byte[] buf, int off, int len, ByteBuffer to) {
/* 805 */     toWriteMode(to);
/* 806 */     int max = Math.min(len, to.remaining());
/* 807 */     if (max > 0) {
/* 808 */       to.put(buf, off, max);
/*     */     }
/* 810 */     toReadMode(to);
/* 811 */     return max;
/*     */   }
/*     */   
/*     */   private int transfer(char[] buf, int off, int len, CharBuffer to) {
/* 815 */     toWriteMode(to);
/* 816 */     int max = Math.min(len, to.remaining());
/* 817 */     if (max > 0) {
/* 818 */       to.put(buf, off, max);
/*     */     }
/* 820 */     toReadMode(to);
/* 821 */     return max;
/*     */   }
/*     */   
/*     */   private int transfer(String s, int off, int len, CharBuffer to) {
/* 825 */     toWriteMode(to);
/* 826 */     int max = Math.min(len, to.remaining());
/* 827 */     if (max > 0) {
/* 828 */       to.put(s, off, off + max);
/*     */     }
/* 830 */     toReadMode(to);
/* 831 */     return max;
/*     */   }
/*     */   
/*     */   private void transfer(ByteBuffer from, ByteBuffer to) {
/* 835 */     toWriteMode(to);
/* 836 */     int max = Math.min(from.remaining(), to.remaining());
/* 837 */     if (max > 0) {
/* 838 */       int fromLimit = from.limit();
/* 839 */       from.limit(from.position() + max);
/* 840 */       to.put(from);
/* 841 */       from.limit(fromLimit);
/*     */     }
/* 843 */     toReadMode(to);
/*     */   }
/*     */   
/*     */   private void clear(Buffer buffer) {
/* 847 */     buffer.rewind().limit(0);
/*     */   }
/*     */   
/*     */   private boolean isFull(Buffer buffer) {
/* 851 */     return buffer.limit() == buffer.capacity();
/*     */   }
/*     */   
/*     */   private void toReadMode(Buffer buffer)
/*     */   {
/* 856 */     buffer.limit(buffer.position()).reset();
/*     */   }
/*     */   
/*     */ 
/*     */   private void toWriteMode(Buffer buffer)
/*     */   {
/* 862 */     buffer.mark().position(buffer.limit()).limit(buffer.capacity());
/*     */   }
/*     */   
/*     */   private static class PrivilegedCreateConverter
/*     */     implements PrivilegedExceptionAction<C2BConverter>
/*     */   {
/*     */     private final Charset charset;
/*     */     
/*     */     public PrivilegedCreateConverter(Charset charset)
/*     */     {
/* 872 */       this.charset = charset;
/*     */     }
/*     */     
/*     */     public C2BConverter run() throws IOException
/*     */     {
/* 877 */       return new C2BConverter(this.charset);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\connector\OutputBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */