/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*      */ import javax.management.ListenerNotFoundException;
/*      */ import javax.management.MBeanNotificationInfo;
/*      */ import javax.management.Notification;
/*      */ import javax.management.NotificationBroadcasterSupport;
/*      */ import javax.management.NotificationEmitter;
/*      */ import javax.management.NotificationFilter;
/*      */ import javax.management.NotificationListener;
/*      */ import javax.management.ObjectName;
/*      */ import javax.servlet.MultipartConfigElement;
/*      */ import javax.servlet.Servlet;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.SingleThreadModel;
/*      */ import javax.servlet.UnavailableException;
/*      */ import javax.servlet.annotation.MultipartConfig;
/*      */ import javax.servlet.http.HttpServlet;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.ContainerServlet;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.security.SecurityUtil;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.PeriodicEventListener;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.log.SystemLogHandler;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.modeler.Util;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StandardWrapper
/*      */   extends ContainerBase
/*      */   implements ServletConfig, Wrapper, NotificationEmitter
/*      */ {
/*   77 */   private final Log log = LogFactory.getLog(StandardWrapper.class);
/*      */   
/*   79 */   protected static final String[] DEFAULT_SERVLET_METHODS = { "GET", "HEAD", "POST" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StandardWrapper()
/*      */   {
/*   91 */     this.swValve = new StandardWrapperValve();
/*   92 */     this.pipeline.setBasic(this.swValve);
/*   93 */     this.broadcaster = new NotificationBroadcasterSupport();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  107 */   protected long available = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final NotificationBroadcasterSupport broadcaster;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  118 */   protected final AtomicInteger countAllocated = new AtomicInteger(0);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  124 */   protected final StandardWrapperFacade facade = new StandardWrapperFacade(this);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  130 */   protected volatile Servlet instance = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  136 */   protected volatile boolean instanceInitialized = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  143 */   protected int loadOnStartup = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  149 */   protected final ArrayList<String> mappings = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  156 */   protected HashMap<String, String> parameters = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  164 */   protected HashMap<String, String> references = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  170 */   protected String runAs = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  175 */   protected long sequenceNumber = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  180 */   protected String servletClass = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  188 */   protected volatile boolean singleThreadModel = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  195 */   protected volatile boolean unloading = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  203 */   protected int maxInstances = 20;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  212 */   protected int nInstances = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  221 */   protected Stack<Servlet> instancePool = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  228 */   protected long unloadDelay = 2000L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isJspServlet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectName jspMonitorON;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  246 */   protected boolean swallowOutput = false;
/*      */   
/*      */   protected StandardWrapperValve swValve;
/*      */   
/*  250 */   protected long loadTime = 0L;
/*  251 */   protected int classLoadTime = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  256 */   protected MultipartConfigElement multipartConfigElement = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  261 */   protected boolean asyncSupported = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  266 */   protected boolean enabled = true;
/*      */   
/*  268 */   private boolean overridable = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  274 */   protected static Class<?>[] classType = { ServletConfig.class };
/*      */   
/*  276 */   private final ReentrantReadWriteLock parametersLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*  279 */   private final ReentrantReadWriteLock mappingsLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*  282 */   private final ReentrantReadWriteLock referencesLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*      */   protected MBeanNotificationInfo[] notificationInfo;
/*      */   
/*      */ 
/*      */   public boolean isOverridable()
/*      */   {
/*  290 */     return this.overridable;
/*      */   }
/*      */   
/*      */   public void setOverridable(boolean overridable)
/*      */   {
/*  295 */     this.overridable = overridable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getAvailable()
/*      */   {
/*  308 */     return this.available;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAvailable(long available)
/*      */   {
/*  323 */     long oldAvailable = this.available;
/*  324 */     if (available > System.currentTimeMillis()) {
/*  325 */       this.available = available;
/*      */     } else {
/*  327 */       this.available = 0L;
/*      */     }
/*  329 */     this.support.firePropertyChange("available", Long.valueOf(oldAvailable), 
/*  330 */       Long.valueOf(this.available));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCountAllocated()
/*      */   {
/*  340 */     return this.countAllocated.get();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLoadOnStartup()
/*      */   {
/*  351 */     if ((this.isJspServlet) && (this.loadOnStartup == -1))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  357 */       return Integer.MAX_VALUE;
/*      */     }
/*  359 */     return this.loadOnStartup;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLoadOnStartup(int value)
/*      */   {
/*  373 */     int oldLoadOnStartup = this.loadOnStartup;
/*  374 */     this.loadOnStartup = value;
/*  375 */     this.support.firePropertyChange("loadOnStartup", 
/*  376 */       Integer.valueOf(oldLoadOnStartup), 
/*  377 */       Integer.valueOf(this.loadOnStartup));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLoadOnStartupString(String value)
/*      */   {
/*      */     try
/*      */     {
/*  394 */       setLoadOnStartup(Integer.parseInt(value));
/*      */     } catch (NumberFormatException e) {
/*  396 */       setLoadOnStartup(0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getLoadOnStartupString()
/*      */   {
/*  404 */     return Integer.toString(getLoadOnStartup());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public int getMaxInstances()
/*      */   {
/*  416 */     return this.maxInstances;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setMaxInstances(int maxInstances)
/*      */   {
/*  431 */     int oldMaxInstances = this.maxInstances;
/*  432 */     this.maxInstances = maxInstances;
/*  433 */     this.support.firePropertyChange("maxInstances", oldMaxInstances, this.maxInstances);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParent(Container container)
/*      */   {
/*  447 */     if ((container != null) && (!(container instanceof Context)))
/*      */     {
/*      */ 
/*  450 */       throw new IllegalArgumentException(sm.getString("standardWrapper.notContext"));
/*      */     }
/*  452 */     if ((container instanceof StandardContext)) {
/*  453 */       this.swallowOutput = ((StandardContext)container).getSwallowOutput();
/*  454 */       this.unloadDelay = ((StandardContext)container).getUnloadDelay();
/*      */     }
/*  456 */     super.setParent(container);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRunAs()
/*      */   {
/*  466 */     return this.runAs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRunAs(String runAs)
/*      */   {
/*  478 */     String oldRunAs = this.runAs;
/*  479 */     this.runAs = runAs;
/*  480 */     this.support.firePropertyChange("runAs", oldRunAs, this.runAs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServletClass()
/*      */   {
/*  490 */     return this.servletClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServletClass(String servletClass)
/*      */   {
/*  502 */     String oldServletClass = this.servletClass;
/*  503 */     this.servletClass = servletClass;
/*  504 */     this.support.firePropertyChange("servletClass", oldServletClass, this.servletClass);
/*      */     
/*  506 */     if ("org.apache.jasper.servlet.JspServlet".equals(servletClass)) {
/*  507 */       this.isJspServlet = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServletName(String name)
/*      */   {
/*  523 */     setName(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public Boolean isSingleThreadModel()
/*      */   {
/*  544 */     if ((this.singleThreadModel) || (this.instance != null)) {
/*  545 */       return Boolean.valueOf(this.singleThreadModel);
/*      */     }
/*  547 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUnavailable()
/*      */   {
/*  557 */     if (!isEnabled())
/*  558 */       return true;
/*  559 */     if (this.available == 0L)
/*  560 */       return false;
/*  561 */     if (this.available <= System.currentTimeMillis()) {
/*  562 */       this.available = 0L;
/*  563 */       return false;
/*      */     }
/*  565 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getServletMethods()
/*      */     throws ServletException
/*      */   {
/*  574 */     this.instance = loadServlet();
/*      */     
/*  576 */     Class<? extends Servlet> servletClazz = this.instance.getClass();
/*  577 */     if (!HttpServlet.class.isAssignableFrom(servletClazz))
/*      */     {
/*  579 */       return DEFAULT_SERVLET_METHODS;
/*      */     }
/*      */     
/*  582 */     Set<String> allow = new HashSet();
/*  583 */     allow.add("OPTIONS");
/*      */     
/*  585 */     if (this.isJspServlet) {
/*  586 */       allow.add("GET");
/*  587 */       allow.add("HEAD");
/*  588 */       allow.add("POST");
/*      */     } else {
/*  590 */       allow.add("TRACE");
/*      */       
/*  592 */       Method[] methods = getAllDeclaredMethods(servletClazz);
/*  593 */       for (int i = 0; (methods != null) && (i < methods.length); i++) {
/*  594 */         Method m = methods[i];
/*      */         
/*  596 */         if (m.getName().equals("doGet")) {
/*  597 */           allow.add("GET");
/*  598 */           allow.add("HEAD");
/*  599 */         } else if (m.getName().equals("doPost")) {
/*  600 */           allow.add("POST");
/*  601 */         } else if (m.getName().equals("doPut")) {
/*  602 */           allow.add("PUT");
/*  603 */         } else if (m.getName().equals("doDelete")) {
/*  604 */           allow.add("DELETE");
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  609 */     String[] methodNames = new String[allow.size()];
/*  610 */     return (String[])allow.toArray(methodNames);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Servlet getServlet()
/*      */   {
/*  619 */     return this.instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServlet(Servlet servlet)
/*      */   {
/*  628 */     this.instance = servlet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void backgroundProcess()
/*      */   {
/*  641 */     super.backgroundProcess();
/*      */     
/*  643 */     if (!getState().isAvailable()) {
/*  644 */       return;
/*      */     }
/*      */     
/*  647 */     if ((getServlet() instanceof PeriodicEventListener)) {
/*  648 */       ((PeriodicEventListener)getServlet()).periodicEvent();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Throwable getRootCause(ServletException e)
/*      */   {
/*  660 */     Throwable rootCause = e;
/*  661 */     Throwable rootCauseCheck = null;
/*      */     
/*  663 */     int loops = 0;
/*      */     do {
/*  665 */       loops++;
/*  666 */       rootCauseCheck = rootCause.getCause();
/*  667 */       if (rootCauseCheck != null) {
/*  668 */         rootCause = rootCauseCheck;
/*      */       }
/*  670 */     } while ((rootCauseCheck != null) && (loops < 20));
/*  671 */     return rootCause;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addChild(Container child)
/*      */   {
/*  685 */     throw new IllegalStateException(sm.getString("standardWrapper.notChild"));
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void addInitParameter(String name, String value)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 42	org/apache/catalina/core/StandardWrapper:parametersLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   4: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   7: invokevirtual 125	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:lock	()V
/*      */     //   10: aload_0
/*      */     //   11: getfield 20	org/apache/catalina/core/StandardWrapper:parameters	Ljava/util/HashMap;
/*      */     //   14: aload_1
/*      */     //   15: aload_2
/*      */     //   16: invokevirtual 126	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   19: pop
/*      */     //   20: aload_0
/*      */     //   21: getfield 42	org/apache/catalina/core/StandardWrapper:parametersLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   24: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   27: invokevirtual 127	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/*      */     //   30: goto +16 -> 46
/*      */     //   33: astore_3
/*      */     //   34: aload_0
/*      */     //   35: getfield 42	org/apache/catalina/core/StandardWrapper:parametersLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   38: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   41: invokevirtual 127	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/*      */     //   44: aload_3
/*      */     //   45: athrow
/*      */     //   46: aload_0
/*      */     //   47: ldc -128
/*      */     //   49: aload_1
/*      */     //   50: invokevirtual 129	org/apache/catalina/core/StandardWrapper:fireContainerEvent	(Ljava/lang/String;Ljava/lang/Object;)V
/*      */     //   53: return
/*      */     // Line number table:
/*      */     //   Java source line #699	-> byte code offset #0
/*      */     //   Java source line #701	-> byte code offset #10
/*      */     //   Java source line #703	-> byte code offset #20
/*      */     //   Java source line #704	-> byte code offset #30
/*      */     //   Java source line #703	-> byte code offset #33
/*      */     //   Java source line #704	-> byte code offset #44
/*      */     //   Java source line #705	-> byte code offset #46
/*      */     //   Java source line #707	-> byte code offset #53
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	54	0	this	StandardWrapper
/*      */     //   0	54	1	name	String
/*      */     //   0	54	2	value	String
/*      */     //   33	12	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   10	20	33	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void addMapping(String mapping)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 43	org/apache/catalina/core/StandardWrapper:mappingsLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   4: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   7: invokevirtual 125	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:lock	()V
/*      */     //   10: aload_0
/*      */     //   11: getfield 17	org/apache/catalina/core/StandardWrapper:mappings	Ljava/util/ArrayList;
/*      */     //   14: aload_1
/*      */     //   15: invokevirtual 130	java/util/ArrayList:add	(Ljava/lang/Object;)Z
/*      */     //   18: pop
/*      */     //   19: aload_0
/*      */     //   20: getfield 43	org/apache/catalina/core/StandardWrapper:mappingsLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   23: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   26: invokevirtual 127	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/*      */     //   29: goto +16 -> 45
/*      */     //   32: astore_2
/*      */     //   33: aload_0
/*      */     //   34: getfield 43	org/apache/catalina/core/StandardWrapper:mappingsLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   37: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   40: invokevirtual 127	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/*      */     //   43: aload_2
/*      */     //   44: athrow
/*      */     //   45: aload_0
/*      */     //   46: getfield 131	org/apache/catalina/core/StandardWrapper:parent	Lorg/apache/catalina/Container;
/*      */     //   49: invokeinterface 132 1 0
/*      */     //   54: getstatic 133	org/apache/catalina/LifecycleState:STARTED	Lorg/apache/catalina/LifecycleState;
/*      */     //   57: invokevirtual 134	org/apache/catalina/LifecycleState:equals	(Ljava/lang/Object;)Z
/*      */     //   60: ifeq +10 -> 70
/*      */     //   63: aload_0
/*      */     //   64: ldc -120
/*      */     //   66: aload_1
/*      */     //   67: invokevirtual 129	org/apache/catalina/core/StandardWrapper:fireContainerEvent	(Ljava/lang/String;Ljava/lang/Object;)V
/*      */     //   70: return
/*      */     // Line number table:
/*      */     //   Java source line #718	-> byte code offset #0
/*      */     //   Java source line #720	-> byte code offset #10
/*      */     //   Java source line #722	-> byte code offset #19
/*      */     //   Java source line #723	-> byte code offset #29
/*      */     //   Java source line #722	-> byte code offset #32
/*      */     //   Java source line #723	-> byte code offset #43
/*      */     //   Java source line #724	-> byte code offset #45
/*      */     //   Java source line #725	-> byte code offset #63
/*      */     //   Java source line #728	-> byte code offset #70
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	71	0	this	StandardWrapper
/*      */     //   0	71	1	mapping	String
/*      */     //   32	12	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   10	19	32	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void addSecurityReference(String name, String link)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 44	org/apache/catalina/core/StandardWrapper:referencesLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   4: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   7: invokevirtual 125	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:lock	()V
/*      */     //   10: aload_0
/*      */     //   11: getfield 21	org/apache/catalina/core/StandardWrapper:references	Ljava/util/HashMap;
/*      */     //   14: aload_1
/*      */     //   15: aload_2
/*      */     //   16: invokevirtual 126	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   19: pop
/*      */     //   20: aload_0
/*      */     //   21: getfield 44	org/apache/catalina/core/StandardWrapper:referencesLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   24: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   27: invokevirtual 127	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/*      */     //   30: goto +16 -> 46
/*      */     //   33: astore_3
/*      */     //   34: aload_0
/*      */     //   35: getfield 44	org/apache/catalina/core/StandardWrapper:referencesLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   38: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   41: invokevirtual 127	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/*      */     //   44: aload_3
/*      */     //   45: athrow
/*      */     //   46: aload_0
/*      */     //   47: ldc -119
/*      */     //   49: aload_1
/*      */     //   50: invokevirtual 129	org/apache/catalina/core/StandardWrapper:fireContainerEvent	(Ljava/lang/String;Ljava/lang/Object;)V
/*      */     //   53: return
/*      */     // Line number table:
/*      */     //   Java source line #741	-> byte code offset #0
/*      */     //   Java source line #743	-> byte code offset #10
/*      */     //   Java source line #745	-> byte code offset #20
/*      */     //   Java source line #746	-> byte code offset #30
/*      */     //   Java source line #745	-> byte code offset #33
/*      */     //   Java source line #746	-> byte code offset #44
/*      */     //   Java source line #747	-> byte code offset #46
/*      */     //   Java source line #749	-> byte code offset #53
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	54	0	this	StandardWrapper
/*      */     //   0	54	1	name	String
/*      */     //   0	54	2	link	String
/*      */     //   33	12	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   10	20	33	finally
/*      */   }
/*      */   
/*      */   public Servlet allocate()
/*      */     throws ServletException
/*      */   {
/*  769 */     if (this.unloading) {
/*  770 */       throw new ServletException(sm.getString("standardWrapper.unloading", new Object[] { getName() }));
/*      */     }
/*      */     
/*  773 */     boolean newInstance = false;
/*      */     
/*      */ 
/*  776 */     if (!this.singleThreadModel)
/*      */     {
/*  778 */       if ((this.instance == null) || (!this.instanceInitialized)) {
/*  779 */         synchronized (this) {
/*  780 */           if (this.instance == null) {
/*      */             try {
/*  782 */               if (this.log.isDebugEnabled()) {
/*  783 */                 this.log.debug("Allocating non-STM instance");
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*  788 */               this.instance = loadServlet();
/*  789 */               newInstance = true;
/*  790 */               if (!this.singleThreadModel)
/*      */               {
/*      */ 
/*      */ 
/*  794 */                 this.countAllocated.incrementAndGet();
/*      */               }
/*      */             } catch (ServletException e) {
/*  797 */               throw e;
/*      */             } catch (Throwable e) {
/*  799 */               ExceptionUtils.handleThrowable(e);
/*  800 */               throw new ServletException(sm.getString("standardWrapper.allocate"), e);
/*      */             }
/*      */           }
/*  803 */           if (!this.instanceInitialized) {
/*  804 */             initServlet(this.instance);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  809 */       if (this.singleThreadModel) {
/*  810 */         if (newInstance)
/*      */         {
/*      */ 
/*  813 */           synchronized (this.instancePool) {
/*  814 */             this.instancePool.push(this.instance);
/*  815 */             this.nInstances += 1;
/*      */           }
/*      */         }
/*      */       } else {
/*  819 */         if (this.log.isTraceEnabled()) {
/*  820 */           this.log.trace("  Returning non-STM instance");
/*      */         }
/*      */         
/*      */ 
/*  824 */         if (!newInstance) {
/*  825 */           this.countAllocated.incrementAndGet();
/*      */         }
/*  827 */         return this.instance;
/*      */       }
/*      */     }
/*      */     
/*  831 */     synchronized (this.instancePool) {
/*  832 */       while (this.countAllocated.get() >= this.nInstances)
/*      */       {
/*  834 */         if (this.nInstances < this.maxInstances) {
/*      */           try {
/*  836 */             this.instancePool.push(loadServlet());
/*  837 */             this.nInstances += 1;
/*      */           } catch (ServletException e) {
/*  839 */             throw e;
/*      */           } catch (Throwable e) {
/*  841 */             ExceptionUtils.handleThrowable(e);
/*  842 */             throw new ServletException(sm.getString("standardWrapper.allocate"), e);
/*      */           }
/*      */         } else {
/*      */           try {
/*  846 */             this.instancePool.wait();
/*      */           }
/*      */           catch (InterruptedException localInterruptedException) {}
/*      */         }
/*      */       }
/*      */       
/*  852 */       if (this.log.isTraceEnabled()) {
/*  853 */         this.log.trace("  Returning allocated STM instance");
/*      */       }
/*  855 */       this.countAllocated.incrementAndGet();
/*  856 */       return (Servlet)this.instancePool.pop();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deallocate(Servlet servlet)
/*      */     throws ServletException
/*      */   {
/*  874 */     if (!this.singleThreadModel) {
/*  875 */       this.countAllocated.decrementAndGet();
/*  876 */       return;
/*      */     }
/*      */     
/*      */ 
/*  880 */     synchronized (this.instancePool) {
/*  881 */       this.countAllocated.decrementAndGet();
/*  882 */       this.instancePool.push(servlet);
/*  883 */       this.instancePool.notify();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findInitParameter(String name)
/*      */   {
/*  898 */     this.parametersLock.readLock().lock();
/*      */     try {
/*  900 */       return (String)this.parameters.get(name);
/*      */     } finally {
/*  902 */       this.parametersLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] findInitParameters()
/*      */   {
/*  915 */     this.parametersLock.readLock().lock();
/*      */     try {
/*  917 */       String[] results = new String[this.parameters.size()];
/*  918 */       return (String[])this.parameters.keySet().toArray(results);
/*      */     } finally {
/*  920 */       this.parametersLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] findMappings()
/*      */   {
/*  932 */     this.mappingsLock.readLock().lock();
/*      */     try {
/*  934 */       return (String[])this.mappings.toArray(new String[0]);
/*      */     } finally {
/*  936 */       this.mappingsLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String findSecurityReference(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aconst_null
/*      */     //   1: astore_2
/*      */     //   2: aload_0
/*      */     //   3: getfield 44	org/apache/catalina/core/StandardWrapper:referencesLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   6: invokevirtual 164	java/util/concurrent/locks/ReentrantReadWriteLock:readLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;
/*      */     //   9: invokevirtual 165	java/util/concurrent/locks/ReentrantReadWriteLock$ReadLock:lock	()V
/*      */     //   12: aload_0
/*      */     //   13: getfield 21	org/apache/catalina/core/StandardWrapper:references	Ljava/util/HashMap;
/*      */     //   16: aload_1
/*      */     //   17: invokevirtual 166	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   20: checkcast 111	java/lang/String
/*      */     //   23: astore_2
/*      */     //   24: aload_0
/*      */     //   25: getfield 44	org/apache/catalina/core/StandardWrapper:referencesLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   28: invokevirtual 164	java/util/concurrent/locks/ReentrantReadWriteLock:readLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;
/*      */     //   31: invokevirtual 167	java/util/concurrent/locks/ReentrantReadWriteLock$ReadLock:unlock	()V
/*      */     //   34: goto +16 -> 50
/*      */     //   37: astore_3
/*      */     //   38: aload_0
/*      */     //   39: getfield 44	org/apache/catalina/core/StandardWrapper:referencesLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   42: invokevirtual 164	java/util/concurrent/locks/ReentrantReadWriteLock:readLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;
/*      */     //   45: invokevirtual 167	java/util/concurrent/locks/ReentrantReadWriteLock$ReadLock:unlock	()V
/*      */     //   48: aload_3
/*      */     //   49: athrow
/*      */     //   50: aload_0
/*      */     //   51: invokevirtual 171	org/apache/catalina/core/StandardWrapper:getParent	()Lorg/apache/catalina/Container;
/*      */     //   54: instanceof 71
/*      */     //   57: ifeq +34 -> 91
/*      */     //   60: aload_0
/*      */     //   61: invokevirtual 171	org/apache/catalina/core/StandardWrapper:getParent	()Lorg/apache/catalina/Container;
/*      */     //   64: checkcast 71	org/apache/catalina/Context
/*      */     //   67: astore_3
/*      */     //   68: aload_2
/*      */     //   69: ifnull +14 -> 83
/*      */     //   72: aload_3
/*      */     //   73: aload_2
/*      */     //   74: invokeinterface 172 2 0
/*      */     //   79: astore_2
/*      */     //   80: goto +11 -> 91
/*      */     //   83: aload_3
/*      */     //   84: aload_1
/*      */     //   85: invokeinterface 172 2 0
/*      */     //   90: astore_2
/*      */     //   91: aload_2
/*      */     //   92: areturn
/*      */     // Line number table:
/*      */     //   Java source line #950	-> byte code offset #0
/*      */     //   Java source line #952	-> byte code offset #2
/*      */     //   Java source line #954	-> byte code offset #12
/*      */     //   Java source line #956	-> byte code offset #24
/*      */     //   Java source line #957	-> byte code offset #34
/*      */     //   Java source line #956	-> byte code offset #37
/*      */     //   Java source line #957	-> byte code offset #48
/*      */     //   Java source line #960	-> byte code offset #50
/*      */     //   Java source line #961	-> byte code offset #60
/*      */     //   Java source line #962	-> byte code offset #68
/*      */     //   Java source line #963	-> byte code offset #72
/*      */     //   Java source line #965	-> byte code offset #83
/*      */     //   Java source line #969	-> byte code offset #91
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	93	0	this	StandardWrapper
/*      */     //   0	93	1	name	String
/*      */     //   1	91	2	reference	String
/*      */     //   37	12	3	localObject	Object
/*      */     //   67	17	3	context	Context
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   12	24	37	finally
/*      */   }
/*      */   
/*      */   public String[] findSecurityReferences()
/*      */   {
/*  980 */     this.referencesLock.readLock().lock();
/*      */     try {
/*  982 */       String[] results = new String[this.references.size()];
/*  983 */       return (String[])this.references.keySet().toArray(results);
/*      */     } finally {
/*  985 */       this.referencesLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void load()
/*      */     throws ServletException
/*      */   {
/* 1010 */     this.instance = loadServlet();
/*      */     
/* 1012 */     if (!this.instanceInitialized) {
/* 1013 */       initServlet(this.instance);
/*      */     }
/*      */     
/* 1016 */     if (this.isJspServlet) {
/* 1017 */       StringBuilder oname = new StringBuilder(getDomain());
/*      */       
/* 1019 */       oname.append(":type=JspMonitor");
/*      */       
/* 1021 */       oname.append(getWebModuleKeyProperties());
/*      */       
/* 1023 */       oname.append(",name=");
/* 1024 */       oname.append(getName());
/*      */       
/* 1026 */       oname.append(getJ2EEKeyProperties());
/*      */       try
/*      */       {
/* 1029 */         this.jspMonitorON = new ObjectName(oname.toString());
/* 1030 */         Registry.getRegistry(null, null).registerComponent(this.instance, this.jspMonitorON, null);
/*      */       } catch (Exception ex) {
/* 1032 */         this.log.warn(sm.getString("standardWrapper.jspMonitorError", new Object[] { this.instance }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Servlet loadServlet()
/*      */     throws ServletException
/*      */   {
/* 1049 */     if ((!this.singleThreadModel) && (this.instance != null)) {
/* 1050 */       return this.instance;
/*      */     }
/*      */     
/* 1053 */     PrintStream out = System.out;
/* 1054 */     if (this.swallowOutput) {
/* 1055 */       SystemLogHandler.startCapture();
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1060 */       long t1 = System.currentTimeMillis();
/*      */       
/* 1062 */       if (this.servletClass == null) {
/* 1063 */         unavailable(null);
/*      */         
/* 1065 */         throw new ServletException(sm.getString("standardWrapper.notClass", new Object[] {getName() }));
/*      */       }
/*      */       
/* 1068 */       InstanceManager instanceManager = ((StandardContext)getParent()).getInstanceManager();
/*      */       try {
/* 1070 */         servlet = (Servlet)instanceManager.newInstance(this.servletClass);
/*      */       } catch (ClassCastException e) { Servlet servlet;
/* 1072 */         unavailable(null);
/*      */         
/*      */ 
/* 1075 */         throw new ServletException(sm.getString("standardWrapper.notServlet", new Object[] { this.servletClass }), e);
/*      */       } catch (Throwable e) {
/* 1077 */         e = ExceptionUtils.unwrapInvocationTargetException(e);
/* 1078 */         ExceptionUtils.handleThrowable(e);
/* 1079 */         unavailable(null);
/*      */         
/*      */ 
/*      */ 
/* 1083 */         if (this.log.isDebugEnabled()) {
/* 1084 */           this.log.debug(sm.getString("standardWrapper.instantiate", new Object[] { this.servletClass }), e);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1089 */         throw new ServletException(sm.getString("standardWrapper.instantiate", new Object[] { this.servletClass }), e);
/*      */       }
/*      */       Servlet servlet;
/* 1092 */       if (this.multipartConfigElement == null)
/*      */       {
/* 1094 */         MultipartConfig annotation = (MultipartConfig)servlet.getClass().getAnnotation(MultipartConfig.class);
/* 1095 */         if (annotation != null) {
/* 1096 */           this.multipartConfigElement = new MultipartConfigElement(annotation);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1104 */       if ((servlet instanceof ContainerServlet)) {
/* 1105 */         ((ContainerServlet)servlet).setWrapper(this);
/*      */       }
/*      */       
/* 1108 */       this.classLoadTime = ((int)(System.currentTimeMillis() - t1));
/*      */       
/* 1110 */       if ((servlet instanceof SingleThreadModel)) {
/* 1111 */         if (this.instancePool == null) {
/* 1112 */           this.instancePool = new Stack();
/*      */         }
/* 1114 */         this.singleThreadModel = true;
/*      */       }
/*      */       
/* 1117 */       initServlet(servlet);
/*      */       
/* 1119 */       fireContainerEvent("load", this);
/*      */       
/* 1121 */       this.loadTime = (System.currentTimeMillis() - t1);
/*      */     } finally { String log;
/* 1123 */       if (this.swallowOutput) {
/* 1124 */         String log = SystemLogHandler.stopCapture();
/* 1125 */         if ((log != null) && (log.length() > 0)) {
/* 1126 */           if (getServletContext() != null) {
/* 1127 */             getServletContext().log(log);
/*      */           } else
/* 1129 */             out.println(log);
/*      */         }
/*      */       }
/*      */     }
/*      */     Servlet servlet;
/* 1134 */     return servlet;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private synchronized void initServlet(Servlet servlet)
/*      */     throws ServletException
/*      */   {
/* 1142 */     if ((this.instanceInitialized) && (!this.singleThreadModel)) {
/* 1143 */       return;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1148 */       if (Globals.IS_SECURITY_ENABLED) {
/* 1149 */         boolean success = false;
/*      */         try {
/* 1151 */           Object[] args = { this.facade };
/* 1152 */           SecurityUtil.doAsPrivilege("init", servlet, classType, args);
/*      */           
/*      */ 
/*      */ 
/* 1156 */           success = true;
/*      */         } finally {
/* 1158 */           if (!success)
/*      */           {
/* 1160 */             SecurityUtil.remove(servlet);
/*      */           }
/*      */         }
/*      */       } else {
/* 1164 */         servlet.init(this.facade);
/*      */       }
/*      */       
/* 1167 */       this.instanceInitialized = true;
/*      */     } catch (UnavailableException f) {
/* 1169 */       unavailable(f);
/* 1170 */       throw f;
/*      */     }
/*      */     catch (ServletException f)
/*      */     {
/* 1174 */       throw f;
/*      */     } catch (Throwable f) {
/* 1176 */       ExceptionUtils.handleThrowable(f);
/* 1177 */       getServletContext().log(sm.getString("standardWrapper.initException", new Object[] { getName() }), f);
/*      */       
/*      */ 
/*      */ 
/* 1181 */       throw new ServletException(sm.getString("standardWrapper.initException", new Object[] {getName() }), f);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void removeInitParameter(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 42	org/apache/catalina/core/StandardWrapper:parametersLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   4: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   7: invokevirtual 125	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:lock	()V
/*      */     //   10: aload_0
/*      */     //   11: getfield 20	org/apache/catalina/core/StandardWrapper:parameters	Ljava/util/HashMap;
/*      */     //   14: aload_1
/*      */     //   15: invokevirtual 225	java/util/HashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   18: pop
/*      */     //   19: aload_0
/*      */     //   20: getfield 42	org/apache/catalina/core/StandardWrapper:parametersLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   23: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   26: invokevirtual 127	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/*      */     //   29: goto +16 -> 45
/*      */     //   32: astore_2
/*      */     //   33: aload_0
/*      */     //   34: getfield 42	org/apache/catalina/core/StandardWrapper:parametersLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   37: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   40: invokevirtual 127	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/*      */     //   43: aload_2
/*      */     //   44: athrow
/*      */     //   45: aload_0
/*      */     //   46: ldc -30
/*      */     //   48: aload_1
/*      */     //   49: invokevirtual 129	org/apache/catalina/core/StandardWrapper:fireContainerEvent	(Ljava/lang/String;Ljava/lang/Object;)V
/*      */     //   52: return
/*      */     // Line number table:
/*      */     //   Java source line #1193	-> byte code offset #0
/*      */     //   Java source line #1195	-> byte code offset #10
/*      */     //   Java source line #1197	-> byte code offset #19
/*      */     //   Java source line #1198	-> byte code offset #29
/*      */     //   Java source line #1197	-> byte code offset #32
/*      */     //   Java source line #1198	-> byte code offset #43
/*      */     //   Java source line #1199	-> byte code offset #45
/*      */     //   Java source line #1201	-> byte code offset #52
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	53	0	this	StandardWrapper
/*      */     //   0	53	1	name	String
/*      */     //   32	12	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   10	19	32	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void removeMapping(String mapping)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 43	org/apache/catalina/core/StandardWrapper:mappingsLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   4: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   7: invokevirtual 125	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:lock	()V
/*      */     //   10: aload_0
/*      */     //   11: getfield 17	org/apache/catalina/core/StandardWrapper:mappings	Ljava/util/ArrayList;
/*      */     //   14: aload_1
/*      */     //   15: invokevirtual 227	java/util/ArrayList:remove	(Ljava/lang/Object;)Z
/*      */     //   18: pop
/*      */     //   19: aload_0
/*      */     //   20: getfield 43	org/apache/catalina/core/StandardWrapper:mappingsLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   23: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   26: invokevirtual 127	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/*      */     //   29: goto +16 -> 45
/*      */     //   32: astore_2
/*      */     //   33: aload_0
/*      */     //   34: getfield 43	org/apache/catalina/core/StandardWrapper:mappingsLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   37: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   40: invokevirtual 127	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/*      */     //   43: aload_2
/*      */     //   44: athrow
/*      */     //   45: aload_0
/*      */     //   46: getfield 131	org/apache/catalina/core/StandardWrapper:parent	Lorg/apache/catalina/Container;
/*      */     //   49: invokeinterface 132 1 0
/*      */     //   54: getstatic 133	org/apache/catalina/LifecycleState:STARTED	Lorg/apache/catalina/LifecycleState;
/*      */     //   57: invokevirtual 134	org/apache/catalina/LifecycleState:equals	(Ljava/lang/Object;)Z
/*      */     //   60: ifeq +10 -> 70
/*      */     //   63: aload_0
/*      */     //   64: ldc -28
/*      */     //   66: aload_1
/*      */     //   67: invokevirtual 129	org/apache/catalina/core/StandardWrapper:fireContainerEvent	(Ljava/lang/String;Ljava/lang/Object;)V
/*      */     //   70: return
/*      */     // Line number table:
/*      */     //   Java source line #1212	-> byte code offset #0
/*      */     //   Java source line #1214	-> byte code offset #10
/*      */     //   Java source line #1216	-> byte code offset #19
/*      */     //   Java source line #1217	-> byte code offset #29
/*      */     //   Java source line #1216	-> byte code offset #32
/*      */     //   Java source line #1217	-> byte code offset #43
/*      */     //   Java source line #1218	-> byte code offset #45
/*      */     //   Java source line #1219	-> byte code offset #63
/*      */     //   Java source line #1222	-> byte code offset #70
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	71	0	this	StandardWrapper
/*      */     //   0	71	1	mapping	String
/*      */     //   32	12	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   10	19	32	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void removeSecurityReference(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 44	org/apache/catalina/core/StandardWrapper:referencesLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   4: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   7: invokevirtual 125	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:lock	()V
/*      */     //   10: aload_0
/*      */     //   11: getfield 21	org/apache/catalina/core/StandardWrapper:references	Ljava/util/HashMap;
/*      */     //   14: aload_1
/*      */     //   15: invokevirtual 225	java/util/HashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   18: pop
/*      */     //   19: aload_0
/*      */     //   20: getfield 44	org/apache/catalina/core/StandardWrapper:referencesLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   23: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   26: invokevirtual 127	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/*      */     //   29: goto +16 -> 45
/*      */     //   32: astore_2
/*      */     //   33: aload_0
/*      */     //   34: getfield 44	org/apache/catalina/core/StandardWrapper:referencesLock	Ljava/util/concurrent/locks/ReentrantReadWriteLock;
/*      */     //   37: invokevirtual 124	java/util/concurrent/locks/ReentrantReadWriteLock:writeLock	()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;
/*      */     //   40: invokevirtual 127	java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock:unlock	()V
/*      */     //   43: aload_2
/*      */     //   44: athrow
/*      */     //   45: aload_0
/*      */     //   46: ldc -27
/*      */     //   48: aload_1
/*      */     //   49: invokevirtual 129	org/apache/catalina/core/StandardWrapper:fireContainerEvent	(Ljava/lang/String;Ljava/lang/Object;)V
/*      */     //   52: return
/*      */     // Line number table:
/*      */     //   Java source line #1233	-> byte code offset #0
/*      */     //   Java source line #1235	-> byte code offset #10
/*      */     //   Java source line #1237	-> byte code offset #19
/*      */     //   Java source line #1238	-> byte code offset #29
/*      */     //   Java source line #1237	-> byte code offset #32
/*      */     //   Java source line #1238	-> byte code offset #43
/*      */     //   Java source line #1239	-> byte code offset #45
/*      */     //   Java source line #1241	-> byte code offset #52
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	53	0	this	StandardWrapper
/*      */     //   0	53	1	name	String
/*      */     //   32	12	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   10	19	32	finally
/*      */   }
/*      */   
/*      */   public void unavailable(UnavailableException unavailable)
/*      */   {
/* 1253 */     getServletContext().log(sm.getString("standardWrapper.unavailable", new Object[] { getName() }));
/* 1254 */     if (unavailable == null) {
/* 1255 */       setAvailable(Long.MAX_VALUE);
/* 1256 */     } else if (unavailable.isPermanent()) {
/* 1257 */       setAvailable(Long.MAX_VALUE);
/*      */     } else {
/* 1259 */       int unavailableSeconds = unavailable.getUnavailableSeconds();
/* 1260 */       if (unavailableSeconds <= 0)
/*      */       {
/* 1262 */         unavailableSeconds = 60;
/*      */       }
/* 1264 */       setAvailable(System.currentTimeMillis() + unavailableSeconds * 1000L);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void unload()
/*      */     throws ServletException
/*      */   {
/* 1285 */     if ((!this.singleThreadModel) && (this.instance == null)) {
/* 1286 */       return;
/*      */     }
/* 1288 */     this.unloading = true;
/*      */     
/*      */ 
/*      */ 
/* 1292 */     if (this.countAllocated.get() > 0) {
/* 1293 */       int nRetries = 0;
/* 1294 */       long delay = this.unloadDelay / 20L;
/* 1295 */       while ((nRetries < 21) && (this.countAllocated.get() > 0)) {
/* 1296 */         if (nRetries % 10 == 0) {
/* 1297 */           this.log.info(sm.getString("standardWrapper.waiting", new Object[] {this.countAllocated
/* 1298 */             .toString(), 
/* 1299 */             getName() }));
/*      */         }
/*      */         try {
/* 1302 */           Thread.sleep(delay);
/*      */         }
/*      */         catch (InterruptedException localInterruptedException) {}
/*      */         
/* 1306 */         nRetries++;
/*      */       }
/*      */     }
/*      */     
/* 1310 */     if (this.instanceInitialized) {
/* 1311 */       PrintStream out = System.out;
/* 1312 */       if (this.swallowOutput) {
/* 1313 */         SystemLogHandler.startCapture();
/*      */       }
/*      */       
/*      */       try
/*      */       {
/* 1318 */         if (Globals.IS_SECURITY_ENABLED) {
/*      */           try {
/* 1320 */             SecurityUtil.doAsPrivilege("destroy", this.instance);
/*      */           } finally {
/* 1322 */             SecurityUtil.remove(this.instance);
/*      */           }
/*      */         } else {
/* 1325 */           this.instance.destroy();
/*      */         }
/*      */       } catch (Throwable t) {
/*      */         String log;
/* 1329 */         t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 1330 */         ExceptionUtils.handleThrowable(t);
/* 1331 */         this.instance = null;
/* 1332 */         this.instancePool = null;
/* 1333 */         this.nInstances = 0;
/* 1334 */         fireContainerEvent("unload", this);
/* 1335 */         this.unloading = false;
/*      */         
/* 1337 */         throw new ServletException(sm.getString("standardWrapper.destroyException", new Object[] {getName() }), t);
/*      */       }
/*      */       finally
/*      */       {
/* 1341 */         if (!((Context)getParent()).getIgnoreAnnotations()) {
/*      */           try {
/* 1343 */             ((Context)getParent()).getInstanceManager().destroyInstance(this.instance);
/*      */           } catch (Throwable t) {
/* 1345 */             ExceptionUtils.handleThrowable(t);
/* 1346 */             this.log.error(sm.getString("standardWrapper.destroyInstance", new Object[] { getName() }), t);
/*      */           }
/*      */         }
/*      */         
/* 1350 */         if (this.swallowOutput) {
/* 1351 */           String log = SystemLogHandler.stopCapture();
/* 1352 */           if ((log != null) && (log.length() > 0)) {
/* 1353 */             if (getServletContext() != null) {
/* 1354 */               getServletContext().log(log);
/*      */             } else {
/* 1356 */               out.println(log);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1364 */     this.instance = null;
/* 1365 */     this.instanceInitialized = false;
/*      */     
/* 1367 */     if ((this.isJspServlet) && (this.jspMonitorON != null)) {
/* 1368 */       Registry.getRegistry(null, null).unregisterComponent(this.jspMonitorON);
/*      */     }
/*      */     
/* 1371 */     if ((this.singleThreadModel) && (this.instancePool != null)) {
/*      */       try {
/* 1373 */         while (!this.instancePool.isEmpty()) {
/* 1374 */           Servlet s = (Servlet)this.instancePool.pop();
/* 1375 */           if (Globals.IS_SECURITY_ENABLED) {
/*      */             try {
/* 1377 */               SecurityUtil.doAsPrivilege("destroy", s);
/*      */             } finally {
/* 1379 */               SecurityUtil.remove(s);
/*      */             }
/*      */           } else {
/* 1382 */             s.destroy();
/*      */           }
/*      */           
/* 1385 */           if (!((Context)getParent()).getIgnoreAnnotations()) {
/* 1386 */             ((StandardContext)getParent()).getInstanceManager().destroyInstance(s);
/*      */           }
/*      */         }
/*      */       } catch (Throwable t) {
/* 1390 */         t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 1391 */         ExceptionUtils.handleThrowable(t);
/* 1392 */         this.instancePool = null;
/* 1393 */         this.nInstances = 0;
/* 1394 */         this.unloading = false;
/* 1395 */         fireContainerEvent("unload", this);
/*      */         
/* 1397 */         throw new ServletException(sm.getString("standardWrapper.destroyException", new Object[] {
/* 1398 */           getName() }), t);
/*      */       }
/* 1400 */       this.instancePool = null;
/* 1401 */       this.nInstances = 0;
/*      */     }
/*      */     
/* 1404 */     this.singleThreadModel = false;
/*      */     
/* 1406 */     this.unloading = false;
/* 1407 */     fireContainerEvent("unload", this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getInitParameter(String name)
/*      */   {
/* 1423 */     return findInitParameter(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<String> getInitParameterNames()
/*      */   {
/* 1434 */     this.parametersLock.readLock().lock();
/*      */     try {
/* 1436 */       return Collections.enumeration(this.parameters.keySet());
/*      */     } finally {
/* 1438 */       this.parametersLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletContext getServletContext()
/*      */   {
/* 1449 */     if (this.parent == null)
/* 1450 */       return null;
/* 1451 */     if (!(this.parent instanceof Context)) {
/* 1452 */       return null;
/*      */     }
/* 1454 */     return ((Context)this.parent).getServletContext();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServletName()
/*      */   {
/* 1464 */     return getName();
/*      */   }
/*      */   
/*      */   public long getProcessingTime() {
/* 1468 */     return this.swValve.getProcessingTime();
/*      */   }
/*      */   
/*      */   public long getMaxTime() {
/* 1472 */     return this.swValve.getMaxTime();
/*      */   }
/*      */   
/*      */   public long getMinTime() {
/* 1476 */     return this.swValve.getMinTime();
/*      */   }
/*      */   
/*      */   public int getRequestCount() {
/* 1480 */     return this.swValve.getRequestCount();
/*      */   }
/*      */   
/*      */   public int getErrorCount() {
/* 1484 */     return this.swValve.getErrorCount();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void incrementErrorCount()
/*      */   {
/* 1492 */     this.swValve.incrementErrorCount();
/*      */   }
/*      */   
/*      */   public long getLoadTime() {
/* 1496 */     return this.loadTime;
/*      */   }
/*      */   
/*      */   public int getClassLoadTime() {
/* 1500 */     return this.classLoadTime;
/*      */   }
/*      */   
/*      */   public MultipartConfigElement getMultipartConfigElement()
/*      */   {
/* 1505 */     return this.multipartConfigElement;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setMultipartConfigElement(MultipartConfigElement multipartConfigElement)
/*      */   {
/* 1511 */     this.multipartConfigElement = multipartConfigElement;
/*      */   }
/*      */   
/*      */   public boolean isAsyncSupported()
/*      */   {
/* 1516 */     return this.asyncSupported;
/*      */   }
/*      */   
/*      */   public void setAsyncSupported(boolean asyncSupported)
/*      */   {
/* 1521 */     this.asyncSupported = asyncSupported;
/*      */   }
/*      */   
/*      */   public boolean isEnabled()
/*      */   {
/* 1526 */     return this.enabled;
/*      */   }
/*      */   
/*      */   public void setEnabled(boolean enabled)
/*      */   {
/* 1531 */     this.enabled = enabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Method[] getAllDeclaredMethods(Class<?> c)
/*      */   {
/* 1542 */     if (c.equals(HttpServlet.class)) {
/* 1543 */       return null;
/*      */     }
/*      */     
/* 1546 */     Method[] parentMethods = getAllDeclaredMethods(c.getSuperclass());
/*      */     
/* 1548 */     Method[] thisMethods = c.getDeclaredMethods();
/* 1549 */     if (thisMethods.length == 0) {
/* 1550 */       return parentMethods;
/*      */     }
/*      */     
/* 1553 */     if ((parentMethods != null) && (parentMethods.length > 0)) {
/* 1554 */       Method[] allMethods = new Method[parentMethods.length + thisMethods.length];
/*      */       
/* 1556 */       System.arraycopy(parentMethods, 0, allMethods, 0, parentMethods.length);
/*      */       
/* 1558 */       System.arraycopy(thisMethods, 0, allMethods, parentMethods.length, thisMethods.length);
/*      */       
/*      */ 
/* 1561 */       thisMethods = allMethods;
/*      */     }
/*      */     
/* 1564 */     return thisMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void startInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1582 */     if (getObjectName() != null)
/*      */     {
/* 1584 */       Notification notification = new Notification("j2ee.state.starting", getObjectName(), this.sequenceNumber++);
/*      */       
/* 1586 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/*      */ 
/* 1590 */     super.startInternal();
/*      */     
/* 1592 */     setAvailable(0L);
/*      */     
/*      */ 
/* 1595 */     if (getObjectName() != null)
/*      */     {
/* 1597 */       Notification notification = new Notification("j2ee.state.running", getObjectName(), this.sequenceNumber++);
/*      */       
/* 1599 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1615 */     setAvailable(Long.MAX_VALUE);
/*      */     
/*      */ 
/* 1618 */     if (getObjectName() != null)
/*      */     {
/* 1620 */       Notification notification = new Notification("j2ee.state.stopping", getObjectName(), this.sequenceNumber++);
/*      */       
/* 1622 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1627 */       unload();
/*      */     } catch (ServletException e) {
/* 1629 */       getServletContext().log(sm
/* 1630 */         .getString("standardWrapper.unloadException", new Object[] {getName() }), e);
/*      */     }
/*      */     
/*      */ 
/* 1634 */     super.stopInternal();
/*      */     
/*      */ 
/* 1637 */     if (getObjectName() != null)
/*      */     {
/* 1639 */       Notification notification = new Notification("j2ee.state.stopped", getObjectName(), this.sequenceNumber++);
/*      */       
/* 1641 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1646 */     Notification notification = new Notification("j2ee.object.deleted", getObjectName(), this.sequenceNumber++);
/*      */     
/* 1648 */     this.broadcaster.sendNotification(notification);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getObjectNameKeyProperties()
/*      */   {
/* 1656 */     StringBuilder keyProperties = new StringBuilder("j2eeType=Servlet");
/*      */     
/*      */ 
/* 1659 */     keyProperties.append(getWebModuleKeyProperties());
/*      */     
/* 1661 */     keyProperties.append(",name=");
/*      */     
/* 1663 */     String name = getName();
/* 1664 */     if (Util.objectNameValueNeedsQuote(name)) {
/* 1665 */       name = ObjectName.quote(name);
/*      */     }
/* 1667 */     keyProperties.append(name);
/*      */     
/* 1669 */     keyProperties.append(getJ2EEKeyProperties());
/*      */     
/* 1671 */     return keyProperties.toString();
/*      */   }
/*      */   
/*      */ 
/*      */   private String getWebModuleKeyProperties()
/*      */   {
/* 1677 */     StringBuilder keyProperties = new StringBuilder(",WebModule=//");
/* 1678 */     String hostName = getParent().getParent().getName();
/* 1679 */     if (hostName == null) {
/* 1680 */       keyProperties.append("DEFAULT");
/*      */     } else {
/* 1682 */       keyProperties.append(hostName);
/*      */     }
/*      */     
/* 1685 */     String contextName = getParent().getName();
/* 1686 */     if (!contextName.startsWith("/")) {
/* 1687 */       keyProperties.append('/');
/*      */     }
/* 1689 */     keyProperties.append(contextName);
/*      */     
/* 1691 */     return keyProperties.toString();
/*      */   }
/*      */   
/*      */   private String getJ2EEKeyProperties()
/*      */   {
/* 1696 */     StringBuilder keyProperties = new StringBuilder(",J2EEApplication=");
/*      */     
/* 1698 */     StandardContext ctx = null;
/* 1699 */     if ((this.parent instanceof StandardContext)) {
/* 1700 */       ctx = (StandardContext)getParent();
/*      */     }
/*      */     
/* 1703 */     if (ctx == null) {
/* 1704 */       keyProperties.append("none");
/*      */     } else {
/* 1706 */       keyProperties.append(ctx.getJ2EEApplication());
/*      */     }
/* 1708 */     keyProperties.append(",J2EEServer=");
/* 1709 */     if (ctx == null) {
/* 1710 */       keyProperties.append("none");
/*      */     } else {
/* 1712 */       keyProperties.append(ctx.getJ2EEServer());
/*      */     }
/*      */     
/* 1715 */     return keyProperties.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeNotificationListener(NotificationListener listener, NotificationFilter filter, Object object)
/*      */     throws ListenerNotFoundException
/*      */   {
/* 1726 */     this.broadcaster.removeNotificationListener(listener, filter, object);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MBeanNotificationInfo[] getNotificationInfo()
/*      */   {
/* 1739 */     if (this.notificationInfo == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1760 */       this.notificationInfo = new MBeanNotificationInfo[] { new MBeanNotificationInfo(new String[] { "j2ee.object.created" }, Notification.class.getName(), "servlet is created"), new MBeanNotificationInfo(new String[] { "j2ee.state.starting" }, Notification.class.getName(), "servlet is starting"), new MBeanNotificationInfo(new String[] { "j2ee.state.running" }, Notification.class.getName(), "servlet is running"), new MBeanNotificationInfo(new String[] { "j2ee.state.stopped" }, Notification.class.getName(), "servlet start to stopped"), new MBeanNotificationInfo(new String[] { "j2ee.object.stopped" }, Notification.class.getName(), "servlet is stopped"), new MBeanNotificationInfo(new String[] { "j2ee.object.deleted" }, Notification.class.getName(), "servlet is deleted") };
/*      */     }
/*      */     
/* 1763 */     return this.notificationInfo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addNotificationListener(NotificationListener listener, NotificationFilter filter, Object object)
/*      */     throws IllegalArgumentException
/*      */   {
/* 1774 */     this.broadcaster.addNotificationListener(listener, filter, object);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeNotificationListener(NotificationListener listener)
/*      */     throws ListenerNotFoundException
/*      */   {
/* 1785 */     this.broadcaster.removeNotificationListener(listener);
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\StandardWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */