package org.apache.catalina.security;

public class Constants
{
  public static final String PACKAGE = "org.apache.catalina.security";
  public static final String CRLF = "\r\n";
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\security\Constants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */