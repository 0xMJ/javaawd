/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import javax.servlet.http.HttpServletMapping;
/*     */ import javax.servlet.http.MappingMatch;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.mapper.MappingData;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationMapping
/*     */ {
/*     */   private final MappingData mappingData;
/*  28 */   private volatile HttpServletMapping mapping = null;
/*     */   
/*     */   public ApplicationMapping(MappingData mappingData) {
/*  31 */     this.mappingData = mappingData;
/*     */   }
/*     */   
/*     */   public HttpServletMapping getHttpServletMapping() {
/*  35 */     if (this.mapping == null) { String servletName;
/*     */       String servletName;
/*  37 */       if (this.mappingData.wrapper == null) {
/*  38 */         servletName = "";
/*     */       } else {
/*  40 */         servletName = this.mappingData.wrapper.getName();
/*     */       }
/*  42 */       if (this.mappingData.matchType == null) {
/*  43 */         this.mapping = new MappingImpl("", "", null, servletName);
/*     */       } else {
/*  45 */         switch (this.mappingData.matchType) {
/*     */         case CONTEXT_ROOT: 
/*  47 */           this.mapping = new MappingImpl("", "", this.mappingData.matchType, servletName);
/*  48 */           break;
/*     */         case DEFAULT: 
/*  50 */           this.mapping = new MappingImpl("", "/", this.mappingData.matchType, servletName);
/*  51 */           break;
/*     */         
/*     */         case EXACT: 
/*  54 */           this.mapping = new MappingImpl(this.mappingData.wrapperPath.toString().substring(1), this.mappingData.wrapperPath.toString(), this.mappingData.matchType, servletName);
/*  55 */           break;
/*     */         case EXTENSION: 
/*  57 */           String path = this.mappingData.wrapperPath.toString();
/*  58 */           int extIndex = path.lastIndexOf('.');
/*     */           
/*  60 */           this.mapping = new MappingImpl(path.substring(1, extIndex), "*" + path.substring(extIndex), this.mappingData.matchType, servletName);
/*  61 */           break;
/*     */         case PATH:  String matchValue;
/*     */           String matchValue;
/*  64 */           if (this.mappingData.pathInfo.isNull()) {
/*  65 */             matchValue = null;
/*     */           } else {
/*  67 */             matchValue = this.mappingData.pathInfo.toString().substring(1);
/*     */           }
/*  69 */           this.mapping = new MappingImpl(matchValue, this.mappingData.wrapperPath.toString() + "/*", this.mappingData.matchType, servletName);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  76 */     return this.mapping;
/*     */   }
/*     */   
/*     */   public void recycle() {
/*  80 */     this.mapping = null;
/*     */   }
/*     */   
/*     */   private static class MappingImpl implements HttpServletMapping
/*     */   {
/*     */     private final String matchValue;
/*     */     private final String pattern;
/*     */     private final MappingMatch mappingType;
/*     */     private final String servletName;
/*     */     
/*     */     public MappingImpl(String matchValue, String pattern, MappingMatch mappingType, String servletName)
/*     */     {
/*  92 */       this.matchValue = matchValue;
/*  93 */       this.pattern = pattern;
/*  94 */       this.mappingType = mappingType;
/*  95 */       this.servletName = servletName;
/*     */     }
/*     */     
/*     */     public String getMatchValue()
/*     */     {
/* 100 */       return this.matchValue;
/*     */     }
/*     */     
/*     */     public String getPattern()
/*     */     {
/* 105 */       return this.pattern;
/*     */     }
/*     */     
/*     */     public MappingMatch getMappingMatch()
/*     */     {
/* 110 */       return this.mappingType;
/*     */     }
/*     */     
/*     */     public String getServletName()
/*     */     {
/* 115 */       return this.servletName;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\ApplicationMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */