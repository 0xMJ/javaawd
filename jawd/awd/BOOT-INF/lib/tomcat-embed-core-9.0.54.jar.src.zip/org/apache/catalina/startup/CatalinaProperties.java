/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CatalinaProperties
/*     */ {
/*  38 */   private static final Log log = LogFactory.getLog(CatalinaProperties.class);
/*     */   
/*  40 */   private static Properties properties = null;
/*     */   
/*     */   static
/*     */   {
/*  44 */     loadProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getProperty(String name)
/*     */   {
/*  53 */     return properties.getProperty(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void loadProperties()
/*     */   {
/*  62 */     InputStream is = null;
/*  63 */     String fileName = "catalina.properties";
/*     */     try
/*     */     {
/*  66 */       String configUrl = System.getProperty("catalina.config");
/*  67 */       if (configUrl != null) {
/*  68 */         if (configUrl.indexOf('/') == -1)
/*     */         {
/*  70 */           fileName = configUrl;
/*     */         } else {
/*  72 */           is = new URL(configUrl).openStream();
/*     */         }
/*     */       }
/*     */     } catch (Throwable t) {
/*  76 */       handleThrowable(t);
/*     */     }
/*     */     
/*  79 */     if (is == null) {
/*     */       try {
/*  81 */         File home = new File(Bootstrap.getCatalinaBase());
/*  82 */         File conf = new File(home, "conf");
/*  83 */         File propsFile = new File(conf, fileName);
/*  84 */         is = new FileInputStream(propsFile);
/*     */       } catch (Throwable t) {
/*  86 */         handleThrowable(t);
/*     */       }
/*     */     }
/*     */     
/*  90 */     if (is == null) {
/*     */       try
/*     */       {
/*  93 */         is = CatalinaProperties.class.getResourceAsStream("/org/apache/catalina/startup/catalina.properties");
/*     */       } catch (Throwable t) {
/*  95 */         handleThrowable(t);
/*     */       }
/*     */     }
/*     */     
/*  99 */     if (is != null) {
/*     */       try {
/* 101 */         properties = new Properties();
/* 102 */         properties.load(is);
/*     */         
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 108 */           is.close();
/*     */         } catch (IOException ioe) {
/* 110 */           log.warn("Could not close catalina properties file", ioe);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 115 */         if (is != null) {
/*     */           break label254;
/*     */         }
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/* 104 */         handleThrowable(t);
/* 105 */         log.warn(t);
/*     */       } finally {
/*     */         try {
/* 108 */           is.close();
/*     */         } catch (IOException ioe) {
/* 110 */           log.warn("Could not close catalina properties file", ioe);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 117 */     log.warn("Failed to load catalina properties file");
/*     */     
/* 119 */     properties = new Properties();
/*     */     
/*     */     label254:
/*     */     
/* 123 */     Enumeration<?> enumeration = properties.propertyNames();
/* 124 */     while (enumeration.hasMoreElements()) {
/* 125 */       String name = (String)enumeration.nextElement();
/* 126 */       String value = properties.getProperty(name);
/* 127 */       if (value != null) {
/* 128 */         System.setProperty(name, value);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static void handleThrowable(Throwable t)
/*     */   {
/* 136 */     if ((t instanceof ThreadDeath)) {
/* 137 */       throw ((ThreadDeath)t);
/*     */     }
/* 139 */     if ((t instanceof VirtualMachineError)) {
/* 140 */       throw ((VirtualMachineError)t);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\CatalinaProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */