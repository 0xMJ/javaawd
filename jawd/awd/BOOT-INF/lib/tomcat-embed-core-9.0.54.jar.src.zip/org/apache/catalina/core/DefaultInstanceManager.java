/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.annotation.PreDestroy;
/*     */ import javax.annotation.Resource;
/*     */ import javax.ejb.EJB;
/*     */ import javax.naming.NamingException;
/*     */ import javax.persistence.PersistenceContext;
/*     */ import javax.persistence.PersistenceUnit;
/*     */ import javax.xml.ws.WebServiceRef;
/*     */ import org.apache.catalina.ContainerServlet;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Loader;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.catalina.util.Introspection;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.collections.ManagedConcurrentWeakHashMap;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultInstanceManager
/*     */   implements InstanceManager
/*     */ {
/*  61 */   private static final AnnotationCacheEntry[] ANNOTATIONS_EMPTY = new AnnotationCacheEntry[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   protected static final StringManager sm = StringManager.getManager(DefaultInstanceManager.class);
/*     */   private static final boolean EJB_PRESENT;
/*     */   private static final boolean JPA_PRESENT;
/*     */   private static final boolean WS_PRESENT;
/*     */   private final javax.naming.Context context;
/*     */   private final Map<String, Map<String, String>> injectionMap;
/*     */   
/*  74 */   static { Class<?> clazz = null;
/*     */     try {
/*  76 */       clazz = Class.forName("javax.ejb.EJB");
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException) {}
/*     */     
/*  80 */     EJB_PRESENT = clazz != null;
/*     */     
/*  82 */     clazz = null;
/*     */     try {
/*  84 */       clazz = Class.forName("javax.persistence.PersistenceContext");
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException1) {}
/*     */     
/*  88 */     JPA_PRESENT = clazz != null;
/*     */     
/*  90 */     clazz = null;
/*     */     try {
/*  92 */       clazz = Class.forName("javax.xml.ws.WebServiceRef");
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException2) {}
/*     */     
/*  96 */     WS_PRESENT = clazz != null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected final ClassLoader classLoader;
/*     */   
/*     */   protected final ClassLoader containerClassLoader;
/*     */   
/*     */   protected final boolean privileged;
/*     */   protected final boolean ignoreAnnotations;
/*     */   private final Set<String> restrictedClasses;
/* 107 */   private final ManagedConcurrentWeakHashMap<Class<?>, AnnotationCacheEntry[]> annotationCache = new ManagedConcurrentWeakHashMap();
/*     */   
/*     */   private final Map<String, String> postConstructMethods;
/*     */   
/*     */   private final Map<String, String> preDestroyMethods;
/*     */   
/*     */ 
/*     */   public DefaultInstanceManager(javax.naming.Context context, Map<String, Map<String, String>> injectionMap, org.apache.catalina.Context catalinaContext, ClassLoader containerClassLoader)
/*     */   {
/* 116 */     this.classLoader = catalinaContext.getLoader().getClassLoader();
/* 117 */     this.privileged = catalinaContext.getPrivileged();
/* 118 */     this.containerClassLoader = containerClassLoader;
/* 119 */     this.ignoreAnnotations = catalinaContext.getIgnoreAnnotations();
/* 120 */     Log log = catalinaContext.getLogger();
/* 121 */     Set<String> classNames = new HashSet();
/* 122 */     loadProperties(classNames, "org/apache/catalina/core/RestrictedServlets.properties", "defaultInstanceManager.restrictedServletsResource", log);
/*     */     
/*     */ 
/* 125 */     loadProperties(classNames, "org/apache/catalina/core/RestrictedListeners.properties", "defaultInstanceManager.restrictedListenersResource", log);
/*     */     
/*     */ 
/* 128 */     loadProperties(classNames, "org/apache/catalina/core/RestrictedFilters.properties", "defaultInstanceManager.restrictedFiltersResource", log);
/*     */     
/*     */ 
/* 131 */     this.restrictedClasses = Collections.unmodifiableSet(classNames);
/* 132 */     this.context = context;
/* 133 */     this.injectionMap = injectionMap;
/* 134 */     this.postConstructMethods = catalinaContext.findPostConstructMethods();
/* 135 */     this.preDestroyMethods = catalinaContext.findPreDestroyMethods();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object newInstance(Class<?> clazz)
/*     */     throws IllegalAccessException, InvocationTargetException, NamingException, InstantiationException, IllegalArgumentException, NoSuchMethodException, SecurityException
/*     */   {
/* 142 */     return newInstance(clazz.getConstructor(new Class[0]).newInstance(new Object[0]), clazz);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object newInstance(String className)
/*     */     throws IllegalAccessException, InvocationTargetException, NamingException, InstantiationException, ClassNotFoundException, IllegalArgumentException, NoSuchMethodException, SecurityException
/*     */   {
/* 149 */     Class<?> clazz = loadClassMaybePrivileged(className, this.classLoader);
/* 150 */     return newInstance(clazz.getConstructor(new Class[0]).newInstance(new Object[0]), clazz);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object newInstance(String className, ClassLoader classLoader)
/*     */     throws IllegalAccessException, NamingException, InvocationTargetException, InstantiationException, ClassNotFoundException, IllegalArgumentException, NoSuchMethodException, SecurityException
/*     */   {
/* 158 */     Class<?> clazz = classLoader.loadClass(className);
/* 159 */     return newInstance(clazz.getConstructor(new Class[0]).newInstance(new Object[0]), clazz);
/*     */   }
/*     */   
/*     */   public void newInstance(Object o)
/*     */     throws IllegalAccessException, InvocationTargetException, NamingException
/*     */   {
/* 165 */     newInstance(o, o.getClass());
/*     */   }
/*     */   
/*     */   private Object newInstance(Object instance, Class<?> clazz) throws IllegalAccessException, InvocationTargetException, NamingException
/*     */   {
/* 170 */     if (!this.ignoreAnnotations) {
/* 171 */       Map<String, String> injections = assembleInjectionsFromClassHierarchy(clazz);
/* 172 */       populateAnnotationsCache(clazz, injections);
/* 173 */       processAnnotations(instance, injections);
/* 174 */       postConstruct(instance, clazz);
/*     */     }
/* 176 */     return instance;
/*     */   }
/*     */   
/*     */   private Map<String, String> assembleInjectionsFromClassHierarchy(Class<?> clazz) {
/* 180 */     Map<String, String> injections = new HashMap();
/* 181 */     Map<String, String> currentInjections = null;
/* 182 */     while (clazz != null) {
/* 183 */       currentInjections = (Map)this.injectionMap.get(clazz.getName());
/* 184 */       if (currentInjections != null) {
/* 185 */         injections.putAll(currentInjections);
/*     */       }
/* 187 */       clazz = clazz.getSuperclass();
/*     */     }
/* 189 */     return injections;
/*     */   }
/*     */   
/*     */   public void destroyInstance(Object instance)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 195 */     if (!this.ignoreAnnotations) {
/* 196 */       preDestroy(instance, instance.getClass());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void postConstruct(Object instance, Class<?> clazz)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 212 */     if (this.context == null)
/*     */     {
/* 214 */       return;
/*     */     }
/*     */     
/* 217 */     Class<?> superClass = clazz.getSuperclass();
/* 218 */     if (superClass != Object.class) {
/* 219 */       postConstruct(instance, superClass);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 224 */     AnnotationCacheEntry[] annotations = (AnnotationCacheEntry[])this.annotationCache.get(clazz);
/* 225 */     for (AnnotationCacheEntry entry : annotations) {
/* 226 */       if (entry.getType() == AnnotationCacheEntryType.POST_CONSTRUCT) {
/* 227 */         Method postConstruct = getMethod(clazz, entry);
/* 228 */         synchronized (postConstruct) {
/* 229 */           boolean accessibility = postConstruct.isAccessible();
/* 230 */           postConstruct.setAccessible(true);
/* 231 */           postConstruct.invoke(instance, new Object[0]);
/* 232 */           postConstruct.setAccessible(accessibility);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void preDestroy(Object instance, Class<?> clazz)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 251 */     Class<?> superClass = clazz.getSuperclass();
/* 252 */     if (superClass != Object.class) {
/* 253 */       preDestroy(instance, superClass);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 258 */     AnnotationCacheEntry[] annotations = (AnnotationCacheEntry[])this.annotationCache.get(clazz);
/* 259 */     if (annotations == null)
/*     */     {
/* 261 */       return;
/*     */     }
/* 263 */     for (AnnotationCacheEntry entry : annotations) {
/* 264 */       if (entry.getType() == AnnotationCacheEntryType.PRE_DESTROY) {
/* 265 */         Method preDestroy = getMethod(clazz, entry);
/* 266 */         synchronized (preDestroy) {
/* 267 */           boolean accessibility = preDestroy.isAccessible();
/* 268 */           preDestroy.setAccessible(true);
/* 269 */           preDestroy.invoke(instance, new Object[0]);
/* 270 */           preDestroy.setAccessible(accessibility);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void backgroundProcess()
/*     */   {
/* 279 */     this.annotationCache.maintain();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void populateAnnotationsCache(Class<?> clazz, Map<String, String> injections)
/*     */     throws IllegalAccessException, InvocationTargetException, NamingException
/*     */   {
/* 299 */     List<AnnotationCacheEntry> annotations = null;
/* 300 */     Set<String> injectionsMatchedToSetter = new HashSet();
/*     */     
/* 302 */     while (clazz != null) {
/* 303 */       AnnotationCacheEntry[] annotationsArray = (AnnotationCacheEntry[])this.annotationCache.get(clazz);
/* 304 */       if (annotationsArray == null) {
/* 305 */         if (annotations == null) {
/* 306 */           annotations = new ArrayList();
/*     */         } else {
/* 308 */           annotations.clear();
/*     */         }
/*     */         
/*     */ 
/* 312 */         Method[] methods = Introspection.getDeclaredMethods(clazz);
/* 313 */         Method postConstruct = null;
/* 314 */         String postConstructFromXml = (String)this.postConstructMethods.get(clazz.getName());
/* 315 */         Method preDestroy = null;
/* 316 */         String preDestroyFromXml = (String)this.preDestroyMethods.get(clazz.getName());
/* 317 */         Method[] arrayOfMethod1 = methods;int i = arrayOfMethod1.length; Method method; for (Method localMethod1 = 0; localMethod1 < i; localMethod1++) { method = arrayOfMethod1[localMethod1];
/* 318 */           if (this.context != null)
/*     */           {
/* 320 */             if ((injections != null) && (Introspection.isValidSetter(method))) {
/* 321 */               String fieldName = Introspection.getPropertyName(method);
/* 322 */               injectionsMatchedToSetter.add(fieldName);
/* 323 */               if (injections.containsKey(fieldName)) {
/* 324 */                 annotations.add(new AnnotationCacheEntry(method
/* 325 */                   .getName(), method
/* 326 */                   .getParameterTypes(), 
/* 327 */                   (String)injections.get(fieldName), AnnotationCacheEntryType.SETTER));
/*     */                 
/* 329 */                 continue;
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */             Resource resourceAnnotation;
/*     */             
/*     */ 
/* 337 */             if ((resourceAnnotation = (Resource)method.getAnnotation(Resource.class)) != null) {
/* 338 */               annotations.add(new AnnotationCacheEntry(method
/* 339 */                 .getName(), method
/* 340 */                 .getParameterTypes(), resourceAnnotation
/* 341 */                 .name(), AnnotationCacheEntryType.SETTER));
/*     */             } else { Annotation ejbAnnotation;
/* 343 */               if ((EJB_PRESENT) && 
/* 344 */                 ((ejbAnnotation = method.getAnnotation(EJB.class)) != null)) {
/* 345 */                 annotations.add(new AnnotationCacheEntry(method
/* 346 */                   .getName(), method
/* 347 */                   .getParameterTypes(), ((EJB)ejbAnnotation)
/* 348 */                   .name(), AnnotationCacheEntryType.SETTER));
/*     */               } else { Annotation webServiceRefAnnotation;
/* 350 */                 if ((WS_PRESENT) && 
/* 351 */                   ((webServiceRefAnnotation = method.getAnnotation(WebServiceRef.class)) != null)) {
/* 352 */                   annotations.add(new AnnotationCacheEntry(method
/* 353 */                     .getName(), method
/* 354 */                     .getParameterTypes(), ((WebServiceRef)webServiceRefAnnotation)
/* 355 */                     .name(), AnnotationCacheEntryType.SETTER));
/*     */                 } else { Annotation persistenceContextAnnotation;
/* 357 */                   if ((JPA_PRESENT) && 
/* 358 */                     ((persistenceContextAnnotation = method.getAnnotation(PersistenceContext.class)) != null)) {
/* 359 */                     annotations.add(new AnnotationCacheEntry(method
/* 360 */                       .getName(), method
/* 361 */                       .getParameterTypes(), ((PersistenceContext)persistenceContextAnnotation)
/* 362 */                       .name(), AnnotationCacheEntryType.SETTER));
/*     */                   } else { Annotation persistenceUnitAnnotation;
/* 364 */                     if ((JPA_PRESENT) && 
/* 365 */                       ((persistenceUnitAnnotation = method.getAnnotation(PersistenceUnit.class)) != null))
/* 366 */                       annotations.add(new AnnotationCacheEntry(method
/* 367 */                         .getName(), method
/* 368 */                         .getParameterTypes(), ((PersistenceUnit)persistenceUnitAnnotation)
/* 369 */                         .name(), AnnotationCacheEntryType.SETTER));
/*     */                   }
/*     */                 }
/*     */               }
/*     */             } }
/* 374 */           postConstruct = findPostConstruct(postConstruct, postConstructFromXml, method);
/*     */           
/* 376 */           preDestroy = findPreDestroy(preDestroy, preDestroyFromXml, method);
/*     */         }
/*     */         
/* 379 */         if (postConstruct != null) {
/* 380 */           annotations.add(new AnnotationCacheEntry(postConstruct
/* 381 */             .getName(), postConstruct
/* 382 */             .getParameterTypes(), null, AnnotationCacheEntryType.POST_CONSTRUCT));
/*     */         }
/* 384 */         else if (postConstructFromXml != null) {
/* 385 */           throw new IllegalArgumentException(sm.getString("defaultInstanceManager.postConstructNotFound", new Object[] { postConstructFromXml, clazz
/* 386 */             .getName() }));
/*     */         }
/* 388 */         if (preDestroy != null) {
/* 389 */           annotations.add(new AnnotationCacheEntry(preDestroy
/* 390 */             .getName(), preDestroy
/* 391 */             .getParameterTypes(), null, AnnotationCacheEntryType.PRE_DESTROY));
/*     */         }
/* 393 */         else if (preDestroyFromXml != null) {
/* 394 */           throw new IllegalArgumentException(sm.getString("defaultInstanceManager.preDestroyNotFound", new Object[] { preDestroyFromXml, clazz
/* 395 */             .getName() }));
/*     */         }
/*     */         
/* 398 */         if (this.context != null)
/*     */         {
/*     */ 
/* 401 */           Field[] fields = Introspection.getDeclaredFields(clazz);
/* 402 */           Field[] arrayOfField1 = fields;localMethod1 = arrayOfField1.length; for (method = 0; method < localMethod1; method++) { Field field = arrayOfField1[method];
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 408 */             String fieldName = field.getName();
/* 409 */             if ((injections != null) && (injections.containsKey(fieldName)) && (!injectionsMatchedToSetter.contains(fieldName))) {
/* 410 */               annotations.add(new AnnotationCacheEntry(fieldName, null, 
/*     */               
/* 412 */                 (String)injections.get(fieldName), AnnotationCacheEntryType.FIELD));
/*     */             } else {
/*     */               Resource resourceAnnotation;
/* 415 */               if ((resourceAnnotation = (Resource)field.getAnnotation(Resource.class)) != null) {
/* 416 */                 annotations.add(new AnnotationCacheEntry(fieldName, null, resourceAnnotation
/* 417 */                   .name(), AnnotationCacheEntryType.FIELD)); } else { Annotation ejbAnnotation;
/* 418 */                 if ((EJB_PRESENT) && 
/* 419 */                   ((ejbAnnotation = field.getAnnotation(EJB.class)) != null)) {
/* 420 */                   annotations.add(new AnnotationCacheEntry(fieldName, null, ((EJB)ejbAnnotation)
/* 421 */                     .name(), AnnotationCacheEntryType.FIELD)); } else { Annotation webServiceRefAnnotation;
/* 422 */                   if ((WS_PRESENT) && 
/* 423 */                     ((webServiceRefAnnotation = field.getAnnotation(WebServiceRef.class)) != null)) {
/* 424 */                     annotations.add(new AnnotationCacheEntry(fieldName, null, ((WebServiceRef)webServiceRefAnnotation)
/* 425 */                       .name(), AnnotationCacheEntryType.FIELD));
/*     */                   } else { Annotation persistenceContextAnnotation;
/* 427 */                     if ((JPA_PRESENT) && 
/* 428 */                       ((persistenceContextAnnotation = field.getAnnotation(PersistenceContext.class)) != null)) {
/* 429 */                       annotations.add(new AnnotationCacheEntry(fieldName, null, ((PersistenceContext)persistenceContextAnnotation)
/* 430 */                         .name(), AnnotationCacheEntryType.FIELD));
/*     */                     } else { Annotation persistenceUnitAnnotation;
/* 432 */                       if ((JPA_PRESENT) && 
/* 433 */                         ((persistenceUnitAnnotation = field.getAnnotation(PersistenceUnit.class)) != null))
/* 434 */                         annotations.add(new AnnotationCacheEntry(fieldName, null, ((PersistenceUnit)persistenceUnitAnnotation)
/* 435 */                           .name(), AnnotationCacheEntryType.FIELD));
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             } } }
/* 441 */         if (annotations.isEmpty())
/*     */         {
/* 443 */           annotationsArray = ANNOTATIONS_EMPTY;
/*     */         } else {
/* 445 */           annotationsArray = (AnnotationCacheEntry[])annotations.toArray(new AnnotationCacheEntry[0]);
/*     */         }
/* 447 */         synchronized (this.annotationCache) {
/* 448 */           this.annotationCache.put(clazz, annotationsArray);
/*     */         }
/*     */       }
/* 451 */       clazz = clazz.getSuperclass();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void processAnnotations(Object instance, Map<String, String> injections)
/*     */     throws IllegalAccessException, InvocationTargetException, NamingException
/*     */   {
/* 469 */     if (this.context == null)
/*     */     {
/* 471 */       return;
/*     */     }
/*     */     
/* 474 */     Class<?> clazz = instance.getClass();
/*     */     
/* 476 */     while (clazz != null) {
/* 477 */       AnnotationCacheEntry[] annotations = (AnnotationCacheEntry[])this.annotationCache.get(clazz);
/* 478 */       for (AnnotationCacheEntry entry : annotations) {
/* 479 */         if (entry.getType() == AnnotationCacheEntryType.SETTER) {
/* 480 */           lookupMethodResource(this.context, instance, 
/* 481 */             getMethod(clazz, entry), entry
/* 482 */             .getName(), clazz);
/* 483 */         } else if (entry.getType() == AnnotationCacheEntryType.FIELD) {
/* 484 */           lookupFieldResource(this.context, instance, 
/* 485 */             getField(clazz, entry), entry
/* 486 */             .getName(), clazz);
/*     */         }
/*     */       }
/* 489 */       clazz = clazz.getSuperclass();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getAnnotationCacheSize()
/*     */   {
/* 500 */     return this.annotationCache.size();
/*     */   }
/*     */   
/*     */   protected Class<?> loadClassMaybePrivileged(String className, ClassLoader classLoader)
/*     */     throws ClassNotFoundException
/*     */   {
/*     */     Class<?> clazz;
/* 507 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 509 */         clazz = (Class)AccessController.doPrivileged(new PrivilegedLoadClass(className, classLoader));
/*     */       } catch (PrivilegedActionException e) {
/*     */         Class<?> clazz;
/* 512 */         Throwable t = e.getCause();
/* 513 */         if ((t instanceof ClassNotFoundException)) {
/* 514 */           throw ((ClassNotFoundException)t);
/*     */         }
/* 516 */         throw new RuntimeException(t);
/*     */       }
/*     */     } else {
/* 519 */       clazz = loadClass(className, classLoader);
/*     */     }
/* 521 */     checkAccess(clazz);
/* 522 */     return clazz;
/*     */   }
/*     */   
/*     */   protected Class<?> loadClass(String className, ClassLoader classLoader) throws ClassNotFoundException
/*     */   {
/* 527 */     if (className.startsWith("org.apache.catalina")) {
/* 528 */       return this.containerClassLoader.loadClass(className);
/*     */     }
/*     */     try {
/* 531 */       Class<?> clazz = this.containerClassLoader.loadClass(className);
/* 532 */       if (ContainerServlet.class.isAssignableFrom(clazz)) {
/* 533 */         return clazz;
/*     */       }
/*     */     } catch (Throwable t) {
/* 536 */       ExceptionUtils.handleThrowable(t);
/*     */     }
/* 538 */     return classLoader.loadClass(className);
/*     */   }
/*     */   
/*     */   private void checkAccess(Class<?> clazz) {
/* 542 */     if (this.privileged) {
/* 543 */       return;
/*     */     }
/* 545 */     if (ContainerServlet.class.isAssignableFrom(clazz)) {
/* 546 */       throw new SecurityException(sm.getString("defaultInstanceManager.restrictedContainerServlet", new Object[] { clazz }));
/*     */     }
/*     */     
/* 549 */     while (clazz != null) {
/* 550 */       if (this.restrictedClasses.contains(clazz.getName())) {
/* 551 */         throw new SecurityException(sm.getString("defaultInstanceManager.restrictedClass", new Object[] { clazz }));
/*     */       }
/*     */       
/* 554 */       clazz = clazz.getSuperclass();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void lookupFieldResource(javax.naming.Context context, Object instance, Field field, String name, Class<?> clazz)
/*     */     throws NamingException, IllegalAccessException
/*     */   {
/* 576 */     String normalizedName = normalize(name);
/*     */     Object lookedupResource;
/* 578 */     Object lookedupResource; if ((normalizedName != null) && (normalizedName.length() > 0)) {
/* 579 */       lookedupResource = context.lookup(normalizedName);
/*     */     }
/*     */     else {
/* 582 */       lookedupResource = context.lookup(clazz.getName() + "/" + field.getName());
/*     */     }
/*     */     
/* 585 */     synchronized (field) {
/* 586 */       boolean accessibility = field.isAccessible();
/* 587 */       field.setAccessible(true);
/* 588 */       field.set(instance, lookedupResource);
/* 589 */       field.setAccessible(accessibility);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     boolean accessibility;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void lookupMethodResource(javax.naming.Context context, Object instance, Method method, String name, Class<?> clazz)
/*     */     throws NamingException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 610 */     if (!Introspection.isValidSetter(method))
/*     */     {
/* 612 */       throw new IllegalArgumentException(sm.getString("defaultInstanceManager.invalidInjection"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 618 */     String normalizedName = normalize(name);
/*     */     Object lookedupResource;
/* 620 */     Object lookedupResource; if ((normalizedName != null) && (normalizedName.length() > 0)) {
/* 621 */       lookedupResource = context.lookup(normalizedName);
/*     */     } else {
/* 623 */       lookedupResource = context.lookup(clazz
/* 624 */         .getName() + "/" + Introspection.getPropertyName(method));
/*     */     }
/*     */     
/* 627 */     synchronized (method) {
/* 628 */       boolean accessibility = method.isAccessible();
/* 629 */       method.setAccessible(true);
/* 630 */       method.invoke(instance, new Object[] { lookedupResource });
/* 631 */       method.setAccessible(accessibility);
/*     */     }
/*     */     boolean accessibility;
/*     */   }
/*     */   
/*     */   private static void loadProperties(Set<String> classNames, String resourceName, String messageKey, Log log) {
/* 637 */     Properties properties = new Properties();
/* 638 */     ClassLoader cl = DefaultInstanceManager.class.getClassLoader();
/* 639 */     try { InputStream is = cl.getResourceAsStream(resourceName);Throwable localThrowable3 = null;
/* 640 */       try { if (is == null) {
/* 641 */           log.error(sm.getString(messageKey, new Object[] { resourceName }));
/*     */         } else {
/* 643 */           properties.load(is);
/*     */         }
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 639 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/* 645 */         if (is != null) if (localThrowable3 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else is.close();
/* 646 */       } } catch (IOException ioe) { log.error(sm.getString(messageKey, new Object[] { resourceName }), ioe);
/*     */     }
/* 648 */     if (properties.isEmpty()) {
/* 649 */       return;
/*     */     }
/* 651 */     for (Object e : properties.entrySet()) {
/* 652 */       if ("restricted".equals(((Map.Entry)e).getValue())) {
/* 653 */         classNames.add(((Map.Entry)e).getKey().toString());
/*     */       } else {
/* 655 */         log.warn(sm.getString("defaultInstanceManager.restrictedWrongValue", new Object[] { resourceName, ((Map.Entry)e)
/*     */         
/* 657 */           .getKey(), ((Map.Entry)e).getValue() }));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static String normalize(String jndiName) {
/* 663 */     if ((jndiName != null) && (jndiName.startsWith("java:comp/env/"))) {
/* 664 */       return jndiName.substring(14);
/*     */     }
/* 666 */     return jndiName;
/*     */   }
/*     */   
/*     */   private static Method getMethod(Class<?> clazz, AnnotationCacheEntry entry)
/*     */   {
/* 671 */     Method result = null;
/* 672 */     if (Globals.IS_SECURITY_ENABLED) {
/* 673 */       result = (Method)AccessController.doPrivileged(new PrivilegedGetMethod(clazz, entry));
/*     */     } else {
/*     */       try {
/* 676 */         result = clazz.getDeclaredMethod(entry
/* 677 */           .getAccessibleObjectName(), entry.getParamTypes());
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException) {}
/*     */     }
/*     */     
/* 682 */     return result;
/*     */   }
/*     */   
/*     */   private static Field getField(Class<?> clazz, AnnotationCacheEntry entry)
/*     */   {
/* 687 */     Field result = null;
/* 688 */     if (Globals.IS_SECURITY_ENABLED) {
/* 689 */       result = (Field)AccessController.doPrivileged(new PrivilegedGetField(clazz, entry));
/*     */     } else {
/*     */       try {
/* 692 */         result = clazz.getDeclaredField(entry.getAccessibleObjectName());
/*     */       }
/*     */       catch (NoSuchFieldException localNoSuchFieldException) {}
/*     */     }
/*     */     
/* 697 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   private static Method findPostConstruct(Method currentPostConstruct, String postConstructFromXml, Method method)
/*     */   {
/* 703 */     return findLifecycleCallback(currentPostConstruct, postConstructFromXml, method, PostConstruct.class);
/*     */   }
/*     */   
/*     */ 
/*     */   private static Method findPreDestroy(Method currentPreDestroy, String preDestroyFromXml, Method method)
/*     */   {
/* 709 */     return findLifecycleCallback(currentPreDestroy, preDestroyFromXml, method, PreDestroy.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static Method findLifecycleCallback(Method currentMethod, String methodNameFromXml, Method method, Class<? extends Annotation> annotation)
/*     */   {
/* 716 */     Method result = currentMethod;
/* 717 */     if (methodNameFromXml != null) {
/* 718 */       if (method.getName().equals(methodNameFromXml)) {
/* 719 */         if (!Introspection.isValidLifecycleCallback(method))
/*     */         {
/* 721 */           throw new IllegalArgumentException("Invalid " + annotation.getName() + " annotation");
/*     */         }
/* 723 */         result = method;
/*     */       }
/*     */     }
/* 726 */     else if (method.isAnnotationPresent(annotation)) {
/* 727 */       if ((currentMethod != null) || (!Introspection.isValidLifecycleCallback(method)))
/*     */       {
/* 729 */         throw new IllegalArgumentException("Invalid " + annotation.getName() + " annotation");
/*     */       }
/* 731 */       result = method;
/*     */     }
/*     */     
/* 734 */     return result;
/*     */   }
/*     */   
/*     */   private static final class AnnotationCacheEntry
/*     */   {
/*     */     private final String accessibleObjectName;
/*     */     private final Class<?>[] paramTypes;
/*     */     private final String name;
/*     */     private final DefaultInstanceManager.AnnotationCacheEntryType type;
/*     */     
/*     */     public AnnotationCacheEntry(String accessibleObjectName, Class<?>[] paramTypes, String name, DefaultInstanceManager.AnnotationCacheEntryType type)
/*     */     {
/* 746 */       this.accessibleObjectName = accessibleObjectName;
/* 747 */       this.paramTypes = paramTypes;
/* 748 */       this.name = name;
/* 749 */       this.type = type;
/*     */     }
/*     */     
/*     */     public String getAccessibleObjectName() {
/* 753 */       return this.accessibleObjectName;
/*     */     }
/*     */     
/*     */     public Class<?>[] getParamTypes() {
/* 757 */       return this.paramTypes;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 761 */       return this.name;
/*     */     }
/*     */     
/* 764 */     public DefaultInstanceManager.AnnotationCacheEntryType getType() { return this.type; }
/*     */   }
/*     */   
/*     */ 
/*     */   private static enum AnnotationCacheEntryType
/*     */   {
/* 770 */     FIELD,  SETTER,  POST_CONSTRUCT,  PRE_DESTROY;
/*     */     
/*     */     private AnnotationCacheEntryType() {}
/*     */   }
/*     */   
/*     */   private static class PrivilegedGetField implements PrivilegedAction<Field> {
/*     */     private final Class<?> clazz;
/*     */     private final DefaultInstanceManager.AnnotationCacheEntry entry;
/*     */     
/*     */     public PrivilegedGetField(Class<?> clazz, DefaultInstanceManager.AnnotationCacheEntry entry) {
/* 780 */       this.clazz = clazz;
/* 781 */       this.entry = entry;
/*     */     }
/*     */     
/*     */     public Field run()
/*     */     {
/* 786 */       Field result = null;
/*     */       try {
/* 788 */         result = this.clazz.getDeclaredField(this.entry.getAccessibleObjectName());
/*     */       }
/*     */       catch (NoSuchFieldException localNoSuchFieldException) {}
/*     */       
/* 792 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedGetMethod implements PrivilegedAction<Method>
/*     */   {
/*     */     private final Class<?> clazz;
/*     */     private final DefaultInstanceManager.AnnotationCacheEntry entry;
/*     */     
/*     */     public PrivilegedGetMethod(Class<?> clazz, DefaultInstanceManager.AnnotationCacheEntry entry)
/*     */     {
/* 803 */       this.clazz = clazz;
/* 804 */       this.entry = entry;
/*     */     }
/*     */     
/*     */     public Method run()
/*     */     {
/* 809 */       Method result = null;
/*     */       try {
/* 811 */         result = this.clazz.getDeclaredMethod(this.entry
/* 812 */           .getAccessibleObjectName(), this.entry.getParamTypes());
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException) {}
/*     */       
/* 816 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   private class PrivilegedLoadClass implements PrivilegedExceptionAction<Class<?>>
/*     */   {
/*     */     private final String className;
/*     */     private final ClassLoader classLoader;
/*     */     
/*     */     public PrivilegedLoadClass(String className, ClassLoader classLoader)
/*     */     {
/* 827 */       this.className = className;
/* 828 */       this.classLoader = classLoader;
/*     */     }
/*     */     
/*     */     public Class<?> run() throws Exception
/*     */     {
/* 833 */       return DefaultInstanceManager.this.loadClass(this.className, this.classLoader);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\DefaultInstanceManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */