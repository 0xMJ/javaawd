/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharsetMapper
/*     */ {
/*     */   public static final String DEFAULT_RESOURCE = "/org/apache/catalina/util/CharsetMapperDefault.properties";
/*     */   
/*     */   public CharsetMapper()
/*     */   {
/*  59 */     this("/org/apache/catalina/util/CharsetMapperDefault.properties");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CharsetMapper(String name)
/*     */   {
/*  72 */     if (JreCompat.isGraalAvailable())
/*  73 */       this.map.put("en", "ISO-8859-1"); else {
/*     */       try {
/*  75 */         InputStream stream = getClass().getResourceAsStream(name);Throwable localThrowable4 = null;
/*  76 */         try { this.map.load(stream);
/*     */         }
/*     */         catch (Throwable localThrowable2)
/*     */         {
/*  75 */           localThrowable4 = localThrowable2;throw localThrowable2;
/*     */         } finally {
/*  77 */           if (stream != null) if (localThrowable4 != null) try { stream.close(); } catch (Throwable localThrowable3) { localThrowable4.addSuppressed(localThrowable3); } else stream.close();
/*  78 */         } } catch (Throwable t) { ExceptionUtils.handleThrowable(t);
/*  79 */         throw new IllegalArgumentException(t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */   private Properties map = new Properties();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCharset(Locale locale)
/*     */   {
/* 109 */     String charset = this.map.getProperty(locale.toString());
/* 110 */     if (charset == null) {
/* 111 */       charset = this.map.getProperty(locale.getLanguage() + "_" + locale
/* 112 */         .getCountry());
/* 113 */       if (charset == null) {
/* 114 */         charset = this.map.getProperty(locale.getLanguage());
/*     */       }
/*     */     }
/* 117 */     return charset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCharsetMappingFromDeploymentDescriptor(String locale, String charset)
/*     */   {
/* 131 */     this.map.put(locale, charset);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\CharsetMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */