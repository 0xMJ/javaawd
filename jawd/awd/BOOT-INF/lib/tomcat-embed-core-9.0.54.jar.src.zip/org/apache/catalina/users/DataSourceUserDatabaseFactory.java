/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ import javax.sql.DataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceUserDatabaseFactory
/*     */   implements ObjectFactory
/*     */ {
/*     */   public Object getObjectInstance(Object obj, Name name, Context nameCtx, Hashtable<?, ?> environment)
/*     */     throws Exception
/*     */   {
/*  74 */     if ((obj == null) || (!(obj instanceof Reference))) {
/*  75 */       return null;
/*     */     }
/*  77 */     Reference ref = (Reference)obj;
/*  78 */     if (!"org.apache.catalina.UserDatabase".equals(ref.getClassName())) {
/*  79 */       return null;
/*     */     }
/*     */     
/*  82 */     DataSource dataSource = null;
/*  83 */     String dataSourceName = null;
/*  84 */     RefAddr ra = null;
/*     */     
/*  86 */     ra = ref.get("dataSourceName");
/*  87 */     if (ra != null) {
/*  88 */       dataSourceName = ra.getContent().toString();
/*  89 */       dataSource = (DataSource)nameCtx.lookup(dataSourceName);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  94 */     DataSourceUserDatabase database = new DataSourceUserDatabase(dataSource, name.toString());
/*  95 */     database.setDataSourceName(dataSourceName);
/*     */     
/*  97 */     ra = ref.get("readonly");
/*  98 */     if (ra != null) {
/*  99 */       database.setReadonly(Boolean.parseBoolean(ra.getContent().toString()));
/*     */     }
/*     */     
/* 102 */     ra = ref.get("userTable");
/* 103 */     if (ra != null) {
/* 104 */       database.setUserTable(ra.getContent().toString());
/*     */     }
/*     */     
/* 107 */     ra = ref.get("groupTable");
/* 108 */     if (ra != null) {
/* 109 */       database.setGroupTable(ra.getContent().toString());
/*     */     }
/*     */     
/* 112 */     ra = ref.get("roleTable");
/* 113 */     if (ra != null) {
/* 114 */       database.setRoleTable(ra.getContent().toString());
/*     */     }
/*     */     
/* 117 */     ra = ref.get("userRoleTable");
/* 118 */     if (ra != null) {
/* 119 */       database.setUserRoleTable(ra.getContent().toString());
/*     */     }
/*     */     
/* 122 */     ra = ref.get("userGroupTable");
/* 123 */     if (ra != null) {
/* 124 */       database.setUserGroupTable(ra.getContent().toString());
/*     */     }
/*     */     
/* 127 */     ra = ref.get("groupRoleTable");
/* 128 */     if (ra != null) {
/* 129 */       database.setGroupRoleTable(ra.getContent().toString());
/*     */     }
/*     */     
/* 132 */     ra = ref.get("roleNameCol");
/* 133 */     if (ra != null) {
/* 134 */       database.setRoleNameCol(ra.getContent().toString());
/*     */     }
/*     */     
/* 137 */     ra = ref.get("roleAndGroupDescriptionCol");
/* 138 */     if (ra != null) {
/* 139 */       database.setRoleAndGroupDescriptionCol(ra.getContent().toString());
/*     */     }
/*     */     
/* 142 */     ra = ref.get("groupNameCol");
/* 143 */     if (ra != null) {
/* 144 */       database.setGroupNameCol(ra.getContent().toString());
/*     */     }
/*     */     
/* 147 */     ra = ref.get("userCredCol");
/* 148 */     if (ra != null) {
/* 149 */       database.setUserCredCol(ra.getContent().toString());
/*     */     }
/*     */     
/* 152 */     ra = ref.get("userFullNameCol");
/* 153 */     if (ra != null) {
/* 154 */       database.setUserFullNameCol(ra.getContent().toString());
/*     */     }
/*     */     
/* 157 */     ra = ref.get("userNameCol");
/* 158 */     if (ra != null) {
/* 159 */       database.setUserNameCol(ra.getContent().toString());
/*     */     }
/*     */     
/*     */ 
/* 163 */     database.open();
/* 164 */     return database;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\users\DataSourceUserDatabaseFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */