/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.Permission;
/*     */ import java.security.cert.Certificate;
/*     */ import java.text.Collator;
/*     */ import java.util.Arrays;
/*     */ import java.util.Locale;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachedResource
/*     */   implements WebResource
/*     */ {
/*  50 */   private static final Log log = LogFactory.getLog(CachedResource.class);
/*  51 */   private static final StringManager sm = StringManager.getManager(CachedResource.class);
/*     */   
/*     */   private static final long CACHE_ENTRY_SIZE = 500L;
/*     */   
/*     */   private final Cache cache;
/*     */   
/*     */   private final StandardRoot root;
/*     */   
/*     */   private final String webAppPath;
/*     */   
/*     */   private final long ttl;
/*     */   
/*     */   private final int objectMaxSizeBytes;
/*     */   private final boolean usesClassLoaderResources;
/*     */   private volatile WebResource webResource;
/*     */   private volatile WebResource[] webResources;
/*     */   private volatile long nextCheck;
/*  68 */   private volatile Long cachedLastModified = null;
/*  69 */   private volatile String cachedLastModifiedHttp = null;
/*  70 */   private volatile byte[] cachedContent = null;
/*  71 */   private volatile Boolean cachedIsFile = null;
/*  72 */   private volatile Boolean cachedIsDirectory = null;
/*  73 */   private volatile Boolean cachedExists = null;
/*  74 */   private volatile Boolean cachedIsVirtual = null;
/*  75 */   private volatile Long cachedContentLength = null;
/*     */   
/*     */ 
/*     */   public CachedResource(Cache cache, StandardRoot root, String path, long ttl, int objectMaxSizeBytes, boolean usesClassLoaderResources)
/*     */   {
/*  80 */     this.cache = cache;
/*  81 */     this.root = root;
/*  82 */     this.webAppPath = path;
/*  83 */     this.ttl = ttl;
/*  84 */     this.objectMaxSizeBytes = objectMaxSizeBytes;
/*  85 */     this.usesClassLoaderResources = usesClassLoaderResources;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean validateResource(boolean useClassLoaderResources)
/*     */   {
/*  96 */     if (this.usesClassLoaderResources != useClassLoaderResources) {
/*  97 */       return false;
/*     */     }
/*     */     
/* 100 */     long now = System.currentTimeMillis();
/*     */     
/* 102 */     if (this.webResource == null) {
/* 103 */       synchronized (this) {
/* 104 */         if (this.webResource == null) {
/* 105 */           this.webResource = this.root.getResourceInternal(this.webAppPath, useClassLoaderResources);
/*     */           
/* 107 */           getLastModified();
/* 108 */           getContentLength();
/* 109 */           this.nextCheck = (this.ttl + now);
/*     */           
/*     */ 
/* 112 */           if ((this.webResource instanceof EmptyResource)) {
/* 113 */             this.cachedExists = Boolean.FALSE;
/*     */           } else {
/* 115 */             this.cachedExists = Boolean.TRUE;
/*     */           }
/* 117 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 122 */     if (now < this.nextCheck) {
/* 123 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 127 */     if (!this.root.isPackedWarFile()) {
/* 128 */       WebResource webResourceInternal = this.root.getResourceInternal(this.webAppPath, useClassLoaderResources);
/*     */       
/* 130 */       if ((!this.webResource.exists()) && (webResourceInternal.exists())) {
/* 131 */         return false;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 136 */       if ((this.webResource.getLastModified() != getLastModified()) || 
/* 137 */         (this.webResource.getContentLength() != getContentLength())) {
/* 138 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 142 */       if ((this.webResource.getLastModified() != webResourceInternal.getLastModified()) || 
/* 143 */         (this.webResource.getContentLength() != webResourceInternal.getContentLength())) {
/* 144 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 148 */     this.nextCheck = (this.ttl + now);
/* 149 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean validateResources(boolean useClassLoaderResources) {
/* 153 */     long now = System.currentTimeMillis();
/*     */     
/* 155 */     if (this.webResources == null) {
/* 156 */       synchronized (this) {
/* 157 */         if (this.webResources == null) {
/* 158 */           this.webResources = this.root.getResourcesInternal(this.webAppPath, useClassLoaderResources);
/*     */           
/* 160 */           this.nextCheck = (this.ttl + now);
/* 161 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 166 */     if (now < this.nextCheck) {
/* 167 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 171 */     if (this.root.isPackedWarFile()) {
/* 172 */       this.nextCheck = (this.ttl + now);
/* 173 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 177 */     return false;
/*     */   }
/*     */   
/*     */   protected long getNextCheck()
/*     */   {
/* 182 */     return this.nextCheck;
/*     */   }
/*     */   
/*     */   public long getLastModified()
/*     */   {
/* 187 */     Long cachedLastModified = this.cachedLastModified;
/* 188 */     if (cachedLastModified == null)
/*     */     {
/* 190 */       cachedLastModified = Long.valueOf(this.webResource.getLastModified());
/* 191 */       this.cachedLastModified = cachedLastModified;
/*     */     }
/* 193 */     return cachedLastModified.longValue();
/*     */   }
/*     */   
/*     */   public String getLastModifiedHttp()
/*     */   {
/* 198 */     String cachedLastModifiedHttp = this.cachedLastModifiedHttp;
/* 199 */     if (cachedLastModifiedHttp == null) {
/* 200 */       cachedLastModifiedHttp = this.webResource.getLastModifiedHttp();
/* 201 */       this.cachedLastModifiedHttp = cachedLastModifiedHttp;
/*     */     }
/* 203 */     return cachedLastModifiedHttp;
/*     */   }
/*     */   
/*     */   public boolean exists()
/*     */   {
/* 208 */     Boolean cachedExists = this.cachedExists;
/* 209 */     if (cachedExists == null) {
/* 210 */       cachedExists = Boolean.valueOf(this.webResource.exists());
/* 211 */       this.cachedExists = cachedExists;
/*     */     }
/* 213 */     return cachedExists.booleanValue();
/*     */   }
/*     */   
/*     */   public boolean isVirtual()
/*     */   {
/* 218 */     Boolean cachedIsVirtual = this.cachedIsVirtual;
/* 219 */     if (cachedIsVirtual == null) {
/* 220 */       cachedIsVirtual = Boolean.valueOf(this.webResource.isVirtual());
/* 221 */       this.cachedIsVirtual = cachedIsVirtual;
/*     */     }
/* 223 */     return cachedIsVirtual.booleanValue();
/*     */   }
/*     */   
/*     */   public boolean isDirectory()
/*     */   {
/* 228 */     Boolean cachedIsDirectory = this.cachedIsDirectory;
/* 229 */     if (cachedIsDirectory == null) {
/* 230 */       cachedIsDirectory = Boolean.valueOf(this.webResource.isDirectory());
/* 231 */       this.cachedIsDirectory = cachedIsDirectory;
/*     */     }
/* 233 */     return cachedIsDirectory.booleanValue();
/*     */   }
/*     */   
/*     */   public boolean isFile()
/*     */   {
/* 238 */     Boolean cachedIsFile = this.cachedIsFile;
/* 239 */     if (cachedIsFile == null) {
/* 240 */       cachedIsFile = Boolean.valueOf(this.webResource.isFile());
/* 241 */       this.cachedIsFile = cachedIsFile;
/*     */     }
/* 243 */     return cachedIsFile.booleanValue();
/*     */   }
/*     */   
/*     */   public boolean delete()
/*     */   {
/* 248 */     boolean deleteResult = this.webResource.delete();
/* 249 */     if (deleteResult) {
/* 250 */       this.cache.removeCacheEntry(this.webAppPath);
/*     */     }
/* 252 */     return deleteResult;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 257 */     return this.webResource.getName();
/*     */   }
/*     */   
/*     */   public long getContentLength()
/*     */   {
/* 262 */     Long cachedContentLength = this.cachedContentLength;
/* 263 */     if (cachedContentLength == null) {
/* 264 */       long result = 0L;
/* 265 */       if (this.webResource != null) {
/* 266 */         result = this.webResource.getContentLength();
/* 267 */         cachedContentLength = Long.valueOf(result);
/* 268 */         this.cachedContentLength = cachedContentLength;
/*     */       }
/* 270 */       return result;
/*     */     }
/* 272 */     return cachedContentLength.longValue();
/*     */   }
/*     */   
/*     */   public String getCanonicalPath()
/*     */   {
/* 277 */     return this.webResource.getCanonicalPath();
/*     */   }
/*     */   
/*     */   public boolean canRead()
/*     */   {
/* 282 */     return this.webResource.canRead();
/*     */   }
/*     */   
/*     */   public String getWebappPath()
/*     */   {
/* 287 */     return this.webAppPath;
/*     */   }
/*     */   
/*     */   public String getETag()
/*     */   {
/* 292 */     return this.webResource.getETag();
/*     */   }
/*     */   
/*     */   public void setMimeType(String mimeType)
/*     */   {
/* 297 */     this.webResource.setMimeType(mimeType);
/*     */   }
/*     */   
/*     */   public String getMimeType()
/*     */   {
/* 302 */     return this.webResource.getMimeType();
/*     */   }
/*     */   
/*     */   public InputStream getInputStream()
/*     */   {
/* 307 */     byte[] content = getContent();
/* 308 */     if (content == null)
/*     */     {
/* 310 */       return this.webResource.getInputStream();
/*     */     }
/* 312 */     return new ByteArrayInputStream(content);
/*     */   }
/*     */   
/*     */   public byte[] getContent()
/*     */   {
/* 317 */     byte[] cachedContent = this.cachedContent;
/* 318 */     if (cachedContent == null) {
/* 319 */       if (getContentLength() > this.objectMaxSizeBytes) {
/* 320 */         return null;
/*     */       }
/* 322 */       cachedContent = this.webResource.getContent();
/* 323 */       this.cachedContent = cachedContent;
/*     */     }
/* 325 */     return cachedContent;
/*     */   }
/*     */   
/*     */   public long getCreation()
/*     */   {
/* 330 */     return this.webResource.getCreation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URL getURL()
/*     */   {
/* 363 */     URL resourceURL = this.webResource.getURL();
/* 364 */     if (resourceURL == null) {
/* 365 */       return null;
/*     */     }
/*     */     try {
/* 368 */       CachedResourceURLStreamHandler handler = new CachedResourceURLStreamHandler(resourceURL, this.root, this.webAppPath, this.usesClassLoaderResources);
/*     */       
/* 370 */       URL result = new URL(null, resourceURL.toExternalForm(), handler);
/* 371 */       handler.setAssociatedURL(result);
/* 372 */       return result;
/*     */     } catch (MalformedURLException e) {
/* 374 */       log.error(sm.getString("cachedResource.invalidURL", new Object[] { resourceURL.toExternalForm() }), e); }
/* 375 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public URL getCodeBase()
/*     */   {
/* 381 */     return this.webResource.getCodeBase();
/*     */   }
/*     */   
/*     */   public Certificate[] getCertificates()
/*     */   {
/* 386 */     return this.webResource.getCertificates();
/*     */   }
/*     */   
/*     */   public Manifest getManifest()
/*     */   {
/* 391 */     return this.webResource.getManifest();
/*     */   }
/*     */   
/*     */   public WebResourceRoot getWebResourceRoot()
/*     */   {
/* 396 */     return this.webResource.getWebResourceRoot();
/*     */   }
/*     */   
/*     */   WebResource getWebResource() {
/* 400 */     return this.webResource;
/*     */   }
/*     */   
/*     */   WebResource[] getWebResources() {
/* 404 */     return this.webResources;
/*     */   }
/*     */   
/*     */   boolean usesClassLoaderResources() {
/* 408 */     return this.usesClassLoaderResources;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   long getSize()
/*     */   {
/* 416 */     long result = 500L;
/*     */     
/*     */ 
/*     */ 
/* 420 */     result += getWebappPath().length() * 2;
/* 421 */     if (getContentLength() <= this.objectMaxSizeBytes) {
/* 422 */       result += getContentLength();
/*     */     }
/* 424 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static InputStream buildInputStream(String[] files)
/*     */   {
/* 433 */     Arrays.sort(files, Collator.getInstance(Locale.getDefault()));
/* 434 */     StringBuilder result = new StringBuilder();
/* 435 */     for (String file : files) {
/* 436 */       result.append(file);
/*     */       
/* 438 */       result.append('\n');
/*     */     }
/* 440 */     return new ByteArrayInputStream(result.toString().getBytes(Charset.defaultCharset()));
/*     */   }
/*     */   
/*     */ 
/*     */   private static class CachedResourceURLStreamHandler
/*     */     extends URLStreamHandler
/*     */   {
/*     */     private final URL resourceURL;
/*     */     private final StandardRoot root;
/*     */     private final String webAppPath;
/*     */     private final boolean usesClassLoaderResources;
/* 451 */     private URL associatedURL = null;
/*     */     
/*     */     public CachedResourceURLStreamHandler(URL resourceURL, StandardRoot root, String webAppPath, boolean usesClassLoaderResources)
/*     */     {
/* 455 */       this.resourceURL = resourceURL;
/* 456 */       this.root = root;
/* 457 */       this.webAppPath = webAppPath;
/* 458 */       this.usesClassLoaderResources = usesClassLoaderResources;
/*     */     }
/*     */     
/*     */     protected void setAssociatedURL(URL associatedURL) {
/* 462 */       this.associatedURL = associatedURL;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected URLConnection openConnection(URL u)
/*     */       throws IOException
/*     */     {
/* 470 */       if ((this.associatedURL != null) && (u == this.associatedURL)) {
/* 471 */         if ("jar".equals(this.associatedURL.getProtocol())) {
/* 472 */           return new CachedResource.CachedResourceJarURLConnection(this.resourceURL, this.root, this.webAppPath, this.usesClassLoaderResources);
/*     */         }
/* 474 */         return new CachedResource.CachedResourceURLConnection(this.resourceURL, this.root, this.webAppPath, this.usesClassLoaderResources);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 479 */       URL constructedURL = new URL(u.toExternalForm());
/* 480 */       return constructedURL.openConnection();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class CachedResourceURLConnection
/*     */     extends URLConnection
/*     */   {
/*     */     private final StandardRoot root;
/*     */     
/*     */     private final String webAppPath;
/*     */     
/*     */     private final boolean usesClassLoaderResources;
/*     */     
/*     */     private final URL resourceURL;
/*     */     
/*     */     protected CachedResourceURLConnection(URL resourceURL, StandardRoot root, String webAppPath, boolean usesClassLoaderResources)
/*     */     {
/* 498 */       super();
/* 499 */       this.root = root;
/* 500 */       this.webAppPath = webAppPath;
/* 501 */       this.usesClassLoaderResources = usesClassLoaderResources;
/* 502 */       this.resourceURL = resourceURL;
/*     */     }
/*     */     
/*     */     public void connect()
/*     */       throws IOException
/*     */     {}
/*     */     
/*     */     public InputStream getInputStream()
/*     */       throws IOException
/*     */     {
/* 512 */       WebResource resource = getResource();
/* 513 */       if (resource.isDirectory()) {
/* 514 */         return CachedResource.buildInputStream(resource.getWebResourceRoot().list(this.webAppPath));
/*     */       }
/* 516 */       return getResource().getInputStream();
/*     */     }
/*     */     
/*     */ 
/*     */     public Permission getPermission()
/*     */       throws IOException
/*     */     {
/* 523 */       return this.resourceURL.openConnection().getPermission();
/*     */     }
/*     */     
/*     */     public long getLastModified()
/*     */     {
/* 528 */       return getResource().getLastModified();
/*     */     }
/*     */     
/*     */     public long getContentLengthLong()
/*     */     {
/* 533 */       return getResource().getContentLength();
/*     */     }
/*     */     
/*     */     private WebResource getResource() {
/* 537 */       return this.root.getResource(this.webAppPath, false, this.usesClassLoaderResources);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class CachedResourceJarURLConnection
/*     */     extends JarURLConnection
/*     */   {
/*     */     private final StandardRoot root;
/*     */     
/*     */     private final String webAppPath;
/*     */     private final boolean usesClassLoaderResources;
/*     */     private final URL resourceURL;
/*     */     
/*     */     protected CachedResourceJarURLConnection(URL resourceURL, StandardRoot root, String webAppPath, boolean usesClassLoaderResources)
/*     */       throws IOException
/*     */     {
/* 554 */       super();
/* 555 */       this.root = root;
/* 556 */       this.webAppPath = webAppPath;
/* 557 */       this.usesClassLoaderResources = usesClassLoaderResources;
/* 558 */       this.resourceURL = resourceURL;
/*     */     }
/*     */     
/*     */     public void connect()
/*     */       throws IOException
/*     */     {}
/*     */     
/*     */     public InputStream getInputStream()
/*     */       throws IOException
/*     */     {
/* 568 */       WebResource resource = getResource();
/* 569 */       if (resource.isDirectory()) {
/* 570 */         return CachedResource.buildInputStream(resource.getWebResourceRoot().list(this.webAppPath));
/*     */       }
/* 572 */       return getResource().getInputStream();
/*     */     }
/*     */     
/*     */ 
/*     */     public Permission getPermission()
/*     */       throws IOException
/*     */     {
/* 579 */       return this.resourceURL.openConnection().getPermission();
/*     */     }
/*     */     
/*     */     public long getLastModified()
/*     */     {
/* 584 */       return getResource().getLastModified();
/*     */     }
/*     */     
/*     */     public long getContentLengthLong()
/*     */     {
/* 589 */       return getResource().getContentLength();
/*     */     }
/*     */     
/*     */     private WebResource getResource() {
/* 593 */       return this.root.getResource(this.webAppPath, false, this.usesClassLoaderResources);
/*     */     }
/*     */     
/*     */     public JarFile getJarFile() throws IOException
/*     */     {
/* 598 */       return ((JarURLConnection)this.resourceURL.openConnection()).getJarFile();
/*     */     }
/*     */     
/*     */     public JarEntry getJarEntry() throws IOException
/*     */     {
/* 603 */       if (getEntryName() == null) {
/* 604 */         return null;
/*     */       }
/* 606 */       return super.getJarEntry();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\webresources\CachedResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */