/*    */ package org.apache.catalina.users;
/*    */ 
/*    */ import org.apache.catalina.UserDatabase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SparseUserDatabase
/*    */   implements UserDatabase
/*    */ {
/*    */   public boolean isSparse()
/*    */   {
/* 25 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\users\SparseUserDatabase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */