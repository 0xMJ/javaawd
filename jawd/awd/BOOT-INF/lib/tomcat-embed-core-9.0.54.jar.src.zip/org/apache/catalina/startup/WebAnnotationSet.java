/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.annotation.Resource;
/*     */ import javax.annotation.Resource.AuthenticationType;
/*     */ import javax.annotation.Resources;
/*     */ import javax.annotation.security.DeclareRoles;
/*     */ import javax.annotation.security.RunAs;
/*     */ import javax.servlet.ServletSecurityElement;
/*     */ import javax.servlet.annotation.ServletSecurity;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.core.ApplicationServletRegistration;
/*     */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*     */ import org.apache.catalina.util.Introspection;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextService;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*     */ import org.apache.tomcat.util.descriptor.web.MessageDestinationRef;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebAnnotationSet
/*     */ {
/*     */   private static final String SEPARATOR = "/";
/*     */   private static final String MAPPED_NAME_PROPERTY = "mappedName";
/*  56 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void loadApplicationAnnotations(Context context)
/*     */   {
/*  67 */     loadApplicationListenerAnnotations(context);
/*  68 */     loadApplicationFilterAnnotations(context);
/*  69 */     loadApplicationServletAnnotations(context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void loadApplicationListenerAnnotations(Context context)
/*     */   {
/*  81 */     String[] applicationListeners = context.findApplicationListeners();
/*  82 */     for (String className : applicationListeners) {
/*  83 */       Class<?> clazz = Introspection.loadClass(context, className);
/*  84 */       if (clazz != null)
/*     */       {
/*     */ 
/*     */ 
/*  88 */         loadClassAnnotation(context, clazz);
/*  89 */         loadFieldsAnnotation(context, clazz);
/*  90 */         loadMethodsAnnotation(context, clazz);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void loadApplicationFilterAnnotations(Context context)
/*     */   {
/* 101 */     FilterDef[] filterDefs = context.findFilterDefs();
/* 102 */     for (FilterDef filterDef : filterDefs) {
/* 103 */       Class<?> clazz = Introspection.loadClass(context, filterDef.getFilterClass());
/* 104 */       if (clazz != null)
/*     */       {
/*     */ 
/*     */ 
/* 108 */         loadClassAnnotation(context, clazz);
/* 109 */         loadFieldsAnnotation(context, clazz);
/* 110 */         loadMethodsAnnotation(context, clazz);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void loadApplicationServletAnnotations(Context context)
/*     */   {
/* 122 */     Container[] children = context.findChildren();
/* 123 */     for (Container child : children) {
/* 124 */       if ((child instanceof Wrapper))
/*     */       {
/* 126 */         Wrapper wrapper = (Wrapper)child;
/* 127 */         if (wrapper.getServletClass() != null)
/*     */         {
/*     */ 
/*     */ 
/* 131 */           Class<?> clazz = Introspection.loadClass(context, wrapper.getServletClass());
/* 132 */           if (clazz != null)
/*     */           {
/*     */ 
/*     */ 
/* 136 */             loadClassAnnotation(context, clazz);
/* 137 */             loadFieldsAnnotation(context, clazz);
/* 138 */             loadMethodsAnnotation(context, clazz);
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */             RunAs runAs = (RunAs)clazz.getAnnotation(RunAs.class);
/* 145 */             if (runAs != null) {
/* 146 */               wrapper.setRunAs(runAs.value());
/*     */             }
/*     */             
/*     */ 
/* 150 */             ServletSecurity servletSecurity = (ServletSecurity)clazz.getAnnotation(ServletSecurity.class);
/* 151 */             if (servletSecurity != null) {
/* 152 */               context.addServletSecurity(new ApplicationServletRegistration(wrapper, context), new ServletSecurityElement(servletSecurity));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void loadClassAnnotation(Context context, Class<?> clazz)
/*     */   {
/* 172 */     Resource resourceAnnotation = (Resource)clazz.getAnnotation(Resource.class);
/* 173 */     if (resourceAnnotation != null) {
/* 174 */       addResource(context, resourceAnnotation);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 179 */     Resources resourcesAnnotation = (Resources)clazz.getAnnotation(Resources.class);
/* 180 */     Resource localResource1; Resource resource; if ((resourcesAnnotation != null) && (resourcesAnnotation.value() != null)) {
/* 181 */       Resource[] arrayOfResource = resourcesAnnotation.value();int i = arrayOfResource.length; for (localResource1 = 0; localResource1 < i; localResource1++) { resource = arrayOfResource[localResource1];
/* 182 */         addResource(context, resource);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 258 */     DeclareRoles declareRolesAnnotation = (DeclareRoles)clazz.getAnnotation(DeclareRoles.class);
/* 259 */     if ((declareRolesAnnotation != null) && (declareRolesAnnotation.value() != null)) {
/* 260 */       String[] arrayOfString = declareRolesAnnotation.value();localResource1 = arrayOfString.length; for (resource = 0; resource < localResource1; resource++) { String role = arrayOfString[resource];
/* 261 */         context.addSecurityRole(role);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected static void loadFieldsAnnotation(Context context, Class<?> clazz)
/*     */   {
/* 269 */     Field[] fields = Introspection.getDeclaredFields(clazz);
/* 270 */     if ((fields != null) && (fields.length > 0)) {
/* 271 */       for (Field field : fields) {
/* 272 */         Resource annotation = (Resource)field.getAnnotation(Resource.class);
/* 273 */         if (annotation != null) {
/* 274 */           String defaultName = clazz.getName() + "/" + field.getName();
/* 275 */           Class<?> defaultType = field.getType();
/* 276 */           addResource(context, annotation, defaultName, defaultType);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected static void loadMethodsAnnotation(Context context, Class<?> clazz)
/*     */   {
/* 285 */     Method[] methods = Introspection.getDeclaredMethods(clazz);
/* 286 */     if ((methods != null) && (methods.length > 0)) {
/* 287 */       for (Method method : methods) {
/* 288 */         Resource annotation = (Resource)method.getAnnotation(Resource.class);
/* 289 */         if (annotation != null) {
/* 290 */           if (!Introspection.isValidSetter(method)) {
/* 291 */             throw new IllegalArgumentException(sm.getString("webAnnotationSet.invalidInjection"));
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 296 */           String defaultName = clazz.getName() + "/" + Introspection.getPropertyName(method);
/*     */           
/* 298 */           Class<?> defaultType = method.getParameterTypes()[0];
/* 299 */           addResource(context, annotation, defaultName, defaultType);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void addResource(Context context, Resource annotation)
/*     */   {
/* 315 */     addResource(context, annotation, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */   protected static void addResource(Context context, Resource annotation, String defaultName, Class<?> defaultType)
/*     */   {
/* 321 */     String name = getName(annotation, defaultName);
/* 322 */     String type = getType(annotation, defaultType);
/*     */     
/* 324 */     if ((type.equals("java.lang.String")) || 
/* 325 */       (type.equals("java.lang.Character")) || 
/* 326 */       (type.equals("java.lang.Integer")) || 
/* 327 */       (type.equals("java.lang.Boolean")) || 
/* 328 */       (type.equals("java.lang.Double")) || 
/* 329 */       (type.equals("java.lang.Byte")) || 
/* 330 */       (type.equals("java.lang.Short")) || 
/* 331 */       (type.equals("java.lang.Long")) || 
/* 332 */       (type.equals("java.lang.Float")))
/*     */     {
/*     */ 
/* 335 */       ContextEnvironment resource = new ContextEnvironment();
/*     */       
/* 337 */       resource.setName(name);
/* 338 */       resource.setType(type);
/* 339 */       resource.setDescription(annotation.description());
/* 340 */       resource.setProperty("mappedName", annotation.mappedName());
/* 341 */       resource.setLookupName(annotation.lookup());
/*     */       
/* 343 */       context.getNamingResources().addEnvironment(resource);
/*     */     }
/* 345 */     else if (type.equals("javax.xml.rpc.Service"))
/*     */     {
/*     */ 
/* 348 */       ContextService service = new ContextService();
/*     */       
/* 350 */       service.setName(name);
/* 351 */       service.setWsdlfile(annotation.mappedName());
/* 352 */       service.setType(type);
/* 353 */       service.setDescription(annotation.description());
/* 354 */       service.setLookupName(annotation.lookup());
/*     */       
/* 356 */       context.getNamingResources().addService(service);
/*     */     }
/* 358 */     else if ((type.equals("javax.sql.DataSource")) || 
/* 359 */       (type.equals("javax.jms.ConnectionFactory")) || 
/* 360 */       (type.equals("javax.jms.QueueConnectionFactory")) || 
/* 361 */       (type.equals("javax.jms.TopicConnectionFactory")) || 
/* 362 */       (type.equals("javax.mail.Session")) || 
/* 363 */       (type.equals("java.net.URL")) || 
/* 364 */       (type.equals("javax.resource.cci.ConnectionFactory")) || 
/* 365 */       (type.equals("org.omg.CORBA_2_3.ORB")) || 
/* 366 */       (type.endsWith("ConnectionFactory")))
/*     */     {
/*     */ 
/* 369 */       ContextResource resource = new ContextResource();
/*     */       
/* 371 */       resource.setName(name);
/* 372 */       resource.setType(type);
/*     */       
/* 374 */       if (annotation.authenticationType() == Resource.AuthenticationType.CONTAINER) {
/* 375 */         resource.setAuth("Container");
/* 376 */       } else if (annotation.authenticationType() == Resource.AuthenticationType.APPLICATION) {
/* 377 */         resource.setAuth("Application");
/*     */       }
/*     */       
/* 380 */       resource.setScope(annotation.shareable() ? "Shareable" : "Unshareable");
/* 381 */       resource.setProperty("mappedName", annotation.mappedName());
/* 382 */       resource.setDescription(annotation.description());
/* 383 */       resource.setLookupName(annotation.lookup());
/*     */       
/* 385 */       context.getNamingResources().addResource(resource);
/*     */     }
/* 387 */     else if ((type.equals("javax.jms.Queue")) || 
/* 388 */       (type.equals("javax.jms.Topic")))
/*     */     {
/*     */ 
/* 391 */       MessageDestinationRef resource = new MessageDestinationRef();
/*     */       
/* 393 */       resource.setName(name);
/* 394 */       resource.setType(type);
/* 395 */       resource.setUsage(annotation.mappedName());
/* 396 */       resource.setDescription(annotation.description());
/* 397 */       resource.setLookupName(annotation.lookup());
/*     */       
/* 399 */       context.getNamingResources().addMessageDestinationRef(resource);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 409 */       ContextResourceEnvRef resource = new ContextResourceEnvRef();
/*     */       
/* 411 */       resource.setName(name);
/* 412 */       resource.setType(type);
/* 413 */       resource.setProperty("mappedName", annotation.mappedName());
/* 414 */       resource.setDescription(annotation.description());
/* 415 */       resource.setLookupName(annotation.lookup());
/*     */       
/* 417 */       context.getNamingResources().addResourceEnvRef(resource);
/*     */     }
/*     */   }
/*     */   
/*     */   private static String getType(Resource annotation, Class<?> defaultType)
/*     */   {
/* 423 */     Class<?> type = annotation.type();
/* 424 */     if (((type == null) || (type.equals(Object.class))) && 
/* 425 */       (defaultType != null)) {
/* 426 */       type = defaultType;
/*     */     }
/*     */     
/* 429 */     return Introspection.convertPrimitiveType(type).getCanonicalName();
/*     */   }
/*     */   
/*     */   private static String getName(Resource annotation, String defaultName)
/*     */   {
/* 434 */     String name = annotation.name();
/* 435 */     if (((name == null) || (name.equals(""))) && 
/* 436 */       (defaultName != null)) {
/* 437 */       name = defaultName;
/*     */     }
/*     */     
/* 440 */     return name;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\WebAnnotationSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */