/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Enumeration;
/*      */ import java.util.EventListener;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import javax.naming.NamingException;
/*      */ import javax.servlet.Filter;
/*      */ import javax.servlet.FilterRegistration;
/*      */ import javax.servlet.FilterRegistration.Dynamic;
/*      */ import javax.servlet.RequestDispatcher;
/*      */ import javax.servlet.Servlet;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletContextAttributeEvent;
/*      */ import javax.servlet.ServletContextAttributeListener;
/*      */ import javax.servlet.ServletContextListener;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletRegistration;
/*      */ import javax.servlet.ServletRegistration.Dynamic;
/*      */ import javax.servlet.ServletRequestAttributeListener;
/*      */ import javax.servlet.ServletRequestListener;
/*      */ import javax.servlet.ServletSecurityElement;
/*      */ import javax.servlet.SessionCookieConfig;
/*      */ import javax.servlet.SessionTrackingMode;
/*      */ import javax.servlet.annotation.ServletSecurity;
/*      */ import javax.servlet.descriptor.JspConfigDescriptor;
/*      */ import javax.servlet.http.HttpServletMapping;
/*      */ import javax.servlet.http.HttpSessionAttributeListener;
/*      */ import javax.servlet.http.HttpSessionIdListener;
/*      */ import javax.servlet.http.HttpSessionListener;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Loader;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.Connector;
/*      */ import org.apache.catalina.mapper.Mapper;
/*      */ import org.apache.catalina.mapper.MappingData;
/*      */ import org.apache.catalina.util.Introspection;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.CharChunk;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.buf.UDecoder;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*      */ import org.apache.tomcat.util.http.RequestUtil;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ApplicationContext
/*      */   implements ServletContext
/*      */ {
/*   98 */   protected static final boolean STRICT_SERVLET_COMPLIANCE = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*  100 */   static { String requireSlash = System.getProperty("org.apache.catalina.core.ApplicationContext.GET_RESOURCE_REQUIRE_SLASH");
/*      */     
/*  102 */     if (requireSlash == null) {
/*  103 */       GET_RESOURCE_REQUIRE_SLASH = STRICT_SERVLET_COMPLIANCE;
/*      */     } else {
/*  105 */       GET_RESOURCE_REQUIRE_SLASH = Boolean.parseBoolean(requireSlash);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final boolean GET_RESOURCE_REQUIRE_SLASH;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ApplicationContext(StandardContext context)
/*      */   {
/*  120 */     this.context = context;
/*  121 */     this.service = ((Engine)context.getParent().getParent()).getService();
/*  122 */     this.sessionCookieConfig = new ApplicationSessionCookieConfig(context);
/*      */     
/*      */ 
/*  125 */     populateSessionTrackingModes();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  135 */   protected Map<String, Object> attributes = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  141 */   private final Map<String, String> readOnlyAttributes = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final StandardContext context;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Service service;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  159 */   private static final List<String> emptyString = Collections.emptyList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  165 */   private static final List<Servlet> emptyServlet = Collections.emptyList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  171 */   private final ServletContext facade = new ApplicationContextFacade(this);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  177 */   private final Map<String, String> parameters = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  183 */   private static final StringManager sm = StringManager.getManager(ApplicationContext.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  189 */   private final ThreadLocal<DispatchData> dispatchData = new ThreadLocal();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private SessionCookieConfig sessionCookieConfig;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  200 */   private Set<SessionTrackingMode> sessionTrackingModes = null;
/*  201 */   private Set<SessionTrackingMode> defaultSessionTrackingModes = null;
/*  202 */   private Set<SessionTrackingMode> supportedSessionTrackingModes = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  209 */   private boolean newServletContextListenerAllowed = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getAttribute(String name)
/*      */   {
/*  216 */     return this.attributes.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */   public Enumeration<String> getAttributeNames()
/*      */   {
/*  222 */     Set<String> names = new HashSet(this.attributes.keySet());
/*  223 */     return Collections.enumeration(names);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletContext getContext(String uri)
/*      */   {
/*  231 */     if ((uri == null) || (!uri.startsWith("/"))) {
/*  232 */       return null;
/*      */     }
/*      */     
/*  235 */     Context child = null;
/*      */     try
/*      */     {
/*  238 */       Container host = this.context.getParent();
/*  239 */       child = (Context)host.findChild(uri);
/*      */       
/*      */ 
/*  242 */       if ((child != null) && (!child.getState().isAvailable())) {
/*  243 */         child = null;
/*      */       }
/*      */       
/*      */ 
/*  247 */       if (child == null) {
/*  248 */         int i = uri.indexOf("##");
/*  249 */         if (i > -1) {
/*  250 */           uri = uri.substring(0, i);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  256 */         MessageBytes hostMB = MessageBytes.newInstance();
/*  257 */         hostMB.setString(host.getName());
/*      */         
/*  259 */         MessageBytes pathMB = MessageBytes.newInstance();
/*  260 */         pathMB.setString(uri);
/*      */         
/*  262 */         MappingData mappingData = new MappingData();
/*  263 */         this.service.getMapper().map(hostMB, pathMB, null, mappingData);
/*  264 */         child = mappingData.context;
/*      */       }
/*      */     } catch (Throwable t) {
/*  267 */       ExceptionUtils.handleThrowable(t);
/*  268 */       return null;
/*      */     }
/*      */     
/*  271 */     if (child == null) {
/*  272 */       return null;
/*      */     }
/*      */     
/*  275 */     if (this.context.getCrossContext())
/*      */     {
/*  277 */       return child.getServletContext(); }
/*  278 */     if (child == this.context)
/*      */     {
/*  280 */       return this.context.getServletContext();
/*      */     }
/*      */     
/*  283 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getContextPath()
/*      */   {
/*  290 */     return this.context.getPath();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getInitParameter(String name)
/*      */   {
/*  298 */     if (("org.apache.jasper.XML_VALIDATE_TLD".equals(name)) && 
/*  299 */       (this.context.getTldValidation())) {
/*  300 */       return "true";
/*      */     }
/*  302 */     if (("org.apache.jasper.XML_BLOCK_EXTERNAL".equals(name)) && 
/*  303 */       (!this.context.getXmlBlockExternal()))
/*      */     {
/*  305 */       return "false";
/*      */     }
/*      */     
/*  308 */     return (String)this.parameters.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */   public Enumeration<String> getInitParameterNames()
/*      */   {
/*  314 */     Set<String> names = new HashSet(this.parameters.keySet());
/*      */     
/*      */ 
/*  317 */     if (this.context.getTldValidation()) {
/*  318 */       names.add("org.apache.jasper.XML_VALIDATE_TLD");
/*      */     }
/*  320 */     if (!this.context.getXmlBlockExternal()) {
/*  321 */       names.add("org.apache.jasper.XML_BLOCK_EXTERNAL");
/*      */     }
/*  323 */     return Collections.enumeration(names);
/*      */   }
/*      */   
/*      */ 
/*      */   public int getMajorVersion()
/*      */   {
/*  329 */     return 4;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getMinorVersion()
/*      */   {
/*  335 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMimeType(String file)
/*      */   {
/*  348 */     if (file == null) {
/*  349 */       return null;
/*      */     }
/*  351 */     int period = file.lastIndexOf('.');
/*  352 */     if (period < 0) {
/*  353 */       return null;
/*      */     }
/*  355 */     String extension = file.substring(period + 1);
/*  356 */     if (extension.length() < 1) {
/*  357 */       return null;
/*      */     }
/*  359 */     return this.context.findMimeMapping(extension);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RequestDispatcher getNamedDispatcher(String name)
/*      */   {
/*  374 */     if (name == null) {
/*  375 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  379 */     Wrapper wrapper = (Wrapper)this.context.findChild(name);
/*  380 */     if (wrapper == null) {
/*  381 */       return null;
/*      */     }
/*      */     
/*  384 */     return new ApplicationDispatcher(wrapper, null, null, null, null, null, name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getRealPath(String path)
/*      */   {
/*  391 */     String validatedPath = validateResourcePath(path, true);
/*  392 */     return this.context.getRealPath(validatedPath);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public RequestDispatcher getRequestDispatcher(String path)
/*      */   {
/*  400 */     if (path == null) {
/*  401 */       return null;
/*      */     }
/*  403 */     if (!path.startsWith("/"))
/*      */     {
/*  405 */       throw new IllegalArgumentException(sm.getString("applicationContext.requestDispatcher.iae", new Object[] { path }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  412 */     int pos = path.indexOf('?');
/*  413 */     String queryString; String uri; String queryString; if (pos >= 0) {
/*  414 */       String uri = path.substring(0, pos);
/*  415 */       queryString = path.substring(pos + 1);
/*      */     } else {
/*  417 */       uri = path;
/*  418 */       queryString = null;
/*      */     }
/*      */     
/*      */ 
/*  422 */     String uriNoParams = stripPathParams(uri);
/*      */     
/*      */ 
/*  425 */     String normalizedUri = RequestUtil.normalize(uriNoParams);
/*  426 */     if (normalizedUri == null) {
/*  427 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  432 */     if (getContext().getDispatchersUseEncodedPaths())
/*      */     {
/*  434 */       String decodedUri = UDecoder.URLDecode(normalizedUri, StandardCharsets.UTF_8);
/*      */       
/*      */ 
/*  437 */       normalizedUri = RequestUtil.normalize(decodedUri);
/*  438 */       if (!decodedUri.equals(normalizedUri)) {
/*  439 */         getContext().getLogger().warn(sm
/*  440 */           .getString("applicationContext.illegalDispatchPath", new Object[] { path }), new IllegalArgumentException());
/*      */         
/*  442 */         return null;
/*      */       }
/*      */       
/*      */ 
/*  446 */       uri = URLEncoder.DEFAULT.encode(getContextPath(), StandardCharsets.UTF_8) + uri;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  452 */       uri = URLEncoder.DEFAULT.encode(getContextPath() + uri, StandardCharsets.UTF_8);
/*      */     }
/*      */     
/*      */ 
/*  456 */     DispatchData dd = (DispatchData)this.dispatchData.get();
/*  457 */     if (dd == null) {
/*  458 */       dd = new DispatchData();
/*  459 */       this.dispatchData.set(dd);
/*      */     }
/*      */     
/*      */ 
/*  463 */     MessageBytes uriMB = dd.uriMB;
/*  464 */     MappingData mappingData = dd.mappingData;
/*      */     
/*      */     try
/*      */     {
/*  468 */       CharChunk uriCC = uriMB.getCharChunk();
/*      */       try {
/*  470 */         uriCC.append(this.context.getPath());
/*  471 */         uriCC.append(normalizedUri);
/*  472 */         this.service.getMapper().map(this.context, uriMB, mappingData);
/*  473 */         if (mappingData.wrapper == null) {
/*  474 */           return null;
/*      */         }
/*      */       }
/*      */       catch (Exception e) {
/*  478 */         log(sm.getString("applicationContext.mapping.error"), e);
/*  479 */         return null;
/*      */       }
/*      */       
/*  482 */       Wrapper wrapper = mappingData.wrapper;
/*  483 */       String wrapperPath = mappingData.wrapperPath.toString();
/*  484 */       String pathInfo = mappingData.pathInfo.toString();
/*  485 */       HttpServletMapping mapping = new ApplicationMapping(mappingData).getHttpServletMapping();
/*      */       
/*      */ 
/*  488 */       return new ApplicationDispatcher(wrapper, uri, wrapperPath, pathInfo, queryString, mapping, null);
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/*      */ 
/*  497 */       uriMB.recycle();
/*  498 */       mappingData.recycle();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static String stripPathParams(String input)
/*      */   {
/*  506 */     if (input.indexOf(';') < 0) {
/*  507 */       return input;
/*      */     }
/*      */     
/*  510 */     StringBuilder sb = new StringBuilder(input.length());
/*  511 */     int pos = 0;
/*  512 */     int limit = input.length();
/*  513 */     while (pos < limit) {
/*  514 */       int nextSemiColon = input.indexOf(';', pos);
/*  515 */       if (nextSemiColon < 0) {
/*  516 */         nextSemiColon = limit;
/*      */       }
/*  518 */       sb.append(input.substring(pos, nextSemiColon));
/*  519 */       int followingSlash = input.indexOf('/', nextSemiColon);
/*  520 */       if (followingSlash < 0) {
/*  521 */         pos = limit;
/*      */       } else {
/*  523 */         pos = followingSlash;
/*      */       }
/*      */     }
/*      */     
/*  527 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */   public URL getResource(String path)
/*      */     throws MalformedURLException
/*      */   {
/*  534 */     String validatedPath = validateResourcePath(path, !GET_RESOURCE_REQUIRE_SLASH);
/*      */     
/*  536 */     if (validatedPath == null)
/*      */     {
/*  538 */       throw new MalformedURLException(sm.getString("applicationContext.requestDispatcher.iae", new Object[] { path }));
/*      */     }
/*      */     
/*  541 */     WebResourceRoot resources = this.context.getResources();
/*  542 */     if (resources != null) {
/*  543 */       return resources.getResource(validatedPath).getURL();
/*      */     }
/*      */     
/*  546 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public InputStream getResourceAsStream(String path)
/*      */   {
/*  553 */     String validatedPath = validateResourcePath(path, !GET_RESOURCE_REQUIRE_SLASH);
/*      */     
/*  555 */     if (validatedPath == null) {
/*  556 */       return null;
/*      */     }
/*      */     
/*  559 */     WebResourceRoot resources = this.context.getResources();
/*  560 */     if (resources != null) {
/*  561 */       return resources.getResource(validatedPath).getInputStream();
/*      */     }
/*      */     
/*  564 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String validateResourcePath(String path, boolean addMissingInitialSlash)
/*      */   {
/*  573 */     if (path == null) {
/*  574 */       return null;
/*      */     }
/*      */     
/*  577 */     if (!path.startsWith("/")) {
/*  578 */       if (addMissingInitialSlash) {
/*  579 */         return "/" + path;
/*      */       }
/*  581 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  585 */     return path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> getResourcePaths(String path)
/*      */   {
/*  593 */     if (path == null) {
/*  594 */       return null;
/*      */     }
/*  596 */     if (!path.startsWith("/")) {
/*  597 */       throw new IllegalArgumentException(sm.getString("applicationContext.resourcePaths.iae", new Object[] { path }));
/*      */     }
/*      */     
/*  600 */     WebResourceRoot resources = this.context.getResources();
/*  601 */     if (resources != null) {
/*  602 */       return resources.listWebAppPaths(path);
/*      */     }
/*      */     
/*  605 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getServerInfo()
/*      */   {
/*  611 */     return ServerInfo.getServerInfo();
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public Servlet getServlet(String name)
/*      */   {
/*  618 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getServletContextName()
/*      */   {
/*  624 */     return this.context.getDisplayName();
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public Enumeration<String> getServletNames()
/*      */   {
/*  631 */     return Collections.enumeration(emptyString);
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public Enumeration<Servlet> getServlets()
/*      */   {
/*  638 */     return Collections.enumeration(emptyServlet);
/*      */   }
/*      */   
/*      */ 
/*      */   public void log(String message)
/*      */   {
/*  644 */     this.context.getLogger().info(message);
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public void log(Exception exception, String message)
/*      */   {
/*  651 */     this.context.getLogger().error(message, exception);
/*      */   }
/*      */   
/*      */ 
/*      */   public void log(String message, Throwable throwable)
/*      */   {
/*  657 */     this.context.getLogger().error(message, throwable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void removeAttribute(String name)
/*      */   {
/*  664 */     Object value = null;
/*      */     
/*      */ 
/*      */ 
/*  668 */     if (this.readOnlyAttributes.containsKey(name)) {
/*  669 */       return;
/*      */     }
/*  671 */     value = this.attributes.remove(name);
/*  672 */     if (value == null) {
/*  673 */       return;
/*      */     }
/*      */     
/*      */ 
/*  677 */     Object[] listeners = this.context.getApplicationEventListeners();
/*  678 */     if ((listeners == null) || (listeners.length == 0)) {
/*  679 */       return;
/*      */     }
/*      */     
/*  682 */     ServletContextAttributeEvent event = new ServletContextAttributeEvent(this.context.getServletContext(), name, value);
/*  683 */     for (Object obj : listeners) {
/*  684 */       if ((obj instanceof ServletContextAttributeListener))
/*      */       {
/*      */ 
/*  687 */         ServletContextAttributeListener listener = (ServletContextAttributeListener)obj;
/*      */         try {
/*  689 */           this.context.fireContainerEvent("beforeContextAttributeRemoved", listener);
/*  690 */           listener.attributeRemoved(event);
/*  691 */           this.context.fireContainerEvent("afterContextAttributeRemoved", listener);
/*      */         } catch (Throwable t) {
/*  693 */           ExceptionUtils.handleThrowable(t);
/*  694 */           this.context.fireContainerEvent("afterContextAttributeRemoved", listener);
/*      */           
/*  696 */           log(sm.getString("applicationContext.attributeEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setAttribute(String name, Object value)
/*      */   {
/*  705 */     if (name == null) {
/*  706 */       throw new NullPointerException(sm.getString("applicationContext.setAttribute.namenull"));
/*      */     }
/*      */     
/*      */ 
/*  710 */     if (value == null) {
/*  711 */       removeAttribute(name);
/*  712 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  717 */     if (this.readOnlyAttributes.containsKey(name)) {
/*  718 */       return;
/*      */     }
/*      */     
/*  721 */     Object oldValue = this.attributes.put(name, value);
/*  722 */     boolean replaced = oldValue != null;
/*      */     
/*      */ 
/*  725 */     Object[] listeners = this.context.getApplicationEventListeners();
/*  726 */     if ((listeners == null) || (listeners.length == 0)) {
/*  727 */       return;
/*      */     }
/*  729 */     ServletContextAttributeEvent event = null;
/*  730 */     if (replaced) {
/*  731 */       event = new ServletContextAttributeEvent(this.context.getServletContext(), name, oldValue);
/*      */     } else {
/*  733 */       event = new ServletContextAttributeEvent(this.context.getServletContext(), name, value);
/*      */     }
/*      */     
/*  736 */     for (Object obj : listeners) {
/*  737 */       if ((obj instanceof ServletContextAttributeListener))
/*      */       {
/*      */ 
/*  740 */         ServletContextAttributeListener listener = (ServletContextAttributeListener)obj;
/*      */         try {
/*  742 */           if (replaced) {
/*  743 */             this.context.fireContainerEvent("beforeContextAttributeReplaced", listener);
/*  744 */             listener.attributeReplaced(event);
/*  745 */             this.context.fireContainerEvent("afterContextAttributeReplaced", listener);
/*      */           } else {
/*  747 */             this.context.fireContainerEvent("beforeContextAttributeAdded", listener);
/*  748 */             listener.attributeAdded(event);
/*  749 */             this.context.fireContainerEvent("afterContextAttributeAdded", listener);
/*      */           }
/*      */         } catch (Throwable t) {
/*  752 */           ExceptionUtils.handleThrowable(t);
/*  753 */           if (replaced) {
/*  754 */             this.context.fireContainerEvent("afterContextAttributeReplaced", listener);
/*      */           } else {
/*  756 */             this.context.fireContainerEvent("afterContextAttributeAdded", listener);
/*      */           }
/*      */           
/*  759 */           log(sm.getString("applicationContext.attributeEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public FilterRegistration.Dynamic addFilter(String filterName, String className)
/*      */   {
/*  767 */     return addFilter(filterName, className, null);
/*      */   }
/*      */   
/*      */ 
/*      */   public FilterRegistration.Dynamic addFilter(String filterName, Filter filter)
/*      */   {
/*  773 */     return addFilter(filterName, null, filter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public FilterRegistration.Dynamic addFilter(String filterName, Class<? extends Filter> filterClass)
/*      */   {
/*  780 */     return addFilter(filterName, filterClass.getName(), null);
/*      */   }
/*      */   
/*      */ 
/*      */   private FilterRegistration.Dynamic addFilter(String filterName, String filterClass, Filter filter)
/*      */     throws IllegalStateException
/*      */   {
/*  787 */     if ((filterName == null) || (filterName.equals(""))) {
/*  788 */       throw new IllegalArgumentException(sm.getString("applicationContext.invalidFilterName", new Object[] { filterName }));
/*      */     }
/*      */     
/*      */ 
/*  792 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP))
/*      */     {
/*      */ 
/*  795 */       throw new IllegalStateException(sm.getString("applicationContext.addFilter.ise", new Object[] {
/*  796 */         getContextPath() }));
/*      */     }
/*      */     
/*  799 */     FilterDef filterDef = this.context.findFilterDef(filterName);
/*      */     
/*      */ 
/*      */ 
/*  803 */     if (filterDef == null) {
/*  804 */       filterDef = new FilterDef();
/*  805 */       filterDef.setFilterName(filterName);
/*  806 */       this.context.addFilterDef(filterDef);
/*      */     }
/*  808 */     else if ((filterDef.getFilterName() != null) && 
/*  809 */       (filterDef.getFilterClass() != null)) {
/*  810 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  814 */     if (filter == null) {
/*  815 */       filterDef.setFilterClass(filterClass);
/*      */     } else {
/*  817 */       filterDef.setFilterClass(filter.getClass().getName());
/*  818 */       filterDef.setFilter(filter);
/*      */     }
/*      */     
/*  821 */     return new ApplicationFilterRegistration(filterDef, this.context);
/*      */   }
/*      */   
/*      */   public <T extends Filter> T createFilter(Class<T> c)
/*      */     throws ServletException
/*      */   {
/*      */     try
/*      */     {
/*  829 */       return (Filter)this.context.getInstanceManager().newInstance(c.getName());
/*      */     }
/*      */     catch (InvocationTargetException e) {
/*  832 */       ExceptionUtils.handleThrowable(e.getCause());
/*  833 */       throw new ServletException(e);
/*      */     } catch (ReflectiveOperationException|NamingException e) {
/*  835 */       throw new ServletException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public FilterRegistration getFilterRegistration(String filterName)
/*      */   {
/*  842 */     FilterDef filterDef = this.context.findFilterDef(filterName);
/*  843 */     if (filterDef == null) {
/*  844 */       return null;
/*      */     }
/*  846 */     return new ApplicationFilterRegistration(filterDef, this.context);
/*      */   }
/*      */   
/*      */ 
/*      */   public ServletRegistration.Dynamic addServlet(String servletName, String className)
/*      */   {
/*  852 */     return addServlet(servletName, className, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */   public ServletRegistration.Dynamic addServlet(String servletName, Servlet servlet)
/*      */   {
/*  858 */     return addServlet(servletName, null, servlet, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ServletRegistration.Dynamic addServlet(String servletName, Class<? extends Servlet> servletClass)
/*      */   {
/*  865 */     return addServlet(servletName, servletClass.getName(), null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletRegistration.Dynamic addJspFile(String jspName, String jspFile)
/*      */   {
/*  873 */     if ((jspFile == null) || (!jspFile.startsWith("/")))
/*      */     {
/*  875 */       throw new IllegalArgumentException(sm.getString("applicationContext.addJspFile.iae", new Object[] { jspFile }));
/*      */     }
/*      */     
/*  878 */     String jspServletClassName = null;
/*  879 */     Map<String, String> jspFileInitParams = new HashMap();
/*      */     
/*  881 */     Wrapper jspServlet = (Wrapper)this.context.findChild("jsp");
/*      */     
/*  883 */     if (jspServlet == null)
/*      */     {
/*      */ 
/*  886 */       jspServletClassName = "org.apache.jasper.servlet.JspServlet";
/*      */     }
/*      */     else
/*      */     {
/*  890 */       jspServletClassName = jspServlet.getServletClass();
/*      */       
/*  892 */       String[] params = jspServlet.findInitParameters();
/*  893 */       for (String param : params) {
/*  894 */         jspFileInitParams.put(param, jspServlet.findInitParameter(param));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  899 */     jspFileInitParams.put("jspFile", jspFile);
/*      */     
/*  901 */     return addServlet(jspName, jspServletClassName, null, jspFileInitParams);
/*      */   }
/*      */   
/*      */ 
/*      */   private ServletRegistration.Dynamic addServlet(String servletName, String servletClass, Servlet servlet, Map<String, String> initParams)
/*      */     throws IllegalStateException
/*      */   {
/*  908 */     if ((servletName == null) || (servletName.equals(""))) {
/*  909 */       throw new IllegalArgumentException(sm.getString("applicationContext.invalidServletName", new Object[] { servletName }));
/*      */     }
/*      */     
/*      */ 
/*  913 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP))
/*      */     {
/*      */ 
/*  916 */       throw new IllegalStateException(sm.getString("applicationContext.addServlet.ise", new Object[] {
/*  917 */         getContextPath() }));
/*      */     }
/*      */     
/*  920 */     Wrapper wrapper = (Wrapper)this.context.findChild(servletName);
/*      */     
/*      */ 
/*      */ 
/*  924 */     if (wrapper == null) {
/*  925 */       wrapper = this.context.createWrapper();
/*  926 */       wrapper.setName(servletName);
/*  927 */       this.context.addChild(wrapper);
/*      */     }
/*  929 */     else if ((wrapper.getName() != null) && 
/*  930 */       (wrapper.getServletClass() != null)) {
/*  931 */       if (wrapper.isOverridable()) {
/*  932 */         wrapper.setOverridable(false);
/*      */       } else {
/*  934 */         return null;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  939 */     ServletSecurity annotation = null;
/*  940 */     Class<?> clazz; if (servlet == null) {
/*  941 */       wrapper.setServletClass(servletClass);
/*  942 */       clazz = Introspection.loadClass(this.context, servletClass);
/*  943 */       if (clazz != null) {
/*  944 */         annotation = (ServletSecurity)clazz.getAnnotation(ServletSecurity.class);
/*      */       }
/*      */     } else {
/*  947 */       wrapper.setServletClass(servlet.getClass().getName());
/*  948 */       wrapper.setServlet(servlet);
/*  949 */       if (this.context.wasCreatedDynamicServlet(servlet)) {
/*  950 */         annotation = (ServletSecurity)servlet.getClass().getAnnotation(ServletSecurity.class);
/*      */       }
/*      */     }
/*      */     
/*  954 */     if (initParams != null) {
/*  955 */       for (Map.Entry<String, String> initParam : initParams.entrySet()) {
/*  956 */         wrapper.addInitParameter((String)initParam.getKey(), (String)initParam.getValue());
/*      */       }
/*      */     }
/*      */     
/*  960 */     ServletRegistration.Dynamic registration = new ApplicationServletRegistration(wrapper, this.context);
/*      */     
/*  962 */     if (annotation != null) {
/*  963 */       registration.setServletSecurity(new ServletSecurityElement(annotation));
/*      */     }
/*  965 */     return registration;
/*      */   }
/*      */   
/*      */   public <T extends Servlet> T createServlet(Class<T> c)
/*      */     throws ServletException
/*      */   {
/*      */     try
/*      */     {
/*  973 */       T servlet = (Servlet)this.context.getInstanceManager().newInstance(c.getName());
/*  974 */       this.context.dynamicServletCreated(servlet);
/*  975 */       return servlet;
/*      */     } catch (InvocationTargetException e) {
/*  977 */       ExceptionUtils.handleThrowable(e.getCause());
/*  978 */       throw new ServletException(e);
/*      */     } catch (ReflectiveOperationException|NamingException e) {
/*  980 */       throw new ServletException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ServletRegistration getServletRegistration(String servletName)
/*      */   {
/*  987 */     Wrapper wrapper = (Wrapper)this.context.findChild(servletName);
/*  988 */     if (wrapper == null) {
/*  989 */       return null;
/*      */     }
/*      */     
/*  992 */     return new ApplicationServletRegistration(wrapper, this.context);
/*      */   }
/*      */   
/*      */ 
/*      */   public Set<SessionTrackingMode> getDefaultSessionTrackingModes()
/*      */   {
/*  998 */     return this.defaultSessionTrackingModes;
/*      */   }
/*      */   
/*      */ 
/*      */   private void populateSessionTrackingModes()
/*      */   {
/* 1004 */     this.defaultSessionTrackingModes = EnumSet.of(SessionTrackingMode.URL);
/* 1005 */     this.supportedSessionTrackingModes = EnumSet.of(SessionTrackingMode.URL);
/*      */     
/* 1007 */     if (this.context.getCookies()) {
/* 1008 */       this.defaultSessionTrackingModes.add(SessionTrackingMode.COOKIE);
/* 1009 */       this.supportedSessionTrackingModes.add(SessionTrackingMode.COOKIE);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1014 */     Connector[] connectors = this.service.findConnectors();
/*      */     
/* 1016 */     for (Connector connector : connectors) {
/* 1017 */       if (Boolean.TRUE.equals(connector.getProperty("SSLEnabled"))) {
/* 1018 */         this.supportedSessionTrackingModes.add(SessionTrackingMode.SSL);
/* 1019 */         break;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Set<SessionTrackingMode> getEffectiveSessionTrackingModes()
/*      */   {
/* 1027 */     if (this.sessionTrackingModes != null) {
/* 1028 */       return this.sessionTrackingModes;
/*      */     }
/* 1030 */     return this.defaultSessionTrackingModes;
/*      */   }
/*      */   
/*      */ 
/*      */   public SessionCookieConfig getSessionCookieConfig()
/*      */   {
/* 1036 */     return this.sessionCookieConfig;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSessionTrackingModes(Set<SessionTrackingMode> sessionTrackingModes)
/*      */   {
/* 1043 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP))
/*      */     {
/* 1045 */       throw new IllegalStateException(sm.getString("applicationContext.setSessionTracking.ise", new Object[] {
/* 1046 */         getContextPath() }));
/*      */     }
/*      */     
/*      */ 
/* 1050 */     for (SessionTrackingMode sessionTrackingMode : sessionTrackingModes) {
/* 1051 */       if (!this.supportedSessionTrackingModes.contains(sessionTrackingMode)) {
/* 1052 */         throw new IllegalArgumentException(sm.getString("applicationContext.setSessionTracking.iae.invalid", new Object[] {sessionTrackingMode
/*      */         
/* 1054 */           .toString(), getContextPath() }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1059 */     if ((sessionTrackingModes.contains(SessionTrackingMode.SSL)) && 
/* 1060 */       (sessionTrackingModes.size() > 1)) {
/* 1061 */       throw new IllegalArgumentException(sm.getString("applicationContext.setSessionTracking.iae.ssl", new Object[] {
/*      */       
/* 1063 */         getContextPath() }));
/*      */     }
/*      */     
/*      */ 
/* 1067 */     this.sessionTrackingModes = sessionTrackingModes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean setInitParameter(String name, String value)
/*      */   {
/* 1074 */     if (name == null) {
/* 1075 */       throw new NullPointerException(sm.getString("applicationContext.setAttribute.namenull"));
/*      */     }
/* 1077 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP))
/*      */     {
/* 1079 */       throw new IllegalStateException(sm.getString("applicationContext.setInitParam.ise", new Object[] {
/* 1080 */         getContextPath() }));
/*      */     }
/*      */     
/* 1083 */     return this.parameters.putIfAbsent(name, value) == null;
/*      */   }
/*      */   
/*      */ 
/*      */   public void addListener(Class<? extends EventListener> listenerClass)
/*      */   {
/*      */     try
/*      */     {
/* 1091 */       listener = createListener(listenerClass);
/*      */     } catch (ServletException e) { EventListener listener;
/* 1093 */       throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.init", new Object[] {listenerClass
/*      */       
/* 1095 */         .getName() }), e); }
/*      */     EventListener listener;
/* 1097 */     addListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */   public void addListener(String className)
/*      */   {
/*      */     try
/*      */     {
/* 1105 */       if (this.context.getInstanceManager() != null) {
/* 1106 */         Object obj = this.context.getInstanceManager().newInstance(className);
/*      */         
/* 1108 */         if (!(obj instanceof EventListener)) {
/* 1109 */           throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.wrongType", new Object[] { className }));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1114 */         EventListener listener = (EventListener)obj;
/* 1115 */         addListener(listener);
/*      */       }
/*      */     } catch (InvocationTargetException e) {
/* 1118 */       ExceptionUtils.handleThrowable(e.getCause());
/* 1119 */       throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.cnfe", new Object[] { className }), e);
/*      */     }
/*      */     catch (ReflectiveOperationException|NamingException e)
/*      */     {
/* 1123 */       throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.cnfe", new Object[] { className }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T extends EventListener> void addListener(T t)
/*      */   {
/* 1133 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP))
/*      */     {
/* 1135 */       throw new IllegalStateException(sm.getString("applicationContext.addListener.ise", new Object[] {
/* 1136 */         getContextPath() }));
/*      */     }
/*      */     
/* 1139 */     boolean match = false;
/* 1140 */     if (((t instanceof ServletContextAttributeListener)) || ((t instanceof ServletRequestListener)) || ((t instanceof ServletRequestAttributeListener)) || ((t instanceof HttpSessionIdListener)) || ((t instanceof HttpSessionAttributeListener)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1145 */       this.context.addApplicationEventListener(t);
/* 1146 */       match = true;
/*      */     }
/*      */     
/* 1149 */     if (((t instanceof HttpSessionListener)) || (((t instanceof ServletContextListener)) && (this.newServletContextListenerAllowed)))
/*      */     {
/*      */ 
/*      */ 
/* 1153 */       this.context.addApplicationLifecycleListener(t);
/* 1154 */       match = true;
/*      */     }
/*      */     
/* 1157 */     if (match) {
/* 1158 */       return;
/*      */     }
/*      */     
/* 1161 */     if ((t instanceof ServletContextListener)) {
/* 1162 */       throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.sclNotAllowed", new Object[] {t
/*      */       
/* 1164 */         .getClass().getName() }));
/*      */     }
/* 1166 */     throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.wrongType", new Object[] {t
/*      */     
/* 1168 */       .getClass().getName() }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T extends EventListener> T createListener(Class<T> c)
/*      */     throws ServletException
/*      */   {
/*      */     try
/*      */     {
/* 1178 */       T listener = (EventListener)this.context.getInstanceManager().newInstance(c);
/* 1179 */       if (((listener instanceof ServletContextListener)) || ((listener instanceof ServletContextAttributeListener)) || ((listener instanceof ServletRequestListener)) || ((listener instanceof ServletRequestAttributeListener)) || ((listener instanceof HttpSessionListener)) || ((listener instanceof HttpSessionIdListener)) || ((listener instanceof HttpSessionAttributeListener)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1186 */         return listener;
/*      */       }
/* 1188 */       throw new IllegalArgumentException(sm.getString("applicationContext.addListener.iae.wrongType", new Object[] {listener
/*      */       
/* 1190 */         .getClass().getName() }));
/*      */     } catch (InvocationTargetException e) {
/* 1192 */       ExceptionUtils.handleThrowable(e.getCause());
/* 1193 */       throw new ServletException(e);
/*      */     } catch (ReflectiveOperationException|NamingException e) {
/* 1195 */       throw new ServletException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void declareRoles(String... roleNames)
/*      */   {
/* 1203 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP))
/*      */     {
/*      */ 
/* 1206 */       throw new IllegalStateException(sm.getString("applicationContext.addRole.ise", new Object[] {
/* 1207 */         getContextPath() }));
/*      */     }
/*      */     
/* 1210 */     if (roleNames == null)
/*      */     {
/* 1212 */       throw new IllegalArgumentException(sm.getString("applicationContext.roles.iae", new Object[] {
/* 1213 */         getContextPath() }));
/*      */     }
/*      */     
/* 1216 */     for (String role : roleNames) {
/* 1217 */       if ((role == null) || (role.isEmpty()))
/*      */       {
/* 1219 */         throw new IllegalArgumentException(sm.getString("applicationContext.role.iae", new Object[] {
/* 1220 */           getContextPath() }));
/*      */       }
/* 1222 */       this.context.addSecurityRole(role);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ClassLoader getClassLoader()
/*      */   {
/* 1229 */     ClassLoader result = this.context.getLoader().getClassLoader();
/* 1230 */     if (Globals.IS_SECURITY_ENABLED) {
/* 1231 */       ClassLoader tccl = Thread.currentThread().getContextClassLoader();
/* 1232 */       ClassLoader parent = result;
/* 1233 */       while ((parent != null) && 
/* 1234 */         (parent != tccl))
/*      */       {
/*      */ 
/* 1237 */         parent = parent.getParent();
/*      */       }
/* 1239 */       if (parent == null) {
/* 1240 */         System.getSecurityManager().checkPermission(new RuntimePermission("getClassLoader"));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1245 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getEffectiveMajorVersion()
/*      */   {
/* 1251 */     return this.context.getEffectiveMajorVersion();
/*      */   }
/*      */   
/*      */ 
/*      */   public int getEffectiveMinorVersion()
/*      */   {
/* 1257 */     return this.context.getEffectiveMinorVersion();
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, ? extends FilterRegistration> getFilterRegistrations()
/*      */   {
/* 1263 */     Map<String, ApplicationFilterRegistration> result = new HashMap();
/*      */     
/* 1265 */     FilterDef[] filterDefs = this.context.findFilterDefs();
/* 1266 */     for (FilterDef filterDef : filterDefs) {
/* 1267 */       result.put(filterDef.getFilterName(), new ApplicationFilterRegistration(filterDef, this.context));
/*      */     }
/*      */     
/*      */ 
/* 1271 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   public JspConfigDescriptor getJspConfigDescriptor()
/*      */   {
/* 1277 */     return this.context.getJspConfigDescriptor();
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, ? extends ServletRegistration> getServletRegistrations()
/*      */   {
/* 1283 */     Map<String, ApplicationServletRegistration> result = new HashMap();
/*      */     
/* 1285 */     Container[] wrappers = this.context.findChildren();
/* 1286 */     for (Container wrapper : wrappers) {
/* 1287 */       result.put(wrapper.getName(), new ApplicationServletRegistration((Wrapper)wrapper, this.context));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1292 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getVirtualServerName()
/*      */   {
/* 1299 */     Container host = this.context.getParent();
/* 1300 */     Container engine = host.getParent();
/* 1301 */     return engine.getName() + "/" + host.getName();
/*      */   }
/*      */   
/*      */ 
/*      */   public int getSessionTimeout()
/*      */   {
/* 1307 */     return this.context.getSessionTimeout();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSessionTimeout(int sessionTimeout)
/*      */   {
/* 1313 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP))
/*      */     {
/* 1315 */       throw new IllegalStateException(sm.getString("applicationContext.setSessionTimeout.ise", new Object[] {
/* 1316 */         getContextPath() }));
/*      */     }
/*      */     
/* 1319 */     this.context.setSessionTimeout(sessionTimeout);
/*      */   }
/*      */   
/*      */ 
/*      */   public String getRequestCharacterEncoding()
/*      */   {
/* 1325 */     return this.context.getRequestCharacterEncoding();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setRequestCharacterEncoding(String encoding)
/*      */   {
/* 1331 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP))
/*      */     {
/* 1333 */       throw new IllegalStateException(sm.getString("applicationContext.setRequestEncoding.ise", new Object[] {
/* 1334 */         getContextPath() }));
/*      */     }
/*      */     
/* 1337 */     this.context.setRequestCharacterEncoding(encoding);
/*      */   }
/*      */   
/*      */ 
/*      */   public String getResponseCharacterEncoding()
/*      */   {
/* 1343 */     return this.context.getResponseCharacterEncoding();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setResponseCharacterEncoding(String encoding)
/*      */   {
/* 1349 */     if (!this.context.getState().equals(LifecycleState.STARTING_PREP))
/*      */     {
/* 1351 */       throw new IllegalStateException(sm.getString("applicationContext.setResponseEncoding.ise", new Object[] {
/* 1352 */         getContextPath() }));
/*      */     }
/*      */     
/* 1355 */     this.context.setResponseCharacterEncoding(encoding);
/*      */   }
/*      */   
/*      */ 
/*      */   protected StandardContext getContext()
/*      */   {
/* 1361 */     return this.context;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void clearAttributes()
/*      */   {
/* 1370 */     List<String> list = new ArrayList(this.attributes.keySet());
/*      */     
/*      */ 
/*      */ 
/* 1374 */     for (String key : list) {
/* 1375 */       removeAttribute(key);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ServletContext getFacade()
/*      */   {
/* 1385 */     return this.facade;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setAttributeReadOnly(String name)
/*      */   {
/* 1394 */     if (this.attributes.containsKey(name)) {
/* 1395 */       this.readOnlyAttributes.put(name, name);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void setNewServletContextListenerAllowed(boolean allowed)
/*      */   {
/* 1402 */     this.newServletContextListenerAllowed = allowed;
/*      */   }
/*      */   
/*      */ 
/*      */   private static final class DispatchData
/*      */   {
/*      */     public MessageBytes uriMB;
/*      */     
/*      */     public MappingData mappingData;
/*      */     
/*      */ 
/*      */     public DispatchData()
/*      */     {
/* 1415 */       this.uriMB = MessageBytes.newInstance();
/* 1416 */       CharChunk uriCC = this.uriMB.getCharChunk();
/* 1417 */       uriCC.setLimit(-1);
/* 1418 */       this.mappingData = new MappingData();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\ApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */