/*     */ package org.apache.catalina.session;
/*     */ 
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardManager
/*     */   extends ManagerBase
/*     */ {
/*  61 */   private final Log log = LogFactory.getLog(StandardManager.class);
/*     */   
/*     */   protected static final String name = "StandardManager";
/*     */   
/*     */ 
/*     */   private class PrivilegedDoLoad
/*     */     implements PrivilegedExceptionAction<Void>
/*     */   {
/*     */     PrivilegedDoLoad() {}
/*     */     
/*     */     public Void run()
/*     */       throws Exception
/*     */     {
/*  74 */       StandardManager.this.doLoad();
/*  75 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class PrivilegedDoUnload
/*     */     implements PrivilegedExceptionAction<Void>
/*     */   {
/*     */     PrivilegedDoUnload() {}
/*     */     
/*     */     public Void run()
/*     */       throws Exception
/*     */     {
/*  88 */       StandardManager.this.doUnload();
/*  89 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */   protected String pathname = "SESSIONS.ser";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 118 */     return "StandardManager";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathname()
/*     */   {
/* 126 */     return this.pathname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPathname(String pathname)
/*     */   {
/* 137 */     String oldPathname = this.pathname;
/* 138 */     this.pathname = pathname;
/* 139 */     this.support.firePropertyChange("pathname", oldPathname, this.pathname);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void load()
/*     */     throws ClassNotFoundException, IOException
/*     */   {
/* 147 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 149 */         AccessController.doPrivileged(new PrivilegedDoLoad());
/*     */       } catch (PrivilegedActionException ex) {
/* 151 */         Exception exception = ex.getException();
/* 152 */         if ((exception instanceof ClassNotFoundException))
/* 153 */           throw ((ClassNotFoundException)exception);
/* 154 */         if ((exception instanceof IOException)) {
/* 155 */           throw ((IOException)exception);
/*     */         }
/* 157 */         if (this.log.isDebugEnabled()) {
/* 158 */           this.log.debug("Unreported exception in load() ", exception);
/*     */         }
/*     */       }
/*     */     } else {
/* 162 */       doLoad();
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected void doLoad()
/*     */     throws ClassNotFoundException, IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 4	org/apache/catalina/session/StandardManager:log	Lorg/apache/juli/logging/Log;
/*     */     //   4: invokeinterface 19 1 0
/*     */     //   9: ifeq +14 -> 23
/*     */     //   12: aload_0
/*     */     //   13: getfield 4	org/apache/catalina/session/StandardManager:log	Lorg/apache/juli/logging/Log;
/*     */     //   16: ldc 23
/*     */     //   18: invokeinterface 24 2 0
/*     */     //   23: aload_0
/*     */     //   24: getfield 25	org/apache/catalina/session/StandardManager:sessions	Ljava/util/Map;
/*     */     //   27: invokeinterface 26 1 0
/*     */     //   32: aload_0
/*     */     //   33: invokevirtual 27	org/apache/catalina/session/StandardManager:file	()Ljava/io/File;
/*     */     //   36: astore_1
/*     */     //   37: aload_1
/*     */     //   38: ifnonnull +4 -> 42
/*     */     //   41: return
/*     */     //   42: aload_0
/*     */     //   43: getfield 4	org/apache/catalina/session/StandardManager:log	Lorg/apache/juli/logging/Log;
/*     */     //   46: invokeinterface 19 1 0
/*     */     //   51: ifeq +31 -> 82
/*     */     //   54: aload_0
/*     */     //   55: getfield 4	org/apache/catalina/session/StandardManager:log	Lorg/apache/juli/logging/Log;
/*     */     //   58: getstatic 28	org/apache/catalina/session/StandardManager:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   61: ldc 29
/*     */     //   63: iconst_1
/*     */     //   64: anewarray 30	java/lang/Object
/*     */     //   67: dup
/*     */     //   68: iconst_0
/*     */     //   69: aload_0
/*     */     //   70: getfield 6	org/apache/catalina/session/StandardManager:pathname	Ljava/lang/String;
/*     */     //   73: aastore
/*     */     //   74: invokevirtual 31	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   77: invokeinterface 24 2 0
/*     */     //   82: aconst_null
/*     */     //   83: astore_2
/*     */     //   84: aconst_null
/*     */     //   85: astore_3
/*     */     //   86: aconst_null
/*     */     //   87: astore 4
/*     */     //   89: new 32	java/io/FileInputStream
/*     */     //   92: dup
/*     */     //   93: aload_1
/*     */     //   94: invokevirtual 33	java/io/File:getAbsolutePath	()Ljava/lang/String;
/*     */     //   97: invokespecial 34	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
/*     */     //   100: astore 5
/*     */     //   102: aconst_null
/*     */     //   103: astore 6
/*     */     //   105: new 35	java/io/BufferedInputStream
/*     */     //   108: dup
/*     */     //   109: aload 5
/*     */     //   111: invokespecial 36	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
/*     */     //   114: astore 7
/*     */     //   116: aconst_null
/*     */     //   117: astore 8
/*     */     //   119: aload_0
/*     */     //   120: invokevirtual 37	org/apache/catalina/session/StandardManager:getContext	()Lorg/apache/catalina/Context;
/*     */     //   123: astore 9
/*     */     //   125: aload 9
/*     */     //   127: invokeinterface 38 1 0
/*     */     //   132: astore_2
/*     */     //   133: aload 9
/*     */     //   135: invokeinterface 39 1 0
/*     */     //   140: astore 4
/*     */     //   142: aload_2
/*     */     //   143: ifnull +10 -> 153
/*     */     //   146: aload_2
/*     */     //   147: invokeinterface 40 1 0
/*     */     //   152: astore_3
/*     */     //   153: aload_3
/*     */     //   154: ifnonnull +11 -> 165
/*     */     //   157: aload_0
/*     */     //   158: invokevirtual 41	java/lang/Object:getClass	()Ljava/lang/Class;
/*     */     //   161: invokevirtual 42	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   164: astore_3
/*     */     //   165: aload_0
/*     */     //   166: getfield 25	org/apache/catalina/session/StandardManager:sessions	Ljava/util/Map;
/*     */     //   169: dup
/*     */     //   170: astore 10
/*     */     //   172: monitorenter
/*     */     //   173: new 43	org/apache/catalina/util/CustomObjectInputStream
/*     */     //   176: dup
/*     */     //   177: aload 7
/*     */     //   179: aload_3
/*     */     //   180: aload 4
/*     */     //   182: aload_0
/*     */     //   183: invokevirtual 44	org/apache/catalina/session/StandardManager:getSessionAttributeValueClassNamePattern	()Ljava/util/regex/Pattern;
/*     */     //   186: aload_0
/*     */     //   187: invokevirtual 45	org/apache/catalina/session/StandardManager:getWarnOnSessionAttributeFilterFailure	()Z
/*     */     //   190: invokespecial 46	org/apache/catalina/util/CustomObjectInputStream:<init>	(Ljava/io/InputStream;Ljava/lang/ClassLoader;Lorg/apache/juli/logging/Log;Ljava/util/regex/Pattern;Z)V
/*     */     //   193: astore 11
/*     */     //   195: aconst_null
/*     */     //   196: astore 12
/*     */     //   198: aload 11
/*     */     //   200: invokevirtual 47	java/io/ObjectInputStream:readObject	()Ljava/lang/Object;
/*     */     //   203: checkcast 48	java/lang/Integer
/*     */     //   206: astore 13
/*     */     //   208: aload 13
/*     */     //   210: invokevirtual 49	java/lang/Integer:intValue	()I
/*     */     //   213: istore 14
/*     */     //   215: aload_0
/*     */     //   216: getfield 4	org/apache/catalina/session/StandardManager:log	Lorg/apache/juli/logging/Log;
/*     */     //   219: invokeinterface 19 1 0
/*     */     //   224: ifeq +37 -> 261
/*     */     //   227: aload_0
/*     */     //   228: getfield 4	org/apache/catalina/session/StandardManager:log	Lorg/apache/juli/logging/Log;
/*     */     //   231: new 50	java/lang/StringBuilder
/*     */     //   234: dup
/*     */     //   235: invokespecial 51	java/lang/StringBuilder:<init>	()V
/*     */     //   238: ldc 52
/*     */     //   240: invokevirtual 53	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   243: iload 14
/*     */     //   245: invokevirtual 54	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   248: ldc 55
/*     */     //   250: invokevirtual 53	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   253: invokevirtual 56	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   256: invokeinterface 24 2 0
/*     */     //   261: iconst_0
/*     */     //   262: istore 15
/*     */     //   264: iload 15
/*     */     //   266: iload 14
/*     */     //   268: if_icmpge +79 -> 347
/*     */     //   271: aload_0
/*     */     //   272: invokevirtual 57	org/apache/catalina/session/StandardManager:getNewSession	()Lorg/apache/catalina/session/StandardSession;
/*     */     //   275: astore 16
/*     */     //   277: aload 16
/*     */     //   279: aload 11
/*     */     //   281: invokevirtual 58	org/apache/catalina/session/StandardSession:readObjectData	(Ljava/io/ObjectInputStream;)V
/*     */     //   284: aload 16
/*     */     //   286: aload_0
/*     */     //   287: invokevirtual 59	org/apache/catalina/session/StandardSession:setManager	(Lorg/apache/catalina/Manager;)V
/*     */     //   290: aload_0
/*     */     //   291: getfield 25	org/apache/catalina/session/StandardManager:sessions	Ljava/util/Map;
/*     */     //   294: aload 16
/*     */     //   296: invokevirtual 60	org/apache/catalina/session/StandardSession:getIdInternal	()Ljava/lang/String;
/*     */     //   299: aload 16
/*     */     //   301: invokeinterface 61 3 0
/*     */     //   306: pop
/*     */     //   307: aload 16
/*     */     //   309: invokevirtual 62	org/apache/catalina/session/StandardSession:activate	()V
/*     */     //   312: aload 16
/*     */     //   314: invokevirtual 63	org/apache/catalina/session/StandardSession:isValidInternal	()Z
/*     */     //   317: ifne +14 -> 331
/*     */     //   320: aload 16
/*     */     //   322: iconst_1
/*     */     //   323: invokevirtual 64	org/apache/catalina/session/StandardSession:setValid	(Z)V
/*     */     //   326: aload 16
/*     */     //   328: invokevirtual 65	org/apache/catalina/session/StandardSession:expire	()V
/*     */     //   331: aload_0
/*     */     //   332: dup
/*     */     //   333: getfield 66	org/apache/catalina/session/StandardManager:sessionCounter	J
/*     */     //   336: lconst_1
/*     */     //   337: ladd
/*     */     //   338: putfield 66	org/apache/catalina/session/StandardManager:sessionCounter	J
/*     */     //   341: iinc 15 1
/*     */     //   344: goto -80 -> 264
/*     */     //   347: aload 11
/*     */     //   349: ifnull +85 -> 434
/*     */     //   352: aload 12
/*     */     //   354: ifnull +23 -> 377
/*     */     //   357: aload 11
/*     */     //   359: invokevirtual 67	java/io/ObjectInputStream:close	()V
/*     */     //   362: goto +72 -> 434
/*     */     //   365: astore 13
/*     */     //   367: aload 12
/*     */     //   369: aload 13
/*     */     //   371: invokevirtual 69	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   374: goto +60 -> 434
/*     */     //   377: aload 11
/*     */     //   379: invokevirtual 67	java/io/ObjectInputStream:close	()V
/*     */     //   382: goto +52 -> 434
/*     */     //   385: astore 13
/*     */     //   387: aload 13
/*     */     //   389: astore 12
/*     */     //   391: aload 13
/*     */     //   393: athrow
/*     */     //   394: astore 17
/*     */     //   396: aload 11
/*     */     //   398: ifnull +33 -> 431
/*     */     //   401: aload 12
/*     */     //   403: ifnull +23 -> 426
/*     */     //   406: aload 11
/*     */     //   408: invokevirtual 67	java/io/ObjectInputStream:close	()V
/*     */     //   411: goto +20 -> 431
/*     */     //   414: astore 18
/*     */     //   416: aload 12
/*     */     //   418: aload 18
/*     */     //   420: invokevirtual 69	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   423: goto +8 -> 431
/*     */     //   426: aload 11
/*     */     //   428: invokevirtual 67	java/io/ObjectInputStream:close	()V
/*     */     //   431: aload 17
/*     */     //   433: athrow
/*     */     //   434: aload_1
/*     */     //   435: invokevirtual 70	java/io/File:exists	()Z
/*     */     //   438: ifeq +82 -> 520
/*     */     //   441: aload_1
/*     */     //   442: invokevirtual 71	java/io/File:delete	()Z
/*     */     //   445: ifne +75 -> 520
/*     */     //   448: aload_0
/*     */     //   449: getfield 4	org/apache/catalina/session/StandardManager:log	Lorg/apache/juli/logging/Log;
/*     */     //   452: getstatic 28	org/apache/catalina/session/StandardManager:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   455: ldc 72
/*     */     //   457: iconst_1
/*     */     //   458: anewarray 30	java/lang/Object
/*     */     //   461: dup
/*     */     //   462: iconst_0
/*     */     //   463: aload_1
/*     */     //   464: aastore
/*     */     //   465: invokevirtual 31	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   468: invokeinterface 73 2 0
/*     */     //   473: goto +47 -> 520
/*     */     //   476: astore 19
/*     */     //   478: aload_1
/*     */     //   479: invokevirtual 70	java/io/File:exists	()Z
/*     */     //   482: ifeq +35 -> 517
/*     */     //   485: aload_1
/*     */     //   486: invokevirtual 71	java/io/File:delete	()Z
/*     */     //   489: ifne +28 -> 517
/*     */     //   492: aload_0
/*     */     //   493: getfield 4	org/apache/catalina/session/StandardManager:log	Lorg/apache/juli/logging/Log;
/*     */     //   496: getstatic 28	org/apache/catalina/session/StandardManager:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   499: ldc 72
/*     */     //   501: iconst_1
/*     */     //   502: anewarray 30	java/lang/Object
/*     */     //   505: dup
/*     */     //   506: iconst_0
/*     */     //   507: aload_1
/*     */     //   508: aastore
/*     */     //   509: invokevirtual 31	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   512: invokeinterface 73 2 0
/*     */     //   517: aload 19
/*     */     //   519: athrow
/*     */     //   520: aload 10
/*     */     //   522: monitorexit
/*     */     //   523: goto +11 -> 534
/*     */     //   526: astore 20
/*     */     //   528: aload 10
/*     */     //   530: monitorexit
/*     */     //   531: aload 20
/*     */     //   533: athrow
/*     */     //   534: aload 7
/*     */     //   536: ifnull +85 -> 621
/*     */     //   539: aload 8
/*     */     //   541: ifnull +23 -> 564
/*     */     //   544: aload 7
/*     */     //   546: invokevirtual 74	java/io/BufferedInputStream:close	()V
/*     */     //   549: goto +72 -> 621
/*     */     //   552: astore 9
/*     */     //   554: aload 8
/*     */     //   556: aload 9
/*     */     //   558: invokevirtual 69	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   561: goto +60 -> 621
/*     */     //   564: aload 7
/*     */     //   566: invokevirtual 74	java/io/BufferedInputStream:close	()V
/*     */     //   569: goto +52 -> 621
/*     */     //   572: astore 9
/*     */     //   574: aload 9
/*     */     //   576: astore 8
/*     */     //   578: aload 9
/*     */     //   580: athrow
/*     */     //   581: astore 21
/*     */     //   583: aload 7
/*     */     //   585: ifnull +33 -> 618
/*     */     //   588: aload 8
/*     */     //   590: ifnull +23 -> 613
/*     */     //   593: aload 7
/*     */     //   595: invokevirtual 74	java/io/BufferedInputStream:close	()V
/*     */     //   598: goto +20 -> 618
/*     */     //   601: astore 22
/*     */     //   603: aload 8
/*     */     //   605: aload 22
/*     */     //   607: invokevirtual 69	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   610: goto +8 -> 618
/*     */     //   613: aload 7
/*     */     //   615: invokevirtual 74	java/io/BufferedInputStream:close	()V
/*     */     //   618: aload 21
/*     */     //   620: athrow
/*     */     //   621: aload 5
/*     */     //   623: ifnull +85 -> 708
/*     */     //   626: aload 6
/*     */     //   628: ifnull +23 -> 651
/*     */     //   631: aload 5
/*     */     //   633: invokevirtual 75	java/io/FileInputStream:close	()V
/*     */     //   636: goto +72 -> 708
/*     */     //   639: astore 7
/*     */     //   641: aload 6
/*     */     //   643: aload 7
/*     */     //   645: invokevirtual 69	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   648: goto +60 -> 708
/*     */     //   651: aload 5
/*     */     //   653: invokevirtual 75	java/io/FileInputStream:close	()V
/*     */     //   656: goto +52 -> 708
/*     */     //   659: astore 7
/*     */     //   661: aload 7
/*     */     //   663: astore 6
/*     */     //   665: aload 7
/*     */     //   667: athrow
/*     */     //   668: astore 23
/*     */     //   670: aload 5
/*     */     //   672: ifnull +33 -> 705
/*     */     //   675: aload 6
/*     */     //   677: ifnull +23 -> 700
/*     */     //   680: aload 5
/*     */     //   682: invokevirtual 75	java/io/FileInputStream:close	()V
/*     */     //   685: goto +20 -> 705
/*     */     //   688: astore 24
/*     */     //   690: aload 6
/*     */     //   692: aload 24
/*     */     //   694: invokevirtual 69	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   697: goto +8 -> 705
/*     */     //   700: aload 5
/*     */     //   702: invokevirtual 75	java/io/FileInputStream:close	()V
/*     */     //   705: aload 23
/*     */     //   707: athrow
/*     */     //   708: goto +29 -> 737
/*     */     //   711: astore 5
/*     */     //   713: aload_0
/*     */     //   714: getfield 4	org/apache/catalina/session/StandardManager:log	Lorg/apache/juli/logging/Log;
/*     */     //   717: invokeinterface 19 1 0
/*     */     //   722: ifeq +14 -> 736
/*     */     //   725: aload_0
/*     */     //   726: getfield 4	org/apache/catalina/session/StandardManager:log	Lorg/apache/juli/logging/Log;
/*     */     //   729: ldc 77
/*     */     //   731: invokeinterface 24 2 0
/*     */     //   736: return
/*     */     //   737: aload_0
/*     */     //   738: getfield 4	org/apache/catalina/session/StandardManager:log	Lorg/apache/juli/logging/Log;
/*     */     //   741: invokeinterface 19 1 0
/*     */     //   746: ifeq +14 -> 760
/*     */     //   749: aload_0
/*     */     //   750: getfield 4	org/apache/catalina/session/StandardManager:log	Lorg/apache/juli/logging/Log;
/*     */     //   753: ldc 78
/*     */     //   755: invokeinterface 24 2 0
/*     */     //   760: return
/*     */     // Line number table:
/*     */     //   Java source line #177	-> byte code offset #0
/*     */     //   Java source line #178	-> byte code offset #12
/*     */     //   Java source line #182	-> byte code offset #23
/*     */     //   Java source line #185	-> byte code offset #32
/*     */     //   Java source line #186	-> byte code offset #37
/*     */     //   Java source line #187	-> byte code offset #41
/*     */     //   Java source line #189	-> byte code offset #42
/*     */     //   Java source line #190	-> byte code offset #54
/*     */     //   Java source line #192	-> byte code offset #82
/*     */     //   Java source line #193	-> byte code offset #84
/*     */     //   Java source line #194	-> byte code offset #86
/*     */     //   Java source line #195	-> byte code offset #89
/*     */     //   Java source line #196	-> byte code offset #105
/*     */     //   Java source line #195	-> byte code offset #116
/*     */     //   Java source line #197	-> byte code offset #119
/*     */     //   Java source line #198	-> byte code offset #125
/*     */     //   Java source line #199	-> byte code offset #133
/*     */     //   Java source line #200	-> byte code offset #142
/*     */     //   Java source line #201	-> byte code offset #146
/*     */     //   Java source line #203	-> byte code offset #153
/*     */     //   Java source line #204	-> byte code offset #157
/*     */     //   Java source line #208	-> byte code offset #165
/*     */     //   Java source line #209	-> byte code offset #173
/*     */     //   Java source line #210	-> byte code offset #183
/*     */     //   Java source line #211	-> byte code offset #187
/*     */     //   Java source line #209	-> byte code offset #195
/*     */     //   Java source line #212	-> byte code offset #198
/*     */     //   Java source line #213	-> byte code offset #208
/*     */     //   Java source line #214	-> byte code offset #215
/*     */     //   Java source line #215	-> byte code offset #227
/*     */     //   Java source line #217	-> byte code offset #261
/*     */     //   Java source line #218	-> byte code offset #271
/*     */     //   Java source line #219	-> byte code offset #277
/*     */     //   Java source line #220	-> byte code offset #284
/*     */     //   Java source line #221	-> byte code offset #290
/*     */     //   Java source line #222	-> byte code offset #307
/*     */     //   Java source line #223	-> byte code offset #312
/*     */     //   Java source line #226	-> byte code offset #320
/*     */     //   Java source line #227	-> byte code offset #326
/*     */     //   Java source line #229	-> byte code offset #331
/*     */     //   Java source line #217	-> byte code offset #341
/*     */     //   Java source line #231	-> byte code offset #347
/*     */     //   Java source line #209	-> byte code offset #385
/*     */     //   Java source line #231	-> byte code offset #394
/*     */     //   Java source line #233	-> byte code offset #434
/*     */     //   Java source line #234	-> byte code offset #441
/*     */     //   Java source line #235	-> byte code offset #448
/*     */     //   Java source line #233	-> byte code offset #476
/*     */     //   Java source line #234	-> byte code offset #485
/*     */     //   Java source line #235	-> byte code offset #492
/*     */     //   Java source line #238	-> byte code offset #517
/*     */     //   Java source line #239	-> byte code offset #520
/*     */     //   Java source line #240	-> byte code offset #534
/*     */     //   Java source line #195	-> byte code offset #572
/*     */     //   Java source line #240	-> byte code offset #581
/*     */     //   Java source line #195	-> byte code offset #659
/*     */     //   Java source line #240	-> byte code offset #668
/*     */     //   Java source line #245	-> byte code offset #708
/*     */     //   Java source line #240	-> byte code offset #711
/*     */     //   Java source line #241	-> byte code offset #713
/*     */     //   Java source line #242	-> byte code offset #725
/*     */     //   Java source line #244	-> byte code offset #736
/*     */     //   Java source line #247	-> byte code offset #737
/*     */     //   Java source line #248	-> byte code offset #749
/*     */     //   Java source line #250	-> byte code offset #760
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	761	0	this	StandardManager
/*     */     //   36	472	1	file	File
/*     */     //   83	64	2	loader	org.apache.catalina.Loader
/*     */     //   85	95	3	classLoader	ClassLoader
/*     */     //   87	94	4	logger	Log
/*     */     //   100	601	5	fis	java.io.FileInputStream
/*     */     //   711	3	5	e	java.io.FileNotFoundException
/*     */     //   103	588	6	localThrowable9	Throwable
/*     */     //   114	500	7	bis	java.io.BufferedInputStream
/*     */     //   639	5	7	localThrowable6	Throwable
/*     */     //   659	7	7	localThrowable7	Throwable
/*     */     //   117	487	8	localThrowable10	Throwable
/*     */     //   123	11	9	c	Context
/*     */     //   552	5	9	localThrowable3	Throwable
/*     */     //   572	7	9	localThrowable4	Throwable
/*     */     //   170	359	10	Ljava/lang/Object;	Object
/*     */     //   193	234	11	ois	java.io.ObjectInputStream
/*     */     //   196	221	12	localThrowable11	Throwable
/*     */     //   206	3	13	count	Integer
/*     */     //   365	5	13	localThrowable	Throwable
/*     */     //   385	7	13	localThrowable1	Throwable
/*     */     //   213	54	14	n	int
/*     */     //   262	80	15	i	int
/*     */     //   275	52	16	session	StandardSession
/*     */     //   394	38	17	localObject1	Object
/*     */     //   414	5	18	localThrowable2	Throwable
/*     */     //   476	42	19	localObject2	Object
/*     */     //   526	6	20	localObject3	Object
/*     */     //   581	38	21	localObject4	Object
/*     */     //   601	5	22	localThrowable5	Throwable
/*     */     //   668	38	23	localObject5	Object
/*     */     //   688	5	24	localThrowable8	Throwable
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   357	362	365	java/lang/Throwable
/*     */     //   198	347	385	java/lang/Throwable
/*     */     //   198	347	394	finally
/*     */     //   385	396	394	finally
/*     */     //   406	411	414	java/lang/Throwable
/*     */     //   173	434	476	finally
/*     */     //   476	478	476	finally
/*     */     //   173	523	526	finally
/*     */     //   526	531	526	finally
/*     */     //   544	549	552	java/lang/Throwable
/*     */     //   119	534	572	java/lang/Throwable
/*     */     //   119	534	581	finally
/*     */     //   572	583	581	finally
/*     */     //   593	598	601	java/lang/Throwable
/*     */     //   631	636	639	java/lang/Throwable
/*     */     //   105	621	659	java/lang/Throwable
/*     */     //   105	621	668	finally
/*     */     //   659	670	668	finally
/*     */     //   680	685	688	java/lang/Throwable
/*     */     //   89	708	711	java/io/FileNotFoundException
/*     */   }
/*     */   
/*     */   public void unload()
/*     */     throws IOException
/*     */   {
/* 255 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 257 */         AccessController.doPrivileged(new PrivilegedDoUnload());
/*     */       } catch (PrivilegedActionException ex) {
/* 259 */         Exception exception = ex.getException();
/* 260 */         if ((exception instanceof IOException)) {
/* 261 */           throw ((IOException)exception);
/*     */         }
/* 263 */         if (this.log.isDebugEnabled()) {
/* 264 */           this.log.debug("Unreported exception in unLoad()", exception);
/*     */         }
/*     */       }
/*     */     } else {
/* 268 */       doUnload();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doUnload()
/*     */     throws IOException
/*     */   {
/* 282 */     if (this.log.isDebugEnabled()) {
/* 283 */       this.log.debug(sm.getString("standardManager.unloading.debug"));
/*     */     }
/*     */     
/* 286 */     if (this.sessions.isEmpty()) {
/* 287 */       this.log.debug(sm.getString("standardManager.unloading.nosessions"));
/* 288 */       return;
/*     */     }
/*     */     
/*     */ 
/* 292 */     File file = file();
/* 293 */     if (file == null) {
/* 294 */       return;
/*     */     }
/* 296 */     if (this.log.isDebugEnabled()) {
/* 297 */       this.log.debug(sm.getString("standardManager.unloading", new Object[] { this.pathname }));
/*     */     }
/*     */     
/*     */ 
/* 301 */     List<StandardSession> list = new ArrayList();
/*     */     
/* 303 */     FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());Throwable localThrowable10 = null;
/* 304 */     try { BufferedOutputStream bos = new BufferedOutputStream(fos);Throwable localThrowable11 = null;
/* 305 */       try { ObjectOutputStream oos = new ObjectOutputStream(bos);Throwable localThrowable12 = null;
/*     */         try {
/* 307 */           synchronized (this.sessions) {
/* 308 */             if (this.log.isDebugEnabled()) {
/* 309 */               this.log.debug("Unloading " + this.sessions.size() + " sessions");
/*     */             }
/*     */             
/* 312 */             oos.writeObject(Integer.valueOf(this.sessions.size()));
/* 313 */             for (Session s : this.sessions.values()) {
/* 314 */               StandardSession session = (StandardSession)s;
/* 315 */               list.add(session);
/* 316 */               session.passivate();
/* 317 */               session.writeObjectData(oos);
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (Throwable localThrowable2)
/*     */         {
/* 303 */           localThrowable12 = localThrowable2;throw localThrowable2; } finally {} } catch (Throwable localThrowable5) { localThrowable11 = localThrowable5;throw localThrowable5; } finally {} } catch (Throwable localThrowable8) { localThrowable10 = localThrowable8;throw localThrowable8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 320 */       if (fos != null) if (localThrowable10 != null) try { fos.close(); } catch (Throwable localThrowable9) { localThrowable10.addSuppressed(localThrowable9); } else { fos.close();
/*     */         }
/*     */     }
/* 323 */     if (this.log.isDebugEnabled()) {
/* 324 */       this.log.debug("Expiring " + list.size() + " persisted sessions");
/*     */     }
/* 326 */     for (StandardSession session : list) {
/*     */       try {
/* 328 */         session.expire(false);
/*     */       } catch (Throwable t) {
/* 330 */         ExceptionUtils.handleThrowable(t);
/*     */       } finally {
/* 332 */         session.recycle();
/*     */       }
/*     */     }
/*     */     
/* 336 */     if (this.log.isDebugEnabled()) {
/* 337 */       this.log.debug("Unloading complete");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 352 */     super.startInternal();
/*     */     
/*     */     try
/*     */     {
/* 356 */       load();
/*     */     } catch (Throwable t) {
/* 358 */       ExceptionUtils.handleThrowable(t);
/* 359 */       this.log.error(sm.getString("standardManager.managerLoad"), t);
/*     */     }
/*     */     
/* 362 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 376 */     if (this.log.isDebugEnabled()) {
/* 377 */       this.log.debug("Stopping");
/*     */     }
/*     */     
/* 380 */     setState(LifecycleState.STOPPING);
/*     */     
/*     */     try
/*     */     {
/* 384 */       unload();
/*     */     } catch (Throwable t) {
/* 386 */       ExceptionUtils.handleThrowable(t);
/* 387 */       this.log.error(sm.getString("standardManager.managerUnload"), t);
/*     */     }
/*     */     
/*     */ 
/* 391 */     Session[] sessions = findSessions();
/* 392 */     for (Session session : sessions) {
/*     */       try {
/* 394 */         if (session.isValid()) {
/* 395 */           session.expire();
/*     */         }
/*     */       } catch (Throwable t) {
/* 398 */         ExceptionUtils.handleThrowable(t);
/*     */       }
/*     */       finally
/*     */       {
/* 402 */         session.recycle();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 407 */     super.stopInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected File file()
/*     */   {
/* 419 */     if ((this.pathname == null) || (this.pathname.length() == 0)) {
/* 420 */       return null;
/*     */     }
/* 422 */     File file = new File(this.pathname);
/* 423 */     if (!file.isAbsolute()) {
/* 424 */       Context context = getContext();
/* 425 */       ServletContext servletContext = context.getServletContext();
/* 426 */       File tempdir = (File)servletContext.getAttribute("javax.servlet.context.tempdir");
/* 427 */       if (tempdir != null) {
/* 428 */         file = new File(tempdir, this.pathname);
/*     */       }
/*     */     }
/* 431 */     return file;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\session\StandardManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */