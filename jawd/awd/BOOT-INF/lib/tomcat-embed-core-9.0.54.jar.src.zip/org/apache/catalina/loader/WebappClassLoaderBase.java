/*      */ package org.apache.catalina.loader;
/*      */ 
/*      */ import java.beans.Introspector;
/*      */ import java.io.File;
/*      */ import java.io.FilePermission;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.instrument.ClassFileTransformer;
/*      */ import java.lang.instrument.IllegalClassFormatException;
/*      */ import java.lang.ref.Reference;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLClassLoader;
/*      */ import java.security.AccessControlException;
/*      */ import java.security.AccessController;
/*      */ import java.security.CodeSource;
/*      */ import java.security.Permission;
/*      */ import java.security.PermissionCollection;
/*      */ import java.security.Policy;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.security.cert.Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.ConcurrentModificationException;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.concurrent.ThreadPoolExecutor;
/*      */ import java.util.jar.Attributes;
/*      */ import java.util.jar.Attributes.Name;
/*      */ import java.util.jar.Manifest;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Lifecycle;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.webresources.TomcatURLStreamHandlerFactory;
/*      */ import org.apache.juli.WebappProperties;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.InstrumentableClassLoader;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.IntrospectionUtils;
/*      */ import org.apache.tomcat.util.compat.JreCompat;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.PermissionCheck;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class WebappClassLoaderBase
/*      */   extends URLClassLoader
/*      */   implements Lifecycle, InstrumentableClassLoader, WebappProperties, PermissionCheck
/*      */ {
/*  127 */   private static final Log log = LogFactory.getLog(WebappClassLoaderBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  133 */   private static final List<String> JVM_THREAD_GROUP_NAMES = new ArrayList();
/*      */   
/*      */   private static final String JVM_THREAD_GROUP_SYSTEM = "system";
/*      */   private static final String CLASS_FILE_SUFFIX = ".class";
/*      */   
/*      */   static
/*      */   {
/*  140 */     if (!JreCompat.isGraalAvailable()) {
/*  141 */       ClassLoader.registerAsParallelCapable();
/*      */     }
/*  143 */     JVM_THREAD_GROUP_NAMES.add("system");
/*  144 */     JVM_THREAD_GROUP_NAMES.add("RMI Runtime");
/*      */   }
/*      */   
/*      */   protected class PrivilegedFindClassByName implements PrivilegedAction<Class<?>>
/*      */   {
/*      */     private final String name;
/*      */     
/*      */     PrivilegedFindClassByName(String name) {
/*  152 */       this.name = name;
/*      */     }
/*      */     
/*      */     public Class<?> run()
/*      */     {
/*  157 */       return WebappClassLoaderBase.this.findClassInternal(this.name);
/*      */     }
/*      */   }
/*      */   
/*      */   protected static final class PrivilegedGetClassLoader implements PrivilegedAction<ClassLoader>
/*      */   {
/*      */     private final Class<?> clazz;
/*      */     
/*      */     public PrivilegedGetClassLoader(Class<?> clazz)
/*      */     {
/*  167 */       this.clazz = clazz;
/*      */     }
/*      */     
/*      */     public ClassLoader run()
/*      */     {
/*  172 */       return this.clazz.getClassLoader();
/*      */     }
/*      */   }
/*      */   
/*      */   protected final class PrivilegedJavaseGetResource implements PrivilegedAction<URL>
/*      */   {
/*      */     private final String name;
/*      */     
/*      */     public PrivilegedJavaseGetResource(String name)
/*      */     {
/*  182 */       this.name = name;
/*      */     }
/*      */     
/*      */     public URL run()
/*      */     {
/*  187 */       return WebappClassLoaderBase.this.javaseClassLoader.getResource(this.name);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  197 */   protected static final StringManager sm = StringManager.getManager(WebappClassLoaderBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected WebappClassLoaderBase()
/*      */   {
/*  208 */     super(new URL[0]);
/*      */     
/*  210 */     ClassLoader p = getParent();
/*  211 */     if (p == null) {
/*  212 */       p = getSystemClassLoader();
/*      */     }
/*  214 */     this.parent = p;
/*      */     
/*  216 */     ClassLoader j = String.class.getClassLoader();
/*  217 */     if (j == null) {
/*  218 */       j = getSystemClassLoader();
/*  219 */       while (j.getParent() != null) {
/*  220 */         j = j.getParent();
/*      */       }
/*      */     }
/*  223 */     this.javaseClassLoader = j;
/*      */     
/*  225 */     this.securityManager = System.getSecurityManager();
/*  226 */     if (this.securityManager != null) {
/*  227 */       refreshPolicy();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected WebappClassLoaderBase(ClassLoader parent)
/*      */   {
/*  243 */     super(new URL[0], parent);
/*      */     
/*  245 */     ClassLoader p = getParent();
/*  246 */     if (p == null) {
/*  247 */       p = getSystemClassLoader();
/*      */     }
/*  249 */     this.parent = p;
/*      */     
/*  251 */     ClassLoader j = String.class.getClassLoader();
/*  252 */     if (j == null) {
/*  253 */       j = getSystemClassLoader();
/*  254 */       while (j.getParent() != null) {
/*  255 */         j = j.getParent();
/*      */       }
/*      */     }
/*  258 */     this.javaseClassLoader = j;
/*      */     
/*  260 */     this.securityManager = System.getSecurityManager();
/*  261 */     if (this.securityManager != null) {
/*  262 */       refreshPolicy();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  272 */   protected WebResourceRoot resources = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  282 */   protected final Map<String, ResourceEntry> resourceEntries = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  295 */   protected boolean delegate = false;
/*      */   
/*      */ 
/*  298 */   private final Map<String, Long> jarModificationTimes = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  305 */   protected final ArrayList<Permission> permissionList = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  312 */   protected final HashMap<String, PermissionCollection> loaderPC = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final SecurityManager securityManager;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final ClassLoader parent;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ClassLoader javaseClassLoader;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  341 */   private boolean clearReferencesRmiTargets = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  352 */   private boolean clearReferencesStopThreads = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  359 */   private boolean clearReferencesStopTimerThreads = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  368 */   private boolean clearReferencesLogFactoryRelease = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  378 */   private boolean clearReferencesHttpClientKeepAliveThread = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  384 */   private boolean clearReferencesObjectStreamClassCaches = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  390 */   private boolean clearReferencesThreadLocals = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  396 */   private boolean skipMemoryLeakChecksOnJvmShutdown = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  405 */   private final List<ClassFileTransformer> transformers = new CopyOnWriteArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  413 */   private boolean hasExternalRepositories = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  419 */   private List<URL> localRepositories = new ArrayList();
/*      */   
/*      */ 
/*  422 */   private volatile LifecycleState state = LifecycleState.NEW;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WebResourceRoot getResources()
/*      */   {
/*  431 */     return this.resources;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResources(WebResourceRoot resources)
/*      */   {
/*  441 */     this.resources = resources;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getContextName()
/*      */   {
/*  449 */     if (this.resources == null) {
/*  450 */       return "Unknown";
/*      */     }
/*  452 */     return this.resources.getContext().getBaseName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDelegate()
/*      */   {
/*  463 */     return this.delegate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDelegate(boolean delegate)
/*      */   {
/*  481 */     this.delegate = delegate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addPermission(URL url)
/*      */   {
/*  492 */     if (url == null) {
/*  493 */       return;
/*      */     }
/*  495 */     if (this.securityManager != null) {
/*  496 */       String protocol = url.getProtocol();
/*  497 */       if ("file".equalsIgnoreCase(protocol))
/*      */       {
/*      */ 
/*      */         try
/*      */         {
/*  502 */           URI uri = url.toURI();
/*  503 */           File f = new File(uri);
/*  504 */           path = f.getCanonicalPath();
/*      */         } catch (IOException|URISyntaxException e) { String path;
/*  506 */           log.warn(sm.getString("webappClassLoader.addPermissionNoCanonicalFile", new Object[] {url
/*      */           
/*  508 */             .toExternalForm() })); return; }
/*      */         String path;
/*      */         File f;
/*  511 */         URI uri; if (f.isFile())
/*      */         {
/*  513 */           addPermission(new FilePermission(path, "read"));
/*  514 */         } else if (f.isDirectory()) {
/*  515 */           addPermission(new FilePermission(path, "read"));
/*  516 */           addPermission(new FilePermission(path + File.separator + "-", "read"));
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  523 */         log.warn(sm.getString("webappClassLoader.addPermissionNoProtocol", new Object[] { protocol, url
/*      */         
/*  525 */           .toExternalForm() }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addPermission(Permission permission)
/*      */   {
/*  537 */     if ((this.securityManager != null) && (permission != null)) {
/*  538 */       this.permissionList.add(permission);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean getClearReferencesRmiTargets()
/*      */   {
/*  544 */     return this.clearReferencesRmiTargets;
/*      */   }
/*      */   
/*      */   public void setClearReferencesRmiTargets(boolean clearReferencesRmiTargets)
/*      */   {
/*  549 */     this.clearReferencesRmiTargets = clearReferencesRmiTargets;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesStopThreads()
/*      */   {
/*  557 */     return this.clearReferencesStopThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesStopThreads(boolean clearReferencesStopThreads)
/*      */   {
/*  568 */     this.clearReferencesStopThreads = clearReferencesStopThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesStopTimerThreads()
/*      */   {
/*  576 */     return this.clearReferencesStopTimerThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesStopTimerThreads(boolean clearReferencesStopTimerThreads)
/*      */   {
/*  587 */     this.clearReferencesStopTimerThreads = clearReferencesStopTimerThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesLogFactoryRelease()
/*      */   {
/*  595 */     return this.clearReferencesLogFactoryRelease;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesLogFactoryRelease(boolean clearReferencesLogFactoryRelease)
/*      */   {
/*  606 */     this.clearReferencesLogFactoryRelease = clearReferencesLogFactoryRelease;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesHttpClientKeepAliveThread()
/*      */   {
/*  616 */     return this.clearReferencesHttpClientKeepAliveThread;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesHttpClientKeepAliveThread(boolean clearReferencesHttpClientKeepAliveThread)
/*      */   {
/*  628 */     this.clearReferencesHttpClientKeepAliveThread = clearReferencesHttpClientKeepAliveThread;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getClearReferencesObjectStreamClassCaches()
/*      */   {
/*  634 */     return this.clearReferencesObjectStreamClassCaches;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setClearReferencesObjectStreamClassCaches(boolean clearReferencesObjectStreamClassCaches)
/*      */   {
/*  640 */     this.clearReferencesObjectStreamClassCaches = clearReferencesObjectStreamClassCaches;
/*      */   }
/*      */   
/*      */   public boolean getClearReferencesThreadLocals()
/*      */   {
/*  645 */     return this.clearReferencesThreadLocals;
/*      */   }
/*      */   
/*      */   public void setClearReferencesThreadLocals(boolean clearReferencesThreadLocals)
/*      */   {
/*  650 */     this.clearReferencesThreadLocals = clearReferencesThreadLocals;
/*      */   }
/*      */   
/*      */   public boolean getSkipMemoryLeakChecksOnJvmShutdown()
/*      */   {
/*  655 */     return this.skipMemoryLeakChecksOnJvmShutdown;
/*      */   }
/*      */   
/*      */   public void setSkipMemoryLeakChecksOnJvmShutdown(boolean skipMemoryLeakChecksOnJvmShutdown)
/*      */   {
/*  660 */     this.skipMemoryLeakChecksOnJvmShutdown = skipMemoryLeakChecksOnJvmShutdown;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTransformer(ClassFileTransformer transformer)
/*      */   {
/*  676 */     if (transformer == null) {
/*  677 */       throw new IllegalArgumentException(sm.getString("webappClassLoader.addTransformer.illegalArgument", new Object[] {
/*  678 */         getContextName() }));
/*      */     }
/*      */     
/*  681 */     if (this.transformers.contains(transformer))
/*      */     {
/*  683 */       log.warn(sm.getString("webappClassLoader.addTransformer.duplicate", new Object[] { transformer, 
/*  684 */         getContextName() }));
/*  685 */       return;
/*      */     }
/*  687 */     this.transformers.add(transformer);
/*      */     
/*  689 */     log.info(sm.getString("webappClassLoader.addTransformer", new Object[] { transformer, getContextName() }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeTransformer(ClassFileTransformer transformer)
/*      */   {
/*  704 */     if (transformer == null) {
/*  705 */       return;
/*      */     }
/*      */     
/*  708 */     if (this.transformers.remove(transformer)) {
/*  709 */       log.info(sm.getString("webappClassLoader.removeTransformer", new Object[] { transformer, 
/*  710 */         getContextName() }));
/*      */     }
/*      */   }
/*      */   
/*      */   protected void copyStateWithoutTransformers(WebappClassLoaderBase base) {
/*  715 */     base.resources = this.resources;
/*  716 */     base.delegate = this.delegate;
/*  717 */     base.state = LifecycleState.NEW;
/*  718 */     base.clearReferencesStopThreads = this.clearReferencesStopThreads;
/*  719 */     base.clearReferencesStopTimerThreads = this.clearReferencesStopTimerThreads;
/*  720 */     base.clearReferencesLogFactoryRelease = this.clearReferencesLogFactoryRelease;
/*  721 */     base.clearReferencesHttpClientKeepAliveThread = this.clearReferencesHttpClientKeepAliveThread;
/*  722 */     base.jarModificationTimes.putAll(this.jarModificationTimes);
/*  723 */     base.permissionList.addAll(this.permissionList);
/*  724 */     base.loaderPC.putAll(this.loaderPC);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean modified()
/*      */   {
/*  734 */     if (log.isDebugEnabled()) {
/*  735 */       log.debug("modified()");
/*      */     }
/*      */     
/*  738 */     for (Map.Entry<String, ResourceEntry> entry : this.resourceEntries.entrySet()) {
/*  739 */       cachedLastModified = ((ResourceEntry)entry.getValue()).lastModified;
/*      */       
/*  741 */       lastModified = this.resources.getClassLoaderResource((String)entry.getKey()).getLastModified();
/*  742 */       if (lastModified != cachedLastModified) {
/*  743 */         if (log.isDebugEnabled()) {
/*  744 */           log.debug(sm.getString("webappClassLoader.resourceModified", new Object[] {entry
/*  745 */             .getKey(), new Date(cachedLastModified), new Date(lastModified) }));
/*      */         }
/*      */         
/*      */ 
/*  749 */         return true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  754 */     WebResource[] jars = this.resources.listResources("/WEB-INF/lib");
/*      */     
/*      */ 
/*  757 */     int jarCount = 0;
/*  758 */     long cachedLastModified = jars;long l1 = cachedLastModified.length; for (long lastModified = 0; lastModified < l1; lastModified++) { WebResource jar = cachedLastModified[lastModified];
/*  759 */       if ((jar.getName().endsWith(".jar")) && (jar.isFile()) && (jar.canRead())) {
/*  760 */         jarCount++;
/*  761 */         Long recordedLastModified = (Long)this.jarModificationTimes.get(jar.getName());
/*  762 */         if (recordedLastModified == null)
/*      */         {
/*  764 */           log.info(sm.getString("webappClassLoader.jarsAdded", new Object[] {this.resources
/*  765 */             .getContext().getName() }));
/*  766 */           return true;
/*      */         }
/*  768 */         if (recordedLastModified.longValue() != jar.getLastModified())
/*      */         {
/*  770 */           log.info(sm.getString("webappClassLoader.jarsModified", new Object[] {this.resources
/*  771 */             .getContext().getName() }));
/*  772 */           return true;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  777 */     if (jarCount < this.jarModificationTimes.size()) {
/*  778 */       log.info(sm.getString("webappClassLoader.jarsRemoved", new Object[] {this.resources
/*  779 */         .getContext().getName() }));
/*  780 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  785 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/*  792 */     StringBuilder sb = new StringBuilder(getClass().getSimpleName());
/*  793 */     sb.append("\r\n  context: ");
/*  794 */     sb.append(getContextName());
/*  795 */     sb.append("\r\n  delegate: ");
/*  796 */     sb.append(this.delegate);
/*  797 */     sb.append("\r\n");
/*  798 */     if (this.parent != null) {
/*  799 */       sb.append("----------> Parent Classloader:\r\n");
/*  800 */       sb.append(this.parent.toString());
/*  801 */       sb.append("\r\n");
/*      */     }
/*  803 */     if (this.transformers.size() > 0) {
/*  804 */       sb.append("----------> Class file transformers:\r\n");
/*  805 */       for (ClassFileTransformer transformer : this.transformers) {
/*  806 */         sb.append(transformer).append("\r\n");
/*      */       }
/*      */     }
/*  809 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Class<?> doDefineClass(String name, byte[] b, int off, int len, ProtectionDomain protectionDomain)
/*      */   {
/*  819 */     return super.defineClass(name, b, off, len, protectionDomain);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Class<?> findClass(String name)
/*      */     throws ClassNotFoundException
/*      */   {
/*  833 */     if (log.isDebugEnabled()) {
/*  834 */       log.debug("    findClass(" + name + ")");
/*      */     }
/*      */     
/*  837 */     checkStateForClassLoading(name);
/*      */     
/*      */ 
/*  840 */     if (this.securityManager != null) {
/*  841 */       int i = name.lastIndexOf('.');
/*  842 */       if (i >= 0) {
/*      */         try {
/*  844 */           if (log.isTraceEnabled()) {
/*  845 */             log.trace("      securityManager.checkPackageDefinition");
/*      */           }
/*  847 */           this.securityManager.checkPackageDefinition(name.substring(0, i));
/*      */         } catch (Exception se) {
/*  849 */           if (log.isTraceEnabled()) {
/*  850 */             log.trace("      -->Exception-->ClassNotFoundException", se);
/*      */           }
/*  852 */           throw new ClassNotFoundException(name, se);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  859 */     Class<?> clazz = null;
/*      */     try {
/*  861 */       if (log.isTraceEnabled()) {
/*  862 */         log.trace("      findClassInternal(" + name + ")");
/*      */       }
/*      */       try {
/*  865 */         if (this.securityManager != null) {
/*  866 */           PrivilegedAction<Class<?>> dp = new PrivilegedFindClassByName(name);
/*      */           
/*  868 */           clazz = (Class)AccessController.doPrivileged(dp);
/*      */         } else {
/*  870 */           clazz = findClassInternal(name);
/*      */         }
/*      */       } catch (AccessControlException ace) {
/*  873 */         log.warn(sm.getString("webappClassLoader.securityException", new Object[] { name, ace
/*  874 */           .getMessage() }), ace);
/*  875 */         throw new ClassNotFoundException(name, ace);
/*      */       } catch (RuntimeException e) {
/*  877 */         if (log.isTraceEnabled()) {
/*  878 */           log.trace("      -->RuntimeException Rethrown", e);
/*      */         }
/*  880 */         throw e;
/*      */       }
/*  882 */       if ((clazz == null) && (this.hasExternalRepositories)) {
/*      */         try {
/*  884 */           clazz = super.findClass(name);
/*      */         } catch (AccessControlException ace) {
/*  886 */           log.warn(sm.getString("webappClassLoader.securityException", new Object[] { name, ace
/*  887 */             .getMessage() }), ace);
/*  888 */           throw new ClassNotFoundException(name, ace);
/*      */         } catch (RuntimeException e) {
/*  890 */           if (log.isTraceEnabled()) {
/*  891 */             log.trace("      -->RuntimeException Rethrown", e);
/*      */           }
/*  893 */           throw e;
/*      */         }
/*      */       }
/*  896 */       if (clazz == null) {
/*  897 */         if (log.isDebugEnabled()) {
/*  898 */           log.debug("    --> Returning ClassNotFoundException");
/*      */         }
/*  900 */         throw new ClassNotFoundException(name);
/*      */       }
/*      */     } catch (ClassNotFoundException e) {
/*  903 */       if (log.isTraceEnabled()) {
/*  904 */         log.trace("    --> Passing on ClassNotFoundException");
/*      */       }
/*  906 */       throw e;
/*      */     }
/*      */     
/*      */ 
/*  910 */     if (log.isTraceEnabled()) {
/*  911 */       log.debug("      Returning class " + clazz);
/*      */     }
/*      */     
/*  914 */     if (log.isTraceEnabled()) { ClassLoader cl;
/*      */       ClassLoader cl;
/*  916 */       if (Globals.IS_SECURITY_ENABLED) {
/*  917 */         cl = (ClassLoader)AccessController.doPrivileged(new PrivilegedGetClassLoader(clazz));
/*      */       }
/*      */       else {
/*  920 */         cl = clazz.getClassLoader();
/*      */       }
/*  922 */       log.debug("      Loaded by " + cl.toString());
/*      */     }
/*  924 */     return clazz;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL findResource(String name)
/*      */   {
/*  939 */     if (log.isDebugEnabled()) {
/*  940 */       log.debug("    findResource(" + name + ")");
/*      */     }
/*      */     
/*  943 */     checkStateForResourceLoading(name);
/*      */     
/*  945 */     URL url = null;
/*      */     
/*  947 */     String path = nameToPath(name);
/*      */     
/*  949 */     WebResource resource = this.resources.getClassLoaderResource(path);
/*  950 */     if (resource.exists()) {
/*  951 */       url = resource.getURL();
/*  952 */       trackLastModified(path, resource);
/*      */     }
/*      */     
/*  955 */     if ((url == null) && (this.hasExternalRepositories)) {
/*  956 */       url = super.findResource(name);
/*      */     }
/*      */     
/*  959 */     if (log.isDebugEnabled()) {
/*  960 */       if (url != null) {
/*  961 */         log.debug("    --> Returning '" + url.toString() + "'");
/*      */       } else {
/*  963 */         log.debug("    --> Resource not found, returning null");
/*      */       }
/*      */     }
/*  966 */     return url;
/*      */   }
/*      */   
/*      */   private void trackLastModified(String path, WebResource resource)
/*      */   {
/*  971 */     if (this.resourceEntries.containsKey(path)) {
/*  972 */       return;
/*      */     }
/*  974 */     ResourceEntry entry = new ResourceEntry();
/*  975 */     entry.lastModified = resource.getLastModified();
/*  976 */     synchronized (this.resourceEntries) {
/*  977 */       this.resourceEntries.putIfAbsent(path, entry);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<URL> findResources(String name)
/*      */     throws IOException
/*      */   {
/*  994 */     if (log.isDebugEnabled()) {
/*  995 */       log.debug("    findResources(" + name + ")");
/*      */     }
/*      */     
/*  998 */     checkStateForResourceLoading(name);
/*      */     
/* 1000 */     LinkedHashSet<URL> result = new LinkedHashSet();
/*      */     
/* 1002 */     String path = nameToPath(name);
/*      */     
/* 1004 */     WebResource[] webResources = this.resources.getClassLoaderResources(path);
/* 1005 */     for (WebResource webResource : webResources) {
/* 1006 */       if (webResource.exists()) {
/* 1007 */         result.add(webResource.getURL());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1012 */     if (this.hasExternalRepositories) {
/* 1013 */       Object otherResourcePaths = super.findResources(name);
/* 1014 */       while (((Enumeration)otherResourcePaths).hasMoreElements()) {
/* 1015 */         result.add(((Enumeration)otherResourcePaths).nextElement());
/*      */       }
/*      */     }
/*      */     
/* 1019 */     return Collections.enumeration(result);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL getResource(String name)
/*      */   {
/* 1048 */     if (log.isDebugEnabled()) {
/* 1049 */       log.debug("getResource(" + name + ")");
/*      */     }
/*      */     
/* 1052 */     checkStateForResourceLoading(name);
/*      */     
/* 1054 */     URL url = null;
/*      */     
/* 1056 */     boolean delegateFirst = (this.delegate) || (filter(name, false));
/*      */     
/*      */ 
/* 1059 */     if (delegateFirst) {
/* 1060 */       if (log.isDebugEnabled()) {
/* 1061 */         log.debug("  Delegating to parent classloader " + this.parent);
/*      */       }
/* 1063 */       url = this.parent.getResource(name);
/* 1064 */       if (url != null) {
/* 1065 */         if (log.isDebugEnabled()) {
/* 1066 */           log.debug("  --> Returning '" + url.toString() + "'");
/*      */         }
/* 1068 */         return url;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1073 */     url = findResource(name);
/* 1074 */     if (url != null) {
/* 1075 */       if (log.isDebugEnabled()) {
/* 1076 */         log.debug("  --> Returning '" + url.toString() + "'");
/*      */       }
/* 1078 */       return url;
/*      */     }
/*      */     
/*      */ 
/* 1082 */     if (!delegateFirst) {
/* 1083 */       url = this.parent.getResource(name);
/* 1084 */       if (url != null) {
/* 1085 */         if (log.isDebugEnabled()) {
/* 1086 */           log.debug("  --> Returning '" + url.toString() + "'");
/*      */         }
/* 1088 */         return url;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1093 */     if (log.isDebugEnabled()) {
/* 1094 */       log.debug("  --> Resource not found, returning null");
/*      */     }
/* 1096 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Enumeration<URL> getResources(String name)
/*      */     throws IOException
/*      */   {
/* 1104 */     Enumeration<URL> parentResources = getParent().getResources(name);
/* 1105 */     Enumeration<URL> localResources = findResources(name);
/*      */     
/*      */ 
/*      */ 
/* 1109 */     boolean delegateFirst = (this.delegate) || (filter(name, false));
/*      */     
/* 1111 */     if (delegateFirst) {
/* 1112 */       return new CombinedEnumeration(parentResources, localResources);
/*      */     }
/* 1114 */     return new CombinedEnumeration(localResources, parentResources);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getResourceAsStream(String name)
/*      */   {
/* 1131 */     if (log.isDebugEnabled()) {
/* 1132 */       log.debug("getResourceAsStream(" + name + ")");
/*      */     }
/*      */     
/* 1135 */     checkStateForResourceLoading(name);
/*      */     
/* 1137 */     InputStream stream = null;
/*      */     
/* 1139 */     boolean delegateFirst = (this.delegate) || (filter(name, false));
/*      */     
/*      */ 
/* 1142 */     if (delegateFirst) {
/* 1143 */       if (log.isDebugEnabled()) {
/* 1144 */         log.debug("  Delegating to parent classloader " + this.parent);
/*      */       }
/* 1146 */       stream = this.parent.getResourceAsStream(name);
/* 1147 */       if (stream != null) {
/* 1148 */         if (log.isDebugEnabled()) {
/* 1149 */           log.debug("  --> Returning stream from parent");
/*      */         }
/* 1151 */         return stream;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1156 */     if (log.isDebugEnabled()) {
/* 1157 */       log.debug("  Searching local repositories");
/*      */     }
/* 1159 */     String path = nameToPath(name);
/* 1160 */     WebResource resource = this.resources.getClassLoaderResource(path);
/* 1161 */     if (resource.exists()) {
/* 1162 */       stream = resource.getInputStream();
/* 1163 */       trackLastModified(path, resource);
/*      */     }
/*      */     try {
/* 1166 */       if ((this.hasExternalRepositories) && (stream == null)) {
/* 1167 */         URL url = super.findResource(name);
/* 1168 */         if (url != null) {
/* 1169 */           stream = url.openStream();
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException localIOException) {}
/*      */     
/* 1175 */     if (stream != null) {
/* 1176 */       if (log.isDebugEnabled()) {
/* 1177 */         log.debug("  --> Returning stream from local");
/*      */       }
/* 1179 */       return stream;
/*      */     }
/*      */     
/*      */ 
/* 1183 */     if (!delegateFirst) {
/* 1184 */       if (log.isDebugEnabled()) {
/* 1185 */         log.debug("  Delegating to parent classloader unconditionally " + this.parent);
/*      */       }
/* 1187 */       stream = this.parent.getResourceAsStream(name);
/* 1188 */       if (stream != null) {
/* 1189 */         if (log.isDebugEnabled()) {
/* 1190 */           log.debug("  --> Returning stream from parent");
/*      */         }
/* 1192 */         return stream;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1197 */     if (log.isDebugEnabled()) {
/* 1198 */       log.debug("  --> Resource not found, returning null");
/*      */     }
/* 1200 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Class<?> loadClass(String name)
/*      */     throws ClassNotFoundException
/*      */   {
/* 1215 */     return loadClass(name, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Class<?> loadClass(String name, boolean resolve)
/*      */     throws ClassNotFoundException
/*      */   {
/* 1247 */     synchronized (JreCompat.isGraalAvailable() ? this : getClassLoadingLock(name)) {
/* 1248 */       if (log.isDebugEnabled()) {
/* 1249 */         log.debug("loadClass(" + name + ", " + resolve + ")");
/*      */       }
/* 1251 */       Class<?> clazz = null;
/*      */       
/*      */ 
/* 1254 */       checkStateForClassLoading(name);
/*      */       
/*      */ 
/* 1257 */       clazz = findLoadedClass0(name);
/* 1258 */       if (clazz != null) {
/* 1259 */         if (log.isDebugEnabled()) {
/* 1260 */           log.debug("  Returning class from cache");
/*      */         }
/* 1262 */         if (resolve) {
/* 1263 */           resolveClass(clazz);
/*      */         }
/* 1265 */         return clazz;
/*      */       }
/*      */       
/*      */ 
/* 1269 */       clazz = JreCompat.isGraalAvailable() ? null : findLoadedClass(name);
/* 1270 */       if (clazz != null) {
/* 1271 */         if (log.isDebugEnabled()) {
/* 1272 */           log.debug("  Returning class from cache");
/*      */         }
/* 1274 */         if (resolve) {
/* 1275 */           resolveClass(clazz);
/*      */         }
/* 1277 */         return clazz;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1283 */       String resourceName = binaryNameToPath(name, false);
/*      */       
/* 1285 */       ClassLoader javaseLoader = getJavaseClassLoader();
/*      */       
/*      */ 
/*      */       boolean tryLoadingFromJavaseLoader;
/*      */       
/*      */ 
/*      */       try
/*      */       {
/*      */         URL url;
/*      */         
/*      */ 
/*      */         URL url;
/*      */         
/*      */ 
/* 1299 */         if (this.securityManager != null) {
/* 1300 */           PrivilegedAction<URL> dp = new PrivilegedJavaseGetResource(resourceName);
/* 1301 */           url = (URL)AccessController.doPrivileged(dp);
/*      */         } else {
/* 1303 */           url = javaseLoader.getResource(resourceName);
/*      */         }
/* 1305 */         tryLoadingFromJavaseLoader = url != null;
/*      */       } catch (Throwable t) {
/*      */         boolean tryLoadingFromJavaseLoader;
/* 1308 */         ExceptionUtils.handleThrowable(t);
/*      */         
/*      */ 
/*      */ 
/* 1312 */         tryLoadingFromJavaseLoader = true;
/*      */       }
/*      */       
/* 1315 */       if (tryLoadingFromJavaseLoader) {
/*      */         try {
/* 1317 */           clazz = javaseLoader.loadClass(name);
/* 1318 */           if (clazz != null) {
/* 1319 */             if (resolve) {
/* 1320 */               resolveClass(clazz);
/*      */             }
/* 1322 */             return clazz;
/*      */           }
/*      */         }
/*      */         catch (ClassNotFoundException localClassNotFoundException) {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1330 */       if (this.securityManager != null) {
/* 1331 */         int i = name.lastIndexOf('.');
/* 1332 */         if (i >= 0) {
/*      */           try {
/* 1334 */             this.securityManager.checkPackageAccess(name.substring(0, i));
/*      */           } catch (SecurityException se) {
/* 1336 */             String error = sm.getString("webappClassLoader.restrictedPackage", new Object[] { name });
/* 1337 */             log.info(error, se);
/* 1338 */             throw new ClassNotFoundException(error, se);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1343 */       boolean delegateLoad = (this.delegate) || (filter(name, true));
/*      */       
/*      */ 
/* 1346 */       if (delegateLoad) {
/* 1347 */         if (log.isDebugEnabled()) {
/* 1348 */           log.debug("  Delegating to parent classloader1 " + this.parent);
/*      */         }
/*      */         try {
/* 1351 */           clazz = Class.forName(name, false, this.parent);
/* 1352 */           if (clazz != null) {
/* 1353 */             if (log.isDebugEnabled()) {
/* 1354 */               log.debug("  Loading class from parent");
/*      */             }
/* 1356 */             if (resolve) {
/* 1357 */               resolveClass(clazz);
/*      */             }
/* 1359 */             return clazz;
/*      */           }
/*      */         }
/*      */         catch (ClassNotFoundException localClassNotFoundException1) {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1367 */       if (log.isDebugEnabled()) {
/* 1368 */         log.debug("  Searching local repositories");
/*      */       }
/*      */       try {
/* 1371 */         clazz = findClass(name);
/* 1372 */         if (clazz != null) {
/* 1373 */           if (log.isDebugEnabled()) {
/* 1374 */             log.debug("  Loading class from local repository");
/*      */           }
/* 1376 */           if (resolve) {
/* 1377 */             resolveClass(clazz);
/*      */           }
/* 1379 */           return clazz;
/*      */         }
/*      */       }
/*      */       catch (ClassNotFoundException localClassNotFoundException2) {}
/*      */       
/*      */ 
/*      */ 
/* 1386 */       if (!delegateLoad) {
/* 1387 */         if (log.isDebugEnabled()) {
/* 1388 */           log.debug("  Delegating to parent classloader at end: " + this.parent);
/*      */         }
/*      */         try {
/* 1391 */           clazz = Class.forName(name, false, this.parent);
/* 1392 */           if (clazz != null) {
/* 1393 */             if (log.isDebugEnabled()) {
/* 1394 */               log.debug("  Loading class from parent");
/*      */             }
/* 1396 */             if (resolve) {
/* 1397 */               resolveClass(clazz);
/*      */             }
/* 1399 */             return clazz;
/*      */           }
/*      */         }
/*      */         catch (ClassNotFoundException localClassNotFoundException3) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1407 */     throw new ClassNotFoundException(name);
/*      */   }
/*      */   
/*      */   protected void checkStateForClassLoading(String className)
/*      */     throws ClassNotFoundException
/*      */   {
/*      */     try
/*      */     {
/* 1415 */       checkStateForResourceLoading(className);
/*      */     } catch (IllegalStateException ise) {
/* 1417 */       throw new ClassNotFoundException(ise.getMessage(), ise);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void checkStateForResourceLoading(String resource)
/*      */     throws IllegalStateException
/*      */   {
/* 1425 */     if (!this.state.isAvailable()) {
/* 1426 */       String msg = sm.getString("webappClassLoader.stopped", new Object[] { resource });
/* 1427 */       IllegalStateException ise = new IllegalStateException(msg);
/* 1428 */       log.info(msg, ise);
/* 1429 */       throw ise;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PermissionCollection getPermissions(CodeSource codeSource)
/*      */   {
/* 1443 */     String codeUrl = codeSource.getLocation().toString();
/*      */     PermissionCollection pc;
/* 1445 */     if ((pc = (PermissionCollection)this.loaderPC.get(codeUrl)) == null) {
/* 1446 */       pc = super.getPermissions(codeSource);
/* 1447 */       if (pc != null) {
/* 1448 */         for (Permission p : this.permissionList) {
/* 1449 */           pc.add(p);
/*      */         }
/* 1451 */         this.loaderPC.put(codeUrl, pc);
/*      */       }
/*      */     }
/* 1454 */     return pc;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean check(Permission permission)
/*      */   {
/* 1460 */     if (!Globals.IS_SECURITY_ENABLED) {
/* 1461 */       return true;
/*      */     }
/* 1463 */     Policy currentPolicy = Policy.getPolicy();
/* 1464 */     if (currentPolicy != null) {
/* 1465 */       URL contextRootUrl = this.resources.getResource("/").getCodeBase();
/* 1466 */       CodeSource cs = new CodeSource(contextRootUrl, (Certificate[])null);
/* 1467 */       PermissionCollection pc = currentPolicy.getPermissions(cs);
/* 1468 */       if (pc.implies(permission)) {
/* 1469 */         return true;
/*      */       }
/*      */     }
/* 1472 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public URL[] getURLs()
/*      */   {
/* 1488 */     ArrayList<URL> result = new ArrayList();
/* 1489 */     result.addAll(this.localRepositories);
/* 1490 */     result.addAll(Arrays.asList(super.getURLs()));
/* 1491 */     return (URL[])result.toArray(new URL[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LifecycleListener[] findLifecycleListeners()
/*      */   {
/* 1515 */     return new LifecycleListener[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LifecycleState getState()
/*      */   {
/* 1537 */     return this.state;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getStateName()
/*      */   {
/* 1546 */     return getState().toString();
/*      */   }
/*      */   
/*      */ 
/*      */   public void init()
/*      */   {
/* 1552 */     this.state = LifecycleState.INITIALIZED;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void start()
/*      */     throws LifecycleException
/*      */   {
/* 1564 */     this.state = LifecycleState.STARTING_PREP;
/*      */     
/* 1566 */     WebResource[] classesResources = this.resources.getResources("/WEB-INF/classes");
/* 1567 */     WebResource[] arrayOfWebResource1 = classesResources;int i = arrayOfWebResource1.length; for (WebResource localWebResource1 = 0; localWebResource1 < i; localWebResource1++) { classes = arrayOfWebResource1[localWebResource1];
/* 1568 */       if ((classes.isDirectory()) && (classes.canRead())) {
/* 1569 */         this.localRepositories.add(classes.getURL());
/*      */       }
/*      */     }
/* 1572 */     WebResource[] jars = this.resources.listResources("/WEB-INF/lib");
/* 1573 */     WebResource[] arrayOfWebResource2 = jars;localWebResource1 = arrayOfWebResource2.length; for (WebResource classes = 0; classes < localWebResource1; classes++) { WebResource jar = arrayOfWebResource2[classes];
/* 1574 */       if ((jar.getName().endsWith(".jar")) && (jar.isFile()) && (jar.canRead())) {
/* 1575 */         this.localRepositories.add(jar.getURL());
/* 1576 */         this.jarModificationTimes.put(jar
/* 1577 */           .getName(), Long.valueOf(jar.getLastModified()));
/*      */       }
/*      */     }
/*      */     
/* 1581 */     this.state = LifecycleState.STARTED;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stop()
/*      */     throws LifecycleException
/*      */   {
/* 1593 */     this.state = LifecycleState.STOPPING_PREP;
/*      */     
/*      */ 
/*      */ 
/* 1597 */     clearReferences();
/*      */     
/* 1599 */     this.state = LifecycleState.STOPPING;
/*      */     
/* 1601 */     this.resourceEntries.clear();
/* 1602 */     this.jarModificationTimes.clear();
/* 1603 */     this.resources = null;
/*      */     
/* 1605 */     this.permissionList.clear();
/* 1606 */     this.loaderPC.clear();
/*      */     
/* 1608 */     this.state = LifecycleState.STOPPED;
/*      */   }
/*      */   
/*      */ 
/*      */   public void destroy()
/*      */   {
/* 1614 */     this.state = LifecycleState.DESTROYING;
/*      */     try
/*      */     {
/* 1617 */       super.close();
/*      */     } catch (IOException ioe) {
/* 1619 */       log.warn(sm.getString("webappClassLoader.superCloseFail"), ioe);
/*      */     }
/* 1621 */     this.state = LifecycleState.DESTROYED;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected ClassLoader getJavaseClassLoader()
/*      */   {
/* 1628 */     return this.javaseClassLoader;
/*      */   }
/*      */   
/*      */   protected void setJavaseClassLoader(ClassLoader classLoader) {
/* 1632 */     if (classLoader == null)
/*      */     {
/* 1634 */       throw new IllegalArgumentException(sm.getString("webappClassLoader.javaseClassLoaderNull"));
/*      */     }
/* 1636 */     this.javaseClassLoader = classLoader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void clearReferences()
/*      */   {
/* 1645 */     if ((this.skipMemoryLeakChecksOnJvmShutdown) && 
/* 1646 */       (!this.resources.getContext().getParent().getState().isAvailable()))
/*      */     {
/*      */       try
/*      */       {
/*      */ 
/* 1651 */         Thread dummyHook = new Thread();
/* 1652 */         Runtime.getRuntime().addShutdownHook(dummyHook);
/* 1653 */         Runtime.getRuntime().removeShutdownHook(dummyHook);
/*      */       } catch (IllegalStateException ise) {
/* 1655 */         return;
/*      */       }
/*      */     }
/*      */     
/* 1659 */     if (!JreCompat.isGraalAvailable())
/*      */     {
/* 1661 */       clearReferencesJdbc();
/*      */     }
/*      */     
/*      */ 
/* 1665 */     clearReferencesThreads();
/*      */     
/*      */ 
/* 1668 */     if ((this.clearReferencesObjectStreamClassCaches) && (!JreCompat.isGraalAvailable())) {
/* 1669 */       clearReferencesObjectStreamClassCaches();
/*      */     }
/*      */     
/*      */ 
/* 1673 */     if ((this.clearReferencesThreadLocals) && (!JreCompat.isGraalAvailable())) {
/* 1674 */       checkThreadLocalsForLeaks();
/*      */     }
/*      */     
/*      */ 
/* 1678 */     if (this.clearReferencesRmiTargets) {
/* 1679 */       clearReferencesRmiTargets();
/*      */     }
/*      */     
/*      */ 
/* 1683 */     IntrospectionUtils.clear();
/*      */     
/*      */ 
/* 1686 */     if (this.clearReferencesLogFactoryRelease) {
/* 1687 */       LogFactory.release(this);
/*      */     }
/*      */     
/*      */ 
/* 1691 */     Introspector.flushCaches();
/*      */     
/*      */ 
/* 1694 */     TomcatURLStreamHandlerFactory.release(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void clearReferencesJdbc()
/*      */   {
/* 1719 */     byte[] classBytes = new byte['ࠀ'];
/* 1720 */     int offset = 0;
/* 1721 */     try { InputStream is = getResourceAsStream("org/apache/catalina/loader/JdbcLeakPrevention.class");Throwable localThrowable4 = null;
/*      */       try {
/* 1723 */         int read = is.read(classBytes, offset, classBytes.length - offset);
/* 1724 */         while (read > -1) {
/* 1725 */           offset += read;
/* 1726 */           if (offset == classBytes.length)
/*      */           {
/* 1728 */             byte[] tmp = new byte[classBytes.length * 2];
/* 1729 */             System.arraycopy(classBytes, 0, tmp, 0, classBytes.length);
/* 1730 */             classBytes = tmp;
/*      */           }
/* 1732 */           read = is.read(classBytes, offset, classBytes.length - offset);
/*      */         }
/*      */         
/* 1735 */         Class<?> lpClass = defineClass("org.apache.catalina.loader.JdbcLeakPrevention", classBytes, 0, offset, 
/* 1736 */           getClass().getProtectionDomain());
/* 1737 */         Object obj = lpClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */         
/*      */ 
/* 1740 */         List<String> driverNames = (List)obj.getClass().getMethod("clearJdbcDriverRegistrations", new Class[0]).invoke(obj, new Object[0]);
/* 1741 */         for (String name : driverNames) {
/* 1742 */           log.warn(sm.getString("webappClassLoader.clearJdbc", new Object[] {
/* 1743 */             getContextName(), name }));
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable2)
/*      */       {
/* 1721 */         localThrowable4 = localThrowable2;throw localThrowable2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1745 */         if (is != null) if (localThrowable4 != null) try { is.close(); } catch (Throwable localThrowable3) { localThrowable4.addSuppressed(localThrowable3); } else is.close();
/*      */       }
/* 1747 */     } catch (Exception e) { Throwable t = ExceptionUtils.unwrapInvocationTargetException(e);
/* 1748 */       ExceptionUtils.handleThrowable(t);
/* 1749 */       log.warn(sm.getString("webappClassLoader.jdbcRemoveFailed", new Object[] {
/* 1750 */         getContextName() }), t);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void clearReferencesThreads()
/*      */   {
/* 1757 */     Thread[] threads = getThreads();
/* 1758 */     List<Thread> threadsToStop = new ArrayList();
/*      */     
/*      */ 
/* 1761 */     for (Thread thread : threads) {
/* 1762 */       if (thread != null) {
/* 1763 */         ClassLoader ccl = thread.getContextClassLoader();
/* 1764 */         if (ccl == this)
/*      */         {
/* 1766 */           if (thread != Thread.currentThread())
/*      */           {
/*      */ 
/*      */ 
/* 1770 */             String threadName = thread.getName();
/*      */             
/*      */ 
/* 1773 */             ThreadGroup tg = thread.getThreadGroup();
/* 1774 */             if ((tg != null) && (JVM_THREAD_GROUP_NAMES.contains(tg.getName())))
/*      */             {
/* 1776 */               if ((this.clearReferencesHttpClientKeepAliveThread) && 
/* 1777 */                 (threadName.equals("Keep-Alive-Timer"))) {
/* 1778 */                 thread.setContextClassLoader(this.parent);
/* 1779 */                 log.debug(sm.getString("webappClassLoader.checkThreadsHttpClient"));
/*      */ 
/*      */ 
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */             }
/* 1787 */             else if (thread.isAlive())
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1794 */               if ((thread.getClass().getName().startsWith("java.util.Timer")) && (this.clearReferencesStopTimerThreads))
/*      */               {
/* 1796 */                 clearReferencesStopTimerThread(thread);
/*      */               }
/*      */               else
/*      */               {
/* 1800 */                 if (isRequestThread(thread)) {
/* 1801 */                   log.warn(sm.getString("webappClassLoader.stackTraceRequestThread", new Object[] {
/* 1802 */                     getContextName(), threadName, getStackTrace(thread) }));
/*      */                 } else {
/* 1804 */                   log.warn(sm.getString("webappClassLoader.stackTrace", new Object[] {
/* 1805 */                     getContextName(), threadName, getStackTrace(thread) }));
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/* 1810 */                 if (this.clearReferencesStopThreads)
/*      */                 {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1816 */                   boolean usingExecutor = false;
/*      */                   
/*      */ 
/*      */ 
/*      */ 
/*      */                   try
/*      */                   {
/* 1823 */                     Object target = null;
/* 1824 */                     for (String fieldName : new String[] { "target", "runnable", "action" }) {
/*      */                       try {
/* 1826 */                         Field targetField = thread.getClass().getDeclaredField(fieldName);
/* 1827 */                         targetField.setAccessible(true);
/* 1828 */                         target = targetField.get(thread);
/*      */                       }
/*      */                       catch (NoSuchFieldException nfe) {}
/*      */                     }
/*      */                     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1837 */                     if ((target != null) && (target.getClass().getCanonicalName() != null) && 
/* 1838 */                       (target.getClass().getCanonicalName().equals("java.util.concurrent.ThreadPoolExecutor.Worker")))
/*      */                     {
/* 1840 */                       Field executorField = target.getClass().getDeclaredField("this$0");
/* 1841 */                       executorField.setAccessible(true);
/* 1842 */                       Object executor = executorField.get(target);
/* 1843 */                       if ((executor instanceof ThreadPoolExecutor)) {
/* 1844 */                         ((ThreadPoolExecutor)executor).shutdownNow();
/* 1845 */                         usingExecutor = true;
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                   catch (NoSuchFieldException|IllegalAccessException|RuntimeException e)
/*      */                   {
/* 1851 */                     log.warn(sm.getString("webappClassLoader.stopThreadFail", new Object[] {thread
/* 1852 */                       .getName(), getContextName() }), e);
/*      */                   }
/*      */                   
/*      */ 
/*      */ 
/*      */ 
/* 1858 */                   if ((!usingExecutor) && (!thread.isInterrupted())) {
/* 1859 */                     thread.interrupt();
/*      */                   }
/*      */                   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1866 */                   threadsToStop.add(thread);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1876 */     int count = 0;
/* 1877 */     for (Thread t : threadsToStop) {
/* 1878 */       while ((t.isAlive()) && (count < 100)) {
/*      */         try {
/* 1880 */           Thread.sleep(20L);
/*      */         }
/*      */         catch (InterruptedException e) {
/*      */           break;
/*      */         }
/* 1885 */         count++;
/*      */       }
/* 1887 */       if (t.isAlive())
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1892 */         t.stop();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isRequestThread(Thread thread)
/*      */   {
/* 1904 */     StackTraceElement[] elements = thread.getStackTrace();
/*      */     
/* 1906 */     if ((elements == null) || (elements.length == 0))
/*      */     {
/*      */ 
/* 1909 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1916 */     for (int i = 0; i < elements.length; i++) {
/* 1917 */       StackTraceElement element = elements[(elements.length - (i + 1))];
/* 1918 */       if ("org.apache.catalina.connector.CoyoteAdapter".equals(element
/* 1919 */         .getClassName())) {
/* 1920 */         return true;
/*      */       }
/*      */     }
/* 1923 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void clearReferencesStopTimerThread(Thread thread)
/*      */   {
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/* 1941 */         Field newTasksMayBeScheduledField = thread.getClass().getDeclaredField("newTasksMayBeScheduled");
/* 1942 */         newTasksMayBeScheduledField.setAccessible(true);
/* 1943 */         Field queueField = thread.getClass().getDeclaredField("queue");
/* 1944 */         queueField.setAccessible(true);
/*      */         
/* 1946 */         Object queue = queueField.get(thread);
/*      */         
/* 1948 */         Method clearMethod = queue.getClass().getDeclaredMethod("clear", new Class[0]);
/* 1949 */         clearMethod.setAccessible(true);
/*      */         
/* 1951 */         synchronized (queue) {
/* 1952 */           newTasksMayBeScheduledField.setBoolean(thread, false);
/* 1953 */           clearMethod.invoke(queue, new Object[0]);
/*      */           
/*      */ 
/* 1956 */           queue.notifyAll();
/*      */         }
/*      */       }
/*      */       catch (NoSuchFieldException nfe) {
/* 1960 */         Method cancelMethod = thread.getClass().getDeclaredMethod("cancel", new Class[0]);
/* 1961 */         synchronized (thread) {
/* 1962 */           cancelMethod.setAccessible(true);
/* 1963 */           cancelMethod.invoke(thread, new Object[0]);
/*      */         }
/*      */       }
/*      */       
/* 1967 */       log.warn(sm.getString("webappClassLoader.warnTimerThread", new Object[] {
/* 1968 */         getContextName(), thread.getName() }));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1972 */       Throwable t = ExceptionUtils.unwrapInvocationTargetException(e);
/* 1973 */       ExceptionUtils.handleThrowable(t);
/* 1974 */       log.warn(sm.getString("webappClassLoader.stopTimerThreadFail", new Object[] {thread
/*      */       
/* 1976 */         .getName(), getContextName() }), t);
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkThreadLocalsForLeaks() {
/* 1981 */     Thread[] threads = getThreads();
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1987 */       Field threadLocalsField = Thread.class.getDeclaredField("threadLocals");
/* 1988 */       threadLocalsField.setAccessible(true);
/*      */       
/* 1990 */       Field inheritableThreadLocalsField = Thread.class.getDeclaredField("inheritableThreadLocals");
/* 1991 */       inheritableThreadLocalsField.setAccessible(true);
/*      */       
/*      */ 
/* 1994 */       Class<?> tlmClass = Class.forName("java.lang.ThreadLocal$ThreadLocalMap");
/* 1995 */       Field tableField = tlmClass.getDeclaredField("table");
/* 1996 */       tableField.setAccessible(true);
/* 1997 */       Method expungeStaleEntriesMethod = tlmClass.getDeclaredMethod("expungeStaleEntries", new Class[0]);
/* 1998 */       expungeStaleEntriesMethod.setAccessible(true);
/*      */       
/* 2000 */       for (Thread thread : threads)
/*      */       {
/* 2002 */         if (thread != null)
/*      */         {
/*      */ 
/* 2005 */           Object threadLocalMap = threadLocalsField.get(thread);
/* 2006 */           if (null != threadLocalMap) {
/* 2007 */             expungeStaleEntriesMethod.invoke(threadLocalMap, new Object[0]);
/* 2008 */             checkThreadLocalMapForLeaks(threadLocalMap, tableField);
/*      */           }
/*      */           
/*      */ 
/* 2012 */           threadLocalMap = inheritableThreadLocalsField.get(thread);
/* 2013 */           if (null != threadLocalMap) {
/* 2014 */             expungeStaleEntriesMethod.invoke(threadLocalMap, new Object[0]);
/* 2015 */             checkThreadLocalMapForLeaks(threadLocalMap, tableField);
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (Throwable t) {
/* 2020 */       JreCompat jreCompat = JreCompat.getInstance();
/* 2021 */       if (jreCompat.isInstanceOfInaccessibleObjectException(t))
/*      */       {
/*      */ 
/* 2024 */         String currentModule = JreCompat.getInstance().getModuleName(getClass());
/* 2025 */         log.warn(sm.getString("webappClassLoader.addExportsThreadLocal", new Object[] { currentModule }));
/*      */       } else {
/* 2027 */         ExceptionUtils.handleThrowable(t);
/* 2028 */         log.warn(sm.getString("webappClassLoader.checkThreadLocalsForLeaksFail", new Object[] {
/*      */         
/* 2030 */           getContextName() }), t);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkThreadLocalMapForLeaks(Object map, Field internalTableField)
/*      */     throws IllegalAccessException, NoSuchFieldException
/*      */   {
/* 2044 */     if (map != null) {
/* 2045 */       Object[] table = (Object[])internalTableField.get(map);
/* 2046 */       if (table != null) {
/* 2047 */         for (Object obj : table) {
/* 2048 */           if (obj != null) {
/* 2049 */             boolean keyLoadedByWebapp = false;
/* 2050 */             boolean valueLoadedByWebapp = false;
/*      */             
/* 2052 */             Object key = ((Reference)obj).get();
/* 2053 */             if ((equals(key)) || (loadedByThisOrChild(key))) {
/* 2054 */               keyLoadedByWebapp = true;
/*      */             }
/*      */             
/*      */ 
/* 2058 */             Field valueField = obj.getClass().getDeclaredField("value");
/* 2059 */             valueField.setAccessible(true);
/* 2060 */             Object value = valueField.get(obj);
/* 2061 */             if ((equals(value)) || (loadedByThisOrChild(value))) {
/* 2062 */               valueLoadedByWebapp = true;
/*      */             }
/* 2064 */             if ((keyLoadedByWebapp) || (valueLoadedByWebapp)) {
/* 2065 */               Object[] args = new Object[5];
/* 2066 */               args[0] = getContextName();
/* 2067 */               if (key != null) {
/* 2068 */                 args[1] = getPrettyClassName(key.getClass());
/*      */                 try {
/* 2070 */                   args[2] = key.toString();
/*      */                 } catch (Exception e) {
/* 2072 */                   log.warn(sm.getString("webappClassLoader.checkThreadLocalsForLeaks.badKey", new Object[] { args[1] }), e);
/*      */                   
/*      */ 
/* 2075 */                   args[2] = sm.getString("webappClassLoader.checkThreadLocalsForLeaks.unknown");
/*      */                 }
/*      */               }
/*      */               
/* 2079 */               if (value != null) {
/* 2080 */                 args[3] = getPrettyClassName(value.getClass());
/*      */                 try {
/* 2082 */                   args[4] = value.toString();
/*      */                 } catch (Exception e) {
/* 2084 */                   log.warn(sm.getString("webappClassLoader.checkThreadLocalsForLeaks.badValue", new Object[] { args[3] }), e);
/*      */                   
/*      */ 
/* 2087 */                   args[4] = sm.getString("webappClassLoader.checkThreadLocalsForLeaks.unknown");
/*      */                 }
/*      */               }
/*      */               
/* 2091 */               if (valueLoadedByWebapp) {
/* 2092 */                 log.error(sm.getString("webappClassLoader.checkThreadLocalsForLeaks", args));
/*      */ 
/*      */               }
/* 2095 */               else if (value == null) {
/* 2096 */                 if (log.isDebugEnabled()) {
/* 2097 */                   log.debug(sm.getString("webappClassLoader.checkThreadLocalsForLeaksNull", args));
/*      */                 }
/*      */                 
/*      */ 
/*      */               }
/* 2102 */               else if (log.isDebugEnabled()) {
/* 2103 */                 log.debug(sm.getString("webappClassLoader.checkThreadLocalsForLeaksNone", args));
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getPrettyClassName(Class<?> clazz)
/*      */   {
/* 2116 */     String name = clazz.getCanonicalName();
/* 2117 */     if (name == null) {
/* 2118 */       name = clazz.getName();
/*      */     }
/* 2120 */     return name;
/*      */   }
/*      */   
/*      */   private String getStackTrace(Thread thread) {
/* 2124 */     StringBuilder builder = new StringBuilder();
/* 2125 */     for (StackTraceElement ste : thread.getStackTrace()) {
/* 2126 */       builder.append("\n ").append(ste);
/*      */     }
/* 2128 */     return builder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean loadedByThisOrChild(Object o)
/*      */   {
/* 2137 */     if (o == null) {
/* 2138 */       return false;
/*      */     }
/*      */     Class<?> clazz;
/*      */     Class<?> clazz;
/* 2142 */     if ((o instanceof Class)) {
/* 2143 */       clazz = (Class)o;
/*      */     } else {
/* 2145 */       clazz = o.getClass();
/*      */     }
/*      */     
/* 2148 */     ClassLoader cl = clazz.getClassLoader();
/* 2149 */     while (cl != null) {
/* 2150 */       if (cl == this) {
/* 2151 */         return true;
/*      */       }
/* 2153 */       cl = cl.getParent();
/*      */     }
/*      */     
/* 2156 */     if ((o instanceof Collection)) {
/* 2157 */       Iterator<?> iter = ((Collection)o).iterator();
/*      */       try {
/* 2159 */         while (iter.hasNext()) {
/* 2160 */           Object entry = iter.next();
/* 2161 */           if (loadedByThisOrChild(entry)) {
/* 2162 */             return true;
/*      */           }
/*      */         }
/*      */       } catch (ConcurrentModificationException e) {
/* 2166 */         log.warn(sm.getString("webappClassLoader.loadedByThisOrChildFail", new Object[] {clazz
/* 2167 */           .getName(), getContextName() }), e);
/*      */       }
/*      */     }
/*      */     
/* 2171 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Thread[] getThreads()
/*      */   {
/* 2179 */     ThreadGroup tg = Thread.currentThread().getThreadGroup();
/*      */     try
/*      */     {
/* 2182 */       while (tg.getParent() != null) {
/* 2183 */         tg = tg.getParent();
/*      */       }
/*      */     } catch (SecurityException se) {
/* 2186 */       String msg = sm.getString("webappClassLoader.getThreadGroupError", new Object[] {tg
/* 2187 */         .getName() });
/* 2188 */       if (log.isDebugEnabled()) {
/* 2189 */         log.debug(msg, se);
/*      */       } else {
/* 2191 */         log.warn(msg);
/*      */       }
/*      */     }
/*      */     
/* 2195 */     int threadCountGuess = tg.activeCount() + 50;
/* 2196 */     Thread[] threads = new Thread[threadCountGuess];
/* 2197 */     int threadCountActual = tg.enumerate(threads);
/*      */     
/* 2199 */     while (threadCountActual == threadCountGuess) {
/* 2200 */       threadCountGuess *= 2;
/* 2201 */       threads = new Thread[threadCountGuess];
/*      */       
/*      */ 
/* 2204 */       threadCountActual = tg.enumerate(threads);
/*      */     }
/*      */     
/* 2207 */     return threads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void clearReferencesRmiTargets()
/*      */   {
/*      */     try
/*      */     {
/* 2220 */       Class<?> objectTargetClass = Class.forName("sun.rmi.transport.Target");
/* 2221 */       Field cclField = objectTargetClass.getDeclaredField("ccl");
/* 2222 */       cclField.setAccessible(true);
/*      */       
/* 2224 */       Field stubField = objectTargetClass.getDeclaredField("stub");
/* 2225 */       stubField.setAccessible(true);
/*      */       
/*      */ 
/* 2228 */       Class<?> objectTableClass = Class.forName("sun.rmi.transport.ObjectTable");
/* 2229 */       Field objTableField = objectTableClass.getDeclaredField("objTable");
/* 2230 */       objTableField.setAccessible(true);
/* 2231 */       Object objTable = objTableField.get(null);
/* 2232 */       if (objTable == null) {
/* 2233 */         return;
/*      */       }
/* 2235 */       Field tableLockField = objectTableClass.getDeclaredField("tableLock");
/* 2236 */       tableLockField.setAccessible(true);
/* 2237 */       Object tableLock = tableLockField.get(null);
/*      */       
/* 2239 */       synchronized (tableLock)
/*      */       {
/* 2241 */         if ((objTable instanceof Map)) {
/* 2242 */           Iterator<?> iter = ((Map)objTable).values().iterator();
/* 2243 */           while (iter.hasNext()) {
/* 2244 */             Object obj = iter.next();
/* 2245 */             Object cclObject = cclField.get(obj);
/* 2246 */             if (this == cclObject) {
/* 2247 */               iter.remove();
/* 2248 */               Object stubObject = stubField.get(obj);
/* 2249 */               log.error(sm.getString("webappClassLoader.clearRmi", new Object[] {stubObject
/* 2250 */                 .getClass().getName(), stubObject }));
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 2256 */         Field implTableField = objectTableClass.getDeclaredField("implTable");
/* 2257 */         implTableField.setAccessible(true);
/* 2258 */         Object implTable = implTableField.get(null);
/* 2259 */         if (implTable == null) {
/* 2260 */           return;
/*      */         }
/*      */         
/*      */ 
/* 2264 */         if ((implTable instanceof Map)) {
/* 2265 */           Iterator<?> iter = ((Map)implTable).values().iterator();
/* 2266 */           while (iter.hasNext()) {
/* 2267 */             Object obj = iter.next();
/* 2268 */             Object cclObject = cclField.get(obj);
/* 2269 */             if (this == cclObject) {
/* 2270 */               iter.remove();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (ClassNotFoundException e) {
/* 2276 */       log.info(sm.getString("webappClassLoader.clearRmiInfo", new Object[] {
/* 2277 */         getContextName() }), e);
/*      */     }
/*      */     catch (SecurityException|NoSuchFieldException|IllegalArgumentException|IllegalAccessException e) {
/* 2280 */       log.warn(sm.getString("webappClassLoader.clearRmiFail", new Object[] {
/* 2281 */         getContextName() }), e);
/*      */     } catch (Exception e) {
/* 2283 */       JreCompat jreCompat = JreCompat.getInstance();
/* 2284 */       if (jreCompat.isInstanceOfInaccessibleObjectException(e))
/*      */       {
/*      */ 
/* 2287 */         String currentModule = JreCompat.getInstance().getModuleName(getClass());
/* 2288 */         log.warn(sm.getString("webappClassLoader.addExportsRmi", new Object[] { currentModule }));
/*      */       }
/*      */       else {
/* 2291 */         throw e;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void clearReferencesObjectStreamClassCaches()
/*      */   {
/*      */     try {
/* 2299 */       Class<?> clazz = Class.forName("java.io.ObjectStreamClass$Caches");
/* 2300 */       clearCache(clazz, "localDescs");
/* 2301 */       clearCache(clazz, "reflectors");
/*      */     } catch (ReflectiveOperationException|SecurityException|ClassCastException e) {
/* 2303 */       log.warn(sm.getString("webappClassLoader.clearObjectStreamClassCachesFail", new Object[] {
/* 2304 */         getContextName() }), e);
/*      */     } catch (Exception e) {
/* 2306 */       JreCompat jreCompat = JreCompat.getInstance();
/* 2307 */       if (jreCompat.isInstanceOfInaccessibleObjectException(e))
/*      */       {
/*      */ 
/* 2310 */         String currentModule = JreCompat.getInstance().getModuleName(getClass());
/* 2311 */         log.warn(sm.getString("webappClassLoader.addExportsJavaIo", new Object[] { currentModule }));
/* 2312 */         return;
/*      */       }
/*      */       
/* 2315 */       throw e;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void clearCache(Class<?> target, String mapName)
/*      */     throws ReflectiveOperationException, SecurityException, ClassCastException
/*      */   {
/* 2323 */     Field f = target.getDeclaredField(mapName);
/* 2324 */     f.setAccessible(true);
/* 2325 */     Map<?, ?> map = (Map)f.get(null);
/* 2326 */     Iterator<?> keys = map.keySet().iterator();
/* 2327 */     while (keys.hasNext()) {
/* 2328 */       Object key = keys.next();
/* 2329 */       if ((key instanceof Reference)) {
/* 2330 */         Object clazz = ((Reference)key).get();
/* 2331 */         if (loadedByThisOrChild(clazz)) {
/* 2332 */           keys.remove();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Class<?> findClassInternal(String name)
/*      */   {
/* 2348 */     checkStateForResourceLoading(name);
/*      */     
/* 2350 */     if (name == null) {
/* 2351 */       return null;
/*      */     }
/* 2353 */     String path = binaryNameToPath(name, true);
/*      */     
/* 2355 */     ResourceEntry entry = (ResourceEntry)this.resourceEntries.get(path);
/* 2356 */     WebResource resource = null;
/*      */     
/* 2358 */     if (entry == null) {
/* 2359 */       resource = this.resources.getClassLoaderResource(path);
/*      */       
/* 2361 */       if (!resource.exists()) {
/* 2362 */         return null;
/*      */       }
/*      */       
/* 2365 */       entry = new ResourceEntry();
/* 2366 */       entry.lastModified = resource.getLastModified();
/*      */       
/*      */ 
/* 2369 */       synchronized (this.resourceEntries)
/*      */       {
/*      */ 
/*      */ 
/* 2373 */         ResourceEntry entry2 = (ResourceEntry)this.resourceEntries.get(path);
/* 2374 */         if (entry2 == null) {
/* 2375 */           this.resourceEntries.put(path, entry);
/*      */         } else {
/* 2377 */           entry = entry2;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2382 */     Class<?> clazz = entry.loadedClass;
/* 2383 */     if (clazz != null) {
/* 2384 */       return clazz;
/*      */     }
/*      */     
/* 2387 */     synchronized (JreCompat.isGraalAvailable() ? this : getClassLoadingLock(name)) {
/* 2388 */       clazz = entry.loadedClass;
/* 2389 */       if (clazz != null) {
/* 2390 */         return clazz;
/*      */       }
/*      */       
/* 2393 */       if (resource == null) {
/* 2394 */         resource = this.resources.getClassLoaderResource(path);
/*      */       }
/*      */       
/* 2397 */       if (!resource.exists()) {
/* 2398 */         return null;
/*      */       }
/*      */       
/* 2401 */       byte[] binaryContent = resource.getContent();
/* 2402 */       if (binaryContent == null)
/*      */       {
/*      */ 
/* 2405 */         return null;
/*      */       }
/* 2407 */       Manifest manifest = resource.getManifest();
/* 2408 */       URL codeBase = resource.getCodeBase();
/* 2409 */       Certificate[] certificates = resource.getCertificates();
/*      */       String internalName;
/* 2411 */       if (this.transformers.size() > 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2417 */         internalName = path.substring(1, path.length() - ".class".length());
/*      */         
/* 2419 */         for (ClassFileTransformer transformer : this.transformers) {
/*      */           try {
/* 2421 */             byte[] transformed = transformer.transform(this, internalName, null, null, binaryContent);
/*      */             
/* 2423 */             if (transformed != null) {
/* 2424 */               binaryContent = transformed;
/*      */             }
/*      */           } catch (IllegalClassFormatException e) {
/* 2427 */             log.error(sm.getString("webappClassLoader.transformError", new Object[] { name }), e);
/* 2428 */             return null;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2434 */       String packageName = null;
/* 2435 */       int pos = name.lastIndexOf('.');
/* 2436 */       if (pos != -1) {
/* 2437 */         packageName = name.substring(0, pos);
/*      */       }
/*      */       
/* 2440 */       Package pkg = null;
/*      */       
/* 2442 */       if (packageName != null) {
/* 2443 */         pkg = getPackage(packageName);
/*      */         
/*      */ 
/* 2446 */         if (pkg == null) {
/*      */           try {
/* 2448 */             if (manifest == null) {
/* 2449 */               definePackage(packageName, null, null, null, null, null, null, null);
/*      */             } else {
/* 2451 */               definePackage(packageName, manifest, codeBase);
/*      */             }
/*      */           }
/*      */           catch (IllegalArgumentException localIllegalArgumentException) {}
/*      */           
/* 2456 */           pkg = getPackage(packageName);
/*      */         }
/*      */       }
/*      */       
/* 2460 */       if (this.securityManager != null)
/*      */       {
/* 2462 */         if (pkg != null) {
/* 2463 */           boolean sealCheck = true;
/* 2464 */           if (pkg.isSealed()) {
/* 2465 */             sealCheck = pkg.isSealed(codeBase);
/*      */           } else {
/* 2467 */             sealCheck = (manifest == null) || (!isPackageSealed(packageName, manifest));
/*      */           }
/* 2469 */           if (!sealCheck) {
/* 2470 */             throw new SecurityException("Sealing violation loading " + name + " : Package " + packageName + " is sealed.");
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 2478 */         clazz = defineClass(name, binaryContent, 0, binaryContent.length, new CodeSource(codeBase, certificates));
/*      */ 
/*      */       }
/*      */       catch (UnsupportedClassVersionError ucve)
/*      */       {
/* 2483 */         throw new UnsupportedClassVersionError(ucve.getLocalizedMessage() + " " + sm.getString("webappClassLoader.wrongVersion", new Object[] { name }));
/*      */       }
/*      */       
/* 2486 */       entry.loadedClass = clazz;
/*      */     }
/*      */     
/* 2489 */     return clazz;
/*      */   }
/*      */   
/*      */ 
/*      */   private String binaryNameToPath(String binaryName, boolean withLeadingSlash)
/*      */   {
/* 2495 */     StringBuilder path = new StringBuilder(7 + binaryName.length());
/* 2496 */     if (withLeadingSlash) {
/* 2497 */       path.append('/');
/*      */     }
/* 2499 */     path.append(binaryName.replace('.', '/'));
/* 2500 */     path.append(".class");
/* 2501 */     return path.toString();
/*      */   }
/*      */   
/*      */   private String nameToPath(String name)
/*      */   {
/* 2506 */     if (name.startsWith("/")) {
/* 2507 */       return name;
/*      */     }
/*      */     
/* 2510 */     StringBuilder path = new StringBuilder(1 + name.length());
/* 2511 */     path.append('/');
/* 2512 */     path.append(name);
/* 2513 */     return path.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isPackageSealed(String name, Manifest man)
/*      */   {
/* 2527 */     String path = name.replace('.', '/') + '/';
/* 2528 */     Attributes attr = man.getAttributes(path);
/* 2529 */     String sealed = null;
/* 2530 */     if (attr != null) {
/* 2531 */       sealed = attr.getValue(Attributes.Name.SEALED);
/*      */     }
/* 2533 */     if ((sealed == null) && 
/* 2534 */       ((attr = man.getMainAttributes()) != null)) {
/* 2535 */       sealed = attr.getValue(Attributes.Name.SEALED);
/*      */     }
/*      */     
/* 2538 */     return "true".equalsIgnoreCase(sealed);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Class<?> findLoadedClass0(String name)
/*      */   {
/* 2553 */     String path = binaryNameToPath(name, true);
/*      */     
/* 2555 */     ResourceEntry entry = (ResourceEntry)this.resourceEntries.get(path);
/* 2556 */     if (entry != null) {
/* 2557 */       return entry.loadedClass;
/*      */     }
/* 2559 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void refreshPolicy()
/*      */   {
/*      */     try
/*      */     {
/* 2572 */       Policy policy = Policy.getPolicy();
/* 2573 */       policy.refresh();
/*      */     }
/*      */     catch (AccessControlException localAccessControlException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean filter(String name, boolean isClassName)
/*      */   {
/* 2592 */     if (name == null) {
/* 2593 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 2597 */     if (name.startsWith("javax"))
/*      */     {
/* 2599 */       if (name.length() == 5) {
/* 2600 */         return false;
/*      */       }
/* 2602 */       char ch = name.charAt(5);
/* 2603 */       if ((isClassName) && (ch == '.'))
/*      */       {
/* 2605 */         if (name.startsWith("servlet.jsp.jstl.", 6)) {
/* 2606 */           return false;
/*      */         }
/* 2608 */         if ((name.startsWith("el.", 6)) || 
/* 2609 */           (name.startsWith("servlet.", 6)) || 
/* 2610 */           (name.startsWith("websocket.", 6)) || 
/* 2611 */           (name.startsWith("security.auth.message.", 6))) {
/* 2612 */           return true;
/*      */         }
/* 2614 */       } else if ((!isClassName) && (ch == '/'))
/*      */       {
/* 2616 */         if (name.startsWith("servlet/jsp/jstl/", 6)) {
/* 2617 */           return false;
/*      */         }
/* 2619 */         if ((name.startsWith("el/", 6)) || 
/* 2620 */           (name.startsWith("servlet/", 6)) || 
/* 2621 */           (name.startsWith("websocket/", 6)) || 
/* 2622 */           (name.startsWith("security/auth/message/", 6))) {
/* 2623 */           return true;
/*      */         }
/*      */       }
/* 2626 */     } else if (name.startsWith("org"))
/*      */     {
/* 2628 */       if (name.length() == 3) {
/* 2629 */         return false;
/*      */       }
/* 2631 */       char ch = name.charAt(3);
/* 2632 */       if ((isClassName) && (ch == '.'))
/*      */       {
/* 2634 */         if (name.startsWith("apache.", 4))
/*      */         {
/* 2636 */           if (name.startsWith("tomcat.jdbc.", 11)) {
/* 2637 */             return false;
/*      */           }
/* 2639 */           if ((name.startsWith("el.", 11)) || 
/* 2640 */             (name.startsWith("catalina.", 11)) || 
/* 2641 */             (name.startsWith("jasper.", 11)) || 
/* 2642 */             (name.startsWith("juli.", 11)) || 
/* 2643 */             (name.startsWith("tomcat.", 11)) || 
/* 2644 */             (name.startsWith("naming.", 11)) || 
/* 2645 */             (name.startsWith("coyote.", 11))) {
/* 2646 */             return true;
/*      */           }
/*      */         }
/* 2649 */       } else if ((!isClassName) && (ch == '/'))
/*      */       {
/* 2651 */         if (name.startsWith("apache/", 4))
/*      */         {
/* 2653 */           if (name.startsWith("tomcat/jdbc/", 11)) {
/* 2654 */             return false;
/*      */           }
/* 2656 */           if ((name.startsWith("el/", 11)) || 
/* 2657 */             (name.startsWith("catalina/", 11)) || 
/* 2658 */             (name.startsWith("jasper/", 11)) || 
/* 2659 */             (name.startsWith("juli/", 11)) || 
/* 2660 */             (name.startsWith("tomcat/", 11)) || 
/* 2661 */             (name.startsWith("naming/", 11)) || 
/* 2662 */             (name.startsWith("coyote/", 11))) {
/* 2663 */             return true;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2668 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   protected void addURL(URL url)
/*      */   {
/* 2674 */     super.addURL(url);
/* 2675 */     this.hasExternalRepositories = true;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getWebappName()
/*      */   {
/* 2681 */     return getContextName();
/*      */   }
/*      */   
/*      */ 
/*      */   public String getHostName()
/*      */   {
/* 2687 */     if (this.resources != null) {
/* 2688 */       Container host = this.resources.getContext().getParent();
/* 2689 */       if (host != null) {
/* 2690 */         return host.getName();
/*      */       }
/*      */     }
/* 2693 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getServiceName()
/*      */   {
/* 2699 */     if (this.resources != null) {
/* 2700 */       Container host = this.resources.getContext().getParent();
/* 2701 */       if (host != null) {
/* 2702 */         Container engine = host.getParent();
/* 2703 */         if (engine != null) {
/* 2704 */           return engine.getName();
/*      */         }
/*      */       }
/*      */     }
/* 2708 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean hasLoggingConfig()
/*      */   {
/* 2714 */     if (Globals.IS_SECURITY_ENABLED) {
/* 2715 */       Boolean result = (Boolean)AccessController.doPrivileged(new PrivilegedHasLoggingConfig(null));
/* 2716 */       return result.booleanValue();
/*      */     }
/* 2718 */     return findResource("logging.properties") != null;
/*      */   }
/*      */   
/*      */   public void addLifecycleListener(LifecycleListener listener) {}
/*      */   
/*      */   public void removeLifecycleListener(LifecycleListener listener) {}
/*      */   
/*      */   private class PrivilegedHasLoggingConfig implements PrivilegedAction<Boolean> { private PrivilegedHasLoggingConfig() {}
/*      */     
/* 2727 */     public Boolean run() { return Boolean.valueOf(WebappClassLoaderBase.this.findResource("logging.properties") != null); }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class CombinedEnumeration
/*      */     implements Enumeration<URL>
/*      */   {
/*      */     private final Enumeration<URL>[] sources;
/* 2735 */     private int index = 0;
/*      */     
/*      */     public CombinedEnumeration(Enumeration<URL> enum1, Enumeration<URL> enum2)
/*      */     {
/* 2739 */       Enumeration<URL>[] sources = { enum1, enum2 };
/* 2740 */       this.sources = sources;
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean hasMoreElements()
/*      */     {
/* 2746 */       return inc();
/*      */     }
/*      */     
/*      */ 
/*      */     public URL nextElement()
/*      */     {
/* 2752 */       if (inc()) {
/* 2753 */         return (URL)this.sources[this.index].nextElement();
/*      */       }
/* 2755 */       throw new NoSuchElementException();
/*      */     }
/*      */     
/*      */     private boolean inc()
/*      */     {
/* 2760 */       while (this.index < this.sources.length) {
/* 2761 */         if (this.sources[this.index].hasMoreElements()) {
/* 2762 */           return true;
/*      */         }
/* 2764 */         this.index += 1;
/*      */       }
/* 2766 */       return false;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\loader\WebappClassLoaderBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */