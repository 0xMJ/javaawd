/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.Principal;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.ContinueResponseTiming;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.descriptor.web.LoginConfig;
/*     */ import org.apache.tomcat.util.http.MimeHeaders;
/*     */ import org.apache.tomcat.util.http.Parameters;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormAuthenticator
/*     */   extends AuthenticatorBase
/*     */ {
/*  55 */   private final Log log = LogFactory.getLog(FormAuthenticator.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */   protected String characterEncoding = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   protected String landingPage = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCharacterEncoding()
/*     */   {
/*  83 */     return this.characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharacterEncoding(String encoding)
/*     */   {
/*  93 */     this.characterEncoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLandingPage()
/*     */   {
/* 103 */     return this.landingPage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLandingPage(String landingPage)
/*     */   {
/* 114 */     this.landingPage = landingPage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean doAuthenticate(org.apache.catalina.connector.Request request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/* 137 */     Session session = null;
/* 138 */     Principal principal = null;
/*     */     
/*     */ 
/* 141 */     if (!this.cache) {
/* 142 */       session = request.getSessionInternal(true);
/* 143 */       if (this.log.isDebugEnabled()) {
/* 144 */         this.log.debug("Checking for reauthenticate in session " + session);
/*     */       }
/* 146 */       String username = (String)session.getNote("org.apache.catalina.session.USERNAME");
/* 147 */       String password = (String)session.getNote("org.apache.catalina.session.PASSWORD");
/* 148 */       if ((username != null) && (password != null)) {
/* 149 */         if (this.log.isDebugEnabled()) {
/* 150 */           this.log.debug("Reauthenticating username '" + username + "'");
/*     */         }
/* 152 */         principal = this.context.getRealm().authenticate(username, password);
/* 153 */         if (principal != null) {
/* 154 */           register(request, response, principal, "FORM", username, password);
/* 155 */           if (!matchRequest(request)) {
/* 156 */             return true;
/*     */           }
/*     */         }
/* 159 */         if (this.log.isDebugEnabled()) {
/* 160 */           this.log.debug("Reauthentication failed, proceed normally");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 167 */     if (matchRequest(request)) {
/* 168 */       session = request.getSessionInternal(true);
/* 169 */       if (this.log.isDebugEnabled()) {
/* 170 */         this.log.debug("Restore request from session '" + session.getIdInternal() + "'");
/*     */       }
/* 172 */       if (restoreRequest(request, session)) {
/* 173 */         if (this.log.isDebugEnabled()) {
/* 174 */           this.log.debug("Proceed to restored request");
/*     */         }
/* 176 */         return true;
/*     */       }
/* 178 */       if (this.log.isDebugEnabled()) {
/* 179 */         this.log.debug("Restore of original request failed");
/*     */       }
/* 181 */       response.sendError(400);
/* 182 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 188 */     if (checkForCachedAuthentication(request, response, true)) {
/* 189 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 193 */     String contextPath = request.getContextPath();
/* 194 */     String requestURI = request.getDecodedRequestURI();
/*     */     
/*     */ 
/* 197 */     boolean loginAction = (requestURI.startsWith(contextPath)) && (requestURI.endsWith("/j_security_check"));
/*     */     
/* 199 */     LoginConfig config = this.context.getLoginConfig();
/*     */     
/*     */ 
/* 202 */     if (!loginAction)
/*     */     {
/*     */ 
/*     */ 
/* 206 */       if ((request.getServletPath().length() == 0) && (request.getPathInfo() == null)) {
/* 207 */         StringBuilder location = new StringBuilder(requestURI);
/* 208 */         location.append('/');
/* 209 */         if (request.getQueryString() != null) {
/* 210 */           location.append('?');
/* 211 */           location.append(request.getQueryString());
/*     */         }
/* 213 */         response.sendRedirect(response.encodeRedirectURL(location.toString()));
/* 214 */         return false;
/*     */       }
/*     */       
/* 217 */       session = request.getSessionInternal(true);
/* 218 */       if (this.log.isDebugEnabled()) {
/* 219 */         this.log.debug("Save request in session '" + session.getIdInternal() + "'");
/*     */       }
/*     */       try {
/* 222 */         saveRequest(request, session);
/*     */       } catch (IOException ioe) {
/* 224 */         this.log.debug("Request body too big to save during authentication");
/* 225 */         response.sendError(403, sm.getString("authenticator.requestBodyTooBig"));
/* 226 */         return false;
/*     */       }
/* 228 */       forwardToLoginPage(request, response, config);
/* 229 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 234 */     request.getResponse().sendAcknowledgement(ContinueResponseTiming.ALWAYS);
/* 235 */     Realm realm = this.context.getRealm();
/* 236 */     if (this.characterEncoding != null) {
/* 237 */       request.setCharacterEncoding(this.characterEncoding);
/*     */     }
/* 239 */     String username = request.getParameter("j_username");
/* 240 */     String password = request.getParameter("j_password");
/* 241 */     if (this.log.isDebugEnabled()) {
/* 242 */       this.log.debug("Authenticating username '" + username + "'");
/*     */     }
/* 244 */     principal = realm.authenticate(username, password);
/* 245 */     if (principal == null) {
/* 246 */       forwardToErrorPage(request, response, config);
/* 247 */       return false;
/*     */     }
/*     */     
/* 250 */     if (this.log.isDebugEnabled()) {
/* 251 */       this.log.debug("Authentication of '" + username + "' was successful");
/*     */     }
/*     */     
/* 254 */     if (session == null) {
/* 255 */       session = request.getSessionInternal(false);
/*     */     }
/* 257 */     if ((session != null) && (getChangeSessionIdOnAuthentication()))
/*     */     {
/* 259 */       String expectedSessionId = (String)session.getNote("org.apache.catalina.authenticator.SESSION_ID");
/* 260 */       if ((expectedSessionId == null) || (!expectedSessionId.equals(request.getRequestedSessionId()))) {
/* 261 */         session.expire();
/* 262 */         session = null;
/*     */       }
/*     */     }
/* 265 */     if (session == null) {
/* 266 */       if (this.containerLog.isDebugEnabled()) {
/* 267 */         this.containerLog.debug("User took so long to log on the session expired");
/*     */       }
/* 269 */       if (this.landingPage == null) {
/* 270 */         response.sendError(408, sm
/* 271 */           .getString("authenticator.sessionExpired"));
/*     */       }
/*     */       else
/*     */       {
/* 275 */         String uri = request.getContextPath() + this.landingPage;
/* 276 */         SavedRequest saved = new SavedRequest();
/* 277 */         saved.setMethod("GET");
/* 278 */         saved.setRequestURI(uri);
/* 279 */         saved.setDecodedRequestURI(uri);
/* 280 */         request.getSessionInternal(true).setNote("org.apache.catalina.authenticator.REQUEST", saved);
/* 281 */         response.sendRedirect(response.encodeRedirectURL(uri));
/*     */       }
/* 283 */       return false;
/*     */     }
/*     */     
/* 286 */     register(request, response, principal, "FORM", username, password);
/*     */     
/*     */ 
/*     */ 
/* 290 */     requestURI = savedRequestURL(session);
/* 291 */     if (this.log.isDebugEnabled()) {
/* 292 */       this.log.debug("Redirecting to original '" + requestURI + "'");
/*     */     }
/* 294 */     if (requestURI == null) {
/* 295 */       if (this.landingPage == null) {
/* 296 */         response.sendError(400, sm.getString("authenticator.formlogin"));
/*     */       }
/*     */       else
/*     */       {
/* 300 */         String uri = request.getContextPath() + this.landingPage;
/* 301 */         SavedRequest saved = new SavedRequest();
/* 302 */         saved.setMethod("GET");
/* 303 */         saved.setRequestURI(uri);
/* 304 */         saved.setDecodedRequestURI(uri);
/* 305 */         session.setNote("org.apache.catalina.authenticator.REQUEST", saved);
/* 306 */         response.sendRedirect(response.encodeRedirectURL(uri));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 311 */       Response internalResponse = request.getResponse();
/* 312 */       String location = response.encodeRedirectURL(requestURI);
/* 313 */       if ("HTTP/1.1".equals(request.getProtocol())) {
/* 314 */         internalResponse.sendRedirect(location, 303);
/*     */       } else {
/* 316 */         internalResponse.sendRedirect(location, 302);
/*     */       }
/*     */     }
/* 319 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isContinuationRequired(org.apache.catalina.connector.Request request)
/*     */   {
/* 328 */     String contextPath = this.context.getPath();
/* 329 */     String decodedRequestURI = request.getDecodedRequestURI();
/* 330 */     if ((decodedRequestURI.startsWith(contextPath)) && 
/* 331 */       (decodedRequestURI.endsWith("/j_security_check"))) {
/* 332 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 341 */     Session session = request.getSessionInternal(false);
/* 342 */     if (session != null) {
/* 343 */       SavedRequest savedRequest = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/* 344 */       if ((savedRequest != null) && 
/* 345 */         (decodedRequestURI.equals(savedRequest.getDecodedRequestURI()))) {
/* 346 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 350 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getAuthMethod()
/*     */   {
/* 356 */     return "FORM";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void register(org.apache.catalina.connector.Request request, HttpServletResponse response, Principal principal, String authType, String username, String password, boolean alwaysUseSession, boolean cache)
/*     */   {
/* 365 */     super.register(request, response, principal, authType, username, password, alwaysUseSession, cache);
/*     */     
/*     */ 
/*     */ 
/* 369 */     if (!cache) {
/* 370 */       Session session = request.getSessionInternal(false);
/* 371 */       if (session != null) {
/* 372 */         if (username != null) {
/* 373 */           session.setNote("org.apache.catalina.session.USERNAME", username);
/*     */         } else {
/* 375 */           session.removeNote("org.apache.catalina.session.USERNAME");
/*     */         }
/* 377 */         if (password != null) {
/* 378 */           session.setNote("org.apache.catalina.session.PASSWORD", password);
/*     */         } else {
/* 380 */           session.removeNote("org.apache.catalina.session.PASSWORD");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void forwardToLoginPage(org.apache.catalina.connector.Request request, HttpServletResponse response, LoginConfig config)
/*     */     throws IOException
/*     */   {
/* 402 */     if (this.log.isDebugEnabled()) {
/* 403 */       this.log.debug(sm.getString("formAuthenticator.forwardLogin", new Object[] {request
/* 404 */         .getRequestURI(), request.getMethod(), config
/* 405 */         .getLoginPage(), this.context.getName() }));
/*     */     }
/*     */     
/* 408 */     String loginPage = config.getLoginPage();
/* 409 */     if ((loginPage == null) || (loginPage.length() == 0)) {
/* 410 */       String msg = sm.getString("formAuthenticator.noLoginPage", new Object[] {this.context
/* 411 */         .getName() });
/* 412 */       this.log.warn(msg);
/* 413 */       response.sendError(500, msg);
/*     */       
/* 415 */       return;
/*     */     }
/*     */     
/* 418 */     if (getChangeSessionIdOnAuthentication()) {
/* 419 */       Session session = request.getSessionInternal(false);
/* 420 */       if (session != null) {
/* 421 */         String newSessionId = changeSessionID(request, session);
/* 422 */         session.setNote("org.apache.catalina.authenticator.SESSION_ID", newSessionId);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 427 */     String oldMethod = request.getMethod();
/* 428 */     request.getCoyoteRequest().method().setString("GET");
/*     */     
/*     */ 
/* 431 */     RequestDispatcher disp = this.context.getServletContext().getRequestDispatcher(loginPage);
/*     */     try {
/* 433 */       if (this.context.fireRequestInitEvent(request.getRequest())) {
/* 434 */         disp.forward(request.getRequest(), response);
/* 435 */         this.context.fireRequestDestroyEvent(request.getRequest());
/*     */       }
/*     */     } catch (Throwable t) {
/* 438 */       ExceptionUtils.handleThrowable(t);
/* 439 */       String msg = sm.getString("formAuthenticator.forwardLoginFail");
/* 440 */       this.log.warn(msg, t);
/* 441 */       request.setAttribute("javax.servlet.error.exception", t);
/* 442 */       response.sendError(500, msg);
/*     */     }
/*     */     finally
/*     */     {
/* 446 */       request.getCoyoteRequest().method().setString(oldMethod);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void forwardToErrorPage(org.apache.catalina.connector.Request request, HttpServletResponse response, LoginConfig config)
/*     */     throws IOException
/*     */   {
/* 466 */     String errorPage = config.getErrorPage();
/* 467 */     if ((errorPage == null) || (errorPage.length() == 0)) {
/* 468 */       String msg = sm.getString("formAuthenticator.noErrorPage", new Object[] {this.context
/* 469 */         .getName() });
/* 470 */       this.log.warn(msg);
/* 471 */       response.sendError(500, msg);
/*     */       
/* 473 */       return;
/*     */     }
/*     */     
/*     */ 
/* 477 */     RequestDispatcher disp = this.context.getServletContext().getRequestDispatcher(config.getErrorPage());
/*     */     try {
/* 479 */       if (this.context.fireRequestInitEvent(request.getRequest())) {
/* 480 */         disp.forward(request.getRequest(), response);
/* 481 */         this.context.fireRequestDestroyEvent(request.getRequest());
/*     */       }
/*     */     } catch (Throwable t) {
/* 484 */       ExceptionUtils.handleThrowable(t);
/* 485 */       String msg = sm.getString("formAuthenticator.forwardErrorFail");
/* 486 */       this.log.warn(msg, t);
/* 487 */       request.setAttribute("javax.servlet.error.exception", t);
/* 488 */       response.sendError(500, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean matchRequest(org.apache.catalina.connector.Request request)
/*     */   {
/* 503 */     Session session = request.getSessionInternal(false);
/* 504 */     if (session == null) {
/* 505 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 509 */     SavedRequest sreq = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/* 510 */     if (sreq == null) {
/* 511 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 515 */     if (((this.cache) && (session.getPrincipal() == null)) || ((!this.cache) && (request.getPrincipal() == null))) {
/* 516 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 520 */     if (getChangeSessionIdOnAuthentication()) {
/* 521 */       String expectedSessionId = (String)session.getNote("org.apache.catalina.authenticator.SESSION_ID");
/* 522 */       if ((expectedSessionId == null) || (!expectedSessionId.equals(request.getRequestedSessionId()))) {
/* 523 */         return false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 528 */     String decodedRequestURI = request.getDecodedRequestURI();
/* 529 */     if (decodedRequestURI == null) {
/* 530 */       return false;
/*     */     }
/* 532 */     return decodedRequestURI.equals(sreq.getDecodedRequestURI());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean restoreRequest(org.apache.catalina.connector.Request request, Session session)
/*     */     throws IOException
/*     */   {
/* 551 */     SavedRequest saved = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/* 552 */     session.removeNote("org.apache.catalina.authenticator.REQUEST");
/* 553 */     session.removeNote("org.apache.catalina.authenticator.SESSION_ID");
/* 554 */     if (saved == null) {
/* 555 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 562 */     byte[] buffer = new byte['က'];
/* 563 */     InputStream is = request.createInputStream();
/* 564 */     while (is.read(buffer) >= 0) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 569 */     request.clearCookies();
/* 570 */     Iterator<Cookie> cookies = saved.getCookies();
/* 571 */     while (cookies.hasNext()) {
/* 572 */       request.addCookie((Cookie)cookies.next());
/*     */     }
/*     */     
/* 575 */     String method = saved.getMethod();
/* 576 */     MimeHeaders rmh = request.getCoyoteRequest().getMimeHeaders();
/* 577 */     rmh.recycle();
/*     */     
/* 579 */     boolean cacheable = ("GET".equalsIgnoreCase(method)) || ("HEAD".equalsIgnoreCase(method));
/* 580 */     Iterator<String> names = saved.getHeaderNames();
/* 581 */     while (names.hasNext()) {
/* 582 */       String name = (String)names.next();
/*     */       
/*     */ 
/*     */ 
/* 586 */       if ((!"If-Modified-Since".equalsIgnoreCase(name)) && ((!cacheable) || 
/* 587 */         (!"If-None-Match".equalsIgnoreCase(name)))) {
/* 588 */         Iterator<String> values = saved.getHeaderValues(name);
/* 589 */         while (values.hasNext()) {
/* 590 */           rmh.addValue(name).setString((String)values.next());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 595 */     request.clearLocales();
/* 596 */     Iterator<Locale> locales = saved.getLocales();
/* 597 */     while (locales.hasNext()) {
/* 598 */       request.addLocale((Locale)locales.next());
/*     */     }
/*     */     
/* 601 */     request.getCoyoteRequest().getParameters().recycle();
/*     */     
/* 603 */     ByteChunk body = saved.getBody();
/*     */     
/* 605 */     if (body != null)
/*     */     {
/* 607 */       request.getCoyoteRequest().action(ActionCode.REQ_SET_BODY_REPLAY, body);
/*     */       
/*     */ 
/* 610 */       MessageBytes contentType = MessageBytes.newInstance();
/*     */       
/*     */ 
/* 613 */       String savedContentType = saved.getContentType();
/* 614 */       if ((savedContentType == null) && ("POST".equalsIgnoreCase(method))) {
/* 615 */         savedContentType = "application/x-www-form-urlencoded";
/*     */       }
/*     */       
/* 618 */       contentType.setString(savedContentType);
/* 619 */       request.getCoyoteRequest().setContentType(contentType);
/*     */     }
/*     */     
/* 622 */     request.getCoyoteRequest().method().setString(method);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 632 */     request.getRequestURI();
/* 633 */     request.getQueryString();
/* 634 */     request.getProtocol();
/*     */     
/* 636 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void saveRequest(org.apache.catalina.connector.Request request, Session session)
/*     */     throws IOException
/*     */   {
/* 651 */     SavedRequest saved = new SavedRequest();
/* 652 */     Cookie[] cookies = request.getCookies();
/* 653 */     if (cookies != null) {
/* 654 */       for (Cookie cookie : cookies) {
/* 655 */         saved.addCookie(cookie);
/*     */       }
/*     */     }
/* 658 */     Object names = request.getHeaderNames();
/* 659 */     while (((Enumeration)names).hasMoreElements()) {
/* 660 */       String name = (String)((Enumeration)names).nextElement();
/* 661 */       Object values = request.getHeaders(name);
/* 662 */       while (((Enumeration)values).hasMoreElements()) {
/* 663 */         String value = (String)((Enumeration)values).nextElement();
/* 664 */         saved.addHeader(name, value);
/*     */       }
/*     */     }
/* 667 */     Object locales = request.getLocales();
/* 668 */     while (((Enumeration)locales).hasMoreElements()) {
/* 669 */       Locale locale = (Locale)((Enumeration)locales).nextElement();
/* 670 */       saved.addLocale(locale);
/*     */     }
/*     */     
/*     */ 
/* 674 */     request.getResponse().sendAcknowledgement(ContinueResponseTiming.ALWAYS);
/*     */     
/* 676 */     int maxSavePostSize = request.getConnector().getMaxSavePostSize();
/* 677 */     if (maxSavePostSize != 0) {
/* 678 */       ByteChunk body = new ByteChunk();
/* 679 */       body.setLimit(maxSavePostSize);
/*     */       
/* 681 */       byte[] buffer = new byte['က'];
/*     */       
/* 683 */       InputStream is = request.getInputStream();
/*     */       int bytesRead;
/* 685 */       while ((bytesRead = is.read(buffer)) >= 0) {
/* 686 */         body.append(buffer, 0, bytesRead);
/*     */       }
/*     */       
/*     */ 
/* 690 */       if (body.getLength() > 0) {
/* 691 */         saved.setContentType(request.getContentType());
/* 692 */         saved.setBody(body);
/*     */       }
/*     */     }
/*     */     
/* 696 */     saved.setMethod(request.getMethod());
/* 697 */     saved.setQueryString(request.getQueryString());
/* 698 */     saved.setRequestURI(request.getRequestURI());
/* 699 */     saved.setDecodedRequestURI(request.getDecodedRequestURI());
/*     */     
/*     */ 
/* 702 */     session.setNote("org.apache.catalina.authenticator.REQUEST", saved);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String savedRequestURL(Session session)
/*     */   {
/* 715 */     SavedRequest saved = (SavedRequest)session.getNote("org.apache.catalina.authenticator.REQUEST");
/* 716 */     if (saved == null) {
/* 717 */       return null;
/*     */     }
/* 719 */     StringBuilder sb = new StringBuilder(saved.getRequestURI());
/* 720 */     if (saved.getQueryString() != null) {
/* 721 */       sb.append('?');
/* 722 */       sb.append(saved.getQueryString());
/*     */     }
/* 724 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\authenticator\FormAuthenticator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */