/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Collection;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResponseFacade
/*     */   implements HttpServletResponse
/*     */ {
/*     */   private final class SetContentTypePrivilegedAction
/*     */     implements PrivilegedAction<Void>
/*     */   {
/*     */     private final String contentType;
/*     */     
/*     */     public SetContentTypePrivilegedAction(String contentType)
/*     */     {
/*  55 */       this.contentType = contentType;
/*     */     }
/*     */     
/*     */     public Void run()
/*     */     {
/*  60 */       ResponseFacade.this.response.setContentType(this.contentType);
/*  61 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private final class DateHeaderPrivilegedAction implements PrivilegedAction<Void>
/*     */   {
/*     */     private final String name;
/*     */     private final long value;
/*     */     private final boolean add;
/*     */     
/*     */     DateHeaderPrivilegedAction(String name, long value, boolean add)
/*     */     {
/*  73 */       this.name = name;
/*  74 */       this.value = value;
/*  75 */       this.add = add;
/*     */     }
/*     */     
/*     */     public Void run()
/*     */     {
/*  80 */       if (this.add) {
/*  81 */         ResponseFacade.this.response.addDateHeader(this.name, this.value);
/*     */       } else {
/*  83 */         ResponseFacade.this.response.setDateHeader(this.name, this.value);
/*     */       }
/*  85 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class FlushBufferPrivilegedAction implements PrivilegedExceptionAction<Void>
/*     */   {
/*     */     private final Response response;
/*     */     
/*     */     public FlushBufferPrivilegedAction(Response response) {
/*  94 */       this.response = response;
/*     */     }
/*     */     
/*     */     public Void run() throws IOException
/*     */     {
/*  99 */       this.response.setAppCommitted(true);
/* 100 */       this.response.flushBuffer();
/* 101 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResponseFacade(Response response)
/*     */   {
/* 115 */     this.response = response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */   protected static final StringManager sm = StringManager.getManager(ResponseFacade.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */   protected Response response = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 141 */     this.response = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/* 151 */     throw new CloneNotSupportedException();
/*     */   }
/*     */   
/*     */ 
/*     */   public void finish()
/*     */   {
/* 157 */     if (this.response == null)
/*     */     {
/* 159 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 162 */     this.response.setSuspended(true);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isFinished()
/*     */   {
/* 168 */     if (this.response == null)
/*     */     {
/* 170 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 173 */     return this.response.isSuspended();
/*     */   }
/*     */   
/*     */ 
/*     */   public long getContentWritten()
/*     */   {
/* 179 */     if (this.response == null)
/*     */     {
/* 181 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 184 */     return this.response.getContentWritten();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCharacterEncoding()
/*     */   {
/* 193 */     if (this.response == null)
/*     */     {
/* 195 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 198 */     return this.response.getCharacterEncoding();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletOutputStream getOutputStream()
/*     */     throws IOException
/*     */   {
/* 210 */     ServletOutputStream sos = this.response.getOutputStream();
/* 211 */     if (isFinished()) {
/* 212 */       this.response.setSuspended(true);
/*     */     }
/* 214 */     return sos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrintWriter getWriter()
/*     */     throws IOException
/*     */   {
/* 227 */     PrintWriter writer = this.response.getWriter();
/* 228 */     if (isFinished()) {
/* 229 */       this.response.setSuspended(true);
/*     */     }
/* 231 */     return writer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setContentLength(int len)
/*     */   {
/* 238 */     if (isCommitted()) {
/* 239 */       return;
/*     */     }
/* 241 */     this.response.setContentLength(len);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setContentLengthLong(long length)
/*     */   {
/* 247 */     if (isCommitted()) {
/* 248 */       return;
/*     */     }
/* 250 */     this.response.setContentLengthLong(length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setContentType(String type)
/*     */   {
/* 257 */     if (isCommitted()) {
/* 258 */       return;
/*     */     }
/*     */     
/* 261 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 262 */       AccessController.doPrivileged(new SetContentTypePrivilegedAction(type));
/*     */     } else {
/* 264 */       this.response.setContentType(type);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setBufferSize(int size)
/*     */   {
/* 272 */     if (isCommitted())
/*     */     {
/* 274 */       throw new IllegalStateException(sm.getString("coyoteResponse.setBufferSize.ise"));
/*     */     }
/*     */     
/* 277 */     this.response.setBufferSize(size);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBufferSize()
/*     */   {
/* 285 */     if (this.response == null)
/*     */     {
/* 287 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 290 */     return this.response.getBufferSize();
/*     */   }
/*     */   
/*     */ 
/*     */   public void flushBuffer()
/*     */     throws IOException
/*     */   {
/* 297 */     if (isFinished()) {
/* 298 */       return;
/*     */     }
/*     */     
/* 301 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 303 */         AccessController.doPrivileged(new FlushBufferPrivilegedAction(this.response));
/*     */       } catch (PrivilegedActionException e) {
/* 305 */         Exception ex = e.getException();
/* 306 */         if ((ex instanceof IOException)) {
/* 307 */           throw ((IOException)ex);
/*     */         }
/*     */       }
/*     */     } else {
/* 311 */       this.response.setAppCommitted(true);
/* 312 */       this.response.flushBuffer();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void resetBuffer()
/*     */   {
/* 320 */     if (isCommitted())
/*     */     {
/* 322 */       throw new IllegalStateException(sm.getString("coyoteResponse.resetBuffer.ise"));
/*     */     }
/*     */     
/* 325 */     this.response.resetBuffer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCommitted()
/*     */   {
/* 333 */     if (this.response == null)
/*     */     {
/* 335 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 338 */     return this.response.isAppCommitted();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 345 */     if (isCommitted())
/*     */     {
/* 347 */       throw new IllegalStateException(sm.getString("coyoteResponse.reset.ise"));
/*     */     }
/*     */     
/* 350 */     this.response.reset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocale(Locale loc)
/*     */   {
/* 358 */     if (isCommitted()) {
/* 359 */       return;
/*     */     }
/*     */     
/* 362 */     this.response.setLocale(loc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Locale getLocale()
/*     */   {
/* 369 */     if (this.response == null)
/*     */     {
/* 371 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 374 */     return this.response.getLocale();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addCookie(Cookie cookie)
/*     */   {
/* 381 */     if (isCommitted()) {
/* 382 */       return;
/*     */     }
/*     */     
/* 385 */     this.response.addCookie(cookie);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsHeader(String name)
/*     */   {
/* 393 */     if (this.response == null)
/*     */     {
/* 395 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 398 */     return this.response.containsHeader(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String encodeURL(String url)
/*     */   {
/* 405 */     if (this.response == null)
/*     */     {
/* 407 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 410 */     return this.response.encodeURL(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String encodeRedirectURL(String url)
/*     */   {
/* 417 */     if (this.response == null)
/*     */     {
/* 419 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 422 */     return this.response.encodeRedirectURL(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String encodeUrl(String url)
/*     */   {
/* 429 */     if (this.response == null)
/*     */     {
/* 431 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 434 */     return this.response.encodeURL(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String encodeRedirectUrl(String url)
/*     */   {
/* 441 */     if (this.response == null)
/*     */     {
/* 443 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 446 */     return this.response.encodeRedirectURL(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void sendError(int sc, String msg)
/*     */     throws IOException
/*     */   {
/* 454 */     if (isCommitted())
/*     */     {
/* 456 */       throw new IllegalStateException(sm.getString("coyoteResponse.sendError.ise"));
/*     */     }
/*     */     
/* 459 */     this.response.setAppCommitted(true);
/*     */     
/* 461 */     this.response.sendError(sc, msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sendError(int sc)
/*     */     throws IOException
/*     */   {
/* 470 */     if (isCommitted())
/*     */     {
/* 472 */       throw new IllegalStateException(sm.getString("coyoteResponse.sendError.ise"));
/*     */     }
/*     */     
/* 475 */     this.response.setAppCommitted(true);
/*     */     
/* 477 */     this.response.sendError(sc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sendRedirect(String location)
/*     */     throws IOException
/*     */   {
/* 486 */     if (isCommitted())
/*     */     {
/* 488 */       throw new IllegalStateException(sm.getString("coyoteResponse.sendRedirect.ise"));
/*     */     }
/*     */     
/* 491 */     this.response.setAppCommitted(true);
/*     */     
/* 493 */     this.response.sendRedirect(location);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateHeader(String name, long date)
/*     */   {
/* 501 */     if (isCommitted()) {
/* 502 */       return;
/*     */     }
/*     */     
/* 505 */     if (Globals.IS_SECURITY_ENABLED) {
/* 506 */       AccessController.doPrivileged(new DateHeaderPrivilegedAction(name, date, false));
/*     */     }
/*     */     else {
/* 509 */       this.response.setDateHeader(name, date);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addDateHeader(String name, long date)
/*     */   {
/* 518 */     if (isCommitted()) {
/* 519 */       return;
/*     */     }
/*     */     
/* 522 */     if (Globals.IS_SECURITY_ENABLED) {
/* 523 */       AccessController.doPrivileged(new DateHeaderPrivilegedAction(name, date, true));
/*     */     }
/*     */     else {
/* 526 */       this.response.addDateHeader(name, date);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeader(String name, String value)
/*     */   {
/* 535 */     if (isCommitted()) {
/* 536 */       return;
/*     */     }
/*     */     
/* 539 */     this.response.setHeader(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addHeader(String name, String value)
/*     */   {
/* 547 */     if (isCommitted()) {
/* 548 */       return;
/*     */     }
/*     */     
/* 551 */     this.response.addHeader(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIntHeader(String name, int value)
/*     */   {
/* 559 */     if (isCommitted()) {
/* 560 */       return;
/*     */     }
/*     */     
/* 563 */     this.response.setIntHeader(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIntHeader(String name, int value)
/*     */   {
/* 571 */     if (isCommitted()) {
/* 572 */       return;
/*     */     }
/*     */     
/* 575 */     this.response.addIntHeader(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatus(int sc)
/*     */   {
/* 583 */     if (isCommitted()) {
/* 584 */       return;
/*     */     }
/*     */     
/* 587 */     this.response.setStatus(sc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatus(int sc, String sm)
/*     */   {
/* 595 */     if (isCommitted()) {
/* 596 */       return;
/*     */     }
/*     */     
/* 599 */     this.response.setStatus(sc, sm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 606 */     if (this.response == null)
/*     */     {
/* 608 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 611 */     return this.response.getContentType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCharacterEncoding(String arg0)
/*     */   {
/* 618 */     if (this.response == null)
/*     */     {
/* 620 */       throw new IllegalStateException(sm.getString("responseFacade.nullResponse"));
/*     */     }
/*     */     
/* 623 */     this.response.setCharacterEncoding(arg0);
/*     */   }
/*     */   
/*     */   public int getStatus()
/*     */   {
/* 628 */     return this.response.getStatus();
/*     */   }
/*     */   
/*     */   public String getHeader(String name)
/*     */   {
/* 633 */     return this.response.getHeader(name);
/*     */   }
/*     */   
/*     */   public Collection<String> getHeaderNames()
/*     */   {
/* 638 */     return this.response.getHeaderNames();
/*     */   }
/*     */   
/*     */   public Collection<String> getHeaders(String name)
/*     */   {
/* 643 */     return this.response.getHeaders(name);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setTrailerFields(Supplier<Map<String, String>> supplier)
/*     */   {
/* 649 */     this.response.setTrailerFields(supplier);
/*     */   }
/*     */   
/*     */ 
/*     */   public Supplier<Map<String, String>> getTrailerFields()
/*     */   {
/* 655 */     return this.response.getTrailerFields();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\connector\ResponseFacade.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */