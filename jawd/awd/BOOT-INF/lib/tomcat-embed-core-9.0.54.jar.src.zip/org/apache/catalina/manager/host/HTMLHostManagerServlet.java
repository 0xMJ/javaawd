/*     */ package org.apache.catalina.manager.host;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.net.URLEncoder;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.manager.Constants;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.security.Escape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HTMLHostManagerServlet
/*     */   extends HostManagerServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String HOSTS_HEADER_SECTION = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"5\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"header-left\"><small>{0}</small></td>\n <td class=\"header-center\"><small>{1}</small></td>\n <td class=\"header-center\"><small>{2}</small></td>\n</tr>\n";
/*     */   private static final String HOSTS_ROW_DETAILS_SECTION = "<tr>\n <td class=\"row-left\"><small><a href=\"http://{0}\" rel=\"noopener noreferrer\">{0}</a></small></td>\n <td class=\"row-center\"><small>{1}</small></td>\n";
/*     */   private static final String MANAGER_HOST_ROW_BUTTON_SECTION = " <td class=\"row-left\">\n  <small>{4}</small>\n </td>\n</tr>\n";
/*     */   private static final String HOSTS_ROW_BUTTON_SECTION = " <td class=\"row-left\" NOWRAP>\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">   <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">   <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n </td>\n</tr>\n";
/*     */   private static final String ADD_SECTION_START = "</table>\n<br>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"name\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{4}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"aliases\" size=\"64\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{5}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"appBase\" size=\"64\">\n </td>\n</tr>\n";
/*     */   private static final String ADD_SECTION_BOOLEAN = "<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n";
/*     */   private static final String ADD_SECTION_END = "<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{0}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>\n\n";
/*     */   private static final String PERSIST_SECTION = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form class=\"inline\" method=\"POST\" action=\"{1}\">   <small><input type=\"submit\" value=\"{2}\"></small>  </form> {3}\n </td>\n</tr>\n</table>\n<br>\n\n";
/*     */   
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/*  79 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager.host", request
/*  80 */       .getLocales());
/*     */     
/*     */ 
/*  83 */     String command = request.getPathInfo();
/*     */     
/*     */ 
/*  86 */     response.setContentType("text/html; charset=utf-8");
/*     */     
/*  88 */     String message = "";
/*     */     
/*  90 */     if (command != null)
/*     */     {
/*  92 */       if (!command.equals("/list"))
/*     */       {
/*  94 */         if ((command.equals("/add")) || (command.equals("/remove")) || 
/*  95 */           (command.equals("/start")) || (command.equals("/stop")) || 
/*  96 */           (command.equals("/persist"))) {
/*  97 */           message = smClient.getString("hostManagerServlet.postCommand", new Object[] { command });
/*     */         }
/*     */         else {
/* 100 */           message = smClient.getString("hostManagerServlet.unknownCommand", new Object[] { command });
/*     */         }
/*     */       }
/*     */     }
/* 104 */     list(request, response, message, smClient);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doPost(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 121 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager.host", request
/* 122 */       .getLocales());
/*     */     
/*     */ 
/* 125 */     String command = request.getPathInfo();
/*     */     
/* 127 */     String name = request.getParameter("name");
/*     */     
/*     */ 
/* 130 */     response.setContentType("text/html; charset=utf-8");
/*     */     
/* 132 */     String message = "";
/*     */     
/*     */ 
/* 135 */     if (command != null)
/*     */     {
/* 137 */       if (command.equals("/add")) {
/* 138 */         message = add(request, name, smClient);
/* 139 */       } else if (command.equals("/remove")) {
/* 140 */         message = remove(name, smClient);
/* 141 */       } else if (command.equals("/start")) {
/* 142 */         message = start(name, smClient);
/* 143 */       } else if (command.equals("/stop")) {
/* 144 */         message = stop(name, smClient);
/* 145 */       } else if (command.equals("/persist")) {
/* 146 */         message = persist(smClient);
/*     */       }
/*     */       else {
/* 149 */         doGet(request, response);
/*     */       }
/*     */     }
/* 152 */     list(request, response, message, smClient);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String add(HttpServletRequest request, String name, StringManager smClient)
/*     */   {
/* 167 */     StringWriter stringWriter = new StringWriter();
/* 168 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 170 */     super.add(request, printWriter, name, true, smClient);
/*     */     
/* 172 */     return stringWriter.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String remove(String name, StringManager smClient)
/*     */   {
/* 185 */     StringWriter stringWriter = new StringWriter();
/* 186 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 188 */     super.remove(printWriter, name, smClient);
/*     */     
/* 190 */     return stringWriter.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String start(String name, StringManager smClient)
/*     */   {
/* 203 */     StringWriter stringWriter = new StringWriter();
/* 204 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 206 */     super.start(printWriter, name, smClient);
/*     */     
/* 208 */     return stringWriter.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String stop(String name, StringManager smClient)
/*     */   {
/* 221 */     StringWriter stringWriter = new StringWriter();
/* 222 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 224 */     super.stop(printWriter, name, smClient);
/*     */     
/* 226 */     return stringWriter.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String persist(StringManager smClient)
/*     */   {
/* 238 */     StringWriter stringWriter = new StringWriter();
/* 239 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */     
/* 241 */     super.persist(printWriter, smClient);
/*     */     
/* 243 */     return stringWriter.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void list(HttpServletRequest request, HttpServletResponse response, String message, StringManager smClient)
/*     */     throws IOException
/*     */   {
/* 262 */     if (this.debug >= 1) {
/* 263 */       log(sm.getString("hostManagerServlet.list", new Object[] { this.engine.getName() }));
/*     */     }
/*     */     
/* 266 */     PrintWriter writer = response.getWriter();
/*     */     
/* 268 */     Object[] args = new Object[2];
/* 269 */     args[0] = request.getContextPath();
/* 270 */     args[1] = smClient.getString("htmlHostManagerServlet.title");
/*     */     
/*     */ 
/* 273 */     writer.print(MessageFormat.format(Constants.HTML_HEADER_SECTION, args));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 278 */     writer.print(MessageFormat.format(Constants.BODY_HEADER_SECTION, args));
/*     */     
/*     */ 
/*     */ 
/* 282 */     args = new Object[3];
/* 283 */     args[0] = smClient.getString("htmlHostManagerServlet.messageLabel");
/* 284 */     if ((message == null) || (message.length() == 0)) {
/* 285 */       args[1] = "OK";
/*     */     } else {
/* 287 */       args[1] = Escape.htmlElementContent(message);
/*     */     }
/* 289 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n <tr>\n  <td class=\"row-left\" width=\"10%\"><small><strong>{0}</strong></small>&nbsp;</td>\n  <td class=\"row-left\"><pre>{1}</pre></td>\n </tr>\n</table>\n<br>\n\n", args));
/*     */     
/*     */ 
/* 292 */     args = new Object[9];
/* 293 */     args[0] = smClient.getString("htmlHostManagerServlet.manager");
/* 294 */     args[1] = response.encodeURL(request.getContextPath() + "/html/list");
/* 295 */     args[2] = smClient.getString("htmlHostManagerServlet.list");
/* 296 */     args[3] = 
/*     */     
/* 298 */       (request.getContextPath() + "/" + smClient.getString("htmlHostManagerServlet.helpHtmlManagerFile"));
/* 299 */     args[4] = smClient.getString("htmlHostManagerServlet.helpHtmlManager");
/* 300 */     args[5] = 
/*     */     
/* 302 */       (request.getContextPath() + "/" + smClient.getString("htmlHostManagerServlet.helpManagerFile"));
/* 303 */     args[6] = smClient.getString("htmlHostManagerServlet.helpManager");
/* 304 */     args[7] = response.encodeURL("/manager/status");
/* 305 */     args[8] = smClient.getString("statusServlet.title");
/* 306 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"4\" class=\"title\">{0}</td>\n</tr>\n <tr>\n  <td class=\"row-left\"><a href=\"{1}\">{2}</a></td>\n  <td class=\"row-center\"><a href=\"{3}\" rel=\"noopener noreferrer\">{4}</a></td>\n  <td class=\"row-center\"><a href=\"{5}\" rel=\"noopener noreferrer\">{6}</a></td>\n  <td class=\"row-right\"><a href=\"{7}\">{8}</a></td>\n </tr>\n</table>\n<br>\n\n", args));
/*     */     
/*     */ 
/* 309 */     args = new Object[3];
/* 310 */     args[0] = smClient.getString("htmlHostManagerServlet.hostName");
/* 311 */     args[1] = smClient.getString("htmlHostManagerServlet.hostAliases");
/* 312 */     args[2] = smClient.getString("htmlHostManagerServlet.hostTasks");
/* 313 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"5\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"header-left\"><small>{0}</small></td>\n <td class=\"header-center\"><small>{1}</small></td>\n <td class=\"header-center\"><small>{2}</small></td>\n</tr>\n", args));
/*     */     
/*     */ 
/*     */ 
/* 317 */     Container[] children = this.engine.findChildren();
/* 318 */     String[] hostNames = new String[children.length];
/* 319 */     for (int i = 0; i < children.length; i++) {
/* 320 */       hostNames[i] = children[i].getName();
/*     */     }
/*     */     
/* 323 */     SortedSet<String> sortedHostNames = new TreeSet();
/* 324 */     sortedHostNames.addAll(Arrays.asList(hostNames));
/*     */     
/* 326 */     String hostsStart = smClient.getString("htmlHostManagerServlet.hostsStart");
/* 327 */     String hostsStop = smClient.getString("htmlHostManagerServlet.hostsStop");
/* 328 */     String hostsRemove = smClient.getString("htmlHostManagerServlet.hostsRemove");
/* 329 */     String hostThis = smClient.getString("htmlHostManagerServlet.hostThis");
/*     */     
/* 331 */     for (String hostName : sortedHostNames) {
/* 332 */       Host host = (Host)this.engine.findChild(hostName);
/*     */       
/* 334 */       if (host != null) {
/* 335 */         args = new Object[2];
/* 336 */         args[0] = 
/* 337 */           Escape.htmlElementContent(hostName);
/* 338 */         String[] aliases = host.findAliases();
/* 339 */         StringBuilder buf = new StringBuilder();
/* 340 */         if (aliases.length > 0) {
/* 341 */           buf.append(aliases[0]);
/* 342 */           for (int j = 1; j < aliases.length; j++) {
/* 343 */             buf.append(", ").append(aliases[j]);
/*     */           }
/*     */         }
/*     */         
/* 347 */         if (buf.length() == 0) {
/* 348 */           buf.append("&nbsp;");
/* 349 */           args[1] = buf.toString();
/*     */         } else {
/* 351 */           args[1] = Escape.htmlElementContent(buf.toString());
/*     */         }
/*     */         
/*     */ 
/* 355 */         writer.print(MessageFormat.format("<tr>\n <td class=\"row-left\"><small><a href=\"http://{0}\" rel=\"noopener noreferrer\">{0}</a></small></td>\n <td class=\"row-center\"><small>{1}</small></td>\n", args));
/*     */         
/* 357 */         args = new Object[5];
/* 358 */         if (host.getState().isAvailable())
/*     */         {
/* 360 */           args[0] = response.encodeURL(request.getContextPath() + "/html/stop?name=" + 
/*     */           
/* 362 */             URLEncoder.encode(hostName, "UTF-8"));
/* 363 */           args[1] = hostsStop;
/*     */         }
/*     */         else {
/* 366 */           args[0] = response.encodeURL(request.getContextPath() + "/html/start?name=" + 
/*     */           
/* 368 */             URLEncoder.encode(hostName, "UTF-8"));
/* 369 */           args[1] = hostsStart;
/*     */         }
/*     */         
/* 372 */         args[2] = response.encodeURL(request.getContextPath() + "/html/remove?name=" + 
/*     */         
/* 374 */           URLEncoder.encode(hostName, "UTF-8"));
/* 375 */         args[3] = hostsRemove;
/* 376 */         args[4] = hostThis;
/* 377 */         if (host == this.installedHost) {
/* 378 */           writer.print(MessageFormat.format(" <td class=\"row-left\">\n  <small>{4}</small>\n </td>\n</tr>\n", args));
/*     */         }
/*     */         else {
/* 381 */           writer.print(MessageFormat.format(" <td class=\"row-left\" NOWRAP>\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">   <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">   <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n </td>\n</tr>\n", args));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 388 */     args = new Object[6];
/* 389 */     args[0] = smClient.getString("htmlHostManagerServlet.addTitle");
/* 390 */     args[1] = smClient.getString("htmlHostManagerServlet.addHost");
/* 391 */     args[2] = response.encodeURL(request.getContextPath() + "/html/add");
/* 392 */     args[3] = smClient.getString("htmlHostManagerServlet.addName");
/* 393 */     args[4] = smClient.getString("htmlHostManagerServlet.addAliases");
/* 394 */     args[5] = smClient.getString("htmlHostManagerServlet.addAppBase");
/* 395 */     writer.print(MessageFormat.format("</table>\n<br>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"name\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{4}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"aliases\" size=\"64\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{5}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"appBase\" size=\"64\">\n </td>\n</tr>\n", args));
/*     */     
/* 397 */     args = new Object[3];
/* 398 */     args[0] = smClient.getString("htmlHostManagerServlet.addAutoDeploy");
/* 399 */     args[1] = "autoDeploy";
/* 400 */     args[2] = "checked";
/* 401 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n", args));
/* 402 */     args[0] = smClient.getString("htmlHostManagerServlet.addDeployOnStartup");
/*     */     
/* 404 */     args[1] = "deployOnStartup";
/* 405 */     args[2] = "checked";
/* 406 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n", args));
/* 407 */     args[0] = smClient.getString("htmlHostManagerServlet.addDeployXML");
/* 408 */     args[1] = "deployXML";
/* 409 */     args[2] = "checked";
/* 410 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n", args));
/* 411 */     args[0] = smClient.getString("htmlHostManagerServlet.addUnpackWARs");
/* 412 */     args[1] = "unpackWARs";
/* 413 */     args[2] = "checked";
/* 414 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n", args));
/*     */     
/* 416 */     args[0] = smClient.getString("htmlHostManagerServlet.addManager");
/* 417 */     args[1] = "manager";
/* 418 */     args[2] = "checked";
/* 419 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n", args));
/*     */     
/* 421 */     args[0] = smClient.getString("htmlHostManagerServlet.addCopyXML");
/* 422 */     args[1] = "copyXML";
/* 423 */     args[2] = "";
/* 424 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  <small>{0}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"checkbox\" name=\"{1}\" {2}>\n </td>\n</tr>\n", args));
/*     */     
/* 426 */     args = new Object[1];
/* 427 */     args[0] = smClient.getString("htmlHostManagerServlet.addButton");
/* 428 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{0}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>\n\n", args));
/*     */     
/*     */ 
/* 431 */     args = new Object[4];
/* 432 */     args[0] = smClient.getString("htmlHostManagerServlet.persistTitle");
/* 433 */     args[1] = response.encodeURL(request.getContextPath() + "/html/persist");
/* 434 */     args[2] = smClient.getString("htmlHostManagerServlet.persistAllButton");
/* 435 */     args[3] = smClient.getString("htmlHostManagerServlet.persistAll");
/* 436 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form class=\"inline\" method=\"POST\" action=\"{1}\">   <small><input type=\"submit\" value=\"{2}\"></small>  </form> {3}\n </td>\n</tr>\n</table>\n<br>\n\n", args));
/*     */     
/*     */ 
/* 439 */     args = new Object[7];
/* 440 */     args[0] = smClient.getString("htmlHostManagerServlet.serverTitle");
/* 441 */     args[1] = smClient.getString("htmlHostManagerServlet.serverVersion");
/* 442 */     args[2] = smClient.getString("htmlHostManagerServlet.serverJVMVersion");
/* 443 */     args[3] = smClient.getString("htmlHostManagerServlet.serverJVMVendor");
/* 444 */     args[4] = smClient.getString("htmlHostManagerServlet.serverOSName");
/* 445 */     args[5] = smClient.getString("htmlHostManagerServlet.serverOSVersion");
/* 446 */     args[6] = smClient.getString("htmlHostManagerServlet.serverOSArch");
/* 447 */     writer.print(
/* 448 */       MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"6\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"header-center\"><small>{1}</small></td>\n <td class=\"header-center\"><small>{2}</small></td>\n <td class=\"header-center\"><small>{3}</small></td>\n <td class=\"header-center\"><small>{4}</small></td>\n <td class=\"header-center\"><small>{5}</small></td>\n <td class=\"header-center\"><small>{6}</small></td>\n</tr>\n", args));
/*     */     
/*     */ 
/* 451 */     args = new Object[6];
/* 452 */     args[0] = ServerInfo.getServerInfo();
/* 453 */     args[1] = System.getProperty("java.runtime.version");
/* 454 */     args[2] = System.getProperty("java.vm.vendor");
/* 455 */     args[3] = System.getProperty("os.name");
/* 456 */     args[4] = System.getProperty("os.version");
/* 457 */     args[5] = System.getProperty("os.arch");
/* 458 */     writer.print(MessageFormat.format("<tr>\n <td class=\"row-center\"><small>{0}</small></td>\n <td class=\"row-center\"><small>{1}</small></td>\n <td class=\"row-center\"><small>{2}</small></td>\n <td class=\"row-center\"><small>{3}</small></td>\n <td class=\"row-center\"><small>{4}</small></td>\n <td class=\"row-center\"><small>{5}</small></td>\n</tr>\n</table>\n<br>\n\n", args));
/*     */     
/*     */ 
/* 461 */     writer.print("<hr size=\"1\" noshade=\"noshade\">\n<center><font size=\"-1\" color=\"#525D76\">\n <em>Copyright &copy; 1999-2021, Apache Software Foundation</em></font></center>\n\n</body>\n</html>");
/*     */     
/*     */ 
/* 464 */     writer.flush();
/* 465 */     writer.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\manager\host\HTMLHostManagerServlet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */