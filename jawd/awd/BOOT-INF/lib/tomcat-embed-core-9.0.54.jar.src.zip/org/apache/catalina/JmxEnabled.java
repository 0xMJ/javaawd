package org.apache.catalina;

import javax.management.MBeanRegistration;
import javax.management.ObjectName;

public abstract interface JmxEnabled
  extends MBeanRegistration
{
  public abstract String getDomain();
  
  public abstract void setDomain(String paramString);
  
  public abstract ObjectName getObjectName();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\JmxEnabled.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */