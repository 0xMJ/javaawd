/*    */ package org.apache.catalina.util;
/*    */ 
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.Locale;
/*    */ import java.util.Queue;
/*    */ import java.util.TimeZone;
/*    */ import java.util.concurrent.ConcurrentLinkedQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ConcurrentDateFormat
/*    */ {
/*    */   private final String format;
/*    */   private final Locale locale;
/*    */   private final TimeZone timezone;
/* 40 */   private final Queue<SimpleDateFormat> queue = new ConcurrentLinkedQueue();
/*    */   
/*    */   public static final String RFC1123_DATE = "EEE, dd MMM yyyy HH:mm:ss zzz";
/* 43 */   public static final TimeZone GMT = TimeZone.getTimeZone("GMT");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 48 */   private static final ConcurrentDateFormat FORMAT_RFC1123 = new ConcurrentDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US, GMT);
/*    */   
/*    */   public static String formatRfc1123(Date date)
/*    */   {
/* 52 */     return FORMAT_RFC1123.format(date);
/*    */   }
/*    */   
/*    */   public ConcurrentDateFormat(String format, Locale locale, TimeZone timezone)
/*    */   {
/* 57 */     this.format = format;
/* 58 */     this.locale = locale;
/* 59 */     this.timezone = timezone;
/* 60 */     SimpleDateFormat initial = createInstance();
/* 61 */     this.queue.add(initial);
/*    */   }
/*    */   
/*    */   public String format(Date date) {
/* 65 */     SimpleDateFormat sdf = (SimpleDateFormat)this.queue.poll();
/* 66 */     if (sdf == null) {
/* 67 */       sdf = createInstance();
/*    */     }
/* 69 */     String result = sdf.format(date);
/* 70 */     this.queue.add(sdf);
/* 71 */     return result;
/*    */   }
/*    */   
/*    */   private SimpleDateFormat createInstance() {
/* 75 */     SimpleDateFormat sdf = new SimpleDateFormat(this.format, this.locale);
/* 76 */     sdf.setTimeZone(this.timezone);
/* 77 */     return sdf;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\ConcurrentDateFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */