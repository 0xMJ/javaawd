/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import javax.naming.Binding;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingEnumeration;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.OperationNotSupportedException;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlobalResourcesLifecycleListener
/*     */   implements LifecycleListener
/*     */ {
/*  51 */   private static final Log log = LogFactory.getLog(GlobalResourcesLifecycleListener.class);
/*  52 */   protected static final StringManager sm = StringManager.getManager(GlobalResourcesLifecycleListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */   protected Lifecycle component = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void lifecycleEvent(LifecycleEvent event)
/*     */   {
/*  73 */     if ("start".equals(event.getType())) {
/*  74 */       this.component = event.getLifecycle();
/*  75 */       createMBeans();
/*  76 */     } else if ("stop".equals(event.getType())) {
/*  77 */       destroyMBeans();
/*  78 */       this.component = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void createMBeans()
/*     */   {
/*  90 */     Context context = null;
/*     */     try {
/*  92 */       context = (Context)new InitialContext().lookup("java:/");
/*     */     } catch (NamingException e) {
/*  94 */       log.error(sm.getString("globalResources.noNamingContext"));
/*  95 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 100 */       createMBeans("", context);
/*     */     } catch (NamingException e) {
/* 102 */       log.error(sm.getString("globalResources.createError"), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void createMBeans(String prefix, Context context)
/*     */     throws NamingException
/*     */   {
/* 118 */     if (log.isDebugEnabled()) {
/* 119 */       log.debug("Creating MBeans for Global JNDI Resources in Context '" + prefix + "'");
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 124 */       NamingEnumeration<Binding> bindings = context.listBindings("");
/* 125 */       while (bindings.hasMore()) {
/* 126 */         Binding binding = (Binding)bindings.next();
/* 127 */         String name = prefix + binding.getName();
/* 128 */         Object value = context.lookup(binding.getName());
/* 129 */         if (log.isDebugEnabled()) {
/* 130 */           log.debug("Checking resource " + name);
/*     */         }
/* 132 */         if ((value instanceof Context)) {
/* 133 */           createMBeans(name + "/", (Context)value);
/* 134 */         } else if ((value instanceof UserDatabase)) {
/*     */           try {
/* 136 */             createMBeans(name, (UserDatabase)value);
/*     */           } catch (Exception e) {
/* 138 */             log.error(sm.getString("globalResources.userDatabaseCreateError", new Object[] { name }), e);
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (RuntimeException ex) {
/* 143 */       log.error(sm.getString("globalResources.createError.runtime"), ex);
/*     */     } catch (OperationNotSupportedException ex) {
/* 145 */       log.error(sm.getString("globalResources.createError.operation"), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void createMBeans(String name, UserDatabase database)
/*     */     throws Exception
/*     */   {
/* 161 */     if (log.isDebugEnabled()) {
/* 162 */       log.debug("Creating UserDatabase MBeans for resource " + name);
/* 163 */       log.debug("Database=" + database);
/*     */     }
/*     */     try {
/* 166 */       MBeanUtils.createMBean(database);
/*     */     } catch (Exception e) {
/* 168 */       throw new IllegalArgumentException(sm.getString("globalResources.createError.userDatabase", new Object[] { name }), e);
/*     */     }
/*     */     
/* 171 */     if (database.isSparse())
/*     */     {
/* 173 */       return;
/*     */     }
/*     */     
/*     */ 
/* 177 */     Iterator<Role> roles = database.getRoles();
/* 178 */     while (roles.hasNext()) {
/* 179 */       Role role = (Role)roles.next();
/* 180 */       if (log.isDebugEnabled()) {
/* 181 */         log.debug("  Creating Role MBean for role " + role);
/*     */       }
/*     */       try {
/* 184 */         MBeanUtils.createMBean(role);
/*     */       } catch (Exception e) {
/* 186 */         throw new IllegalArgumentException(sm.getString("globalResources.createError.userDatabase.role", new Object[] { role }), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 191 */     Iterator<Group> groups = database.getGroups();
/* 192 */     while (groups.hasNext()) {
/* 193 */       Group group = (Group)groups.next();
/* 194 */       if (log.isDebugEnabled()) {
/* 195 */         log.debug("  Creating Group MBean for group " + group);
/*     */       }
/*     */       try {
/* 198 */         MBeanUtils.createMBean(group);
/*     */       } catch (Exception e) {
/* 200 */         throw new IllegalArgumentException(sm.getString("globalResources.createError.userDatabase.group", new Object[] { group }), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 205 */     Iterator<User> users = database.getUsers();
/* 206 */     while (users.hasNext()) {
/* 207 */       User user = (User)users.next();
/* 208 */       if (log.isDebugEnabled()) {
/* 209 */         log.debug("  Creating User MBean for user " + user);
/*     */       }
/*     */       try {
/* 212 */         MBeanUtils.createMBean(user);
/*     */       } catch (Exception e) {
/* 214 */         throw new IllegalArgumentException(sm.getString("globalResources.createError.userDatabase.user", new Object[] { user }), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void destroyMBeans()
/*     */   {
/* 224 */     if (log.isDebugEnabled()) {
/* 225 */       log.debug("Destroying MBeans for Global JNDI Resources");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\GlobalResourcesLifecycleListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */