/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ReadListener;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.Constants;
/*     */ import org.apache.coyote.ContainerThreadMarker;
/*     */ import org.apache.coyote.Request;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.buf.ByteChunk.ByteInputChannel;
/*     */ import org.apache.tomcat.util.collections.SynchronizedStack;
/*     */ import org.apache.tomcat.util.net.ApplicationBufferHandler;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputBuffer
/*     */   extends Reader
/*     */   implements ByteChunk.ByteInputChannel, ApplicationBufferHandler
/*     */ {
/*  59 */   protected static final StringManager sm = StringManager.getManager(InputBuffer.class);
/*     */   
/*  61 */   private static final Log log = LogFactory.getLog(InputBuffer.class);
/*     */   
/*     */ 
/*     */   public static final int DEFAULT_BUFFER_SIZE = 8192;
/*     */   
/*     */ 
/*  67 */   public final int INITIAL_STATE = 0;
/*  68 */   public final int CHAR_STATE = 1;
/*  69 */   public final int BYTE_STATE = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */   private static final Map<Charset, SynchronizedStack<B2CConverter>> encoders = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ByteBuffer bb;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CharBuffer cb;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */   private int state = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */   private boolean closed = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected B2CConverter conv;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Request coyoteRequest;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */   private int markPos = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int readLimit;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int size;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputBuffer()
/*     */   {
/* 141 */     this(8192);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputBuffer(int size)
/*     */   {
/* 153 */     this.size = size;
/* 154 */     this.bb = ByteBuffer.allocate(size);
/* 155 */     clear(this.bb);
/* 156 */     this.cb = CharBuffer.allocate(size);
/* 157 */     clear(this.cb);
/* 158 */     this.readLimit = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequest(Request coyoteRequest)
/*     */   {
/* 172 */     this.coyoteRequest = coyoteRequest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void recycle()
/*     */   {
/* 183 */     this.state = 0;
/*     */     
/*     */ 
/* 186 */     if (this.cb.capacity() > this.size) {
/* 187 */       this.cb = CharBuffer.allocate(this.size);
/* 188 */       clear(this.cb);
/*     */     } else {
/* 190 */       clear(this.cb);
/*     */     }
/* 192 */     this.readLimit = this.size;
/* 193 */     this.markPos = -1;
/* 194 */     clear(this.bb);
/* 195 */     this.closed = false;
/*     */     
/* 197 */     if (this.conv != null) {
/* 198 */       this.conv.recycle();
/* 199 */       ((SynchronizedStack)encoders.get(this.conv.getCharset())).push(this.conv);
/* 200 */       this.conv = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 212 */     this.closed = true;
/*     */   }
/*     */   
/*     */   public int available()
/*     */   {
/* 217 */     int available = availableInThisBuffer();
/* 218 */     if (available == 0) {
/* 219 */       this.coyoteRequest.action(ActionCode.AVAILABLE, 
/* 220 */         Boolean.valueOf(this.coyoteRequest.getReadListener() != null));
/* 221 */       available = this.coyoteRequest.getAvailable() > 0 ? 1 : 0;
/*     */     }
/* 223 */     return available;
/*     */   }
/*     */   
/*     */   private int availableInThisBuffer()
/*     */   {
/* 228 */     int available = 0;
/* 229 */     if (this.state == 2) {
/* 230 */       available = this.bb.remaining();
/* 231 */     } else if (this.state == 1) {
/* 232 */       available = this.cb.remaining();
/*     */     }
/* 234 */     return available;
/*     */   }
/*     */   
/*     */   public void setReadListener(ReadListener listener)
/*     */   {
/* 239 */     this.coyoteRequest.setReadListener(listener);
/*     */   }
/*     */   
/*     */   public boolean isFinished()
/*     */   {
/* 244 */     int available = 0;
/* 245 */     if (this.state == 2) {
/* 246 */       available = this.bb.remaining();
/* 247 */     } else if (this.state == 1) {
/* 248 */       available = this.cb.remaining();
/*     */     }
/* 250 */     if (available > 0) {
/* 251 */       return false;
/*     */     }
/* 253 */     return this.coyoteRequest.isFinished();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isReady()
/*     */   {
/* 259 */     if (this.coyoteRequest.getReadListener() == null) {
/* 260 */       if (log.isDebugEnabled()) {
/* 261 */         log.debug(sm.getString("inputBuffer.requiresNonBlocking"));
/*     */       }
/* 263 */       return false;
/*     */     }
/* 265 */     if (isFinished())
/*     */     {
/*     */ 
/*     */ 
/* 269 */       if (!ContainerThreadMarker.isContainerThread()) {
/* 270 */         this.coyoteRequest.action(ActionCode.DISPATCH_READ, null);
/* 271 */         this.coyoteRequest.action(ActionCode.DISPATCH_EXECUTE, null);
/*     */       }
/* 273 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 283 */     if (availableInThisBuffer() > 0) {
/* 284 */       return true;
/*     */     }
/*     */     
/* 287 */     return this.coyoteRequest.isReady();
/*     */   }
/*     */   
/*     */   boolean isBlocking()
/*     */   {
/* 292 */     return this.coyoteRequest.getReadListener() == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int realReadBytes()
/*     */     throws IOException
/*     */   {
/* 305 */     if (this.closed) {
/* 306 */       return -1;
/*     */     }
/* 308 */     if (this.coyoteRequest == null) {
/* 309 */       return -1;
/*     */     }
/*     */     
/* 312 */     if (this.state == 0) {
/* 313 */       this.state = 2;
/*     */     }
/*     */     try
/*     */     {
/* 317 */       return this.coyoteRequest.doRead(this);
/*     */     } catch (IOException ioe) {
/* 319 */       this.coyoteRequest.setErrorException(ioe);
/*     */       
/*     */ 
/* 322 */       throw new ClientAbortException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */   public int readByte() throws IOException
/*     */   {
/* 328 */     throwIfClosed();
/*     */     
/* 330 */     if (checkByteBufferEof()) {
/* 331 */       return -1;
/*     */     }
/* 333 */     return this.bb.get() & 0xFF;
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException
/*     */   {
/* 338 */     throwIfClosed();
/*     */     
/* 340 */     if (checkByteBufferEof()) {
/* 341 */       return -1;
/*     */     }
/* 343 */     int n = Math.min(len, this.bb.remaining());
/* 344 */     this.bb.get(b, off, n);
/* 345 */     return n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(ByteBuffer to)
/*     */     throws IOException
/*     */   {
/* 361 */     throwIfClosed();
/*     */     
/* 363 */     if (checkByteBufferEof()) {
/* 364 */       return -1;
/*     */     }
/* 366 */     int n = Math.min(to.remaining(), this.bb.remaining());
/* 367 */     int orgLimit = this.bb.limit();
/* 368 */     this.bb.limit(this.bb.position() + n);
/* 369 */     to.put(this.bb);
/* 370 */     this.bb.limit(orgLimit);
/* 371 */     to.limit(to.position()).position(to.position() - n);
/* 372 */     return n;
/*     */   }
/*     */   
/*     */ 
/*     */   public int realReadChars()
/*     */     throws IOException
/*     */   {
/* 379 */     checkConverter();
/*     */     
/* 381 */     boolean eof = false;
/*     */     
/* 383 */     if (this.bb.remaining() <= 0) {
/* 384 */       int nRead = realReadBytes();
/* 385 */       if (nRead < 0) {
/* 386 */         eof = true;
/*     */       }
/*     */     }
/*     */     
/* 390 */     if (this.markPos == -1) {
/* 391 */       clear(this.cb);
/*     */     }
/*     */     else {
/* 394 */       makeSpace(this.bb.remaining());
/* 395 */       if ((this.cb.capacity() - this.cb.limit() == 0) && (this.bb.remaining() != 0))
/*     */       {
/* 397 */         clear(this.cb);
/* 398 */         this.markPos = -1;
/*     */       }
/*     */     }
/*     */     
/* 402 */     this.state = 1;
/* 403 */     this.conv.convert(this.bb, this.cb, this, eof);
/*     */     
/* 405 */     if ((this.cb.remaining() == 0) && (eof)) {
/* 406 */       return -1;
/*     */     }
/* 408 */     return this.cb.remaining();
/*     */   }
/*     */   
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 415 */     throwIfClosed();
/*     */     
/* 417 */     if (checkCharBufferEof()) {
/* 418 */       return -1;
/*     */     }
/* 420 */     return this.cb.get();
/*     */   }
/*     */   
/*     */   public int read(char[] cbuf)
/*     */     throws IOException
/*     */   {
/* 426 */     throwIfClosed();
/* 427 */     return read(cbuf, 0, cbuf.length);
/*     */   }
/*     */   
/*     */   public int read(char[] cbuf, int off, int len)
/*     */     throws IOException
/*     */   {
/* 433 */     throwIfClosed();
/*     */     
/* 435 */     if (checkCharBufferEof()) {
/* 436 */       return -1;
/*     */     }
/* 438 */     int n = Math.min(len, this.cb.remaining());
/* 439 */     this.cb.get(cbuf, off, n);
/* 440 */     return n;
/*     */   }
/*     */   
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/* 446 */     throwIfClosed();
/*     */     
/* 448 */     if (n < 0L) {
/* 449 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 452 */     long nRead = 0L;
/* 453 */     while (nRead < n) {
/* 454 */       if (this.cb.remaining() >= n) {
/* 455 */         this.cb.position(this.cb.position() + (int)n);
/* 456 */         nRead = n;
/*     */       } else {
/* 458 */         nRead += this.cb.remaining();
/* 459 */         this.cb.position(this.cb.limit());
/* 460 */         int nb = realReadChars();
/* 461 */         if (nb < 0) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/* 466 */     return nRead;
/*     */   }
/*     */   
/*     */   public boolean ready()
/*     */     throws IOException
/*     */   {
/* 472 */     throwIfClosed();
/* 473 */     if (this.state == 0) {
/* 474 */       this.state = 1;
/*     */     }
/* 476 */     return available() > 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 482 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void mark(int readAheadLimit)
/*     */     throws IOException
/*     */   {
/* 489 */     throwIfClosed();
/*     */     
/* 491 */     if (this.cb.remaining() <= 0) {
/* 492 */       clear(this.cb);
/*     */     }
/* 494 */     else if ((this.cb.capacity() > 2 * this.size) && (this.cb.remaining() < this.cb.position())) {
/* 495 */       this.cb.compact();
/* 496 */       this.cb.flip();
/*     */     }
/*     */     
/* 499 */     this.readLimit = (this.cb.position() + readAheadLimit + this.size);
/* 500 */     this.markPos = this.cb.position();
/*     */   }
/*     */   
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 507 */     throwIfClosed();
/*     */     
/* 509 */     if (this.state == 1) {
/* 510 */       if (this.markPos < 0) {
/* 511 */         clear(this.cb);
/* 512 */         this.markPos = -1;
/* 513 */         IOException ioe = new IOException();
/* 514 */         this.coyoteRequest.setErrorException(ioe);
/* 515 */         throw ioe;
/*     */       }
/* 517 */       this.cb.position(this.markPos);
/*     */     }
/*     */     else {
/* 520 */       clear(this.bb);
/*     */     }
/*     */   }
/*     */   
/*     */   private void throwIfClosed() throws IOException
/*     */   {
/* 526 */     if (this.closed) {
/* 527 */       IOException ioe = new IOException(sm.getString("inputBuffer.streamClosed"));
/* 528 */       this.coyoteRequest.setErrorException(ioe);
/* 529 */       throw ioe;
/*     */     }
/*     */   }
/*     */   
/*     */   public void checkConverter() throws IOException {
/* 534 */     if (this.conv != null) {
/* 535 */       return;
/*     */     }
/*     */     
/* 538 */     Charset charset = null;
/* 539 */     if (this.coyoteRequest != null) {
/* 540 */       charset = this.coyoteRequest.getCharset();
/*     */     }
/*     */     
/* 543 */     if (charset == null) {
/* 544 */       charset = Constants.DEFAULT_BODY_CHARSET;
/*     */     }
/*     */     
/* 547 */     SynchronizedStack<B2CConverter> stack = (SynchronizedStack)encoders.get(charset);
/* 548 */     if (stack == null) {
/* 549 */       stack = new SynchronizedStack();
/* 550 */       encoders.putIfAbsent(charset, stack);
/* 551 */       stack = (SynchronizedStack)encoders.get(charset);
/*     */     }
/* 553 */     this.conv = ((B2CConverter)stack.pop());
/*     */     
/* 555 */     if (this.conv == null) {
/* 556 */       this.conv = createConverter(charset);
/*     */     }
/*     */   }
/*     */   
/*     */   private static B2CConverter createConverter(Charset charset) throws IOException
/*     */   {
/* 562 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 564 */         return (B2CConverter)AccessController.doPrivileged(new PrivilegedCreateConverter(charset));
/*     */       } catch (PrivilegedActionException ex) {
/* 566 */         Exception e = ex.getException();
/* 567 */         if ((e instanceof IOException)) {
/* 568 */           throw ((IOException)e);
/*     */         }
/* 570 */         throw new IOException(e);
/*     */       }
/*     */     }
/*     */     
/* 574 */     return new B2CConverter(charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setByteBuffer(ByteBuffer buffer)
/*     */   {
/* 582 */     this.bb = buffer;
/*     */   }
/*     */   
/*     */ 
/*     */   public ByteBuffer getByteBuffer()
/*     */   {
/* 588 */     return this.bb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void expand(int size) {}
/*     */   
/*     */ 
/*     */   private boolean checkByteBufferEof()
/*     */     throws IOException
/*     */   {
/* 599 */     if (this.bb.remaining() == 0) {
/* 600 */       int n = realReadBytes();
/* 601 */       if (n < 0) {
/* 602 */         return true;
/*     */       }
/*     */     }
/* 605 */     return false;
/*     */   }
/*     */   
/*     */   private boolean checkCharBufferEof() throws IOException {
/* 609 */     if (this.cb.remaining() == 0) {
/* 610 */       int n = realReadChars();
/* 611 */       if (n < 0) {
/* 612 */         return true;
/*     */       }
/*     */     }
/* 615 */     return false;
/*     */   }
/*     */   
/*     */   private void clear(Buffer buffer) {
/* 619 */     buffer.rewind().limit(0);
/*     */   }
/*     */   
/*     */   private void makeSpace(int count) {
/* 623 */     int desiredSize = this.cb.limit() + count;
/* 624 */     if (desiredSize > this.readLimit) {
/* 625 */       desiredSize = this.readLimit;
/*     */     }
/*     */     
/* 628 */     if (desiredSize <= this.cb.capacity()) {
/* 629 */       return;
/*     */     }
/*     */     
/* 632 */     int newSize = 2 * this.cb.capacity();
/* 633 */     if (desiredSize >= newSize) {
/* 634 */       newSize = 2 * this.cb.capacity() + count;
/*     */     }
/*     */     
/* 637 */     if (newSize > this.readLimit) {
/* 638 */       newSize = this.readLimit;
/*     */     }
/*     */     
/* 641 */     CharBuffer tmp = CharBuffer.allocate(newSize);
/* 642 */     int oldPosition = this.cb.position();
/* 643 */     this.cb.position(0);
/* 644 */     tmp.put(this.cb);
/* 645 */     tmp.flip();
/* 646 */     tmp.position(oldPosition);
/* 647 */     this.cb = tmp;
/* 648 */     tmp = null;
/*     */   }
/*     */   
/*     */   private static class PrivilegedCreateConverter
/*     */     implements PrivilegedExceptionAction<B2CConverter>
/*     */   {
/*     */     private final Charset charset;
/*     */     
/*     */     public PrivilegedCreateConverter(Charset charset)
/*     */     {
/* 658 */       this.charset = charset;
/*     */     }
/*     */     
/*     */     public B2CConverter run() throws IOException
/*     */     {
/* 663 */       return new B2CConverter(this.charset);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\connector\InputBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */