/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.catalina.Store;
/*     */ import org.apache.catalina.StoreManager;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentValve
/*     */   extends ValveBase
/*     */ {
/*  54 */   private static final ClassLoader MY_CLASSLOADER = PersistentValve.class.getClassLoader();
/*     */   
/*     */   private volatile boolean clBindRequired;
/*     */   
/*  58 */   protected Pattern filter = null;
/*     */   
/*     */ 
/*     */   public PersistentValve()
/*     */   {
/*  63 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContainer(Container container)
/*     */   {
/*  71 */     super.setContainer(container);
/*  72 */     if (((container instanceof Engine)) || ((container instanceof Host))) {
/*  73 */       this.clBindRequired = true;
/*     */     } else {
/*  75 */       this.clBindRequired = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void invoke(Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/*  96 */     if (isRequestWithoutSession(request.getDecodedRequestURI())) {
/*  97 */       getNext().invoke(request, response);
/*  98 */       return;
/*     */     }
/*     */     
/*     */ 
/* 102 */     Context context = request.getContext();
/* 103 */     if (context == null) {
/* 104 */       response.sendError(500, sm
/* 105 */         .getString("standardHost.noContext"));
/* 106 */       return;
/*     */     }
/*     */     
/*     */ 
/* 110 */     String sessionId = request.getRequestedSessionId();
/* 111 */     Manager manager = context.getManager();
/* 112 */     if ((sessionId != null) && ((manager instanceof StoreManager))) {
/* 113 */       Store store = ((StoreManager)manager).getStore();
/* 114 */       if (store != null) {
/* 115 */         Session session = null;
/*     */         try {
/* 117 */           session = store.load(sessionId);
/*     */         } catch (Exception e) {
/* 119 */           this.container.getLogger().error("deserializeError");
/*     */         }
/* 121 */         if (session != null) {
/* 122 */           if ((!session.isValid()) || 
/* 123 */             (isSessionStale(session, System.currentTimeMillis()))) {
/* 124 */             if (this.container.getLogger().isDebugEnabled()) {
/* 125 */               this.container.getLogger().debug("session swapped in is invalid or expired");
/*     */             }
/* 127 */             session.expire();
/* 128 */             store.remove(sessionId);
/*     */           } else {
/* 130 */             session.setManager(manager);
/*     */             
/* 132 */             manager.add(session);
/*     */             
/* 134 */             session.access();
/* 135 */             session.endAccess();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 140 */     if (this.container.getLogger().isDebugEnabled()) {
/* 141 */       this.container.getLogger().debug("sessionId: " + sessionId);
/*     */     }
/*     */     
/*     */ 
/* 145 */     getNext().invoke(request, response);
/*     */     
/*     */ 
/* 148 */     if (!request.isAsync())
/*     */     {
/*     */       Session hsess;
/*     */       try
/*     */       {
/* 153 */         hsess = request.getSessionInternal(false);
/*     */       } catch (Exception ex) { Session hsess;
/* 155 */         hsess = null;
/*     */       }
/* 157 */       String newsessionId = null;
/* 158 */       if (hsess != null) {
/* 159 */         newsessionId = hsess.getIdInternal();
/*     */       }
/*     */       
/* 162 */       if (this.container.getLogger().isDebugEnabled()) {
/* 163 */         this.container.getLogger().debug("newsessionId: " + newsessionId);
/*     */       }
/* 165 */       if (newsessionId != null) {
/*     */         try {
/* 167 */           bind(context);
/*     */           
/*     */ 
/* 170 */           if ((manager instanceof StoreManager)) {
/* 171 */             Session session = manager.findSession(newsessionId);
/* 172 */             Store store = ((StoreManager)manager).getStore();
/* 173 */             boolean stored = false;
/* 174 */             if (session != null) {
/* 175 */               synchronized (session) {
/* 176 */                 if ((store != null) && (session.isValid()) && 
/* 177 */                   (!isSessionStale(session, System.currentTimeMillis()))) {
/* 178 */                   store.save(session);
/* 179 */                   ((StoreManager)manager).removeSuper(session);
/* 180 */                   session.recycle();
/* 181 */                   stored = true;
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/* 186 */             if ((!stored) && 
/* 187 */               (this.container.getLogger().isDebugEnabled()))
/*     */             {
/* 189 */               this.container.getLogger().debug("newsessionId store: " + store + " session: " + session + " valid: " + (session == null ? "N/A" : 
/* 190 */                 Boolean.toString(session.isValid())) + " stale: " + 
/* 191 */                 isSessionStale(session, System.currentTimeMillis()));
/*     */             }
/*     */             
/*     */           }
/* 195 */           else if (this.container.getLogger().isDebugEnabled()) {
/* 196 */             this.container.getLogger().debug("newsessionId Manager: " + manager);
/*     */           }
/*     */         }
/*     */         finally
/*     */         {
/* 201 */           unbind(context);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isSessionStale(Session session, long timeNow)
/*     */   {
/* 219 */     if (session != null) {
/* 220 */       int maxInactiveInterval = session.getMaxInactiveInterval();
/* 221 */       if (maxInactiveInterval >= 0) {
/* 222 */         int timeIdle = (int)(session.getIdleTimeInternal() / 1000L);
/* 223 */         if (timeIdle >= maxInactiveInterval) {
/* 224 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 229 */     return false;
/*     */   }
/*     */   
/*     */   private void bind(Context context)
/*     */   {
/* 234 */     if (this.clBindRequired) {
/* 235 */       context.bind(Globals.IS_SECURITY_ENABLED, MY_CLASSLOADER);
/*     */     }
/*     */   }
/*     */   
/*     */   private void unbind(Context context)
/*     */   {
/* 241 */     if (this.clBindRequired) {
/* 242 */       context.unbind(Globals.IS_SECURITY_ENABLED, MY_CLASSLOADER);
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean isRequestWithoutSession(String uri) {
/* 247 */     Pattern f = this.filter;
/* 248 */     return (f != null) && (f.matcher(uri).matches());
/*     */   }
/*     */   
/*     */   public String getFilter() {
/* 252 */     if (this.filter == null) {
/* 253 */       return null;
/*     */     }
/* 255 */     return this.filter.toString();
/*     */   }
/*     */   
/*     */   public void setFilter(String filter) {
/* 259 */     if ((filter == null) || (filter.length() == 0)) {
/* 260 */       this.filter = null;
/*     */     } else {
/*     */       try {
/* 263 */         this.filter = Pattern.compile(filter);
/*     */       } catch (PatternSyntaxException pse) {
/* 265 */         this.container.getLogger().error(sm.getString("persistentValve.filter.failure", new Object[] { filter }), pse);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\PersistentValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */