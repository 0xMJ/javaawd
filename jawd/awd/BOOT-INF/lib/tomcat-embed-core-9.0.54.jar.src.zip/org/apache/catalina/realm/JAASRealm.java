/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.login.AccountExpiredException;
/*     */ import javax.security.auth.login.Configuration;
/*     */ import javax.security.auth.login.CredentialExpiredException;
/*     */ import javax.security.auth.login.FailedLoginException;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JAASRealm
/*     */   extends RealmBase
/*     */ {
/* 129 */   private static final Log log = LogFactory.getLog(JAASRealm.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */   protected String appName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */   protected final List<String> roleClasses = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 150 */   protected final List<String> userClasses = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */   protected boolean useContextClassLoader = true;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String configFile;
/*     */   
/*     */ 
/*     */   protected volatile Configuration jaasConfiguration;
/*     */   
/*     */ 
/* 168 */   protected volatile boolean jaasConfigurationLoaded = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 177 */   private volatile boolean invocationSuccess = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getConfigFile()
/*     */   {
/* 185 */     return this.configFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConfigFile(String configFile)
/*     */   {
/* 193 */     this.configFile = configFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAppName(String name)
/*     */   {
/* 202 */     this.appName = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getAppName()
/*     */   {
/* 209 */     return this.appName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseContextClassLoader(boolean useContext)
/*     */   {
/* 219 */     this.useContextClassLoader = useContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUseContextClassLoader()
/*     */   {
/* 229 */     return this.useContextClassLoader;
/*     */   }
/*     */   
/*     */   public void setContainer(Container container)
/*     */   {
/* 234 */     super.setContainer(container);
/*     */     
/* 236 */     if (this.appName == null) {
/* 237 */       this.appName = makeLegalForJAAS(container.getName());
/* 238 */       log.info(sm.getString("jaasRealm.appName", new Object[] { this.appName }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 246 */   protected String roleClassNames = null;
/*     */   
/*     */   public String getRoleClassNames() {
/* 249 */     return this.roleClassNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRoleClassNames(String roleClassNames)
/*     */   {
/* 260 */     this.roleClassNames = roleClassNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void parseClassNames(String classNamesString, List<String> classNamesList)
/*     */   {
/* 273 */     classNamesList.clear();
/* 274 */     if (classNamesString == null) {
/* 275 */       return;
/*     */     }
/*     */     
/* 278 */     ClassLoader loader = getClass().getClassLoader();
/* 279 */     if (isUseContextClassLoader()) {
/* 280 */       loader = Thread.currentThread().getContextClassLoader();
/*     */     }
/*     */     
/* 283 */     String[] classNames = classNamesString.split("[ ]*,[ ]*");
/* 284 */     for (String className : classNames) {
/* 285 */       if (className.length() != 0)
/*     */       {
/*     */         try
/*     */         {
/* 289 */           Class<?> principalClass = Class.forName(className, false, loader);
/*     */           
/* 291 */           if (Principal.class.isAssignableFrom(principalClass)) {
/* 292 */             classNamesList.add(className);
/*     */           } else {
/* 294 */             log.error(sm.getString("jaasRealm.notPrincipal", new Object[] { className }));
/*     */           }
/*     */         } catch (ClassNotFoundException e) {
/* 297 */           log.error(sm.getString("jaasRealm.classNotFound", new Object[] { className }));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 306 */   protected String userClassNames = null;
/*     */   
/*     */   public String getUserClassNames() {
/* 309 */     return this.userClassNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserClassNames(String userClassNames)
/*     */   {
/* 320 */     this.userClassNames = userClassNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username, String credentials)
/*     */   {
/* 337 */     return authenticate(username, new JAASCallbackHandler(this, username, credentials));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realmName, String md5a2)
/*     */   {
/* 361 */     return authenticate(username, new JAASCallbackHandler(this, username, clientDigest, nonce, nc, cnonce, qop, realmName, md5a2, "DIGEST"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Principal authenticate(String username, CallbackHandler callbackHandler)
/*     */   {
/*     */     try
/*     */     {
/* 385 */       LoginContext loginContext = null;
/* 386 */       if (this.appName == null) {
/* 387 */         this.appName = "Tomcat";
/*     */       }
/*     */       
/* 390 */       if (log.isDebugEnabled()) {
/* 391 */         log.debug(sm.getString("jaasRealm.beginLogin", new Object[] { username, this.appName }));
/*     */       }
/*     */       
/*     */ 
/* 395 */       ClassLoader ocl = null;
/*     */       
/* 397 */       if (!isUseContextClassLoader()) {
/* 398 */         ocl = Thread.currentThread().getContextClassLoader();
/* 399 */         Thread.currentThread().setContextClassLoader(
/* 400 */           getClass().getClassLoader());
/*     */       }
/*     */       try
/*     */       {
/* 404 */         Configuration config = getConfig();
/* 405 */         loginContext = new LoginContext(this.appName, null, callbackHandler, config);
/*     */       }
/*     */       catch (Throwable e) {
/* 408 */         ExceptionUtils.handleThrowable(e);
/* 409 */         log.error(sm.getString("jaasRealm.unexpectedError"), e);
/*     */         
/*     */ 
/* 412 */         this.invocationSuccess = false;
/* 413 */         return null;
/*     */       } finally {
/* 415 */         if (!isUseContextClassLoader()) {
/* 416 */           Thread.currentThread().setContextClassLoader(ocl);
/*     */         }
/*     */       }
/*     */       
/* 420 */       if (log.isDebugEnabled()) {
/* 421 */         log.debug("Login context created " + username);
/*     */       }
/*     */       
/*     */ 
/* 425 */       Subject subject = null;
/*     */       try {
/* 427 */         loginContext.login();
/* 428 */         subject = loginContext.getSubject();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 433 */         this.invocationSuccess = true;
/* 434 */         if (subject == null) {
/* 435 */           if (log.isDebugEnabled()) {
/* 436 */             log.debug(sm.getString("jaasRealm.failedLogin", new Object[] { username }));
/*     */           }
/* 438 */           return null;
/*     */         }
/*     */       } catch (AccountExpiredException e) {
/* 441 */         if (log.isDebugEnabled()) {
/* 442 */           log.debug(sm.getString("jaasRealm.accountExpired", new Object[] { username }));
/*     */         }
/*     */         
/*     */ 
/* 446 */         this.invocationSuccess = true;
/* 447 */         return null;
/*     */       } catch (CredentialExpiredException e) {
/* 449 */         if (log.isDebugEnabled()) {
/* 450 */           log.debug(sm.getString("jaasRealm.credentialExpired", new Object[] { username }));
/*     */         }
/*     */         
/*     */ 
/* 454 */         this.invocationSuccess = true;
/* 455 */         return null;
/*     */       } catch (FailedLoginException e) {
/* 457 */         if (log.isDebugEnabled()) {
/* 458 */           log.debug(sm.getString("jaasRealm.failedLogin", new Object[] { username }));
/*     */         }
/*     */         
/*     */ 
/* 462 */         this.invocationSuccess = true;
/* 463 */         return null;
/*     */       } catch (LoginException e) {
/* 465 */         log.warn(sm.getString("jaasRealm.loginException", new Object[] { username }), e);
/*     */         
/*     */ 
/* 468 */         this.invocationSuccess = true;
/* 469 */         return null;
/*     */       } catch (Throwable e) {
/* 471 */         ExceptionUtils.handleThrowable(e);
/* 472 */         log.error(sm.getString("jaasRealm.unexpectedError"), e);
/*     */         
/*     */ 
/* 475 */         this.invocationSuccess = false;
/* 476 */         return null;
/*     */       }
/*     */       
/* 479 */       if (log.isDebugEnabled()) {
/* 480 */         log.debug(sm.getString("jaasRealm.loginContextCreated", new Object[] { username }));
/*     */       }
/*     */       
/*     */ 
/* 484 */       Principal principal = createPrincipal(username, subject, loginContext);
/* 485 */       if (principal == null) {
/* 486 */         log.debug(sm.getString("jaasRealm.authenticateFailure", new Object[] { username }));
/* 487 */         return null;
/*     */       }
/* 489 */       if (log.isDebugEnabled()) {
/* 490 */         log.debug(sm.getString("jaasRealm.authenticateSuccess", new Object[] { username, principal }));
/*     */       }
/*     */       
/* 493 */       return principal;
/*     */     } catch (Throwable t) {
/* 495 */       log.error("error ", t);
/*     */       
/* 497 */       this.invocationSuccess = false; }
/* 498 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPassword(String username)
/*     */   {
/* 510 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Principal getPrincipal(String username)
/*     */   {
/* 520 */     return authenticate(username, new JAASCallbackHandler(this, username, null, null, null, null, null, null, null, "CLIENT_CERT"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Principal createPrincipal(String username, Subject subject, LoginContext loginContext)
/*     */   {
/* 547 */     List<String> roles = new ArrayList();
/* 548 */     Principal userPrincipal = null;
/*     */     
/*     */ 
/* 551 */     for (Principal principal : subject.getPrincipals()) {
/* 552 */       String principalClass = principal.getClass().getName();
/*     */       
/* 554 */       if (log.isDebugEnabled()) {
/* 555 */         log.debug(sm.getString("jaasRealm.checkPrincipal", new Object[] { principal, principalClass }));
/*     */       }
/*     */       
/* 558 */       if ((userPrincipal == null) && (this.userClasses.contains(principalClass))) {
/* 559 */         userPrincipal = principal;
/* 560 */         if (log.isDebugEnabled()) {
/* 561 */           log.debug(sm.getString("jaasRealm.userPrincipalSuccess", new Object[] { principal.getName() }));
/*     */         }
/*     */       }
/*     */       
/* 565 */       if (this.roleClasses.contains(principalClass)) {
/* 566 */         roles.add(principal.getName());
/* 567 */         if (log.isDebugEnabled()) {
/* 568 */           log.debug(sm.getString("jaasRealm.rolePrincipalAdd", new Object[] { principal.getName() }));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 574 */     if (userPrincipal == null) {
/* 575 */       if (log.isDebugEnabled()) {
/* 576 */         log.debug(sm.getString("jaasRealm.userPrincipalFailure"));
/* 577 */         log.debug(sm.getString("jaasRealm.rolePrincipalFailure"));
/*     */       }
/* 579 */       return null;
/*     */     }
/* 581 */     if ((roles.size() == 0) && 
/* 582 */       (log.isDebugEnabled())) {
/* 583 */       log.debug(sm.getString("jaasRealm.rolePrincipalFailure"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 589 */     return new GenericPrincipal(username, null, roles, userPrincipal, loginContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String makeLegalForJAAS(String src)
/*     */   {
/* 603 */     String result = src;
/*     */     
/*     */ 
/* 606 */     if (result == null) {
/* 607 */       result = "other";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 612 */     if (result.startsWith("/")) {
/* 613 */       result = result.substring(1);
/*     */     }
/*     */     
/* 616 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 636 */     parseClassNames(this.userClassNames, this.userClasses);
/* 637 */     parseClassNames(this.roleClassNames, this.roleClasses);
/*     */     
/* 639 */     super.startInternal();
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected Configuration getConfig()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 12	org/apache/catalina/realm/JAASRealm:configFile	Ljava/lang/String;
/*     */     //   4: astore_1
/*     */     //   5: aload_0
/*     */     //   6: getfield 8	org/apache/catalina/realm/JAASRealm:jaasConfigurationLoaded	Z
/*     */     //   9: ifeq +8 -> 17
/*     */     //   12: aload_0
/*     */     //   13: getfield 101	org/apache/catalina/realm/JAASRealm:jaasConfiguration	Ljavax/security/auth/login/Configuration;
/*     */     //   16: areturn
/*     */     //   17: aload_0
/*     */     //   18: dup
/*     */     //   19: astore_2
/*     */     //   20: monitorenter
/*     */     //   21: aload_1
/*     */     //   22: ifnonnull +12 -> 34
/*     */     //   25: aload_0
/*     */     //   26: iconst_1
/*     */     //   27: putfield 8	org/apache/catalina/realm/JAASRealm:jaasConfigurationLoaded	Z
/*     */     //   30: aconst_null
/*     */     //   31: aload_2
/*     */     //   32: monitorexit
/*     */     //   33: areturn
/*     */     //   34: invokestatic 26	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   37: invokevirtual 27	java/lang/Thread:getContextClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   40: aload_1
/*     */     //   41: invokevirtual 102	java/lang/ClassLoader:getResource	(Ljava/lang/String;)Ljava/net/URL;
/*     */     //   44: astore_3
/*     */     //   45: aload_3
/*     */     //   46: invokevirtual 103	java/net/URL:toURI	()Ljava/net/URI;
/*     */     //   49: astore 4
/*     */     //   51: ldc 104
/*     */     //   53: invokestatic 105	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   56: astore 5
/*     */     //   58: aload 5
/*     */     //   60: iconst_1
/*     */     //   61: anewarray 106	java/lang/Class
/*     */     //   64: dup
/*     */     //   65: iconst_0
/*     */     //   66: ldc 107
/*     */     //   68: aastore
/*     */     //   69: invokevirtual 108	java/lang/Class:getConstructor	([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
/*     */     //   72: astore 6
/*     */     //   74: aload 6
/*     */     //   76: iconst_1
/*     */     //   77: anewarray 19	java/lang/Object
/*     */     //   80: dup
/*     */     //   81: iconst_0
/*     */     //   82: aload 4
/*     */     //   84: aastore
/*     */     //   85: invokevirtual 109	java/lang/reflect/Constructor:newInstance	([Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   88: checkcast 110	javax/security/auth/login/Configuration
/*     */     //   91: astore 7
/*     */     //   93: aload_0
/*     */     //   94: aload 7
/*     */     //   96: putfield 101	org/apache/catalina/realm/JAASRealm:jaasConfiguration	Ljavax/security/auth/login/Configuration;
/*     */     //   99: aload_0
/*     */     //   100: iconst_1
/*     */     //   101: putfield 8	org/apache/catalina/realm/JAASRealm:jaasConfigurationLoaded	Z
/*     */     //   104: aload_0
/*     */     //   105: getfield 101	org/apache/catalina/realm/JAASRealm:jaasConfiguration	Ljavax/security/auth/login/Configuration;
/*     */     //   108: aload_2
/*     */     //   109: monitorexit
/*     */     //   110: areturn
/*     */     //   111: astore 8
/*     */     //   113: aload_2
/*     */     //   114: monitorexit
/*     */     //   115: aload 8
/*     */     //   117: athrow
/*     */     //   118: astore_2
/*     */     //   119: new 112	java/lang/RuntimeException
/*     */     //   122: dup
/*     */     //   123: aload_2
/*     */     //   124: invokevirtual 113	java/lang/reflect/InvocationTargetException:getCause	()Ljava/lang/Throwable;
/*     */     //   127: invokespecial 114	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   130: athrow
/*     */     //   131: astore_2
/*     */     //   132: new 112	java/lang/RuntimeException
/*     */     //   135: dup
/*     */     //   136: aload_2
/*     */     //   137: invokespecial 114	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   140: athrow
/*     */     // Line number table:
/*     */     //   Java source line #649	-> byte code offset #0
/*     */     //   Java source line #651	-> byte code offset #5
/*     */     //   Java source line #652	-> byte code offset #12
/*     */     //   Java source line #654	-> byte code offset #17
/*     */     //   Java source line #655	-> byte code offset #21
/*     */     //   Java source line #656	-> byte code offset #25
/*     */     //   Java source line #657	-> byte code offset #30
/*     */     //   Java source line #659	-> byte code offset #34
/*     */     //   Java source line #660	-> byte code offset #45
/*     */     //   Java source line #662	-> byte code offset #51
/*     */     //   Java source line #663	-> byte code offset #53
/*     */     //   Java source line #664	-> byte code offset #58
/*     */     //   Java source line #665	-> byte code offset #69
/*     */     //   Java source line #666	-> byte code offset #74
/*     */     //   Java source line #667	-> byte code offset #93
/*     */     //   Java source line #668	-> byte code offset #99
/*     */     //   Java source line #669	-> byte code offset #104
/*     */     //   Java source line #670	-> byte code offset #111
/*     */     //   Java source line #671	-> byte code offset #118
/*     */     //   Java source line #672	-> byte code offset #119
/*     */     //   Java source line #673	-> byte code offset #131
/*     */     //   Java source line #675	-> byte code offset #132
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	141	0	this	JAASRealm
/*     */     //   4	37	1	configFile	String
/*     */     //   118	6	2	ex	java.lang.reflect.InvocationTargetException
/*     */     //   131	6	2	ex	Exception
/*     */     //   44	2	3	resource	java.net.URL
/*     */     //   49	34	4	uri	java.net.URI
/*     */     //   56	3	5	sunConfigFile	Class<Configuration>
/*     */     //   72	3	6	constructor	java.lang.reflect.Constructor<Configuration>
/*     */     //   91	4	7	config	Configuration
/*     */     //   111	5	8	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   21	33	111	finally
/*     */     //   34	110	111	finally
/*     */     //   111	115	111	finally
/*     */     //   5	16	118	java/lang/reflect/InvocationTargetException
/*     */     //   17	33	118	java/lang/reflect/InvocationTargetException
/*     */     //   34	110	118	java/lang/reflect/InvocationTargetException
/*     */     //   111	118	118	java/lang/reflect/InvocationTargetException
/*     */     //   5	16	131	java/lang/SecurityException
/*     */     //   5	16	131	java/net/URISyntaxException
/*     */     //   5	16	131	java/lang/ReflectiveOperationException
/*     */     //   5	16	131	java/lang/IllegalArgumentException
/*     */     //   17	33	131	java/lang/SecurityException
/*     */     //   17	33	131	java/net/URISyntaxException
/*     */     //   17	33	131	java/lang/ReflectiveOperationException
/*     */     //   17	33	131	java/lang/IllegalArgumentException
/*     */     //   34	110	131	java/lang/SecurityException
/*     */     //   34	110	131	java/net/URISyntaxException
/*     */     //   34	110	131	java/lang/ReflectiveOperationException
/*     */     //   34	110	131	java/lang/IllegalArgumentException
/*     */     //   111	118	131	java/lang/SecurityException
/*     */     //   111	118	131	java/net/URISyntaxException
/*     */     //   111	118	131	java/lang/ReflectiveOperationException
/*     */     //   111	118	131	java/lang/IllegalArgumentException
/*     */   }
/*     */   
/*     */   public boolean isAvailable()
/*     */   {
/* 681 */     return this.invocationSuccess;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\JAASRealm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */