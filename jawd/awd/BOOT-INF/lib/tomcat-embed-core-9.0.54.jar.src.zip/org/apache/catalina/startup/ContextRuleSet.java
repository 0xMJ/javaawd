/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.digester.RuleSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextRuleSet
/*     */   implements RuleSet
/*     */ {
/*     */   protected final String prefix;
/*     */   protected final boolean create;
/*     */   
/*     */   public ContextRuleSet()
/*     */   {
/*  51 */     this("");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContextRuleSet(String prefix)
/*     */   {
/*  63 */     this(prefix, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContextRuleSet(String prefix, boolean create)
/*     */   {
/*  77 */     this.prefix = prefix;
/*  78 */     this.create = create;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRuleInstances(Digester digester)
/*     */   {
/*  96 */     if (this.create) {
/*  97 */       digester.addObjectCreate(this.prefix + "Context", "org.apache.catalina.core.StandardContext", "className");
/*     */       
/*  99 */       digester.addSetProperties(this.prefix + "Context");
/*     */     } else {
/* 101 */       digester.addSetProperties(this.prefix + "Context", new String[] { "path", "docBase" });
/*     */     }
/*     */     
/* 104 */     if (this.create) {
/* 105 */       digester.addRule(this.prefix + "Context", new LifecycleListenerRule("org.apache.catalina.startup.ContextConfig", "configClass"));
/*     */       
/*     */ 
/*     */ 
/* 109 */       digester.addSetNext(this.prefix + "Context", "addChild", "org.apache.catalina.Container");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 114 */     digester.addObjectCreate(this.prefix + "Context/Listener", null, "className");
/*     */     
/*     */ 
/* 117 */     digester.addSetProperties(this.prefix + "Context/Listener");
/* 118 */     digester.addSetNext(this.prefix + "Context/Listener", "addLifecycleListener", "org.apache.catalina.LifecycleListener");
/*     */     
/*     */ 
/*     */ 
/* 122 */     digester.addObjectCreate(this.prefix + "Context/Loader", "org.apache.catalina.loader.WebappLoader", "className");
/*     */     
/*     */ 
/* 125 */     digester.addSetProperties(this.prefix + "Context/Loader");
/* 126 */     digester.addSetNext(this.prefix + "Context/Loader", "setLoader", "org.apache.catalina.Loader");
/*     */     
/*     */ 
/*     */ 
/* 130 */     digester.addObjectCreate(this.prefix + "Context/Manager", "org.apache.catalina.session.StandardManager", "className");
/*     */     
/*     */ 
/* 133 */     digester.addSetProperties(this.prefix + "Context/Manager");
/* 134 */     digester.addSetNext(this.prefix + "Context/Manager", "setManager", "org.apache.catalina.Manager");
/*     */     
/*     */ 
/*     */ 
/* 138 */     digester.addObjectCreate(this.prefix + "Context/Manager/Store", null, "className");
/*     */     
/*     */ 
/* 141 */     digester.addSetProperties(this.prefix + "Context/Manager/Store");
/* 142 */     digester.addSetNext(this.prefix + "Context/Manager/Store", "setStore", "org.apache.catalina.Store");
/*     */     
/*     */ 
/*     */ 
/* 146 */     digester.addObjectCreate(this.prefix + "Context/Manager/SessionIdGenerator", "org.apache.catalina.util.StandardSessionIdGenerator", "className");
/*     */     
/*     */ 
/* 149 */     digester.addSetProperties(this.prefix + "Context/Manager/SessionIdGenerator");
/* 150 */     digester.addSetNext(this.prefix + "Context/Manager/SessionIdGenerator", "setSessionIdGenerator", "org.apache.catalina.SessionIdGenerator");
/*     */     
/*     */ 
/*     */ 
/* 154 */     digester.addObjectCreate(this.prefix + "Context/Parameter", "org.apache.tomcat.util.descriptor.web.ApplicationParameter");
/*     */     
/* 156 */     digester.addSetProperties(this.prefix + "Context/Parameter");
/* 157 */     digester.addSetNext(this.prefix + "Context/Parameter", "addApplicationParameter", "org.apache.tomcat.util.descriptor.web.ApplicationParameter");
/*     */     
/*     */ 
/*     */ 
/* 161 */     digester.addRuleSet(new RealmRuleSet(this.prefix + "Context/"));
/*     */     
/* 163 */     digester.addObjectCreate(this.prefix + "Context/Resources", "org.apache.catalina.webresources.StandardRoot", "className");
/*     */     
/*     */ 
/* 166 */     digester.addSetProperties(this.prefix + "Context/Resources");
/* 167 */     digester.addSetNext(this.prefix + "Context/Resources", "setResources", "org.apache.catalina.WebResourceRoot");
/*     */     
/*     */ 
/*     */ 
/* 171 */     digester.addObjectCreate(this.prefix + "Context/Resources/PreResources", null, "className");
/*     */     
/*     */ 
/* 174 */     digester.addSetProperties(this.prefix + "Context/Resources/PreResources");
/* 175 */     digester.addSetNext(this.prefix + "Context/Resources/PreResources", "addPreResources", "org.apache.catalina.WebResourceSet");
/*     */     
/*     */ 
/*     */ 
/* 179 */     digester.addObjectCreate(this.prefix + "Context/Resources/JarResources", null, "className");
/*     */     
/*     */ 
/* 182 */     digester.addSetProperties(this.prefix + "Context/Resources/JarResources");
/* 183 */     digester.addSetNext(this.prefix + "Context/Resources/JarResources", "addJarResources", "org.apache.catalina.WebResourceSet");
/*     */     
/*     */ 
/*     */ 
/* 187 */     digester.addObjectCreate(this.prefix + "Context/Resources/PostResources", null, "className");
/*     */     
/*     */ 
/* 190 */     digester.addSetProperties(this.prefix + "Context/Resources/PostResources");
/* 191 */     digester.addSetNext(this.prefix + "Context/Resources/PostResources", "addPostResources", "org.apache.catalina.WebResourceSet");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 196 */     digester.addObjectCreate(this.prefix + "Context/ResourceLink", "org.apache.tomcat.util.descriptor.web.ContextResourceLink");
/*     */     
/* 198 */     digester.addSetProperties(this.prefix + "Context/ResourceLink");
/* 199 */     digester.addRule(this.prefix + "Context/ResourceLink", new SetNextNamingRule("addResourceLink", "org.apache.tomcat.util.descriptor.web.ContextResourceLink"));
/*     */     
/*     */ 
/*     */ 
/* 203 */     digester.addObjectCreate(this.prefix + "Context/Valve", null, "className");
/*     */     
/*     */ 
/* 206 */     digester.addSetProperties(this.prefix + "Context/Valve");
/* 207 */     digester.addSetNext(this.prefix + "Context/Valve", "addValve", "org.apache.catalina.Valve");
/*     */     
/*     */ 
/*     */ 
/* 211 */     digester.addCallMethod(this.prefix + "Context/WatchedResource", "addWatchedResource", 0);
/*     */     
/*     */ 
/* 214 */     digester.addCallMethod(this.prefix + "Context/WrapperLifecycle", "addWrapperLifecycle", 0);
/*     */     
/*     */ 
/* 217 */     digester.addCallMethod(this.prefix + "Context/WrapperListener", "addWrapperListener", 0);
/*     */     
/*     */ 
/* 220 */     digester.addObjectCreate(this.prefix + "Context/JarScanner", "org.apache.tomcat.util.scan.StandardJarScanner", "className");
/*     */     
/*     */ 
/* 223 */     digester.addSetProperties(this.prefix + "Context/JarScanner");
/* 224 */     digester.addSetNext(this.prefix + "Context/JarScanner", "setJarScanner", "org.apache.tomcat.JarScanner");
/*     */     
/*     */ 
/*     */ 
/* 228 */     digester.addObjectCreate(this.prefix + "Context/JarScanner/JarScanFilter", "org.apache.tomcat.util.scan.StandardJarScanFilter", "className");
/*     */     
/*     */ 
/* 231 */     digester.addSetProperties(this.prefix + "Context/JarScanner/JarScanFilter");
/* 232 */     digester.addSetNext(this.prefix + "Context/JarScanner/JarScanFilter", "setJarScanFilter", "org.apache.tomcat.JarScanFilter");
/*     */     
/*     */ 
/*     */ 
/* 236 */     digester.addObjectCreate(this.prefix + "Context/CookieProcessor", "org.apache.tomcat.util.http.Rfc6265CookieProcessor", "className");
/*     */     
/*     */ 
/* 239 */     digester.addSetProperties(this.prefix + "Context/CookieProcessor");
/* 240 */     digester.addSetNext(this.prefix + "Context/CookieProcessor", "setCookieProcessor", "org.apache.tomcat.util.http.CookieProcessor");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\ContextRuleSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */