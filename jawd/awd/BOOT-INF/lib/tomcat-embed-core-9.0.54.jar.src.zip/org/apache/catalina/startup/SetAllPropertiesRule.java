/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import org.apache.tomcat.util.digester.SetPropertiesRule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class SetAllPropertiesRule
/*    */   extends SetPropertiesRule
/*    */ {
/*    */   public SetAllPropertiesRule() {}
/*    */   
/*    */   public SetAllPropertiesRule(String[] exclude)
/*    */   {
/* 37 */     super(exclude);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\SetAllPropertiesRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */