/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import org.apache.tomcat.util.buf.UriUtil;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource.Resource;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CatalinaBaseConfigurationSource
/*     */   implements ConfigurationSource
/*     */ {
/*  34 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */   private final String serverXmlPath;
/*     */   private final File catalinaBaseFile;
/*     */   private final URI catalinaBaseUri;
/*     */   
/*     */   public CatalinaBaseConfigurationSource(File catalinaBaseFile, String serverXmlPath)
/*     */   {
/*  41 */     this.catalinaBaseFile = catalinaBaseFile;
/*  42 */     this.catalinaBaseUri = catalinaBaseFile.toURI();
/*  43 */     this.serverXmlPath = serverXmlPath;
/*     */   }
/*     */   
/*     */   public ConfigurationSource.Resource getServerXml() throws IOException
/*     */   {
/*  48 */     IOException ioe = null;
/*  49 */     ConfigurationSource.Resource result = null;
/*     */     try {
/*  51 */       if ((this.serverXmlPath == null) || (this.serverXmlPath.equals("conf/server.xml"))) {
/*  52 */         result = super.getServerXml();
/*     */       } else {
/*  54 */         result = getResource(this.serverXmlPath);
/*     */       }
/*     */     } catch (IOException e) {
/*  57 */       ioe = e;
/*     */     }
/*  59 */     if (result == null)
/*     */     {
/*  61 */       InputStream stream = getClass().getClassLoader().getResourceAsStream("server-embed.xml");
/*  62 */       if (stream != null) {
/*     */         try {
/*  64 */           result = new ConfigurationSource.Resource(stream, getClass().getClassLoader().getResource("server-embed.xml").toURI());
/*     */         } catch (URISyntaxException e) {
/*  66 */           stream.close();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  71 */     if ((result == null) && (ioe != null)) {
/*  72 */       throw ioe;
/*     */     }
/*  74 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigurationSource.Resource getResource(String name)
/*     */     throws IOException
/*     */   {
/*  84 */     if (!UriUtil.isAbsoluteURI(name)) {
/*  85 */       File f = new File(name);
/*  86 */       if (!f.isAbsolute()) {
/*  87 */         f = new File(this.catalinaBaseFile, name);
/*     */       }
/*  89 */       if (f.isFile()) {
/*  90 */         FileInputStream fis = new FileInputStream(f);
/*  91 */         return new ConfigurationSource.Resource(fis, f.toURI());
/*     */       }
/*     */       
/*     */ 
/*  95 */       InputStream stream = null;
/*     */       try {
/*  97 */         stream = getClass().getClassLoader().getResourceAsStream(name);
/*  98 */         if (stream != null) {
/*  99 */           return new ConfigurationSource.Resource(stream, getClass().getClassLoader().getResource(name).toURI());
/*     */         }
/*     */       } catch (URISyntaxException e) {
/* 102 */         stream.close();
/* 103 */         throw new IOException(sm.getString("catalinaConfigurationSource.cannotObtainURL", new Object[] { name }), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 108 */     URI uri = null;
/*     */     try {
/* 110 */       uri = getURIInternal(name);
/*     */     } catch (IllegalArgumentException e) {
/* 112 */       throw new IOException(sm.getString("catalinaConfigurationSource.cannotObtainURL", new Object[] { name }));
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 117 */       URL url = uri.toURL();
/* 118 */       return new ConfigurationSource.Resource(url.openConnection().getInputStream(), uri);
/*     */     } catch (MalformedURLException e) {
/* 120 */       throw new IOException(sm.getString("catalinaConfigurationSource.cannotObtainURL", new Object[] { name }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public URI getURI(String name)
/*     */   {
/* 130 */     if (!UriUtil.isAbsoluteURI(name)) {
/* 131 */       File f = new File(name);
/* 132 */       if (!f.isAbsolute()) {
/* 133 */         f = new File(this.catalinaBaseFile, name);
/*     */       }
/* 135 */       if (f.isFile()) {
/* 136 */         return f.toURI();
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 141 */         URL resource = getClass().getClassLoader().getResource(name);
/* 142 */         if (resource != null) {
/* 143 */           return resource.toURI();
/*     */         }
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     }
/*     */     
/*     */ 
/* 150 */     return getURIInternal(name);
/*     */   }
/*     */   
/*     */ 
/*     */   private URI getURIInternal(String name)
/*     */   {
/*     */     URI uri;
/*     */     URI uri;
/* 158 */     if (this.catalinaBaseUri != null) {
/* 159 */       uri = this.catalinaBaseUri.resolve(name);
/*     */     } else {
/* 161 */       uri = URI.create(name);
/*     */     }
/* 163 */     return uri;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\CatalinaBaseConfigurationSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */