/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Properties;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerInfo
/*     */ {
/*     */   private static final String serverInfo;
/*     */   private static final String serverBuilt;
/*     */   private static final String serverNumber;
/*     */   
/*     */   static
/*     */   {
/*  55 */     String info = null;
/*  56 */     String built = null;
/*  57 */     String number = null;
/*     */     
/*  59 */     Properties props = new Properties();
/*     */     try {
/*  61 */       InputStream is = ServerInfo.class.getResourceAsStream("/org/apache/catalina/util/ServerInfo.properties");Throwable localThrowable4 = null;
/*  62 */       try { props.load(is);
/*  63 */         info = props.getProperty("server.info");
/*  64 */         built = props.getProperty("server.built");
/*  65 */         number = props.getProperty("server.number");
/*     */       }
/*     */       catch (Throwable localThrowable2)
/*     */       {
/*  60 */         localThrowable4 = localThrowable2;throw localThrowable2;
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*  66 */         if (is != null) if (localThrowable4 != null) try { is.close(); } catch (Throwable localThrowable3) { localThrowable4.addSuppressed(localThrowable3); } else is.close();
/*  67 */       } } catch (Throwable t) { ExceptionUtils.handleThrowable(t);
/*     */     }
/*  69 */     if ((info == null) || (info.equals("Apache Tomcat/@VERSION@"))) {
/*  70 */       info = "Apache Tomcat/9.0.x-dev";
/*     */     }
/*  72 */     if ((built == null) || (built.equals("@VERSION_BUILT@"))) {
/*  73 */       built = "unknown";
/*     */     }
/*  75 */     if ((number == null) || (number.equals("@VERSION_NUMBER@"))) {
/*  76 */       number = "9.0.x";
/*     */     }
/*     */     
/*  79 */     serverInfo = info;
/*  80 */     serverBuilt = built;
/*  81 */     serverNumber = number;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getServerInfo()
/*     */   {
/*  92 */     return serverInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String getServerBuilt()
/*     */   {
/*  99 */     return serverBuilt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String getServerNumber()
/*     */   {
/* 106 */     return serverNumber;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 110 */     System.out.println("Server version: " + getServerInfo());
/* 111 */     System.out.println("Server built:   " + getServerBuilt());
/* 112 */     System.out.println("Server number:  " + getServerNumber());
/* 113 */     System.out.println("OS Name:        " + 
/* 114 */       System.getProperty("os.name"));
/* 115 */     System.out.println("OS Version:     " + 
/* 116 */       System.getProperty("os.version"));
/* 117 */     System.out.println("Architecture:   " + 
/* 118 */       System.getProperty("os.arch"));
/* 119 */     System.out.println("JVM Version:    " + 
/* 120 */       System.getProperty("java.runtime.version"));
/* 121 */     System.out.println("JVM Vendor:     " + 
/* 122 */       System.getProperty("java.vm.vendor"));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\ServerInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */