/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.digester.RuleSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HostRuleSet
/*     */   implements RuleSet
/*     */ {
/*     */   protected final String prefix;
/*     */   
/*     */   public HostRuleSet()
/*     */   {
/*  47 */     this("");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HostRuleSet(String prefix)
/*     */   {
/*  59 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRuleInstances(Digester digester)
/*     */   {
/*  77 */     digester.addObjectCreate(this.prefix + "Host", "org.apache.catalina.core.StandardHost", "className");
/*     */     
/*     */ 
/*  80 */     digester.addSetProperties(this.prefix + "Host");
/*  81 */     digester.addRule(this.prefix + "Host", new CopyParentClassLoaderRule());
/*     */     
/*  83 */     digester.addRule(this.prefix + "Host", new LifecycleListenerRule("org.apache.catalina.startup.HostConfig", "hostConfigClass"));
/*     */     
/*     */ 
/*     */ 
/*  87 */     digester.addSetNext(this.prefix + "Host", "addChild", "org.apache.catalina.Container");
/*     */     
/*     */ 
/*     */ 
/*  91 */     digester.addCallMethod(this.prefix + "Host/Alias", "addAlias", 0);
/*     */     
/*     */ 
/*     */ 
/*  95 */     digester.addObjectCreate(this.prefix + "Host/Cluster", null, "className");
/*     */     
/*     */ 
/*  98 */     digester.addSetProperties(this.prefix + "Host/Cluster");
/*  99 */     digester.addSetNext(this.prefix + "Host/Cluster", "setCluster", "org.apache.catalina.Cluster");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 104 */     digester.addObjectCreate(this.prefix + "Host/Listener", null, "className");
/*     */     
/*     */ 
/* 107 */     digester.addSetProperties(this.prefix + "Host/Listener");
/* 108 */     digester.addSetNext(this.prefix + "Host/Listener", "addLifecycleListener", "org.apache.catalina.LifecycleListener");
/*     */     
/*     */ 
/*     */ 
/* 112 */     digester.addRuleSet(new RealmRuleSet(this.prefix + "Host/"));
/*     */     
/* 114 */     digester.addObjectCreate(this.prefix + "Host/Valve", null, "className");
/*     */     
/*     */ 
/* 117 */     digester.addSetProperties(this.prefix + "Host/Valve");
/* 118 */     digester.addSetNext(this.prefix + "Host/Valve", "addValve", "org.apache.catalina.Valve");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\HostRuleSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */