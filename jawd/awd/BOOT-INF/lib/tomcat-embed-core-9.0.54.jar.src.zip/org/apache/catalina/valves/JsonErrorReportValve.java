/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonErrorReportValve
/*     */   extends ErrorReportValve
/*     */ {
/*     */   protected void report(Request request, org.apache.catalina.connector.Response response, Throwable throwable)
/*     */   {
/*  45 */     int statusCode = response.getStatus();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  51 */     if ((statusCode < 400) || (response.getContentWritten() > 0L) || (!response.setErrorReported())) {
/*  52 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  57 */     AtomicBoolean result = new AtomicBoolean(false);
/*  58 */     response.getCoyoteResponse().action(ActionCode.IS_IO_ALLOWED, result);
/*  59 */     if (!result.get()) {
/*  60 */       return;
/*     */     }
/*     */     
/*  63 */     StringManager smClient = StringManager.getManager("org.apache.catalina.valves", request.getLocales());
/*  64 */     response.setLocale(smClient.getLocale());
/*  65 */     String type = null;
/*  66 */     if (throwable != null) {
/*  67 */       type = smClient.getString("errorReportValve.exceptionReport");
/*     */     } else {
/*  69 */       type = smClient.getString("errorReportValve.statusReport");
/*     */     }
/*  71 */     String message = response.getMessage();
/*  72 */     if ((message == null) && (throwable != null)) {
/*  73 */       message = throwable.getMessage();
/*     */     }
/*  75 */     String description = null;
/*  76 */     description = smClient.getString("http." + statusCode + ".desc");
/*  77 */     if (description == null) {
/*  78 */       if ((message == null) || (message.isEmpty())) {
/*  79 */         return;
/*     */       }
/*  81 */       description = smClient.getString("errorReportValve.noDescription");
/*     */     }
/*     */     
/*  84 */     String jsonReport = "{\n  \"type\": \"" + type + "\",\n  \"message\": \"" + message + "\",\n  \"description\": \"" + description + "\"\n}";
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*  91 */         response.setContentType("application/json");
/*  92 */         response.setCharacterEncoding("utf-8");
/*     */       } catch (Throwable t) {
/*  94 */         ExceptionUtils.handleThrowable(t);
/*  95 */         if (this.container.getLogger().isDebugEnabled()) {
/*  96 */           this.container.getLogger().debug("status.setContentType", t);
/*     */         }
/*     */       }
/*  99 */       Writer writer = response.getReporter();
/* 100 */       if (writer != null) {
/* 101 */         writer.write(jsonReport);
/* 102 */         response.finishResponse();
/* 103 */         return;
/*     */       }
/*     */     }
/*     */     catch (IOException|IllegalStateException localIOException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\JsonErrorReportValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */