/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RewriteRule
/*     */ {
/*  27 */   protected RewriteCond[] conditions = new RewriteCond[0];
/*     */   
/*  29 */   protected ThreadLocal<Pattern> pattern = new ThreadLocal();
/*  30 */   protected Substitution substitution = null;
/*     */   
/*  32 */   protected String patternString = null;
/*  33 */   protected String substitutionString = null;
/*  34 */   protected String flagsString = null;
/*  35 */   protected boolean positive = true;
/*     */   
/*     */   public void parse(Map<String, RewriteMap> maps)
/*     */   {
/*  39 */     if (!"-".equals(this.substitutionString)) {
/*  40 */       this.substitution = new Substitution();
/*  41 */       this.substitution.setSub(this.substitutionString);
/*  42 */       this.substitution.parse(maps);
/*  43 */       this.substitution.setEscapeBackReferences(isEscapeBackReferences());
/*     */     }
/*     */     
/*  46 */     if (this.patternString.startsWith("!")) {
/*  47 */       this.positive = false;
/*  48 */       this.patternString = this.patternString.substring(1);
/*     */     }
/*  50 */     int flags = 0;
/*  51 */     if (isNocase()) {
/*  52 */       flags |= 0x2;
/*     */     }
/*  54 */     Pattern.compile(this.patternString, flags);
/*     */     
/*  56 */     for (RewriteCond condition : this.conditions) {
/*  57 */       condition.parse(maps);
/*     */     }
/*     */     
/*  60 */     if (isEnv()) {
/*  61 */       for (??? = this.envValue.iterator(); ((Iterator)???).hasNext();) { String s = (String)((Iterator)???).next();
/*  62 */         Substitution newEnvSubstitution = new Substitution();
/*  63 */         newEnvSubstitution.setSub(s);
/*  64 */         newEnvSubstitution.parse(maps);
/*  65 */         this.envSubstitution.add(newEnvSubstitution);
/*  66 */         this.envResult.add(new ThreadLocal());
/*     */       }
/*     */     }
/*  69 */     if (isCookie()) {
/*  70 */       this.cookieSubstitution = new Substitution();
/*  71 */       this.cookieSubstitution.setSub(this.cookieValue);
/*  72 */       this.cookieSubstitution.parse(maps);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addCondition(RewriteCond condition) {
/*  77 */     RewriteCond[] conditions = (RewriteCond[])Arrays.copyOf(this.conditions, this.conditions.length + 1);
/*  78 */     conditions[this.conditions.length] = condition;
/*  79 */     this.conditions = conditions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CharSequence evaluate(CharSequence url, Resolver resolver)
/*     */   {
/*  89 */     Pattern pattern = (Pattern)this.pattern.get();
/*  90 */     if (pattern == null)
/*     */     {
/*  92 */       int flags = 0;
/*  93 */       if (isNocase()) {
/*  94 */         flags |= 0x2;
/*     */       }
/*  96 */       pattern = Pattern.compile(this.patternString, flags);
/*  97 */       this.pattern.set(pattern);
/*     */     }
/*  99 */     Matcher matcher = pattern.matcher(url);
/*     */     
/* 101 */     if ((this.positive ^ matcher.matches()))
/*     */     {
/* 103 */       return null;
/*     */     }
/*     */     
/* 106 */     boolean done = false;
/* 107 */     boolean rewrite = true;
/* 108 */     Matcher lastMatcher = null;
/* 109 */     int pos = 0;
/* 110 */     while (!done) {
/* 111 */       if (pos < this.conditions.length) {
/* 112 */         rewrite = this.conditions[pos].evaluate(matcher, lastMatcher, resolver);
/* 113 */         if (rewrite) {
/* 114 */           Matcher lastMatcher2 = this.conditions[pos].getMatcher();
/* 115 */           if (lastMatcher2 != null) {
/* 116 */             lastMatcher = lastMatcher2;
/*     */           }
/* 118 */           while ((pos < this.conditions.length) && (this.conditions[pos].isOrnext())) {
/* 119 */             pos++;
/*     */           }
/* 121 */         } else if (!this.conditions[pos].isOrnext()) {
/* 122 */           done = true;
/*     */         }
/* 124 */         pos++;
/*     */       } else {
/* 126 */         done = true;
/*     */       }
/*     */     }
/*     */     
/* 130 */     if (rewrite) {
/* 131 */       if (isEnv()) {
/* 132 */         for (int i = 0; i < this.envSubstitution.size(); i++) {
/* 133 */           ((ThreadLocal)this.envResult.get(i)).set(((Substitution)this.envSubstitution.get(i)).evaluate(matcher, lastMatcher, resolver));
/*     */         }
/*     */       }
/* 136 */       if (isCookie()) {
/* 137 */         this.cookieResult.set(this.cookieSubstitution.evaluate(matcher, lastMatcher, resolver));
/*     */       }
/* 139 */       if (this.substitution != null) {
/* 140 */         return this.substitution.evaluate(matcher, lastMatcher, resolver);
/*     */       }
/* 142 */       return url;
/*     */     }
/*     */     
/* 145 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 155 */     return "RewriteRule " + this.patternString + " " + this.substitutionString + (this.flagsString != null ? " " + this.flagsString : "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 160 */   private boolean escapeBackReferences = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 171 */   protected boolean chain = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 180 */   protected boolean cookie = false;
/* 181 */   protected String cookieName = null;
/* 182 */   protected String cookieValue = null;
/* 183 */   protected String cookieDomain = null;
/* 184 */   protected int cookieLifetime = -1;
/* 185 */   protected String cookiePath = null;
/* 186 */   protected boolean cookieSecure = false;
/* 187 */   protected boolean cookieHttpOnly = false;
/* 188 */   protected Substitution cookieSubstitution = null;
/* 189 */   protected ThreadLocal<String> cookieResult = new ThreadLocal();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 196 */   protected boolean env = false;
/* 197 */   protected ArrayList<String> envName = new ArrayList();
/* 198 */   protected ArrayList<String> envValue = new ArrayList();
/* 199 */   protected ArrayList<Substitution> envSubstitution = new ArrayList();
/* 200 */   protected ArrayList<ThreadLocal<String>> envResult = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */   protected boolean forbidden = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 214 */   protected boolean gone = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 221 */   protected boolean host = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 230 */   protected boolean last = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 240 */   protected boolean next = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 247 */   protected boolean nocase = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 259 */   protected boolean noescape = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 273 */   protected boolean nosubreq = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 289 */   protected boolean qsappend = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 298 */   protected boolean qsdiscard = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 316 */   protected boolean redirect = false;
/* 317 */   protected int redirectCode = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 326 */   protected int skip = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 335 */   protected boolean type = false;
/* 336 */   protected String typeValue = null;
/*     */   
/*     */   public boolean isEscapeBackReferences() {
/* 339 */     return this.escapeBackReferences;
/*     */   }
/*     */   
/* 342 */   public void setEscapeBackReferences(boolean escapeBackReferences) { this.escapeBackReferences = escapeBackReferences; }
/*     */   
/*     */   public boolean isChain() {
/* 345 */     return this.chain;
/*     */   }
/*     */   
/* 348 */   public void setChain(boolean chain) { this.chain = chain; }
/*     */   
/*     */   public RewriteCond[] getConditions() {
/* 351 */     return this.conditions;
/*     */   }
/*     */   
/* 354 */   public void setConditions(RewriteCond[] conditions) { this.conditions = conditions; }
/*     */   
/*     */   public boolean isCookie() {
/* 357 */     return this.cookie;
/*     */   }
/*     */   
/* 360 */   public void setCookie(boolean cookie) { this.cookie = cookie; }
/*     */   
/*     */   public String getCookieName() {
/* 363 */     return this.cookieName;
/*     */   }
/*     */   
/* 366 */   public void setCookieName(String cookieName) { this.cookieName = cookieName; }
/*     */   
/*     */   public String getCookieValue() {
/* 369 */     return this.cookieValue;
/*     */   }
/*     */   
/* 372 */   public void setCookieValue(String cookieValue) { this.cookieValue = cookieValue; }
/*     */   
/*     */   public String getCookieResult() {
/* 375 */     return (String)this.cookieResult.get();
/*     */   }
/*     */   
/* 378 */   public boolean isEnv() { return this.env; }
/*     */   
/*     */   public int getEnvSize() {
/* 381 */     return this.envName.size();
/*     */   }
/*     */   
/* 384 */   public void setEnv(boolean env) { this.env = env; }
/*     */   
/*     */   public String getEnvName(int i) {
/* 387 */     return (String)this.envName.get(i);
/*     */   }
/*     */   
/* 390 */   public void addEnvName(String envName) { this.envName.add(envName); }
/*     */   
/*     */   public String getEnvValue(int i) {
/* 393 */     return (String)this.envValue.get(i);
/*     */   }
/*     */   
/* 396 */   public void addEnvValue(String envValue) { this.envValue.add(envValue); }
/*     */   
/*     */   public String getEnvResult(int i) {
/* 399 */     return (String)((ThreadLocal)this.envResult.get(i)).get();
/*     */   }
/*     */   
/* 402 */   public boolean isForbidden() { return this.forbidden; }
/*     */   
/*     */   public void setForbidden(boolean forbidden) {
/* 405 */     this.forbidden = forbidden;
/*     */   }
/*     */   
/* 408 */   public boolean isGone() { return this.gone; }
/*     */   
/*     */   public void setGone(boolean gone) {
/* 411 */     this.gone = gone;
/*     */   }
/*     */   
/* 414 */   public boolean isLast() { return this.last; }
/*     */   
/*     */   public void setLast(boolean last) {
/* 417 */     this.last = last;
/*     */   }
/*     */   
/* 420 */   public boolean isNext() { return this.next; }
/*     */   
/*     */   public void setNext(boolean next) {
/* 423 */     this.next = next;
/*     */   }
/*     */   
/* 426 */   public boolean isNocase() { return this.nocase; }
/*     */   
/*     */   public void setNocase(boolean nocase) {
/* 429 */     this.nocase = nocase;
/*     */   }
/*     */   
/* 432 */   public boolean isNoescape() { return this.noescape; }
/*     */   
/*     */   public void setNoescape(boolean noescape) {
/* 435 */     this.noescape = noescape;
/*     */   }
/*     */   
/* 438 */   public boolean isNosubreq() { return this.nosubreq; }
/*     */   
/*     */   public void setNosubreq(boolean nosubreq) {
/* 441 */     this.nosubreq = nosubreq;
/*     */   }
/*     */   
/* 444 */   public boolean isQsappend() { return this.qsappend; }
/*     */   
/*     */   public void setQsappend(boolean qsappend) {
/* 447 */     this.qsappend = qsappend;
/*     */   }
/*     */   
/* 450 */   public final boolean isQsdiscard() { return this.qsdiscard; }
/*     */   
/*     */   public final void setQsdiscard(boolean qsdiscard) {
/* 453 */     this.qsdiscard = qsdiscard;
/*     */   }
/*     */   
/* 456 */   public boolean isRedirect() { return this.redirect; }
/*     */   
/*     */   public void setRedirect(boolean redirect) {
/* 459 */     this.redirect = redirect;
/*     */   }
/*     */   
/* 462 */   public int getRedirectCode() { return this.redirectCode; }
/*     */   
/*     */   public void setRedirectCode(int redirectCode) {
/* 465 */     this.redirectCode = redirectCode;
/*     */   }
/*     */   
/* 468 */   public int getSkip() { return this.skip; }
/*     */   
/*     */   public void setSkip(int skip) {
/* 471 */     this.skip = skip;
/*     */   }
/*     */   
/* 474 */   public Substitution getSubstitution() { return this.substitution; }
/*     */   
/*     */   public void setSubstitution(Substitution substitution) {
/* 477 */     this.substitution = substitution;
/*     */   }
/*     */   
/* 480 */   public boolean isType() { return this.type; }
/*     */   
/*     */   public void setType(boolean type) {
/* 483 */     this.type = type;
/*     */   }
/*     */   
/* 486 */   public String getTypeValue() { return this.typeValue; }
/*     */   
/*     */   public void setTypeValue(String typeValue) {
/* 489 */     this.typeValue = typeValue;
/*     */   }
/*     */   
/*     */   public String getPatternString() {
/* 493 */     return this.patternString;
/*     */   }
/*     */   
/*     */   public void setPatternString(String patternString) {
/* 497 */     this.patternString = patternString;
/*     */   }
/*     */   
/*     */   public String getSubstitutionString() {
/* 501 */     return this.substitutionString;
/*     */   }
/*     */   
/*     */   public void setSubstitutionString(String substitutionString) {
/* 505 */     this.substitutionString = substitutionString;
/*     */   }
/*     */   
/*     */   public final String getFlagsString() {
/* 509 */     return this.flagsString;
/*     */   }
/*     */   
/*     */   public final void setFlagsString(String flagsString) {
/* 513 */     this.flagsString = flagsString;
/*     */   }
/*     */   
/*     */   public boolean isHost() {
/* 517 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(boolean host) {
/* 521 */     this.host = host;
/*     */   }
/*     */   
/*     */   public String getCookieDomain() {
/* 525 */     return this.cookieDomain;
/*     */   }
/*     */   
/*     */   public void setCookieDomain(String cookieDomain) {
/* 529 */     this.cookieDomain = cookieDomain;
/*     */   }
/*     */   
/*     */   public int getCookieLifetime() {
/* 533 */     return this.cookieLifetime;
/*     */   }
/*     */   
/*     */   public void setCookieLifetime(int cookieLifetime) {
/* 537 */     this.cookieLifetime = cookieLifetime;
/*     */   }
/*     */   
/*     */   public String getCookiePath() {
/* 541 */     return this.cookiePath;
/*     */   }
/*     */   
/*     */   public void setCookiePath(String cookiePath) {
/* 545 */     this.cookiePath = cookiePath;
/*     */   }
/*     */   
/*     */   public boolean isCookieSecure() {
/* 549 */     return this.cookieSecure;
/*     */   }
/*     */   
/*     */   public void setCookieSecure(boolean cookieSecure) {
/* 553 */     this.cookieSecure = cookieSecure;
/*     */   }
/*     */   
/*     */   public boolean isCookieHttpOnly() {
/* 557 */     return this.cookieHttpOnly;
/*     */   }
/*     */   
/*     */   public void setCookieHttpOnly(boolean cookieHttpOnly) {
/* 561 */     this.cookieHttpOnly = cookieHttpOnly;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\rewrite\RewriteRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */