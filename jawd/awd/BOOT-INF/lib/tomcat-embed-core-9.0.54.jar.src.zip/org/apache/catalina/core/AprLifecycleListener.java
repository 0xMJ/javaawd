/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.jni.Library;
/*     */ import org.apache.tomcat.jni.LibraryNotFoundError;
/*     */ import org.apache.tomcat.jni.SSL;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AprLifecycleListener
/*     */   implements LifecycleListener
/*     */ {
/*  46 */   private static final Log log = LogFactory.getLog(AprLifecycleListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */   private static final List<String> initInfoLogMessages = new ArrayList(3);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  57 */   protected static final StringManager sm = StringManager.getManager(AprLifecycleListener.class);
/*     */   
/*     */ 
/*     */   protected static final int TCN_REQUIRED_MAJOR = 1;
/*     */   
/*     */ 
/*     */   protected static final int TCN_REQUIRED_MINOR = 2;
/*     */   
/*     */   protected static final int TCN_REQUIRED_PATCH = 14;
/*     */   
/*     */   protected static final int TCN_RECOMMENDED_MINOR = 2;
/*     */   
/*     */   protected static final int TCN_RECOMMENDED_PV = 30;
/*     */   
/*  71 */   protected static String SSLEngine = "on";
/*  72 */   protected static String FIPSMode = "off";
/*  73 */   protected static String SSLRandomSeed = "builtin";
/*  74 */   protected static boolean sslInitialized = false;
/*  75 */   protected static boolean fipsModeActive = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int FIPS_ON = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int FIPS_OFF = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */   protected static final Object lock = new Object();
/*     */   
/*     */   public static boolean isAprAvailable()
/*     */   {
/*  97 */     if (AprStatus.isInstanceCreated()) {
/*  98 */       synchronized (lock) {
/*  99 */         init();
/*     */       }
/*     */     }
/* 102 */     return AprStatus.isAprAvailable();
/*     */   }
/*     */   
/*     */   public AprLifecycleListener() {
/* 106 */     AprStatus.setInstanceCreated(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void lifecycleEvent(LifecycleEvent event)
/*     */   {
/* 119 */     if ("before_init".equals(event.getType())) {
/* 120 */       synchronized (lock) {
/* 121 */         init();
/* 122 */         for (String msg : initInfoLogMessages) {
/* 123 */           log.info(msg);
/*     */         }
/* 125 */         initInfoLogMessages.clear();
/* 126 */         if (AprStatus.isAprAvailable()) {
/*     */           try {
/* 128 */             initializeSSL();
/*     */           } catch (Throwable t) {
/* 130 */             t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 131 */             ExceptionUtils.handleThrowable(t);
/* 132 */             log.error(sm.getString("aprListener.sslInit"), t);
/*     */           }
/*     */         }
/*     */         
/* 136 */         if ((null != FIPSMode) && (!"off".equalsIgnoreCase(FIPSMode)) && (!isFIPSModeActive())) {
/* 137 */           String errorMessage = sm.getString("aprListener.initializeFIPSFailed");
/* 138 */           Error e = new Error(errorMessage);
/*     */           
/* 140 */           log.fatal(errorMessage, e);
/* 141 */           throw e;
/*     */         }
/*     */       }
/* 144 */     } else if ("after_destroy".equals(event.getType())) {
/* 145 */       synchronized (lock) {
/* 146 */         if (!AprStatus.isAprAvailable()) {
/* 147 */           return;
/*     */         }
/*     */         try {
/* 150 */           terminateAPR();
/*     */         } catch (Throwable t) {
/* 152 */           t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 153 */           ExceptionUtils.handleThrowable(t);
/* 154 */           log.info(sm.getString("aprListener.aprDestroy"));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void terminateAPR()
/*     */     throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 165 */     String methodName = "terminate";
/*     */     
/* 167 */     Method method = Class.forName("org.apache.tomcat.jni.Library").getMethod(methodName, (Class[])null);
/* 168 */     method.invoke(null, (Object[])null);
/* 169 */     AprStatus.setAprAvailable(false);
/* 170 */     AprStatus.setAprInitialized(false);
/* 171 */     sslInitialized = false;
/* 172 */     fipsModeActive = false;
/*     */   }
/*     */   
/*     */   private static void init()
/*     */   {
/* 177 */     int major = 0;
/* 178 */     int minor = 0;
/* 179 */     int patch = 0;
/* 180 */     int apver = 0;
/* 181 */     int rqver = 1214;
/* 182 */     int rcver = 1230;
/*     */     
/* 184 */     if (AprStatus.isAprInitialized()) {
/* 185 */       return;
/*     */     }
/* 187 */     AprStatus.setAprInitialized(true);
/*     */     try
/*     */     {
/* 190 */       Library.initialize(null);
/* 191 */       major = Library.TCN_MAJOR_VERSION;
/* 192 */       minor = Library.TCN_MINOR_VERSION;
/* 193 */       patch = Library.TCN_PATCH_VERSION;
/* 194 */       apver = major * 1000 + minor * 100 + patch;
/*     */     }
/*     */     catch (LibraryNotFoundError lnfe) {
/* 197 */       if (log.isDebugEnabled()) {
/* 198 */         log.debug(sm.getString("aprListener.aprInitDebug", new Object[] {lnfe
/* 199 */           .getLibraryNames(), System.getProperty("java.library.path"), lnfe
/* 200 */           .getMessage() }), lnfe);
/*     */       }
/* 202 */       initInfoLogMessages.add(sm.getString("aprListener.aprInit", new Object[] {
/* 203 */         System.getProperty("java.library.path") }));
/* 204 */       return;
/*     */     }
/*     */     catch (Throwable t) {
/* 207 */       t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 208 */       ExceptionUtils.handleThrowable(t);
/* 209 */       log.warn(sm.getString("aprListener.aprInitError", new Object[] { t.getMessage() }), t);
/* 210 */       return;
/*     */     }
/* 212 */     if (apver < rqver) {
/* 213 */       log.error(sm.getString("aprListener.tcnInvalid", new Object[] {
/* 214 */         Library.versionString(), "1.2.14" }));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 221 */         terminateAPR();
/*     */       } catch (Throwable t) {
/* 223 */         t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 224 */         ExceptionUtils.handleThrowable(t);
/*     */       }
/* 226 */       return;
/*     */     }
/* 228 */     if (apver < rcver) {
/* 229 */       initInfoLogMessages.add(sm.getString("aprListener.tcnVersion", new Object[] {
/* 230 */         Library.versionString(), "1.2.30" }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 236 */     initInfoLogMessages.add(sm.getString("aprListener.tcnValid", new Object[] {
/* 237 */       Library.versionString(), 
/* 238 */       Library.aprVersionString() }));
/*     */     
/*     */ 
/* 241 */     initInfoLogMessages.add(sm.getString("aprListener.flags", new Object[] {
/* 242 */       Boolean.valueOf(Library.APR_HAVE_IPV6), 
/* 243 */       Boolean.valueOf(Library.APR_HAS_SENDFILE), 
/* 244 */       Boolean.valueOf(Library.APR_HAS_SO_ACCEPTFILTER), 
/* 245 */       Boolean.valueOf(Library.APR_HAS_RANDOM), 
/* 246 */       Boolean.valueOf(Library.APR_HAVE_UNIX) }));
/*     */     
/* 248 */     initInfoLogMessages.add(sm.getString("aprListener.config", new Object[] {
/* 249 */       Boolean.valueOf(AprStatus.getUseAprConnector()), 
/* 250 */       Boolean.valueOf(AprStatus.getUseOpenSSL()) }));
/*     */     
/* 252 */     AprStatus.setAprAvailable(true);
/*     */   }
/*     */   
/*     */   private static void initializeSSL() throws Exception
/*     */   {
/* 257 */     if ("off".equalsIgnoreCase(SSLEngine)) {
/* 258 */       return;
/*     */     }
/* 260 */     if (sslInitialized)
/*     */     {
/* 262 */       return;
/*     */     }
/*     */     
/* 265 */     sslInitialized = true;
/*     */     
/* 267 */     String methodName = "randSet";
/* 268 */     Class<?>[] paramTypes = new Class[1];
/* 269 */     paramTypes[0] = String.class;
/* 270 */     Object[] paramValues = new Object[1];
/* 271 */     paramValues[0] = SSLRandomSeed;
/* 272 */     Class<?> clazz = Class.forName("org.apache.tomcat.jni.SSL");
/* 273 */     Method method = clazz.getMethod(methodName, paramTypes);
/* 274 */     method.invoke(null, paramValues);
/*     */     
/*     */ 
/* 277 */     methodName = "initialize";
/* 278 */     paramValues[0] = ("on".equalsIgnoreCase(SSLEngine) ? null : SSLEngine);
/* 279 */     method = clazz.getMethod(methodName, paramTypes);
/* 280 */     method.invoke(null, paramValues);
/*     */     
/* 282 */     if ((null != FIPSMode) && (!"off".equalsIgnoreCase(FIPSMode)))
/*     */     {
/* 284 */       fipsModeActive = false;
/*     */       
/*     */ 
/* 287 */       int fipsModeState = SSL.fipsModeGet();
/*     */       
/* 289 */       if (log.isDebugEnabled()) {
/* 290 */         log.debug(sm.getString("aprListener.currentFIPSMode", new Object[] {
/* 291 */           Integer.valueOf(fipsModeState) }));
/*     */       }
/*     */       boolean enterFipsMode;
/* 294 */       if ("on".equalsIgnoreCase(FIPSMode)) { boolean enterFipsMode;
/* 295 */         if (fipsModeState == 1) {
/* 296 */           log.info(sm.getString("aprListener.skipFIPSInitialization"));
/* 297 */           fipsModeActive = true;
/* 298 */           enterFipsMode = false;
/*     */         } else {
/* 300 */           enterFipsMode = true;
/*     */         }
/* 302 */       } else if ("require".equalsIgnoreCase(FIPSMode)) { boolean enterFipsMode;
/* 303 */         if (fipsModeState == 1) {
/* 304 */           fipsModeActive = true;
/* 305 */           enterFipsMode = false;
/*     */         }
/*     */         else {
/* 308 */           throw new IllegalStateException(sm.getString("aprListener.requireNotInFIPSMode"));
/*     */         }
/* 310 */       } else if ("enter".equalsIgnoreCase(FIPSMode)) { boolean enterFipsMode;
/* 311 */         if (fipsModeState == 0) {
/* 312 */           enterFipsMode = true;
/*     */         } else {
/* 314 */           throw new IllegalStateException(sm.getString("aprListener.enterAlreadyInFIPSMode", new Object[] {
/*     */           
/* 316 */             Integer.valueOf(fipsModeState) }));
/*     */         }
/*     */       } else {
/* 319 */         throw new IllegalArgumentException(sm.getString("aprListener.wrongFIPSMode", new Object[] { FIPSMode }));
/*     */       }
/*     */       
/*     */       boolean enterFipsMode;
/* 323 */       if (enterFipsMode) {
/* 324 */         log.info(sm.getString("aprListener.initializingFIPS"));
/*     */         
/* 326 */         fipsModeState = SSL.fipsModeSet(1);
/* 327 */         if (fipsModeState != 1)
/*     */         {
/*     */ 
/* 330 */           String message = sm.getString("aprListener.initializeFIPSFailed");
/* 331 */           log.error(message);
/* 332 */           throw new IllegalStateException(message);
/*     */         }
/*     */         
/* 335 */         fipsModeActive = true;
/* 336 */         log.info(sm.getString("aprListener.initializeFIPSSuccess"));
/*     */       }
/*     */     }
/*     */     
/* 340 */     log.info(sm.getString("aprListener.initializedOpenSSL", new Object[] { SSL.versionString() }));
/*     */   }
/*     */   
/*     */   public String getSSLEngine() {
/* 344 */     return SSLEngine;
/*     */   }
/*     */   
/*     */   public void setSSLEngine(String SSLEngine) {
/* 348 */     if (!SSLEngine.equals(SSLEngine))
/*     */     {
/* 350 */       if (sslInitialized)
/*     */       {
/* 352 */         throw new IllegalStateException(sm.getString("aprListener.tooLateForSSLEngine"));
/*     */       }
/*     */       
/* 355 */       SSLEngine = SSLEngine;
/*     */     }
/*     */   }
/*     */   
/*     */   public String getSSLRandomSeed() {
/* 360 */     return SSLRandomSeed;
/*     */   }
/*     */   
/*     */   public void setSSLRandomSeed(String SSLRandomSeed) {
/* 364 */     if (!SSLRandomSeed.equals(SSLRandomSeed))
/*     */     {
/* 366 */       if (sslInitialized)
/*     */       {
/* 368 */         throw new IllegalStateException(sm.getString("aprListener.tooLateForSSLRandomSeed"));
/*     */       }
/*     */       
/* 371 */       SSLRandomSeed = SSLRandomSeed;
/*     */     }
/*     */   }
/*     */   
/*     */   public String getFIPSMode() {
/* 376 */     return FIPSMode;
/*     */   }
/*     */   
/*     */   public void setFIPSMode(String FIPSMode) {
/* 380 */     if (!FIPSMode.equals(FIPSMode))
/*     */     {
/* 382 */       if (sslInitialized)
/*     */       {
/* 384 */         throw new IllegalStateException(sm.getString("aprListener.tooLateForFIPSMode"));
/*     */       }
/*     */       
/* 387 */       FIPSMode = FIPSMode;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isFIPSModeActive() {
/* 392 */     return fipsModeActive;
/*     */   }
/*     */   
/*     */   public void setUseAprConnector(boolean useAprConnector) {
/* 396 */     if (useAprConnector != AprStatus.getUseAprConnector()) {
/* 397 */       AprStatus.setUseAprConnector(useAprConnector);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean getUseAprConnector() {
/* 402 */     return AprStatus.getUseAprConnector();
/*     */   }
/*     */   
/*     */   public void setUseOpenSSL(boolean useOpenSSL) {
/* 406 */     if (useOpenSSL != AprStatus.getUseOpenSSL()) {
/* 407 */       AprStatus.setUseOpenSSL(useOpenSSL);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean getUseOpenSSL() {
/* 412 */     return AprStatus.getUseOpenSSL();
/*     */   }
/*     */   
/*     */   public static boolean isInstanceCreated() {
/* 416 */     return AprStatus.isInstanceCreated();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\AprLifecycleListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */