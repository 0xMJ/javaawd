/*     */ package org.apache.catalina.security;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecurityClassLoad
/*     */ {
/*     */   public static void securityClassLoad(ClassLoader loader)
/*     */     throws Exception
/*     */   {
/*  29 */     securityClassLoad(loader, true);
/*     */   }
/*     */   
/*     */   static void securityClassLoad(ClassLoader loader, boolean requireSecurityManager)
/*     */     throws Exception
/*     */   {
/*  35 */     if ((requireSecurityManager) && (System.getSecurityManager() == null)) {
/*  36 */       return;
/*     */     }
/*     */     
/*  39 */     loadCorePackage(loader);
/*  40 */     loadCoyotePackage(loader);
/*  41 */     loadLoaderPackage(loader);
/*  42 */     loadRealmPackage(loader);
/*  43 */     loadServletsPackage(loader);
/*  44 */     loadSessionPackage(loader);
/*  45 */     loadUtilPackage(loader);
/*  46 */     loadJavaxPackage(loader);
/*  47 */     loadConnectorPackage(loader);
/*  48 */     loadTomcatPackage(loader);
/*     */   }
/*     */   
/*     */   private static final void loadCorePackage(ClassLoader loader) throws Exception
/*     */   {
/*  53 */     String basePackage = "org.apache.catalina.core.";
/*  54 */     loader.loadClass("org.apache.catalina.core.AccessLogAdapter");
/*  55 */     loader.loadClass("org.apache.catalina.core.ApplicationContextFacade$PrivilegedExecuteMethod");
/*  56 */     loader.loadClass("org.apache.catalina.core.ApplicationDispatcher$PrivilegedForward");
/*  57 */     loader.loadClass("org.apache.catalina.core.ApplicationDispatcher$PrivilegedInclude");
/*  58 */     loader.loadClass("org.apache.catalina.core.ApplicationPushBuilder");
/*  59 */     loader.loadClass("org.apache.catalina.core.AsyncContextImpl");
/*  60 */     loader.loadClass("org.apache.catalina.core.AsyncContextImpl$AsyncRunnable");
/*  61 */     loader.loadClass("org.apache.catalina.core.AsyncContextImpl$DebugException");
/*  62 */     loader.loadClass("org.apache.catalina.core.AsyncListenerWrapper");
/*  63 */     loader.loadClass("org.apache.catalina.core.ContainerBase$PrivilegedAddChild");
/*  64 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$AnnotationCacheEntry");
/*  65 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$AnnotationCacheEntryType");
/*  66 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$PrivilegedGetField");
/*  67 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$PrivilegedGetMethod");
/*  68 */     loader.loadClass("org.apache.catalina.core.DefaultInstanceManager$PrivilegedLoadClass");
/*  69 */     loader.loadClass("org.apache.catalina.core.ApplicationHttpRequest$AttributeNamesEnumerator");
/*     */   }
/*     */   
/*     */   private static final void loadLoaderPackage(ClassLoader loader) throws Exception
/*     */   {
/*  74 */     String basePackage = "org.apache.catalina.loader.";
/*  75 */     loader.loadClass("org.apache.catalina.loader.WebappClassLoaderBase$PrivilegedFindClassByName");
/*  76 */     loader.loadClass("org.apache.catalina.loader.WebappClassLoaderBase$PrivilegedHasLoggingConfig");
/*     */   }
/*     */   
/*     */   private static final void loadRealmPackage(ClassLoader loader) throws Exception
/*     */   {
/*  81 */     String basePackage = "org.apache.catalina.realm.";
/*  82 */     loader.loadClass("org.apache.catalina.realm.LockOutRealm$LockRecord");
/*     */   }
/*     */   
/*     */   private static final void loadServletsPackage(ClassLoader loader) throws Exception
/*     */   {
/*  87 */     String basePackage = "org.apache.catalina.servlets.";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     loader.loadClass("org.apache.catalina.servlets.DefaultServlet");
/*     */   }
/*     */   
/*     */   private static final void loadSessionPackage(ClassLoader loader) throws Exception
/*     */   {
/*  98 */     String basePackage = "org.apache.catalina.session.";
/*  99 */     loader.loadClass("org.apache.catalina.session.StandardSession");
/* 100 */     loader.loadClass("org.apache.catalina.session.StandardSession$PrivilegedNewSessionFacade");
/* 101 */     loader.loadClass("org.apache.catalina.session.StandardManager$PrivilegedDoUnload");
/*     */   }
/*     */   
/*     */   private static final void loadUtilPackage(ClassLoader loader) throws Exception
/*     */   {
/* 106 */     String basePackage = "org.apache.catalina.util.";
/* 107 */     loader.loadClass("org.apache.catalina.util.ParameterMap");
/* 108 */     loader.loadClass("org.apache.catalina.util.RequestUtil");
/* 109 */     loader.loadClass("org.apache.catalina.util.TLSUtil");
/*     */   }
/*     */   
/*     */   private static final void loadCoyotePackage(ClassLoader loader) throws Exception
/*     */   {
/* 114 */     String basePackage = "org.apache.coyote.";
/* 115 */     loader.loadClass("org.apache.coyote.http11.Constants");
/*     */     
/* 117 */     Class<?> clazz = loader.loadClass("org.apache.coyote.Constants");
/* 118 */     clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 119 */     loader.loadClass("org.apache.coyote.http2.Stream$PrivilegedPush");
/*     */   }
/*     */   
/*     */   private static final void loadJavaxPackage(ClassLoader loader) throws Exception
/*     */   {
/* 124 */     loader.loadClass("javax.servlet.http.Cookie");
/*     */   }
/*     */   
/*     */   private static final void loadConnectorPackage(ClassLoader loader) throws Exception
/*     */   {
/* 129 */     String basePackage = "org.apache.catalina.connector.";
/* 130 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetAttributePrivilegedAction");
/* 131 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetParameterMapPrivilegedAction");
/* 132 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetRequestDispatcherPrivilegedAction");
/* 133 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetParameterPrivilegedAction");
/* 134 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetParameterNamesPrivilegedAction");
/* 135 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetParameterValuePrivilegedAction");
/* 136 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetCharacterEncodingPrivilegedAction");
/* 137 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetHeadersPrivilegedAction");
/* 138 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetHeaderNamesPrivilegedAction");
/* 139 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetCookiesPrivilegedAction");
/* 140 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetLocalePrivilegedAction");
/* 141 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetLocalesPrivilegedAction");
/* 142 */     loader.loadClass("org.apache.catalina.connector.ResponseFacade$SetContentTypePrivilegedAction");
/* 143 */     loader.loadClass("org.apache.catalina.connector.ResponseFacade$DateHeaderPrivilegedAction");
/* 144 */     loader.loadClass("org.apache.catalina.connector.RequestFacade$GetSessionPrivilegedAction");
/* 145 */     loader.loadClass("org.apache.catalina.connector.ResponseFacade$FlushBufferPrivilegedAction");
/* 146 */     loader.loadClass("org.apache.catalina.connector.OutputBuffer$PrivilegedCreateConverter");
/* 147 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$PrivilegedAvailable");
/* 148 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$PrivilegedClose");
/* 149 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$PrivilegedRead");
/* 150 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$PrivilegedReadArray");
/* 151 */     loader.loadClass("org.apache.catalina.connector.CoyoteInputStream$PrivilegedReadBuffer");
/* 152 */     loader.loadClass("org.apache.catalina.connector.CoyoteOutputStream");
/* 153 */     loader.loadClass("org.apache.catalina.connector.InputBuffer$PrivilegedCreateConverter");
/* 154 */     loader.loadClass("org.apache.catalina.connector.Response$PrivilegedDoIsEncodable");
/* 155 */     loader.loadClass("org.apache.catalina.connector.Response$PrivilegedGenerateCookieString");
/* 156 */     loader.loadClass("org.apache.catalina.connector.Response$PrivilegedEncodeUrl");
/*     */   }
/*     */   
/*     */   private static final void loadTomcatPackage(ClassLoader loader) throws Exception
/*     */   {
/* 161 */     String basePackage = "org.apache.tomcat.";
/*     */     
/* 163 */     loader.loadClass("org.apache.tomcat.util.buf.B2CConverter");
/* 164 */     loader.loadClass("org.apache.tomcat.util.buf.ByteBufferUtils");
/* 165 */     loader.loadClass("org.apache.tomcat.util.buf.C2BConverter");
/* 166 */     loader.loadClass("org.apache.tomcat.util.buf.HexUtils");
/* 167 */     loader.loadClass("org.apache.tomcat.util.buf.StringCache");
/* 168 */     loader.loadClass("org.apache.tomcat.util.buf.StringCache$ByteEntry");
/* 169 */     loader.loadClass("org.apache.tomcat.util.buf.StringCache$CharEntry");
/* 170 */     loader.loadClass("org.apache.tomcat.util.buf.UriUtil");
/*     */     
/* 172 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap");
/* 173 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap$EntryImpl");
/* 174 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap$EntryIterator");
/* 175 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap$EntrySet");
/* 176 */     loader.loadClass("org.apache.tomcat.util.collections.CaseInsensitiveKeyMap$Key");
/*     */     
/* 178 */     loader.loadClass("org.apache.tomcat.util.http.CookieProcessor");
/* 179 */     loader.loadClass("org.apache.tomcat.util.http.NamesEnumerator");
/*     */     
/* 181 */     Class<?> clazz = loader.loadClass("org.apache.tomcat.util.http.FastHttpDateFormat");
/* 182 */     clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 183 */     loader.loadClass("org.apache.tomcat.util.http.parser.HttpParser");
/* 184 */     loader.loadClass("org.apache.tomcat.util.http.parser.MediaType");
/* 185 */     loader.loadClass("org.apache.tomcat.util.http.parser.MediaTypeCache");
/* 186 */     loader.loadClass("org.apache.tomcat.util.http.parser.SkipResult");
/*     */     
/* 188 */     loader.loadClass("org.apache.tomcat.util.net.Constants");
/* 189 */     loader.loadClass("org.apache.tomcat.util.net.DispatchType");
/* 190 */     loader.loadClass("org.apache.tomcat.util.net.AprEndpoint$AprSocketWrapper$AprOperationState");
/* 191 */     loader.loadClass("org.apache.tomcat.util.net.NioEndpoint$NioSocketWrapper$NioOperationState");
/* 192 */     loader.loadClass("org.apache.tomcat.util.net.Nio2Endpoint$Nio2SocketWrapper$Nio2OperationState");
/* 193 */     loader.loadClass("org.apache.tomcat.util.net.SocketWrapperBase$BlockingMode");
/* 194 */     loader.loadClass("org.apache.tomcat.util.net.SocketWrapperBase$CompletionCheck");
/* 195 */     loader.loadClass("org.apache.tomcat.util.net.SocketWrapperBase$CompletionHandlerCall");
/* 196 */     loader.loadClass("org.apache.tomcat.util.net.SocketWrapperBase$CompletionState");
/* 197 */     loader.loadClass("org.apache.tomcat.util.net.SocketWrapperBase$VectoredIOCompletionHandler");
/* 198 */     loader.loadClass("org.apache.tomcat.util.net.TLSClientHelloExtractor");
/* 199 */     loader.loadClass("org.apache.tomcat.util.net.TLSClientHelloExtractor$ExtractorResult");
/*     */     
/* 201 */     loader.loadClass("org.apache.tomcat.util.security.PrivilegedGetTccl");
/* 202 */     loader.loadClass("org.apache.tomcat.util.security.PrivilegedSetTccl");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\security\SecurityClassLoad.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */