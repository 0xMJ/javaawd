/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.apache.catalina.Container;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.tomcat.util.digester.Digester;
/*    */ import org.apache.tomcat.util.digester.Rule;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CopyParentClassLoaderRule
/*    */   extends Rule
/*    */ {
/*    */   public void begin(String namespace, String name, Attributes attributes)
/*    */     throws Exception
/*    */   {
/* 62 */     if (this.digester.getLogger().isDebugEnabled()) {
/* 63 */       this.digester.getLogger().debug("Copying parent class loader");
/*    */     }
/* 65 */     Container child = (Container)this.digester.peek(0);
/* 66 */     Object parent = this.digester.peek(1);
/*    */     
/* 68 */     Method method = parent.getClass().getMethod("getParentClassLoader", new Class[0]);
/*    */     
/* 70 */     ClassLoader classLoader = (ClassLoader)method.invoke(parent, new Object[0]);
/* 71 */     child.setParentClassLoader(classLoader);
/*    */     
/* 73 */     StringBuilder code = this.digester.getGeneratedCode();
/* 74 */     if (code != null) {
/* 75 */       code.append(this.digester.toVariableName(child)).append(".setParentClassLoader(");
/* 76 */       code.append(this.digester.toVariableName(parent)).append(".getParentClassLoader());");
/* 77 */       code.append(System.lineSeparator());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\CopyParentClassLoaderRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */