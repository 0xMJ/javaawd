/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLWriter
/*     */ {
/*     */   public static final int OPENING = 0;
/*     */   public static final int CLOSING = 1;
/*     */   public static final int NO_CONTENT = 2;
/*  55 */   protected StringBuilder buffer = new StringBuilder();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Writer writer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLWriter()
/*     */   {
/*  71 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XMLWriter(Writer writer)
/*     */   {
/*  84 */     this.writer = writer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  98 */     return this.buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeProperty(String namespace, String name, String value)
/*     */   {
/* 110 */     writeElement(namespace, name, 0);
/* 111 */     this.buffer.append(value);
/* 112 */     writeElement(namespace, name, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeElement(String namespace, String name, int type)
/*     */   {
/* 124 */     writeElement(namespace, null, name, type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeElement(String namespace, String namespaceInfo, String name, int type)
/*     */   {
/* 138 */     if ((namespace != null) && (namespace.length() > 0)) {}
/* 139 */     switch (type) {
/*     */     case 0: 
/* 141 */       if (namespaceInfo != null) {
/* 142 */         this.buffer.append("<" + namespace + ":" + name + " xmlns:" + namespace + "=\"" + namespaceInfo + "\">");
/*     */       }
/*     */       else
/*     */       {
/* 146 */         this.buffer.append("<" + namespace + ":" + name + ">");
/*     */       }
/* 148 */       break;
/*     */     case 1: 
/* 150 */       this.buffer.append("</" + namespace + ":" + name + ">\n");
/* 151 */       break;
/*     */     case 2: 
/*     */     default: 
/* 154 */       if (namespaceInfo != null) {
/* 155 */         this.buffer.append("<" + namespace + ":" + name + " xmlns:" + namespace + "=\"" + namespaceInfo + "\"/>");
/*     */       }
/*     */       else
/*     */       {
/* 159 */         this.buffer.append("<" + namespace + ":" + name + "/>");
/*     */         
/* 161 */         break;
/*     */         
/*     */ 
/* 164 */         switch (type) {
/*     */         case 0: 
/* 166 */           this.buffer.append("<" + name + ">");
/* 167 */           break;
/*     */         case 1: 
/* 169 */           this.buffer.append("</" + name + ">\n");
/* 170 */           break;
/*     */         case 2: 
/*     */         default: 
/* 173 */           this.buffer.append("<" + name + "/>");
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeText(String text)
/*     */   {
/* 186 */     this.buffer.append(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeData(String data)
/*     */   {
/* 196 */     this.buffer.append("<![CDATA[" + data + "]]>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeXMLHeader()
/*     */   {
/* 204 */     this.buffer.append("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sendData()
/*     */     throws IOException
/*     */   {
/* 214 */     if (this.writer != null) {
/* 215 */       this.writer.write(this.buffer.toString());
/* 216 */       this.buffer = new StringBuilder();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\XMLWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */