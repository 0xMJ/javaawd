/*     */ package org.apache.catalina.authenticator.jaspic;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.message.AuthException;
/*     */ import javax.security.auth.message.MessageInfo;
/*     */ import javax.security.auth.message.config.ServerAuthConfig;
/*     */ import javax.security.auth.message.config.ServerAuthContext;
/*     */ import javax.security.auth.message.module.ServerAuthModule;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleServerAuthConfig
/*     */   implements ServerAuthConfig
/*     */ {
/*  42 */   private static StringManager sm = StringManager.getManager(SimpleServerAuthConfig.class);
/*     */   
/*     */   private static final String SERVER_AUTH_MODULE_KEY_PREFIX = "org.apache.catalina.authenticator.jaspic.ServerAuthModule.";
/*     */   
/*     */   private final String layer;
/*     */   
/*     */   private final String appContext;
/*     */   
/*     */   private final CallbackHandler handler;
/*     */   private final Map<String, String> properties;
/*     */   private volatile ServerAuthContext serverAuthContext;
/*     */   
/*     */   public SimpleServerAuthConfig(String layer, String appContext, CallbackHandler handler, Map<String, String> properties)
/*     */   {
/*  56 */     this.layer = layer;
/*  57 */     this.appContext = appContext;
/*  58 */     this.handler = handler;
/*  59 */     this.properties = properties;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getMessageLayer()
/*     */   {
/*  65 */     return this.layer;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getAppContext()
/*     */   {
/*  71 */     return this.appContext;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getAuthContextID(MessageInfo messageInfo)
/*     */   {
/*  77 */     return messageInfo.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public void refresh()
/*     */   {
/*  83 */     this.serverAuthContext = null;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isProtected()
/*     */   {
/*  89 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ServerAuthContext getAuthContext(String authContextID, Subject serviceSubject, Map properties)
/*     */     throws AuthException
/*     */   {
/*  97 */     ServerAuthContext serverAuthContext = this.serverAuthContext;
/*  98 */     if (serverAuthContext == null) {
/*  99 */       synchronized (this) {
/* 100 */         if (this.serverAuthContext == null) {
/* 101 */           Map<String, String> mergedProperties = new HashMap();
/* 102 */           if (this.properties != null) {
/* 103 */             mergedProperties.putAll(this.properties);
/*     */           }
/* 105 */           if (properties != null) {
/* 106 */             mergedProperties.putAll(properties);
/*     */           }
/*     */           
/* 109 */           List<ServerAuthModule> modules = new ArrayList();
/* 110 */           int moduleIndex = 1;
/* 111 */           String key = "org.apache.catalina.authenticator.jaspic.ServerAuthModule." + moduleIndex;
/* 112 */           String moduleClassName = (String)mergedProperties.get(key);
/* 113 */           while (moduleClassName != null) {
/*     */             try {
/* 115 */               Class<?> clazz = Class.forName(moduleClassName);
/*     */               
/* 117 */               ServerAuthModule module = (ServerAuthModule)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 118 */               module.initialize(null, null, this.handler, mergedProperties);
/* 119 */               modules.add(module);
/*     */             }
/*     */             catch (ReflectiveOperationException|IllegalArgumentException|SecurityException e) {
/* 122 */               AuthException ae = new AuthException();
/* 123 */               ae.initCause(e);
/* 124 */               throw ae;
/*     */             }
/*     */             
/*     */ 
/* 128 */             moduleIndex++;
/* 129 */             key = "org.apache.catalina.authenticator.jaspic.ServerAuthModule." + moduleIndex;
/* 130 */             moduleClassName = (String)mergedProperties.get(key);
/*     */           }
/*     */           
/* 133 */           if (modules.size() == 0) {
/* 134 */             throw new AuthException(sm.getString("simpleServerAuthConfig.noModules"));
/*     */           }
/*     */           
/* 137 */           this.serverAuthContext = createServerAuthContext(modules);
/*     */         }
/* 139 */         serverAuthContext = this.serverAuthContext;
/*     */       }
/*     */     }
/*     */     
/* 143 */     return serverAuthContext;
/*     */   }
/*     */   
/*     */   protected ServerAuthContext createServerAuthContext(List<ServerAuthModule> modules)
/*     */   {
/* 148 */     return new SimpleServerAuthContext(modules);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\authenticator\jaspic\SimpleServerAuthConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */