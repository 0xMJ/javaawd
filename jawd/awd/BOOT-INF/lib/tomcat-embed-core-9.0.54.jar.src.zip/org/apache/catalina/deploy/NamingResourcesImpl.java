/*      */ package org.apache.catalina.deploy;
/*      */ 
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.naming.NamingException;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.JmxEnabled;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.mbeans.MBeanUtils;
/*      */ import org.apache.catalina.util.Introspection;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.naming.ContextBindings;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextLocalEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResourceLink;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextService;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextTransaction;
/*      */ import org.apache.tomcat.util.descriptor.web.InjectionTarget;
/*      */ import org.apache.tomcat.util.descriptor.web.MessageDestinationRef;
/*      */ import org.apache.tomcat.util.descriptor.web.NamingResources;
/*      */ import org.apache.tomcat.util.descriptor.web.ResourceBase;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NamingResourcesImpl
/*      */   extends LifecycleMBeanBase
/*      */   implements Serializable, NamingResources
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   73 */   private static final Log log = LogFactory.getLog(NamingResourcesImpl.class);
/*      */   
/*   75 */   private static final StringManager sm = StringManager.getManager(NamingResourcesImpl.class);
/*      */   
/*   77 */   private volatile boolean resourceRequireExplicitRegistration = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   96 */   private Object container = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  102 */   private final Set<String> entries = new HashSet();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  108 */   private final Map<String, ContextEjb> ejbs = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  114 */   private final Map<String, ContextEnvironment> envs = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  121 */   private final Map<String, ContextLocalEjb> localEjbs = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  128 */   private final Map<String, MessageDestinationRef> mdrs = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  135 */   private final HashMap<String, ContextResourceEnvRef> resourceEnvRefs = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  142 */   private final HashMap<String, ContextResource> resources = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  149 */   private final HashMap<String, ContextResourceLink> resourceLinks = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  156 */   private final HashMap<String, ContextService> services = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  163 */   private ContextTransaction transaction = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  169 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getContainer()
/*      */   {
/*  181 */     return this.container;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContainer(Object container)
/*      */   {
/*  190 */     this.container = container;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTransaction(ContextTransaction transaction)
/*      */   {
/*  199 */     this.transaction = transaction;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ContextTransaction getTransaction()
/*      */   {
/*  207 */     return this.transaction;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addEjb(ContextEjb ejb)
/*      */   {
/*  219 */     String ejbLink = ejb.getLink();
/*  220 */     String lookupName = ejb.getLookupName();
/*      */     
/*  222 */     if ((ejbLink != null) && (ejbLink.length() > 0) && (lookupName != null) && (lookupName.length() > 0))
/*      */     {
/*  224 */       throw new IllegalArgumentException(sm.getString("namingResources.ejbLookupLink", new Object[] {ejb.getName() }));
/*      */     }
/*      */     
/*  227 */     if (this.entries.contains(ejb.getName())) {
/*  228 */       return;
/*      */     }
/*  230 */     this.entries.add(ejb.getName());
/*      */     
/*      */ 
/*  233 */     synchronized (this.ejbs) {
/*  234 */       ejb.setNamingResources(this);
/*  235 */       this.ejbs.put(ejb.getName(), ejb);
/*      */     }
/*  237 */     this.support.firePropertyChange("ejb", null, ejb);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addEnvironment(ContextEnvironment environment)
/*      */   {
/*  250 */     if (this.entries.contains(environment.getName())) {
/*  251 */       ContextEnvironment ce = findEnvironment(environment.getName());
/*  252 */       ContextResourceLink rl = findResourceLink(environment.getName());
/*  253 */       if (ce != null) {
/*  254 */         if (ce.getOverride()) {
/*  255 */           removeEnvironment(environment.getName());
/*      */         }
/*      */         
/*      */       }
/*  259 */       else if (rl != null)
/*      */       {
/*  261 */         NamingResourcesImpl global = getServer().getGlobalNamingResources();
/*  262 */         if (global.findEnvironment(rl.getGlobal()) != null) {
/*  263 */           if (global.findEnvironment(rl.getGlobal()).getOverride()) {
/*  264 */             removeResourceLink(environment.getName());
/*      */           } else {
/*  266 */             return;
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/*  271 */         return;
/*      */       }
/*      */     }
/*      */     
/*  275 */     List<InjectionTarget> injectionTargets = environment.getInjectionTargets();
/*  276 */     String value = environment.getValue();
/*  277 */     String lookupName = environment.getLookupName();
/*      */     
/*      */ 
/*  280 */     if ((injectionTargets != null) && (injectionTargets.size() > 0) && ((value == null) || 
/*  281 */       (value.length() == 0))) {
/*  282 */       return;
/*      */     }
/*      */     
/*      */ 
/*  286 */     if ((value != null) && (value.length() > 0) && (lookupName != null) && (lookupName.length() > 0))
/*      */     {
/*  288 */       throw new IllegalArgumentException(sm.getString("namingResources.envEntryLookupValue", new Object[] {environment.getName() }));
/*      */     }
/*      */     
/*  291 */     if (!checkResourceType(environment)) {
/*  292 */       throw new IllegalArgumentException(sm.getString("namingResources.resourceTypeFail", new Object[] {environment
/*  293 */         .getName(), environment
/*  294 */         .getType() }));
/*      */     }
/*      */     
/*  297 */     this.entries.add(environment.getName());
/*      */     
/*  299 */     synchronized (this.envs) {
/*  300 */       environment.setNamingResources(this);
/*  301 */       this.envs.put(environment.getName(), environment);
/*      */     }
/*  303 */     this.support.firePropertyChange("environment", null, environment);
/*      */     
/*      */ 
/*  306 */     if (this.resourceRequireExplicitRegistration) {
/*      */       try {
/*  308 */         MBeanUtils.createMBean(environment);
/*      */       } catch (Exception e) {
/*  310 */         log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] {environment
/*  311 */           .getName() }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private Server getServer()
/*      */   {
/*  319 */     if ((this.container instanceof Server)) {
/*  320 */       return (Server)this.container;
/*      */     }
/*  322 */     if ((this.container instanceof org.apache.catalina.Context))
/*      */     {
/*      */ 
/*  325 */       Engine engine = (Engine)((org.apache.catalina.Context)this.container).getParent().getParent();
/*  326 */       return engine.getService().getServer();
/*      */     }
/*  328 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addLocalEjb(ContextLocalEjb ejb)
/*      */   {
/*  338 */     if (this.entries.contains(ejb.getName())) {
/*  339 */       return;
/*      */     }
/*  341 */     this.entries.add(ejb.getName());
/*      */     
/*      */ 
/*  344 */     synchronized (this.localEjbs) {
/*  345 */       ejb.setNamingResources(this);
/*  346 */       this.localEjbs.put(ejb.getName(), ejb);
/*      */     }
/*  348 */     this.support.firePropertyChange("localEjb", null, ejb);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addMessageDestinationRef(MessageDestinationRef mdr)
/*      */   {
/*  360 */     if (this.entries.contains(mdr.getName())) {
/*  361 */       return;
/*      */     }
/*  363 */     if (!checkResourceType(mdr)) {
/*  364 */       throw new IllegalArgumentException(sm.getString("namingResources.resourceTypeFail", new Object[] {mdr
/*  365 */         .getName(), mdr
/*  366 */         .getType() }));
/*      */     }
/*  368 */     this.entries.add(mdr.getName());
/*      */     
/*      */ 
/*  371 */     synchronized (this.mdrs) {
/*  372 */       mdr.setNamingResources(this);
/*  373 */       this.mdrs.put(mdr.getName(), mdr);
/*      */     }
/*  375 */     this.support.firePropertyChange("messageDestinationRef", null, mdr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/*  387 */     this.support.addPropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResource(ContextResource resource)
/*      */   {
/*  400 */     if (this.entries.contains(resource.getName())) {
/*  401 */       return;
/*      */     }
/*  403 */     if (!checkResourceType(resource)) {
/*  404 */       throw new IllegalArgumentException(sm.getString("namingResources.resourceTypeFail", new Object[] {resource
/*  405 */         .getName(), resource
/*  406 */         .getType() }));
/*      */     }
/*  408 */     this.entries.add(resource.getName());
/*      */     
/*      */ 
/*  411 */     synchronized (this.resources) {
/*  412 */       resource.setNamingResources(this);
/*  413 */       this.resources.put(resource.getName(), resource);
/*      */     }
/*  415 */     this.support.firePropertyChange("resource", null, resource);
/*      */     
/*      */ 
/*  418 */     if (this.resourceRequireExplicitRegistration) {
/*      */       try {
/*  420 */         MBeanUtils.createMBean(resource);
/*      */       } catch (Exception e) {
/*  422 */         log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] {resource
/*  423 */           .getName() }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResourceEnvRef(ContextResourceEnvRef resource)
/*      */   {
/*  436 */     if (this.entries.contains(resource.getName())) {
/*  437 */       return;
/*      */     }
/*  439 */     if (!checkResourceType(resource)) {
/*  440 */       throw new IllegalArgumentException(sm.getString("namingResources.resourceTypeFail", new Object[] {resource
/*  441 */         .getName(), resource
/*  442 */         .getType() }));
/*      */     }
/*  444 */     this.entries.add(resource.getName());
/*      */     
/*      */ 
/*  447 */     synchronized (this.resourceEnvRefs) {
/*  448 */       resource.setNamingResources(this);
/*  449 */       this.resourceEnvRefs.put(resource.getName(), resource);
/*      */     }
/*  451 */     this.support.firePropertyChange("resourceEnvRef", null, resource);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResourceLink(ContextResourceLink resourceLink)
/*      */   {
/*  464 */     if (this.entries.contains(resourceLink.getName())) {
/*  465 */       return;
/*      */     }
/*  467 */     this.entries.add(resourceLink.getName());
/*      */     
/*      */ 
/*  470 */     synchronized (this.resourceLinks) {
/*  471 */       resourceLink.setNamingResources(this);
/*  472 */       this.resourceLinks.put(resourceLink.getName(), resourceLink);
/*      */     }
/*  474 */     this.support.firePropertyChange("resourceLink", null, resourceLink);
/*      */     
/*      */ 
/*  477 */     if (this.resourceRequireExplicitRegistration) {
/*      */       try {
/*  479 */         MBeanUtils.createMBean(resourceLink);
/*      */       } catch (Exception e) {
/*  481 */         log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] {resourceLink
/*  482 */           .getName() }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addService(ContextService service)
/*      */   {
/*  495 */     if (this.entries.contains(service.getName())) {
/*  496 */       return;
/*      */     }
/*  498 */     this.entries.add(service.getName());
/*      */     
/*      */ 
/*  501 */     synchronized (this.services) {
/*  502 */       service.setNamingResources(this);
/*  503 */       this.services.put(service.getName(), service);
/*      */     }
/*  505 */     this.support.firePropertyChange("service", null, service);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ContextEjb findEjb(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 9	org/apache/catalina/deploy/NamingResourcesImpl:ejbs	Ljava/util/Map;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 9	org/apache/catalina/deploy/NamingResourcesImpl:ejbs	Ljava/util/Map;
/*      */     //   11: aload_1
/*      */     //   12: invokeinterface 93 2 0
/*      */     //   17: checkcast 94	org/apache/tomcat/util/descriptor/web/ContextEjb
/*      */     //   20: aload_2
/*      */     //   21: monitorexit
/*      */     //   22: areturn
/*      */     //   23: astore_3
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: aload_3
/*      */     //   27: athrow
/*      */     // Line number table:
/*      */     //   Java source line #518	-> byte code offset #0
/*      */     //   Java source line #519	-> byte code offset #7
/*      */     //   Java source line #520	-> byte code offset #23
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	28	0	this	NamingResourcesImpl
/*      */     //   0	28	1	name	String
/*      */     //   5	20	2	Ljava/lang/Object;	Object
/*      */     //   23	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	22	23	finally
/*      */     //   23	26	23	finally
/*      */   }
/*      */   
/*      */   public ContextEjb[] findEjbs()
/*      */   {
/*  531 */     synchronized (this.ejbs) {
/*  532 */       ContextEjb[] results = new ContextEjb[this.ejbs.size()];
/*  533 */       return (ContextEjb[])this.ejbs.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ContextEnvironment findEnvironment(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 10	org/apache/catalina/deploy/NamingResourcesImpl:envs	Ljava/util/Map;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 10	org/apache/catalina/deploy/NamingResourcesImpl:envs	Ljava/util/Map;
/*      */     //   11: aload_1
/*      */     //   12: invokeinterface 93 2 0
/*      */     //   17: checkcast 99	org/apache/tomcat/util/descriptor/web/ContextEnvironment
/*      */     //   20: aload_2
/*      */     //   21: monitorexit
/*      */     //   22: areturn
/*      */     //   23: astore_3
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: aload_3
/*      */     //   27: athrow
/*      */     // Line number table:
/*      */     //   Java source line #547	-> byte code offset #0
/*      */     //   Java source line #548	-> byte code offset #7
/*      */     //   Java source line #549	-> byte code offset #23
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	28	0	this	NamingResourcesImpl
/*      */     //   0	28	1	name	String
/*      */     //   5	20	2	Ljava/lang/Object;	Object
/*      */     //   23	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	22	23	finally
/*      */     //   23	26	23	finally
/*      */   }
/*      */   
/*      */   public ContextEnvironment[] findEnvironments()
/*      */   {
/*  561 */     synchronized (this.envs) {
/*  562 */       ContextEnvironment[] results = new ContextEnvironment[this.envs.size()];
/*  563 */       return (ContextEnvironment[])this.envs.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ContextLocalEjb findLocalEjb(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 11	org/apache/catalina/deploy/NamingResourcesImpl:localEjbs	Ljava/util/Map;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 11	org/apache/catalina/deploy/NamingResourcesImpl:localEjbs	Ljava/util/Map;
/*      */     //   11: aload_1
/*      */     //   12: invokeinterface 93 2 0
/*      */     //   17: checkcast 101	org/apache/tomcat/util/descriptor/web/ContextLocalEjb
/*      */     //   20: aload_2
/*      */     //   21: monitorexit
/*      */     //   22: areturn
/*      */     //   23: astore_3
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: aload_3
/*      */     //   27: athrow
/*      */     // Line number table:
/*      */     //   Java source line #577	-> byte code offset #0
/*      */     //   Java source line #578	-> byte code offset #7
/*      */     //   Java source line #579	-> byte code offset #23
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	28	0	this	NamingResourcesImpl
/*      */     //   0	28	1	name	String
/*      */     //   5	20	2	Ljava/lang/Object;	Object
/*      */     //   23	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	22	23	finally
/*      */     //   23	26	23	finally
/*      */   }
/*      */   
/*      */   public ContextLocalEjb[] findLocalEjbs()
/*      */   {
/*  590 */     synchronized (this.localEjbs) {
/*  591 */       ContextLocalEjb[] results = new ContextLocalEjb[this.localEjbs.size()];
/*  592 */       return (ContextLocalEjb[])this.localEjbs.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public MessageDestinationRef findMessageDestinationRef(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 12	org/apache/catalina/deploy/NamingResourcesImpl:mdrs	Ljava/util/Map;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 12	org/apache/catalina/deploy/NamingResourcesImpl:mdrs	Ljava/util/Map;
/*      */     //   11: aload_1
/*      */     //   12: invokeinterface 93 2 0
/*      */     //   17: checkcast 103	org/apache/tomcat/util/descriptor/web/MessageDestinationRef
/*      */     //   20: aload_2
/*      */     //   21: monitorexit
/*      */     //   22: areturn
/*      */     //   23: astore_3
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: aload_3
/*      */     //   27: athrow
/*      */     // Line number table:
/*      */     //   Java source line #606	-> byte code offset #0
/*      */     //   Java source line #607	-> byte code offset #7
/*      */     //   Java source line #608	-> byte code offset #23
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	28	0	this	NamingResourcesImpl
/*      */     //   0	28	1	name	String
/*      */     //   5	20	2	Ljava/lang/Object;	Object
/*      */     //   23	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	22	23	finally
/*      */     //   23	26	23	finally
/*      */   }
/*      */   
/*      */   public MessageDestinationRef[] findMessageDestinationRefs()
/*      */   {
/*  619 */     synchronized (this.mdrs)
/*      */     {
/*  621 */       MessageDestinationRef[] results = new MessageDestinationRef[this.mdrs.size()];
/*  622 */       return (MessageDestinationRef[])this.mdrs.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ContextResource findResource(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 14	org/apache/catalina/deploy/NamingResourcesImpl:resources	Ljava/util/HashMap;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 14	org/apache/catalina/deploy/NamingResourcesImpl:resources	Ljava/util/HashMap;
/*      */     //   11: aload_1
/*      */     //   12: invokevirtual 105	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   15: checkcast 106	org/apache/tomcat/util/descriptor/web/ContextResource
/*      */     //   18: aload_2
/*      */     //   19: monitorexit
/*      */     //   20: areturn
/*      */     //   21: astore_3
/*      */     //   22: aload_2
/*      */     //   23: monitorexit
/*      */     //   24: aload_3
/*      */     //   25: athrow
/*      */     // Line number table:
/*      */     //   Java source line #636	-> byte code offset #0
/*      */     //   Java source line #637	-> byte code offset #7
/*      */     //   Java source line #638	-> byte code offset #21
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	26	0	this	NamingResourcesImpl
/*      */     //   0	26	1	name	String
/*      */     //   5	18	2	Ljava/lang/Object;	Object
/*      */     //   21	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	20	21	finally
/*      */     //   21	24	21	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ContextResourceLink findResourceLink(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 15	org/apache/catalina/deploy/NamingResourcesImpl:resourceLinks	Ljava/util/HashMap;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 15	org/apache/catalina/deploy/NamingResourcesImpl:resourceLinks	Ljava/util/HashMap;
/*      */     //   11: aload_1
/*      */     //   12: invokevirtual 105	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   15: checkcast 107	org/apache/tomcat/util/descriptor/web/ContextResourceLink
/*      */     //   18: aload_2
/*      */     //   19: monitorexit
/*      */     //   20: areturn
/*      */     //   21: astore_3
/*      */     //   22: aload_2
/*      */     //   23: monitorexit
/*      */     //   24: aload_3
/*      */     //   25: athrow
/*      */     // Line number table:
/*      */     //   Java source line #651	-> byte code offset #0
/*      */     //   Java source line #652	-> byte code offset #7
/*      */     //   Java source line #653	-> byte code offset #21
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	26	0	this	NamingResourcesImpl
/*      */     //   0	26	1	name	String
/*      */     //   5	18	2	Ljava/lang/Object;	Object
/*      */     //   21	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	20	21	finally
/*      */     //   21	24	21	finally
/*      */   }
/*      */   
/*      */   public ContextResourceLink[] findResourceLinks()
/*      */   {
/*  664 */     synchronized (this.resourceLinks)
/*      */     {
/*  666 */       ContextResourceLink[] results = new ContextResourceLink[this.resourceLinks.size()];
/*  667 */       return (ContextResourceLink[])this.resourceLinks.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ContextResource[] findResources()
/*      */   {
/*  679 */     synchronized (this.resources) {
/*  680 */       ContextResource[] results = new ContextResource[this.resources.size()];
/*  681 */       return (ContextResource[])this.resources.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ContextResourceEnvRef findResourceEnvRef(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 13	org/apache/catalina/deploy/NamingResourcesImpl:resourceEnvRefs	Ljava/util/HashMap;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 13	org/apache/catalina/deploy/NamingResourcesImpl:resourceEnvRefs	Ljava/util/HashMap;
/*      */     //   11: aload_1
/*      */     //   12: invokevirtual 105	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   15: checkcast 112	org/apache/tomcat/util/descriptor/web/ContextResourceEnvRef
/*      */     //   18: aload_2
/*      */     //   19: monitorexit
/*      */     //   20: areturn
/*      */     //   21: astore_3
/*      */     //   22: aload_2
/*      */     //   23: monitorexit
/*      */     //   24: aload_3
/*      */     //   25: athrow
/*      */     // Line number table:
/*      */     //   Java source line #695	-> byte code offset #0
/*      */     //   Java source line #696	-> byte code offset #7
/*      */     //   Java source line #697	-> byte code offset #21
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	26	0	this	NamingResourcesImpl
/*      */     //   0	26	1	name	String
/*      */     //   5	18	2	Ljava/lang/Object;	Object
/*      */     //   21	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	20	21	finally
/*      */     //   21	24	21	finally
/*      */   }
/*      */   
/*      */   public ContextResourceEnvRef[] findResourceEnvRefs()
/*      */   {
/*  709 */     synchronized (this.resourceEnvRefs) {
/*  710 */       ContextResourceEnvRef[] results = new ContextResourceEnvRef[this.resourceEnvRefs.size()];
/*  711 */       return (ContextResourceEnvRef[])this.resourceEnvRefs.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ContextService findService(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 16	org/apache/catalina/deploy/NamingResourcesImpl:services	Ljava/util/HashMap;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 16	org/apache/catalina/deploy/NamingResourcesImpl:services	Ljava/util/HashMap;
/*      */     //   11: aload_1
/*      */     //   12: invokevirtual 105	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   15: checkcast 114	org/apache/tomcat/util/descriptor/web/ContextService
/*      */     //   18: aload_2
/*      */     //   19: monitorexit
/*      */     //   20: areturn
/*      */     //   21: astore_3
/*      */     //   22: aload_2
/*      */     //   23: monitorexit
/*      */     //   24: aload_3
/*      */     //   25: athrow
/*      */     // Line number table:
/*      */     //   Java source line #725	-> byte code offset #0
/*      */     //   Java source line #726	-> byte code offset #7
/*      */     //   Java source line #727	-> byte code offset #21
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	26	0	this	NamingResourcesImpl
/*      */     //   0	26	1	name	String
/*      */     //   5	18	2	Ljava/lang/Object;	Object
/*      */     //   21	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	20	21	finally
/*      */     //   21	24	21	finally
/*      */   }
/*      */   
/*      */   public ContextService[] findServices()
/*      */   {
/*  738 */     synchronized (this.services) {
/*  739 */       ContextService[] results = new ContextService[this.services.size()];
/*  740 */       return (ContextService[])this.services.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeEjb(String name)
/*      */   {
/*  753 */     this.entries.remove(name);
/*      */     
/*  755 */     ContextEjb ejb = null;
/*  756 */     synchronized (this.ejbs) {
/*  757 */       ejb = (ContextEjb)this.ejbs.remove(name);
/*      */     }
/*  759 */     if (ejb != null) {
/*  760 */       this.support.firePropertyChange("ejb", ejb, null);
/*  761 */       ejb.setNamingResources(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeEnvironment(String name)
/*      */   {
/*  775 */     this.entries.remove(name);
/*      */     
/*  777 */     ContextEnvironment environment = null;
/*  778 */     synchronized (this.envs) {
/*  779 */       environment = (ContextEnvironment)this.envs.remove(name);
/*      */     }
/*  781 */     if (environment != null) {
/*  782 */       this.support.firePropertyChange("environment", environment, null);
/*      */       
/*  784 */       if (this.resourceRequireExplicitRegistration) {
/*      */         try {
/*  786 */           MBeanUtils.destroyMBean(environment);
/*      */         } catch (Exception e) {
/*  788 */           log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] {environment
/*  789 */             .getName() }), e);
/*      */         }
/*      */       }
/*  792 */       environment.setNamingResources(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeLocalEjb(String name)
/*      */   {
/*  804 */     this.entries.remove(name);
/*      */     
/*  806 */     ContextLocalEjb localEjb = null;
/*  807 */     synchronized (this.localEjbs) {
/*  808 */       localEjb = (ContextLocalEjb)this.localEjbs.remove(name);
/*      */     }
/*  810 */     if (localEjb != null) {
/*  811 */       this.support.firePropertyChange("localEjb", localEjb, null);
/*  812 */       localEjb.setNamingResources(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeMessageDestinationRef(String name)
/*      */   {
/*  825 */     this.entries.remove(name);
/*      */     
/*  827 */     MessageDestinationRef mdr = null;
/*  828 */     synchronized (this.mdrs) {
/*  829 */       mdr = (MessageDestinationRef)this.mdrs.remove(name);
/*      */     }
/*  831 */     if (mdr != null) {
/*  832 */       this.support.firePropertyChange("messageDestinationRef", mdr, null);
/*      */       
/*  834 */       mdr.setNamingResources(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/*  847 */     this.support.removePropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeResource(String name)
/*      */   {
/*  860 */     this.entries.remove(name);
/*      */     
/*  862 */     ContextResource resource = null;
/*  863 */     synchronized (this.resources) {
/*  864 */       resource = (ContextResource)this.resources.remove(name);
/*      */     }
/*  866 */     if (resource != null) {
/*  867 */       this.support.firePropertyChange("resource", resource, null);
/*      */       
/*  869 */       if (this.resourceRequireExplicitRegistration) {
/*      */         try {
/*  871 */           MBeanUtils.destroyMBean(resource);
/*      */         } catch (Exception e) {
/*  873 */           log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] {resource
/*  874 */             .getName() }), e);
/*      */         }
/*      */       }
/*  877 */       resource.setNamingResources(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeResourceEnvRef(String name)
/*      */   {
/*  889 */     this.entries.remove(name);
/*      */     
/*  891 */     ContextResourceEnvRef resourceEnvRef = null;
/*  892 */     synchronized (this.resourceEnvRefs)
/*      */     {
/*  894 */       resourceEnvRef = (ContextResourceEnvRef)this.resourceEnvRefs.remove(name);
/*      */     }
/*  896 */     if (resourceEnvRef != null) {
/*  897 */       this.support.firePropertyChange("resourceEnvRef", resourceEnvRef, null);
/*  898 */       resourceEnvRef.setNamingResources(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeResourceLink(String name)
/*      */   {
/*  912 */     this.entries.remove(name);
/*      */     
/*  914 */     ContextResourceLink resourceLink = null;
/*  915 */     synchronized (this.resourceLinks) {
/*  916 */       resourceLink = (ContextResourceLink)this.resourceLinks.remove(name);
/*      */     }
/*  918 */     if (resourceLink != null) {
/*  919 */       this.support.firePropertyChange("resourceLink", resourceLink, null);
/*      */       
/*  921 */       if (this.resourceRequireExplicitRegistration) {
/*      */         try {
/*  923 */           MBeanUtils.destroyMBean(resourceLink);
/*      */         } catch (Exception e) {
/*  925 */           log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] {resourceLink
/*  926 */             .getName() }), e);
/*      */         }
/*      */       }
/*  929 */       resourceLink.setNamingResources(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeService(String name)
/*      */   {
/*  941 */     this.entries.remove(name);
/*      */     
/*  943 */     ContextService service = null;
/*  944 */     synchronized (this.services) {
/*  945 */       service = (ContextService)this.services.remove(name);
/*      */     }
/*  947 */     if (service != null) {
/*  948 */       this.support.firePropertyChange("service", service, null);
/*  949 */       service.setNamingResources(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initInternal()
/*      */     throws LifecycleException
/*      */   {
/*  959 */     super.initInternal();
/*      */     
/*      */ 
/*      */ 
/*  963 */     this.resourceRequireExplicitRegistration = true;
/*      */     
/*  965 */     for (ContextResource cr : this.resources.values()) {
/*      */       try {
/*  967 */         MBeanUtils.createMBean(cr);
/*      */       } catch (Exception e) {
/*  969 */         log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] {cr
/*  970 */           .getName() }), e);
/*      */       }
/*      */     }
/*      */     
/*  974 */     for (ContextEnvironment ce : this.envs.values()) {
/*      */       try {
/*  976 */         MBeanUtils.createMBean(ce);
/*      */       } catch (Exception e) {
/*  978 */         log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] {ce
/*  979 */           .getName() }), e);
/*      */       }
/*      */     }
/*      */     
/*  983 */     for (ContextResourceLink crl : this.resourceLinks.values()) {
/*      */       try {
/*  985 */         MBeanUtils.createMBean(crl);
/*      */       } catch (Exception e) {
/*  987 */         log.warn(sm.getString("namingResources.mbeanCreateFail", new Object[] {crl
/*  988 */           .getName() }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void startInternal()
/*      */     throws LifecycleException
/*      */   {
/*  996 */     fireLifecycleEvent("configure_start", null);
/*  997 */     setState(LifecycleState.STARTING);
/*      */   }
/*      */   
/*      */   protected void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1003 */     cleanUp();
/* 1004 */     setState(LifecycleState.STOPPING);
/* 1005 */     fireLifecycleEvent("configure_stop", null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void cleanUp()
/*      */   {
/* 1012 */     if (this.resources.size() == 0) {
/* 1013 */       return;
/*      */     }
/*      */     try {
/*      */       javax.naming.Context ctxt;
/* 1017 */       if ((this.container instanceof Server)) {
/* 1018 */         ctxt = ((Server)this.container).getGlobalNamingContext();
/*      */       } else {
/* 1020 */         javax.naming.Context ctxt = ContextBindings.getClassLoader();
/* 1021 */         ctxt = (javax.naming.Context)ctxt.lookup("comp/env");
/*      */       }
/*      */     } catch (NamingException e) {
/* 1024 */       log.warn(sm.getString("namingResources.cleanupNoContext", new Object[] { this.container }), e); return;
/*      */     }
/*      */     
/*      */     javax.naming.Context ctxt;
/* 1028 */     for (ContextResource cr : this.resources.values()) {
/* 1029 */       if (cr.getSingleton()) {
/* 1030 */         String closeMethod = cr.getCloseMethod();
/* 1031 */         if ((closeMethod != null) && (closeMethod.length() > 0)) {
/* 1032 */           String name = cr.getName();
/*      */           try
/*      */           {
/* 1035 */             resource = ctxt.lookup(name);
/*      */           } catch (NamingException e) { Object resource;
/* 1037 */             log.warn(sm.getString("namingResources.cleanupNoResource", new Object[] {cr
/*      */             
/* 1039 */               .getName(), this.container }), e); }
/* 1040 */           continue;
/*      */           Object resource;
/* 1042 */           cleanUp(resource, name, closeMethod);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void cleanUp(Object resource, String name, String closeMethod)
/*      */   {
/* 1059 */     Method m = null;
/*      */     try {
/* 1061 */       m = resource.getClass().getMethod(closeMethod, (Class[])null);
/*      */     } catch (SecurityException e) {
/* 1063 */       log.debug(sm.getString("namingResources.cleanupCloseSecurity", new Object[] { closeMethod, name, this.container }));
/*      */       
/* 1065 */       return;
/*      */     } catch (NoSuchMethodException e) {
/* 1067 */       log.debug(sm.getString("namingResources.cleanupNoClose", new Object[] { name, this.container, closeMethod }));
/*      */       
/* 1069 */       return;
/*      */     }
/*      */     try {
/* 1072 */       m.invoke(resource, (Object[])null);
/*      */     } catch (IllegalArgumentException|IllegalAccessException e) {
/* 1074 */       log.warn(sm.getString("namingResources.cleanupCloseFailed", new Object[] { closeMethod, name, this.container }), e);
/*      */     }
/*      */     catch (InvocationTargetException e) {
/* 1077 */       Throwable t = ExceptionUtils.unwrapInvocationTargetException(e);
/* 1078 */       ExceptionUtils.handleThrowable(t);
/* 1079 */       log.warn(sm.getString("namingResources.cleanupCloseFailed", new Object[] { closeMethod, name, this.container }), t);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void destroyInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1089 */     this.resourceRequireExplicitRegistration = false;
/*      */     
/*      */ 
/* 1092 */     for (ContextResourceLink crl : this.resourceLinks.values()) {
/*      */       try {
/* 1094 */         MBeanUtils.destroyMBean(crl);
/*      */       } catch (Exception e) {
/* 1096 */         log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] {crl
/* 1097 */           .getName() }), e);
/*      */       }
/*      */     }
/*      */     
/* 1101 */     for (ContextEnvironment ce : this.envs.values()) {
/*      */       try {
/* 1103 */         MBeanUtils.destroyMBean(ce);
/*      */       } catch (Exception e) {
/* 1105 */         log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] {ce
/* 1106 */           .getName() }), e);
/*      */       }
/*      */     }
/*      */     
/* 1110 */     for (ContextResource cr : this.resources.values()) {
/*      */       try {
/* 1112 */         MBeanUtils.destroyMBean(cr);
/*      */       } catch (Exception e) {
/* 1114 */         log.warn(sm.getString("namingResources.mbeanDestroyFail", new Object[] {cr
/* 1115 */           .getName() }), e);
/*      */       }
/*      */     }
/*      */     
/* 1119 */     super.destroyInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected String getDomainInternal()
/*      */   {
/* 1126 */     Object c = getContainer();
/*      */     
/* 1128 */     if ((c instanceof JmxEnabled)) {
/* 1129 */       return ((JmxEnabled)c).getDomain();
/*      */     }
/*      */     
/* 1132 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   protected String getObjectNameKeyProperties()
/*      */   {
/* 1138 */     Object c = getContainer();
/* 1139 */     if ((c instanceof Container)) {
/* 1140 */       return 
/* 1141 */         "type=NamingResources" + ((Container)c).getMBeanKeyProperties();
/*      */     }
/*      */     
/* 1144 */     return "type=NamingResources";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean checkResourceType(ResourceBase resource)
/*      */   {
/* 1160 */     if (!(this.container instanceof org.apache.catalina.Context))
/*      */     {
/* 1162 */       return true;
/*      */     }
/*      */     
/* 1165 */     if ((resource.getInjectionTargets() == null) || 
/* 1166 */       (resource.getInjectionTargets().size() == 0))
/*      */     {
/* 1168 */       return true;
/*      */     }
/*      */     
/* 1171 */     org.apache.catalina.Context context = (org.apache.catalina.Context)this.container;
/*      */     
/* 1173 */     String typeName = resource.getType();
/* 1174 */     Class<?> typeClass = null;
/* 1175 */     if (typeName != null) {
/* 1176 */       typeClass = Introspection.loadClass(context, typeName);
/* 1177 */       if (typeClass == null)
/*      */       {
/*      */ 
/* 1180 */         return true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1185 */     Class<?> compatibleClass = getCompatibleType(context, resource, typeClass);
/* 1186 */     if (compatibleClass == null)
/*      */     {
/*      */ 
/* 1189 */       return false;
/*      */     }
/*      */     
/* 1192 */     resource.setType(compatibleClass.getCanonicalName());
/* 1193 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   private Class<?> getCompatibleType(org.apache.catalina.Context context, ResourceBase resource, Class<?> typeClass)
/*      */   {
/* 1199 */     Class<?> result = null;
/*      */     
/* 1201 */     for (InjectionTarget injectionTarget : resource.getInjectionTargets()) {
/* 1202 */       Class<?> clazz = Introspection.loadClass(context, injectionTarget
/* 1203 */         .getTargetClass());
/* 1204 */       if (clazz != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1210 */         String targetName = injectionTarget.getTargetName();
/*      */         
/* 1212 */         Class<?> targetType = getSetterType(clazz, targetName);
/* 1213 */         if (targetType == null)
/*      */         {
/* 1215 */           targetType = getFieldType(clazz, targetName);
/*      */         }
/* 1217 */         if (targetType != null)
/*      */         {
/*      */ 
/*      */ 
/* 1221 */           targetType = Introspection.convertPrimitiveType(targetType);
/*      */           
/* 1223 */           if (typeClass == null)
/*      */           {
/* 1225 */             if (result == null) {
/* 1226 */               result = targetType;
/* 1227 */             } else if (!targetType.isAssignableFrom(result))
/*      */             {
/* 1229 */               if (result.isAssignableFrom(targetType))
/*      */               {
/* 1231 */                 result = targetType;
/*      */               }
/*      */               else {
/* 1234 */                 return null;
/*      */               }
/*      */               
/*      */             }
/*      */           }
/* 1239 */           else if (targetType.isAssignableFrom(typeClass)) {
/* 1240 */             result = typeClass;
/*      */           }
/*      */           else
/* 1243 */             return null;
/*      */         }
/*      */       }
/*      */     }
/* 1247 */     return result;
/*      */   }
/*      */   
/*      */   private Class<?> getSetterType(Class<?> clazz, String name) {
/* 1251 */     Method[] methods = Introspection.getDeclaredMethods(clazz);
/* 1252 */     if ((methods != null) && (methods.length > 0)) {
/* 1253 */       for (Method method : methods) {
/* 1254 */         if ((Introspection.isValidSetter(method)) && 
/* 1255 */           (Introspection.getPropertyName(method).equals(name))) {
/* 1256 */           return method.getParameterTypes()[0];
/*      */         }
/*      */       }
/*      */     }
/* 1260 */     return null;
/*      */   }
/*      */   
/*      */   private Class<?> getFieldType(Class<?> clazz, String name) {
/* 1264 */     Field[] fields = Introspection.getDeclaredFields(clazz);
/* 1265 */     if ((fields != null) && (fields.length > 0)) {
/* 1266 */       for (Field field : fields) {
/* 1267 */         if (field.getName().equals(name)) {
/* 1268 */           return field.getType();
/*      */         }
/*      */       }
/*      */     }
/* 1272 */     return null;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\deploy\NamingResourcesImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */