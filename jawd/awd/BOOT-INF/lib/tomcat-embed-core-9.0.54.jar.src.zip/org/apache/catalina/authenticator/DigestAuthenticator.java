/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.Principal;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.util.SessionIdGeneratorBase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.http.MimeHeaders;
/*     */ import org.apache.tomcat.util.http.parser.Authorization;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.security.ConcurrentMessageDigest;
/*     */ import org.apache.tomcat.util.security.MD5Encoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DigestAuthenticator
/*     */   extends AuthenticatorBase
/*     */ {
/*  49 */   private final Log log = LogFactory.getLog(DigestAuthenticator.class);
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final String QOP = "auth";
/*     */   
/*     */ 
/*     */ 
/*     */   protected Map<String, NonceInfo> nonces;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DigestAuthenticator()
/*     */   {
/*  64 */     setCache(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   protected long lastTimestamp = 0L;
/*  81 */   protected final Object lastTimestampLock = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */   protected int nonceCacheSize = 1000;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */   protected int nonceCountWindowSize = 100;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 100 */   protected String key = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */   protected long nonceValidity = 300000L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String opaque;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */   protected boolean validateUri = true;
/*     */   
/*     */ 
/*     */   public int getNonceCountWindowSize()
/*     */   {
/* 125 */     return this.nonceCountWindowSize;
/*     */   }
/*     */   
/*     */   public void setNonceCountWindowSize(int nonceCountWindowSize)
/*     */   {
/* 130 */     this.nonceCountWindowSize = nonceCountWindowSize;
/*     */   }
/*     */   
/*     */   public int getNonceCacheSize()
/*     */   {
/* 135 */     return this.nonceCacheSize;
/*     */   }
/*     */   
/*     */   public void setNonceCacheSize(int nonceCacheSize)
/*     */   {
/* 140 */     this.nonceCacheSize = nonceCacheSize;
/*     */   }
/*     */   
/*     */   public String getKey()
/*     */   {
/* 145 */     return this.key;
/*     */   }
/*     */   
/*     */   public void setKey(String key)
/*     */   {
/* 150 */     this.key = key;
/*     */   }
/*     */   
/*     */   public long getNonceValidity()
/*     */   {
/* 155 */     return this.nonceValidity;
/*     */   }
/*     */   
/*     */   public void setNonceValidity(long nonceValidity)
/*     */   {
/* 160 */     this.nonceValidity = nonceValidity;
/*     */   }
/*     */   
/*     */   public String getOpaque()
/*     */   {
/* 165 */     return this.opaque;
/*     */   }
/*     */   
/*     */   public void setOpaque(String opaque)
/*     */   {
/* 170 */     this.opaque = opaque;
/*     */   }
/*     */   
/*     */   public boolean isValidateUri()
/*     */   {
/* 175 */     return this.validateUri;
/*     */   }
/*     */   
/*     */   public void setValidateUri(boolean validateUri)
/*     */   {
/* 180 */     this.validateUri = validateUri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean doAuthenticate(org.apache.catalina.connector.Request request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/* 209 */     if (checkForCachedAuthentication(request, response, false)) {
/* 210 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 214 */     Principal principal = null;
/* 215 */     String authorization = request.getHeader("authorization");
/*     */     
/* 217 */     DigestInfo digestInfo = new DigestInfo(getOpaque(), getNonceValidity(), getKey(), this.nonces, isValidateUri());
/* 218 */     if ((authorization != null) && 
/* 219 */       (digestInfo.parse(request, authorization))) {
/* 220 */       if (digestInfo.validate(request)) {
/* 221 */         principal = digestInfo.authenticate(this.context.getRealm());
/*     */       }
/*     */       
/* 224 */       if ((principal != null) && (!digestInfo.isNonceStale())) {
/* 225 */         register(request, response, principal, "DIGEST", digestInfo
/*     */         
/* 227 */           .getUsername(), null);
/* 228 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 237 */     String nonce = generateNonce(request);
/*     */     
/* 239 */     setAuthenticateHeader(request, response, nonce, (principal != null) && 
/* 240 */       (digestInfo.isNonceStale()));
/* 241 */     response.sendError(401);
/* 242 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getAuthMethod()
/*     */   {
/* 248 */     return "DIGEST";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static String removeQuotes(String quotedString, boolean quotesRequired)
/*     */   {
/* 266 */     if ((quotedString.length() > 0) && (quotedString.charAt(0) != '"') && (!quotesRequired))
/*     */     {
/* 268 */       return quotedString; }
/* 269 */     if (quotedString.length() > 2) {
/* 270 */       return quotedString.substring(1, quotedString.length() - 1);
/*     */     }
/* 272 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static String removeQuotes(String quotedString)
/*     */   {
/* 283 */     return removeQuotes(quotedString, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String generateNonce(org.apache.catalina.connector.Request request)
/*     */   {
/* 296 */     long currentTime = System.currentTimeMillis();
/*     */     
/* 298 */     synchronized (this.lastTimestampLock) {
/* 299 */       if (currentTime > this.lastTimestamp) {
/* 300 */         this.lastTimestamp = currentTime;
/*     */       } else {
/* 302 */         currentTime = ++this.lastTimestamp;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 307 */     String ipTimeKey = request.getRemoteAddr() + ":" + currentTime + ":" + getKey();
/*     */     
/* 309 */     byte[] buffer = ConcurrentMessageDigest.digestMD5(new byte[][] {ipTimeKey
/* 310 */       .getBytes(StandardCharsets.ISO_8859_1) });
/* 311 */     String nonce = currentTime + ":" + MD5Encoder.encode(buffer);
/*     */     
/* 313 */     NonceInfo info = new NonceInfo(currentTime, getNonceCountWindowSize());
/* 314 */     synchronized (this.nonces) {
/* 315 */       this.nonces.put(nonce, info);
/*     */     }
/*     */     
/* 318 */     return nonce;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setAuthenticateHeader(HttpServletRequest request, HttpServletResponse response, String nonce, boolean isNonceStale)
/*     */   {
/* 353 */     String realmName = getRealmName(this.context);
/*     */     String authenticateHeader;
/*     */     String authenticateHeader;
/* 356 */     if (isNonceStale)
/*     */     {
/*     */ 
/* 359 */       authenticateHeader = "Digest realm=\"" + realmName + "\", qop=\"" + "auth" + "\", nonce=\"" + nonce + "\", opaque=\"" + getOpaque() + "\", stale=true";
/*     */     }
/*     */     else
/*     */     {
/* 363 */       authenticateHeader = "Digest realm=\"" + realmName + "\", qop=\"" + "auth" + "\", nonce=\"" + nonce + "\", opaque=\"" + getOpaque() + "\"";
/*     */     }
/*     */     
/* 366 */     response.setHeader("WWW-Authenticate", authenticateHeader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isPreemptiveAuthPossible(org.apache.catalina.connector.Request request)
/*     */   {
/* 373 */     MessageBytes authorizationHeader = request.getCoyoteRequest().getMimeHeaders().getValue("authorization");
/* 374 */     return (authorizationHeader != null) && (authorizationHeader.startsWithIgnoreCase("digest ", 0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 382 */     super.startInternal();
/*     */     
/*     */ 
/* 385 */     if (getKey() == null) {
/* 386 */       setKey(this.sessionIdGenerator.generateSessionId());
/*     */     }
/*     */     
/*     */ 
/* 390 */     if (getOpaque() == null) {
/* 391 */       setOpaque(this.sessionIdGenerator.generateSessionId());
/*     */     }
/*     */     
/* 394 */     this.nonces = new LinkedHashMap()
/*     */     {
/*     */       private static final long serialVersionUID = 1L;
/*     */       
/*     */       private static final long LOG_SUPPRESS_TIME = 300000L;
/* 399 */       private long lastLog = 0L;
/*     */       
/*     */ 
/*     */ 
/*     */       protected boolean removeEldestEntry(Map.Entry<String, DigestAuthenticator.NonceInfo> eldest)
/*     */       {
/* 405 */         long currentTime = System.currentTimeMillis();
/* 406 */         if (size() > DigestAuthenticator.this.getNonceCacheSize()) {
/* 407 */           if (this.lastLog < currentTime)
/*     */           {
/* 409 */             if (currentTime - ((DigestAuthenticator.NonceInfo)eldest.getValue()).getTimestamp() < DigestAuthenticator.this.getNonceValidity())
/*     */             {
/* 411 */               DigestAuthenticator.this.log.warn(AuthenticatorBase.sm.getString("digestAuthenticator.cacheRemove"));
/*     */               
/* 413 */               this.lastLog = (currentTime + 300000L);
/*     */             } }
/* 415 */           return true;
/*     */         }
/* 417 */         return false;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public static class DigestInfo
/*     */   {
/*     */     private final String opaque;
/*     */     private final long nonceValidity;
/*     */     private final String key;
/*     */     private final Map<String, DigestAuthenticator.NonceInfo> nonces;
/* 428 */     private boolean validateUri = true;
/*     */     
/* 430 */     private String userName = null;
/* 431 */     private String method = null;
/* 432 */     private String uri = null;
/* 433 */     private String response = null;
/* 434 */     private String nonce = null;
/* 435 */     private String nc = null;
/* 436 */     private String cnonce = null;
/* 437 */     private String realmName = null;
/* 438 */     private String qop = null;
/* 439 */     private String opaqueReceived = null;
/*     */     
/* 441 */     private boolean nonceStale = false;
/*     */     
/*     */ 
/*     */     public DigestInfo(String opaque, long nonceValidity, String key, Map<String, DigestAuthenticator.NonceInfo> nonces, boolean validateUri)
/*     */     {
/* 446 */       this.opaque = opaque;
/* 447 */       this.nonceValidity = nonceValidity;
/* 448 */       this.key = key;
/* 449 */       this.nonces = nonces;
/* 450 */       this.validateUri = validateUri;
/*     */     }
/*     */     
/*     */     public String getUsername()
/*     */     {
/* 455 */       return this.userName;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean parse(org.apache.catalina.connector.Request request, String authorization)
/*     */     {
/* 461 */       if (authorization == null) {
/* 462 */         return false;
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 467 */         directives = Authorization.parseAuthorizationDigest(new StringReader(authorization));
/*     */       } catch (IOException e) {
/*     */         Map<String, String> directives;
/* 470 */         return false;
/*     */       }
/*     */       Map<String, String> directives;
/* 473 */       if (directives == null) {
/* 474 */         return false;
/*     */       }
/*     */       
/* 477 */       this.method = request.getMethod();
/* 478 */       this.userName = ((String)directives.get("username"));
/* 479 */       this.realmName = ((String)directives.get("realm"));
/* 480 */       this.nonce = ((String)directives.get("nonce"));
/* 481 */       this.nc = ((String)directives.get("nc"));
/* 482 */       this.cnonce = ((String)directives.get("cnonce"));
/* 483 */       this.qop = ((String)directives.get("qop"));
/* 484 */       this.uri = ((String)directives.get("uri"));
/* 485 */       this.response = ((String)directives.get("response"));
/* 486 */       this.opaqueReceived = ((String)directives.get("opaque"));
/*     */       
/* 488 */       return true;
/*     */     }
/*     */     
/*     */     public boolean validate(org.apache.catalina.connector.Request request) {
/* 492 */       if ((this.userName == null) || (this.realmName == null) || (this.nonce == null) || (this.uri == null) || (this.response == null))
/*     */       {
/* 494 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 498 */       if (this.validateUri)
/*     */       {
/* 500 */         String query = request.getQueryString();
/* 501 */         String uriQuery; String uriQuery; if (query == null) {
/* 502 */           uriQuery = request.getRequestURI();
/*     */         } else {
/* 504 */           uriQuery = request.getRequestURI() + "?" + query;
/*     */         }
/* 506 */         if (!this.uri.equals(uriQuery))
/*     */         {
/*     */ 
/*     */ 
/* 510 */           String host = request.getHeader("host");
/* 511 */           String scheme = request.getScheme();
/* 512 */           if ((host != null) && (!uriQuery.startsWith(scheme))) {
/* 513 */             StringBuilder absolute = new StringBuilder();
/* 514 */             absolute.append(scheme);
/* 515 */             absolute.append("://");
/* 516 */             absolute.append(host);
/* 517 */             absolute.append(uriQuery);
/* 518 */             if (!this.uri.equals(absolute.toString())) {
/* 519 */               return false;
/*     */             }
/*     */           } else {
/* 522 */             return false;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 528 */       String lcRealm = AuthenticatorBase.getRealmName(request.getContext());
/* 529 */       if (!lcRealm.equals(this.realmName)) {
/* 530 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 534 */       if (!this.opaque.equals(this.opaqueReceived)) {
/* 535 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 539 */       int i = this.nonce.indexOf(':');
/* 540 */       if ((i < 0) || (i + 1 == this.nonce.length())) {
/* 541 */         return false;
/*     */       }
/*     */       try
/*     */       {
/* 545 */         nonceTime = Long.parseLong(this.nonce.substring(0, i));
/*     */       } catch (NumberFormatException nfe) { long nonceTime;
/* 547 */         return false; }
/*     */       long nonceTime;
/* 549 */       String md5clientIpTimeKey = this.nonce.substring(i + 1);
/* 550 */       long currentTime = System.currentTimeMillis();
/* 551 */       if (currentTime - nonceTime > this.nonceValidity) {
/* 552 */         this.nonceStale = true;
/* 553 */         synchronized (this.nonces) {
/* 554 */           this.nonces.remove(this.nonce);
/*     */         }
/*     */       }
/*     */       
/* 558 */       String serverIpTimeKey = request.getRemoteAddr() + ":" + nonceTime + ":" + this.key;
/* 559 */       byte[] buffer = ConcurrentMessageDigest.digestMD5(new byte[][] {serverIpTimeKey
/* 560 */         .getBytes(StandardCharsets.ISO_8859_1) });
/* 561 */       String md5ServerIpTimeKey = MD5Encoder.encode(buffer);
/* 562 */       if (!md5ServerIpTimeKey.equals(md5clientIpTimeKey)) {
/* 563 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 567 */       if ((this.qop != null) && (!"auth".equals(this.qop))) {
/* 568 */         return false;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 573 */       if (this.qop == null) {
/* 574 */         if ((this.cnonce != null) || (this.nc != null)) {
/* 575 */           return false;
/*     */         }
/*     */       } else {
/* 578 */         if ((this.cnonce == null) || (this.nc == null)) {
/* 579 */           return false;
/*     */         }
/*     */         
/*     */ 
/* 583 */         if ((this.nc.length() < 6) || (this.nc.length() > 8)) {
/* 584 */           return false;
/*     */         }
/*     */         try
/*     */         {
/* 588 */           count = Long.parseLong(this.nc, 16);
/*     */         } catch (NumberFormatException nfe) { long count;
/* 590 */           return false; }
/*     */         long count;
/*     */         DigestAuthenticator.NonceInfo info;
/* 593 */         synchronized (this.nonces) {
/* 594 */           info = (DigestAuthenticator.NonceInfo)this.nonces.get(this.nonce); }
/*     */         DigestAuthenticator.NonceInfo info;
/* 596 */         if (info == null)
/*     */         {
/*     */ 
/* 599 */           this.nonceStale = true;
/*     */         }
/* 601 */         else if (!info.nonceCountValid(count)) {
/* 602 */           return false;
/*     */         }
/*     */       }
/*     */       
/* 606 */       return true;
/*     */     }
/*     */     
/*     */     public boolean isNonceStale() {
/* 610 */       return this.nonceStale;
/*     */     }
/*     */     
/*     */ 
/*     */     public Principal authenticate(Realm realm)
/*     */     {
/* 616 */       String a2 = this.method + ":" + this.uri;
/*     */       
/* 618 */       byte[] buffer = ConcurrentMessageDigest.digestMD5(new byte[][] {a2
/* 619 */         .getBytes(StandardCharsets.ISO_8859_1) });
/* 620 */       String md5a2 = MD5Encoder.encode(buffer);
/*     */       
/* 622 */       return realm.authenticate(this.userName, this.response, this.nonce, this.nc, this.cnonce, this.qop, this.realmName, md5a2);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class NonceInfo
/*     */   {
/*     */     private final long timestamp;
/*     */     private final boolean[] seen;
/*     */     private final int offset;
/* 632 */     private int count = 0;
/*     */     
/*     */     public NonceInfo(long currentTime, int seenWindowSize) {
/* 635 */       this.timestamp = currentTime;
/* 636 */       this.seen = new boolean[seenWindowSize];
/* 637 */       this.offset = (seenWindowSize / 2);
/*     */     }
/*     */     
/*     */     public synchronized boolean nonceCountValid(long nonceCount) {
/* 641 */       if ((this.count - this.offset >= nonceCount) || (nonceCount > this.count - this.offset + this.seen.length))
/*     */       {
/* 643 */         return false;
/*     */       }
/* 645 */       int checkIndex = (int)((nonceCount + this.offset) % this.seen.length);
/* 646 */       if (this.seen[checkIndex] != 0) {
/* 647 */         return false;
/*     */       }
/* 649 */       this.seen[checkIndex] = true;
/* 650 */       this.seen[(this.count % this.seen.length)] = false;
/* 651 */       this.count += 1;
/* 652 */       return true;
/*     */     }
/*     */     
/*     */     public long getTimestamp()
/*     */     {
/* 657 */       return this.timestamp;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\authenticator\DigestAuthenticator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */