/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.catalina.CredentialHandler;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource.Resource;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryRealm
/*     */   extends RealmBase
/*     */ {
/*  48 */   private static final Log log = LogFactory.getLog(MemoryRealm.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */   private static Digester digester = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */   private String pathname = "conf/tomcat-users.xml";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   private final Map<String, GenericPrincipal> principals = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathname()
/*     */   {
/*  79 */     return this.pathname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPathname(String pathname)
/*     */   {
/*  92 */     this.pathname = pathname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username, String credentials)
/*     */   {
/* 114 */     if ((username == null) || (credentials == null)) {
/* 115 */       if (log.isDebugEnabled()) {
/* 116 */         log.debug(sm.getString("memoryRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/* 118 */       return null;
/*     */     }
/*     */     
/* 121 */     GenericPrincipal principal = (GenericPrincipal)this.principals.get(username);
/*     */     
/* 123 */     if ((principal == null) || (principal.getPassword() == null))
/*     */     {
/*     */ 
/* 126 */       getCredentialHandler().mutate(credentials);
/*     */       
/* 128 */       if (log.isDebugEnabled()) {
/* 129 */         log.debug(sm.getString("memoryRealm.authenticateFailure", new Object[] { username }));
/*     */       }
/* 131 */       return null;
/*     */     }
/*     */     
/* 134 */     boolean validated = getCredentialHandler().matches(credentials, principal.getPassword());
/*     */     
/* 136 */     if (validated) {
/* 137 */       if (log.isDebugEnabled()) {
/* 138 */         log.debug(sm.getString("memoryRealm.authenticateSuccess", new Object[] { username }));
/*     */       }
/* 140 */       return principal;
/*     */     }
/* 142 */     if (log.isDebugEnabled()) {
/* 143 */       log.debug(sm.getString("memoryRealm.authenticateFailure", new Object[] { username }));
/*     */     }
/* 145 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void addUser(String username, String password, String roles)
/*     */   {
/* 163 */     List<String> list = new ArrayList();
/* 164 */     roles = roles + ",";
/*     */     for (;;) {
/* 166 */       int comma = roles.indexOf(',');
/* 167 */       if (comma < 0) {
/*     */         break;
/*     */       }
/* 170 */       String role = roles.substring(0, comma).trim();
/* 171 */       list.add(role);
/* 172 */       roles = roles.substring(comma + 1);
/*     */     }
/*     */     
/*     */ 
/* 176 */     GenericPrincipal principal = new GenericPrincipal(username, password, list);
/*     */     
/* 178 */     this.principals.put(username, principal);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized Digester getDigester()
/*     */   {
/* 191 */     if (digester == null) {
/* 192 */       digester = new Digester();
/* 193 */       digester.setValidating(false);
/*     */       try {
/* 195 */         digester.setFeature("http://apache.org/xml/features/allow-java-encodings", true);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 199 */         log.warn(sm.getString("memoryRealm.xmlFeatureEncoding"), e);
/*     */       }
/* 201 */       digester.addRuleSet(new MemoryRuleSet());
/*     */     }
/* 203 */     return digester;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPassword(String username)
/*     */   {
/* 213 */     GenericPrincipal principal = (GenericPrincipal)this.principals.get(username);
/* 214 */     if (principal != null) {
/* 215 */       return principal.getPassword();
/*     */     }
/* 217 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Principal getPrincipal(String username)
/*     */   {
/* 229 */     return (Principal)this.principals.get(username);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 246 */     String pathName = getPathname();
/* 247 */     try { InputStream is = ConfigFileLoader.getSource().getResource(pathName).getInputStream();Throwable localThrowable3 = null;
/*     */       try {
/* 249 */         if (log.isDebugEnabled()) {
/* 250 */           log.debug(sm.getString("memoryRealm.loadPath", new Object[] { pathName }));
/*     */         }
/*     */         
/* 253 */         Digester digester = getDigester();
/*     */         try {
/* 255 */           synchronized (digester) {
/* 256 */             digester.push(this);
/* 257 */             digester.parse(is);
/*     */           }
/*     */         } catch (Exception e) {
/* 260 */           throw new LifecycleException(sm.getString("memoryRealm.readXml"), e);
/*     */         } finally {
/* 262 */           digester.reset();
/*     */         }
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 247 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 264 */         if (is != null) if (localThrowable3 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else is.close();
/* 265 */       } } catch (IOException ioe) { throw new LifecycleException(sm.getString("memoryRealm.loadExist", new Object[] { pathName }), ioe);
/*     */     }
/*     */     
/* 268 */     super.startInternal();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\MemoryRealm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */