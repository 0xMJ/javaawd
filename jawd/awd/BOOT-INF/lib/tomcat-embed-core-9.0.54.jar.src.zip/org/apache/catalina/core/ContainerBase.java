/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.File;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.ScheduledExecutorService;
/*      */ import java.util.concurrent.ScheduledFuture;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import javax.management.ObjectName;
/*      */ import org.apache.catalina.AccessLog;
/*      */ import org.apache.catalina.Cluster;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.ContainerEvent;
/*      */ import org.apache.catalina.ContainerListener;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.Lifecycle;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Loader;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.Request;
/*      */ import org.apache.catalina.connector.Response;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.MultiThrowable;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.threads.InlineExecutorService;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ContainerBase
/*      */   extends LifecycleMBeanBase
/*      */   implements Container
/*      */ {
/*  131 */   private static final Log log = LogFactory.getLog(ContainerBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */   protected class PrivilegedAddChild
/*      */     implements PrivilegedAction<Void>
/*      */   {
/*      */     private final Container child;
/*      */     
/*      */ 
/*      */ 
/*      */     PrivilegedAddChild(Container child)
/*      */     {
/*  144 */       this.child = child;
/*      */     }
/*      */     
/*      */     public Void run()
/*      */     {
/*  149 */       ContainerBase.this.addChildInternal(this.child);
/*  150 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  162 */   protected final HashMap<String, Container> children = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  168 */   protected int backgroundProcessorDelay = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ScheduledFuture<?> backgroundProcessorFuture;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ScheduledFuture<?> monitorFuture;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  183 */   protected final List<ContainerListener> listeners = new CopyOnWriteArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  188 */   protected Log logger = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  194 */   protected String logName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  200 */   protected Cluster cluster = null;
/*  201 */   private final ReadWriteLock clusterLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  207 */   protected String name = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  213 */   protected Container parent = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  219 */   protected ClassLoader parentClassLoader = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  225 */   protected final Pipeline pipeline = new StandardPipeline(this);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  231 */   private volatile Realm realm = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  237 */   private final ReadWriteLock realmLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  243 */   protected static final StringManager sm = StringManager.getManager(ContainerBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  249 */   protected boolean startChildren = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  254 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  262 */   protected volatile AccessLog accessLog = null;
/*  263 */   private volatile boolean accessLogScanComplete = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  270 */   private int startStopThreads = 1;
/*      */   
/*      */ 
/*      */   protected ExecutorService startStopExecutor;
/*      */   
/*      */ 
/*      */   public int getStartStopThreads()
/*      */   {
/*  278 */     return this.startStopThreads;
/*      */   }
/*      */   
/*      */   public void setStartStopThreads(int startStopThreads)
/*      */   {
/*  283 */     int oldStartStopThreads = this.startStopThreads;
/*  284 */     this.startStopThreads = startStopThreads;
/*      */     
/*      */ 
/*  287 */     if ((oldStartStopThreads != startStopThreads) && (this.startStopExecutor != null)) {
/*  288 */       reconfigureStartStopExecutor(getStartStopThreads());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getBackgroundProcessorDelay()
/*      */   {
/*  304 */     return this.backgroundProcessorDelay;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBackgroundProcessorDelay(int delay)
/*      */   {
/*  317 */     this.backgroundProcessorDelay = delay;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Log getLogger()
/*      */   {
/*  326 */     if (this.logger != null) {
/*  327 */       return this.logger;
/*      */     }
/*  329 */     this.logger = LogFactory.getLog(getLogName());
/*  330 */     return this.logger;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLogName()
/*      */   {
/*  340 */     if (this.logName != null) {
/*  341 */       return this.logName;
/*      */     }
/*  343 */     String loggerName = null;
/*  344 */     Container current = this;
/*  345 */     while (current != null) {
/*  346 */       String name = current.getName();
/*  347 */       if ((name == null) || (name.equals(""))) {
/*  348 */         name = "/";
/*  349 */       } else if (name.startsWith("##")) {
/*  350 */         name = "/" + name;
/*      */       }
/*  352 */       loggerName = "[" + name + "]" + (loggerName != null ? "." + loggerName : "");
/*      */       
/*  354 */       current = current.getParent();
/*      */     }
/*  356 */     this.logName = (ContainerBase.class.getName() + "." + loggerName);
/*  357 */     return this.logName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cluster getCluster()
/*      */   {
/*  369 */     Lock readLock = this.clusterLock.readLock();
/*  370 */     readLock.lock();
/*      */     try { Cluster localCluster;
/*  372 */       if (this.cluster != null) {
/*  373 */         return this.cluster;
/*      */       }
/*      */       
/*  376 */       if (this.parent != null) {
/*  377 */         return this.parent.getCluster();
/*      */       }
/*      */       
/*  380 */       return null;
/*      */     } finally {
/*  382 */       readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Cluster getClusterInternal()
/*      */   {
/*  391 */     Lock readLock = this.clusterLock.readLock();
/*  392 */     readLock.lock();
/*      */     try {
/*  394 */       return this.cluster;
/*      */     } finally {
/*  396 */       readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCluster(Cluster cluster)
/*      */   {
/*  409 */     Cluster oldCluster = null;
/*  410 */     Lock writeLock = this.clusterLock.writeLock();
/*  411 */     writeLock.lock();
/*      */     try
/*      */     {
/*  414 */       oldCluster = this.cluster;
/*  415 */       if (oldCluster == cluster) {
/*  416 */         return;
/*      */       }
/*  418 */       this.cluster = cluster;
/*      */       
/*      */ 
/*  421 */       if ((getState().isAvailable()) && (oldCluster != null) && ((oldCluster instanceof Lifecycle))) {
/*      */         try
/*      */         {
/*  424 */           ((Lifecycle)oldCluster).stop();
/*      */         } catch (LifecycleException e) {
/*  426 */           log.error(sm.getString("containerBase.cluster.stop"), e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  431 */       if (cluster != null) {
/*  432 */         cluster.setContainer(this);
/*      */       }
/*      */       
/*  435 */       if ((getState().isAvailable()) && (cluster != null) && ((cluster instanceof Lifecycle))) {
/*      */         try
/*      */         {
/*  438 */           ((Lifecycle)cluster).start();
/*      */         } catch (LifecycleException e) {
/*  440 */           log.error(sm.getString("containerBase.cluster.start"), e);
/*      */         }
/*      */       }
/*      */     } finally {
/*  444 */       writeLock.unlock();
/*      */     }
/*      */     
/*      */ 
/*  448 */     this.support.firePropertyChange("cluster", oldCluster, cluster);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  459 */     return this.name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setName(String name)
/*      */   {
/*  476 */     if (name == null) {
/*  477 */       throw new IllegalArgumentException(sm.getString("containerBase.nullName"));
/*      */     }
/*  479 */     String oldName = this.name;
/*  480 */     this.name = name;
/*  481 */     this.support.firePropertyChange("name", oldName, this.name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getStartChildren()
/*      */   {
/*  492 */     return this.startChildren;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStartChildren(boolean startChildren)
/*      */   {
/*  504 */     boolean oldStartChildren = this.startChildren;
/*  505 */     this.startChildren = startChildren;
/*  506 */     this.support.firePropertyChange("startChildren", oldStartChildren, this.startChildren);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Container getParent()
/*      */   {
/*  516 */     return this.parent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParent(Container container)
/*      */   {
/*  534 */     Container oldParent = this.parent;
/*  535 */     this.parent = container;
/*  536 */     this.support.firePropertyChange("parent", oldParent, this.parent);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassLoader getParentClassLoader()
/*      */   {
/*  548 */     if (this.parentClassLoader != null) {
/*  549 */       return this.parentClassLoader;
/*      */     }
/*  551 */     if (this.parent != null) {
/*  552 */       return this.parent.getParentClassLoader();
/*      */     }
/*  554 */     return ClassLoader.getSystemClassLoader();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParentClassLoader(ClassLoader parent)
/*      */   {
/*  569 */     ClassLoader oldParentClassLoader = this.parentClassLoader;
/*  570 */     this.parentClassLoader = parent;
/*  571 */     this.support.firePropertyChange("parentClassLoader", oldParentClassLoader, this.parentClassLoader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Pipeline getPipeline()
/*      */   {
/*  583 */     return this.pipeline;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Realm getRealm()
/*      */   {
/*  595 */     Lock l = this.realmLock.readLock();
/*  596 */     l.lock();
/*      */     try { Realm localRealm;
/*  598 */       if (this.realm != null) {
/*  599 */         return this.realm;
/*      */       }
/*  601 */       if (this.parent != null) {
/*  602 */         return this.parent.getRealm();
/*      */       }
/*  604 */       return null;
/*      */     } finally {
/*  606 */       l.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   protected Realm getRealmInternal()
/*      */   {
/*  612 */     Lock l = this.realmLock.readLock();
/*  613 */     l.lock();
/*      */     try {
/*  615 */       return this.realm;
/*      */     } finally {
/*  617 */       l.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRealm(Realm realm)
/*      */   {
/*  629 */     Lock l = this.realmLock.writeLock();
/*  630 */     l.lock();
/*      */     try
/*      */     {
/*  633 */       Realm oldRealm = this.realm;
/*  634 */       if (oldRealm == realm) {
/*  635 */         return;
/*      */       }
/*  637 */       this.realm = realm;
/*      */       
/*      */ 
/*  640 */       if ((getState().isAvailable()) && (oldRealm != null) && ((oldRealm instanceof Lifecycle))) {
/*      */         try
/*      */         {
/*  643 */           ((Lifecycle)oldRealm).stop();
/*      */         } catch (LifecycleException e) {
/*  645 */           log.error(sm.getString("containerBase.realm.stop"), e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  650 */       if (realm != null) {
/*  651 */         realm.setContainer(this);
/*      */       }
/*  653 */       if ((getState().isAvailable()) && (realm != null) && ((realm instanceof Lifecycle))) {
/*      */         try
/*      */         {
/*  656 */           ((Lifecycle)realm).start();
/*      */         } catch (LifecycleException e) {
/*  658 */           log.error(sm.getString("containerBase.realm.start"), e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  663 */       this.support.firePropertyChange("realm", oldRealm, this.realm);
/*      */     } finally {
/*  665 */       l.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addChild(Container child)
/*      */   {
/*  693 */     if (Globals.IS_SECURITY_ENABLED) {
/*  694 */       PrivilegedAction<Void> dp = new PrivilegedAddChild(child);
/*      */       
/*  696 */       AccessController.doPrivileged(dp);
/*      */     } else {
/*  698 */       addChildInternal(child);
/*      */     }
/*      */   }
/*      */   
/*      */   private void addChildInternal(Container child)
/*      */   {
/*  704 */     if (log.isDebugEnabled()) {
/*  705 */       log.debug("Add child " + child + " " + this);
/*      */     }
/*      */     
/*  708 */     synchronized (this.children) {
/*  709 */       if (this.children.get(child.getName()) != null)
/*      */       {
/*  711 */         throw new IllegalArgumentException(sm.getString("containerBase.child.notUnique", new Object[] {child.getName() }));
/*      */       }
/*  713 */       child.setParent(this);
/*  714 */       this.children.put(child.getName(), child);
/*      */     }
/*      */     
/*  717 */     fireContainerEvent("addChild", child);
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  723 */       if (((getState().isAvailable()) || 
/*  724 */         (LifecycleState.STARTING_PREP.equals(getState()))) && (this.startChildren))
/*      */       {
/*  726 */         child.start();
/*      */       }
/*      */     } catch (LifecycleException e) {
/*  729 */       throw new IllegalStateException(sm.getString("containerBase.child.start"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addContainerListener(ContainerListener listener)
/*      */   {
/*  741 */     this.listeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/*  752 */     this.support.addPropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public Container findChild(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ifnonnull +5 -> 6
/*      */     //   4: aconst_null
/*      */     //   5: areturn
/*      */     //   6: aload_0
/*      */     //   7: getfield 6	org/apache/catalina/core/ContainerBase:children	Ljava/util/HashMap;
/*      */     //   10: dup
/*      */     //   11: astore_2
/*      */     //   12: monitorenter
/*      */     //   13: aload_0
/*      */     //   14: getfield 6	org/apache/catalina/core/ContainerBase:children	Ljava/util/HashMap;
/*      */     //   17: aload_1
/*      */     //   18: invokevirtual 96	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   21: checkcast 102	org/apache/catalina/Container
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: areturn
/*      */     //   27: astore_3
/*      */     //   28: aload_2
/*      */     //   29: monitorexit
/*      */     //   30: aload_3
/*      */     //   31: athrow
/*      */     // Line number table:
/*      */     //   Java source line #764	-> byte code offset #0
/*      */     //   Java source line #765	-> byte code offset #4
/*      */     //   Java source line #767	-> byte code offset #6
/*      */     //   Java source line #768	-> byte code offset #13
/*      */     //   Java source line #769	-> byte code offset #27
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	32	0	this	ContainerBase
/*      */     //   0	32	1	name	String
/*      */     //   11	18	2	Ljava/lang/Object;	Object
/*      */     //   27	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   13	26	27	finally
/*      */     //   27	30	27	finally
/*      */   }
/*      */   
/*      */   public Container[] findChildren()
/*      */   {
/*  779 */     synchronized (this.children) {
/*  780 */       Container[] results = new Container[this.children.size()];
/*  781 */       return (Container[])this.children.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ContainerListener[] findContainerListeners()
/*      */   {
/*  793 */     ContainerListener[] results = new ContainerListener[0];
/*      */     
/*  795 */     return (ContainerListener[])this.listeners.toArray(results);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeChild(Container child)
/*      */   {
/*  808 */     if (child == null) {
/*  809 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  813 */       if (child.getState().isAvailable()) {
/*  814 */         child.stop();
/*      */       }
/*      */     } catch (LifecycleException e) {
/*  817 */       log.error(sm.getString("containerBase.child.stop"), e);
/*      */     }
/*      */     
/*  820 */     boolean destroy = false;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  825 */       if (!LifecycleState.DESTROYING.equals(child.getState())) {
/*  826 */         child.destroy();
/*  827 */         destroy = true;
/*      */       }
/*      */     } catch (LifecycleException e) {
/*  830 */       log.error(sm.getString("containerBase.child.destroy"), e);
/*      */     }
/*      */     
/*  833 */     if (!destroy) {
/*  834 */       fireContainerEvent("removeChild", child);
/*      */     }
/*      */     
/*  837 */     synchronized (this.children) {
/*  838 */       if (this.children.get(child.getName()) == null) {
/*  839 */         return;
/*      */       }
/*  841 */       this.children.remove(child.getName());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeContainerListener(ContainerListener listener)
/*      */   {
/*  854 */     this.listeners.remove(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/*  866 */     this.support.removePropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void initInternal()
/*      */     throws LifecycleException
/*      */   {
/*  873 */     reconfigureStartStopExecutor(getStartStopThreads());
/*  874 */     super.initInternal();
/*      */   }
/*      */   
/*      */   private void reconfigureStartStopExecutor(int threads)
/*      */   {
/*  879 */     if (threads == 1)
/*      */     {
/*  881 */       if (!(this.startStopExecutor instanceof InlineExecutorService)) {
/*  882 */         this.startStopExecutor = new InlineExecutorService();
/*      */       }
/*      */     }
/*      */     else {
/*  886 */       Server server = Container.getService(this).getServer();
/*  887 */       server.setUtilityThreads(threads);
/*  888 */       this.startStopExecutor = server.getUtilityExecutor();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void startInternal()
/*      */     throws LifecycleException
/*      */   {
/*  904 */     this.logger = null;
/*  905 */     getLogger();
/*  906 */     Cluster cluster = getClusterInternal();
/*  907 */     if ((cluster instanceof Lifecycle)) {
/*  908 */       ((Lifecycle)cluster).start();
/*      */     }
/*  910 */     Realm realm = getRealmInternal();
/*  911 */     if ((realm instanceof Lifecycle)) {
/*  912 */       ((Lifecycle)realm).start();
/*      */     }
/*      */     
/*      */ 
/*  916 */     Container[] children = findChildren();
/*  917 */     List<Future<Void>> results = new ArrayList();
/*  918 */     for (Container child : children) {
/*  919 */       results.add(this.startStopExecutor.submit(new StartChild(child)));
/*      */     }
/*      */     
/*  922 */     MultiThrowable multiThrowable = null;
/*      */     
/*  924 */     for (Object result : results) {
/*      */       try {
/*  926 */         ((Future)result).get();
/*      */       } catch (Throwable e) {
/*  928 */         log.error(sm.getString("containerBase.threadedStartFailed"), e);
/*  929 */         if (multiThrowable == null) {
/*  930 */           multiThrowable = new MultiThrowable();
/*      */         }
/*  932 */         multiThrowable.add(e);
/*      */       }
/*      */     }
/*      */     
/*  936 */     if (multiThrowable != null)
/*      */     {
/*  938 */       throw new LifecycleException(sm.getString("containerBase.threadedStartFailed"), multiThrowable.getThrowable());
/*      */     }
/*      */     
/*      */ 
/*  942 */     if ((this.pipeline instanceof Lifecycle)) {
/*  943 */       ((Lifecycle)this.pipeline).start();
/*      */     }
/*      */     
/*  946 */     setState(LifecycleState.STARTING);
/*      */     
/*      */ 
/*  949 */     if (this.backgroundProcessorDelay > 0)
/*      */     {
/*  951 */       this.monitorFuture = Container.getService(this).getServer().getUtilityExecutor().scheduleWithFixedDelay(new ContainerBackgroundProcessorMonitor(), 0L, 60L, TimeUnit.SECONDS);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/*  968 */     if (this.monitorFuture != null) {
/*  969 */       this.monitorFuture.cancel(true);
/*  970 */       this.monitorFuture = null;
/*      */     }
/*  972 */     threadStop();
/*      */     
/*  974 */     setState(LifecycleState.STOPPING);
/*      */     
/*      */ 
/*  977 */     if (((this.pipeline instanceof Lifecycle)) && 
/*  978 */       (((Lifecycle)this.pipeline).getState().isAvailable())) {
/*  979 */       ((Lifecycle)this.pipeline).stop();
/*      */     }
/*      */     
/*      */ 
/*  983 */     Container[] children = findChildren();
/*  984 */     List<Future<Void>> results = new ArrayList();
/*  985 */     for (Container child : children) {
/*  986 */       results.add(this.startStopExecutor.submit(new StopChild(child)));
/*      */     }
/*      */     
/*  989 */     boolean fail = false;
/*  990 */     for (Object result : results) {
/*      */       try {
/*  992 */         ((Future)result).get();
/*      */       } catch (Exception e) {
/*  994 */         log.error(sm.getString("containerBase.threadedStopFailed"), e);
/*  995 */         fail = true;
/*      */       }
/*      */     }
/*  998 */     if (fail)
/*      */     {
/* 1000 */       throw new LifecycleException(sm.getString("containerBase.threadedStopFailed"));
/*      */     }
/*      */     
/*      */ 
/* 1004 */     Realm realm = getRealmInternal();
/* 1005 */     if ((realm instanceof Lifecycle)) {
/* 1006 */       ((Lifecycle)realm).stop();
/*      */     }
/* 1008 */     Cluster cluster = getClusterInternal();
/* 1009 */     if ((cluster instanceof Lifecycle)) {
/* 1010 */       ((Lifecycle)cluster).stop();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void destroyInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1017 */     Realm realm = getRealmInternal();
/* 1018 */     if ((realm instanceof Lifecycle)) {
/* 1019 */       ((Lifecycle)realm).destroy();
/*      */     }
/* 1021 */     Cluster cluster = getClusterInternal();
/* 1022 */     if ((cluster instanceof Lifecycle)) {
/* 1023 */       ((Lifecycle)cluster).destroy();
/*      */     }
/*      */     
/*      */ 
/* 1027 */     if ((this.pipeline instanceof Lifecycle)) {
/* 1028 */       ((Lifecycle)this.pipeline).destroy();
/*      */     }
/*      */     
/*      */ 
/* 1032 */     for (Container child : findChildren()) {
/* 1033 */       removeChild(child);
/*      */     }
/*      */     
/*      */ 
/* 1037 */     if (this.parent != null) {
/* 1038 */       this.parent.removeChild(this);
/*      */     }
/*      */     
/*      */ 
/* 1042 */     if (this.startStopExecutor != null) {
/* 1043 */       this.startStopExecutor.shutdownNow();
/*      */     }
/*      */     
/* 1046 */     super.destroyInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void logAccess(Request request, Response response, long time, boolean useDefault)
/*      */   {
/* 1059 */     boolean logged = false;
/*      */     
/* 1061 */     if (getAccessLog() != null) {
/* 1062 */       getAccessLog().log(request, response, time);
/* 1063 */       logged = true;
/*      */     }
/*      */     
/* 1066 */     if (getParent() != null)
/*      */     {
/*      */ 
/* 1069 */       getParent().logAccess(request, response, time, (useDefault) && (!logged));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public AccessLog getAccessLog()
/*      */   {
/* 1076 */     if (this.accessLogScanComplete) {
/* 1077 */       return this.accessLog;
/*      */     }
/*      */     
/* 1080 */     AccessLogAdapter adapter = null;
/* 1081 */     Valve[] valves = getPipeline().getValves();
/* 1082 */     for (Valve valve : valves) {
/* 1083 */       if ((valve instanceof AccessLog)) {
/* 1084 */         if (adapter == null) {
/* 1085 */           adapter = new AccessLogAdapter((AccessLog)valve);
/*      */         } else {
/* 1087 */           adapter.add((AccessLog)valve);
/*      */         }
/*      */       }
/*      */     }
/* 1091 */     if (adapter != null) {
/* 1092 */       this.accessLog = adapter;
/*      */     }
/* 1094 */     this.accessLogScanComplete = true;
/* 1095 */     return this.accessLog;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void addValve(Valve valve)
/*      */   {
/* 1120 */     this.pipeline.addValve(valve);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void backgroundProcess()
/*      */   {
/* 1132 */     if (!getState().isAvailable()) {
/* 1133 */       return;
/*      */     }
/*      */     
/* 1136 */     Cluster cluster = getClusterInternal();
/* 1137 */     if (cluster != null) {
/*      */       try {
/* 1139 */         cluster.backgroundProcess();
/*      */       } catch (Exception e) {
/* 1141 */         log.warn(sm.getString("containerBase.backgroundProcess.cluster", new Object[] { cluster }), e);
/*      */       }
/*      */     }
/*      */     
/* 1145 */     Realm realm = getRealmInternal();
/* 1146 */     if (realm != null) {
/*      */       try {
/* 1148 */         realm.backgroundProcess();
/*      */       } catch (Exception e) {
/* 1150 */         log.warn(sm.getString("containerBase.backgroundProcess.realm", new Object[] { realm }), e);
/*      */       }
/*      */     }
/* 1153 */     Valve current = this.pipeline.getFirst();
/* 1154 */     while (current != null) {
/*      */       try {
/* 1156 */         current.backgroundProcess();
/*      */       } catch (Exception e) {
/* 1158 */         log.warn(sm.getString("containerBase.backgroundProcess.valve", new Object[] { current }), e);
/*      */       }
/* 1160 */       current = current.getNext();
/*      */     }
/* 1162 */     fireLifecycleEvent("periodic", null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public File getCatalinaBase()
/*      */   {
/* 1169 */     if (this.parent == null) {
/* 1170 */       return null;
/*      */     }
/*      */     
/* 1173 */     return this.parent.getCatalinaBase();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public File getCatalinaHome()
/*      */   {
/* 1180 */     if (this.parent == null) {
/* 1181 */       return null;
/*      */     }
/*      */     
/* 1184 */     return this.parent.getCatalinaHome();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fireContainerEvent(String type, Object data)
/*      */   {
/* 1201 */     if (this.listeners.size() < 1) {
/* 1202 */       return;
/*      */     }
/*      */     
/* 1205 */     ContainerEvent event = new ContainerEvent(this, type, data);
/*      */     
/* 1207 */     for (ContainerListener listener : this.listeners) {
/* 1208 */       listener.containerEvent(event);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getDomainInternal()
/*      */   {
/* 1218 */     Container p = getParent();
/* 1219 */     if (p == null) {
/* 1220 */       return null;
/*      */     }
/* 1222 */     return p.getDomain();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getMBeanKeyProperties()
/*      */   {
/* 1229 */     Container c = this;
/* 1230 */     StringBuilder keyProperties = new StringBuilder();
/* 1231 */     int containerCount = 0;
/*      */     
/*      */ 
/*      */ 
/* 1235 */     while (!(c instanceof Engine)) {
/* 1236 */       if ((c instanceof Wrapper)) {
/* 1237 */         keyProperties.insert(0, ",servlet=");
/* 1238 */         keyProperties.insert(9, c.getName());
/* 1239 */       } else if ((c instanceof Context)) {
/* 1240 */         keyProperties.insert(0, ",context=");
/* 1241 */         ContextName cn = new ContextName(c.getName(), false);
/* 1242 */         keyProperties.insert(9, cn.getDisplayName());
/* 1243 */       } else if ((c instanceof Host)) {
/* 1244 */         keyProperties.insert(0, ",host=");
/* 1245 */         keyProperties.insert(6, c.getName());
/* 1246 */       } else { if (c == null)
/*      */         {
/* 1248 */           keyProperties.append(",container");
/* 1249 */           keyProperties.append(containerCount++);
/* 1250 */           keyProperties.append("=null");
/* 1251 */           break;
/*      */         }
/*      */         
/* 1254 */         keyProperties.append(",container");
/* 1255 */         keyProperties.append(containerCount++);
/* 1256 */         keyProperties.append('=');
/* 1257 */         keyProperties.append(c.getName());
/*      */       }
/* 1259 */       c = c.getParent();
/*      */     }
/* 1261 */     return keyProperties.toString();
/*      */   }
/*      */   
/*      */   public ObjectName[] getChildren() {
/* 1265 */     List<ObjectName> names = new ArrayList(this.children.size());
/* 1266 */     for (Container next : this.children.values()) {
/* 1267 */       if ((next instanceof ContainerBase)) {
/* 1268 */         names.add(next.getObjectName());
/*      */       }
/*      */     }
/* 1271 */     return (ObjectName[])names.toArray(new ObjectName[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void threadStart()
/*      */   {
/* 1282 */     if ((this.backgroundProcessorDelay > 0) && 
/* 1283 */       ((getState().isAvailable()) || (LifecycleState.STARTING_PREP.equals(getState()))) && ((this.backgroundProcessorFuture == null) || 
/* 1284 */       (this.backgroundProcessorFuture.isDone()))) {
/* 1285 */       if ((this.backgroundProcessorFuture != null) && (this.backgroundProcessorFuture.isDone())) {
/*      */         try
/*      */         {
/* 1288 */           this.backgroundProcessorFuture.get();
/*      */         } catch (InterruptedException|ExecutionException e) {
/* 1290 */           log.error(sm.getString("containerBase.backgroundProcess.error"), e);
/*      */         }
/*      */       }
/*      */       
/* 1294 */       this.backgroundProcessorFuture = Container.getService(this).getServer().getUtilityExecutor().scheduleWithFixedDelay(new ContainerBackgroundProcessor(), this.backgroundProcessorDelay, this.backgroundProcessorDelay, TimeUnit.SECONDS);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void threadStop()
/*      */   {
/* 1306 */     if (this.backgroundProcessorFuture != null) {
/* 1307 */       this.backgroundProcessorFuture.cancel(true);
/* 1308 */       this.backgroundProcessorFuture = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public final String toString()
/*      */   {
/* 1315 */     StringBuilder sb = new StringBuilder();
/* 1316 */     Container parent = getParent();
/* 1317 */     if (parent != null) {
/* 1318 */       sb.append(parent.toString());
/* 1319 */       sb.append('.');
/*      */     }
/* 1321 */     sb.append(getClass().getSimpleName());
/* 1322 */     sb.append('[');
/* 1323 */     sb.append(getName());
/* 1324 */     sb.append(']');
/* 1325 */     return sb.toString();
/*      */   }
/*      */   
/*      */   protected class ContainerBackgroundProcessorMonitor implements Runnable
/*      */   {
/*      */     protected ContainerBackgroundProcessorMonitor() {}
/*      */     
/*      */     public void run() {
/* 1333 */       if (ContainerBase.this.getState().isAvailable()) {
/* 1334 */         ContainerBase.this.threadStart();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected class ContainerBackgroundProcessor
/*      */     implements Runnable
/*      */   {
/*      */     protected ContainerBackgroundProcessor() {}
/*      */     
/*      */     public void run()
/*      */     {
/* 1347 */       processChildren(ContainerBase.this);
/*      */     }
/*      */     
/*      */     protected void processChildren(Container container) {
/* 1351 */       ClassLoader originalClassLoader = null;
/*      */       try
/*      */       {
/* 1354 */         if ((container instanceof Context)) {
/* 1355 */           Loader loader = ((Context)container).getLoader();
/*      */           
/* 1357 */           if (loader == null) {
/* 1358 */             return;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1363 */           originalClassLoader = ((Context)container).bind(false, null);
/*      */         }
/* 1365 */         container.backgroundProcess();
/* 1366 */         Container[] children = container.findChildren();
/* 1367 */         for (Container child : children) {
/* 1368 */           if (child.getBackgroundProcessorDelay() <= 0) {
/* 1369 */             processChildren(child);
/*      */           }
/*      */         }
/*      */       } catch (Throwable t) {
/* 1373 */         ExceptionUtils.handleThrowable(t);
/* 1374 */         ContainerBase.log.error(ContainerBase.sm.getString("containerBase.backgroundProcess.error"), t);
/*      */       } finally {
/* 1376 */         if ((container instanceof Context)) {
/* 1377 */           ((Context)container).unbind(false, originalClassLoader);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class StartChild
/*      */     implements Callable<Void>
/*      */   {
/*      */     private Container child;
/*      */     
/*      */     public StartChild(Container child)
/*      */     {
/* 1391 */       this.child = child;
/*      */     }
/*      */     
/*      */     public Void call() throws LifecycleException
/*      */     {
/* 1396 */       this.child.start();
/* 1397 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class StopChild implements Callable<Void>
/*      */   {
/*      */     private Container child;
/*      */     
/*      */     public StopChild(Container child) {
/* 1406 */       this.child = child;
/*      */     }
/*      */     
/*      */     public Void call() throws LifecycleException
/*      */     {
/* 1411 */       if (this.child.getState().isAvailable()) {
/* 1412 */         this.child.stop();
/*      */       }
/* 1414 */       return null;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\ContainerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */