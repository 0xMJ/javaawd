/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import javax.servlet.AsyncContext;
/*      */ import javax.servlet.DispatcherType;
/*      */ import javax.servlet.RequestDispatcher;
/*      */ import javax.servlet.Servlet;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletRequestWrapper;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.ServletResponseWrapper;
/*      */ import javax.servlet.UnavailableException;
/*      */ import javax.servlet.http.HttpServletMapping;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.catalina.AsyncDispatcher;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.ClientAbortException;
/*      */ import org.apache.catalina.connector.Request;
/*      */ import org.apache.catalina.connector.RequestFacade;
/*      */ import org.apache.catalina.connector.Response;
/*      */ import org.apache.catalina.connector.ResponseFacade;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class ApplicationDispatcher
/*      */   implements AsyncDispatcher, RequestDispatcher
/*      */ {
/*   72 */   static final boolean STRICT_SERVLET_COMPLIANCE = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*   74 */   static { String wrapSameObject = System.getProperty("org.apache.catalina.core.ApplicationDispatcher.WRAP_SAME_OBJECT");
/*      */     
/*   76 */     if (wrapSameObject == null) {
/*   77 */       WRAP_SAME_OBJECT = STRICT_SERVLET_COMPLIANCE;
/*      */     } else {
/*   79 */       WRAP_SAME_OBJECT = Boolean.parseBoolean(wrapSameObject);
/*      */     }
/*      */   }
/*      */   
/*      */   protected class PrivilegedForward implements PrivilegedExceptionAction<Void>
/*      */   {
/*      */     private final ServletRequest request;
/*      */     private final ServletResponse response;
/*      */     
/*      */     PrivilegedForward(ServletRequest request, ServletResponse response)
/*      */     {
/*   90 */       this.request = request;
/*   91 */       this.response = response;
/*      */     }
/*      */     
/*      */     public Void run() throws Exception
/*      */     {
/*   96 */       ApplicationDispatcher.this.doForward(this.request, this.response);
/*   97 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class PrivilegedInclude implements PrivilegedExceptionAction<Void>
/*      */   {
/*      */     private final ServletRequest request;
/*      */     private final ServletResponse response;
/*      */     
/*      */     PrivilegedInclude(ServletRequest request, ServletResponse response) {
/*  107 */       this.request = request;
/*  108 */       this.response = response;
/*      */     }
/*      */     
/*      */     public Void run() throws ServletException, IOException
/*      */     {
/*  113 */       ApplicationDispatcher.this.doInclude(this.request, this.response);
/*  114 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class PrivilegedDispatch implements PrivilegedExceptionAction<Void>
/*      */   {
/*      */     private final ServletRequest request;
/*      */     private final ServletResponse response;
/*      */     
/*      */     PrivilegedDispatch(ServletRequest request, ServletResponse response) {
/*  124 */       this.request = request;
/*  125 */       this.response = response;
/*      */     }
/*      */     
/*      */     public Void run() throws ServletException, IOException
/*      */     {
/*  130 */       ApplicationDispatcher.this.doDispatch(this.request, this.response);
/*  131 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class State
/*      */   {
/*      */     State(ServletRequest request, ServletResponse response, boolean including)
/*      */     {
/*  144 */       this.outerRequest = request;
/*  145 */       this.outerResponse = response;
/*  146 */       this.including = including;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  152 */     ServletRequest outerRequest = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  158 */     ServletResponse outerResponse = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  163 */     ServletRequest wrapRequest = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  169 */     ServletResponse wrapResponse = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  174 */     boolean including = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  179 */     HttpServletRequest hrequest = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  184 */     HttpServletResponse hresponse = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final boolean WRAP_SAME_OBJECT;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Context context;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String name;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String pathInfo;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ApplicationDispatcher(Wrapper wrapper, String requestURI, String servletPath, String pathInfo, String queryString, HttpServletMapping mapping, String name)
/*      */   {
/*  215 */     this.wrapper = wrapper;
/*  216 */     this.context = ((Context)wrapper.getParent());
/*  217 */     this.requestURI = requestURI;
/*  218 */     this.servletPath = servletPath;
/*  219 */     this.pathInfo = pathInfo;
/*  220 */     this.queryString = queryString;
/*  221 */     this.mapping = mapping;
/*  222 */     this.name = name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String queryString;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String requestURI;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String servletPath;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final HttpServletMapping mapping;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  273 */   private static final StringManager sm = StringManager.getManager(ApplicationDispatcher.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Wrapper wrapper;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void forward(ServletRequest request, ServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  301 */     if (Globals.IS_SECURITY_ENABLED) {
/*      */       try {
/*  303 */         PrivilegedForward dp = new PrivilegedForward(request, response);
/*  304 */         AccessController.doPrivileged(dp);
/*      */       } catch (PrivilegedActionException pe) {
/*  306 */         Exception e = pe.getException();
/*  307 */         if ((e instanceof ServletException)) {
/*  308 */           throw ((ServletException)e);
/*      */         }
/*  310 */         throw ((IOException)e);
/*      */       }
/*      */     } else {
/*  313 */       doForward(request, response);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void doForward(ServletRequest request, ServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  322 */     if (response.isCommitted())
/*      */     {
/*  324 */       throw new IllegalStateException(sm.getString("applicationDispatcher.forward.ise"));
/*      */     }
/*      */     try {
/*  327 */       response.resetBuffer();
/*      */     } catch (IllegalStateException e) {
/*  329 */       throw e;
/*      */     }
/*      */     
/*      */ 
/*  333 */     State state = new State(request, response, false);
/*      */     
/*  335 */     if (WRAP_SAME_OBJECT)
/*      */     {
/*  337 */       checkSameObjects(request, response);
/*      */     }
/*      */     
/*  340 */     wrapResponse(state);
/*      */     
/*  342 */     if ((this.servletPath == null) && (this.pathInfo == null))
/*      */     {
/*      */ 
/*  345 */       ApplicationHttpRequest wrequest = (ApplicationHttpRequest)wrapRequest(state);
/*  346 */       HttpServletRequest hrequest = state.hrequest;
/*  347 */       wrequest.setRequestURI(hrequest.getRequestURI());
/*  348 */       wrequest.setContextPath(hrequest.getContextPath());
/*  349 */       wrequest.setServletPath(hrequest.getServletPath());
/*  350 */       wrequest.setPathInfo(hrequest.getPathInfo());
/*  351 */       wrequest.setQueryString(hrequest.getQueryString());
/*      */       
/*  353 */       processRequest(request, response, state);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  359 */       ApplicationHttpRequest wrequest = (ApplicationHttpRequest)wrapRequest(state);
/*  360 */       HttpServletRequest hrequest = state.hrequest;
/*  361 */       if (hrequest.getAttribute("javax.servlet.forward.request_uri") == null) {
/*  362 */         wrequest.setAttribute("javax.servlet.forward.request_uri", hrequest
/*  363 */           .getRequestURI());
/*  364 */         wrequest.setAttribute("javax.servlet.forward.context_path", hrequest
/*  365 */           .getContextPath());
/*  366 */         wrequest.setAttribute("javax.servlet.forward.servlet_path", hrequest
/*  367 */           .getServletPath());
/*  368 */         wrequest.setAttribute("javax.servlet.forward.path_info", hrequest
/*  369 */           .getPathInfo());
/*  370 */         wrequest.setAttribute("javax.servlet.forward.query_string", hrequest
/*  371 */           .getQueryString());
/*  372 */         wrequest.setAttribute("javax.servlet.forward.mapping", hrequest.getHttpServletMapping());
/*      */       }
/*      */       
/*  375 */       wrequest.setContextPath(this.context.getEncodedPath());
/*  376 */       wrequest.setRequestURI(this.requestURI);
/*  377 */       wrequest.setServletPath(this.servletPath);
/*  378 */       wrequest.setPathInfo(this.pathInfo);
/*  379 */       if (this.queryString != null) {
/*  380 */         wrequest.setQueryString(this.queryString);
/*  381 */         wrequest.setQueryParams(this.queryString);
/*      */       }
/*  383 */       wrequest.setMapping(this.mapping);
/*      */       
/*  385 */       processRequest(request, response, state);
/*      */     }
/*      */     
/*  388 */     if (request.isAsyncStarted())
/*      */     {
/*      */ 
/*  391 */       return;
/*      */     }
/*      */     
/*      */ 
/*  395 */     if (this.wrapper.getLogger().isDebugEnabled()) {
/*  396 */       this.wrapper.getLogger().debug(" Disabling the response for further output");
/*      */     }
/*      */     
/*  399 */     if ((response instanceof ResponseFacade)) {
/*  400 */       ((ResponseFacade)response).finish();
/*      */     }
/*      */     else
/*      */     {
/*  404 */       if (this.wrapper.getLogger().isDebugEnabled()) {
/*  405 */         this.wrapper.getLogger().debug(" The Response is vehiculed using a wrapper: " + response
/*  406 */           .getClass().getName());
/*      */       }
/*      */       
/*      */       try
/*      */       {
/*  411 */         PrintWriter writer = response.getWriter();
/*  412 */         writer.close();
/*      */       } catch (IllegalStateException e) {
/*      */         try {
/*  415 */           ServletOutputStream stream = response.getOutputStream();
/*  416 */           stream.close();
/*      */         }
/*      */         catch (IllegalStateException|IOException localIllegalStateException1) {}
/*      */       }
/*      */       catch (IOException localIOException) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processRequest(ServletRequest request, ServletResponse response, State state)
/*      */     throws IOException, ServletException
/*      */   {
/*  442 */     DispatcherType disInt = (DispatcherType)request.getAttribute("org.apache.catalina.core.DISPATCHER_TYPE");
/*  443 */     if (disInt != null) {
/*  444 */       boolean doInvoke = true;
/*      */       
/*  446 */       if ((this.context.getFireRequestListenersOnForwards()) && 
/*  447 */         (!this.context.fireRequestInitEvent(request))) {
/*  448 */         doInvoke = false;
/*      */       }
/*      */       
/*  451 */       if (doInvoke) {
/*  452 */         if (disInt != DispatcherType.ERROR) {
/*  453 */           state.outerRequest.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", 
/*      */           
/*  455 */             getCombinedPath());
/*  456 */           state.outerRequest.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", DispatcherType.FORWARD);
/*      */           
/*      */ 
/*  459 */           invoke(state.outerRequest, response, state);
/*      */         } else {
/*  461 */           invoke(state.outerRequest, response, state);
/*      */         }
/*      */         
/*  464 */         if (this.context.getFireRequestListenersOnForwards()) {
/*  465 */           this.context.fireRequestDestroyEvent(request);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getCombinedPath()
/*      */   {
/*  479 */     if (this.servletPath == null) {
/*  480 */       return null;
/*      */     }
/*  482 */     if (this.pathInfo == null) {
/*  483 */       return this.servletPath;
/*      */     }
/*  485 */     return this.servletPath + this.pathInfo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void include(ServletRequest request, ServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  504 */     if (Globals.IS_SECURITY_ENABLED) {
/*      */       try {
/*  506 */         PrivilegedInclude dp = new PrivilegedInclude(request, response);
/*  507 */         AccessController.doPrivileged(dp);
/*      */       } catch (PrivilegedActionException pe) {
/*  509 */         Exception e = pe.getException();
/*      */         
/*  511 */         if ((e instanceof ServletException)) {
/*  512 */           throw ((ServletException)e);
/*      */         }
/*  514 */         throw ((IOException)e);
/*      */       }
/*      */     } else {
/*  517 */       doInclude(request, response);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void doInclude(ServletRequest request, ServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  525 */     State state = new State(request, response, true);
/*      */     
/*  527 */     if (WRAP_SAME_OBJECT)
/*      */     {
/*  529 */       checkSameObjects(request, response);
/*      */     }
/*      */     
/*      */ 
/*  533 */     wrapResponse(state);
/*      */     
/*      */ 
/*  536 */     if (this.name != null)
/*      */     {
/*  538 */       ApplicationHttpRequest wrequest = (ApplicationHttpRequest)wrapRequest(state);
/*  539 */       wrequest.setAttribute("org.apache.catalina.NAMED", this.name);
/*  540 */       if (this.servletPath != null) {
/*  541 */         wrequest.setServletPath(this.servletPath);
/*      */       }
/*  543 */       wrequest.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", DispatcherType.INCLUDE);
/*  544 */       wrequest.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", getCombinedPath());
/*  545 */       invoke(state.outerRequest, state.outerResponse, state);
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  552 */       ApplicationHttpRequest wrequest = (ApplicationHttpRequest)wrapRequest(state);
/*  553 */       String contextPath = this.context.getPath();
/*  554 */       if (this.requestURI != null) {
/*  555 */         wrequest.setAttribute("javax.servlet.include.request_uri", this.requestURI);
/*      */       }
/*  557 */       if (contextPath != null) {
/*  558 */         wrequest.setAttribute("javax.servlet.include.context_path", contextPath);
/*      */       }
/*  560 */       if (this.servletPath != null) {
/*  561 */         wrequest.setAttribute("javax.servlet.include.servlet_path", this.servletPath);
/*      */       }
/*  563 */       if (this.pathInfo != null) {
/*  564 */         wrequest.setAttribute("javax.servlet.include.path_info", this.pathInfo);
/*      */       }
/*  566 */       if (this.queryString != null) {
/*  567 */         wrequest.setAttribute("javax.servlet.include.query_string", this.queryString);
/*  568 */         wrequest.setQueryParams(this.queryString);
/*      */       }
/*  570 */       if (this.mapping != null) {
/*  571 */         wrequest.setAttribute("javax.servlet.include.mapping", this.mapping);
/*      */       }
/*      */       
/*  574 */       wrequest.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", DispatcherType.INCLUDE);
/*      */       
/*  576 */       wrequest.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", 
/*  577 */         getCombinedPath());
/*  578 */       invoke(state.outerRequest, state.outerResponse, state);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void dispatch(ServletRequest request, ServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  587 */     if (Globals.IS_SECURITY_ENABLED) {
/*      */       try {
/*  589 */         PrivilegedDispatch dp = new PrivilegedDispatch(request, response);
/*  590 */         AccessController.doPrivileged(dp);
/*      */       } catch (PrivilegedActionException pe) {
/*  592 */         Exception e = pe.getException();
/*      */         
/*  594 */         if ((e instanceof ServletException)) {
/*  595 */           throw ((ServletException)e);
/*      */         }
/*  597 */         throw ((IOException)e);
/*      */       }
/*      */     } else {
/*  600 */       doDispatch(request, response);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void doDispatch(ServletRequest request, ServletResponse response)
/*      */     throws ServletException, IOException
/*      */   {
/*  608 */     State state = new State(request, response, false);
/*      */     
/*      */ 
/*  611 */     wrapResponse(state);
/*      */     
/*  613 */     ApplicationHttpRequest wrequest = (ApplicationHttpRequest)wrapRequest(state);
/*  614 */     HttpServletRequest hrequest = state.hrequest;
/*      */     
/*  616 */     wrequest.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", DispatcherType.ASYNC);
/*  617 */     wrequest.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", getCombinedPath());
/*  618 */     wrequest.setAttribute("javax.servlet.async.mapping", hrequest.getHttpServletMapping());
/*      */     
/*  620 */     wrequest.setContextPath(this.context.getEncodedPath());
/*  621 */     wrequest.setRequestURI(this.requestURI);
/*  622 */     wrequest.setServletPath(this.servletPath);
/*  623 */     wrequest.setPathInfo(this.pathInfo);
/*  624 */     if (this.queryString != null) {
/*  625 */       wrequest.setQueryString(this.queryString);
/*  626 */       wrequest.setQueryParams(this.queryString);
/*      */     }
/*  628 */     if (!Globals.STRICT_SERVLET_COMPLIANCE) {
/*  629 */       wrequest.setMapping(this.mapping);
/*      */     }
/*      */     
/*  632 */     invoke(state.outerRequest, state.outerResponse, state);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void invoke(ServletRequest request, ServletResponse response, State state)
/*      */     throws IOException, ServletException
/*      */   {
/*  660 */     ClassLoader oldCCL = this.context.bind(false, null);
/*      */     
/*      */ 
/*  663 */     HttpServletResponse hresponse = state.hresponse;
/*  664 */     Servlet servlet = null;
/*  665 */     IOException ioException = null;
/*  666 */     ServletException servletException = null;
/*  667 */     RuntimeException runtimeException = null;
/*  668 */     boolean unavailable = false;
/*      */     
/*      */ 
/*  671 */     if (this.wrapper.isUnavailable()) {
/*  672 */       this.wrapper.getLogger().warn(sm
/*  673 */         .getString("applicationDispatcher.isUnavailable", new Object[] {this.wrapper
/*  674 */         .getName() }));
/*  675 */       long available = this.wrapper.getAvailable();
/*  676 */       if ((available > 0L) && (available < Long.MAX_VALUE)) {
/*  677 */         hresponse.setDateHeader("Retry-After", available);
/*      */       }
/*  679 */       hresponse.sendError(503, sm
/*  680 */         .getString("applicationDispatcher.isUnavailable", new Object[] {this.wrapper.getName() }));
/*  681 */       unavailable = true;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  686 */       if (!unavailable) {
/*  687 */         servlet = this.wrapper.allocate();
/*      */       }
/*      */     } catch (ServletException e) {
/*  690 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.allocateException", new Object[] {this.wrapper
/*  691 */         .getName() }), StandardWrapper.getRootCause(e));
/*  692 */       servletException = e;
/*      */     } catch (Throwable e) {
/*  694 */       ExceptionUtils.handleThrowable(e);
/*  695 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.allocateException", new Object[] {this.wrapper
/*  696 */         .getName() }), e);
/*      */       
/*  698 */       servletException = new ServletException(sm.getString("applicationDispatcher.allocateException", new Object[] {this.wrapper
/*  699 */         .getName() }), e);
/*  700 */       servlet = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  705 */     ApplicationFilterChain filterChain = ApplicationFilterFactory.createFilterChain(request, this.wrapper, servlet);
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  710 */       if ((servlet != null) && (filterChain != null)) {
/*  711 */         filterChain.doFilter(request, response);
/*      */       }
/*      */     }
/*      */     catch (ClientAbortException e) {
/*  715 */       ioException = e;
/*      */     } catch (IOException e) {
/*  717 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.serviceException", new Object[] {this.wrapper
/*  718 */         .getName() }), e);
/*  719 */       ioException = e;
/*      */     } catch (UnavailableException e) {
/*  721 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.serviceException", new Object[] {this.wrapper
/*  722 */         .getName() }), e);
/*  723 */       servletException = e;
/*  724 */       this.wrapper.unavailable(e);
/*      */     } catch (ServletException e) {
/*  726 */       Throwable rootCause = StandardWrapper.getRootCause(e);
/*  727 */       if (!(rootCause instanceof ClientAbortException)) {
/*  728 */         this.wrapper.getLogger().error(sm.getString("applicationDispatcher.serviceException", new Object[] {this.wrapper
/*  729 */           .getName() }), rootCause);
/*      */       }
/*  731 */       servletException = e;
/*      */     } catch (RuntimeException e) {
/*  733 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.serviceException", new Object[] {this.wrapper
/*  734 */         .getName() }), e);
/*  735 */       runtimeException = e;
/*      */     }
/*      */     
/*      */ 
/*  739 */     if (filterChain != null) {
/*  740 */       filterChain.release();
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  745 */       if (servlet != null) {
/*  746 */         this.wrapper.deallocate(servlet);
/*      */       }
/*      */     } catch (ServletException e) {
/*  749 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.deallocateException", new Object[] {this.wrapper
/*  750 */         .getName() }), e);
/*  751 */       servletException = e;
/*      */     } catch (Throwable e) {
/*  753 */       ExceptionUtils.handleThrowable(e);
/*  754 */       this.wrapper.getLogger().error(sm.getString("applicationDispatcher.deallocateException", new Object[] {this.wrapper
/*  755 */         .getName() }), e);
/*      */       
/*  757 */       servletException = new ServletException(sm.getString("applicationDispatcher.deallocateException", new Object[] {this.wrapper
/*  758 */         .getName() }), e);
/*      */     }
/*      */     
/*      */ 
/*  762 */     this.context.unbind(false, oldCCL);
/*      */     
/*      */ 
/*      */ 
/*  766 */     unwrapRequest(state);
/*  767 */     unwrapResponse(state);
/*      */     
/*  769 */     recycleRequestWrapper(state);
/*      */     
/*      */ 
/*  772 */     if (ioException != null) {
/*  773 */       throw ioException;
/*      */     }
/*  775 */     if (servletException != null) {
/*  776 */       throw servletException;
/*      */     }
/*  778 */     if (runtimeException != null) {
/*  779 */       throw runtimeException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void unwrapRequest(State state)
/*      */   {
/*  789 */     if (state.wrapRequest == null) {
/*  790 */       return;
/*      */     }
/*      */     
/*  793 */     if ((state.outerRequest.isAsyncStarted()) && 
/*  794 */       (!state.outerRequest.getAsyncContext().hasOriginalRequestAndResponse())) {
/*  795 */       return;
/*      */     }
/*      */     
/*      */ 
/*  799 */     ServletRequest previous = null;
/*  800 */     ServletRequest current = state.outerRequest;
/*  801 */     while (current != null)
/*      */     {
/*      */ 
/*  804 */       if (((current instanceof Request)) || ((current instanceof RequestFacade))) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  809 */       if (current == state.wrapRequest)
/*      */       {
/*  811 */         ServletRequest next = ((ServletRequestWrapper)current).getRequest();
/*  812 */         if (previous == null) {
/*  813 */           state.outerRequest = next; break;
/*      */         }
/*  815 */         ((ServletRequestWrapper)previous).setRequest(next);
/*      */         
/*  817 */         break;
/*      */       }
/*      */       
/*      */ 
/*  821 */       previous = current;
/*  822 */       current = ((ServletRequestWrapper)current).getRequest();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void unwrapResponse(State state)
/*      */   {
/*  833 */     if (state.wrapResponse == null) {
/*  834 */       return;
/*      */     }
/*      */     
/*  837 */     if ((state.outerRequest.isAsyncStarted()) && 
/*  838 */       (!state.outerRequest.getAsyncContext().hasOriginalRequestAndResponse())) {
/*  839 */       return;
/*      */     }
/*      */     
/*      */ 
/*  843 */     ServletResponse previous = null;
/*  844 */     ServletResponse current = state.outerResponse;
/*  845 */     while (current != null)
/*      */     {
/*      */ 
/*  848 */       if (((current instanceof Response)) || ((current instanceof ResponseFacade))) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/*  853 */       if (current == state.wrapResponse)
/*      */       {
/*  855 */         ServletResponse next = ((ServletResponseWrapper)current).getResponse();
/*  856 */         if (previous == null) {
/*  857 */           state.outerResponse = next; break;
/*      */         }
/*  859 */         ((ServletResponseWrapper)previous).setResponse(next);
/*      */         
/*  861 */         break;
/*      */       }
/*      */       
/*      */ 
/*  865 */       previous = current;
/*  866 */       current = ((ServletResponseWrapper)current).getResponse();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ServletRequest wrapRequest(State state)
/*      */   {
/*  880 */     ServletRequest previous = null;
/*  881 */     ServletRequest current = state.outerRequest;
/*  882 */     while (current != null) {
/*  883 */       if ((state.hrequest == null) && ((current instanceof HttpServletRequest))) {
/*  884 */         state.hrequest = ((HttpServletRequest)current);
/*      */       }
/*  886 */       if (!(current instanceof ServletRequestWrapper)) {
/*      */         break;
/*      */       }
/*  889 */       if ((current instanceof ApplicationHttpRequest)) {
/*      */         break;
/*      */       }
/*  892 */       if ((current instanceof ApplicationRequest)) {
/*      */         break;
/*      */       }
/*  895 */       previous = current;
/*  896 */       current = ((ServletRequestWrapper)current).getRequest();
/*      */     }
/*      */     
/*      */ 
/*  900 */     ServletRequest wrapper = null;
/*  901 */     if (((current instanceof ApplicationHttpRequest)) || ((current instanceof Request)) || ((current instanceof HttpServletRequest)))
/*      */     {
/*      */ 
/*      */ 
/*  905 */       HttpServletRequest hcurrent = (HttpServletRequest)current;
/*  906 */       boolean crossContext = false;
/*  907 */       if (((state.outerRequest instanceof ApplicationHttpRequest)) || ((state.outerRequest instanceof Request)) || ((state.outerRequest instanceof HttpServletRequest)))
/*      */       {
/*      */ 
/*  910 */         HttpServletRequest houterRequest = (HttpServletRequest)state.outerRequest;
/*      */         
/*  912 */         Object contextPath = houterRequest.getAttribute("javax.servlet.include.context_path");
/*      */         
/*  914 */         if (contextPath == null)
/*      */         {
/*  916 */           contextPath = houterRequest.getContextPath();
/*      */         }
/*  918 */         crossContext = !this.context.getPath().equals(contextPath);
/*      */       }
/*  920 */       wrapper = new ApplicationHttpRequest(hcurrent, this.context, crossContext);
/*      */     }
/*      */     else {
/*  923 */       wrapper = new ApplicationRequest(current);
/*      */     }
/*  925 */     if (previous == null) {
/*  926 */       state.outerRequest = wrapper;
/*      */     } else {
/*  928 */       ((ServletRequestWrapper)previous).setRequest(wrapper);
/*      */     }
/*  930 */     state.wrapRequest = wrapper;
/*  931 */     return wrapper;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ServletResponse wrapResponse(State state)
/*      */   {
/*  943 */     ServletResponse previous = null;
/*  944 */     ServletResponse current = state.outerResponse;
/*  945 */     while (current != null) {
/*  946 */       if ((state.hresponse == null) && ((current instanceof HttpServletResponse))) {
/*  947 */         state.hresponse = ((HttpServletResponse)current);
/*  948 */         if (!state.including) {
/*  949 */           return null;
/*      */         }
/*      */       }
/*  952 */       if (!(current instanceof ServletResponseWrapper)) {
/*      */         break;
/*      */       }
/*  955 */       if ((current instanceof ApplicationHttpResponse)) {
/*      */         break;
/*      */       }
/*  958 */       if ((current instanceof ApplicationResponse)) {
/*      */         break;
/*      */       }
/*  961 */       previous = current;
/*  962 */       current = ((ServletResponseWrapper)current).getResponse();
/*      */     }
/*      */     
/*      */ 
/*  966 */     ServletResponse wrapper = null;
/*  967 */     if (((current instanceof ApplicationHttpResponse)) || ((current instanceof Response)) || ((current instanceof HttpServletResponse)))
/*      */     {
/*  969 */       wrapper = new ApplicationHttpResponse((HttpServletResponse)current, state.including);
/*      */     } else {
/*  971 */       wrapper = new ApplicationResponse(current, state.including);
/*      */     }
/*  973 */     if (previous == null) {
/*  974 */       state.outerResponse = wrapper;
/*      */     } else {
/*  976 */       ((ServletResponseWrapper)previous).setResponse(wrapper);
/*      */     }
/*  978 */     state.wrapResponse = wrapper;
/*  979 */     return wrapper;
/*      */   }
/*      */   
/*      */ 
/*      */   private void checkSameObjects(ServletRequest appRequest, ServletResponse appResponse)
/*      */     throws ServletException
/*      */   {
/*  986 */     ServletRequest originalRequest = ApplicationFilterChain.getLastServicedRequest();
/*      */     
/*  988 */     ServletResponse originalResponse = ApplicationFilterChain.getLastServicedResponse();
/*      */     
/*      */ 
/*  991 */     if ((originalRequest == null) || (originalResponse == null)) {
/*  992 */       return;
/*      */     }
/*      */     
/*  995 */     boolean same = false;
/*  996 */     ServletRequest dispatchedRequest = appRequest;
/*      */     
/*      */ 
/*  999 */     while (((originalRequest instanceof ServletRequestWrapper)) && 
/* 1000 */       (((ServletRequestWrapper)originalRequest).getRequest() != null))
/*      */     {
/* 1002 */       originalRequest = ((ServletRequestWrapper)originalRequest).getRequest();
/*      */     }
/*      */     
/* 1005 */     while (!same) {
/* 1006 */       if (originalRequest.equals(dispatchedRequest)) {
/* 1007 */         same = true;
/*      */       }
/* 1009 */       if ((same) || (!(dispatchedRequest instanceof ServletRequestWrapper)))
/*      */         break;
/* 1011 */       dispatchedRequest = ((ServletRequestWrapper)dispatchedRequest).getRequest();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1016 */     if (!same) {
/* 1017 */       throw new ServletException(sm.getString("applicationDispatcher.specViolation.request"));
/*      */     }
/*      */     
/*      */ 
/* 1021 */     same = false;
/* 1022 */     ServletResponse dispatchedResponse = appResponse;
/*      */     
/*      */ 
/* 1025 */     while (((originalResponse instanceof ServletResponseWrapper)) && 
/* 1026 */       (((ServletResponseWrapper)originalResponse).getResponse() != null))
/*      */     {
/*      */ 
/* 1029 */       originalResponse = ((ServletResponseWrapper)originalResponse).getResponse();
/*      */     }
/*      */     
/* 1032 */     while (!same) {
/* 1033 */       if (originalResponse.equals(dispatchedResponse)) {
/* 1034 */         same = true;
/*      */       }
/*      */       
/* 1037 */       if ((same) || (!(dispatchedResponse instanceof ServletResponseWrapper)))
/*      */         break;
/* 1039 */       dispatchedResponse = ((ServletResponseWrapper)dispatchedResponse).getResponse();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1045 */     if (!same) {
/* 1046 */       throw new ServletException(sm.getString("applicationDispatcher.specViolation.response"));
/*      */     }
/*      */   }
/*      */   
/*      */   private void recycleRequestWrapper(State state)
/*      */   {
/* 1052 */     if ((state.wrapRequest instanceof ApplicationHttpRequest)) {
/* 1053 */       ((ApplicationHttpRequest)state.wrapRequest).recycle();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\ApplicationDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */