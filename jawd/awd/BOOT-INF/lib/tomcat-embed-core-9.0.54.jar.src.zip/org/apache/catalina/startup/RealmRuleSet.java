/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import org.apache.tomcat.util.digester.Digester;
/*    */ import org.apache.tomcat.util.digester.RuleSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RealmRuleSet
/*    */   implements RuleSet
/*    */ {
/* 29 */   private static final int MAX_NESTED_REALM_LEVELS = Integer.getInteger("org.apache.catalina.startup.RealmRuleSet.MAX_NESTED_REALM_LEVELS", 3)
/*    */   
/* 31 */     .intValue();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final String prefix;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RealmRuleSet()
/*    */   {
/* 49 */     this("");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RealmRuleSet(String prefix)
/*    */   {
/* 61 */     this.prefix = prefix;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addRuleInstances(Digester digester)
/*    */   {
/* 78 */     StringBuilder pattern = new StringBuilder(this.prefix);
/* 79 */     for (int i = 0; i < MAX_NESTED_REALM_LEVELS; i++) {
/* 80 */       if (i > 0) {
/* 81 */         pattern.append('/');
/*    */       }
/* 83 */       pattern.append("Realm");
/* 84 */       addRuleInstances(digester, pattern.toString(), i == 0 ? "setRealm" : "addRealm");
/*    */     }
/*    */   }
/*    */   
/*    */   private void addRuleInstances(Digester digester, String pattern, String methodName) {
/* 89 */     digester.addObjectCreate(pattern, null, "className");
/*    */     
/* 91 */     digester.addSetProperties(pattern);
/* 92 */     digester.addSetNext(pattern, methodName, "org.apache.catalina.Realm");
/* 93 */     digester.addRuleSet(new CredentialHandlerRuleSet(pattern + "/"));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\RealmRuleSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */