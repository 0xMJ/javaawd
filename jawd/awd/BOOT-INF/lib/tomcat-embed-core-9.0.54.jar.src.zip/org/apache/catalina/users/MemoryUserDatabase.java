/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource.Resource;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryUserDatabase
/*     */   implements UserDatabase
/*     */ {
/*  84 */   private static final Log log = LogFactory.getLog(MemoryUserDatabase.class);
/*  85 */   private static final StringManager sm = StringManager.getManager(MemoryUserDatabase.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MemoryUserDatabase()
/*     */   {
/*  94 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MemoryUserDatabase(String id)
/*     */   {
/* 104 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */   protected final Map<String, Group> groups = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String id;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 123 */   protected String pathname = "conf/tomcat-users.xml";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */   protected String pathnameOld = this.pathname + ".old";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */   protected String pathnameNew = this.pathname + ".new";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 140 */   protected boolean readonly = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 145 */   protected final Map<String, Role> roles = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 150 */   protected final Map<String, User> users = new ConcurrentHashMap();
/*     */   
/* 152 */   private final ReentrantReadWriteLock dbLock = new ReentrantReadWriteLock();
/* 153 */   private final Lock readLock = this.dbLock.readLock();
/* 154 */   private final Lock writeLock = this.dbLock.writeLock();
/*     */   
/* 156 */   private volatile long lastModified = 0L;
/* 157 */   private boolean watchSource = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<Group> getGroups()
/*     */   {
/* 167 */     this.readLock.lock();
/*     */     try {
/* 169 */       return new ArrayList(this.groups.values()).iterator();
/*     */     } finally {
/* 171 */       this.readLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/* 181 */     return this.id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathname()
/*     */   {
/* 189 */     return this.pathname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPathname(String pathname)
/*     */   {
/* 199 */     this.pathname = pathname;
/* 200 */     this.pathnameOld = (pathname + ".old");
/* 201 */     this.pathnameNew = (pathname + ".new");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getReadonly()
/*     */   {
/* 209 */     return this.readonly;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReadonly(boolean readonly)
/*     */   {
/* 219 */     this.readonly = readonly;
/*     */   }
/*     */   
/*     */   public boolean getWatchSource()
/*     */   {
/* 224 */     return this.watchSource;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setWatchSource(boolean watchSource)
/*     */   {
/* 230 */     this.watchSource = watchSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<Role> getRoles()
/*     */   {
/* 239 */     this.readLock.lock();
/*     */     try {
/* 241 */       return new ArrayList(this.roles.values()).iterator();
/*     */     } finally {
/* 243 */       this.readLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<User> getUsers()
/*     */   {
/* 253 */     this.readLock.lock();
/*     */     try {
/* 255 */       return new ArrayList(this.users.values()).iterator();
/*     */     } finally {
/* 257 */       this.readLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void close()
/*     */     throws Exception
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 25	org/apache/catalina/users/MemoryUserDatabase:writeLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   4: invokeinterface 29 1 0
/*     */     //   9: aload_0
/*     */     //   10: invokevirtual 35	org/apache/catalina/users/MemoryUserDatabase:save	()V
/*     */     //   13: aload_0
/*     */     //   14: getfield 18	org/apache/catalina/users/MemoryUserDatabase:users	Ljava/util/Map;
/*     */     //   17: invokeinterface 36 1 0
/*     */     //   22: aload_0
/*     */     //   23: getfield 5	org/apache/catalina/users/MemoryUserDatabase:groups	Ljava/util/Map;
/*     */     //   26: invokeinterface 36 1 0
/*     */     //   31: aload_0
/*     */     //   32: getfield 17	org/apache/catalina/users/MemoryUserDatabase:roles	Ljava/util/Map;
/*     */     //   35: invokeinterface 36 1 0
/*     */     //   40: aload_0
/*     */     //   41: getfield 25	org/apache/catalina/users/MemoryUserDatabase:writeLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   44: invokeinterface 34 1 0
/*     */     //   49: goto +15 -> 64
/*     */     //   52: astore_1
/*     */     //   53: aload_0
/*     */     //   54: getfield 25	org/apache/catalina/users/MemoryUserDatabase:writeLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   57: invokeinterface 34 1 0
/*     */     //   62: aload_1
/*     */     //   63: athrow
/*     */     //   64: return
/*     */     // Line number table:
/*     */     //   Java source line #272	-> byte code offset #0
/*     */     //   Java source line #274	-> byte code offset #9
/*     */     //   Java source line #275	-> byte code offset #13
/*     */     //   Java source line #276	-> byte code offset #22
/*     */     //   Java source line #277	-> byte code offset #31
/*     */     //   Java source line #279	-> byte code offset #40
/*     */     //   Java source line #280	-> byte code offset #49
/*     */     //   Java source line #279	-> byte code offset #52
/*     */     //   Java source line #280	-> byte code offset #62
/*     */     //   Java source line #281	-> byte code offset #64
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	65	0	this	MemoryUserDatabase
/*     */     //   52	11	1	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   9	40	52	finally
/*     */   }
/*     */   
/*     */   public Group createGroup(String groupname, String description)
/*     */   {
/* 292 */     if ((groupname == null) || (groupname.length() == 0)) {
/* 293 */       String msg = sm.getString("memoryUserDatabase.nullGroup");
/* 294 */       log.warn(msg);
/* 295 */       throw new IllegalArgumentException(msg);
/*     */     }
/*     */     
/* 298 */     MemoryGroup group = new MemoryGroup(this, groupname, description);
/* 299 */     this.readLock.lock();
/*     */     try {
/* 301 */       this.groups.put(group.getGroupname(), group);
/*     */     } finally {
/* 303 */       this.readLock.unlock();
/*     */     }
/* 305 */     return group;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Role createRole(String rolename, String description)
/*     */   {
/* 317 */     if ((rolename == null) || (rolename.length() == 0)) {
/* 318 */       String msg = sm.getString("memoryUserDatabase.nullRole");
/* 319 */       log.warn(msg);
/* 320 */       throw new IllegalArgumentException(msg);
/*     */     }
/*     */     
/* 323 */     MemoryRole role = new MemoryRole(this, rolename, description);
/* 324 */     this.readLock.lock();
/*     */     try {
/* 326 */       this.roles.put(role.getRolename(), role);
/*     */     } finally {
/* 328 */       this.readLock.unlock();
/*     */     }
/* 330 */     return role;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public User createUser(String username, String password, String fullName)
/*     */   {
/* 344 */     if ((username == null) || (username.length() == 0)) {
/* 345 */       String msg = sm.getString("memoryUserDatabase.nullUser");
/* 346 */       log.warn(msg);
/* 347 */       throw new IllegalArgumentException(msg);
/*     */     }
/*     */     
/* 350 */     MemoryUser user = new MemoryUser(this, username, password, fullName);
/* 351 */     this.readLock.lock();
/*     */     try {
/* 353 */       this.users.put(user.getUsername(), user);
/*     */     } finally {
/* 355 */       this.readLock.unlock();
/*     */     }
/* 357 */     return user;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Group findGroup(String groupname)
/*     */   {
/* 369 */     this.readLock.lock();
/*     */     try {
/* 371 */       return (Group)this.groups.get(groupname);
/*     */     } finally {
/* 373 */       this.readLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Role findRole(String rolename)
/*     */   {
/* 386 */     this.readLock.lock();
/*     */     try {
/* 388 */       return (Role)this.roles.get(rolename);
/*     */     } finally {
/* 390 */       this.readLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public User findUser(String username)
/*     */   {
/* 403 */     this.readLock.lock();
/*     */     try {
/* 405 */       return (User)this.users.get(username);
/*     */     } finally {
/* 407 */       this.readLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open()
/*     */     throws Exception
/*     */   {
/* 419 */     this.writeLock.lock();
/*     */     try
/*     */     {
/* 422 */       this.users.clear();
/* 423 */       this.groups.clear();
/* 424 */       this.roles.clear();
/*     */       
/* 426 */       String pathName = getPathname();
/* 427 */       try { ConfigurationSource.Resource resource = ConfigFileLoader.getSource().getResource(pathName);Throwable localThrowable3 = null;
/* 428 */         try { this.lastModified = resource.getLastModified();
/*     */           
/*     */ 
/* 431 */           Digester digester = new Digester();
/*     */           try {
/* 433 */             digester.setFeature("http://apache.org/xml/features/allow-java-encodings", true);
/*     */           }
/*     */           catch (Exception e) {
/* 436 */             log.warn(sm.getString("memoryUserDatabase.xmlFeatureEncoding"), e);
/*     */           }
/* 438 */           digester.addFactoryCreate("tomcat-users/group", new MemoryGroupCreationFactory(this), true);
/*     */           
/* 440 */           digester.addFactoryCreate("tomcat-users/role", new MemoryRoleCreationFactory(this), true);
/*     */           
/* 442 */           digester.addFactoryCreate("tomcat-users/user", new MemoryUserCreationFactory(this), true);
/*     */           
/*     */ 
/*     */ 
/* 446 */           digester.parse(resource.getInputStream());
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 427 */           localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 447 */           if (resource != null) if (localThrowable3 != null) try { resource.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else resource.close();
/* 448 */         } } catch (IOException ioe) { log.error(sm.getString("memoryUserDatabase.fileNotFound", new Object[] { pathName }));
/*     */       }
/*     */       catch (Exception e) {
/* 451 */         this.users.clear();
/* 452 */         this.groups.clear();
/* 453 */         this.roles.clear();
/* 454 */         throw e;
/*     */       }
/*     */     } finally {
/* 457 */       this.writeLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeGroup(Group group)
/*     */   {
/* 469 */     this.readLock.lock();
/*     */     try {
/* 471 */       Iterator<User> users = getUsers();
/* 472 */       while (users.hasNext()) {
/* 473 */         User user = (User)users.next();
/* 474 */         user.removeGroup(group);
/*     */       }
/* 476 */       this.groups.remove(group.getGroupname());
/*     */     } finally {
/* 478 */       this.readLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRole(Role role)
/*     */   {
/* 490 */     this.readLock.lock();
/*     */     try {
/* 492 */       Iterator<Group> groups = getGroups();
/* 493 */       while (groups.hasNext()) {
/* 494 */         Group group = (Group)groups.next();
/* 495 */         group.removeRole(role);
/*     */       }
/* 497 */       Iterator<User> users = getUsers();
/* 498 */       while (users.hasNext()) {
/* 499 */         User user = (User)users.next();
/* 500 */         user.removeRole(role);
/*     */       }
/* 502 */       this.roles.remove(role.getRolename());
/*     */     } finally {
/* 504 */       this.readLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void removeUser(User user)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 23	org/apache/catalina/users/MemoryUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   4: invokeinterface 29 1 0
/*     */     //   9: aload_0
/*     */     //   10: getfield 18	org/apache/catalina/users/MemoryUserDatabase:users	Ljava/util/Map;
/*     */     //   13: aload_1
/*     */     //   14: invokeinterface 102 1 0
/*     */     //   19: invokeinterface 97 2 0
/*     */     //   24: pop
/*     */     //   25: aload_0
/*     */     //   26: getfield 23	org/apache/catalina/users/MemoryUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   29: invokeinterface 34 1 0
/*     */     //   34: goto +15 -> 49
/*     */     //   37: astore_2
/*     */     //   38: aload_0
/*     */     //   39: getfield 23	org/apache/catalina/users/MemoryUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   42: invokeinterface 34 1 0
/*     */     //   47: aload_2
/*     */     //   48: athrow
/*     */     //   49: return
/*     */     // Line number table:
/*     */     //   Java source line #516	-> byte code offset #0
/*     */     //   Java source line #518	-> byte code offset #9
/*     */     //   Java source line #520	-> byte code offset #25
/*     */     //   Java source line #521	-> byte code offset #34
/*     */     //   Java source line #520	-> byte code offset #37
/*     */     //   Java source line #521	-> byte code offset #47
/*     */     //   Java source line #522	-> byte code offset #49
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	50	0	this	MemoryUserDatabase
/*     */     //   0	50	1	user	User
/*     */     //   37	11	2	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   9	25	37	finally
/*     */   }
/*     */   
/*     */   public boolean isWriteable()
/*     */   {
/* 533 */     File file = new File(this.pathname);
/* 534 */     if (!file.isAbsolute()) {
/* 535 */       file = new File(System.getProperty("catalina.base"), this.pathname);
/*     */     }
/* 537 */     File dir = file.getParentFile();
/* 538 */     return (dir.exists()) && (dir.isDirectory()) && (dir.canWrite());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void save()
/*     */     throws Exception
/*     */   {
/* 551 */     if (getReadonly()) {
/* 552 */       log.error(sm.getString("memoryUserDatabase.readOnly"));
/* 553 */       return;
/*     */     }
/*     */     
/* 556 */     if (!isWriteable()) {
/* 557 */       log.warn(sm.getString("memoryUserDatabase.notPersistable"));
/* 558 */       return;
/*     */     }
/*     */     
/*     */ 
/* 562 */     File fileNew = new File(this.pathnameNew);
/* 563 */     if (!fileNew.isAbsolute()) {
/* 564 */       fileNew = new File(System.getProperty("catalina.base"), this.pathnameNew);
/*     */     }
/*     */     
/* 567 */     this.writeLock.lock();
/*     */     try {
/* 569 */       try { FileOutputStream fos = new FileOutputStream(fileNew);Throwable localThrowable9 = null;
/* 570 */         try { OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);Throwable localThrowable10 = null;
/* 571 */           try { PrintWriter writer = new PrintWriter(osw);Throwable localThrowable11 = null;
/*     */             try
/*     */             {
/* 574 */               writer.println("<?xml version='1.0' encoding='utf-8'?>");
/* 575 */               writer.println("<tomcat-users xmlns=\"http://tomcat.apache.org/xml\"");
/* 576 */               writer.print("              ");
/* 577 */               writer.println("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
/* 578 */               writer.print("              ");
/* 579 */               writer.println("xsi:schemaLocation=\"http://tomcat.apache.org/xml tomcat-users.xsd\"");
/* 580 */               writer.println("              version=\"1.0\">");
/*     */               
/*     */ 
/* 583 */               Iterator<?> values = null;
/* 584 */               values = getRoles();
/* 585 */               while (values.hasNext()) {
/* 586 */                 writer.print("  ");
/* 587 */                 writer.println(values.next());
/*     */               }
/* 589 */               values = getGroups();
/* 590 */               while (values.hasNext()) {
/* 591 */                 writer.print("  ");
/* 592 */                 writer.println(values.next());
/*     */               }
/* 594 */               values = getUsers();
/* 595 */               while (values.hasNext()) {
/* 596 */                 writer.print("  ");
/* 597 */                 writer.println(((MemoryUser)values.next()).toXml());
/*     */               }
/*     */               
/*     */ 
/* 601 */               writer.println("</tomcat-users>");
/*     */               
/*     */ 
/* 604 */               if (writer.checkError()) {
/* 605 */                 throw new IOException(sm.getString("memoryUserDatabase.writeException", new Object[] {fileNew
/* 606 */                   .getAbsolutePath() }));
/*     */               }
/*     */             }
/*     */             catch (Throwable localThrowable1)
/*     */             {
/* 569 */               localThrowable11 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable4) { localThrowable10 = localThrowable4;throw localThrowable4; } finally {} } catch (Throwable localThrowable7) { localThrowable9 = localThrowable7;throw localThrowable7;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 608 */           if (fos != null) if (localThrowable9 != null) try { fos.close(); } catch (Throwable localThrowable8) { localThrowable9.addSuppressed(localThrowable8); } else fos.close();
/* 609 */         } } catch (IOException e) { if ((fileNew.exists()) && (!fileNew.delete())) {
/* 610 */           log.warn(sm.getString("memoryUserDatabase.fileDelete", new Object[] { fileNew }));
/*     */         }
/* 612 */         throw e;
/*     */       }
/* 614 */       this.lastModified = fileNew.lastModified();
/*     */     } finally {
/* 616 */       this.writeLock.unlock();
/*     */     }
/*     */     
/*     */ 
/* 620 */     File fileOld = new File(this.pathnameOld);
/* 621 */     if (!fileOld.isAbsolute()) {
/* 622 */       fileOld = new File(System.getProperty("catalina.base"), this.pathnameOld);
/*     */     }
/* 624 */     if ((fileOld.exists()) && (!fileOld.delete())) {
/* 625 */       throw new IOException(sm.getString("memoryUserDatabase.fileDelete", new Object[] { fileOld }));
/*     */     }
/* 627 */     File fileOrig = new File(this.pathname);
/* 628 */     if (!fileOrig.isAbsolute()) {
/* 629 */       fileOrig = new File(System.getProperty("catalina.base"), this.pathname);
/*     */     }
/* 631 */     if ((fileOrig.exists()) && 
/* 632 */       (!fileOrig.renameTo(fileOld))) {
/* 633 */       throw new IOException(sm.getString("memoryUserDatabase.renameOld", new Object[] {fileOld
/* 634 */         .getAbsolutePath() }));
/*     */     }
/*     */     
/* 637 */     if (!fileNew.renameTo(fileOrig)) {
/* 638 */       if ((fileOld.exists()) && 
/* 639 */         (!fileOld.renameTo(fileOrig))) {
/* 640 */         log.warn(sm.getString("memoryUserDatabase.restoreOrig", new Object[] { fileOld }));
/*     */       }
/*     */       
/* 643 */       throw new IOException(sm.getString("memoryUserDatabase.renameNew", new Object[] {fileOrig
/* 644 */         .getAbsolutePath() }));
/*     */     }
/* 646 */     if ((fileOld.exists()) && (!fileOld.delete())) {
/* 647 */       throw new IOException(sm.getString("memoryUserDatabase.fileDelete", new Object[] { fileOld }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void backgroundProcess()
/*     */   {
/* 654 */     if (!this.watchSource) {
/* 655 */       return;
/*     */     }
/*     */     
/* 658 */     URI uri = ConfigFileLoader.getSource().getURI(getPathname());
/* 659 */     URLConnection uConn = null;
/*     */     try {
/* 661 */       URL url = uri.toURL();
/* 662 */       uConn = url.openConnection();
/*     */       
/* 664 */       if (this.lastModified != uConn.getLastModified()) {
/* 665 */         this.writeLock.lock();
/*     */         try {
/* 667 */           long detectedLastModified = uConn.getLastModified();
/*     */           
/*     */ 
/*     */ 
/* 671 */           if ((this.lastModified != detectedLastModified) && 
/* 672 */             (detectedLastModified + 2000L < System.currentTimeMillis())) {
/* 673 */             log.info(sm.getString("memoryUserDatabase.reload", new Object[] { this.id, uri }));
/* 674 */             open();
/*     */           }
/*     */         } finally {
/* 677 */           this.writeLock.unlock();
/*     */         }
/*     */       }
/*     */       return;
/* 681 */     } catch (Exception ioe) { log.error(sm.getString("memoryUserDatabase.reloadError", new Object[] { this.id, uri }), ioe);
/*     */     } finally {
/* 683 */       if (uConn != null) {
/*     */         try
/*     */         {
/* 686 */           uConn.getInputStream().close();
/*     */ 
/*     */         }
/*     */         catch (FileNotFoundException fnfe)
/*     */         {
/* 691 */           this.lastModified = 0L;
/*     */         } catch (IOException ioe) {
/* 693 */           log.warn(sm.getString("memoryUserDatabase.fileClose", new Object[] { this.pathname }), ioe);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 705 */     StringBuilder sb = new StringBuilder("MemoryUserDatabase[id=");
/* 706 */     sb.append(this.id);
/* 707 */     sb.append(",pathname=");
/* 708 */     sb.append(this.pathname);
/* 709 */     sb.append(",groupCount=");
/* 710 */     sb.append(this.groups.size());
/* 711 */     sb.append(",roleCount=");
/* 712 */     sb.append(this.roles.size());
/* 713 */     sb.append(",userCount=");
/* 714 */     sb.append(this.users.size());
/* 715 */     sb.append(']');
/* 716 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\users\MemoryUserDatabase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */