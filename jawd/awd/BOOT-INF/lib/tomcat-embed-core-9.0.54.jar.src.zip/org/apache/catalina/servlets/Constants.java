package org.apache.catalina.servlets;

@Deprecated
public class Constants
{
  public static final String Package = "org.apache.catalina.servlets";
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\servlets\Constants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */