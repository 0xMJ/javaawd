/*     */ package org.apache.catalina.mapper;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerEvent;
/*     */ import org.apache.catalina.ContainerListener;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapperListener
/*     */   extends LifecycleMBeanBase
/*     */   implements ContainerListener, LifecycleListener
/*     */ {
/*  52 */   private static final Log log = LogFactory.getLog(MapperListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Mapper mapper;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Service service;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.mapper");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  76 */   private final String domain = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MapperListener(Service service)
/*     */   {
/*  87 */     this.service = service;
/*  88 */     this.mapper = service.getMapper();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startInternal()
/*     */     throws LifecycleException
/*     */   {
/*  97 */     setState(LifecycleState.STARTING);
/*     */     
/*  99 */     Engine engine = this.service.getContainer();
/* 100 */     if (engine == null) {
/* 101 */       return;
/*     */     }
/*     */     
/* 104 */     findDefaultHost();
/*     */     
/* 106 */     addListeners(engine);
/*     */     
/* 108 */     Container[] conHosts = engine.findChildren();
/* 109 */     for (Container conHost : conHosts) {
/* 110 */       Host host = (Host)conHost;
/* 111 */       if (!LifecycleState.NEW.equals(host.getState()))
/*     */       {
/* 113 */         registerHost(host);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 121 */     setState(LifecycleState.STOPPING);
/*     */     
/* 123 */     Engine engine = this.service.getContainer();
/* 124 */     if (engine == null) {
/* 125 */       return;
/*     */     }
/* 127 */     removeListeners(engine);
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getDomainInternal()
/*     */   {
/* 133 */     if ((this.service instanceof LifecycleMBeanBase)) {
/* 134 */       return this.service.getDomain();
/*     */     }
/* 136 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getObjectNameKeyProperties()
/*     */   {
/* 144 */     return "type=Mapper";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void containerEvent(ContainerEvent event)
/*     */   {
/* 152 */     if ("addChild".equals(event.getType())) {
/* 153 */       Container child = (Container)event.getData();
/* 154 */       addListeners(child);
/*     */       
/*     */ 
/* 157 */       if (child.getState().isAvailable()) {
/* 158 */         if ((child instanceof Host)) {
/* 159 */           registerHost((Host)child);
/* 160 */         } else if ((child instanceof Context)) {
/* 161 */           registerContext((Context)child);
/* 162 */         } else if ((child instanceof Wrapper))
/*     */         {
/*     */ 
/* 165 */           if (child.getParent().getState().isAvailable()) {
/* 166 */             registerWrapper((Wrapper)child);
/*     */           }
/*     */         }
/*     */       }
/* 170 */     } else if ("removeChild".equals(event.getType())) {
/* 171 */       Container child = (Container)event.getData();
/* 172 */       removeListeners(child);
/*     */ 
/*     */     }
/* 175 */     else if ("addAlias".equals(event.getType()))
/*     */     {
/* 177 */       this.mapper.addHostAlias(((Host)event.getSource()).getName(), event
/* 178 */         .getData().toString());
/* 179 */     } else if ("removeAlias".equals(event.getType()))
/*     */     {
/* 181 */       this.mapper.removeHostAlias(event.getData().toString());
/* 182 */     } else if ("addMapping".equals(event.getType()))
/*     */     {
/* 184 */       Wrapper wrapper = (Wrapper)event.getSource();
/* 185 */       Context context = (Context)wrapper.getParent();
/* 186 */       String contextPath = context.getPath();
/* 187 */       if ("/".equals(contextPath)) {
/* 188 */         contextPath = "";
/*     */       }
/* 190 */       String version = context.getWebappVersion();
/* 191 */       String hostName = context.getParent().getName();
/* 192 */       String wrapperName = wrapper.getName();
/* 193 */       String mapping = (String)event.getData();
/*     */       
/* 195 */       boolean jspWildCard = ("jsp".equals(wrapperName)) && (mapping.endsWith("/*"));
/* 196 */       this.mapper.addWrapper(hostName, contextPath, version, mapping, wrapper, jspWildCard, context
/* 197 */         .isResourceOnlyServlet(wrapperName));
/* 198 */     } else if ("removeMapping".equals(event.getType()))
/*     */     {
/* 200 */       Wrapper wrapper = (Wrapper)event.getSource();
/*     */       
/* 202 */       Context context = (Context)wrapper.getParent();
/* 203 */       String contextPath = context.getPath();
/* 204 */       if ("/".equals(contextPath)) {
/* 205 */         contextPath = "";
/*     */       }
/* 207 */       String version = context.getWebappVersion();
/* 208 */       String hostName = context.getParent().getName();
/*     */       
/* 210 */       String mapping = (String)event.getData();
/*     */       
/* 212 */       this.mapper.removeWrapper(hostName, contextPath, version, mapping);
/* 213 */     } else if ("addWelcomeFile".equals(event.getType()))
/*     */     {
/* 215 */       Context context = (Context)event.getSource();
/*     */       
/* 217 */       String hostName = context.getParent().getName();
/*     */       
/* 219 */       String contextPath = context.getPath();
/* 220 */       if ("/".equals(contextPath)) {
/* 221 */         contextPath = "";
/*     */       }
/*     */       
/* 224 */       String welcomeFile = (String)event.getData();
/*     */       
/* 226 */       this.mapper.addWelcomeFile(hostName, contextPath, context
/* 227 */         .getWebappVersion(), welcomeFile);
/* 228 */     } else if ("removeWelcomeFile".equals(event.getType()))
/*     */     {
/* 230 */       Context context = (Context)event.getSource();
/*     */       
/* 232 */       String hostName = context.getParent().getName();
/*     */       
/* 234 */       String contextPath = context.getPath();
/* 235 */       if ("/".equals(contextPath)) {
/* 236 */         contextPath = "";
/*     */       }
/*     */       
/* 239 */       String welcomeFile = (String)event.getData();
/*     */       
/* 241 */       this.mapper.removeWelcomeFile(hostName, contextPath, context
/* 242 */         .getWebappVersion(), welcomeFile);
/* 243 */     } else if ("clearWelcomeFiles".equals(event.getType()))
/*     */     {
/* 245 */       Context context = (Context)event.getSource();
/*     */       
/* 247 */       String hostName = context.getParent().getName();
/*     */       
/* 249 */       String contextPath = context.getPath();
/* 250 */       if ("/".equals(contextPath)) {
/* 251 */         contextPath = "";
/*     */       }
/*     */       
/* 254 */       this.mapper.clearWelcomeFiles(hostName, contextPath, context
/* 255 */         .getWebappVersion());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void findDefaultHost()
/*     */   {
/* 264 */     Engine engine = this.service.getContainer();
/* 265 */     String defaultHost = engine.getDefaultHost();
/*     */     
/* 267 */     boolean found = false;
/*     */     
/* 269 */     if ((defaultHost != null) && (defaultHost.length() > 0)) {
/* 270 */       Container[] containers = engine.findChildren();
/*     */       
/* 272 */       for (Container container : containers) {
/* 273 */         Host host = (Host)container;
/* 274 */         if (defaultHost.equalsIgnoreCase(host.getName())) {
/* 275 */           found = true;
/* 276 */           break;
/*     */         }
/*     */         
/* 279 */         String[] aliases = host.findAliases();
/* 280 */         for (String alias : aliases) {
/* 281 */           if (defaultHost.equalsIgnoreCase(alias)) {
/* 282 */             found = true;
/* 283 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 289 */     if (found) {
/* 290 */       this.mapper.setDefaultHostName(defaultHost);
/*     */     } else {
/* 292 */       log.error(sm.getString("mapperListener.unknownDefaultHost", new Object[] { defaultHost, this.service }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void registerHost(Host host)
/*     */   {
/* 302 */     String[] aliases = host.findAliases();
/* 303 */     this.mapper.addHost(host.getName(), aliases, host);
/*     */     
/* 305 */     for (Container container : host.findChildren()) {
/* 306 */       if (container.getState().isAvailable()) {
/* 307 */         registerContext((Context)container);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 312 */     findDefaultHost();
/*     */     
/* 314 */     if (log.isDebugEnabled()) {
/* 315 */       log.debug(sm.getString("mapperListener.registerHost", new Object[] {host
/* 316 */         .getName(), this.domain, this.service }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void unregisterHost(Host host)
/*     */   {
/* 326 */     String hostname = host.getName();
/*     */     
/* 328 */     this.mapper.removeHost(hostname);
/*     */     
/*     */ 
/* 331 */     findDefaultHost();
/*     */     
/* 333 */     if (log.isDebugEnabled()) {
/* 334 */       log.debug(sm.getString("mapperListener.unregisterHost", new Object[] { hostname, this.domain, this.service }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void unregisterWrapper(Wrapper wrapper)
/*     */   {
/* 345 */     Context context = (Context)wrapper.getParent();
/* 346 */     String contextPath = context.getPath();
/* 347 */     String wrapperName = wrapper.getName();
/*     */     
/* 349 */     if ("/".equals(contextPath)) {
/* 350 */       contextPath = "";
/*     */     }
/* 352 */     String version = context.getWebappVersion();
/* 353 */     String hostName = context.getParent().getName();
/*     */     
/* 355 */     String[] mappings = wrapper.findMappings();
/*     */     
/* 357 */     for (String mapping : mappings) {
/* 358 */       this.mapper.removeWrapper(hostName, contextPath, version, mapping);
/*     */     }
/*     */     
/* 361 */     if (log.isDebugEnabled()) {
/* 362 */       log.debug(sm.getString("mapperListener.unregisterWrapper", new Object[] { wrapperName, contextPath, this.service }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void registerContext(Context context)
/*     */   {
/* 373 */     String contextPath = context.getPath();
/* 374 */     if ("/".equals(contextPath)) {
/* 375 */       contextPath = "";
/*     */     }
/* 377 */     Host host = (Host)context.getParent();
/*     */     
/* 379 */     WebResourceRoot resources = context.getResources();
/* 380 */     String[] welcomeFiles = context.findWelcomeFiles();
/* 381 */     List<WrapperMappingInfo> wrappers = new ArrayList();
/*     */     
/* 383 */     for (Container container : context.findChildren()) {
/* 384 */       prepareWrapperMappingInfo(context, (Wrapper)container, wrappers);
/*     */       
/* 386 */       if (log.isDebugEnabled()) {
/* 387 */         log.debug(sm.getString("mapperListener.registerWrapper", new Object[] {container
/* 388 */           .getName(), contextPath, this.service }));
/*     */       }
/*     */     }
/*     */     
/* 392 */     this.mapper.addContextVersion(host.getName(), host, contextPath, context
/* 393 */       .getWebappVersion(), context, welcomeFiles, resources, wrappers);
/*     */     
/*     */ 
/* 396 */     if (log.isDebugEnabled()) {
/* 397 */       log.debug(sm.getString("mapperListener.registerContext", new Object[] { contextPath, this.service }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void unregisterContext(Context context)
/*     */   {
/* 408 */     String contextPath = context.getPath();
/* 409 */     if ("/".equals(contextPath)) {
/* 410 */       contextPath = "";
/*     */     }
/* 412 */     String hostName = context.getParent().getName();
/*     */     
/* 414 */     if (context.getPaused()) {
/* 415 */       if (log.isDebugEnabled()) {
/* 416 */         log.debug(sm.getString("mapperListener.pauseContext", new Object[] { contextPath, this.service }));
/*     */       }
/*     */       
/*     */ 
/* 420 */       this.mapper.pauseContextVersion(context, hostName, contextPath, context
/* 421 */         .getWebappVersion());
/*     */     } else {
/* 423 */       if (log.isDebugEnabled()) {
/* 424 */         log.debug(sm.getString("mapperListener.unregisterContext", new Object[] { contextPath, this.service }));
/*     */       }
/*     */       
/*     */ 
/* 428 */       this.mapper.removeContextVersion(context, hostName, contextPath, context
/* 429 */         .getWebappVersion());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void registerWrapper(Wrapper wrapper)
/*     */   {
/* 439 */     Context context = (Context)wrapper.getParent();
/* 440 */     String contextPath = context.getPath();
/* 441 */     if ("/".equals(contextPath)) {
/* 442 */       contextPath = "";
/*     */     }
/* 444 */     String version = context.getWebappVersion();
/* 445 */     String hostName = context.getParent().getName();
/*     */     
/* 447 */     List<WrapperMappingInfo> wrappers = new ArrayList();
/* 448 */     prepareWrapperMappingInfo(context, wrapper, wrappers);
/* 449 */     this.mapper.addWrappers(hostName, contextPath, version, wrappers);
/*     */     
/* 451 */     if (log.isDebugEnabled()) {
/* 452 */       log.debug(sm.getString("mapperListener.registerWrapper", new Object[] {wrapper
/* 453 */         .getName(), contextPath, this.service }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prepareWrapperMappingInfo(Context context, Wrapper wrapper, List<WrapperMappingInfo> wrappers)
/*     */   {
/* 463 */     String wrapperName = wrapper.getName();
/* 464 */     boolean resourceOnly = context.isResourceOnlyServlet(wrapperName);
/* 465 */     String[] mappings = wrapper.findMappings();
/* 466 */     for (String mapping : mappings)
/*     */     {
/* 468 */       boolean jspWildCard = (wrapperName.equals("jsp")) && (mapping.endsWith("/*"));
/* 469 */       wrappers.add(new WrapperMappingInfo(mapping, wrapper, jspWildCard, resourceOnly));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void lifecycleEvent(LifecycleEvent event)
/*     */   {
/* 476 */     if (event.getType().equals("after_start")) {
/* 477 */       Object obj = event.getSource();
/* 478 */       if ((obj instanceof Wrapper)) {
/* 479 */         Wrapper w = (Wrapper)obj;
/*     */         
/*     */ 
/* 482 */         if (w.getParent().getState().isAvailable()) {
/* 483 */           registerWrapper(w);
/*     */         }
/* 485 */       } else if ((obj instanceof Context)) {
/* 486 */         Context c = (Context)obj;
/*     */         
/*     */ 
/* 489 */         if (c.getParent().getState().isAvailable()) {
/* 490 */           registerContext(c);
/*     */         }
/* 492 */       } else if ((obj instanceof Host)) {
/* 493 */         registerHost((Host)obj);
/*     */       }
/* 495 */     } else if (event.getType().equals("before_stop")) {
/* 496 */       Object obj = event.getSource();
/* 497 */       if ((obj instanceof Wrapper)) {
/* 498 */         unregisterWrapper((Wrapper)obj);
/* 499 */       } else if ((obj instanceof Context)) {
/* 500 */         unregisterContext((Context)obj);
/* 501 */       } else if ((obj instanceof Host)) {
/* 502 */         unregisterHost((Host)obj);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addListeners(Container container)
/*     */   {
/* 514 */     container.addContainerListener(this);
/* 515 */     container.addLifecycleListener(this);
/* 516 */     for (Container child : container.findChildren()) {
/* 517 */       addListeners(child);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void removeListeners(Container container)
/*     */   {
/* 528 */     container.removeContainerListener(this);
/* 529 */     container.removeLifecycleListener(this);
/* 530 */     for (Container child : container.findChildren()) {
/* 531 */       removeListeners(child);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mapper\MapperListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */