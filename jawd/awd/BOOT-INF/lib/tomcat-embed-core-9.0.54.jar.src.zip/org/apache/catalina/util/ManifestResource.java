/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.Manifest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManifestResource
/*     */ {
/*     */   public static final int SYSTEM = 1;
/*     */   public static final int WAR = 2;
/*     */   public static final int APPLICATION = 3;
/*  39 */   private ArrayList<Extension> availableExtensions = null;
/*  40 */   private ArrayList<Extension> requiredExtensions = null;
/*     */   
/*     */   private final String resourceName;
/*     */   private final int resourceType;
/*     */   
/*     */   public ManifestResource(String resourceName, Manifest manifest, int resourceType)
/*     */   {
/*  47 */     this.resourceName = resourceName;
/*  48 */     this.resourceType = resourceType;
/*  49 */     processManifest(manifest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getResourceName()
/*     */   {
/*  58 */     return this.resourceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArrayList<Extension> getAvailableExtensions()
/*     */   {
/*  67 */     return this.availableExtensions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArrayList<Extension> getRequiredExtensions()
/*     */   {
/*  76 */     return this.requiredExtensions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAvailableExtensionCount()
/*     */   {
/*  87 */     return this.availableExtensions != null ? this.availableExtensions.size() : 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRequiredExtensionCount()
/*     */   {
/*  96 */     return this.requiredExtensions != null ? this.requiredExtensions.size() : 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFulfilled()
/*     */   {
/* 106 */     if (this.requiredExtensions == null) {
/* 107 */       return true;
/*     */     }
/* 109 */     for (Extension ext : this.requiredExtensions) {
/* 110 */       if (!ext.isFulfilled()) {
/* 111 */         return false;
/*     */       }
/*     */     }
/* 114 */     return true;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 119 */     StringBuilder sb = new StringBuilder("ManifestResource[");
/* 120 */     sb.append(this.resourceName);
/*     */     
/* 122 */     sb.append(", isFulfilled=");
/* 123 */     sb.append(isFulfilled() + "");
/* 124 */     sb.append(", requiredExtensionCount =");
/* 125 */     sb.append(getRequiredExtensionCount());
/* 126 */     sb.append(", availableExtensionCount=");
/* 127 */     sb.append(getAvailableExtensionCount());
/* 128 */     switch (this.resourceType) {
/* 129 */     case 1:  sb.append(", resourceType=SYSTEM"); break;
/* 130 */     case 2:  sb.append(", resourceType=WAR"); break;
/* 131 */     case 3:  sb.append(", resourceType=APPLICATION");
/*     */     }
/* 133 */     sb.append(']');
/* 134 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void processManifest(Manifest manifest)
/*     */   {
/* 141 */     this.availableExtensions = getAvailableExtensions(manifest);
/* 142 */     this.requiredExtensions = getRequiredExtensions(manifest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<Extension> getRequiredExtensions(Manifest manifest)
/*     */   {
/* 157 */     Attributes attributes = manifest.getMainAttributes();
/* 158 */     String names = attributes.getValue("Extension-List");
/* 159 */     if (names == null) {
/* 160 */       return null;
/*     */     }
/*     */     
/* 163 */     ArrayList<Extension> extensionList = new ArrayList();
/* 164 */     names = names + " ";
/*     */     
/*     */     for (;;)
/*     */     {
/* 168 */       int space = names.indexOf(' ');
/* 169 */       if (space < 0) {
/*     */         break;
/*     */       }
/* 172 */       String name = names.substring(0, space).trim();
/* 173 */       names = names.substring(space + 1);
/*     */       
/*     */ 
/* 176 */       String value = attributes.getValue(name + "-Extension-Name");
/* 177 */       if (value != null)
/*     */       {
/*     */ 
/* 180 */         Extension extension = new Extension();
/* 181 */         extension.setExtensionName(value);
/* 182 */         extension
/* 183 */           .setImplementationURL(attributes.getValue(name + "-Implementation-URL"));
/* 184 */         extension
/* 185 */           .setImplementationVendorId(attributes.getValue(name + "-Implementation-Vendor-Id"));
/* 186 */         String version = attributes.getValue(name + "-Implementation-Version");
/* 187 */         extension.setImplementationVersion(version);
/* 188 */         extension
/* 189 */           .setSpecificationVersion(attributes.getValue(name + "-Specification-Version"));
/* 190 */         extensionList.add(extension);
/*     */       } }
/* 192 */     return extensionList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArrayList<Extension> getAvailableExtensions(Manifest manifest)
/*     */   {
/* 207 */     Attributes attributes = manifest.getMainAttributes();
/* 208 */     String name = attributes.getValue("Extension-Name");
/* 209 */     if (name == null) {
/* 210 */       return null;
/*     */     }
/*     */     
/* 213 */     ArrayList<Extension> extensionList = new ArrayList();
/*     */     
/* 215 */     Extension extension = new Extension();
/* 216 */     extension.setExtensionName(name);
/* 217 */     extension.setImplementationURL(attributes
/* 218 */       .getValue("Implementation-URL"));
/* 219 */     extension.setImplementationVendor(attributes
/* 220 */       .getValue("Implementation-Vendor"));
/* 221 */     extension.setImplementationVendorId(attributes
/* 222 */       .getValue("Implementation-Vendor-Id"));
/* 223 */     extension.setImplementationVersion(attributes
/* 224 */       .getValue("Implementation-Version"));
/* 225 */     extension.setSpecificationVersion(attributes
/* 226 */       .getValue("Specification-Version"));
/*     */     
/* 228 */     extensionList.add(extension);
/*     */     
/* 230 */     return extensionList;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\ManifestResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */