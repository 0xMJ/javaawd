/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLAuthenticator
/*     */   extends AuthenticatorBase
/*     */ {
/*     */   protected boolean doAuthenticate(org.apache.catalina.connector.Request request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/*  62 */     if (checkForCachedAuthentication(request, response, false)) {
/*  63 */       return true;
/*     */     }
/*     */     
/*     */ 
/*  67 */     if (this.containerLog.isDebugEnabled()) {
/*  68 */       this.containerLog.debug(" Looking up certificates");
/*     */     }
/*     */     
/*  71 */     X509Certificate[] certs = getRequestCertificates(request);
/*     */     
/*  73 */     if ((certs == null) || (certs.length < 1)) {
/*  74 */       if (this.containerLog.isDebugEnabled()) {
/*  75 */         this.containerLog.debug("  No certificates included with this request");
/*     */       }
/*  77 */       response.sendError(401, sm
/*  78 */         .getString("authenticator.certificates"));
/*  79 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  83 */     Principal principal = this.context.getRealm().authenticate(certs);
/*  84 */     if (principal == null) {
/*  85 */       if (this.containerLog.isDebugEnabled()) {
/*  86 */         this.containerLog.debug("  Realm.authenticate() returned false");
/*     */       }
/*  88 */       response.sendError(401, sm
/*  89 */         .getString("authenticator.unauthorized"));
/*  90 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  94 */     register(request, response, principal, "CLIENT_CERT", null, null);
/*     */     
/*  96 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getAuthMethod()
/*     */   {
/* 103 */     return "CLIENT_CERT";
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean isPreemptiveAuthPossible(org.apache.catalina.connector.Request request)
/*     */   {
/* 109 */     X509Certificate[] certs = getRequestCertificates(request);
/* 110 */     return (certs != null) && (certs.length > 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected X509Certificate[] getRequestCertificates(org.apache.catalina.connector.Request request)
/*     */     throws IllegalStateException
/*     */   {
/* 128 */     X509Certificate[] certs = (X509Certificate[])request.getAttribute("javax.servlet.request.X509Certificate");
/*     */     
/* 130 */     if ((certs == null) || (certs.length < 1)) {
/*     */       try {
/* 132 */         request.getCoyoteRequest().action(ActionCode.REQ_SSL_CERTIFICATE, null);
/* 133 */         certs = (X509Certificate[])request.getAttribute("javax.servlet.request.X509Certificate");
/*     */       }
/*     */       catch (IllegalStateException localIllegalStateException) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 140 */     return certs;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\authenticator\SSLAuthenticator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */