/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.ietf.jgss.GSSContext;
/*     */ import org.ietf.jgss.GSSCredential;
/*     */ import org.ietf.jgss.GSSException;
/*     */ import org.ietf.jgss.GSSName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LockOutRealm
/*     */   extends CombinedRealm
/*     */ {
/*  47 */   private static final Log log = LogFactory.getLog(LockOutRealm.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */   protected int failureCount = 5;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  59 */   protected int lockOutTime = 300;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */   protected int cacheSize = 1000;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   protected int cacheRemovalWarningTime = 3600;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   protected Map<String, LockRecord> failedUsers = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/*  94 */     this.failedUsers = new LinkedHashMap(this.cacheSize, 0.75F, true)
/*     */     {
/*     */       private static final long serialVersionUID = 1L;
/*     */       
/*     */       protected boolean removeEldestEntry(Map.Entry<String, LockOutRealm.LockRecord> eldest)
/*     */       {
/* 100 */         if (size() > LockOutRealm.this.cacheSize)
/*     */         {
/*     */ 
/* 103 */           long timeInCache = (System.currentTimeMillis() - ((LockOutRealm.LockRecord)eldest.getValue()).getLastFailureTime()) / 1000L;
/*     */           
/* 105 */           if (timeInCache < LockOutRealm.this.cacheRemovalWarningTime) {
/* 106 */             LockOutRealm.log.warn(RealmBase.sm.getString("lockOutRealm.removeWarning", new Object[] {eldest
/* 107 */               .getKey(), Long.valueOf(timeInCache) }));
/*     */           }
/* 109 */           return true;
/*     */         }
/* 111 */         return false;
/*     */       }
/*     */       
/* 114 */     };
/* 115 */     super.startInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realmName, String md5a2)
/*     */   {
/* 137 */     Principal authenticatedUser = super.authenticate(username, clientDigest, nonce, nc, cnonce, qop, realmName, md5a2);
/*     */     
/* 139 */     return filterLockedAccounts(username, authenticatedUser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(String username, String credentials)
/*     */   {
/* 153 */     Principal authenticatedUser = super.authenticate(username, credentials);
/* 154 */     return filterLockedAccounts(username, authenticatedUser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(X509Certificate[] certs)
/*     */   {
/* 167 */     String username = null;
/* 168 */     if ((certs != null) && (certs.length > 0)) {
/* 169 */       username = certs[0].getSubjectDN().getName();
/*     */     }
/*     */     
/* 172 */     Principal authenticatedUser = super.authenticate(certs);
/* 173 */     return filterLockedAccounts(username, authenticatedUser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(GSSContext gssContext, boolean storeCreds)
/*     */   {
/* 182 */     if (gssContext.isEstablished()) {
/* 183 */       String username = null;
/* 184 */       GSSName name = null;
/*     */       try {
/* 186 */         name = gssContext.getSrcName();
/*     */       } catch (GSSException e) {
/* 188 */         log.warn(sm.getString("realmBase.gssNameFail"), e);
/* 189 */         return null;
/*     */       }
/*     */       
/* 192 */       username = name.toString();
/*     */       
/* 194 */       Principal authenticatedUser = super.authenticate(gssContext, storeCreds);
/*     */       
/* 196 */       return filterLockedAccounts(username, authenticatedUser);
/*     */     }
/*     */     
/*     */ 
/* 200 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Principal authenticate(GSSName gssName, GSSCredential gssCredential)
/*     */   {
/* 208 */     String username = gssName.toString();
/*     */     
/* 210 */     Principal authenticatedUser = super.authenticate(gssName, gssCredential);
/*     */     
/* 212 */     return filterLockedAccounts(username, authenticatedUser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Principal filterLockedAccounts(String username, Principal authenticatedUser)
/*     */   {
/* 222 */     if ((authenticatedUser == null) && (isAvailable())) {
/* 223 */       registerAuthFailure(username);
/*     */     }
/*     */     
/* 226 */     if (isLocked(username))
/*     */     {
/* 228 */       log.warn(sm.getString("lockOutRealm.authLockedUser", new Object[] { username }));
/* 229 */       return null;
/*     */     }
/*     */     
/* 232 */     if (authenticatedUser != null) {
/* 233 */       registerAuthSuccess(username);
/*     */     }
/*     */     
/* 236 */     return authenticatedUser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void unlock(String username)
/*     */   {
/* 248 */     registerAuthSuccess(username);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLocked(String username)
/*     */   {
/* 257 */     LockRecord lockRecord = null;
/* 258 */     synchronized (this) {
/* 259 */       lockRecord = (LockRecord)this.failedUsers.get(username);
/*     */     }
/*     */     
/*     */ 
/* 263 */     if (lockRecord == null) {
/* 264 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 268 */     if (lockRecord.getFailures() >= this.failureCount)
/*     */     {
/* 270 */       if ((System.currentTimeMillis() - lockRecord.getLastFailureTime()) / 1000L < this.lockOutTime) {
/* 271 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 275 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void registerAuthSuccess(String username)
/*     */   {
/* 285 */     this.failedUsers.remove(username);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void registerAuthFailure(String username)
/*     */   {
/* 294 */     LockRecord lockRecord = null;
/* 295 */     synchronized (this) {
/* 296 */       if (!this.failedUsers.containsKey(username)) {
/* 297 */         lockRecord = new LockRecord();
/* 298 */         this.failedUsers.put(username, lockRecord);
/*     */       } else {
/* 300 */         lockRecord = (LockRecord)this.failedUsers.get(username);
/* 301 */         if (lockRecord.getFailures() >= this.failureCount)
/*     */         {
/* 303 */           if ((System.currentTimeMillis() - lockRecord.getLastFailureTime()) / 1000L > this.lockOutTime)
/*     */           {
/*     */ 
/*     */ 
/* 307 */             lockRecord.setFailures(0); }
/*     */         }
/*     */       }
/*     */     }
/* 311 */     lockRecord.registerFailure();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFailureCount()
/*     */   {
/* 321 */     return this.failureCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFailureCount(int failureCount)
/*     */   {
/* 331 */     this.failureCount = failureCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLockOutTime()
/*     */   {
/* 340 */     return this.lockOutTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLockOutTime(int lockOutTime)
/*     */   {
/* 349 */     this.lockOutTime = lockOutTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCacheSize()
/*     */   {
/* 359 */     return this.cacheSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheSize(int cacheSize)
/*     */   {
/* 369 */     this.cacheSize = cacheSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCacheRemovalWarningTime()
/*     */   {
/* 380 */     return this.cacheRemovalWarningTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheRemovalWarningTime(int cacheRemovalWarningTime)
/*     */   {
/* 391 */     this.cacheRemovalWarningTime = cacheRemovalWarningTime;
/*     */   }
/*     */   
/*     */   protected static class LockRecord
/*     */   {
/* 396 */     private final AtomicInteger failures = new AtomicInteger(0);
/* 397 */     private long lastFailureTime = 0L;
/*     */     
/*     */     public int getFailures() {
/* 400 */       return this.failures.get();
/*     */     }
/*     */     
/*     */     public void setFailures(int theFailures) {
/* 404 */       this.failures.set(theFailures);
/*     */     }
/*     */     
/*     */     public long getLastFailureTime() {
/* 408 */       return this.lastFailureTime;
/*     */     }
/*     */     
/*     */     public void registerFailure() {
/* 412 */       this.failures.incrementAndGet();
/* 413 */       this.lastFailureTime = System.currentTimeMillis();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\LockOutRealm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */