/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.net.InetAddress;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.core.StandardEngine;
/*     */ import org.apache.catalina.core.StandardHost;
/*     */ import org.apache.catalina.core.StandardService;
/*     */ import org.apache.catalina.loader.WebappLoader;
/*     */ import org.apache.catalina.realm.DataSourceRealm;
/*     */ import org.apache.catalina.realm.JDBCRealm;
/*     */ import org.apache.catalina.realm.JNDIRealm;
/*     */ import org.apache.catalina.realm.MemoryRealm;
/*     */ import org.apache.catalina.realm.UserDatabaseRealm;
/*     */ import org.apache.catalina.session.StandardManager;
/*     */ import org.apache.catalina.startup.HostConfig;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanFactory
/*     */ {
/*  57 */   private static final Log log = LogFactory.getLog(MBeanFactory.class);
/*     */   
/*  59 */   protected static final StringManager sm = StringManager.getManager(MBeanFactory.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  64 */   private static final MBeanServer mserver = MBeanUtils.createServer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object container;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContainer(Object container)
/*     */   {
/*  82 */     this.container = container;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String getPathStr(String t)
/*     */   {
/*  94 */     if ((t == null) || (t.equals("/"))) {
/*  95 */       return "";
/*     */     }
/*  97 */     return t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Container getParentContainerFromParent(ObjectName pname)
/*     */     throws Exception
/*     */   {
/* 107 */     String type = pname.getKeyProperty("type");
/* 108 */     String j2eeType = pname.getKeyProperty("j2eeType");
/* 109 */     Service service = getService(pname);
/* 110 */     StandardEngine engine = (StandardEngine)service.getContainer();
/* 111 */     if ((j2eeType != null) && (j2eeType.equals("WebModule"))) {
/* 112 */       String name = pname.getKeyProperty("name");
/* 113 */       name = name.substring(2);
/* 114 */       int i = name.indexOf('/');
/* 115 */       String hostName = name.substring(0, i);
/* 116 */       String path = name.substring(i);
/* 117 */       Container host = engine.findChild(hostName);
/* 118 */       String pathStr = getPathStr(path);
/* 119 */       Container context = host.findChild(pathStr);
/* 120 */       return context; }
/* 121 */     if (type != null) {
/* 122 */       if (type.equals("Engine"))
/* 123 */         return engine;
/* 124 */       if (type.equals("Host")) {
/* 125 */         String hostName = pname.getKeyProperty("host");
/* 126 */         Container host = engine.findChild(hostName);
/* 127 */         return host;
/*     */       }
/*     */     }
/* 130 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Container getParentContainerFromChild(ObjectName oname)
/*     */     throws Exception
/*     */   {
/* 142 */     String hostName = oname.getKeyProperty("host");
/* 143 */     String path = oname.getKeyProperty("path");
/* 144 */     Service service = getService(oname);
/* 145 */     Container engine = service.getContainer();
/* 146 */     if (hostName == null)
/*     */     {
/* 148 */       return engine; }
/* 149 */     if (path == null)
/*     */     {
/* 151 */       Container host = engine.findChild(hostName);
/* 152 */       return host;
/*     */     }
/*     */     
/* 155 */     Container host = engine.findChild(hostName);
/* 156 */     path = getPathStr(path);
/* 157 */     Container context = host.findChild(path);
/* 158 */     return context;
/*     */   }
/*     */   
/*     */ 
/*     */   private Service getService(ObjectName oname)
/*     */     throws Exception
/*     */   {
/* 165 */     if ((this.container instanceof Service))
/*     */     {
/* 167 */       return (Service)this.container;
/*     */     }
/*     */     
/* 170 */     StandardService service = null;
/* 171 */     String domain = oname.getDomain();
/* 172 */     if ((this.container instanceof Server)) {
/* 173 */       Service[] services = ((Server)this.container).findServices();
/* 174 */       for (Service value : services) {
/* 175 */         service = (StandardService)value;
/* 176 */         if (domain.equals(service.getObjectName().getDomain())) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/* 181 */     if ((service == null) || 
/* 182 */       (!service.getObjectName().getDomain().equals(domain))) {
/* 183 */       throw new Exception(sm.getString("mBeanFactory.noService", new Object[] { domain }));
/*     */     }
/* 185 */     return service;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createAjpConnector(String parent, String address, int port)
/*     */     throws Exception
/*     */   {
/* 203 */     return createConnector(parent, address, port, true, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createDataSourceRealm(String parent, String dataSourceName, String roleNameCol, String userCredCol, String userNameCol, String userRoleTable, String userTable)
/*     */     throws Exception
/*     */   {
/* 225 */     DataSourceRealm realm = new DataSourceRealm();
/* 226 */     realm.setDataSourceName(dataSourceName);
/* 227 */     realm.setRoleNameCol(roleNameCol);
/* 228 */     realm.setUserCredCol(userCredCol);
/* 229 */     realm.setUserNameCol(userNameCol);
/* 230 */     realm.setUserRoleTable(userRoleTable);
/* 231 */     realm.setUserTable(userTable);
/*     */     
/*     */ 
/* 234 */     return addRealmToParent(parent, realm);
/*     */   }
/*     */   
/*     */   private String addRealmToParent(String parent, Realm realm) throws Exception
/*     */   {
/* 239 */     ObjectName pname = new ObjectName(parent);
/* 240 */     Container container = getParentContainerFromParent(pname);
/*     */     
/* 242 */     container.setRealm(realm);
/*     */     
/* 244 */     ObjectName oname = null;
/* 245 */     if ((realm instanceof JmxEnabled)) {
/* 246 */       oname = ((JmxEnabled)realm).getObjectName();
/*     */     }
/* 248 */     if (oname != null) {
/* 249 */       return oname.toString();
/*     */     }
/* 251 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createHttpConnector(String parent, String address, int port)
/*     */     throws Exception
/*     */   {
/* 268 */     return createConnector(parent, address, port, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String createConnector(String parent, String address, int port, boolean isAjp, boolean isSSL)
/*     */     throws Exception
/*     */   {
/* 286 */     String protocol = isAjp ? "AJP/1.3" : "HTTP/1.1";
/* 287 */     Connector retobj = new Connector(protocol);
/* 288 */     if ((address != null) && (address.length() > 0)) {
/* 289 */       retobj.setProperty("address", address);
/*     */     }
/*     */     
/* 292 */     retobj.setPort(port);
/*     */     
/* 294 */     retobj.setSecure(isSSL);
/* 295 */     retobj.setScheme(isSSL ? "https" : "http");
/*     */     
/*     */ 
/* 298 */     ObjectName pname = new ObjectName(parent);
/* 299 */     Service service = getService(pname);
/* 300 */     service.addConnector(retobj);
/*     */     
/*     */ 
/* 303 */     ObjectName coname = retobj.getObjectName();
/*     */     
/* 305 */     return coname.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createHttpsConnector(String parent, String address, int port)
/*     */     throws Exception
/*     */   {
/* 321 */     return createConnector(parent, address, port, false, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public String createJDBCRealm(String parent, String driverName, String connectionName, String connectionPassword, String connectionURL)
/*     */     throws Exception
/*     */   {
/* 346 */     JDBCRealm realm = new JDBCRealm();
/* 347 */     realm.setDriverName(driverName);
/* 348 */     realm.setConnectionName(connectionName);
/* 349 */     realm.setConnectionPassword(connectionPassword);
/* 350 */     realm.setConnectionURL(connectionURL);
/*     */     
/*     */ 
/* 353 */     return addRealmToParent(parent, realm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createJNDIRealm(String parent)
/*     */     throws Exception
/*     */   {
/* 368 */     JNDIRealm realm = new JNDIRealm();
/*     */     
/*     */ 
/* 371 */     return addRealmToParent(parent, realm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createMemoryRealm(String parent)
/*     */     throws Exception
/*     */   {
/* 386 */     MemoryRealm realm = new MemoryRealm();
/*     */     
/*     */ 
/* 389 */     return addRealmToParent(parent, realm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createStandardContext(String parent, String path, String docBase)
/*     */     throws Exception
/*     */   {
/* 408 */     return createStandardContext(parent, path, docBase, false, false);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public String createStandardContext(String parent, String path, String docBase, boolean xmlValidation, boolean xmlNamespaceAware)
/*     */     throws Exception
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 78	org/apache/catalina/core/StandardContext
/*     */     //   3: dup
/*     */     //   4: invokespecial 79	org/apache/catalina/core/StandardContext:<init>	()V
/*     */     //   7: astore 6
/*     */     //   9: aload_0
/*     */     //   10: aload_2
/*     */     //   11: invokespecial 18	org/apache/catalina/mbeans/MBeanFactory:getPathStr	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   14: astore_2
/*     */     //   15: aload 6
/*     */     //   17: aload_2
/*     */     //   18: invokevirtual 80	org/apache/catalina/core/StandardContext:setPath	(Ljava/lang/String;)V
/*     */     //   21: aload 6
/*     */     //   23: aload_3
/*     */     //   24: invokevirtual 81	org/apache/catalina/core/StandardContext:setDocBase	(Ljava/lang/String;)V
/*     */     //   27: aload 6
/*     */     //   29: iload 4
/*     */     //   31: invokevirtual 82	org/apache/catalina/core/StandardContext:setXmlValidation	(Z)V
/*     */     //   34: aload 6
/*     */     //   36: iload 5
/*     */     //   38: invokevirtual 83	org/apache/catalina/core/StandardContext:setXmlNamespaceAware	(Z)V
/*     */     //   41: new 84	org/apache/catalina/startup/ContextConfig
/*     */     //   44: dup
/*     */     //   45: invokespecial 85	org/apache/catalina/startup/ContextConfig:<init>	()V
/*     */     //   48: astore 7
/*     */     //   50: aload 6
/*     */     //   52: aload 7
/*     */     //   54: invokevirtual 86	org/apache/catalina/core/StandardContext:addLifecycleListener	(Lorg/apache/catalina/LifecycleListener;)V
/*     */     //   57: new 46	javax/management/ObjectName
/*     */     //   60: dup
/*     */     //   61: aload_1
/*     */     //   62: invokespecial 47	javax/management/ObjectName:<init>	(Ljava/lang/String;)V
/*     */     //   65: astore 8
/*     */     //   67: new 46	javax/management/ObjectName
/*     */     //   70: dup
/*     */     //   71: new 87	java/lang/StringBuilder
/*     */     //   74: dup
/*     */     //   75: invokespecial 88	java/lang/StringBuilder:<init>	()V
/*     */     //   78: aload 8
/*     */     //   80: invokevirtual 25	javax/management/ObjectName:getDomain	()Ljava/lang/String;
/*     */     //   83: invokevirtual 89	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   86: ldc 90
/*     */     //   88: invokevirtual 89	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   91: aload 8
/*     */     //   93: ldc 22
/*     */     //   95: invokevirtual 7	javax/management/ObjectName:getKeyProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   98: invokevirtual 89	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   101: invokevirtual 91	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   104: invokespecial 47	javax/management/ObjectName:<init>	(Ljava/lang/String;)V
/*     */     //   107: astore 9
/*     */     //   109: getstatic 92	org/apache/catalina/mbeans/MBeanFactory:mserver	Ljavax/management/MBeanServer;
/*     */     //   112: aload 9
/*     */     //   114: invokeinterface 93 2 0
/*     */     //   119: ifeq +268 -> 387
/*     */     //   122: aload 6
/*     */     //   124: invokevirtual 94	org/apache/catalina/core/StandardContext:getName	()Ljava/lang/String;
/*     */     //   127: astore 10
/*     */     //   129: getstatic 92	org/apache/catalina/mbeans/MBeanFactory:mserver	Ljavax/management/MBeanServer;
/*     */     //   132: aload 9
/*     */     //   134: ldc 95
/*     */     //   136: iconst_1
/*     */     //   137: anewarray 33	java/lang/Object
/*     */     //   140: dup
/*     */     //   141: iconst_0
/*     */     //   142: aload 10
/*     */     //   144: aastore
/*     */     //   145: iconst_1
/*     */     //   146: anewarray 96	java/lang/String
/*     */     //   149: dup
/*     */     //   150: iconst_0
/*     */     //   151: ldc 97
/*     */     //   153: aastore
/*     */     //   154: invokeinterface 98 5 0
/*     */     //   159: checkcast 99	java/lang/Boolean
/*     */     //   162: astore 11
/*     */     //   164: aload 11
/*     */     //   166: invokevirtual 100	java/lang/Boolean:booleanValue	()Z
/*     */     //   169: ifeq +190 -> 359
/*     */     //   172: getstatic 92	org/apache/catalina/mbeans/MBeanFactory:mserver	Ljavax/management/MBeanServer;
/*     */     //   175: aload 9
/*     */     //   177: ldc 101
/*     */     //   179: invokeinterface 102 3 0
/*     */     //   184: checkcast 96	java/lang/String
/*     */     //   187: astore 12
/*     */     //   189: aload 6
/*     */     //   191: invokevirtual 103	org/apache/catalina/core/StandardContext:getBaseName	()Ljava/lang/String;
/*     */     //   194: astore 13
/*     */     //   196: new 104	java/io/File
/*     */     //   199: dup
/*     */     //   200: new 104	java/io/File
/*     */     //   203: dup
/*     */     //   204: aload 12
/*     */     //   206: invokespecial 105	java/io/File:<init>	(Ljava/lang/String;)V
/*     */     //   209: new 87	java/lang/StringBuilder
/*     */     //   212: dup
/*     */     //   213: invokespecial 88	java/lang/StringBuilder:<init>	()V
/*     */     //   216: aload 13
/*     */     //   218: invokevirtual 89	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   221: ldc 106
/*     */     //   223: invokevirtual 89	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   226: invokevirtual 91	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   229: invokespecial 107	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
/*     */     //   232: astore 14
/*     */     //   234: aload 14
/*     */     //   236: invokevirtual 108	java/io/File:isFile	()Z
/*     */     //   239: ifeq +16 -> 255
/*     */     //   242: aload 6
/*     */     //   244: aload 14
/*     */     //   246: invokevirtual 109	java/io/File:toURI	()Ljava/net/URI;
/*     */     //   249: invokevirtual 110	java/net/URI:toURL	()Ljava/net/URL;
/*     */     //   252: invokevirtual 111	org/apache/catalina/core/StandardContext:setConfigFile	(Ljava/net/URL;)V
/*     */     //   255: getstatic 92	org/apache/catalina/mbeans/MBeanFactory:mserver	Ljavax/management/MBeanServer;
/*     */     //   258: aload 9
/*     */     //   260: ldc 112
/*     */     //   262: iconst_1
/*     */     //   263: anewarray 33	java/lang/Object
/*     */     //   266: dup
/*     */     //   267: iconst_0
/*     */     //   268: aload 6
/*     */     //   270: aastore
/*     */     //   271: iconst_1
/*     */     //   272: anewarray 96	java/lang/String
/*     */     //   275: dup
/*     */     //   276: iconst_0
/*     */     //   277: ldc 113
/*     */     //   279: aastore
/*     */     //   280: invokeinterface 98 5 0
/*     */     //   285: pop
/*     */     //   286: getstatic 92	org/apache/catalina/mbeans/MBeanFactory:mserver	Ljavax/management/MBeanServer;
/*     */     //   289: aload 9
/*     */     //   291: ldc 114
/*     */     //   293: iconst_1
/*     */     //   294: anewarray 33	java/lang/Object
/*     */     //   297: dup
/*     */     //   298: iconst_0
/*     */     //   299: aload 10
/*     */     //   301: aastore
/*     */     //   302: iconst_1
/*     */     //   303: anewarray 96	java/lang/String
/*     */     //   306: dup
/*     */     //   307: iconst_0
/*     */     //   308: ldc 97
/*     */     //   310: aastore
/*     */     //   311: invokeinterface 98 5 0
/*     */     //   316: pop
/*     */     //   317: goto +39 -> 356
/*     */     //   320: astore 15
/*     */     //   322: getstatic 92	org/apache/catalina/mbeans/MBeanFactory:mserver	Ljavax/management/MBeanServer;
/*     */     //   325: aload 9
/*     */     //   327: ldc 114
/*     */     //   329: iconst_1
/*     */     //   330: anewarray 33	java/lang/Object
/*     */     //   333: dup
/*     */     //   334: iconst_0
/*     */     //   335: aload 10
/*     */     //   337: aastore
/*     */     //   338: iconst_1
/*     */     //   339: anewarray 96	java/lang/String
/*     */     //   342: dup
/*     */     //   343: iconst_0
/*     */     //   344: ldc 97
/*     */     //   346: aastore
/*     */     //   347: invokeinterface 98 5 0
/*     */     //   352: pop
/*     */     //   353: aload 15
/*     */     //   355: athrow
/*     */     //   356: goto +28 -> 384
/*     */     //   359: new 115	java/lang/IllegalStateException
/*     */     //   362: dup
/*     */     //   363: getstatic 31	org/apache/catalina/mbeans/MBeanFactory:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   366: ldc 116
/*     */     //   368: iconst_1
/*     */     //   369: anewarray 33	java/lang/Object
/*     */     //   372: dup
/*     */     //   373: iconst_0
/*     */     //   374: aload 10
/*     */     //   376: aastore
/*     */     //   377: invokevirtual 34	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   380: invokespecial 117	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
/*     */     //   383: athrow
/*     */     //   384: goto +78 -> 462
/*     */     //   387: getstatic 118	org/apache/catalina/mbeans/MBeanFactory:log	Lorg/apache/juli/logging/Log;
/*     */     //   390: getstatic 31	org/apache/catalina/mbeans/MBeanFactory:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   393: ldc 119
/*     */     //   395: iconst_1
/*     */     //   396: anewarray 33	java/lang/Object
/*     */     //   399: dup
/*     */     //   400: iconst_0
/*     */     //   401: aload 8
/*     */     //   403: ldc 22
/*     */     //   405: invokevirtual 7	javax/management/ObjectName:getKeyProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   408: aastore
/*     */     //   409: invokevirtual 34	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   412: invokeinterface 120 2 0
/*     */     //   417: aload_0
/*     */     //   418: aload 8
/*     */     //   420: invokespecial 9	org/apache/catalina/mbeans/MBeanFactory:getService	(Ljavax/management/ObjectName;)Lorg/apache/catalina/Service;
/*     */     //   423: astore 10
/*     */     //   425: aload 10
/*     */     //   427: invokeinterface 10 1 0
/*     */     //   432: astore 11
/*     */     //   434: aload 11
/*     */     //   436: aload 8
/*     */     //   438: ldc 22
/*     */     //   440: invokevirtual 7	javax/management/ObjectName:getKeyProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   443: invokeinterface 121 2 0
/*     */     //   448: checkcast 122	org/apache/catalina/Host
/*     */     //   451: astore 12
/*     */     //   453: aload 12
/*     */     //   455: aload 6
/*     */     //   457: invokeinterface 123 2 0
/*     */     //   462: aload 6
/*     */     //   464: invokevirtual 124	org/apache/catalina/core/StandardContext:getObjectName	()Ljavax/management/ObjectName;
/*     */     //   467: invokevirtual 52	javax/management/ObjectName:toString	()Ljava/lang/String;
/*     */     //   470: areturn
/*     */     // Line number table:
/*     */     //   Java source line #432	-> byte code offset #0
/*     */     //   Java source line #433	-> byte code offset #9
/*     */     //   Java source line #434	-> byte code offset #15
/*     */     //   Java source line #435	-> byte code offset #21
/*     */     //   Java source line #436	-> byte code offset #27
/*     */     //   Java source line #437	-> byte code offset #34
/*     */     //   Java source line #439	-> byte code offset #41
/*     */     //   Java source line #440	-> byte code offset #50
/*     */     //   Java source line #443	-> byte code offset #57
/*     */     //   Java source line #444	-> byte code offset #67
/*     */     //   Java source line #446	-> byte code offset #95
/*     */     //   Java source line #447	-> byte code offset #109
/*     */     //   Java source line #448	-> byte code offset #122
/*     */     //   Java source line #449	-> byte code offset #129
/*     */     //   Java source line #452	-> byte code offset #164
/*     */     //   Java source line #454	-> byte code offset #172
/*     */     //   Java source line #455	-> byte code offset #189
/*     */     //   Java source line #456	-> byte code offset #196
/*     */     //   Java source line #457	-> byte code offset #234
/*     */     //   Java source line #458	-> byte code offset #242
/*     */     //   Java source line #460	-> byte code offset #255
/*     */     //   Java source line #464	-> byte code offset #286
/*     */     //   Java source line #467	-> byte code offset #317
/*     */     //   Java source line #464	-> byte code offset #320
/*     */     //   Java source line #467	-> byte code offset #353
/*     */     //   Java source line #469	-> byte code offset #359
/*     */     //   Java source line #471	-> byte code offset #384
/*     */     //   Java source line #472	-> byte code offset #387
/*     */     //   Java source line #473	-> byte code offset #417
/*     */     //   Java source line #474	-> byte code offset #425
/*     */     //   Java source line #475	-> byte code offset #434
/*     */     //   Java source line #476	-> byte code offset #453
/*     */     //   Java source line #480	-> byte code offset #462
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	471	0	this	MBeanFactory
/*     */     //   0	471	1	parent	String
/*     */     //   0	471	2	path	String
/*     */     //   0	471	3	docBase	String
/*     */     //   0	471	4	xmlValidation	boolean
/*     */     //   0	471	5	xmlNamespaceAware	boolean
/*     */     //   7	456	6	context	org.apache.catalina.core.StandardContext
/*     */     //   48	5	7	contextConfig	org.apache.catalina.startup.ContextConfig
/*     */     //   65	372	8	pname	ObjectName
/*     */     //   107	219	9	deployer	ObjectName
/*     */     //   127	248	10	contextName	String
/*     */     //   423	3	10	service	Service
/*     */     //   162	3	11	result	Boolean
/*     */     //   432	3	11	engine	Engine
/*     */     //   187	18	12	configPath	String
/*     */     //   451	3	12	host	Host
/*     */     //   194	23	13	baseName	String
/*     */     //   232	13	14	configFile	java.io.File
/*     */     //   320	34	15	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   172	286	320	finally
/*     */     //   320	322	320	finally
/*     */   }
/*     */   
/*     */   public String createStandardHost(String parent, String name, String appBase, boolean autoDeploy, boolean deployOnStartup, boolean deployXML, boolean unpackWARs)
/*     */     throws Exception
/*     */   {
/* 507 */     StandardHost host = new StandardHost();
/* 508 */     host.setName(name);
/* 509 */     host.setAppBase(appBase);
/* 510 */     host.setAutoDeploy(autoDeploy);
/* 511 */     host.setDeployOnStartup(deployOnStartup);
/* 512 */     host.setDeployXML(deployXML);
/* 513 */     host.setUnpackWARs(unpackWARs);
/*     */     
/*     */ 
/* 516 */     HostConfig hostConfig = new HostConfig();
/* 517 */     host.addLifecycleListener(hostConfig);
/*     */     
/*     */ 
/* 520 */     ObjectName pname = new ObjectName(parent);
/* 521 */     Service service = getService(pname);
/* 522 */     Engine engine = service.getContainer();
/* 523 */     engine.addChild(host);
/*     */     
/*     */ 
/* 526 */     return host.getObjectName().toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createStandardServiceEngine(String domain, String defaultHost, String baseDir)
/*     */     throws Exception
/*     */   {
/* 544 */     if (!(this.container instanceof Server)) {
/* 545 */       throw new Exception(sm.getString("mBeanFactory.notServer"));
/*     */     }
/*     */     
/* 548 */     StandardEngine engine = new StandardEngine();
/* 549 */     engine.setDomain(domain);
/* 550 */     engine.setName(domain);
/* 551 */     engine.setDefaultHost(defaultHost);
/*     */     
/* 553 */     Service service = new StandardService();
/* 554 */     service.setContainer(engine);
/* 555 */     service.setName(domain);
/*     */     
/* 557 */     ((Server)this.container).addService(service);
/*     */     
/* 559 */     return engine.getObjectName().toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createStandardManager(String parent)
/*     */     throws Exception
/*     */   {
/* 575 */     StandardManager manager = new StandardManager();
/*     */     
/*     */ 
/* 578 */     ObjectName pname = new ObjectName(parent);
/* 579 */     Container container = getParentContainerFromParent(pname);
/* 580 */     if ((container instanceof Context)) {
/* 581 */       ((Context)container).setManager(manager);
/*     */     } else {
/* 583 */       throw new Exception(sm.getString("mBeanFactory.managerContext"));
/*     */     }
/* 585 */     ObjectName oname = manager.getObjectName();
/* 586 */     if (oname != null) {
/* 587 */       return oname.toString();
/*     */     }
/* 589 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createUserDatabaseRealm(String parent, String resourceName)
/*     */     throws Exception
/*     */   {
/* 609 */     UserDatabaseRealm realm = new UserDatabaseRealm();
/* 610 */     realm.setResourceName(resourceName);
/*     */     
/*     */ 
/* 613 */     return addRealmToParent(parent, realm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createValve(String className, String parent)
/*     */     throws Exception
/*     */   {
/* 634 */     ObjectName parentName = new ObjectName(parent);
/* 635 */     Container container = getParentContainerFromParent(parentName);
/*     */     
/* 637 */     if (container == null)
/*     */     {
/* 639 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 642 */     Valve valve = (Valve)Class.forName(className).getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */     
/* 644 */     container.getPipeline().addValve(valve);
/*     */     
/* 646 */     if ((valve instanceof JmxEnabled)) {
/* 647 */       return ((JmxEnabled)valve).getObjectName().toString();
/*     */     }
/* 649 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createWebappLoader(String parent)
/*     */     throws Exception
/*     */   {
/* 666 */     WebappLoader loader = new WebappLoader();
/*     */     
/*     */ 
/* 669 */     ObjectName pname = new ObjectName(parent);
/* 670 */     Container container = getParentContainerFromParent(pname);
/* 671 */     if ((container instanceof Context)) {
/* 672 */       ((Context)container).setLoader(loader);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 677 */     ObjectName oname = MBeanUtils.createObjectName(pname.getDomain(), loader);
/* 678 */     return oname.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeConnector(String name)
/*     */     throws Exception
/*     */   {
/* 693 */     ObjectName oname = new ObjectName(name);
/* 694 */     Service service = getService(oname);
/* 695 */     String port = oname.getKeyProperty("port");
/* 696 */     String address = oname.getKeyProperty("address");
/* 697 */     if (address != null) {
/* 698 */       address = ObjectName.unquote(address);
/*     */     }
/*     */     
/* 701 */     Connector[] conns = service.findConnectors();
/*     */     
/* 703 */     for (Connector conn : conns) {
/* 704 */       String connAddress = null;
/* 705 */       Object objConnAddress = conn.getProperty("address");
/* 706 */       if (objConnAddress != null) {
/* 707 */         connAddress = ((InetAddress)objConnAddress).getHostAddress();
/*     */       }
/* 709 */       String connPort = "" + conn.getPortWithOffset();
/*     */       
/* 711 */       if (address == null)
/*     */       {
/*     */ 
/* 714 */         if ((connAddress == null) && (port.equals(connPort))) {
/* 715 */           service.removeConnector(conn);
/* 716 */           conn.destroy();
/* 717 */           break;
/*     */         }
/*     */       }
/* 720 */       else if ((address.equals(connAddress)) && (port.equals(connPort))) {
/* 721 */         service.removeConnector(conn);
/* 722 */         conn.destroy();
/* 723 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void removeContext(String contextName)
/*     */     throws Exception
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 46	javax/management/ObjectName
/*     */     //   3: dup
/*     */     //   4: aload_1
/*     */     //   5: invokespecial 47	javax/management/ObjectName:<init>	(Ljava/lang/String;)V
/*     */     //   8: astore_2
/*     */     //   9: aload_2
/*     */     //   10: invokevirtual 25	javax/management/ObjectName:getDomain	()Ljava/lang/String;
/*     */     //   13: astore_3
/*     */     //   14: aload_0
/*     */     //   15: aload_2
/*     */     //   16: invokespecial 9	org/apache/catalina/mbeans/MBeanFactory:getService	(Ljavax/management/ObjectName;)Lorg/apache/catalina/Service;
/*     */     //   19: checkcast 28	org/apache/catalina/core/StandardService
/*     */     //   22: astore 4
/*     */     //   24: aload 4
/*     */     //   26: invokevirtual 181	org/apache/catalina/core/StandardService:getContainer	()Lorg/apache/catalina/Engine;
/*     */     //   29: astore 5
/*     */     //   31: aload_2
/*     */     //   32: ldc 13
/*     */     //   34: invokevirtual 7	javax/management/ObjectName:getKeyProperty	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   37: astore 6
/*     */     //   39: aload 6
/*     */     //   41: iconst_2
/*     */     //   42: invokevirtual 14	java/lang/String:substring	(I)Ljava/lang/String;
/*     */     //   45: astore 6
/*     */     //   47: aload 6
/*     */     //   49: bipush 47
/*     */     //   51: invokevirtual 15	java/lang/String:indexOf	(I)I
/*     */     //   54: istore 7
/*     */     //   56: aload 6
/*     */     //   58: iconst_0
/*     */     //   59: iload 7
/*     */     //   61: invokevirtual 16	java/lang/String:substring	(II)Ljava/lang/String;
/*     */     //   64: astore 8
/*     */     //   66: aload 6
/*     */     //   68: iload 7
/*     */     //   70: invokevirtual 14	java/lang/String:substring	(I)Ljava/lang/String;
/*     */     //   73: astore 9
/*     */     //   75: new 46	javax/management/ObjectName
/*     */     //   78: dup
/*     */     //   79: new 87	java/lang/StringBuilder
/*     */     //   82: dup
/*     */     //   83: invokespecial 88	java/lang/StringBuilder:<init>	()V
/*     */     //   86: aload_3
/*     */     //   87: invokevirtual 89	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   90: ldc 90
/*     */     //   92: invokevirtual 89	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   95: aload 8
/*     */     //   97: invokevirtual 89	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   100: invokevirtual 91	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   103: invokespecial 47	javax/management/ObjectName:<init>	(Ljava/lang/String;)V
/*     */     //   106: astore 10
/*     */     //   108: aload_0
/*     */     //   109: aload 9
/*     */     //   111: invokespecial 18	org/apache/catalina/mbeans/MBeanFactory:getPathStr	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   114: astore 11
/*     */     //   116: getstatic 92	org/apache/catalina/mbeans/MBeanFactory:mserver	Ljavax/management/MBeanServer;
/*     */     //   119: aload 10
/*     */     //   121: invokeinterface 93 2 0
/*     */     //   126: ifeq +178 -> 304
/*     */     //   129: getstatic 92	org/apache/catalina/mbeans/MBeanFactory:mserver	Ljavax/management/MBeanServer;
/*     */     //   132: aload 10
/*     */     //   134: ldc 95
/*     */     //   136: iconst_1
/*     */     //   137: anewarray 33	java/lang/Object
/*     */     //   140: dup
/*     */     //   141: iconst_0
/*     */     //   142: aload 11
/*     */     //   144: aastore
/*     */     //   145: iconst_1
/*     */     //   146: anewarray 96	java/lang/String
/*     */     //   149: dup
/*     */     //   150: iconst_0
/*     */     //   151: ldc 97
/*     */     //   153: aastore
/*     */     //   154: invokeinterface 98 5 0
/*     */     //   159: checkcast 99	java/lang/Boolean
/*     */     //   162: astore 12
/*     */     //   164: aload 12
/*     */     //   166: invokevirtual 100	java/lang/Boolean:booleanValue	()Z
/*     */     //   169: ifeq +107 -> 276
/*     */     //   172: getstatic 92	org/apache/catalina/mbeans/MBeanFactory:mserver	Ljavax/management/MBeanServer;
/*     */     //   175: aload 10
/*     */     //   177: ldc -74
/*     */     //   179: iconst_1
/*     */     //   180: anewarray 33	java/lang/Object
/*     */     //   183: dup
/*     */     //   184: iconst_0
/*     */     //   185: aload 11
/*     */     //   187: aastore
/*     */     //   188: iconst_1
/*     */     //   189: anewarray 96	java/lang/String
/*     */     //   192: dup
/*     */     //   193: iconst_0
/*     */     //   194: ldc 97
/*     */     //   196: aastore
/*     */     //   197: invokeinterface 98 5 0
/*     */     //   202: pop
/*     */     //   203: getstatic 92	org/apache/catalina/mbeans/MBeanFactory:mserver	Ljavax/management/MBeanServer;
/*     */     //   206: aload 10
/*     */     //   208: ldc 114
/*     */     //   210: iconst_1
/*     */     //   211: anewarray 33	java/lang/Object
/*     */     //   214: dup
/*     */     //   215: iconst_0
/*     */     //   216: aload 11
/*     */     //   218: aastore
/*     */     //   219: iconst_1
/*     */     //   220: anewarray 96	java/lang/String
/*     */     //   223: dup
/*     */     //   224: iconst_0
/*     */     //   225: ldc 97
/*     */     //   227: aastore
/*     */     //   228: invokeinterface 98 5 0
/*     */     //   233: pop
/*     */     //   234: goto +39 -> 273
/*     */     //   237: astore 13
/*     */     //   239: getstatic 92	org/apache/catalina/mbeans/MBeanFactory:mserver	Ljavax/management/MBeanServer;
/*     */     //   242: aload 10
/*     */     //   244: ldc 114
/*     */     //   246: iconst_1
/*     */     //   247: anewarray 33	java/lang/Object
/*     */     //   250: dup
/*     */     //   251: iconst_0
/*     */     //   252: aload 11
/*     */     //   254: aastore
/*     */     //   255: iconst_1
/*     */     //   256: anewarray 96	java/lang/String
/*     */     //   259: dup
/*     */     //   260: iconst_0
/*     */     //   261: ldc 97
/*     */     //   263: aastore
/*     */     //   264: invokeinterface 98 5 0
/*     */     //   269: pop
/*     */     //   270: aload 13
/*     */     //   272: athrow
/*     */     //   273: goto +28 -> 301
/*     */     //   276: new 115	java/lang/IllegalStateException
/*     */     //   279: dup
/*     */     //   280: getstatic 31	org/apache/catalina/mbeans/MBeanFactory:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   283: ldc -73
/*     */     //   285: iconst_1
/*     */     //   286: anewarray 33	java/lang/Object
/*     */     //   289: dup
/*     */     //   290: iconst_0
/*     */     //   291: aload 11
/*     */     //   293: aastore
/*     */     //   294: invokevirtual 34	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   297: invokespecial 117	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
/*     */     //   300: athrow
/*     */     //   301: goto +103 -> 404
/*     */     //   304: getstatic 118	org/apache/catalina/mbeans/MBeanFactory:log	Lorg/apache/juli/logging/Log;
/*     */     //   307: getstatic 31	org/apache/catalina/mbeans/MBeanFactory:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   310: ldc 119
/*     */     //   312: iconst_1
/*     */     //   313: anewarray 33	java/lang/Object
/*     */     //   316: dup
/*     */     //   317: iconst_0
/*     */     //   318: aload 8
/*     */     //   320: aastore
/*     */     //   321: invokevirtual 34	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   324: invokeinterface 120 2 0
/*     */     //   329: aload 5
/*     */     //   331: aload 8
/*     */     //   333: invokeinterface 121 2 0
/*     */     //   338: checkcast 122	org/apache/catalina/Host
/*     */     //   341: astore 12
/*     */     //   343: aload 12
/*     */     //   345: aload 11
/*     */     //   347: invokeinterface 184 2 0
/*     */     //   352: checkcast 151	org/apache/catalina/Context
/*     */     //   355: astore 13
/*     */     //   357: aload 12
/*     */     //   359: aload 13
/*     */     //   361: invokeinterface 185 2 0
/*     */     //   366: aload 13
/*     */     //   368: instanceof 78
/*     */     //   371: ifeq +33 -> 404
/*     */     //   374: aload 13
/*     */     //   376: invokeinterface 186 1 0
/*     */     //   381: goto +23 -> 404
/*     */     //   384: astore 14
/*     */     //   386: getstatic 118	org/apache/catalina/mbeans/MBeanFactory:log	Lorg/apache/juli/logging/Log;
/*     */     //   389: getstatic 31	org/apache/catalina/mbeans/MBeanFactory:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   392: ldc -69
/*     */     //   394: invokevirtual 139	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   397: aload 14
/*     */     //   399: invokeinterface 188 3 0
/*     */     //   404: return
/*     */     // Line number table:
/*     */     //   Java source line #739	-> byte code offset #0
/*     */     //   Java source line #740	-> byte code offset #9
/*     */     //   Java source line #741	-> byte code offset #14
/*     */     //   Java source line #743	-> byte code offset #24
/*     */     //   Java source line #744	-> byte code offset #31
/*     */     //   Java source line #745	-> byte code offset #39
/*     */     //   Java source line #746	-> byte code offset #47
/*     */     //   Java source line #747	-> byte code offset #56
/*     */     //   Java source line #748	-> byte code offset #66
/*     */     //   Java source line #749	-> byte code offset #75
/*     */     //   Java source line #751	-> byte code offset #108
/*     */     //   Java source line #752	-> byte code offset #116
/*     */     //   Java source line #753	-> byte code offset #129
/*     */     //   Java source line #756	-> byte code offset #164
/*     */     //   Java source line #758	-> byte code offset #172
/*     */     //   Java source line #762	-> byte code offset #203
/*     */     //   Java source line #765	-> byte code offset #234
/*     */     //   Java source line #762	-> byte code offset #237
/*     */     //   Java source line #765	-> byte code offset #270
/*     */     //   Java source line #767	-> byte code offset #276
/*     */     //   Java source line #769	-> byte code offset #301
/*     */     //   Java source line #770	-> byte code offset #304
/*     */     //   Java source line #771	-> byte code offset #329
/*     */     //   Java source line #772	-> byte code offset #343
/*     */     //   Java source line #774	-> byte code offset #357
/*     */     //   Java source line #775	-> byte code offset #366
/*     */     //   Java source line #777	-> byte code offset #374
/*     */     //   Java source line #780	-> byte code offset #381
/*     */     //   Java source line #778	-> byte code offset #384
/*     */     //   Java source line #779	-> byte code offset #386
/*     */     //   Java source line #784	-> byte code offset #404
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	405	0	this	MBeanFactory
/*     */     //   0	405	1	contextName	String
/*     */     //   8	24	2	oname	ObjectName
/*     */     //   13	74	3	domain	String
/*     */     //   22	3	4	service	StandardService
/*     */     //   29	301	5	engine	Engine
/*     */     //   37	30	6	name	String
/*     */     //   54	15	7	i	int
/*     */     //   64	268	8	hostName	String
/*     */     //   73	37	9	path	String
/*     */     //   106	137	10	deployer	ObjectName
/*     */     //   114	232	11	pathStr	String
/*     */     //   162	3	12	result	Boolean
/*     */     //   341	17	12	host	Host
/*     */     //   237	34	13	localObject	Object
/*     */     //   355	20	13	context	Context
/*     */     //   384	14	14	e	Exception
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   172	203	237	finally
/*     */     //   237	239	237	finally
/*     */     //   374	381	384	java/lang/Exception
/*     */   }
/*     */   
/*     */   public void removeHost(String name)
/*     */     throws Exception
/*     */   {
/* 797 */     ObjectName oname = new ObjectName(name);
/* 798 */     String hostName = oname.getKeyProperty("host");
/* 799 */     Service service = getService(oname);
/* 800 */     Engine engine = service.getContainer();
/* 801 */     Host host = (Host)engine.findChild(hostName);
/*     */     
/*     */ 
/* 804 */     if (host != null) {
/* 805 */       engine.removeChild(host);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLoader(String name)
/*     */     throws Exception
/*     */   {
/* 819 */     ObjectName oname = new ObjectName(name);
/*     */     
/* 821 */     Container container = getParentContainerFromChild(oname);
/* 822 */     if ((container instanceof Context)) {
/* 823 */       ((Context)container).setLoader(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeManager(String name)
/*     */     throws Exception
/*     */   {
/* 837 */     ObjectName oname = new ObjectName(name);
/*     */     
/* 839 */     Container container = getParentContainerFromChild(oname);
/* 840 */     if ((container instanceof Context)) {
/* 841 */       ((Context)container).setManager(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRealm(String name)
/*     */     throws Exception
/*     */   {
/* 855 */     ObjectName oname = new ObjectName(name);
/*     */     
/* 857 */     Container container = getParentContainerFromChild(oname);
/* 858 */     container.setRealm(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeService(String name)
/*     */     throws Exception
/*     */   {
/* 871 */     if (!(this.container instanceof Server)) {
/* 872 */       throw new Exception();
/*     */     }
/*     */     
/*     */ 
/* 876 */     ObjectName oname = new ObjectName(name);
/* 877 */     Service service = getService(oname);
/* 878 */     ((Server)this.container).removeService(service);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeValve(String name)
/*     */     throws Exception
/*     */   {
/* 892 */     ObjectName oname = new ObjectName(name);
/* 893 */     Container container = getParentContainerFromChild(oname);
/* 894 */     Valve[] valves = container.getPipeline().getValves();
/* 895 */     for (Valve valve : valves) {
/* 896 */       ObjectName voname = ((JmxEnabled)valve).getObjectName();
/* 897 */       if (voname.equals(oname)) {
/* 898 */         container.getPipeline().removeValve(valve);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\MBeanFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */