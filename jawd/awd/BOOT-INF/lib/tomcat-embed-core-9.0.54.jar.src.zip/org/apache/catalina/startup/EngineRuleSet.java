/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.digester.RuleSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EngineRuleSet
/*     */   implements RuleSet
/*     */ {
/*     */   protected final String prefix;
/*     */   
/*     */   public EngineRuleSet()
/*     */   {
/*  47 */     this("");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EngineRuleSet(String prefix)
/*     */   {
/*  59 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRuleInstances(Digester digester)
/*     */   {
/*  77 */     digester.addObjectCreate(this.prefix + "Engine", "org.apache.catalina.core.StandardEngine", "className");
/*     */     
/*     */ 
/*  80 */     digester.addSetProperties(this.prefix + "Engine");
/*  81 */     digester.addRule(this.prefix + "Engine", new LifecycleListenerRule("org.apache.catalina.startup.EngineConfig", "engineConfigClass"));
/*     */     
/*     */ 
/*     */ 
/*  85 */     digester.addSetNext(this.prefix + "Engine", "setContainer", "org.apache.catalina.Engine");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  90 */     digester.addObjectCreate(this.prefix + "Engine/Cluster", null, "className");
/*     */     
/*     */ 
/*  93 */     digester.addSetProperties(this.prefix + "Engine/Cluster");
/*  94 */     digester.addSetNext(this.prefix + "Engine/Cluster", "setCluster", "org.apache.catalina.Cluster");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  99 */     digester.addObjectCreate(this.prefix + "Engine/Listener", null, "className");
/*     */     
/*     */ 
/* 102 */     digester.addSetProperties(this.prefix + "Engine/Listener");
/* 103 */     digester.addSetNext(this.prefix + "Engine/Listener", "addLifecycleListener", "org.apache.catalina.LifecycleListener");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 108 */     digester.addRuleSet(new RealmRuleSet(this.prefix + "Engine/"));
/*     */     
/* 110 */     digester.addObjectCreate(this.prefix + "Engine/Valve", null, "className");
/*     */     
/*     */ 
/* 113 */     digester.addSetProperties(this.prefix + "Engine/Valve");
/* 114 */     digester.addSetNext(this.prefix + "Engine/Valve", "addValve", "org.apache.catalina.Valve");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\EngineRuleSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */