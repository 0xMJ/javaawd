/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.util.NetMask;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RemoteCIDRValve
/*     */   extends RequestFilterValve
/*     */ {
/*  40 */   private static final Log log = LogFactory.getLog(RemoteCIDRValve.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  45 */   private final List<NetMask> allow = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  50 */   private final List<NetMask> deny = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAllow()
/*     */   {
/*  65 */     return this.allow.toString().replace("[", "").replace("]", "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllow(String input)
/*     */   {
/*  78 */     List<String> messages = fillFromInput(input, this.allow);
/*     */     
/*  80 */     if (messages.isEmpty()) {
/*  81 */       return;
/*     */     }
/*     */     
/*  84 */     this.allowValid = false;
/*  85 */     for (String message : messages) {
/*  86 */       log.error(message);
/*     */     }
/*     */     
/*  89 */     throw new IllegalArgumentException(sm.getString("remoteCidrValve.invalid", new Object[] { "allow" }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDeny()
/*     */   {
/* 101 */     return this.deny.toString().replace("[", "").replace("]", "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDeny(String input)
/*     */   {
/* 114 */     List<String> messages = fillFromInput(input, this.deny);
/*     */     
/* 116 */     if (messages.isEmpty()) {
/* 117 */       return;
/*     */     }
/*     */     
/* 120 */     this.denyValid = false;
/* 121 */     for (String message : messages) {
/* 122 */       log.error(message);
/*     */     }
/*     */     
/* 125 */     throw new IllegalArgumentException(sm.getString("remoteCidrValve.invalid", new Object[] { "deny" }));
/*     */   }
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException
/*     */   {
/*     */     String property;
/*     */     String property;
/* 132 */     if (getUsePeerAddress()) {
/* 133 */       property = request.getPeerAddr();
/*     */     } else {
/* 135 */       property = request.getRequest().getRemoteAddr();
/*     */     }
/* 137 */     if (getAddConnectorPort())
/*     */     {
/* 139 */       property = property + ";" + request.getConnector().getPortWithOffset();
/*     */     }
/* 141 */     process(property, request, response);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAllowed(String property)
/*     */   {
/* 147 */     int portIdx = property.indexOf(';');
/*     */     
/*     */     String nonPortPart;
/*     */     String nonPortPart;
/* 151 */     if (portIdx == -1) {
/* 152 */       if (getAddConnectorPort()) {
/* 153 */         log.error(sm.getString("remoteCidrValve.noPort"));
/* 154 */         return false;
/*     */       }
/* 156 */       int port = -1;
/* 157 */       nonPortPart = property;
/*     */     } else {
/* 159 */       if (!getAddConnectorPort()) {
/* 160 */         log.error(sm.getString("remoteCidrValve.unexpectedPort"));
/* 161 */         return false;
/*     */       }
/* 163 */       nonPortPart = property.substring(0, portIdx);
/*     */       try {
/* 165 */         port = Integer.parseInt(property.substring(portIdx + 1));
/*     */       }
/*     */       catch (NumberFormatException e) {
/*     */         int port;
/* 169 */         log.error(sm.getString("remoteCidrValve.noPort"), e);
/* 170 */         return false;
/*     */       }
/*     */     }
/*     */     int port;
/*     */     try
/*     */     {
/* 176 */       addr = InetAddress.getByName(nonPortPart);
/*     */     }
/*     */     catch (UnknownHostException e) {
/*     */       InetAddress addr;
/* 180 */       log.error(sm.getString("remoteCidrValve.noRemoteIp"), e);
/* 181 */       return false;
/*     */     }
/*     */     InetAddress addr;
/* 184 */     for (NetMask nm : this.deny) {
/* 185 */       if (getAddConnectorPort()) {
/* 186 */         if (nm.matches(addr, port)) {
/* 187 */           return false;
/*     */         }
/*     */       }
/* 190 */       else if (nm.matches(addr)) {
/* 191 */         return false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 196 */     for (NetMask nm : this.allow) {
/* 197 */       if (getAddConnectorPort()) {
/* 198 */         if (nm.matches(addr, port)) {
/* 199 */           return true;
/*     */         }
/*     */       }
/* 202 */       else if (nm.matches(addr)) {
/* 203 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 209 */     if ((!this.deny.isEmpty()) && (this.allow.isEmpty())) {
/* 210 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 214 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Log getLog()
/*     */   {
/* 220 */     return log;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<String> fillFromInput(String input, List<NetMask> target)
/*     */   {
/* 234 */     target.clear();
/* 235 */     if ((input == null) || (input.isEmpty())) {
/* 236 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 239 */     List<String> messages = new LinkedList();
/*     */     
/*     */ 
/* 242 */     for (String s : input.split("\\s*,\\s*")) {
/*     */       try {
/* 244 */         NetMask nm = new NetMask(s);
/* 245 */         target.add(nm);
/*     */       } catch (IllegalArgumentException e) {
/* 247 */         messages.add(s + ": " + e.getMessage());
/*     */       }
/*     */     }
/*     */     
/* 251 */     return Collections.unmodifiableList(messages);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\RemoteCIDRValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */