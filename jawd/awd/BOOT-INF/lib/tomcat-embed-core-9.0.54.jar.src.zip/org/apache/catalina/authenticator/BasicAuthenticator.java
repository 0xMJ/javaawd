/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.Principal;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.ByteChunk;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.codec.binary.Base64;
/*     */ import org.apache.tomcat.util.http.MimeHeaders;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicAuthenticator
/*     */   extends AuthenticatorBase
/*     */ {
/*  43 */   private final Log log = LogFactory.getLog(BasicAuthenticator.class);
/*     */   
/*  45 */   private Charset charset = StandardCharsets.ISO_8859_1;
/*  46 */   private String charsetString = null;
/*  47 */   private boolean trimCredentials = true;
/*     */   
/*     */   public String getCharset()
/*     */   {
/*  51 */     return this.charsetString;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCharset(String charsetString)
/*     */   {
/*  57 */     if ((charsetString == null) || (charsetString.isEmpty())) {
/*  58 */       this.charset = StandardCharsets.ISO_8859_1;
/*  59 */     } else if ("UTF-8".equalsIgnoreCase(charsetString)) {
/*  60 */       this.charset = StandardCharsets.UTF_8;
/*     */     } else {
/*  62 */       throw new IllegalArgumentException(sm.getString("basicAuthenticator.invalidCharset"));
/*     */     }
/*  64 */     this.charsetString = charsetString;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean getTrimCredentials()
/*     */   {
/*  70 */     return this.trimCredentials;
/*     */   }
/*     */   
/*     */   public void setTrimCredentials(boolean trimCredentials)
/*     */   {
/*  75 */     this.trimCredentials = trimCredentials;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean doAuthenticate(org.apache.catalina.connector.Request request, HttpServletResponse response)
/*     */     throws IOException
/*     */   {
/*  83 */     if (checkForCachedAuthentication(request, response, true)) {
/*  84 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  90 */     MessageBytes authorization = request.getCoyoteRequest().getMimeHeaders().getValue("authorization");
/*     */     
/*  92 */     if (authorization != null) {
/*  93 */       authorization.toBytes();
/*  94 */       ByteChunk authorizationBC = authorization.getByteChunk();
/*  95 */       BasicCredentials credentials = null;
/*     */       try {
/*  97 */         credentials = new BasicCredentials(authorizationBC, this.charset, getTrimCredentials());
/*  98 */         String username = credentials.getUsername();
/*  99 */         String password = credentials.getPassword();
/*     */         
/* 101 */         Principal principal = this.context.getRealm().authenticate(username, password);
/* 102 */         if (principal != null) {
/* 103 */           register(request, response, principal, "BASIC", username, password);
/*     */           
/* 105 */           return true;
/*     */         }
/*     */       }
/*     */       catch (IllegalArgumentException iae) {
/* 109 */         if (this.log.isDebugEnabled()) {
/* 110 */           this.log.debug("Invalid Authorization" + iae.getMessage());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 116 */     StringBuilder value = new StringBuilder(16);
/* 117 */     value.append("Basic realm=\"");
/* 118 */     value.append(getRealmName(this.context));
/* 119 */     value.append('"');
/* 120 */     if ((this.charsetString != null) && (!this.charsetString.isEmpty())) {
/* 121 */       value.append(", charset=");
/* 122 */       value.append(this.charsetString);
/*     */     }
/* 124 */     response.setHeader("WWW-Authenticate", value.toString());
/* 125 */     response.sendError(401);
/* 126 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getAuthMethod()
/*     */   {
/* 133 */     return "BASIC";
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean isPreemptiveAuthPossible(org.apache.catalina.connector.Request request)
/*     */   {
/* 139 */     MessageBytes authorizationHeader = request.getCoyoteRequest().getMimeHeaders().getValue("authorization");
/* 140 */     return (authorizationHeader != null) && (authorizationHeader.startsWithIgnoreCase("basic ", 0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class BasicCredentials
/*     */   {
/*     */     private static final String METHOD = "basic ";
/*     */     
/*     */ 
/*     */     private final Charset charset;
/*     */     
/*     */     private final boolean trimCredentials;
/*     */     
/*     */     private final ByteChunk authorization;
/*     */     
/*     */     private final int initialOffset;
/*     */     
/*     */     private int base64blobOffset;
/*     */     
/*     */     private int base64blobLength;
/*     */     
/* 162 */     private String username = null;
/* 163 */     private String password = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     @Deprecated
/*     */     public BasicCredentials(ByteChunk input, Charset charset)
/*     */       throws IllegalArgumentException
/*     */     {
/* 180 */       this(input, charset, true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public BasicCredentials(ByteChunk input, Charset charset, boolean trimCredentials)
/*     */       throws IllegalArgumentException
/*     */     {
/* 199 */       this.authorization = input;
/* 200 */       this.initialOffset = input.getOffset();
/* 201 */       this.charset = charset;
/* 202 */       this.trimCredentials = trimCredentials;
/*     */       
/* 204 */       parseMethod();
/* 205 */       byte[] decoded = parseBase64();
/* 206 */       parseCredentials(decoded);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getUsername()
/*     */     {
/* 216 */       return this.username;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getPassword()
/*     */     {
/* 226 */       return this.password;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private void parseMethod()
/*     */       throws IllegalArgumentException
/*     */     {
/* 234 */       if (this.authorization.startsWithIgnoreCase("basic ", 0))
/*     */       {
/* 236 */         this.base64blobOffset = (this.initialOffset + "basic ".length());
/* 237 */         this.base64blobLength = (this.authorization.getLength() - "basic ".length());
/*     */       }
/*     */       else {
/* 240 */         throw new IllegalArgumentException("Authorization header method is not \"Basic\"");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private byte[] parseBase64()
/*     */       throws IllegalArgumentException
/*     */     {
/* 251 */       byte[] decoded = Base64.decodeBase64(this.authorization
/* 252 */         .getBuffer(), this.base64blobOffset, this.base64blobLength);
/*     */       
/*     */ 
/* 255 */       this.authorization.setOffset(this.initialOffset);
/* 256 */       if (decoded == null) {
/* 257 */         throw new IllegalArgumentException("Basic Authorization credentials are not Base64");
/*     */       }
/*     */       
/* 260 */       return decoded;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void parseCredentials(byte[] decoded)
/*     */       throws IllegalArgumentException
/*     */     {
/* 270 */       int colon = -1;
/* 271 */       for (int i = 0; i < decoded.length; i++) {
/* 272 */         if (decoded[i] == 58) {
/* 273 */           colon = i;
/* 274 */           break;
/*     */         }
/*     */       }
/*     */       
/* 278 */       if (colon < 0) {
/* 279 */         this.username = new String(decoded, this.charset);
/*     */       }
/*     */       else {
/* 282 */         this.username = new String(decoded, 0, colon, this.charset);
/* 283 */         this.password = new String(decoded, colon + 1, decoded.length - colon - 1, this.charset);
/*     */         
/* 285 */         if ((this.password.length() > 1) && (this.trimCredentials)) {
/* 286 */           this.password = this.password.trim();
/*     */         }
/*     */       }
/*     */       
/* 290 */       if ((this.username.length() > 1) && (this.trimCredentials)) {
/* 291 */         this.username = this.username.trim();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\authenticator\BasicAuthenticator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */