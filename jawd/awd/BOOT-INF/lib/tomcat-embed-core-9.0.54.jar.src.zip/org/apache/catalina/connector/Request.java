/*      */ package org.apache.catalina.connector;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.security.Principal;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TimeZone;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import javax.naming.NamingException;
/*      */ import javax.security.auth.Subject;
/*      */ import javax.servlet.AsyncContext;
/*      */ import javax.servlet.DispatcherType;
/*      */ import javax.servlet.FilterChain;
/*      */ import javax.servlet.MultipartConfigElement;
/*      */ import javax.servlet.RequestDispatcher;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletInputStream;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletRequestAttributeEvent;
/*      */ import javax.servlet.ServletRequestAttributeListener;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.SessionTrackingMode;
/*      */ import javax.servlet.http.Cookie;
/*      */ import javax.servlet.http.HttpServletMapping;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletRequestWrapper;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpSession;
/*      */ import javax.servlet.http.HttpUpgradeHandler;
/*      */ import javax.servlet.http.Part;
/*      */ import javax.servlet.http.PushBuilder;
/*      */ import org.apache.catalina.Authenticator;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.TomcatPrincipal;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.core.ApplicationFilterChain;
/*      */ import org.apache.catalina.core.ApplicationMapping;
/*      */ import org.apache.catalina.core.ApplicationPart;
/*      */ import org.apache.catalina.core.ApplicationPushBuilder;
/*      */ import org.apache.catalina.core.ApplicationSessionCookieConfig;
/*      */ import org.apache.catalina.core.AsyncContextImpl;
/*      */ import org.apache.catalina.mapper.MappingData;
/*      */ import org.apache.catalina.util.ParameterMap;
/*      */ import org.apache.catalina.util.TLSUtil;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.coyote.ActionCode;
/*      */ import org.apache.coyote.Constants;
/*      */ import org.apache.coyote.ProtocolHandler;
/*      */ import org.apache.coyote.UpgradeToken;
/*      */ import org.apache.coyote.http11.upgrade.InternalHttpUpgradeHandler;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.B2CConverter;
/*      */ import org.apache.tomcat.util.buf.ByteChunk;
/*      */ import org.apache.tomcat.util.buf.EncodedSolidusHandling;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.buf.StringUtils;
/*      */ import org.apache.tomcat.util.buf.UDecoder;
/*      */ import org.apache.tomcat.util.http.CookieProcessor;
/*      */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*      */ import org.apache.tomcat.util.http.MimeHeaders;
/*      */ import org.apache.tomcat.util.http.Parameters;
/*      */ import org.apache.tomcat.util.http.Parameters.FailReason;
/*      */ import org.apache.tomcat.util.http.ServerCookie;
/*      */ import org.apache.tomcat.util.http.ServerCookies;
/*      */ import org.apache.tomcat.util.http.fileupload.FileItem;
/*      */ import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
/*      */ import org.apache.tomcat.util.http.fileupload.impl.InvalidContentTypeException;
/*      */ import org.apache.tomcat.util.http.fileupload.impl.SizeException;
/*      */ import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
/*      */ import org.apache.tomcat.util.http.fileupload.servlet.ServletRequestContext;
/*      */ import org.apache.tomcat.util.http.parser.AcceptLanguage;
/*      */ import org.apache.tomcat.util.http.parser.Upgrade;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.ietf.jgss.GSSCredential;
/*      */ import org.ietf.jgss.GSSException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Request
/*      */   implements HttpServletRequest
/*      */ {
/*      */   private static final String HTTP_UPGRADE_HEADER_NAME = "upgrade";
/*  132 */   private static final Log log = LogFactory.getLog(Request.class);
/*      */   
/*      */ 
/*      */ 
/*      */   protected org.apache.coyote.Request coyoteRequest;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Request(Connector connector)
/*      */   {
/*  143 */     this.connector = connector;
/*      */     
/*  145 */     this.formats = new SimpleDateFormat[formatsTemplate.length];
/*  146 */     for (int i = 0; i < this.formats.length; i++) {
/*  147 */       this.formats[i] = ((SimpleDateFormat)formatsTemplate[i].clone());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCoyoteRequest(org.apache.coyote.Request coyoteRequest)
/*      */   {
/*  166 */     this.coyoteRequest = coyoteRequest;
/*  167 */     this.inputBuffer.setRequest(coyoteRequest);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public org.apache.coyote.Request getCoyoteRequest()
/*      */   {
/*  176 */     return this.coyoteRequest;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  186 */   protected static final TimeZone GMT_ZONE = TimeZone.getTimeZone("GMT");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  192 */   protected static final StringManager sm = StringManager.getManager(Request.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  198 */   protected Cookie[] cookies = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected final SimpleDateFormat[] formats;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  213 */   private static final SimpleDateFormat[] formatsTemplate = { new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US), new SimpleDateFormat("EEEEEE, dd-MMM-yy HH:mm:ss zzz", Locale.US), new SimpleDateFormat("EEE MMMM d HH:mm:ss yyyy", Locale.US) };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  223 */   protected static final Locale defaultLocale = Locale.getDefault();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  229 */   private final Map<String, Object> attributes = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  237 */   protected boolean sslAttributesParsed = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  243 */   protected final ArrayList<Locale> locales = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  250 */   private final transient HashMap<String, Object> notes = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  256 */   protected String authType = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  262 */   protected DispatcherType internalDispatcherType = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  268 */   protected final InputBuffer inputBuffer = new InputBuffer();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  274 */   protected CoyoteInputStream inputStream = new CoyoteInputStream(this.inputBuffer);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  281 */   protected CoyoteReader reader = new CoyoteReader(this.inputBuffer);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  287 */   protected boolean usingInputStream = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  293 */   protected boolean usingReader = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  299 */   protected Principal userPrincipal = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  305 */   protected boolean parametersParsed = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  312 */   protected boolean cookiesParsed = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  319 */   protected boolean cookiesConverted = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  325 */   protected boolean secure = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  331 */   protected transient Subject subject = null;
/*      */   
/*      */ 
/*      */ 
/*      */   protected static final int CACHED_POST_LEN = 8192;
/*      */   
/*      */ 
/*  338 */   protected byte[] postData = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  344 */   protected ParameterMap<String, String[]> parameterMap = new ParameterMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  350 */   protected Collection<Part> parts = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  356 */   protected Exception partsParseException = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  362 */   protected Session session = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  368 */   protected Object requestDispatcherPath = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  374 */   protected boolean requestedSessionCookie = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  380 */   protected String requestedSessionId = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  386 */   protected boolean requestedSessionURL = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  392 */   protected boolean requestedSessionSSL = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  398 */   protected boolean localesParsed = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  404 */   protected int localPort = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  409 */   protected String remoteAddr = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  415 */   protected String peerAddr = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  421 */   protected String remoteHost = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  427 */   protected int remotePort = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  432 */   protected String localAddr = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  438 */   protected String localName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  443 */   private volatile AsyncContextImpl asyncContext = null;
/*      */   
/*  445 */   protected Boolean asyncSupported = null;
/*      */   
/*  447 */   private HttpServletRequest applicationRequest = null;
/*      */   
/*      */   protected final Connector connector;
/*      */   
/*      */   protected void addPathParameter(String name, String value)
/*      */   {
/*  453 */     this.coyoteRequest.addPathParameter(name, value);
/*      */   }
/*      */   
/*      */   protected String getPathParameter(String name) {
/*  457 */     return this.coyoteRequest.getPathParameter(name);
/*      */   }
/*      */   
/*      */   public void setAsyncSupported(boolean asyncSupported) {
/*  461 */     this.asyncSupported = Boolean.valueOf(asyncSupported);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void recycle()
/*      */   {
/*  470 */     this.internalDispatcherType = null;
/*  471 */     this.requestDispatcherPath = null;
/*      */     
/*  473 */     this.authType = null;
/*  474 */     this.inputBuffer.recycle();
/*  475 */     this.usingInputStream = false;
/*  476 */     this.usingReader = false;
/*  477 */     this.userPrincipal = null;
/*  478 */     this.subject = null;
/*  479 */     this.parametersParsed = false;
/*  480 */     if (this.parts != null) {
/*  481 */       for (Part part : this.parts) {
/*      */         try {
/*  483 */           part.delete();
/*      */         }
/*      */         catch (IOException localIOException) {}
/*      */       }
/*      */       
/*  488 */       this.parts = null;
/*      */     }
/*  490 */     this.partsParseException = null;
/*  491 */     this.locales.clear();
/*  492 */     this.localesParsed = false;
/*  493 */     this.secure = false;
/*  494 */     this.remoteAddr = null;
/*  495 */     this.peerAddr = null;
/*  496 */     this.remoteHost = null;
/*  497 */     this.remotePort = -1;
/*  498 */     this.localPort = -1;
/*  499 */     this.localAddr = null;
/*  500 */     this.localName = null;
/*      */     
/*  502 */     this.attributes.clear();
/*  503 */     this.sslAttributesParsed = false;
/*  504 */     this.notes.clear();
/*      */     
/*  506 */     recycleSessionInfo();
/*  507 */     recycleCookieInfo(false);
/*      */     
/*  509 */     if (getDiscardFacades()) {
/*  510 */       this.parameterMap = new ParameterMap();
/*      */     } else {
/*  512 */       this.parameterMap.setLocked(false);
/*  513 */       this.parameterMap.clear();
/*      */     }
/*      */     
/*  516 */     this.mappingData.recycle();
/*  517 */     this.applicationMapping.recycle();
/*      */     
/*  519 */     this.applicationRequest = null;
/*  520 */     if (getDiscardFacades()) {
/*  521 */       if (this.facade != null) {
/*  522 */         this.facade.clear();
/*  523 */         this.facade = null;
/*      */       }
/*  525 */       if (this.inputStream != null) {
/*  526 */         this.inputStream.clear();
/*  527 */         this.inputStream = null;
/*      */       }
/*  529 */       if (this.reader != null) {
/*  530 */         this.reader.clear();
/*  531 */         this.reader = null;
/*      */       }
/*      */     }
/*      */     
/*  535 */     this.asyncSupported = null;
/*  536 */     if (this.asyncContext != null) {
/*  537 */       this.asyncContext.recycle();
/*      */     }
/*  539 */     this.asyncContext = null;
/*      */   }
/*      */   
/*      */   protected void recycleSessionInfo()
/*      */   {
/*  544 */     if (this.session != null) {
/*      */       try {
/*  546 */         this.session.endAccess();
/*      */       } catch (Throwable t) {
/*  548 */         ExceptionUtils.handleThrowable(t);
/*  549 */         log.warn(sm.getString("coyoteRequest.sessionEndAccessFail"), t);
/*      */       }
/*      */     }
/*  552 */     this.session = null;
/*  553 */     this.requestedSessionCookie = false;
/*  554 */     this.requestedSessionId = null;
/*  555 */     this.requestedSessionURL = false;
/*  556 */     this.requestedSessionSSL = false;
/*      */   }
/*      */   
/*      */   protected void recycleCookieInfo(boolean recycleCoyote)
/*      */   {
/*  561 */     this.cookiesParsed = false;
/*  562 */     this.cookiesConverted = false;
/*  563 */     this.cookies = null;
/*  564 */     if (recycleCoyote) {
/*  565 */       getCoyoteRequest().getCookies().recycle();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connector getConnector()
/*      */   {
/*  581 */     return this.connector;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context getContext()
/*      */   {
/*  595 */     return this.mappingData.context;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDiscardFacades()
/*      */   {
/*  605 */     return this.connector == null ? true : this.connector.getDiscardFacades();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  612 */   protected FilterChain filterChain = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FilterChain getFilterChain()
/*      */   {
/*  620 */     return this.filterChain;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFilterChain(FilterChain filterChain)
/*      */   {
/*  629 */     this.filterChain = filterChain;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Host getHost()
/*      */   {
/*  637 */     return this.mappingData.host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  644 */   protected final MappingData mappingData = new MappingData();
/*  645 */   private final ApplicationMapping applicationMapping = new ApplicationMapping(this.mappingData);
/*      */   
/*      */ 
/*      */ 
/*      */   public MappingData getMappingData()
/*      */   {
/*  651 */     return this.mappingData;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  658 */   protected RequestFacade facade = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpServletRequest getRequest()
/*      */   {
/*  666 */     if (this.facade == null) {
/*  667 */       this.facade = new RequestFacade(this);
/*      */     }
/*  669 */     if (this.applicationRequest == null) {
/*  670 */       this.applicationRequest = this.facade;
/*      */     }
/*  672 */     return this.applicationRequest;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequest(HttpServletRequest applicationRequest)
/*      */   {
/*  686 */     ServletRequest r = applicationRequest;
/*  687 */     while ((r instanceof HttpServletRequestWrapper)) {
/*  688 */       r = ((HttpServletRequestWrapper)r).getRequest();
/*      */     }
/*  690 */     if (r != this.facade) {
/*  691 */       throw new IllegalArgumentException(sm.getString("request.illegalWrap"));
/*      */     }
/*  693 */     this.applicationRequest = applicationRequest;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  700 */   protected Response response = null;
/*      */   
/*      */ 
/*      */ 
/*      */   public Response getResponse()
/*      */   {
/*  706 */     return this.response;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResponse(Response response)
/*      */   {
/*  715 */     this.response = response;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public InputStream getStream()
/*      */   {
/*  722 */     if (this.inputStream == null) {
/*  723 */       this.inputStream = new CoyoteInputStream(this.inputBuffer);
/*      */     }
/*  725 */     return this.inputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  731 */   protected B2CConverter URIConverter = null;
/*      */   
/*      */ 
/*      */ 
/*      */   protected B2CConverter getURIConverter()
/*      */   {
/*  737 */     return this.URIConverter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setURIConverter(B2CConverter URIConverter)
/*      */   {
/*  746 */     this.URIConverter = URIConverter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Wrapper getWrapper()
/*      */   {
/*  754 */     return this.mappingData.wrapper;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletInputStream createInputStream()
/*      */     throws IOException
/*      */   {
/*  769 */     if (this.inputStream == null) {
/*  770 */       this.inputStream = new CoyoteInputStream(this.inputBuffer);
/*      */     }
/*  772 */     return this.inputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void finishRequest()
/*      */     throws IOException
/*      */   {
/*  783 */     if (this.response.getStatus() == 413) {
/*  784 */       checkSwallowInput();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getNote(String name)
/*      */   {
/*  796 */     return this.notes.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeNote(String name)
/*      */   {
/*  807 */     this.notes.remove(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocalPort(int port)
/*      */   {
/*  817 */     this.localPort = port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNote(String name, Object value)
/*      */   {
/*  828 */     this.notes.put(name, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRemoteAddr(String remoteAddr)
/*      */   {
/*  838 */     this.remoteAddr = remoteAddr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRemoteHost(String remoteHost)
/*      */   {
/*  849 */     this.remoteHost = remoteHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecure(boolean secure)
/*      */   {
/*  860 */     this.secure = secure;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServerPort(int port)
/*      */   {
/*  870 */     this.coyoteRequest.setServerPort(port);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getAttribute(String name)
/*      */   {
/*  885 */     SpecialAttributeAdapter adapter = (SpecialAttributeAdapter)specialAttributes.get(name);
/*  886 */     if (adapter != null) {
/*  887 */       return adapter.get(this, name);
/*      */     }
/*      */     
/*  890 */     Object attr = this.attributes.get(name);
/*      */     
/*  892 */     if (attr != null) {
/*  893 */       return attr;
/*      */     }
/*      */     
/*  896 */     attr = this.coyoteRequest.getAttribute(name);
/*  897 */     if (attr != null) {
/*  898 */       return attr;
/*      */     }
/*  900 */     if ((!this.sslAttributesParsed) && (TLSUtil.isTLSRequestAttribute(name))) {
/*  901 */       this.coyoteRequest.action(ActionCode.REQ_SSL_ATTRIBUTE, this.coyoteRequest);
/*  902 */       attr = this.coyoteRequest.getAttribute("javax.servlet.request.X509Certificate");
/*  903 */       if (attr != null) {
/*  904 */         this.attributes.put("javax.servlet.request.X509Certificate", attr);
/*      */       }
/*  906 */       attr = this.coyoteRequest.getAttribute("javax.servlet.request.cipher_suite");
/*  907 */       if (attr != null) {
/*  908 */         this.attributes.put("javax.servlet.request.cipher_suite", attr);
/*      */       }
/*  910 */       attr = this.coyoteRequest.getAttribute("javax.servlet.request.key_size");
/*  911 */       if (attr != null) {
/*  912 */         this.attributes.put("javax.servlet.request.key_size", attr);
/*      */       }
/*  914 */       attr = this.coyoteRequest.getAttribute("javax.servlet.request.ssl_session_id");
/*  915 */       if (attr != null) {
/*  916 */         this.attributes.put("javax.servlet.request.ssl_session_id", attr);
/*      */       }
/*  918 */       attr = this.coyoteRequest.getAttribute("javax.servlet.request.ssl_session_mgr");
/*  919 */       if (attr != null) {
/*  920 */         this.attributes.put("javax.servlet.request.ssl_session_mgr", attr);
/*      */       }
/*  922 */       attr = this.coyoteRequest.getAttribute("org.apache.tomcat.util.net.secure_protocol_version");
/*  923 */       if (attr != null) {
/*  924 */         this.attributes.put("org.apache.tomcat.util.net.secure_protocol_version", attr);
/*      */       }
/*  926 */       attr = this.coyoteRequest.getAttribute("org.apache.tomcat.util.net.secure_requested_protocol_versions");
/*  927 */       if (attr != null) {
/*  928 */         this.attributes.put("org.apache.tomcat.util.net.secure_requested_protocol_versions", attr);
/*      */       }
/*  930 */       attr = this.coyoteRequest.getAttribute("org.apache.tomcat.util.net.secure_requested_ciphers");
/*  931 */       if (attr != null) {
/*  932 */         this.attributes.put("org.apache.tomcat.util.net.secure_requested_ciphers", attr);
/*      */       }
/*  934 */       attr = this.attributes.get(name);
/*  935 */       this.sslAttributesParsed = true;
/*      */     }
/*  937 */     return attr;
/*      */   }
/*      */   
/*      */ 
/*      */   public long getContentLengthLong()
/*      */   {
/*  943 */     return this.coyoteRequest.getContentLengthLong();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<String> getAttributeNames()
/*      */   {
/*  977 */     if ((isSecure()) && (!this.sslAttributesParsed)) {
/*  978 */       getAttribute("javax.servlet.request.X509Certificate");
/*      */     }
/*      */     
/*      */ 
/*  982 */     Set<String> names = new HashSet(this.attributes.keySet());
/*  983 */     return Collections.enumeration(names);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCharacterEncoding()
/*      */   {
/*  992 */     String characterEncoding = this.coyoteRequest.getCharacterEncoding();
/*  993 */     if (characterEncoding != null) {
/*  994 */       return characterEncoding;
/*      */     }
/*      */     
/*  997 */     Context context = getContext();
/*  998 */     if (context != null) {
/*  999 */       return context.getRequestCharacterEncoding();
/*      */     }
/*      */     
/* 1002 */     return null;
/*      */   }
/*      */   
/*      */   private Charset getCharset()
/*      */   {
/* 1007 */     Charset charset = null;
/*      */     try {
/* 1009 */       charset = this.coyoteRequest.getCharset();
/*      */     }
/*      */     catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
/*      */     
/* 1013 */     if (charset != null) {
/* 1014 */       return charset;
/*      */     }
/*      */     
/* 1017 */     Context context = getContext();
/* 1018 */     if (context != null) {
/* 1019 */       String encoding = context.getRequestCharacterEncoding();
/* 1020 */       if (encoding != null) {
/*      */         try {
/* 1022 */           return B2CConverter.getCharset(encoding);
/*      */         }
/*      */         catch (UnsupportedEncodingException localUnsupportedEncodingException1) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1029 */     return Constants.DEFAULT_BODY_CHARSET;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getContentLength()
/*      */   {
/* 1038 */     return this.coyoteRequest.getContentLength();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getContentType()
/*      */   {
/* 1047 */     return this.coyoteRequest.getContentType();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContentType(String contentType)
/*      */   {
/* 1057 */     this.coyoteRequest.setContentType(contentType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletInputStream getInputStream()
/*      */     throws IOException
/*      */   {
/* 1073 */     if (this.usingReader) {
/* 1074 */       throw new IllegalStateException(sm.getString("coyoteRequest.getInputStream.ise"));
/*      */     }
/*      */     
/* 1077 */     this.usingInputStream = true;
/* 1078 */     if (this.inputStream == null) {
/* 1079 */       this.inputStream = new CoyoteInputStream(this.inputBuffer);
/*      */     }
/* 1081 */     return this.inputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Locale getLocale()
/*      */   {
/* 1095 */     if (!this.localesParsed) {
/* 1096 */       parseLocales();
/*      */     }
/*      */     
/* 1099 */     if (this.locales.size() > 0) {
/* 1100 */       return (Locale)this.locales.get(0);
/*      */     }
/*      */     
/* 1103 */     return defaultLocale;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<Locale> getLocales()
/*      */   {
/* 1116 */     if (!this.localesParsed) {
/* 1117 */       parseLocales();
/*      */     }
/*      */     
/* 1120 */     if (this.locales.size() > 0) {
/* 1121 */       return Collections.enumeration(this.locales);
/*      */     }
/* 1123 */     ArrayList<Locale> results = new ArrayList();
/* 1124 */     results.add(defaultLocale);
/* 1125 */     return Collections.enumeration(results);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getParameter(String name)
/*      */   {
/* 1140 */     if (!this.parametersParsed) {
/* 1141 */       parseParameters();
/*      */     }
/*      */     
/* 1144 */     return this.coyoteRequest.getParameters().getParameter(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Map<String, String[]> getParameterMap()
/*      */   {
/* 1162 */     if (this.parameterMap.isLocked()) {
/* 1163 */       return this.parameterMap;
/*      */     }
/*      */     
/* 1166 */     Enumeration<String> enumeration = getParameterNames();
/* 1167 */     while (enumeration.hasMoreElements()) {
/* 1168 */       String name = (String)enumeration.nextElement();
/* 1169 */       String[] values = getParameterValues(name);
/* 1170 */       this.parameterMap.put(name, values);
/*      */     }
/*      */     
/* 1173 */     this.parameterMap.setLocked(true);
/*      */     
/* 1175 */     return this.parameterMap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<String> getParameterNames()
/*      */   {
/* 1186 */     if (!this.parametersParsed) {
/* 1187 */       parseParameters();
/*      */     }
/*      */     
/* 1190 */     return this.coyoteRequest.getParameters().getParameterNames();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getParameterValues(String name)
/*      */   {
/* 1204 */     if (!this.parametersParsed) {
/* 1205 */       parseParameters();
/*      */     }
/*      */     
/* 1208 */     return this.coyoteRequest.getParameters().getParameterValues(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProtocol()
/*      */   {
/* 1218 */     return this.coyoteRequest.protocol().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BufferedReader getReader()
/*      */     throws IOException
/*      */   {
/* 1235 */     if (this.usingInputStream) {
/* 1236 */       throw new IllegalStateException(sm.getString("coyoteRequest.getReader.ise"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1243 */     if (this.coyoteRequest.getCharacterEncoding() == null)
/*      */     {
/*      */ 
/* 1246 */       Context context = getContext();
/* 1247 */       if (context != null) {
/* 1248 */         String enc = context.getRequestCharacterEncoding();
/* 1249 */         if (enc != null)
/*      */         {
/*      */ 
/* 1252 */           setCharacterEncoding(enc);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1257 */     this.usingReader = true;
/*      */     
/* 1259 */     this.inputBuffer.checkConverter();
/* 1260 */     if (this.reader == null) {
/* 1261 */       this.reader = new CoyoteReader(this.inputBuffer);
/*      */     }
/* 1263 */     return this.reader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String getRealPath(String path)
/*      */   {
/* 1279 */     Context context = getContext();
/* 1280 */     if (context == null) {
/* 1281 */       return null;
/*      */     }
/* 1283 */     ServletContext servletContext = context.getServletContext();
/* 1284 */     if (servletContext == null) {
/* 1285 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 1289 */       return servletContext.getRealPath(path);
/*      */     } catch (IllegalArgumentException e) {}
/* 1291 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRemoteAddr()
/*      */   {
/* 1301 */     if (this.remoteAddr == null) {
/* 1302 */       this.coyoteRequest.action(ActionCode.REQ_HOST_ADDR_ATTRIBUTE, this.coyoteRequest);
/* 1303 */       this.remoteAddr = this.coyoteRequest.remoteAddr().toString();
/*      */     }
/* 1305 */     return this.remoteAddr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPeerAddr()
/*      */   {
/* 1313 */     if (this.peerAddr == null) {
/* 1314 */       this.coyoteRequest.action(ActionCode.REQ_PEER_ADDR_ATTRIBUTE, this.coyoteRequest);
/* 1315 */       this.peerAddr = this.coyoteRequest.peerAddr().toString();
/*      */     }
/* 1317 */     return this.peerAddr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRemoteHost()
/*      */   {
/* 1326 */     if (this.remoteHost == null) {
/* 1327 */       if (!this.connector.getEnableLookups()) {
/* 1328 */         this.remoteHost = getRemoteAddr();
/*      */       } else {
/* 1330 */         this.coyoteRequest.action(ActionCode.REQ_HOST_ATTRIBUTE, this.coyoteRequest);
/* 1331 */         this.remoteHost = this.coyoteRequest.remoteHost().toString();
/*      */       }
/*      */     }
/* 1334 */     return this.remoteHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRemotePort()
/*      */   {
/* 1343 */     if (this.remotePort == -1) {
/* 1344 */       this.coyoteRequest.action(ActionCode.REQ_REMOTEPORT_ATTRIBUTE, this.coyoteRequest);
/* 1345 */       this.remotePort = this.coyoteRequest.getRemotePort();
/*      */     }
/* 1347 */     return this.remotePort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLocalName()
/*      */   {
/* 1356 */     if (this.localName == null) {
/* 1357 */       this.coyoteRequest.action(ActionCode.REQ_LOCAL_NAME_ATTRIBUTE, this.coyoteRequest);
/* 1358 */       this.localName = this.coyoteRequest.localName().toString();
/*      */     }
/* 1360 */     return this.localName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLocalAddr()
/*      */   {
/* 1369 */     if (this.localAddr == null) {
/* 1370 */       this.coyoteRequest.action(ActionCode.REQ_LOCAL_ADDR_ATTRIBUTE, this.coyoteRequest);
/* 1371 */       this.localAddr = this.coyoteRequest.localAddr().toString();
/*      */     }
/* 1373 */     return this.localAddr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLocalPort()
/*      */   {
/* 1383 */     if (this.localPort == -1) {
/* 1384 */       this.coyoteRequest.action(ActionCode.REQ_LOCALPORT_ATTRIBUTE, this.coyoteRequest);
/* 1385 */       this.localPort = this.coyoteRequest.getLocalPort();
/*      */     }
/* 1387 */     return this.localPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RequestDispatcher getRequestDispatcher(String path)
/*      */   {
/* 1399 */     Context context = getContext();
/* 1400 */     if (context == null) {
/* 1401 */       return null;
/*      */     }
/*      */     
/* 1404 */     if (path == null) {
/* 1405 */       return null;
/*      */     }
/*      */     
/* 1408 */     int fragmentPos = path.indexOf('#');
/* 1409 */     if (fragmentPos > -1) {
/* 1410 */       log.warn(sm.getString("request.fragmentInDispatchPath", new Object[] { path }));
/* 1411 */       path = path.substring(0, fragmentPos);
/*      */     }
/*      */     
/*      */ 
/* 1415 */     if (path.startsWith("/")) {
/* 1416 */       return context.getServletContext().getRequestDispatcher(path);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1439 */     String servletPath = (String)getAttribute("javax.servlet.include.servlet_path");
/*      */     
/* 1441 */     if (servletPath == null) {
/* 1442 */       servletPath = getServletPath();
/*      */     }
/*      */     
/*      */ 
/* 1446 */     String pathInfo = getPathInfo();
/* 1447 */     String requestPath = null;
/*      */     
/* 1449 */     if (pathInfo == null) {
/* 1450 */       requestPath = servletPath;
/*      */     } else {
/* 1452 */       requestPath = servletPath + pathInfo;
/*      */     }
/*      */     
/* 1455 */     int pos = requestPath.lastIndexOf('/');
/* 1456 */     String relative = null;
/* 1457 */     if (context.getDispatchersUseEncodedPaths()) {
/* 1458 */       if (pos >= 0) {
/* 1459 */         relative = URLEncoder.DEFAULT.encode(requestPath
/* 1460 */           .substring(0, pos + 1), StandardCharsets.UTF_8) + path;
/*      */       }
/*      */       else {
/* 1462 */         relative = URLEncoder.DEFAULT.encode(requestPath, StandardCharsets.UTF_8) + path;
/*      */       }
/*      */     }
/* 1465 */     else if (pos >= 0) {
/* 1466 */       relative = requestPath.substring(0, pos + 1) + path;
/*      */     } else {
/* 1468 */       relative = requestPath + path;
/*      */     }
/*      */     
/*      */ 
/* 1472 */     return context.getServletContext().getRequestDispatcher(relative);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getScheme()
/*      */   {
/* 1481 */     return this.coyoteRequest.scheme().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServerName()
/*      */   {
/* 1490 */     return this.coyoteRequest.serverName().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getServerPort()
/*      */   {
/* 1499 */     return this.coyoteRequest.getServerPort();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSecure()
/*      */   {
/* 1508 */     return this.secure;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAttribute(String name)
/*      */   {
/* 1521 */     if (name.startsWith("org.apache.tomcat.")) {
/* 1522 */       this.coyoteRequest.getAttributes().remove(name);
/*      */     }
/*      */     
/* 1525 */     boolean found = this.attributes.containsKey(name);
/* 1526 */     if (found) {
/* 1527 */       Object value = this.attributes.get(name);
/* 1528 */       this.attributes.remove(name);
/*      */       
/*      */ 
/* 1531 */       notifyAttributeRemoved(name, value);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAttribute(String name, Object value)
/*      */   {
/* 1546 */     if (name == null) {
/* 1547 */       throw new IllegalArgumentException(sm.getString("coyoteRequest.setAttribute.namenull"));
/*      */     }
/*      */     
/*      */ 
/* 1551 */     if (value == null) {
/* 1552 */       removeAttribute(name);
/* 1553 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1557 */     SpecialAttributeAdapter adapter = (SpecialAttributeAdapter)specialAttributes.get(name);
/* 1558 */     if (adapter != null) {
/* 1559 */       adapter.set(this, name, value);
/* 1560 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1565 */     if ((Globals.IS_SECURITY_ENABLED) && 
/* 1566 */       (name.equals("org.apache.tomcat.sendfile.filename")))
/*      */     {
/*      */ 
/*      */       try
/*      */       {
/* 1571 */         canonicalPath = new File(value.toString()).getCanonicalPath();
/*      */       } catch (IOException e) { String canonicalPath;
/* 1573 */         throw new SecurityException(sm.getString("coyoteRequest.sendfileNotCanonical", new Object[] { value }), e);
/*      */       }
/*      */       
/*      */ 
/*      */       String canonicalPath;
/*      */       
/* 1579 */       System.getSecurityManager().checkRead(canonicalPath);
/*      */       
/* 1581 */       value = canonicalPath;
/*      */     }
/*      */     
/* 1584 */     Object oldValue = this.attributes.put(name, value);
/*      */     
/*      */ 
/* 1587 */     if (name.startsWith("org.apache.tomcat.")) {
/* 1588 */       this.coyoteRequest.setAttribute(name, value);
/*      */     }
/*      */     
/*      */ 
/* 1592 */     notifyAttributeAssigned(name, value, oldValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void notifyAttributeAssigned(String name, Object value, Object oldValue)
/*      */   {
/* 1605 */     Context context = getContext();
/* 1606 */     if (context == null) {
/* 1607 */       return;
/*      */     }
/* 1609 */     Object[] listeners = context.getApplicationEventListeners();
/* 1610 */     if ((listeners == null) || (listeners.length == 0)) {
/* 1611 */       return;
/*      */     }
/* 1613 */     boolean replaced = oldValue != null;
/* 1614 */     ServletRequestAttributeEvent event = null;
/* 1615 */     if (replaced)
/*      */     {
/* 1617 */       event = new ServletRequestAttributeEvent(context.getServletContext(), getRequest(), name, oldValue);
/*      */     }
/*      */     else {
/* 1620 */       event = new ServletRequestAttributeEvent(context.getServletContext(), getRequest(), name, value);
/*      */     }
/*      */     
/* 1623 */     for (Object o : listeners) {
/* 1624 */       if ((o instanceof ServletRequestAttributeListener))
/*      */       {
/*      */ 
/* 1627 */         ServletRequestAttributeListener listener = (ServletRequestAttributeListener)o;
/*      */         try {
/* 1629 */           if (replaced) {
/* 1630 */             listener.attributeReplaced(event);
/*      */           } else {
/* 1632 */             listener.attributeAdded(event);
/*      */           }
/*      */         } catch (Throwable t) {
/* 1635 */           ExceptionUtils.handleThrowable(t);
/*      */           
/* 1637 */           this.attributes.put("javax.servlet.error.exception", t);
/* 1638 */           context.getLogger().error(sm.getString("coyoteRequest.attributeEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void notifyAttributeRemoved(String name, Object value)
/*      */   {
/* 1651 */     Context context = getContext();
/* 1652 */     Object[] listeners = context.getApplicationEventListeners();
/* 1653 */     if ((listeners == null) || (listeners.length == 0)) {
/* 1654 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1658 */     ServletRequestAttributeEvent event = new ServletRequestAttributeEvent(context.getServletContext(), getRequest(), name, value);
/* 1659 */     for (Object o : listeners) {
/* 1660 */       if ((o instanceof ServletRequestAttributeListener))
/*      */       {
/*      */ 
/* 1663 */         ServletRequestAttributeListener listener = (ServletRequestAttributeListener)o;
/*      */         try {
/* 1665 */           listener.attributeRemoved(event);
/*      */         } catch (Throwable t) {
/* 1667 */           ExceptionUtils.handleThrowable(t);
/*      */           
/* 1669 */           this.attributes.put("javax.servlet.error.exception", t);
/* 1670 */           context.getLogger().error(sm.getString("coyoteRequest.attributeEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterEncoding(String enc)
/*      */     throws UnsupportedEncodingException
/*      */   {
/* 1691 */     if (this.usingReader) {
/* 1692 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1696 */     Charset charset = B2CConverter.getCharset(enc);
/*      */     
/*      */ 
/* 1699 */     this.coyoteRequest.setCharset(charset);
/*      */   }
/*      */   
/*      */ 
/*      */   public ServletContext getServletContext()
/*      */   {
/* 1705 */     return getContext().getServletContext();
/*      */   }
/*      */   
/*      */   public AsyncContext startAsync()
/*      */   {
/* 1710 */     return startAsync(getRequest(), this.response.getResponse());
/*      */   }
/*      */   
/*      */ 
/*      */   public AsyncContext startAsync(ServletRequest request, ServletResponse response)
/*      */   {
/* 1716 */     if (!isAsyncSupported())
/*      */     {
/* 1718 */       IllegalStateException ise = new IllegalStateException(sm.getString("request.asyncNotSupported"));
/* 1719 */       log.warn(sm.getString("coyoteRequest.noAsync", new Object[] {
/* 1720 */         StringUtils.join(getNonAsyncClassNames()) }), ise);
/* 1721 */       throw ise;
/*      */     }
/*      */     
/* 1724 */     if (this.asyncContext == null) {
/* 1725 */       this.asyncContext = new AsyncContextImpl(this);
/*      */     }
/*      */     
/* 1728 */     this.asyncContext.setStarted(getContext(), request, response, 
/* 1729 */       (request == getRequest()) && (response == getResponse().getResponse()));
/* 1730 */     this.asyncContext.setTimeout(getConnector().getAsyncTimeout());
/*      */     
/* 1732 */     return this.asyncContext;
/*      */   }
/*      */   
/*      */   private Set<String> getNonAsyncClassNames()
/*      */   {
/* 1737 */     Set<String> result = new HashSet();
/*      */     
/* 1739 */     Wrapper wrapper = getWrapper();
/* 1740 */     if (!wrapper.isAsyncSupported()) {
/* 1741 */       result.add(wrapper.getServletClass());
/*      */     }
/*      */     
/* 1744 */     FilterChain filterChain = getFilterChain();
/* 1745 */     if ((filterChain instanceof ApplicationFilterChain)) {
/* 1746 */       ((ApplicationFilterChain)filterChain).findNonAsyncFilters(result);
/*      */     } else {
/* 1748 */       result.add(sm.getString("coyoteRequest.filterAsyncSupportUnknown"));
/*      */     }
/*      */     
/* 1751 */     Container c = wrapper;
/* 1752 */     while (c != null) {
/* 1753 */       c.getPipeline().findNonAsyncValves(result);
/* 1754 */       c = c.getParent();
/*      */     }
/*      */     
/* 1757 */     return result;
/*      */   }
/*      */   
/*      */   public boolean isAsyncStarted()
/*      */   {
/* 1762 */     if (this.asyncContext == null) {
/* 1763 */       return false;
/*      */     }
/*      */     
/* 1766 */     return this.asyncContext.isStarted();
/*      */   }
/*      */   
/*      */   public boolean isAsyncDispatching() {
/* 1770 */     if (this.asyncContext == null) {
/* 1771 */       return false;
/*      */     }
/*      */     
/* 1774 */     AtomicBoolean result = new AtomicBoolean(false);
/* 1775 */     this.coyoteRequest.action(ActionCode.ASYNC_IS_DISPATCHING, result);
/* 1776 */     return result.get();
/*      */   }
/*      */   
/*      */   public boolean isAsyncCompleting() {
/* 1780 */     if (this.asyncContext == null) {
/* 1781 */       return false;
/*      */     }
/*      */     
/* 1784 */     AtomicBoolean result = new AtomicBoolean(false);
/* 1785 */     this.coyoteRequest.action(ActionCode.ASYNC_IS_COMPLETING, result);
/* 1786 */     return result.get();
/*      */   }
/*      */   
/*      */   public boolean isAsync() {
/* 1790 */     if (this.asyncContext == null) {
/* 1791 */       return false;
/*      */     }
/*      */     
/* 1794 */     AtomicBoolean result = new AtomicBoolean(false);
/* 1795 */     this.coyoteRequest.action(ActionCode.ASYNC_IS_ASYNC, result);
/* 1796 */     return result.get();
/*      */   }
/*      */   
/*      */   public boolean isAsyncSupported()
/*      */   {
/* 1801 */     if (this.asyncSupported == null) {
/* 1802 */       return true;
/*      */     }
/*      */     
/* 1805 */     return this.asyncSupported.booleanValue();
/*      */   }
/*      */   
/*      */   public AsyncContext getAsyncContext()
/*      */   {
/* 1810 */     if (!isAsyncStarted()) {
/* 1811 */       throw new IllegalStateException(sm.getString("request.notAsync"));
/*      */     }
/* 1813 */     return this.asyncContext;
/*      */   }
/*      */   
/*      */   public AsyncContextImpl getAsyncContextInternal() {
/* 1817 */     return this.asyncContext;
/*      */   }
/*      */   
/*      */   public DispatcherType getDispatcherType()
/*      */   {
/* 1822 */     if (this.internalDispatcherType == null) {
/* 1823 */       return DispatcherType.REQUEST;
/*      */     }
/*      */     
/* 1826 */     return this.internalDispatcherType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCookie(Cookie cookie)
/*      */   {
/* 1839 */     if (!this.cookiesConverted) {
/* 1840 */       convertCookies();
/*      */     }
/*      */     
/* 1843 */     int size = 0;
/* 1844 */     if (this.cookies != null) {
/* 1845 */       size = this.cookies.length;
/*      */     }
/*      */     
/* 1848 */     Cookie[] newCookies = new Cookie[size + 1];
/* 1849 */     if (this.cookies != null) {
/* 1850 */       System.arraycopy(this.cookies, 0, newCookies, 0, size);
/*      */     }
/* 1852 */     newCookies[size] = cookie;
/*      */     
/* 1854 */     this.cookies = newCookies;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addLocale(Locale locale)
/*      */   {
/* 1866 */     this.locales.add(locale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearCookies()
/*      */   {
/* 1874 */     this.cookiesParsed = true;
/* 1875 */     this.cookiesConverted = true;
/* 1876 */     this.cookies = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearLocales()
/*      */   {
/* 1884 */     this.locales.clear();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAuthType(String type)
/*      */   {
/* 1896 */     this.authType = type;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPathInfo(String path)
/*      */   {
/* 1908 */     this.mappingData.pathInfo.setString(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestedSessionCookie(boolean flag)
/*      */   {
/* 1921 */     this.requestedSessionCookie = flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestedSessionId(String id)
/*      */   {
/* 1934 */     this.requestedSessionId = id;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestedSessionURL(boolean flag)
/*      */   {
/* 1948 */     this.requestedSessionURL = flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestedSessionSSL(boolean flag)
/*      */   {
/* 1962 */     this.requestedSessionSSL = flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDecodedRequestURI()
/*      */   {
/* 1973 */     return this.coyoteRequest.decodedURI().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MessageBytes getDecodedRequestURIMB()
/*      */   {
/* 1983 */     return this.coyoteRequest.decodedURI();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserPrincipal(Principal principal)
/*      */   {
/* 1995 */     if ((Globals.IS_SECURITY_ENABLED) && (principal != null)) {
/* 1996 */       if (this.subject == null) {
/* 1997 */         HttpSession session = getSession(false);
/* 1998 */         if (session == null)
/*      */         {
/* 2000 */           this.subject = newSubject(principal);
/*      */         }
/*      */         else {
/* 2003 */           this.subject = ((Subject)session.getAttribute("javax.security.auth.subject"));
/* 2004 */           if (this.subject == null) {
/* 2005 */             this.subject = newSubject(principal);
/* 2006 */             session.setAttribute("javax.security.auth.subject", this.subject);
/*      */           } else {
/* 2008 */             this.subject.getPrincipals().add(principal);
/*      */           }
/*      */         }
/*      */       } else {
/* 2012 */         this.subject.getPrincipals().add(principal);
/*      */       }
/*      */     }
/* 2015 */     this.userPrincipal = principal;
/*      */   }
/*      */   
/*      */   private Subject newSubject(Principal principal)
/*      */   {
/* 2020 */     Subject result = new Subject();
/* 2021 */     result.getPrincipals().add(principal);
/* 2022 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isTrailerFieldsReady()
/*      */   {
/* 2030 */     return this.coyoteRequest.isTrailerFieldsReady();
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, String> getTrailerFields()
/*      */   {
/* 2036 */     if (!isTrailerFieldsReady()) {
/* 2037 */       throw new IllegalStateException(sm.getString("coyoteRequest.trailersNotReady"));
/*      */     }
/* 2039 */     Map<String, String> result = new HashMap(this.coyoteRequest.getTrailerFields());
/* 2040 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   public PushBuilder newPushBuilder()
/*      */   {
/* 2046 */     return newPushBuilder(this);
/*      */   }
/*      */   
/*      */   public PushBuilder newPushBuilder(HttpServletRequest request)
/*      */   {
/* 2051 */     AtomicBoolean result = new AtomicBoolean();
/* 2052 */     this.coyoteRequest.action(ActionCode.IS_PUSH_SUPPORTED, result);
/* 2053 */     if (result.get()) {
/* 2054 */       return new ApplicationPushBuilder(this, request);
/*      */     }
/* 2056 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T extends HttpUpgradeHandler> T upgrade(Class<T> httpUpgradeHandlerClass)
/*      */     throws IOException, ServletException
/*      */   {
/* 2066 */     InstanceManager instanceManager = null;
/*      */     try
/*      */     {
/*      */       T handler;
/* 2070 */       if (InternalHttpUpgradeHandler.class.isAssignableFrom(httpUpgradeHandlerClass)) {
/* 2071 */         handler = (HttpUpgradeHandler)httpUpgradeHandlerClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */       } else {
/* 2073 */         instanceManager = getContext().getInstanceManager();
/* 2074 */         handler = (HttpUpgradeHandler)instanceManager.newInstance(httpUpgradeHandlerClass);
/*      */       }
/*      */     } catch (ReflectiveOperationException|NamingException|IllegalArgumentException|SecurityException e) {
/*      */       T handler;
/* 2078 */       throw new ServletException(e);
/*      */     }
/*      */     T handler;
/* 2081 */     UpgradeToken upgradeToken = new UpgradeToken(handler, getContext(), instanceManager, getUpgradeProtocolName(httpUpgradeHandlerClass));
/*      */     
/* 2083 */     this.coyoteRequest.action(ActionCode.UPGRADE, upgradeToken);
/*      */     
/*      */ 
/*      */ 
/* 2087 */     this.response.setStatus(101);
/*      */     
/* 2089 */     return handler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getUpgradeProtocolName(Class<? extends HttpUpgradeHandler> httpUpgradeHandlerClass)
/*      */   {
/* 2096 */     String result = this.response.getHeader("upgrade");
/*      */     
/* 2098 */     if (result == null)
/*      */     {
/*      */ 
/* 2101 */       List<Upgrade> upgradeProtocols = Upgrade.parse(getHeaders("upgrade"));
/* 2102 */       if ((upgradeProtocols != null) && (upgradeProtocols.size() == 1)) {
/* 2103 */         result = ((Upgrade)upgradeProtocols.get(0)).toString();
/*      */       }
/*      */     }
/*      */     
/* 2107 */     if (result == null)
/*      */     {
/* 2109 */       result = httpUpgradeHandlerClass.getName();
/*      */     }
/* 2111 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAuthType()
/*      */   {
/* 2120 */     return this.authType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getContextPath()
/*      */   {
/* 2131 */     int lastSlash = this.mappingData.contextSlashCount;
/*      */     
/* 2133 */     if (lastSlash == 0) {
/* 2134 */       return "";
/*      */     }
/*      */     
/* 2137 */     String canonicalContextPath = getServletContext().getContextPath();
/*      */     
/* 2139 */     String uri = getRequestURI();
/* 2140 */     int pos = 0;
/* 2141 */     if (!getContext().getAllowMultipleLeadingForwardSlashInPath())
/*      */     {
/*      */ 
/*      */       do
/*      */       {
/* 2146 */         pos++;
/* 2147 */       } while ((pos < uri.length()) && (uri.charAt(pos) == '/'));
/* 2148 */       pos--;
/* 2149 */       uri = uri.substring(pos);
/*      */     }
/*      */     
/* 2152 */     char[] uriChars = uri.toCharArray();
/*      */     
/* 2154 */     while (lastSlash > 0) {
/* 2155 */       pos = nextSlash(uriChars, pos + 1);
/* 2156 */       if (pos == -1) {
/*      */         break;
/*      */       }
/* 2159 */       lastSlash--;
/*      */     }
/*      */     
/*      */ 
/*      */     String candidate;
/*      */     
/*      */ 
/* 2166 */     if (pos == -1) {
/* 2167 */       candidate = uri;
/*      */     } else {
/* 2169 */       candidate = uri.substring(0, pos);
/*      */     }
/* 2171 */     String candidate = removePathParameters(candidate);
/* 2172 */     candidate = UDecoder.URLDecode(candidate, this.connector.getURICharset());
/* 2173 */     candidate = org.apache.tomcat.util.http.RequestUtil.normalize(candidate);
/* 2174 */     boolean match = canonicalContextPath.equals(candidate);
/* 2175 */     while ((!match) && (pos != -1)) {
/* 2176 */       pos = nextSlash(uriChars, pos + 1);
/* 2177 */       if (pos == -1) {
/* 2178 */         candidate = uri;
/*      */       } else {
/* 2180 */         candidate = uri.substring(0, pos);
/*      */       }
/* 2182 */       candidate = removePathParameters(candidate);
/* 2183 */       candidate = UDecoder.URLDecode(candidate, this.connector.getURICharset());
/* 2184 */       candidate = org.apache.tomcat.util.http.RequestUtil.normalize(candidate);
/* 2185 */       match = canonicalContextPath.equals(candidate);
/*      */     }
/* 2187 */     if (match) {
/* 2188 */       if (pos == -1) {
/* 2189 */         return uri;
/*      */       }
/* 2191 */       return uri.substring(0, pos);
/*      */     }
/*      */     
/*      */ 
/* 2195 */     throw new IllegalStateException(sm.getString("coyoteRequest.getContextPath.ise", new Object[] { canonicalContextPath, uri }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String removePathParameters(String input)
/*      */   {
/* 2202 */     int nextSemiColon = input.indexOf(';');
/*      */     
/* 2204 */     if (nextSemiColon == -1) {
/* 2205 */       return input;
/*      */     }
/* 2207 */     StringBuilder result = new StringBuilder(input.length());
/* 2208 */     result.append(input.substring(0, nextSemiColon));
/*      */     for (;;) {
/* 2210 */       int nextSlash = input.indexOf('/', nextSemiColon);
/* 2211 */       if (nextSlash == -1) {
/*      */         break;
/*      */       }
/* 2214 */       nextSemiColon = input.indexOf(';', nextSlash);
/* 2215 */       if (nextSemiColon == -1) {
/* 2216 */         result.append(input.substring(nextSlash));
/* 2217 */         break;
/*      */       }
/* 2219 */       result.append(input.substring(nextSlash, nextSemiColon));
/*      */     }
/*      */     
/*      */ 
/* 2223 */     return result.toString();
/*      */   }
/*      */   
/*      */   private int nextSlash(char[] uri, int startPos)
/*      */   {
/* 2228 */     int len = uri.length;
/* 2229 */     int pos = startPos;
/* 2230 */     while (pos < len) {
/* 2231 */       if (uri[pos] == '/')
/* 2232 */         return pos;
/* 2233 */       if ((this.connector.getEncodedSolidusHandlingInternal() == EncodedSolidusHandling.DECODE) && (uri[pos] == '%') && (pos + 2 < len) && (uri[(pos + 1)] == '2') && ((uri[(pos + 2)] == 'f') || (uri[(pos + 2)] == 'F')))
/*      */       {
/*      */ 
/* 2236 */         return pos;
/*      */       }
/* 2238 */       pos++;
/*      */     }
/* 2240 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Cookie[] getCookies()
/*      */   {
/* 2253 */     if (!this.cookiesConverted) {
/* 2254 */       convertCookies();
/*      */     }
/* 2256 */     return this.cookies;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServerCookies getServerCookies()
/*      */   {
/* 2268 */     parseCookies();
/* 2269 */     return this.coyoteRequest.getCookies();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getDateHeader(String name)
/*      */   {
/* 2286 */     String value = getHeader(name);
/* 2287 */     if (value == null) {
/* 2288 */       return -1L;
/*      */     }
/*      */     
/*      */ 
/* 2292 */     long result = FastHttpDateFormat.parseDate(value);
/* 2293 */     if (result != -1L) {
/* 2294 */       return result;
/*      */     }
/* 2296 */     throw new IllegalArgumentException(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getHeader(String name)
/*      */   {
/* 2310 */     return this.coyoteRequest.getHeader(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<String> getHeaders(String name)
/*      */   {
/* 2323 */     return this.coyoteRequest.getMimeHeaders().values(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<String> getHeaderNames()
/*      */   {
/* 2332 */     return this.coyoteRequest.getMimeHeaders().names();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getIntHeader(String name)
/*      */   {
/* 2349 */     String value = getHeader(name);
/* 2350 */     if (value == null) {
/* 2351 */       return -1;
/*      */     }
/*      */     
/* 2354 */     return Integer.parseInt(value);
/*      */   }
/*      */   
/*      */ 
/*      */   public HttpServletMapping getHttpServletMapping()
/*      */   {
/* 2360 */     return this.applicationMapping.getHttpServletMapping();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMethod()
/*      */   {
/* 2369 */     return this.coyoteRequest.method().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPathInfo()
/*      */   {
/* 2378 */     return this.mappingData.pathInfo.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPathTranslated()
/*      */   {
/* 2389 */     Context context = getContext();
/* 2390 */     if (context == null) {
/* 2391 */       return null;
/*      */     }
/*      */     
/* 2394 */     if (getPathInfo() == null) {
/* 2395 */       return null;
/*      */     }
/*      */     
/* 2398 */     return context.getServletContext().getRealPath(getPathInfo());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getQueryString()
/*      */   {
/* 2407 */     return this.coyoteRequest.queryString().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRemoteUser()
/*      */   {
/* 2418 */     if (this.userPrincipal == null) {
/* 2419 */       return null;
/*      */     }
/*      */     
/* 2422 */     return this.userPrincipal.getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MessageBytes getRequestPathMB()
/*      */   {
/* 2432 */     return this.mappingData.requestPath;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRequestedSessionId()
/*      */   {
/* 2441 */     return this.requestedSessionId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRequestURI()
/*      */   {
/* 2450 */     return this.coyoteRequest.requestURI().toString();
/*      */   }
/*      */   
/*      */ 
/*      */   public StringBuffer getRequestURL()
/*      */   {
/* 2456 */     return org.apache.catalina.util.RequestUtil.getRequestURL(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServletPath()
/*      */   {
/* 2466 */     return this.mappingData.wrapperPath.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpSession getSession()
/*      */   {
/* 2476 */     Session session = doGetSession(true);
/* 2477 */     if (session == null) {
/* 2478 */       return null;
/*      */     }
/*      */     
/* 2481 */     return session.getSession();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpSession getSession(boolean create)
/*      */   {
/* 2493 */     Session session = doGetSession(create);
/* 2494 */     if (session == null) {
/* 2495 */       return null;
/*      */     }
/*      */     
/* 2498 */     return session.getSession();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRequestedSessionIdFromCookie()
/*      */   {
/* 2509 */     if (this.requestedSessionId == null) {
/* 2510 */       return false;
/*      */     }
/*      */     
/* 2513 */     return this.requestedSessionCookie;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRequestedSessionIdFromURL()
/*      */   {
/* 2524 */     if (this.requestedSessionId == null) {
/* 2525 */       return false;
/*      */     }
/*      */     
/* 2528 */     return this.requestedSessionURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public boolean isRequestedSessionIdFromUrl()
/*      */   {
/* 2542 */     return isRequestedSessionIdFromURL();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isRequestedSessionIdValid()
/*      */   {
/* 2553 */     if (this.requestedSessionId == null) {
/* 2554 */       return false;
/*      */     }
/*      */     
/* 2557 */     Context context = getContext();
/* 2558 */     if (context == null) {
/* 2559 */       return false;
/*      */     }
/*      */     
/* 2562 */     Manager manager = context.getManager();
/* 2563 */     if (manager == null) {
/* 2564 */       return false;
/*      */     }
/*      */     
/* 2567 */     Session session = null;
/*      */     try {
/* 2569 */       session = manager.findSession(this.requestedSessionId);
/*      */     }
/*      */     catch (IOException localIOException) {}
/*      */     
/*      */ 
/* 2574 */     if ((session == null) || (!session.isValid()))
/*      */     {
/* 2576 */       if (getMappingData().contexts == null) {
/* 2577 */         return false;
/*      */       }
/* 2579 */       for (int i = getMappingData().contexts.length; i > 0; i--) {
/* 2580 */         Context ctxt = getMappingData().contexts[(i - 1)];
/*      */         try {
/* 2582 */           if (ctxt.getManager().findSession(this.requestedSessionId) != null)
/*      */           {
/* 2584 */             return true;
/*      */           }
/*      */         }
/*      */         catch (IOException localIOException1) {}
/*      */       }
/*      */       
/* 2590 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 2594 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUserInRole(String role)
/*      */   {
/* 2608 */     if (this.userPrincipal == null) {
/* 2609 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 2613 */     Context context = getContext();
/* 2614 */     if (context == null) {
/* 2615 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2620 */     if ("*".equals(role)) {
/* 2621 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2626 */     if (("**".equals(role)) && (!context.findSecurityRole("**"))) {
/* 2627 */       return this.userPrincipal != null;
/*      */     }
/*      */     
/* 2630 */     Realm realm = context.getRealm();
/* 2631 */     if (realm == null) {
/* 2632 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 2636 */     return realm.hasRole(getWrapper(), this.userPrincipal, role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal getPrincipal()
/*      */   {
/* 2644 */     return this.userPrincipal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal getUserPrincipal()
/*      */   {
/* 2653 */     if ((this.userPrincipal instanceof TomcatPrincipal))
/*      */     {
/* 2655 */       GSSCredential gssCredential = ((TomcatPrincipal)this.userPrincipal).getGssCredential();
/* 2656 */       if (gssCredential != null) {
/* 2657 */         int left = -1;
/*      */         try {
/* 2659 */           left = gssCredential.getRemainingLifetime();
/*      */         } catch (GSSException e) {
/* 2661 */           log.warn(sm.getString("coyoteRequest.gssLifetimeFail", new Object[] {this.userPrincipal
/* 2662 */             .getName() }), e);
/*      */         }
/* 2664 */         if (left == 0)
/*      */         {
/*      */           try {
/* 2667 */             logout();
/*      */           }
/*      */           catch (ServletException localServletException) {}
/*      */           
/*      */ 
/* 2672 */           return null;
/*      */         }
/*      */       }
/* 2675 */       return ((TomcatPrincipal)this.userPrincipal).getUserPrincipal();
/*      */     }
/*      */     
/* 2678 */     return this.userPrincipal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Session getSessionInternal()
/*      */   {
/* 2687 */     return doGetSession(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void changeSessionId(String newSessionId)
/*      */   {
/* 2702 */     if ((this.requestedSessionId != null) && (this.requestedSessionId.length() > 0)) {
/* 2703 */       this.requestedSessionId = newSessionId;
/*      */     }
/*      */     
/* 2706 */     Context context = getContext();
/* 2707 */     if (context != null)
/*      */     {
/*      */ 
/* 2710 */       if (!context.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.COOKIE)) {
/* 2711 */         return;
/*      */       }
/*      */     }
/* 2714 */     if (this.response != null) {
/* 2715 */       Cookie newCookie = ApplicationSessionCookieConfig.createSessionCookie(context, newSessionId, 
/* 2716 */         isSecure());
/* 2717 */       this.response.addSessionCookieInternal(newCookie);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String changeSessionId()
/*      */   {
/* 2725 */     Session session = getSessionInternal(false);
/* 2726 */     if (session == null)
/*      */     {
/* 2728 */       throw new IllegalStateException(sm.getString("coyoteRequest.changeSessionId"));
/*      */     }
/*      */     
/* 2731 */     Manager manager = getContext().getManager();
/*      */     
/* 2733 */     String newSessionId = manager.rotateSessionId(session);
/* 2734 */     changeSessionId(newSessionId);
/*      */     
/* 2736 */     return newSessionId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Session getSessionInternal(boolean create)
/*      */   {
/* 2746 */     return doGetSession(create);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isParametersParsed()
/*      */   {
/* 2754 */     return this.parametersParsed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFinished()
/*      */   {
/* 2763 */     return this.coyoteRequest.isFinished();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkSwallowInput()
/*      */   {
/* 2773 */     Context context = getContext();
/* 2774 */     if ((context != null) && (!context.getSwallowAbortedUploads())) {
/* 2775 */       this.coyoteRequest.action(ActionCode.DISABLE_SWALLOW_INPUT, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean authenticate(HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/* 2785 */     if (response.isCommitted())
/*      */     {
/* 2787 */       throw new IllegalStateException(sm.getString("coyoteRequest.authenticate.ise"));
/*      */     }
/*      */     
/* 2790 */     return getContext().getAuthenticator().authenticate(this, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void login(String username, String password)
/*      */     throws ServletException
/*      */   {
/* 2799 */     if ((getAuthType() != null) || (getRemoteUser() != null) || 
/* 2800 */       (getUserPrincipal() != null))
/*      */     {
/* 2802 */       throw new ServletException(sm.getString("coyoteRequest.alreadyAuthenticated"));
/*      */     }
/*      */     
/* 2805 */     getContext().getAuthenticator().login(username, password, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void logout()
/*      */     throws ServletException
/*      */   {
/* 2813 */     getContext().getAuthenticator().logout(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<Part> getParts()
/*      */     throws IOException, IllegalStateException, ServletException
/*      */   {
/* 2823 */     parseParts(true);
/*      */     
/* 2825 */     if (this.partsParseException != null) {
/* 2826 */       if ((this.partsParseException instanceof IOException))
/* 2827 */         throw ((IOException)this.partsParseException);
/* 2828 */       if ((this.partsParseException instanceof IllegalStateException))
/* 2829 */         throw ((IllegalStateException)this.partsParseException);
/* 2830 */       if ((this.partsParseException instanceof ServletException)) {
/* 2831 */         throw ((ServletException)this.partsParseException);
/*      */       }
/*      */     }
/*      */     
/* 2835 */     return this.parts;
/*      */   }
/*      */   
/*      */ 
/*      */   private void parseParts(boolean explicit)
/*      */   {
/* 2841 */     if ((this.parts != null) || (this.partsParseException != null)) {
/* 2842 */       return;
/*      */     }
/*      */     
/* 2845 */     Context context = getContext();
/* 2846 */     MultipartConfigElement mce = getWrapper().getMultipartConfigElement();
/*      */     
/* 2848 */     if (mce == null) {
/* 2849 */       if (context.getAllowCasualMultipartParsing())
/*      */       {
/* 2851 */         mce = new MultipartConfigElement(null, this.connector.getMaxPostSize(), this.connector.getMaxPostSize(), this.connector.getMaxPostSize());
/*      */       } else {
/* 2853 */         if (explicit)
/*      */         {
/* 2855 */           this.partsParseException = new IllegalStateException(sm.getString("coyoteRequest.noMultipartConfig"));
/* 2856 */           return;
/*      */         }
/* 2858 */         this.parts = Collections.emptyList();
/* 2859 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2864 */     Parameters parameters = this.coyoteRequest.getParameters();
/* 2865 */     parameters.setLimit(getConnector().getMaxParameterCount());
/*      */     
/* 2867 */     boolean success = false;
/*      */     try
/*      */     {
/* 2870 */       String locationStr = mce.getLocation();
/* 2871 */       File location; File location; if ((locationStr == null) || (locationStr.length() == 0)) {
/* 2872 */         location = (File)context.getServletContext().getAttribute("javax.servlet.context.tempdir");
/*      */       }
/*      */       else
/*      */       {
/* 2876 */         location = new File(locationStr);
/* 2877 */         if (!location.isAbsolute())
/*      */         {
/*      */ 
/* 2880 */           location = new File((File)context.getServletContext().getAttribute("javax.servlet.context.tempdir"), locationStr).getAbsoluteFile();
/*      */         }
/*      */       }
/*      */       
/* 2884 */       if ((!location.exists()) && (context.getCreateUploadTargets())) {
/* 2885 */         log.warn(sm.getString("coyoteRequest.uploadCreate", new Object[] {location
/* 2886 */           .getAbsolutePath(), getMappingData().wrapper.getName() }));
/* 2887 */         if (!location.mkdirs()) {
/* 2888 */           log.warn(sm.getString("coyoteRequest.uploadCreateFail", new Object[] {location
/* 2889 */             .getAbsolutePath() }));
/*      */         }
/*      */       }
/*      */       
/* 2893 */       if (!location.isDirectory()) {
/* 2894 */         parameters.setParseFailedReason(Parameters.FailReason.MULTIPART_CONFIG_INVALID);
/*      */         
/* 2896 */         this.partsParseException = new IOException(sm.getString("coyoteRequest.uploadLocationInvalid", new Object[] { location }));
/*      */         
/* 2898 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2903 */       DiskFileItemFactory factory = new DiskFileItemFactory();
/*      */       try {
/* 2905 */         factory.setRepository(location.getCanonicalFile());
/*      */       } catch (IOException ioe) {
/* 2907 */         parameters.setParseFailedReason(Parameters.FailReason.IO_ERROR);
/* 2908 */         this.partsParseException = ioe;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2977 */         if ((this.partsParseException != null) || (!success)) {
/* 2978 */           parameters.setParseFailedReason(Parameters.FailReason.UNKNOWN);
/*      */         }
/* 2909 */         return;
/*      */       }
/* 2911 */       factory.setSizeThreshold(mce.getFileSizeThreshold());
/*      */       
/* 2913 */       ServletFileUpload upload = new ServletFileUpload();
/* 2914 */       upload.setFileItemFactory(factory);
/* 2915 */       upload.setFileSizeMax(mce.getMaxFileSize());
/* 2916 */       upload.setSizeMax(mce.getMaxRequestSize());
/*      */       
/* 2918 */       this.parts = new ArrayList();
/*      */       try
/*      */       {
/* 2921 */         List<FileItem> items = upload.parseRequest(new ServletRequestContext(this));
/* 2922 */         int maxPostSize = getConnector().getMaxPostSize();
/* 2923 */         int postSize = 0;
/* 2924 */         Charset charset = getCharset();
/* 2925 */         for (FileItem item : items) {
/* 2926 */           ApplicationPart part = new ApplicationPart(item, location);
/* 2927 */           this.parts.add(part);
/* 2928 */           if (part.getSubmittedFileName() == null) {
/* 2929 */             String name = part.getName();
/* 2930 */             if (maxPostSize >= 0)
/*      */             {
/*      */ 
/* 2933 */               postSize += name.getBytes(charset).length;
/*      */               
/* 2935 */               postSize++;
/*      */               
/* 2937 */               postSize = (int)(postSize + part.getSize());
/*      */               
/* 2939 */               postSize++;
/* 2940 */               if (postSize > maxPostSize) {
/* 2941 */                 parameters.setParseFailedReason(Parameters.FailReason.POST_TOO_LARGE);
/* 2942 */                 throw new IllegalStateException(sm.getString("coyoteRequest.maxPostSizeExceeded"));
/*      */               }
/*      */             }
/*      */             
/* 2946 */             String value = null;
/*      */             try {
/* 2948 */               value = part.getString(charset.name());
/*      */             }
/*      */             catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
/*      */             
/* 2952 */             parameters.addParameter(name, value);
/*      */           }
/*      */         }
/*      */         
/* 2956 */         success = true;
/*      */       } catch (InvalidContentTypeException e) {
/* 2958 */         parameters.setParseFailedReason(Parameters.FailReason.INVALID_CONTENT_TYPE);
/* 2959 */         this.partsParseException = new ServletException(e);
/*      */       } catch (SizeException e) {
/* 2961 */         parameters.setParseFailedReason(Parameters.FailReason.POST_TOO_LARGE);
/* 2962 */         checkSwallowInput();
/* 2963 */         this.partsParseException = new IllegalStateException(e);
/*      */       } catch (IOException e) {
/* 2965 */         parameters.setParseFailedReason(Parameters.FailReason.IO_ERROR);
/* 2966 */         this.partsParseException = new IOException(e);
/*      */       }
/*      */       catch (IllegalStateException e) {
/* 2969 */         checkSwallowInput();
/* 2970 */         this.partsParseException = e;
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/* 2977 */       if ((this.partsParseException != null) || (!success)) {
/* 2978 */         parameters.setParseFailedReason(Parameters.FailReason.UNKNOWN);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Part getPart(String name)
/*      */     throws IOException, IllegalStateException, ServletException
/*      */   {
/* 2990 */     for (Part part : getParts()) {
/* 2991 */       if (name.equals(part.getName())) {
/* 2992 */         return part;
/*      */       }
/*      */     }
/* 2995 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Session doGetSession(boolean create)
/*      */   {
/* 3004 */     Context context = getContext();
/* 3005 */     if (context == null) {
/* 3006 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 3010 */     if ((this.session != null) && (!this.session.isValid())) {
/* 3011 */       this.session = null;
/*      */     }
/* 3013 */     if (this.session != null) {
/* 3014 */       return this.session;
/*      */     }
/*      */     
/*      */ 
/* 3018 */     Manager manager = context.getManager();
/* 3019 */     if (manager == null) {
/* 3020 */       return null;
/*      */     }
/* 3022 */     if (this.requestedSessionId != null) {
/*      */       try {
/* 3024 */         this.session = manager.findSession(this.requestedSessionId);
/*      */       } catch (IOException e) {
/* 3026 */         if (log.isDebugEnabled()) {
/* 3027 */           log.debug(sm.getString("request.session.failed", new Object[] { this.requestedSessionId, e.getMessage() }), e);
/*      */         } else {
/* 3029 */           log.info(sm.getString("request.session.failed", new Object[] { this.requestedSessionId, e.getMessage() }));
/*      */         }
/* 3031 */         this.session = null;
/*      */       }
/* 3033 */       if ((this.session != null) && (!this.session.isValid())) {
/* 3034 */         this.session = null;
/*      */       }
/* 3036 */       if (this.session != null) {
/* 3037 */         this.session.access();
/* 3038 */         return this.session;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 3043 */     if (!create) {
/* 3044 */       return null;
/*      */     }
/*      */     
/* 3047 */     boolean trackModesIncludesCookie = context.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.COOKIE);
/* 3048 */     if ((trackModesIncludesCookie) && (this.response.getResponse().isCommitted())) {
/* 3049 */       throw new IllegalStateException(sm.getString("coyoteRequest.sessionCreateCommitted"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3054 */     String sessionId = getRequestedSessionId();
/* 3055 */     if (!this.requestedSessionSSL)
/*      */     {
/*      */ 
/* 3058 */       if (("/".equals(context.getSessionCookiePath())) && 
/* 3059 */         (isRequestedSessionIdFromCookie()))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3070 */         if (context.getValidateClientProvidedNewSessionId()) {
/* 3071 */           boolean found = false;
/* 3072 */           for (Container container : getHost().findChildren()) {
/* 3073 */             Manager m = ((Context)container).getManager();
/* 3074 */             if (m != null) {
/*      */               try {
/* 3076 */                 if (m.findSession(sessionId) != null) {
/* 3077 */                   found = true;
/* 3078 */                   break;
/*      */                 }
/*      */               }
/*      */               catch (IOException localIOException1) {}
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 3086 */           if (!found) {
/* 3087 */             sessionId = null;
/*      */           }
/*      */         }
/*      */       } else
/* 3091 */         sessionId = null;
/*      */     }
/* 3093 */     this.session = manager.createSession(sessionId);
/*      */     
/*      */ 
/* 3096 */     if ((this.session != null) && (trackModesIncludesCookie)) {
/* 3097 */       Cookie cookie = ApplicationSessionCookieConfig.createSessionCookie(context, this.session
/* 3098 */         .getIdInternal(), isSecure());
/*      */       
/* 3100 */       this.response.addSessionCookieInternal(cookie);
/*      */     }
/*      */     
/* 3103 */     if (this.session == null) {
/* 3104 */       return null;
/*      */     }
/*      */     
/* 3107 */     this.session.access();
/* 3108 */     return this.session;
/*      */   }
/*      */   
/*      */   protected String unescape(String s) {
/* 3112 */     if (s == null) {
/* 3113 */       return null;
/*      */     }
/* 3115 */     if (s.indexOf('\\') == -1) {
/* 3116 */       return s;
/*      */     }
/* 3118 */     StringBuilder buf = new StringBuilder();
/* 3119 */     for (int i = 0; i < s.length(); i++) {
/* 3120 */       char c = s.charAt(i);
/* 3121 */       if (c != '\\') {
/* 3122 */         buf.append(c);
/*      */       } else {
/* 3124 */         i++; if (i >= s.length()) {
/* 3125 */           throw new IllegalArgumentException();
/*      */         }
/* 3127 */         c = s.charAt(i);
/* 3128 */         buf.append(c);
/*      */       }
/*      */     }
/* 3131 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseCookies()
/*      */   {
/* 3139 */     if (this.cookiesParsed) {
/* 3140 */       return;
/*      */     }
/*      */     
/* 3143 */     this.cookiesParsed = true;
/*      */     
/* 3145 */     ServerCookies serverCookies = this.coyoteRequest.getCookies();
/* 3146 */     serverCookies.setLimit(this.connector.getMaxCookieCount());
/* 3147 */     CookieProcessor cookieProcessor = getContext().getCookieProcessor();
/* 3148 */     cookieProcessor.parseCookieHeader(this.coyoteRequest.getMimeHeaders(), serverCookies);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void convertCookies()
/*      */   {
/* 3156 */     if (this.cookiesConverted) {
/* 3157 */       return;
/*      */     }
/*      */     
/* 3160 */     this.cookiesConverted = true;
/*      */     
/* 3162 */     if (getContext() == null) {
/* 3163 */       return;
/*      */     }
/*      */     
/* 3166 */     parseCookies();
/*      */     
/* 3168 */     ServerCookies serverCookies = this.coyoteRequest.getCookies();
/* 3169 */     CookieProcessor cookieProcessor = getContext().getCookieProcessor();
/*      */     
/* 3171 */     int count = serverCookies.getCookieCount();
/* 3172 */     if (count <= 0) {
/* 3173 */       return;
/*      */     }
/*      */     
/* 3176 */     this.cookies = new Cookie[count];
/*      */     
/* 3178 */     int idx = 0;
/* 3179 */     for (int i = 0; i < count; i++) {
/* 3180 */       ServerCookie scookie = serverCookies.getCookie(i);
/*      */       try
/*      */       {
/* 3183 */         Cookie cookie = new Cookie(scookie.getName().toString(), null);
/* 3184 */         int version = scookie.getVersion();
/* 3185 */         cookie.setVersion(version);
/* 3186 */         scookie.getValue().getByteChunk().setCharset(cookieProcessor.getCharset());
/* 3187 */         cookie.setValue(unescape(scookie.getValue().toString()));
/* 3188 */         cookie.setPath(unescape(scookie.getPath().toString()));
/* 3189 */         String domain = scookie.getDomain().toString();
/* 3190 */         if (domain != null) {
/* 3191 */           cookie.setDomain(unescape(domain));
/*      */         }
/* 3193 */         String comment = scookie.getComment().toString();
/* 3194 */         cookie.setComment(version == 1 ? unescape(comment) : null);
/* 3195 */         this.cookies[(idx++)] = cookie;
/*      */       }
/*      */       catch (IllegalArgumentException localIllegalArgumentException) {}
/*      */     }
/*      */     
/* 3200 */     if (idx < count) {
/* 3201 */       Cookie[] ncookies = new Cookie[idx];
/* 3202 */       System.arraycopy(this.cookies, 0, ncookies, 0, idx);
/* 3203 */       this.cookies = ncookies;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseParameters()
/*      */   {
/* 3213 */     this.parametersParsed = true;
/*      */     
/* 3215 */     Parameters parameters = this.coyoteRequest.getParameters();
/* 3216 */     boolean success = false;
/*      */     try
/*      */     {
/* 3219 */       parameters.setLimit(getConnector().getMaxParameterCount());
/*      */       
/*      */ 
/*      */ 
/* 3223 */       Charset charset = getCharset();
/*      */       
/* 3225 */       boolean useBodyEncodingForURI = this.connector.getUseBodyEncodingForURI();
/* 3226 */       parameters.setCharset(charset);
/* 3227 */       if (useBodyEncodingForURI) {
/* 3228 */         parameters.setQueryStringCharset(charset);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3233 */       parameters.handleQueryParameters();
/*      */       
/* 3235 */       if ((this.usingInputStream) || (this.usingReader)) {
/* 3236 */         success = true;
/* 3237 */         return;
/*      */       }
/*      */       
/* 3240 */       String contentType = getContentType();
/* 3241 */       if (contentType == null) {
/* 3242 */         contentType = "";
/*      */       }
/* 3244 */       int semicolon = contentType.indexOf(';');
/* 3245 */       if (semicolon >= 0) {
/* 3246 */         contentType = contentType.substring(0, semicolon).trim();
/*      */       } else {
/* 3248 */         contentType = contentType.trim();
/*      */       }
/*      */       
/* 3251 */       if ("multipart/form-data".equals(contentType)) {
/* 3252 */         parseParts(false);
/* 3253 */         success = true;
/* 3254 */         return;
/*      */       }
/*      */       
/* 3257 */       if (!getConnector().isParseBodyMethod(getMethod())) {
/* 3258 */         success = true;
/* 3259 */         return;
/*      */       }
/*      */       
/* 3262 */       if (!"application/x-www-form-urlencoded".equals(contentType)) {
/* 3263 */         success = true;
/* 3264 */         return;
/*      */       }
/*      */       
/* 3267 */       int len = getContentLength();
/*      */       
/* 3269 */       if (len > 0) {
/* 3270 */         int maxPostSize = this.connector.getMaxPostSize();
/* 3271 */         if ((maxPostSize >= 0) && (len > maxPostSize)) {
/* 3272 */           Context context = getContext();
/* 3273 */           if ((context != null) && (context.getLogger().isDebugEnabled())) {
/* 3274 */             context.getLogger().debug(sm
/* 3275 */               .getString("coyoteRequest.postTooLarge"));
/*      */           }
/* 3277 */           checkSwallowInput();
/* 3278 */           parameters.setParseFailedReason(Parameters.FailReason.POST_TOO_LARGE);
/* 3279 */           return;
/*      */         }
/* 3281 */         byte[] formData = null;
/* 3282 */         if (len < 8192) {
/* 3283 */           if (this.postData == null) {
/* 3284 */             this.postData = new byte[' '];
/*      */           }
/* 3286 */           formData = this.postData;
/*      */         } else {
/* 3288 */           formData = new byte[len];
/*      */         }
/*      */         try {
/* 3291 */           if (readPostBody(formData, len) != len) {
/* 3292 */             parameters.setParseFailedReason(Parameters.FailReason.REQUEST_BODY_INCOMPLETE);
/* 3293 */             return;
/*      */           }
/*      */         }
/*      */         catch (IOException e) {
/* 3297 */           Context context = getContext();
/* 3298 */           if ((context != null) && (context.getLogger().isDebugEnabled())) {
/* 3299 */             context.getLogger().debug(sm
/* 3300 */               .getString("coyoteRequest.parseParameters"), e);
/*      */           }
/* 3302 */           parameters.setParseFailedReason(Parameters.FailReason.CLIENT_DISCONNECT);
/* 3303 */           return;
/*      */         }
/* 3305 */         parameters.processParameters(formData, 0, len);
/* 3306 */       } else if ("chunked".equalsIgnoreCase(this.coyoteRequest
/* 3307 */         .getHeader("transfer-encoding"))) {
/* 3308 */         byte[] formData = null;
/*      */         try {
/* 3310 */           formData = readChunkedPostBody();
/*      */         }
/*      */         catch (IllegalStateException ise) {
/* 3313 */           parameters.setParseFailedReason(Parameters.FailReason.POST_TOO_LARGE);
/* 3314 */           Context context = getContext();
/* 3315 */           if ((context != null) && (context.getLogger().isDebugEnabled())) {
/* 3316 */             context.getLogger().debug(sm
/* 3317 */               .getString("coyoteRequest.parseParameters"), ise);
/*      */           }
/*      */           
/* 3320 */           return;
/*      */         }
/*      */         catch (IOException e) {
/* 3323 */           parameters.setParseFailedReason(Parameters.FailReason.CLIENT_DISCONNECT);
/* 3324 */           Context context = getContext();
/* 3325 */           if ((context != null) && (context.getLogger().isDebugEnabled())) {
/* 3326 */             context.getLogger().debug(sm
/* 3327 */               .getString("coyoteRequest.parseParameters"), e);
/*      */           }
/* 3329 */           return;
/*      */         }
/* 3331 */         if (formData != null) {
/* 3332 */           parameters.processParameters(formData, 0, formData.length);
/*      */         }
/*      */       }
/* 3335 */       success = true;
/*      */     } finally {
/* 3337 */       if (!success) {
/* 3338 */         parameters.setParseFailedReason(Parameters.FailReason.UNKNOWN);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int readPostBody(byte[] body, int len)
/*      */     throws IOException
/*      */   {
/* 3356 */     int offset = 0;
/*      */     do {
/* 3358 */       int inputLen = getStream().read(body, offset, len - offset);
/* 3359 */       if (inputLen <= 0) {
/* 3360 */         return offset;
/*      */       }
/* 3362 */       offset += inputLen;
/* 3363 */     } while (len - offset > 0);
/* 3364 */     return len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] readChunkedPostBody()
/*      */     throws IOException
/*      */   {
/* 3376 */     ByteChunk body = new ByteChunk();
/*      */     
/* 3378 */     byte[] buffer = new byte[' '];
/*      */     
/* 3380 */     int len = 0;
/* 3381 */     while (len > -1) {
/* 3382 */       len = getStream().read(buffer, 0, 8192);
/* 3383 */       if ((this.connector.getMaxPostSize() >= 0) && 
/* 3384 */         (body.getLength() + len > this.connector.getMaxPostSize()))
/*      */       {
/* 3386 */         checkSwallowInput();
/*      */         
/* 3388 */         throw new IllegalStateException(sm.getString("coyoteRequest.chunkedPostTooLarge"));
/*      */       }
/* 3390 */       if (len > 0) {
/* 3391 */         body.append(buffer, 0, len);
/*      */       }
/*      */     }
/* 3394 */     if (body.getLength() == 0) {
/* 3395 */       return null;
/*      */     }
/* 3397 */     if (body.getLength() < body.getBuffer().length) {
/* 3398 */       int length = body.getLength();
/* 3399 */       byte[] result = new byte[length];
/* 3400 */       System.arraycopy(body.getBuffer(), 0, result, 0, length);
/* 3401 */       return result;
/*      */     }
/*      */     
/* 3404 */     return body.getBuffer();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseLocales()
/*      */   {
/* 3413 */     this.localesParsed = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3419 */     TreeMap<Double, ArrayList<Locale>> locales = new TreeMap();
/*      */     
/* 3421 */     Enumeration<String> values = getHeaders("accept-language");
/*      */     String value;
/* 3423 */     while (values.hasMoreElements()) {
/* 3424 */       value = (String)values.nextElement();
/* 3425 */       parseLocalesHeader(value, locales);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3430 */     for (ArrayList<Locale> list : locales.values()) {
/* 3431 */       for (Locale locale : list) {
/* 3432 */         addLocale(locale);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void parseLocalesHeader(String value, TreeMap<Double, ArrayList<Locale>> locales)
/*      */   {
/*      */     try
/*      */     {
/* 3448 */       acceptLanguages = AcceptLanguage.parse(new StringReader(value));
/*      */     }
/*      */     catch (IOException e) {
/*      */       List<AcceptLanguage> acceptLanguages;
/*      */       return;
/*      */     }
/*      */     List<AcceptLanguage> acceptLanguages;
/* 3455 */     for (AcceptLanguage acceptLanguage : acceptLanguages)
/*      */     {
/* 3457 */       Double key = Double.valueOf(-acceptLanguage.getQuality());
/* 3458 */       ArrayList<Locale> values = (ArrayList)locales.get(key);
/* 3459 */       if (values == null) {
/* 3460 */         values = new ArrayList();
/* 3461 */         locales.put(key, values);
/*      */       }
/* 3463 */       values.add(acceptLanguage.getLocale());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3479 */   private static final Map<String, SpecialAttributeAdapter> specialAttributes = new HashMap();
/*      */   
/*      */   static {
/* 3482 */     specialAttributes.put("org.apache.catalina.core.DISPATCHER_TYPE", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3486 */         return request.internalDispatcherType == null ? DispatcherType.REQUEST : request.internalDispatcherType;
/*      */       }
/*      */       
/*      */ 
/*      */       public void set(Request request, String name, Object value)
/*      */       {
/* 3492 */         request.internalDispatcherType = ((DispatcherType)value);
/*      */       }
/* 3494 */     });
/* 3495 */     specialAttributes.put("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3499 */         return request.requestDispatcherPath == null ? request
/* 3500 */           .getRequestPathMB().toString() : request.requestDispatcherPath
/* 3501 */           .toString();
/*      */       }
/*      */       
/*      */       public void set(Request request, String name, Object value)
/*      */       {
/* 3506 */         request.requestDispatcherPath = value;
/*      */       }
/* 3508 */     });
/* 3509 */     specialAttributes.put("org.apache.catalina.ASYNC_SUPPORTED", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3513 */         return request.asyncSupported;
/*      */       }
/*      */       
/*      */       public void set(Request request, String name, Object value)
/*      */       {
/* 3518 */         Boolean oldValue = request.asyncSupported;
/* 3519 */         request.asyncSupported = ((Boolean)value);
/* 3520 */         request.notifyAttributeAssigned(name, value, oldValue);
/*      */       }
/* 3522 */     });
/* 3523 */     specialAttributes.put("org.apache.catalina.realm.GSS_CREDENTIAL", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3527 */         if ((request.userPrincipal instanceof TomcatPrincipal)) {
/* 3528 */           return 
/* 3529 */             ((TomcatPrincipal)request.userPrincipal).getGssCredential();
/*      */         }
/* 3531 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void set(Request request, String name, Object value) {}
/* 3538 */     });
/* 3539 */     specialAttributes.put("org.apache.catalina.parameter_parse_failed", new SpecialAttributeAdapter()
/*      */     {
/*      */ 
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3544 */         if (request.getCoyoteRequest().getParameters().isParseFailed()) {
/* 3545 */           return Boolean.TRUE;
/*      */         }
/* 3547 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void set(Request request, String name, Object value) {}
/* 3554 */     });
/* 3555 */     specialAttributes.put("org.apache.catalina.parameter_parse_failed_reason", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3559 */         return request.getCoyoteRequest().getParameters().getParseFailedReason();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       public void set(Request request, String name, Object value) {}
/* 3566 */     });
/* 3567 */     specialAttributes.put("org.apache.tomcat.sendfile.support", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3571 */         return Boolean.valueOf(
/*      */         
/* 3573 */           (request.getConnector().getProtocolHandler().isSendfileSupported()) && (request.getCoyoteRequest().getSendfile()));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void set(Request request, String name, Object value) {}
/* 3579 */     });
/* 3580 */     specialAttributes.put("org.apache.coyote.connectionID", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3584 */         AtomicReference<Object> result = new AtomicReference();
/* 3585 */         request.getCoyoteRequest().action(ActionCode.CONNECTION_ID, result);
/* 3586 */         return result.get();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void set(Request request, String name, Object value) {}
/* 3592 */     });
/* 3593 */     specialAttributes.put("org.apache.coyote.streamID", new SpecialAttributeAdapter()
/*      */     {
/*      */       public Object get(Request request, String name)
/*      */       {
/* 3597 */         AtomicReference<Object> result = new AtomicReference();
/* 3598 */         request.getCoyoteRequest().action(ActionCode.STREAM_ID, result);
/* 3599 */         return result.get();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void set(Request request, String name, Object value) {}
/*      */     });
/*      */     
/* 3607 */     for (SimpleDateFormat sdf : formatsTemplate) {
/* 3608 */       sdf.setTimeZone(GMT_ZONE);
/*      */     }
/*      */   }
/*      */   
/*      */   private static abstract interface SpecialAttributeAdapter
/*      */   {
/*      */     public abstract Object get(Request paramRequest, String paramString);
/*      */     
/*      */     public abstract void set(Request paramRequest, String paramString, Object paramObject);
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\connector\Request.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */