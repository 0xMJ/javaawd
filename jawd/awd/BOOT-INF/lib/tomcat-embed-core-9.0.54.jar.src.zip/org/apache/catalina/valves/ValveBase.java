/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import org.apache.catalina.Contained;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.catalina.util.ToStringUtil;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ValveBase
/*     */   extends LifecycleMBeanBase
/*     */   implements Contained, Valve
/*     */ {
/*  41 */   protected static final StringManager sm = StringManager.getManager(ValveBase.class);
/*     */   
/*     */   protected boolean asyncSupported;
/*     */   
/*     */   public ValveBase()
/*     */   {
/*  47 */     this(false);
/*     */   }
/*     */   
/*     */   public ValveBase(boolean asyncSupported)
/*     */   {
/*  52 */     this.asyncSupported = asyncSupported;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   protected Container container = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   protected Log containerLog = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   protected Valve next = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Container getContainer()
/*     */   {
/*  89 */     return this.container;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContainer(Container container)
/*     */   {
/* 100 */     this.container = container;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAsyncSupported()
/*     */   {
/* 106 */     return this.asyncSupported;
/*     */   }
/*     */   
/*     */   public void setAsyncSupported(boolean asyncSupported)
/*     */   {
/* 111 */     this.asyncSupported = asyncSupported;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Valve getNext()
/*     */   {
/* 121 */     return this.next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNext(Valve valve)
/*     */   {
/* 132 */     this.next = valve;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void backgroundProcess() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 151 */     super.initInternal();
/* 152 */     this.containerLog = getContainer().getLogger();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 165 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 178 */     setState(LifecycleState.STOPPING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 187 */     return ToStringUtil.toString(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getObjectNameKeyProperties()
/*     */   {
/* 195 */     StringBuilder name = new StringBuilder("type=Valve");
/*     */     
/* 197 */     Container container = getContainer();
/*     */     
/* 199 */     name.append(container.getMBeanKeyProperties());
/*     */     
/* 201 */     int seq = 0;
/*     */     
/*     */ 
/* 204 */     Pipeline p = container.getPipeline();
/* 205 */     if (p != null) {
/* 206 */       for (Valve valve : p.getValves())
/*     */       {
/* 208 */         if (valve != null)
/*     */         {
/*     */ 
/*     */ 
/* 212 */           if (valve == this) {
/*     */             break;
/*     */           }
/* 215 */           if (valve.getClass() == getClass())
/*     */           {
/*     */ 
/* 218 */             seq++;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 223 */     if (seq > 0) {
/* 224 */       name.append(",seq=");
/* 225 */       name.append(seq);
/*     */     }
/*     */     
/* 228 */     String className = getClass().getName();
/* 229 */     int period = className.lastIndexOf('.');
/* 230 */     if (period >= 0) {
/* 231 */       className = className.substring(period + 1);
/*     */     }
/* 233 */     name.append(",name=");
/* 234 */     name.append(className);
/*     */     
/* 236 */     return name.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public String getDomainInternal()
/*     */   {
/* 242 */     Container c = getContainer();
/* 243 */     if (c == null) {
/* 244 */       return null;
/*     */     }
/* 246 */     return c.getDomain();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\ValveBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */