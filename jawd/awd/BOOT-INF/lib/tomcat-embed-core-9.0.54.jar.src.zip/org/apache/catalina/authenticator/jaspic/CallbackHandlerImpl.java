/*     */ package org.apache.catalina.authenticator.jaspic;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.callback.UnsupportedCallbackException;
/*     */ import javax.security.auth.message.callback.CallerPrincipalCallback;
/*     */ import javax.security.auth.message.callback.GroupPrincipalCallback;
/*     */ import javax.security.auth.message.callback.PasswordValidationCallback;
/*     */ import org.apache.catalina.Contained;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.realm.GenericPrincipal;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CallbackHandlerImpl
/*     */   implements CallbackHandler, Contained
/*     */ {
/*  45 */   private static final StringManager sm = StringManager.getManager(CallbackHandlerImpl.class);
/*  46 */   private final Log log = LogFactory.getLog(CallbackHandlerImpl.class);
/*     */   
/*     */   private Container container;
/*     */   
/*     */ 
/*     */   public void handle(Callback[] callbacks)
/*     */     throws IOException, UnsupportedCallbackException
/*     */   {
/*  54 */     String name = null;
/*  55 */     Principal principal = null;
/*  56 */     Subject subject = null;
/*  57 */     String[] groups = null;
/*     */     
/*  59 */     if (callbacks != null)
/*     */     {
/*     */ 
/*     */ 
/*  63 */       for (Callback callback : callbacks) {
/*  64 */         if ((callback instanceof CallerPrincipalCallback)) {
/*  65 */           CallerPrincipalCallback cpc = (CallerPrincipalCallback)callback;
/*  66 */           name = cpc.getName();
/*  67 */           principal = cpc.getPrincipal();
/*  68 */           subject = cpc.getSubject();
/*  69 */         } else if ((callback instanceof GroupPrincipalCallback)) {
/*  70 */           GroupPrincipalCallback gpc = (GroupPrincipalCallback)callback;
/*  71 */           groups = gpc.getGroups();
/*  72 */         } else if ((callback instanceof PasswordValidationCallback)) {
/*  73 */           if (this.container == null) {
/*  74 */             this.log.warn(sm.getString("callbackHandlerImpl.containerMissing", new Object[] { callback.getClass().getName() }));
/*  75 */           } else if (this.container.getRealm() == null) {
/*  76 */             this.log.warn(sm.getString("callbackHandlerImpl.realmMissing", new Object[] {callback
/*  77 */               .getClass().getName(), this.container.getName() }));
/*     */           } else {
/*  79 */             PasswordValidationCallback pvc = (PasswordValidationCallback)callback;
/*  80 */             principal = this.container.getRealm().authenticate(pvc.getUsername(), 
/*  81 */               String.valueOf(pvc.getPassword()));
/*  82 */             pvc.setResult(principal != null);
/*  83 */             subject = pvc.getSubject();
/*     */           }
/*     */         } else {
/*  86 */           this.log.error(sm.getString("callbackHandlerImpl.jaspicCallbackMissing", new Object[] {callback
/*  87 */             .getClass().getName() }));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*  92 */       Principal gp = getPrincipal(principal, name, groups);
/*  93 */       if ((subject != null) && (gp != null)) {
/*  94 */         subject.getPrivateCredentials().add(gp);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private Principal getPrincipal(Principal principal, String name, String[] groups)
/*     */   {
/* 102 */     if ((principal instanceof GenericPrincipal)) {
/* 103 */       return principal;
/*     */     }
/* 105 */     if ((name == null) && (principal != null)) {
/* 106 */       name = principal.getName();
/*     */     }
/* 108 */     if (name == null)
/* 109 */       return null;
/*     */     List<String> roles;
/*     */     List<String> roles;
/* 112 */     if ((groups == null) || (groups.length == 0)) {
/* 113 */       roles = Collections.emptyList();
/*     */     } else {
/* 115 */       roles = Arrays.asList(groups);
/*     */     }
/*     */     
/* 118 */     return new GenericPrincipal(name, null, roles, principal);
/*     */   }
/*     */   
/*     */ 
/*     */   public Container getContainer()
/*     */   {
/* 124 */     return this.container;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setContainer(Container container)
/*     */   {
/* 130 */     this.container = container;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\authenticator\jaspic\CallbackHandlerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */