/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IOTools
/*     */ {
/*     */   protected static final int DEFAULT_BUFFER_SIZE = 4096;
/*     */   
/*     */   public static void flow(Reader reader, Writer writer, char[] buf)
/*     */     throws IOException
/*     */   {
/*     */     int numRead;
/*  50 */     while ((numRead = reader.read(buf)) >= 0) {
/*  51 */       writer.write(buf, 0, numRead);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void flow(Reader reader, Writer writer)
/*     */     throws IOException
/*     */   {
/*  66 */     char[] buf = new char['က'];
/*  67 */     flow(reader, writer, buf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void flow(InputStream is, OutputStream os)
/*     */     throws IOException
/*     */   {
/*  82 */     byte[] buf = new byte['က'];
/*     */     int numRead;
/*  84 */     while ((numRead = is.read(buf)) >= 0) {
/*  85 */       if (os != null) {
/*  86 */         os.write(buf, 0, numRead);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int readFully(InputStream is, byte[] buf)
/*     */     throws IOException
/*     */   {
/* 103 */     int bytesRead = 0;
/*     */     int read;
/* 105 */     while ((bytesRead < buf.length) && ((read = is.read(buf, bytesRead, buf.length - bytesRead)) >= 0)) {
/* 106 */       bytesRead += read;
/*     */     }
/* 108 */     return bytesRead;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\IOTools.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */