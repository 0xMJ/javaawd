/*    */ package org.apache.catalina.mbeans;
/*    */ 
/*    */ import javax.management.Attribute;
/*    */ import javax.management.AttributeNotFoundException;
/*    */ import javax.management.MBeanException;
/*    */ import javax.management.ReflectionException;
/*    */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*    */ import org.apache.tomcat.util.descriptor.web.NamingResources;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContextEnvironmentMBean
/*    */   extends BaseCatalinaMBean<ContextEnvironment>
/*    */ {
/*    */   public void setAttribute(Attribute attribute)
/*    */     throws AttributeNotFoundException, MBeanException, ReflectionException
/*    */   {
/* 53 */     super.setAttribute(attribute);
/*    */     
/* 55 */     ContextEnvironment ce = (ContextEnvironment)doGetManagedResource();
/*    */     
/*    */ 
/*    */ 
/* 59 */     NamingResources nr = ce.getNamingResources();
/* 60 */     nr.removeEnvironment(ce.getName());
/* 61 */     nr.addEnvironment(ce);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\ContextEnvironmentMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */