/*     */ package org.apache.catalina.authenticator.jaspic;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PersistentProviderRegistrations
/*     */ {
/*  48 */   private static final Log log = LogFactory.getLog(PersistentProviderRegistrations.class);
/*     */   
/*  50 */   private static final StringManager sm = StringManager.getManager(PersistentProviderRegistrations.class);
/*     */   
/*     */   /* Error */
/*     */   static Providers loadProviders(File configFile)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 2	java/io/FileInputStream
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: invokespecial 3	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   8: astore_1
/*     */     //   9: aconst_null
/*     */     //   10: astore_2
/*     */     //   11: new 4	org/apache/tomcat/util/digester/Digester
/*     */     //   14: dup
/*     */     //   15: invokespecial 5	org/apache/tomcat/util/digester/Digester:<init>	()V
/*     */     //   18: astore_3
/*     */     //   19: aload_3
/*     */     //   20: ldc 6
/*     */     //   22: iconst_1
/*     */     //   23: invokevirtual 7	org/apache/tomcat/util/digester/Digester:setFeature	(Ljava/lang/String;Z)V
/*     */     //   26: goto +23 -> 49
/*     */     //   29: astore 4
/*     */     //   31: getstatic 9	org/apache/catalina/authenticator/jaspic/PersistentProviderRegistrations:log	Lorg/apache/juli/logging/Log;
/*     */     //   34: getstatic 10	org/apache/catalina/authenticator/jaspic/PersistentProviderRegistrations:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   37: ldc 11
/*     */     //   39: invokevirtual 12	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   42: aload 4
/*     */     //   44: invokeinterface 13 3 0
/*     */     //   49: aload_3
/*     */     //   50: iconst_1
/*     */     //   51: invokevirtual 14	org/apache/tomcat/util/digester/Digester:setValidating	(Z)V
/*     */     //   54: aload_3
/*     */     //   55: iconst_1
/*     */     //   56: invokevirtual 15	org/apache/tomcat/util/digester/Digester:setNamespaceAware	(Z)V
/*     */     //   59: new 16	org/apache/catalina/authenticator/jaspic/PersistentProviderRegistrations$Providers
/*     */     //   62: dup
/*     */     //   63: invokespecial 17	org/apache/catalina/authenticator/jaspic/PersistentProviderRegistrations$Providers:<init>	()V
/*     */     //   66: astore 4
/*     */     //   68: aload_3
/*     */     //   69: aload 4
/*     */     //   71: invokevirtual 18	org/apache/tomcat/util/digester/Digester:push	(Ljava/lang/Object;)V
/*     */     //   74: aload_3
/*     */     //   75: ldc 19
/*     */     //   77: ldc 20
/*     */     //   79: invokevirtual 21	java/lang/Class:getName	()Ljava/lang/String;
/*     */     //   82: invokevirtual 22	org/apache/tomcat/util/digester/Digester:addObjectCreate	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   85: aload_3
/*     */     //   86: ldc 19
/*     */     //   88: invokevirtual 23	org/apache/tomcat/util/digester/Digester:addSetProperties	(Ljava/lang/String;)V
/*     */     //   91: aload_3
/*     */     //   92: ldc 19
/*     */     //   94: ldc 24
/*     */     //   96: ldc 20
/*     */     //   98: invokevirtual 21	java/lang/Class:getName	()Ljava/lang/String;
/*     */     //   101: invokevirtual 25	org/apache/tomcat/util/digester/Digester:addSetNext	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   104: aload_3
/*     */     //   105: ldc 26
/*     */     //   107: ldc 27
/*     */     //   109: invokevirtual 21	java/lang/Class:getName	()Ljava/lang/String;
/*     */     //   112: invokevirtual 22	org/apache/tomcat/util/digester/Digester:addObjectCreate	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   115: aload_3
/*     */     //   116: ldc 26
/*     */     //   118: invokevirtual 23	org/apache/tomcat/util/digester/Digester:addSetProperties	(Ljava/lang/String;)V
/*     */     //   121: aload_3
/*     */     //   122: ldc 26
/*     */     //   124: ldc 28
/*     */     //   126: ldc 27
/*     */     //   128: invokevirtual 21	java/lang/Class:getName	()Ljava/lang/String;
/*     */     //   131: invokevirtual 25	org/apache/tomcat/util/digester/Digester:addSetNext	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   134: aload_3
/*     */     //   135: aload_1
/*     */     //   136: invokevirtual 29	org/apache/tomcat/util/digester/Digester:parse	(Ljava/io/InputStream;)Ljava/lang/Object;
/*     */     //   139: pop
/*     */     //   140: aload 4
/*     */     //   142: astore 5
/*     */     //   144: aload_1
/*     */     //   145: ifnull +29 -> 174
/*     */     //   148: aload_2
/*     */     //   149: ifnull +21 -> 170
/*     */     //   152: aload_1
/*     */     //   153: invokevirtual 30	java/io/InputStream:close	()V
/*     */     //   156: goto +18 -> 174
/*     */     //   159: astore 6
/*     */     //   161: aload_2
/*     */     //   162: aload 6
/*     */     //   164: invokevirtual 32	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   167: goto +7 -> 174
/*     */     //   170: aload_1
/*     */     //   171: invokevirtual 30	java/io/InputStream:close	()V
/*     */     //   174: aload 5
/*     */     //   176: areturn
/*     */     //   177: astore_3
/*     */     //   178: aload_3
/*     */     //   179: astore_2
/*     */     //   180: aload_3
/*     */     //   181: athrow
/*     */     //   182: astore 7
/*     */     //   184: aload_1
/*     */     //   185: ifnull +29 -> 214
/*     */     //   188: aload_2
/*     */     //   189: ifnull +21 -> 210
/*     */     //   192: aload_1
/*     */     //   193: invokevirtual 30	java/io/InputStream:close	()V
/*     */     //   196: goto +18 -> 214
/*     */     //   199: astore 8
/*     */     //   201: aload_2
/*     */     //   202: aload 8
/*     */     //   204: invokevirtual 32	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   207: goto +7 -> 214
/*     */     //   210: aload_1
/*     */     //   211: invokevirtual 30	java/io/InputStream:close	()V
/*     */     //   214: aload 7
/*     */     //   216: athrow
/*     */     //   217: astore_1
/*     */     //   218: new 35	java/lang/SecurityException
/*     */     //   221: dup
/*     */     //   222: aload_1
/*     */     //   223: invokespecial 36	java/lang/SecurityException:<init>	(Ljava/lang/Throwable;)V
/*     */     //   226: athrow
/*     */     // Line number table:
/*     */     //   Java source line #59	-> byte code offset #0
/*     */     //   Java source line #61	-> byte code offset #11
/*     */     //   Java source line #64	-> byte code offset #19
/*     */     //   Java source line #67	-> byte code offset #26
/*     */     //   Java source line #65	-> byte code offset #29
/*     */     //   Java source line #66	-> byte code offset #31
/*     */     //   Java source line #69	-> byte code offset #49
/*     */     //   Java source line #70	-> byte code offset #54
/*     */     //   Java source line #74	-> byte code offset #59
/*     */     //   Java source line #75	-> byte code offset #68
/*     */     //   Java source line #78	-> byte code offset #74
/*     */     //   Java source line #79	-> byte code offset #85
/*     */     //   Java source line #80	-> byte code offset #91
/*     */     //   Java source line #82	-> byte code offset #104
/*     */     //   Java source line #83	-> byte code offset #115
/*     */     //   Java source line #84	-> byte code offset #121
/*     */     //   Java source line #87	-> byte code offset #134
/*     */     //   Java source line #89	-> byte code offset #140
/*     */     //   Java source line #90	-> byte code offset #144
/*     */     //   Java source line #89	-> byte code offset #174
/*     */     //   Java source line #59	-> byte code offset #177
/*     */     //   Java source line #90	-> byte code offset #182
/*     */     //   Java source line #91	-> byte code offset #218
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	227	0	configFile	File
/*     */     //   8	203	1	is	java.io.InputStream
/*     */     //   217	6	1	e	Exception
/*     */     //   10	192	2	localThrowable3	Throwable
/*     */     //   18	117	3	digester	org.apache.tomcat.util.digester.Digester
/*     */     //   177	4	3	localThrowable1	Throwable
/*     */     //   29	14	4	se	org.xml.sax.SAXException
/*     */     //   66	75	4	result	Providers
/*     */     //   159	4	6	localThrowable	Throwable
/*     */     //   182	33	7	localObject	Object
/*     */     //   199	4	8	localThrowable2	Throwable
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   19	26	29	org/xml/sax/SAXException
/*     */     //   152	156	159	java/lang/Throwable
/*     */     //   11	144	177	java/lang/Throwable
/*     */     //   11	144	182	finally
/*     */     //   177	184	182	finally
/*     */     //   192	196	199	java/lang/Throwable
/*     */     //   0	174	217	java/io/IOException
/*     */     //   0	174	217	javax/xml/parsers/ParserConfigurationException
/*     */     //   0	174	217	org/xml/sax/SAXException
/*     */     //   177	217	217	java/io/IOException
/*     */     //   177	217	217	javax/xml/parsers/ParserConfigurationException
/*     */     //   177	217	217	org/xml/sax/SAXException
/*     */   }
/*     */   
/*     */   static void writeProviders(Providers providers, File configFile)
/*     */   {
/*  97 */     File configFileOld = new File(configFile.getAbsolutePath() + ".old");
/*  98 */     File configFileNew = new File(configFile.getAbsolutePath() + ".new");
/*     */     
/*     */ 
/* 101 */     if ((configFileOld.exists()) && 
/* 102 */       (configFileOld.delete())) {
/* 103 */       throw new SecurityException(sm.getString("persistentProviderRegistrations.existsDeleteFail", new Object[] {configFileOld
/*     */       
/* 105 */         .getAbsolutePath() }));
/*     */     }
/*     */     
/* 108 */     if ((configFileNew.exists()) && 
/* 109 */       (configFileNew.delete())) {
/* 110 */       throw new SecurityException(sm.getString("persistentProviderRegistrations.existsDeleteFail", new Object[] {configFileNew
/*     */       
/* 112 */         .getAbsolutePath() }));
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 117 */       OutputStream fos = new FileOutputStream(configFileNew);Throwable localThrowable6 = null;
/* 118 */       try { Writer writer = new OutputStreamWriter(fos, StandardCharsets.UTF_8);Throwable localThrowable7 = null;
/* 119 */         try { writer.write("<?xml version='1.0' encoding='utf-8'?>\n<jaspic-providers\n    xmlns=\"http://tomcat.apache.org/xml\"\n    xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n    xsi:schemaLocation=\"http://tomcat.apache.org/xml jaspic-providers.xsd\"\n    version=\"1.0\">\n");
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */           for (Provider provider : providers.providers) {
/* 127 */             writer.write("  <provider");
/* 128 */             writeOptional("className", provider.getClassName(), writer);
/* 129 */             writeOptional("layer", provider.getLayer(), writer);
/* 130 */             writeOptional("appContext", provider.getAppContext(), writer);
/* 131 */             writeOptional("description", provider.getDescription(), writer);
/* 132 */             writer.write(">\n");
/* 133 */             for (Map.Entry<String, String> entry : provider.getProperties().entrySet()) {
/* 134 */               writer.write("    <property name=\"");
/* 135 */               writer.write((String)entry.getKey());
/* 136 */               writer.write("\" value=\"");
/* 137 */               writer.write((String)entry.getValue());
/* 138 */               writer.write("\"/>\n");
/*     */             }
/* 140 */             writer.write("  </provider>\n");
/*     */           }
/* 142 */           writer.write("</jaspic-providers>\n");
/*     */         }
/*     */         catch (Throwable localThrowable9)
/*     */         {
/* 117 */           localThrowable7 = localThrowable9;throw localThrowable9; } finally {} } catch (Throwable localThrowable4) { localThrowable6 = localThrowable4;throw localThrowable4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */         if (fos != null) if (localThrowable6 != null) try { fos.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else fos.close();
/* 144 */       } } catch (IOException e) { if (!configFileNew.delete()) {
/* 145 */         Log log = LogFactory.getLog(PersistentProviderRegistrations.class);
/* 146 */         log.warn(sm.getString("persistentProviderRegistrations.deleteFail", new Object[] {configFileNew
/* 147 */           .getAbsolutePath() }));
/*     */       }
/* 149 */       throw new SecurityException(e);
/*     */     }
/*     */     
/*     */ 
/* 153 */     if ((configFile.isFile()) && 
/* 154 */       (!configFile.renameTo(configFileOld))) {
/* 155 */       throw new SecurityException(sm.getString("persistentProviderRegistrations.moveFail", new Object[] {configFile
/* 156 */         .getAbsolutePath(), configFileOld.getAbsolutePath() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 161 */     if (!configFileNew.renameTo(configFile)) {
/* 162 */       throw new SecurityException(sm.getString("persistentProviderRegistrations.moveFail", new Object[] {configFileNew
/* 163 */         .getAbsolutePath(), configFile.getAbsolutePath() }));
/*     */     }
/*     */     
/*     */ 
/* 167 */     if ((configFileOld.exists()) && (!configFileOld.delete())) {
/* 168 */       Log log = LogFactory.getLog(PersistentProviderRegistrations.class);
/* 169 */       log.warn(sm.getString("persistentProviderRegistrations.deleteFail", new Object[] {configFileOld
/* 170 */         .getAbsolutePath() }));
/*     */     }
/*     */   }
/*     */   
/*     */   private static void writeOptional(String name, String value, Writer writer) throws IOException
/*     */   {
/* 176 */     if (value != null) {
/* 177 */       writer.write(" " + name + "=\"");
/* 178 */       writer.write(value);
/* 179 */       writer.write("\"");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Providers
/*     */   {
/* 185 */     private final List<PersistentProviderRegistrations.Provider> providers = new ArrayList();
/*     */     
/*     */     public void addProvider(PersistentProviderRegistrations.Provider provider) {
/* 188 */       this.providers.add(provider);
/*     */     }
/*     */     
/*     */     public List<PersistentProviderRegistrations.Provider> getProviders() {
/* 192 */       return this.providers;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Provider
/*     */   {
/*     */     private String className;
/*     */     private String layer;
/*     */     private String appContext;
/*     */     private String description;
/* 202 */     private final Map<String, String> properties = new HashMap();
/*     */     
/*     */     public String getClassName()
/*     */     {
/* 206 */       return this.className;
/*     */     }
/*     */     
/* 209 */     public void setClassName(String className) { this.className = className; }
/*     */     
/*     */ 
/*     */     public String getLayer()
/*     */     {
/* 214 */       return this.layer;
/*     */     }
/*     */     
/* 217 */     public void setLayer(String layer) { this.layer = layer; }
/*     */     
/*     */ 
/*     */     public String getAppContext()
/*     */     {
/* 222 */       return this.appContext;
/*     */     }
/*     */     
/* 225 */     public void setAppContext(String appContext) { this.appContext = appContext; }
/*     */     
/*     */ 
/*     */     public String getDescription()
/*     */     {
/* 230 */       return this.description;
/*     */     }
/*     */     
/* 233 */     public void setDescription(String description) { this.description = description; }
/*     */     
/*     */ 
/*     */     public void addProperty(PersistentProviderRegistrations.Property property)
/*     */     {
/* 238 */       this.properties.put(property.getName(), property.getValue());
/*     */     }
/*     */     
/* 241 */     public void setProperty(String name, String value) { addProperty(name, value); }
/*     */     
/*     */     void addProperty(String name, String value) {
/* 244 */       this.properties.put(name, value);
/*     */     }
/*     */     
/* 247 */     public Map<String, String> getProperties() { return this.properties; }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class Property
/*     */   {
/*     */     private String name;
/*     */     private String value;
/*     */     
/*     */     public String getName()
/*     */     {
/* 258 */       return this.name;
/*     */     }
/*     */     
/* 261 */     public void setName(String name) { this.name = name; }
/*     */     
/*     */ 
/*     */     public String getValue()
/*     */     {
/* 266 */       return this.value;
/*     */     }
/*     */     
/* 269 */     public void setValue(String value) { this.value = value; }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\authenticator\jaspic\PersistentProviderRegistrations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */