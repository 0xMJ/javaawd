/*    */ package org.apache.catalina.startup;
/*    */ 
/*    */ import org.apache.tomcat.util.digester.Digester;
/*    */ import org.apache.tomcat.util.digester.Rule;
/*    */ import org.apache.tomcat.util.net.SSLHostConfig;
/*    */ import org.apache.tomcat.util.net.SSLHostConfigCertificate;
/*    */ import org.apache.tomcat.util.net.SSLHostConfigCertificate.Type;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CertificateCreateRule
/*    */   extends Rule
/*    */ {
/*    */   public void begin(String namespace, String name, Attributes attributes)
/*    */     throws Exception
/*    */   {
/* 32 */     SSLHostConfig sslHostConfig = (SSLHostConfig)this.digester.peek();
/*    */     
/*    */ 
/* 35 */     String typeValue = attributes.getValue("type");
/* 36 */     SSLHostConfigCertificate.Type type; SSLHostConfigCertificate.Type type; if ((typeValue == null) || (typeValue.length() == 0)) {
/* 37 */       type = SSLHostConfigCertificate.Type.UNDEFINED;
/*    */     } else {
/* 39 */       type = SSLHostConfigCertificate.Type.valueOf(typeValue);
/*    */     }
/*    */     
/* 42 */     SSLHostConfigCertificate certificate = new SSLHostConfigCertificate(sslHostConfig, type);
/*    */     
/* 44 */     this.digester.push(certificate);
/*    */     
/* 46 */     StringBuilder code = this.digester.getGeneratedCode();
/* 47 */     if (code != null) {
/* 48 */       code.append(SSLHostConfigCertificate.class.getName()).append(' ').append(this.digester.toVariableName(certificate));
/* 49 */       code.append(" = new ").append(SSLHostConfigCertificate.class.getName());
/* 50 */       code.append('(').append(this.digester.toVariableName(sslHostConfig));
/* 51 */       code.append(", ").append(SSLHostConfigCertificate.Type.class.getName().replace('$', '.')).append('.').append(type).append(");");
/* 52 */       code.append(System.lineSeparator());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void end(String namespace, String name)
/*    */     throws Exception
/*    */   {
/* 68 */     this.digester.pop();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\CertificateCreateRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */