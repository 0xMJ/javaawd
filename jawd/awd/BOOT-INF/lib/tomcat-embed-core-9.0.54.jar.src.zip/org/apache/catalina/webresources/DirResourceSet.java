/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import java.util.Set;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.WebResourceRoot.ResourceSetType;
/*     */ import org.apache.catalina.util.ResourceSet;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DirResourceSet
/*     */   extends AbstractFileResourceSet
/*     */ {
/*  41 */   private static final Log log = LogFactory.getLog(DirResourceSet.class);
/*     */   
/*     */ 
/*     */ 
/*     */   public DirResourceSet()
/*     */   {
/*  47 */     super("/");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DirResourceSet(WebResourceRoot root, String webAppMount, String base, String internalPath)
/*     */   {
/*  70 */     super(internalPath);
/*  71 */     setRoot(root);
/*  72 */     setWebAppMount(webAppMount);
/*  73 */     setBase(base);
/*     */     
/*  75 */     if (root.getContext().getAddWebinfClassesResources()) {
/*  76 */       File f = new File(base, internalPath);
/*  77 */       f = new File(f, "/WEB-INF/classes/META-INF/resources");
/*     */       
/*  79 */       if (f.isDirectory()) {
/*  80 */         root.createWebResourceSet(WebResourceRoot.ResourceSetType.RESOURCE_JAR, "/", f
/*  81 */           .getAbsolutePath(), null, "/");
/*     */       }
/*     */     }
/*     */     
/*  85 */     if (getRoot().getState().isAvailable()) {
/*     */       try {
/*  87 */         start();
/*     */       } catch (LifecycleException e) {
/*  89 */         throw new IllegalStateException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public WebResource getResource(String path)
/*     */   {
/*  97 */     checkPath(path);
/*  98 */     String webAppMount = getWebAppMount();
/*  99 */     WebResourceRoot root = getRoot();
/* 100 */     if (path.startsWith(webAppMount)) {
/* 101 */       File f = file(path.substring(webAppMount.length()), false);
/* 102 */       if (f == null) {
/* 103 */         return new EmptyResource(root, path);
/*     */       }
/* 105 */       if (!f.exists()) {
/* 106 */         return new EmptyResource(root, path, f);
/*     */       }
/* 108 */       if ((f.isDirectory()) && (path.charAt(path.length() - 1) != '/')) {
/* 109 */         path = path + '/';
/*     */       }
/* 111 */       return new FileResource(root, path, f, isReadOnly(), getManifest());
/*     */     }
/* 113 */     return new EmptyResource(root, path);
/*     */   }
/*     */   
/*     */ 
/*     */   public String[] list(String path)
/*     */   {
/* 119 */     checkPath(path);
/* 120 */     String webAppMount = getWebAppMount();
/* 121 */     if (path.startsWith(webAppMount)) {
/* 122 */       File f = file(path.substring(webAppMount.length()), true);
/* 123 */       if (f == null) {
/* 124 */         return EMPTY_STRING_ARRAY;
/*     */       }
/* 126 */       String[] result = f.list();
/* 127 */       if (result == null) {
/* 128 */         return EMPTY_STRING_ARRAY;
/*     */       }
/* 130 */       return result;
/*     */     }
/*     */     
/* 133 */     if (!path.endsWith("/")) {
/* 134 */       path = path + "/";
/*     */     }
/* 136 */     if (webAppMount.startsWith(path)) {
/* 137 */       int i = webAppMount.indexOf('/', path.length());
/* 138 */       if (i == -1) {
/* 139 */         return new String[] { webAppMount.substring(path.length()) };
/*     */       }
/* 141 */       return new String[] {webAppMount
/* 142 */         .substring(path.length(), i) };
/*     */     }
/*     */     
/* 145 */     return EMPTY_STRING_ARRAY;
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<String> listWebAppPaths(String path)
/*     */   {
/* 151 */     checkPath(path);
/* 152 */     String webAppMount = getWebAppMount();
/* 153 */     ResourceSet<String> result = new ResourceSet();
/* 154 */     if (path.startsWith(webAppMount)) {
/* 155 */       File f = file(path.substring(webAppMount.length()), true);
/* 156 */       if (f != null) {
/* 157 */         File[] list = f.listFiles();
/* 158 */         if (list != null) {
/* 159 */           for (File entry : list)
/*     */           {
/*     */ 
/* 162 */             if (!getRoot().getAllowLinking())
/*     */             {
/*     */ 
/* 165 */               boolean symlink = true;
/* 166 */               String absPath = null;
/* 167 */               String canPath = null;
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */               try
/*     */               {
/* 174 */                 absPath = entry.getAbsolutePath().substring(f.getAbsolutePath().length());
/* 175 */                 if (entry.getCanonicalPath().length() >= f.getCanonicalPath().length()) {
/* 176 */                   canPath = entry.getCanonicalPath().substring(f.getCanonicalPath().length());
/* 177 */                   if (absPath.equals(canPath)) {
/* 178 */                     symlink = false;
/*     */                   }
/*     */                 }
/*     */               }
/*     */               catch (IOException ioe) {
/* 183 */                 canPath = "Unknown";
/*     */               }
/* 185 */               if (symlink) {
/* 186 */                 logIgnoredSymlink(getRoot().getContext().getName(), absPath, canPath);
/* 187 */                 continue;
/*     */               }
/*     */             }
/* 190 */             StringBuilder sb = new StringBuilder(path);
/* 191 */             if (path.charAt(path.length() - 1) != '/') {
/* 192 */               sb.append('/');
/*     */             }
/* 194 */             sb.append(entry.getName());
/* 195 */             if (entry.isDirectory()) {
/* 196 */               sb.append('/');
/*     */             }
/* 198 */             result.add(sb.toString());
/*     */           }
/*     */         }
/*     */       }
/*     */     } else {
/* 203 */       if (!path.endsWith("/")) {
/* 204 */         path = path + "/";
/*     */       }
/* 206 */       if (webAppMount.startsWith(path)) {
/* 207 */         int i = webAppMount.indexOf('/', path.length());
/* 208 */         if (i == -1) {
/* 209 */           result.add(webAppMount + "/");
/*     */         } else {
/* 211 */           result.add(webAppMount.substring(0, i + 1));
/*     */         }
/*     */       }
/*     */     }
/* 215 */     result.setLocked(true);
/* 216 */     return result;
/*     */   }
/*     */   
/*     */   public boolean mkdir(String path)
/*     */   {
/* 221 */     checkPath(path);
/* 222 */     if (isReadOnly()) {
/* 223 */       return false;
/*     */     }
/* 225 */     String webAppMount = getWebAppMount();
/* 226 */     if (path.startsWith(webAppMount)) {
/* 227 */       File f = file(path.substring(webAppMount.length()), false);
/* 228 */       if (f == null) {
/* 229 */         return false;
/*     */       }
/* 231 */       return f.mkdir();
/*     */     }
/* 233 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean write(String path, InputStream is, boolean overwrite)
/*     */   {
/* 239 */     checkPath(path);
/*     */     
/* 241 */     if (is == null)
/*     */     {
/* 243 */       throw new NullPointerException(sm.getString("dirResourceSet.writeNpe"));
/*     */     }
/*     */     
/* 246 */     if (isReadOnly()) {
/* 247 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 252 */     if (path.endsWith("/")) {
/* 253 */       return false;
/*     */     }
/*     */     
/* 256 */     File dest = null;
/* 257 */     String webAppMount = getWebAppMount();
/* 258 */     if (path.startsWith(webAppMount)) {
/* 259 */       dest = file(path.substring(webAppMount.length()), false);
/* 260 */       if (dest == null) {
/* 261 */         return false;
/*     */       }
/*     */     } else {
/* 264 */       return false;
/*     */     }
/*     */     
/* 267 */     if ((dest.exists()) && (!overwrite)) {
/* 268 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 272 */       if (overwrite) {
/* 273 */         Files.copy(is, dest.toPath(), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*     */       } else {
/* 275 */         Files.copy(is, dest.toPath(), new CopyOption[0]);
/*     */       }
/*     */     } catch (IOException ioe) {
/* 278 */       return false;
/*     */     }
/*     */     
/* 281 */     return true;
/*     */   }
/*     */   
/*     */   protected void checkType(File file)
/*     */   {
/* 286 */     if (!file.isDirectory()) {
/* 287 */       throw new IllegalArgumentException(sm.getString("dirResourceSet.notDirectory", new Object[] {
/* 288 */         getBase(), File.separator, getInternalPath() }));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 295 */     super.initInternal();
/*     */     
/* 297 */     if (getWebAppMount().equals(""))
/*     */     {
/* 299 */       File mf = file("META-INF/MANIFEST.MF", true);
/* 300 */       if ((mf != null) && (mf.isFile())) {
/* 301 */         try { FileInputStream fis = new FileInputStream(mf);Throwable localThrowable3 = null;
/* 302 */           try { setManifest(new Manifest(fis));
/*     */           }
/*     */           catch (Throwable localThrowable1)
/*     */           {
/* 301 */             localThrowable3 = localThrowable1;throw localThrowable1;
/*     */           } finally {
/* 303 */             if (fis != null) if (localThrowable3 != null) try { fis.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else fis.close();
/* 304 */           } } catch (IOException e) { log.warn(sm.getString("dirResourceSet.manifestFail", new Object[] { mf.getAbsolutePath() }), e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\webresources\DirResourceSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */