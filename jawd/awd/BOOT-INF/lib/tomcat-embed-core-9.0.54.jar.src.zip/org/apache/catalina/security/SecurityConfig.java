/*     */ package org.apache.catalina.security;
/*     */ 
/*     */ import java.security.Security;
/*     */ import org.apache.catalina.startup.CatalinaProperties;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecurityConfig
/*     */ {
/*  32 */   private static final Object singletonLock = new Object();
/*  33 */   private static volatile SecurityConfig singleton = null;
/*     */   
/*  35 */   private static final Log log = LogFactory.getLog(SecurityConfig.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String PACKAGE_ACCESS = "sun.,org.apache.catalina.,org.apache.jasper.,org.apache.coyote.,org.apache.tomcat.";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String PACKAGE_DEFINITION = "java.,sun.,org.apache.catalina.,org.apache.coyote.,org.apache.tomcat.,org.apache.jasper.";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String packageDefinition;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String packageAccess;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SecurityConfig()
/*     */   {
/*  67 */     String definition = null;
/*  68 */     String access = null;
/*     */     try {
/*  70 */       definition = CatalinaProperties.getProperty("package.definition");
/*  71 */       access = CatalinaProperties.getProperty("package.access");
/*     */     } catch (Exception ex) {
/*  73 */       if (log.isDebugEnabled()) {
/*  74 */         log.debug("Unable to load properties using CatalinaProperties", ex);
/*     */       }
/*     */     } finally {
/*  77 */       this.packageDefinition = definition;
/*  78 */       this.packageAccess = access;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SecurityConfig newInstance()
/*     */   {
/*  88 */     if (singleton == null) {
/*  89 */       synchronized (singletonLock) {
/*  90 */         if (singleton == null) {
/*  91 */           singleton = new SecurityConfig();
/*     */         }
/*     */       }
/*     */     }
/*  95 */     return singleton;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPackageAccess()
/*     */   {
/* 104 */     if (this.packageAccess == null) {
/* 105 */       setSecurityProperty("package.access", "sun.,org.apache.catalina.,org.apache.jasper.,org.apache.coyote.,org.apache.tomcat.");
/*     */     } else {
/* 107 */       setSecurityProperty("package.access", this.packageAccess);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPackageDefinition()
/*     */   {
/* 117 */     if (this.packageDefinition == null) {
/* 118 */       setSecurityProperty("package.definition", "java.,sun.,org.apache.catalina.,org.apache.coyote.,org.apache.tomcat.,org.apache.jasper.");
/*     */     } else {
/* 120 */       setSecurityProperty("package.definition", this.packageDefinition);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final void setSecurityProperty(String properties, String packageList)
/*     */   {
/* 130 */     if (System.getSecurityManager() != null) {
/* 131 */       String definition = Security.getProperty(properties);
/* 132 */       if ((definition != null) && (definition.length() > 0)) {
/* 133 */         if (packageList.length() > 0) {
/* 134 */           definition = definition + ',' + packageList;
/*     */         }
/*     */       } else {
/* 137 */         definition = packageList;
/*     */       }
/*     */       
/* 140 */       Security.setProperty(properties, definition);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\security\SecurityConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */