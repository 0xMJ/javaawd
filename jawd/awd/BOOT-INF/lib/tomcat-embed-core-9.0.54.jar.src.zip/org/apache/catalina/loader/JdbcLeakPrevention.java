/*    */ package org.apache.catalina.loader;
/*    */ 
/*    */ import java.sql.Driver;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.SQLException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Enumeration;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdbcLeakPrevention
/*    */ {
/*    */   public List<String> clearJdbcDriverRegistrations()
/*    */     throws SQLException
/*    */   {
/* 43 */     List<String> driverNames = new ArrayList();
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 54 */     Set<Driver> originalDrivers = new HashSet();
/* 55 */     Enumeration<Driver> drivers = DriverManager.getDrivers();
/* 56 */     while (drivers.hasMoreElements()) {
/* 57 */       originalDrivers.add(drivers.nextElement());
/*    */     }
/* 59 */     drivers = DriverManager.getDrivers();
/* 60 */     while (drivers.hasMoreElements()) {
/* 61 */       Driver driver = (Driver)drivers.nextElement();
/*    */       
/*    */ 
/* 64 */       if (driver.getClass().getClassLoader() == getClass().getClassLoader())
/*    */       {
/*    */ 
/*    */ 
/*    */ 
/* 69 */         if (originalDrivers.contains(driver)) {
/* 70 */           driverNames.add(driver.getClass().getCanonicalName());
/*    */         }
/* 72 */         DriverManager.deregisterDriver(driver);
/*    */       } }
/* 74 */     return driverNames;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\loader\JdbcLeakPrevention.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */