/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EngineConfig
/*     */   implements LifecycleListener
/*     */ {
/*  39 */   private static final Log log = LogFactory.getLog(EngineConfig.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */   protected Engine engine = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  54 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void lifecycleEvent(LifecycleEvent event)
/*     */   {
/*     */     try
/*     */     {
/*  70 */       this.engine = ((Engine)event.getLifecycle());
/*     */     } catch (ClassCastException e) {
/*  72 */       log.error(sm.getString("engineConfig.cce", new Object[] { event.getLifecycle() }), e);
/*  73 */       return;
/*     */     }
/*     */     
/*     */ 
/*  77 */     if (event.getType().equals("start")) {
/*  78 */       start();
/*  79 */     } else if (event.getType().equals("stop")) {
/*  80 */       stop();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void start()
/*     */   {
/*  94 */     if (this.engine.getLogger().isDebugEnabled()) {
/*  95 */       this.engine.getLogger().debug(sm.getString("engineConfig.start"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stop()
/*     */   {
/* 106 */     if (this.engine.getLogger().isDebugEnabled()) {
/* 107 */       this.engine.getLogger().debug(sm.getString("engineConfig.stop"));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\EngineConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */