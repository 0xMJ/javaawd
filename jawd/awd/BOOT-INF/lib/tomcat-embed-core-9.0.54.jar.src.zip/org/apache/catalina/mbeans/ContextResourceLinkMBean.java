/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResourceLink;
/*     */ import org.apache.tomcat.util.descriptor.web.NamingResources;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextResourceLinkMBean
/*     */   extends BaseCatalinaMBean<ContextResourceLink>
/*     */ {
/*  37 */   private static final StringManager sm = StringManager.getManager(ContextResourceLinkMBean.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getAttribute(String name)
/*     */     throws AttributeNotFoundException, MBeanException, ReflectionException
/*     */   {
/*  56 */     if (name == null)
/*     */     {
/*     */ 
/*  59 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullName")), sm.getString("mBean.nullName"));
/*     */     }
/*     */     
/*  62 */     ContextResourceLink cl = (ContextResourceLink)doGetManagedResource();
/*     */     
/*  64 */     String value = null;
/*  65 */     if ("global".equals(name))
/*  66 */       return cl.getGlobal();
/*  67 */     if ("description".equals(name))
/*  68 */       return cl.getDescription();
/*  69 */     if ("name".equals(name))
/*  70 */       return cl.getName();
/*  71 */     if ("type".equals(name)) {
/*  72 */       return cl.getType();
/*     */     }
/*  74 */     value = (String)cl.getProperty(name);
/*  75 */     if (value == null) {
/*  76 */       throw new AttributeNotFoundException(sm.getString("mBean.attributeNotFound", new Object[] { name }));
/*     */     }
/*     */     
/*     */ 
/*  80 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttribute(Attribute attribute)
/*     */     throws AttributeNotFoundException, MBeanException, ReflectionException
/*     */   {
/* 102 */     if (attribute == null)
/*     */     {
/*     */ 
/* 105 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullAttribute")), sm.getString("mBean.nullAttribute"));
/*     */     }
/*     */     
/* 108 */     String name = attribute.getName();
/* 109 */     Object value = attribute.getValue();
/* 110 */     if (name == null)
/*     */     {
/*     */ 
/* 113 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullName")), sm.getString("mBean.nullName"));
/*     */     }
/*     */     
/* 116 */     ContextResourceLink crl = (ContextResourceLink)doGetManagedResource();
/*     */     
/* 118 */     if ("global".equals(name)) {
/* 119 */       crl.setGlobal((String)value);
/* 120 */     } else if ("description".equals(name)) {
/* 121 */       crl.setDescription((String)value);
/* 122 */     } else if ("name".equals(name)) {
/* 123 */       crl.setName((String)value);
/* 124 */     } else if ("type".equals(name)) {
/* 125 */       crl.setType((String)value);
/*     */     } else {
/* 127 */       crl.setProperty(name, "" + value);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 132 */     NamingResources nr = crl.getNamingResources();
/* 133 */     nr.removeResourceLink(crl.getName());
/* 134 */     nr.addResourceLink(crl);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\ContextResourceLinkMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */