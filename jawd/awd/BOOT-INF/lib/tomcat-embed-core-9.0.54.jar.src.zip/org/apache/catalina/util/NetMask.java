/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NetMask
/*     */ {
/*  54 */   private static final StringManager sm = StringManager.getManager(NetMask.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String expression;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final byte[] netaddr;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int nrBytes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int lastByteShift;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean foundPort;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Pattern portPattern;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NetMask(String input)
/*     */   {
/*  97 */     this.expression = input;
/*     */     
/*  99 */     int portIdx = input.indexOf(';');
/*     */     
/*     */     String nonPortPart;
/* 102 */     if (portIdx == -1) {
/* 103 */       this.foundPort = false;
/* 104 */       String nonPortPart = input;
/* 105 */       this.portPattern = null;
/*     */     } else {
/* 107 */       this.foundPort = true;
/* 108 */       nonPortPart = input.substring(0, portIdx);
/*     */       try {
/* 110 */         this.portPattern = Pattern.compile(input.substring(portIdx + 1));
/*     */ 
/*     */       }
/*     */       catch (PatternSyntaxException e)
/*     */       {
/* 115 */         throw new IllegalArgumentException(sm.getString("netmask.invalidPort", new Object[] { input }), e);
/*     */       }
/*     */     }
/*     */     
/* 119 */     int idx = nonPortPart.indexOf('/');
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 124 */     if (idx == -1) {
/*     */       try {
/* 126 */         this.netaddr = InetAddress.getByName(nonPortPart).getAddress();
/*     */       } catch (UnknownHostException e) {
/* 128 */         throw new IllegalArgumentException(sm.getString("netmask.invalidAddress", new Object[] { nonPortPart }));
/*     */       }
/* 130 */       this.nrBytes = this.netaddr.length;
/* 131 */       this.lastByteShift = 0;
/* 132 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 140 */     String addressPart = nonPortPart.substring(0, idx);String cidrPart = nonPortPart.substring(idx + 1);
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 146 */       this.netaddr = InetAddress.getByName(addressPart).getAddress();
/*     */     } catch (UnknownHostException e) {
/* 148 */       throw new IllegalArgumentException(sm.getString("netmask.invalidAddress", new Object[] { addressPart }));
/*     */     }
/*     */     
/* 151 */     int addrlen = this.netaddr.length * 8;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 158 */       cidr = Integer.parseInt(cidrPart);
/*     */     } catch (NumberFormatException e) { int cidr;
/* 160 */       throw new IllegalArgumentException(sm.getString("netmask.cidrNotNumeric", new Object[] { cidrPart }));
/*     */     }
/*     */     
/*     */ 
/*     */     int cidr;
/*     */     
/*     */ 
/* 167 */     if (cidr < 0) {
/* 168 */       throw new IllegalArgumentException(sm.getString("netmask.cidrNegative", new Object[] { cidrPart }));
/*     */     }
/* 170 */     if (cidr > addrlen)
/*     */     {
/* 172 */       throw new IllegalArgumentException(sm.getString("netmask.cidrTooBig", new Object[] { cidrPart, Integer.valueOf(addrlen) }));
/*     */     }
/*     */     
/* 175 */     this.nrBytes = (cidr / 8);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 186 */     int remainder = cidr % 8;
/*     */     
/* 188 */     this.lastByteShift = (remainder == 0 ? 0 : 8 - remainder);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(InetAddress addr, int port)
/*     */   {
/* 200 */     if (!this.foundPort) {
/* 201 */       return false;
/*     */     }
/* 203 */     String portString = Integer.toString(port);
/* 204 */     if (!this.portPattern.matcher(portString).matches()) {
/* 205 */       return false;
/*     */     }
/* 207 */     return matches(addr, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(InetAddress addr)
/*     */   {
/* 218 */     return matches(addr, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(InetAddress addr, boolean checkedPort)
/*     */   {
/* 230 */     if ((!checkedPort) && (this.foundPort)) {
/* 231 */       return false;
/*     */     }
/* 233 */     byte[] candidate = addr.getAddress();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 253 */     if (candidate.length != this.netaddr.length) {
/* 254 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 267 */     for (int i = 0; 
/* 268 */         i < this.nrBytes; i++) {
/* 269 */       if (this.netaddr[i] != candidate[i]) {
/* 270 */         return false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 278 */     if (this.lastByteShift == 0) {
/* 279 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 294 */     int lastByte = this.netaddr[i] ^ candidate[i];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 299 */     return lastByte >> this.lastByteShift == 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 305 */     return this.expression;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\NetMask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */