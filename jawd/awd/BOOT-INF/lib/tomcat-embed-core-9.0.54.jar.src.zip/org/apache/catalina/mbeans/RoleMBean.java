/*    */ package org.apache.catalina.mbeans;
/*    */ 
/*    */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*    */ import org.apache.tomcat.util.modeler.ManagedBean;
/*    */ import org.apache.tomcat.util.modeler.Registry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleMBean
/*    */   extends BaseModelMBean
/*    */ {
/* 36 */   protected final Registry registry = MBeanUtils.createRegistry();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 42 */   protected final ManagedBean managed = this.registry.findManagedBean("Role");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\RoleMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */