/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletRequestWrapper;
/*     */ import javax.servlet.http.HttpServletMapping;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.PushBuilder;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.catalina.connector.RequestFacade;
/*     */ import org.apache.catalina.util.ParameterMap;
/*     */ import org.apache.catalina.util.RequestUtil;
/*     */ import org.apache.catalina.util.URLEncoder;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.http.Parameters;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ApplicationHttpRequest
/*     */   extends HttpServletRequestWrapper
/*     */ {
/*  74 */   private static final StringManager sm = StringManager.getManager(ApplicationHttpRequest.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  79 */   protected static final String[] specials = { "javax.servlet.include.request_uri", "javax.servlet.include.context_path", "javax.servlet.include.servlet_path", "javax.servlet.include.path_info", "javax.servlet.include.query_string", "javax.servlet.include.mapping", "javax.servlet.forward.request_uri", "javax.servlet.forward.context_path", "javax.servlet.forward.servlet_path", "javax.servlet.forward.path_info", "javax.servlet.forward.query_string", "javax.servlet.forward.mapping" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int SPECIALS_FIRST_FORWARD_INDEX = 6;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Context context;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ApplicationHttpRequest(HttpServletRequest request, Context context, boolean crossContext)
/*     */   {
/* 110 */     super(request);
/* 111 */     this.context = context;
/* 112 */     this.crossContext = crossContext;
/* 113 */     setRequest(request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 130 */   protected String contextPath = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final boolean crossContext;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */   protected DispatcherType dispatcherType = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 150 */   protected Map<String, String[]> parameters = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */   private boolean parsedParams = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 162 */   protected String pathInfo = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */   private String queryParamString = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 174 */   protected String queryString = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 180 */   protected Object requestDispatcherPath = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 186 */   protected String requestURI = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */   protected String servletPath = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 198 */   private HttpServletMapping mapping = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 204 */   protected Session session = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */   protected final Object[] specialAttributes = new Object[specials.length];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletContext getServletContext()
/*     */   {
/* 217 */     if (this.context == null) {
/* 218 */       return null;
/*     */     }
/* 220 */     return this.context.getServletContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getAttribute(String name)
/*     */   {
/* 232 */     if (name.equals("org.apache.catalina.core.DISPATCHER_TYPE"))
/* 233 */       return this.dispatcherType;
/* 234 */     if (name.equals("org.apache.catalina.core.DISPATCHER_REQUEST_PATH")) {
/* 235 */       if (this.requestDispatcherPath != null) {
/* 236 */         return this.requestDispatcherPath.toString();
/*     */       }
/* 238 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 242 */     int pos = getSpecial(name);
/* 243 */     if (pos == -1) {
/* 244 */       return getRequest().getAttribute(name);
/*     */     }
/* 246 */     if ((this.specialAttributes[pos] == null) && (this.specialAttributes[6] == null) && (pos >= 6))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 252 */       return getRequest().getAttribute(name);
/*     */     }
/* 254 */     return this.specialAttributes[pos];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getAttributeNames()
/*     */   {
/* 267 */     return new AttributeNamesEnumerator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeAttribute(String name)
/*     */   {
/* 280 */     if (!removeSpecial(name)) {
/* 281 */       getRequest().removeAttribute(name);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttribute(String name, Object value)
/*     */   {
/* 297 */     if (name.equals("org.apache.catalina.core.DISPATCHER_TYPE")) {
/* 298 */       this.dispatcherType = ((DispatcherType)value);
/* 299 */       return; }
/* 300 */     if (name.equals("org.apache.catalina.core.DISPATCHER_REQUEST_PATH")) {
/* 301 */       this.requestDispatcherPath = value;
/* 302 */       return;
/*     */     }
/*     */     
/* 305 */     if (!setSpecial(name, value)) {
/* 306 */       getRequest().setAttribute(name, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestDispatcher getRequestDispatcher(String path)
/*     */   {
/* 321 */     if (this.context == null) {
/* 322 */       return null;
/*     */     }
/*     */     
/* 325 */     if (path == null) {
/* 326 */       return null;
/*     */     }
/*     */     
/* 329 */     int fragmentPos = path.indexOf('#');
/* 330 */     if (fragmentPos > -1) {
/* 331 */       this.context.getLogger().warn(sm.getString("applicationHttpRequest.fragmentInDispatchPath", new Object[] { path }));
/* 332 */       path = path.substring(0, fragmentPos);
/*     */     }
/*     */     
/*     */ 
/* 336 */     if (path.startsWith("/")) {
/* 337 */       return this.context.getServletContext().getRequestDispatcher(path);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 342 */     String servletPath = (String)getAttribute("javax.servlet.include.servlet_path");
/* 343 */     if (servletPath == null) {
/* 344 */       servletPath = getServletPath();
/*     */     }
/*     */     
/*     */ 
/* 348 */     String pathInfo = getPathInfo();
/* 349 */     String requestPath = null;
/*     */     
/* 351 */     if (pathInfo == null) {
/* 352 */       requestPath = servletPath;
/*     */     } else {
/* 354 */       requestPath = servletPath + pathInfo;
/*     */     }
/*     */     
/* 357 */     int pos = requestPath.lastIndexOf('/');
/* 358 */     String relative = null;
/* 359 */     if (this.context.getDispatchersUseEncodedPaths()) {
/* 360 */       if (pos >= 0) {
/* 361 */         relative = URLEncoder.DEFAULT.encode(requestPath
/* 362 */           .substring(0, pos + 1), StandardCharsets.UTF_8) + path;
/*     */       }
/*     */       else {
/* 364 */         relative = URLEncoder.DEFAULT.encode(requestPath, StandardCharsets.UTF_8) + path;
/*     */       }
/*     */     }
/* 367 */     else if (pos >= 0) {
/* 368 */       relative = requestPath.substring(0, pos + 1) + path;
/*     */     } else {
/* 370 */       relative = requestPath + path;
/*     */     }
/*     */     
/*     */ 
/* 374 */     return this.context.getServletContext().getRequestDispatcher(relative);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DispatcherType getDispatcherType()
/*     */   {
/* 385 */     return this.dispatcherType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContextPath()
/*     */   {
/* 398 */     return this.contextPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 409 */     parseParameters();
/*     */     
/* 411 */     String[] value = (String[])this.parameters.get(name);
/* 412 */     if (value == null) {
/* 413 */       return null;
/*     */     }
/* 415 */     return value[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String[]> getParameterMap()
/*     */   {
/* 425 */     parseParameters();
/* 426 */     return this.parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getParameterNames()
/*     */   {
/* 436 */     parseParameters();
/* 437 */     return Collections.enumeration(this.parameters.keySet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getParameterValues(String name)
/*     */   {
/* 449 */     parseParameters();
/* 450 */     return (String[])this.parameters.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathInfo()
/*     */   {
/* 459 */     return this.pathInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathTranslated()
/*     */   {
/* 469 */     if ((getPathInfo() == null) || (getServletContext() == null)) {
/* 470 */       return null;
/*     */     }
/*     */     
/* 473 */     return getServletContext().getRealPath(getPathInfo());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQueryString()
/*     */   {
/* 483 */     return this.queryString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRequestURI()
/*     */   {
/* 493 */     return this.requestURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringBuffer getRequestURL()
/*     */   {
/* 503 */     return RequestUtil.getRequestURL(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getServletPath()
/*     */   {
/* 513 */     return this.servletPath;
/*     */   }
/*     */   
/*     */ 
/*     */   public HttpServletMapping getHttpServletMapping()
/*     */   {
/* 519 */     return this.mapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpSession getSession()
/*     */   {
/* 529 */     return getSession(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpSession getSession(boolean create)
/*     */   {
/* 542 */     if (this.crossContext)
/*     */     {
/*     */ 
/* 545 */       if (this.context == null) {
/* 546 */         return null;
/*     */       }
/*     */       
/*     */ 
/* 550 */       if ((this.session != null) && (this.session.isValid())) {
/* 551 */         return this.session.getSession();
/*     */       }
/*     */       
/* 554 */       HttpSession other = super.getSession(false);
/* 555 */       if ((create) && (other == null))
/*     */       {
/*     */ 
/*     */ 
/* 559 */         other = super.getSession(true);
/*     */       }
/* 561 */       if (other != null) {
/* 562 */         Session localSession = null;
/*     */         try
/*     */         {
/* 565 */           localSession = this.context.getManager().findSession(other.getId());
/* 566 */           if ((localSession != null) && (!localSession.isValid())) {
/* 567 */             localSession = null;
/*     */           }
/*     */         }
/*     */         catch (IOException localIOException) {}
/*     */         
/* 572 */         if ((localSession == null) && (create))
/*     */         {
/* 574 */           localSession = this.context.getManager().createSession(other.getId());
/*     */         }
/* 576 */         if (localSession != null) {
/* 577 */           localSession.access();
/* 578 */           this.session = localSession;
/* 579 */           return this.session.getSession();
/*     */         }
/*     */       }
/* 582 */       return null;
/*     */     }
/*     */     
/* 585 */     return super.getSession(create);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRequestedSessionIdValid()
/*     */   {
/* 601 */     if (this.crossContext)
/*     */     {
/* 603 */       String requestedSessionId = getRequestedSessionId();
/* 604 */       if (requestedSessionId == null) {
/* 605 */         return false;
/*     */       }
/* 607 */       if (this.context == null) {
/* 608 */         return false;
/*     */       }
/* 610 */       Manager manager = this.context.getManager();
/* 611 */       if (manager == null) {
/* 612 */         return false;
/*     */       }
/* 614 */       Session session = null;
/*     */       try {
/* 616 */         session = manager.findSession(requestedSessionId);
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */       
/* 620 */       if ((session != null) && (session.isValid())) {
/* 621 */         return true;
/*     */       }
/* 623 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 627 */     return super.isRequestedSessionIdValid();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PushBuilder newPushBuilder()
/*     */   {
/* 634 */     ServletRequest current = getRequest();
/* 635 */     while ((current instanceof ServletRequestWrapper)) {
/* 636 */       current = ((ServletRequestWrapper)current).getRequest();
/*     */     }
/* 638 */     if ((current instanceof RequestFacade)) {
/* 639 */       return ((RequestFacade)current).newPushBuilder(this);
/*     */     }
/* 641 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void recycle()
/*     */   {
/* 652 */     if (this.session != null) {
/* 653 */       this.session.endAccess();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setContextPath(String contextPath)
/*     */   {
/* 665 */     this.contextPath = contextPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setPathInfo(String pathInfo)
/*     */   {
/* 677 */     this.pathInfo = pathInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setQueryString(String queryString)
/*     */   {
/* 689 */     this.queryString = queryString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setRequest(HttpServletRequest request)
/*     */   {
/* 701 */     super.setRequest(request);
/*     */     
/*     */ 
/* 704 */     this.dispatcherType = ((DispatcherType)request.getAttribute("org.apache.catalina.core.DISPATCHER_TYPE"));
/*     */     
/* 706 */     this.requestDispatcherPath = request.getAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH");
/*     */     
/*     */ 
/* 709 */     this.contextPath = request.getContextPath();
/* 710 */     this.pathInfo = request.getPathInfo();
/* 711 */     this.queryString = request.getQueryString();
/* 712 */     this.requestURI = request.getRequestURI();
/* 713 */     this.servletPath = request.getServletPath();
/* 714 */     this.mapping = request.getHttpServletMapping();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setRequestURI(String requestURI)
/*     */   {
/* 725 */     this.requestURI = requestURI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setServletPath(String servletPath)
/*     */   {
/* 737 */     this.servletPath = servletPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void parseParameters()
/*     */   {
/* 750 */     if (this.parsedParams) {
/* 751 */       return;
/*     */     }
/*     */     
/* 754 */     this.parameters = new ParameterMap();
/* 755 */     this.parameters.putAll(getRequest().getParameterMap());
/* 756 */     mergeParameters();
/* 757 */     ((ParameterMap)this.parameters).setLocked(true);
/* 758 */     this.parsedParams = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setQueryParams(String queryString)
/*     */   {
/* 769 */     this.queryParamString = queryString;
/*     */   }
/*     */   
/*     */   void setMapping(HttpServletMapping mapping)
/*     */   {
/* 774 */     this.mapping = mapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isSpecial(String name)
/*     */   {
/* 788 */     for (String special : specials) {
/* 789 */       if (special.equals(name)) {
/* 790 */         return true;
/*     */       }
/*     */     }
/* 793 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getSpecial(String name)
/*     */   {
/* 805 */     for (int i = 0; i < specials.length; i++) {
/* 806 */       if (specials[i].equals(name)) {
/* 807 */         return i;
/*     */       }
/*     */     }
/* 810 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean setSpecial(String name, Object value)
/*     */   {
/* 820 */     for (int i = 0; i < specials.length; i++) {
/* 821 */       if (specials[i].equals(name)) {
/* 822 */         this.specialAttributes[i] = value;
/* 823 */         return true;
/*     */       }
/*     */     }
/* 826 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean removeSpecial(String name)
/*     */   {
/* 836 */     for (int i = 0; i < specials.length; i++) {
/* 837 */       if (specials[i].equals(name)) {
/* 838 */         this.specialAttributes[i] = null;
/* 839 */         return true;
/*     */       }
/*     */     }
/* 842 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] mergeValues(String[] values1, String[] values2)
/*     */   {
/* 854 */     List<Object> results = new ArrayList();
/*     */     
/* 856 */     if (values1 != null)
/*     */     {
/*     */ 
/* 859 */       results.addAll(Arrays.asList(values1));
/*     */     }
/*     */     
/* 862 */     if (values2 != null)
/*     */     {
/*     */ 
/* 865 */       results.addAll(Arrays.asList(values2));
/*     */     }
/*     */     
/* 868 */     String[] values = new String[results.size()];
/* 869 */     return (String[])results.toArray(values);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void mergeParameters()
/*     */   {
/* 884 */     if ((this.queryParamString == null) || (this.queryParamString.length() < 1)) {
/* 885 */       return;
/*     */     }
/*     */     
/*     */ 
/* 889 */     Parameters paramParser = new Parameters();
/* 890 */     MessageBytes queryMB = MessageBytes.newInstance();
/* 891 */     queryMB.setString(this.queryParamString);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 899 */     String encoding = getCharacterEncoding();
/* 900 */     Charset charset = null;
/* 901 */     if (encoding != null) {
/*     */       try {
/* 903 */         charset = B2CConverter.getCharset(encoding);
/* 904 */         queryMB.setCharset(charset);
/*     */       }
/*     */       catch (UnsupportedEncodingException e) {
/* 907 */         charset = StandardCharsets.ISO_8859_1;
/*     */       }
/*     */     }
/*     */     
/* 911 */     paramParser.setQuery(queryMB);
/* 912 */     paramParser.setQueryStringCharset(charset);
/* 913 */     paramParser.handleQueryParameters();
/*     */     
/*     */ 
/* 916 */     Enumeration<String> dispParamNames = paramParser.getParameterNames();
/* 917 */     while (dispParamNames.hasMoreElements()) {
/* 918 */       String dispParamName = (String)dispParamNames.nextElement();
/* 919 */       String[] dispParamValues = paramParser.getParameterValues(dispParamName);
/* 920 */       String[] originalValues = (String[])this.parameters.get(dispParamName);
/* 921 */       if (originalValues == null) {
/* 922 */         this.parameters.put(dispParamName, dispParamValues);
/*     */       }
/*     */       else {
/* 925 */         this.parameters.put(dispParamName, mergeValues(dispParamValues, originalValues));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected class AttributeNamesEnumerator
/*     */     implements Enumeration<String>
/*     */   {
/* 939 */     protected int pos = -1;
/*     */     protected final int last;
/*     */     protected final Enumeration<String> parentEnumeration;
/* 942 */     protected String next = null;
/*     */     
/*     */     public AttributeNamesEnumerator() {
/* 945 */       int last = -1;
/* 946 */       this.parentEnumeration = ApplicationHttpRequest.this.getRequest().getAttributeNames();
/* 947 */       for (int i = ApplicationHttpRequest.this.specialAttributes.length - 1; i >= 0; i--) {
/* 948 */         if (ApplicationHttpRequest.this.getAttribute(ApplicationHttpRequest.specials[i]) != null) {
/* 949 */           last = i;
/* 950 */           break;
/*     */         }
/*     */       }
/* 953 */       this.last = last;
/*     */     }
/*     */     
/*     */     public boolean hasMoreElements()
/*     */     {
/* 958 */       return (this.pos != this.last) || (this.next != null) || 
/* 959 */         ((this.next = findNext()) != null);
/*     */     }
/*     */     
/*     */     public String nextElement()
/*     */     {
/* 964 */       if (this.pos != this.last) {
/* 965 */         for (int i = this.pos + 1; i <= this.last; i++) {
/* 966 */           if (ApplicationHttpRequest.this.getAttribute(ApplicationHttpRequest.specials[i]) != null) {
/* 967 */             this.pos = i;
/* 968 */             return ApplicationHttpRequest.specials[i];
/*     */           }
/*     */         }
/*     */       }
/* 972 */       String result = this.next;
/* 973 */       if (this.next != null) {
/* 974 */         this.next = findNext();
/*     */       } else {
/* 976 */         throw new NoSuchElementException();
/*     */       }
/* 978 */       return result;
/*     */     }
/*     */     
/*     */     protected String findNext() {
/* 982 */       String result = null;
/* 983 */       while ((result == null) && (this.parentEnumeration.hasMoreElements())) {
/* 984 */         String current = (String)this.parentEnumeration.nextElement();
/* 985 */         if (!ApplicationHttpRequest.this.isSpecial(current)) {
/* 986 */           result = current;
/*     */         }
/*     */       }
/* 989 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\ApplicationHttpRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */