/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import java.util.Enumeration;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JarContents
/*     */ {
/*     */   private final BitSet bits1;
/*     */   private final BitSet bits2;
/*     */   private static final int HASH_PRIME_1 = 31;
/*     */   private static final int HASH_PRIME_2 = 17;
/*     */   private static final int TABLE_SIZE = 2048;
/*     */   
/*     */   public JarContents(JarFile jar)
/*     */   {
/*  57 */     Enumeration<JarEntry> entries = jar.entries();
/*  58 */     this.bits1 = new BitSet(2048);
/*  59 */     this.bits2 = new BitSet(2048);
/*     */     
/*     */ 
/*  62 */     while (entries.hasMoreElements()) {
/*  63 */       JarEntry entry = (JarEntry)entries.nextElement();
/*  64 */       String name = entry.getName();
/*  65 */       int startPos = 0;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  70 */       boolean precedingSlash = name.charAt(0) == '/';
/*  71 */       if (precedingSlash) {
/*  72 */         startPos = 1;
/*     */       }
/*     */       
/*     */ 
/*  76 */       int pathHash1 = hashcode(name, startPos, 31);
/*  77 */       int pathHash2 = hashcode(name, startPos, 17);
/*     */       
/*  79 */       this.bits1.set(pathHash1 % 2048);
/*  80 */       this.bits2.set(pathHash2 % 2048);
/*     */       
/*     */ 
/*     */ 
/*  84 */       if (entry.isDirectory()) {
/*  85 */         pathHash1 = hashcode(name, startPos, name.length() - 1, 31);
/*  86 */         pathHash2 = hashcode(name, startPos, name.length() - 1, 17);
/*     */         
/*  88 */         this.bits1.set(pathHash1 % 2048);
/*  89 */         this.bits2.set(pathHash2 % 2048);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int hashcode(String content, int startPos, int hashPrime)
/*     */   {
/* 105 */     return hashcode(content, startPos, content.length(), hashPrime);
/*     */   }
/*     */   
/*     */   private int hashcode(String content, int startPos, int endPos, int hashPrime) {
/* 109 */     int h = hashPrime / 2;
/* 110 */     for (int i = startPos; i < endPos; i++) {
/* 111 */       h = hashPrime * h + content.charAt(i);
/*     */     }
/*     */     
/* 114 */     if (h < 0) {
/* 115 */       h *= -1;
/*     */     }
/* 117 */     return h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean mightContainResource(String path, String webappRoot)
/*     */   {
/* 133 */     int startPos = 0;
/* 134 */     if (path.startsWith(webappRoot)) {
/* 135 */       startPos = webappRoot.length();
/*     */     }
/*     */     
/* 138 */     if (path.charAt(startPos) == '/')
/*     */     {
/* 140 */       startPos++;
/*     */     }
/*     */     
/*     */ 
/* 144 */     return (this.bits1.get(hashcode(path, startPos, 31) % 2048)) && 
/* 145 */       (this.bits2.get(hashcode(path, startPos, 17) % 2048));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\webresources\JarContents.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */