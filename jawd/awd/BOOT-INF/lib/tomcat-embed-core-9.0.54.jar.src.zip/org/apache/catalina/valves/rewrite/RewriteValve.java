/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringReader;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.valves.ValveBase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource;
/*     */ import org.apache.tomcat.util.file.ConfigurationSource.Resource;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RewriteValve
/*     */   extends ValveBase
/*     */ {
/*  74 */   protected RewriteRule[] rules = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   protected ThreadLocal<Boolean> invoked = new ThreadLocal();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */   protected String resourcePath = "rewrite.config";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */   protected boolean context = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */   protected boolean enabled = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 105 */   protected Map<String, RewriteMap> maps = new Hashtable();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */   protected ArrayList<String> mapsConfiguration = new ArrayList();
/*     */   
/*     */   public RewriteValve()
/*     */   {
/* 115 */     super(true);
/*     */   }
/*     */   
/*     */   public boolean getEnabled()
/*     */   {
/* 120 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 124 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 130 */     super.initInternal();
/* 131 */     this.containerLog = LogFactory.getLog(getContainer().getLogName() + ".rewrite");
/*     */   }
/*     */   
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 138 */     super.startInternal();
/*     */     
/* 140 */     InputStream is = null;
/*     */     
/*     */ 
/* 143 */     if ((getContainer() instanceof Context)) {
/* 144 */       this.context = true;
/*     */       
/* 146 */       is = ((Context)getContainer()).getServletContext().getResourceAsStream("/WEB-INF/" + this.resourcePath);
/* 147 */       if (this.containerLog.isDebugEnabled()) {
/* 148 */         if (is == null) {
/* 149 */           this.containerLog.debug("No configuration resource found: /WEB-INF/" + this.resourcePath);
/*     */         } else {
/* 151 */           this.containerLog.debug("Read configuration from: /WEB-INF/" + this.resourcePath);
/*     */         }
/*     */       }
/*     */     } else {
/* 155 */       String resourceName = Container.getConfigPath(getContainer(), this.resourcePath);
/*     */       try {
/* 157 */         ConfigurationSource.Resource resource = ConfigFileLoader.getSource().getResource(resourceName);
/* 158 */         is = resource.getInputStream();
/*     */       } catch (IOException e) {
/* 160 */         if (this.containerLog.isDebugEnabled()) {
/* 161 */           this.containerLog.debug("No configuration resource found: " + resourceName, e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 166 */     if (is == null)
/*     */     {
/* 168 */       return;
/*     */     }
/*     */     try {
/* 171 */       InputStreamReader isr = new InputStreamReader(is, StandardCharsets.UTF_8);e = null;
/* 172 */       try { BufferedReader reader = new BufferedReader(isr);Throwable localThrowable6 = null;
/* 173 */         try { parse(reader);
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 171 */           localThrowable6 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable4) { e = localThrowable4;throw localThrowable4;
/*     */       }
/*     */       finally {
/* 174 */         if (isr != null) if (e != null) try { isr.close(); } catch (Throwable localThrowable5) { e.addSuppressed(localThrowable5); } else isr.close(); }
/*     */       return; } catch (IOException ioe) { this.containerLog.error(sm.getString("rewriteValve.closeError"), ioe);
/*     */     } finally {
/*     */       try {
/* 178 */         is.close();
/*     */       } catch (IOException e) {
/* 180 */         this.containerLog.error(sm.getString("rewriteValve.closeError"), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setConfiguration(String configuration)
/*     */     throws Exception
/*     */   {
/* 188 */     if (this.containerLog == null) {
/* 189 */       this.containerLog = LogFactory.getLog(getContainer().getLogName() + ".rewrite");
/*     */     }
/* 191 */     this.maps.clear();
/* 192 */     parse(new BufferedReader(new StringReader(configuration)));
/*     */   }
/*     */   
/*     */   public String getConfiguration() {
/* 196 */     StringBuilder buffer = new StringBuilder();
/* 197 */     for (Object localObject = this.mapsConfiguration.iterator(); ((Iterator)localObject).hasNext();) { mapConfiguration = (String)((Iterator)localObject).next();
/* 198 */       buffer.append(mapConfiguration).append("\r\n");
/*     */     }
/* 200 */     if (this.mapsConfiguration.size() > 0) {
/* 201 */       buffer.append("\r\n");
/*     */     }
/* 203 */     localObject = this.rules;String mapConfiguration = localObject.length; for (String str1 = 0; str1 < mapConfiguration; str1++) { RewriteRule rule = localObject[str1];
/* 204 */       for (int j = 0; j < rule.getConditions().length; j++) {
/* 205 */         buffer.append(rule.getConditions()[j].toString()).append("\r\n");
/*     */       }
/* 207 */       buffer.append(rule.toString()).append("\r\n").append("\r\n");
/*     */     }
/* 209 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   protected void parse(BufferedReader reader) throws LifecycleException {
/* 213 */     List<RewriteRule> rules = new ArrayList();
/* 214 */     List<RewriteCond> conditions = new ArrayList();
/*     */     try {
/*     */       for (;;) {
/* 217 */         String line = reader.readLine();
/* 218 */         if (line == null) {
/*     */           break;
/*     */         }
/* 221 */         result = parse(line);
/* 222 */         if ((result instanceof RewriteRule)) {
/* 223 */           RewriteRule rule = (RewriteRule)result;
/* 224 */           if (this.containerLog.isDebugEnabled()) {
/* 225 */             this.containerLog.debug("Add rule with pattern " + rule.getPatternString() + " and substitution " + rule
/* 226 */               .getSubstitutionString());
/*     */           }
/* 228 */           for (int i = conditions.size() - 1; i > 0; i--) {
/* 229 */             if (((RewriteCond)conditions.get(i - 1)).isOrnext()) {
/* 230 */               ((RewriteCond)conditions.get(i)).setOrnext(true);
/*     */             }
/*     */           }
/* 233 */           for (RewriteCond condition : conditions) {
/* 234 */             if (this.containerLog.isDebugEnabled()) {
/* 235 */               RewriteCond cond = condition;
/* 236 */               this.containerLog.debug("Add condition " + cond.getCondPattern() + " test " + cond
/* 237 */                 .getTestString() + " to rule with pattern " + rule
/* 238 */                 .getPatternString() + " and substitution " + rule
/* 239 */                 .getSubstitutionString() + (cond.isOrnext() ? " [OR]" : "") + (cond
/* 240 */                 .isNocase() ? " [NC]" : ""));
/*     */             }
/* 242 */             rule.addCondition(condition);
/*     */           }
/* 244 */           conditions.clear();
/* 245 */           rules.add(rule);
/* 246 */         } else if ((result instanceof RewriteCond)) {
/* 247 */           conditions.add((RewriteCond)result);
/* 248 */         } else if ((result instanceof Object[])) {
/* 249 */           mapName = (String)((Object[])(Object[])result)[0];
/* 250 */           RewriteMap map = (RewriteMap)((Object[])(Object[])result)[1];
/* 251 */           this.maps.put(mapName, map);
/*     */           
/*     */ 
/* 254 */           this.mapsConfiguration.add(line);
/* 255 */           if ((map instanceof Lifecycle))
/* 256 */             ((Lifecycle)map).start();
/*     */         }
/*     */       }
/*     */     } catch (IOException e) {
/* 260 */       this.containerLog.error(sm.getString("rewriteValve.readError"), e);
/*     */     }
/*     */     
/* 263 */     this.rules = ((RewriteRule[])rules.toArray(new RewriteRule[0]));
/*     */     
/*     */ 
/* 266 */     e = this.rules;Object result = e.length; for (String mapName = 0; mapName < result; mapName++) { RewriteRule rule = e[mapName];
/* 267 */       rule.parse(this.maps);
/*     */     }
/*     */   }
/*     */   
/*     */   protected synchronized void stopInternal() throws LifecycleException
/*     */   {
/* 273 */     super.stopInternal();
/* 274 */     for (RewriteMap map : this.maps.values()) {
/* 275 */       if ((map instanceof Lifecycle)) {
/* 276 */         ((Lifecycle)map).stop();
/*     */       }
/*     */     }
/* 279 */     this.maps.clear();
/* 280 */     this.rules = null;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void invoke(org.apache.catalina.connector.Request request, org.apache.catalina.connector.Response response)
/*     */     throws IOException, javax.servlet.ServletException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokevirtual 108	org/apache/catalina/valves/rewrite/RewriteValve:getEnabled	()Z
/*     */     //   4: ifeq +18 -> 22
/*     */     //   7: aload_0
/*     */     //   8: getfield 2	org/apache/catalina/valves/rewrite/RewriteValve:rules	[Lorg/apache/catalina/valves/rewrite/RewriteRule;
/*     */     //   11: ifnull +11 -> 22
/*     */     //   14: aload_0
/*     */     //   15: getfield 2	org/apache/catalina/valves/rewrite/RewriteValve:rules	[Lorg/apache/catalina/valves/rewrite/RewriteRule;
/*     */     //   18: arraylength
/*     */     //   19: ifne +15 -> 34
/*     */     //   22: aload_0
/*     */     //   23: invokevirtual 109	org/apache/catalina/valves/rewrite/RewriteValve:getNext	()Lorg/apache/catalina/Valve;
/*     */     //   26: aload_1
/*     */     //   27: aload_2
/*     */     //   28: invokeinterface 110 3 0
/*     */     //   33: return
/*     */     //   34: getstatic 111	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   37: aload_0
/*     */     //   38: getfield 5	org/apache/catalina/valves/rewrite/RewriteValve:invoked	Ljava/lang/ThreadLocal;
/*     */     //   41: invokevirtual 112	java/lang/ThreadLocal:get	()Ljava/lang/Object;
/*     */     //   44: invokevirtual 113	java/lang/Boolean:equals	(Ljava/lang/Object;)Z
/*     */     //   47: ifeq +37 -> 84
/*     */     //   50: aload_0
/*     */     //   51: invokevirtual 109	org/apache/catalina/valves/rewrite/RewriteValve:getNext	()Lorg/apache/catalina/Valve;
/*     */     //   54: aload_1
/*     */     //   55: aload_2
/*     */     //   56: invokeinterface 110 3 0
/*     */     //   61: aload_0
/*     */     //   62: getfield 5	org/apache/catalina/valves/rewrite/RewriteValve:invoked	Ljava/lang/ThreadLocal;
/*     */     //   65: aconst_null
/*     */     //   66: invokevirtual 114	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
/*     */     //   69: goto +14 -> 83
/*     */     //   72: astore_3
/*     */     //   73: aload_0
/*     */     //   74: getfield 5	org/apache/catalina/valves/rewrite/RewriteValve:invoked	Ljava/lang/ThreadLocal;
/*     */     //   77: aconst_null
/*     */     //   78: invokevirtual 114	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
/*     */     //   81: aload_3
/*     */     //   82: athrow
/*     */     //   83: return
/*     */     //   84: new 115	org/apache/catalina/valves/rewrite/ResolverImpl
/*     */     //   87: dup
/*     */     //   88: aload_1
/*     */     //   89: invokespecial 116	org/apache/catalina/valves/rewrite/ResolverImpl:<init>	(Lorg/apache/catalina/connector/Request;)V
/*     */     //   92: astore_3
/*     */     //   93: aload_0
/*     */     //   94: getfield 5	org/apache/catalina/valves/rewrite/RewriteValve:invoked	Ljava/lang/ThreadLocal;
/*     */     //   97: getstatic 111	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   100: invokevirtual 114	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
/*     */     //   103: aload_1
/*     */     //   104: invokevirtual 117	org/apache/catalina/connector/Request:getConnector	()Lorg/apache/catalina/connector/Connector;
/*     */     //   107: invokevirtual 118	org/apache/catalina/connector/Connector:getURICharset	()Ljava/nio/charset/Charset;
/*     */     //   110: astore 4
/*     */     //   112: aload_1
/*     */     //   113: invokevirtual 119	org/apache/catalina/connector/Request:getQueryString	()Ljava/lang/String;
/*     */     //   116: astore 5
/*     */     //   118: aload_0
/*     */     //   119: getfield 8	org/apache/catalina/valves/rewrite/RewriteValve:context	Z
/*     */     //   122: ifeq +10 -> 132
/*     */     //   125: aload_1
/*     */     //   126: invokevirtual 120	org/apache/catalina/connector/Request:getRequestPathMB	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   129: goto +7 -> 136
/*     */     //   132: aload_1
/*     */     //   133: invokevirtual 121	org/apache/catalina/connector/Request:getDecodedRequestURIMB	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   136: astore 6
/*     */     //   138: aload 6
/*     */     //   140: invokevirtual 122	org/apache/tomcat/util/buf/MessageBytes:toChars	()V
/*     */     //   143: aload 6
/*     */     //   145: invokevirtual 123	org/apache/tomcat/util/buf/MessageBytes:getCharChunk	()Lorg/apache/tomcat/util/buf/CharChunk;
/*     */     //   148: astore 7
/*     */     //   150: aload_1
/*     */     //   151: invokevirtual 124	org/apache/catalina/connector/Request:getServerName	()Ljava/lang/String;
/*     */     //   154: astore 8
/*     */     //   156: iconst_0
/*     */     //   157: istore 9
/*     */     //   159: iconst_0
/*     */     //   160: istore 10
/*     */     //   162: iconst_0
/*     */     //   163: istore 11
/*     */     //   165: iconst_0
/*     */     //   166: istore 12
/*     */     //   168: iconst_0
/*     */     //   169: istore 13
/*     */     //   171: iload 13
/*     */     //   173: aload_0
/*     */     //   174: getfield 2	org/apache/catalina/valves/rewrite/RewriteValve:rules	[Lorg/apache/catalina/valves/rewrite/RewriteRule;
/*     */     //   177: arraylength
/*     */     //   178: if_icmpge +854 -> 1032
/*     */     //   181: aload_0
/*     */     //   182: getfield 2	org/apache/catalina/valves/rewrite/RewriteValve:rules	[Lorg/apache/catalina/valves/rewrite/RewriteRule;
/*     */     //   185: iload 13
/*     */     //   187: aaload
/*     */     //   188: astore 14
/*     */     //   190: aload 14
/*     */     //   192: invokevirtual 125	org/apache/catalina/valves/rewrite/RewriteRule:isHost	()Z
/*     */     //   195: ifeq +8 -> 203
/*     */     //   198: aload 8
/*     */     //   200: goto +5 -> 205
/*     */     //   203: aload 7
/*     */     //   205: astore 15
/*     */     //   207: aload 14
/*     */     //   209: aload 15
/*     */     //   211: aload_3
/*     */     //   212: invokevirtual 126	org/apache/catalina/valves/rewrite/RewriteRule:evaluate	(Ljava/lang/CharSequence;Lorg/apache/catalina/valves/rewrite/Resolver;)Ljava/lang/CharSequence;
/*     */     //   215: astore 16
/*     */     //   217: aload 16
/*     */     //   219: ifnull +104 -> 323
/*     */     //   222: aload 15
/*     */     //   224: aload 16
/*     */     //   226: invokeinterface 127 1 0
/*     */     //   231: invokevirtual 128	java/lang/Object:equals	(Ljava/lang/Object;)Z
/*     */     //   234: ifne +89 -> 323
/*     */     //   237: aload_0
/*     */     //   238: getfield 25	org/apache/catalina/valves/rewrite/RewriteValve:containerLog	Lorg/apache/juli/logging/Log;
/*     */     //   241: invokeinterface 31 1 0
/*     */     //   246: ifeq +55 -> 301
/*     */     //   249: aload_0
/*     */     //   250: getfield 25	org/apache/catalina/valves/rewrite/RewriteValve:containerLog	Lorg/apache/juli/logging/Log;
/*     */     //   253: new 17	java/lang/StringBuilder
/*     */     //   256: dup
/*     */     //   257: invokespecial 18	java/lang/StringBuilder:<init>	()V
/*     */     //   260: ldc -127
/*     */     //   262: invokevirtual 21	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   265: aload 15
/*     */     //   267: invokevirtual 130	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   270: ldc -125
/*     */     //   272: invokevirtual 21	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   275: aload 16
/*     */     //   277: invokevirtual 130	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   280: ldc -124
/*     */     //   282: invokevirtual 21	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   285: aload 14
/*     */     //   287: invokevirtual 73	org/apache/catalina/valves/rewrite/RewriteRule:getPatternString	()Ljava/lang/String;
/*     */     //   290: invokevirtual 21	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   293: invokevirtual 23	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   296: invokeinterface 33 2 0
/*     */     //   301: aload 14
/*     */     //   303: invokevirtual 125	org/apache/catalina/valves/rewrite/RewriteRule:isHost	()Z
/*     */     //   306: ifeq +10 -> 316
/*     */     //   309: aload 16
/*     */     //   311: astore 8
/*     */     //   313: goto +7 -> 320
/*     */     //   316: aload 16
/*     */     //   318: astore 7
/*     */     //   320: iconst_1
/*     */     //   321: istore 9
/*     */     //   323: iload 11
/*     */     //   325: ifne +19 -> 344
/*     */     //   328: aload 16
/*     */     //   330: ifnull +14 -> 344
/*     */     //   333: aload 14
/*     */     //   335: invokevirtual 133	org/apache/catalina/valves/rewrite/RewriteRule:isQsappend	()Z
/*     */     //   338: ifeq +6 -> 344
/*     */     //   341: iconst_1
/*     */     //   342: istore 11
/*     */     //   344: iload 11
/*     */     //   346: ifne +19 -> 365
/*     */     //   349: aload 16
/*     */     //   351: ifnull +14 -> 365
/*     */     //   354: aload 14
/*     */     //   356: invokevirtual 134	org/apache/catalina/valves/rewrite/RewriteRule:isQsdiscard	()Z
/*     */     //   359: ifeq +6 -> 365
/*     */     //   362: iconst_1
/*     */     //   363: istore 12
/*     */     //   365: aload 14
/*     */     //   367: invokevirtual 135	org/apache/catalina/valves/rewrite/RewriteRule:isForbidden	()Z
/*     */     //   370: ifeq +21 -> 391
/*     */     //   373: aload 16
/*     */     //   375: ifnull +16 -> 391
/*     */     //   378: aload_2
/*     */     //   379: sipush 403
/*     */     //   382: invokevirtual 137	org/apache/catalina/connector/Response:sendError	(I)V
/*     */     //   385: iconst_1
/*     */     //   386: istore 10
/*     */     //   388: goto +644 -> 1032
/*     */     //   391: aload 14
/*     */     //   393: invokevirtual 138	org/apache/catalina/valves/rewrite/RewriteRule:isGone	()Z
/*     */     //   396: ifeq +21 -> 417
/*     */     //   399: aload 16
/*     */     //   401: ifnull +16 -> 417
/*     */     //   404: aload_2
/*     */     //   405: sipush 410
/*     */     //   408: invokevirtual 137	org/apache/catalina/connector/Response:sendError	(I)V
/*     */     //   411: iconst_1
/*     */     //   412: istore 10
/*     */     //   414: goto +618 -> 1032
/*     */     //   417: aload 14
/*     */     //   419: invokevirtual 139	org/apache/catalina/valves/rewrite/RewriteRule:isRedirect	()Z
/*     */     //   422: ifeq +338 -> 760
/*     */     //   425: aload 16
/*     */     //   427: ifnull +333 -> 760
/*     */     //   430: aload 7
/*     */     //   432: invokeinterface 127 1 0
/*     */     //   437: astore 17
/*     */     //   439: aload 17
/*     */     //   441: bipush 63
/*     */     //   443: invokevirtual 140	java/lang/String:indexOf	(I)I
/*     */     //   446: istore 18
/*     */     //   448: iload 18
/*     */     //   450: iconst_m1
/*     */     //   451: if_icmpne +9 -> 460
/*     */     //   454: aconst_null
/*     */     //   455: astore 19
/*     */     //   457: goto +24 -> 481
/*     */     //   460: aload 17
/*     */     //   462: iload 18
/*     */     //   464: iconst_1
/*     */     //   465: iadd
/*     */     //   466: invokevirtual 141	java/lang/String:substring	(I)Ljava/lang/String;
/*     */     //   469: astore 19
/*     */     //   471: aload 17
/*     */     //   473: iconst_0
/*     */     //   474: iload 18
/*     */     //   476: invokevirtual 142	java/lang/String:substring	(II)Ljava/lang/String;
/*     */     //   479: astore 17
/*     */     //   481: new 17	java/lang/StringBuilder
/*     */     //   484: dup
/*     */     //   485: getstatic 143	org/apache/catalina/util/URLEncoder:DEFAULT	Lorg/apache/catalina/util/URLEncoder;
/*     */     //   488: aload 17
/*     */     //   490: aload 4
/*     */     //   492: invokevirtual 144	org/apache/catalina/util/URLEncoder:encode	(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;
/*     */     //   495: invokespecial 145	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   498: astore 20
/*     */     //   500: iload 12
/*     */     //   502: ifne +138 -> 640
/*     */     //   505: aload 5
/*     */     //   507: ifnull +133 -> 640
/*     */     //   510: aload 5
/*     */     //   512: invokevirtual 146	java/lang/String:length	()I
/*     */     //   515: ifle +125 -> 640
/*     */     //   518: aload 19
/*     */     //   520: ifnonnull +22 -> 542
/*     */     //   523: aload 20
/*     */     //   525: bipush 63
/*     */     //   527: invokevirtual 147	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
/*     */     //   530: pop
/*     */     //   531: aload 20
/*     */     //   533: aload 5
/*     */     //   535: invokevirtual 21	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   538: pop
/*     */     //   539: goto +130 -> 669
/*     */     //   542: iload 11
/*     */     //   544: ifeq +46 -> 590
/*     */     //   547: aload 20
/*     */     //   549: bipush 63
/*     */     //   551: invokevirtual 147	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
/*     */     //   554: pop
/*     */     //   555: aload 20
/*     */     //   557: getstatic 148	org/apache/catalina/util/URLEncoder:QUERY	Lorg/apache/catalina/util/URLEncoder;
/*     */     //   560: aload 19
/*     */     //   562: aload 4
/*     */     //   564: invokevirtual 144	org/apache/catalina/util/URLEncoder:encode	(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;
/*     */     //   567: invokevirtual 21	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   570: pop
/*     */     //   571: aload 20
/*     */     //   573: bipush 38
/*     */     //   575: invokevirtual 147	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
/*     */     //   578: pop
/*     */     //   579: aload 20
/*     */     //   581: aload 5
/*     */     //   583: invokevirtual 21	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   586: pop
/*     */     //   587: goto +82 -> 669
/*     */     //   590: iload 18
/*     */     //   592: aload 20
/*     */     //   594: invokevirtual 149	java/lang/StringBuilder:length	()I
/*     */     //   597: iconst_1
/*     */     //   598: isub
/*     */     //   599: if_icmpne +14 -> 613
/*     */     //   602: aload 20
/*     */     //   604: iload 18
/*     */     //   606: invokevirtual 150	java/lang/StringBuilder:deleteCharAt	(I)Ljava/lang/StringBuilder;
/*     */     //   609: pop
/*     */     //   610: goto +59 -> 669
/*     */     //   613: aload 20
/*     */     //   615: bipush 63
/*     */     //   617: invokevirtual 147	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
/*     */     //   620: pop
/*     */     //   621: aload 20
/*     */     //   623: getstatic 148	org/apache/catalina/util/URLEncoder:QUERY	Lorg/apache/catalina/util/URLEncoder;
/*     */     //   626: aload 19
/*     */     //   628: aload 4
/*     */     //   630: invokevirtual 144	org/apache/catalina/util/URLEncoder:encode	(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;
/*     */     //   633: invokevirtual 21	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   636: pop
/*     */     //   637: goto +32 -> 669
/*     */     //   640: aload 19
/*     */     //   642: ifnull +27 -> 669
/*     */     //   645: aload 20
/*     */     //   647: bipush 63
/*     */     //   649: invokevirtual 147	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
/*     */     //   652: pop
/*     */     //   653: aload 20
/*     */     //   655: getstatic 148	org/apache/catalina/util/URLEncoder:QUERY	Lorg/apache/catalina/util/URLEncoder;
/*     */     //   658: aload 19
/*     */     //   660: aload 4
/*     */     //   662: invokevirtual 144	org/apache/catalina/util/URLEncoder:encode	(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;
/*     */     //   665: invokevirtual 21	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   668: pop
/*     */     //   669: aload_0
/*     */     //   670: getfield 8	org/apache/catalina/valves/rewrite/RewriteValve:context	Z
/*     */     //   673: ifeq +38 -> 711
/*     */     //   676: aload 20
/*     */     //   678: iconst_0
/*     */     //   679: invokevirtual 151	java/lang/StringBuilder:charAt	(I)C
/*     */     //   682: bipush 47
/*     */     //   684: if_icmpne +27 -> 711
/*     */     //   687: aload 20
/*     */     //   689: invokestatic 152	org/apache/tomcat/util/buf/UriUtil:hasScheme	(Ljava/lang/CharSequence;)Z
/*     */     //   692: ifne +19 -> 711
/*     */     //   695: aload 20
/*     */     //   697: iconst_0
/*     */     //   698: aload_1
/*     */     //   699: invokevirtual 153	org/apache/catalina/connector/Request:getContext	()Lorg/apache/catalina/Context;
/*     */     //   702: invokeinterface 154 1 0
/*     */     //   707: invokevirtual 155	java/lang/StringBuilder:insert	(ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   710: pop
/*     */     //   711: aload 14
/*     */     //   713: invokevirtual 156	org/apache/catalina/valves/rewrite/RewriteRule:isNoescape	()Z
/*     */     //   716: ifeq +20 -> 736
/*     */     //   719: aload_2
/*     */     //   720: aload 20
/*     */     //   722: invokevirtual 23	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   725: aload 4
/*     */     //   727: invokestatic 157	org/apache/tomcat/util/buf/UDecoder:URLDecode	(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;
/*     */     //   730: invokevirtual 158	org/apache/catalina/connector/Response:sendRedirect	(Ljava/lang/String;)V
/*     */     //   733: goto +12 -> 745
/*     */     //   736: aload_2
/*     */     //   737: aload 20
/*     */     //   739: invokevirtual 23	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   742: invokevirtual 158	org/apache/catalina/connector/Response:sendRedirect	(Ljava/lang/String;)V
/*     */     //   745: aload_2
/*     */     //   746: aload 14
/*     */     //   748: invokevirtual 159	org/apache/catalina/valves/rewrite/RewriteRule:getRedirectCode	()I
/*     */     //   751: invokevirtual 160	org/apache/catalina/connector/Response:setStatus	(I)V
/*     */     //   754: iconst_1
/*     */     //   755: istore 10
/*     */     //   757: goto +275 -> 1032
/*     */     //   760: aload 14
/*     */     //   762: invokevirtual 161	org/apache/catalina/valves/rewrite/RewriteRule:isCookie	()Z
/*     */     //   765: ifeq +83 -> 848
/*     */     //   768: aload 16
/*     */     //   770: ifnull +78 -> 848
/*     */     //   773: new 162	javax/servlet/http/Cookie
/*     */     //   776: dup
/*     */     //   777: aload 14
/*     */     //   779: invokevirtual 163	org/apache/catalina/valves/rewrite/RewriteRule:getCookieName	()Ljava/lang/String;
/*     */     //   782: aload 14
/*     */     //   784: invokevirtual 164	org/apache/catalina/valves/rewrite/RewriteRule:getCookieResult	()Ljava/lang/String;
/*     */     //   787: invokespecial 165	javax/servlet/http/Cookie:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   790: astore 17
/*     */     //   792: aload 17
/*     */     //   794: aload 14
/*     */     //   796: invokevirtual 166	org/apache/catalina/valves/rewrite/RewriteRule:getCookieDomain	()Ljava/lang/String;
/*     */     //   799: invokevirtual 167	javax/servlet/http/Cookie:setDomain	(Ljava/lang/String;)V
/*     */     //   802: aload 17
/*     */     //   804: aload 14
/*     */     //   806: invokevirtual 168	org/apache/catalina/valves/rewrite/RewriteRule:getCookieLifetime	()I
/*     */     //   809: invokevirtual 169	javax/servlet/http/Cookie:setMaxAge	(I)V
/*     */     //   812: aload 17
/*     */     //   814: aload 14
/*     */     //   816: invokevirtual 170	org/apache/catalina/valves/rewrite/RewriteRule:getCookiePath	()Ljava/lang/String;
/*     */     //   819: invokevirtual 171	javax/servlet/http/Cookie:setPath	(Ljava/lang/String;)V
/*     */     //   822: aload 17
/*     */     //   824: aload 14
/*     */     //   826: invokevirtual 172	org/apache/catalina/valves/rewrite/RewriteRule:isCookieSecure	()Z
/*     */     //   829: invokevirtual 173	javax/servlet/http/Cookie:setSecure	(Z)V
/*     */     //   832: aload 17
/*     */     //   834: aload 14
/*     */     //   836: invokevirtual 174	org/apache/catalina/valves/rewrite/RewriteRule:isCookieHttpOnly	()Z
/*     */     //   839: invokevirtual 175	javax/servlet/http/Cookie:setHttpOnly	(Z)V
/*     */     //   842: aload_2
/*     */     //   843: aload 17
/*     */     //   845: invokevirtual 176	org/apache/catalina/connector/Response:addCookie	(Ljavax/servlet/http/Cookie;)V
/*     */     //   848: aload 14
/*     */     //   850: invokevirtual 177	org/apache/catalina/valves/rewrite/RewriteRule:isEnv	()Z
/*     */     //   853: ifeq +45 -> 898
/*     */     //   856: aload 16
/*     */     //   858: ifnull +40 -> 898
/*     */     //   861: iconst_0
/*     */     //   862: istore 17
/*     */     //   864: iload 17
/*     */     //   866: aload 14
/*     */     //   868: invokevirtual 178	org/apache/catalina/valves/rewrite/RewriteRule:getEnvSize	()I
/*     */     //   871: if_icmpge +27 -> 898
/*     */     //   874: aload_1
/*     */     //   875: aload 14
/*     */     //   877: iload 17
/*     */     //   879: invokevirtual 179	org/apache/catalina/valves/rewrite/RewriteRule:getEnvName	(I)Ljava/lang/String;
/*     */     //   882: aload 14
/*     */     //   884: iload 17
/*     */     //   886: invokevirtual 180	org/apache/catalina/valves/rewrite/RewriteRule:getEnvResult	(I)Ljava/lang/String;
/*     */     //   889: invokevirtual 181	org/apache/catalina/connector/Request:setAttribute	(Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   892: iinc 17 1
/*     */     //   895: goto -31 -> 864
/*     */     //   898: aload 14
/*     */     //   900: invokevirtual 182	org/apache/catalina/valves/rewrite/RewriteRule:isType	()Z
/*     */     //   903: ifeq +17 -> 920
/*     */     //   906: aload 16
/*     */     //   908: ifnull +12 -> 920
/*     */     //   911: aload_1
/*     */     //   912: aload 14
/*     */     //   914: invokevirtual 183	org/apache/catalina/valves/rewrite/RewriteRule:getTypeValue	()Ljava/lang/String;
/*     */     //   917: invokevirtual 184	org/apache/catalina/connector/Request:setContentType	(Ljava/lang/String;)V
/*     */     //   920: aload 14
/*     */     //   922: invokevirtual 185	org/apache/catalina/valves/rewrite/RewriteRule:isChain	()Z
/*     */     //   925: ifeq +51 -> 976
/*     */     //   928: aload 16
/*     */     //   930: ifnonnull +46 -> 976
/*     */     //   933: iload 13
/*     */     //   935: istore 17
/*     */     //   937: iload 17
/*     */     //   939: aload_0
/*     */     //   940: getfield 2	org/apache/catalina/valves/rewrite/RewriteValve:rules	[Lorg/apache/catalina/valves/rewrite/RewriteRule;
/*     */     //   943: arraylength
/*     */     //   944: if_icmpge +29 -> 973
/*     */     //   947: aload_0
/*     */     //   948: getfield 2	org/apache/catalina/valves/rewrite/RewriteValve:rules	[Lorg/apache/catalina/valves/rewrite/RewriteRule;
/*     */     //   951: iload 17
/*     */     //   953: aaload
/*     */     //   954: invokevirtual 185	org/apache/catalina/valves/rewrite/RewriteRule:isChain	()Z
/*     */     //   957: ifne +10 -> 967
/*     */     //   960: iload 17
/*     */     //   962: istore 13
/*     */     //   964: goto +9 -> 973
/*     */     //   967: iinc 17 1
/*     */     //   970: goto -33 -> 937
/*     */     //   973: goto +53 -> 1026
/*     */     //   976: aload 14
/*     */     //   978: invokevirtual 186	org/apache/catalina/valves/rewrite/RewriteRule:isLast	()Z
/*     */     //   981: ifeq +11 -> 992
/*     */     //   984: aload 16
/*     */     //   986: ifnull +6 -> 992
/*     */     //   989: goto +43 -> 1032
/*     */     //   992: aload 14
/*     */     //   994: invokevirtual 187	org/apache/catalina/valves/rewrite/RewriteRule:isNext	()Z
/*     */     //   997: ifeq +14 -> 1011
/*     */     //   1000: aload 16
/*     */     //   1002: ifnull +9 -> 1011
/*     */     //   1005: iconst_0
/*     */     //   1006: istore 13
/*     */     //   1008: goto +18 -> 1026
/*     */     //   1011: aload 16
/*     */     //   1013: ifnull +13 -> 1026
/*     */     //   1016: iload 13
/*     */     //   1018: aload 14
/*     */     //   1020: invokevirtual 188	org/apache/catalina/valves/rewrite/RewriteRule:getSkip	()I
/*     */     //   1023: iadd
/*     */     //   1024: istore 13
/*     */     //   1026: iinc 13 1
/*     */     //   1029: goto -858 -> 171
/*     */     //   1032: iload 9
/*     */     //   1034: ifeq +470 -> 1504
/*     */     //   1037: iload 10
/*     */     //   1039: ifne +476 -> 1515
/*     */     //   1042: aload 7
/*     */     //   1044: invokeinterface 127 1 0
/*     */     //   1049: astore 13
/*     */     //   1051: aconst_null
/*     */     //   1052: astore 14
/*     */     //   1054: aload 13
/*     */     //   1056: bipush 63
/*     */     //   1058: invokevirtual 140	java/lang/String:indexOf	(I)I
/*     */     //   1061: istore 15
/*     */     //   1063: iload 15
/*     */     //   1065: iconst_m1
/*     */     //   1066: if_icmpeq +24 -> 1090
/*     */     //   1069: aload 13
/*     */     //   1071: iload 15
/*     */     //   1073: iconst_1
/*     */     //   1074: iadd
/*     */     //   1075: invokevirtual 141	java/lang/String:substring	(I)Ljava/lang/String;
/*     */     //   1078: astore 14
/*     */     //   1080: aload 13
/*     */     //   1082: iconst_0
/*     */     //   1083: iload 15
/*     */     //   1085: invokevirtual 142	java/lang/String:substring	(II)Ljava/lang/String;
/*     */     //   1088: astore 13
/*     */     //   1090: aconst_null
/*     */     //   1091: astore 16
/*     */     //   1093: aload_0
/*     */     //   1094: getfield 8	org/apache/catalina/valves/rewrite/RewriteValve:context	Z
/*     */     //   1097: ifeq +9 -> 1106
/*     */     //   1100: aload_1
/*     */     //   1101: invokevirtual 189	org/apache/catalina/connector/Request:getContextPath	()Ljava/lang/String;
/*     */     //   1104: astore 16
/*     */     //   1106: aload_1
/*     */     //   1107: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1110: invokevirtual 191	org/apache/coyote/Request:requestURI	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   1113: aconst_null
/*     */     //   1114: invokevirtual 192	org/apache/tomcat/util/buf/MessageBytes:setString	(Ljava/lang/String;)V
/*     */     //   1117: aload_1
/*     */     //   1118: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1121: invokevirtual 191	org/apache/coyote/Request:requestURI	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   1124: invokevirtual 123	org/apache/tomcat/util/buf/MessageBytes:getCharChunk	()Lorg/apache/tomcat/util/buf/CharChunk;
/*     */     //   1127: astore 17
/*     */     //   1129: aload 17
/*     */     //   1131: invokevirtual 193	org/apache/tomcat/util/buf/CharChunk:recycle	()V
/*     */     //   1134: aload_0
/*     */     //   1135: getfield 8	org/apache/catalina/valves/rewrite/RewriteValve:context	Z
/*     */     //   1138: ifeq +10 -> 1148
/*     */     //   1141: aload 17
/*     */     //   1143: aload 16
/*     */     //   1145: invokevirtual 194	org/apache/tomcat/util/buf/CharChunk:append	(Ljava/lang/String;)V
/*     */     //   1148: aload 17
/*     */     //   1150: getstatic 143	org/apache/catalina/util/URLEncoder:DEFAULT	Lorg/apache/catalina/util/URLEncoder;
/*     */     //   1153: aload 13
/*     */     //   1155: aload 4
/*     */     //   1157: invokevirtual 144	org/apache/catalina/util/URLEncoder:encode	(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;
/*     */     //   1160: invokevirtual 194	org/apache/tomcat/util/buf/CharChunk:append	(Ljava/lang/String;)V
/*     */     //   1163: aload_1
/*     */     //   1164: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1167: invokevirtual 191	org/apache/coyote/Request:requestURI	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   1170: invokevirtual 122	org/apache/tomcat/util/buf/MessageBytes:toChars	()V
/*     */     //   1173: aload 13
/*     */     //   1175: invokestatic 195	org/apache/tomcat/util/http/RequestUtil:normalize	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   1178: astore 13
/*     */     //   1180: aload_1
/*     */     //   1181: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1184: invokevirtual 196	org/apache/coyote/Request:decodedURI	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   1187: aconst_null
/*     */     //   1188: invokevirtual 192	org/apache/tomcat/util/buf/MessageBytes:setString	(Ljava/lang/String;)V
/*     */     //   1191: aload_1
/*     */     //   1192: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1195: invokevirtual 196	org/apache/coyote/Request:decodedURI	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   1198: invokevirtual 123	org/apache/tomcat/util/buf/MessageBytes:getCharChunk	()Lorg/apache/tomcat/util/buf/CharChunk;
/*     */     //   1201: astore 17
/*     */     //   1203: aload 17
/*     */     //   1205: invokevirtual 193	org/apache/tomcat/util/buf/CharChunk:recycle	()V
/*     */     //   1208: aload_0
/*     */     //   1209: getfield 8	org/apache/catalina/valves/rewrite/RewriteValve:context	Z
/*     */     //   1212: ifeq +17 -> 1229
/*     */     //   1215: aload 17
/*     */     //   1217: aload_1
/*     */     //   1218: invokevirtual 197	org/apache/catalina/connector/Request:getServletContext	()Ljavax/servlet/ServletContext;
/*     */     //   1221: invokeinterface 198 1 0
/*     */     //   1226: invokevirtual 194	org/apache/tomcat/util/buf/CharChunk:append	(Ljava/lang/String;)V
/*     */     //   1229: aload 17
/*     */     //   1231: aload 13
/*     */     //   1233: invokevirtual 194	org/apache/tomcat/util/buf/CharChunk:append	(Ljava/lang/String;)V
/*     */     //   1236: aload_1
/*     */     //   1237: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1240: invokevirtual 196	org/apache/coyote/Request:decodedURI	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   1243: invokevirtual 122	org/apache/tomcat/util/buf/MessageBytes:toChars	()V
/*     */     //   1246: aload 14
/*     */     //   1248: ifnull +96 -> 1344
/*     */     //   1251: aload_1
/*     */     //   1252: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1255: invokevirtual 199	org/apache/coyote/Request:queryString	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   1258: aconst_null
/*     */     //   1259: invokevirtual 192	org/apache/tomcat/util/buf/MessageBytes:setString	(Ljava/lang/String;)V
/*     */     //   1262: aload_1
/*     */     //   1263: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1266: invokevirtual 199	org/apache/coyote/Request:queryString	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   1269: invokevirtual 123	org/apache/tomcat/util/buf/MessageBytes:getCharChunk	()Lorg/apache/tomcat/util/buf/CharChunk;
/*     */     //   1272: astore 17
/*     */     //   1274: aload 17
/*     */     //   1276: invokevirtual 193	org/apache/tomcat/util/buf/CharChunk:recycle	()V
/*     */     //   1279: aload 17
/*     */     //   1281: getstatic 148	org/apache/catalina/util/URLEncoder:QUERY	Lorg/apache/catalina/util/URLEncoder;
/*     */     //   1284: aload 14
/*     */     //   1286: aload 4
/*     */     //   1288: invokevirtual 144	org/apache/catalina/util/URLEncoder:encode	(Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;
/*     */     //   1291: invokevirtual 194	org/apache/tomcat/util/buf/CharChunk:append	(Ljava/lang/String;)V
/*     */     //   1294: iload 11
/*     */     //   1296: ifeq +30 -> 1326
/*     */     //   1299: aload 5
/*     */     //   1301: ifnull +25 -> 1326
/*     */     //   1304: aload 5
/*     */     //   1306: invokevirtual 146	java/lang/String:length	()I
/*     */     //   1309: ifle +17 -> 1326
/*     */     //   1312: aload 17
/*     */     //   1314: bipush 38
/*     */     //   1316: invokevirtual 200	org/apache/tomcat/util/buf/CharChunk:append	(C)V
/*     */     //   1319: aload 17
/*     */     //   1321: aload 5
/*     */     //   1323: invokevirtual 194	org/apache/tomcat/util/buf/CharChunk:append	(Ljava/lang/String;)V
/*     */     //   1326: aload 17
/*     */     //   1328: invokevirtual 201	org/apache/tomcat/util/buf/CharChunk:isNull	()Z
/*     */     //   1331: ifne +13 -> 1344
/*     */     //   1334: aload_1
/*     */     //   1335: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1338: invokevirtual 199	org/apache/coyote/Request:queryString	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   1341: invokevirtual 122	org/apache/tomcat/util/buf/MessageBytes:toChars	()V
/*     */     //   1344: aload 8
/*     */     //   1346: aload_1
/*     */     //   1347: invokevirtual 124	org/apache/catalina/connector/Request:getServerName	()Ljava/lang/String;
/*     */     //   1350: invokevirtual 128	java/lang/Object:equals	(Ljava/lang/Object;)Z
/*     */     //   1353: ifne +53 -> 1406
/*     */     //   1356: aload_1
/*     */     //   1357: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1360: invokevirtual 202	org/apache/coyote/Request:serverName	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   1363: aconst_null
/*     */     //   1364: invokevirtual 192	org/apache/tomcat/util/buf/MessageBytes:setString	(Ljava/lang/String;)V
/*     */     //   1367: aload_1
/*     */     //   1368: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1371: invokevirtual 202	org/apache/coyote/Request:serverName	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   1374: invokevirtual 123	org/apache/tomcat/util/buf/MessageBytes:getCharChunk	()Lorg/apache/tomcat/util/buf/CharChunk;
/*     */     //   1377: astore 17
/*     */     //   1379: aload 17
/*     */     //   1381: invokevirtual 193	org/apache/tomcat/util/buf/CharChunk:recycle	()V
/*     */     //   1384: aload 17
/*     */     //   1386: aload 8
/*     */     //   1388: invokeinterface 127 1 0
/*     */     //   1393: invokevirtual 194	org/apache/tomcat/util/buf/CharChunk:append	(Ljava/lang/String;)V
/*     */     //   1396: aload_1
/*     */     //   1397: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1400: invokevirtual 202	org/apache/coyote/Request:serverName	()Lorg/apache/tomcat/util/buf/MessageBytes;
/*     */     //   1403: invokevirtual 122	org/apache/tomcat/util/buf/MessageBytes:toChars	()V
/*     */     //   1406: aload_1
/*     */     //   1407: invokevirtual 203	org/apache/catalina/connector/Request:getMappingData	()Lorg/apache/catalina/mapper/MappingData;
/*     */     //   1410: invokevirtual 204	org/apache/catalina/mapper/MappingData:recycle	()V
/*     */     //   1413: aload_1
/*     */     //   1414: invokevirtual 117	org/apache/catalina/connector/Request:getConnector	()Lorg/apache/catalina/connector/Connector;
/*     */     //   1417: astore 18
/*     */     //   1419: aload 18
/*     */     //   1421: invokevirtual 205	org/apache/catalina/connector/Connector:getProtocolHandler	()Lorg/apache/coyote/ProtocolHandler;
/*     */     //   1424: invokeinterface 206 1 0
/*     */     //   1429: aload_1
/*     */     //   1430: invokevirtual 190	org/apache/catalina/connector/Request:getCoyoteRequest	()Lorg/apache/coyote/Request;
/*     */     //   1433: aload_2
/*     */     //   1434: invokevirtual 207	org/apache/catalina/connector/Response:getCoyoteResponse	()Lorg/apache/coyote/Response;
/*     */     //   1437: invokeinterface 208 3 0
/*     */     //   1442: ifne +12 -> 1454
/*     */     //   1445: aload_0
/*     */     //   1446: getfield 5	org/apache/catalina/valves/rewrite/RewriteValve:invoked	Ljava/lang/ThreadLocal;
/*     */     //   1449: aconst_null
/*     */     //   1450: invokevirtual 114	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
/*     */     //   1453: return
/*     */     //   1454: goto +5 -> 1459
/*     */     //   1457: astore 19
/*     */     //   1459: aload 18
/*     */     //   1461: invokevirtual 210	org/apache/catalina/connector/Connector:getService	()Lorg/apache/catalina/Service;
/*     */     //   1464: invokeinterface 211 1 0
/*     */     //   1469: invokeinterface 212 1 0
/*     */     //   1474: astore 19
/*     */     //   1476: aload_1
/*     */     //   1477: aload 19
/*     */     //   1479: invokeinterface 213 1 0
/*     */     //   1484: invokevirtual 214	org/apache/catalina/connector/Request:setAsyncSupported	(Z)V
/*     */     //   1487: aload 19
/*     */     //   1489: invokeinterface 215 1 0
/*     */     //   1494: aload_1
/*     */     //   1495: aload_2
/*     */     //   1496: invokeinterface 110 3 0
/*     */     //   1501: goto +14 -> 1515
/*     */     //   1504: aload_0
/*     */     //   1505: invokevirtual 109	org/apache/catalina/valves/rewrite/RewriteValve:getNext	()Lorg/apache/catalina/Valve;
/*     */     //   1508: aload_1
/*     */     //   1509: aload_2
/*     */     //   1510: invokeinterface 110 3 0
/*     */     //   1515: aload_0
/*     */     //   1516: getfield 5	org/apache/catalina/valves/rewrite/RewriteValve:invoked	Ljava/lang/ThreadLocal;
/*     */     //   1519: aconst_null
/*     */     //   1520: invokevirtual 114	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
/*     */     //   1523: goto +16 -> 1539
/*     */     //   1526: astore 21
/*     */     //   1528: aload_0
/*     */     //   1529: getfield 5	org/apache/catalina/valves/rewrite/RewriteValve:invoked	Ljava/lang/ThreadLocal;
/*     */     //   1532: aconst_null
/*     */     //   1533: invokevirtual 114	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
/*     */     //   1536: aload 21
/*     */     //   1538: athrow
/*     */     //   1539: return
/*     */     // Line number table:
/*     */     //   Java source line #288	-> byte code offset #0
/*     */     //   Java source line #289	-> byte code offset #22
/*     */     //   Java source line #290	-> byte code offset #33
/*     */     //   Java source line #293	-> byte code offset #34
/*     */     //   Java source line #295	-> byte code offset #50
/*     */     //   Java source line #297	-> byte code offset #61
/*     */     //   Java source line #298	-> byte code offset #69
/*     */     //   Java source line #297	-> byte code offset #72
/*     */     //   Java source line #298	-> byte code offset #81
/*     */     //   Java source line #299	-> byte code offset #83
/*     */     //   Java source line #304	-> byte code offset #84
/*     */     //   Java source line #306	-> byte code offset #93
/*     */     //   Java source line #310	-> byte code offset #103
/*     */     //   Java source line #311	-> byte code offset #112
/*     */     //   Java source line #312	-> byte code offset #118
/*     */     //   Java source line #313	-> byte code offset #126
/*     */     //   Java source line #314	-> byte code offset #138
/*     */     //   Java source line #315	-> byte code offset #143
/*     */     //   Java source line #316	-> byte code offset #150
/*     */     //   Java source line #317	-> byte code offset #156
/*     */     //   Java source line #318	-> byte code offset #159
/*     */     //   Java source line #319	-> byte code offset #162
/*     */     //   Java source line #320	-> byte code offset #165
/*     */     //   Java source line #321	-> byte code offset #168
/*     */     //   Java source line #322	-> byte code offset #181
/*     */     //   Java source line #323	-> byte code offset #190
/*     */     //   Java source line #324	-> byte code offset #207
/*     */     //   Java source line #325	-> byte code offset #217
/*     */     //   Java source line #326	-> byte code offset #237
/*     */     //   Java source line #327	-> byte code offset #249
/*     */     //   Java source line #328	-> byte code offset #287
/*     */     //   Java source line #327	-> byte code offset #296
/*     */     //   Java source line #330	-> byte code offset #301
/*     */     //   Java source line #331	-> byte code offset #309
/*     */     //   Java source line #333	-> byte code offset #316
/*     */     //   Java source line #335	-> byte code offset #320
/*     */     //   Java source line #339	-> byte code offset #323
/*     */     //   Java source line #340	-> byte code offset #341
/*     */     //   Java source line #343	-> byte code offset #344
/*     */     //   Java source line #344	-> byte code offset #362
/*     */     //   Java source line #350	-> byte code offset #365
/*     */     //   Java source line #351	-> byte code offset #378
/*     */     //   Java source line #352	-> byte code offset #385
/*     */     //   Java source line #353	-> byte code offset #388
/*     */     //   Java source line #356	-> byte code offset #391
/*     */     //   Java source line #357	-> byte code offset #404
/*     */     //   Java source line #358	-> byte code offset #411
/*     */     //   Java source line #359	-> byte code offset #414
/*     */     //   Java source line #363	-> byte code offset #417
/*     */     //   Java source line #366	-> byte code offset #430
/*     */     //   Java source line #367	-> byte code offset #439
/*     */     //   Java source line #369	-> byte code offset #448
/*     */     //   Java source line #370	-> byte code offset #454
/*     */     //   Java source line #372	-> byte code offset #460
/*     */     //   Java source line #373	-> byte code offset #471
/*     */     //   Java source line #376	-> byte code offset #481
/*     */     //   Java source line #377	-> byte code offset #492
/*     */     //   Java source line #378	-> byte code offset #500
/*     */     //   Java source line #379	-> byte code offset #512
/*     */     //   Java source line #380	-> byte code offset #518
/*     */     //   Java source line #381	-> byte code offset #523
/*     */     //   Java source line #382	-> byte code offset #531
/*     */     //   Java source line #384	-> byte code offset #542
/*     */     //   Java source line #386	-> byte code offset #547
/*     */     //   Java source line #387	-> byte code offset #555
/*     */     //   Java source line #389	-> byte code offset #571
/*     */     //   Java source line #390	-> byte code offset #579
/*     */     //   Java source line #391	-> byte code offset #590
/*     */     //   Java source line #394	-> byte code offset #602
/*     */     //   Java source line #396	-> byte code offset #613
/*     */     //   Java source line #397	-> byte code offset #621
/*     */     //   Java source line #401	-> byte code offset #640
/*     */     //   Java source line #402	-> byte code offset #645
/*     */     //   Java source line #403	-> byte code offset #653
/*     */     //   Java source line #404	-> byte code offset #662
/*     */     //   Java source line #403	-> byte code offset #665
/*     */     //   Java source line #411	-> byte code offset #669
/*     */     //   Java source line #412	-> byte code offset #689
/*     */     //   Java source line #413	-> byte code offset #695
/*     */     //   Java source line #415	-> byte code offset #711
/*     */     //   Java source line #416	-> byte code offset #719
/*     */     //   Java source line #417	-> byte code offset #722
/*     */     //   Java source line #416	-> byte code offset #730
/*     */     //   Java source line #419	-> byte code offset #736
/*     */     //   Java source line #421	-> byte code offset #745
/*     */     //   Java source line #422	-> byte code offset #754
/*     */     //   Java source line #423	-> byte code offset #757
/*     */     //   Java source line #429	-> byte code offset #760
/*     */     //   Java source line #430	-> byte code offset #773
/*     */     //   Java source line #431	-> byte code offset #784
/*     */     //   Java source line #432	-> byte code offset #792
/*     */     //   Java source line #433	-> byte code offset #802
/*     */     //   Java source line #434	-> byte code offset #812
/*     */     //   Java source line #435	-> byte code offset #822
/*     */     //   Java source line #436	-> byte code offset #832
/*     */     //   Java source line #437	-> byte code offset #842
/*     */     //   Java source line #440	-> byte code offset #848
/*     */     //   Java source line #441	-> byte code offset #861
/*     */     //   Java source line #442	-> byte code offset #874
/*     */     //   Java source line #441	-> byte code offset #892
/*     */     //   Java source line #447	-> byte code offset #898
/*     */     //   Java source line #448	-> byte code offset #911
/*     */     //   Java source line #454	-> byte code offset #920
/*     */     //   Java source line #455	-> byte code offset #933
/*     */     //   Java source line #456	-> byte code offset #947
/*     */     //   Java source line #457	-> byte code offset #960
/*     */     //   Java source line #458	-> byte code offset #964
/*     */     //   Java source line #455	-> byte code offset #967
/*     */     //   Java source line #461	-> byte code offset #973
/*     */     //   Java source line #464	-> byte code offset #976
/*     */     //   Java source line #465	-> byte code offset #989
/*     */     //   Java source line #468	-> byte code offset #992
/*     */     //   Java source line #469	-> byte code offset #1005
/*     */     //   Java source line #470	-> byte code offset #1008
/*     */     //   Java source line #473	-> byte code offset #1011
/*     */     //   Java source line #474	-> byte code offset #1016
/*     */     //   Java source line #321	-> byte code offset #1026
/*     */     //   Java source line #479	-> byte code offset #1032
/*     */     //   Java source line #480	-> byte code offset #1037
/*     */     //   Java source line #482	-> byte code offset #1042
/*     */     //   Java source line #483	-> byte code offset #1051
/*     */     //   Java source line #484	-> byte code offset #1054
/*     */     //   Java source line #485	-> byte code offset #1063
/*     */     //   Java source line #486	-> byte code offset #1069
/*     */     //   Java source line #487	-> byte code offset #1080
/*     */     //   Java source line #490	-> byte code offset #1090
/*     */     //   Java source line #491	-> byte code offset #1093
/*     */     //   Java source line #492	-> byte code offset #1100
/*     */     //   Java source line #495	-> byte code offset #1106
/*     */     //   Java source line #496	-> byte code offset #1117
/*     */     //   Java source line #497	-> byte code offset #1129
/*     */     //   Java source line #498	-> byte code offset #1134
/*     */     //   Java source line #500	-> byte code offset #1141
/*     */     //   Java source line #502	-> byte code offset #1148
/*     */     //   Java source line #503	-> byte code offset #1163
/*     */     //   Java source line #506	-> byte code offset #1173
/*     */     //   Java source line #507	-> byte code offset #1180
/*     */     //   Java source line #508	-> byte code offset #1191
/*     */     //   Java source line #509	-> byte code offset #1203
/*     */     //   Java source line #510	-> byte code offset #1208
/*     */     //   Java source line #512	-> byte code offset #1215
/*     */     //   Java source line #514	-> byte code offset #1229
/*     */     //   Java source line #515	-> byte code offset #1236
/*     */     //   Java source line #517	-> byte code offset #1246
/*     */     //   Java source line #518	-> byte code offset #1251
/*     */     //   Java source line #519	-> byte code offset #1262
/*     */     //   Java source line #520	-> byte code offset #1274
/*     */     //   Java source line #521	-> byte code offset #1279
/*     */     //   Java source line #522	-> byte code offset #1294
/*     */     //   Java source line #523	-> byte code offset #1306
/*     */     //   Java source line #524	-> byte code offset #1312
/*     */     //   Java source line #525	-> byte code offset #1319
/*     */     //   Java source line #527	-> byte code offset #1326
/*     */     //   Java source line #528	-> byte code offset #1334
/*     */     //   Java source line #532	-> byte code offset #1344
/*     */     //   Java source line #533	-> byte code offset #1356
/*     */     //   Java source line #534	-> byte code offset #1367
/*     */     //   Java source line #535	-> byte code offset #1379
/*     */     //   Java source line #536	-> byte code offset #1384
/*     */     //   Java source line #537	-> byte code offset #1396
/*     */     //   Java source line #539	-> byte code offset #1406
/*     */     //   Java source line #541	-> byte code offset #1413
/*     */     //   Java source line #543	-> byte code offset #1419
/*     */     //   Java source line #544	-> byte code offset #1430
/*     */     //   Java source line #543	-> byte code offset #1437
/*     */     //   Java source line #559	-> byte code offset #1445
/*     */     //   Java source line #545	-> byte code offset #1453
/*     */     //   Java source line #549	-> byte code offset #1454
/*     */     //   Java source line #547	-> byte code offset #1457
/*     */     //   Java source line #550	-> byte code offset #1459
/*     */     //   Java source line #551	-> byte code offset #1476
/*     */     //   Java source line #552	-> byte code offset #1487
/*     */     //   Java source line #553	-> byte code offset #1501
/*     */     //   Java source line #555	-> byte code offset #1504
/*     */     //   Java source line #559	-> byte code offset #1515
/*     */     //   Java source line #560	-> byte code offset #1523
/*     */     //   Java source line #559	-> byte code offset #1526
/*     */     //   Java source line #560	-> byte code offset #1536
/*     */     //   Java source line #562	-> byte code offset #1539
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	1540	0	this	RewriteValve
/*     */     //   0	1540	1	request	org.apache.catalina.connector.Request
/*     */     //   0	1540	2	response	org.apache.catalina.connector.Response
/*     */     //   72	10	3	localObject1	Object
/*     */     //   92	120	3	resolver	Object
/*     */     //   110	1177	4	uriCharset	java.nio.charset.Charset
/*     */     //   116	1206	5	originalQueryStringEncoded	String
/*     */     //   136	8	6	urlMB	org.apache.tomcat.util.buf.MessageBytes
/*     */     //   148	895	7	urlDecoded	CharSequence
/*     */     //   154	1233	8	host	CharSequence
/*     */     //   157	876	9	rewritten	boolean
/*     */     //   160	878	10	done	boolean
/*     */     //   163	1132	11	qsa	boolean
/*     */     //   166	335	12	qsd	boolean
/*     */     //   169	858	13	i	int
/*     */     //   1049	183	13	urlStringDecoded	String
/*     */     //   188	831	14	rule	RewriteRule
/*     */     //   1052	233	14	queryStringDecoded	String
/*     */     //   205	61	15	test	CharSequence
/*     */     //   1061	23	15	queryIndex	int
/*     */     //   215	797	16	newtest	CharSequence
/*     */     //   1091	53	16	contextPath	String
/*     */     //   437	52	17	urlStringDecoded	String
/*     */     //   790	54	17	cookie	javax.servlet.http.Cookie
/*     */     //   862	31	17	j	int
/*     */     //   935	33	17	j	int
/*     */     //   1127	258	17	chunk	org.apache.tomcat.util.buf.CharChunk
/*     */     //   446	159	18	index	int
/*     */     //   1417	43	18	connector	org.apache.catalina.connector.Connector
/*     */     //   455	3	19	rewrittenQueryStringDecoded	String
/*     */     //   469	190	19	rewrittenQueryStringDecoded	String
/*     */     //   1457	1	19	localException	Exception
/*     */     //   1474	14	19	pipeline	org.apache.catalina.Pipeline
/*     */     //   498	240	20	urlStringEncoded	StringBuilder
/*     */     //   1526	11	21	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   50	61	72	finally
/*     */     //   1419	1445	1457	java/lang/Exception
/*     */     //   84	1445	1526	finally
/*     */     //   1454	1515	1526	finally
/*     */     //   1526	1528	1526	finally
/*     */   }
/*     */   
/*     */   public static Object parse(String line)
/*     */   {
/* 575 */     QuotedStringTokenizer tokenizer = new QuotedStringTokenizer(line);
/* 576 */     if (tokenizer.hasMoreTokens()) {
/* 577 */       String token = tokenizer.nextToken();
/* 578 */       if (token.equals("RewriteCond"))
/*     */       {
/* 580 */         RewriteCond condition = new RewriteCond();
/* 581 */         if (tokenizer.countTokens() < 2) {
/* 582 */           throw new IllegalArgumentException(sm.getString("rewriteValve.invalidLine", new Object[] { line }));
/*     */         }
/* 584 */         condition.setTestString(tokenizer.nextToken());
/* 585 */         condition.setCondPattern(tokenizer.nextToken());
/* 586 */         if (tokenizer.hasMoreTokens()) {
/* 587 */           String flags = tokenizer.nextToken();
/* 588 */           condition.setFlagsString(flags);
/* 589 */           if ((flags.startsWith("[")) && (flags.endsWith("]"))) {
/* 590 */             flags = flags.substring(1, flags.length() - 1);
/*     */           }
/* 592 */           StringTokenizer flagsTokenizer = new StringTokenizer(flags, ",");
/* 593 */           while (flagsTokenizer.hasMoreElements()) {
/* 594 */             parseCondFlag(line, condition, flagsTokenizer.nextToken());
/*     */           }
/*     */         }
/* 597 */         return condition; }
/* 598 */       if (token.equals("RewriteRule"))
/*     */       {
/* 600 */         RewriteRule rule = new RewriteRule();
/* 601 */         if (tokenizer.countTokens() < 2) {
/* 602 */           throw new IllegalArgumentException(sm.getString("rewriteValve.invalidLine", new Object[] { line }));
/*     */         }
/* 604 */         rule.setPatternString(tokenizer.nextToken());
/* 605 */         rule.setSubstitutionString(tokenizer.nextToken());
/* 606 */         if (tokenizer.hasMoreTokens()) {
/* 607 */           String flags = tokenizer.nextToken();
/* 608 */           rule.setFlagsString(flags);
/* 609 */           if ((flags.startsWith("[")) && (flags.endsWith("]"))) {
/* 610 */             flags = flags.substring(1, flags.length() - 1);
/*     */           }
/* 612 */           StringTokenizer flagsTokenizer = new StringTokenizer(flags, ",");
/* 613 */           while (flagsTokenizer.hasMoreElements()) {
/* 614 */             parseRuleFlag(line, rule, flagsTokenizer.nextToken());
/*     */           }
/*     */         }
/* 617 */         return rule; }
/* 618 */       if (token.equals("RewriteMap"))
/*     */       {
/*     */ 
/* 621 */         if (tokenizer.countTokens() < 2) {
/* 622 */           throw new IllegalArgumentException(sm.getString("rewriteValve.invalidLine", new Object[] { line }));
/*     */         }
/* 624 */         String name = tokenizer.nextToken();
/* 625 */         String rewriteMapClassName = tokenizer.nextToken();
/* 626 */         RewriteMap map = null;
/* 627 */         if (rewriteMapClassName.startsWith("int:")) {
/* 628 */           map = InternalRewriteMap.toMap(rewriteMapClassName.substring("int:".length()));
/* 629 */         } else if (rewriteMapClassName.startsWith("prg:")) {
/* 630 */           rewriteMapClassName = rewriteMapClassName.substring("prg:".length());
/*     */         }
/* 632 */         if (map == null) {
/*     */           try
/*     */           {
/* 635 */             map = (RewriteMap)Class.forName(rewriteMapClassName).getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */           } catch (Exception e) {
/* 637 */             throw new IllegalArgumentException(sm.getString("rewriteValve.invalidMapClassName", new Object[] { line }));
/*     */           }
/*     */         }
/* 640 */         if (tokenizer.hasMoreTokens()) {
/* 641 */           if (tokenizer.countTokens() == 1) {
/* 642 */             map.setParameters(tokenizer.nextToken());
/*     */           } else {
/* 644 */             List<String> params = new ArrayList();
/* 645 */             while (tokenizer.hasMoreTokens()) {
/* 646 */               params.add(tokenizer.nextToken());
/*     */             }
/* 648 */             map.setParameters((String[])params.toArray(new String[0]));
/*     */           }
/*     */         }
/* 651 */         return new Object[] { name, map }; }
/* 652 */       if (!token.startsWith("#"))
/*     */       {
/*     */ 
/* 655 */         throw new IllegalArgumentException(sm.getString("rewriteValve.invalidLine", new Object[] { line }));
/*     */       }
/*     */     }
/* 658 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void parseCondFlag(String line, RewriteCond condition, String flag)
/*     */   {
/* 669 */     if ((flag.equals("NC")) || (flag.equals("nocase"))) {
/* 670 */       condition.setNocase(true);
/* 671 */     } else if ((flag.equals("OR")) || (flag.equals("ornext"))) {
/* 672 */       condition.setOrnext(true);
/*     */     } else {
/* 674 */       throw new IllegalArgumentException(sm.getString("rewriteValve.invalidFlags", new Object[] { line, flag }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void parseRuleFlag(String line, RewriteRule rule, String flag)
/*     */   {
/* 686 */     if (flag.equals("B")) {
/* 687 */       rule.setEscapeBackReferences(true);
/* 688 */     } else if ((flag.equals("chain")) || (flag.equals("C"))) {
/* 689 */       rule.setChain(true);
/* 690 */     } else if ((flag.startsWith("cookie=")) || (flag.startsWith("CO="))) {
/* 691 */       rule.setCookie(true);
/* 692 */       if (flag.startsWith("cookie")) {
/* 693 */         flag = flag.substring("cookie=".length());
/* 694 */       } else if (flag.startsWith("CO=")) {
/* 695 */         flag = flag.substring("CO=".length());
/*     */       }
/* 697 */       StringTokenizer tokenizer = new StringTokenizer(flag, ":");
/* 698 */       if (tokenizer.countTokens() < 2) {
/* 699 */         throw new IllegalArgumentException(sm.getString("rewriteValve.invalidFlags", new Object[] { line, flag }));
/*     */       }
/* 701 */       rule.setCookieName(tokenizer.nextToken());
/* 702 */       rule.setCookieValue(tokenizer.nextToken());
/* 703 */       if (tokenizer.hasMoreTokens()) {
/* 704 */         rule.setCookieDomain(tokenizer.nextToken());
/*     */       }
/* 706 */       if (tokenizer.hasMoreTokens()) {
/*     */         try {
/* 708 */           rule.setCookieLifetime(Integer.parseInt(tokenizer.nextToken()));
/*     */         } catch (NumberFormatException ???) {
/* 710 */           throw new IllegalArgumentException(sm.getString("rewriteValve.invalidFlags", new Object[] { line, flag }), ???);
/*     */         }
/*     */       }
/* 713 */       if (tokenizer.hasMoreTokens()) {
/* 714 */         rule.setCookiePath(tokenizer.nextToken());
/*     */       }
/* 716 */       if (tokenizer.hasMoreTokens()) {
/* 717 */         rule.setCookieSecure(Boolean.parseBoolean(tokenizer.nextToken()));
/*     */       }
/* 719 */       if (tokenizer.hasMoreTokens()) {
/* 720 */         rule.setCookieHttpOnly(Boolean.parseBoolean(tokenizer.nextToken()));
/*     */       }
/* 722 */     } else if ((flag.startsWith("env=")) || (flag.startsWith("E="))) {
/* 723 */       rule.setEnv(true);
/* 724 */       if (flag.startsWith("env=")) {
/* 725 */         flag = flag.substring("env=".length());
/* 726 */       } else if (flag.startsWith("E=")) {
/* 727 */         flag = flag.substring("E=".length());
/*     */       }
/* 729 */       int pos = flag.indexOf(':');
/* 730 */       if ((pos == -1) || (pos + 1 == flag.length())) {
/* 731 */         throw new IllegalArgumentException(sm.getString("rewriteValve.invalidFlags", new Object[] { line, flag }));
/*     */       }
/* 733 */       rule.addEnvName(flag.substring(0, pos));
/* 734 */       rule.addEnvValue(flag.substring(pos + 1));
/* 735 */     } else if ((flag.startsWith("forbidden")) || (flag.startsWith("F"))) {
/* 736 */       rule.setForbidden(true);
/* 737 */     } else if ((flag.startsWith("gone")) || (flag.startsWith("G"))) {
/* 738 */       rule.setGone(true);
/* 739 */     } else if ((flag.startsWith("host")) || (flag.startsWith("H"))) {
/* 740 */       rule.setHost(true);
/* 741 */     } else if ((flag.startsWith("last")) || (flag.startsWith("L"))) {
/* 742 */       rule.setLast(true);
/* 743 */     } else if ((flag.startsWith("nocase")) || (flag.startsWith("NC"))) {
/* 744 */       rule.setNocase(true);
/* 745 */     } else if ((flag.startsWith("noescape")) || (flag.startsWith("NE"))) {
/* 746 */       rule.setNoescape(true);
/* 747 */     } else if ((flag.startsWith("next")) || (flag.startsWith("N"))) {
/* 748 */       rule.setNext(true);
/*     */ 
/*     */     }
/* 751 */     else if ((flag.startsWith("qsappend")) || (flag.startsWith("QSA"))) {
/* 752 */       rule.setQsappend(true);
/* 753 */     } else if ((flag.startsWith("qsdiscard")) || (flag.startsWith("QSD"))) {
/* 754 */       rule.setQsdiscard(true);
/* 755 */     } else if ((flag.startsWith("redirect")) || (flag.startsWith("R"))) {
/* 756 */       rule.setRedirect(true);
/* 757 */       int redirectCode = 302;
/* 758 */       if ((flag.startsWith("redirect=")) || (flag.startsWith("R="))) {
/* 759 */         if (flag.startsWith("redirect=")) {
/* 760 */           flag = flag.substring("redirect=".length());
/* 761 */         } else if (flag.startsWith("R=")) {
/* 762 */           flag = flag.substring("R=".length());
/*     */         }
/* 764 */         switch (flag) {
/*     */         case "temp": 
/* 766 */           redirectCode = 302;
/* 767 */           break;
/*     */         case "permanent": 
/* 769 */           redirectCode = 301;
/* 770 */           break;
/*     */         case "seeother": 
/* 772 */           redirectCode = 303;
/* 773 */           break;
/*     */         default: 
/* 775 */           redirectCode = Integer.parseInt(flag);
/*     */         }
/*     */         
/*     */       }
/* 779 */       rule.setRedirectCode(redirectCode);
/* 780 */     } else if ((flag.startsWith("skip")) || (flag.startsWith("S"))) {
/* 781 */       if (flag.startsWith("skip=")) {
/* 782 */         flag = flag.substring("skip=".length());
/* 783 */       } else if (flag.startsWith("S=")) {
/* 784 */         flag = flag.substring("S=".length());
/*     */       }
/* 786 */       rule.setSkip(Integer.parseInt(flag));
/* 787 */     } else if ((flag.startsWith("type")) || (flag.startsWith("T"))) {
/* 788 */       if (flag.startsWith("type=")) {
/* 789 */         flag = flag.substring("type=".length());
/* 790 */       } else if (flag.startsWith("T=")) {
/* 791 */         flag = flag.substring("T=".length());
/*     */       }
/* 793 */       rule.setType(true);
/* 794 */       rule.setTypeValue(flag);
/*     */     } else {
/* 796 */       throw new IllegalArgumentException(sm.getString("rewriteValve.invalidFlags", new Object[] { line, flag }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\rewrite\RewriteValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */