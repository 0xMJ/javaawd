/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.net.InetAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.rmi.AccessException;
/*     */ import java.rmi.AlreadyBoundException;
/*     */ import java.rmi.NotBoundException;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.server.RMIClientSocketFactory;
/*     */ import java.rmi.server.RMIServerSocketFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.management.remote.JMXConnectorServer;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import javax.management.remote.rmi.RMIConnectorServer;
/*     */ import javax.management.remote.rmi.RMIJRMPServerImpl;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLServerSocket;
/*     */ import javax.net.ssl.SSLServerSocketFactory;
/*     */ import javax.net.ssl.SSLSessionContext;
/*     */ import javax.rmi.ssl.SslRMIClientSocketFactory;
/*     */ import javax.rmi.ssl.SslRMIServerSocketFactory;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.net.SSLHostConfig;
/*     */ import org.apache.tomcat.util.net.SSLHostConfig.CertificateVerification;
/*     */ import org.apache.tomcat.util.net.SSLHostConfigCertificate;
/*     */ import org.apache.tomcat.util.net.jsse.JSSEUtil;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import sun.rmi.registry.RegistryImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class JmxRemoteLifecycleListener
/*     */   extends SSLHostConfig
/*     */   implements LifecycleListener
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  75 */   private static final Log log = LogFactory.getLog(JmxRemoteLifecycleListener.class);
/*     */   
/*     */ 
/*  78 */   protected static final StringManager sm = StringManager.getManager(JmxRemoteLifecycleListener.class);
/*     */   
/*  80 */   protected String rmiBindAddress = null;
/*  81 */   protected int rmiRegistryPortPlatform = -1;
/*  82 */   protected int rmiServerPortPlatform = -1;
/*  83 */   protected boolean rmiRegistrySSL = true;
/*  84 */   protected boolean rmiServerSSL = true;
/*  85 */   protected boolean authenticate = true;
/*  86 */   protected String passwordFile = null;
/*  87 */   protected String loginModuleName = null;
/*  88 */   protected String accessFile = null;
/*  89 */   protected boolean useLocalPorts = false;
/*     */   
/*  91 */   protected transient JMXConnectorServer csPlatform = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRmiBindAddress()
/*     */   {
/*  98 */     return this.rmiBindAddress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRmiBindAddress(String theRmiBindAddress)
/*     */   {
/* 106 */     this.rmiBindAddress = theRmiBindAddress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRmiServerPortPlatform()
/*     */   {
/* 115 */     return this.rmiServerPortPlatform;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRmiServerPortPlatform(int theRmiServerPortPlatform)
/*     */   {
/* 124 */     this.rmiServerPortPlatform = theRmiServerPortPlatform;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRmiRegistryPortPlatform()
/*     */   {
/* 132 */     return this.rmiRegistryPortPlatform;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRmiRegistryPortPlatform(int theRmiRegistryPortPlatform)
/*     */   {
/* 140 */     this.rmiRegistryPortPlatform = theRmiRegistryPortPlatform;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getUseLocalPorts()
/*     */   {
/* 150 */     return this.useLocalPorts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseLocalPorts(boolean useLocalPorts)
/*     */   {
/* 161 */     this.useLocalPorts = useLocalPorts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isRmiRegistrySSL()
/*     */   {
/* 168 */     return this.rmiRegistrySSL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRmiRegistrySSL(boolean rmiRegistrySSL)
/*     */   {
/* 175 */     this.rmiRegistrySSL = rmiRegistrySSL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isRmiServerSSL()
/*     */   {
/* 182 */     return this.rmiServerSSL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRmiServerSSL(boolean rmiServerSSL)
/*     */   {
/* 189 */     this.rmiServerSSL = rmiServerSSL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isAuthenticate()
/*     */   {
/* 196 */     return this.authenticate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAuthenticate(boolean authenticate)
/*     */   {
/* 203 */     this.authenticate = authenticate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getPasswordFile()
/*     */   {
/* 210 */     return this.passwordFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPasswordFile(String passwordFile)
/*     */   {
/* 217 */     this.passwordFile = passwordFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getLoginModuleName()
/*     */   {
/* 224 */     return this.loginModuleName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLoginModuleName(String loginModuleName)
/*     */   {
/* 231 */     this.loginModuleName = loginModuleName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getAccessFile()
/*     */   {
/* 238 */     return this.accessFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAccessFile(String accessFile)
/*     */   {
/* 245 */     this.accessFile = accessFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void init()
/*     */   {
/* 252 */     String rmiRegistrySSLValue = System.getProperty("com.sun.management.jmxremote.registry.ssl");
/* 253 */     if (rmiRegistrySSLValue != null) {
/* 254 */       setRmiRegistrySSL(Boolean.parseBoolean(rmiRegistrySSLValue));
/*     */     }
/*     */     
/* 257 */     String rmiServerSSLValue = System.getProperty("com.sun.management.jmxremote.ssl");
/* 258 */     if (rmiServerSSLValue != null) {
/* 259 */       setRmiServerSSL(Boolean.parseBoolean(rmiServerSSLValue));
/*     */     }
/*     */     
/* 262 */     String protocolsValue = System.getProperty("com.sun.management.jmxremote.ssl.enabled.protocols");
/* 263 */     if (protocolsValue != null) {
/* 264 */       setEnabledProtocols(protocolsValue.split(","));
/*     */     }
/*     */     
/* 267 */     String ciphersValue = System.getProperty("com.sun.management.jmxremote.ssl.enabled.cipher.suites");
/* 268 */     if (ciphersValue != null) {
/* 269 */       setCiphers(ciphersValue);
/*     */     }
/*     */     
/* 272 */     String clientAuthValue = System.getProperty("com.sun.management.jmxremote.ssl.need.client.auth");
/* 273 */     if (clientAuthValue != null) {
/* 274 */       setCertificateVerification(clientAuthValue);
/*     */     }
/*     */     
/* 277 */     String authenticateValue = System.getProperty("com.sun.management.jmxremote.authenticate");
/* 278 */     if (authenticateValue != null) {
/* 279 */       setAuthenticate(Boolean.parseBoolean(authenticateValue));
/*     */     }
/*     */     
/* 282 */     String passwordFileValue = System.getProperty("com.sun.management.jmxremote.password.file");
/* 283 */     if (passwordFileValue != null) {
/* 284 */       setPasswordFile(passwordFileValue);
/*     */     }
/*     */     
/* 287 */     String accessFileValue = System.getProperty("com.sun.management.jmxremote.access.file");
/* 288 */     if (accessFileValue != null) {
/* 289 */       setAccessFile(accessFileValue);
/*     */     }
/*     */     
/* 292 */     String loginModuleNameValue = System.getProperty("com.sun.management.jmxremote.login.config");
/* 293 */     if (loginModuleNameValue != null) {
/* 294 */       setLoginModuleName(loginModuleNameValue);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void lifecycleEvent(LifecycleEvent event)
/*     */   {
/* 301 */     if ("before_init".equals(event.getType())) {
/* 302 */       log.warn(sm.getString("jmxRemoteLifecycleListener.deprecated"));
/* 303 */     } else if ("start".equals(event.getType()))
/*     */     {
/*     */ 
/*     */ 
/* 307 */       init();
/*     */       
/* 309 */       SSLContext sslContext = null;
/*     */       
/* 311 */       if (getCertificates().size() > 0) {
/* 312 */         SSLHostConfigCertificate certificate = (SSLHostConfigCertificate)getCertificates().iterator().next();
/*     */         
/* 314 */         JSSEUtil sslUtil = new JSSEUtil(certificate);
/*     */         try {
/* 316 */           sslContext = SSLContext.getInstance(getSslProtocol());
/* 317 */           setEnabledProtocols(sslUtil.getEnabledProtocols());
/* 318 */           setEnabledCiphers(sslUtil.getEnabledCiphers());
/* 319 */           sslContext.init(sslUtil.getKeyManagers(), sslUtil.getTrustManagers(), null);
/* 320 */           SSLSessionContext sessionContext = sslContext.getServerSessionContext();
/* 321 */           if (sessionContext != null) {
/* 322 */             sslUtil.configureSessionContext(sessionContext);
/*     */           }
/*     */         } catch (Exception e) {
/* 325 */           log.error(sm.getString("jmxRemoteLifecycleListener.invalidSSLConfiguration"), e);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 330 */       System.setProperty("java.rmi.server.randomIDs", "true");
/*     */       
/*     */ 
/* 333 */       Map<String, Object> env = new HashMap();
/*     */       
/* 335 */       RMIClientSocketFactory registryCsf = null;
/* 336 */       RMIServerSocketFactory registrySsf = null;
/*     */       
/* 338 */       RMIClientSocketFactory serverCsf = null;
/* 339 */       RMIServerSocketFactory serverSsf = null;
/*     */       
/*     */ 
/* 342 */       if (this.rmiRegistrySSL) {
/* 343 */         registryCsf = new SslRMIClientSocketFactory();
/* 344 */         if (this.rmiBindAddress == null)
/*     */         {
/*     */ 
/* 347 */           registrySsf = new SslRMIServerSocketFactory(sslContext, getEnabledCiphers(), getEnabledProtocols(), getCertificateVerification() == SSLHostConfig.CertificateVerification.REQUIRED);
/*     */         }
/*     */         else
/*     */         {
/* 351 */           registrySsf = new SslRmiServerBindSocketFactory(sslContext, getEnabledCiphers(), getEnabledProtocols(), getCertificateVerification() == SSLHostConfig.CertificateVerification.REQUIRED, this.rmiBindAddress);
/*     */         }
/*     */         
/*     */       }
/* 355 */       else if (this.rmiBindAddress != null) {
/* 356 */         registrySsf = new RmiServerBindSocketFactory(this.rmiBindAddress);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 361 */       if (this.rmiServerSSL) {
/* 362 */         serverCsf = new SslRMIClientSocketFactory();
/* 363 */         if (this.rmiBindAddress == null)
/*     */         {
/*     */ 
/* 366 */           serverSsf = new SslRMIServerSocketFactory(sslContext, getEnabledCiphers(), getEnabledProtocols(), getCertificateVerification() == SSLHostConfig.CertificateVerification.REQUIRED);
/*     */         }
/*     */         else
/*     */         {
/* 370 */           serverSsf = new SslRmiServerBindSocketFactory(sslContext, getEnabledCiphers(), getEnabledProtocols(), getCertificateVerification() == SSLHostConfig.CertificateVerification.REQUIRED, this.rmiBindAddress);
/*     */         }
/*     */         
/*     */       }
/* 374 */       else if (this.rmiBindAddress != null) {
/* 375 */         serverSsf = new RmiServerBindSocketFactory(this.rmiBindAddress);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 382 */       if (this.rmiBindAddress != null) {
/* 383 */         System.setProperty("java.rmi.server.hostname", this.rmiBindAddress);
/*     */       }
/*     */       
/*     */ 
/* 387 */       if (this.useLocalPorts) {
/* 388 */         registryCsf = new RmiClientLocalhostSocketFactory(registryCsf);
/* 389 */         serverCsf = new RmiClientLocalhostSocketFactory(serverCsf);
/*     */       }
/*     */       
/* 392 */       env.put("jmx.remote.rmi.server.credential.types", new String[] {String[].class
/* 393 */         .getName(), String.class
/* 394 */         .getName() });
/*     */       
/*     */ 
/* 397 */       if (serverCsf != null) {
/* 398 */         env.put("jmx.remote.rmi.client.socket.factory", serverCsf);
/* 399 */         env.put("com.sun.jndi.rmi.factory.socket", registryCsf);
/*     */       }
/* 401 */       if (serverSsf != null) {
/* 402 */         env.put("jmx.remote.rmi.server.socket.factory", serverSsf);
/*     */       }
/*     */       
/*     */ 
/* 406 */       if (this.authenticate) {
/* 407 */         env.put("jmx.remote.x.password.file", this.passwordFile);
/* 408 */         env.put("jmx.remote.x.access.file", this.accessFile);
/* 409 */         env.put("jmx.remote.x.login.config", this.loginModuleName);
/*     */       }
/*     */       
/*     */ 
/* 413 */       this.csPlatform = createServer("Platform", this.rmiBindAddress, this.rmiRegistryPortPlatform, this.rmiServerPortPlatform, env, registryCsf, registrySsf, serverCsf, serverSsf);
/*     */ 
/*     */     }
/* 416 */     else if ("stop".equals(event.getType())) {
/* 417 */       destroyServer("Platform", this.csPlatform);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JMXConnectorServer createServer(String serverName, String bindAddress, int theRmiRegistryPort, int theRmiServerPort, Map<String, Object> theEnv, RMIClientSocketFactory registryCsf, RMIServerSocketFactory registrySsf, RMIClientSocketFactory serverCsf, RMIServerSocketFactory serverSsf)
/*     */   {
/* 428 */     if (bindAddress == null) {
/* 429 */       bindAddress = "localhost";
/*     */     }
/*     */     
/* 432 */     String url = "service:jmx:rmi://" + bindAddress;
/*     */     try
/*     */     {
/* 435 */       serviceUrl = new JMXServiceURL(url);
/*     */     } catch (MalformedURLException e) { JMXServiceURL serviceUrl;
/* 437 */       log.error(sm.getString("jmxRemoteLifecycleListener.invalidURL", new Object[] { serverName, url }), e);
/* 438 */       return null;
/*     */     }
/*     */     JMXServiceURL serviceUrl;
/* 441 */     RMIConnectorServer cs = null;
/*     */     try {
/* 443 */       RMIJRMPServerImpl server = new RMIJRMPServerImpl(this.rmiServerPortPlatform, serverCsf, serverSsf, theEnv);
/*     */       
/*     */ 
/* 446 */       cs = new RMIConnectorServer(serviceUrl, theEnv, server, ManagementFactory.getPlatformMBeanServer());
/* 447 */       cs.start();
/* 448 */       Remote jmxServer = server.toStub();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 457 */         JmxRegistry localJmxRegistry = new JmxRegistry(theRmiRegistryPort, registryCsf, registrySsf, "jmxrmi", jmxServer);
/*     */       } catch (RemoteException e) {
/* 459 */         log.error(sm.getString("jmxRemoteLifecycleListener.createRegistryFailed", new Object[] { serverName, 
/*     */         
/* 461 */           Integer.toString(theRmiRegistryPort) }), e);
/* 462 */         return null;
/*     */       }
/* 464 */       log.info(sm.getString("jmxRemoteLifecycleListener.start", new Object[] {
/* 465 */         Integer.toString(theRmiRegistryPort), 
/* 466 */         Integer.toString(theRmiServerPort), serverName }));
/*     */     } catch (IOException e) {
/* 468 */       log.error(sm.getString("jmxRemoteLifecycleListener.createServerFailed", new Object[] { serverName }), e);
/*     */     }
/*     */     
/*     */ 
/* 472 */     return cs;
/*     */   }
/*     */   
/*     */ 
/*     */   private void destroyServer(String serverName, JMXConnectorServer theConnectorServer)
/*     */   {
/* 478 */     if (theConnectorServer != null) {
/*     */       try {
/* 480 */         theConnectorServer.stop();
/*     */       } catch (IOException e) {
/* 482 */         log.error(sm.getString("jmxRemoteLifecycleListener.destroyServerFailed", new Object[] { serverName }), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class RmiClientLocalhostSocketFactory
/*     */     implements RMIClientSocketFactory, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private static final String FORCED_HOST = "localhost";
/*     */     
/*     */     private final RMIClientSocketFactory factory;
/*     */     
/*     */ 
/*     */     public RmiClientLocalhostSocketFactory(RMIClientSocketFactory theFactory)
/*     */     {
/* 500 */       this.factory = theFactory;
/*     */     }
/*     */     
/*     */     public Socket createSocket(String host, int port) throws IOException
/*     */     {
/* 505 */       if (this.factory == null) {
/* 506 */         return new Socket("localhost", port);
/*     */       }
/* 508 */       return this.factory.createSocket("localhost", port);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class RmiServerBindSocketFactory
/*     */     implements RMIServerSocketFactory
/*     */   {
/*     */     private final InetAddress bindAddress;
/*     */     
/*     */     public RmiServerBindSocketFactory(String address)
/*     */     {
/* 519 */       InetAddress bindAddress = null;
/*     */       try {
/* 521 */         bindAddress = InetAddress.getByName(address);
/*     */       } catch (UnknownHostException e) {
/* 523 */         JmxRemoteLifecycleListener.log.error(JmxRemoteLifecycleListener.sm.getString("jmxRemoteLifecycleListener.invalidRmiBindAddress", new Object[] { address }), e);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 528 */       this.bindAddress = bindAddress;
/*     */     }
/*     */     
/*     */     public ServerSocket createServerSocket(int port) throws IOException
/*     */     {
/* 533 */       return new ServerSocket(port, 0, this.bindAddress);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SslRmiServerBindSocketFactory
/*     */     extends SslRMIServerSocketFactory
/*     */   {
/*     */     private final InetAddress bindAddress;
/*     */     private final SSLContext sslContext;
/*     */     
/*     */     public SslRmiServerBindSocketFactory(SSLContext sslContext, String[] enabledCipherSuites, String[] enabledProtocols, boolean needClientAuth, String address)
/*     */     {
/* 545 */       super(enabledCipherSuites, enabledProtocols, needClientAuth);
/* 546 */       this.sslContext = sslContext;
/* 547 */       InetAddress bindAddress = null;
/*     */       try {
/* 549 */         bindAddress = InetAddress.getByName(address);
/*     */       } catch (UnknownHostException e) {
/* 551 */         JmxRemoteLifecycleListener.log.error(JmxRemoteLifecycleListener.sm.getString("jmxRemoteLifecycleListener.invalidRmiBindAddress", new Object[] { address }), e);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 556 */       this.bindAddress = bindAddress;
/*     */     }
/*     */     
/*     */ 
/*     */     public ServerSocket createServerSocket(int port)
/*     */       throws IOException
/*     */     {
/* 563 */       SSLServerSocketFactory sslServerSocketFactory = this.sslContext == null ? (SSLServerSocketFactory)SSLServerSocketFactory.getDefault() : this.sslContext.getServerSocketFactory();
/*     */       
/* 565 */       SSLServerSocket sslServerSocket = (SSLServerSocket)sslServerSocketFactory.createServerSocket(port, 0, this.bindAddress);
/* 566 */       if (getEnabledCipherSuites() != null) {
/* 567 */         sslServerSocket.setEnabledCipherSuites(getEnabledCipherSuites());
/*     */       }
/* 569 */       if (getEnabledProtocols() != null) {
/* 570 */         sslServerSocket.setEnabledProtocols(getEnabledProtocols());
/*     */       }
/* 572 */       sslServerSocket.setNeedClientAuth(getNeedClientAuth());
/* 573 */       return sslServerSocket;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 580 */       int prime = 31;
/* 581 */       int result = super.hashCode();
/* 582 */       result = 31 * result + (this.bindAddress == null ? 0 : this.bindAddress.hashCode());
/* 583 */       return result;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 588 */       if (this == obj) {
/* 589 */         return true;
/*     */       }
/* 591 */       if (!super.equals(obj)) {
/* 592 */         return false;
/*     */       }
/* 594 */       if (getClass() != obj.getClass()) {
/* 595 */         return false;
/*     */       }
/* 597 */       SslRmiServerBindSocketFactory other = (SslRmiServerBindSocketFactory)obj;
/* 598 */       if (this.bindAddress == null) {
/* 599 */         if (other.bindAddress != null) {
/* 600 */           return false;
/*     */         }
/* 602 */       } else if (!this.bindAddress.equals(other.bindAddress)) {
/* 603 */         return false;
/*     */       }
/* 605 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class JmxRegistry
/*     */     extends RegistryImpl
/*     */   {
/*     */     private static final long serialVersionUID = -3772054804656428217L;
/*     */     private final String jmxName;
/*     */     private final Remote jmxServer;
/*     */     
/*     */     public JmxRegistry(int port, RMIClientSocketFactory csf, RMIServerSocketFactory ssf, String jmxName, Remote jmxServer)
/*     */       throws RemoteException
/*     */     {
/* 620 */       super(csf, ssf);
/* 621 */       this.jmxName = jmxName;
/* 622 */       this.jmxServer = jmxServer;
/*     */     }
/*     */     
/*     */     public Remote lookup(String name) throws RemoteException, NotBoundException
/*     */     {
/* 627 */       return this.jmxName.equals(name) ? this.jmxServer : null;
/*     */     }
/*     */     
/*     */     public void bind(String name, Remote obj)
/*     */       throws RemoteException, AlreadyBoundException, AccessException
/*     */     {}
/*     */     
/*     */     public void unbind(String name)
/*     */       throws RemoteException, NotBoundException, AccessException
/*     */     {}
/*     */     
/*     */     public void rebind(String name, Remote obj) throws RemoteException, AccessException
/*     */     {}
/*     */     
/*     */     public String[] list() throws RemoteException
/*     */     {
/* 643 */       return new String[] { this.jmxName };
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\JmxRemoteLifecycleListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */