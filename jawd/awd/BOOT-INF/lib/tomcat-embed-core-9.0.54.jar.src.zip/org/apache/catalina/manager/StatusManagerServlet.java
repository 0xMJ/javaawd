/*     */ package org.apache.catalina.manager;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerNotification;
/*     */ import javax.management.Notification;
/*     */ import javax.management.NotificationListener;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatusManagerServlet
/*     */   extends HttpServlet
/*     */   implements NotificationListener
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  58 */   protected MBeanServer mBeanServer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  64 */   protected final Vector<ObjectName> protocolHandlers = new Vector();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */   protected final Vector<ObjectName> threadPools = new Vector();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */   protected final Vector<ObjectName> requestProcessors = new Vector();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */   protected final Vector<ObjectName> globalRequestProcessors = new Vector();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.manager");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init()
/*     */     throws ServletException
/*     */   {
/* 102 */     this.mBeanServer = Registry.getRegistry(null, null).getMBeanServer();
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 107 */       String onStr = "*:type=ProtocolHandler,*";
/* 108 */       ObjectName objectName = new ObjectName(onStr);
/* 109 */       Set<ObjectInstance> set = this.mBeanServer.queryMBeans(objectName, null);
/* 110 */       Iterator<ObjectInstance> iterator = set.iterator();
/* 111 */       while (iterator.hasNext()) {
/* 112 */         ObjectInstance oi = (ObjectInstance)iterator.next();
/* 113 */         this.protocolHandlers.addElement(oi.getObjectName());
/*     */       }
/*     */       
/*     */ 
/* 117 */       onStr = "*:type=ThreadPool,*";
/* 118 */       objectName = new ObjectName(onStr);
/* 119 */       set = this.mBeanServer.queryMBeans(objectName, null);
/* 120 */       iterator = set.iterator();
/* 121 */       while (iterator.hasNext()) {
/* 122 */         ObjectInstance oi = (ObjectInstance)iterator.next();
/* 123 */         this.threadPools.addElement(oi.getObjectName());
/*     */       }
/*     */       
/*     */ 
/* 127 */       onStr = "*:type=GlobalRequestProcessor,*";
/* 128 */       objectName = new ObjectName(onStr);
/* 129 */       set = this.mBeanServer.queryMBeans(objectName, null);
/* 130 */       iterator = set.iterator();
/* 131 */       while (iterator.hasNext()) {
/* 132 */         ObjectInstance oi = (ObjectInstance)iterator.next();
/* 133 */         this.globalRequestProcessors.addElement(oi.getObjectName());
/*     */       }
/*     */       
/*     */ 
/* 137 */       onStr = "*:type=RequestProcessor,*";
/* 138 */       objectName = new ObjectName(onStr);
/* 139 */       set = this.mBeanServer.queryMBeans(objectName, null);
/* 140 */       iterator = set.iterator();
/* 141 */       while (iterator.hasNext()) {
/* 142 */         ObjectInstance oi = (ObjectInstance)iterator.next();
/* 143 */         this.requestProcessors.addElement(oi.getObjectName());
/*     */       }
/*     */       
/*     */ 
/* 147 */       onStr = "JMImplementation:type=MBeanServerDelegate";
/* 148 */       objectName = new ObjectName(onStr);
/* 149 */       this.mBeanServer.addNotificationListener(objectName, this, null, null);
/*     */     }
/*     */     catch (Exception e) {
/* 152 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 165 */     String onStr = "JMImplementation:type=MBeanServerDelegate";
/*     */     try
/*     */     {
/* 168 */       ObjectName objectName = new ObjectName(onStr);
/* 169 */       this.mBeanServer.removeNotificationListener(objectName, this, null, null);
/*     */     } catch (Exception e) {
/* 171 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/* 191 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request
/* 192 */       .getLocales());
/*     */     
/*     */ 
/* 195 */     int mode = 0;
/*     */     
/* 197 */     if ((request.getParameter("XML") != null) && 
/* 198 */       (request.getParameter("XML").equals("true"))) {
/* 199 */       mode = 1;
/*     */     }
/* 201 */     StatusTransformer.setContentType(response, mode);
/*     */     
/* 203 */     PrintWriter writer = response.getWriter();
/*     */     
/* 205 */     boolean completeStatus = false;
/* 206 */     if ((request.getPathInfo() != null) && 
/* 207 */       (request.getPathInfo().equals("/all"))) {
/* 208 */       completeStatus = true;
/*     */     }
/*     */     
/* 211 */     Object[] args = new Object[1];
/* 212 */     args[0] = request.getContextPath();
/* 213 */     StatusTransformer.writeHeader(writer, args, mode);
/*     */     
/*     */ 
/* 216 */     args = new Object[2];
/* 217 */     args[0] = request.getContextPath();
/* 218 */     if (completeStatus) {
/* 219 */       args[1] = smClient.getString("statusServlet.complete");
/*     */     } else {
/* 221 */       args[1] = smClient.getString("statusServlet.title");
/*     */     }
/*     */     
/* 224 */     StatusTransformer.writeBody(writer, args, mode);
/*     */     
/*     */ 
/* 227 */     args = new Object[9];
/* 228 */     args[0] = smClient.getString("htmlManagerServlet.manager");
/* 229 */     args[1] = response.encodeURL(request.getContextPath() + "/html/list");
/* 230 */     args[2] = smClient.getString("htmlManagerServlet.list");
/* 231 */     args[3] = 
/*     */     
/* 233 */       (request.getContextPath() + "/" + smClient.getString("htmlManagerServlet.helpHtmlManagerFile"));
/* 234 */     args[4] = smClient.getString("htmlManagerServlet.helpHtmlManager");
/* 235 */     args[5] = 
/*     */     
/* 237 */       (request.getContextPath() + "/" + smClient.getString("htmlManagerServlet.helpManagerFile"));
/* 238 */     args[6] = smClient.getString("htmlManagerServlet.helpManager");
/* 239 */     if (completeStatus)
/*     */     {
/* 241 */       args[7] = response.encodeURL(request.getContextPath() + "/status");
/* 242 */       args[8] = smClient.getString("statusServlet.title");
/*     */     }
/*     */     else {
/* 245 */       args[7] = response.encodeURL(request.getContextPath() + "/status/all");
/* 246 */       args[8] = smClient.getString("statusServlet.complete");
/*     */     }
/*     */     
/* 249 */     StatusTransformer.writeManager(writer, args, mode);
/*     */     
/*     */ 
/* 252 */     args = new Object[9];
/* 253 */     args[0] = smClient.getString("htmlManagerServlet.serverTitle");
/* 254 */     args[1] = smClient.getString("htmlManagerServlet.serverVersion");
/* 255 */     args[2] = smClient.getString("htmlManagerServlet.serverJVMVersion");
/* 256 */     args[3] = smClient.getString("htmlManagerServlet.serverJVMVendor");
/* 257 */     args[4] = smClient.getString("htmlManagerServlet.serverOSName");
/* 258 */     args[5] = smClient.getString("htmlManagerServlet.serverOSVersion");
/* 259 */     args[6] = smClient.getString("htmlManagerServlet.serverOSArch");
/* 260 */     args[7] = smClient.getString("htmlManagerServlet.serverHostname");
/* 261 */     args[8] = smClient.getString("htmlManagerServlet.serverIPAddress");
/*     */     
/* 263 */     StatusTransformer.writePageHeading(writer, args, mode);
/*     */     
/*     */ 
/* 266 */     args = new Object[8];
/* 267 */     args[0] = ServerInfo.getServerInfo();
/* 268 */     args[1] = System.getProperty("java.runtime.version");
/* 269 */     args[2] = System.getProperty("java.vm.vendor");
/* 270 */     args[3] = System.getProperty("os.name");
/* 271 */     args[4] = System.getProperty("os.version");
/* 272 */     args[5] = System.getProperty("os.arch");
/*     */     try {
/* 274 */       InetAddress address = InetAddress.getLocalHost();
/* 275 */       args[6] = address.getHostName();
/* 276 */       args[7] = address.getHostAddress();
/*     */     } catch (UnknownHostException e) {
/* 278 */       args[6] = "-";
/* 279 */       args[7] = "-";
/*     */     }
/*     */     
/* 282 */     StatusTransformer.writeServerInfo(writer, args, mode);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 287 */       args = new Object[7];
/* 288 */       args[0] = smClient.getString("htmlManagerServlet.osPhysicalMemory");
/* 289 */       args[1] = smClient.getString("htmlManagerServlet.osAvailableMemory");
/* 290 */       args[2] = smClient.getString("htmlManagerServlet.osTotalPageFile");
/* 291 */       args[3] = smClient.getString("htmlManagerServlet.osFreePageFile");
/* 292 */       args[4] = smClient.getString("htmlManagerServlet.osMemoryLoad");
/* 293 */       args[5] = smClient.getString("htmlManagerServlet.osKernelTime");
/* 294 */       args[6] = smClient.getString("htmlManagerServlet.osUserTime");
/* 295 */       StatusTransformer.writeOSState(writer, mode, args);
/*     */       
/*     */ 
/* 298 */       args = new Object[9];
/* 299 */       args[0] = smClient.getString("htmlManagerServlet.jvmFreeMemory");
/* 300 */       args[1] = smClient.getString("htmlManagerServlet.jvmTotalMemory");
/* 301 */       args[2] = smClient.getString("htmlManagerServlet.jvmMaxMemory");
/* 302 */       args[3] = smClient.getString("htmlManagerServlet.jvmTableTitleMemoryPool");
/* 303 */       args[4] = smClient.getString("htmlManagerServlet.jvmTableTitleType");
/* 304 */       args[5] = smClient.getString("htmlManagerServlet.jvmTableTitleInitial");
/* 305 */       args[6] = smClient.getString("htmlManagerServlet.jvmTableTitleTotal");
/* 306 */       args[7] = smClient.getString("htmlManagerServlet.jvmTableTitleMaximum");
/* 307 */       args[8] = smClient.getString("htmlManagerServlet.jvmTableTitleUsed");
/*     */       
/* 309 */       StatusTransformer.writeVMState(writer, mode, args);
/*     */       
/* 311 */       Enumeration<ObjectName> enumeration = this.threadPools.elements();
/* 312 */       while (enumeration.hasMoreElements()) {
/* 313 */         ObjectName objectName = (ObjectName)enumeration.nextElement();
/* 314 */         String name = objectName.getKeyProperty("name");
/* 315 */         args = new Object[19];
/* 316 */         args[0] = smClient.getString("htmlManagerServlet.connectorStateMaxThreads");
/* 317 */         args[1] = smClient.getString("htmlManagerServlet.connectorStateThreadCount");
/* 318 */         args[2] = smClient.getString("htmlManagerServlet.connectorStateThreadBusy");
/* 319 */         args[3] = smClient.getString("htmlManagerServlet.connectorStateAliveSocketCount");
/* 320 */         args[4] = smClient.getString("htmlManagerServlet.connectorStateMaxProcessingTime");
/* 321 */         args[5] = smClient.getString("htmlManagerServlet.connectorStateProcessingTime");
/* 322 */         args[6] = smClient.getString("htmlManagerServlet.connectorStateRequestCount");
/* 323 */         args[7] = smClient.getString("htmlManagerServlet.connectorStateErrorCount");
/* 324 */         args[8] = smClient.getString("htmlManagerServlet.connectorStateBytesReceived");
/* 325 */         args[9] = smClient.getString("htmlManagerServlet.connectorStateBytesSent");
/* 326 */         args[10] = smClient.getString("htmlManagerServlet.connectorStateTableTitleStage");
/* 327 */         args[11] = smClient.getString("htmlManagerServlet.connectorStateTableTitleTime");
/* 328 */         args[12] = smClient.getString("htmlManagerServlet.connectorStateTableTitleBSent");
/* 329 */         args[13] = smClient.getString("htmlManagerServlet.connectorStateTableTitleBRecv");
/* 330 */         args[14] = smClient.getString("htmlManagerServlet.connectorStateTableTitleClientForw");
/* 331 */         args[15] = smClient.getString("htmlManagerServlet.connectorStateTableTitleClientAct");
/* 332 */         args[16] = smClient.getString("htmlManagerServlet.connectorStateTableTitleVHost");
/* 333 */         args[17] = smClient.getString("htmlManagerServlet.connectorStateTableTitleRequest");
/* 334 */         args[18] = smClient.getString("htmlManagerServlet.connectorStateHint");
/*     */         
/*     */ 
/* 337 */         StatusTransformer.writeConnectorState(writer, objectName, name, this.mBeanServer, this.globalRequestProcessors, this.requestProcessors, mode, args);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 342 */       if ((request.getPathInfo() != null) && 
/* 343 */         (request.getPathInfo().equals("/all")))
/*     */       {
/*     */ 
/*     */ 
/* 347 */         StatusTransformer.writeDetailedState(writer, this.mBeanServer, mode);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 351 */       throw new ServletException(e);
/*     */     }
/*     */     
/*     */ 
/* 355 */     StatusTransformer.writeFooter(writer, mode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleNotification(Notification notification, Object handback)
/*     */   {
/* 366 */     if ((notification instanceof MBeanServerNotification))
/*     */     {
/* 368 */       ObjectName objectName = ((MBeanServerNotification)notification).getMBeanName();
/*     */       
/* 370 */       if (notification.getType().equals("JMX.mbean.registered")) {
/* 371 */         String type = objectName.getKeyProperty("type");
/* 372 */         if (type != null) {
/* 373 */           if (type.equals("ProtocolHandler")) {
/* 374 */             this.protocolHandlers.addElement(objectName);
/* 375 */           } else if (type.equals("ThreadPool")) {
/* 376 */             this.threadPools.addElement(objectName);
/* 377 */           } else if (type.equals("GlobalRequestProcessor")) {
/* 378 */             this.globalRequestProcessors.addElement(objectName);
/* 379 */           } else if (type.equals("RequestProcessor")) {
/* 380 */             this.requestProcessors.addElement(objectName);
/*     */           }
/*     */         }
/*     */       }
/* 384 */       else if (notification.getType().equals("JMX.mbean.unregistered")) {
/* 385 */         String type = objectName.getKeyProperty("type");
/* 386 */         if (type != null) {
/* 387 */           if (type.equals("ProtocolHandler")) {
/* 388 */             this.protocolHandlers.removeElement(objectName);
/* 389 */           } else if (type.equals("ThreadPool")) {
/* 390 */             this.threadPools.removeElement(objectName);
/* 391 */           } else if (type.equals("GlobalRequestProcessor")) {
/* 392 */             this.globalRequestProcessors.removeElement(objectName);
/* 393 */           } else if (type.equals("RequestProcessor")) {
/* 394 */             this.requestProcessors.removeElement(objectName);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\manager\StatusManagerServlet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */