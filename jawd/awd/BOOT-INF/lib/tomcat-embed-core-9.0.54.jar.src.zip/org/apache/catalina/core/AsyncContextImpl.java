/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javax.naming.NamingException;
/*     */ import javax.servlet.AsyncContext;
/*     */ import javax.servlet.AsyncEvent;
/*     */ import javax.servlet.AsyncListener;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.AsyncDispatcher;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.coyote.AsyncContextCallback;
/*     */ import org.apache.coyote.RequestInfo;
/*     */ import org.apache.coyote.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.UDecoder;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncContextImpl
/*     */   implements AsyncContext, AsyncContextCallback
/*     */ {
/*  54 */   private static final Log log = LogFactory.getLog(AsyncContextImpl.class);
/*     */   
/*  56 */   protected static final StringManager sm = StringManager.getManager(AsyncContextImpl.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */   private final Object asyncContextLock = new Object();
/*     */   
/*  67 */   private volatile ServletRequest servletRequest = null;
/*  68 */   private volatile ServletResponse servletResponse = null;
/*  69 */   private final List<AsyncListenerWrapper> listeners = new ArrayList();
/*  70 */   private boolean hasOriginalRequestAndResponse = true;
/*  71 */   private volatile Runnable dispatch = null;
/*  72 */   private Context context = null;
/*     */   
/*  74 */   private long timeout = -1L;
/*  75 */   private AsyncEvent event = null;
/*     */   private volatile org.apache.catalina.connector.Request request;
/*     */   
/*     */   public AsyncContextImpl(org.apache.catalina.connector.Request request) {
/*  79 */     if (log.isDebugEnabled()) {
/*  80 */       logDebug("Constructor");
/*     */     }
/*  82 */     this.request = request;
/*     */   }
/*     */   
/*     */   public void complete()
/*     */   {
/*  87 */     if (log.isDebugEnabled()) {
/*  88 */       logDebug("complete   ");
/*     */     }
/*  90 */     check();
/*  91 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_COMPLETE, null);
/*     */   }
/*     */   
/*     */   public void fireOnComplete()
/*     */   {
/*  96 */     if (log.isDebugEnabled()) {
/*  97 */       log.debug(sm.getString("asyncContextImpl.fireOnComplete"));
/*     */     }
/*  99 */     List<AsyncListenerWrapper> listenersCopy = new ArrayList(this.listeners);
/*     */     
/* 101 */     ClassLoader oldCL = this.context.bind(Globals.IS_SECURITY_ENABLED, null);
/*     */     try {
/* 103 */       for (AsyncListenerWrapper listener : listenersCopy) {
/*     */         try {
/* 105 */           listener.fireOnComplete(this.event);
/*     */         } catch (Throwable t) {
/* 107 */           ExceptionUtils.handleThrowable(t);
/* 108 */           log.warn(sm.getString("asyncContextImpl.onCompleteError", new Object[] {listener
/* 109 */             .getClass().getName() }), t);
/*     */         }
/*     */       }
/*     */     } finally {
/* 113 */       this.context.fireRequestDestroyEvent(this.request.getRequest());
/* 114 */       clearServletRequestResponse();
/* 115 */       this.context.unbind(Globals.IS_SECURITY_ENABLED, oldCL);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean timeout()
/*     */   {
/* 121 */     AtomicBoolean result = new AtomicBoolean();
/* 122 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_TIMEOUT, result);
/*     */     
/* 124 */     Context context = this.context;
/*     */     
/* 126 */     if (result.get()) {
/* 127 */       if (log.isDebugEnabled()) {
/* 128 */         log.debug(sm.getString("asyncContextImpl.fireOnTimeout"));
/*     */       }
/* 130 */       ClassLoader oldCL = context.bind(false, null);
/*     */       try {
/* 132 */         List<AsyncListenerWrapper> listenersCopy = new ArrayList(this.listeners);
/* 133 */         for (AsyncListenerWrapper listener : listenersCopy) {
/*     */           try {
/* 135 */             listener.fireOnTimeout(this.event);
/*     */           } catch (Throwable t) {
/* 137 */             ExceptionUtils.handleThrowable(t);
/* 138 */             log.warn(sm.getString("asyncContextImpl.onTimeoutError", new Object[] {listener
/* 139 */               .getClass().getName() }), t);
/*     */           }
/*     */         }
/* 142 */         this.request.getCoyoteRequest().action(ActionCode.ASYNC_IS_TIMINGOUT, result);
/*     */       }
/*     */       finally {
/* 145 */         context.unbind(false, oldCL);
/*     */       }
/*     */     }
/* 148 */     return !result.get();
/*     */   }
/*     */   
/*     */   public void dispatch()
/*     */   {
/* 153 */     check();
/*     */     
/*     */ 
/* 156 */     ServletRequest servletRequest = getRequest();
/* 157 */     String cpath; String path; String cpath; if ((servletRequest instanceof HttpServletRequest)) {
/* 158 */       HttpServletRequest sr = (HttpServletRequest)servletRequest;
/* 159 */       String path = sr.getRequestURI();
/* 160 */       cpath = sr.getContextPath();
/*     */     } else {
/* 162 */       path = this.request.getRequestURI();
/* 163 */       cpath = this.request.getContextPath();
/*     */     }
/* 165 */     if (cpath.length() > 1) {
/* 166 */       path = path.substring(cpath.length());
/*     */     }
/* 168 */     if (!this.context.getDispatchersUseEncodedPaths()) {
/* 169 */       path = UDecoder.URLDecode(path, StandardCharsets.UTF_8);
/*     */     }
/* 171 */     dispatch(path);
/*     */   }
/*     */   
/*     */   public void dispatch(String path)
/*     */   {
/* 176 */     check();
/* 177 */     dispatch(getRequest().getServletContext(), path);
/*     */   }
/*     */   
/*     */   public void dispatch(ServletContext servletContext, String path)
/*     */   {
/* 182 */     synchronized (this.asyncContextLock) {
/* 183 */       if (log.isDebugEnabled()) {
/* 184 */         logDebug("dispatch   ");
/*     */       }
/* 186 */       check();
/* 187 */       if (this.dispatch != null)
/*     */       {
/* 189 */         throw new IllegalStateException(sm.getString("asyncContextImpl.dispatchingStarted"));
/*     */       }
/* 191 */       if (this.request.getAttribute("javax.servlet.async.request_uri") == null) {
/* 192 */         this.request.setAttribute("javax.servlet.async.request_uri", this.request.getRequestURI());
/* 193 */         this.request.setAttribute("javax.servlet.async.context_path", this.request.getContextPath());
/* 194 */         this.request.setAttribute("javax.servlet.async.servlet_path", this.request.getServletPath());
/* 195 */         this.request.setAttribute("javax.servlet.async.path_info", this.request.getPathInfo());
/* 196 */         this.request.setAttribute("javax.servlet.async.query_string", this.request.getQueryString());
/*     */       }
/* 198 */       RequestDispatcher requestDispatcher = servletContext.getRequestDispatcher(path);
/* 199 */       if (!(requestDispatcher instanceof AsyncDispatcher))
/*     */       {
/* 201 */         throw new UnsupportedOperationException(sm.getString("asyncContextImpl.noAsyncDispatcher"));
/*     */       }
/* 203 */       AsyncDispatcher applicationDispatcher = (AsyncDispatcher)requestDispatcher;
/*     */       
/* 205 */       ServletRequest servletRequest = getRequest();
/* 206 */       ServletResponse servletResponse = getResponse();
/* 207 */       this.dispatch = new AsyncRunnable(this.request, applicationDispatcher, servletRequest, servletResponse);
/*     */       
/* 209 */       this.request.getCoyoteRequest().action(ActionCode.ASYNC_DISPATCH, null);
/* 210 */       clearServletRequestResponse();
/*     */     }
/*     */   }
/*     */   
/*     */   public ServletRequest getRequest()
/*     */   {
/* 216 */     check();
/* 217 */     if (this.servletRequest == null)
/*     */     {
/* 219 */       throw new IllegalStateException(sm.getString("asyncContextImpl.request.ise"));
/*     */     }
/* 221 */     return this.servletRequest;
/*     */   }
/*     */   
/*     */   public ServletResponse getResponse()
/*     */   {
/* 226 */     check();
/* 227 */     if (this.servletResponse == null)
/*     */     {
/* 229 */       throw new IllegalStateException(sm.getString("asyncContextImpl.response.ise"));
/*     */     }
/* 231 */     return this.servletResponse;
/*     */   }
/*     */   
/*     */   public void start(Runnable run)
/*     */   {
/* 236 */     if (log.isDebugEnabled()) {
/* 237 */       logDebug("start      ");
/*     */     }
/* 239 */     check();
/* 240 */     Runnable wrapper = new RunnableWrapper(run, this.context, this.request.getCoyoteRequest());
/* 241 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_RUN, wrapper);
/*     */   }
/*     */   
/*     */   public void addListener(AsyncListener listener)
/*     */   {
/* 246 */     check();
/* 247 */     AsyncListenerWrapper wrapper = new AsyncListenerWrapper();
/* 248 */     wrapper.setListener(listener);
/* 249 */     this.listeners.add(wrapper);
/*     */   }
/*     */   
/*     */ 
/*     */   public void addListener(AsyncListener listener, ServletRequest servletRequest, ServletResponse servletResponse)
/*     */   {
/* 255 */     check();
/* 256 */     AsyncListenerWrapper wrapper = new AsyncListenerWrapper();
/* 257 */     wrapper.setListener(listener);
/* 258 */     wrapper.setServletRequest(servletRequest);
/* 259 */     wrapper.setServletResponse(servletResponse);
/* 260 */     this.listeners.add(wrapper);
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends AsyncListener> T createListener(Class<T> clazz)
/*     */     throws ServletException
/*     */   {
/* 267 */     check();
/* 268 */     T listener = null;
/*     */     try {
/* 270 */       listener = (AsyncListener)this.context.getInstanceManager().newInstance(clazz
/* 271 */         .getName(), clazz.getClassLoader());
/*     */     } catch (ReflectiveOperationException|NamingException e) {
/* 273 */       ServletException se = new ServletException(e);
/* 274 */       throw se;
/*     */     } catch (Exception e) {
/* 276 */       ExceptionUtils.handleThrowable(e.getCause());
/* 277 */       ServletException se = new ServletException(e);
/* 278 */       throw se;
/*     */     }
/* 280 */     return listener;
/*     */   }
/*     */   
/*     */   public void recycle() {
/* 284 */     if (log.isDebugEnabled()) {
/* 285 */       logDebug("recycle    ");
/*     */     }
/* 287 */     this.context = null;
/* 288 */     this.dispatch = null;
/* 289 */     this.event = null;
/* 290 */     this.hasOriginalRequestAndResponse = true;
/* 291 */     this.listeners.clear();
/* 292 */     this.request = null;
/* 293 */     clearServletRequestResponse();
/* 294 */     this.timeout = -1L;
/*     */   }
/*     */   
/*     */   private void clearServletRequestResponse() {
/* 298 */     this.servletRequest = null;
/* 299 */     this.servletResponse = null;
/*     */   }
/*     */   
/*     */   public boolean isStarted() {
/* 303 */     AtomicBoolean result = new AtomicBoolean(false);
/* 304 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_IS_STARTED, result);
/*     */     
/* 306 */     return result.get();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setStarted(Context context, ServletRequest request, ServletResponse response, boolean originalRequestResponse)
/*     */   {
/* 312 */     synchronized (this.asyncContextLock) {
/* 313 */       this.request.getCoyoteRequest().action(ActionCode.ASYNC_START, this);
/*     */       
/*     */ 
/* 316 */       this.context = context;
/* 317 */       context.incrementInProgressAsyncCount();
/* 318 */       this.servletRequest = request;
/* 319 */       this.servletResponse = response;
/* 320 */       this.hasOriginalRequestAndResponse = originalRequestResponse;
/* 321 */       this.event = new AsyncEvent(this, request, response);
/*     */       
/* 323 */       List<AsyncListenerWrapper> listenersCopy = new ArrayList(this.listeners);
/* 324 */       this.listeners.clear();
/* 325 */       if (log.isDebugEnabled()) {
/* 326 */         log.debug(sm.getString("asyncContextImpl.fireOnStartAsync"));
/*     */       }
/* 328 */       for (AsyncListenerWrapper listener : listenersCopy) {
/*     */         try {
/* 330 */           listener.fireOnStartAsync(this.event);
/*     */         } catch (Throwable t) {
/* 332 */           ExceptionUtils.handleThrowable(t);
/* 333 */           log.warn(sm.getString("asyncContextImpl.onStartAsyncError", new Object[] {listener
/* 334 */             .getClass().getName() }), t);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasOriginalRequestAndResponse()
/*     */   {
/* 342 */     check();
/* 343 */     return this.hasOriginalRequestAndResponse;
/*     */   }
/*     */   
/*     */   protected void doInternalDispatch() throws ServletException, IOException {
/* 347 */     if (log.isDebugEnabled()) {
/* 348 */       logDebug("intDispatch");
/*     */     }
/*     */     try {
/* 351 */       Runnable runnable = this.dispatch;
/* 352 */       this.dispatch = null;
/* 353 */       runnable.run();
/* 354 */       if (!this.request.isAsync()) {
/* 355 */         fireOnComplete();
/*     */       }
/*     */     }
/*     */     catch (RuntimeException x) {
/* 359 */       if ((x.getCause() instanceof ServletException)) {
/* 360 */         throw ((ServletException)x.getCause());
/*     */       }
/* 362 */       if ((x.getCause() instanceof IOException)) {
/* 363 */         throw ((IOException)x.getCause());
/*     */       }
/* 365 */       throw new ServletException(x);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public long getTimeout()
/*     */   {
/* 372 */     check();
/* 373 */     return this.timeout;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setTimeout(long timeout)
/*     */   {
/* 379 */     check();
/* 380 */     this.timeout = timeout;
/* 381 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_SETTIMEOUT, 
/* 382 */       Long.valueOf(timeout));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isAvailable()
/*     */   {
/* 389 */     Context context = this.context;
/* 390 */     if (context == null) {
/* 391 */       return false;
/*     */     }
/* 393 */     return context.getState().isAvailable();
/*     */   }
/*     */   
/*     */   public void setErrorState(Throwable t, boolean fireOnError)
/*     */   {
/* 398 */     if (t != null) {
/* 399 */       this.request.setAttribute("javax.servlet.error.exception", t);
/*     */     }
/* 401 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_ERROR, null);
/*     */     AsyncEvent errorEvent;
/* 403 */     if (fireOnError) {
/* 404 */       if (log.isDebugEnabled()) {
/* 405 */         log.debug(sm.getString("asyncContextImpl.fireOnError"));
/*     */       }
/*     */       
/* 408 */       errorEvent = new AsyncEvent(this.event.getAsyncContext(), this.event.getSuppliedRequest(), this.event.getSuppliedResponse(), t);
/* 409 */       List<AsyncListenerWrapper> listenersCopy = new ArrayList(this.listeners);
/* 410 */       for (AsyncListenerWrapper listener : listenersCopy) {
/*     */         try {
/* 412 */           listener.fireOnError(errorEvent);
/*     */         } catch (Throwable t2) {
/* 414 */           ExceptionUtils.handleThrowable(t2);
/* 415 */           log.warn(sm.getString("asyncContextImpl.onErrorError", new Object[] {listener
/* 416 */             .getClass().getName() }), t2);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 422 */     AtomicBoolean result = new AtomicBoolean();
/* 423 */     this.request.getCoyoteRequest().action(ActionCode.ASYNC_IS_ERROR, result);
/* 424 */     if (result.get())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 430 */       ServletResponse servletResponse = this.servletResponse;
/* 431 */       if ((servletResponse instanceof HttpServletResponse)) {
/* 432 */         ((HttpServletResponse)servletResponse).setStatus(500);
/*     */       }
/*     */       
/*     */ 
/* 436 */       Host host = (Host)this.context.getParent();
/* 437 */       Valve stdHostValve = host.getPipeline().getBasic();
/* 438 */       if ((stdHostValve instanceof StandardHostValve)) {
/* 439 */         ((StandardHostValve)stdHostValve).throwable(this.request, this.request
/* 440 */           .getResponse(), t);
/*     */       }
/*     */       
/* 443 */       this.request.getCoyoteRequest().action(ActionCode.ASYNC_IS_ERROR, result);
/*     */       
/* 445 */       if (result.get())
/*     */       {
/*     */ 
/* 448 */         complete();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void incrementInProgressAsyncCount()
/*     */   {
/* 456 */     this.context.incrementInProgressAsyncCount();
/*     */   }
/*     */   
/*     */ 
/*     */   public void decrementInProgressAsyncCount()
/*     */   {
/* 462 */     this.context.decrementInProgressAsyncCount();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void logDebug(String method)
/*     */   {
/* 471 */     StringBuilder uri = new StringBuilder();
/* 472 */     String rHashCode; String crHashCode; String rpHashCode; String stage; if (this.request == null) {
/* 473 */       String rHashCode = "null";
/* 474 */       String crHashCode = "null";
/* 475 */       String rpHashCode = "null";
/* 476 */       String stage = "-";
/* 477 */       uri.append("N/A");
/*     */     } else {
/* 479 */       rHashCode = Integer.toHexString(this.request.hashCode());
/* 480 */       org.apache.coyote.Request coyoteRequest = this.request.getCoyoteRequest();
/* 481 */       String stage; if (coyoteRequest == null) {
/* 482 */         String crHashCode = "null";
/* 483 */         String rpHashCode = "null";
/* 484 */         stage = "-";
/*     */       } else {
/* 486 */         crHashCode = Integer.toHexString(coyoteRequest.hashCode());
/* 487 */         RequestInfo rp = coyoteRequest.getRequestProcessor();
/* 488 */         String stage; if (rp == null) {
/* 489 */           String rpHashCode = "null";
/* 490 */           stage = "-";
/*     */         } else {
/* 492 */           rpHashCode = Integer.toHexString(rp.hashCode());
/* 493 */           stage = Integer.toString(rp.getStage());
/*     */         }
/*     */       }
/* 496 */       uri.append(this.request.getRequestURI());
/* 497 */       if (this.request.getQueryString() != null) {
/* 498 */         uri.append('?');
/* 499 */         uri.append(this.request.getQueryString());
/*     */       }
/*     */     }
/* 502 */     String threadName = Thread.currentThread().getName();
/* 503 */     int len = threadName.length();
/* 504 */     if (len > 20) {
/* 505 */       threadName = threadName.substring(len - 20, len);
/*     */     }
/* 507 */     String msg = String.format("Req: %1$8s  CReq: %2$8s  RP: %3$8s  Stage: %4$s  Thread: %5$20s  State: %6$20s  Method: %7$11s  URI: %8$s", new Object[] { rHashCode, crHashCode, rpHashCode, stage, threadName, "N/A", method, uri });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 512 */     if (log.isTraceEnabled()) {
/* 513 */       log.trace(msg, new DebugException(null));
/*     */     } else {
/* 515 */       log.debug(msg);
/*     */     }
/*     */   }
/*     */   
/*     */   private void check() {
/* 520 */     if (this.request == null)
/*     */     {
/* 522 */       throw new IllegalStateException(sm.getString("asyncContextImpl.requestEnded"));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class DebugException extends Exception
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */   }
/*     */   
/*     */   private static class RunnableWrapper implements Runnable
/*     */   {
/*     */     private final Runnable wrapped;
/*     */     private final Context context;
/*     */     private final org.apache.coyote.Request coyoteRequest;
/*     */     
/*     */     public RunnableWrapper(Runnable wrapped, Context ctxt, org.apache.coyote.Request coyoteRequest)
/*     */     {
/* 539 */       this.wrapped = wrapped;
/* 540 */       this.context = ctxt;
/* 541 */       this.coyoteRequest = coyoteRequest;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 546 */       ClassLoader oldCL = this.context.bind(Globals.IS_SECURITY_ENABLED, null);
/*     */       try {
/* 548 */         this.wrapped.run();
/*     */       } catch (Throwable t) {
/* 550 */         ExceptionUtils.handleThrowable(t);
/* 551 */         this.context.getLogger().error(AsyncContextImpl.sm.getString("asyncContextImpl.asyncRunnableError"), t);
/* 552 */         this.coyoteRequest.setAttribute("javax.servlet.error.exception", t);
/* 553 */         Response coyoteResponse = this.coyoteRequest.getResponse();
/* 554 */         coyoteResponse.setStatus(500);
/* 555 */         coyoteResponse.setError();
/*     */       } finally {
/* 557 */         this.context.unbind(Globals.IS_SECURITY_ENABLED, oldCL);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 563 */       this.coyoteRequest.action(ActionCode.DISPATCH_EXECUTE, null);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class AsyncRunnable
/*     */     implements Runnable
/*     */   {
/*     */     private final AsyncDispatcher applicationDispatcher;
/*     */     private final org.apache.catalina.connector.Request request;
/*     */     private final ServletRequest servletRequest;
/*     */     private final ServletResponse servletResponse;
/*     */     
/*     */     public AsyncRunnable(org.apache.catalina.connector.Request request, AsyncDispatcher applicationDispatcher, ServletRequest servletRequest, ServletResponse servletResponse)
/*     */     {
/* 577 */       this.request = request;
/* 578 */       this.applicationDispatcher = applicationDispatcher;
/* 579 */       this.servletRequest = servletRequest;
/* 580 */       this.servletResponse = servletResponse;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 585 */       this.request.getCoyoteRequest().action(ActionCode.ASYNC_DISPATCHED, null);
/*     */       try {
/* 587 */         this.applicationDispatcher.dispatch(this.servletRequest, this.servletResponse);
/*     */       } catch (Exception e) {
/* 589 */         throw new RuntimeException(AsyncContextImpl.sm.getString("asyncContextImpl.asyncDispatchError"), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\AsyncContextImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */