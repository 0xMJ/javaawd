/*     */ package org.apache.catalina.manager;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.catalina.manager.util.SessionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JspHelper
/*     */ {
/*     */   private static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
/*     */   private static final int HIGHEST_SPECIAL = 62;
/*     */   
/*  55 */   public static String guessDisplayLocaleFromSession(Session in_session) { return localeToString(SessionUtils.guessLocaleFromSession(in_session)); }
/*     */   
/*     */   private static String localeToString(Locale locale) {
/*  58 */     if (locale != null) {
/*  59 */       return escapeXml(locale.toString());
/*     */     }
/*  61 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String guessDisplayUserFromSession(Session in_session)
/*     */   {
/*  71 */     Object user = SessionUtils.guessUserFromSession(in_session);
/*  72 */     return escapeXml(user);
/*     */   }
/*     */   
/*     */   public static String getDisplayCreationTimeForSession(Session in_session)
/*     */   {
/*     */     try {
/*  78 */       if (in_session.getCreationTime() == 0L) {
/*  79 */         return "";
/*     */       }
/*  81 */       DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  82 */       return formatter.format(new Date(in_session.getCreationTime()));
/*     */     }
/*     */     catch (IllegalStateException ise) {}
/*  85 */     return "";
/*     */   }
/*     */   
/*     */   public static String getDisplayLastAccessedTimeForSession(Session in_session)
/*     */   {
/*     */     try {
/*  91 */       if (in_session.getLastAccessedTime() == 0L) {
/*  92 */         return "";
/*     */       }
/*  94 */       DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  95 */       return formatter.format(new Date(in_session.getLastAccessedTime()));
/*     */     }
/*     */     catch (IllegalStateException ise) {}
/*  98 */     return "";
/*     */   }
/*     */   
/*     */   public static String getDisplayUsedTimeForSession(Session in_session)
/*     */   {
/*     */     try {
/* 104 */       if (in_session.getCreationTime() == 0L) {
/* 105 */         return "";
/*     */       }
/*     */     }
/*     */     catch (IllegalStateException ise) {
/* 109 */       return "";
/*     */     }
/* 111 */     return secondsToTimeString(SessionUtils.getUsedTimeForSession(in_session) / 1000L);
/*     */   }
/*     */   
/*     */   public static String getDisplayTTLForSession(Session in_session) {
/*     */     try {
/* 116 */       if (in_session.getCreationTime() == 0L) {
/* 117 */         return "";
/*     */       }
/*     */     }
/*     */     catch (IllegalStateException ise) {
/* 121 */       return "";
/*     */     }
/* 123 */     return secondsToTimeString(SessionUtils.getTTLForSession(in_session) / 1000L);
/*     */   }
/*     */   
/*     */   public static String getDisplayInactiveTimeForSession(Session in_session) {
/*     */     try {
/* 128 */       if (in_session.getCreationTime() == 0L) {
/* 129 */         return "";
/*     */       }
/*     */     }
/*     */     catch (IllegalStateException ise) {
/* 133 */       return "";
/*     */     }
/* 135 */     return secondsToTimeString(SessionUtils.getInactiveTimeForSession(in_session) / 1000L);
/*     */   }
/*     */   
/*     */   public static String secondsToTimeString(long in_seconds) {
/* 139 */     StringBuilder buff = new StringBuilder(9);
/* 140 */     if (in_seconds < 0L) {
/* 141 */       buff.append('-');
/* 142 */       in_seconds = -in_seconds;
/*     */     }
/* 144 */     long rest = in_seconds;
/* 145 */     long hour = rest / 3600L;
/* 146 */     rest %= 3600L;
/* 147 */     long minute = rest / 60L;
/* 148 */     rest %= 60L;
/* 149 */     long second = rest;
/* 150 */     if (hour < 10L) {
/* 151 */       buff.append('0');
/*     */     }
/* 153 */     buff.append(hour);
/* 154 */     buff.append(':');
/* 155 */     if (minute < 10L) {
/* 156 */       buff.append('0');
/*     */     }
/* 158 */     buff.append(minute);
/* 159 */     buff.append(':');
/* 160 */     if (second < 10L) {
/* 161 */       buff.append('0');
/*     */     }
/* 163 */     buff.append(second);
/* 164 */     return buff.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 173 */   private static final char[][] specialCharactersRepresentation = new char[63][];
/*     */   
/*     */   static {
/* 176 */     specialCharactersRepresentation[38] = "&amp;".toCharArray();
/* 177 */     specialCharactersRepresentation[60] = "&lt;".toCharArray();
/* 178 */     specialCharactersRepresentation[62] = "&gt;".toCharArray();
/* 179 */     specialCharactersRepresentation[34] = "&#034;".toCharArray();
/* 180 */     specialCharactersRepresentation[39] = "&#039;".toCharArray();
/*     */   }
/*     */   
/*     */   public static String escapeXml(Object obj) {
/* 184 */     String value = null;
/*     */     try {
/* 186 */       value = obj == null ? null : obj.toString();
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/* 190 */     return escapeXml(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escapeXml(String buffer)
/*     */   {
/* 209 */     if (buffer == null) {
/* 210 */       return "";
/*     */     }
/* 212 */     int start = 0;
/* 213 */     int length = buffer.length();
/* 214 */     char[] arrayBuffer = buffer.toCharArray();
/* 215 */     StringBuilder escapedBuffer = null;
/*     */     
/* 217 */     for (int i = 0; i < length; i++) {
/* 218 */       char c = arrayBuffer[i];
/* 219 */       if (c <= '>') {
/* 220 */         char[] escaped = specialCharactersRepresentation[c];
/* 221 */         if (escaped != null)
/*     */         {
/* 223 */           if (start == 0) {
/* 224 */             escapedBuffer = new StringBuilder(length + 5);
/*     */           }
/*     */           
/* 227 */           if (start < i) {
/* 228 */             escapedBuffer.append(arrayBuffer, start, i - start);
/*     */           }
/* 230 */           start = i + 1;
/*     */           
/* 232 */           escapedBuffer.append(escaped);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 237 */     if (start == 0) {
/* 238 */       return buffer;
/*     */     }
/*     */     
/* 241 */     if (start < length) {
/* 242 */       escapedBuffer.append(arrayBuffer, start, length - start);
/*     */     }
/* 244 */     return escapedBuffer.toString();
/*     */   }
/*     */   
/*     */   public static String formatNumber(long number) {
/* 248 */     return NumberFormat.getNumberInstance().format(number);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\manager\JspHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */