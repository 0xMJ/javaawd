/*    */ package org.apache.catalina.loader;
/*    */ 
/*    */ import org.apache.catalina.LifecycleException;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ import org.apache.tomcat.util.compat.JreCompat;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParallelWebappClassLoader
/*    */   extends WebappClassLoaderBase
/*    */ {
/* 26 */   private static final Log log = LogFactory.getLog(ParallelWebappClassLoader.class);
/*    */   
/*    */   static {
/* 29 */     if ((!JreCompat.isGraalAvailable()) && 
/* 30 */       (!ClassLoader.registerAsParallelCapable())) {
/* 31 */       log.warn(sm.getString("webappClassLoaderParallel.registrationFailed"));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ParallelWebappClassLoader(ClassLoader parent)
/*    */   {
/* 42 */     super(parent);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ParallelWebappClassLoader copyWithoutTransformers()
/*    */   {
/* 64 */     ParallelWebappClassLoader result = new ParallelWebappClassLoader(getParent());
/*    */     
/* 66 */     super.copyStateWithoutTransformers(result);
/*    */     try
/*    */     {
/* 69 */       result.start();
/*    */     } catch (LifecycleException e) {
/* 71 */       throw new IllegalStateException(e);
/*    */     }
/*    */     
/* 74 */     return result;
/*    */   }
/*    */   
/*    */   public ParallelWebappClassLoader() {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\loader\ParallelWebappClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */