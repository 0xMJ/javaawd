/*      */ package org.apache.catalina.startup;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.security.Principal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Stack;
/*      */ import java.util.jar.JarEntry;
/*      */ import java.util.jar.JarFile;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.LogManager;
/*      */ import java.util.logging.Logger;
/*      */ import javax.servlet.Servlet;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.SingleThreadModel;
/*      */ import javax.servlet.annotation.WebServlet;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleEvent;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.authenticator.NonLoginAuthenticator;
/*      */ import org.apache.catalina.connector.Connector;
/*      */ import org.apache.catalina.core.ContainerBase;
/*      */ import org.apache.catalina.core.NamingContextListener;
/*      */ import org.apache.catalina.core.StandardContext;
/*      */ import org.apache.catalina.core.StandardEngine;
/*      */ import org.apache.catalina.core.StandardHost;
/*      */ import org.apache.catalina.core.StandardServer;
/*      */ import org.apache.catalina.core.StandardService;
/*      */ import org.apache.catalina.core.StandardWrapper;
/*      */ import org.apache.catalina.realm.GenericPrincipal;
/*      */ import org.apache.catalina.realm.RealmBase;
/*      */ import org.apache.catalina.security.SecurityClassLoad;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.IOTools;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.UriUtil;
/*      */ import org.apache.tomcat.util.compat.JreCompat;
/*      */ import org.apache.tomcat.util.descriptor.web.LoginConfig;
/*      */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*      */ import org.apache.tomcat.util.file.ConfigurationSource;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Tomcat
/*      */ {
/*  161 */   private static final StringManager sm = StringManager.getManager(Tomcat.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  168 */   private final Map<String, Logger> pinnedLoggers = new HashMap();
/*      */   
/*      */   protected Server server;
/*      */   
/*  172 */   protected int port = 8080;
/*  173 */   protected String hostname = "localhost";
/*      */   
/*      */   protected String basedir;
/*  176 */   private final Map<String, String> userPass = new HashMap();
/*  177 */   private final Map<String, List<String>> userRoles = new HashMap();
/*  178 */   private final Map<String, Principal> userPrincipals = new HashMap();
/*      */   
/*  180 */   private boolean addDefaultWebXmlToWebapp = true;
/*      */   
/*      */   public Tomcat() {
/*  183 */     ExceptionUtils.preload();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBaseDir(String basedir)
/*      */   {
/*  209 */     this.basedir = basedir;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(int port)
/*      */   {
/*  218 */     this.port = port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHostname(String s)
/*      */   {
/*  227 */     this.hostname = s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addWebapp(String contextPath, String docBase)
/*      */   {
/*  249 */     return addWebapp(getHost(), contextPath, docBase);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addWebapp(String contextPath, URL source)
/*      */     throws IOException
/*      */   {
/*  270 */     ContextName cn = new ContextName(contextPath, null);
/*      */     
/*      */ 
/*  273 */     Host h = getHost();
/*  274 */     if (h.findChild(cn.getName()) != null) {
/*  275 */       throw new IllegalArgumentException(sm.getString("tomcat.addWebapp.conflictChild", new Object[] { source, contextPath, cn
/*  276 */         .getName() }));
/*      */     }
/*      */     
/*      */ 
/*  280 */     File targetWar = new File(h.getAppBaseFile(), cn.getBaseName() + ".war");
/*  281 */     File targetDir = new File(h.getAppBaseFile(), cn.getBaseName());
/*      */     
/*  283 */     if (targetWar.exists()) {
/*  284 */       throw new IllegalArgumentException(sm.getString("tomcat.addWebapp.conflictFile", new Object[] { source, contextPath, targetWar
/*  285 */         .getAbsolutePath() }));
/*      */     }
/*  287 */     if (targetDir.exists()) {
/*  288 */       throw new IllegalArgumentException(sm.getString("tomcat.addWebapp.conflictFile", new Object[] { source, contextPath, targetDir
/*  289 */         .getAbsolutePath() }));
/*      */     }
/*      */     
/*      */ 
/*  293 */     URLConnection uConn = source.openConnection();
/*      */     
/*  295 */     InputStream is = uConn.getInputStream();Throwable localThrowable6 = null;
/*  296 */     try { OutputStream os = new FileOutputStream(targetWar);Throwable localThrowable7 = null;
/*  297 */       try { IOTools.flow(is, os);
/*      */       }
/*      */       catch (Throwable localThrowable1)
/*      */       {
/*  295 */         localThrowable7 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable4) { localThrowable6 = localThrowable4;throw localThrowable4;
/*      */     }
/*      */     finally {
/*  298 */       if (is != null) if (localThrowable6 != null) try { is.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else is.close();
/*      */     }
/*  300 */     return addWebapp(contextPath, targetWar.getAbsolutePath());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addContext(String contextPath, String docBase)
/*      */   {
/*  347 */     return addContext(getHost(), contextPath, docBase);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Wrapper addServlet(String contextPath, String servletName, String servletClass)
/*      */   {
/*  372 */     Container ctx = getHost().findChild(contextPath);
/*  373 */     return addServlet((Context)ctx, servletName, servletClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Wrapper addServlet(Context ctx, String servletName, String servletClass)
/*      */   {
/*  387 */     Wrapper sw = ctx.createWrapper();
/*  388 */     sw.setServletClass(servletClass);
/*  389 */     sw.setName(servletName);
/*  390 */     ctx.addChild(sw);
/*      */     
/*  392 */     return sw;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Wrapper addServlet(String contextPath, String servletName, Servlet servlet)
/*      */   {
/*  406 */     Container ctx = getHost().findChild(contextPath);
/*  407 */     return addServlet((Context)ctx, servletName, servlet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Wrapper addServlet(Context ctx, String servletName, Servlet servlet)
/*      */   {
/*  421 */     Wrapper sw = new ExistingStandardWrapper(servlet);
/*  422 */     sw.setName(servletName);
/*  423 */     ctx.addChild(sw);
/*      */     
/*  425 */     return sw;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init(ConfigurationSource source)
/*      */   {
/*  439 */     init(source, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init(ConfigurationSource source, String[] catalinaArguments)
/*      */   {
/*  453 */     ConfigFileLoader.setSource(source);
/*  454 */     this.addDefaultWebXmlToWebapp = false;
/*  455 */     Catalina catalina = new Catalina();
/*      */     
/*      */ 
/*  458 */     if (catalinaArguments == null) {
/*  459 */       catalina.load();
/*      */     } else {
/*  461 */       catalina.load(catalinaArguments);
/*      */     }
/*      */     
/*  464 */     this.server = catalina.getServer();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init()
/*      */     throws LifecycleException
/*      */   {
/*  474 */     getServer();
/*  475 */     this.server.init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void start()
/*      */     throws LifecycleException
/*      */   {
/*  485 */     getServer();
/*  486 */     this.server.start();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stop()
/*      */     throws LifecycleException
/*      */   {
/*  495 */     getServer();
/*  496 */     this.server.stop();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void destroy()
/*      */     throws LifecycleException
/*      */   {
/*  507 */     getServer();
/*  508 */     this.server.destroy();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addUser(String user, String pass)
/*      */   {
/*  519 */     this.userPass.put(user, pass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRole(String user, String role)
/*      */   {
/*  529 */     List<String> roles = (List)this.userRoles.get(user);
/*  530 */     if (roles == null) {
/*  531 */       roles = new ArrayList();
/*  532 */       this.userRoles.put(user, roles);
/*      */     }
/*  534 */     roles.add(role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connector getConnector()
/*      */   {
/*  550 */     Service service = getService();
/*  551 */     if (service.findConnectors().length > 0) {
/*  552 */       return service.findConnectors()[0];
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  558 */     Connector connector = new Connector("HTTP/1.1");
/*  559 */     connector.setPort(this.port);
/*  560 */     service.addConnector(connector);
/*  561 */     return connector;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnector(Connector connector)
/*      */   {
/*  570 */     Service service = getService();
/*  571 */     boolean found = false;
/*  572 */     for (Connector serviceConnector : service.findConnectors()) {
/*  573 */       if (connector == serviceConnector) {
/*  574 */         found = true;
/*  575 */         break;
/*      */       }
/*      */     }
/*  578 */     if (!found) {
/*  579 */       service.addConnector(connector);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Service getService()
/*      */   {
/*  589 */     return getServer().findServices()[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHost(Host host)
/*      */   {
/*  600 */     Engine engine = getEngine();
/*  601 */     boolean found = false;
/*  602 */     for (Container engineHost : engine.findChildren()) {
/*  603 */       if (engineHost == host) {
/*  604 */         found = true;
/*  605 */         break;
/*      */       }
/*      */     }
/*  608 */     if (!found) {
/*  609 */       engine.addChild(host);
/*      */     }
/*      */   }
/*      */   
/*      */   public Host getHost() {
/*  614 */     Engine engine = getEngine();
/*  615 */     if (engine.findChildren().length > 0) {
/*  616 */       return (Host)engine.findChildren()[0];
/*      */     }
/*      */     
/*  619 */     Host host = new StandardHost();
/*  620 */     host.setName(this.hostname);
/*  621 */     getEngine().addChild(host);
/*  622 */     return host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Engine getEngine()
/*      */   {
/*  630 */     Service service = getServer().findServices()[0];
/*  631 */     if (service.getContainer() != null) {
/*  632 */       return service.getContainer();
/*      */     }
/*  634 */     Engine engine = new StandardEngine();
/*  635 */     engine.setName("Tomcat");
/*  636 */     engine.setDefaultHost(this.hostname);
/*  637 */     engine.setRealm(createDefaultRealm());
/*  638 */     service.setContainer(engine);
/*  639 */     return engine;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Server getServer()
/*      */   {
/*  649 */     if (this.server != null) {
/*  650 */       return this.server;
/*      */     }
/*      */     
/*  653 */     System.setProperty("catalina.useNaming", "false");
/*      */     
/*  655 */     this.server = new StandardServer();
/*      */     
/*  657 */     initBaseDir();
/*      */     
/*      */ 
/*  660 */     ConfigFileLoader.setSource(new CatalinaBaseConfigurationSource(new File(this.basedir), null));
/*      */     
/*  662 */     this.server.setPort(-1);
/*      */     
/*  664 */     Service service = new StandardService();
/*  665 */     service.setName("Tomcat");
/*  666 */     this.server.addService(service);
/*  667 */     return this.server;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addContext(Host host, String contextPath, String dir)
/*      */   {
/*  679 */     return addContext(host, contextPath, contextPath, dir);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addContext(Host host, String contextPath, String contextName, String dir)
/*      */   {
/*  693 */     silence(host, contextName);
/*  694 */     Context ctx = createContext(host, contextPath);
/*  695 */     ctx.setName(contextName);
/*  696 */     ctx.setPath(contextPath);
/*  697 */     ctx.setDocBase(dir);
/*  698 */     ctx.addLifecycleListener(new FixContextListener());
/*      */     
/*  700 */     if (host == null) {
/*  701 */       getHost().addChild(ctx);
/*      */     } else {
/*  703 */       host.addChild(ctx);
/*      */     }
/*  705 */     return ctx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addWebapp(Host host, String contextPath, String docBase)
/*      */   {
/*  728 */     LifecycleListener listener = null;
/*      */     try {
/*  730 */       Class<?> clazz = Class.forName(getHost().getConfigClass());
/*  731 */       listener = (LifecycleListener)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */     }
/*      */     catch (ReflectiveOperationException e)
/*      */     {
/*  735 */       throw new IllegalArgumentException(e);
/*      */     }
/*      */     
/*  738 */     return addWebapp(host, contextPath, docBase, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context addWebapp(Host host, String contextPath, String docBase, LifecycleListener config)
/*      */   {
/*  766 */     silence(host, contextPath);
/*      */     
/*  768 */     Context ctx = createContext(host, contextPath);
/*  769 */     ctx.setPath(contextPath);
/*  770 */     ctx.setDocBase(docBase);
/*      */     
/*  772 */     if (this.addDefaultWebXmlToWebapp) {
/*  773 */       ctx.addLifecycleListener(getDefaultWebXmlListener());
/*      */     }
/*      */     
/*  776 */     ctx.setConfigFile(getWebappConfigFile(docBase, contextPath));
/*      */     
/*  778 */     ctx.addLifecycleListener(config);
/*      */     
/*  780 */     if ((this.addDefaultWebXmlToWebapp) && ((config instanceof ContextConfig)))
/*      */     {
/*  782 */       ((ContextConfig)config).setDefaultWebXml(noDefaultWebXmlPath());
/*      */     }
/*      */     
/*  785 */     if (host == null) {
/*  786 */       getHost().addChild(ctx);
/*      */     } else {
/*  788 */       host.addChild(ctx);
/*      */     }
/*      */     
/*  791 */     return ctx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LifecycleListener getDefaultWebXmlListener()
/*      */   {
/*  803 */     return new DefaultWebXmlListener();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String noDefaultWebXmlPath()
/*      */   {
/*  812 */     return "org/apache/catalina/startup/NO_DEFAULT_XML";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Realm createDefaultRealm()
/*      */   {
/*  825 */     return new SimpleRealm(null);
/*      */   }
/*      */   
/*      */   private class SimpleRealm extends RealmBase
/*      */   {
/*      */     private SimpleRealm() {}
/*      */     
/*      */     protected String getPassword(String username) {
/*  833 */       return (String)Tomcat.this.userPass.get(username);
/*      */     }
/*      */     
/*      */     protected Principal getPrincipal(String username)
/*      */     {
/*  838 */       Principal p = (Principal)Tomcat.this.userPrincipals.get(username);
/*  839 */       if (p == null) {
/*  840 */         String pass = (String)Tomcat.this.userPass.get(username);
/*  841 */         if (pass != null)
/*      */         {
/*  843 */           p = new GenericPrincipal(username, pass, (List)Tomcat.this.userRoles.get(username));
/*  844 */           Tomcat.this.userPrincipals.put(username, p);
/*      */         }
/*      */       }
/*  847 */       return p;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void initBaseDir()
/*      */   {
/*  853 */     String catalinaHome = System.getProperty("catalina.home");
/*  854 */     if (this.basedir == null) {
/*  855 */       this.basedir = System.getProperty("catalina.base");
/*      */     }
/*  857 */     if (this.basedir == null) {
/*  858 */       this.basedir = catalinaHome;
/*      */     }
/*  860 */     if (this.basedir == null)
/*      */     {
/*  862 */       this.basedir = (System.getProperty("user.dir") + "/tomcat." + this.port);
/*      */     }
/*      */     
/*  865 */     File baseFile = new File(this.basedir);
/*  866 */     if (baseFile.exists()) {
/*  867 */       if (!baseFile.isDirectory()) {
/*  868 */         throw new IllegalArgumentException(sm.getString("tomcat.baseDirNotDir", new Object[] { baseFile }));
/*      */       }
/*      */     }
/*  871 */     else if (!baseFile.mkdirs())
/*      */     {
/*  873 */       throw new IllegalStateException(sm.getString("tomcat.baseDirMakeFail", new Object[] { baseFile }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  884 */       baseFile = baseFile.getCanonicalFile();
/*      */     } catch (IOException e) {
/*  886 */       baseFile = baseFile.getAbsoluteFile();
/*      */     }
/*  888 */     this.server.setCatalinaBase(baseFile);
/*  889 */     System.setProperty("catalina.base", baseFile.getPath());
/*  890 */     this.basedir = baseFile.getPath();
/*      */     
/*  892 */     if (catalinaHome == null) {
/*  893 */       this.server.setCatalinaHome(baseFile);
/*      */     } else {
/*  895 */       File homeFile = new File(catalinaHome);
/*  896 */       if ((!homeFile.isDirectory()) && (!homeFile.mkdirs()))
/*      */       {
/*  898 */         throw new IllegalStateException(sm.getString("tomcat.homeDirMakeFail", new Object[] { homeFile }));
/*      */       }
/*      */       try {
/*  901 */         homeFile = homeFile.getCanonicalFile();
/*      */       } catch (IOException e) {
/*  903 */         homeFile = homeFile.getAbsoluteFile();
/*      */       }
/*  905 */       this.server.setCatalinaHome(homeFile);
/*      */     }
/*  907 */     System.setProperty("catalina.home", this.server
/*  908 */       .getCatalinaHome().getPath());
/*      */   }
/*      */   
/*  911 */   static final String[] silences = { "org.apache.coyote.http11.Http11NioProtocol", "org.apache.catalina.core.StandardService", "org.apache.catalina.core.StandardEngine", "org.apache.catalina.startup.ContextConfig", "org.apache.catalina.core.ApplicationContext", "org.apache.catalina.core.AprLifecycleListener" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  920 */   private boolean silent = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSilent(boolean silent)
/*      */   {
/*  931 */     this.silent = silent;
/*  932 */     for (String s : silences) {
/*  933 */       Logger logger = Logger.getLogger(s);
/*  934 */       this.pinnedLoggers.put(s, logger);
/*  935 */       if (silent) {
/*  936 */         logger.setLevel(Level.WARNING);
/*      */       } else {
/*  938 */         logger.setLevel(Level.INFO);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void silence(Host host, String contextPath) {
/*  944 */     String loggerName = getLoggerName(host, contextPath);
/*  945 */     Logger logger = Logger.getLogger(loggerName);
/*  946 */     this.pinnedLoggers.put(loggerName, logger);
/*  947 */     if (this.silent) {
/*  948 */       logger.setLevel(Level.WARNING);
/*      */     } else {
/*  950 */       logger.setLevel(Level.INFO);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAddDefaultWebXmlToWebapp(boolean addDefaultWebXmlToWebapp)
/*      */   {
/*  969 */     this.addDefaultWebXmlToWebapp = addDefaultWebXmlToWebapp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getLoggerName(Host host, String contextName)
/*      */   {
/*  977 */     if (host == null) {
/*  978 */       host = getHost();
/*      */     }
/*  980 */     StringBuilder loggerName = new StringBuilder();
/*  981 */     loggerName.append(ContainerBase.class.getName());
/*  982 */     loggerName.append(".[");
/*      */     
/*  984 */     loggerName.append(host.getParent().getName());
/*  985 */     loggerName.append("].[");
/*      */     
/*  987 */     loggerName.append(host.getName());
/*  988 */     loggerName.append("].[");
/*      */     
/*  990 */     if ((contextName == null) || (contextName.equals(""))) {
/*  991 */       loggerName.append('/');
/*  992 */     } else if (contextName.startsWith("##")) {
/*  993 */       loggerName.append('/');
/*  994 */       loggerName.append(contextName);
/*      */     }
/*  996 */     loggerName.append(']');
/*      */     
/*  998 */     return loggerName.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Context createContext(Host host, String url)
/*      */   {
/* 1014 */     String defaultContextClass = StandardContext.class.getName();
/* 1015 */     String contextClass = StandardContext.class.getName();
/* 1016 */     if (host == null) {
/* 1017 */       host = getHost();
/*      */     }
/* 1019 */     if ((host instanceof StandardHost)) {
/* 1020 */       contextClass = ((StandardHost)host).getContextClass();
/*      */     }
/*      */     try {
/* 1023 */       if (defaultContextClass.equals(contextClass)) {
/* 1024 */         return new StandardContext();
/*      */       }
/* 1026 */       return 
/* 1027 */         (Context)Class.forName(contextClass).getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */     }
/*      */     catch (ReflectiveOperationException|IllegalArgumentException|SecurityException e)
/*      */     {
/* 1031 */       throw new IllegalArgumentException(sm.getString("tomcat.noContextClass", new Object[] { contextClass, host, url }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void enableNaming()
/*      */   {
/* 1044 */     getServer();
/* 1045 */     this.server.addLifecycleListener(new NamingContextListener());
/*      */     
/* 1047 */     System.setProperty("catalina.useNaming", "true");
/*      */     
/* 1049 */     String value = "org.apache.naming";
/*      */     
/* 1051 */     String oldValue = System.getProperty("java.naming.factory.url.pkgs");
/* 1052 */     if (oldValue != null) {
/* 1053 */       if (oldValue.contains(value)) {
/* 1054 */         value = oldValue;
/*      */       } else {
/* 1056 */         value = value + ":" + oldValue;
/*      */       }
/*      */     }
/* 1059 */     System.setProperty("java.naming.factory.url.pkgs", value);
/*      */     
/*      */ 
/* 1062 */     value = System.getProperty("java.naming.factory.initial");
/* 1063 */     if (value == null)
/*      */     {
/* 1065 */       System.setProperty("java.naming.factory.initial", "org.apache.naming.java.javaURLContextFactory");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void initWebappDefaults(String contextPath)
/*      */   {
/* 1088 */     Container ctx = getHost().findChild(contextPath);
/* 1089 */     initWebappDefaults((Context)ctx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void initWebappDefaults(Context ctx)
/*      */   {
/* 1100 */     Wrapper servlet = addServlet(ctx, "default", "org.apache.catalina.servlets.DefaultServlet");
/*      */     
/* 1102 */     servlet.setLoadOnStartup(1);
/* 1103 */     servlet.setOverridable(true);
/*      */     
/*      */ 
/* 1106 */     servlet = addServlet(ctx, "jsp", "org.apache.jasper.servlet.JspServlet");
/*      */     
/* 1108 */     servlet.addInitParameter("fork", "false");
/* 1109 */     servlet.setLoadOnStartup(3);
/* 1110 */     servlet.setOverridable(true);
/*      */     
/*      */ 
/* 1113 */     ctx.addServletMappingDecoded("/", "default");
/* 1114 */     ctx.addServletMappingDecoded("*.jsp", "jsp");
/* 1115 */     ctx.addServletMappingDecoded("*.jspx", "jsp");
/*      */     
/*      */ 
/* 1118 */     ctx.setSessionTimeout(30);
/*      */     
/*      */ 
/* 1121 */     addDefaultMimeTypeMappings(ctx);
/*      */     
/*      */ 
/* 1124 */     ctx.addWelcomeFile("index.html");
/* 1125 */     ctx.addWelcomeFile("index.htm");
/* 1126 */     ctx.addWelcomeFile("index.jsp");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void addDefaultMimeTypeMappings(Context context)
/*      */   {
/* 1137 */     Properties defaultMimeMappings = new Properties();
/* 1138 */     try { InputStream is = Tomcat.class.getResourceAsStream("MimeTypeMappings.properties");Throwable localThrowable3 = null;
/* 1139 */       try { defaultMimeMappings.load(is);
/* 1140 */         for (Map.Entry<Object, Object> entry : defaultMimeMappings.entrySet()) {
/* 1141 */           context.addMimeMapping((String)entry.getKey(), (String)entry.getValue());
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable5)
/*      */       {
/* 1138 */         localThrowable3 = localThrowable5;throw localThrowable5;
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/* 1143 */         if (is != null) if (localThrowable3 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else is.close();
/* 1144 */       } } catch (IOException e) { throw new IllegalStateException(sm.getString("tomcat.defaultMimeTypeMappingsFail"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class FixContextListener
/*      */     implements LifecycleListener
/*      */   {
/*      */     public void lifecycleEvent(LifecycleEvent event)
/*      */     {
/*      */       try
/*      */       {
/* 1161 */         Context context = (Context)event.getLifecycle();
/* 1162 */         if (event.getType().equals("configure_start")) {
/* 1163 */           context.setConfigured(true);
/*      */           
/*      */ 
/*      */ 
/* 1167 */           if (!JreCompat.isGraalAvailable()) {
/* 1168 */             WebAnnotationSet.loadApplicationAnnotations(context);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1173 */           if (context.getLoginConfig() == null) {
/* 1174 */             context.setLoginConfig(new LoginConfig("NONE", null, null, null));
/* 1175 */             context.getPipeline().addValve(new NonLoginAuthenticator());
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (ClassCastException localClassCastException) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class DefaultWebXmlListener
/*      */     implements LifecycleListener
/*      */   {
/*      */     public void lifecycleEvent(LifecycleEvent event)
/*      */     {
/* 1192 */       if ("before_start".equals(event.getType())) {
/* 1193 */         Tomcat.initWebappDefaults((Context)event.getLifecycle());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static class ExistingStandardWrapper
/*      */     extends StandardWrapper
/*      */   {
/*      */     private final Servlet existing;
/*      */     
/*      */ 
/*      */ 
/*      */     public ExistingStandardWrapper(Servlet existing)
/*      */     {
/* 1209 */       this.existing = existing;
/* 1210 */       if ((existing instanceof SingleThreadModel)) {
/* 1211 */         this.singleThreadModel = true;
/* 1212 */         this.instancePool = new Stack();
/*      */       }
/* 1214 */       this.asyncSupported = hasAsync(existing);
/*      */     }
/*      */     
/*      */     private static boolean hasAsync(Servlet existing) {
/* 1218 */       boolean result = false;
/* 1219 */       Class<?> clazz = existing.getClass();
/* 1220 */       WebServlet ws = (WebServlet)clazz.getAnnotation(WebServlet.class);
/* 1221 */       if (ws != null) {
/* 1222 */         result = ws.asyncSupported();
/*      */       }
/* 1224 */       return result;
/*      */     }
/*      */     
/*      */     public synchronized Servlet loadServlet()
/*      */       throws ServletException
/*      */     {
/* 1230 */       if (this.singleThreadModel)
/*      */       {
/*      */         try {
/* 1233 */           instance = (Servlet)this.existing.getClass().getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */         } catch (ReflectiveOperationException e) { Servlet instance;
/* 1235 */           throw new ServletException(e); }
/*      */         Servlet instance;
/* 1237 */         instance.init(this.facade);
/* 1238 */         return instance;
/*      */       }
/* 1240 */       if (!this.instanceInitialized) {
/* 1241 */         this.existing.init(this.facade);
/* 1242 */         this.instanceInitialized = true;
/*      */       }
/* 1244 */       return this.existing;
/*      */     }
/*      */     
/*      */     public long getAvailable()
/*      */     {
/* 1249 */       return 0L;
/*      */     }
/*      */     
/*      */     public boolean isUnavailable() {
/* 1253 */       return false;
/*      */     }
/*      */     
/*      */     public Servlet getServlet() {
/* 1257 */       return this.existing;
/*      */     }
/*      */     
/*      */     public String getServletClass() {
/* 1261 */       return this.existing.getClass().getName();
/*      */     }
/*      */   }
/*      */   
/*      */   protected URL getWebappConfigFile(String path, String contextName) {
/* 1266 */     File docBase = new File(path);
/* 1267 */     if (docBase.isDirectory()) {
/* 1268 */       return getWebappConfigFileFromDirectory(docBase, contextName);
/*      */     }
/* 1270 */     return getWebappConfigFileFromWar(docBase, contextName);
/*      */   }
/*      */   
/*      */   private URL getWebappConfigFileFromDirectory(File docBase, String contextName)
/*      */   {
/* 1275 */     URL result = null;
/* 1276 */     File webAppContextXml = new File(docBase, "META-INF/context.xml");
/* 1277 */     if (webAppContextXml.exists()) {
/*      */       try {
/* 1279 */         result = webAppContextXml.toURI().toURL();
/*      */       } catch (MalformedURLException e) {
/* 1281 */         Logger.getLogger(getLoggerName(getHost(), contextName)).log(Level.WARNING, sm
/* 1282 */           .getString("tomcat.noContextXml", new Object[] { docBase }), e);
/*      */       }
/*      */     }
/* 1285 */     return result;
/*      */   }
/*      */   
/*      */   private URL getWebappConfigFileFromWar(File docBase, String contextName) {
/* 1289 */     URL result = null;
/* 1290 */     try { JarFile jar = new JarFile(docBase);Throwable localThrowable3 = null;
/* 1291 */       try { JarEntry entry = jar.getJarEntry("META-INF/context.xml");
/* 1292 */         if (entry != null) {
/* 1293 */           result = UriUtil.buildJarUrl(docBase, "META-INF/context.xml");
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable1)
/*      */       {
/* 1290 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/* 1295 */         if (jar != null) if (localThrowable3 != null) try { jar.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else jar.close();
/* 1296 */       } } catch (IOException e) { Logger.getLogger(getLoggerName(getHost(), contextName)).log(Level.WARNING, sm
/* 1297 */         .getString("tomcat.noContextXml", new Object[] { docBase }), e);
/*      */     }
/* 1299 */     return result;
/*      */   }
/*      */   
/*      */   static
/*      */   {
/* 1304 */     if (JreCompat.isGraalAvailable()) {
/* 1305 */       try { InputStream is = new FileInputStream(new File(System.getProperty("java.util.logging.config.file", "conf/logging.properties")));Throwable localThrowable3 = null;
/* 1306 */         try { LogManager.getLogManager().readConfiguration(is);
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/* 1305 */           localThrowable3 = localThrowable1;throw localThrowable1;
/*      */         } finally {
/* 1307 */           if (is != null) { if (localThrowable3 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else { is.close();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (SecurityException|IOException localSecurityException) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static void main(String[] args)
/*      */     throws Exception
/*      */   {
/* 1320 */     String[] catalinaArguments = null;
/* 1321 */     for (int i = 0; i < args.length; i++) {
/* 1322 */       if (args[i].equals("--no-jmx")) {
/* 1323 */         Registry.disableRegistry();
/* 1324 */       } else if (args[i].equals("--catalina"))
/*      */       {
/*      */ 
/* 1327 */         ArrayList<String> result = new ArrayList();
/* 1328 */         for (int j = i + 1; j < args.length; j++) {
/* 1329 */           result.add(args[j]);
/*      */         }
/* 1331 */         catalinaArguments = (String[])result.toArray(new String[0]);
/* 1332 */         break;
/*      */       }
/*      */     }
/* 1335 */     SecurityClassLoad.securityClassLoad(Thread.currentThread().getContextClassLoader());
/* 1336 */     Tomcat tomcat = new Tomcat();
/*      */     
/*      */ 
/*      */ 
/* 1340 */     tomcat.init(null, catalinaArguments);
/* 1341 */     boolean await = false;
/* 1342 */     String path = "";
/*      */     
/* 1344 */     for (int i = 0; i < args.length; i++) {
/* 1345 */       if (args[i].equals("--war")) {
/* 1346 */         i++; if (i >= args.length) {
/* 1347 */           throw new IllegalArgumentException(sm.getString("tomcat.invalidCommandLine", new Object[] { args[(i - 1)] }));
/*      */         }
/* 1349 */         File war = new File(args[i]);
/* 1350 */         tomcat.addWebapp(path, war.getAbsolutePath());
/* 1351 */       } else if (args[i].equals("--path")) {
/* 1352 */         i++; if (i >= args.length) {
/* 1353 */           throw new IllegalArgumentException(sm.getString("tomcat.invalidCommandLine", new Object[] { args[(i - 1)] }));
/*      */         }
/* 1355 */         path = args[i];
/* 1356 */       } else if (args[i].equals("--await")) {
/* 1357 */         await = true;
/* 1358 */       } else if (!args[i].equals("--no-jmx"))
/*      */       {
/* 1360 */         if (args[i].equals("--catalina")) {
/*      */           break;
/*      */         }
/*      */         
/*      */ 
/* 1365 */         throw new IllegalArgumentException(sm.getString("tomcat.invalidCommandLine", new Object[] { args[i] }));
/*      */       }
/*      */     }
/* 1368 */     tomcat.start();
/*      */     
/* 1370 */     if (await) {
/* 1371 */       tomcat.getServer().await();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\Tomcat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */