/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.GenericFilter;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebdavFixFilter
/*     */   extends GenericFilter
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  64 */   protected static final StringManager sm = StringManager.getManager(WebdavFixFilter.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String UA_MINIDIR_START = "Microsoft-WebDAV-MiniRedir";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String UA_MINIDIR_5_1_2600 = "Microsoft-WebDAV-MiniRedir/5.1.2600";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String UA_MINIDIR_5_2_3790 = "Microsoft-WebDAV-MiniRedir/5.2.3790";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  84 */     if ((!(request instanceof HttpServletRequest)) || (!(response instanceof HttpServletResponse)))
/*     */     {
/*  86 */       chain.doFilter(request, response);
/*  87 */       return;
/*     */     }
/*  89 */     HttpServletRequest httpRequest = (HttpServletRequest)request;
/*  90 */     HttpServletResponse httpResponse = (HttpServletResponse)response;
/*  91 */     String ua = httpRequest.getHeader("User-Agent");
/*     */     
/*  93 */     if ((ua == null) || (ua.length() == 0) || 
/*  94 */       (!ua.startsWith("Microsoft-WebDAV-MiniRedir")))
/*     */     {
/*     */ 
/*  97 */       chain.doFilter(request, response);
/*  98 */     } else if (ua.startsWith("Microsoft-WebDAV-MiniRedir/5.1.2600"))
/*     */     {
/* 100 */       httpResponse.sendRedirect(buildRedirect(httpRequest));
/* 101 */     } else if (ua.startsWith("Microsoft-WebDAV-MiniRedir/5.2.3790"))
/*     */     {
/* 103 */       if (!httpRequest.getContextPath().isEmpty()) {
/* 104 */         getServletContext().log(sm.getString("webDavFilter.xpRootContext"));
/*     */       }
/*     */       
/*     */ 
/* 108 */       getServletContext().log(sm.getString("webDavFilter.xpProblem"));
/*     */       
/* 110 */       chain.doFilter(request, response);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 115 */       httpResponse.sendRedirect(buildRedirect(httpRequest));
/*     */     }
/*     */   }
/*     */   
/*     */   private String buildRedirect(HttpServletRequest request)
/*     */   {
/* 121 */     StringBuilder location = new StringBuilder(request.getRequestURL().length());
/* 122 */     location.append(request.getScheme());
/* 123 */     location.append("://");
/* 124 */     location.append(request.getServerName());
/* 125 */     location.append(':');
/*     */     
/*     */ 
/*     */ 
/* 129 */     location.append(request.getServerPort());
/* 130 */     location.append(request.getRequestURI());
/* 131 */     return location.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\filters\WebdavFixFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */