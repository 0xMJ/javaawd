/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import org.apache.catalina.UserDatabase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericRole<UD extends UserDatabase>
/*     */   extends AbstractRole
/*     */ {
/*     */   protected final UserDatabase database;
/*     */   
/*     */   GenericRole(UD database, String rolename, String description)
/*     */   {
/*  49 */     this.database = database;
/*  50 */     this.rolename = rolename;
/*  51 */     this.description = description;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UserDatabase getUserDatabase()
/*     */   {
/*  73 */     return this.database;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDescription(String description)
/*     */   {
/*  79 */     this.database.modifiedRole(this);
/*  80 */     super.setDescription(description);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setRolename(String rolename)
/*     */   {
/*  86 */     this.database.modifiedRole(this);
/*  87 */     super.setRolename(rolename);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  93 */     if ((obj instanceof GenericRole)) {
/*  94 */       GenericRole<?> role = (GenericRole)obj;
/*  95 */       return (role.database == this.database) && (this.rolename.equals(role.getRolename()));
/*     */     }
/*  97 */     return super.equals(obj);
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 103 */     int prime = 31;
/* 104 */     int result = 1;
/* 105 */     result = 31 * result + (this.database == null ? 0 : this.database.hashCode());
/* 106 */     result = 31 * result + (this.rolename == null ? 0 : this.rolename.hashCode());
/* 107 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\users\GenericRole.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */