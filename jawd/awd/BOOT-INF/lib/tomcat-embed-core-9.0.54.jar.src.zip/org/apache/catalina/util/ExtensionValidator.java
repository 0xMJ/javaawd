/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.jar.JarInputStream;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExtensionValidator
/*     */ {
/*  51 */   private static final Log log = LogFactory.getLog(ExtensionValidator.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  57 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.util");
/*     */   
/*  59 */   private static volatile List<Extension> containerAvailableExtensions = null;
/*  60 */   private static final List<ManifestResource> containerManifestResources = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  78 */     String systemClasspath = System.getProperty("java.class.path");
/*     */     
/*  80 */     StringTokenizer strTok = new StringTokenizer(systemClasspath, File.pathSeparator);
/*     */     
/*     */ 
/*     */ 
/*  84 */     while (strTok.hasMoreTokens()) {
/*  85 */       String classpathItem = strTok.nextToken();
/*  86 */       if (classpathItem.toLowerCase(Locale.ENGLISH).endsWith(".jar")) {
/*  87 */         File item = new File(classpathItem);
/*  88 */         if (item.isFile()) {
/*     */           try {
/*  90 */             addSystemResource(item);
/*     */           } catch (IOException e) {
/*  92 */             log.error(sm
/*  93 */               .getString("extensionValidator.failload", new Object[] { item }), e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 100 */     addFolderList("java.ext.dirs");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized boolean validateApplication(WebResourceRoot resources, Context context)
/*     */     throws IOException
/*     */   {
/* 130 */     String appName = context.getName();
/* 131 */     List<ManifestResource> appManifestResources = new ArrayList();
/*     */     
/*     */ 
/* 134 */     WebResource resource = resources.getResource("/META-INF/MANIFEST.MF");
/* 135 */     if (resource.isFile()) {
/* 136 */       InputStream inputStream = resource.getInputStream();localObject1 = null;
/* 137 */       try { Manifest manifest = new Manifest(inputStream);
/*     */         
/* 139 */         mre = new ManifestResource(sm.getString("extensionValidator.web-application-manifest"), manifest, 2);
/*     */         
/* 141 */         appManifestResources.add(mre);
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 136 */         localObject1 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/* 142 */         if (inputStream != null) { if (localObject1 != null) try { inputStream.close(); } catch (Throwable localThrowable2) { ((Throwable)localObject1).addSuppressed(localThrowable2); } else { inputStream.close();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 147 */     WebResource[] manifestResources = resources.getClassLoaderResources("/META-INF/MANIFEST.MF");
/* 148 */     Object localObject1 = manifestResources;localThrowable1 = localObject1.length; for (ManifestResource mre = 0; mre < localThrowable1; mre++) { WebResource manifestResource = localObject1[mre];
/* 149 */       if (manifestResource.isFile())
/*     */       {
/* 151 */         String jarName = manifestResource.getURL().toExternalForm();
/* 152 */         Manifest jmanifest = manifestResource.getManifest();
/* 153 */         if (jmanifest != null) {
/* 154 */           ManifestResource mre = new ManifestResource(jarName, jmanifest, 3);
/*     */           
/* 156 */           appManifestResources.add(mre);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 161 */     return validateManifestResources(appName, appManifestResources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addSystemResource(File jarFile)
/*     */     throws IOException
/*     */   {
/* 173 */     InputStream is = new FileInputStream(jarFile);Throwable localThrowable3 = null;
/* 174 */     try { Manifest manifest = getManifest(is);
/* 175 */       if (manifest != null) {
/* 176 */         ManifestResource mre = new ManifestResource(jarFile.getAbsolutePath(), manifest, 1);
/*     */         
/* 178 */         containerManifestResources.add(mre);
/*     */       }
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 173 */       localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/* 180 */       if (is != null) { if (localThrowable3 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else { is.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean validateManifestResources(String appName, List<ManifestResource> resources)
/*     */   {
/* 208 */     boolean passes = true;
/* 209 */     int failureCount = 0;
/* 210 */     List<Extension> availableExtensions = null;
/*     */     
/* 212 */     for (Iterator localIterator1 = resources.iterator(); localIterator1.hasNext();) { mre = (ManifestResource)localIterator1.next();
/* 213 */       ArrayList<Extension> requiredList = mre.getRequiredExtensions();
/* 214 */       if (requiredList != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 219 */         if (availableExtensions == null) {
/* 220 */           availableExtensions = buildAvailableExtensionsList(resources);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 225 */         if (containerAvailableExtensions == null)
/*     */         {
/* 227 */           containerAvailableExtensions = buildAvailableExtensionsList(containerManifestResources);
/*     */         }
/*     */         
/*     */ 
/* 231 */         for (Extension requiredExt : requiredList) {
/* 232 */           boolean found = false;
/*     */           
/* 234 */           if (availableExtensions != null) {
/* 235 */             for (Extension targetExt : availableExtensions) {
/* 236 */               if (targetExt.isCompatibleWith(requiredExt)) {
/* 237 */                 requiredExt.setFulfilled(true);
/* 238 */                 found = true;
/* 239 */                 break;
/*     */               }
/*     */             }
/*     */           }
/*     */           
/* 244 */           if ((!found) && (containerAvailableExtensions != null)) {
/* 245 */             for (Extension targetExt : containerAvailableExtensions) {
/* 246 */               if (targetExt.isCompatibleWith(requiredExt)) {
/* 247 */                 requiredExt.setFulfilled(true);
/* 248 */                 found = true;
/* 249 */                 break;
/*     */               }
/*     */             }
/*     */           }
/* 253 */           if (!found)
/*     */           {
/* 255 */             log.info(sm.getString("extensionValidator.extension-not-found-error", new Object[] { appName, mre
/*     */             
/* 257 */               .getResourceName(), requiredExt
/* 258 */               .getExtensionName() }));
/* 259 */             passes = false;
/* 260 */             failureCount++;
/*     */           }
/*     */         }
/*     */       } }
/*     */     ManifestResource mre;
/* 265 */     if (!passes) {
/* 266 */       log.info(sm.getString("extensionValidator.extension-validation-error", new Object[] { appName, failureCount + "" }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 271 */     return passes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static List<Extension> buildAvailableExtensionsList(List<ManifestResource> resources)
/*     */   {
/* 294 */     List<Extension> availableList = null;
/*     */     
/* 296 */     for (ManifestResource mre : resources) {
/* 297 */       ArrayList<Extension> list = mre.getAvailableExtensions();
/* 298 */       if (list != null) {
/* 299 */         for (Extension ext : list) {
/* 300 */           if (availableList == null) {
/* 301 */             availableList = new ArrayList();
/* 302 */             availableList.add(ext);
/*     */           } else {
/* 304 */             availableList.add(ext);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 310 */     return availableList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Manifest getManifest(InputStream inStream)
/*     */     throws IOException
/*     */   {
/* 320 */     Manifest manifest = null;
/* 321 */     JarInputStream jin = new JarInputStream(inStream);Throwable localThrowable3 = null;
/* 322 */     try { manifest = jin.getManifest();
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 321 */       localThrowable3 = localThrowable1;throw localThrowable1;
/*     */     } finally {
/* 323 */       if (jin != null) if (localThrowable3 != null) try { jin.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else jin.close(); }
/* 324 */     return manifest;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void addFolderList(String property)
/*     */   {
/* 334 */     String extensionsDir = System.getProperty(property);
/* 335 */     if (extensionsDir != null) {
/* 336 */       StringTokenizer extensionsTok = new StringTokenizer(extensionsDir, File.pathSeparator);
/*     */       
/* 338 */       while (extensionsTok.hasMoreTokens()) {
/* 339 */         File targetDir = new File(extensionsTok.nextToken());
/* 340 */         if (targetDir.isDirectory())
/*     */         {
/*     */ 
/* 343 */           File[] files = targetDir.listFiles();
/* 344 */           if (files != null)
/*     */           {
/*     */ 
/* 347 */             for (File file : files) {
/* 348 */               if ((file.getName().toLowerCase(Locale.ENGLISH).endsWith(".jar")) && (file.isFile())) {
/*     */                 try {
/* 350 */                   addSystemResource(file);
/*     */                 } catch (IOException e) {
/* 352 */                   log.error(sm.getString("extensionValidator.failload", new Object[] { file }), e);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\ExtensionValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */