/*      */ package org.apache.catalina.filters;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.servlet.FilterChain;
/*      */ import javax.servlet.FilterConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.WriteListener;
/*      */ import javax.servlet.http.HttpServletMapping;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpServletResponseWrapper;
/*      */ import javax.servlet.http.MappingMatch;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ExpiresFilter
/*      */   extends FilterBase
/*      */ {
/*      */   protected static class Duration
/*      */   {
/*      */     protected final int amount;
/*      */     protected final ExpiresFilter.DurationUnit unit;
/*      */     
/*      */     public Duration(int amount, ExpiresFilter.DurationUnit unit)
/*      */     {
/*  443 */       this.amount = amount;
/*  444 */       this.unit = unit;
/*      */     }
/*      */     
/*      */     public int getAmount() {
/*  448 */       return this.amount;
/*      */     }
/*      */     
/*      */     public ExpiresFilter.DurationUnit getUnit() {
/*  452 */       return this.unit;
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/*  457 */       return this.amount + " " + this.unit;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static enum DurationUnit
/*      */   {
/*  465 */     DAY(6),  HOUR(10),  MINUTE(12),  MONTH(2), 
/*  466 */     SECOND(13),  WEEK(3), 
/*  467 */     YEAR(1);
/*      */     
/*      */     private final int calendarField;
/*      */     
/*  471 */     private DurationUnit(int calendarField) { this.calendarField = calendarField; }
/*      */     
/*      */     public int getCalendardField()
/*      */     {
/*  475 */       return this.calendarField;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static class ExpiresConfiguration
/*      */   {
/*      */     private final List<ExpiresFilter.Duration> durations;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final ExpiresFilter.StartingPoint startingPoint;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public ExpiresConfiguration(ExpiresFilter.StartingPoint startingPoint, List<ExpiresFilter.Duration> durations)
/*      */     {
/*  502 */       this.startingPoint = startingPoint;
/*  503 */       this.durations = durations;
/*      */     }
/*      */     
/*      */     public List<ExpiresFilter.Duration> getDurations() {
/*  507 */       return this.durations;
/*      */     }
/*      */     
/*      */     public ExpiresFilter.StartingPoint getStartingPoint() {
/*  511 */       return this.startingPoint;
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/*  516 */       return "ExpiresConfiguration[startingPoint=" + this.startingPoint + ", duration=" + this.durations + "]";
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static enum StartingPoint
/*      */   {
/*  528 */     ACCESS_TIME,  LAST_MODIFICATION_TIME;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private StartingPoint() {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public class XHttpServletResponse
/*      */     extends HttpServletResponseWrapper
/*      */   {
/*      */     private String cacheControlHeader;
/*      */     
/*      */ 
/*      */ 
/*      */     private long lastModifiedHeader;
/*      */     
/*      */ 
/*      */ 
/*      */     private boolean lastModifiedHeaderSet;
/*      */     
/*      */ 
/*      */ 
/*      */     private PrintWriter printWriter;
/*      */     
/*      */ 
/*      */ 
/*      */     private final HttpServletRequest request;
/*      */     
/*      */ 
/*      */ 
/*      */     private ServletOutputStream servletOutputStream;
/*      */     
/*      */ 
/*      */ 
/*      */     private boolean writeResponseBodyStarted;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public XHttpServletResponse(HttpServletRequest request, HttpServletResponse response)
/*      */     {
/*  574 */       super();
/*  575 */       this.request = request;
/*      */     }
/*      */     
/*      */     public void addDateHeader(String name, long date)
/*      */     {
/*  580 */       super.addDateHeader(name, date);
/*  581 */       if (!this.lastModifiedHeaderSet) {
/*  582 */         this.lastModifiedHeader = date;
/*  583 */         this.lastModifiedHeaderSet = true;
/*      */       }
/*      */     }
/*      */     
/*      */     public void addHeader(String name, String value)
/*      */     {
/*  589 */       super.addHeader(name, value);
/*  590 */       if (("Cache-Control".equalsIgnoreCase(name)) && (this.cacheControlHeader == null))
/*      */       {
/*  592 */         this.cacheControlHeader = value;
/*      */       }
/*      */     }
/*      */     
/*      */     public String getCacheControlHeader() {
/*  597 */       return this.cacheControlHeader;
/*      */     }
/*      */     
/*      */     public long getLastModifiedHeader() {
/*  601 */       return this.lastModifiedHeader;
/*      */     }
/*      */     
/*      */     public ServletOutputStream getOutputStream() throws IOException
/*      */     {
/*  606 */       if (this.servletOutputStream == null)
/*      */       {
/*  608 */         this.servletOutputStream = new ExpiresFilter.XServletOutputStream(ExpiresFilter.this, super.getOutputStream(), this.request, this);
/*      */       }
/*  610 */       return this.servletOutputStream;
/*      */     }
/*      */     
/*      */     public PrintWriter getWriter() throws IOException
/*      */     {
/*  615 */       if (this.printWriter == null) {
/*  616 */         this.printWriter = new ExpiresFilter.XPrintWriter(ExpiresFilter.this, super.getWriter(), this.request, this);
/*      */       }
/*  618 */       return this.printWriter;
/*      */     }
/*      */     
/*      */     public boolean isLastModifiedHeaderSet() {
/*  622 */       return this.lastModifiedHeaderSet;
/*      */     }
/*      */     
/*      */     public boolean isWriteResponseBodyStarted() {
/*  626 */       return this.writeResponseBodyStarted;
/*      */     }
/*      */     
/*      */     public void reset()
/*      */     {
/*  631 */       super.reset();
/*  632 */       this.lastModifiedHeader = 0L;
/*  633 */       this.lastModifiedHeaderSet = false;
/*  634 */       this.cacheControlHeader = null;
/*      */     }
/*      */     
/*      */     public void setDateHeader(String name, long date)
/*      */     {
/*  639 */       super.setDateHeader(name, date);
/*  640 */       if ("Last-Modified".equalsIgnoreCase(name)) {
/*  641 */         this.lastModifiedHeader = date;
/*  642 */         this.lastModifiedHeaderSet = true;
/*      */       }
/*      */     }
/*      */     
/*      */     public void setHeader(String name, String value)
/*      */     {
/*  648 */       super.setHeader(name, value);
/*  649 */       if ("Cache-Control".equalsIgnoreCase(name)) {
/*  650 */         this.cacheControlHeader = value;
/*      */       }
/*      */     }
/*      */     
/*      */     public void setWriteResponseBodyStarted(boolean writeResponseBodyStarted) {
/*  655 */       this.writeResponseBodyStarted = writeResponseBodyStarted;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public class XPrintWriter
/*      */     extends PrintWriter
/*      */   {
/*      */     private final PrintWriter out;
/*      */     
/*      */     private final HttpServletRequest request;
/*      */     
/*      */     private final ExpiresFilter.XHttpServletResponse response;
/*      */     
/*      */ 
/*      */     public XPrintWriter(PrintWriter out, HttpServletRequest request, ExpiresFilter.XHttpServletResponse response)
/*      */     {
/*  672 */       super();
/*  673 */       this.out = out;
/*  674 */       this.request = request;
/*  675 */       this.response = response;
/*      */     }
/*      */     
/*      */     public PrintWriter append(char c)
/*      */     {
/*  680 */       fireBeforeWriteResponseBodyEvent();
/*  681 */       return this.out.append(c);
/*      */     }
/*      */     
/*      */     public PrintWriter append(CharSequence csq)
/*      */     {
/*  686 */       fireBeforeWriteResponseBodyEvent();
/*  687 */       return this.out.append(csq);
/*      */     }
/*      */     
/*      */     public PrintWriter append(CharSequence csq, int start, int end)
/*      */     {
/*  692 */       fireBeforeWriteResponseBodyEvent();
/*  693 */       return this.out.append(csq, start, end);
/*      */     }
/*      */     
/*      */     public void close()
/*      */     {
/*  698 */       fireBeforeWriteResponseBodyEvent();
/*  699 */       this.out.close();
/*      */     }
/*      */     
/*      */     private void fireBeforeWriteResponseBodyEvent() {
/*  703 */       if (!this.response.isWriteResponseBodyStarted()) {
/*  704 */         this.response.setWriteResponseBodyStarted(true);
/*  705 */         ExpiresFilter.this.onBeforeWriteResponseBody(this.request, this.response);
/*      */       }
/*      */     }
/*      */     
/*      */     public void flush()
/*      */     {
/*  711 */       fireBeforeWriteResponseBodyEvent();
/*  712 */       this.out.flush();
/*      */     }
/*      */     
/*      */     public void print(boolean b)
/*      */     {
/*  717 */       fireBeforeWriteResponseBodyEvent();
/*  718 */       this.out.print(b);
/*      */     }
/*      */     
/*      */     public void print(char c)
/*      */     {
/*  723 */       fireBeforeWriteResponseBodyEvent();
/*  724 */       this.out.print(c);
/*      */     }
/*      */     
/*      */     public void print(char[] s)
/*      */     {
/*  729 */       fireBeforeWriteResponseBodyEvent();
/*  730 */       this.out.print(s);
/*      */     }
/*      */     
/*      */     public void print(double d)
/*      */     {
/*  735 */       fireBeforeWriteResponseBodyEvent();
/*  736 */       this.out.print(d);
/*      */     }
/*      */     
/*      */     public void print(float f)
/*      */     {
/*  741 */       fireBeforeWriteResponseBodyEvent();
/*  742 */       this.out.print(f);
/*      */     }
/*      */     
/*      */     public void print(int i)
/*      */     {
/*  747 */       fireBeforeWriteResponseBodyEvent();
/*  748 */       this.out.print(i);
/*      */     }
/*      */     
/*      */     public void print(long l)
/*      */     {
/*  753 */       fireBeforeWriteResponseBodyEvent();
/*  754 */       this.out.print(l);
/*      */     }
/*      */     
/*      */     public void print(Object obj)
/*      */     {
/*  759 */       fireBeforeWriteResponseBodyEvent();
/*  760 */       this.out.print(obj);
/*      */     }
/*      */     
/*      */     public void print(String s)
/*      */     {
/*  765 */       fireBeforeWriteResponseBodyEvent();
/*  766 */       this.out.print(s);
/*      */     }
/*      */     
/*      */     public PrintWriter printf(Locale l, String format, Object... args)
/*      */     {
/*  771 */       fireBeforeWriteResponseBodyEvent();
/*  772 */       return this.out.printf(l, format, args);
/*      */     }
/*      */     
/*      */     public PrintWriter printf(String format, Object... args)
/*      */     {
/*  777 */       fireBeforeWriteResponseBodyEvent();
/*  778 */       return this.out.printf(format, args);
/*      */     }
/*      */     
/*      */     public void println()
/*      */     {
/*  783 */       fireBeforeWriteResponseBodyEvent();
/*  784 */       this.out.println();
/*      */     }
/*      */     
/*      */     public void println(boolean x)
/*      */     {
/*  789 */       fireBeforeWriteResponseBodyEvent();
/*  790 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(char x)
/*      */     {
/*  795 */       fireBeforeWriteResponseBodyEvent();
/*  796 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(char[] x)
/*      */     {
/*  801 */       fireBeforeWriteResponseBodyEvent();
/*  802 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(double x)
/*      */     {
/*  807 */       fireBeforeWriteResponseBodyEvent();
/*  808 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(float x)
/*      */     {
/*  813 */       fireBeforeWriteResponseBodyEvent();
/*  814 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(int x)
/*      */     {
/*  819 */       fireBeforeWriteResponseBodyEvent();
/*  820 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(long x)
/*      */     {
/*  825 */       fireBeforeWriteResponseBodyEvent();
/*  826 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(Object x)
/*      */     {
/*  831 */       fireBeforeWriteResponseBodyEvent();
/*  832 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void println(String x)
/*      */     {
/*  837 */       fireBeforeWriteResponseBodyEvent();
/*  838 */       this.out.println(x);
/*      */     }
/*      */     
/*      */     public void write(char[] buf)
/*      */     {
/*  843 */       fireBeforeWriteResponseBodyEvent();
/*  844 */       this.out.write(buf);
/*      */     }
/*      */     
/*      */     public void write(char[] buf, int off, int len)
/*      */     {
/*  849 */       fireBeforeWriteResponseBodyEvent();
/*  850 */       this.out.write(buf, off, len);
/*      */     }
/*      */     
/*      */     public void write(int c)
/*      */     {
/*  855 */       fireBeforeWriteResponseBodyEvent();
/*  856 */       this.out.write(c);
/*      */     }
/*      */     
/*      */     public void write(String s)
/*      */     {
/*  861 */       fireBeforeWriteResponseBodyEvent();
/*  862 */       this.out.write(s);
/*      */     }
/*      */     
/*      */     public void write(String s, int off, int len)
/*      */     {
/*  867 */       fireBeforeWriteResponseBodyEvent();
/*  868 */       this.out.write(s, off, len);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public class XServletOutputStream
/*      */     extends ServletOutputStream
/*      */   {
/*      */     private final HttpServletRequest request;
/*      */     
/*      */ 
/*      */     private final ExpiresFilter.XHttpServletResponse response;
/*      */     
/*      */ 
/*      */     private final ServletOutputStream servletOutputStream;
/*      */     
/*      */ 
/*      */     public XServletOutputStream(ServletOutputStream servletOutputStream, HttpServletRequest request, ExpiresFilter.XHttpServletResponse response)
/*      */     {
/*  888 */       this.servletOutputStream = servletOutputStream;
/*  889 */       this.response = response;
/*  890 */       this.request = request;
/*      */     }
/*      */     
/*      */     public void close() throws IOException
/*      */     {
/*  895 */       fireOnBeforeWriteResponseBodyEvent();
/*  896 */       this.servletOutputStream.close();
/*      */     }
/*      */     
/*      */     private void fireOnBeforeWriteResponseBodyEvent() {
/*  900 */       if (!this.response.isWriteResponseBodyStarted()) {
/*  901 */         this.response.setWriteResponseBodyStarted(true);
/*  902 */         ExpiresFilter.this.onBeforeWriteResponseBody(this.request, this.response);
/*      */       }
/*      */     }
/*      */     
/*      */     public void flush() throws IOException
/*      */     {
/*  908 */       fireOnBeforeWriteResponseBodyEvent();
/*  909 */       this.servletOutputStream.flush();
/*      */     }
/*      */     
/*      */     public void print(boolean b) throws IOException
/*      */     {
/*  914 */       fireOnBeforeWriteResponseBodyEvent();
/*  915 */       this.servletOutputStream.print(b);
/*      */     }
/*      */     
/*      */     public void print(char c) throws IOException
/*      */     {
/*  920 */       fireOnBeforeWriteResponseBodyEvent();
/*  921 */       this.servletOutputStream.print(c);
/*      */     }
/*      */     
/*      */     public void print(double d) throws IOException
/*      */     {
/*  926 */       fireOnBeforeWriteResponseBodyEvent();
/*  927 */       this.servletOutputStream.print(d);
/*      */     }
/*      */     
/*      */     public void print(float f) throws IOException
/*      */     {
/*  932 */       fireOnBeforeWriteResponseBodyEvent();
/*  933 */       this.servletOutputStream.print(f);
/*      */     }
/*      */     
/*      */     public void print(int i) throws IOException
/*      */     {
/*  938 */       fireOnBeforeWriteResponseBodyEvent();
/*  939 */       this.servletOutputStream.print(i);
/*      */     }
/*      */     
/*      */     public void print(long l) throws IOException
/*      */     {
/*  944 */       fireOnBeforeWriteResponseBodyEvent();
/*  945 */       this.servletOutputStream.print(l);
/*      */     }
/*      */     
/*      */     public void print(String s) throws IOException
/*      */     {
/*  950 */       fireOnBeforeWriteResponseBodyEvent();
/*  951 */       this.servletOutputStream.print(s);
/*      */     }
/*      */     
/*      */     public void println() throws IOException
/*      */     {
/*  956 */       fireOnBeforeWriteResponseBodyEvent();
/*  957 */       this.servletOutputStream.println();
/*      */     }
/*      */     
/*      */     public void println(boolean b) throws IOException
/*      */     {
/*  962 */       fireOnBeforeWriteResponseBodyEvent();
/*  963 */       this.servletOutputStream.println(b);
/*      */     }
/*      */     
/*      */     public void println(char c) throws IOException
/*      */     {
/*  968 */       fireOnBeforeWriteResponseBodyEvent();
/*  969 */       this.servletOutputStream.println(c);
/*      */     }
/*      */     
/*      */     public void println(double d) throws IOException
/*      */     {
/*  974 */       fireOnBeforeWriteResponseBodyEvent();
/*  975 */       this.servletOutputStream.println(d);
/*      */     }
/*      */     
/*      */     public void println(float f) throws IOException
/*      */     {
/*  980 */       fireOnBeforeWriteResponseBodyEvent();
/*  981 */       this.servletOutputStream.println(f);
/*      */     }
/*      */     
/*      */     public void println(int i) throws IOException
/*      */     {
/*  986 */       fireOnBeforeWriteResponseBodyEvent();
/*  987 */       this.servletOutputStream.println(i);
/*      */     }
/*      */     
/*      */     public void println(long l) throws IOException
/*      */     {
/*  992 */       fireOnBeforeWriteResponseBodyEvent();
/*  993 */       this.servletOutputStream.println(l);
/*      */     }
/*      */     
/*      */     public void println(String s) throws IOException
/*      */     {
/*  998 */       fireOnBeforeWriteResponseBodyEvent();
/*  999 */       this.servletOutputStream.println(s);
/*      */     }
/*      */     
/*      */     public void write(byte[] b) throws IOException
/*      */     {
/* 1004 */       fireOnBeforeWriteResponseBodyEvent();
/* 1005 */       this.servletOutputStream.write(b);
/*      */     }
/*      */     
/*      */     public void write(byte[] b, int off, int len) throws IOException
/*      */     {
/* 1010 */       fireOnBeforeWriteResponseBodyEvent();
/* 1011 */       this.servletOutputStream.write(b, off, len);
/*      */     }
/*      */     
/*      */     public void write(int b) throws IOException
/*      */     {
/* 1016 */       fireOnBeforeWriteResponseBodyEvent();
/* 1017 */       this.servletOutputStream.write(b);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isReady()
/*      */     {
/* 1025 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setWriteListener(WriteListener listener) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1041 */   private static final Pattern commaSeparatedValuesPattern = Pattern.compile("\\s*,\\s*");
/*      */   
/*      */ 
/*      */   private static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*      */   
/*      */ 
/*      */   private static final String HEADER_EXPIRES = "Expires";
/*      */   
/*      */   private static final String HEADER_LAST_MODIFIED = "Last-Modified";
/*      */   
/* 1051 */   private final Log log = LogFactory.getLog(ExpiresFilter.class);
/*      */   
/*      */ 
/*      */   private static final String PARAMETER_EXPIRES_BY_TYPE = "ExpiresByType";
/*      */   
/*      */ 
/*      */   private static final String PARAMETER_EXPIRES_DEFAULT = "ExpiresDefault";
/*      */   
/*      */ 
/*      */   private static final String PARAMETER_EXPIRES_EXCLUDED_RESPONSE_STATUS_CODES = "ExpiresExcludedResponseStatusCodes";
/*      */   
/*      */ 
/*      */   private ExpiresConfiguration defaultExpiresConfiguration;
/*      */   
/*      */ 
/*      */   protected static int[] commaDelimitedListToIntArray(String commaDelimitedInts)
/*      */   {
/* 1068 */     String[] intsAsStrings = commaDelimitedListToStringArray(commaDelimitedInts);
/* 1069 */     int[] ints = new int[intsAsStrings.length];
/* 1070 */     for (int i = 0; i < intsAsStrings.length; i++) {
/* 1071 */       String intAsString = intsAsStrings[i];
/*      */       try {
/* 1073 */         ints[i] = Integer.parseInt(intAsString);
/*      */       } catch (NumberFormatException e) {
/* 1075 */         throw new RuntimeException(sm.getString("expiresFilter.numberError", new Object[] {
/* 1076 */           Integer.valueOf(i), commaDelimitedInts }));
/*      */       }
/*      */     }
/* 1079 */     return ints;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String[] commaDelimitedListToStringArray(String commaDelimitedStrings)
/*      */   {
/* 1090 */     return (commaDelimitedStrings == null) || (commaDelimitedStrings.length() == 0) ? new String[0] : commaSeparatedValuesPattern
/* 1091 */       .split(commaDelimitedStrings);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static boolean contains(String str, String searchStr)
/*      */   {
/* 1101 */     if ((str == null) || (searchStr == null)) {
/* 1102 */       return false;
/*      */     }
/* 1104 */     return str.contains(searchStr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String intsToCommaDelimitedString(int[] ints)
/*      */   {
/* 1113 */     if (ints == null) {
/* 1114 */       return "";
/*      */     }
/*      */     
/* 1117 */     StringBuilder result = new StringBuilder();
/*      */     
/* 1119 */     for (int i = 0; i < ints.length; i++) {
/* 1120 */       result.append(ints[i]);
/* 1121 */       if (i < ints.length - 1) {
/* 1122 */         result.append(", ");
/*      */       }
/*      */     }
/* 1125 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static boolean isEmpty(String str)
/*      */   {
/* 1134 */     return (str == null) || (str.length() == 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static boolean isNotEmpty(String str)
/*      */   {
/* 1143 */     return !isEmpty(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static boolean startsWithIgnoreCase(String string, String prefix)
/*      */   {
/* 1156 */     if ((string == null) || (prefix == null)) {
/* 1157 */       return (string == null) && (prefix == null);
/*      */     }
/* 1159 */     if (prefix.length() > string.length()) {
/* 1160 */       return false;
/*      */     }
/*      */     
/* 1163 */     return string.regionMatches(true, 0, prefix, 0, prefix.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String substringBefore(String str, String separator)
/*      */   {
/* 1178 */     if ((str == null) || (str.isEmpty()) || (separator == null)) {
/* 1179 */       return null;
/*      */     }
/*      */     
/* 1182 */     if (separator.isEmpty()) {
/* 1183 */       return "";
/*      */     }
/*      */     
/* 1186 */     int separatorIndex = str.indexOf(separator);
/* 1187 */     if (separatorIndex == -1) {
/* 1188 */       return str;
/*      */     }
/* 1190 */     return str.substring(0, separatorIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1202 */   private int[] excludedResponseStatusCodes = { 304 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1207 */   private Map<String, ExpiresConfiguration> expiresConfigurationByContentType = new LinkedHashMap();
/*      */   
/*      */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*      */     throws IOException, ServletException
/*      */   {
/* 1212 */     if (((request instanceof HttpServletRequest)) && ((response instanceof HttpServletResponse)))
/*      */     {
/* 1214 */       HttpServletRequest httpRequest = (HttpServletRequest)request;
/* 1215 */       HttpServletResponse httpResponse = (HttpServletResponse)response;
/*      */       
/* 1217 */       if (response.isCommitted()) {
/* 1218 */         if (this.log.isDebugEnabled()) {
/* 1219 */           this.log.debug(sm.getString("expiresFilter.responseAlreadyCommitted", new Object[] {httpRequest
/*      */           
/* 1221 */             .getRequestURL() }));
/*      */         }
/* 1223 */         chain.doFilter(request, response);
/*      */       } else {
/* 1225 */         XHttpServletResponse xResponse = new XHttpServletResponse(httpRequest, httpResponse);
/*      */         
/* 1227 */         chain.doFilter(request, xResponse);
/* 1228 */         if (!xResponse.isWriteResponseBodyStarted())
/*      */         {
/*      */ 
/* 1231 */           onBeforeWriteResponseBody(httpRequest, xResponse);
/*      */         }
/*      */       }
/*      */     } else {
/* 1235 */       chain.doFilter(request, response);
/*      */     }
/*      */   }
/*      */   
/*      */   public ExpiresConfiguration getDefaultExpiresConfiguration() {
/* 1240 */     return this.defaultExpiresConfiguration;
/*      */   }
/*      */   
/*      */   public String getExcludedResponseStatusCodes() {
/* 1244 */     return intsToCommaDelimitedString(this.excludedResponseStatusCodes);
/*      */   }
/*      */   
/*      */   public int[] getExcludedResponseStatusCodesAsInts() {
/* 1248 */     return this.excludedResponseStatusCodes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected Date getExpirationDate(XHttpServletResponse response)
/*      */   {
/* 1269 */     return getExpirationDate((HttpServletRequest)null, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Date getExpirationDate(HttpServletRequest request, XHttpServletResponse response)
/*      */   {
/* 1287 */     String contentType = response.getContentType();
/* 1288 */     if ((contentType == null) && (request != null) && 
/* 1289 */       (request.getHttpServletMapping().getMappingMatch() == MappingMatch.DEFAULT) && 
/* 1290 */       (response.getStatus() == 304))
/*      */     {
/*      */ 
/* 1293 */       String servletPath = request.getServletPath();
/* 1294 */       if (servletPath != null) {
/* 1295 */         int lastSlash = servletPath.lastIndexOf('/');
/* 1296 */         if (lastSlash > -1) {
/* 1297 */           String fileName = servletPath.substring(lastSlash + 1);
/* 1298 */           contentType = request.getServletContext().getMimeType(fileName);
/*      */         }
/*      */       }
/*      */     }
/* 1302 */     if (contentType != null) {
/* 1303 */       contentType = contentType.toLowerCase(Locale.ENGLISH);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1308 */     ExpiresConfiguration configuration = (ExpiresConfiguration)this.expiresConfigurationByContentType.get(contentType);
/* 1309 */     if (configuration != null) {
/* 1310 */       Date result = getExpirationDate(configuration, response);
/* 1311 */       if (this.log.isDebugEnabled()) {
/* 1312 */         this.log.debug(sm.getString("expiresFilter.useMatchingConfiguration", new Object[] { configuration, contentType, contentType, result }));
/*      */       }
/*      */       
/*      */ 
/* 1316 */       return result;
/*      */     }
/*      */     
/* 1319 */     if (contains(contentType, ";"))
/*      */     {
/* 1321 */       String contentTypeWithoutCharset = substringBefore(contentType, ";").trim();
/* 1322 */       configuration = (ExpiresConfiguration)this.expiresConfigurationByContentType.get(contentTypeWithoutCharset);
/*      */       
/* 1324 */       if (configuration != null) {
/* 1325 */         Date result = getExpirationDate(configuration, response);
/* 1326 */         if (this.log.isDebugEnabled()) {
/* 1327 */           this.log.debug(sm.getString("expiresFilter.useMatchingConfiguration", new Object[] { configuration, contentTypeWithoutCharset, contentType, result }));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1332 */         return result;
/*      */       }
/*      */     }
/*      */     
/* 1336 */     if (contains(contentType, "/"))
/*      */     {
/* 1338 */       String majorType = substringBefore(contentType, "/");
/* 1339 */       configuration = (ExpiresConfiguration)this.expiresConfigurationByContentType.get(majorType);
/* 1340 */       if (configuration != null) {
/* 1341 */         Date result = getExpirationDate(configuration, response);
/* 1342 */         if (this.log.isDebugEnabled()) {
/* 1343 */           this.log.debug(sm.getString("expiresFilter.useMatchingConfiguration", new Object[] { configuration, majorType, contentType, result }));
/*      */         }
/*      */         
/*      */ 
/* 1347 */         return result;
/*      */       }
/*      */     }
/*      */     
/* 1351 */     if (this.defaultExpiresConfiguration != null) {
/* 1352 */       Date result = getExpirationDate(this.defaultExpiresConfiguration, response);
/*      */       
/* 1354 */       if (this.log.isDebugEnabled()) {
/* 1355 */         this.log.debug(sm.getString("expiresFilter.useDefaultConfiguration", new Object[] { this.defaultExpiresConfiguration, contentType, result }));
/*      */       }
/*      */       
/* 1358 */       return result;
/*      */     }
/*      */     
/* 1361 */     if (this.log.isDebugEnabled()) {
/* 1362 */       this.log.debug(sm.getString("expiresFilter.noExpirationConfiguredForContentType", new Object[] { contentType }));
/*      */     }
/*      */     
/*      */ 
/* 1366 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Date getExpirationDate(ExpiresConfiguration configuration, XHttpServletResponse response)
/*      */   {
/*      */     Calendar calendar;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     Calendar calendar;
/*      */     
/*      */ 
/*      */ 
/* 1384 */     switch (configuration.getStartingPoint()) {
/*      */     case ACCESS_TIME: 
/* 1386 */       calendar = Calendar.getInstance();
/* 1387 */       break;
/*      */     case LAST_MODIFICATION_TIME: 
/* 1389 */       if (response.isLastModifiedHeaderSet()) {
/*      */         Calendar calendar;
/* 1391 */         try { long lastModified = response.getLastModifiedHeader();
/* 1392 */           Calendar calendar = Calendar.getInstance();
/* 1393 */           calendar.setTimeInMillis(lastModified);
/*      */         }
/*      */         catch (NumberFormatException e) {
/* 1396 */           calendar = Calendar.getInstance();
/*      */         }
/*      */       }
/*      */       else {
/* 1400 */         calendar = Calendar.getInstance();
/*      */       }
/* 1402 */       break;
/*      */     default: 
/* 1404 */       throw new IllegalStateException(sm.getString("expiresFilter.unsupportedStartingPoint", new Object[] {configuration
/*      */       
/* 1406 */         .getStartingPoint() })); }
/*      */     Calendar calendar;
/* 1408 */     for (Duration duration : configuration.getDurations()) {
/* 1409 */       calendar.add(duration.getUnit().getCalendardField(), duration
/* 1410 */         .getAmount());
/*      */     }
/*      */     
/* 1413 */     return calendar.getTime();
/*      */   }
/*      */   
/*      */   public Map<String, ExpiresConfiguration> getExpiresConfigurationByContentType() {
/* 1417 */     return this.expiresConfigurationByContentType;
/*      */   }
/*      */   
/*      */   protected Log getLogger()
/*      */   {
/* 1422 */     return this.log;
/*      */   }
/*      */   
/*      */   public void init(FilterConfig filterConfig) throws ServletException
/*      */   {
/* 1427 */     for (Enumeration<String> names = filterConfig.getInitParameterNames(); names.hasMoreElements();) {
/* 1428 */       String name = (String)names.nextElement();
/* 1429 */       String value = filterConfig.getInitParameter(name);
/*      */       try
/*      */       {
/* 1432 */         if (name.startsWith("ExpiresByType"))
/*      */         {
/* 1434 */           String contentType = name.substring("ExpiresByType".length()).trim().toLowerCase(Locale.ENGLISH);
/* 1435 */           ExpiresConfiguration expiresConfiguration = parseExpiresConfiguration(value);
/* 1436 */           this.expiresConfigurationByContentType.put(contentType, expiresConfiguration);
/*      */         }
/* 1438 */         else if (name.equalsIgnoreCase("ExpiresDefault")) {
/* 1439 */           ExpiresConfiguration expiresConfiguration = parseExpiresConfiguration(value);
/* 1440 */           this.defaultExpiresConfiguration = expiresConfiguration;
/* 1441 */         } else if (name.equalsIgnoreCase("ExpiresExcludedResponseStatusCodes")) {
/* 1442 */           this.excludedResponseStatusCodes = commaDelimitedListToIntArray(value);
/*      */         } else {
/* 1444 */           this.log.warn(sm.getString("expiresFilter.unknownParameterIgnored", new Object[] { name, value }));
/*      */         }
/*      */       }
/*      */       catch (RuntimeException e)
/*      */       {
/* 1449 */         throw new ServletException(sm.getString("expiresFilter.exceptionProcessingParameter", new Object[] { name, value }), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1455 */     this.log.debug(sm.getString("expiresFilter.filterInitialized", new Object[] {
/* 1456 */       toString() }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isEligibleToExpirationHeaderGeneration(HttpServletRequest request, XHttpServletResponse response)
/*      */   {
/* 1470 */     boolean expirationHeaderHasBeenSet = (response.containsHeader("Expires")) || (contains(response.getCacheControlHeader(), "max-age"));
/* 1471 */     if (expirationHeaderHasBeenSet) {
/* 1472 */       if (this.log.isDebugEnabled()) {
/* 1473 */         this.log.debug(sm.getString("expiresFilter.expirationHeaderAlreadyDefined", new Object[] {request
/*      */         
/* 1475 */           .getRequestURI(), 
/* 1476 */           Integer.valueOf(response.getStatus()), response
/* 1477 */           .getContentType() }));
/*      */       }
/* 1479 */       return false;
/*      */     }
/*      */     
/* 1482 */     for (int skippedStatusCode : this.excludedResponseStatusCodes) {
/* 1483 */       if (response.getStatus() == skippedStatusCode) {
/* 1484 */         if (this.log.isDebugEnabled()) {
/* 1485 */           this.log.debug(sm.getString("expiresFilter.skippedStatusCode", new Object[] {request
/* 1486 */             .getRequestURI(), 
/* 1487 */             Integer.valueOf(response.getStatus()), response
/* 1488 */             .getContentType() }));
/*      */         }
/* 1490 */         return false;
/*      */       }
/*      */     }
/*      */     
/* 1494 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void onBeforeWriteResponseBody(HttpServletRequest request, XHttpServletResponse response)
/*      */   {
/* 1520 */     if (!isEligibleToExpirationHeaderGeneration(request, response)) {
/* 1521 */       return;
/*      */     }
/*      */     
/* 1524 */     Date expirationDate = getExpirationDate(request, response);
/* 1525 */     if (expirationDate == null) {
/* 1526 */       if (this.log.isDebugEnabled()) {
/* 1527 */         this.log.debug(sm.getString("expiresFilter.noExpirationConfigured", new Object[] {request
/* 1528 */           .getRequestURI(), 
/* 1529 */           Integer.valueOf(response.getStatus()), response
/* 1530 */           .getContentType() }));
/*      */       }
/*      */     } else {
/* 1533 */       if (this.log.isDebugEnabled()) {
/* 1534 */         this.log.debug(sm.getString("expiresFilter.setExpirationDate", new Object[] {request
/* 1535 */           .getRequestURI(), 
/* 1536 */           Integer.valueOf(response.getStatus()), response
/* 1537 */           .getContentType(), expirationDate }));
/*      */       }
/*      */       
/*      */ 
/* 1541 */       String maxAgeDirective = "max-age=" + (expirationDate.getTime() - System.currentTimeMillis()) / 1000L;
/*      */       
/* 1543 */       String cacheControlHeader = response.getCacheControlHeader();
/* 1544 */       String newCacheControlHeader = cacheControlHeader + ", " + maxAgeDirective;
/*      */       
/* 1546 */       response.setHeader("Cache-Control", newCacheControlHeader);
/* 1547 */       response.setDateHeader("Expires", expirationDate.getTime());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ExpiresConfiguration parseExpiresConfiguration(String inputLine)
/*      */   {
/* 1561 */     String line = inputLine.trim();
/*      */     
/* 1563 */     StringTokenizer tokenizer = new StringTokenizer(line, " ");
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1568 */       currentToken = tokenizer.nextToken();
/*      */     } catch (NoSuchElementException e) { String currentToken;
/* 1570 */       throw new IllegalStateException(sm.getString("expiresFilter.startingPointNotFound", new Object[] { line }));
/*      */     }
/*      */     
/*      */     String currentToken;
/*      */     StartingPoint startingPoint;
/* 1575 */     if (("access".equalsIgnoreCase(currentToken)) || 
/* 1576 */       ("now".equalsIgnoreCase(currentToken))) {
/* 1577 */       startingPoint = StartingPoint.ACCESS_TIME; } else { StartingPoint startingPoint;
/* 1578 */       if ("modification".equalsIgnoreCase(currentToken)) {
/* 1579 */         startingPoint = StartingPoint.LAST_MODIFICATION_TIME;
/* 1580 */       } else if ((!tokenizer.hasMoreTokens()) && 
/* 1581 */         (startsWithIgnoreCase(currentToken, "a"))) {
/* 1582 */         StartingPoint startingPoint = StartingPoint.ACCESS_TIME;
/*      */         
/* 1584 */         tokenizer = new StringTokenizer(currentToken.substring(1) + " seconds", " ");
/*      */       }
/* 1586 */       else if ((!tokenizer.hasMoreTokens()) && 
/* 1587 */         (startsWithIgnoreCase(currentToken, "m"))) {
/* 1588 */         StartingPoint startingPoint = StartingPoint.LAST_MODIFICATION_TIME;
/*      */         
/* 1590 */         tokenizer = new StringTokenizer(currentToken.substring(1) + " seconds", " ");
/*      */       }
/*      */       else {
/* 1593 */         throw new IllegalStateException(sm.getString("expiresFilter.startingPointInvalid", new Object[] { currentToken, line }));
/*      */       }
/*      */     }
/*      */     StartingPoint startingPoint;
/*      */     try {
/* 1598 */       currentToken = tokenizer.nextToken();
/*      */     } catch (NoSuchElementException e) {
/* 1600 */       throw new IllegalStateException(sm.getString("expiresFilter.noDurationFound", new Object[] { line }));
/*      */     }
/*      */     
/*      */ 
/* 1604 */     if ("plus".equalsIgnoreCase(currentToken)) {
/*      */       try
/*      */       {
/* 1607 */         currentToken = tokenizer.nextToken();
/*      */       } catch (NoSuchElementException e) {
/* 1609 */         throw new IllegalStateException(sm.getString("expiresFilter.noDurationFound", new Object[] { line }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1614 */     List<Duration> durations = new ArrayList();
/*      */     
/* 1616 */     while (currentToken != null)
/*      */     {
/*      */       try {
/* 1619 */         amount = Integer.parseInt(currentToken);
/*      */       } catch (NumberFormatException e) { int amount;
/* 1621 */         throw new IllegalStateException(sm.getString("expiresFilter.invalidDurationNumber", new Object[] { currentToken, line }));
/*      */       }
/*      */       
/*      */       int amount;
/*      */       try
/*      */       {
/* 1627 */         currentToken = tokenizer.nextToken();
/*      */       }
/*      */       catch (NoSuchElementException e) {
/* 1630 */         throw new IllegalStateException(sm.getString("expiresFilter.noDurationUnitAfterAmount", new Object[] {
/*      */         
/* 1632 */           Integer.valueOf(amount), line }));
/*      */       }
/*      */       DurationUnit durationUnit;
/* 1635 */       if (("year".equalsIgnoreCase(currentToken)) || 
/* 1636 */         ("years".equalsIgnoreCase(currentToken))) {
/* 1637 */         durationUnit = DurationUnit.YEAR; } else { DurationUnit durationUnit;
/* 1638 */         if (("month".equalsIgnoreCase(currentToken)) || 
/* 1639 */           ("months".equalsIgnoreCase(currentToken))) {
/* 1640 */           durationUnit = DurationUnit.MONTH; } else { DurationUnit durationUnit;
/* 1641 */           if (("week".equalsIgnoreCase(currentToken)) || 
/* 1642 */             ("weeks".equalsIgnoreCase(currentToken))) {
/* 1643 */             durationUnit = DurationUnit.WEEK; } else { DurationUnit durationUnit;
/* 1644 */             if (("day".equalsIgnoreCase(currentToken)) || 
/* 1645 */               ("days".equalsIgnoreCase(currentToken))) {
/* 1646 */               durationUnit = DurationUnit.DAY; } else { DurationUnit durationUnit;
/* 1647 */               if (("hour".equalsIgnoreCase(currentToken)) || 
/* 1648 */                 ("hours".equalsIgnoreCase(currentToken))) {
/* 1649 */                 durationUnit = DurationUnit.HOUR; } else { DurationUnit durationUnit;
/* 1650 */                 if (("minute".equalsIgnoreCase(currentToken)) || 
/* 1651 */                   ("minutes".equalsIgnoreCase(currentToken))) {
/* 1652 */                   durationUnit = DurationUnit.MINUTE; } else { DurationUnit durationUnit;
/* 1653 */                   if (("second".equalsIgnoreCase(currentToken)) || 
/* 1654 */                     ("seconds".equalsIgnoreCase(currentToken))) {
/* 1655 */                     durationUnit = DurationUnit.SECOND;
/*      */                   }
/*      */                   else
/* 1658 */                     throw new IllegalStateException(sm.getString("expiresFilter.invalidDurationUnit", new Object[] { currentToken, line }));
/*      */                 }
/*      */               }
/*      */             } } } }
/*      */       DurationUnit durationUnit;
/* 1663 */       Duration duration = new Duration(amount, durationUnit);
/* 1664 */       durations.add(duration);
/*      */       
/* 1666 */       if (tokenizer.hasMoreTokens()) {
/* 1667 */         currentToken = tokenizer.nextToken();
/*      */       } else {
/* 1669 */         currentToken = null;
/*      */       }
/*      */     }
/*      */     
/* 1673 */     return new ExpiresConfiguration(startingPoint, durations);
/*      */   }
/*      */   
/*      */   public void setDefaultExpiresConfiguration(ExpiresConfiguration defaultExpiresConfiguration)
/*      */   {
/* 1678 */     this.defaultExpiresConfiguration = defaultExpiresConfiguration;
/*      */   }
/*      */   
/*      */   public void setExcludedResponseStatusCodes(int[] excludedResponseStatusCodes) {
/* 1682 */     this.excludedResponseStatusCodes = excludedResponseStatusCodes;
/*      */   }
/*      */   
/*      */   public void setExpiresConfigurationByContentType(Map<String, ExpiresConfiguration> expiresConfigurationByContentType)
/*      */   {
/* 1687 */     this.expiresConfigurationByContentType = expiresConfigurationByContentType;
/*      */   }
/*      */   
/*      */   public String toString()
/*      */   {
/* 1692 */     return 
/* 1693 */       getClass().getSimpleName() + "[excludedResponseStatusCode=[" + intsToCommaDelimitedString(this.excludedResponseStatusCodes) + "], default=" + this.defaultExpiresConfiguration + ", byType=" + this.expiresConfigurationByContentType + "]";
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\filters\ExpiresFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */