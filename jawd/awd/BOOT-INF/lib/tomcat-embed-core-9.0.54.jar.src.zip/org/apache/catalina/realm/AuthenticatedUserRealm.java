/*    */ package org.apache.catalina.realm;
/*    */ 
/*    */ import java.security.Principal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticatedUserRealm
/*    */   extends RealmBase
/*    */ {
/*    */   protected String getPassword(String username)
/*    */   {
/* 37 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Principal getPrincipal(String username)
/*    */   {
/* 44 */     return new GenericPrincipal(username, null, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\AuthenticatedUserRealm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */