/*    */ package org.apache.catalina.mbeans;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import javax.management.InstanceNotFoundException;
/*    */ import javax.management.MBeanException;
/*    */ import javax.management.RuntimeOperationsException;
/*    */ import javax.management.modelmbean.InvalidTargetObjectTypeException;
/*    */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseCatalinaMBean<T>
/*    */   extends BaseModelMBean
/*    */ {
/*    */   protected T doGetManagedResource()
/*    */     throws MBeanException
/*    */   {
/*    */     try
/*    */     {
/* 31 */       return (T)getManagedResource();
/*    */     }
/*    */     catch (InstanceNotFoundException|RuntimeOperationsException|InvalidTargetObjectTypeException e)
/*    */     {
/* 35 */       throw new MBeanException(e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected static Object newInstance(String type) throws MBeanException
/*    */   {
/*    */     try {
/* 42 */       return Class.forName(type).getConstructor(new Class[0]).newInstance(new Object[0]);
/*    */     } catch (ReflectiveOperationException e) {
/* 44 */       throw new MBeanException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\BaseCatalinaMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */