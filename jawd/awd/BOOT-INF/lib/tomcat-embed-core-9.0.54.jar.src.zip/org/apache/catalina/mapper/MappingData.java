/*    */ package org.apache.catalina.mapper;
/*    */ 
/*    */ import javax.servlet.http.MappingMatch;
/*    */ import org.apache.catalina.Context;
/*    */ import org.apache.catalina.Host;
/*    */ import org.apache.catalina.Wrapper;
/*    */ import org.apache.tomcat.util.buf.MessageBytes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MappingData
/*    */ {
/* 33 */   public Host host = null;
/* 34 */   public Context context = null;
/* 35 */   public int contextSlashCount = 0;
/* 36 */   public Context[] contexts = null;
/* 37 */   public Wrapper wrapper = null;
/* 38 */   public boolean jspWildCard = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @Deprecated
/* 44 */   public final MessageBytes contextPath = MessageBytes.newInstance();
/* 45 */   public final MessageBytes requestPath = MessageBytes.newInstance();
/* 46 */   public final MessageBytes wrapperPath = MessageBytes.newInstance();
/* 47 */   public final MessageBytes pathInfo = MessageBytes.newInstance();
/*    */   
/* 49 */   public final MessageBytes redirectPath = MessageBytes.newInstance();
/*    */   
/*    */ 
/* 52 */   public MappingMatch matchType = null;
/*    */   
/*    */   public void recycle() {
/* 55 */     this.host = null;
/* 56 */     this.context = null;
/* 57 */     this.contextSlashCount = 0;
/* 58 */     this.contexts = null;
/* 59 */     this.wrapper = null;
/* 60 */     this.jspWildCard = false;
/* 61 */     this.contextPath.recycle();
/* 62 */     this.requestPath.recycle();
/* 63 */     this.wrapperPath.recycle();
/* 64 */     this.pathInfo.recycle();
/* 65 */     this.redirectPath.recycle();
/* 66 */     this.matchType = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mapper\MappingData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */