/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Locale;
/*     */ import org.apache.catalina.util.URLEncoder;
/*     */ import org.apache.tomcat.util.buf.UDecoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternalRewriteMap
/*     */ {
/*     */   public static RewriteMap toMap(String name)
/*     */   {
/*  29 */     if ("toupper".equals(name))
/*  30 */       return new UpperCase();
/*  31 */     if ("tolower".equals(name))
/*  32 */       return new LowerCase();
/*  33 */     if ("escape".equals(name))
/*  34 */       return new Escape();
/*  35 */     if ("unescape".equals(name)) {
/*  36 */       return new Unescape();
/*     */     }
/*  38 */     return null;
/*     */   }
/*     */   
/*     */   public static class LowerCase
/*     */     implements RewriteMap
/*     */   {
/*  44 */     private Locale locale = Locale.getDefault();
/*     */     
/*     */     public String setParameters(String params)
/*     */     {
/*  48 */       this.locale = Locale.forLanguageTag(params);
/*  49 */       return null;
/*     */     }
/*     */     
/*     */     public String lookup(String key)
/*     */     {
/*  54 */       if (key != null) {
/*  55 */         return key.toLowerCase(this.locale);
/*     */       }
/*  57 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class UpperCase
/*     */     implements RewriteMap
/*     */   {
/*  64 */     private Locale locale = Locale.getDefault();
/*     */     
/*     */     public String setParameters(String params)
/*     */     {
/*  68 */       this.locale = Locale.forLanguageTag(params);
/*  69 */       return null;
/*     */     }
/*     */     
/*     */     public String lookup(String key)
/*     */     {
/*  74 */       if (key != null) {
/*  75 */         return key.toUpperCase(this.locale);
/*     */       }
/*  77 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Escape
/*     */     implements RewriteMap
/*     */   {
/*  84 */     private Charset charset = StandardCharsets.UTF_8;
/*     */     
/*     */     public String setParameters(String params)
/*     */     {
/*  88 */       this.charset = Charset.forName(params);
/*  89 */       return null;
/*     */     }
/*     */     
/*     */     public String lookup(String key)
/*     */     {
/*  94 */       if (key != null) {
/*  95 */         return URLEncoder.DEFAULT.encode(key, this.charset);
/*     */       }
/*  97 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Unescape
/*     */     implements RewriteMap
/*     */   {
/* 104 */     private Charset charset = StandardCharsets.UTF_8;
/*     */     
/*     */     public String setParameters(String params)
/*     */     {
/* 108 */       this.charset = Charset.forName(params);
/* 109 */       return null;
/*     */     }
/*     */     
/*     */     public String lookup(String key)
/*     */     {
/* 114 */       if (key != null) {
/* 115 */         return UDecoder.URLDecode(key, this.charset);
/*     */       }
/* 117 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\rewrite\InternalRewriteMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */