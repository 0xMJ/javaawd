/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.Set;
/*     */ import javax.management.DynamicMBean;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Loader;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.catalina.util.ContextName;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResourceLink;
/*     */ import org.apache.tomcat.util.descriptor.web.NamingResources;
/*     */ import org.apache.tomcat.util.modeler.ManagedBean;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanUtils
/*     */ {
/*  54 */   protected static final StringManager sm = StringManager.getManager(MBeanUtils.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */   private static final String[][] exceptions = { { "org.apache.catalina.users.MemoryGroup", "Group" }, { "org.apache.catalina.users.MemoryRole", "Role" }, { "org.apache.catalina.users.MemoryUser", "User" }, { "org.apache.catalina.users.GenericGroup", "Group" }, { "org.apache.catalina.users.GenericRole", "Role" }, { "org.apache.catalina.users.GenericUser", "User" } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   private static Registry registry = createRegistry();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  86 */   private static MBeanServer mserver = createServer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String createManagedName(Object component)
/*     */   {
/* 100 */     String className = component.getClass().getName();
/* 101 */     for (String[] exception : exceptions) {
/* 102 */       if (className.equals(exception[0])) {
/* 103 */         return exception[1];
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 108 */     int period = className.lastIndexOf('.');
/* 109 */     if (period >= 0) {
/* 110 */       className = className.substring(period + 1);
/*     */     }
/* 112 */     return className;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DynamicMBean createMBean(ContextEnvironment environment)
/*     */     throws Exception
/*     */   {
/* 128 */     String mname = createManagedName(environment);
/* 129 */     ManagedBean managed = registry.findManagedBean(mname);
/* 130 */     if (managed == null) {
/* 131 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 132 */       throw new MBeanException(e);
/*     */     }
/* 134 */     String domain = managed.getDomain();
/* 135 */     if (domain == null) {
/* 136 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 138 */     DynamicMBean mbean = managed.createMBean(environment);
/* 139 */     ObjectName oname = createObjectName(domain, environment);
/* 140 */     if (mserver.isRegistered(oname)) {
/* 141 */       mserver.unregisterMBean(oname);
/*     */     }
/* 143 */     mserver.registerMBean(mbean, oname);
/* 144 */     return mbean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DynamicMBean createMBean(ContextResource resource)
/*     */     throws Exception
/*     */   {
/* 160 */     String mname = createManagedName(resource);
/* 161 */     ManagedBean managed = registry.findManagedBean(mname);
/* 162 */     if (managed == null) {
/* 163 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 164 */       throw new MBeanException(e);
/*     */     }
/* 166 */     String domain = managed.getDomain();
/* 167 */     if (domain == null) {
/* 168 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 170 */     DynamicMBean mbean = managed.createMBean(resource);
/* 171 */     ObjectName oname = createObjectName(domain, resource);
/* 172 */     if (mserver.isRegistered(oname)) {
/* 173 */       mserver.unregisterMBean(oname);
/*     */     }
/* 175 */     mserver.registerMBean(mbean, oname);
/* 176 */     return mbean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DynamicMBean createMBean(ContextResourceLink resourceLink)
/*     */     throws Exception
/*     */   {
/* 192 */     String mname = createManagedName(resourceLink);
/* 193 */     ManagedBean managed = registry.findManagedBean(mname);
/* 194 */     if (managed == null) {
/* 195 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 196 */       throw new MBeanException(e);
/*     */     }
/* 198 */     String domain = managed.getDomain();
/* 199 */     if (domain == null) {
/* 200 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 202 */     DynamicMBean mbean = managed.createMBean(resourceLink);
/* 203 */     ObjectName oname = createObjectName(domain, resourceLink);
/* 204 */     if (mserver.isRegistered(oname)) {
/* 205 */       mserver.unregisterMBean(oname);
/*     */     }
/* 207 */     mserver.registerMBean(mbean, oname);
/* 208 */     return mbean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static DynamicMBean createMBean(Group group)
/*     */     throws Exception
/*     */   {
/* 224 */     String mname = createManagedName(group);
/* 225 */     ManagedBean managed = registry.findManagedBean(mname);
/* 226 */     if (managed == null) {
/* 227 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 228 */       throw new MBeanException(e);
/*     */     }
/* 230 */     String domain = managed.getDomain();
/* 231 */     if (domain == null) {
/* 232 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 234 */     DynamicMBean mbean = managed.createMBean(group);
/* 235 */     ObjectName oname = createObjectName(domain, group);
/* 236 */     if (mserver.isRegistered(oname)) {
/* 237 */       mserver.unregisterMBean(oname);
/*     */     }
/* 239 */     mserver.registerMBean(mbean, oname);
/* 240 */     return mbean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static DynamicMBean createMBean(Role role)
/*     */     throws Exception
/*     */   {
/* 256 */     String mname = createManagedName(role);
/* 257 */     ManagedBean managed = registry.findManagedBean(mname);
/* 258 */     if (managed == null) {
/* 259 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 260 */       throw new MBeanException(e);
/*     */     }
/* 262 */     String domain = managed.getDomain();
/* 263 */     if (domain == null) {
/* 264 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 266 */     DynamicMBean mbean = managed.createMBean(role);
/* 267 */     ObjectName oname = createObjectName(domain, role);
/* 268 */     if (mserver.isRegistered(oname)) {
/* 269 */       mserver.unregisterMBean(oname);
/*     */     }
/* 271 */     mserver.registerMBean(mbean, oname);
/* 272 */     return mbean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static DynamicMBean createMBean(User user)
/*     */     throws Exception
/*     */   {
/* 288 */     String mname = createManagedName(user);
/* 289 */     ManagedBean managed = registry.findManagedBean(mname);
/* 290 */     if (managed == null) {
/* 291 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 292 */       throw new MBeanException(e);
/*     */     }
/* 294 */     String domain = managed.getDomain();
/* 295 */     if (domain == null) {
/* 296 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 298 */     DynamicMBean mbean = managed.createMBean(user);
/* 299 */     ObjectName oname = createObjectName(domain, user);
/* 300 */     if (mserver.isRegistered(oname)) {
/* 301 */       mserver.unregisterMBean(oname);
/*     */     }
/* 303 */     mserver.registerMBean(mbean, oname);
/* 304 */     return mbean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static DynamicMBean createMBean(UserDatabase userDatabase)
/*     */     throws Exception
/*     */   {
/* 320 */     if (userDatabase.isSparse())
/*     */     {
/* 322 */       ManagedBean managed = registry.findManagedBean("SparseUserDatabase");
/* 323 */       if (managed == null) {
/* 324 */         Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { "SparseUserDatabase" }));
/* 325 */         throw new MBeanException(e);
/*     */       }
/* 327 */       String domain = managed.getDomain();
/* 328 */       if (domain == null) {
/* 329 */         domain = mserver.getDefaultDomain();
/*     */       }
/* 331 */       DynamicMBean mbean = managed.createMBean(userDatabase);
/* 332 */       ObjectName oname = createObjectName(domain, userDatabase);
/* 333 */       if (mserver.isRegistered(oname)) {
/* 334 */         mserver.unregisterMBean(oname);
/*     */       }
/* 336 */       mserver.registerMBean(mbean, oname);
/*     */     }
/*     */     
/* 339 */     String mname = createManagedName(userDatabase);
/* 340 */     ManagedBean managed = registry.findManagedBean(mname);
/* 341 */     if (managed == null) {
/* 342 */       Exception e = new Exception(sm.getString("mBeanUtils.noManagedBean", new Object[] { mname }));
/* 343 */       throw new MBeanException(e);
/*     */     }
/* 345 */     String domain = managed.getDomain();
/* 346 */     if (domain == null) {
/* 347 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 349 */     DynamicMBean mbean = managed.createMBean(userDatabase);
/* 350 */     ObjectName oname = createObjectName(domain, userDatabase);
/* 351 */     if (mserver.isRegistered(oname)) {
/* 352 */       mserver.unregisterMBean(oname);
/*     */     }
/* 354 */     mserver.registerMBean(mbean, oname);
/* 355 */     return mbean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ObjectName createObjectName(String domain, ContextEnvironment environment)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 373 */     ObjectName name = null;
/*     */     
/* 375 */     Object container = environment.getNamingResources().getContainer();
/* 376 */     if ((container instanceof Server))
/*     */     {
/* 378 */       name = new ObjectName(domain + ":type=Environment,resourcetype=Global,name=" + environment.getName());
/* 379 */     } else if ((container instanceof Context)) {
/* 380 */       Context context = (Context)container;
/* 381 */       ContextName cn = new ContextName(context.getName(), false);
/* 382 */       Container host = context.getParent();
/*     */       
/*     */ 
/*     */ 
/* 386 */       name = new ObjectName(domain + ":type=Environment,resourcetype=Context,host=" + host.getName() + ",context=" + cn.getDisplayName() + ",name=" + environment.getName());
/*     */     }
/* 388 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ObjectName createObjectName(String domain, ContextResource resource)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 406 */     ObjectName name = null;
/* 407 */     String quotedResourceName = ObjectName.quote(resource.getName());
/*     */     
/* 409 */     Object container = resource.getNamingResources().getContainer();
/* 410 */     if ((container instanceof Server))
/*     */     {
/* 412 */       name = new ObjectName(domain + ":type=Resource,resourcetype=Global,class=" + resource.getType() + ",name=" + quotedResourceName);
/*     */     }
/* 414 */     else if ((container instanceof Context)) {
/* 415 */       Context context = (Context)container;
/* 416 */       ContextName cn = new ContextName(context.getName(), false);
/* 417 */       Container host = context.getParent();
/*     */       
/*     */ 
/*     */ 
/* 421 */       name = new ObjectName(domain + ":type=Resource,resourcetype=Context,host=" + host.getName() + ",context=" + cn.getDisplayName() + ",class=" + resource.getType() + ",name=" + quotedResourceName);
/*     */     }
/*     */     
/*     */ 
/* 425 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ObjectName createObjectName(String domain, ContextResourceLink resourceLink)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 443 */     ObjectName name = null;
/*     */     
/* 445 */     String quotedResourceLinkName = ObjectName.quote(resourceLink.getName());
/*     */     
/* 447 */     Object container = resourceLink.getNamingResources().getContainer();
/* 448 */     if ((container instanceof Server)) {
/* 449 */       name = new ObjectName(domain + ":type=ResourceLink,resourcetype=Global,name=" + quotedResourceLinkName);
/*     */ 
/*     */     }
/* 452 */     else if ((container instanceof Context)) {
/* 453 */       Context context = (Context)container;
/* 454 */       ContextName cn = new ContextName(context.getName(), false);
/* 455 */       Container host = context.getParent();
/*     */       
/*     */ 
/* 458 */       name = new ObjectName(domain + ":type=ResourceLink,resourcetype=Context,host=" + host.getName() + ",context=" + cn.getDisplayName() + ",name=" + quotedResourceLinkName);
/*     */     }
/*     */     
/*     */ 
/* 462 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ObjectName createObjectName(String domain, Group group)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 480 */     ObjectName name = null;
/*     */     
/*     */ 
/* 483 */     name = new ObjectName(domain + ":type=Group,groupname=" + ObjectName.quote(group.getGroupname()) + ",database=" + group.getUserDatabase().getId());
/* 484 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ObjectName createObjectName(String domain, Loader loader)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 501 */     ObjectName name = null;
/* 502 */     Context context = loader.getContext();
/*     */     
/* 504 */     ContextName cn = new ContextName(context.getName(), false);
/* 505 */     Container host = context.getParent();
/*     */     
/* 507 */     name = new ObjectName(domain + ":type=Loader,host=" + host.getName() + ",context=" + cn.getDisplayName());
/*     */     
/* 509 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ObjectName createObjectName(String domain, Role role)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 527 */     ObjectName name = new ObjectName(domain + ":type=Role,rolename=" + ObjectName.quote(role.getRolename()) + ",database=" + role.getUserDatabase().getId());
/* 528 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ObjectName createObjectName(String domain, User user)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 546 */     ObjectName name = new ObjectName(domain + ":type=User,username=" + ObjectName.quote(user.getUsername()) + ",database=" + user.getUserDatabase().getId());
/* 547 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ObjectName createObjectName(String domain, UserDatabase userDatabase)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 564 */     ObjectName name = null;
/*     */     
/* 566 */     name = new ObjectName(domain + ":type=UserDatabase,database=" + userDatabase.getId());
/* 567 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized Registry createRegistry()
/*     */   {
/* 577 */     if (registry == null) {
/* 578 */       registry = Registry.getRegistry(null, null);
/* 579 */       ClassLoader cl = MBeanUtils.class.getClassLoader();
/*     */       
/* 581 */       registry.loadDescriptors("org.apache.catalina.mbeans", cl);
/* 582 */       registry.loadDescriptors("org.apache.catalina.authenticator", cl);
/* 583 */       registry.loadDescriptors("org.apache.catalina.core", cl);
/* 584 */       registry.loadDescriptors("org.apache.catalina", cl);
/* 585 */       registry.loadDescriptors("org.apache.catalina.deploy", cl);
/* 586 */       registry.loadDescriptors("org.apache.catalina.loader", cl);
/* 587 */       registry.loadDescriptors("org.apache.catalina.realm", cl);
/* 588 */       registry.loadDescriptors("org.apache.catalina.session", cl);
/* 589 */       registry.loadDescriptors("org.apache.catalina.startup", cl);
/* 590 */       registry.loadDescriptors("org.apache.catalina.users", cl);
/* 591 */       registry.loadDescriptors("org.apache.catalina.ha", cl);
/* 592 */       registry.loadDescriptors("org.apache.catalina.connector", cl);
/* 593 */       registry.loadDescriptors("org.apache.catalina.valves", cl);
/* 594 */       registry.loadDescriptors("org.apache.catalina.storeconfig", cl);
/* 595 */       registry.loadDescriptors("org.apache.tomcat.util.descriptor.web", cl);
/*     */     }
/* 597 */     return registry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized MBeanServer createServer()
/*     */   {
/* 608 */     if (mserver == null) {
/* 609 */       mserver = Registry.getRegistry(null, null).getMBeanServer();
/*     */     }
/* 611 */     return mserver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void destroyMBean(ContextEnvironment environment)
/*     */     throws Exception
/*     */   {
/* 626 */     String mname = createManagedName(environment);
/* 627 */     ManagedBean managed = registry.findManagedBean(mname);
/* 628 */     if (managed == null) {
/* 629 */       return;
/*     */     }
/* 631 */     String domain = managed.getDomain();
/* 632 */     if (domain == null) {
/* 633 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 635 */     ObjectName oname = createObjectName(domain, environment);
/* 636 */     if (mserver.isRegistered(oname)) {
/* 637 */       mserver.unregisterMBean(oname);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void destroyMBean(ContextResource resource)
/*     */     throws Exception
/*     */   {
/* 656 */     if ("org.apache.catalina.UserDatabase".equals(resource.getType())) {
/* 657 */       destroyMBeanUserDatabase(resource.getName());
/*     */     }
/*     */     
/* 660 */     String mname = createManagedName(resource);
/* 661 */     ManagedBean managed = registry.findManagedBean(mname);
/* 662 */     if (managed == null) {
/* 663 */       return;
/*     */     }
/* 665 */     String domain = managed.getDomain();
/* 666 */     if (domain == null) {
/* 667 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 669 */     ObjectName oname = createObjectName(domain, resource);
/* 670 */     if (mserver.isRegistered(oname)) {
/* 671 */       mserver.unregisterMBean(oname);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void destroyMBean(ContextResourceLink resourceLink)
/*     */     throws Exception
/*     */   {
/* 688 */     String mname = createManagedName(resourceLink);
/* 689 */     ManagedBean managed = registry.findManagedBean(mname);
/* 690 */     if (managed == null) {
/* 691 */       return;
/*     */     }
/* 693 */     String domain = managed.getDomain();
/* 694 */     if (domain == null) {
/* 695 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 697 */     ObjectName oname = createObjectName(domain, resourceLink);
/* 698 */     if (mserver.isRegistered(oname)) {
/* 699 */       mserver.unregisterMBean(oname);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void destroyMBean(Group group)
/*     */     throws Exception
/*     */   {
/* 715 */     String mname = createManagedName(group);
/* 716 */     ManagedBean managed = registry.findManagedBean(mname);
/* 717 */     if (managed == null) {
/* 718 */       return;
/*     */     }
/* 720 */     String domain = managed.getDomain();
/* 721 */     if (domain == null) {
/* 722 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 724 */     ObjectName oname = createObjectName(domain, group);
/* 725 */     if (mserver.isRegistered(oname)) {
/* 726 */       mserver.unregisterMBean(oname);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void destroyMBean(Role role)
/*     */     throws Exception
/*     */   {
/* 743 */     String mname = createManagedName(role);
/* 744 */     ManagedBean managed = registry.findManagedBean(mname);
/* 745 */     if (managed == null) {
/* 746 */       return;
/*     */     }
/* 748 */     String domain = managed.getDomain();
/* 749 */     if (domain == null) {
/* 750 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 752 */     ObjectName oname = createObjectName(domain, role);
/* 753 */     if (mserver.isRegistered(oname)) {
/* 754 */       mserver.unregisterMBean(oname);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void destroyMBean(User user)
/*     */     throws Exception
/*     */   {
/* 771 */     String mname = createManagedName(user);
/* 772 */     ManagedBean managed = registry.findManagedBean(mname);
/* 773 */     if (managed == null) {
/* 774 */       return;
/*     */     }
/* 776 */     String domain = managed.getDomain();
/* 777 */     if (domain == null) {
/* 778 */       domain = mserver.getDefaultDomain();
/*     */     }
/* 780 */     ObjectName oname = createObjectName(domain, user);
/* 781 */     if (mserver.isRegistered(oname)) {
/* 782 */       mserver.unregisterMBean(oname);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void destroyMBeanUserDatabase(String userDatabase)
/*     */     throws Exception
/*     */   {
/* 799 */     ObjectName query = null;
/* 800 */     Set<ObjectName> results = null;
/*     */     
/*     */ 
/* 803 */     query = new ObjectName("Users:type=Group,database=" + userDatabase + ",*");
/*     */     
/* 805 */     results = mserver.queryNames(query, null);
/* 806 */     for (ObjectName result : results) {
/* 807 */       mserver.unregisterMBean(result);
/*     */     }
/*     */     
/*     */ 
/* 811 */     query = new ObjectName("Users:type=Role,database=" + userDatabase + ",*");
/*     */     
/* 813 */     results = mserver.queryNames(query, null);
/* 814 */     for (ObjectName result : results) {
/* 815 */       mserver.unregisterMBean(result);
/*     */     }
/*     */     
/*     */ 
/* 819 */     query = new ObjectName("Users:type=User,database=" + userDatabase + ",*");
/*     */     
/* 821 */     results = mserver.queryNames(query, null);
/* 822 */     for (ObjectName result : results) {
/* 823 */       mserver.unregisterMBean(result);
/*     */     }
/*     */     
/*     */ 
/* 827 */     ObjectName db = new ObjectName("Users:type=UserDatabase,database=" + userDatabase);
/*     */     
/* 829 */     if (mserver.isRegistered(db)) {
/* 830 */       mserver.unregisterMBean(db);
/*     */     }
/* 832 */     db = new ObjectName("Catalina:type=UserDatabase,database=" + userDatabase);
/*     */     
/* 834 */     if (mserver.isRegistered(db)) {
/* 835 */       mserver.unregisterMBean(db);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\MBeanUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */