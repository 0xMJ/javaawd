/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Deque;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.buf.StringUtils;
/*     */ import org.apache.tomcat.util.http.MimeHeaders;
/*     */ import org.apache.tomcat.util.http.parser.Host;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RemoteIpValve
/*     */   extends ValveBase
/*     */ {
/* 363 */   private static final Pattern commaSeparatedValuesPattern = Pattern.compile("\\s*,\\s*");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 368 */   private static final Log log = LogFactory.getLog(RemoteIpValve.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static String[] commaDelimitedListToStringArray(String commaDelimitedStrings)
/*     */   {
/* 376 */     return (commaDelimitedStrings == null) || (commaDelimitedStrings.length() == 0) ? new String[0] : commaSeparatedValuesPattern
/* 377 */       .split(commaDelimitedStrings);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected static String listToCommaDelimitedString(List<String> stringList)
/*     */   {
/* 390 */     if (stringList == null) {
/* 391 */       return "";
/*     */     }
/* 393 */     StringBuilder result = new StringBuilder();
/* 394 */     for (Iterator<String> it = stringList.iterator(); it.hasNext();) {
/* 395 */       Object element = it.next();
/* 396 */       if (element != null) {
/* 397 */         result.append(element);
/* 398 */         if (it.hasNext()) {
/* 399 */           result.append(", ");
/*     */         }
/*     */       }
/*     */     }
/* 403 */     return result.toString();
/*     */   }
/*     */   
/* 406 */   private String hostHeader = null;
/*     */   
/* 408 */   private boolean changeLocalName = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 413 */   private int httpServerPort = 80;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 418 */   private int httpsServerPort = 443;
/*     */   
/* 420 */   private String portHeader = null;
/*     */   
/* 422 */   private boolean changeLocalPort = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 427 */   private Pattern internalProxies = Pattern.compile("10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|192\\.168\\.\\d{1,3}\\.\\d{1,3}|169\\.254\\.\\d{1,3}\\.\\d{1,3}|127\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|172\\.1[6-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.2[0-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.3[0-1]{1}\\.\\d{1,3}\\.\\d{1,3}|0:0:0:0:0:0:0:1|::1");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 440 */   private String protocolHeader = "X-Forwarded-Proto";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 445 */   private String protocolHeaderHttpsValue = "https";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 450 */   private String proxiesHeader = "X-Forwarded-By";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 455 */   private String remoteIpHeader = "X-Forwarded-For";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 460 */   private boolean requestAttributesEnabled = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 465 */   private Pattern trustedProxies = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RemoteIpValve()
/*     */   {
/* 474 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHostHeader()
/*     */   {
/* 485 */     return this.hostHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHostHeader(String hostHeader)
/*     */   {
/* 496 */     this.hostHeader = hostHeader;
/*     */   }
/*     */   
/*     */   public boolean isChangeLocalName() {
/* 500 */     return this.changeLocalName;
/*     */   }
/*     */   
/*     */   public void setChangeLocalName(boolean changeLocalName) {
/* 504 */     this.changeLocalName = changeLocalName;
/*     */   }
/*     */   
/*     */   public int getHttpServerPort() {
/* 508 */     return this.httpServerPort;
/*     */   }
/*     */   
/*     */   public int getHttpsServerPort() {
/* 512 */     return this.httpsServerPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPortHeader()
/*     */   {
/* 523 */     return this.portHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPortHeader(String portHeader)
/*     */   {
/* 534 */     this.portHeader = portHeader;
/*     */   }
/*     */   
/*     */   public boolean isChangeLocalPort() {
/* 538 */     return this.changeLocalPort;
/*     */   }
/*     */   
/*     */   public void setChangeLocalPort(boolean changeLocalPort) {
/* 542 */     this.changeLocalPort = changeLocalPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getInternalProxies()
/*     */   {
/* 550 */     if (this.internalProxies == null) {
/* 551 */       return null;
/*     */     }
/* 553 */     return this.internalProxies.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProtocolHeader()
/*     */   {
/* 561 */     return this.protocolHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProtocolHeaderHttpsValue()
/*     */   {
/* 569 */     return this.protocolHeaderHttpsValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProxiesHeader()
/*     */   {
/* 577 */     return this.proxiesHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRemoteIpHeader()
/*     */   {
/* 585 */     return this.remoteIpHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getRequestAttributesEnabled()
/*     */   {
/* 594 */     return this.requestAttributesEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTrustedProxies()
/*     */   {
/* 602 */     if (this.trustedProxies == null) {
/* 603 */       return null;
/*     */     }
/* 605 */     return this.trustedProxies.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void invoke(org.apache.catalina.connector.Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/* 613 */     String originalRemoteAddr = request.getRemoteAddr();
/* 614 */     String originalRemoteHost = request.getRemoteHost();
/* 615 */     String originalScheme = request.getScheme();
/* 616 */     boolean originalSecure = request.isSecure();
/* 617 */     String originalServerName = request.getServerName();
/* 618 */     String originalLocalName = isChangeLocalName() ? request.getLocalName() : null;
/* 619 */     int originalServerPort = request.getServerPort();
/* 620 */     int originalLocalPort = request.getLocalPort();
/* 621 */     String originalProxiesHeader = request.getHeader(this.proxiesHeader);
/* 622 */     String originalRemoteIpHeader = request.getHeader(this.remoteIpHeader);
/*     */     
/* 624 */     boolean isInternal = (this.internalProxies != null) && (this.internalProxies.matcher(originalRemoteAddr).matches());
/*     */     
/* 626 */     if ((isInternal) || ((this.trustedProxies != null) && 
/* 627 */       (this.trustedProxies.matcher(originalRemoteAddr).matches()))) {
/* 628 */       String remoteIp = null;
/* 629 */       Deque<String> proxiesHeaderValue = new LinkedList();
/* 630 */       StringBuilder concatRemoteIpHeaderValue = new StringBuilder();
/*     */       
/* 632 */       for (Enumeration<String> e = request.getHeaders(this.remoteIpHeader); e.hasMoreElements();) {
/* 633 */         if (concatRemoteIpHeaderValue.length() > 0) {
/* 634 */           concatRemoteIpHeaderValue.append(", ");
/*     */         }
/*     */         
/* 637 */         concatRemoteIpHeaderValue.append((String)e.nextElement());
/*     */       }
/*     */       
/* 640 */       String[] remoteIpHeaderValue = commaDelimitedListToStringArray(concatRemoteIpHeaderValue.toString());
/*     */       
/* 642 */       if (!isInternal) {
/* 643 */         proxiesHeaderValue.addFirst(originalRemoteAddr);
/*     */       }
/*     */       
/* 646 */       for (int idx = remoteIpHeaderValue.length - 1; idx >= 0; idx--) {
/* 647 */         String currentRemoteIp = remoteIpHeaderValue[idx];
/* 648 */         remoteIp = currentRemoteIp;
/* 649 */         if ((this.internalProxies == null) || (!this.internalProxies.matcher(currentRemoteIp).matches()))
/*     */         {
/* 651 */           if ((this.trustedProxies != null) && 
/* 652 */             (this.trustedProxies.matcher(currentRemoteIp).matches())) {
/* 653 */             proxiesHeaderValue.addFirst(currentRemoteIp);
/*     */           } else {
/* 655 */             idx--;
/* 656 */             break;
/*     */           }
/*     */         }
/*     */       }
/* 660 */       LinkedList<String> newRemoteIpHeaderValue = new LinkedList();
/* 661 */       for (; idx >= 0; idx--) {
/* 662 */         String currentRemoteIp = remoteIpHeaderValue[idx];
/* 663 */         newRemoteIpHeaderValue.addFirst(currentRemoteIp);
/*     */       }
/* 665 */       if (remoteIp != null)
/*     */       {
/* 667 */         request.setRemoteAddr(remoteIp);
/* 668 */         if (request.getConnector().getEnableLookups())
/*     */         {
/*     */ 
/*     */           try
/*     */           {
/*     */ 
/* 674 */             InetAddress inetAddress = InetAddress.getByName(remoteIp);
/*     */             
/* 676 */             request.setRemoteHost(inetAddress.getCanonicalHostName());
/*     */           } catch (UnknownHostException e) {
/* 678 */             log.debug(sm.getString("remoteIpValve.invalidRemoteAddress", new Object[] { remoteIp }), e);
/* 679 */             request.setRemoteHost(remoteIp);
/*     */           }
/*     */         } else {
/* 682 */           request.setRemoteHost(remoteIp);
/*     */         }
/*     */         
/* 685 */         if (proxiesHeaderValue.size() == 0) {
/* 686 */           request.getCoyoteRequest().getMimeHeaders().removeHeader(this.proxiesHeader);
/*     */         } else {
/* 688 */           String commaDelimitedListOfProxies = StringUtils.join(proxiesHeaderValue);
/* 689 */           request.getCoyoteRequest().getMimeHeaders().setValue(this.proxiesHeader).setString(commaDelimitedListOfProxies);
/*     */         }
/* 691 */         if (newRemoteIpHeaderValue.size() == 0) {
/* 692 */           request.getCoyoteRequest().getMimeHeaders().removeHeader(this.remoteIpHeader);
/*     */         } else {
/* 694 */           String commaDelimitedRemoteIpHeaderValue = StringUtils.join(newRemoteIpHeaderValue);
/* 695 */           request.getCoyoteRequest().getMimeHeaders().setValue(this.remoteIpHeader).setString(commaDelimitedRemoteIpHeaderValue);
/*     */         }
/*     */       }
/*     */       
/* 699 */       if (this.protocolHeader != null) {
/* 700 */         String protocolHeaderValue = request.getHeader(this.protocolHeader);
/* 701 */         if (protocolHeaderValue != null)
/*     */         {
/*     */ 
/* 704 */           if (isForwardedProtoHeaderValueSecure(protocolHeaderValue)) {
/* 705 */             request.setSecure(true);
/* 706 */             request.getCoyoteRequest().scheme().setString("https");
/* 707 */             setPorts(request, this.httpsServerPort);
/*     */           } else {
/* 709 */             request.setSecure(false);
/* 710 */             request.getCoyoteRequest().scheme().setString("http");
/* 711 */             setPorts(request, this.httpServerPort);
/*     */           }
/*     */         }
/*     */       }
/* 715 */       if (this.hostHeader != null) {
/* 716 */         String hostHeaderValue = request.getHeader(this.hostHeader);
/* 717 */         if (hostHeaderValue != null) {
/*     */           try {
/* 719 */             int portIndex = Host.parse(hostHeaderValue);
/* 720 */             if (portIndex > -1) {
/* 721 */               log.debug(sm.getString("remoteIpValve.invalidHostWithPort", new Object[] { hostHeaderValue, this.hostHeader }));
/* 722 */               hostHeaderValue = hostHeaderValue.substring(0, portIndex);
/*     */             }
/*     */             
/* 725 */             request.getCoyoteRequest().serverName().setString(hostHeaderValue);
/* 726 */             if (isChangeLocalName()) {
/* 727 */               request.getCoyoteRequest().localName().setString(hostHeaderValue);
/*     */             }
/*     */           }
/*     */           catch (IllegalArgumentException iae) {
/* 731 */             log.debug(sm.getString("remoteIpValve.invalidHostHeader", new Object[] { hostHeaderValue, this.hostHeader }));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 736 */       request.setAttribute("org.apache.tomcat.request.forwarded", Boolean.TRUE);
/*     */       
/* 738 */       if (log.isDebugEnabled()) {
/* 739 */         log.debug("Incoming request " + request.getRequestURI() + " with originalRemoteAddr [" + originalRemoteAddr + "], originalRemoteHost=[" + originalRemoteHost + "], originalSecure=[" + originalSecure + "], originalScheme=[" + originalScheme + "], originalServerName=[" + originalServerName + "], originalServerPort=[" + originalServerPort + "] will be seen as newRemoteAddr=[" + request
/*     */         
/*     */ 
/*     */ 
/* 743 */           .getRemoteAddr() + "], newRemoteHost=[" + request
/* 744 */           .getRemoteHost() + "], newSecure=[" + request.isSecure() + "], newScheme=[" + request
/* 745 */           .getScheme() + "], newServerName=[" + request.getServerName() + "], newServerPort=[" + request
/* 746 */           .getServerPort() + "]");
/*     */       }
/*     */     }
/* 749 */     else if (log.isDebugEnabled()) {
/* 750 */       log.debug("Skip RemoteIpValve for request " + request.getRequestURI() + " with originalRemoteAddr '" + request
/* 751 */         .getRemoteAddr() + "'");
/*     */     }
/*     */     
/* 754 */     if (this.requestAttributesEnabled) {
/* 755 */       request.setAttribute("org.apache.catalina.AccessLog.RemoteAddr", request
/* 756 */         .getRemoteAddr());
/* 757 */       request.setAttribute("org.apache.tomcat.remoteAddr", request
/* 758 */         .getRemoteAddr());
/* 759 */       request.setAttribute("org.apache.catalina.AccessLog.RemoteHost", request
/* 760 */         .getRemoteHost());
/* 761 */       request.setAttribute("org.apache.catalina.AccessLog.Protocol", request
/* 762 */         .getProtocol());
/* 763 */       request.setAttribute("org.apache.catalina.AccessLog.ServerName", request
/* 764 */         .getServerName());
/* 765 */       request.setAttribute("org.apache.catalina.AccessLog.ServerPort", 
/* 766 */         Integer.valueOf(request.getServerPort()));
/*     */     }
/*     */     try {
/* 769 */       getNext().invoke(request, response);
/*     */     } finally { MimeHeaders headers;
/* 771 */       request.setRemoteAddr(originalRemoteAddr);
/* 772 */       request.setRemoteHost(originalRemoteHost);
/* 773 */       request.setSecure(originalSecure);
/* 774 */       request.getCoyoteRequest().scheme().setString(originalScheme);
/* 775 */       request.getCoyoteRequest().serverName().setString(originalServerName);
/* 776 */       if (isChangeLocalName()) {
/* 777 */         request.getCoyoteRequest().localName().setString(originalLocalName);
/*     */       }
/* 779 */       request.setServerPort(originalServerPort);
/* 780 */       request.setLocalPort(originalLocalPort);
/*     */       
/* 782 */       MimeHeaders headers = request.getCoyoteRequest().getMimeHeaders();
/* 783 */       if ((originalProxiesHeader == null) || (originalProxiesHeader.length() == 0)) {
/* 784 */         headers.removeHeader(this.proxiesHeader);
/*     */       } else {
/* 786 */         headers.setValue(this.proxiesHeader).setString(originalProxiesHeader);
/*     */       }
/*     */       
/* 789 */       if ((originalRemoteIpHeader == null) || (originalRemoteIpHeader.length() == 0)) {
/* 790 */         headers.removeHeader(this.remoteIpHeader);
/*     */       } else {
/* 792 */         headers.setValue(this.remoteIpHeader).setString(originalRemoteIpHeader);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isForwardedProtoHeaderValueSecure(String protocolHeaderValue)
/*     */   {
/* 802 */     if (!protocolHeaderValue.contains(",")) {
/* 803 */       return this.protocolHeaderHttpsValue.equalsIgnoreCase(protocolHeaderValue);
/*     */     }
/* 805 */     String[] forwardedProtocols = commaDelimitedListToStringArray(protocolHeaderValue);
/* 806 */     if (forwardedProtocols.length == 0) {
/* 807 */       return false;
/*     */     }
/* 809 */     for (String forwardedProtocol : forwardedProtocols) {
/* 810 */       if (!this.protocolHeaderHttpsValue.equalsIgnoreCase(forwardedProtocol)) {
/* 811 */         return false;
/*     */       }
/*     */     }
/* 814 */     return true;
/*     */   }
/*     */   
/*     */   private void setPorts(org.apache.catalina.connector.Request request, int defaultPort) {
/* 818 */     int port = defaultPort;
/* 819 */     if (this.portHeader != null) {
/* 820 */       String portHeaderValue = request.getHeader(this.portHeader);
/* 821 */       if (portHeaderValue != null) {
/*     */         try {
/* 823 */           port = Integer.parseInt(portHeaderValue);
/*     */         } catch (NumberFormatException nfe) {
/* 825 */           if (log.isDebugEnabled()) {
/* 826 */             log.debug(sm.getString("remoteIpValve.invalidPortHeader", new Object[] { portHeaderValue, this.portHeader }), nfe);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 833 */     request.setServerPort(port);
/* 834 */     if (this.changeLocalPort) {
/* 835 */       request.setLocalPort(port);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHttpServerPort(int httpServerPort)
/*     */   {
/* 849 */     this.httpServerPort = httpServerPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHttpsServerPort(int httpsServerPort)
/*     */   {
/* 862 */     this.httpsServerPort = httpsServerPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInternalProxies(String internalProxies)
/*     */   {
/* 875 */     if ((internalProxies == null) || (internalProxies.length() == 0)) {
/* 876 */       this.internalProxies = null;
/*     */     } else {
/* 878 */       this.internalProxies = Pattern.compile(internalProxies);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProtocolHeader(String protocolHeader)
/*     */   {
/* 893 */     this.protocolHeader = protocolHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProtocolHeaderHttpsValue(String protocolHeaderHttpsValue)
/*     */   {
/* 906 */     this.protocolHeaderHttpsValue = protocolHeaderHttpsValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxiesHeader(String proxiesHeader)
/*     */   {
/* 927 */     this.proxiesHeader = proxiesHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteIpHeader(String remoteIpHeader)
/*     */   {
/* 944 */     this.remoteIpHeader = remoteIpHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequestAttributesEnabled(boolean requestAttributesEnabled)
/*     */   {
/* 967 */     this.requestAttributesEnabled = requestAttributesEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTrustedProxies(String trustedProxies)
/*     */   {
/* 981 */     if ((trustedProxies == null) || (trustedProxies.length() == 0)) {
/* 982 */       this.trustedProxies = null;
/*     */     } else {
/* 984 */       this.trustedProxies = Pattern.compile(trustedProxies);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\RemoteIpValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */