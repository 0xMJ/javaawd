/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.SessionCookieConfig;
/*     */ import org.apache.catalina.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionConfig
/*     */ {
/*     */   private static final String DEFAULT_SESSION_COOKIE_NAME = "JSESSIONID";
/*     */   private static final String DEFAULT_SESSION_PARAMETER_NAME = "jsessionid";
/*     */   
/*     */   public static String getSessionCookieName(Context context)
/*     */   {
/*  36 */     String result = getConfiguredSessionCookieName(context);
/*     */     
/*  38 */     if (result == null) {
/*  39 */       result = "JSESSIONID";
/*     */     }
/*     */     
/*  42 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getSessionUriParamName(Context context)
/*     */   {
/*  53 */     String result = getConfiguredSessionCookieName(context);
/*     */     
/*  55 */     if (result == null) {
/*  56 */       result = "jsessionid";
/*     */     }
/*     */     
/*  59 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getConfiguredSessionCookieName(Context context)
/*     */   {
/*  69 */     if (context != null) {
/*  70 */       String cookieName = context.getSessionCookieName();
/*  71 */       if ((cookieName != null) && (cookieName.length() > 0)) {
/*  72 */         return cookieName;
/*     */       }
/*     */       
/*     */ 
/*  76 */       SessionCookieConfig scc = context.getServletContext().getSessionCookieConfig();
/*  77 */       cookieName = scc.getName();
/*  78 */       if ((cookieName != null) && (cookieName.length() > 0)) {
/*  79 */         return cookieName;
/*     */       }
/*     */     }
/*     */     
/*  83 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getSessionCookiePath(Context context)
/*     */   {
/*  96 */     SessionCookieConfig scc = context.getServletContext().getSessionCookieConfig();
/*     */     
/*  98 */     String contextPath = context.getSessionCookiePath();
/*  99 */     if ((contextPath == null) || (contextPath.length() == 0)) {
/* 100 */       contextPath = scc.getPath();
/*     */     }
/* 102 */     if ((contextPath == null) || (contextPath.length() == 0)) {
/* 103 */       contextPath = context.getEncodedPath();
/*     */     }
/* 105 */     if (context.getSessionCookiePathUsesTrailingSlash())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 110 */       if (!contextPath.endsWith("/")) {
/* 111 */         contextPath = contextPath + "/";
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 116 */     else if (contextPath.length() == 0) {
/* 117 */       contextPath = "/";
/*     */     }
/*     */     
/*     */ 
/* 121 */     return contextPath;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\SessionConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */