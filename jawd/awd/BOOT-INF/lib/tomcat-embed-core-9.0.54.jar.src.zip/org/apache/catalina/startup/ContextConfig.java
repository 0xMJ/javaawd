/*      */ package org.apache.catalina.startup;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileWriter;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.nio.file.Path;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.EnumSet;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Future;
/*      */ import javax.servlet.MultipartConfigElement;
/*      */ import javax.servlet.ServletContainerInitializer;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.SessionCookieConfig;
/*      */ import javax.servlet.annotation.HandlesTypes;
/*      */ import org.apache.catalina.Authenticator;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleEvent;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Loader;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.WebResourceRoot.ResourceSetType;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.core.StandardContext;
/*      */ import org.apache.catalina.core.StandardHost;
/*      */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.Introspection;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.Jar;
/*      */ import org.apache.tomcat.JarScanType;
/*      */ import org.apache.tomcat.JarScanner;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.bcel.classfile.AnnotationElementValue;
/*      */ import org.apache.tomcat.util.bcel.classfile.AnnotationEntry;
/*      */ import org.apache.tomcat.util.bcel.classfile.ArrayElementValue;
/*      */ import org.apache.tomcat.util.bcel.classfile.ClassFormatException;
/*      */ import org.apache.tomcat.util.bcel.classfile.ClassParser;
/*      */ import org.apache.tomcat.util.bcel.classfile.ElementValue;
/*      */ import org.apache.tomcat.util.bcel.classfile.ElementValuePair;
/*      */ import org.apache.tomcat.util.bcel.classfile.JavaClass;
/*      */ import org.apache.tomcat.util.buf.UriUtil;
/*      */ import org.apache.tomcat.util.descriptor.InputSourceUtil;
/*      */ import org.apache.tomcat.util.descriptor.XmlErrorHandler;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextLocalEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextService;
/*      */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*      */ import org.apache.tomcat.util.descriptor.web.FragmentJarScannerCallback;
/*      */ import org.apache.tomcat.util.descriptor.web.JspPropertyGroup;
/*      */ import org.apache.tomcat.util.descriptor.web.LoginConfig;
/*      */ import org.apache.tomcat.util.descriptor.web.MessageDestinationRef;
/*      */ import org.apache.tomcat.util.descriptor.web.MultipartDef;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityRoleRef;
/*      */ import org.apache.tomcat.util.descriptor.web.ServletDef;
/*      */ import org.apache.tomcat.util.descriptor.web.SessionConfig;
/*      */ import org.apache.tomcat.util.descriptor.web.WebXml;
/*      */ import org.apache.tomcat.util.descriptor.web.WebXmlParser;
/*      */ import org.apache.tomcat.util.digester.Digester;
/*      */ import org.apache.tomcat.util.digester.RuleSet;
/*      */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*      */ import org.apache.tomcat.util.file.ConfigurationSource;
/*      */ import org.apache.tomcat.util.file.ConfigurationSource.Resource;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.scan.JarFactory;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXParseException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ContextConfig
/*      */   implements LifecycleListener
/*      */ {
/*  125 */   private static final Log log = LogFactory.getLog(ContextConfig.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  131 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*      */   
/*      */ 
/*  134 */   protected static final LoginConfig DUMMY_LOGIN_CONFIG = new LoginConfig("NONE", null, null, null);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final Properties authenticators;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/*  147 */     Properties props = new Properties();
/*  148 */     try { InputStream is = ContextConfig.class.getClassLoader().getResourceAsStream("org/apache/catalina/startup/Authenticators.properties");Throwable localThrowable3 = null;
/*      */       try {
/*  150 */         if (is != null) {
/*  151 */           props.load(is);
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable1)
/*      */       {
/*  148 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*  153 */         if (is != null) if (localThrowable3 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else is.close();
/*  154 */       } } catch (IOException ioe) { props = null;
/*      */     }
/*  156 */     authenticators = props;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  162 */   protected static long deploymentCount = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  168 */   protected static final Map<Host, DefaultWebXmlCacheEntry> hostWebXmlCache = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  176 */   private static final Set<ServletContainerInitializer> EMPTY_SCI_SET = Collections.emptySet();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Map<String, Authenticator> customAuthenticators;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  189 */   protected volatile Context context = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  195 */   protected String defaultWebXml = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  201 */   protected boolean ok = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  207 */   protected String originalDocBase = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  214 */   private File antiLockingDocBase = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  220 */   protected final Map<ServletContainerInitializer, Set<Class<?>>> initializerClassMap = new LinkedHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  227 */   protected final Map<Class<?>, Set<ServletContainerInitializer>> typeInitializerMap = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  234 */   protected boolean handlesTypesAnnotations = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  240 */   protected boolean handlesTypesNonAnnotations = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDefaultWebXml()
/*      */   {
/*  252 */     if (this.defaultWebXml == null) {
/*  253 */       this.defaultWebXml = "conf/web.xml";
/*      */     }
/*  255 */     return this.defaultWebXml;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultWebXml(String path)
/*      */   {
/*  266 */     this.defaultWebXml = path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCustomAuthenticators(Map<String, Authenticator> customAuthenticators)
/*      */   {
/*  278 */     this.customAuthenticators = customAuthenticators;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void lifecycleEvent(LifecycleEvent event)
/*      */   {
/*      */     try
/*      */     {
/*  295 */       this.context = ((Context)event.getLifecycle());
/*      */     } catch (ClassCastException e) {
/*  297 */       log.error(sm.getString("contextConfig.cce", new Object[] { event.getLifecycle() }), e);
/*  298 */       return;
/*      */     }
/*      */     
/*      */ 
/*  302 */     if (event.getType().equals("configure_start")) {
/*  303 */       configureStart();
/*  304 */     } else if (event.getType().equals("before_start")) {
/*  305 */       beforeStart();
/*  306 */     } else if (event.getType().equals("after_start"))
/*      */     {
/*  308 */       if (this.originalDocBase != null) {
/*  309 */         this.context.setDocBase(this.originalDocBase);
/*      */       }
/*  311 */     } else if (event.getType().equals("configure_stop")) {
/*  312 */       configureStop();
/*  313 */     } else if (event.getType().equals("after_init")) {
/*  314 */       init();
/*  315 */     } else if (event.getType().equals("after_destroy")) {
/*  316 */       destroy();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void applicationAnnotationsConfig()
/*      */   {
/*  330 */     long t1 = System.currentTimeMillis();
/*      */     
/*  332 */     WebAnnotationSet.loadApplicationAnnotations(this.context);
/*      */     
/*  334 */     long t2 = System.currentTimeMillis();
/*  335 */     if ((this.context instanceof StandardContext)) {
/*  336 */       ((StandardContext)this.context).setStartupTime(t2 - t1 + ((StandardContext)this.context)
/*  337 */         .getStartupTime());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void authenticatorConfig()
/*      */   {
/*  348 */     LoginConfig loginConfig = this.context.getLoginConfig();
/*  349 */     if (loginConfig == null)
/*      */     {
/*  351 */       loginConfig = DUMMY_LOGIN_CONFIG;
/*  352 */       this.context.setLoginConfig(loginConfig);
/*      */     }
/*      */     
/*      */ 
/*  356 */     if (this.context.getAuthenticator() != null) {
/*  357 */       return;
/*      */     }
/*      */     
/*      */ 
/*  361 */     if (this.context.getRealm() == null) {
/*  362 */       log.error(sm.getString("contextConfig.missingRealm"));
/*  363 */       this.ok = false;
/*  364 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  372 */     Valve authenticator = null;
/*  373 */     if (this.customAuthenticators != null) {
/*  374 */       authenticator = (Valve)this.customAuthenticators.get(loginConfig.getAuthMethod());
/*      */     }
/*      */     
/*  377 */     if (authenticator == null) {
/*  378 */       if (authenticators == null) {
/*  379 */         log.error(sm.getString("contextConfig.authenticatorResources"));
/*  380 */         this.ok = false;
/*  381 */         return;
/*      */       }
/*      */       
/*      */ 
/*  385 */       String authenticatorName = authenticators.getProperty(loginConfig.getAuthMethod());
/*  386 */       if (authenticatorName == null) {
/*  387 */         log.error(sm.getString("contextConfig.authenticatorMissing", new Object[] {loginConfig
/*  388 */           .getAuthMethod() }));
/*  389 */         this.ok = false;
/*  390 */         return;
/*      */       }
/*      */       
/*      */       try
/*      */       {
/*  395 */         Class<?> authenticatorClass = Class.forName(authenticatorName);
/*  396 */         authenticator = (Valve)authenticatorClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */       } catch (Throwable t) {
/*  398 */         ExceptionUtils.handleThrowable(t);
/*  399 */         log.error(sm.getString("contextConfig.authenticatorInstantiate", new Object[] { authenticatorName }), t);
/*      */         
/*      */ 
/*      */ 
/*  403 */         this.ok = false;
/*      */       }
/*      */     }
/*      */     
/*  407 */     if (authenticator != null) {
/*  408 */       Pipeline pipeline = this.context.getPipeline();
/*  409 */       if (pipeline != null) {
/*  410 */         pipeline.addValve(authenticator);
/*  411 */         if (log.isDebugEnabled()) {
/*  412 */           log.debug(sm.getString("contextConfig.authenticatorConfigured", new Object[] {loginConfig
/*      */           
/*  414 */             .getAuthMethod() }));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Digester createContextDigester()
/*      */   {
/*  427 */     Digester digester = new Digester();
/*  428 */     digester.setValidating(false);
/*  429 */     digester.setRulesValidation(true);
/*  430 */     Map<Class<?>, List<String>> fakeAttributes = new HashMap();
/*  431 */     List<String> objectAttrs = new ArrayList();
/*  432 */     objectAttrs.add("className");
/*  433 */     fakeAttributes.put(Object.class, objectAttrs);
/*      */     
/*  435 */     List<String> contextAttrs = new ArrayList();
/*  436 */     contextAttrs.add("source");
/*  437 */     fakeAttributes.put(StandardContext.class, contextAttrs);
/*  438 */     digester.setFakeAttributes(fakeAttributes);
/*  439 */     RuleSet contextRuleSet = new ContextRuleSet("", false);
/*  440 */     digester.addRuleSet(contextRuleSet);
/*  441 */     RuleSet namingRuleSet = new NamingRuleSet("Context/");
/*  442 */     digester.addRuleSet(namingRuleSet);
/*  443 */     return digester;
/*      */   }
/*      */   
/*      */   protected boolean getGenerateCode()
/*      */   {
/*  448 */     Catalina catalina = Container.getService(this.context).getServer().getCatalina();
/*  449 */     if (catalina != null) {
/*  450 */       return catalina.getGenerateCode();
/*      */     }
/*  452 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   protected boolean getUseGeneratedCode()
/*      */   {
/*  458 */     Catalina catalina = Container.getService(this.context).getServer().getCatalina();
/*  459 */     if (catalina != null) {
/*  460 */       return catalina.getUseGeneratedCode();
/*      */     }
/*  462 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   protected File getGeneratedCodeLocation()
/*      */   {
/*  468 */     Catalina catalina = Container.getService(this.context).getServer().getCatalina();
/*  469 */     if (catalina != null) {
/*  470 */       return catalina.getGeneratedCodeLocation();
/*      */     }
/*      */     
/*  473 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   protected String getGeneratedCodePackage()
/*      */   {
/*  479 */     Catalina catalina = Container.getService(this.context).getServer().getCatalina();
/*  480 */     if (catalina != null) {
/*  481 */       return catalina.getGeneratedCodePackage();
/*      */     }
/*  483 */     return "generatedCodePackage";
/*      */   }
/*      */   
/*      */ 
/*      */   protected static String getContextXmlPackageName(String generatedCodePackage, Container container)
/*      */   {
/*  489 */     StringBuilder result = new StringBuilder();
/*  490 */     Container host = null;
/*  491 */     Container engine = null;
/*  492 */     while (container != null) {
/*  493 */       if ((container instanceof Host)) {
/*  494 */         host = container;
/*  495 */       } else if ((container instanceof Engine)) {
/*  496 */         engine = container;
/*      */       }
/*  498 */       container = container.getParent();
/*      */     }
/*  500 */     result.append(generatedCodePackage);
/*  501 */     if (engine != null) {
/*  502 */       result.append('.');
/*      */     }
/*  504 */     if (engine != null) {
/*  505 */       result.append(engine.getName());
/*  506 */       if (host != null) {
/*  507 */         result.append('.');
/*      */       }
/*      */     }
/*  510 */     if (host != null) {
/*  511 */       result.append(host.getName());
/*      */     }
/*  513 */     return result.toString();
/*      */   }
/*      */   
/*      */   protected File getContextXmlJavaSource(String contextXmlPackageName, String contextXmlSimpleClassName)
/*      */   {
/*  518 */     File generatedSourceFolder = getGeneratedCodeLocation();
/*  519 */     String path = contextXmlPackageName.replace('.', File.separatorChar);
/*  520 */     File packageFolder = new File(generatedSourceFolder, path);
/*  521 */     if ((packageFolder.isDirectory()) || (packageFolder.mkdirs())) {
/*  522 */       return new File(packageFolder, contextXmlSimpleClassName + ".java");
/*      */     }
/*  524 */     return null;
/*      */   }
/*      */   
/*      */   protected void generateClassHeader(Digester digester, String packageName, String resourceName)
/*      */   {
/*  529 */     StringBuilder code = digester.getGeneratedCode();
/*  530 */     code.append("package ").append(packageName).append(';').append(System.lineSeparator());
/*  531 */     code.append("public class ").append(resourceName).append(" implements ");
/*  532 */     code.append(ContextXml.class.getName().replace('$', '.'));
/*  533 */     code.append(" {").append(System.lineSeparator());
/*  534 */     code.append("public void load(");
/*  535 */     code.append(Context.class.getName());
/*  536 */     String contextArgument = digester.toVariableName(this.context);
/*  537 */     code.append(' ').append(contextArgument).append(") {").append(System.lineSeparator());
/*      */     
/*  539 */     digester.setKnown(this.context);
/*  540 */     code.append(this.context.getClass().getName()).append(' ').append(digester.toVariableName(this.context));
/*  541 */     code.append(" = (").append(this.context.getClass().getName()).append(") ").append(contextArgument);
/*  542 */     code.append(';').append(System.lineSeparator());
/*      */   }
/*      */   
/*      */   protected void generateClassFooter(Digester digester)
/*      */   {
/*  547 */     StringBuilder code = digester.getGeneratedCode();
/*  548 */     code.append('}').append(System.lineSeparator());
/*  549 */     code.append('}').append(System.lineSeparator());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void contextConfig(Digester digester)
/*      */   {
/*  564 */     String defaultContextXml = null;
/*      */     
/*  566 */     boolean generateCode = getGenerateCode();
/*  567 */     boolean useGeneratedCode = getUseGeneratedCode();
/*      */     
/*  569 */     String contextXmlPackageName = null;
/*  570 */     String contextXmlSimpleClassName = null;
/*  571 */     String contextXmlClassName = null;
/*  572 */     File contextXmlJavaSource = null;
/*      */     
/*      */ 
/*  575 */     if ((this.context instanceof StandardContext)) {
/*  576 */       defaultContextXml = ((StandardContext)this.context).getDefaultContextXml();
/*      */     }
/*      */     
/*  579 */     if (defaultContextXml == null) {
/*  580 */       defaultContextXml = "conf/context.xml";
/*      */     }
/*      */     
/*  583 */     ContextXml contextXml = null;
/*      */     
/*  585 */     if (!this.context.getOverride())
/*      */     {
/*  587 */       if ((useGeneratedCode) || (generateCode)) {
/*  588 */         contextXmlPackageName = getGeneratedCodePackage();
/*  589 */         contextXmlSimpleClassName = "ContextXmlDefault";
/*  590 */         contextXmlClassName = contextXmlPackageName + "." + contextXmlSimpleClassName;
/*      */       }
/*  592 */       if (useGeneratedCode) {
/*  593 */         contextXml = (ContextXml)Digester.loadGeneratedClass(contextXmlClassName);
/*      */       }
/*  595 */       if (contextXml != null) {
/*  596 */         contextXml.load(this.context);
/*  597 */         contextXml = null;
/*  598 */       } else if (!useGeneratedCode) {
/*      */         try {
/*  600 */           ConfigurationSource.Resource contextXmlResource = ConfigFileLoader.getSource().getResource(defaultContextXml);Throwable localThrowable15 = null;
/*  601 */           try { if (generateCode) {
/*  602 */               contextXmlJavaSource = getContextXmlJavaSource(contextXmlPackageName, contextXmlSimpleClassName);
/*  603 */               digester.startGeneratingCode();
/*  604 */               generateClassHeader(digester, contextXmlPackageName, contextXmlSimpleClassName);
/*      */             }
/*  606 */             URL defaultContextUrl = contextXmlResource.getURI().toURL();
/*  607 */             processContextConfig(digester, defaultContextUrl, contextXmlResource.getInputStream());
/*  608 */             if (generateCode) {
/*  609 */               generateClassFooter(digester);
/*  610 */               FileWriter writer = new FileWriter(contextXmlJavaSource);Throwable localThrowable17 = null;
/*  611 */               try { writer.write(digester.getGeneratedCode().toString());
/*      */               }
/*      */               catch (Throwable localThrowable1)
/*      */               {
/*  610 */                 localThrowable17 = localThrowable1;throw localThrowable1;
/*      */               }
/*      */               finally {}
/*  613 */               digester.endGeneratingCode();
/*  614 */               Digester.addGeneratedClass(contextXmlClassName);
/*      */             }
/*      */           }
/*      */           catch (Throwable localThrowable4)
/*      */           {
/*  599 */             localThrowable15 = localThrowable4;throw localThrowable4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  616 */             if (contextXmlResource != null) if (localThrowable15 != null) try { contextXmlResource.close(); } catch (Throwable localThrowable5) { localThrowable15.addSuppressed(localThrowable5); } else contextXmlResource.close();
/*  617 */           } } catch (MalformedURLException e) { log.error(sm.getString("contextConfig.badUrl", new Object[] { defaultContextXml }), e);
/*      */         }
/*      */         catch (IOException localIOException) {}
/*      */       }
/*      */       
/*      */ 
/*  623 */       if ((useGeneratedCode) || (generateCode)) {
/*  624 */         contextXmlPackageName = getContextXmlPackageName(getGeneratedCodePackage(), this.context);
/*  625 */         contextXmlSimpleClassName = "ContextXmlDefault";
/*  626 */         contextXmlClassName = contextXmlPackageName + "." + contextXmlSimpleClassName;
/*      */       }
/*  628 */       if (useGeneratedCode) {
/*  629 */         contextXml = (ContextXml)Digester.loadGeneratedClass(contextXmlClassName);
/*      */       }
/*  631 */       if (contextXml != null) {
/*  632 */         contextXml.load(this.context);
/*  633 */         contextXml = null;
/*  634 */       } else if (!useGeneratedCode) {
/*  635 */         String hostContextFile = Container.getConfigPath(this.context, "context.xml.default");
/*      */         try {
/*  637 */           ConfigurationSource.Resource contextXmlResource = ConfigFileLoader.getSource().getResource(hostContextFile);localThrowable4 = null;
/*  638 */           try { if (generateCode) {
/*  639 */               contextXmlJavaSource = getContextXmlJavaSource(contextXmlPackageName, contextXmlSimpleClassName);
/*  640 */               digester.startGeneratingCode();
/*  641 */               generateClassHeader(digester, contextXmlPackageName, contextXmlSimpleClassName);
/*      */             }
/*  643 */             URL defaultContextUrl = contextXmlResource.getURI().toURL();
/*  644 */             processContextConfig(digester, defaultContextUrl, contextXmlResource.getInputStream());
/*  645 */             if (generateCode) {
/*  646 */               generateClassFooter(digester);
/*  647 */               FileWriter writer = new FileWriter(contextXmlJavaSource);localThrowable1 = null;
/*  648 */               try { writer.write(digester.getGeneratedCode().toString());
/*      */               }
/*      */               catch (Throwable localThrowable19)
/*      */               {
/*  647 */                 localThrowable1 = localThrowable19;throw localThrowable19;
/*      */               }
/*      */               finally {}
/*  650 */               digester.endGeneratingCode();
/*  651 */               Digester.addGeneratedClass(contextXmlClassName);
/*      */             }
/*      */           }
/*      */           catch (Throwable localThrowable10)
/*      */           {
/*  636 */             localThrowable4 = localThrowable10;throw localThrowable10;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  653 */             if (contextXmlResource != null) if (localThrowable4 != null) try { contextXmlResource.close(); } catch (Throwable localThrowable11) { localThrowable4.addSuppressed(localThrowable11); } else contextXmlResource.close();
/*  654 */           } } catch (MalformedURLException e) { log.error(sm.getString("contextConfig.badUrl", new Object[] { hostContextFile }), e);
/*      */         }
/*      */         catch (IOException localIOException3) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  661 */     if (this.context.getConfigFile() != null) {
/*  662 */       if ((useGeneratedCode) || (generateCode)) {
/*  663 */         contextXmlPackageName = getContextXmlPackageName(getGeneratedCodePackage(), this.context);
/*  664 */         contextXmlSimpleClassName = "ContextXml_" + this.context.getName().replace('/', '_').replace("-", "__");
/*  665 */         contextXmlClassName = contextXmlPackageName + "." + contextXmlSimpleClassName;
/*      */       }
/*  667 */       if (useGeneratedCode) {
/*  668 */         contextXml = (ContextXml)Digester.loadGeneratedClass(contextXmlClassName);
/*      */       }
/*  670 */       if (contextXml != null) {
/*  671 */         contextXml.load(this.context);
/*  672 */         contextXml = null;
/*  673 */       } else if (!useGeneratedCode) {
/*  674 */         if (generateCode) {
/*  675 */           contextXmlJavaSource = getContextXmlJavaSource(contextXmlPackageName, contextXmlSimpleClassName);
/*  676 */           digester.startGeneratingCode();
/*  677 */           generateClassHeader(digester, contextXmlPackageName, contextXmlSimpleClassName);
/*      */         }
/*  679 */         processContextConfig(digester, this.context.getConfigFile(), null);
/*  680 */         if (generateCode) {
/*  681 */           generateClassFooter(digester);
/*  682 */           try { FileWriter writer = new FileWriter(contextXmlJavaSource);Throwable localThrowable16 = null;
/*  683 */             try { writer.write(digester.getGeneratedCode().toString());
/*      */             }
/*      */             catch (Throwable localThrowable13)
/*      */             {
/*  682 */               localThrowable16 = localThrowable13;throw localThrowable13;
/*      */             } finally {
/*  684 */               if (writer != null) if (localThrowable16 != null) try { writer.close(); } catch (Throwable localThrowable14) { localThrowable16.addSuppressed(localThrowable14); } else writer.close();
/*      */             }
/*      */           } catch (IOException localIOException2) {}
/*  687 */           digester.endGeneratingCode();
/*  688 */           Digester.addGeneratedClass(contextXmlClassName);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processContextConfig(Digester digester, URL contextXml, InputStream stream)
/*      */   {
/*  704 */     if (log.isDebugEnabled()) {
/*  705 */       log.debug("Processing context [" + this.context.getName() + "] configuration file [" + contextXml + "]");
/*      */     }
/*      */     
/*      */ 
/*  709 */     InputSource source = null;
/*      */     try
/*      */     {
/*  712 */       source = new InputSource(contextXml.toString());
/*  713 */       if (stream == null) {
/*  714 */         URLConnection xmlConn = contextXml.openConnection();
/*  715 */         xmlConn.setUseCaches(false);
/*  716 */         stream = xmlConn.getInputStream();
/*      */       }
/*      */     } catch (Exception e) {
/*  719 */       log.error(sm.getString("contextConfig.contextMissing", new Object[] { contextXml }), e);
/*      */     }
/*      */     
/*      */ 
/*  723 */     if (source == null) {
/*  724 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  728 */       source.setByteStream(stream);
/*  729 */       digester.setClassLoader(getClass().getClassLoader());
/*  730 */       digester.setUseContextClassLoader(false);
/*  731 */       digester.push(this.context.getParent());
/*  732 */       digester.push(this.context);
/*  733 */       XmlErrorHandler errorHandler = new XmlErrorHandler();
/*  734 */       digester.setErrorHandler(errorHandler);
/*  735 */       digester.parse(source);
/*  736 */       if ((errorHandler.getWarnings().size() > 0) || 
/*  737 */         (errorHandler.getErrors().size() > 0)) {
/*  738 */         errorHandler.logFindings(log, contextXml.toString());
/*  739 */         this.ok = false;
/*      */       }
/*  741 */       if (log.isDebugEnabled()) {
/*  742 */         log.debug("Successfully processed context [" + this.context.getName() + "] configuration file [" + contextXml + "]");
/*      */       }
/*      */       return;
/*      */     } catch (SAXParseException e) {
/*  746 */       log.error(sm.getString("contextConfig.contextParse", new Object[] {this.context
/*  747 */         .getName() }), e);
/*  748 */       log.error(sm.getString("contextConfig.defaultPosition", new Object[] {"" + e
/*  749 */         .getLineNumber(), "" + e
/*  750 */         .getColumnNumber() }));
/*  751 */       this.ok = false;
/*      */     } catch (Exception e) {
/*  753 */       log.error(sm.getString("contextConfig.contextParse", new Object[] {this.context
/*  754 */         .getName() }), e);
/*  755 */       this.ok = false;
/*      */     } finally {
/*      */       try {
/*  758 */         if (stream != null) {
/*  759 */           stream.close();
/*      */         }
/*      */       } catch (IOException e) {
/*  762 */         log.error(sm.getString("contextConfig.contextClose"), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void fixDocBase()
/*      */     throws IOException
/*      */   {
/*  774 */     Host host = (Host)this.context.getParent();
/*  775 */     File appBase = host.getAppBaseFile();
/*      */     
/*      */ 
/*  778 */     String docBaseConfigured = this.context.getDocBase();
/*      */     
/*  780 */     if (docBaseConfigured == null)
/*      */     {
/*  782 */       String path = this.context.getPath();
/*  783 */       if (path == null) {
/*  784 */         return;
/*      */       }
/*  786 */       ContextName cn = new ContextName(path, this.context.getWebappVersion());
/*  787 */       docBaseConfigured = cn.getBaseName();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  792 */     File docBaseConfiguredFile = new File(docBaseConfigured);
/*  793 */     String docBaseAbsolute; String docBaseAbsolute; if (!docBaseConfiguredFile.isAbsolute()) {
/*  794 */       docBaseAbsolute = new File(appBase, docBaseConfigured).getAbsolutePath();
/*      */     } else {
/*  796 */       docBaseAbsolute = docBaseConfiguredFile.getAbsolutePath();
/*      */     }
/*  798 */     File docBaseAbsoluteFile = new File(docBaseAbsolute);
/*  799 */     String originalDocBase = docBaseAbsolute;
/*      */     
/*  801 */     ContextName cn = new ContextName(this.context.getPath(), this.context.getWebappVersion());
/*  802 */     String pathName = cn.getBaseName();
/*      */     
/*  804 */     boolean unpackWARs = true;
/*  805 */     if ((host instanceof StandardHost)) {
/*  806 */       unpackWARs = ((StandardHost)host).isUnpackWARs();
/*  807 */       if ((unpackWARs) && ((this.context instanceof StandardContext))) {
/*  808 */         unpackWARs = ((StandardContext)this.context).getUnpackWAR();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  816 */     boolean docBaseAbsoluteInAppBase = docBaseAbsolute.startsWith(appBase.getPath() + File.separatorChar);
/*  817 */     if ((docBaseAbsolute.toLowerCase(Locale.ENGLISH).endsWith(".war")) && (!docBaseAbsoluteFile.isDirectory())) {
/*  818 */       URL war = UriUtil.buildJarUrl(docBaseAbsoluteFile);
/*  819 */       if (unpackWARs) {
/*  820 */         docBaseAbsolute = ExpandWar.expand(host, war, pathName);
/*  821 */         docBaseAbsoluteFile = new File(docBaseAbsolute);
/*  822 */         if ((this.context instanceof StandardContext)) {
/*  823 */           ((StandardContext)this.context).setOriginalDocBase(originalDocBase);
/*      */         }
/*      */       } else {
/*  826 */         ExpandWar.validate(host, war, pathName);
/*      */       }
/*      */     } else {
/*  829 */       File docBaseAbsoluteFileWar = new File(docBaseAbsolute + ".war");
/*  830 */       URL war = null;
/*  831 */       if ((docBaseAbsoluteFileWar.exists()) && (docBaseAbsoluteInAppBase)) {
/*  832 */         war = UriUtil.buildJarUrl(docBaseAbsoluteFileWar);
/*      */       }
/*  834 */       if (docBaseAbsoluteFile.exists()) {
/*  835 */         if ((war != null) && (unpackWARs))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  840 */           ExpandWar.expand(host, war, pathName);
/*      */         }
/*      */       } else {
/*  843 */         if (war != null) {
/*  844 */           if (unpackWARs) {
/*  845 */             docBaseAbsolute = ExpandWar.expand(host, war, pathName);
/*  846 */             docBaseAbsoluteFile = new File(docBaseAbsolute);
/*      */           } else {
/*  848 */             docBaseAbsoluteFile = docBaseAbsoluteFileWar;
/*  849 */             ExpandWar.validate(host, war, pathName);
/*      */           }
/*      */         }
/*  852 */         if ((this.context instanceof StandardContext)) {
/*  853 */           ((StandardContext)this.context).setOriginalDocBase(originalDocBase);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  858 */     String docBaseCanonical = docBaseAbsoluteFile.getCanonicalPath();
/*      */     
/*      */ 
/*      */ 
/*  862 */     boolean docBaseCanonicalInAppBase = docBaseAbsoluteFile.getCanonicalFile().toPath().startsWith(appBase.toPath());
/*      */     String docBase;
/*  864 */     if (docBaseCanonicalInAppBase) {
/*  865 */       String docBase = docBaseCanonical.substring(appBase.getPath().length());
/*  866 */       docBase = docBase.replace(File.separatorChar, '/');
/*  867 */       if (docBase.startsWith("/")) {
/*  868 */         docBase = docBase.substring(1);
/*      */       }
/*      */     } else {
/*  871 */       docBase = docBaseCanonical.replace(File.separatorChar, '/');
/*      */     }
/*      */     
/*  874 */     this.context.setDocBase(docBase);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void antiLocking()
/*      */   {
/*  880 */     if (((this.context instanceof StandardContext)) && 
/*  881 */       (((StandardContext)this.context).getAntiResourceLocking()))
/*      */     {
/*  883 */       Host host = (Host)this.context.getParent();
/*  884 */       String docBase = this.context.getDocBase();
/*  885 */       if (docBase == null) {
/*  886 */         return;
/*      */       }
/*  888 */       this.originalDocBase = docBase;
/*      */       
/*  890 */       File docBaseFile = new File(docBase);
/*  891 */       if (!docBaseFile.isAbsolute()) {
/*  892 */         docBaseFile = new File(host.getAppBaseFile(), docBase);
/*      */       }
/*      */       
/*  895 */       String path = this.context.getPath();
/*  896 */       if (path == null) {
/*  897 */         return;
/*      */       }
/*  899 */       ContextName cn = new ContextName(path, this.context.getWebappVersion());
/*  900 */       docBase = cn.getBaseName();
/*      */       
/*  902 */       String tmp = System.getProperty("java.io.tmpdir");
/*  903 */       File tmpFile = new File(tmp);
/*  904 */       if (!tmpFile.isDirectory()) {
/*  905 */         log.error(sm.getString("contextConfig.noAntiLocking", new Object[] { tmp, this.context.getName() }));
/*  906 */         return;
/*      */       }
/*      */       
/*  909 */       if (this.originalDocBase.toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/*  910 */         this.antiLockingDocBase = new File(tmpFile, deploymentCount++ + "-" + docBase + ".war");
/*      */       } else {
/*  912 */         this.antiLockingDocBase = new File(tmpFile, deploymentCount++ + "-" + docBase);
/*      */       }
/*  914 */       this.antiLockingDocBase = this.antiLockingDocBase.getAbsoluteFile();
/*      */       
/*  916 */       if (log.isDebugEnabled()) {
/*  917 */         log.debug("Anti locking context[" + this.context.getName() + "] setting docBase to " + this.antiLockingDocBase
/*      */         
/*  919 */           .getPath());
/*      */       }
/*      */       
/*      */ 
/*  923 */       ExpandWar.delete(this.antiLockingDocBase);
/*  924 */       if (ExpandWar.copy(docBaseFile, this.antiLockingDocBase)) {
/*  925 */         this.context.setDocBase(this.antiLockingDocBase.getPath());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void init()
/*      */   {
/*  937 */     Digester contextDigester = null;
/*  938 */     if (!getUseGeneratedCode()) {
/*  939 */       contextDigester = createContextDigester();
/*  940 */       contextDigester.getParser();
/*      */     }
/*      */     
/*  943 */     if (log.isDebugEnabled()) {
/*  944 */       log.debug(sm.getString("contextConfig.init"));
/*      */     }
/*  946 */     this.context.setConfigured(false);
/*  947 */     this.ok = true;
/*      */     
/*  949 */     contextConfig(contextDigester);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void beforeStart()
/*      */   {
/*      */     try
/*      */     {
/*  959 */       fixDocBase();
/*      */     } catch (IOException e) {
/*  961 */       log.error(sm.getString("contextConfig.fixDocBase", new Object[] {this.context
/*  962 */         .getName() }), e);
/*      */     }
/*      */     
/*  965 */     antiLocking();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void configureStart()
/*      */   {
/*  975 */     if (log.isDebugEnabled()) {
/*  976 */       log.debug(sm.getString("contextConfig.start"));
/*      */     }
/*      */     
/*  979 */     if (log.isDebugEnabled()) {
/*  980 */       log.debug(sm.getString("contextConfig.xmlSettings", new Object[] {this.context
/*  981 */         .getName(), 
/*  982 */         Boolean.valueOf(this.context.getXmlValidation()), 
/*  983 */         Boolean.valueOf(this.context.getXmlNamespaceAware()) }));
/*      */     }
/*      */     
/*  986 */     webConfig();
/*      */     
/*  988 */     if (!this.context.getIgnoreAnnotations()) {
/*  989 */       applicationAnnotationsConfig();
/*      */     }
/*  991 */     if (this.ok) {
/*  992 */       validateSecurityRoles();
/*      */     }
/*      */     
/*      */ 
/*  996 */     if (this.ok) {
/*  997 */       authenticatorConfig();
/*      */     }
/*      */     
/*      */ 
/* 1001 */     if (log.isDebugEnabled()) {
/* 1002 */       log.debug("Pipeline Configuration:");
/* 1003 */       Pipeline pipeline = this.context.getPipeline();
/* 1004 */       Valve[] valves = null;
/* 1005 */       if (pipeline != null) {
/* 1006 */         valves = pipeline.getValves();
/*      */       }
/* 1008 */       if (valves != null) {
/* 1009 */         for (Valve valve : valves) {
/* 1010 */           log.debug("  " + valve.getClass().getName());
/*      */         }
/*      */       }
/* 1013 */       log.debug("======================");
/*      */     }
/*      */     
/*      */ 
/* 1017 */     if (this.ok) {
/* 1018 */       this.context.setConfigured(true);
/*      */     } else {
/* 1020 */       log.error(sm.getString("contextConfig.unavailable"));
/* 1021 */       this.context.setConfigured(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void configureStop()
/*      */   {
/* 1032 */     if (log.isDebugEnabled()) {
/* 1033 */       log.debug(sm.getString("contextConfig.stop"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1039 */     Container[] children = this.context.findChildren();
/* 1040 */     for (int i = 0; i < children.length; i++) {
/* 1041 */       this.context.removeChild(children[i]);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1055 */     SecurityConstraint[] securityConstraints = this.context.findConstraints();
/* 1056 */     for (i = 0; i < securityConstraints.length; i++) {
/* 1057 */       this.context.removeConstraint(securityConstraints[i]);
/*      */     }
/*      */     
/*      */ 
/* 1061 */     ErrorPage[] errorPages = this.context.findErrorPages();
/* 1062 */     for (i = 0; i < errorPages.length; i++) {
/* 1063 */       this.context.removeErrorPage(errorPages[i]);
/*      */     }
/*      */     
/*      */ 
/* 1067 */     FilterDef[] filterDefs = this.context.findFilterDefs();
/* 1068 */     for (i = 0; i < filterDefs.length; i++) {
/* 1069 */       this.context.removeFilterDef(filterDefs[i]);
/*      */     }
/*      */     
/*      */ 
/* 1073 */     FilterMap[] filterMaps = this.context.findFilterMaps();
/* 1074 */     for (i = 0; i < filterMaps.length; i++) {
/* 1075 */       this.context.removeFilterMap(filterMaps[i]);
/*      */     }
/*      */     
/*      */ 
/* 1079 */     String[] mimeMappings = this.context.findMimeMappings();
/* 1080 */     for (i = 0; i < mimeMappings.length; i++) {
/* 1081 */       this.context.removeMimeMapping(mimeMappings[i]);
/*      */     }
/*      */     
/*      */ 
/* 1085 */     String[] parameters = this.context.findParameters();
/* 1086 */     for (i = 0; i < parameters.length; i++) {
/* 1087 */       this.context.removeParameter(parameters[i]);
/*      */     }
/*      */     
/*      */ 
/* 1091 */     String[] securityRoles = this.context.findSecurityRoles();
/* 1092 */     for (i = 0; i < securityRoles.length; i++) {
/* 1093 */       this.context.removeSecurityRole(securityRoles[i]);
/*      */     }
/*      */     
/*      */ 
/* 1097 */     String[] servletMappings = this.context.findServletMappings();
/* 1098 */     for (i = 0; i < servletMappings.length; i++) {
/* 1099 */       this.context.removeServletMapping(servletMappings[i]);
/*      */     }
/*      */     
/*      */ 
/* 1103 */     String[] welcomeFiles = this.context.findWelcomeFiles();
/* 1104 */     for (i = 0; i < welcomeFiles.length; i++) {
/* 1105 */       this.context.removeWelcomeFile(welcomeFiles[i]);
/*      */     }
/*      */     
/*      */ 
/* 1109 */     String[] wrapperLifecycles = this.context.findWrapperLifecycles();
/* 1110 */     for (i = 0; i < wrapperLifecycles.length; i++) {
/* 1111 */       this.context.removeWrapperLifecycle(wrapperLifecycles[i]);
/*      */     }
/*      */     
/*      */ 
/* 1115 */     String[] wrapperListeners = this.context.findWrapperListeners();
/* 1116 */     for (i = 0; i < wrapperListeners.length; i++) {
/* 1117 */       this.context.removeWrapperListener(wrapperListeners[i]);
/*      */     }
/*      */     
/*      */ 
/* 1121 */     if (this.antiLockingDocBase != null)
/*      */     {
/* 1123 */       ExpandWar.delete(this.antiLockingDocBase, false);
/*      */     }
/*      */     
/*      */ 
/* 1127 */     this.initializerClassMap.clear();
/* 1128 */     this.typeInitializerMap.clear();
/*      */     
/* 1130 */     this.ok = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void destroy()
/*      */   {
/* 1140 */     if (log.isDebugEnabled()) {
/* 1141 */       log.debug(sm.getString("contextConfig.destroy"));
/*      */     }
/*      */     
/*      */ 
/* 1145 */     Server s = getServer();
/* 1146 */     if ((s != null) && (!s.getState().isAvailable())) {
/* 1147 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1151 */     if ((this.context instanceof StandardContext)) {
/* 1152 */       String workDir = ((StandardContext)this.context).getWorkPath();
/* 1153 */       if (workDir != null) {
/* 1154 */         ExpandWar.delete(new File(workDir));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private Server getServer()
/*      */   {
/* 1161 */     Container c = this.context;
/* 1162 */     while ((c != null) && (!(c instanceof Engine))) {
/* 1163 */       c = c.getParent();
/*      */     }
/*      */     
/* 1166 */     if (c == null) {
/* 1167 */       return null;
/*      */     }
/*      */     
/* 1170 */     Service s = ((Engine)c).getService();
/*      */     
/* 1172 */     if (s == null) {
/* 1173 */       return null;
/*      */     }
/*      */     
/* 1176 */     return s.getServer();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void validateSecurityRoles()
/*      */   {
/* 1189 */     SecurityConstraint[] constraints = this.context.findConstraints();
/* 1190 */     SecurityConstraint[] arrayOfSecurityConstraint1 = constraints;int i = arrayOfSecurityConstraint1.length; String role; for (SecurityConstraint localSecurityConstraint1 = 0; localSecurityConstraint1 < i; localSecurityConstraint1++) { constraint = arrayOfSecurityConstraint1[localSecurityConstraint1];
/* 1191 */       String[] roles = constraint.findAuthRoles();
/* 1192 */       for (role : roles) {
/* 1193 */         if ((!"*".equals(role)) && 
/* 1194 */           (!this.context.findSecurityRole(role))) {
/* 1195 */           log.warn(sm.getString("contextConfig.role.auth", new Object[] { role }));
/* 1196 */           this.context.addSecurityRole(role);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1202 */     Container[] wrappers = this.context.findChildren();
/* 1203 */     Container[] arrayOfContainer1 = wrappers;localSecurityConstraint1 = arrayOfContainer1.length; for (SecurityConstraint constraint = 0; constraint < localSecurityConstraint1; constraint++) { Container container = arrayOfContainer1[constraint];
/* 1204 */       Wrapper wrapper = (Wrapper)container;
/* 1205 */       String runAs = wrapper.getRunAs();
/* 1206 */       if ((runAs != null) && (!this.context.findSecurityRole(runAs))) {
/* 1207 */         log.warn(sm.getString("contextConfig.role.runas", new Object[] { runAs }));
/* 1208 */         this.context.addSecurityRole(runAs);
/*      */       }
/* 1210 */       String[] names = wrapper.findSecurityReferences();
/* 1211 */       for (String name : names) {
/* 1212 */         String link = wrapper.findSecurityReference(name);
/* 1213 */         if ((link != null) && (!this.context.findSecurityRole(link))) {
/* 1214 */           log.warn(sm.getString("contextConfig.role.link", new Object[] { link }));
/* 1215 */           this.context.addSecurityRole(link);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected File getHostConfigBase()
/*      */   {
/* 1224 */     File file = null;
/* 1225 */     if ((this.context.getParent() instanceof Host)) {
/* 1226 */       file = ((Host)this.context.getParent()).getConfigBaseFile();
/*      */     }
/* 1228 */     return file;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void webConfig()
/*      */   {
/* 1265 */     WebXmlParser webXmlParser = new WebXmlParser(this.context.getXmlNamespaceAware(), this.context.getXmlValidation(), this.context.getXmlBlockExternal());
/*      */     
/* 1267 */     Set<WebXml> defaults = new HashSet();
/* 1268 */     defaults.add(getDefaultWebXmlFragment(webXmlParser));
/*      */     
/* 1270 */     Set<WebXml> tomcatWebXml = new HashSet();
/* 1271 */     tomcatWebXml.add(getTomcatWebXmlFragment(webXmlParser));
/*      */     
/* 1273 */     WebXml webXml = createWebXml();
/*      */     
/*      */ 
/* 1276 */     InputSource contextWebXml = getContextWebXmlSource();
/* 1277 */     if (!webXmlParser.parseWebXml(contextWebXml, webXml, false)) {
/* 1278 */       this.ok = false;
/*      */     }
/*      */     
/* 1281 */     ServletContext sContext = this.context.getServletContext();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1289 */     Map<String, WebXml> fragments = processJarsForWebFragments(webXml, webXmlParser);
/*      */     
/*      */ 
/* 1292 */     Set<WebXml> orderedFragments = null;
/*      */     
/* 1294 */     orderedFragments = WebXml.orderWebFragments(webXml, fragments, sContext);
/*      */     
/*      */ 
/* 1297 */     if (this.ok) {
/* 1298 */       processServletContainerInitializers();
/*      */     }
/*      */     
/* 1301 */     if ((!webXml.isMetadataComplete()) || (this.typeInitializerMap.size() > 0))
/*      */     {
/* 1303 */       processClasses(webXml, orderedFragments);
/*      */     }
/*      */     
/* 1306 */     if (!webXml.isMetadataComplete())
/*      */     {
/*      */ 
/* 1309 */       if (this.ok) {
/* 1310 */         this.ok = webXml.merge(orderedFragments);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1315 */       webXml.merge(tomcatWebXml);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1320 */       webXml.merge(defaults);
/*      */       
/*      */ 
/* 1323 */       if (this.ok) {
/* 1324 */         convertJsps(webXml);
/*      */       }
/*      */       
/*      */ 
/* 1328 */       if (this.ok) {
/* 1329 */         configureContext(webXml);
/*      */       }
/*      */     } else {
/* 1332 */       webXml.merge(tomcatWebXml);
/* 1333 */       webXml.merge(defaults);
/* 1334 */       convertJsps(webXml);
/* 1335 */       configureContext(webXml);
/*      */     }
/*      */     
/* 1338 */     if (this.context.getLogEffectiveWebXml()) {
/* 1339 */       log.info(sm.getString("contextConfig.effectiveWebXml", new Object[] { webXml.toXml() }));
/*      */     }
/*      */     
/*      */     Set<WebXml> resourceJars;
/*      */     
/* 1344 */     if (this.ok)
/*      */     {
/*      */ 
/* 1347 */       resourceJars = new LinkedHashSet(orderedFragments);
/* 1348 */       for (WebXml fragment : fragments.values()) {
/* 1349 */         if (!resourceJars.contains(fragment)) {
/* 1350 */           resourceJars.add(fragment);
/*      */         }
/*      */       }
/* 1353 */       processResourceJARs(resourceJars);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1360 */     if (this.ok)
/*      */     {
/*      */ 
/* 1363 */       for (Object entry : this.initializerClassMap.entrySet()) {
/* 1364 */         if (((Set)((Map.Entry)entry).getValue()).isEmpty()) {
/* 1365 */           this.context.addServletContainerInitializer(
/* 1366 */             (ServletContainerInitializer)((Map.Entry)entry).getKey(), null);
/*      */         } else {
/* 1368 */           this.context.addServletContainerInitializer(
/* 1369 */             (ServletContainerInitializer)((Map.Entry)entry).getKey(), (Set)((Map.Entry)entry).getValue());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void processClasses(WebXml webXml, Set<WebXml> orderedFragments)
/*      */   {
/*      */     Map<String, JavaClassCacheEntry> javaClassCache;
/*      */     
/*      */     Map<String, JavaClassCacheEntry> javaClassCache;
/*      */     
/* 1382 */     if (this.context.getParallelAnnotationScanning()) {
/* 1383 */       javaClassCache = new ConcurrentHashMap();
/*      */     } else {
/* 1385 */       javaClassCache = new HashMap();
/*      */     }
/*      */     
/* 1388 */     if (this.ok)
/*      */     {
/* 1390 */       WebResource[] webResources = this.context.getResources().listResources("/WEB-INF/classes");
/*      */       
/* 1392 */       for (WebResource webResource : webResources)
/*      */       {
/*      */ 
/* 1395 */         if (!"META-INF".equals(webResource.getName()))
/*      */         {
/*      */ 
/* 1398 */           processAnnotationsWebResource(webResource, webXml, webXml
/* 1399 */             .isMetadataComplete(), javaClassCache);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1407 */     if (this.ok) {
/* 1408 */       processAnnotations(orderedFragments, webXml
/* 1409 */         .isMetadataComplete(), javaClassCache);
/*      */     }
/*      */     
/*      */ 
/* 1413 */     javaClassCache.clear();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void configureContext(WebXml webxml)
/*      */   {
/* 1421 */     this.context.setPublicId(webxml.getPublicId());
/*      */     
/*      */ 
/* 1424 */     this.context.setEffectiveMajorVersion(webxml.getMajorVersion());
/* 1425 */     this.context.setEffectiveMinorVersion(webxml.getMinorVersion());
/*      */     
/* 1427 */     for (Map.Entry<String, String> entry : webxml.getContextParams().entrySet()) {
/* 1428 */       this.context.addParameter((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/* 1430 */     this.context.setDenyUncoveredHttpMethods(webxml
/* 1431 */       .getDenyUncoveredHttpMethods());
/* 1432 */     this.context.setDisplayName(webxml.getDisplayName());
/* 1433 */     this.context.setDistributable(webxml.isDistributable());
/* 1434 */     for (ContextLocalEjb ejbLocalRef : webxml.getEjbLocalRefs().values()) {
/* 1435 */       this.context.getNamingResources().addLocalEjb(ejbLocalRef);
/*      */     }
/* 1437 */     for (ContextEjb ejbRef : webxml.getEjbRefs().values()) {
/* 1438 */       this.context.getNamingResources().addEjb(ejbRef);
/*      */     }
/* 1440 */     for (ContextEnvironment environment : webxml.getEnvEntries().values()) {
/* 1441 */       this.context.getNamingResources().addEnvironment(environment);
/*      */     }
/* 1443 */     for (ErrorPage errorPage : webxml.getErrorPages().values()) {
/* 1444 */       this.context.addErrorPage(errorPage);
/*      */     }
/* 1446 */     for (FilterDef filter : webxml.getFilters().values()) {
/* 1447 */       if (filter.getAsyncSupported() == null) {
/* 1448 */         filter.setAsyncSupported("false");
/*      */       }
/* 1450 */       this.context.addFilterDef(filter);
/*      */     }
/* 1452 */     for (FilterMap filterMap : webxml.getFilterMappings()) {
/* 1453 */       this.context.addFilterMap(filterMap);
/*      */     }
/* 1455 */     this.context.setJspConfigDescriptor(webxml.getJspConfigDescriptor());
/* 1456 */     for (String listener : webxml.getListeners()) {
/* 1457 */       this.context.addApplicationListener(listener);
/*      */     }
/*      */     
/* 1460 */     for (Map.Entry<String, String> entry : webxml.getLocaleEncodingMappings().entrySet()) {
/* 1461 */       this.context.addLocaleEncodingMappingParameter((String)entry.getKey(), 
/* 1462 */         (String)entry.getValue());
/*      */     }
/*      */     
/* 1465 */     if (webxml.getLoginConfig() != null) {
/* 1466 */       this.context.setLoginConfig(webxml.getLoginConfig());
/*      */     }
/*      */     
/* 1469 */     for (MessageDestinationRef mdr : webxml.getMessageDestinationRefs().values()) {
/* 1470 */       this.context.getNamingResources().addMessageDestinationRef(mdr);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1475 */     this.context.setIgnoreAnnotations(webxml.isMetadataComplete());
/*      */     
/* 1477 */     for (Map.Entry<String, String> entry : webxml.getMimeMappings().entrySet()) {
/* 1478 */       this.context.addMimeMapping((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/* 1480 */     this.context.setRequestCharacterEncoding(webxml.getRequestCharacterEncoding());
/*      */     
/*      */ 
/* 1483 */     for (ContextResourceEnvRef resource : webxml.getResourceEnvRefs().values()) {
/* 1484 */       this.context.getNamingResources().addResourceEnvRef(resource);
/*      */     }
/* 1486 */     for (??? = webxml.getResourceRefs().values().iterator(); ???.hasNext();) { resource = (ContextResource)???.next();
/* 1487 */       this.context.getNamingResources().addResource(resource); }
/*      */     ContextResource resource;
/* 1489 */     this.context.setResponseCharacterEncoding(webxml.getResponseCharacterEncoding());
/*      */     
/* 1491 */     boolean allAuthenticatedUsersIsAppRole = webxml.getSecurityRoles().contains("**");
/*      */     
/* 1493 */     for (SecurityConstraint constraint : webxml.getSecurityConstraints()) {
/* 1494 */       if (allAuthenticatedUsersIsAppRole) {
/* 1495 */         constraint.treatAllAuthenticatedUsersAsApplicationRole();
/*      */       }
/* 1497 */       this.context.addConstraint(constraint);
/*      */     }
/* 1499 */     for (String role : webxml.getSecurityRoles()) {
/* 1500 */       this.context.addSecurityRole(role);
/*      */     }
/* 1502 */     for (ContextService service : webxml.getServiceRefs().values()) {
/* 1503 */       this.context.getNamingResources().addService(service);
/*      */     }
/* 1505 */     for (ServletDef servlet : webxml.getServlets().values()) {
/* 1506 */       Wrapper wrapper = this.context.createWrapper();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1513 */       if (servlet.getLoadOnStartup() != null) {
/* 1514 */         wrapper.setLoadOnStartup(servlet.getLoadOnStartup().intValue());
/*      */       }
/* 1516 */       if (servlet.getEnabled() != null) {
/* 1517 */         wrapper.setEnabled(servlet.getEnabled().booleanValue());
/*      */       }
/* 1519 */       wrapper.setName(servlet.getServletName());
/* 1520 */       Map<String, String> params = servlet.getParameterMap();
/* 1521 */       for (Iterator localIterator2 = params.entrySet().iterator(); localIterator2.hasNext();) { entry = (Map.Entry)localIterator2.next();
/* 1522 */         wrapper.addInitParameter((String)entry.getKey(), (String)entry.getValue()); }
/*      */       Map.Entry<String, String> entry;
/* 1524 */       wrapper.setRunAs(servlet.getRunAs());
/* 1525 */       roleRefs = servlet.getSecurityRoleRefs();
/* 1526 */       for (SecurityRoleRef roleRef : (Set)roleRefs) {
/* 1527 */         wrapper.addSecurityReference(roleRef
/* 1528 */           .getName(), roleRef.getLink());
/*      */       }
/* 1530 */       wrapper.setServletClass(servlet.getServletClass());
/* 1531 */       MultipartDef multipartdef = servlet.getMultipartDef();
/* 1532 */       if (multipartdef != null) {
/* 1533 */         long maxFileSize = -1L;
/* 1534 */         long maxRequestSize = -1L;
/* 1535 */         int fileSizeThreshold = 0;
/*      */         
/* 1537 */         if (null != multipartdef.getMaxFileSize()) {
/* 1538 */           maxFileSize = Long.parseLong(multipartdef.getMaxFileSize());
/*      */         }
/* 1540 */         if (null != multipartdef.getMaxRequestSize()) {
/* 1541 */           maxRequestSize = Long.parseLong(multipartdef.getMaxRequestSize());
/*      */         }
/* 1543 */         if (null != multipartdef.getFileSizeThreshold()) {
/* 1544 */           fileSizeThreshold = Integer.parseInt(multipartdef.getFileSizeThreshold());
/*      */         }
/*      */         
/* 1547 */         wrapper.setMultipartConfigElement(new MultipartConfigElement(multipartdef
/* 1548 */           .getLocation(), maxFileSize, maxRequestSize, fileSizeThreshold));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1553 */       if (servlet.getAsyncSupported() != null) {
/* 1554 */         wrapper.setAsyncSupported(servlet
/* 1555 */           .getAsyncSupported().booleanValue());
/*      */       }
/* 1557 */       wrapper.setOverridable(servlet.isOverridable());
/* 1558 */       this.context.addChild(wrapper);
/*      */     }
/*      */     Object roleRefs;
/* 1561 */     for (Map.Entry<String, String> entry : webxml.getServletMappings().entrySet()) {
/* 1562 */       this.context.addServletMappingDecoded((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/* 1564 */     SessionConfig sessionConfig = webxml.getSessionConfig();
/* 1565 */     SessionCookieConfig scc; if (sessionConfig != null) {
/* 1566 */       if (sessionConfig.getSessionTimeout() != null) {
/* 1567 */         this.context.setSessionTimeout(sessionConfig
/* 1568 */           .getSessionTimeout().intValue());
/*      */       }
/*      */       
/* 1571 */       scc = this.context.getServletContext().getSessionCookieConfig();
/* 1572 */       scc.setName(sessionConfig.getCookieName());
/* 1573 */       scc.setDomain(sessionConfig.getCookieDomain());
/* 1574 */       scc.setPath(sessionConfig.getCookiePath());
/* 1575 */       scc.setComment(sessionConfig.getCookieComment());
/* 1576 */       if (sessionConfig.getCookieHttpOnly() != null) {
/* 1577 */         scc.setHttpOnly(sessionConfig.getCookieHttpOnly().booleanValue());
/*      */       }
/* 1579 */       if (sessionConfig.getCookieSecure() != null) {
/* 1580 */         scc.setSecure(sessionConfig.getCookieSecure().booleanValue());
/*      */       }
/* 1582 */       if (sessionConfig.getCookieMaxAge() != null) {
/* 1583 */         scc.setMaxAge(sessionConfig.getCookieMaxAge().intValue());
/*      */       }
/* 1585 */       if (sessionConfig.getSessionTrackingModes().size() > 0) {
/* 1586 */         this.context.getServletContext().setSessionTrackingModes(sessionConfig
/* 1587 */           .getSessionTrackingModes());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1593 */     for (String welcomeFile : webxml.getWelcomeFiles())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1601 */       if ((welcomeFile != null) && (welcomeFile.length() > 0)) {
/* 1602 */         this.context.addWelcomeFile(welcomeFile);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1608 */     for (JspPropertyGroup jspPropertyGroup : webxml.getJspPropertyGroups()) {
/* 1609 */       jspServletName = this.context.findServletMapping("*.jsp");
/* 1610 */       if (jspServletName == null) {
/* 1611 */         jspServletName = "jsp";
/*      */       }
/* 1613 */       if (this.context.findChild(jspServletName) != null) {
/* 1614 */         for (roleRefs = jspPropertyGroup.getUrlPatterns().iterator(); ((Iterator)roleRefs).hasNext();) { String urlPattern = (String)((Iterator)roleRefs).next();
/* 1615 */           this.context.addServletMappingDecoded(urlPattern, jspServletName, true);
/*      */         }
/*      */         
/* 1618 */       } else if (log.isDebugEnabled()) {
/* 1619 */         for (roleRefs = jspPropertyGroup.getUrlPatterns().iterator(); ((Iterator)roleRefs).hasNext();) { String urlPattern = (String)((Iterator)roleRefs).next();
/* 1620 */           log.debug("Skipping " + urlPattern + " , no servlet " + jspServletName);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     String jspServletName;
/*      */     
/* 1628 */     for (Map.Entry<String, String> entry : webxml.getPostConstructMethods().entrySet()) {
/* 1629 */       this.context.addPostConstructMethod((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/*      */     
/*      */ 
/* 1633 */     for (Map.Entry<String, String> entry : webxml.getPreDestroyMethods().entrySet()) {
/* 1634 */       this.context.addPreDestroyMethod((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private WebXml getTomcatWebXmlFragment(WebXmlParser webXmlParser)
/*      */   {
/* 1641 */     WebXml webXmlTomcatFragment = createWebXml();
/* 1642 */     webXmlTomcatFragment.setOverridable(true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1647 */     webXmlTomcatFragment.setDistributable(true);
/*      */     
/*      */ 
/* 1650 */     webXmlTomcatFragment.setAlwaysAddWelcomeFiles(false);
/*      */     
/* 1652 */     WebResource resource = this.context.getResources().getResource("/WEB-INF/tomcat-web.xml");
/* 1653 */     if (resource.isFile()) {
/*      */       try {
/* 1655 */         InputSource source = new InputSource(resource.getURL().toURI().toString());
/* 1656 */         source.setByteStream(resource.getInputStream());
/* 1657 */         if (!webXmlParser.parseWebXml(source, webXmlTomcatFragment, false)) {
/* 1658 */           this.ok = false;
/*      */         }
/*      */       } catch (URISyntaxException e) {
/* 1661 */         log.error(sm.getString("contextConfig.tomcatWebXmlError"), e);
/*      */       }
/*      */     }
/* 1664 */     return webXmlTomcatFragment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private WebXml getDefaultWebXmlFragment(WebXmlParser webXmlParser)
/*      */   {
/* 1671 */     Host host = (Host)this.context.getParent();
/*      */     
/* 1673 */     DefaultWebXmlCacheEntry entry = (DefaultWebXmlCacheEntry)hostWebXmlCache.get(host);
/*      */     
/* 1675 */     InputSource globalWebXml = getGlobalWebXmlSource();
/* 1676 */     InputSource hostWebXml = getHostWebXmlSource();
/*      */     
/* 1678 */     long globalTimeStamp = 0L;
/* 1679 */     long hostTimeStamp = 0L;
/*      */     
/* 1681 */     if (globalWebXml != null) {
/* 1682 */       URLConnection uc = null;
/*      */       try {
/* 1684 */         URL url = new URL(globalWebXml.getSystemId());
/* 1685 */         uc = url.openConnection();
/* 1686 */         globalTimeStamp = uc.getLastModified();
/*      */         
/*      */ 
/*      */ 
/* 1690 */         if (uc != null) {
/*      */           try {
/* 1692 */             uc.getInputStream().close();
/*      */           } catch (IOException e) {
/* 1694 */             ExceptionUtils.handleThrowable(e);
/* 1695 */             globalTimeStamp = -1L;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1701 */         if (hostWebXml == null) {
/*      */           break label320;
/*      */         }
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 1688 */         globalTimeStamp = -1L;
/*      */       } finally {
/* 1690 */         if (uc != null) {
/*      */           try {
/* 1692 */             uc.getInputStream().close();
/*      */           } catch (IOException e) {
/* 1694 */             ExceptionUtils.handleThrowable(e);
/* 1695 */             globalTimeStamp = -1L;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1702 */     URLConnection uc = null;
/*      */     try {
/* 1704 */       URL url = new URL(hostWebXml.getSystemId());
/* 1705 */       uc = url.openConnection();
/* 1706 */       hostTimeStamp = uc.getLastModified();
/*      */       
/*      */ 
/*      */ 
/* 1710 */       if (uc != null) {
/*      */         try {
/* 1712 */           uc.getInputStream().close();
/*      */         } catch (IOException e) {
/* 1714 */           ExceptionUtils.handleThrowable(e);
/* 1715 */           hostTimeStamp = -1L;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1721 */       if (entry == null) {
/*      */         break label359;
/*      */       }
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 1708 */       hostTimeStamp = -1L;
/*      */     } finally {
/* 1710 */       if (uc != null) {
/*      */         try {
/* 1712 */           uc.getInputStream().close();
/*      */         } catch (IOException e) {
/* 1714 */           ExceptionUtils.handleThrowable(e);
/* 1715 */           hostTimeStamp = -1L;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     label320:
/* 1721 */     if ((entry.getGlobalTimeStamp() == globalTimeStamp) && 
/* 1722 */       (entry.getHostTimeStamp() == hostTimeStamp)) {
/* 1723 */       InputSourceUtil.close(globalWebXml);
/* 1724 */       InputSourceUtil.close(hostWebXml);
/* 1725 */       return entry.getWebXml();
/*      */     }
/*      */     
/*      */ 
/*      */     label359:
/*      */     
/* 1731 */     synchronized (host.getPipeline()) {
/* 1732 */       entry = (DefaultWebXmlCacheEntry)hostWebXmlCache.get(host);
/* 1733 */       if ((entry != null) && (entry.getGlobalTimeStamp() == globalTimeStamp) && 
/* 1734 */         (entry.getHostTimeStamp() == hostTimeStamp)) {
/* 1735 */         return entry.getWebXml();
/*      */       }
/*      */       
/* 1738 */       WebXml webXmlDefaultFragment = createWebXml();
/* 1739 */       webXmlDefaultFragment.setOverridable(true);
/*      */       
/*      */ 
/*      */ 
/* 1743 */       webXmlDefaultFragment.setDistributable(true);
/*      */       
/*      */ 
/* 1746 */       webXmlDefaultFragment.setAlwaysAddWelcomeFiles(false);
/*      */       
/*      */ 
/* 1749 */       if (globalWebXml == null)
/*      */       {
/* 1751 */         log.info(sm.getString("contextConfig.defaultMissing"));
/*      */       }
/* 1753 */       else if (!webXmlParser.parseWebXml(globalWebXml, webXmlDefaultFragment, false))
/*      */       {
/* 1755 */         this.ok = false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1761 */       webXmlDefaultFragment.setReplaceWelcomeFiles(true);
/*      */       
/* 1763 */       if (!webXmlParser.parseWebXml(hostWebXml, webXmlDefaultFragment, false))
/*      */       {
/* 1765 */         this.ok = false;
/*      */       }
/*      */       
/*      */ 
/* 1769 */       if ((globalTimeStamp != -1L) && (hostTimeStamp != -1L)) {
/* 1770 */         entry = new DefaultWebXmlCacheEntry(webXmlDefaultFragment, globalTimeStamp, hostTimeStamp);
/*      */         
/* 1772 */         hostWebXmlCache.put(host, entry);
/*      */         
/*      */ 
/* 1775 */         host.addLifecycleListener(new HostWebXmlCacheCleaner(null));
/*      */       }
/*      */       
/* 1778 */       return webXmlDefaultFragment;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void convertJsps(WebXml webXml)
/*      */   {
/* 1785 */     ServletDef jspServlet = (ServletDef)webXml.getServlets().get("jsp");
/* 1786 */     Wrapper w; Map<String, String> jspInitParams; if (jspServlet == null) {
/* 1787 */       Map<String, String> jspInitParams = new HashMap();
/* 1788 */       w = (Wrapper)this.context.findChild("jsp");
/* 1789 */       if (w != null) {
/* 1790 */         String[] params = w.findInitParameters();
/* 1791 */         for (String param : params) {
/* 1792 */           jspInitParams.put(param, w.findInitParameter(param));
/*      */         }
/*      */       }
/*      */     } else {
/* 1796 */       jspInitParams = jspServlet.getParameterMap();
/*      */     }
/* 1798 */     for (ServletDef servletDef : webXml.getServlets().values()) {
/* 1799 */       if (servletDef.getJspFile() != null) {
/* 1800 */         convertJsp(servletDef, jspInitParams);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void convertJsp(ServletDef servletDef, Map<String, String> jspInitParams)
/*      */   {
/* 1807 */     servletDef.setServletClass("org.apache.jasper.servlet.JspServlet");
/* 1808 */     String jspFile = servletDef.getJspFile();
/* 1809 */     if ((jspFile != null) && (!jspFile.startsWith("/"))) {
/* 1810 */       if (this.context.isServlet22()) {
/* 1811 */         if (log.isDebugEnabled()) {
/* 1812 */           log.debug(sm.getString("contextConfig.jspFile.warning", new Object[] { jspFile }));
/*      */         }
/*      */         
/* 1815 */         jspFile = "/" + jspFile;
/*      */       }
/*      */       else {
/* 1818 */         throw new IllegalArgumentException(sm.getString("contextConfig.jspFile.error", new Object[] { jspFile }));
/*      */       }
/*      */     }
/* 1821 */     servletDef.getParameterMap().put("jspFile", jspFile);
/* 1822 */     servletDef.setJspFile(null);
/* 1823 */     for (Map.Entry<String, String> initParam : jspInitParams.entrySet()) {
/* 1824 */       servletDef.addInitParameter((String)initParam.getKey(), (String)initParam.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */   protected WebXml createWebXml() {
/* 1829 */     return new WebXml();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processServletContainerInitializers()
/*      */   {
/*      */     try
/*      */     {
/* 1839 */       WebappServiceLoader<ServletContainerInitializer> loader = new WebappServiceLoader(this.context);
/* 1840 */       detectedScis = loader.load(ServletContainerInitializer.class);
/*      */     } catch (IOException e) { List<ServletContainerInitializer> detectedScis;
/* 1842 */       log.error(sm.getString("contextConfig.servletContainerInitializerFail", new Object[] {this.context
/*      */       
/* 1844 */         .getName() }), e);
/*      */       
/* 1846 */       this.ok = false; return;
/*      */     }
/*      */     
/*      */     List<ServletContainerInitializer> detectedScis;
/* 1850 */     for (ServletContainerInitializer sci : detectedScis) {
/* 1851 */       this.initializerClassMap.put(sci, new HashSet());
/*      */       
/*      */       try
/*      */       {
/* 1855 */         ht = (HandlesTypes)sci.getClass().getAnnotation(HandlesTypes.class);
/*      */       } catch (Exception e) { HandlesTypes ht;
/* 1857 */         if (log.isDebugEnabled()) {
/* 1858 */           log.info(sm.getString("contextConfig.sci.debug", new Object[] {sci
/* 1859 */             .getClass().getName() }), e);
/*      */         }
/*      */         else
/* 1862 */           log.info(sm.getString("contextConfig.sci.info", new Object[] {sci
/* 1863 */             .getClass().getName() }));
/*      */       }
/* 1865 */       continue;
/*      */       HandlesTypes ht;
/* 1867 */       if (ht != null)
/*      */       {
/*      */ 
/* 1870 */         Class<?>[] types = ht.value();
/* 1871 */         if (types != null)
/*      */         {
/*      */ 
/*      */ 
/* 1875 */           for (Class<?> type : types) {
/* 1876 */             if (type.isAnnotation()) {
/* 1877 */               this.handlesTypesAnnotations = true;
/*      */             } else {
/* 1879 */               this.handlesTypesNonAnnotations = true;
/*      */             }
/*      */             
/* 1882 */             Set<ServletContainerInitializer> scis = (Set)this.typeInitializerMap.get(type);
/* 1883 */             if (scis == null) {
/* 1884 */               scis = new HashSet();
/* 1885 */               this.typeInitializerMap.put(type, scis);
/*      */             }
/* 1887 */             scis.add(sci);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processResourceJARs(Set<WebXml> fragments)
/*      */   {
/* 1902 */     for (WebXml fragment : fragments) {
/* 1903 */       URL url = fragment.getURL();
/*      */       try {
/* 1905 */         if (("jar".equals(url.getProtocol())) || (url.toString().endsWith(".jar"))) {
/* 1906 */           Jar jar = JarFactory.newInstance(url);Throwable localThrowable3 = null;
/* 1907 */           try { jar.nextEntry();
/* 1908 */             String entryName = jar.getEntryName();
/* 1909 */             while (entryName != null) {
/* 1910 */               if (entryName.startsWith("META-INF/resources/")) {
/* 1911 */                 this.context.getResources().createWebResourceSet(WebResourceRoot.ResourceSetType.RESOURCE_JAR, "/", url, "/META-INF/resources");
/*      */                 
/*      */ 
/* 1914 */                 break;
/*      */               }
/* 1916 */               jar.nextEntry();
/* 1917 */               entryName = jar.getEntryName();
/*      */             }
/*      */           }
/*      */           catch (Throwable localThrowable1)
/*      */           {
/* 1906 */             localThrowable3 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1919 */             if (jar != null) if (localThrowable3 != null) try { jar.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else jar.close();
/* 1920 */           } } else if ("file".equals(url.getProtocol())) {
/* 1921 */           File file = new File(url.toURI());
/* 1922 */           File resources = new File(file, "META-INF/resources/");
/* 1923 */           if (resources.isDirectory()) {
/* 1924 */             this.context.getResources().createWebResourceSet(WebResourceRoot.ResourceSetType.RESOURCE_JAR, "/", resources
/*      */             
/* 1926 */               .getAbsolutePath(), null, "/");
/*      */           }
/*      */         }
/*      */       } catch (IOException|URISyntaxException e) {
/* 1930 */         log.error(sm.getString("contextConfig.resourceJarFail", new Object[] { url, this.context
/* 1931 */           .getName() }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputSource getGlobalWebXmlSource()
/*      */   {
/* 1944 */     if ((this.defaultWebXml == null) && ((this.context instanceof StandardContext))) {
/* 1945 */       this.defaultWebXml = ((StandardContext)this.context).getDefaultWebXml();
/*      */     }
/*      */     
/* 1948 */     if (this.defaultWebXml == null) {
/* 1949 */       getDefaultWebXml();
/*      */     }
/*      */     
/*      */ 
/* 1953 */     if ("org/apache/catalina/startup/NO_DEFAULT_XML".equals(this.defaultWebXml)) {
/* 1954 */       return null;
/*      */     }
/* 1956 */     return getWebXmlSource(this.defaultWebXml, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputSource getHostWebXmlSource()
/*      */   {
/* 1966 */     File hostConfigBase = getHostConfigBase();
/* 1967 */     if (hostConfigBase == null) {
/* 1968 */       return null;
/*      */     }
/*      */     
/* 1971 */     return getWebXmlSource(hostConfigBase.getPath(), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputSource getContextWebXmlSource()
/*      */   {
/* 1980 */     InputStream stream = null;
/* 1981 */     source = null;
/* 1982 */     URL url = null;
/*      */     
/* 1984 */     String altDDName = null;
/*      */     
/*      */ 
/* 1987 */     ServletContext servletContext = this.context.getServletContext();
/*      */     try {
/* 1989 */       if (servletContext != null) {
/* 1990 */         altDDName = (String)servletContext.getAttribute("org.apache.catalina.deploy.alt_dd");
/* 1991 */         if (altDDName != null) {
/*      */           try {
/* 1993 */             stream = new FileInputStream(altDDName);
/* 1994 */             url = new File(altDDName).toURI().toURL();
/*      */           } catch (FileNotFoundException e) {
/* 1996 */             log.error(sm.getString("contextConfig.altDDNotFound", new Object[] { altDDName }));
/*      */           }
/*      */           catch (MalformedURLException e) {
/* 1999 */             log.error(sm.getString("contextConfig.applicationUrl"));
/*      */           }
/*      */         }
/*      */         else {
/* 2003 */           stream = servletContext.getResourceAsStream("/WEB-INF/web.xml");
/*      */           try {
/* 2005 */             url = servletContext.getResource("/WEB-INF/web.xml");
/*      */           }
/*      */           catch (MalformedURLException e) {
/* 2008 */             log.error(sm.getString("contextConfig.applicationUrl"));
/*      */           }
/*      */         }
/*      */       }
/* 2012 */       if ((stream == null) || (url == null)) {
/* 2013 */         if (log.isDebugEnabled()) {
/* 2014 */           log.debug(sm.getString("contextConfig.applicationMissing") + " " + this.context);
/*      */         }
/*      */       } else {
/* 2017 */         source = new InputSource(url.toExternalForm());
/* 2018 */         source.setByteStream(stream);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2030 */       return source;
/*      */     }
/*      */     finally
/*      */     {
/* 2021 */       if ((source == null) && (stream != null)) {
/*      */         try {
/* 2023 */           stream.close();
/*      */         }
/*      */         catch (IOException localIOException1) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getConfigBasePath()
/*      */   {
/* 2034 */     String path = null;
/* 2035 */     if ((this.context.getParent() instanceof Host)) {
/* 2036 */       Host host = (Host)this.context.getParent();
/* 2037 */       if (host.getXmlBase() != null) {
/* 2038 */         path = host.getXmlBase();
/*      */       } else {
/* 2040 */         StringBuilder xmlDir = new StringBuilder("conf");
/* 2041 */         Container parent = host.getParent();
/* 2042 */         if ((parent instanceof Engine)) {
/* 2043 */           xmlDir.append('/');
/* 2044 */           xmlDir.append(parent.getName());
/*      */         }
/* 2046 */         xmlDir.append('/');
/* 2047 */         xmlDir.append(host.getName());
/* 2048 */         path = xmlDir.toString();
/*      */       }
/*      */     }
/* 2051 */     return path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputSource getWebXmlSource(String filename, boolean global)
/*      */   {
/* 2063 */     ConfigurationSource.Resource webXmlResource = null;
/*      */     try {
/* 2065 */       if (global) {
/* 2066 */         if ("conf/web.xml".equals(filename)) {
/* 2067 */           webXmlResource = ConfigFileLoader.getSource().getSharedWebXml();
/*      */         } else {
/* 2069 */           webXmlResource = ConfigFileLoader.getSource().getResource(filename);
/*      */         }
/*      */       } else {
/* 2072 */         String hostWebXml = Container.getConfigPath(this.context, "web.xml.default");
/* 2073 */         webXmlResource = ConfigFileLoader.getSource().getResource(hostWebXml);
/*      */       }
/*      */     }
/*      */     catch (IOException e) {
/* 2077 */       return null;
/*      */     }
/*      */     
/* 2080 */     InputStream stream = null;
/* 2081 */     source = null;
/*      */     try
/*      */     {
/* 2084 */       stream = webXmlResource.getInputStream();
/* 2085 */       source = new InputSource(webXmlResource.getURI().toString());
/* 2086 */       if (stream != null) {
/* 2087 */         source.setByteStream(stream);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2101 */       return source;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2090 */       log.error(sm.getString("contextConfig.defaultError", new Object[] { filename, webXmlResource.getURI() }), e);
/*      */     } finally {
/* 2092 */       if ((source == null) && (stream != null)) {
/*      */         try {
/* 2094 */           stream.close();
/*      */         }
/*      */         catch (IOException localIOException3) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Map<String, WebXml> processJarsForWebFragments(WebXml application, WebXmlParser webXmlParser)
/*      */   {
/* 2119 */     JarScanner jarScanner = this.context.getJarScanner();
/* 2120 */     boolean delegate = false;
/* 2121 */     if ((this.context instanceof StandardContext)) {
/* 2122 */       delegate = ((StandardContext)this.context).getDelegate();
/*      */     }
/* 2124 */     boolean parseRequired = true;
/* 2125 */     Set<String> absoluteOrder = application.getAbsoluteOrdering();
/* 2126 */     if ((absoluteOrder != null) && (absoluteOrder.isEmpty()) && 
/* 2127 */       (!this.context.getXmlValidation()))
/*      */     {
/*      */ 
/* 2130 */       parseRequired = false;
/*      */     }
/*      */     
/* 2133 */     FragmentJarScannerCallback callback = new FragmentJarScannerCallback(webXmlParser, delegate, parseRequired);
/*      */     
/*      */ 
/* 2136 */     jarScanner.scan(JarScanType.PLUGGABILITY, this.context
/* 2137 */       .getServletContext(), callback);
/*      */     
/* 2139 */     if (!callback.isOk()) {
/* 2140 */       this.ok = false;
/*      */     }
/* 2142 */     return callback.getFragments();
/*      */   }
/*      */   
/*      */ 
/*      */   protected void processAnnotations(Set<WebXml> fragments, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2148 */     if (this.context.getParallelAnnotationScanning()) {
/* 2149 */       processAnnotationsInParallel(fragments, handlesTypesOnly, javaClassCache);
/*      */     } else {
/* 2151 */       for (WebXml fragment : fragments) {
/* 2152 */         scanWebXmlFragment(handlesTypesOnly, fragment, javaClassCache);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void scanWebXmlFragment(boolean handlesTypesOnly, WebXml fragment, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2166 */     boolean htOnly = (handlesTypesOnly) || (!fragment.getWebappJar()) || (fragment.isMetadataComplete());
/*      */     
/* 2168 */     WebXml annotations = new WebXml();
/*      */     
/* 2170 */     annotations.setDistributable(true);
/* 2171 */     URL url = fragment.getURL();
/* 2172 */     processAnnotationsUrl(url, annotations, htOnly, javaClassCache);
/* 2173 */     Set<WebXml> set = new HashSet();
/* 2174 */     set.add(annotations);
/*      */     
/* 2176 */     fragment.merge(set);
/*      */   }
/*      */   
/*      */   public static abstract interface ContextXml {
/*      */     public abstract void load(Context paramContext);
/*      */   }
/*      */   
/*      */   private class AnnotationScanTask implements Runnable {
/*      */     private final WebXml fragment;
/*      */     private final boolean handlesTypesOnly;
/*      */     private Map<String, ContextConfig.JavaClassCacheEntry> javaClassCache;
/*      */     
/*      */     private AnnotationScanTask(boolean fragment, Map<String, ContextConfig.JavaClassCacheEntry> handlesTypesOnly) {
/* 2189 */       this.fragment = fragment;
/* 2190 */       this.handlesTypesOnly = handlesTypesOnly;
/* 2191 */       this.javaClassCache = javaClassCache;
/*      */     }
/*      */     
/*      */     public void run()
/*      */     {
/* 2196 */       ContextConfig.this.scanWebXmlFragment(this.handlesTypesOnly, this.fragment, this.javaClassCache);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processAnnotationsInParallel(Set<WebXml> fragments, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2211 */     Server s = getServer();
/* 2212 */     ExecutorService pool = null;
/* 2213 */     pool = s.getUtilityExecutor();
/* 2214 */     List<Future<?>> futures = new ArrayList(fragments.size());
/* 2215 */     for (WebXml fragment : fragments) {
/* 2216 */       Runnable task = new AnnotationScanTask(fragment, handlesTypesOnly, javaClassCache, null);
/* 2217 */       futures.add(pool.submit(task));
/*      */     }
/*      */     try {
/* 2220 */       for (??? = futures.iterator(); ???.hasNext();) { Future<?> future = (Future)???.next();
/* 2221 */         future.get();
/*      */       }
/*      */     } catch (Exception e) {
/* 2224 */       throw new RuntimeException(sm.getString("contextConfig.processAnnotationsInParallelFailure"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void processAnnotationsWebResource(WebResource webResource, WebXml fragment, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2232 */     if (webResource.isDirectory())
/*      */     {
/* 2234 */       WebResource[] webResources = webResource.getWebResourceRoot().listResources(webResource
/* 2235 */         .getWebappPath());
/* 2236 */       if (webResources.length > 0) {
/* 2237 */         if (log.isDebugEnabled()) {
/* 2238 */           log.debug(sm.getString("contextConfig.processAnnotationsWebDir.debug", new Object[] {webResource
/*      */           
/* 2240 */             .getURL() }));
/*      */         }
/* 2242 */         for (WebResource r : webResources) {
/* 2243 */           processAnnotationsWebResource(r, fragment, handlesTypesOnly, javaClassCache);
/*      */         }
/*      */       }
/* 2246 */     } else if ((webResource.isFile()) && 
/* 2247 */       (webResource.getName().endsWith(".class"))) {
/* 2248 */       try { InputStream is = webResource.getInputStream();??? = null;
/* 2249 */         try { processAnnotationsStream(is, fragment, handlesTypesOnly, javaClassCache);
/*      */         }
/*      */         catch (Throwable localThrowable4)
/*      */         {
/* 2248 */           ??? = localThrowable4;throw localThrowable4;
/*      */         } finally {
/* 2250 */           if (is != null) if (??? != null) try { is.close(); } catch (Throwable localThrowable2) { ((Throwable)???).addSuppressed(localThrowable2); } else is.close();
/* 2251 */         } } catch (IOException|ClassFormatException e) { log.error(sm.getString("contextConfig.inputStreamWebResource", new Object[] {webResource
/* 2252 */           .getWebappPath() }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void processAnnotationsUrl(URL url, WebXml fragment, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2260 */     if (url == null)
/*      */     {
/* 2262 */       return; }
/* 2263 */     if (("jar".equals(url.getProtocol())) || (url.toString().endsWith(".jar"))) {
/* 2264 */       processAnnotationsJar(url, fragment, handlesTypesOnly, javaClassCache);
/* 2265 */     } else if ("file".equals(url.getProtocol())) {
/*      */       try {
/* 2267 */         processAnnotationsFile(new File(url
/* 2268 */           .toURI()), fragment, handlesTypesOnly, javaClassCache);
/*      */       } catch (URISyntaxException e) {
/* 2270 */         log.error(sm.getString("contextConfig.fileUrl", new Object[] { url }), e);
/*      */       }
/*      */     } else {
/* 2273 */       log.error(sm.getString("contextConfig.unknownUrlProtocol", new Object[] {url
/* 2274 */         .getProtocol(), url }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void processAnnotationsJar(URL url, WebXml fragment, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/*      */     try
/*      */     {
/* 2283 */       Jar jar = JarFactory.newInstance(url);Throwable localThrowable6 = null;
/* 2284 */       try { if (log.isDebugEnabled()) {
/* 2285 */           log.debug(sm.getString("contextConfig.processAnnotationsJar.debug", new Object[] { url }));
/*      */         }
/*      */         
/*      */ 
/* 2289 */         jar.nextEntry();
/* 2290 */         String entryName = jar.getEntryName();
/* 2291 */         while (entryName != null) {
/* 2292 */           if (entryName.endsWith(".class")) {
/* 2293 */             try { InputStream is = jar.getEntryInputStream();Throwable localThrowable7 = null;
/* 2294 */               try { processAnnotationsStream(is, fragment, handlesTypesOnly, javaClassCache);
/*      */               }
/*      */               catch (Throwable localThrowable1)
/*      */               {
/* 2293 */                 localThrowable7 = localThrowable1;throw localThrowable1;
/*      */               } finally {
/* 2295 */                 if (is != null) if (localThrowable7 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable7.addSuppressed(localThrowable2); } else is.close();
/* 2296 */               } } catch (IOException|ClassFormatException e) { log.error(sm.getString("contextConfig.inputStreamJar", new Object[] { entryName, url }), e);
/*      */             }
/*      */           }
/*      */           
/* 2300 */           jar.nextEntry();
/* 2301 */           entryName = jar.getEntryName();
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable4)
/*      */       {
/* 2283 */         localThrowable6 = localThrowable4;throw localThrowable4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2303 */         if (jar != null) if (localThrowable6 != null) try { jar.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else jar.close();
/* 2304 */       } } catch (IOException e) { log.error(sm.getString("contextConfig.jarFile", new Object[] { url }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void processAnnotationsFile(File file, WebXml fragment, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2312 */     if (file.isDirectory())
/*      */     {
/* 2314 */       String[] dirs = file.list();
/* 2315 */       if (dirs != null) {
/* 2316 */         if (log.isDebugEnabled()) {
/* 2317 */           log.debug(sm.getString("contextConfig.processAnnotationsDir.debug", new Object[] { file }));
/*      */         }
/*      */         
/* 2320 */         for (String dir : dirs) {
/* 2321 */           processAnnotationsFile(new File(file, dir), fragment, handlesTypesOnly, javaClassCache);
/*      */         }
/*      */       }
/*      */     }
/* 2325 */     else if ((file.getName().endsWith(".class")) && (file.canRead())) {
/* 2326 */       try { FileInputStream fis = new FileInputStream(file);??? = null;
/* 2327 */         try { processAnnotationsStream(fis, fragment, handlesTypesOnly, javaClassCache);
/*      */         }
/*      */         catch (Throwable localThrowable4)
/*      */         {
/* 2326 */           ??? = localThrowable4;throw localThrowable4;
/*      */         } finally {
/* 2328 */           if (fis != null) if (??? != null) try { fis.close(); } catch (Throwable localThrowable2) { ((Throwable)???).addSuppressed(localThrowable2); } else fis.close();
/* 2329 */         } } catch (IOException|ClassFormatException e) { log.error(sm.getString("contextConfig.inputStreamFile", new Object[] {file
/* 2330 */           .getAbsolutePath() }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void processAnnotationsStream(InputStream is, WebXml fragment, boolean handlesTypesOnly, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */     throws ClassFormatException, IOException
/*      */   {
/* 2340 */     ClassParser parser = new ClassParser(is);
/* 2341 */     JavaClass clazz = parser.parse();
/* 2342 */     checkHandlesTypes(clazz, javaClassCache);
/*      */     
/* 2344 */     if (handlesTypesOnly) {
/* 2345 */       return;
/*      */     }
/*      */     
/* 2348 */     processClass(fragment, clazz);
/*      */   }
/*      */   
/*      */   protected void processClass(WebXml fragment, JavaClass clazz)
/*      */   {
/* 2353 */     AnnotationEntry[] annotationsEntries = clazz.getAnnotationEntries();
/* 2354 */     if (annotationsEntries != null) {
/* 2355 */       String className = clazz.getClassName();
/* 2356 */       for (AnnotationEntry ae : annotationsEntries) {
/* 2357 */         String type = ae.getAnnotationType();
/* 2358 */         if ("Ljavax/servlet/annotation/WebServlet;".equals(type)) {
/* 2359 */           processAnnotationWebServlet(className, ae, fragment);
/* 2360 */         } else if ("Ljavax/servlet/annotation/WebFilter;".equals(type)) {
/* 2361 */           processAnnotationWebFilter(className, ae, fragment);
/* 2362 */         } else if ("Ljavax/servlet/annotation/WebListener;".equals(type)) {
/* 2363 */           fragment.addListener(className);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkHandlesTypes(JavaClass javaClass, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2383 */     if (this.typeInitializerMap.size() == 0) {
/* 2384 */       return;
/*      */     }
/*      */     
/* 2387 */     if ((javaClass.getAccessFlags() & 0x2000) != 0)
/*      */     {
/*      */ 
/* 2390 */       return;
/*      */     }
/*      */     
/* 2393 */     String className = javaClass.getClassName();
/*      */     
/* 2395 */     Class<?> clazz = null;
/* 2396 */     if (this.handlesTypesNonAnnotations)
/*      */     {
/* 2398 */       populateJavaClassCache(className, javaClass, javaClassCache);
/* 2399 */       JavaClassCacheEntry entry = (JavaClassCacheEntry)javaClassCache.get(className);
/* 2400 */       if (entry.getSciSet() == null) {
/*      */         try {
/* 2402 */           populateSCIsForCacheEntry(entry, javaClassCache);
/*      */         } catch (StackOverflowError soe) {
/* 2404 */           throw new IllegalStateException(sm.getString("contextConfig.annotationsStackOverflow", new Object[] {this.context
/*      */           
/* 2406 */             .getName(), 
/* 2407 */             classHierarchyToString(className, entry, javaClassCache) }));
/*      */         }
/*      */       }
/* 2410 */       if (!entry.getSciSet().isEmpty())
/*      */       {
/* 2412 */         clazz = Introspection.loadClass(this.context, className);
/* 2413 */         if (clazz == null)
/*      */         {
/* 2415 */           return;
/*      */         }
/*      */         
/* 2418 */         for (ServletContainerInitializer sci : entry.getSciSet()) {
/* 2419 */           Set<Class<?>> classes = (Set)this.initializerClassMap.get(sci);
/* 2420 */           if (classes == null) {
/* 2421 */             classes = new HashSet();
/* 2422 */             this.initializerClassMap.put(sci, classes);
/*      */           }
/* 2424 */           classes.add(clazz);
/*      */         }
/*      */       }
/*      */     }
/*      */     AnnotationEntry[] annotationEntries;
/* 2429 */     if (this.handlesTypesAnnotations) {
/* 2430 */       annotationEntries = javaClass.getAllAnnotationEntries();
/* 2431 */       if (annotationEntries != null)
/*      */       {
/* 2433 */         for (Map.Entry<Class<?>, Set<ServletContainerInitializer>> entry : this.typeInitializerMap.entrySet()) {
/* 2434 */           if (((Class)entry.getKey()).isAnnotation()) {
/* 2435 */             String entryClassName = ((Class)entry.getKey()).getName();
/* 2436 */             for (AnnotationEntry annotationEntry : annotationEntries) {
/* 2437 */               if (entryClassName.equals(
/* 2438 */                 getClassName(annotationEntry.getAnnotationType()))) {
/* 2439 */                 if (clazz == null) {
/* 2440 */                   clazz = Introspection.loadClass(this.context, className);
/*      */                   
/* 2442 */                   if (clazz == null)
/*      */                   {
/*      */ 
/* 2445 */                     return;
/*      */                   }
/*      */                 }
/* 2448 */                 for (ServletContainerInitializer sci : (Set)entry.getValue()) {
/* 2449 */                   ((Set)this.initializerClassMap.get(sci)).add(clazz);
/*      */                 }
/* 2451 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private String classHierarchyToString(String className, JavaClassCacheEntry entry, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2463 */     JavaClassCacheEntry start = entry;
/* 2464 */     StringBuilder msg = new StringBuilder(className);
/* 2465 */     msg.append("->");
/*      */     
/* 2467 */     String parentName = entry.getSuperclassName();
/* 2468 */     JavaClassCacheEntry parent = (JavaClassCacheEntry)javaClassCache.get(parentName);
/* 2469 */     int count = 0;
/*      */     
/* 2471 */     while ((count < 100) && (parent != null) && (parent != start)) {
/* 2472 */       msg.append(parentName);
/* 2473 */       msg.append("->");
/*      */       
/* 2475 */       count++;
/* 2476 */       parentName = parent.getSuperclassName();
/* 2477 */       parent = (JavaClassCacheEntry)javaClassCache.get(parentName);
/*      */     }
/*      */     
/* 2480 */     msg.append(parentName);
/*      */     
/* 2482 */     return msg.toString();
/*      */   }
/*      */   
/*      */   private void populateJavaClassCache(String className, JavaClass javaClass, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2487 */     if (javaClassCache.containsKey(className)) {
/* 2488 */       return;
/*      */     }
/*      */     
/*      */ 
/* 2492 */     javaClassCache.put(className, new JavaClassCacheEntry(javaClass));
/*      */     
/* 2494 */     populateJavaClassCache(javaClass.getSuperclassName(), javaClassCache);
/*      */     
/* 2496 */     for (String interfaceName : javaClass.getInterfaceNames()) {
/* 2497 */       populateJavaClassCache(interfaceName, javaClassCache);
/*      */     }
/*      */   }
/*      */   
/*      */   private void populateJavaClassCache(String className, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2503 */     if (!javaClassCache.containsKey(className)) {
/* 2504 */       String name = className.replace('.', '/') + ".class";
/* 2505 */       try { InputStream is = this.context.getLoader().getClassLoader().getResourceAsStream(name);Throwable localThrowable4 = null;
/* 2506 */         try { if (is == null) {
/* 2507 */             return;
/*      */           }
/* 2509 */           ClassParser parser = new ClassParser(is);
/* 2510 */           JavaClass clazz = parser.parse();
/* 2511 */           populateJavaClassCache(clazz.getClassName(), clazz, javaClassCache);
/*      */         }
/*      */         catch (Throwable localThrowable2)
/*      */         {
/* 2505 */           localThrowable4 = localThrowable2;throw localThrowable2;
/*      */ 
/*      */ 
/*      */         }
/*      */         finally
/*      */         {
/*      */ 
/* 2512 */           if (is != null) if (localThrowable4 != null) try { is.close(); } catch (Throwable localThrowable3) { localThrowable4.addSuppressed(localThrowable3); } else is.close();
/* 2513 */         } } catch (ClassFormatException|IOException e) { log.debug(sm.getString("contextConfig.invalidSciHandlesTypes", new Object[] { className }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void populateSCIsForCacheEntry(JavaClassCacheEntry cacheEntry, Map<String, JavaClassCacheEntry> javaClassCache)
/*      */   {
/* 2521 */     Set<ServletContainerInitializer> result = new HashSet();
/*      */     
/*      */ 
/* 2524 */     String superClassName = cacheEntry.getSuperclassName();
/*      */     
/* 2526 */     JavaClassCacheEntry superClassCacheEntry = (JavaClassCacheEntry)javaClassCache.get(superClassName);
/*      */     
/*      */ 
/* 2529 */     if (cacheEntry.equals(superClassCacheEntry)) {
/* 2530 */       cacheEntry.setSciSet(EMPTY_SCI_SET);
/* 2531 */       return;
/*      */     }
/*      */     
/*      */ 
/* 2535 */     if (superClassCacheEntry != null) {
/* 2536 */       if (superClassCacheEntry.getSciSet() == null) {
/* 2537 */         populateSCIsForCacheEntry(superClassCacheEntry, javaClassCache);
/*      */       }
/* 2539 */       result.addAll(superClassCacheEntry.getSciSet());
/*      */     }
/* 2541 */     result.addAll(getSCIsForClass(superClassName));
/*      */     
/*      */ 
/* 2544 */     for (String interfaceName : cacheEntry.getInterfaceNames())
/*      */     {
/* 2546 */       JavaClassCacheEntry interfaceEntry = (JavaClassCacheEntry)javaClassCache.get(interfaceName);
/*      */       
/*      */ 
/*      */ 
/* 2550 */       if (interfaceEntry != null) {
/* 2551 */         if (interfaceEntry.getSciSet() == null) {
/* 2552 */           populateSCIsForCacheEntry(interfaceEntry, javaClassCache);
/*      */         }
/* 2554 */         result.addAll(interfaceEntry.getSciSet());
/*      */       }
/* 2556 */       result.addAll(getSCIsForClass(interfaceName));
/*      */     }
/*      */     
/* 2559 */     cacheEntry.setSciSet(result.isEmpty() ? EMPTY_SCI_SET : result);
/*      */   }
/*      */   
/*      */   private Set<ServletContainerInitializer> getSCIsForClass(String className)
/*      */   {
/* 2564 */     for (Map.Entry<Class<?>, Set<ServletContainerInitializer>> entry : this.typeInitializerMap.entrySet()) {
/* 2565 */       Class<?> clazz = (Class)entry.getKey();
/* 2566 */       if ((!clazz.isAnnotation()) && 
/* 2567 */         (clazz.getName().equals(className))) {
/* 2568 */         return (Set)entry.getValue();
/*      */       }
/*      */     }
/*      */     
/* 2572 */     return EMPTY_SCI_SET;
/*      */   }
/*      */   
/*      */   private static final String getClassName(String internalForm) {
/* 2576 */     if (!internalForm.startsWith("L")) {
/* 2577 */       return internalForm;
/*      */     }
/*      */     
/*      */ 
/* 2581 */     return 
/* 2582 */       internalForm.substring(1, internalForm.length() - 1).replace('/', '.');
/*      */   }
/*      */   
/*      */   protected void processAnnotationWebServlet(String className, AnnotationEntry ae, WebXml fragment)
/*      */   {
/* 2587 */     String servletName = null;
/*      */     
/* 2589 */     List<ElementValuePair> evps = ae.getElementValuePairs();
/* 2590 */     for (ElementValuePair evp : evps) {
/* 2591 */       String name = evp.getNameString();
/* 2592 */       if ("name".equals(name)) {
/* 2593 */         servletName = evp.getValue().stringifyValue();
/* 2594 */         break;
/*      */       }
/*      */     }
/* 2597 */     if (servletName == null)
/*      */     {
/* 2599 */       servletName = className;
/*      */     }
/* 2601 */     ServletDef servletDef = (ServletDef)fragment.getServlets().get(servletName);
/*      */     boolean isWebXMLservletDef;
/*      */     boolean isWebXMLservletDef;
/* 2604 */     if (servletDef == null) {
/* 2605 */       servletDef = new ServletDef();
/* 2606 */       servletDef.setServletName(servletName);
/* 2607 */       servletDef.setServletClass(className);
/* 2608 */       isWebXMLservletDef = false;
/*      */     } else {
/* 2610 */       isWebXMLservletDef = true;
/*      */     }
/*      */     
/* 2613 */     boolean urlPatternsSet = false;
/* 2614 */     String[] urlPatterns = null;
/*      */     
/*      */ 
/* 2617 */     for (Object localObject1 = evps.iterator(); ((Iterator)localObject1).hasNext();) { evp = (ElementValuePair)((Iterator)localObject1).next();
/* 2618 */       name = evp.getNameString();
/* 2619 */       if (("value".equals(name)) || ("urlPatterns".equals(name))) {
/* 2620 */         if (urlPatternsSet) {
/* 2621 */           throw new IllegalArgumentException(sm.getString("contextConfig.urlPatternValue", new Object[] { "WebServlet", className }));
/*      */         }
/*      */         
/* 2624 */         urlPatternsSet = true;
/* 2625 */         urlPatterns = processAnnotationsStringArray(evp.getValue());
/* 2626 */       } else if ("description".equals(name)) {
/* 2627 */         if (servletDef.getDescription() == null) {
/* 2628 */           servletDef.setDescription(evp.getValue().stringifyValue());
/*      */         }
/* 2630 */       } else if ("displayName".equals(name)) {
/* 2631 */         if (servletDef.getDisplayName() == null) {
/* 2632 */           servletDef.setDisplayName(evp.getValue().stringifyValue());
/*      */         }
/* 2634 */       } else if ("largeIcon".equals(name)) {
/* 2635 */         if (servletDef.getLargeIcon() == null) {
/* 2636 */           servletDef.setLargeIcon(evp.getValue().stringifyValue());
/*      */         }
/* 2638 */       } else if ("smallIcon".equals(name)) {
/* 2639 */         if (servletDef.getSmallIcon() == null) {
/* 2640 */           servletDef.setSmallIcon(evp.getValue().stringifyValue());
/*      */         }
/* 2642 */       } else if ("asyncSupported".equals(name)) {
/* 2643 */         if (servletDef.getAsyncSupported() == null) {
/* 2644 */           servletDef.setAsyncSupported(evp.getValue()
/* 2645 */             .stringifyValue());
/*      */         }
/* 2647 */       } else if ("loadOnStartup".equals(name)) {
/* 2648 */         if (servletDef.getLoadOnStartup() == null)
/*      */         {
/* 2650 */           servletDef.setLoadOnStartup(evp.getValue().stringifyValue());
/*      */         }
/* 2652 */       } else if ("initParams".equals(name)) {
/* 2653 */         Map<String, String> initParams = processAnnotationWebInitParams(evp
/* 2654 */           .getValue());
/* 2655 */         if (isWebXMLservletDef)
/*      */         {
/* 2657 */           webXMLInitParams = servletDef.getParameterMap();
/* 2658 */           for (Map.Entry<String, String> entry : initParams
/* 2659 */             .entrySet()) {
/* 2660 */             if (webXMLInitParams.get(entry.getKey()) == null) {
/* 2661 */               servletDef.addInitParameter((String)entry.getKey(), 
/* 2662 */                 (String)entry.getValue());
/*      */             }
/*      */           }
/*      */         } else {
/* 2666 */           for (Object entry : initParams
/* 2667 */             .entrySet())
/* 2668 */             servletDef.addInitParameter((String)((Map.Entry)entry).getKey(), 
/* 2669 */               (String)((Map.Entry)entry).getValue());
/*      */         } } }
/*      */     ElementValuePair evp;
/*      */     String name;
/*      */     Map<String, String> webXMLInitParams;
/* 2674 */     if ((!isWebXMLservletDef) && (urlPatterns != null)) {
/* 2675 */       fragment.addServlet(servletDef);
/*      */     }
/* 2677 */     if ((urlPatterns != null) && 
/* 2678 */       (!fragment.getServletMappings().containsValue(servletName))) {
/* 2679 */       localObject1 = urlPatterns;evp = localObject1.length; for (name = 0; name < evp; name++) { String urlPattern = localObject1[name];
/* 2680 */         fragment.addServletMapping(urlPattern, servletName);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processAnnotationWebFilter(String className, AnnotationEntry ae, WebXml fragment)
/*      */   {
/* 2697 */     String filterName = null;
/*      */     
/* 2699 */     List<ElementValuePair> evps = ae.getElementValuePairs();
/* 2700 */     for (ElementValuePair evp : evps) {
/* 2701 */       String name = evp.getNameString();
/* 2702 */       if ("filterName".equals(name)) {
/* 2703 */         filterName = evp.getValue().stringifyValue();
/* 2704 */         break;
/*      */       }
/*      */     }
/* 2707 */     if (filterName == null)
/*      */     {
/* 2709 */       filterName = className;
/*      */     }
/* 2711 */     FilterDef filterDef = (FilterDef)fragment.getFilters().get(filterName);
/* 2712 */     FilterMap filterMap = new FilterMap();
/*      */     boolean isWebXMLfilterDef;
/*      */     boolean isWebXMLfilterDef;
/* 2715 */     if (filterDef == null) {
/* 2716 */       filterDef = new FilterDef();
/* 2717 */       filterDef.setFilterName(filterName);
/* 2718 */       filterDef.setFilterClass(className);
/* 2719 */       isWebXMLfilterDef = false;
/*      */     } else {
/* 2721 */       isWebXMLfilterDef = true;
/*      */     }
/*      */     
/* 2724 */     boolean urlPatternsSet = false;
/* 2725 */     boolean servletNamesSet = false;
/* 2726 */     boolean dispatchTypesSet = false;
/* 2727 */     String[] urlPatterns = null;
/*      */     
/* 2729 */     for (ElementValuePair evp : evps) {
/* 2730 */       name = evp.getNameString();
/* 2731 */       String str1; String urlPattern; if (("value".equals(name)) || ("urlPatterns".equals(name))) {
/* 2732 */         if (urlPatternsSet) {
/* 2733 */           throw new IllegalArgumentException(sm.getString("contextConfig.urlPatternValue", new Object[] { "WebFilter", className }));
/*      */         }
/*      */         
/* 2736 */         urlPatterns = processAnnotationsStringArray(evp.getValue());
/* 2737 */         urlPatternsSet = urlPatterns.length > 0;
/* 2738 */         String[] arrayOfString1 = urlPatterns;int i = arrayOfString1.length; for (str1 = 0; str1 < i; str1++) { urlPattern = arrayOfString1[str1];
/*      */           
/* 2740 */           filterMap.addURLPattern(urlPattern);
/*      */         } } else { String[] arrayOfString2;
/* 2742 */         if ("servletNames".equals(name)) {
/* 2743 */           String[] servletNames = processAnnotationsStringArray(evp
/* 2744 */             .getValue());
/* 2745 */           servletNamesSet = servletNames.length > 0;
/* 2746 */           arrayOfString2 = servletNames;str1 = arrayOfString2.length; for (urlPattern = 0; urlPattern < str1; urlPattern++) { String servletName = arrayOfString2[urlPattern];
/* 2747 */             filterMap.addServletName(servletName);
/*      */           } } else { Object localObject2;
/* 2749 */           if ("dispatcherTypes".equals(name)) {
/* 2750 */             String[] dispatcherTypes = processAnnotationsStringArray(evp
/* 2751 */               .getValue());
/* 2752 */             dispatchTypesSet = dispatcherTypes.length > 0;
/* 2753 */             arrayOfString2 = dispatcherTypes;localObject2 = arrayOfString2.length; for (urlPattern = 0; urlPattern < localObject2; urlPattern++) { String dispatcherType = arrayOfString2[urlPattern];
/* 2754 */               filterMap.setDispatcher(dispatcherType);
/*      */             }
/* 2756 */           } else if ("description".equals(name)) {
/* 2757 */             if (filterDef.getDescription() == null) {
/* 2758 */               filterDef.setDescription(evp.getValue().stringifyValue());
/*      */             }
/* 2760 */           } else if ("displayName".equals(name)) {
/* 2761 */             if (filterDef.getDisplayName() == null) {
/* 2762 */               filterDef.setDisplayName(evp.getValue().stringifyValue());
/*      */             }
/* 2764 */           } else if ("largeIcon".equals(name)) {
/* 2765 */             if (filterDef.getLargeIcon() == null) {
/* 2766 */               filterDef.setLargeIcon(evp.getValue().stringifyValue());
/*      */             }
/* 2768 */           } else if ("smallIcon".equals(name)) {
/* 2769 */             if (filterDef.getSmallIcon() == null) {
/* 2770 */               filterDef.setSmallIcon(evp.getValue().stringifyValue());
/*      */             }
/* 2772 */           } else if ("asyncSupported".equals(name)) {
/* 2773 */             if (filterDef.getAsyncSupported() == null)
/*      */             {
/* 2775 */               filterDef.setAsyncSupported(evp.getValue().stringifyValue());
/*      */             }
/* 2777 */           } else if ("initParams".equals(name)) {
/* 2778 */             Object initParams = processAnnotationWebInitParams(evp
/* 2779 */               .getValue());
/* 2780 */             if (isWebXMLfilterDef)
/*      */             {
/* 2782 */               webXMLInitParams = filterDef.getParameterMap();
/* 2783 */               for (localObject2 = ((Map)initParams)
/* 2784 */                     .entrySet().iterator(); ((Iterator)localObject2).hasNext();) { Map.Entry<String, String> entry = (Map.Entry)((Iterator)localObject2).next();
/*      */                 
/* 2785 */                 if (((Map)webXMLInitParams).get(entry.getKey()) == null) {
/* 2786 */                   filterDef.addInitParameter((String)entry.getKey(), 
/* 2787 */                     (String)entry.getValue());
/*      */                 }
/*      */               }
/*      */             } else {
/* 2791 */               for (webXMLInitParams = ((Map)initParams)
/* 2792 */                     .entrySet().iterator(); ((Iterator)webXMLInitParams).hasNext();) { entry = (Map.Entry)((Iterator)webXMLInitParams).next();
/*      */                 
/* 2793 */                 filterDef.addInitParameter((String)((Map.Entry)entry).getKey(), 
/* 2794 */                   (String)((Map.Entry)entry).getValue());
/*      */               }
/*      */             } } } } }
/*      */     String name;
/*      */     Object webXMLInitParams;
/*      */     Object entry;
/* 2800 */     if (!isWebXMLfilterDef) {
/* 2801 */       fragment.addFilter(filterDef);
/* 2802 */       if ((urlPatternsSet) || (servletNamesSet)) {
/* 2803 */         filterMap.setFilterName(filterName);
/* 2804 */         fragment.addFilterMapping(filterMap);
/*      */       }
/*      */     }
/* 2807 */     if ((urlPatternsSet) || (dispatchTypesSet)) {
/* 2808 */       Object fmap = fragment.getFilterMappings();
/* 2809 */       FilterMap descMap = null;
/* 2810 */       for (name = ((Set)fmap).iterator(); name.hasNext();) { map = (FilterMap)name.next();
/* 2811 */         if (filterName.equals(((FilterMap)map).getFilterName())) {
/* 2812 */           descMap = (FilterMap)map;
/* 2813 */           break;
/*      */         } }
/*      */       Object map;
/* 2816 */       if (descMap != null) {
/* 2817 */         String[] urlsPatterns = descMap.getURLPatterns();
/* 2818 */         Object localObject1; String urlPattern; if ((urlPatternsSet) && ((urlsPatterns == null) || (urlsPatterns.length == 0)))
/*      */         {
/* 2820 */           map = filterMap.getURLPatterns();localObject1 = map.length; for (Object localObject3 = 0; localObject3 < localObject1; localObject3++) { urlPattern = map[localObject3];
/*      */             
/* 2822 */             descMap.addURLPattern(urlPattern);
/*      */           }
/*      */         }
/* 2825 */         String[] dispatcherNames = descMap.getDispatcherNames();
/* 2826 */         if ((dispatchTypesSet) && ((dispatcherNames == null) || (dispatcherNames.length == 0)))
/*      */         {
/* 2828 */           localObject1 = filterMap.getDispatcherNames();String str2 = localObject1.length; for (urlPattern = 0; urlPattern < str2; urlPattern++) { String dis = localObject1[urlPattern];
/* 2829 */             descMap.setDispatcher(dis);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected String[] processAnnotationsStringArray(ElementValue ev)
/*      */   {
/* 2838 */     List<String> values = new ArrayList();
/* 2839 */     if ((ev instanceof ArrayElementValue))
/*      */     {
/* 2841 */       ElementValue[] arrayValues = ((ArrayElementValue)ev).getElementValuesArray();
/* 2842 */       for (ElementValue value : arrayValues) {
/* 2843 */         values.add(value.stringifyValue());
/*      */       }
/*      */     } else {
/* 2846 */       values.add(ev.stringifyValue());
/*      */     }
/* 2848 */     String[] result = new String[values.size()];
/* 2849 */     return (String[])values.toArray(result);
/*      */   }
/*      */   
/*      */   protected Map<String, String> processAnnotationWebInitParams(ElementValue ev)
/*      */   {
/* 2854 */     Map<String, String> result = new HashMap();
/* 2855 */     if ((ev instanceof ArrayElementValue))
/*      */     {
/* 2857 */       ElementValue[] arrayValues = ((ArrayElementValue)ev).getElementValuesArray();
/* 2858 */       for (ElementValue value : arrayValues) {
/* 2859 */         if ((value instanceof AnnotationElementValue))
/*      */         {
/* 2861 */           List<ElementValuePair> evps = ((AnnotationElementValue)value).getAnnotationEntry().getElementValuePairs();
/* 2862 */           String initParamName = null;
/* 2863 */           String initParamValue = null;
/* 2864 */           for (ElementValuePair evp : evps) {
/* 2865 */             if ("name".equals(evp.getNameString())) {
/* 2866 */               initParamName = evp.getValue().stringifyValue();
/* 2867 */             } else if ("value".equals(evp.getNameString())) {
/* 2868 */               initParamValue = evp.getValue().stringifyValue();
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 2873 */           result.put(initParamName, initParamValue);
/*      */         }
/*      */       }
/*      */     }
/* 2877 */     return result;
/*      */   }
/*      */   
/*      */   private static class DefaultWebXmlCacheEntry
/*      */   {
/*      */     private final WebXml webXml;
/*      */     private final long globalTimeStamp;
/*      */     private final long hostTimeStamp;
/*      */     
/*      */     public DefaultWebXmlCacheEntry(WebXml webXml, long globalTimeStamp, long hostTimeStamp) {
/* 2887 */       this.webXml = webXml;
/* 2888 */       this.globalTimeStamp = globalTimeStamp;
/* 2889 */       this.hostTimeStamp = hostTimeStamp;
/*      */     }
/*      */     
/*      */     public WebXml getWebXml() {
/* 2893 */       return this.webXml;
/*      */     }
/*      */     
/*      */     public long getGlobalTimeStamp() {
/* 2897 */       return this.globalTimeStamp;
/*      */     }
/*      */     
/*      */     public long getHostTimeStamp() {
/* 2901 */       return this.hostTimeStamp;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class HostWebXmlCacheCleaner
/*      */     implements LifecycleListener
/*      */   {
/*      */     public void lifecycleEvent(LifecycleEvent event)
/*      */     {
/* 2910 */       if ("after_destroy".equals(event.getType())) {
/* 2911 */         Host host = (Host)event.getSource();
/* 2912 */         ContextConfig.hostWebXmlCache.remove(host);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   static class JavaClassCacheEntry
/*      */   {
/*      */     public final String superclassName;
/*      */     public final String[] interfaceNames;
/* 2922 */     private Set<ServletContainerInitializer> sciSet = null;
/*      */     
/*      */     public JavaClassCacheEntry(JavaClass javaClass) {
/* 2925 */       this.superclassName = javaClass.getSuperclassName();
/* 2926 */       this.interfaceNames = javaClass.getInterfaceNames();
/*      */     }
/*      */     
/*      */     public String getSuperclassName() {
/* 2930 */       return this.superclassName;
/*      */     }
/*      */     
/*      */     public String[] getInterfaceNames() {
/* 2934 */       return this.interfaceNames;
/*      */     }
/*      */     
/*      */     public Set<ServletContainerInitializer> getSciSet() {
/* 2938 */       return this.sciSet;
/*      */     }
/*      */     
/*      */     public void setSciSet(Set<ServletContainerInitializer> sciSet) {
/* 2942 */       this.sciSet = sciSet;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\ContextConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */