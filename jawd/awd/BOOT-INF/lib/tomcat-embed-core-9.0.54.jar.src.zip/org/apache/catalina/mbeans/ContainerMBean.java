/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.ContainerListener;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.core.ContainerBase;
/*     */ import org.apache.catalina.core.StandardContext;
/*     */ import org.apache.catalina.core.StandardHost;
/*     */ import org.apache.catalina.startup.ContextConfig;
/*     */ import org.apache.catalina.startup.HostConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContainerMBean
/*     */   extends BaseCatalinaMBean<ContainerBase>
/*     */ {
/*     */   public void addChild(String type, String name)
/*     */     throws MBeanException
/*     */   {
/*  52 */     Container contained = (Container)newInstance(type);
/*  53 */     contained.setName(name);
/*     */     
/*  55 */     if ((contained instanceof StandardHost)) {
/*  56 */       HostConfig config = new HostConfig();
/*  57 */       contained.addLifecycleListener(config);
/*  58 */     } else if ((contained instanceof StandardContext)) {
/*  59 */       ContextConfig config = new ContextConfig();
/*  60 */       contained.addLifecycleListener(config);
/*     */     }
/*     */     
/*  63 */     boolean oldValue = true;
/*     */     
/*  65 */     ContainerBase container = (ContainerBase)doGetManagedResource();
/*     */     try {
/*  67 */       oldValue = container.getStartChildren();
/*  68 */       container.setStartChildren(false);
/*  69 */       container.addChild(contained);
/*  70 */       contained.init();
/*     */     } catch (LifecycleException e) {
/*  72 */       throw new MBeanException(e);
/*     */     } finally {
/*  74 */       if (container != null) {
/*  75 */         container.setStartChildren(oldValue);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeChild(String name)
/*     */     throws MBeanException
/*     */   {
/*  89 */     if (name != null) {
/*  90 */       Container container = (Container)doGetManagedResource();
/*  91 */       Container contained = container.findChild(name);
/*  92 */       container.removeChild(contained);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String addValve(String valveType)
/*     */     throws MBeanException
/*     */   {
/* 105 */     Valve valve = (Valve)newInstance(valveType);
/*     */     
/* 107 */     Container container = (Container)doGetManagedResource();
/* 108 */     container.getPipeline().addValve(valve);
/*     */     
/* 110 */     if ((valve instanceof JmxEnabled)) {
/* 111 */       return ((JmxEnabled)valve).getObjectName().toString();
/*     */     }
/* 113 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeValve(String valveName)
/*     */     throws MBeanException
/*     */   {
/* 126 */     Container container = (Container)doGetManagedResource();
/*     */     
/*     */     try
/*     */     {
/* 130 */       oname = new ObjectName(valveName);
/*     */     } catch (MalformedObjectNameException|NullPointerException e) { ObjectName oname;
/* 132 */       throw new MBeanException(e);
/*     */     }
/*     */     ObjectName oname;
/* 135 */     if (container != null) {
/* 136 */       Valve[] valves = container.getPipeline().getValves();
/* 137 */       for (Valve valve : valves) {
/* 138 */         if ((valve instanceof JmxEnabled)) {
/* 139 */           ObjectName voname = ((JmxEnabled)valve).getObjectName();
/* 140 */           if (voname.equals(oname)) {
/* 141 */             container.getPipeline().removeValve(valve);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLifecycleListener(String type)
/*     */     throws MBeanException
/*     */   {
/* 156 */     LifecycleListener listener = (LifecycleListener)newInstance(type);
/* 157 */     Container container = (Container)doGetManagedResource();
/* 158 */     container.addLifecycleListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLifecycleListeners(String type)
/*     */     throws MBeanException
/*     */   {
/* 170 */     Container container = (Container)doGetManagedResource();
/*     */     
/* 172 */     LifecycleListener[] listeners = container.findLifecycleListeners();
/* 173 */     for (LifecycleListener listener : listeners) {
/* 174 */       if (listener.getClass().getName().equals(type)) {
/* 175 */         container.removeLifecycleListener(listener);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findLifecycleListenerNames()
/*     */     throws MBeanException
/*     */   {
/* 188 */     Container container = (Container)doGetManagedResource();
/* 189 */     List<String> result = new ArrayList();
/*     */     
/* 191 */     LifecycleListener[] listeners = container.findLifecycleListeners();
/* 192 */     for (LifecycleListener listener : listeners) {
/* 193 */       result.add(listener.getClass().getName());
/*     */     }
/*     */     
/* 196 */     return (String[])result.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findContainerListenerNames()
/*     */     throws MBeanException
/*     */   {
/* 207 */     Container container = (Container)doGetManagedResource();
/* 208 */     List<String> result = new ArrayList();
/*     */     
/* 210 */     ContainerListener[] listeners = container.findContainerListeners();
/* 211 */     for (ContainerListener listener : listeners) {
/* 212 */       result.add(listener.getClass().getName());
/*     */     }
/*     */     
/* 215 */     return (String[])result.toArray(new String[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\ContainerMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */