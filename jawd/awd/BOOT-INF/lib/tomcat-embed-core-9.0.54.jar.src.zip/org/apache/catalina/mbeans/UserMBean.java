/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*     */ import org.apache.tomcat.util.modeler.ManagedBean;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UserMBean
/*     */   extends BaseModelMBean
/*     */ {
/*  42 */   private static final StringManager sm = StringManager.getManager(UserMBean.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */   protected final Registry registry = MBeanUtils.createRegistry();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   protected final ManagedBean managed = this.registry.findManagedBean("User");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getGroups()
/*     */   {
/*  66 */     User user = (User)this.resource;
/*  67 */     List<String> results = new ArrayList();
/*  68 */     Iterator<Group> groups = user.getGroups();
/*  69 */     while (groups.hasNext()) {
/*  70 */       Group group = null;
/*     */       try {
/*  72 */         group = (Group)groups.next();
/*     */         
/*  74 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), group);
/*  75 */         results.add(oname.toString());
/*     */       } catch (MalformedObjectNameException e) {
/*  77 */         throw new IllegalArgumentException(sm.getString("userMBean.createError.group", new Object[] { group }), e);
/*     */       }
/*     */     }
/*  80 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getRoles()
/*     */   {
/*  89 */     User user = (User)this.resource;
/*  90 */     List<String> results = new ArrayList();
/*  91 */     Iterator<Role> roles = user.getRoles();
/*  92 */     while (roles.hasNext()) {
/*  93 */       Role role = null;
/*     */       try {
/*  95 */         role = (Role)roles.next();
/*     */         
/*  97 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), role);
/*  98 */         results.add(oname.toString());
/*     */       } catch (MalformedObjectNameException e) {
/* 100 */         throw new IllegalArgumentException(sm.getString("userMBean.createError.role", new Object[] { role }), e);
/*     */       }
/*     */     }
/* 103 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addGroup(String groupname)
/*     */   {
/* 116 */     User user = (User)this.resource;
/* 117 */     if (user == null) {
/* 118 */       return;
/*     */     }
/* 120 */     Group group = user.getUserDatabase().findGroup(groupname);
/* 121 */     if (group == null) {
/* 122 */       throw new IllegalArgumentException(sm.getString("userMBean.invalidGroup", new Object[] { groupname }));
/*     */     }
/* 124 */     user.addGroup(group);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRole(String rolename)
/*     */   {
/* 135 */     User user = (User)this.resource;
/* 136 */     if (user == null) {
/* 137 */       return;
/*     */     }
/* 139 */     Role role = user.getUserDatabase().findRole(rolename);
/* 140 */     if (role == null) {
/* 141 */       throw new IllegalArgumentException(sm.getString("userMBean.invalidRole", new Object[] { rolename }));
/*     */     }
/* 143 */     user.addRole(role);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeGroup(String groupname)
/*     */   {
/* 154 */     User user = (User)this.resource;
/* 155 */     if (user == null) {
/* 156 */       return;
/*     */     }
/* 158 */     Group group = user.getUserDatabase().findGroup(groupname);
/* 159 */     if (group == null) {
/* 160 */       throw new IllegalArgumentException(sm.getString("userMBean.invalidGroup", new Object[] { groupname }));
/*     */     }
/* 162 */     user.removeGroup(group);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRole(String rolename)
/*     */   {
/* 173 */     User user = (User)this.resource;
/* 174 */     if (user == null) {
/* 175 */       return;
/*     */     }
/* 177 */     Role role = user.getUserDatabase().findRole(rolename);
/* 178 */     if (role == null) {
/* 179 */       throw new IllegalArgumentException(sm.getString("userMBean.invalidRole", new Object[] { rolename }));
/*     */     }
/* 181 */     user.removeRole(role);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\UserMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */