/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import javax.management.MBeanException;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.tomcat.util.descriptor.web.ApplicationParameter;
/*     */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*     */ import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextMBean
/*     */   extends BaseCatalinaMBean<Context>
/*     */ {
/*     */   public String[] findApplicationParameters()
/*     */     throws MBeanException
/*     */   {
/*  37 */     Context context = (Context)doGetManagedResource();
/*     */     
/*  39 */     ApplicationParameter[] params = context.findApplicationParameters();
/*  40 */     String[] stringParams = new String[params.length];
/*  41 */     for (int counter = 0; counter < params.length; counter++) {
/*  42 */       stringParams[counter] = params[counter].toString();
/*     */     }
/*     */     
/*  45 */     return stringParams;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findConstraints()
/*     */     throws MBeanException
/*     */   {
/*  58 */     Context context = (Context)doGetManagedResource();
/*     */     
/*  60 */     SecurityConstraint[] constraints = context.findConstraints();
/*  61 */     String[] stringConstraints = new String[constraints.length];
/*  62 */     for (int counter = 0; counter < constraints.length; counter++) {
/*  63 */       stringConstraints[counter] = constraints[counter].toString();
/*     */     }
/*     */     
/*  66 */     return stringConstraints;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String findErrorPage(int errorCode)
/*     */     throws MBeanException
/*     */   {
/*  79 */     Context context = (Context)doGetManagedResource();
/*  80 */     return context.findErrorPage(errorCode).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public String findErrorPage(String exceptionType)
/*     */     throws MBeanException
/*     */   {
/*  96 */     Context context = (Context)doGetManagedResource();
/*  97 */     return context.findErrorPage(exceptionType).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String findErrorPage(Throwable exceptionType)
/*     */     throws MBeanException
/*     */   {
/* 110 */     Context context = (Context)doGetManagedResource();
/* 111 */     return context.findErrorPage(exceptionType).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findErrorPages()
/*     */     throws MBeanException
/*     */   {
/* 123 */     Context context = (Context)doGetManagedResource();
/*     */     
/* 125 */     ErrorPage[] pages = context.findErrorPages();
/* 126 */     String[] stringPages = new String[pages.length];
/* 127 */     for (int counter = 0; counter < pages.length; counter++) {
/* 128 */       stringPages[counter] = pages[counter].toString();
/*     */     }
/*     */     
/* 131 */     return stringPages;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String findFilterDef(String name)
/*     */     throws MBeanException
/*     */   {
/* 145 */     Context context = (Context)doGetManagedResource();
/*     */     
/* 147 */     FilterDef filterDef = context.findFilterDef(name);
/* 148 */     return filterDef.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findFilterDefs()
/*     */     throws MBeanException
/*     */   {
/* 160 */     Context context = (Context)doGetManagedResource();
/*     */     
/* 162 */     FilterDef[] filterDefs = context.findFilterDefs();
/* 163 */     String[] stringFilters = new String[filterDefs.length];
/* 164 */     for (int counter = 0; counter < filterDefs.length; counter++) {
/* 165 */       stringFilters[counter] = filterDefs[counter].toString();
/*     */     }
/*     */     
/* 168 */     return stringFilters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findFilterMaps()
/*     */     throws MBeanException
/*     */   {
/* 179 */     Context context = (Context)doGetManagedResource();
/*     */     
/* 181 */     FilterMap[] maps = context.findFilterMaps();
/* 182 */     String[] stringMaps = new String[maps.length];
/* 183 */     for (int counter = 0; counter < maps.length; counter++) {
/* 184 */       stringMaps[counter] = maps[counter].toString();
/*     */     }
/*     */     
/* 187 */     return stringMaps;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\ContextMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */