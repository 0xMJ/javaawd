/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.catalina.Executor;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.threads.ResizableExecutor;
/*     */ import org.apache.tomcat.util.threads.TaskQueue;
/*     */ import org.apache.tomcat.util.threads.TaskThreadFactory;
/*     */ import org.apache.tomcat.util.threads.ThreadPoolExecutor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardThreadExecutor
/*     */   extends LifecycleMBeanBase
/*     */   implements Executor, ResizableExecutor
/*     */ {
/*  34 */   protected static final StringManager sm = StringManager.getManager(StandardThreadExecutor.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  40 */   protected int threadPriority = 5;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  45 */   protected boolean daemon = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  50 */   protected String namePrefix = "tomcat-exec-";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  55 */   protected int maxThreads = 200;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  60 */   protected int minSpareThreads = 25;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  65 */   protected int maxIdleTime = 60000;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  70 */   protected ThreadPoolExecutor executor = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String name;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  80 */   protected boolean prestartminSpareThreads = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  85 */   protected int maxQueueSize = Integer.MAX_VALUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */   protected long threadRenewalDelay = 1000L;
/*     */   
/*     */ 
/*  95 */   private TaskQueue taskqueue = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 106 */     super.initInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 120 */     this.taskqueue = new TaskQueue(this.maxQueueSize);
/* 121 */     TaskThreadFactory tf = new TaskThreadFactory(this.namePrefix, this.daemon, getThreadPriority());
/* 122 */     this.executor = new ThreadPoolExecutor(getMinSpareThreads(), getMaxThreads(), this.maxIdleTime, TimeUnit.MILLISECONDS, this.taskqueue, tf);
/* 123 */     this.executor.setThreadRenewalDelay(this.threadRenewalDelay);
/* 124 */     if (this.prestartminSpareThreads) {
/* 125 */       this.executor.prestartAllCoreThreads();
/*     */     }
/* 127 */     this.taskqueue.setParent(this.executor);
/*     */     
/* 129 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 143 */     setState(LifecycleState.STOPPING);
/* 144 */     if (this.executor != null) {
/* 145 */       this.executor.shutdownNow();
/*     */     }
/* 147 */     this.executor = null;
/* 148 */     this.taskqueue = null;
/*     */   }
/*     */   
/*     */   protected void destroyInternal()
/*     */     throws LifecycleException
/*     */   {
/* 154 */     super.destroyInternal();
/*     */   }
/*     */   
/*     */ 
/*     */   @Deprecated
/*     */   public void execute(Runnable command, long timeout, TimeUnit unit)
/*     */   {
/* 161 */     if (this.executor != null) {
/* 162 */       this.executor.execute(command, timeout, unit);
/*     */     } else {
/* 164 */       throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void execute(Runnable command)
/*     */   {
/* 171 */     if (this.executor != null)
/*     */     {
/*     */ 
/* 174 */       this.executor.execute(command);
/*     */     } else {
/* 176 */       throw new IllegalStateException(sm.getString("standardThreadExecutor.notStarted"));
/*     */     }
/*     */   }
/*     */   
/*     */   public void contextStopping() {
/* 181 */     if (this.executor != null) {
/* 182 */       this.executor.contextStopping();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getThreadPriority() {
/* 187 */     return this.threadPriority;
/*     */   }
/*     */   
/*     */   public boolean isDaemon()
/*     */   {
/* 192 */     return this.daemon;
/*     */   }
/*     */   
/*     */   public String getNamePrefix() {
/* 196 */     return this.namePrefix;
/*     */   }
/*     */   
/*     */   public int getMaxIdleTime() {
/* 200 */     return this.maxIdleTime;
/*     */   }
/*     */   
/*     */   public int getMaxThreads()
/*     */   {
/* 205 */     return this.maxThreads;
/*     */   }
/*     */   
/*     */   public int getMinSpareThreads() {
/* 209 */     return this.minSpareThreads;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 214 */     return this.name;
/*     */   }
/*     */   
/*     */   public boolean isPrestartminSpareThreads()
/*     */   {
/* 219 */     return this.prestartminSpareThreads;
/*     */   }
/*     */   
/* 222 */   public void setThreadPriority(int threadPriority) { this.threadPriority = threadPriority; }
/*     */   
/*     */   public void setDaemon(boolean daemon)
/*     */   {
/* 226 */     this.daemon = daemon;
/*     */   }
/*     */   
/*     */   public void setNamePrefix(String namePrefix) {
/* 230 */     this.namePrefix = namePrefix;
/*     */   }
/*     */   
/*     */   public void setMaxIdleTime(int maxIdleTime) {
/* 234 */     this.maxIdleTime = maxIdleTime;
/* 235 */     if (this.executor != null) {
/* 236 */       this.executor.setKeepAliveTime(maxIdleTime, TimeUnit.MILLISECONDS);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setMaxThreads(int maxThreads) {
/* 241 */     this.maxThreads = maxThreads;
/* 242 */     if (this.executor != null) {
/* 243 */       this.executor.setMaximumPoolSize(maxThreads);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setMinSpareThreads(int minSpareThreads) {
/* 248 */     this.minSpareThreads = minSpareThreads;
/* 249 */     if (this.executor != null) {
/* 250 */       this.executor.setCorePoolSize(minSpareThreads);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setPrestartminSpareThreads(boolean prestartminSpareThreads) {
/* 255 */     this.prestartminSpareThreads = prestartminSpareThreads;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 259 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void setMaxQueueSize(int size) {
/* 263 */     this.maxQueueSize = size;
/*     */   }
/*     */   
/*     */   public int getMaxQueueSize() {
/* 267 */     return this.maxQueueSize;
/*     */   }
/*     */   
/*     */   public long getThreadRenewalDelay() {
/* 271 */     return this.threadRenewalDelay;
/*     */   }
/*     */   
/*     */   public void setThreadRenewalDelay(long threadRenewalDelay) {
/* 275 */     this.threadRenewalDelay = threadRenewalDelay;
/* 276 */     if (this.executor != null) {
/* 277 */       this.executor.setThreadRenewalDelay(threadRenewalDelay);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int getActiveCount()
/*     */   {
/* 284 */     return this.executor != null ? this.executor.getActiveCount() : 0;
/*     */   }
/*     */   
/*     */   public long getCompletedTaskCount() {
/* 288 */     return this.executor != null ? this.executor.getCompletedTaskCount() : 0L;
/*     */   }
/*     */   
/*     */   public int getCorePoolSize() {
/* 292 */     return this.executor != null ? this.executor.getCorePoolSize() : 0;
/*     */   }
/*     */   
/*     */   public int getLargestPoolSize() {
/* 296 */     return this.executor != null ? this.executor.getLargestPoolSize() : 0;
/*     */   }
/*     */   
/*     */   public int getPoolSize()
/*     */   {
/* 301 */     return this.executor != null ? this.executor.getPoolSize() : 0;
/*     */   }
/*     */   
/*     */   public int getQueueSize() {
/* 305 */     return this.executor != null ? this.executor.getQueue().size() : -1;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean resizePool(int corePoolSize, int maximumPoolSize)
/*     */   {
/* 311 */     if (this.executor == null) {
/* 312 */       return false;
/*     */     }
/*     */     
/* 315 */     this.executor.setCorePoolSize(corePoolSize);
/* 316 */     this.executor.setMaximumPoolSize(maximumPoolSize);
/* 317 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean resizeQueue(int capacity)
/*     */   {
/* 323 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getDomainInternal()
/*     */   {
/* 330 */     return null;
/*     */   }
/*     */   
/*     */   protected String getObjectNameKeyProperties()
/*     */   {
/* 335 */     return "type=Executor,name=" + getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\StandardThreadExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */