/*    */ package org.apache.catalina.util;
/*    */ 
/*    */ import org.apache.catalina.Contained;
/*    */ import org.apache.catalina.Container;
/*    */ import org.apache.catalina.Manager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ToStringUtil
/*    */ {
/*    */   public static final String toString(Contained contained)
/*    */   {
/* 35 */     return toString(contained, contained.getContainer());
/*    */   }
/*    */   
/*    */   public static final String toString(Object obj, Container container)
/*    */   {
/* 40 */     return containedToString(obj, container, "Container");
/*    */   }
/*    */   
/*    */   public static final String toString(Object obj, Manager manager)
/*    */   {
/* 45 */     return containedToString(obj, manager, "Manager");
/*    */   }
/*    */   
/*    */ 
/*    */   private static final String containedToString(Object contained, Object container, String containerTypeName)
/*    */   {
/* 51 */     StringBuilder sb = new StringBuilder(contained.getClass().getSimpleName());
/* 52 */     sb.append('[');
/* 53 */     if (container == null) {
/* 54 */       sb.append(containerTypeName);
/* 55 */       sb.append(" is null");
/*    */     } else {
/* 57 */       sb.append(container.toString());
/*    */     }
/* 59 */     sb.append(']');
/* 60 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\ToStringUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */