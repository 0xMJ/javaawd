/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Enumeration;
/*      */ import java.util.EventListener;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import javax.management.ListenerNotFoundException;
/*      */ import javax.management.MBeanNotificationInfo;
/*      */ import javax.management.Notification;
/*      */ import javax.management.NotificationBroadcasterSupport;
/*      */ import javax.management.NotificationEmitter;
/*      */ import javax.management.NotificationFilter;
/*      */ import javax.management.NotificationListener;
/*      */ import javax.naming.NamingException;
/*      */ import javax.servlet.Filter;
/*      */ import javax.servlet.FilterConfig;
/*      */ import javax.servlet.FilterRegistration;
/*      */ import javax.servlet.FilterRegistration.Dynamic;
/*      */ import javax.servlet.RequestDispatcher;
/*      */ import javax.servlet.Servlet;
/*      */ import javax.servlet.ServletContainerInitializer;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletContextAttributeListener;
/*      */ import javax.servlet.ServletContextEvent;
/*      */ import javax.servlet.ServletContextListener;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletRegistration;
/*      */ import javax.servlet.ServletRegistration.Dynamic;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletRequestAttributeListener;
/*      */ import javax.servlet.ServletRequestEvent;
/*      */ import javax.servlet.ServletRequestListener;
/*      */ import javax.servlet.ServletSecurityElement;
/*      */ import javax.servlet.SessionCookieConfig;
/*      */ import javax.servlet.SessionTrackingMode;
/*      */ import javax.servlet.descriptor.JspConfigDescriptor;
/*      */ import javax.servlet.http.HttpSessionAttributeListener;
/*      */ import javax.servlet.http.HttpSessionIdListener;
/*      */ import javax.servlet.http.HttpSessionListener;
/*      */ import org.apache.catalina.Authenticator;
/*      */ import org.apache.catalina.Cluster;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.ContainerListener;
/*      */ import org.apache.catalina.CredentialHandler;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Lifecycle;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Loader;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.ThreadBindingListener;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.WebResourceRoot.ResourceSetType;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*      */ import org.apache.catalina.loader.WebappClassLoaderBase;
/*      */ import org.apache.catalina.loader.WebappLoader;
/*      */ import org.apache.catalina.session.StandardManager;
/*      */ import org.apache.catalina.util.CharsetMapper;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.ErrorPageSupport;
/*      */ import org.apache.catalina.util.ExtensionValidator;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.catalina.webresources.StandardRoot;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.naming.ContextBindings;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.InstanceManagerBindings;
/*      */ import org.apache.tomcat.JarScanner;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.StringUtils;
/*      */ import org.apache.tomcat.util.compat.JreCompat;
/*      */ import org.apache.tomcat.util.descriptor.web.ApplicationParameter;
/*      */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*      */ import org.apache.tomcat.util.descriptor.web.Injectable;
/*      */ import org.apache.tomcat.util.descriptor.web.InjectionTarget;
/*      */ import org.apache.tomcat.util.descriptor.web.LoginConfig;
/*      */ import org.apache.tomcat.util.descriptor.web.MessageDestination;
/*      */ import org.apache.tomcat.util.descriptor.web.MessageDestinationRef;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityCollection;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
/*      */ import org.apache.tomcat.util.http.CookieProcessor;
/*      */ import org.apache.tomcat.util.http.Rfc6265CookieProcessor;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.scan.StandardJarScanner;
/*      */ import org.apache.tomcat.util.security.PrivilegedGetTccl;
/*      */ import org.apache.tomcat.util.security.PrivilegedSetTccl;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StandardContext
/*      */   extends ContainerBase
/*      */   implements org.apache.catalina.Context, NotificationEmitter
/*      */ {
/*  149 */   private static final Log log = LogFactory.getLog(StandardContext.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public StandardContext()
/*      */   {
/*  161 */     this.pipeline.setBasic(new StandardContextValve());
/*  162 */     this.broadcaster = new NotificationBroadcasterSupport();
/*      */     
/*  164 */     if (!Globals.STRICT_SERVLET_COMPLIANCE)
/*      */     {
/*      */ 
/*  167 */       this.resourceOnlyServlets.add("jsp");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  179 */   protected boolean allowCasualMultipartParsing = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  185 */   private boolean swallowAbortedUploads = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  190 */   private String altDDName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  196 */   private InstanceManager instanceManager = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  202 */   private boolean antiResourceLocking = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  210 */   private String[] applicationListeners = new String[0];
/*      */   
/*  212 */   private final Object applicationListenersLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  218 */   private final Set<Object> noPluggabilityListeners = new HashSet();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  225 */   private List<Object> applicationEventListenersList = new CopyOnWriteArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  233 */   private Object[] applicationLifecycleListenersObjects = new Object[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  240 */   private Map<ServletContainerInitializer, Set<Class<?>>> initializers = new LinkedHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  247 */   private ApplicationParameter[] applicationParameters = new ApplicationParameter[0];
/*      */   
/*      */ 
/*  250 */   private final Object applicationParametersLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  256 */   private NotificationBroadcasterSupport broadcaster = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  261 */   private CharsetMapper charsetMapper = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  267 */   private String charsetMapperClass = "org.apache.catalina.util.CharsetMapper";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  274 */   private URL configFile = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  280 */   private boolean configured = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  286 */   private volatile SecurityConstraint[] constraints = new SecurityConstraint[0];
/*      */   
/*      */ 
/*  289 */   private final Object constraintsLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  295 */   protected ApplicationContext context = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  302 */   private NoPluggabilityServletContext noPluggabilityServletContext = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  308 */   private boolean cookies = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  315 */   private boolean crossContext = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  321 */   private String encodedPath = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  327 */   private String path = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  336 */   private boolean delegate = JreCompat.isGraalAvailable();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean denyUncoveredHttpMethods;
/*      */   
/*      */ 
/*      */ 
/*  345 */   private String displayName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String defaultContextXml;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String defaultWebXml;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  363 */   private boolean distributable = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  369 */   private String docBase = null;
/*      */   
/*      */ 
/*  372 */   private final ErrorPageSupport errorPageSupport = new ErrorPageSupport();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  378 */   private Map<String, ApplicationFilterConfig> filterConfigs = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  385 */   private Map<String, FilterDef> filterDefs = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  394 */   private final ContextFilterMaps filterMaps = new ContextFilterMaps(null);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  399 */   private boolean ignoreAnnotations = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  405 */   private Loader loader = null;
/*  406 */   private final ReadWriteLock loaderLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  412 */   private LoginConfig loginConfig = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  418 */   protected Manager manager = null;
/*  419 */   private final ReadWriteLock managerLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  425 */   private NamingContextListener namingContextListener = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  431 */   private NamingResourcesImpl namingResources = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  436 */   private HashMap<String, MessageDestination> messageDestinations = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  443 */   private Map<String, String> mimeMappings = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  450 */   private final Map<String, String> parameters = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  456 */   private volatile boolean paused = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  464 */   private String publicId = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  470 */   private boolean reloadable = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  476 */   private boolean unpackWAR = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  482 */   private boolean copyXML = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  488 */   private boolean override = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  494 */   private String originalDocBase = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  500 */   private boolean privileged = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  510 */   private boolean replaceWelcomeFiles = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  517 */   private Map<String, String> roleMappings = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  523 */   private String[] securityRoles = new String[0];
/*      */   
/*  525 */   private final Object securityRolesLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  532 */   private Map<String, String> servletMappings = new HashMap();
/*      */   
/*  534 */   private final Object servletMappingsLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  540 */   private int sessionTimeout = 30;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  545 */   private AtomicLong sequenceNumber = new AtomicLong(0L);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  552 */   private boolean swallowOutput = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  558 */   private long unloadDelay = 2000L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  564 */   private String[] watchedResources = new String[0];
/*      */   
/*  566 */   private final Object watchedResourcesLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  572 */   private String[] welcomeFiles = new String[0];
/*      */   
/*  574 */   private final Object welcomeFilesLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  581 */   private String[] wrapperLifecycles = new String[0];
/*      */   
/*  583 */   private final Object wrapperLifecyclesLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  589 */   private String[] wrapperListeners = new String[0];
/*      */   
/*  591 */   private final Object wrapperListenersLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  597 */   private String workDir = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  603 */   private String wrapperClassName = StandardWrapper.class.getName();
/*  604 */   private Class<?> wrapperClass = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  610 */   private boolean useNaming = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  616 */   private String namingContextName = null;
/*      */   
/*      */   private WebResourceRoot resources;
/*      */   
/*  620 */   private final ReadWriteLock resourcesLock = new ReentrantReadWriteLock();
/*      */   
/*      */ 
/*      */   private long startupTime;
/*      */   
/*      */   private long startTime;
/*      */   
/*      */   private long tldScanTime;
/*      */   
/*  629 */   private String j2EEApplication = "none";
/*  630 */   private String j2EEServer = "none";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  637 */   private boolean webXmlValidation = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  643 */   private boolean webXmlNamespaceAware = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  649 */   private boolean xmlBlockExternal = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  655 */   private boolean tldValidation = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String sessionCookieName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  668 */   private boolean useHttpOnly = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String sessionCookieDomain;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String sessionCookiePath;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  690 */   private boolean sessionCookiePathUsesTrailingSlash = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  697 */   private JarScanner jarScanner = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  704 */   private boolean clearReferencesRmiTargets = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  715 */   private boolean clearReferencesStopThreads = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  722 */   private boolean clearReferencesStopTimerThreads = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  732 */   private boolean clearReferencesHttpClientKeepAliveThread = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  740 */   private boolean renewThreadsWhenStoppingContext = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  746 */   private boolean clearReferencesObjectStreamClassCaches = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  752 */   private boolean clearReferencesThreadLocals = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  758 */   private boolean skipMemoryLeakChecksOnJvmShutdown = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  763 */   private boolean logEffectiveWebXml = false;
/*      */   
/*  765 */   private int effectiveMajorVersion = 3;
/*      */   
/*  767 */   private int effectiveMinorVersion = 0;
/*      */   
/*  769 */   private JspConfigDescriptor jspConfigDescriptor = null;
/*      */   
/*  771 */   private Set<String> resourceOnlyServlets = new HashSet();
/*      */   
/*  773 */   private String webappVersion = "";
/*      */   
/*  775 */   private boolean addWebinfClassesResources = false;
/*      */   
/*  777 */   private boolean fireRequestListenersOnForwards = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  783 */   private Set<Servlet> createdServlets = new HashSet();
/*      */   
/*  785 */   private boolean preemptiveAuthentication = false;
/*      */   
/*  787 */   private boolean sendRedirectBody = false;
/*      */   
/*  789 */   private boolean jndiExceptionOnFailedWrite = true;
/*      */   
/*  791 */   private Map<String, String> postConstructMethods = new HashMap();
/*  792 */   private Map<String, String> preDestroyMethods = new HashMap();
/*      */   
/*      */   private String containerSciFilter;
/*      */   
/*      */   private Boolean failCtxIfServletStartFails;
/*      */   
/*  798 */   protected static final ThreadBindingListener DEFAULT_NAMING_LISTENER = new ThreadBindingListener()
/*      */   {
/*      */     public void bind() {}
/*      */     
/*      */     public void unbind() {}
/*      */   };
/*  804 */   protected ThreadBindingListener threadBindingListener = DEFAULT_NAMING_LISTENER;
/*      */   
/*  806 */   private final Object namingToken = new Object();
/*      */   
/*      */   private CookieProcessor cookieProcessor;
/*      */   
/*  810 */   private boolean validateClientProvidedNewSessionId = true;
/*      */   
/*  812 */   private boolean mapperContextRootRedirectEnabled = true;
/*      */   
/*  814 */   private boolean mapperDirectoryRedirectEnabled = false;
/*      */   
/*  816 */   private boolean useRelativeRedirects = !Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*  818 */   private boolean dispatchersUseEncodedPaths = true;
/*      */   
/*  820 */   private String requestEncoding = null;
/*      */   
/*  822 */   private String responseEncoding = null;
/*      */   
/*  824 */   private boolean allowMultipleLeadingForwardSlashInPath = false;
/*      */   
/*  826 */   private final AtomicLong inProgressAsyncCount = new AtomicLong(0L);
/*      */   
/*  828 */   private boolean createUploadTargets = false;
/*      */   
/*      */ 
/*  831 */   private boolean parallelAnnotationScanning = false;
/*      */   
/*  833 */   private boolean useBloomFilterForArchives = false;
/*      */   
/*      */   private MBeanNotificationInfo[] notificationInfo;
/*      */   
/*      */   public void setCreateUploadTargets(boolean createUploadTargets)
/*      */   {
/*  839 */     this.createUploadTargets = createUploadTargets;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getCreateUploadTargets()
/*      */   {
/*  845 */     return this.createUploadTargets;
/*      */   }
/*      */   
/*      */ 
/*      */   public void incrementInProgressAsyncCount()
/*      */   {
/*  851 */     this.inProgressAsyncCount.incrementAndGet();
/*      */   }
/*      */   
/*      */ 
/*      */   public void decrementInProgressAsyncCount()
/*      */   {
/*  857 */     this.inProgressAsyncCount.decrementAndGet();
/*      */   }
/*      */   
/*      */   public long getInProgressAsyncCount()
/*      */   {
/*  862 */     return this.inProgressAsyncCount.get();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAllowMultipleLeadingForwardSlashInPath(boolean allowMultipleLeadingForwardSlashInPath)
/*      */   {
/*  869 */     this.allowMultipleLeadingForwardSlashInPath = allowMultipleLeadingForwardSlashInPath;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getAllowMultipleLeadingForwardSlashInPath()
/*      */   {
/*  875 */     return this.allowMultipleLeadingForwardSlashInPath;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getRequestCharacterEncoding()
/*      */   {
/*  881 */     return this.requestEncoding;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setRequestCharacterEncoding(String requestEncoding)
/*      */   {
/*  887 */     this.requestEncoding = requestEncoding;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getResponseCharacterEncoding()
/*      */   {
/*  893 */     return this.responseEncoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResponseCharacterEncoding(String responseEncoding)
/*      */   {
/*  905 */     if (responseEncoding == null) {
/*  906 */       this.responseEncoding = null;
/*      */     } else {
/*  908 */       this.responseEncoding = new String(responseEncoding);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDispatchersUseEncodedPaths(boolean dispatchersUseEncodedPaths)
/*      */   {
/*  915 */     this.dispatchersUseEncodedPaths = dispatchersUseEncodedPaths;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDispatchersUseEncodedPaths()
/*      */   {
/*  926 */     return this.dispatchersUseEncodedPaths;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setUseRelativeRedirects(boolean useRelativeRedirects)
/*      */   {
/*  932 */     this.useRelativeRedirects = useRelativeRedirects;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseRelativeRedirects()
/*      */   {
/*  943 */     return this.useRelativeRedirects;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setMapperContextRootRedirectEnabled(boolean mapperContextRootRedirectEnabled)
/*      */   {
/*  949 */     this.mapperContextRootRedirectEnabled = mapperContextRootRedirectEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMapperContextRootRedirectEnabled()
/*      */   {
/*  960 */     return this.mapperContextRootRedirectEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setMapperDirectoryRedirectEnabled(boolean mapperDirectoryRedirectEnabled)
/*      */   {
/*  966 */     this.mapperDirectoryRedirectEnabled = mapperDirectoryRedirectEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getMapperDirectoryRedirectEnabled()
/*      */   {
/*  977 */     return this.mapperDirectoryRedirectEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setValidateClientProvidedNewSessionId(boolean validateClientProvidedNewSessionId)
/*      */   {
/*  983 */     this.validateClientProvidedNewSessionId = validateClientProvidedNewSessionId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getValidateClientProvidedNewSessionId()
/*      */   {
/*  994 */     return this.validateClientProvidedNewSessionId;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCookieProcessor(CookieProcessor cookieProcessor)
/*      */   {
/* 1000 */     if (cookieProcessor == null)
/*      */     {
/* 1002 */       throw new IllegalArgumentException(sm.getString("standardContext.cookieProcessor.null"));
/*      */     }
/* 1004 */     this.cookieProcessor = cookieProcessor;
/*      */   }
/*      */   
/*      */ 
/*      */   public CookieProcessor getCookieProcessor()
/*      */   {
/* 1010 */     return this.cookieProcessor;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object getNamingToken()
/*      */   {
/* 1016 */     return this.namingToken;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setContainerSciFilter(String containerSciFilter)
/*      */   {
/* 1022 */     this.containerSciFilter = containerSciFilter;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getContainerSciFilter()
/*      */   {
/* 1028 */     return this.containerSciFilter;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getSendRedirectBody()
/*      */   {
/* 1034 */     return this.sendRedirectBody;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSendRedirectBody(boolean sendRedirectBody)
/*      */   {
/* 1040 */     this.sendRedirectBody = sendRedirectBody;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getPreemptiveAuthentication()
/*      */   {
/* 1046 */     return this.preemptiveAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setPreemptiveAuthentication(boolean preemptiveAuthentication)
/*      */   {
/* 1052 */     this.preemptiveAuthentication = preemptiveAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setFireRequestListenersOnForwards(boolean enable)
/*      */   {
/* 1058 */     this.fireRequestListenersOnForwards = enable;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getFireRequestListenersOnForwards()
/*      */   {
/* 1064 */     return this.fireRequestListenersOnForwards;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setAddWebinfClassesResources(boolean addWebinfClassesResources)
/*      */   {
/* 1071 */     this.addWebinfClassesResources = addWebinfClassesResources;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getAddWebinfClassesResources()
/*      */   {
/* 1077 */     return this.addWebinfClassesResources;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setWebappVersion(String webappVersion)
/*      */   {
/* 1083 */     if (null == webappVersion) {
/* 1084 */       this.webappVersion = "";
/*      */     } else {
/* 1086 */       this.webappVersion = webappVersion;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public String getWebappVersion()
/*      */   {
/* 1093 */     return this.webappVersion;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getBaseName()
/*      */   {
/* 1099 */     return new ContextName(this.path, this.webappVersion).getBaseName();
/*      */   }
/*      */   
/*      */ 
/*      */   public String getResourceOnlyServlets()
/*      */   {
/* 1105 */     return StringUtils.join(this.resourceOnlyServlets);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setResourceOnlyServlets(String resourceOnlyServlets)
/*      */   {
/* 1111 */     this.resourceOnlyServlets.clear();
/* 1112 */     if (resourceOnlyServlets == null) {
/* 1113 */       return;
/*      */     }
/* 1115 */     for (String servletName : resourceOnlyServlets.split(",")) {
/* 1116 */       servletName = servletName.trim();
/* 1117 */       if (servletName.length() > 0) {
/* 1118 */         this.resourceOnlyServlets.add(servletName);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isResourceOnlyServlet(String servletName)
/*      */   {
/* 1126 */     return this.resourceOnlyServlets.contains(servletName);
/*      */   }
/*      */   
/*      */ 
/*      */   public int getEffectiveMajorVersion()
/*      */   {
/* 1132 */     return this.effectiveMajorVersion;
/*      */   }
/*      */   
/*      */   public void setEffectiveMajorVersion(int effectiveMajorVersion)
/*      */   {
/* 1137 */     this.effectiveMajorVersion = effectiveMajorVersion;
/*      */   }
/*      */   
/*      */   public int getEffectiveMinorVersion()
/*      */   {
/* 1142 */     return this.effectiveMinorVersion;
/*      */   }
/*      */   
/*      */   public void setEffectiveMinorVersion(int effectiveMinorVersion)
/*      */   {
/* 1147 */     this.effectiveMinorVersion = effectiveMinorVersion;
/*      */   }
/*      */   
/*      */   public void setLogEffectiveWebXml(boolean logEffectiveWebXml)
/*      */   {
/* 1152 */     this.logEffectiveWebXml = logEffectiveWebXml;
/*      */   }
/*      */   
/*      */   public boolean getLogEffectiveWebXml()
/*      */   {
/* 1157 */     return this.logEffectiveWebXml;
/*      */   }
/*      */   
/*      */   public Authenticator getAuthenticator()
/*      */   {
/* 1162 */     Pipeline pipeline = getPipeline();
/* 1163 */     if (pipeline != null) {
/* 1164 */       Valve basic = pipeline.getBasic();
/* 1165 */       if ((basic instanceof Authenticator)) {
/* 1166 */         return (Authenticator)basic;
/*      */       }
/* 1168 */       for (Valve valve : pipeline.getValves()) {
/* 1169 */         if ((valve instanceof Authenticator)) {
/* 1170 */           return (Authenticator)valve;
/*      */         }
/*      */       }
/*      */     }
/* 1174 */     return null;
/*      */   }
/*      */   
/*      */   public JarScanner getJarScanner()
/*      */   {
/* 1179 */     if (this.jarScanner == null) {
/* 1180 */       this.jarScanner = new StandardJarScanner();
/*      */     }
/* 1182 */     return this.jarScanner;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setJarScanner(JarScanner jarScanner)
/*      */   {
/* 1188 */     this.jarScanner = jarScanner;
/*      */   }
/*      */   
/*      */ 
/*      */   public InstanceManager getInstanceManager()
/*      */   {
/* 1194 */     return this.instanceManager;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setInstanceManager(InstanceManager instanceManager)
/*      */   {
/* 1200 */     this.instanceManager = instanceManager;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getEncodedPath()
/*      */   {
/* 1206 */     return this.encodedPath;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowCasualMultipartParsing(boolean allowCasualMultipartParsing)
/*      */   {
/* 1222 */     this.allowCasualMultipartParsing = allowCasualMultipartParsing;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAllowCasualMultipartParsing()
/*      */   {
/* 1235 */     return this.allowCasualMultipartParsing;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSwallowAbortedUploads(boolean swallowAbortedUploads)
/*      */   {
/* 1247 */     this.swallowAbortedUploads = swallowAbortedUploads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSwallowAbortedUploads()
/*      */   {
/* 1259 */     return this.swallowAbortedUploads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addServletContainerInitializer(ServletContainerInitializer sci, Set<Class<?>> classes)
/*      */   {
/* 1272 */     this.initializers.put(sci, classes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDelegate()
/*      */   {
/* 1283 */     return this.delegate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDelegate(boolean delegate)
/*      */   {
/* 1295 */     boolean oldDelegate = this.delegate;
/* 1296 */     this.delegate = delegate;
/* 1297 */     this.support.firePropertyChange("delegate", oldDelegate, this.delegate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUseNaming()
/*      */   {
/* 1307 */     return this.useNaming;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseNaming(boolean useNaming)
/*      */   {
/* 1317 */     this.useNaming = useNaming;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object[] getApplicationEventListeners()
/*      */   {
/* 1323 */     return this.applicationEventListenersList.toArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setApplicationEventListeners(Object[] listeners)
/*      */   {
/* 1336 */     this.applicationEventListenersList.clear();
/* 1337 */     if ((listeners != null) && (listeners.length > 0)) {
/* 1338 */       this.applicationEventListenersList.addAll(Arrays.asList(listeners));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addApplicationEventListener(Object listener)
/*      */   {
/* 1350 */     this.applicationEventListenersList.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object[] getApplicationLifecycleListeners()
/*      */   {
/* 1356 */     return this.applicationLifecycleListenersObjects;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setApplicationLifecycleListeners(Object[] listeners)
/*      */   {
/* 1369 */     this.applicationLifecycleListenersObjects = listeners;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addApplicationLifecycleListener(Object listener)
/*      */   {
/* 1380 */     int len = this.applicationLifecycleListenersObjects.length;
/* 1381 */     Object[] newListeners = Arrays.copyOf(this.applicationLifecycleListenersObjects, len + 1);
/*      */     
/* 1383 */     newListeners[len] = listener;
/* 1384 */     this.applicationLifecycleListenersObjects = newListeners;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAntiResourceLocking()
/*      */   {
/* 1392 */     return this.antiResourceLocking;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAntiResourceLocking(boolean antiResourceLocking)
/*      */   {
/* 1403 */     boolean oldAntiResourceLocking = this.antiResourceLocking;
/* 1404 */     this.antiResourceLocking = antiResourceLocking;
/* 1405 */     this.support.firePropertyChange("antiResourceLocking", oldAntiResourceLocking, this.antiResourceLocking);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseBloomFilterForArchives()
/*      */   {
/* 1414 */     return this.useBloomFilterForArchives;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUseBloomFilterForArchives(boolean useBloomFilterForArchives)
/*      */   {
/* 1421 */     boolean oldUseBloomFilterForArchives = this.useBloomFilterForArchives;
/* 1422 */     this.useBloomFilterForArchives = useBloomFilterForArchives;
/* 1423 */     this.support.firePropertyChange("useBloomFilterForArchives", oldUseBloomFilterForArchives, this.useBloomFilterForArchives);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParallelAnnotationScanning(boolean parallelAnnotationScanning)
/*      */   {
/* 1432 */     boolean oldParallelAnnotationScanning = this.parallelAnnotationScanning;
/* 1433 */     this.parallelAnnotationScanning = parallelAnnotationScanning;
/* 1434 */     this.support.firePropertyChange("parallelAnnotationScanning", oldParallelAnnotationScanning, this.parallelAnnotationScanning);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getParallelAnnotationScanning()
/*      */   {
/* 1442 */     return this.parallelAnnotationScanning;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CharsetMapper getCharsetMapper()
/*      */   {
/* 1452 */     if (this.charsetMapper == null) {
/*      */       try {
/* 1454 */         Class<?> clazz = Class.forName(this.charsetMapperClass);
/* 1455 */         this.charsetMapper = ((CharsetMapper)clazz.getConstructor(new Class[0]).newInstance(new Object[0]));
/*      */       } catch (Throwable t) {
/* 1457 */         ExceptionUtils.handleThrowable(t);
/* 1458 */         this.charsetMapper = new CharsetMapper();
/*      */       }
/*      */     }
/*      */     
/* 1462 */     return this.charsetMapper;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharsetMapper(CharsetMapper mapper)
/*      */   {
/* 1474 */     CharsetMapper oldCharsetMapper = this.charsetMapper;
/* 1475 */     this.charsetMapper = mapper;
/* 1476 */     if (mapper != null) {
/* 1477 */       this.charsetMapperClass = mapper.getClass().getName();
/*      */     }
/* 1479 */     this.support.firePropertyChange("charsetMapper", oldCharsetMapper, this.charsetMapper);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCharset(Locale locale)
/*      */   {
/* 1487 */     return getCharsetMapper().getCharset(locale);
/*      */   }
/*      */   
/*      */ 
/*      */   public URL getConfigFile()
/*      */   {
/* 1493 */     return this.configFile;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setConfigFile(URL configFile)
/*      */   {
/* 1499 */     this.configFile = configFile;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getConfigured()
/*      */   {
/* 1505 */     return this.configured;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConfigured(boolean configured)
/*      */   {
/* 1519 */     boolean oldConfigured = this.configured;
/* 1520 */     this.configured = configured;
/* 1521 */     this.support.firePropertyChange("configured", oldConfigured, this.configured);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getCookies()
/*      */   {
/* 1530 */     return this.cookies;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCookies(boolean cookies)
/*      */   {
/* 1542 */     boolean oldCookies = this.cookies;
/* 1543 */     this.cookies = cookies;
/* 1544 */     this.support.firePropertyChange("cookies", oldCookies, this.cookies);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionCookieName()
/*      */   {
/* 1560 */     return this.sessionCookieName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionCookieName(String sessionCookieName)
/*      */   {
/* 1572 */     String oldSessionCookieName = this.sessionCookieName;
/* 1573 */     this.sessionCookieName = sessionCookieName;
/* 1574 */     this.support.firePropertyChange("sessionCookieName", oldSessionCookieName, sessionCookieName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseHttpOnly()
/*      */   {
/* 1587 */     return this.useHttpOnly;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseHttpOnly(boolean useHttpOnly)
/*      */   {
/* 1599 */     boolean oldUseHttpOnly = this.useHttpOnly;
/* 1600 */     this.useHttpOnly = useHttpOnly;
/* 1601 */     this.support.firePropertyChange("useHttpOnly", oldUseHttpOnly, this.useHttpOnly);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionCookieDomain()
/*      */   {
/* 1616 */     return this.sessionCookieDomain;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionCookieDomain(String sessionCookieDomain)
/*      */   {
/* 1628 */     String oldSessionCookieDomain = this.sessionCookieDomain;
/* 1629 */     this.sessionCookieDomain = sessionCookieDomain;
/* 1630 */     this.support.firePropertyChange("sessionCookieDomain", oldSessionCookieDomain, sessionCookieDomain);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionCookiePath()
/*      */   {
/* 1644 */     return this.sessionCookiePath;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionCookiePath(String sessionCookiePath)
/*      */   {
/* 1656 */     String oldSessionCookiePath = this.sessionCookiePath;
/* 1657 */     this.sessionCookiePath = sessionCookiePath;
/* 1658 */     this.support.firePropertyChange("sessionCookiePath", oldSessionCookiePath, sessionCookiePath);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getSessionCookiePathUsesTrailingSlash()
/*      */   {
/* 1665 */     return this.sessionCookiePathUsesTrailingSlash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSessionCookiePathUsesTrailingSlash(boolean sessionCookiePathUsesTrailingSlash)
/*      */   {
/* 1672 */     this.sessionCookiePathUsesTrailingSlash = sessionCookiePathUsesTrailingSlash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getCrossContext()
/*      */   {
/* 1679 */     return this.crossContext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCrossContext(boolean crossContext)
/*      */   {
/* 1691 */     boolean oldCrossContext = this.crossContext;
/* 1692 */     this.crossContext = crossContext;
/* 1693 */     this.support.firePropertyChange("crossContext", oldCrossContext, this.crossContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getDefaultContextXml()
/*      */   {
/* 1700 */     return this.defaultContextXml;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultContextXml(String defaultContextXml)
/*      */   {
/* 1711 */     this.defaultContextXml = defaultContextXml;
/*      */   }
/*      */   
/*      */   public String getDefaultWebXml() {
/* 1715 */     return this.defaultWebXml;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultWebXml(String defaultWebXml)
/*      */   {
/* 1726 */     this.defaultWebXml = defaultWebXml;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getStartupTime()
/*      */   {
/* 1735 */     return this.startupTime;
/*      */   }
/*      */   
/*      */   public void setStartupTime(long startupTime) {
/* 1739 */     this.startupTime = startupTime;
/*      */   }
/*      */   
/*      */   public long getTldScanTime() {
/* 1743 */     return this.tldScanTime;
/*      */   }
/*      */   
/*      */   public void setTldScanTime(long tldScanTime) {
/* 1747 */     this.tldScanTime = tldScanTime;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getDenyUncoveredHttpMethods()
/*      */   {
/* 1753 */     return this.denyUncoveredHttpMethods;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDenyUncoveredHttpMethods(boolean denyUncoveredHttpMethods)
/*      */   {
/* 1759 */     this.denyUncoveredHttpMethods = denyUncoveredHttpMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDisplayName()
/*      */   {
/* 1768 */     return this.displayName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAltDDName()
/*      */   {
/* 1777 */     return this.altDDName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAltDDName(String altDDName)
/*      */   {
/* 1788 */     this.altDDName = altDDName;
/* 1789 */     if (this.context != null) {
/* 1790 */       this.context.setAttribute("org.apache.catalina.deploy.alt_dd", altDDName);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDisplayName(String displayName)
/*      */   {
/* 1803 */     String oldDisplayName = this.displayName;
/* 1804 */     this.displayName = displayName;
/* 1805 */     this.support.firePropertyChange("displayName", oldDisplayName, this.displayName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDistributable()
/*      */   {
/* 1815 */     return this.distributable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDistributable(boolean distributable)
/*      */   {
/* 1825 */     boolean oldDistributable = this.distributable;
/* 1826 */     this.distributable = distributable;
/* 1827 */     this.support.firePropertyChange("distributable", oldDistributable, this.distributable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDocBase()
/*      */   {
/* 1835 */     return this.docBase;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDocBase(String docBase)
/*      */   {
/* 1841 */     this.docBase = docBase;
/*      */   }
/*      */   
/*      */   public String getJ2EEApplication()
/*      */   {
/* 1846 */     return this.j2EEApplication;
/*      */   }
/*      */   
/*      */   public void setJ2EEApplication(String j2EEApplication) {
/* 1850 */     this.j2EEApplication = j2EEApplication;
/*      */   }
/*      */   
/*      */   public String getJ2EEServer() {
/* 1854 */     return this.j2EEServer;
/*      */   }
/*      */   
/*      */   public void setJ2EEServer(String j2EEServer) {
/* 1858 */     this.j2EEServer = j2EEServer;
/*      */   }
/*      */   
/*      */ 
/*      */   public Loader getLoader()
/*      */   {
/* 1864 */     Lock readLock = this.loaderLock.readLock();
/* 1865 */     readLock.lock();
/*      */     try {
/* 1867 */       return this.loader;
/*      */     } finally {
/* 1869 */       readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLoader(Loader loader)
/*      */   {
/* 1876 */     Lock writeLock = this.loaderLock.writeLock();
/* 1877 */     writeLock.lock();
/* 1878 */     Loader oldLoader = null;
/*      */     try
/*      */     {
/* 1881 */       oldLoader = this.loader;
/* 1882 */       if (oldLoader == loader) {
/* 1883 */         return;
/*      */       }
/* 1885 */       this.loader = loader;
/*      */       
/*      */ 
/* 1888 */       if ((getState().isAvailable()) && (oldLoader != null) && ((oldLoader instanceof Lifecycle))) {
/*      */         try
/*      */         {
/* 1891 */           ((Lifecycle)oldLoader).stop();
/*      */         } catch (LifecycleException e) {
/* 1893 */           log.error(sm.getString("standardContext.setLoader.stop"), e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1898 */       if (loader != null) {
/* 1899 */         loader.setContext(this);
/*      */       }
/* 1901 */       if ((getState().isAvailable()) && (loader != null) && ((loader instanceof Lifecycle))) {
/*      */         try
/*      */         {
/* 1904 */           ((Lifecycle)loader).start();
/*      */         } catch (LifecycleException e) {
/* 1906 */           log.error(sm.getString("standardContext.setLoader.start"), e);
/*      */         }
/*      */       }
/*      */     } finally {
/* 1910 */       writeLock.unlock();
/*      */     }
/*      */     
/*      */ 
/* 1914 */     this.support.firePropertyChange("loader", oldLoader, loader);
/*      */   }
/*      */   
/*      */ 
/*      */   public Manager getManager()
/*      */   {
/* 1920 */     Lock readLock = this.managerLock.readLock();
/* 1921 */     readLock.lock();
/*      */     try {
/* 1923 */       return this.manager;
/*      */     } finally {
/* 1925 */       readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setManager(Manager manager)
/*      */   {
/* 1933 */     Lock writeLock = this.managerLock.writeLock();
/* 1934 */     writeLock.lock();
/* 1935 */     Manager oldManager = null;
/*      */     try
/*      */     {
/* 1938 */       oldManager = this.manager;
/* 1939 */       if (oldManager == manager) {
/* 1940 */         return;
/*      */       }
/* 1942 */       this.manager = manager;
/*      */       
/*      */ 
/* 1945 */       if ((oldManager instanceof Lifecycle)) {
/*      */         try {
/* 1947 */           ((Lifecycle)oldManager).stop();
/* 1948 */           ((Lifecycle)oldManager).destroy();
/*      */         } catch (LifecycleException e) {
/* 1950 */           log.error(sm.getString("standardContext.setManager.stop"), e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1955 */       if (manager != null) {
/* 1956 */         manager.setContext(this);
/*      */       }
/* 1958 */       if ((getState().isAvailable()) && ((manager instanceof Lifecycle))) {
/*      */         try {
/* 1960 */           ((Lifecycle)manager).start();
/*      */         } catch (LifecycleException e) {
/* 1962 */           log.error(sm.getString("standardContext.setManager.start"), e);
/*      */         }
/*      */       }
/*      */     } finally {
/* 1966 */       writeLock.unlock();
/*      */     }
/*      */     
/*      */ 
/* 1970 */     this.support.firePropertyChange("manager", oldManager, manager);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getIgnoreAnnotations()
/*      */   {
/* 1979 */     return this.ignoreAnnotations;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIgnoreAnnotations(boolean ignoreAnnotations)
/*      */   {
/* 1991 */     boolean oldIgnoreAnnotations = this.ignoreAnnotations;
/* 1992 */     this.ignoreAnnotations = ignoreAnnotations;
/* 1993 */     this.support.firePropertyChange("ignoreAnnotations", oldIgnoreAnnotations, this.ignoreAnnotations);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LoginConfig getLoginConfig()
/*      */   {
/* 2003 */     return this.loginConfig;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLoginConfig(LoginConfig config)
/*      */   {
/* 2016 */     if (config == null)
/*      */     {
/* 2018 */       throw new IllegalArgumentException(sm.getString("standardContext.loginConfig.required"));
/*      */     }
/* 2020 */     String loginPage = config.getLoginPage();
/* 2021 */     if ((loginPage != null) && (!loginPage.startsWith("/"))) {
/* 2022 */       if (isServlet22()) {
/* 2023 */         if (log.isDebugEnabled()) {
/* 2024 */           log.debug(sm.getString("standardContext.loginConfig.loginWarning", new Object[] { loginPage }));
/*      */         }
/*      */         
/* 2027 */         config.setLoginPage("/" + loginPage);
/*      */       }
/*      */       else {
/* 2030 */         throw new IllegalArgumentException(sm.getString("standardContext.loginConfig.loginPage", new Object[] { loginPage }));
/*      */       }
/*      */     }
/*      */     
/* 2034 */     String errorPage = config.getErrorPage();
/* 2035 */     if ((errorPage != null) && (!errorPage.startsWith("/"))) {
/* 2036 */       if (isServlet22()) {
/* 2037 */         if (log.isDebugEnabled()) {
/* 2038 */           log.debug(sm.getString("standardContext.loginConfig.errorWarning", new Object[] { errorPage }));
/*      */         }
/*      */         
/* 2041 */         config.setErrorPage("/" + errorPage);
/*      */       }
/*      */       else {
/* 2044 */         throw new IllegalArgumentException(sm.getString("standardContext.loginConfig.errorPage", new Object[] { errorPage }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2050 */     LoginConfig oldLoginConfig = this.loginConfig;
/* 2051 */     this.loginConfig = config;
/* 2052 */     this.support.firePropertyChange("loginConfig", oldLoginConfig, this.loginConfig);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NamingResourcesImpl getNamingResources()
/*      */   {
/* 2063 */     if (this.namingResources == null) {
/* 2064 */       setNamingResources(new NamingResourcesImpl());
/*      */     }
/* 2066 */     return this.namingResources;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNamingResources(NamingResourcesImpl namingResources)
/*      */   {
/* 2079 */     NamingResourcesImpl oldNamingResources = this.namingResources;
/* 2080 */     this.namingResources = namingResources;
/* 2081 */     if (namingResources != null) {
/* 2082 */       namingResources.setContainer(this);
/*      */     }
/* 2084 */     this.support.firePropertyChange("namingResources", oldNamingResources, this.namingResources);
/*      */     
/*      */ 
/* 2087 */     if ((getState() == LifecycleState.NEW) || 
/* 2088 */       (getState() == LifecycleState.INITIALIZING) || 
/* 2089 */       (getState() == LifecycleState.INITIALIZED))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2100 */       return;
/*      */     }
/*      */     
/* 2103 */     if (oldNamingResources != null) {
/*      */       try {
/* 2105 */         oldNamingResources.stop();
/* 2106 */         oldNamingResources.destroy();
/*      */       } catch (LifecycleException e) {
/* 2108 */         log.error(sm.getString("standardContext.namingResource.destroy.fail"), e);
/*      */       }
/*      */     }
/* 2111 */     if (namingResources != null) {
/*      */       try {
/* 2113 */         namingResources.init();
/* 2114 */         namingResources.start();
/*      */       } catch (LifecycleException e) {
/* 2116 */         log.error(sm.getString("standardContext.namingResource.init.fail"), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPath()
/*      */   {
/* 2127 */     return this.path;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPath(String path)
/*      */   {
/* 2138 */     boolean invalid = false;
/* 2139 */     if ((path == null) || (path.equals("/"))) {
/* 2140 */       invalid = true;
/* 2141 */       this.path = "";
/* 2142 */     } else if ((path.isEmpty()) || (path.startsWith("/"))) {
/* 2143 */       this.path = path;
/*      */     } else {
/* 2145 */       invalid = true;
/* 2146 */       this.path = ("/" + path);
/*      */     }
/* 2148 */     if (this.path.endsWith("/")) {
/* 2149 */       invalid = true;
/* 2150 */       this.path = this.path.substring(0, this.path.length() - 1);
/*      */     }
/* 2152 */     if (invalid) {
/* 2153 */       log.warn(sm.getString("standardContext.pathInvalid", new Object[] { path, this.path }));
/*      */     }
/*      */     
/* 2156 */     this.encodedPath = URLEncoder.DEFAULT.encode(this.path, StandardCharsets.UTF_8);
/* 2157 */     if (getName() == null) {
/* 2158 */       setName(this.path);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPublicId()
/*      */   {
/* 2169 */     return this.publicId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPublicId(String publicId)
/*      */   {
/* 2182 */     if (log.isDebugEnabled()) {
/* 2183 */       log.debug("Setting deployment descriptor public ID to '" + publicId + "'");
/*      */     }
/*      */     
/*      */ 
/* 2187 */     String oldPublicId = this.publicId;
/* 2188 */     this.publicId = publicId;
/* 2189 */     this.support.firePropertyChange("publicId", oldPublicId, publicId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getReloadable()
/*      */   {
/* 2199 */     return this.reloadable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getOverride()
/*      */   {
/* 2208 */     return this.override;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getOriginalDocBase()
/*      */   {
/* 2218 */     return this.originalDocBase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOriginalDocBase(String docBase)
/*      */   {
/* 2229 */     this.originalDocBase = docBase;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassLoader getParentClassLoader()
/*      */   {
/* 2240 */     if (this.parentClassLoader != null) {
/* 2241 */       return this.parentClassLoader;
/*      */     }
/* 2243 */     if (getPrivileged())
/* 2244 */       return getClass().getClassLoader();
/* 2245 */     if (this.parent != null) {
/* 2246 */       return this.parent.getParentClassLoader();
/*      */     }
/* 2248 */     return ClassLoader.getSystemClassLoader();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getPrivileged()
/*      */   {
/* 2257 */     return this.privileged;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrivileged(boolean privileged)
/*      */   {
/* 2269 */     boolean oldPrivileged = this.privileged;
/* 2270 */     this.privileged = privileged;
/* 2271 */     this.support.firePropertyChange("privileged", oldPrivileged, this.privileged);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReloadable(boolean reloadable)
/*      */   {
/* 2286 */     boolean oldReloadable = this.reloadable;
/* 2287 */     this.reloadable = reloadable;
/* 2288 */     this.support.firePropertyChange("reloadable", oldReloadable, this.reloadable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOverride(boolean override)
/*      */   {
/* 2303 */     boolean oldOverride = this.override;
/* 2304 */     this.override = override;
/* 2305 */     this.support.firePropertyChange("override", oldOverride, this.override);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReplaceWelcomeFiles(boolean replaceWelcomeFiles)
/*      */   {
/* 2319 */     boolean oldReplaceWelcomeFiles = this.replaceWelcomeFiles;
/* 2320 */     this.replaceWelcomeFiles = replaceWelcomeFiles;
/* 2321 */     this.support.firePropertyChange("replaceWelcomeFiles", oldReplaceWelcomeFiles, this.replaceWelcomeFiles);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletContext getServletContext()
/*      */   {
/* 2333 */     if (this.context == null) {
/* 2334 */       this.context = new ApplicationContext(this);
/* 2335 */       if (this.altDDName != null) {
/* 2336 */         this.context.setAttribute("org.apache.catalina.deploy.alt_dd", this.altDDName);
/*      */       }
/*      */     }
/* 2339 */     return this.context.getFacade();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSessionTimeout()
/*      */   {
/* 2349 */     return this.sessionTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionTimeout(int timeout)
/*      */   {
/* 2362 */     int oldSessionTimeout = this.sessionTimeout;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2368 */     this.sessionTimeout = (timeout == 0 ? -1 : timeout);
/* 2369 */     this.support.firePropertyChange("sessionTimeout", oldSessionTimeout, this.sessionTimeout);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSwallowOutput()
/*      */   {
/* 2381 */     return this.swallowOutput;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSwallowOutput(boolean swallowOutput)
/*      */   {
/* 2395 */     boolean oldSwallowOutput = this.swallowOutput;
/* 2396 */     this.swallowOutput = swallowOutput;
/* 2397 */     this.support.firePropertyChange("swallowOutput", oldSwallowOutput, this.swallowOutput);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getUnloadDelay()
/*      */   {
/* 2408 */     return this.unloadDelay;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUnloadDelay(long unloadDelay)
/*      */   {
/* 2422 */     long oldUnloadDelay = this.unloadDelay;
/* 2423 */     this.unloadDelay = unloadDelay;
/* 2424 */     this.support.firePropertyChange("unloadDelay", 
/* 2425 */       Long.valueOf(oldUnloadDelay), 
/* 2426 */       Long.valueOf(this.unloadDelay));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUnpackWAR()
/*      */   {
/* 2435 */     return this.unpackWAR;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUnpackWAR(boolean unpackWAR)
/*      */   {
/* 2445 */     this.unpackWAR = unpackWAR;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getCopyXML()
/*      */   {
/* 2457 */     return this.copyXML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCopyXML(boolean copyXML)
/*      */   {
/* 2468 */     this.copyXML = copyXML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getWrapperClass()
/*      */   {
/* 2478 */     return this.wrapperClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWrapperClass(String wrapperClassName)
/*      */   {
/* 2494 */     this.wrapperClassName = wrapperClassName;
/*      */     try
/*      */     {
/* 2497 */       this.wrapperClass = Class.forName(wrapperClassName);
/* 2498 */       if (!StandardWrapper.class.isAssignableFrom(this.wrapperClass))
/*      */       {
/* 2500 */         throw new IllegalArgumentException(sm.getString("standardContext.invalidWrapperClass", new Object[] { wrapperClassName }));
/*      */       }
/*      */     }
/*      */     catch (ClassNotFoundException cnfe) {
/* 2504 */       throw new IllegalArgumentException(cnfe.getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public WebResourceRoot getResources()
/*      */   {
/* 2511 */     Lock readLock = this.resourcesLock.readLock();
/* 2512 */     readLock.lock();
/*      */     try {
/* 2514 */       return this.resources;
/*      */     } finally {
/* 2516 */       readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setResources(WebResourceRoot resources)
/*      */   {
/* 2524 */     Lock writeLock = this.resourcesLock.writeLock();
/* 2525 */     writeLock.lock();
/* 2526 */     WebResourceRoot oldResources = null;
/*      */     try {
/* 2528 */       if (getState().isAvailable())
/*      */       {
/* 2530 */         throw new IllegalStateException(sm.getString("standardContext.resourcesStart"));
/*      */       }
/*      */       
/* 2533 */       oldResources = this.resources;
/* 2534 */       if (oldResources == resources) {
/* 2535 */         return;
/*      */       }
/*      */       
/* 2538 */       this.resources = resources;
/* 2539 */       if (oldResources != null) {
/* 2540 */         oldResources.setContext(null);
/*      */       }
/* 2542 */       if (resources != null) {
/* 2543 */         resources.setContext(this);
/*      */       }
/*      */       
/* 2546 */       this.support.firePropertyChange("resources", oldResources, resources);
/*      */     }
/*      */     finally {
/* 2549 */       writeLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public JspConfigDescriptor getJspConfigDescriptor()
/*      */   {
/* 2556 */     return this.jspConfigDescriptor;
/*      */   }
/*      */   
/*      */   public void setJspConfigDescriptor(JspConfigDescriptor descriptor)
/*      */   {
/* 2561 */     this.jspConfigDescriptor = descriptor;
/*      */   }
/*      */   
/*      */   public ThreadBindingListener getThreadBindingListener()
/*      */   {
/* 2566 */     return this.threadBindingListener;
/*      */   }
/*      */   
/*      */   public void setThreadBindingListener(ThreadBindingListener threadBindingListener)
/*      */   {
/* 2571 */     this.threadBindingListener = threadBindingListener;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getJndiExceptionOnFailedWrite()
/*      */   {
/* 2582 */     return this.jndiExceptionOnFailedWrite;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setJndiExceptionOnFailedWrite(boolean jndiExceptionOnFailedWrite)
/*      */   {
/* 2594 */     this.jndiExceptionOnFailedWrite = jndiExceptionOnFailedWrite;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCharsetMapperClass()
/*      */   {
/* 2602 */     return this.charsetMapperClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharsetMapperClass(String mapper)
/*      */   {
/* 2613 */     String oldCharsetMapperClass = this.charsetMapperClass;
/* 2614 */     this.charsetMapperClass = mapper;
/* 2615 */     this.support.firePropertyChange("charsetMapperClass", oldCharsetMapperClass, this.charsetMapperClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getWorkPath()
/*      */   {
/* 2628 */     if (getWorkDir() == null) {
/* 2629 */       return null;
/*      */     }
/* 2631 */     File workDir = new File(getWorkDir());
/* 2632 */     if (!workDir.isAbsolute()) {
/*      */       try
/*      */       {
/* 2635 */         workDir = new File(getCatalinaBase().getCanonicalFile(), getWorkDir());
/*      */       } catch (IOException e) {
/* 2637 */         log.warn(sm.getString("standardContext.workPath", new Object[] { getName() }), e);
/*      */       }
/*      */     }
/*      */     
/* 2641 */     return workDir.getAbsolutePath();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getWorkDir()
/*      */   {
/* 2648 */     return this.workDir;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWorkDir(String workDir)
/*      */   {
/* 2659 */     this.workDir = workDir;
/*      */     
/* 2661 */     if (getState().isAvailable()) {
/* 2662 */       postWorkDirectory();
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean getClearReferencesRmiTargets()
/*      */   {
/* 2668 */     return this.clearReferencesRmiTargets;
/*      */   }
/*      */   
/*      */   public void setClearReferencesRmiTargets(boolean clearReferencesRmiTargets)
/*      */   {
/* 2673 */     boolean oldClearReferencesRmiTargets = this.clearReferencesRmiTargets;
/* 2674 */     this.clearReferencesRmiTargets = clearReferencesRmiTargets;
/* 2675 */     this.support.firePropertyChange("clearReferencesRmiTargets", oldClearReferencesRmiTargets, this.clearReferencesRmiTargets);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesStopThreads()
/*      */   {
/* 2684 */     return this.clearReferencesStopThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesStopThreads(boolean clearReferencesStopThreads)
/*      */   {
/* 2696 */     boolean oldClearReferencesStopThreads = this.clearReferencesStopThreads;
/* 2697 */     this.clearReferencesStopThreads = clearReferencesStopThreads;
/* 2698 */     this.support.firePropertyChange("clearReferencesStopThreads", oldClearReferencesStopThreads, this.clearReferencesStopThreads);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesStopTimerThreads()
/*      */   {
/* 2709 */     return this.clearReferencesStopTimerThreads;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesStopTimerThreads(boolean clearReferencesStopTimerThreads)
/*      */   {
/* 2721 */     boolean oldClearReferencesStopTimerThreads = this.clearReferencesStopTimerThreads;
/*      */     
/* 2723 */     this.clearReferencesStopTimerThreads = clearReferencesStopTimerThreads;
/* 2724 */     this.support.firePropertyChange("clearReferencesStopTimerThreads", oldClearReferencesStopTimerThreads, this.clearReferencesStopTimerThreads);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesHttpClientKeepAliveThread()
/*      */   {
/* 2735 */     return this.clearReferencesHttpClientKeepAliveThread;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClearReferencesHttpClientKeepAliveThread(boolean clearReferencesHttpClientKeepAliveThread)
/*      */   {
/* 2747 */     this.clearReferencesHttpClientKeepAliveThread = clearReferencesHttpClientKeepAliveThread;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getRenewThreadsWhenStoppingContext()
/*      */   {
/* 2753 */     return this.renewThreadsWhenStoppingContext;
/*      */   }
/*      */   
/*      */   public void setRenewThreadsWhenStoppingContext(boolean renewThreadsWhenStoppingContext)
/*      */   {
/* 2758 */     boolean oldRenewThreadsWhenStoppingContext = this.renewThreadsWhenStoppingContext;
/*      */     
/* 2760 */     this.renewThreadsWhenStoppingContext = renewThreadsWhenStoppingContext;
/* 2761 */     this.support.firePropertyChange("renewThreadsWhenStoppingContext", oldRenewThreadsWhenStoppingContext, this.renewThreadsWhenStoppingContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesObjectStreamClassCaches()
/*      */   {
/* 2768 */     return this.clearReferencesObjectStreamClassCaches;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setClearReferencesObjectStreamClassCaches(boolean clearReferencesObjectStreamClassCaches)
/*      */   {
/* 2774 */     boolean oldClearReferencesObjectStreamClassCaches = this.clearReferencesObjectStreamClassCaches;
/*      */     
/* 2776 */     this.clearReferencesObjectStreamClassCaches = clearReferencesObjectStreamClassCaches;
/* 2777 */     this.support.firePropertyChange("clearReferencesObjectStreamClassCaches", oldClearReferencesObjectStreamClassCaches, this.clearReferencesObjectStreamClassCaches);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getClearReferencesThreadLocals()
/*      */   {
/* 2784 */     return this.clearReferencesThreadLocals;
/*      */   }
/*      */   
/*      */   public void setClearReferencesThreadLocals(boolean clearReferencesThreadLocals)
/*      */   {
/* 2789 */     boolean oldClearReferencesThreadLocals = this.clearReferencesThreadLocals;
/* 2790 */     this.clearReferencesThreadLocals = clearReferencesThreadLocals;
/* 2791 */     this.support.firePropertyChange("clearReferencesThreadLocals", oldClearReferencesThreadLocals, this.clearReferencesThreadLocals);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getSkipMemoryLeakChecksOnJvmShutdown()
/*      */   {
/* 2798 */     return this.skipMemoryLeakChecksOnJvmShutdown;
/*      */   }
/*      */   
/*      */   public void setSkipMemoryLeakChecksOnJvmShutdown(boolean skipMemoryLeakChecksOnJvmShutdown)
/*      */   {
/* 2803 */     this.skipMemoryLeakChecksOnJvmShutdown = skipMemoryLeakChecksOnJvmShutdown;
/*      */   }
/*      */   
/*      */   public Boolean getFailCtxIfServletStartFails()
/*      */   {
/* 2808 */     return this.failCtxIfServletStartFails;
/*      */   }
/*      */   
/*      */   public void setFailCtxIfServletStartFails(Boolean failCtxIfServletStartFails)
/*      */   {
/* 2813 */     Boolean oldFailCtxIfServletStartFails = this.failCtxIfServletStartFails;
/* 2814 */     this.failCtxIfServletStartFails = failCtxIfServletStartFails;
/* 2815 */     this.support.firePropertyChange("failCtxIfServletStartFails", oldFailCtxIfServletStartFails, failCtxIfServletStartFails);
/*      */   }
/*      */   
/*      */ 
/*      */   protected boolean getComputedFailCtxIfServletStartFails()
/*      */   {
/* 2821 */     if (this.failCtxIfServletStartFails != null) {
/* 2822 */       return this.failCtxIfServletStartFails.booleanValue();
/*      */     }
/*      */     
/* 2825 */     if ((getParent() instanceof StandardHost)) {
/* 2826 */       return ((StandardHost)getParent()).isFailCtxIfServletStartFails();
/*      */     }
/*      */     
/* 2829 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addApplicationListener(String listener)
/*      */   {
/* 2843 */     synchronized (this.applicationListenersLock) {
/* 2844 */       String[] results = new String[this.applicationListeners.length + 1];
/* 2845 */       for (int i = 0; i < this.applicationListeners.length; i++) {
/* 2846 */         if (listener.equals(this.applicationListeners[i])) {
/* 2847 */           log.info(sm.getString("standardContext.duplicateListener", new Object[] { listener }));
/* 2848 */           return;
/*      */         }
/* 2850 */         results[i] = this.applicationListeners[i];
/*      */       }
/* 2852 */       results[this.applicationListeners.length] = listener;
/* 2853 */       this.applicationListeners = results;
/*      */     }
/* 2855 */     fireContainerEvent("addApplicationListener", listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addApplicationParameter(ApplicationParameter parameter)
/*      */   {
/* 2868 */     synchronized (this.applicationParametersLock) {
/* 2869 */       String newName = parameter.getName();
/* 2870 */       for (ApplicationParameter p : this.applicationParameters) {
/* 2871 */         if ((newName.equals(p.getName())) && (!p.getOverride())) {
/* 2872 */           return;
/*      */         }
/*      */       }
/* 2875 */       ApplicationParameter[] results = (ApplicationParameter[])Arrays.copyOf(this.applicationParameters, this.applicationParameters.length + 1);
/*      */       
/* 2877 */       results[this.applicationParameters.length] = parameter;
/* 2878 */       this.applicationParameters = results;
/*      */     }
/* 2880 */     fireContainerEvent("addApplicationParameter", parameter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addChild(Container child)
/*      */   {
/* 2898 */     Wrapper oldJspServlet = null;
/*      */     
/* 2900 */     if (!(child instanceof Wrapper))
/*      */     {
/* 2902 */       throw new IllegalArgumentException(sm.getString("standardContext.notWrapper"));
/*      */     }
/*      */     
/* 2905 */     boolean isJspServlet = "jsp".equals(child.getName());
/*      */     
/*      */ 
/* 2908 */     if (isJspServlet) {
/* 2909 */       oldJspServlet = (Wrapper)findChild("jsp");
/* 2910 */       if (oldJspServlet != null) {
/* 2911 */         removeChild(oldJspServlet);
/*      */       }
/*      */     }
/*      */     
/* 2915 */     super.addChild(child);
/*      */     
/* 2917 */     if ((isJspServlet) && (oldJspServlet != null))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2922 */       String[] jspMappings = oldJspServlet.findMappings();
/* 2923 */       for (int i = 0; (jspMappings != null) && (i < jspMappings.length); i++) {
/* 2924 */         addServletMappingDecoded(jspMappings[i], child.getName());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addConstraint(SecurityConstraint constraint)
/*      */   {
/* 2939 */     SecurityCollection[] collections = constraint.findCollections();
/* 2940 */     for (SecurityCollection collection : collections) {
/* 2941 */       String[] patterns = collection.findPatterns();
/* 2942 */       for (int j = 0; j < patterns.length; j++) {
/* 2943 */         patterns[j] = adjustURLPattern(patterns[j]);
/* 2944 */         if (!validateURLPattern(patterns[j]))
/*      */         {
/*      */ 
/* 2947 */           throw new IllegalArgumentException(sm.getString("standardContext.securityConstraint.pattern", new Object[] { patterns[j] }));
/*      */         }
/*      */       }
/*      */       
/* 2951 */       if ((collection.findMethods().length > 0) && 
/* 2952 */         (collection.findOmittedMethods().length > 0)) {
/* 2953 */         throw new IllegalArgumentException(sm.getString("standardContext.securityConstraint.mixHttpMethod"));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2959 */     synchronized (this.constraintsLock) {
/* 2960 */       SecurityConstraint[] results = (SecurityConstraint[])Arrays.copyOf(this.constraints, this.constraints.length + 1);
/* 2961 */       results[this.constraints.length] = constraint;
/* 2962 */       this.constraints = results;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addErrorPage(ErrorPage errorPage)
/*      */   {
/* 2977 */     if (errorPage == null)
/*      */     {
/* 2979 */       throw new IllegalArgumentException(sm.getString("standardContext.errorPage.required"));
/*      */     }
/* 2981 */     String location = errorPage.getLocation();
/* 2982 */     if ((location != null) && (!location.startsWith("/"))) {
/* 2983 */       if (isServlet22()) {
/* 2984 */         if (log.isDebugEnabled()) {
/* 2985 */           log.debug(sm.getString("standardContext.errorPage.warning", new Object[] { location }));
/*      */         }
/*      */         
/* 2988 */         errorPage.setLocation("/" + location);
/*      */       }
/*      */       else {
/* 2991 */         throw new IllegalArgumentException(sm.getString("standardContext.errorPage.error", new Object[] { location }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2996 */     this.errorPageSupport.add(errorPage);
/* 2997 */     fireContainerEvent("addErrorPage", errorPage);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addFilterDef(FilterDef filterDef)
/*      */   {
/* 3009 */     synchronized (this.filterDefs) {
/* 3010 */       this.filterDefs.put(filterDef.getFilterName(), filterDef);
/*      */     }
/* 3012 */     fireContainerEvent("addFilterDef", filterDef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addFilterMap(FilterMap filterMap)
/*      */   {
/* 3029 */     validateFilterMap(filterMap);
/*      */     
/* 3031 */     this.filterMaps.add(filterMap);
/* 3032 */     fireContainerEvent("addFilterMap", filterMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addFilterMapBefore(FilterMap filterMap)
/*      */   {
/* 3048 */     validateFilterMap(filterMap);
/*      */     
/* 3050 */     this.filterMaps.addBefore(filterMap);
/* 3051 */     fireContainerEvent("addFilterMap", filterMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void validateFilterMap(FilterMap filterMap)
/*      */   {
/* 3062 */     String filterName = filterMap.getFilterName();
/* 3063 */     String[] servletNames = filterMap.getServletNames();
/* 3064 */     String[] urlPatterns = filterMap.getURLPatterns();
/* 3065 */     if (findFilterDef(filterName) == null)
/*      */     {
/* 3067 */       throw new IllegalArgumentException(sm.getString("standardContext.filterMap.name", new Object[] { filterName }));
/*      */     }
/*      */     
/* 3070 */     if ((!filterMap.getMatchAllServletNames()) && 
/* 3071 */       (!filterMap.getMatchAllUrlPatterns()) && (servletNames.length == 0) && (urlPatterns.length == 0))
/*      */     {
/*      */ 
/* 3074 */       throw new IllegalArgumentException(sm.getString("standardContext.filterMap.either"));
/*      */     }
/* 3076 */     for (String urlPattern : urlPatterns) {
/* 3077 */       if (!validateURLPattern(urlPattern))
/*      */       {
/* 3079 */         throw new IllegalArgumentException(sm.getString("standardContext.filterMap.pattern", new Object[] { urlPattern }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addLocaleEncodingMappingParameter(String locale, String encoding)
/*      */   {
/* 3094 */     getCharsetMapper().addCharsetMappingFromDeploymentDescriptor(locale, encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addMessageDestination(MessageDestination md)
/*      */   {
/* 3105 */     synchronized (this.messageDestinations) {
/* 3106 */       this.messageDestinations.put(md.getName(), md);
/*      */     }
/* 3108 */     fireContainerEvent("addMessageDestination", md.getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void addMessageDestinationRef(MessageDestinationRef mdr)
/*      */   {
/* 3123 */     getNamingResources().addMessageDestinationRef(mdr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addMimeMapping(String extension, String mimeType)
/*      */   {
/* 3137 */     synchronized (this.mimeMappings) {
/* 3138 */       this.mimeMappings.put(extension.toLowerCase(Locale.ENGLISH), mimeType);
/*      */     }
/* 3140 */     fireContainerEvent("addMimeMapping", extension);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addParameter(String name, String value)
/*      */   {
/* 3158 */     if ((name == null) || (value == null))
/*      */     {
/* 3160 */       throw new IllegalArgumentException(sm.getString("standardContext.parameter.required"));
/*      */     }
/*      */     
/*      */ 
/* 3164 */     String oldValue = (String)this.parameters.putIfAbsent(name, value);
/*      */     
/* 3166 */     if (oldValue != null)
/*      */     {
/* 3168 */       throw new IllegalArgumentException(sm.getString("standardContext.parameter.duplicate", new Object[] { name }));
/*      */     }
/*      */     
/* 3171 */     fireContainerEvent("addParameter", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRoleMapping(String role, String link)
/*      */   {
/* 3184 */     synchronized (this.roleMappings) {
/* 3185 */       this.roleMappings.put(role, link);
/*      */     }
/* 3187 */     fireContainerEvent("addRoleMapping", role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSecurityRole(String role)
/*      */   {
/* 3200 */     synchronized (this.securityRolesLock) {
/* 3201 */       String[] results = (String[])Arrays.copyOf(this.securityRoles, this.securityRoles.length + 1);
/* 3202 */       results[this.securityRoles.length] = role;
/* 3203 */       this.securityRoles = results;
/*      */     }
/* 3205 */     fireContainerEvent("addSecurityRole", role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addServletMappingDecoded(String pattern, String name, boolean jspWildCard)
/*      */   {
/* 3226 */     if (findChild(name) == null)
/*      */     {
/* 3228 */       throw new IllegalArgumentException(sm.getString("standardContext.servletMap.name", new Object[] { name }));
/*      */     }
/* 3230 */     String adjustedPattern = adjustURLPattern(pattern);
/* 3231 */     if (!validateURLPattern(adjustedPattern))
/*      */     {
/* 3233 */       throw new IllegalArgumentException(sm.getString("standardContext.servletMap.pattern", new Object[] { adjustedPattern }));
/*      */     }
/*      */     
/*      */ 
/* 3237 */     synchronized (this.servletMappingsLock) {
/* 3238 */       String name2 = (String)this.servletMappings.get(adjustedPattern);
/* 3239 */       if (name2 != null)
/*      */       {
/* 3241 */         Wrapper wrapper = (Wrapper)findChild(name2);
/* 3242 */         wrapper.removeMapping(adjustedPattern);
/*      */       }
/* 3244 */       this.servletMappings.put(adjustedPattern, name);
/*      */     }
/* 3246 */     Wrapper wrapper = (Wrapper)findChild(name);
/* 3247 */     wrapper.addMapping(adjustedPattern);
/*      */     
/* 3249 */     fireContainerEvent("addServletMapping", adjustedPattern);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addWatchedResource(String name)
/*      */   {
/* 3261 */     synchronized (this.watchedResourcesLock) {
/* 3262 */       String[] results = (String[])Arrays.copyOf(this.watchedResources, this.watchedResources.length + 1);
/* 3263 */       results[this.watchedResources.length] = name;
/* 3264 */       this.watchedResources = results;
/*      */     }
/* 3266 */     fireContainerEvent("addWatchedResource", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addWelcomeFile(String name)
/*      */   {
/* 3278 */     synchronized (this.welcomeFilesLock)
/*      */     {
/*      */ 
/* 3281 */       if (this.replaceWelcomeFiles) {
/* 3282 */         fireContainerEvent("clearWelcomeFiles", null);
/* 3283 */         this.welcomeFiles = new String[0];
/* 3284 */         setReplaceWelcomeFiles(false);
/*      */       }
/* 3286 */       String[] results = (String[])Arrays.copyOf(this.welcomeFiles, this.welcomeFiles.length + 1);
/* 3287 */       results[this.welcomeFiles.length] = name;
/* 3288 */       this.welcomeFiles = results;
/*      */     }
/* 3290 */     if (getState().equals(LifecycleState.STARTED)) {
/* 3291 */       fireContainerEvent("addWelcomeFile", name);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addWrapperLifecycle(String listener)
/*      */   {
/* 3305 */     synchronized (this.wrapperLifecyclesLock) {
/* 3306 */       String[] results = (String[])Arrays.copyOf(this.wrapperLifecycles, this.wrapperLifecycles.length + 1);
/* 3307 */       results[this.wrapperLifecycles.length] = listener;
/* 3308 */       this.wrapperLifecycles = results;
/*      */     }
/* 3310 */     fireContainerEvent("addWrapperLifecycle", listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addWrapperListener(String listener)
/*      */   {
/* 3324 */     synchronized (this.wrapperListenersLock) {
/* 3325 */       String[] results = (String[])Arrays.copyOf(this.wrapperListeners, this.wrapperListeners.length + 1);
/* 3326 */       results[this.wrapperListeners.length] = listener;
/* 3327 */       this.wrapperListeners = results;
/*      */     }
/* 3329 */     fireContainerEvent("addWrapperListener", listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Wrapper createWrapper()
/*      */   {
/* 3343 */     Wrapper wrapper = null;
/* 3344 */     if (this.wrapperClass != null) {
/*      */       try {
/* 3346 */         wrapper = (Wrapper)this.wrapperClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */       } catch (Throwable t) {
/* 3348 */         ExceptionUtils.handleThrowable(t);
/* 3349 */         log.error(sm.getString("standardContext.createWrapper.error"), t);
/* 3350 */         return null;
/*      */       }
/*      */     } else {
/* 3353 */       wrapper = new StandardWrapper();
/*      */     }
/*      */     
/* 3356 */     synchronized (this.wrapperLifecyclesLock) {
/* 3357 */       for (String wrapperLifecycle : this.wrapperLifecycles) {
/*      */         try {
/* 3359 */           Class<?> clazz = Class.forName(wrapperLifecycle);
/*      */           
/* 3361 */           LifecycleListener listener = (LifecycleListener)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 3362 */           wrapper.addLifecycleListener(listener);
/*      */         } catch (Throwable t) {
/* 3364 */           ExceptionUtils.handleThrowable(t);
/* 3365 */           log.error(sm.getString("standardContext.createWrapper.listenerError"), t);
/* 3366 */           return null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3371 */     synchronized (this.wrapperListenersLock) {
/* 3372 */       for (String wrapperListener : this.wrapperListeners) {
/*      */         try {
/* 3374 */           Class<?> clazz = Class.forName(wrapperListener);
/*      */           
/* 3376 */           ContainerListener listener = (ContainerListener)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 3377 */           wrapper.addContainerListener(listener);
/*      */         } catch (Throwable t) {
/* 3379 */           ExceptionUtils.handleThrowable(t);
/* 3380 */           log.error(sm.getString("standardContext.createWrapper.containerListenerError"), t);
/* 3381 */           return null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3386 */     return wrapper;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] findApplicationListeners()
/*      */   {
/* 3396 */     return this.applicationListeners;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public ApplicationParameter[] findApplicationParameters()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 24	org/apache/catalina/core/StandardContext:applicationParametersLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 23	org/apache/catalina/core/StandardContext:applicationParameters	[Lorg/apache/tomcat/util/descriptor/web/ApplicationParameter;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3406	-> byte code offset #0
/*      */     //   Java source line #3407	-> byte code offset #7
/*      */     //   Java source line #3408	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	StandardContext
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public SecurityConstraint[] findConstraints()
/*      */   {
/* 3419 */     return this.constraints;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ErrorPage findErrorPage(int errorCode)
/*      */   {
/* 3431 */     return this.errorPageSupport.find(errorCode);
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public ErrorPage findErrorPage(String exceptionType)
/*      */   {
/* 3438 */     return this.errorPageSupport.find(exceptionType);
/*      */   }
/*      */   
/*      */ 
/*      */   public ErrorPage findErrorPage(Throwable exceptionType)
/*      */   {
/* 3444 */     return this.errorPageSupport.find(exceptionType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ErrorPage[] findErrorPages()
/*      */   {
/* 3454 */     return this.errorPageSupport.findAll();
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public FilterDef findFilterDef(String filterName)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 51	org/apache/catalina/core/StandardContext:filterDefs	Ljava/util/Map;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 51	org/apache/catalina/core/StandardContext:filterDefs	Ljava/util/Map;
/*      */     //   11: aload_1
/*      */     //   12: invokeinterface 428 2 0
/*      */     //   17: checkcast 453	org/apache/tomcat/util/descriptor/web/FilterDef
/*      */     //   20: aload_2
/*      */     //   21: monitorexit
/*      */     //   22: areturn
/*      */     //   23: astore_3
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: aload_3
/*      */     //   27: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3466	-> byte code offset #0
/*      */     //   Java source line #3467	-> byte code offset #7
/*      */     //   Java source line #3468	-> byte code offset #23
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	28	0	this	StandardContext
/*      */     //   0	28	1	filterName	String
/*      */     //   5	20	2	Ljava/lang/Object;	Object
/*      */     //   23	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	22	23	finally
/*      */     //   23	26	23	finally
/*      */   }
/*      */   
/*      */   public FilterDef[] findFilterDefs()
/*      */   {
/* 3477 */     synchronized (this.filterDefs) {
/* 3478 */       FilterDef[] results = new FilterDef[this.filterDefs.size()];
/* 3479 */       return (FilterDef[])this.filterDefs.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FilterMap[] findFilterMaps()
/*      */   {
/* 3489 */     return this.filterMaps.asArray();
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public MessageDestination findMessageDestination(String name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 65	org/apache/catalina/core/StandardContext:messageDestinations	Ljava/util/HashMap;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 65	org/apache/catalina/core/StandardContext:messageDestinations	Ljava/util/HashMap;
/*      */     //   11: aload_1
/*      */     //   12: invokevirtual 459	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   15: checkcast 460	org/apache/tomcat/util/descriptor/web/MessageDestination
/*      */     //   18: aload_2
/*      */     //   19: monitorexit
/*      */     //   20: areturn
/*      */     //   21: astore_3
/*      */     //   22: aload_2
/*      */     //   23: monitorexit
/*      */     //   24: aload_3
/*      */     //   25: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3500	-> byte code offset #0
/*      */     //   Java source line #3501	-> byte code offset #7
/*      */     //   Java source line #3502	-> byte code offset #21
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	26	0	this	StandardContext
/*      */     //   0	26	1	name	String
/*      */     //   5	18	2	Ljava/lang/Object;	Object
/*      */     //   21	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	20	21	finally
/*      */     //   21	24	21	finally
/*      */   }
/*      */   
/*      */   public MessageDestination[] findMessageDestinations()
/*      */   {
/* 3512 */     synchronized (this.messageDestinations)
/*      */     {
/* 3514 */       MessageDestination[] results = new MessageDestination[this.messageDestinations.size()];
/* 3515 */       return (MessageDestination[])this.messageDestinations.values().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public MessageDestinationRef findMessageDestinationRef(String name)
/*      */   {
/* 3531 */     return getNamingResources().findMessageDestinationRef(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public MessageDestinationRef[] findMessageDestinationRefs()
/*      */   {
/* 3545 */     return getNamingResources().findMessageDestinationRefs();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findMimeMapping(String extension)
/*      */   {
/* 3557 */     return (String)this.mimeMappings.get(extension.toLowerCase(Locale.ENGLISH));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] findMimeMappings()
/*      */   {
/* 3567 */     synchronized (this.mimeMappings) {
/* 3568 */       String[] results = new String[this.mimeMappings.size()];
/* 3569 */       return (String[])this.mimeMappings.keySet().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findParameter(String name)
/*      */   {
/* 3582 */     return (String)this.parameters.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] findParameters()
/*      */   {
/* 3593 */     return (String[])this.parameters.keySet().toArray(new String[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findRoleMapping(String role)
/*      */   {
/* 3607 */     String realRole = null;
/* 3608 */     synchronized (this.roleMappings) {
/* 3609 */       realRole = (String)this.roleMappings.get(role);
/*      */     }
/* 3611 */     if (realRole != null) {
/* 3612 */       return realRole;
/*      */     }
/* 3614 */     return role;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean findSecurityRole(String role)
/*      */   {
/* 3628 */     synchronized (this.securityRolesLock) {
/* 3629 */       for (String securityRole : this.securityRoles) {
/* 3630 */         if (role.equals(securityRole)) {
/* 3631 */           return true;
/*      */         }
/*      */       }
/*      */     }
/* 3635 */     return false;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String[] findSecurityRoles()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 81	org/apache/catalina/core/StandardContext:securityRolesLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 80	org/apache/catalina/core/StandardContext:securityRoles	[Ljava/lang/String;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3646	-> byte code offset #0
/*      */     //   Java source line #3647	-> byte code offset #7
/*      */     //   Java source line #3648	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	StandardContext
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String findServletMapping(String pattern)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 83	org/apache/catalina/core/StandardContext:servletMappingsLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_2
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 82	org/apache/catalina/core/StandardContext:servletMappings	Ljava/util/Map;
/*      */     //   11: aload_1
/*      */     //   12: invokeinterface 428 2 0
/*      */     //   17: checkcast 7	java/lang/String
/*      */     //   20: aload_2
/*      */     //   21: monitorexit
/*      */     //   22: areturn
/*      */     //   23: astore_3
/*      */     //   24: aload_2
/*      */     //   25: monitorexit
/*      */     //   26: aload_3
/*      */     //   27: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3660	-> byte code offset #0
/*      */     //   Java source line #3661	-> byte code offset #7
/*      */     //   Java source line #3662	-> byte code offset #23
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	28	0	this	StandardContext
/*      */     //   0	28	1	pattern	String
/*      */     //   5	20	2	Ljava/lang/Object;	Object
/*      */     //   23	4	3	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	22	23	finally
/*      */     //   23	26	23	finally
/*      */   }
/*      */   
/*      */   public String[] findServletMappings()
/*      */   {
/* 3672 */     synchronized (this.servletMappingsLock) {
/* 3673 */       String[] results = new String[this.servletMappings.size()];
/* 3674 */       return (String[])this.servletMappings.keySet().toArray(results);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String findStatusPage(int status)
/*      */   {
/* 3683 */     ErrorPage errorPage = findErrorPage(status);
/* 3684 */     if (errorPage != null) {
/* 3685 */       return errorPage.getLocation();
/*      */     }
/* 3687 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public int[] findStatusPages()
/*      */   {
/* 3694 */     ErrorPage[] errorPages = findErrorPages();
/* 3695 */     int size = errorPages.length;
/* 3696 */     int[] temp = new int[size];
/* 3697 */     int count = 0;
/* 3698 */     for (int i = 0; i < size; i++) {
/* 3699 */       if (errorPages[i].getExceptionType() == null) {
/* 3700 */         temp[(count++)] = errorPages[i].getErrorCode();
/*      */       }
/*      */     }
/* 3703 */     int[] result = new int[count];
/* 3704 */     System.arraycopy(temp, 0, result, 0, count);
/* 3705 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean findWelcomeFile(String name)
/*      */   {
/* 3718 */     synchronized (this.welcomeFilesLock) {
/* 3719 */       for (String welcomeFile : this.welcomeFiles) {
/* 3720 */         if (name.equals(welcomeFile)) {
/* 3721 */           return true;
/*      */         }
/*      */       }
/*      */     }
/* 3725 */     return false;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String[] findWatchedResources()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 93	org/apache/catalina/core/StandardContext:watchedResourcesLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 92	org/apache/catalina/core/StandardContext:watchedResources	[Ljava/lang/String;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3736	-> byte code offset #0
/*      */     //   Java source line #3737	-> byte code offset #7
/*      */     //   Java source line #3738	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	StandardContext
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String[] findWelcomeFiles()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 95	org/apache/catalina/core/StandardContext:welcomeFilesLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 94	org/apache/catalina/core/StandardContext:welcomeFiles	[Ljava/lang/String;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3748	-> byte code offset #0
/*      */     //   Java source line #3749	-> byte code offset #7
/*      */     //   Java source line #3750	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	StandardContext
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String[] findWrapperLifecycles()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 97	org/apache/catalina/core/StandardContext:wrapperLifecyclesLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 96	org/apache/catalina/core/StandardContext:wrapperLifecycles	[Ljava/lang/String;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3760	-> byte code offset #0
/*      */     //   Java source line #3761	-> byte code offset #7
/*      */     //   Java source line #3762	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	StandardContext
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String[] findWrapperListeners()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 99	org/apache/catalina/core/StandardContext:wrapperListenersLock	Ljava/lang/Object;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: aload_0
/*      */     //   8: getfield 98	org/apache/catalina/core/StandardContext:wrapperListeners	[Ljava/lang/String;
/*      */     //   11: aload_1
/*      */     //   12: monitorexit
/*      */     //   13: areturn
/*      */     //   14: astore_2
/*      */     //   15: aload_1
/*      */     //   16: monitorexit
/*      */     //   17: aload_2
/*      */     //   18: athrow
/*      */     // Line number table:
/*      */     //   Java source line #3772	-> byte code offset #0
/*      */     //   Java source line #3773	-> byte code offset #7
/*      */     //   Java source line #3774	-> byte code offset #14
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	19	0	this	StandardContext
/*      */     //   5	11	1	Ljava/lang/Object;	Object
/*      */     //   14	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	14	finally
/*      */     //   14	17	14	finally
/*      */   }
/*      */   
/*      */   public synchronized void reload()
/*      */   {
/* 3797 */     if (!getState().isAvailable())
/*      */     {
/* 3799 */       throw new IllegalStateException(sm.getString("standardContext.notStarted", new Object[] {getName() }));
/*      */     }
/*      */     
/* 3802 */     if (log.isInfoEnabled()) {
/* 3803 */       log.info(sm.getString("standardContext.reloadingStarted", new Object[] {
/* 3804 */         getName() }));
/*      */     }
/*      */     
/*      */ 
/* 3808 */     setPaused(true);
/*      */     try
/*      */     {
/* 3811 */       stop();
/*      */     } catch (LifecycleException e) {
/* 3813 */       log.error(sm
/* 3814 */         .getString("standardContext.stoppingContext", new Object[] {getName() }), e);
/*      */     }
/*      */     try
/*      */     {
/* 3818 */       start();
/*      */     } catch (LifecycleException e) {
/* 3820 */       log.error(sm
/* 3821 */         .getString("standardContext.startingContext", new Object[] {getName() }), e);
/*      */     }
/*      */     
/* 3824 */     setPaused(false);
/*      */     
/* 3826 */     if (log.isInfoEnabled()) {
/* 3827 */       log.info(sm.getString("standardContext.reloadingCompleted", new Object[] {
/* 3828 */         getName() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeApplicationListener(String listener)
/*      */   {
/* 3843 */     synchronized (this.applicationListenersLock)
/*      */     {
/*      */ 
/* 3846 */       int n = -1;
/* 3847 */       for (int i = 0; i < this.applicationListeners.length; i++) {
/* 3848 */         if (this.applicationListeners[i].equals(listener)) {
/* 3849 */           n = i;
/* 3850 */           break;
/*      */         }
/*      */       }
/* 3853 */       if (n < 0) {
/* 3854 */         return;
/*      */       }
/*      */       
/*      */ 
/* 3858 */       int j = 0;
/* 3859 */       String[] results = new String[this.applicationListeners.length - 1];
/* 3860 */       for (int i = 0; i < this.applicationListeners.length; i++) {
/* 3861 */         if (i != n) {
/* 3862 */           results[(j++)] = this.applicationListeners[i];
/*      */         }
/*      */       }
/* 3865 */       this.applicationListeners = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3870 */     fireContainerEvent("removeApplicationListener", listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeApplicationParameter(String name)
/*      */   {
/* 3884 */     synchronized (this.applicationParametersLock)
/*      */     {
/*      */ 
/* 3887 */       int n = -1;
/* 3888 */       for (int i = 0; i < this.applicationParameters.length; i++) {
/* 3889 */         if (name.equals(this.applicationParameters[i].getName())) {
/* 3890 */           n = i;
/* 3891 */           break;
/*      */         }
/*      */       }
/* 3894 */       if (n < 0) {
/* 3895 */         return;
/*      */       }
/*      */       
/*      */ 
/* 3899 */       int j = 0;
/* 3900 */       ApplicationParameter[] results = new ApplicationParameter[this.applicationParameters.length - 1];
/*      */       
/* 3902 */       for (int i = 0; i < this.applicationParameters.length; i++) {
/* 3903 */         if (i != n) {
/* 3904 */           results[(j++)] = this.applicationParameters[i];
/*      */         }
/*      */       }
/* 3907 */       this.applicationParameters = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3912 */     fireContainerEvent("removeApplicationParameter", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeChild(Container child)
/*      */   {
/* 3929 */     if (!(child instanceof Wrapper))
/*      */     {
/* 3931 */       throw new IllegalArgumentException(sm.getString("standardContext.notWrapper"));
/*      */     }
/*      */     
/* 3934 */     super.removeChild(child);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeConstraint(SecurityConstraint constraint)
/*      */   {
/* 3947 */     synchronized (this.constraintsLock)
/*      */     {
/*      */ 
/* 3950 */       int n = -1;
/* 3951 */       for (int i = 0; i < this.constraints.length; i++) {
/* 3952 */         if (this.constraints[i].equals(constraint)) {
/* 3953 */           n = i;
/* 3954 */           break;
/*      */         }
/*      */       }
/* 3957 */       if (n < 0) {
/* 3958 */         return;
/*      */       }
/*      */       
/*      */ 
/* 3962 */       int j = 0;
/* 3963 */       SecurityConstraint[] results = new SecurityConstraint[this.constraints.length - 1];
/*      */       
/* 3965 */       for (int i = 0; i < this.constraints.length; i++) {
/* 3966 */         if (i != n) {
/* 3967 */           results[(j++)] = this.constraints[i];
/*      */         }
/*      */       }
/* 3970 */       this.constraints = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3975 */     fireContainerEvent("removeConstraint", constraint);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeErrorPage(ErrorPage errorPage)
/*      */   {
/* 3988 */     this.errorPageSupport.remove(errorPage);
/* 3989 */     fireContainerEvent("removeErrorPage", errorPage);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeFilterDef(FilterDef filterDef)
/*      */   {
/* 4002 */     synchronized (this.filterDefs) {
/* 4003 */       this.filterDefs.remove(filterDef.getFilterName());
/*      */     }
/* 4005 */     fireContainerEvent("removeFilterDef", filterDef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeFilterMap(FilterMap filterMap)
/*      */   {
/* 4017 */     this.filterMaps.remove(filterMap);
/*      */     
/* 4019 */     fireContainerEvent("removeFilterMap", filterMap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeMessageDestination(String name)
/*      */   {
/* 4030 */     synchronized (this.messageDestinations) {
/* 4031 */       this.messageDestinations.remove(name);
/*      */     }
/* 4033 */     fireContainerEvent("removeMessageDestination", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void removeMessageDestinationRef(String name)
/*      */   {
/* 4048 */     getNamingResources().removeMessageDestinationRef(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeMimeMapping(String extension)
/*      */   {
/* 4061 */     synchronized (this.mimeMappings) {
/* 4062 */       this.mimeMappings.remove(extension);
/*      */     }
/* 4064 */     fireContainerEvent("removeMimeMapping", extension);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeParameter(String name)
/*      */   {
/* 4077 */     this.parameters.remove(name);
/* 4078 */     fireContainerEvent("removeParameter", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeRoleMapping(String role)
/*      */   {
/* 4090 */     synchronized (this.roleMappings) {
/* 4091 */       this.roleMappings.remove(role);
/*      */     }
/* 4093 */     fireContainerEvent("removeRoleMapping", role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSecurityRole(String role)
/*      */   {
/* 4106 */     synchronized (this.securityRolesLock)
/*      */     {
/*      */ 
/* 4109 */       int n = -1;
/* 4110 */       for (int i = 0; i < this.securityRoles.length; i++) {
/* 4111 */         if (role.equals(this.securityRoles[i])) {
/* 4112 */           n = i;
/* 4113 */           break;
/*      */         }
/*      */       }
/* 4116 */       if (n < 0) {
/* 4117 */         return;
/*      */       }
/*      */       
/*      */ 
/* 4121 */       int j = 0;
/* 4122 */       String[] results = new String[this.securityRoles.length - 1];
/* 4123 */       for (int i = 0; i < this.securityRoles.length; i++) {
/* 4124 */         if (i != n) {
/* 4125 */           results[(j++)] = this.securityRoles[i];
/*      */         }
/*      */       }
/* 4128 */       this.securityRoles = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4133 */     fireContainerEvent("removeSecurityRole", role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeServletMapping(String pattern)
/*      */   {
/* 4147 */     String name = null;
/* 4148 */     synchronized (this.servletMappingsLock) {
/* 4149 */       name = (String)this.servletMappings.remove(pattern);
/*      */     }
/* 4151 */     Wrapper wrapper = (Wrapper)findChild(name);
/* 4152 */     if (wrapper != null) {
/* 4153 */       wrapper.removeMapping(pattern);
/*      */     }
/* 4155 */     fireContainerEvent("removeServletMapping", pattern);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWatchedResource(String name)
/*      */   {
/* 4168 */     synchronized (this.watchedResourcesLock)
/*      */     {
/*      */ 
/* 4171 */       int n = -1;
/* 4172 */       for (int i = 0; i < this.watchedResources.length; i++) {
/* 4173 */         if (this.watchedResources[i].equals(name)) {
/* 4174 */           n = i;
/* 4175 */           break;
/*      */         }
/*      */       }
/* 4178 */       if (n < 0) {
/* 4179 */         return;
/*      */       }
/*      */       
/*      */ 
/* 4183 */       int j = 0;
/* 4184 */       String[] results = new String[this.watchedResources.length - 1];
/* 4185 */       for (int i = 0; i < this.watchedResources.length; i++) {
/* 4186 */         if (i != n) {
/* 4187 */           results[(j++)] = this.watchedResources[i];
/*      */         }
/*      */       }
/* 4190 */       this.watchedResources = results;
/*      */     }
/*      */     
/*      */ 
/* 4194 */     fireContainerEvent("removeWatchedResource", name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWelcomeFile(String name)
/*      */   {
/* 4208 */     synchronized (this.welcomeFilesLock)
/*      */     {
/*      */ 
/* 4211 */       int n = -1;
/* 4212 */       for (int i = 0; i < this.welcomeFiles.length; i++) {
/* 4213 */         if (this.welcomeFiles[i].equals(name)) {
/* 4214 */           n = i;
/* 4215 */           break;
/*      */         }
/*      */       }
/* 4218 */       if (n < 0) {
/* 4219 */         return;
/*      */       }
/*      */       
/*      */ 
/* 4223 */       int j = 0;
/* 4224 */       String[] results = new String[this.welcomeFiles.length - 1];
/* 4225 */       for (int i = 0; i < this.welcomeFiles.length; i++) {
/* 4226 */         if (i != n) {
/* 4227 */           results[(j++)] = this.welcomeFiles[i];
/*      */         }
/*      */       }
/* 4230 */       this.welcomeFiles = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4235 */     if (getState().equals(LifecycleState.STARTED)) {
/* 4236 */       fireContainerEvent("removeWelcomeFile", name);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWrapperLifecycle(String listener)
/*      */   {
/* 4252 */     synchronized (this.wrapperLifecyclesLock)
/*      */     {
/*      */ 
/* 4255 */       int n = -1;
/* 4256 */       for (int i = 0; i < this.wrapperLifecycles.length; i++) {
/* 4257 */         if (this.wrapperLifecycles[i].equals(listener)) {
/* 4258 */           n = i;
/* 4259 */           break;
/*      */         }
/*      */       }
/* 4262 */       if (n < 0) {
/* 4263 */         return;
/*      */       }
/*      */       
/*      */ 
/* 4267 */       int j = 0;
/* 4268 */       String[] results = new String[this.wrapperLifecycles.length - 1];
/* 4269 */       for (int i = 0; i < this.wrapperLifecycles.length; i++) {
/* 4270 */         if (i != n) {
/* 4271 */           results[(j++)] = this.wrapperLifecycles[i];
/*      */         }
/*      */       }
/* 4274 */       this.wrapperLifecycles = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4279 */     fireContainerEvent("removeWrapperLifecycle", listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWrapperListener(String listener)
/*      */   {
/* 4294 */     synchronized (this.wrapperListenersLock)
/*      */     {
/*      */ 
/* 4297 */       int n = -1;
/* 4298 */       for (int i = 0; i < this.wrapperListeners.length; i++) {
/* 4299 */         if (this.wrapperListeners[i].equals(listener)) {
/* 4300 */           n = i;
/* 4301 */           break;
/*      */         }
/*      */       }
/* 4304 */       if (n < 0) {
/* 4305 */         return;
/*      */       }
/*      */       
/*      */ 
/* 4309 */       int j = 0;
/* 4310 */       String[] results = new String[this.wrapperListeners.length - 1];
/* 4311 */       for (int i = 0; i < this.wrapperListeners.length; i++) {
/* 4312 */         if (i != n) {
/* 4313 */           results[(j++)] = this.wrapperListeners[i];
/*      */         }
/*      */       }
/* 4316 */       this.wrapperListeners = results;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4321 */     fireContainerEvent("removeWrapperListener", listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getProcessingTime()
/*      */   {
/* 4335 */     long result = 0L;
/*      */     
/* 4337 */     Container[] children = findChildren();
/* 4338 */     if (children != null) {
/* 4339 */       for (Container child : children) {
/* 4340 */         result += ((StandardWrapper)child).getProcessingTime();
/*      */       }
/*      */     }
/*      */     
/* 4344 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getMaxTime()
/*      */   {
/* 4356 */     long result = 0L;
/*      */     
/*      */ 
/* 4359 */     Container[] children = findChildren();
/* 4360 */     if (children != null) {
/* 4361 */       for (Container child : children) {
/* 4362 */         long time = ((StandardWrapper)child).getMaxTime();
/* 4363 */         if (time > result) {
/* 4364 */           result = time;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4369 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getMinTime()
/*      */   {
/* 4381 */     long result = -1L;
/*      */     
/*      */ 
/* 4384 */     Container[] children = findChildren();
/* 4385 */     if (children != null) {
/* 4386 */       for (Container child : children) {
/* 4387 */         long time = ((StandardWrapper)child).getMinTime();
/* 4388 */         if ((result < 0L) || (time < result)) {
/* 4389 */           result = time;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4394 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRequestCount()
/*      */   {
/* 4406 */     int result = 0;
/*      */     
/* 4408 */     Container[] children = findChildren();
/* 4409 */     if (children != null) {
/* 4410 */       for (Container child : children) {
/* 4411 */         result += ((StandardWrapper)child).getRequestCount();
/*      */       }
/*      */     }
/*      */     
/* 4415 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getErrorCount()
/*      */   {
/* 4427 */     int result = 0;
/*      */     
/* 4429 */     Container[] children = findChildren();
/* 4430 */     if (children != null) {
/* 4431 */       for (Container child : children) {
/* 4432 */         result += ((StandardWrapper)child).getErrorCount();
/*      */       }
/*      */     }
/*      */     
/* 4436 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRealPath(String path)
/*      */   {
/* 4450 */     if ("".equals(path)) {
/* 4451 */       path = "/";
/*      */     }
/* 4453 */     if (this.resources != null) {
/*      */       try {
/* 4455 */         WebResource resource = this.resources.getResource(path);
/* 4456 */         String canonicalPath = resource.getCanonicalPath();
/* 4457 */         if (canonicalPath == null)
/* 4458 */           return null;
/* 4459 */         if (((resource.isDirectory()) && (!canonicalPath.endsWith(File.separator))) || (
/* 4460 */           (!resource.exists()) && (path.endsWith("/")))) {
/* 4461 */           return canonicalPath + File.separatorChar;
/*      */         }
/* 4463 */         return canonicalPath;
/*      */       }
/*      */       catch (IllegalArgumentException localIllegalArgumentException) {}
/*      */     }
/*      */     
/*      */ 
/* 4469 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void dynamicServletCreated(Servlet servlet)
/*      */   {
/* 4480 */     this.createdServlets.add(servlet);
/*      */   }
/*      */   
/*      */   public boolean wasCreatedDynamicServlet(Servlet servlet)
/*      */   {
/* 4485 */     return this.createdServlets.contains(servlet);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final class ContextFilterMaps
/*      */   {
/* 4493 */     private final Object lock = new Object();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4501 */     private FilterMap[] array = new FilterMap[0];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4512 */     private int insertPoint = 0;
/*      */     
/*      */     /* Error */
/*      */     public FilterMap[] asArray()
/*      */     {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: getfield 4	org/apache/catalina/core/StandardContext$ContextFilterMaps:lock	Ljava/lang/Object;
/*      */       //   4: dup
/*      */       //   5: astore_1
/*      */       //   6: monitorenter
/*      */       //   7: aload_0
/*      */       //   8: getfield 6	org/apache/catalina/core/StandardContext$ContextFilterMaps:array	[Lorg/apache/tomcat/util/descriptor/web/FilterMap;
/*      */       //   11: aload_1
/*      */       //   12: monitorexit
/*      */       //   13: areturn
/*      */       //   14: astore_2
/*      */       //   15: aload_1
/*      */       //   16: monitorexit
/*      */       //   17: aload_2
/*      */       //   18: athrow
/*      */       // Line number table:
/*      */       //   Java source line #4518	-> byte code offset #0
/*      */       //   Java source line #4519	-> byte code offset #7
/*      */       //   Java source line #4520	-> byte code offset #14
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	signature
/*      */       //   0	19	0	this	ContextFilterMaps
/*      */       //   5	11	1	Ljava/lang/Object;	Object
/*      */       //   14	4	2	localObject1	Object
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   7	13	14	finally
/*      */       //   14	17	14	finally
/*      */     }
/*      */     
/*      */     public void add(FilterMap filterMap)
/*      */     {
/* 4531 */       synchronized (this.lock) {
/* 4532 */         FilterMap[] results = (FilterMap[])Arrays.copyOf(this.array, this.array.length + 1);
/* 4533 */         results[this.array.length] = filterMap;
/* 4534 */         this.array = results;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void addBefore(FilterMap filterMap)
/*      */     {
/* 4546 */       synchronized (this.lock) {
/* 4547 */         FilterMap[] results = new FilterMap[this.array.length + 1];
/* 4548 */         System.arraycopy(this.array, 0, results, 0, this.insertPoint);
/* 4549 */         System.arraycopy(this.array, this.insertPoint, results, this.insertPoint + 1, this.array.length - this.insertPoint);
/*      */         
/* 4551 */         results[this.insertPoint] = filterMap;
/* 4552 */         this.array = results;
/* 4553 */         this.insertPoint += 1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void remove(FilterMap filterMap)
/*      */     {
/* 4563 */       synchronized (this.lock)
/*      */       {
/* 4565 */         int n = -1;
/* 4566 */         for (int i = 0; i < this.array.length; i++) {
/* 4567 */           if (this.array[i] == filterMap) {
/* 4568 */             n = i;
/* 4569 */             break;
/*      */           }
/*      */         }
/* 4572 */         if (n < 0) {
/* 4573 */           return;
/*      */         }
/*      */         
/*      */ 
/* 4577 */         FilterMap[] results = new FilterMap[this.array.length - 1];
/* 4578 */         System.arraycopy(this.array, 0, results, 0, n);
/* 4579 */         System.arraycopy(this.array, n + 1, results, n, this.array.length - 1 - n);
/*      */         
/* 4581 */         this.array = results;
/* 4582 */         if (n < this.insertPoint) {
/* 4583 */           this.insertPoint -= 1;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean filterStart()
/*      */   {
/* 4599 */     if (getLogger().isDebugEnabled()) {
/* 4600 */       getLogger().debug("Starting filters");
/*      */     }
/*      */     
/* 4603 */     boolean ok = true;
/* 4604 */     synchronized (this.filterConfigs) {
/* 4605 */       this.filterConfigs.clear();
/* 4606 */       for (Map.Entry<String, FilterDef> entry : this.filterDefs.entrySet()) {
/* 4607 */         String name = (String)entry.getKey();
/* 4608 */         if (getLogger().isDebugEnabled()) {
/* 4609 */           getLogger().debug(" Starting filter '" + name + "'");
/*      */         }
/*      */         try
/*      */         {
/* 4613 */           ApplicationFilterConfig filterConfig = new ApplicationFilterConfig(this, (FilterDef)entry.getValue());
/* 4614 */           this.filterConfigs.put(name, filterConfig);
/*      */         } catch (Throwable t) {
/* 4616 */           t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 4617 */           ExceptionUtils.handleThrowable(t);
/* 4618 */           getLogger().error(sm.getString("standardContext.filterStart", new Object[] { name }), t);
/*      */           
/* 4620 */           ok = false;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4625 */     return ok;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean filterStop()
/*      */   {
/* 4636 */     if (getLogger().isDebugEnabled()) {
/* 4637 */       getLogger().debug("Stopping filters");
/*      */     }
/*      */     
/*      */ 
/* 4641 */     synchronized (this.filterConfigs) {
/* 4642 */       for (Map.Entry<String, ApplicationFilterConfig> entry : this.filterConfigs.entrySet()) {
/* 4643 */         if (getLogger().isDebugEnabled()) {
/* 4644 */           getLogger().debug(" Stopping filter '" + (String)entry.getKey() + "'");
/*      */         }
/* 4646 */         ApplicationFilterConfig filterConfig = (ApplicationFilterConfig)entry.getValue();
/* 4647 */         filterConfig.release();
/*      */       }
/* 4649 */       this.filterConfigs.clear();
/*      */     }
/* 4651 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FilterConfig findFilterConfig(String name)
/*      */   {
/* 4664 */     return (FilterConfig)this.filterConfigs.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean listenerStart()
/*      */   {
/* 4676 */     if (log.isDebugEnabled()) {
/* 4677 */       log.debug("Configuring application event listeners");
/*      */     }
/*      */     
/*      */ 
/* 4681 */     String[] listeners = findApplicationListeners();
/* 4682 */     Object[] results = new Object[listeners.length];
/* 4683 */     boolean ok = true;
/* 4684 */     for (int i = 0; i < results.length; i++) {
/* 4685 */       if (getLogger().isDebugEnabled()) {
/* 4686 */         getLogger().debug(" Configuring event listener class '" + listeners[i] + "'");
/*      */       }
/*      */       try
/*      */       {
/* 4690 */         String listener = listeners[i];
/* 4691 */         results[i] = getInstanceManager().newInstance(listener);
/*      */       } catch (Throwable t) {
/* 4693 */         t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 4694 */         ExceptionUtils.handleThrowable(t);
/* 4695 */         getLogger().error(sm.getString("standardContext.applicationListener", new Object[] { listeners[i] }), t);
/*      */         
/* 4697 */         ok = false;
/*      */       }
/*      */     }
/* 4700 */     if (!ok) {
/* 4701 */       getLogger().error(sm.getString("standardContext.applicationSkipped"));
/* 4702 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 4706 */     List<Object> eventListeners = new ArrayList();
/* 4707 */     List<Object> lifecycleListeners = new ArrayList();
/* 4708 */     for (Object result : results) {
/* 4709 */       if (((result instanceof ServletContextAttributeListener)) || ((result instanceof ServletRequestAttributeListener)) || ((result instanceof ServletRequestListener)) || ((result instanceof HttpSessionIdListener)) || ((result instanceof HttpSessionAttributeListener)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 4714 */         eventListeners.add(result);
/*      */       }
/* 4716 */       if (((result instanceof ServletContextListener)) || ((result instanceof HttpSessionListener)))
/*      */       {
/* 4718 */         lifecycleListeners.add(result);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4727 */     eventListeners.addAll(Arrays.asList(getApplicationEventListeners()));
/* 4728 */     setApplicationEventListeners(eventListeners.toArray());
/* 4729 */     Object lifecycleListener; for (lifecycleListener : getApplicationLifecycleListeners()) {
/* 4730 */       lifecycleListeners.add(lifecycleListener);
/* 4731 */       if ((lifecycleListener instanceof ServletContextListener)) {
/* 4732 */         this.noPluggabilityListeners.add(lifecycleListener);
/*      */       }
/*      */     }
/* 4735 */     setApplicationLifecycleListeners(lifecycleListeners.toArray());
/*      */     
/*      */ 
/*      */ 
/* 4739 */     if (getLogger().isDebugEnabled()) {
/* 4740 */       getLogger().debug("Sending application start events");
/*      */     }
/*      */     
/*      */ 
/* 4744 */     getServletContext();
/* 4745 */     this.context.setNewServletContextListenerAllowed(false);
/*      */     
/* 4747 */     Object[] instances = getApplicationLifecycleListeners();
/* 4748 */     if ((instances == null) || (instances.length == 0)) {
/* 4749 */       return ok;
/*      */     }
/*      */     
/* 4752 */     ServletContextEvent event = new ServletContextEvent(getServletContext());
/* 4753 */     ServletContextEvent tldEvent = null;
/* 4754 */     if (this.noPluggabilityListeners.size() > 0) {
/* 4755 */       this.noPluggabilityServletContext = new NoPluggabilityServletContext(getServletContext());
/* 4756 */       tldEvent = new ServletContextEvent(this.noPluggabilityServletContext);
/*      */     }
/* 4758 */     for (Object instance : instances)
/* 4759 */       if ((instance instanceof ServletContextListener))
/*      */       {
/*      */ 
/* 4762 */         ServletContextListener listener = (ServletContextListener)instance;
/*      */         try {
/* 4764 */           fireContainerEvent("beforeContextInitialized", listener);
/* 4765 */           if (this.noPluggabilityListeners.contains(listener)) {
/* 4766 */             listener.contextInitialized(tldEvent);
/*      */           } else {
/* 4768 */             listener.contextInitialized(event);
/*      */           }
/* 4770 */           fireContainerEvent("afterContextInitialized", listener);
/*      */         } catch (Throwable t) {
/* 4772 */           ExceptionUtils.handleThrowable(t);
/* 4773 */           fireContainerEvent("afterContextInitialized", listener);
/* 4774 */           getLogger().error(sm.getString("standardContext.listenerStart", new Object[] {instance
/* 4775 */             .getClass().getName() }), t);
/* 4776 */           ok = false;
/*      */         }
/*      */       }
/* 4779 */     return ok;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean listenerStop()
/*      */   {
/* 4791 */     if (log.isDebugEnabled()) {
/* 4792 */       log.debug("Sending application stop events");
/*      */     }
/*      */     
/* 4795 */     boolean ok = true;
/* 4796 */     Object[] listeners = getApplicationLifecycleListeners();
/* 4797 */     if ((listeners != null) && (listeners.length > 0)) {
/* 4798 */       ServletContextEvent event = new ServletContextEvent(getServletContext());
/* 4799 */       ServletContextEvent tldEvent = null;
/* 4800 */       if (this.noPluggabilityServletContext != null) {
/* 4801 */         tldEvent = new ServletContextEvent(this.noPluggabilityServletContext);
/*      */       }
/* 4803 */       for (int i = 0; i < listeners.length; i++) {
/* 4804 */         int j = listeners.length - 1 - i;
/* 4805 */         if (listeners[j] != null)
/*      */         {
/*      */ 
/* 4808 */           if ((listeners[j] instanceof ServletContextListener)) {
/* 4809 */             ServletContextListener listener = (ServletContextListener)listeners[j];
/*      */             try
/*      */             {
/* 4812 */               fireContainerEvent("beforeContextDestroyed", listener);
/* 4813 */               if (this.noPluggabilityListeners.contains(listener)) {
/* 4814 */                 listener.contextDestroyed(tldEvent);
/*      */               } else {
/* 4816 */                 listener.contextDestroyed(event);
/*      */               }
/* 4818 */               fireContainerEvent("afterContextDestroyed", listener);
/*      */             } catch (Throwable t) {
/* 4820 */               ExceptionUtils.handleThrowable(t);
/* 4821 */               fireContainerEvent("afterContextDestroyed", listener);
/* 4822 */               getLogger()
/* 4823 */                 .error(sm.getString("standardContext.listenerStop", new Object[] {listeners[j]
/* 4824 */                 .getClass().getName() }), t);
/* 4825 */               ok = false;
/*      */             }
/*      */           }
/*      */           try {
/* 4829 */             if (getInstanceManager() != null) {
/* 4830 */               getInstanceManager().destroyInstance(listeners[j]);
/*      */             }
/*      */           } catch (Throwable t) {
/* 4833 */             t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 4834 */             ExceptionUtils.handleThrowable(t);
/* 4835 */             getLogger()
/* 4836 */               .error(sm.getString("standardContext.listenerStop", new Object[] {listeners[j]
/* 4837 */               .getClass().getName() }), t);
/* 4838 */             ok = false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4844 */     listeners = getApplicationEventListeners();
/* 4845 */     if (listeners != null) {
/* 4846 */       for (int i = 0; i < listeners.length; i++) {
/* 4847 */         int j = listeners.length - 1 - i;
/* 4848 */         if (listeners[j] != null)
/*      */         {
/*      */           try
/*      */           {
/* 4852 */             if (getInstanceManager() != null) {
/* 4853 */               getInstanceManager().destroyInstance(listeners[j]);
/*      */             }
/*      */           } catch (Throwable t) {
/* 4856 */             t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 4857 */             ExceptionUtils.handleThrowable(t);
/* 4858 */             getLogger()
/* 4859 */               .error(sm.getString("standardContext.listenerStop", new Object[] {listeners[j]
/* 4860 */               .getClass().getName() }), t);
/* 4861 */             ok = false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 4866 */     setApplicationEventListeners(null);
/* 4867 */     setApplicationLifecycleListeners(null);
/*      */     
/* 4869 */     this.noPluggabilityServletContext = null;
/* 4870 */     this.noPluggabilityListeners.clear();
/*      */     
/* 4872 */     return ok;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resourcesStart()
/*      */     throws LifecycleException
/*      */   {
/* 4884 */     if (!this.resources.getState().isAvailable()) {
/* 4885 */       this.resources.start();
/*      */     }
/*      */     
/* 4888 */     if ((this.effectiveMajorVersion >= 3) && (this.addWebinfClassesResources)) {
/* 4889 */       WebResource webinfClassesResource = this.resources.getResource("/WEB-INF/classes/META-INF/resources");
/*      */       
/* 4891 */       if (webinfClassesResource.isDirectory()) {
/* 4892 */         getResources().createWebResourceSet(WebResourceRoot.ResourceSetType.RESOURCE_JAR, "/", webinfClassesResource
/*      */         
/* 4894 */           .getURL(), "/");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean resourcesStop()
/*      */   {
/* 4906 */     boolean ok = true;
/*      */     
/* 4908 */     Lock writeLock = this.resourcesLock.writeLock();
/* 4909 */     writeLock.lock();
/*      */     try {
/* 4911 */       if (this.resources != null) {
/* 4912 */         this.resources.stop();
/*      */       }
/*      */     } catch (Throwable t) {
/* 4915 */       ExceptionUtils.handleThrowable(t);
/* 4916 */       log.error(sm.getString("standardContext.resourcesStop"), t);
/* 4917 */       ok = false;
/*      */     } finally {
/* 4919 */       writeLock.unlock();
/*      */     }
/*      */     
/* 4922 */     return ok;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean loadOnStartup(Container[] children)
/*      */   {
/* 4937 */     TreeMap<Integer, ArrayList<Wrapper>> map = new TreeMap();
/* 4938 */     for (Container child : children) {
/* 4939 */       Wrapper wrapper = (Wrapper)child;
/* 4940 */       int loadOnStartup = wrapper.getLoadOnStartup();
/* 4941 */       if (loadOnStartup >= 0)
/*      */       {
/*      */ 
/* 4944 */         Integer key = Integer.valueOf(loadOnStartup);
/* 4945 */         ArrayList<Wrapper> list = (ArrayList)map.get(key);
/* 4946 */         if (list == null) {
/* 4947 */           list = new ArrayList();
/* 4948 */           map.put(key, list);
/*      */         }
/* 4950 */         list.add(wrapper);
/*      */       }
/*      */     }
/*      */     
/* 4954 */     for (??? = map.values().iterator(); ((Iterator)???).hasNext();) { Object list = (ArrayList)((Iterator)???).next();
/* 4955 */       for (Wrapper wrapper : (ArrayList)list) {
/*      */         try {
/* 4957 */           wrapper.load();
/*      */         } catch (ServletException e) {
/* 4959 */           getLogger().error(sm.getString("standardContext.loadOnStartup.loadException", new Object[] {
/* 4960 */             getName(), wrapper.getName() }), StandardWrapper.getRootCause(e));
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 4965 */           if (getComputedFailCtxIfServletStartFails()) {
/* 4966 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 4971 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void startInternal()
/*      */     throws LifecycleException
/*      */   {
/* 4986 */     if (log.isDebugEnabled()) {
/* 4987 */       log.debug("Starting " + getBaseName());
/*      */     }
/*      */     
/*      */ 
/* 4991 */     if (getObjectName() != null)
/*      */     {
/* 4993 */       Notification notification = new Notification("j2ee.state.starting", getObjectName(), this.sequenceNumber.getAndIncrement());
/* 4994 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/* 4997 */     setConfigured(false);
/* 4998 */     boolean ok = true;
/*      */     
/*      */ 
/*      */ 
/* 5002 */     if (this.namingResources != null) {
/* 5003 */       this.namingResources.start();
/*      */     }
/*      */     
/*      */ 
/* 5007 */     postWorkDirectory();
/*      */     
/*      */ 
/* 5010 */     if (getResources() == null) {
/* 5011 */       if (log.isDebugEnabled()) {
/* 5012 */         log.debug("Configuring default Resources");
/*      */       }
/*      */       try
/*      */       {
/* 5016 */         setResources(new StandardRoot(this));
/*      */       } catch (IllegalArgumentException e) {
/* 5018 */         log.error(sm.getString("standardContext.resourcesInit"), e);
/* 5019 */         ok = false;
/*      */       }
/*      */     }
/* 5022 */     if (ok) {
/* 5023 */       resourcesStart();
/*      */     }
/*      */     
/* 5026 */     if (getLoader() == null) {
/* 5027 */       WebappLoader webappLoader = new WebappLoader();
/* 5028 */       webappLoader.setDelegate(getDelegate());
/* 5029 */       setLoader(webappLoader);
/*      */     }
/*      */     
/*      */ 
/* 5033 */     if (this.cookieProcessor == null) {
/* 5034 */       this.cookieProcessor = new Rfc6265CookieProcessor();
/*      */     }
/*      */     
/*      */ 
/* 5038 */     getCharsetMapper();
/*      */     
/*      */ 
/* 5041 */     boolean dependencyCheck = true;
/*      */     try
/*      */     {
/* 5044 */       dependencyCheck = ExtensionValidator.validateApplication(getResources(), this);
/*      */     } catch (IOException ioe) {
/* 5046 */       log.error(sm.getString("standardContext.extensionValidationError"), ioe);
/* 5047 */       dependencyCheck = false;
/*      */     }
/*      */     
/* 5050 */     if (!dependencyCheck)
/*      */     {
/* 5052 */       ok = false;
/*      */     }
/*      */     
/*      */ 
/* 5056 */     String useNamingProperty = System.getProperty("catalina.useNaming");
/* 5057 */     if ((useNamingProperty != null) && 
/* 5058 */       (useNamingProperty.equals("false"))) {
/* 5059 */       this.useNaming = false;
/*      */     }
/*      */     
/* 5062 */     if ((ok) && (isUseNaming()) && 
/* 5063 */       (getNamingContextListener() == null)) {
/* 5064 */       NamingContextListener ncl = new NamingContextListener();
/* 5065 */       ncl.setName(getNamingContextName());
/* 5066 */       ncl.setExceptionOnFailedWrite(getJndiExceptionOnFailedWrite());
/* 5067 */       addLifecycleListener(ncl);
/* 5068 */       setNamingContextListener(ncl);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5073 */     if (log.isDebugEnabled()) {
/* 5074 */       log.debug("Processing standard container startup");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5079 */     ClassLoader oldCCL = bindThread();
/*      */     try {
/*      */       Loader loader;
/* 5082 */       if (ok)
/*      */       {
/* 5084 */         loader = getLoader();
/* 5085 */         if ((loader instanceof Lifecycle)) {
/* 5086 */           ((Lifecycle)loader).start();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5091 */         if ((loader.getClassLoader() instanceof WebappClassLoaderBase)) {
/* 5092 */           WebappClassLoaderBase cl = (WebappClassLoaderBase)loader.getClassLoader();
/* 5093 */           cl.setClearReferencesRmiTargets(getClearReferencesRmiTargets());
/* 5094 */           cl.setClearReferencesStopThreads(getClearReferencesStopThreads());
/* 5095 */           cl.setClearReferencesStopTimerThreads(getClearReferencesStopTimerThreads());
/* 5096 */           cl.setClearReferencesHttpClientKeepAliveThread(getClearReferencesHttpClientKeepAliveThread());
/* 5097 */           cl.setClearReferencesObjectStreamClassCaches(getClearReferencesObjectStreamClassCaches());
/* 5098 */           cl.setClearReferencesThreadLocals(getClearReferencesThreadLocals());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5103 */         unbindThread(oldCCL);
/* 5104 */         oldCCL = bindThread();
/*      */         
/*      */ 
/*      */ 
/* 5108 */         this.logger = null;
/* 5109 */         getLogger();
/*      */         
/* 5111 */         Realm realm = getRealmInternal();
/* 5112 */         CredentialHandler safeHandler; if (null != realm) {
/* 5113 */           if ((realm instanceof Lifecycle)) {
/* 5114 */             ((Lifecycle)realm).start();
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 5120 */           safeHandler = new CredentialHandler()
/*      */           {
/*      */             public boolean matches(String inputCredentials, String storedCredentials) {
/* 5123 */               return StandardContext.this.getRealmInternal().getCredentialHandler().matches(inputCredentials, storedCredentials);
/*      */             }
/*      */             
/*      */             public String mutate(String inputCredentials)
/*      */             {
/* 5128 */               return StandardContext.this.getRealmInternal().getCredentialHandler().mutate(inputCredentials);
/*      */             }
/* 5130 */           };
/* 5131 */           this.context.setAttribute("org.apache.catalina.CredentialHandler", safeHandler);
/*      */         }
/*      */         
/*      */ 
/* 5135 */         fireLifecycleEvent("configure_start", null);
/*      */         
/*      */ 
/* 5138 */         for (Container child : findChildren()) {
/* 5139 */           if (!child.getState().isAvailable()) {
/* 5140 */             child.start();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5146 */         if ((this.pipeline instanceof Lifecycle)) {
/* 5147 */           ((Lifecycle)this.pipeline).start();
/*      */         }
/*      */         
/*      */ 
/* 5151 */         Manager contextManager = null;
/* 5152 */         Manager manager = getManager();
/* 5153 */         if (manager == null) {
/* 5154 */           if (log.isDebugEnabled()) {
/* 5155 */             log.debug(sm.getString("standardContext.cluster.noManager", new Object[] {
/* 5156 */               Boolean.valueOf(getCluster() != null ? 1 : false), 
/* 5157 */               Boolean.valueOf(this.distributable) }));
/*      */           }
/* 5159 */           if ((getCluster() != null) && (this.distributable)) {
/*      */             try {
/* 5161 */               contextManager = getCluster().createManager(getName());
/*      */             } catch (Exception ex) {
/* 5163 */               log.error(sm.getString("standardContext.cluster.managerError"), ex);
/* 5164 */               ok = false;
/*      */             }
/*      */           } else {
/* 5167 */             contextManager = new StandardManager();
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 5172 */         if (contextManager != null) {
/* 5173 */           if (log.isDebugEnabled()) {
/* 5174 */             log.debug(sm.getString("standardContext.manager", new Object[] {contextManager
/* 5175 */               .getClass().getName() }));
/*      */           }
/* 5177 */           setManager(contextManager);
/*      */         }
/*      */         
/* 5180 */         if ((manager != null) && (getCluster() != null) && (this.distributable))
/*      */         {
/*      */ 
/* 5183 */           getCluster().registerManager(manager);
/*      */         }
/*      */       }
/*      */       
/* 5187 */       if (!getConfigured()) {
/* 5188 */         log.error(sm.getString("standardContext.configurationFail"));
/* 5189 */         ok = false;
/*      */       }
/*      */       
/*      */ 
/* 5193 */       if (ok)
/*      */       {
/* 5195 */         getServletContext().setAttribute("org.apache.catalina.resources", getResources());
/*      */         
/* 5197 */         if (getInstanceManager() == null) {
/* 5198 */           setInstanceManager(createInstanceManager());
/*      */         }
/* 5200 */         getServletContext().setAttribute(InstanceManager.class
/* 5201 */           .getName(), getInstanceManager());
/* 5202 */         InstanceManagerBindings.bind(getLoader().getClassLoader(), getInstanceManager());
/*      */         
/*      */ 
/* 5205 */         getServletContext().setAttribute(JarScanner.class
/* 5206 */           .getName(), getJarScanner());
/*      */         
/*      */ 
/* 5209 */         getServletContext().setAttribute("org.apache.catalina.webappVersion", getWebappVersion());
/*      */       }
/*      */       
/*      */ 
/* 5213 */       mergeParameters();
/*      */       
/*      */ 
/*      */ 
/* 5217 */       for (Map.Entry<ServletContainerInitializer, Set<Class<?>>> entry : this.initializers.entrySet()) {
/*      */         try {
/* 5219 */           ((ServletContainerInitializer)entry.getKey()).onStartup((Set)entry.getValue(), 
/* 5220 */             getServletContext());
/*      */         } catch (ServletException e) {
/* 5222 */           log.error(sm.getString("standardContext.sciFail"), e);
/* 5223 */           ok = false;
/* 5224 */           break;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 5229 */       if ((ok) && 
/* 5230 */         (!listenerStart())) {
/* 5231 */         log.error(sm.getString("standardContext.listenerFail"));
/* 5232 */         ok = false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5239 */       if (ok) {
/* 5240 */         checkConstraintsForUncoveredMethods(findConstraints());
/*      */       }
/*      */       
/*      */       try
/*      */       {
/* 5245 */         Manager manager = getManager();
/* 5246 */         if ((manager instanceof Lifecycle)) {
/* 5247 */           ((Lifecycle)manager).start();
/*      */         }
/*      */       } catch (Exception e) {
/* 5250 */         log.error(sm.getString("standardContext.managerFail"), e);
/* 5251 */         ok = false;
/*      */       }
/*      */       
/*      */ 
/* 5255 */       if ((ok) && 
/* 5256 */         (!filterStart())) {
/* 5257 */         log.error(sm.getString("standardContext.filterFail"));
/* 5258 */         ok = false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 5263 */       if ((ok) && 
/* 5264 */         (!loadOnStartup(findChildren()))) {
/* 5265 */         log.error(sm.getString("standardContext.servletFail"));
/* 5266 */         ok = false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 5271 */       super.threadStart();
/*      */     }
/*      */     finally {
/* 5274 */       unbindThread(oldCCL);
/*      */     }
/*      */     
/*      */ 
/* 5278 */     if (ok) {
/* 5279 */       if (log.isDebugEnabled()) {
/* 5280 */         log.debug("Starting completed");
/*      */       }
/*      */     } else {
/* 5283 */       log.error(sm.getString("standardContext.startFailed", new Object[] { getName() }));
/*      */     }
/*      */     
/* 5286 */     this.startTime = System.currentTimeMillis();
/*      */     
/*      */ 
/* 5289 */     if ((ok) && (getObjectName() != null))
/*      */     {
/*      */ 
/* 5292 */       Notification notification = new Notification("j2ee.state.running", getObjectName(), this.sequenceNumber.getAndIncrement());
/* 5293 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5300 */     getResources().gc();
/*      */     
/*      */ 
/* 5303 */     if (!ok) {
/* 5304 */       setState(LifecycleState.FAILED);
/*      */       
/* 5306 */       if (getObjectName() != null)
/*      */       {
/* 5308 */         Notification notification = new Notification("j2ee.object.failed", getObjectName(), this.sequenceNumber.getAndIncrement());
/* 5309 */         this.broadcaster.sendNotification(notification);
/*      */       }
/*      */     } else {
/* 5312 */       setState(LifecycleState.STARTING);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void checkConstraintsForUncoveredMethods(SecurityConstraint[] constraints)
/*      */   {
/* 5320 */     SecurityConstraint[] newConstraints = SecurityConstraint.findUncoveredHttpMethods(constraints, 
/* 5321 */       getDenyUncoveredHttpMethods(), getLogger());
/* 5322 */     for (SecurityConstraint constraint : newConstraints) {
/* 5323 */       addConstraint(constraint);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public InstanceManager createInstanceManager()
/*      */   {
/* 5330 */     javax.naming.Context context = null;
/* 5331 */     if ((isUseNaming()) && (getNamingContextListener() != null)) {
/* 5332 */       context = getNamingContextListener().getEnvContext();
/*      */     }
/* 5334 */     Map<String, Map<String, String>> injectionMap = buildInjectionMap(
/* 5335 */       getIgnoreAnnotations() ? new NamingResourcesImpl() : getNamingResources());
/* 5336 */     return new DefaultInstanceManager(context, injectionMap, this, 
/* 5337 */       getClass().getClassLoader());
/*      */   }
/*      */   
/*      */   private Map<String, Map<String, String>> buildInjectionMap(NamingResourcesImpl namingResources) {
/* 5341 */     Map<String, Map<String, String>> injectionMap = new HashMap();
/* 5342 */     for (Injectable resource : namingResources.findLocalEjbs()) {
/* 5343 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5345 */     for (Injectable resource : namingResources.findEjbs()) {
/* 5346 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5348 */     for (Injectable resource : namingResources.findEnvironments()) {
/* 5349 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5351 */     for (Injectable resource : namingResources.findMessageDestinationRefs()) {
/* 5352 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5354 */     for (Injectable resource : namingResources.findResourceEnvRefs()) {
/* 5355 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5357 */     for (Injectable resource : namingResources.findResources()) {
/* 5358 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5360 */     for (Injectable resource : namingResources.findServices()) {
/* 5361 */       addInjectionTarget(resource, injectionMap);
/*      */     }
/* 5363 */     return injectionMap;
/*      */   }
/*      */   
/*      */   private void addInjectionTarget(Injectable resource, Map<String, Map<String, String>> injectionMap) {
/* 5367 */     List<InjectionTarget> injectionTargets = resource.getInjectionTargets();
/* 5368 */     String jndiName; if ((injectionTargets != null) && (injectionTargets.size() > 0)) {
/* 5369 */       jndiName = resource.getName();
/* 5370 */       for (InjectionTarget injectionTarget : injectionTargets) {
/* 5371 */         String clazz = injectionTarget.getTargetClass();
/* 5372 */         Map<String, String> injections = (Map)injectionMap.get(clazz);
/* 5373 */         if (injections == null) {
/* 5374 */           injections = new HashMap();
/* 5375 */           injectionMap.put(clazz, injections);
/*      */         }
/* 5377 */         injections.put(injectionTarget.getTargetName(), jndiName);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void mergeParameters()
/*      */   {
/* 5391 */     Map<String, String> mergedParams = new HashMap();
/*      */     
/* 5393 */     String[] names = findParameters();
/* 5394 */     String[] arrayOfString1 = names;int i = arrayOfString1.length; for (Object localObject = 0; localObject < i; localObject++) { s = arrayOfString1[localObject];
/* 5395 */       mergedParams.put(s, findParameter(s));
/*      */     }
/*      */     
/* 5398 */     ApplicationParameter[] params = findApplicationParameters();
/* 5399 */     ApplicationParameter[] arrayOfApplicationParameter1 = params;localObject = arrayOfApplicationParameter1.length; for (String s = 0; s < localObject; s++) { ApplicationParameter param = arrayOfApplicationParameter1[s];
/* 5400 */       if (param.getOverride()) {
/* 5401 */         if (mergedParams.get(param.getName()) == null) {
/* 5402 */           mergedParams.put(param.getName(), param
/* 5403 */             .getValue());
/*      */         }
/*      */       } else {
/* 5406 */         mergedParams.put(param.getName(), param.getValue());
/*      */       }
/*      */     }
/*      */     
/* 5410 */     ServletContext sc = getServletContext();
/* 5411 */     for (localObject = mergedParams.entrySet().iterator(); ((Iterator)localObject).hasNext();) { Map.Entry<String, String> entry = (Map.Entry)((Iterator)localObject).next();
/* 5412 */       sc.setInitParameter((String)entry.getKey(), (String)entry.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 5429 */     if (getObjectName() != null)
/*      */     {
/*      */ 
/* 5432 */       Notification notification = new Notification("j2ee.state.stopping", getObjectName(), this.sequenceNumber.getAndIncrement());
/* 5433 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5440 */     long limit = System.currentTimeMillis() + this.unloadDelay;
/* 5441 */     for (;;) { if ((this.inProgressAsyncCount.get() > 0L) && (System.currentTimeMillis() < limit)) {
/*      */         try {
/* 5443 */           Thread.sleep(50L);
/*      */         } catch (InterruptedException e) {
/* 5445 */           log.info(sm.getString("standardContext.stop.asyncWaitInterrupted"), e);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5452 */     setState(LifecycleState.STOPPING);
/*      */     
/*      */ 
/* 5455 */     ClassLoader oldCCL = bindThread();
/*      */     
/*      */     try
/*      */     {
/* 5459 */       Container[] children = findChildren();
/*      */       
/*      */ 
/* 5462 */       threadStop();
/*      */       
/* 5464 */       for (Container child : children) {
/* 5465 */         child.stop();
/*      */       }
/*      */       
/*      */ 
/* 5469 */       filterStop();
/*      */       
/* 5471 */       Manager manager = getManager();
/* 5472 */       if (((manager instanceof Lifecycle)) && (((Lifecycle)manager).getState().isAvailable())) {
/* 5473 */         ((Lifecycle)manager).stop();
/*      */       }
/*      */       
/*      */ 
/* 5477 */       listenerStop();
/*      */       
/*      */ 
/* 5480 */       setCharsetMapper(null);
/*      */       
/*      */ 
/* 5483 */       if (log.isDebugEnabled()) {
/* 5484 */         log.debug("Processing standard container shutdown");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5491 */       if (this.namingResources != null) {
/* 5492 */         this.namingResources.stop();
/*      */       }
/*      */       
/* 5495 */       fireLifecycleEvent("configure_stop", null);
/*      */       
/*      */ 
/* 5498 */       if (((this.pipeline instanceof Lifecycle)) && 
/* 5499 */         (((Lifecycle)this.pipeline).getState().isAvailable())) {
/* 5500 */         ((Lifecycle)this.pipeline).stop();
/*      */       }
/*      */       
/*      */ 
/* 5504 */       if (this.context != null) {
/* 5505 */         this.context.clearAttributes();
/*      */       }
/*      */       
/* 5508 */       Realm realm = getRealmInternal();
/* 5509 */       if ((realm instanceof Lifecycle)) {
/* 5510 */         ((Lifecycle)realm).stop();
/*      */       }
/* 5512 */       Loader loader = getLoader();
/* 5513 */       if ((loader instanceof Lifecycle)) {
/* 5514 */         ClassLoader classLoader = loader.getClassLoader();
/* 5515 */         ((Lifecycle)loader).stop();
/* 5516 */         if (classLoader != null) {
/* 5517 */           InstanceManagerBindings.unbind(classLoader);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 5522 */       resourcesStop();
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/* 5527 */       unbindThread(oldCCL);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5532 */     if (getObjectName() != null)
/*      */     {
/*      */ 
/* 5535 */       Notification notification = new Notification("j2ee.state.stopped", getObjectName(), this.sequenceNumber.getAndIncrement());
/* 5536 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/*      */ 
/* 5540 */     this.context = null;
/*      */     
/*      */     try
/*      */     {
/* 5544 */       resetContext();
/*      */     } catch (Exception ex) {
/* 5546 */       log.error("Error resetting context " + this + " " + ex, ex);
/*      */     }
/*      */     
/*      */ 
/* 5550 */     setInstanceManager(null);
/*      */     
/* 5552 */     if (log.isDebugEnabled()) {
/* 5553 */       log.debug("Stopping complete");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void destroyInternal()
/*      */     throws LifecycleException
/*      */   {
/* 5573 */     if (getObjectName() != null)
/*      */     {
/*      */ 
/*      */ 
/* 5577 */       Notification notification = new Notification("j2ee.object.deleted", getObjectName(), this.sequenceNumber.getAndIncrement());
/* 5578 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */     
/* 5581 */     if (this.namingResources != null) {
/* 5582 */       this.namingResources.destroy();
/*      */     }
/*      */     
/* 5585 */     Loader loader = getLoader();
/* 5586 */     if ((loader instanceof Lifecycle)) {
/* 5587 */       ((Lifecycle)loader).destroy();
/*      */     }
/*      */     
/* 5590 */     Manager manager = getManager();
/* 5591 */     if ((manager instanceof Lifecycle)) {
/* 5592 */       ((Lifecycle)manager).destroy();
/*      */     }
/*      */     
/* 5595 */     if (this.resources != null) {
/* 5596 */       this.resources.destroy();
/*      */     }
/*      */     
/* 5599 */     super.destroyInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void backgroundProcess()
/*      */   {
/* 5606 */     if (!getState().isAvailable()) {
/* 5607 */       return;
/*      */     }
/*      */     
/* 5610 */     Loader loader = getLoader();
/* 5611 */     if (loader != null) {
/*      */       try {
/* 5613 */         loader.backgroundProcess();
/*      */       } catch (Exception e) {
/* 5615 */         log.warn(sm.getString("standardContext.backgroundProcess.loader", new Object[] { loader }), e);
/*      */       }
/*      */     }
/*      */     
/* 5619 */     Manager manager = getManager();
/* 5620 */     if (manager != null) {
/*      */       try {
/* 5622 */         manager.backgroundProcess();
/*      */       } catch (Exception e) {
/* 5624 */         log.warn(sm.getString("standardContext.backgroundProcess.manager", new Object[] { manager }), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5629 */     WebResourceRoot resources = getResources();
/* 5630 */     if (resources != null) {
/*      */       try {
/* 5632 */         resources.backgroundProcess();
/*      */       } catch (Exception e) {
/* 5634 */         log.warn(sm.getString("standardContext.backgroundProcess.resources", new Object[] { resources }), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5639 */     InstanceManager instanceManager = getInstanceManager();
/* 5640 */     if (instanceManager != null) {
/*      */       try {
/* 5642 */         instanceManager.backgroundProcess();
/*      */       } catch (Exception e) {
/* 5644 */         log.warn(sm.getString("standardContext.backgroundProcess.instanceManager", new Object[] { resources }), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5649 */     super.backgroundProcess();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void resetContext()
/*      */     throws Exception
/*      */   {
/* 5660 */     for (Container child : findChildren()) {
/* 5661 */       removeChild(child);
/*      */     }
/* 5663 */     this.startupTime = 0L;
/* 5664 */     this.startTime = 0L;
/* 5665 */     this.tldScanTime = 0L;
/*      */     
/*      */ 
/* 5668 */     this.distributable = false;
/*      */     
/* 5670 */     this.applicationListeners = new String[0];
/* 5671 */     this.applicationEventListenersList.clear();
/* 5672 */     this.applicationLifecycleListenersObjects = new Object[0];
/* 5673 */     this.jspConfigDescriptor = null;
/*      */     
/* 5675 */     this.initializers.clear();
/*      */     
/* 5677 */     this.createdServlets.clear();
/*      */     
/* 5679 */     this.postConstructMethods.clear();
/* 5680 */     this.preDestroyMethods.clear();
/*      */     
/* 5682 */     if (log.isDebugEnabled()) {
/* 5683 */       log.debug("resetContext " + getObjectName());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String adjustURLPattern(String urlPattern)
/*      */   {
/* 5701 */     if (urlPattern == null) {
/* 5702 */       return urlPattern;
/*      */     }
/* 5704 */     if ((urlPattern.startsWith("/")) || (urlPattern.startsWith("*."))) {
/* 5705 */       return urlPattern;
/*      */     }
/* 5707 */     if (!isServlet22()) {
/* 5708 */       return urlPattern;
/*      */     }
/* 5710 */     if (log.isDebugEnabled()) {
/* 5711 */       log.debug(sm.getString("standardContext.urlPattern.patternWarning", new Object[] { urlPattern }));
/*      */     }
/*      */     
/* 5714 */     return "/" + urlPattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isServlet22()
/*      */   {
/* 5726 */     return "-//Sun Microsystems, Inc.//DTD Web Application 2.2//EN".equals(this.publicId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> addServletSecurity(ServletRegistration.Dynamic registration, ServletSecurityElement servletSecurityElement)
/*      */   {
/* 5735 */     Set<String> conflicts = new HashSet();
/*      */     
/* 5737 */     Collection<String> urlPatterns = registration.getMappings();
/* 5738 */     for (String urlPattern : urlPatterns) {
/* 5739 */       boolean foundConflict = false;
/*      */       
/*      */ 
/* 5742 */       SecurityConstraint[] securityConstraints = findConstraints();
/* 5743 */       SecurityConstraint[] arrayOfSecurityConstraint1 = securityConstraints;int i = arrayOfSecurityConstraint1.length; SecurityConstraint securityConstraint; for (SecurityConstraint localSecurityConstraint1 = 0; localSecurityConstraint1 < i; localSecurityConstraint1++) { securityConstraint = arrayOfSecurityConstraint1[localSecurityConstraint1];
/*      */         
/*      */ 
/* 5746 */         SecurityCollection[] collections = securityConstraint.findCollections();
/* 5747 */         for (SecurityCollection collection : collections) {
/* 5748 */           if (collection.findPattern(urlPattern))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 5753 */             if (collection.isFromDescriptor())
/*      */             {
/* 5755 */               foundConflict = true;
/* 5756 */               conflicts.add(urlPattern);
/* 5757 */               break;
/*      */             }
/*      */             
/* 5760 */             collection.removePattern(urlPattern);
/*      */             
/* 5762 */             if (collection.findPatterns().length == 0) {
/* 5763 */               securityConstraint.removeCollection(collection);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5770 */         if (securityConstraint.findCollections().length == 0) {
/* 5771 */           removeConstraint(securityConstraint);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5776 */         if (foundConflict) {
/*      */           break;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5790 */       if (!foundConflict)
/*      */       {
/* 5792 */         SecurityConstraint[] newSecurityConstraints = SecurityConstraint.createConstraints(servletSecurityElement, urlPattern);
/*      */         
/*      */ 
/*      */ 
/* 5796 */         SecurityConstraint[] arrayOfSecurityConstraint2 = newSecurityConstraints;localSecurityConstraint1 = arrayOfSecurityConstraint2.length; for (securityConstraint = 0; securityConstraint < localSecurityConstraint1; securityConstraint++) { SecurityConstraint securityConstraint = arrayOfSecurityConstraint2[securityConstraint];
/* 5797 */           addConstraint(securityConstraint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 5802 */     return conflicts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ClassLoader bindThread()
/*      */   {
/* 5814 */     ClassLoader oldContextClassLoader = bind(false, null);
/*      */     
/* 5816 */     if (isUseNaming()) {
/*      */       try {
/* 5818 */         ContextBindings.bindThread(this, getNamingToken());
/*      */       }
/*      */       catch (NamingException localNamingException) {}
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5825 */     return oldContextClassLoader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void unbindThread(ClassLoader oldContextClassLoader)
/*      */   {
/* 5836 */     if (isUseNaming()) {
/* 5837 */       ContextBindings.unbindThread(this, getNamingToken());
/*      */     }
/*      */     
/* 5840 */     unbind(false, oldContextClassLoader);
/*      */   }
/*      */   
/*      */ 
/*      */   public ClassLoader bind(boolean usePrivilegedAction, ClassLoader originalClassLoader)
/*      */   {
/* 5846 */     Loader loader = getLoader();
/* 5847 */     ClassLoader webApplicationClassLoader = null;
/* 5848 */     if (loader != null) {
/* 5849 */       webApplicationClassLoader = loader.getClassLoader();
/*      */     }
/*      */     
/* 5852 */     if (originalClassLoader == null) {
/* 5853 */       if (usePrivilegedAction) {
/* 5854 */         PrivilegedAction<ClassLoader> pa = new PrivilegedGetTccl();
/* 5855 */         originalClassLoader = (ClassLoader)AccessController.doPrivileged(pa);
/*      */       } else {
/* 5857 */         originalClassLoader = Thread.currentThread().getContextClassLoader();
/*      */       }
/*      */     }
/*      */     
/* 5861 */     if ((webApplicationClassLoader == null) || (webApplicationClassLoader == originalClassLoader))
/*      */     {
/*      */ 
/*      */ 
/* 5865 */       return null;
/*      */     }
/*      */     
/* 5868 */     ThreadBindingListener threadBindingListener = getThreadBindingListener();
/*      */     
/* 5870 */     if (usePrivilegedAction) {
/* 5871 */       PrivilegedAction<Void> pa = new PrivilegedSetTccl(webApplicationClassLoader);
/* 5872 */       AccessController.doPrivileged(pa);
/*      */     } else {
/* 5874 */       Thread.currentThread().setContextClassLoader(webApplicationClassLoader);
/*      */     }
/* 5876 */     if (threadBindingListener != null) {
/*      */       try {
/* 5878 */         threadBindingListener.bind();
/*      */       } catch (Throwable t) {
/* 5880 */         ExceptionUtils.handleThrowable(t);
/* 5881 */         log.error(sm.getString("standardContext.threadBindingListenerError", new Object[] {
/* 5882 */           getName() }), t);
/*      */       }
/*      */     }
/*      */     
/* 5886 */     return originalClassLoader;
/*      */   }
/*      */   
/*      */ 
/*      */   public void unbind(boolean usePrivilegedAction, ClassLoader originalClassLoader)
/*      */   {
/* 5892 */     if (originalClassLoader == null) {
/* 5893 */       return;
/*      */     }
/*      */     
/* 5896 */     if (this.threadBindingListener != null) {
/*      */       try {
/* 5898 */         this.threadBindingListener.unbind();
/*      */       } catch (Throwable t) {
/* 5900 */         ExceptionUtils.handleThrowable(t);
/* 5901 */         log.error(sm.getString("standardContext.threadBindingListenerError", new Object[] {
/* 5902 */           getName() }), t);
/*      */       }
/*      */     }
/*      */     
/* 5906 */     if (usePrivilegedAction) {
/* 5907 */       PrivilegedAction<Void> pa = new PrivilegedSetTccl(originalClassLoader);
/* 5908 */       AccessController.doPrivileged(pa);
/*      */     } else {
/* 5910 */       Thread.currentThread().setContextClassLoader(originalClassLoader);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getNamingContextName()
/*      */   {
/* 5921 */     if (this.namingContextName == null) {
/* 5922 */       Container parent = getParent();
/* 5923 */       if (parent == null) {
/* 5924 */         this.namingContextName = getName();
/*      */       } else {
/* 5926 */         Stack<String> stk = new Stack();
/* 5927 */         StringBuilder buff = new StringBuilder();
/* 5928 */         while (parent != null) {
/* 5929 */           stk.push(parent.getName());
/* 5930 */           parent = parent.getParent();
/*      */         }
/* 5932 */         while (!stk.empty()) {
/* 5933 */           buff.append("/" + (String)stk.pop());
/*      */         }
/* 5935 */         buff.append(getName());
/* 5936 */         this.namingContextName = buff.toString();
/*      */       }
/*      */     }
/* 5939 */     return this.namingContextName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NamingContextListener getNamingContextListener()
/*      */   {
/* 5949 */     return this.namingContextListener;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNamingContextListener(NamingContextListener namingContextListener)
/*      */   {
/* 5959 */     this.namingContextListener = namingContextListener;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getPaused()
/*      */   {
/* 5968 */     return this.paused;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean fireRequestInitEvent(ServletRequest request)
/*      */   {
/* 5975 */     Object[] instances = getApplicationEventListeners();
/*      */     
/* 5977 */     if ((instances != null) && (instances.length > 0))
/*      */     {
/*      */ 
/* 5980 */       ServletRequestEvent event = new ServletRequestEvent(getServletContext(), request);
/*      */       
/* 5982 */       for (Object instance : instances)
/* 5983 */         if (instance != null)
/*      */         {
/*      */ 
/* 5986 */           if ((instance instanceof ServletRequestListener))
/*      */           {
/*      */ 
/* 5989 */             ServletRequestListener listener = (ServletRequestListener)instance;
/*      */             try
/*      */             {
/* 5992 */               listener.requestInitialized(event);
/*      */             } catch (Throwable t) {
/* 5994 */               ExceptionUtils.handleThrowable(t);
/* 5995 */               getLogger().error(sm.getString("standardContext.requestListener.requestInit", new Object[] {instance
/*      */               
/* 5997 */                 .getClass().getName() }), t);
/* 5998 */               request.setAttribute("javax.servlet.error.exception", t);
/* 5999 */               return false;
/*      */             }
/*      */           } }
/*      */     }
/* 6003 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean fireRequestDestroyEvent(ServletRequest request)
/*      */   {
/* 6009 */     Object[] instances = getApplicationEventListeners();
/*      */     
/* 6011 */     if ((instances != null) && (instances.length > 0))
/*      */     {
/*      */ 
/* 6014 */       ServletRequestEvent event = new ServletRequestEvent(getServletContext(), request);
/*      */       
/* 6016 */       for (int i = 0; i < instances.length; i++) {
/* 6017 */         int j = instances.length - 1 - i;
/* 6018 */         if (instances[j] != null)
/*      */         {
/*      */ 
/* 6021 */           if ((instances[j] instanceof ServletRequestListener))
/*      */           {
/*      */ 
/* 6024 */             ServletRequestListener listener = (ServletRequestListener)instances[j];
/*      */             
/*      */             try
/*      */             {
/* 6028 */               listener.requestDestroyed(event);
/*      */             } catch (Throwable t) {
/* 6030 */               ExceptionUtils.handleThrowable(t);
/* 6031 */               getLogger().error(sm.getString("standardContext.requestListener.requestInit", new Object[] {instances[j]
/*      */               
/* 6033 */                 .getClass().getName() }), t);
/* 6034 */               request.setAttribute("javax.servlet.error.exception", t);
/* 6035 */               return false;
/*      */             }
/*      */           } }
/*      */       } }
/* 6039 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   public void addPostConstructMethod(String clazz, String method)
/*      */   {
/* 6045 */     if ((clazz == null) || (method == null))
/*      */     {
/* 6047 */       throw new IllegalArgumentException(sm.getString("standardContext.postconstruct.required"));
/*      */     }
/* 6049 */     if (this.postConstructMethods.get(clazz) != null) {
/* 6050 */       throw new IllegalArgumentException(sm.getString("standardContext.postconstruct.duplicate", new Object[] { clazz }));
/*      */     }
/*      */     
/*      */ 
/* 6054 */     this.postConstructMethods.put(clazz, method);
/* 6055 */     fireContainerEvent("addPostConstructMethod", clazz);
/*      */   }
/*      */   
/*      */ 
/*      */   public void removePostConstructMethod(String clazz)
/*      */   {
/* 6061 */     this.postConstructMethods.remove(clazz);
/* 6062 */     fireContainerEvent("removePostConstructMethod", clazz);
/*      */   }
/*      */   
/*      */ 
/*      */   public void addPreDestroyMethod(String clazz, String method)
/*      */   {
/* 6068 */     if ((clazz == null) || (method == null))
/*      */     {
/* 6070 */       throw new IllegalArgumentException(sm.getString("standardContext.predestroy.required"));
/*      */     }
/* 6072 */     if (this.preDestroyMethods.get(clazz) != null) {
/* 6073 */       throw new IllegalArgumentException(sm.getString("standardContext.predestroy.duplicate", new Object[] { clazz }));
/*      */     }
/*      */     
/*      */ 
/* 6077 */     this.preDestroyMethods.put(clazz, method);
/* 6078 */     fireContainerEvent("addPreDestroyMethod", clazz);
/*      */   }
/*      */   
/*      */ 
/*      */   public void removePreDestroyMethod(String clazz)
/*      */   {
/* 6084 */     this.preDestroyMethods.remove(clazz);
/* 6085 */     fireContainerEvent("removePreDestroyMethod", clazz);
/*      */   }
/*      */   
/*      */ 
/*      */   public String findPostConstructMethod(String clazz)
/*      */   {
/* 6091 */     return (String)this.postConstructMethods.get(clazz);
/*      */   }
/*      */   
/*      */ 
/*      */   public String findPreDestroyMethod(String clazz)
/*      */   {
/* 6097 */     return (String)this.preDestroyMethods.get(clazz);
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, String> findPostConstructMethods()
/*      */   {
/* 6103 */     return this.postConstructMethods;
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, String> findPreDestroyMethods()
/*      */   {
/* 6109 */     return this.preDestroyMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void postWorkDirectory()
/*      */   {
/* 6119 */     String workDir = getWorkDir();
/* 6120 */     if ((workDir == null) || (workDir.length() == 0))
/*      */     {
/*      */ 
/* 6123 */       String hostName = null;
/* 6124 */       String engineName = null;
/* 6125 */       String hostWorkDir = null;
/* 6126 */       Container parentHost = getParent();
/* 6127 */       if (parentHost != null) {
/* 6128 */         hostName = parentHost.getName();
/* 6129 */         if ((parentHost instanceof StandardHost)) {
/* 6130 */           hostWorkDir = ((StandardHost)parentHost).getWorkDir();
/*      */         }
/* 6132 */         Container parentEngine = parentHost.getParent();
/* 6133 */         if (parentEngine != null) {
/* 6134 */           engineName = parentEngine.getName();
/*      */         }
/*      */       }
/* 6137 */       if ((hostName == null) || (hostName.length() < 1)) {
/* 6138 */         hostName = "_";
/*      */       }
/* 6140 */       if ((engineName == null) || (engineName.length() < 1)) {
/* 6141 */         engineName = "_";
/*      */       }
/*      */       
/* 6144 */       String temp = getBaseName();
/* 6145 */       if (temp.startsWith("/")) {
/* 6146 */         temp = temp.substring(1);
/*      */       }
/* 6148 */       temp = temp.replace('/', '_');
/* 6149 */       temp = temp.replace('\\', '_');
/* 6150 */       if (temp.length() < 1) {
/* 6151 */         temp = "ROOT";
/*      */       }
/* 6153 */       if (hostWorkDir != null) {
/* 6154 */         workDir = hostWorkDir + File.separator + temp;
/*      */       } else {
/* 6156 */         workDir = "work" + File.separator + engineName + File.separator + hostName + File.separator + temp;
/*      */       }
/*      */       
/* 6159 */       setWorkDir(workDir);
/*      */     }
/*      */     
/*      */ 
/* 6163 */     File dir = new File(workDir);
/* 6164 */     if (!dir.isAbsolute()) {
/* 6165 */       String catalinaHomePath = null;
/*      */       try {
/* 6167 */         catalinaHomePath = getCatalinaBase().getCanonicalPath();
/* 6168 */         dir = new File(catalinaHomePath, workDir);
/*      */       } catch (IOException e) {
/* 6170 */         log.warn(sm.getString("standardContext.workCreateException", new Object[] { workDir, catalinaHomePath, 
/* 6171 */           getName() }), e);
/*      */       }
/*      */     }
/* 6174 */     if ((!dir.mkdirs()) && (!dir.isDirectory())) {
/* 6175 */       log.warn(sm.getString("standardContext.workCreateFail", new Object[] { dir, 
/* 6176 */         getName() }));
/*      */     }
/*      */     
/*      */ 
/* 6180 */     if (this.context == null) {
/* 6181 */       getServletContext();
/*      */     }
/* 6183 */     this.context.setAttribute("javax.servlet.context.tempdir", dir);
/* 6184 */     this.context.setAttributeReadOnly("javax.servlet.context.tempdir");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setPaused(boolean paused)
/*      */   {
/* 6195 */     this.paused = paused;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean validateURLPattern(String urlPattern)
/*      */   {
/* 6209 */     if (urlPattern == null) {
/* 6210 */       return false;
/*      */     }
/* 6212 */     if ((urlPattern.indexOf('\n') >= 0) || (urlPattern.indexOf('\r') >= 0)) {
/* 6213 */       return false;
/*      */     }
/* 6215 */     if (urlPattern.equals("")) {
/* 6216 */       return true;
/*      */     }
/* 6218 */     if (urlPattern.startsWith("*.")) {
/* 6219 */       if (urlPattern.indexOf('/') < 0) {
/* 6220 */         checkUnusualURLPattern(urlPattern);
/* 6221 */         return true;
/*      */       }
/* 6223 */       return false;
/*      */     }
/*      */     
/* 6226 */     if ((urlPattern.startsWith("/")) && (!urlPattern.contains("*."))) {
/* 6227 */       checkUnusualURLPattern(urlPattern);
/* 6228 */       return true;
/*      */     }
/* 6230 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkUnusualURLPattern(String urlPattern)
/*      */   {
/* 6241 */     if (log.isInfoEnabled())
/*      */     {
/*      */ 
/* 6244 */       if (((urlPattern.endsWith("*")) && ((urlPattern.length() < 2) || 
/* 6245 */         (urlPattern.charAt(urlPattern.length() - 2) != '/'))) || (
/* 6246 */         (urlPattern.startsWith("*.")) && (urlPattern.length() > 2) && 
/* 6247 */         (urlPattern.lastIndexOf('.') > 1))) {
/* 6248 */         log.info(sm.getString("standardContext.suspiciousUrl", new Object[] { urlPattern, getName() }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getObjectNameKeyProperties()
/*      */   {
/* 6259 */     StringBuilder keyProperties = new StringBuilder("j2eeType=WebModule,");
/*      */     
/* 6261 */     keyProperties.append(getObjectKeyPropertiesNameOnly());
/* 6262 */     keyProperties.append(",J2EEApplication=");
/* 6263 */     keyProperties.append(getJ2EEApplication());
/* 6264 */     keyProperties.append(",J2EEServer=");
/* 6265 */     keyProperties.append(getJ2EEServer());
/*      */     
/* 6267 */     return keyProperties.toString();
/*      */   }
/*      */   
/*      */   private String getObjectKeyPropertiesNameOnly() {
/* 6271 */     StringBuilder result = new StringBuilder("name=//");
/* 6272 */     String hostname = getParent().getName();
/* 6273 */     if (hostname == null) {
/* 6274 */       result.append("DEFAULT");
/*      */     } else {
/* 6276 */       result.append(hostname);
/*      */     }
/*      */     
/* 6279 */     String contextName = getName();
/* 6280 */     if (!contextName.startsWith("/")) {
/* 6281 */       result.append('/');
/*      */     }
/* 6283 */     result.append(contextName);
/*      */     
/* 6285 */     return result.toString();
/*      */   }
/*      */   
/*      */   protected void initInternal() throws LifecycleException
/*      */   {
/* 6290 */     super.initInternal();
/*      */     
/*      */ 
/* 6293 */     if (this.namingResources != null) {
/* 6294 */       this.namingResources.init();
/*      */     }
/*      */     
/*      */ 
/* 6298 */     if (getObjectName() != null)
/*      */     {
/* 6300 */       Notification notification = new Notification("j2ee.object.created", getObjectName(), this.sequenceNumber.getAndIncrement());
/* 6301 */       this.broadcaster.sendNotification(notification);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeNotificationListener(NotificationListener listener, NotificationFilter filter, Object object)
/*      */     throws ListenerNotFoundException
/*      */   {
/* 6313 */     this.broadcaster.removeNotificationListener(listener, filter, object);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MBeanNotificationInfo[] getNotificationInfo()
/*      */   {
/* 6325 */     if (this.notificationInfo == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6353 */       this.notificationInfo = new MBeanNotificationInfo[] { new MBeanNotificationInfo(new String[] { "j2ee.object.created" }, Notification.class.getName(), "web application is created"), new MBeanNotificationInfo(new String[] { "j2ee.state.starting" }, Notification.class.getName(), "change web application is starting"), new MBeanNotificationInfo(new String[] { "j2ee.state.running" }, Notification.class.getName(), "web application is running"), new MBeanNotificationInfo(new String[] { "j2ee.state.stopping" }, Notification.class.getName(), "web application start to stopped"), new MBeanNotificationInfo(new String[] { "j2ee.object.stopped" }, Notification.class.getName(), "web application is stopped"), new MBeanNotificationInfo(new String[] { "j2ee.object.deleted" }, Notification.class.getName(), "web application is deleted"), new MBeanNotificationInfo(new String[] { "j2ee.object.failed" }, Notification.class.getName(), "web application failed") };
/*      */     }
/*      */     
/*      */ 
/* 6357 */     return this.notificationInfo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addNotificationListener(NotificationListener listener, NotificationFilter filter, Object object)
/*      */     throws IllegalArgumentException
/*      */   {
/* 6368 */     this.broadcaster.addNotificationListener(listener, filter, object);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeNotificationListener(NotificationListener listener)
/*      */     throws ListenerNotFoundException
/*      */   {
/* 6379 */     this.broadcaster.removeNotificationListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getWelcomeFiles()
/*      */   {
/* 6390 */     return findWelcomeFiles();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getXmlNamespaceAware()
/*      */   {
/* 6397 */     return this.webXmlNamespaceAware;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setXmlNamespaceAware(boolean webXmlNamespaceAware)
/*      */   {
/* 6403 */     this.webXmlNamespaceAware = webXmlNamespaceAware;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setXmlValidation(boolean webXmlValidation)
/*      */   {
/* 6409 */     this.webXmlValidation = webXmlValidation;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getXmlValidation()
/*      */   {
/* 6415 */     return this.webXmlValidation;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setXmlBlockExternal(boolean xmlBlockExternal)
/*      */   {
/* 6421 */     this.xmlBlockExternal = xmlBlockExternal;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getXmlBlockExternal()
/*      */   {
/* 6427 */     return this.xmlBlockExternal;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTldValidation(boolean tldValidation)
/*      */   {
/* 6433 */     this.tldValidation = tldValidation;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getTldValidation()
/*      */   {
/* 6439 */     return this.tldValidation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6446 */   private String server = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 6451 */   private String[] javaVMs = null;
/*      */   
/*      */   public String getServer() {
/* 6454 */     return this.server;
/*      */   }
/*      */   
/*      */   public String setServer(String server) {
/* 6458 */     return this.server = server;
/*      */   }
/*      */   
/*      */   public String[] getJavaVMs() {
/* 6462 */     return this.javaVMs;
/*      */   }
/*      */   
/*      */   public String[] setJavaVMs(String[] javaVMs) {
/* 6466 */     return this.javaVMs = javaVMs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getStartTime()
/*      */   {
/* 6476 */     return this.startTime;
/*      */   }
/*      */   
/*      */   private static class NoPluggabilityServletContext
/*      */     implements ServletContext
/*      */   {
/*      */     private final ServletContext sc;
/*      */     
/*      */     public NoPluggabilityServletContext(ServletContext sc)
/*      */     {
/* 6486 */       this.sc = sc;
/*      */     }
/*      */     
/*      */     public String getContextPath()
/*      */     {
/* 6491 */       return this.sc.getContextPath();
/*      */     }
/*      */     
/*      */     public ServletContext getContext(String uripath)
/*      */     {
/* 6496 */       return this.sc.getContext(uripath);
/*      */     }
/*      */     
/*      */     public int getMajorVersion()
/*      */     {
/* 6501 */       return this.sc.getMajorVersion();
/*      */     }
/*      */     
/*      */     public int getMinorVersion()
/*      */     {
/* 6506 */       return this.sc.getMinorVersion();
/*      */     }
/*      */     
/*      */ 
/*      */     public int getEffectiveMajorVersion()
/*      */     {
/* 6512 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public int getEffectiveMinorVersion()
/*      */     {
/* 6518 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */     public String getMimeType(String file)
/*      */     {
/* 6523 */       return this.sc.getMimeType(file);
/*      */     }
/*      */     
/*      */     public Set<String> getResourcePaths(String path)
/*      */     {
/* 6528 */       return this.sc.getResourcePaths(path);
/*      */     }
/*      */     
/*      */     public URL getResource(String path) throws MalformedURLException
/*      */     {
/* 6533 */       return this.sc.getResource(path);
/*      */     }
/*      */     
/*      */     public InputStream getResourceAsStream(String path)
/*      */     {
/* 6538 */       return this.sc.getResourceAsStream(path);
/*      */     }
/*      */     
/*      */     public RequestDispatcher getRequestDispatcher(String path)
/*      */     {
/* 6543 */       return this.sc.getRequestDispatcher(path);
/*      */     }
/*      */     
/*      */     public RequestDispatcher getNamedDispatcher(String name)
/*      */     {
/* 6548 */       return this.sc.getNamedDispatcher(name);
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Servlet getServlet(String name) throws ServletException
/*      */     {
/* 6554 */       return this.sc.getServlet(name);
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Enumeration<Servlet> getServlets()
/*      */     {
/* 6560 */       return this.sc.getServlets();
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public Enumeration<String> getServletNames()
/*      */     {
/* 6566 */       return this.sc.getServletNames();
/*      */     }
/*      */     
/*      */     public void log(String msg)
/*      */     {
/* 6571 */       this.sc.log(msg);
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public void log(Exception exception, String msg)
/*      */     {
/* 6577 */       this.sc.log(exception, msg);
/*      */     }
/*      */     
/*      */     public void log(String message, Throwable throwable)
/*      */     {
/* 6582 */       this.sc.log(message, throwable);
/*      */     }
/*      */     
/*      */     public String getRealPath(String path)
/*      */     {
/* 6587 */       return this.sc.getRealPath(path);
/*      */     }
/*      */     
/*      */     public String getServerInfo()
/*      */     {
/* 6592 */       return this.sc.getServerInfo();
/*      */     }
/*      */     
/*      */     public String getInitParameter(String name)
/*      */     {
/* 6597 */       return this.sc.getInitParameter(name);
/*      */     }
/*      */     
/*      */     public Enumeration<String> getInitParameterNames()
/*      */     {
/* 6602 */       return this.sc.getInitParameterNames();
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean setInitParameter(String name, String value)
/*      */     {
/* 6608 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */     public Object getAttribute(String name)
/*      */     {
/* 6613 */       return this.sc.getAttribute(name);
/*      */     }
/*      */     
/*      */     public Enumeration<String> getAttributeNames()
/*      */     {
/* 6618 */       return this.sc.getAttributeNames();
/*      */     }
/*      */     
/*      */     public void setAttribute(String name, Object object)
/*      */     {
/* 6623 */       this.sc.setAttribute(name, object);
/*      */     }
/*      */     
/*      */     public void removeAttribute(String name)
/*      */     {
/* 6628 */       this.sc.removeAttribute(name);
/*      */     }
/*      */     
/*      */     public String getServletContextName()
/*      */     {
/* 6633 */       return this.sc.getServletContextName();
/*      */     }
/*      */     
/*      */ 
/*      */     public ServletRegistration.Dynamic addServlet(String servletName, String className)
/*      */     {
/* 6639 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public ServletRegistration.Dynamic addServlet(String servletName, Servlet servlet)
/*      */     {
/* 6645 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public ServletRegistration.Dynamic addServlet(String servletName, Class<? extends Servlet> servletClass)
/*      */     {
/* 6652 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public ServletRegistration.Dynamic addJspFile(String jspName, String jspFile)
/*      */     {
/* 6658 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public <T extends Servlet> T createServlet(Class<T> c)
/*      */       throws ServletException
/*      */     {
/* 6665 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public ServletRegistration getServletRegistration(String servletName)
/*      */     {
/* 6671 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public Map<String, ? extends ServletRegistration> getServletRegistrations()
/*      */     {
/* 6677 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public FilterRegistration.Dynamic addFilter(String filterName, String className)
/*      */     {
/* 6684 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public FilterRegistration.Dynamic addFilter(String filterName, Filter filter)
/*      */     {
/* 6691 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public FilterRegistration.Dynamic addFilter(String filterName, Class<? extends Filter> filterClass)
/*      */     {
/* 6698 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public <T extends Filter> T createFilter(Class<T> c)
/*      */       throws ServletException
/*      */     {
/* 6705 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public FilterRegistration getFilterRegistration(String filterName)
/*      */     {
/* 6711 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public Map<String, ? extends FilterRegistration> getFilterRegistrations()
/*      */     {
/* 6717 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public SessionCookieConfig getSessionCookieConfig()
/*      */     {
/* 6723 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setSessionTrackingModes(Set<SessionTrackingMode> sessionTrackingModes)
/*      */     {
/* 6730 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public Set<SessionTrackingMode> getDefaultSessionTrackingModes()
/*      */     {
/* 6736 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public Set<SessionTrackingMode> getEffectiveSessionTrackingModes()
/*      */     {
/* 6742 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public void addListener(String className)
/*      */     {
/* 6748 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public <T extends EventListener> void addListener(T t)
/*      */     {
/* 6754 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public void addListener(Class<? extends EventListener> listenerClass)
/*      */     {
/* 6760 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public <T extends EventListener> T createListener(Class<T> c)
/*      */       throws ServletException
/*      */     {
/* 6767 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public JspConfigDescriptor getJspConfigDescriptor()
/*      */     {
/* 6773 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public ClassLoader getClassLoader()
/*      */     {
/* 6779 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public void declareRoles(String... roleNames)
/*      */     {
/* 6785 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */     public String getVirtualServerName()
/*      */     {
/* 6790 */       return this.sc.getVirtualServerName();
/*      */     }
/*      */     
/*      */ 
/*      */     public int getSessionTimeout()
/*      */     {
/* 6796 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public void setSessionTimeout(int sessionTimeout)
/*      */     {
/* 6802 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public String getRequestCharacterEncoding()
/*      */     {
/* 6808 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public void setRequestCharacterEncoding(String encoding)
/*      */     {
/* 6814 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public String getResponseCharacterEncoding()
/*      */     {
/* 6820 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */     
/*      */ 
/*      */     public void setResponseCharacterEncoding(String encoding)
/*      */     {
/* 6826 */       throw new UnsupportedOperationException(ContainerBase.sm.getString("noPluggabilityServletContext.notAllowed"));
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\StandardContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */