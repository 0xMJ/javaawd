/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetCharacterEncodingFilter
/*     */   extends FilterBase
/*     */ {
/*  59 */   private final Log log = LogFactory.getLog(SetCharacterEncodingFilter.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */   private String encoding = null;
/*  69 */   public void setEncoding(String encoding) { this.encoding = encoding; }
/*  70 */   public String getEncoding() { return this.encoding; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */   private boolean ignore = false;
/*  77 */   public void setIgnore(boolean ignore) { this.ignore = ignore; }
/*  78 */   public boolean isIgnore() { return this.ignore; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/* 101 */     if ((this.ignore) || (request.getCharacterEncoding() == null)) {
/* 102 */       String characterEncoding = selectEncoding(request);
/* 103 */       if (characterEncoding != null) {
/* 104 */         request.setCharacterEncoding(characterEncoding);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 109 */     chain.doFilter(request, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Log getLogger()
/*     */   {
/* 117 */     return this.log;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String selectEncoding(ServletRequest request)
/*     */   {
/* 135 */     return this.encoding;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\filters\SetCharacterEncodingFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */