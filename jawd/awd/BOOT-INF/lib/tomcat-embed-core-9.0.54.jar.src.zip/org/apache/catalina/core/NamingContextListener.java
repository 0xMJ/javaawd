/*      */ package org.apache.catalina.core;
/*      */ 
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.management.MalformedObjectNameException;
/*      */ import javax.management.ObjectName;
/*      */ import javax.naming.NameAlreadyBoundException;
/*      */ import javax.naming.NamingException;
/*      */ import javax.naming.Reference;
/*      */ import javax.naming.StringRefAddr;
/*      */ import javax.servlet.ServletContext;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.ContainerEvent;
/*      */ import org.apache.catalina.ContainerListener;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleEvent;
/*      */ import org.apache.catalina.LifecycleListener;
/*      */ import org.apache.catalina.Loader;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.naming.ContextAccessController;
/*      */ import org.apache.naming.ContextBindings;
/*      */ import org.apache.naming.EjbRef;
/*      */ import org.apache.naming.HandlerRef;
/*      */ import org.apache.naming.LookupRef;
/*      */ import org.apache.naming.NamingContext;
/*      */ import org.apache.naming.ResourceEnvRef;
/*      */ import org.apache.naming.ResourceLinkRef;
/*      */ import org.apache.naming.ResourceRef;
/*      */ import org.apache.naming.ServiceRef;
/*      */ import org.apache.naming.TransactionRef;
/*      */ import org.apache.naming.factory.ResourceLinkFactory;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextHandler;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextLocalEjb;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextResourceLink;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextService;
/*      */ import org.apache.tomcat.util.descriptor.web.ContextTransaction;
/*      */ import org.apache.tomcat.util.descriptor.web.MessageDestinationRef;
/*      */ import org.apache.tomcat.util.descriptor.web.ResourceBase;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NamingContextListener
/*      */   implements LifecycleListener, ContainerListener, PropertyChangeListener
/*      */ {
/*   86 */   private static final Log log = LogFactory.getLog(NamingContextListener.class);
/*   87 */   protected static final StringManager sm = StringManager.getManager(NamingContextListener.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   95 */   protected String name = "/";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  101 */   protected Object container = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  106 */   private Object token = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  111 */   protected boolean initialized = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  117 */   protected NamingResourcesImpl namingResources = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  123 */   protected NamingContext namingContext = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  129 */   protected javax.naming.Context compCtx = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  135 */   protected javax.naming.Context envCtx = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  141 */   protected HashMap<String, ObjectName> objectNames = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  148 */   private boolean exceptionOnFailedWrite = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getExceptionOnFailedWrite()
/*      */   {
/*  158 */     return this.exceptionOnFailedWrite;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExceptionOnFailedWrite(boolean exceptionOnFailedWrite)
/*      */   {
/*  169 */     this.exceptionOnFailedWrite = exceptionOnFailedWrite;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  177 */     return this.name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setName(String name)
/*      */   {
/*  187 */     this.name = name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public javax.naming.Context getEnvContext()
/*      */   {
/*  195 */     return this.envCtx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void lifecycleEvent(LifecycleEvent event)
/*      */   {
/*  209 */     this.container = event.getLifecycle();
/*      */     
/*  211 */     if ((this.container instanceof org.apache.catalina.Context)) {
/*  212 */       this.namingResources = ((org.apache.catalina.Context)this.container).getNamingResources();
/*  213 */       this.token = ((org.apache.catalina.Context)this.container).getNamingToken();
/*  214 */     } else if ((this.container instanceof Server)) {
/*  215 */       this.namingResources = ((Server)this.container).getGlobalNamingResources();
/*  216 */       this.token = ((Server)this.container).getNamingToken();
/*      */     } else {
/*  218 */       return;
/*      */     }
/*      */     
/*  221 */     if ("configure_start".equals(event.getType()))
/*      */     {
/*  223 */       if (this.initialized) {
/*  224 */         return;
/*      */       }
/*      */       try
/*      */       {
/*  228 */         Hashtable<String, Object> contextEnv = new Hashtable();
/*  229 */         this.namingContext = new NamingContext(contextEnv, getName());
/*  230 */         ContextAccessController.setSecurityToken(getName(), this.token);
/*  231 */         ContextAccessController.setSecurityToken(this.container, this.token);
/*  232 */         ContextBindings.bindContext(this.container, this.namingContext, this.token);
/*  233 */         if (log.isDebugEnabled()) {
/*  234 */           log.debug("Bound " + this.container);
/*      */         }
/*      */         
/*      */ 
/*  238 */         this.namingContext.setExceptionOnFailedWrite(
/*  239 */           getExceptionOnFailedWrite());
/*      */         
/*      */ 
/*  242 */         ContextAccessController.setWritable(getName(), this.token);
/*      */         try
/*      */         {
/*  245 */           createNamingContext();
/*      */         }
/*      */         catch (NamingException e) {
/*  248 */           log.error(sm.getString("naming.namingContextCreationFailed", new Object[] { e }));
/*      */         }
/*      */         
/*  251 */         this.namingResources.addPropertyChangeListener(this);
/*      */         
/*      */ 
/*  254 */         if ((this.container instanceof org.apache.catalina.Context))
/*      */         {
/*  256 */           ContextAccessController.setReadOnly(getName());
/*      */           try {
/*  258 */             ContextBindings.bindClassLoader(this.container, this.token, ((org.apache.catalina.Context)this.container)
/*  259 */               .getLoader().getClassLoader());
/*      */           } catch (NamingException e) {
/*  261 */             log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */           }
/*      */         }
/*      */         
/*  265 */         if ((this.container instanceof Server))
/*      */         {
/*  267 */           ResourceLinkFactory.setGlobalContext(this.namingContext);
/*      */           try {
/*  269 */             ContextBindings.bindClassLoader(this.container, this.token, 
/*  270 */               getClass().getClassLoader());
/*      */           } catch (NamingException e) {
/*  272 */             log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */           }
/*  274 */           if ((this.container instanceof StandardServer))
/*      */           {
/*  276 */             ((StandardServer)this.container).setGlobalNamingContext(this.namingContext);
/*      */           }
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/*  282 */         this.initialized = true;
/*      */       }
/*      */     }
/*  285 */     else if ("configure_stop".equals(event.getType()))
/*      */     {
/*  287 */       if (!this.initialized) {
/*  288 */         return;
/*      */       }
/*      */       
/*      */       try
/*      */       {
/*  293 */         ContextAccessController.setWritable(getName(), this.token);
/*  294 */         ContextBindings.unbindContext(this.container, this.token);
/*      */         
/*  296 */         if ((this.container instanceof org.apache.catalina.Context)) {
/*  297 */           ContextBindings.unbindClassLoader(this.container, this.token, ((org.apache.catalina.Context)this.container)
/*  298 */             .getLoader().getClassLoader());
/*      */         }
/*      */         
/*  301 */         if ((this.container instanceof Server)) {
/*  302 */           ContextBindings.unbindClassLoader(this.container, this.token, 
/*  303 */             getClass().getClassLoader());
/*      */         }
/*      */         
/*  306 */         this.namingResources.removePropertyChangeListener(this);
/*      */         
/*  308 */         ContextAccessController.unsetSecurityToken(getName(), this.token);
/*  309 */         ContextAccessController.unsetSecurityToken(this.container, this.token);
/*      */         
/*      */         Registry registry;
/*  312 */         if (!this.objectNames.isEmpty()) {
/*  313 */           Collection<ObjectName> names = this.objectNames.values();
/*  314 */           registry = Registry.getRegistry(null, null);
/*  315 */           for (ObjectName objectName : names) {
/*  316 */             registry.unregisterComponent(objectName);
/*      */           }
/*      */         }
/*      */         
/*  320 */         javax.naming.Context global = getGlobalNamingContext();
/*  321 */         if (global != null) {
/*  322 */           ResourceLinkFactory.deregisterGlobalResourceAccess(global);
/*      */         }
/*      */       } finally {
/*  325 */         this.objectNames.clear();
/*      */         
/*  327 */         this.namingContext = null;
/*  328 */         this.envCtx = null;
/*  329 */         this.compCtx = null;
/*  330 */         this.initialized = false;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void containerEvent(ContainerEvent event) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void propertyChange(PropertyChangeEvent event)
/*      */   {
/*  367 */     if (!this.initialized) {
/*  368 */       return;
/*      */     }
/*      */     
/*  371 */     Object source = event.getSource();
/*  372 */     if (source == this.namingResources)
/*      */     {
/*      */ 
/*  375 */       ContextAccessController.setWritable(getName(), this.token);
/*      */       
/*  377 */       processGlobalResourcesChange(event.getPropertyName(), event
/*  378 */         .getOldValue(), event
/*  379 */         .getNewValue());
/*      */       
/*      */ 
/*  382 */       ContextAccessController.setReadOnly(getName());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processGlobalResourcesChange(String name, Object oldValue, Object newValue)
/*      */   {
/*  404 */     if (name.equals("ejb")) {
/*  405 */       if (oldValue != null) {
/*  406 */         ContextEjb ejb = (ContextEjb)oldValue;
/*  407 */         if (ejb.getName() != null) {
/*  408 */           removeEjb(ejb.getName());
/*      */         }
/*      */       }
/*  411 */       if (newValue != null) {
/*  412 */         ContextEjb ejb = (ContextEjb)newValue;
/*  413 */         if (ejb.getName() != null) {
/*  414 */           addEjb(ejb);
/*      */         }
/*      */       }
/*  417 */     } else if (name.equals("environment")) {
/*  418 */       if (oldValue != null) {
/*  419 */         ContextEnvironment env = (ContextEnvironment)oldValue;
/*  420 */         if (env.getName() != null) {
/*  421 */           removeEnvironment(env.getName());
/*      */         }
/*      */       }
/*  424 */       if (newValue != null) {
/*  425 */         ContextEnvironment env = (ContextEnvironment)newValue;
/*  426 */         if (env.getName() != null) {
/*  427 */           addEnvironment(env);
/*      */         }
/*      */       }
/*  430 */     } else if (name.equals("localEjb")) {
/*  431 */       if (oldValue != null) {
/*  432 */         ContextLocalEjb ejb = (ContextLocalEjb)oldValue;
/*  433 */         if (ejb.getName() != null) {
/*  434 */           removeLocalEjb(ejb.getName());
/*      */         }
/*      */       }
/*  437 */       if (newValue != null) {
/*  438 */         ContextLocalEjb ejb = (ContextLocalEjb)newValue;
/*  439 */         if (ejb.getName() != null) {
/*  440 */           addLocalEjb(ejb);
/*      */         }
/*      */       }
/*  443 */     } else if (name.equals("messageDestinationRef")) {
/*  444 */       if (oldValue != null) {
/*  445 */         MessageDestinationRef mdr = (MessageDestinationRef)oldValue;
/*  446 */         if (mdr.getName() != null) {
/*  447 */           removeMessageDestinationRef(mdr.getName());
/*      */         }
/*      */       }
/*  450 */       if (newValue != null) {
/*  451 */         MessageDestinationRef mdr = (MessageDestinationRef)newValue;
/*  452 */         if (mdr.getName() != null) {
/*  453 */           addMessageDestinationRef(mdr);
/*      */         }
/*      */       }
/*  456 */     } else if (name.equals("resource")) {
/*  457 */       if (oldValue != null) {
/*  458 */         ContextResource resource = (ContextResource)oldValue;
/*  459 */         if (resource.getName() != null) {
/*  460 */           removeResource(resource.getName());
/*      */         }
/*      */       }
/*  463 */       if (newValue != null) {
/*  464 */         ContextResource resource = (ContextResource)newValue;
/*  465 */         if (resource.getName() != null) {
/*  466 */           addResource(resource);
/*      */         }
/*      */       }
/*  469 */     } else if (name.equals("resourceEnvRef")) {
/*  470 */       if (oldValue != null) {
/*  471 */         ContextResourceEnvRef resourceEnvRef = (ContextResourceEnvRef)oldValue;
/*      */         
/*  473 */         if (resourceEnvRef.getName() != null) {
/*  474 */           removeResourceEnvRef(resourceEnvRef.getName());
/*      */         }
/*      */       }
/*  477 */       if (newValue != null) {
/*  478 */         ContextResourceEnvRef resourceEnvRef = (ContextResourceEnvRef)newValue;
/*      */         
/*  480 */         if (resourceEnvRef.getName() != null) {
/*  481 */           addResourceEnvRef(resourceEnvRef);
/*      */         }
/*      */       }
/*  484 */     } else if (name.equals("resourceLink")) {
/*  485 */       if (oldValue != null) {
/*  486 */         ContextResourceLink rl = (ContextResourceLink)oldValue;
/*  487 */         if (rl.getName() != null) {
/*  488 */           removeResourceLink(rl.getName());
/*      */         }
/*      */       }
/*  491 */       if (newValue != null) {
/*  492 */         ContextResourceLink rl = (ContextResourceLink)newValue;
/*  493 */         if (rl.getName() != null) {
/*  494 */           addResourceLink(rl);
/*      */         }
/*      */       }
/*  497 */     } else if (name.equals("service")) {
/*  498 */       if (oldValue != null) {
/*  499 */         ContextService service = (ContextService)oldValue;
/*  500 */         if (service.getName() != null) {
/*  501 */           removeService(service.getName());
/*      */         }
/*      */       }
/*  504 */       if (newValue != null) {
/*  505 */         ContextService service = (ContextService)newValue;
/*  506 */         if (service.getName() != null) {
/*  507 */           addService(service);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void createNamingContext()
/*      */     throws NamingException
/*      */   {
/*  523 */     if ((this.container instanceof Server)) {
/*  524 */       this.compCtx = this.namingContext;
/*  525 */       this.envCtx = this.namingContext;
/*      */     } else {
/*  527 */       this.compCtx = this.namingContext.createSubcontext("comp");
/*  528 */       this.envCtx = this.compCtx.createSubcontext("env");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  533 */     if (log.isDebugEnabled()) {
/*  534 */       log.debug("Creating JNDI naming context");
/*      */     }
/*      */     
/*  537 */     if (this.namingResources == null) {
/*  538 */       this.namingResources = new NamingResourcesImpl();
/*  539 */       this.namingResources.setContainer(this.container);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  544 */     ContextResourceLink[] resourceLinks = this.namingResources.findResourceLinks();
/*  545 */     for (int i = 0; i < resourceLinks.length; i++) {
/*  546 */       addResourceLink(resourceLinks[i]);
/*      */     }
/*      */     
/*      */ 
/*  550 */     ContextResource[] resources = this.namingResources.findResources();
/*  551 */     for (i = 0; i < resources.length; i++) {
/*  552 */       addResource(resources[i]);
/*      */     }
/*      */     
/*      */ 
/*  556 */     ContextResourceEnvRef[] resourceEnvRefs = this.namingResources.findResourceEnvRefs();
/*  557 */     for (i = 0; i < resourceEnvRefs.length; i++) {
/*  558 */       addResourceEnvRef(resourceEnvRefs[i]);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  563 */     ContextEnvironment[] contextEnvironments = this.namingResources.findEnvironments();
/*  564 */     for (i = 0; i < contextEnvironments.length; i++) {
/*  565 */       addEnvironment(contextEnvironments[i]);
/*      */     }
/*      */     
/*      */ 
/*  569 */     ContextEjb[] ejbs = this.namingResources.findEjbs();
/*  570 */     for (i = 0; i < ejbs.length; i++) {
/*  571 */       addEjb(ejbs[i]);
/*      */     }
/*      */     
/*      */ 
/*  575 */     MessageDestinationRef[] mdrs = this.namingResources.findMessageDestinationRefs();
/*  576 */     for (i = 0; i < mdrs.length; i++) {
/*  577 */       addMessageDestinationRef(mdrs[i]);
/*      */     }
/*      */     
/*      */ 
/*  581 */     ContextService[] services = this.namingResources.findServices();
/*  582 */     for (i = 0; i < services.length; i++) {
/*  583 */       addService(services[i]);
/*      */     }
/*      */     
/*      */ 
/*  587 */     if ((this.container instanceof org.apache.catalina.Context)) {
/*      */       try {
/*  589 */         Reference ref = new TransactionRef();
/*  590 */         this.compCtx.bind("UserTransaction", ref);
/*  591 */         ContextTransaction transaction = this.namingResources.getTransaction();
/*  592 */         if (transaction != null) {
/*  593 */           Iterator<String> params = transaction.listProperties();
/*  594 */           while (params.hasNext()) {
/*  595 */             String paramName = (String)params.next();
/*  596 */             String paramValue = (String)transaction.getProperty(paramName);
/*  597 */             StringRefAddr refAddr = new StringRefAddr(paramName, paramValue);
/*  598 */             ref.add(refAddr);
/*      */           }
/*      */           
/*      */         }
/*      */       }
/*      */       catch (NameAlreadyBoundException localNameAlreadyBoundException) {}catch (NamingException e)
/*      */       {
/*  605 */         log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  610 */     if ((this.container instanceof org.apache.catalina.Context)) {
/*      */       try {
/*  612 */         this.compCtx.bind("Resources", ((org.apache.catalina.Context)this.container)
/*  613 */           .getResources());
/*      */       } catch (NamingException e) {
/*  615 */         log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectName createObjectName(ContextResource resource)
/*      */     throws MalformedObjectNameException
/*      */   {
/*  633 */     String domain = null;
/*  634 */     if ((this.container instanceof StandardServer)) {
/*  635 */       domain = ((StandardServer)this.container).getDomain();
/*  636 */     } else if ((this.container instanceof ContainerBase)) {
/*  637 */       domain = ((ContainerBase)this.container).getDomain();
/*      */     }
/*  639 */     if (domain == null) {
/*  640 */       domain = "Catalina";
/*      */     }
/*      */     
/*  643 */     ObjectName name = null;
/*  644 */     String quotedResourceName = ObjectName.quote(resource.getName());
/*  645 */     if ((this.container instanceof Server))
/*      */     {
/*  647 */       name = new ObjectName(domain + ":type=DataSource,class=" + resource.getType() + ",name=" + quotedResourceName);
/*      */     }
/*  649 */     else if ((this.container instanceof org.apache.catalina.Context)) {
/*  650 */       String contextName = ((org.apache.catalina.Context)this.container).getName();
/*  651 */       if (!contextName.startsWith("/")) {
/*  652 */         contextName = "/" + contextName;
/*      */       }
/*  654 */       Host host = (Host)((org.apache.catalina.Context)this.container).getParent();
/*      */       
/*      */ 
/*      */ 
/*  658 */       name = new ObjectName(domain + ":type=DataSource,host=" + host.getName() + ",context=" + contextName + ",class=" + resource.getType() + ",name=" + quotedResourceName);
/*      */     }
/*      */     
/*      */ 
/*  662 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addEjb(ContextEjb ejb)
/*      */   {
/*  674 */     Reference ref = lookForLookupRef(ejb);
/*      */     
/*  676 */     if (ref == null)
/*      */     {
/*  678 */       ref = new EjbRef(ejb.getType(), ejb.getHome(), ejb.getRemote(), ejb.getLink());
/*      */       
/*  680 */       Iterator<String> params = ejb.listProperties();
/*  681 */       while (params.hasNext()) {
/*  682 */         String paramName = (String)params.next();
/*  683 */         String paramValue = (String)ejb.getProperty(paramName);
/*  684 */         StringRefAddr refAddr = new StringRefAddr(paramName, paramValue);
/*  685 */         ref.add(refAddr);
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/*  690 */       createSubcontexts(this.envCtx, ejb.getName());
/*  691 */       this.envCtx.bind(ejb.getName(), ref);
/*      */     } catch (NamingException e) {
/*  693 */       log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addEnvironment(ContextEnvironment env)
/*      */   {
/*  705 */     Object value = lookForLookupRef(env);
/*      */     
/*  707 */     if (value == null)
/*      */     {
/*      */ 
/*  710 */       String type = env.getType();
/*      */       try {
/*  712 */         if (type.equals("java.lang.String")) {
/*  713 */           value = env.getValue();
/*  714 */         } else if (type.equals("java.lang.Byte")) {
/*  715 */           if (env.getValue() == null) {
/*  716 */             value = Byte.valueOf((byte)0);
/*      */           } else {
/*  718 */             value = Byte.decode(env.getValue());
/*      */           }
/*  720 */         } else if (type.equals("java.lang.Short")) {
/*  721 */           if (env.getValue() == null) {
/*  722 */             value = Short.valueOf((short)0);
/*      */           } else {
/*  724 */             value = Short.decode(env.getValue());
/*      */           }
/*  726 */         } else if (type.equals("java.lang.Integer")) {
/*  727 */           if (env.getValue() == null) {
/*  728 */             value = Integer.valueOf(0);
/*      */           } else {
/*  730 */             value = Integer.decode(env.getValue());
/*      */           }
/*  732 */         } else if (type.equals("java.lang.Long")) {
/*  733 */           if (env.getValue() == null) {
/*  734 */             value = Long.valueOf(0L);
/*      */           } else {
/*  736 */             value = Long.decode(env.getValue());
/*      */           }
/*  738 */         } else if (type.equals("java.lang.Boolean")) {
/*  739 */           value = Boolean.valueOf(env.getValue());
/*  740 */         } else if (type.equals("java.lang.Double")) {
/*  741 */           if (env.getValue() == null) {
/*  742 */             value = Double.valueOf(0.0D);
/*      */           } else {
/*  744 */             value = Double.valueOf(env.getValue());
/*      */           }
/*  746 */         } else if (type.equals("java.lang.Float")) {
/*  747 */           if (env.getValue() == null) {
/*  748 */             value = Float.valueOf(0.0F);
/*      */           } else {
/*  750 */             value = Float.valueOf(env.getValue());
/*      */           }
/*  752 */         } else if (type.equals("java.lang.Character")) {
/*  753 */           if (env.getValue() == null) {
/*  754 */             value = Character.valueOf('\000');
/*      */           }
/*  756 */           else if (env.getValue().length() == 1) {
/*  757 */             value = Character.valueOf(env.getValue().charAt(0));
/*      */           } else {
/*  759 */             throw new IllegalArgumentException();
/*      */           }
/*      */         }
/*      */         else {
/*  763 */           value = constructEnvEntry(env.getType(), env.getValue());
/*  764 */           if (value == null) {
/*  765 */             log.error(sm.getString("naming.invalidEnvEntryType", new Object[] {env
/*  766 */               .getName() }));
/*      */           }
/*      */         }
/*      */       } catch (IllegalArgumentException e) {
/*  770 */         log.error(sm.getString("naming.invalidEnvEntryValue", new Object[] { env.getName() }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  775 */     if (value != null) {
/*      */       try {
/*  777 */         if (log.isDebugEnabled()) {
/*  778 */           log.debug(sm.getString("naming.addEnvEntry", new Object[] { env.getName() }));
/*      */         }
/*  780 */         createSubcontexts(this.envCtx, env.getName());
/*  781 */         this.envCtx.bind(env.getName(), value);
/*      */       } catch (NamingException e) {
/*  783 */         log.error(sm.getString("naming.invalidEnvEntryValue", new Object[] { e }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private Object constructEnvEntry(String type, String value)
/*      */   {
/*      */     try {
/*  791 */       Class<?> clazz = Class.forName(type);
/*  792 */       Constructor<?> c = null;
/*      */       try {
/*  794 */         c = clazz.getConstructor(new Class[] { String.class });
/*  795 */         return c.newInstance(new Object[] { value });
/*      */ 
/*      */       }
/*      */       catch (NoSuchMethodException localNoSuchMethodException)
/*      */       {
/*  800 */         if (value.length() != 1) {
/*  801 */           return null;
/*      */         }
/*      */         try
/*      */         {
/*  805 */           c = clazz.getConstructor(new Class[] { Character.TYPE });
/*  806 */           return c.newInstance(new Object[] { Character.valueOf(value.charAt(0)) });
/*      */         }
/*      */         catch (NoSuchMethodException localNoSuchMethodException1) {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  813 */       return null;
/*      */     }
/*      */     catch (Exception localException) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addLocalEjb(ContextLocalEjb localEjb) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addMessageDestinationRef(MessageDestinationRef mdr) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addService(ContextService service)
/*      */   {
/*  847 */     Reference ref = lookForLookupRef(service);
/*      */     
/*  849 */     if (ref == null)
/*      */     {
/*  851 */       if (service.getWsdlfile() != null) {
/*  852 */         URL wsdlURL = null;
/*      */         try
/*      */         {
/*  855 */           wsdlURL = new URL(service.getWsdlfile());
/*      */         }
/*      */         catch (MalformedURLException localMalformedURLException1) {}
/*      */         
/*  859 */         if (wsdlURL == null) {
/*      */           try {
/*  861 */             wsdlURL = ((org.apache.catalina.Context)this.container).getServletContext().getResource(service
/*  862 */               .getWsdlfile());
/*      */           }
/*      */           catch (MalformedURLException localMalformedURLException2) {}
/*      */         }
/*      */         
/*  867 */         if (wsdlURL == null) {
/*      */           try {
/*  869 */             wsdlURL = ((org.apache.catalina.Context)this.container).getServletContext().getResource("/" + service
/*  870 */               .getWsdlfile());
/*  871 */             log.debug("  Changing service ref wsdl file for /" + service
/*  872 */               .getWsdlfile());
/*      */           } catch (MalformedURLException e) {
/*  874 */             log.error(sm.getString("naming.wsdlFailed", new Object[] { e }));
/*      */           }
/*      */         }
/*  877 */         if (wsdlURL == null) {
/*  878 */           service.setWsdlfile(null);
/*      */         } else {
/*  880 */           service.setWsdlfile(wsdlURL.toString());
/*      */         }
/*      */       }
/*      */       
/*  884 */       if (service.getJaxrpcmappingfile() != null) {
/*  885 */         URL jaxrpcURL = null;
/*      */         try
/*      */         {
/*  888 */           jaxrpcURL = new URL(service.getJaxrpcmappingfile());
/*      */         }
/*      */         catch (MalformedURLException localMalformedURLException3) {}
/*      */         
/*  892 */         if (jaxrpcURL == null) {
/*      */           try {
/*  894 */             jaxrpcURL = ((org.apache.catalina.Context)this.container).getServletContext().getResource(service
/*  895 */               .getJaxrpcmappingfile());
/*      */           }
/*      */           catch (MalformedURLException localMalformedURLException4) {}
/*      */         }
/*      */         
/*  900 */         if (jaxrpcURL == null) {
/*      */           try {
/*  902 */             jaxrpcURL = ((org.apache.catalina.Context)this.container).getServletContext().getResource("/" + service
/*  903 */               .getJaxrpcmappingfile());
/*  904 */             log.debug("  Changing service ref jaxrpc file for /" + service
/*  905 */               .getJaxrpcmappingfile());
/*      */           } catch (MalformedURLException e) {
/*  907 */             log.error(sm.getString("naming.wsdlFailed", new Object[] { e }));
/*      */           }
/*      */         }
/*  910 */         if (jaxrpcURL == null) {
/*  911 */           service.setJaxrpcmappingfile(null);
/*      */         } else {
/*  913 */           service.setJaxrpcmappingfile(jaxrpcURL.toString());
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  920 */       ref = new ServiceRef(service.getName(), service.getInterface(), service.getServiceqname(), service.getWsdlfile(), service.getJaxrpcmappingfile());
/*      */       
/*      */ 
/*  923 */       Iterator<String> portcomponent = service.getServiceendpoints();
/*  924 */       while (portcomponent.hasNext()) {
/*  925 */         String serviceendpoint = (String)portcomponent.next();
/*  926 */         StringRefAddr refAddr = new StringRefAddr("serviceendpointinterface", serviceendpoint);
/*  927 */         ref.add(refAddr);
/*  928 */         String portlink = service.getPortlink(serviceendpoint);
/*  929 */         refAddr = new StringRefAddr("portcomponentlink", portlink);
/*  930 */         ref.add(refAddr);
/*      */       }
/*      */       
/*  933 */       Iterator<String> handlers = service.getHandlers();
/*  934 */       while (handlers.hasNext()) {
/*  935 */         String handlername = (String)handlers.next();
/*  936 */         ContextHandler handler = service.getHandler(handlername);
/*  937 */         HandlerRef handlerRef = new HandlerRef(handlername, handler.getHandlerclass());
/*  938 */         Iterator<String> localParts = handler.getLocalparts();
/*  939 */         while (localParts.hasNext()) {
/*  940 */           String localPart = (String)localParts.next();
/*  941 */           String namespaceURI = handler.getNamespaceuri(localPart);
/*  942 */           handlerRef.add(new StringRefAddr("handlerlocalpart", localPart));
/*  943 */           handlerRef.add(new StringRefAddr("handlernamespace", namespaceURI));
/*      */         }
/*  945 */         Iterator<String> params = handler.listProperties();
/*  946 */         while (params.hasNext()) {
/*  947 */           String paramName = (String)params.next();
/*  948 */           String paramValue = (String)handler.getProperty(paramName);
/*  949 */           handlerRef.add(new StringRefAddr("handlerparamname", paramName));
/*  950 */           handlerRef.add(new StringRefAddr("handlerparamvalue", paramValue));
/*      */         }
/*  952 */         for (int i = 0; i < handler.getSoapRolesSize(); i++) {
/*  953 */           handlerRef.add(new StringRefAddr("handlersoaprole", handler.getSoapRole(i)));
/*      */         }
/*  955 */         for (int i = 0; i < handler.getPortNamesSize(); i++) {
/*  956 */           handlerRef.add(new StringRefAddr("handlerportname", handler.getPortName(i)));
/*      */         }
/*  958 */         ((ServiceRef)ref).addHandler(handlerRef);
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/*  963 */       if (log.isDebugEnabled()) {
/*  964 */         log.debug("  Adding service ref " + service.getName() + "  " + ref);
/*      */       }
/*  966 */       createSubcontexts(this.envCtx, service.getName());
/*  967 */       this.envCtx.bind(service.getName(), ref);
/*      */     } catch (NamingException e) {
/*  969 */       log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResource(ContextResource resource)
/*      */   {
/*  981 */     Reference ref = lookForLookupRef(resource);
/*      */     
/*  983 */     if (ref == null)
/*      */     {
/*      */ 
/*  986 */       ref = new ResourceRef(resource.getType(), resource.getDescription(), resource.getScope(), resource.getAuth(), resource.getSingleton());
/*      */       
/*  988 */       Iterator<String> params = resource.listProperties();
/*  989 */       while (params.hasNext()) {
/*  990 */         String paramName = (String)params.next();
/*  991 */         String paramValue = (String)resource.getProperty(paramName);
/*  992 */         StringRefAddr refAddr = new StringRefAddr(paramName, paramValue);
/*  993 */         ref.add(refAddr);
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/*  998 */       if (log.isDebugEnabled()) {
/*  999 */         log.debug("  Adding resource ref " + resource.getName() + "  " + ref);
/*      */       }
/* 1001 */       createSubcontexts(this.envCtx, resource.getName());
/* 1002 */       this.envCtx.bind(resource.getName(), ref);
/*      */     } catch (NamingException e) {
/* 1004 */       log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */     }
/*      */     
/* 1007 */     if ((("javax.sql.DataSource".equals(ref.getClassName())) || 
/* 1008 */       ("javax.sql.XADataSource".equals(ref.getClassName()))) && 
/* 1009 */       (resource.getSingleton())) {
/* 1010 */       Object actualResource = null;
/*      */       try {
/* 1012 */         ObjectName on = createObjectName(resource);
/* 1013 */         actualResource = this.envCtx.lookup(resource.getName());
/* 1014 */         Registry.getRegistry(null, null).registerComponent(actualResource, on, null);
/* 1015 */         this.objectNames.put(resource.getName(), on);
/*      */       } catch (Exception e) {
/* 1017 */         log.warn(sm.getString("naming.jmxRegistrationFailed", new Object[] { e }));
/*      */       }
/*      */       
/*      */ 
/* 1021 */       if (((actualResource instanceof AutoCloseable)) && (!resource.getCloseMethodConfigured())) {
/* 1022 */         resource.setCloseMethod("close");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResourceEnvRef(ContextResourceEnvRef resourceEnvRef)
/*      */   {
/* 1035 */     Reference ref = lookForLookupRef(resourceEnvRef);
/*      */     
/* 1037 */     if (ref == null)
/*      */     {
/* 1039 */       ref = new ResourceEnvRef(resourceEnvRef.getType());
/*      */       
/* 1041 */       Iterator<String> params = resourceEnvRef.listProperties();
/* 1042 */       while (params.hasNext()) {
/* 1043 */         String paramName = (String)params.next();
/* 1044 */         String paramValue = (String)resourceEnvRef.getProperty(paramName);
/* 1045 */         StringRefAddr refAddr = new StringRefAddr(paramName, paramValue);
/* 1046 */         ref.add(refAddr);
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/* 1051 */       if (log.isDebugEnabled()) {
/* 1052 */         log.debug(sm.getString("naming.addResourceEnvRef", new Object[] { resourceEnvRef.getName() }));
/*      */       }
/* 1054 */       createSubcontexts(this.envCtx, resourceEnvRef.getName());
/* 1055 */       this.envCtx.bind(resourceEnvRef.getName(), ref);
/*      */     } catch (NamingException e) {
/* 1057 */       log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addResourceLink(ContextResourceLink resourceLink)
/*      */   {
/* 1071 */     Reference ref = new ResourceLinkRef(resourceLink.getType(), resourceLink.getGlobal(), resourceLink.getFactory(), null);
/* 1072 */     Iterator<String> i = resourceLink.listProperties();
/* 1073 */     while (i.hasNext()) {
/* 1074 */       String key = (String)i.next();
/* 1075 */       Object val = resourceLink.getProperty(key);
/* 1076 */       if (val != null) {
/* 1077 */         StringRefAddr refAddr = new StringRefAddr(key, val.toString());
/* 1078 */         ref.add(refAddr);
/*      */       }
/*      */     }
/*      */     
/* 1082 */     javax.naming.Context ctx = "UserTransaction".equals(resourceLink.getName()) ? this.compCtx : this.envCtx;
/*      */     try
/*      */     {
/* 1085 */       if (log.isDebugEnabled()) {
/* 1086 */         log.debug("  Adding resource link " + resourceLink.getName());
/*      */       }
/* 1088 */       createSubcontexts(this.envCtx, resourceLink.getName());
/* 1089 */       ctx.bind(resourceLink.getName(), ref);
/*      */     } catch (NamingException e) {
/* 1091 */       log.error(sm.getString("naming.bindFailed", new Object[] { e }));
/*      */     }
/*      */     
/* 1094 */     ResourceLinkFactory.registerGlobalResourceAccess(
/* 1095 */       getGlobalNamingContext(), resourceLink.getName(), resourceLink.getGlobal());
/*      */   }
/*      */   
/*      */   private javax.naming.Context getGlobalNamingContext()
/*      */   {
/* 1100 */     if ((this.container instanceof org.apache.catalina.Context)) {
/* 1101 */       Engine e = (Engine)((org.apache.catalina.Context)this.container).getParent().getParent();
/* 1102 */       Server s = e.getService().getServer();
/*      */       
/* 1104 */       if (s != null) {
/* 1105 */         return s.getGlobalNamingContext();
/*      */       }
/*      */     }
/* 1108 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeEjb(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1120 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1122 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeEnvironment(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1136 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1138 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeLocalEjb(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1152 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1154 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeMessageDestinationRef(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1169 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1171 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeService(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1185 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1187 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeResource(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1201 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1203 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     }
/*      */     
/* 1206 */     ObjectName on = (ObjectName)this.objectNames.get(name);
/* 1207 */     if (on != null) {
/* 1208 */       Registry.getRegistry(null, null).unregisterComponent(on);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeResourceEnvRef(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1224 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1226 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeResourceLink(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1240 */       this.envCtx.unbind(name);
/*      */     } catch (NamingException e) {
/* 1242 */       log.error(sm.getString("naming.unbindFailed", new Object[] { name }), e);
/*      */     }
/*      */     
/* 1245 */     ResourceLinkFactory.deregisterGlobalResourceAccess(getGlobalNamingContext(), name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void createSubcontexts(javax.naming.Context ctx, String name)
/*      */     throws NamingException
/*      */   {
/* 1254 */     javax.naming.Context currentContext = ctx;
/* 1255 */     StringTokenizer tokenizer = new StringTokenizer(name, "/");
/* 1256 */     while (tokenizer.hasMoreTokens()) {
/* 1257 */       String token = tokenizer.nextToken();
/* 1258 */       if ((!token.equals("")) && (tokenizer.hasMoreTokens())) {
/*      */         try {
/* 1260 */           currentContext = currentContext.createSubcontext(token);
/*      */ 
/*      */         }
/*      */         catch (NamingException e)
/*      */         {
/* 1265 */           currentContext = (javax.naming.Context)currentContext.lookup(token);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private LookupRef lookForLookupRef(ResourceBase resourceBase)
/*      */   {
/* 1279 */     String lookupName = resourceBase.getLookupName();
/* 1280 */     if ((lookupName != null) && (!lookupName.equals(""))) {
/* 1281 */       return new LookupRef(resourceBase.getType(), lookupName);
/*      */     }
/* 1283 */     return null;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\NamingContextListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */