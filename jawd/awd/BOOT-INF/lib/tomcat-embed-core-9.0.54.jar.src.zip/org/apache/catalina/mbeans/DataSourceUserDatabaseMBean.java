/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*     */ import org.apache.tomcat.util.modeler.ManagedBean;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceUserDatabaseMBean
/*     */   extends BaseModelMBean
/*     */ {
/*  44 */   protected final Registry registry = MBeanUtils.createRegistry();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  50 */   protected final ManagedBean managed = this.registry.findManagedBean("DataSourceUserDatabase");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getGroups()
/*     */   {
/*  59 */     UserDatabase database = (UserDatabase)this.resource;
/*  60 */     List<String> results = new ArrayList();
/*  61 */     Iterator<Group> groups = database.getGroups();
/*  62 */     while (groups.hasNext()) {
/*  63 */       Group group = (Group)groups.next();
/*  64 */       results.add(group.getGroupname());
/*     */     }
/*  66 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getRoles()
/*     */   {
/*  74 */     UserDatabase database = (UserDatabase)this.resource;
/*  75 */     List<String> results = new ArrayList();
/*  76 */     Iterator<Role> roles = database.getRoles();
/*  77 */     while (roles.hasNext()) {
/*  78 */       Role role = (Role)roles.next();
/*  79 */       results.add(role.getRolename());
/*     */     }
/*  81 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getUsers()
/*     */   {
/*  89 */     UserDatabase database = (UserDatabase)this.resource;
/*  90 */     List<String> results = new ArrayList();
/*  91 */     Iterator<User> users = database.getUsers();
/*  92 */     while (users.hasNext()) {
/*  93 */       User user = (User)users.next();
/*  94 */       results.add(user.getUsername());
/*     */     }
/*  96 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createGroup(String groupname, String description)
/*     */   {
/* 110 */     UserDatabase database = (UserDatabase)this.resource;
/* 111 */     Group group = database.createGroup(groupname, description);
/* 112 */     return group.getGroupname();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createRole(String rolename, String description)
/*     */   {
/* 124 */     UserDatabase database = (UserDatabase)this.resource;
/* 125 */     Role role = database.createRole(rolename, description);
/* 126 */     return role.getRolename();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createUser(String username, String password, String fullName)
/*     */   {
/* 139 */     UserDatabase database = (UserDatabase)this.resource;
/* 140 */     User user = database.createUser(username, password, fullName);
/* 141 */     return user.getUsername();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeGroup(String groupname)
/*     */   {
/* 151 */     UserDatabase database = (UserDatabase)this.resource;
/* 152 */     Group group = database.findGroup(groupname);
/* 153 */     if (group == null) {
/* 154 */       return;
/*     */     }
/* 156 */     database.removeGroup(group);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRole(String rolename)
/*     */   {
/* 166 */     UserDatabase database = (UserDatabase)this.resource;
/* 167 */     Role role = database.findRole(rolename);
/* 168 */     if (role == null) {
/* 169 */       return;
/*     */     }
/* 171 */     database.removeRole(role);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeUser(String username)
/*     */   {
/* 181 */     UserDatabase database = (UserDatabase)this.resource;
/* 182 */     User user = database.findUser(username);
/* 183 */     if (user == null) {
/* 184 */       return;
/*     */     }
/* 186 */     database.removeUser(user);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void changeUserPassword(String username, String password)
/*     */   {
/* 196 */     UserDatabase database = (UserDatabase)this.resource;
/* 197 */     User user = database.findUser(username);
/* 198 */     if (user != null) {
/* 199 */       user.setPassword(password);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addUserRole(String username, String rolename)
/*     */   {
/* 210 */     UserDatabase database = (UserDatabase)this.resource;
/* 211 */     User user = database.findUser(username);
/* 212 */     Role role = database.findRole(rolename);
/* 213 */     if ((user != null) && (role != null)) {
/* 214 */       user.addRole(role);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeUserRole(String username, String rolename)
/*     */   {
/* 225 */     UserDatabase database = (UserDatabase)this.resource;
/* 226 */     User user = database.findUser(username);
/* 227 */     Role role = database.findRole(rolename);
/* 228 */     if ((user != null) && (role != null)) {
/* 229 */       user.removeRole(role);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getUserRoles(String username)
/*     */   {
/* 240 */     UserDatabase database = (UserDatabase)this.resource;
/* 241 */     User user = database.findUser(username);
/* 242 */     if (user != null) {
/* 243 */       List<String> results = new ArrayList();
/* 244 */       Iterator<Role> roles = user.getRoles();
/* 245 */       while (roles.hasNext()) {
/* 246 */         Role role = (Role)roles.next();
/* 247 */         results.add(role.getRolename());
/*     */       }
/* 249 */       return (String[])results.toArray(new String[0]);
/*     */     }
/* 251 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addUserGroup(String username, String groupname)
/*     */   {
/* 262 */     UserDatabase database = (UserDatabase)this.resource;
/* 263 */     User user = database.findUser(username);
/* 264 */     Group group = database.findGroup(groupname);
/* 265 */     if ((user != null) && (group != null)) {
/* 266 */       user.addGroup(group);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeUserGroup(String username, String groupname)
/*     */   {
/* 277 */     UserDatabase database = (UserDatabase)this.resource;
/* 278 */     User user = database.findUser(username);
/* 279 */     Group group = database.findGroup(groupname);
/* 280 */     if ((user != null) && (group != null)) {
/* 281 */       user.removeGroup(group);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getUserGroups(String username)
/*     */   {
/* 292 */     UserDatabase database = (UserDatabase)this.resource;
/* 293 */     User user = database.findUser(username);
/* 294 */     if (user != null) {
/* 295 */       List<String> results = new ArrayList();
/* 296 */       Iterator<Group> groups = user.getGroups();
/* 297 */       while (groups.hasNext()) {
/* 298 */         Group group = (Group)groups.next();
/* 299 */         results.add(group.getGroupname());
/*     */       }
/* 301 */       return (String[])results.toArray(new String[0]);
/*     */     }
/* 303 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addGroupRole(String groupname, String rolename)
/*     */   {
/* 314 */     UserDatabase database = (UserDatabase)this.resource;
/* 315 */     Group group = database.findGroup(groupname);
/* 316 */     Role role = database.findRole(rolename);
/* 317 */     if ((group != null) && (role != null)) {
/* 318 */       group.addRole(role);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeGroupRole(String groupname, String rolename)
/*     */   {
/* 329 */     UserDatabase database = (UserDatabase)this.resource;
/* 330 */     Group group = database.findGroup(groupname);
/* 331 */     Role role = database.findRole(rolename);
/* 332 */     if ((group != null) && (role != null)) {
/* 333 */       group.removeRole(role);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getGroupRoles(String groupname)
/*     */   {
/* 344 */     UserDatabase database = (UserDatabase)this.resource;
/* 345 */     Group group = database.findGroup(groupname);
/* 346 */     if (group != null) {
/* 347 */       List<String> results = new ArrayList();
/* 348 */       Iterator<Role> roles = group.getRoles();
/* 349 */       while (roles.hasNext()) {
/* 350 */         Role role = (Role)roles.next();
/* 351 */         results.add(role.getRolename());
/*     */       }
/* 353 */       return (String[])results.toArray(new String[0]);
/*     */     }
/* 355 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\DataSourceUserDatabaseMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */