/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LifecycleMBeanBase
/*     */   extends LifecycleBase
/*     */   implements JmxEnabled
/*     */ {
/*  33 */   private static final Log log = LogFactory.getLog(LifecycleMBeanBase.class);
/*     */   
/*     */ 
/*  36 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.util");
/*     */   
/*     */ 
/*     */ 
/*  40 */   private String domain = null;
/*  41 */   private ObjectName oname = null; @Deprecated
/*  42 */   protected MBeanServer mserver = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/*  54 */     if (this.oname == null) {
/*  55 */       this.mserver = Registry.getRegistry(null, null).getMBeanServer();
/*     */       
/*  57 */       this.oname = register(this, getObjectNameKeyProperties());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void destroyInternal()
/*     */     throws LifecycleException
/*     */   {
/*  69 */     unregister(this.oname);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setDomain(String domain)
/*     */   {
/*  80 */     this.domain = domain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getDomain()
/*     */   {
/*  90 */     if (this.domain == null) {
/*  91 */       this.domain = getDomainInternal();
/*     */     }
/*     */     
/*  94 */     if (this.domain == null) {
/*  95 */       this.domain = "Catalina";
/*     */     }
/*     */     
/*  98 */     return this.domain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract String getDomainInternal();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final ObjectName getObjectName()
/*     */   {
/* 116 */     return this.oname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract String getObjectNameKeyProperties();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ObjectName register(Object obj, String objectNameKeyProperties)
/*     */   {
/* 148 */     StringBuilder name = new StringBuilder(getDomain());
/* 149 */     name.append(':');
/* 150 */     name.append(objectNameKeyProperties);
/*     */     
/* 152 */     ObjectName on = null;
/*     */     try
/*     */     {
/* 155 */       on = new ObjectName(name.toString());
/* 156 */       Registry.getRegistry(null, null).registerComponent(obj, on, null);
/*     */     } catch (Exception e) {
/* 158 */       log.warn(sm.getString("lifecycleMBeanBase.registerFail", new Object[] { obj, name }), e);
/*     */     }
/*     */     
/* 161 */     return on;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void unregister(String objectNameKeyProperties)
/*     */   {
/* 178 */     StringBuilder name = new StringBuilder(getDomain());
/* 179 */     name.append(':');
/* 180 */     name.append(objectNameKeyProperties);
/* 181 */     Registry.getRegistry(null, null).unregisterComponent(name.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void unregister(ObjectName on)
/*     */   {
/* 195 */     Registry.getRegistry(null, null).unregisterComponent(on);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void postDeregister() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void postRegister(Boolean registrationDone) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void preDeregister()
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final ObjectName preRegister(MBeanServer server, ObjectName name)
/*     */     throws Exception
/*     */   {
/* 234 */     this.mserver = server;
/* 235 */     this.oname = name;
/* 236 */     this.domain = name.getDomain().intern();
/*     */     
/* 238 */     return this.oname;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\LifecycleMBeanBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */