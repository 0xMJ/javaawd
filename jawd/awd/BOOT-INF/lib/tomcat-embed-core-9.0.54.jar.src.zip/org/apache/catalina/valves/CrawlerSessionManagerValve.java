/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.HttpSessionBindingEvent;
/*     */ import javax.servlet.http.HttpSessionBindingListener;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CrawlerSessionManagerValve
/*     */   extends ValveBase
/*     */ {
/*  48 */   private static final Log log = LogFactory.getLog(CrawlerSessionManagerValve.class);
/*     */   
/*  50 */   private final Map<String, String> clientIdSessionId = new ConcurrentHashMap();
/*  51 */   private final Map<String, String> sessionIdClientId = new ConcurrentHashMap();
/*     */   
/*  53 */   private String crawlerUserAgents = ".*[bB]ot.*|.*Yahoo! Slurp.*|.*Feedfetcher-Google.*";
/*  54 */   private Pattern uaPattern = null;
/*     */   
/*  56 */   private String crawlerIps = null;
/*  57 */   private Pattern ipPattern = null;
/*     */   
/*  59 */   private int sessionInactiveInterval = 60;
/*     */   
/*  61 */   private boolean isHostAware = true;
/*     */   
/*  63 */   private boolean isContextAware = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CrawlerSessionManagerValve()
/*     */   {
/*  70 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCrawlerUserAgents(String crawlerUserAgents)
/*     */   {
/*  82 */     this.crawlerUserAgents = crawlerUserAgents;
/*  83 */     if ((crawlerUserAgents == null) || (crawlerUserAgents.length() == 0)) {
/*  84 */       this.uaPattern = null;
/*     */     } else {
/*  86 */       this.uaPattern = Pattern.compile(crawlerUserAgents);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCrawlerUserAgents()
/*     */   {
/*  95 */     return this.crawlerUserAgents;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCrawlerIps(String crawlerIps)
/*     */   {
/* 107 */     this.crawlerIps = crawlerIps;
/* 108 */     if ((crawlerIps == null) || (crawlerIps.length() == 0)) {
/* 109 */       this.ipPattern = null;
/*     */     } else {
/* 111 */       this.ipPattern = Pattern.compile(crawlerIps);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCrawlerIps()
/*     */   {
/* 120 */     return this.crawlerIps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSessionInactiveInterval(int sessionInactiveInterval)
/*     */   {
/* 131 */     this.sessionInactiveInterval = sessionInactiveInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSessionInactiveInterval()
/*     */   {
/* 139 */     return this.sessionInactiveInterval;
/*     */   }
/*     */   
/*     */   public Map<String, String> getClientIpSessionId()
/*     */   {
/* 144 */     return this.clientIdSessionId;
/*     */   }
/*     */   
/*     */   public boolean isHostAware()
/*     */   {
/* 149 */     return this.isHostAware;
/*     */   }
/*     */   
/*     */   public void setHostAware(boolean isHostAware)
/*     */   {
/* 154 */     this.isHostAware = isHostAware;
/*     */   }
/*     */   
/*     */   public boolean isContextAware()
/*     */   {
/* 159 */     return this.isContextAware;
/*     */   }
/*     */   
/*     */   public void setContextAware(boolean isContextAware)
/*     */   {
/* 164 */     this.isContextAware = isContextAware;
/*     */   }
/*     */   
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 170 */     super.initInternal();
/*     */     
/* 172 */     this.uaPattern = Pattern.compile(this.crawlerUserAgents);
/*     */   }
/*     */   
/*     */ 
/*     */   public void invoke(Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/* 179 */     boolean isBot = false;
/* 180 */     String sessionId = null;
/* 181 */     String clientIp = request.getRemoteAddr();
/* 182 */     String clientIdentifier = getClientIdentifier(request.getHost(), request.getContext(), clientIp);
/*     */     
/* 184 */     if (log.isDebugEnabled()) {
/* 185 */       log.debug(request.hashCode() + ": ClientIdentifier=" + clientIdentifier + ", RequestedSessionId=" + request
/* 186 */         .getRequestedSessionId());
/*     */     }
/*     */     
/*     */ 
/* 190 */     if (request.getSession(false) == null)
/*     */     {
/*     */ 
/* 193 */       Enumeration<String> uaHeaders = request.getHeaders("user-agent");
/* 194 */       String uaHeader = null;
/* 195 */       if (uaHeaders.hasMoreElements()) {
/* 196 */         uaHeader = (String)uaHeaders.nextElement();
/*     */       }
/*     */       
/*     */ 
/* 200 */       if ((uaHeader != null) && (!uaHeaders.hasMoreElements()))
/*     */       {
/* 202 */         if (log.isDebugEnabled()) {
/* 203 */           log.debug(request.hashCode() + ": UserAgent=" + uaHeader);
/*     */         }
/*     */         
/* 206 */         if (this.uaPattern.matcher(uaHeader).matches()) {
/* 207 */           isBot = true;
/*     */           
/* 209 */           if (log.isDebugEnabled()) {
/* 210 */             log.debug(request.hashCode() + ": Bot found. UserAgent=" + uaHeader);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 215 */       if ((this.ipPattern != null) && (this.ipPattern.matcher(clientIp).matches())) {
/* 216 */         isBot = true;
/*     */         
/* 218 */         if (log.isDebugEnabled()) {
/* 219 */           log.debug(request.hashCode() + ": Bot found. IP=" + clientIp);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 224 */       if (isBot) {
/* 225 */         sessionId = (String)this.clientIdSessionId.get(clientIdentifier);
/* 226 */         if (sessionId != null) {
/* 227 */           request.setRequestedSessionId(sessionId);
/* 228 */           if (log.isDebugEnabled()) {
/* 229 */             log.debug(request.hashCode() + ": SessionID=" + sessionId);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 235 */     getNext().invoke(request, response);
/*     */     
/* 237 */     if (isBot) {
/* 238 */       if (sessionId == null)
/*     */       {
/* 240 */         HttpSession s = request.getSession(false);
/* 241 */         if (s != null) {
/* 242 */           this.clientIdSessionId.put(clientIdentifier, s.getId());
/* 243 */           this.sessionIdClientId.put(s.getId(), clientIdentifier);
/*     */           
/* 245 */           s.setAttribute(getClass().getName(), new CrawlerHttpSessionBindingListener(this.clientIdSessionId, clientIdentifier, null));
/*     */           
/* 247 */           s.setMaxInactiveInterval(this.sessionInactiveInterval);
/*     */           
/* 249 */           if (log.isDebugEnabled()) {
/* 250 */             log.debug(request.hashCode() + ": New bot session. SessionID=" + s.getId());
/*     */           }
/*     */         }
/*     */       }
/* 254 */       else if (log.isDebugEnabled()) {
/* 255 */         log.debug(request
/* 256 */           .hashCode() + ": Bot session accessed. SessionID=" + sessionId);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private String getClientIdentifier(Host host, Context context, String clientIp)
/*     */   {
/* 264 */     StringBuilder result = new StringBuilder(clientIp);
/* 265 */     if (this.isHostAware) {
/* 266 */       result.append('-').append(host.getName());
/*     */     }
/* 268 */     if ((this.isContextAware) && (context != null)) {
/* 269 */       result.append(context.getName());
/*     */     }
/* 271 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static class CrawlerHttpSessionBindingListener implements HttpSessionBindingListener, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final transient Map<String, String> clientIdSessionId;
/*     */     private final transient String clientIdentifier;
/*     */     
/*     */     private CrawlerHttpSessionBindingListener(Map<String, String> clientIdSessionId, String clientIdentifier) {
/* 281 */       this.clientIdSessionId = clientIdSessionId;
/* 282 */       this.clientIdentifier = clientIdentifier;
/*     */     }
/*     */     
/*     */     public void valueUnbound(HttpSessionBindingEvent event)
/*     */     {
/* 287 */       if ((this.clientIdentifier != null) && (this.clientIdSessionId != null)) {
/* 288 */         this.clientIdSessionId.remove(this.clientIdentifier, event.getSession().getId());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\CrawlerSessionManagerValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */