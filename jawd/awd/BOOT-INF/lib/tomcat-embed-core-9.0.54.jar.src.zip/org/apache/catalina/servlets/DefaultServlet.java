/*      */ package org.apache.catalina.servlets;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringReader;
/*      */ import java.io.StringWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.nio.file.Path;
/*      */ import java.security.AccessController;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import javax.servlet.DispatcherType;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.ServletResponseWrapper;
/*      */ import javax.servlet.UnavailableException;
/*      */ import javax.servlet.http.HttpServlet;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.transform.Source;
/*      */ import javax.xml.transform.Transformer;
/*      */ import javax.xml.transform.TransformerException;
/*      */ import javax.xml.transform.TransformerFactory;
/*      */ import javax.xml.transform.dom.DOMSource;
/*      */ import javax.xml.transform.stream.StreamResult;
/*      */ import javax.xml.transform.stream.StreamSource;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.connector.RequestFacade;
/*      */ import org.apache.catalina.connector.ResponseFacade;
/*      */ import org.apache.catalina.util.IOTools;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.catalina.webresources.CachedResource;
/*      */ import org.apache.coyote.Constants;
/*      */ import org.apache.tomcat.util.buf.B2CConverter;
/*      */ import org.apache.tomcat.util.http.ResponseUtil;
/*      */ import org.apache.tomcat.util.http.parser.ContentRange;
/*      */ import org.apache.tomcat.util.http.parser.EntityTag;
/*      */ import org.apache.tomcat.util.http.parser.Ranges;
/*      */ import org.apache.tomcat.util.http.parser.Ranges.Entry;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.Escape;
/*      */ import org.apache.tomcat.util.security.PrivilegedGetTccl;
/*      */ import org.apache.tomcat.util.security.PrivilegedSetTccl;
/*      */ import org.w3c.dom.Document;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.ext.EntityResolver2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DefaultServlet
/*      */   extends HttpServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*  144 */   protected static final StringManager sm = StringManager.getManager(DefaultServlet.class);
/*      */   
/*      */ 
/*      */   private static final DocumentBuilderFactory factory;
/*      */   
/*      */ 
/*      */   private static final SecureEntityResolver secureEntityResolver;
/*      */   
/*      */ 
/*  153 */   protected static final ArrayList<Range> FULL = new ArrayList();
/*      */   
/*  155 */   private static final Range IGNORE = new Range();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final String mimeSeparation = "CATALINA_MIME_BOUNDARY";
/*      */   
/*      */ 
/*      */ 
/*      */   protected static final int BUFFER_SIZE = 4096;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/*  171 */     if (Globals.IS_SECURITY_ENABLED) {
/*  172 */       factory = DocumentBuilderFactory.newInstance();
/*  173 */       factory.setNamespaceAware(true);
/*  174 */       factory.setValidating(false);
/*  175 */       secureEntityResolver = new SecureEntityResolver(null);
/*      */     } else {
/*  177 */       factory = null;
/*  178 */       secureEntityResolver = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  188 */   protected int debug = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  193 */   protected int input = 2048;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  198 */   protected boolean listings = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  203 */   protected boolean readOnly = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected CompressionFormat[] compressionFormats;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  213 */   protected int output = 2048;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  218 */   protected String localXsltFile = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  223 */   protected String contextXsltFile = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  228 */   protected String globalXsltFile = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  233 */   protected String readmeFile = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  238 */   protected transient WebResourceRoot resources = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  244 */   protected String fileEncoding = null;
/*  245 */   private transient Charset fileEncodingCharset = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  251 */   private BomConfig useBomIfPresent = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  256 */   protected int sendfileSize = 49152;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  261 */   protected boolean useAcceptRanges = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  266 */   protected boolean showServerInfo = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  271 */   protected boolean sortListings = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected transient SortManager sortManager;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  281 */   private boolean allowPartialPut = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init()
/*      */     throws ServletException
/*      */   {
/*  301 */     if (getServletConfig().getInitParameter("debug") != null) {
/*  302 */       this.debug = Integer.parseInt(getServletConfig().getInitParameter("debug"));
/*      */     }
/*      */     
/*  305 */     if (getServletConfig().getInitParameter("input") != null) {
/*  306 */       this.input = Integer.parseInt(getServletConfig().getInitParameter("input"));
/*      */     }
/*      */     
/*  309 */     if (getServletConfig().getInitParameter("output") != null) {
/*  310 */       this.output = Integer.parseInt(getServletConfig().getInitParameter("output"));
/*      */     }
/*      */     
/*  313 */     this.listings = Boolean.parseBoolean(getServletConfig().getInitParameter("listings"));
/*      */     
/*  315 */     if (getServletConfig().getInitParameter("readonly") != null) {
/*  316 */       this.readOnly = Boolean.parseBoolean(getServletConfig().getInitParameter("readonly"));
/*      */     }
/*      */     
/*  319 */     this.compressionFormats = parseCompressionFormats(
/*  320 */       getServletConfig().getInitParameter("precompressed"), 
/*  321 */       getServletConfig().getInitParameter("gzip"));
/*      */     
/*  323 */     if (getServletConfig().getInitParameter("sendfileSize") != null) {
/*  324 */       this.sendfileSize = (Integer.parseInt(getServletConfig().getInitParameter("sendfileSize")) * 1024);
/*      */     }
/*      */     
/*  327 */     this.fileEncoding = getServletConfig().getInitParameter("fileEncoding");
/*  328 */     if (this.fileEncoding == null) {
/*  329 */       this.fileEncodingCharset = Charset.defaultCharset();
/*  330 */       this.fileEncoding = this.fileEncodingCharset.name();
/*      */     } else {
/*      */       try {
/*  333 */         this.fileEncodingCharset = B2CConverter.getCharset(this.fileEncoding);
/*      */       } catch (UnsupportedEncodingException e) {
/*  335 */         throw new ServletException(e);
/*      */       }
/*      */     }
/*      */     
/*  339 */     String useBomIfPresent = getServletConfig().getInitParameter("useBomIfPresent");
/*  340 */     if (useBomIfPresent == null)
/*      */     {
/*  342 */       this.useBomIfPresent = BomConfig.TRUE;
/*      */     } else {
/*  344 */       for (BomConfig bomConfig : BomConfig.values()) {
/*  345 */         if (bomConfig.configurationValue.equalsIgnoreCase(useBomIfPresent)) {
/*  346 */           this.useBomIfPresent = bomConfig;
/*  347 */           break;
/*      */         }
/*      */       }
/*  350 */       if (this.useBomIfPresent == null)
/*      */       {
/*      */ 
/*  353 */         IllegalArgumentException iae = new IllegalArgumentException(sm.getString("defaultServlet.unknownBomConfig", new Object[] { useBomIfPresent }));
/*  354 */         throw new ServletException(iae);
/*      */       }
/*      */     }
/*      */     
/*  358 */     this.globalXsltFile = getServletConfig().getInitParameter("globalXsltFile");
/*  359 */     this.contextXsltFile = getServletConfig().getInitParameter("contextXsltFile");
/*  360 */     this.localXsltFile = getServletConfig().getInitParameter("localXsltFile");
/*  361 */     this.readmeFile = getServletConfig().getInitParameter("readmeFile");
/*      */     
/*  363 */     if (getServletConfig().getInitParameter("useAcceptRanges") != null) {
/*  364 */       this.useAcceptRanges = Boolean.parseBoolean(getServletConfig().getInitParameter("useAcceptRanges"));
/*      */     }
/*      */     
/*      */ 
/*  368 */     if (this.input < 256) {
/*  369 */       this.input = 256;
/*      */     }
/*  371 */     if (this.output < 256) {
/*  372 */       this.output = 256;
/*      */     }
/*      */     
/*  375 */     if (this.debug > 0) {
/*  376 */       log("DefaultServlet.init:  input buffer size=" + this.input + ", output buffer size=" + this.output);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  381 */     this.resources = ((WebResourceRoot)getServletContext().getAttribute("org.apache.catalina.resources"));
/*      */     
/*  383 */     if (this.resources == null) {
/*  384 */       throw new UnavailableException(sm.getString("defaultServlet.noResources"));
/*      */     }
/*      */     
/*  387 */     if (getServletConfig().getInitParameter("showServerInfo") != null) {
/*  388 */       this.showServerInfo = Boolean.parseBoolean(getServletConfig().getInitParameter("showServerInfo"));
/*      */     }
/*      */     
/*  391 */     if (getServletConfig().getInitParameter("sortListings") != null) {
/*  392 */       this.sortListings = Boolean.parseBoolean(getServletConfig().getInitParameter("sortListings"));
/*      */       
/*  394 */       if (this.sortListings) { boolean sortDirectoriesFirst;
/*      */         boolean sortDirectoriesFirst;
/*  396 */         if (getServletConfig().getInitParameter("sortDirectoriesFirst") != null) {
/*  397 */           sortDirectoriesFirst = Boolean.parseBoolean(getServletConfig().getInitParameter("sortDirectoriesFirst"));
/*      */         } else {
/*  399 */           sortDirectoriesFirst = false;
/*      */         }
/*      */         
/*  402 */         this.sortManager = new SortManager(sortDirectoriesFirst);
/*      */       }
/*      */     }
/*      */     
/*  406 */     if (getServletConfig().getInitParameter("allowPartialPut") != null) {
/*  407 */       this.allowPartialPut = Boolean.parseBoolean(getServletConfig().getInitParameter("allowPartialPut"));
/*      */     }
/*      */   }
/*      */   
/*      */   private CompressionFormat[] parseCompressionFormats(String precompressed, String gzip) {
/*  412 */     List<CompressionFormat> ret = new ArrayList();
/*  413 */     if ((precompressed != null) && (precompressed.indexOf('=') > 0)) {
/*  414 */       for (String pair : precompressed.split(",")) {
/*  415 */         String[] setting = pair.split("=");
/*  416 */         String encoding = setting[0];
/*  417 */         String extension = setting[1];
/*  418 */         ret.add(new CompressionFormat(extension, encoding));
/*      */       }
/*  420 */     } else if (precompressed != null) {
/*  421 */       if (Boolean.parseBoolean(precompressed)) {
/*  422 */         ret.add(new CompressionFormat(".br", "br"));
/*  423 */         ret.add(new CompressionFormat(".gz", "gzip"));
/*      */       }
/*  425 */     } else if (Boolean.parseBoolean(gzip))
/*      */     {
/*  427 */       ret.add(new CompressionFormat(".gz", "gzip"));
/*      */     }
/*  429 */     return (CompressionFormat[])ret.toArray(new CompressionFormat[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getRelativePath(HttpServletRequest request)
/*      */   {
/*  443 */     return getRelativePath(request, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected String getRelativePath(HttpServletRequest request, boolean allowEmptyPath)
/*      */   {
/*      */     String servletPath;
/*      */     
/*      */     String pathInfo;
/*      */     
/*      */     String servletPath;
/*      */     
/*  456 */     if (request.getAttribute("javax.servlet.include.request_uri") != null)
/*      */     {
/*  458 */       String pathInfo = (String)request.getAttribute("javax.servlet.include.path_info");
/*  459 */       servletPath = (String)request.getAttribute("javax.servlet.include.servlet_path");
/*      */     } else {
/*  461 */       pathInfo = request.getPathInfo();
/*  462 */       servletPath = request.getServletPath();
/*      */     }
/*      */     
/*  465 */     StringBuilder result = new StringBuilder();
/*  466 */     if (servletPath.length() > 0) {
/*  467 */       result.append(servletPath);
/*      */     }
/*  469 */     if (pathInfo != null) {
/*  470 */       result.append(pathInfo);
/*      */     }
/*  472 */     if ((result.length() == 0) && (!allowEmptyPath)) {
/*  473 */       result.append('/');
/*      */     }
/*      */     
/*  476 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getPathPrefix(HttpServletRequest request)
/*      */   {
/*  488 */     return request.getContextPath();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void service(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  496 */     if (req.getDispatcherType() == DispatcherType.ERROR) {
/*  497 */       doGet(req, resp);
/*      */     } else {
/*  499 */       super.service(req, resp);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doGet(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  519 */     serveResource(request, response, true, this.fileEncoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doHead(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  539 */     boolean serveContent = DispatcherType.INCLUDE.equals(request.getDispatcherType());
/*  540 */     serveResource(request, response, serveContent, this.fileEncoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doOptions(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  567 */     resp.setHeader("Allow", determineMethodsAllowed(req));
/*      */   }
/*      */   
/*      */   protected String determineMethodsAllowed(HttpServletRequest req)
/*      */   {
/*  572 */     StringBuilder allow = new StringBuilder();
/*      */     
/*      */ 
/*  575 */     allow.append("OPTIONS, GET, HEAD, POST");
/*      */     
/*      */ 
/*  578 */     if (!this.readOnly) {
/*  579 */       allow.append(", PUT, DELETE");
/*      */     }
/*      */     
/*      */ 
/*  583 */     if (((req instanceof RequestFacade)) && 
/*  584 */       (((RequestFacade)req).getAllowTrace())) {
/*  585 */       allow.append(", TRACE");
/*      */     }
/*      */     
/*  588 */     return allow.toString();
/*      */   }
/*      */   
/*      */   protected void sendNotAllowed(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/*  594 */     resp.addHeader("Allow", determineMethodsAllowed(req));
/*  595 */     resp.sendError(405);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doPost(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  612 */     doGet(request, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doPut(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  629 */     if (this.readOnly) {
/*  630 */       sendNotAllowed(req, resp);
/*  631 */       return;
/*      */     }
/*      */     
/*  634 */     String path = getRelativePath(req);
/*      */     
/*  636 */     WebResource resource = this.resources.getResource(path);
/*      */     
/*  638 */     Range range = parseContentRange(req, resp);
/*      */     
/*  640 */     if (range == null)
/*      */     {
/*  642 */       return;
/*      */     }
/*      */     
/*  645 */     InputStream resourceInputStream = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  652 */       if (range == IGNORE) {
/*  653 */         resourceInputStream = req.getInputStream();
/*      */       } else {
/*  655 */         File contentFile = executePartialPut(req, range, path);
/*  656 */         resourceInputStream = new FileInputStream(contentFile);
/*      */       }
/*      */       
/*  659 */       if (this.resources.write(path, resourceInputStream, true)) {
/*  660 */         if (resource.exists()) {
/*  661 */           resp.setStatus(204);
/*      */         } else {
/*  663 */           resp.setStatus(201);
/*      */         }
/*      */       } else
/*  666 */         resp.sendError(409);
/*      */       return;
/*      */     } finally {
/*  669 */       if (resourceInputStream != null) {
/*      */         try {
/*  671 */           resourceInputStream.close();
/*      */         }
/*      */         catch (IOException localIOException1) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected File executePartialPut(HttpServletRequest req, Range range, String path)
/*      */     throws IOException
/*      */   {
/*  698 */     File tempDir = (File)getServletContext().getAttribute("javax.servlet.context.tempdir");
/*      */     
/*  700 */     String convertedResourcePath = path.replace('/', '.');
/*  701 */     File contentFile = new File(tempDir, convertedResourcePath);
/*  702 */     if (contentFile.createNewFile())
/*      */     {
/*  704 */       contentFile.deleteOnExit();
/*      */     }
/*      */     
/*  707 */     RandomAccessFile randAccessContentFile = new RandomAccessFile(contentFile, "rw");Throwable localThrowable9 = null;
/*      */     try
/*      */     {
/*  710 */       WebResource oldResource = this.resources.getResource(path);
/*      */       
/*      */ 
/*  713 */       if (oldResource.isFile())
/*      */       {
/*  715 */         BufferedInputStream bufOldRevStream = new BufferedInputStream(oldResource.getInputStream(), 4096);Throwable localThrowable10 = null;
/*      */         
/*      */         try
/*      */         {
/*  719 */           copyBuffer = new byte['က'];
/*  720 */           int numBytesRead; while ((numBytesRead = bufOldRevStream.read(copyBuffer)) != -1) {
/*  721 */             randAccessContentFile.write(copyBuffer, 0, numBytesRead);
/*      */           }
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/*  714 */           localThrowable10 = localThrowable1;throw localThrowable1;
/*      */         }
/*      */         finally {}
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  727 */       randAccessContentFile.setLength(range.length);
/*      */       
/*      */ 
/*  730 */       randAccessContentFile.seek(range.start);
/*      */       
/*  732 */       byte[] transferBuffer = new byte['က'];
/*      */       
/*  734 */       BufferedInputStream requestBufInStream = new BufferedInputStream(req.getInputStream(), 4096);byte[] copyBuffer = null;
/*      */       try { int numBytesRead;
/*  735 */         while ((numBytesRead = requestBufInStream.read(transferBuffer)) != -1) {
/*  736 */           randAccessContentFile.write(transferBuffer, 0, numBytesRead);
/*      */         }
/*      */       }
/*      */       catch (Throwable localThrowable12)
/*      */       {
/*  733 */         copyBuffer = localThrowable12;throw localThrowable12;
/*      */       }
/*      */       finally {}
/*      */     }
/*      */     catch (Throwable localThrowable7)
/*      */     {
/*  707 */       localThrowable9 = localThrowable7;throw localThrowable7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  739 */       if (randAccessContentFile != null) if (localThrowable9 != null) try { randAccessContentFile.close(); } catch (Throwable localThrowable8) { localThrowable9.addSuppressed(localThrowable8); } else randAccessContentFile.close();
/*      */     }
/*  741 */     return contentFile;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doDelete(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  758 */     if (this.readOnly) {
/*  759 */       sendNotAllowed(req, resp);
/*  760 */       return;
/*      */     }
/*      */     
/*  763 */     String path = getRelativePath(req);
/*      */     
/*  765 */     WebResource resource = this.resources.getResource(path);
/*      */     
/*  767 */     if (resource.exists()) {
/*  768 */       if (resource.delete()) {
/*  769 */         resp.setStatus(204);
/*      */       } else {
/*  771 */         resp.sendError(405);
/*      */       }
/*      */     } else {
/*  774 */       resp.sendError(404);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkIfHeaders(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */     throws IOException
/*      */   {
/*  797 */     return (checkIfMatch(request, response, resource)) && 
/*  798 */       (checkIfModifiedSince(request, response, resource)) && 
/*  799 */       (checkIfNoneMatch(request, response, resource)) && 
/*  800 */       (checkIfUnmodifiedSince(request, response, resource));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String rewriteUrl(String path)
/*      */   {
/*  812 */     return URLEncoder.DEFAULT.encode(path, StandardCharsets.UTF_8);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void serveResource(HttpServletRequest request, HttpServletResponse response, boolean content, String inputEncoding)
/*      */     throws IOException, ServletException
/*      */   {
/*  834 */     boolean serveContent = content;
/*      */     
/*      */ 
/*  837 */     String path = getRelativePath(request, true);
/*      */     
/*  839 */     if (this.debug > 0) {
/*  840 */       if (serveContent) {
/*  841 */         log("DefaultServlet.serveResource:  Serving resource '" + path + "' headers and data");
/*      */       }
/*      */       else {
/*  844 */         log("DefaultServlet.serveResource:  Serving resource '" + path + "' headers only");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  849 */     if (path.length() == 0)
/*      */     {
/*  851 */       doDirectoryRedirect(request, response);
/*  852 */       return;
/*      */     }
/*      */     
/*  855 */     WebResource resource = this.resources.getResource(path);
/*  856 */     boolean isError = DispatcherType.ERROR == request.getDispatcherType();
/*      */     
/*  858 */     if (!resource.exists())
/*      */     {
/*      */ 
/*  861 */       String requestUri = (String)request.getAttribute("javax.servlet.include.request_uri");
/*      */       
/*  863 */       if (requestUri == null) {
/*  864 */         requestUri = request.getRequestURI();
/*      */       }
/*      */       else
/*      */       {
/*  868 */         throw new FileNotFoundException(sm.getString("defaultServlet.missingResource", new Object[] { requestUri }));
/*      */       }
/*      */       
/*      */ 
/*  872 */       if (isError) {
/*  873 */         response.sendError(((Integer)request.getAttribute("javax.servlet.error.status_code"))
/*  874 */           .intValue());
/*      */       } else {
/*  876 */         response.sendError(404, sm
/*  877 */           .getString("defaultServlet.missingResource", new Object[] { requestUri }));
/*      */       }
/*  879 */       return;
/*      */     }
/*      */     
/*  882 */     if (!resource.canRead())
/*      */     {
/*      */ 
/*  885 */       String requestUri = (String)request.getAttribute("javax.servlet.include.request_uri");
/*      */       
/*  887 */       if (requestUri == null) {
/*  888 */         requestUri = request.getRequestURI();
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  893 */         throw new FileNotFoundException(sm.getString("defaultServlet.missingResource", new Object[] { requestUri }));
/*      */       }
/*      */       
/*      */ 
/*  897 */       if (isError) {
/*  898 */         response.sendError(((Integer)request.getAttribute("javax.servlet.error.status_code"))
/*  899 */           .intValue());
/*      */       } else {
/*  901 */         response.sendError(403, requestUri);
/*      */       }
/*  903 */       return;
/*      */     }
/*      */     
/*  906 */     boolean included = false;
/*      */     
/*      */ 
/*  909 */     if (resource.isFile())
/*      */     {
/*  911 */       included = request.getAttribute("javax.servlet.include.context_path") != null;
/*      */       
/*  913 */       if ((!included) && (!isError) && (!checkIfHeaders(request, response, resource))) {
/*  914 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  919 */     String contentType = resource.getMimeType();
/*  920 */     if (contentType == null) {
/*  921 */       contentType = getServletContext().getMimeType(resource.getName());
/*  922 */       resource.setMimeType(contentType);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  928 */     String eTag = null;
/*  929 */     String lastModifiedHttp = null;
/*  930 */     if ((resource.isFile()) && (!isError)) {
/*  931 */       eTag = generateETag(resource);
/*  932 */       lastModifiedHttp = resource.getLastModifiedHttp();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  937 */     boolean usingPrecompressedVersion = false;
/*  938 */     if ((this.compressionFormats.length > 0) && (!included) && (resource.isFile()) && 
/*  939 */       (!pathEndsWithCompressedExtension(path)))
/*      */     {
/*  941 */       List<PrecompressedResource> precompressedResources = getAvailablePrecompressedResources(path);
/*  942 */       if (!precompressedResources.isEmpty()) {
/*  943 */         ResponseUtil.addVaryFieldName(response, "accept-encoding");
/*      */         
/*  945 */         PrecompressedResource bestResource = getBestPrecompressedResource(request, precompressedResources);
/*  946 */         if (bestResource != null) {
/*  947 */           response.addHeader("Content-Encoding", bestResource.format.encoding);
/*  948 */           resource = bestResource.resource;
/*  949 */           usingPrecompressedVersion = true;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  954 */     ArrayList<Range> ranges = FULL;
/*  955 */     long contentLength = -1L;
/*      */     
/*  957 */     if (resource.isDirectory()) {
/*  958 */       if (!path.endsWith("/")) {
/*  959 */         doDirectoryRedirect(request, response);
/*  960 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  965 */       if (!this.listings) {
/*  966 */         response.sendError(404, sm
/*  967 */           .getString("defaultServlet.missingResource", new Object[] {request.getRequestURI() }));
/*  968 */         return;
/*      */       }
/*  970 */       contentType = "text/html;charset=UTF-8";
/*      */     } else {
/*  972 */       if (!isError) {
/*  973 */         if (this.useAcceptRanges)
/*      */         {
/*  975 */           response.setHeader("Accept-Ranges", "bytes");
/*      */         }
/*      */         
/*      */ 
/*  979 */         ranges = parseRange(request, response, resource);
/*  980 */         if (ranges == null) {
/*  981 */           return;
/*      */         }
/*      */         
/*      */ 
/*  985 */         response.setHeader("ETag", eTag);
/*      */         
/*      */ 
/*  988 */         response.setHeader("Last-Modified", lastModifiedHttp);
/*      */       }
/*      */       
/*      */ 
/*  992 */       contentLength = resource.getContentLength();
/*      */       
/*      */ 
/*  995 */       if (contentLength == 0L) {
/*  996 */         serveContent = false;
/*      */       }
/*      */     }
/*      */     
/* 1000 */     ServletOutputStream ostream = null;
/* 1001 */     PrintWriter writer = null;
/*      */     
/* 1003 */     if (serveContent) {
/*      */       try
/*      */       {
/* 1006 */         ostream = response.getOutputStream();
/*      */       }
/*      */       catch (IllegalStateException e)
/*      */       {
/* 1010 */         if ((!usingPrecompressedVersion) && (isText(contentType))) {
/* 1011 */           writer = response.getWriter();
/*      */           
/* 1013 */           ranges = FULL;
/*      */         } else {
/* 1015 */           throw e;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1023 */     ServletResponse r = response;
/* 1024 */     long contentWritten = 0L;
/* 1025 */     while ((r instanceof ServletResponseWrapper)) {
/* 1026 */       r = ((ServletResponseWrapper)r).getResponse();
/*      */     }
/* 1028 */     if ((r instanceof ResponseFacade)) {
/* 1029 */       contentWritten = ((ResponseFacade)r).getContentWritten();
/*      */     }
/* 1031 */     if (contentWritten > 0L) {
/* 1032 */       ranges = FULL;
/*      */     }
/*      */     
/* 1035 */     String outputEncoding = response.getCharacterEncoding();
/* 1036 */     Charset charset = B2CConverter.getCharset(outputEncoding);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1050 */     boolean outputEncodingSpecified = (outputEncoding != Constants.DEFAULT_BODY_CHARSET.name()) && (outputEncoding != this.resources.getContext().getResponseCharacterEncoding());
/* 1051 */     boolean conversionRequired; if ((!usingPrecompressedVersion) && (isText(contentType)) && (outputEncodingSpecified) && 
/* 1052 */       (!charset.equals(this.fileEncodingCharset))) {
/* 1053 */       boolean conversionRequired = true;
/*      */       
/*      */ 
/* 1056 */       ranges = FULL;
/*      */     } else {
/* 1058 */       conversionRequired = false;
/*      */     }
/*      */     
/* 1061 */     if ((resource.isDirectory()) || (isError) || (ranges == FULL))
/*      */     {
/* 1063 */       if (contentType != null) {
/* 1064 */         if (this.debug > 0) {
/* 1065 */           log("DefaultServlet.serveFile:  contentType='" + contentType + "'");
/*      */         }
/*      */         
/*      */ 
/* 1069 */         if (response.getContentType() == null) {
/* 1070 */           response.setContentType(contentType);
/*      */         }
/*      */       }
/* 1073 */       if ((resource.isFile()) && (contentLength >= 0L) && ((!serveContent) || (ostream != null)))
/*      */       {
/* 1075 */         if (this.debug > 0) {
/* 1076 */           log("DefaultServlet.serveFile:  contentLength=" + contentLength);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1081 */         if ((contentWritten == 0L) && (!conversionRequired)) {
/* 1082 */           response.setContentLengthLong(contentLength);
/*      */         }
/*      */       }
/*      */       
/* 1086 */       if (serveContent) {
/*      */         try {
/* 1088 */           response.setBufferSize(this.output);
/*      */         }
/*      */         catch (IllegalStateException localIllegalStateException1) {}
/*      */         
/* 1092 */         InputStream renderResult = null;
/* 1093 */         if (ostream == null)
/*      */         {
/*      */ 
/* 1096 */           if (resource.isDirectory()) {
/* 1097 */             renderResult = render(request, getPathPrefix(request), resource, inputEncoding);
/*      */           } else {
/* 1099 */             renderResult = resource.getInputStream();
/* 1100 */             if (included)
/*      */             {
/* 1102 */               if (!renderResult.markSupported()) {
/* 1103 */                 renderResult = new BufferedInputStream(renderResult);
/*      */               }
/* 1105 */               Charset bomCharset = processBom(renderResult, this.useBomIfPresent.stripBom);
/* 1106 */               if ((bomCharset != null) && (this.useBomIfPresent.useBomEncoding)) {
/* 1107 */                 inputEncoding = bomCharset.name();
/*      */               }
/*      */             }
/*      */           }
/* 1111 */           copy(renderResult, writer, inputEncoding);
/*      */         }
/*      */         else {
/* 1114 */           if (resource.isDirectory()) {
/* 1115 */             renderResult = render(request, getPathPrefix(request), resource, inputEncoding);
/*      */ 
/*      */ 
/*      */           }
/* 1119 */           else if ((conversionRequired) || (included))
/*      */           {
/*      */ 
/*      */ 
/* 1123 */             InputStream source = resource.getInputStream();
/* 1124 */             if (!source.markSupported()) {
/* 1125 */               source = new BufferedInputStream(source);
/*      */             }
/* 1127 */             Charset bomCharset = processBom(source, this.useBomIfPresent.stripBom);
/* 1128 */             if ((bomCharset != null) && (this.useBomIfPresent.useBomEncoding)) {
/* 1129 */               inputEncoding = bomCharset.name();
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 1134 */             if (outputEncodingSpecified) {
/* 1135 */               OutputStreamWriter osw = new OutputStreamWriter(ostream, charset);
/* 1136 */               PrintWriter pw = new PrintWriter(osw);
/* 1137 */               copy(source, pw, inputEncoding);
/* 1138 */               pw.flush();
/*      */             }
/*      */             else {
/* 1141 */               renderResult = source;
/*      */             }
/*      */           }
/* 1144 */           else if (!checkSendfile(request, response, resource, contentLength, null))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1151 */             byte[] resourceBody = null;
/* 1152 */             if ((resource instanceof CachedResource)) {
/* 1153 */               resourceBody = resource.getContent();
/*      */             }
/* 1155 */             if (resourceBody == null)
/*      */             {
/*      */ 
/* 1158 */               renderResult = resource.getInputStream();
/*      */             }
/*      */             else {
/* 1161 */               ostream.write(resourceBody);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 1168 */           if (renderResult != null) {
/* 1169 */             copy(renderResult, ostream);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1176 */       if ((ranges == null) || (ranges.isEmpty())) {
/* 1177 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1182 */       response.setStatus(206);
/*      */       
/* 1184 */       if (ranges.size() == 1)
/*      */       {
/* 1186 */         Range range = (Range)ranges.get(0);
/* 1187 */         response.addHeader("Content-Range", "bytes " + range.start + "-" + range.end + "/" + range.length);
/*      */         
/*      */ 
/*      */ 
/* 1191 */         long length = range.end - range.start + 1L;
/* 1192 */         response.setContentLengthLong(length);
/*      */         
/* 1194 */         if (contentType != null) {
/* 1195 */           if (this.debug > 0) {
/* 1196 */             log("DefaultServlet.serveFile:  contentType='" + contentType + "'");
/*      */           }
/*      */           
/* 1199 */           response.setContentType(contentType);
/*      */         }
/*      */         
/* 1202 */         if (serveContent) {
/*      */           try {
/* 1204 */             response.setBufferSize(this.output);
/*      */           }
/*      */           catch (IllegalStateException localIllegalStateException2) {}
/*      */           
/* 1208 */           if (ostream != null) {
/* 1209 */             if (!checkSendfile(request, response, resource, range.end - range.start + 1L, range))
/*      */             {
/* 1211 */               copy(resource, ostream, range);
/*      */             }
/*      */           }
/*      */           else {
/* 1215 */             throw new IllegalStateException();
/*      */           }
/*      */         }
/*      */       } else {
/* 1219 */         response.setContentType("multipart/byteranges; boundary=CATALINA_MIME_BOUNDARY");
/*      */         
/* 1221 */         if (serveContent) {
/*      */           try {
/* 1223 */             response.setBufferSize(this.output);
/*      */           }
/*      */           catch (IllegalStateException localIllegalStateException3) {}
/*      */           
/* 1227 */           if (ostream != null) {
/* 1228 */             copy(resource, ostream, ranges.iterator(), contentType);
/*      */           }
/*      */           else {
/* 1231 */             throw new IllegalStateException();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Charset processBom(InputStream is, boolean stripBom)
/*      */     throws IOException
/*      */   {
/* 1244 */     byte[] bom = new byte[4];
/* 1245 */     is.mark(bom.length);
/*      */     
/* 1247 */     int count = is.read(bom);
/*      */     
/*      */ 
/* 1250 */     if (count < 2) {
/* 1251 */       skip(is, 0, stripBom);
/* 1252 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1256 */     int b0 = bom[0] & 0xFF;
/* 1257 */     int b1 = bom[1] & 0xFF;
/* 1258 */     if ((b0 == 254) && (b1 == 255)) {
/* 1259 */       skip(is, 2, stripBom);
/* 1260 */       return StandardCharsets.UTF_16BE;
/*      */     }
/*      */     
/*      */ 
/* 1264 */     if ((count == 2) && (b0 == 255) && (b1 == 254)) {
/* 1265 */       skip(is, 2, stripBom);
/* 1266 */       return StandardCharsets.UTF_16LE;
/*      */     }
/*      */     
/*      */ 
/* 1270 */     if (count < 3) {
/* 1271 */       skip(is, 0, stripBom);
/* 1272 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1276 */     int b2 = bom[2] & 0xFF;
/* 1277 */     if ((b0 == 239) && (b1 == 187) && (b2 == 191)) {
/* 1278 */       skip(is, 3, stripBom);
/* 1279 */       return StandardCharsets.UTF_8;
/*      */     }
/*      */     
/* 1282 */     if (count < 4) {
/* 1283 */       skip(is, 0, stripBom);
/* 1284 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1288 */     int b3 = bom[3] & 0xFF;
/* 1289 */     if ((b0 == 0) && (b1 == 0) && (b2 == 254) && (b3 == 255)) {
/* 1290 */       return Charset.forName("UTF-32BE");
/*      */     }
/* 1292 */     if ((b0 == 255) && (b1 == 254) && (b2 == 0) && (b3 == 0)) {
/* 1293 */       return Charset.forName("UTF-32LE");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1299 */     if ((b0 == 255) && (b1 == 254)) {
/* 1300 */       skip(is, 2, stripBom);
/* 1301 */       return StandardCharsets.UTF_16LE;
/*      */     }
/*      */     
/* 1304 */     skip(is, 0, stripBom);
/* 1305 */     return null;
/*      */   }
/*      */   
/*      */   private static void skip(InputStream is, int skip, boolean stripBom) throws IOException
/*      */   {
/* 1310 */     is.reset();
/* 1311 */     if (stripBom) {
/* 1312 */       while (skip-- > 0) {
/* 1313 */         is.read();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static boolean isText(String contentType)
/*      */   {
/* 1320 */     return (contentType == null) || (contentType.startsWith("text")) || 
/* 1321 */       (contentType.endsWith("xml")) || (contentType.contains("/javascript"));
/*      */   }
/*      */   
/*      */   private boolean pathEndsWithCompressedExtension(String path)
/*      */   {
/* 1326 */     for (CompressionFormat format : this.compressionFormats) {
/* 1327 */       if (path.endsWith(format.extension)) {
/* 1328 */         return true;
/*      */       }
/*      */     }
/* 1331 */     return false;
/*      */   }
/*      */   
/*      */   private List<PrecompressedResource> getAvailablePrecompressedResources(String path) {
/* 1335 */     List<PrecompressedResource> ret = new ArrayList(this.compressionFormats.length);
/* 1336 */     for (CompressionFormat format : this.compressionFormats) {
/* 1337 */       WebResource precompressedResource = this.resources.getResource(path + format.extension);
/* 1338 */       if ((precompressedResource.exists()) && (precompressedResource.isFile())) {
/* 1339 */         ret.add(new PrecompressedResource(precompressedResource, format, null));
/*      */       }
/*      */     }
/* 1342 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private PrecompressedResource getBestPrecompressedResource(HttpServletRequest request, List<PrecompressedResource> precompressedResources)
/*      */   {
/* 1354 */     Enumeration<String> headers = request.getHeaders("Accept-Encoding");
/* 1355 */     PrecompressedResource bestResource = null;
/* 1356 */     double bestResourceQuality = 0.0D;
/* 1357 */     int bestResourcePreference = Integer.MAX_VALUE;
/* 1358 */     while (headers.hasMoreElements()) {
/* 1359 */       String header = (String)headers.nextElement();
/* 1360 */       for (String preference : header.split(",")) {
/* 1361 */         double quality = 1.0D;
/* 1362 */         int qualityIdx = preference.indexOf(';');
/* 1363 */         if (qualityIdx > 0) {
/* 1364 */           int equalsIdx = preference.indexOf('=', qualityIdx + 1);
/* 1365 */           if (equalsIdx != -1)
/*      */           {
/*      */ 
/* 1368 */             quality = Double.parseDouble(preference.substring(equalsIdx + 1).trim());
/*      */           }
/* 1370 */         } else if (quality >= bestResourceQuality) {
/* 1371 */           String encoding = preference;
/* 1372 */           if (qualityIdx > 0) {
/* 1373 */             encoding = encoding.substring(0, qualityIdx);
/*      */           }
/* 1375 */           encoding = encoding.trim();
/* 1376 */           if ("identity".equals(encoding)) {
/* 1377 */             bestResource = null;
/* 1378 */             bestResourceQuality = quality;
/* 1379 */             bestResourcePreference = Integer.MAX_VALUE;
/*      */ 
/*      */           }
/* 1382 */           else if ("*".equals(encoding)) {
/* 1383 */             bestResource = (PrecompressedResource)precompressedResources.get(0);
/* 1384 */             bestResourceQuality = quality;
/* 1385 */             bestResourcePreference = 0;
/*      */           }
/*      */           else {
/* 1388 */             for (int i = 0; i < precompressedResources.size(); i++) {
/* 1389 */               PrecompressedResource resource = (PrecompressedResource)precompressedResources.get(i);
/* 1390 */               if (encoding.equals(resource.format.encoding)) {
/* 1391 */                 if ((quality <= bestResourceQuality) && (i >= bestResourcePreference)) break;
/* 1392 */                 bestResource = resource;
/* 1393 */                 bestResourceQuality = quality;
/* 1394 */                 bestResourcePreference = i; break;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1402 */     return bestResource;
/*      */   }
/*      */   
/*      */   private void doDirectoryRedirect(HttpServletRequest request, HttpServletResponse response) throws IOException
/*      */   {
/* 1407 */     StringBuilder location = new StringBuilder(request.getRequestURI());
/* 1408 */     location.append('/');
/* 1409 */     if (request.getQueryString() != null) {
/* 1410 */       location.append('?');
/* 1411 */       location.append(request.getQueryString());
/*      */     }
/*      */     
/* 1414 */     while ((location.length() > 1) && (location.charAt(1) == '/')) {
/* 1415 */       location.deleteCharAt(0);
/*      */     }
/* 1417 */     response.sendRedirect(response.encodeRedirectURL(location.toString()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Range parseContentRange(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException
/*      */   {
/* 1435 */     String contentRangeHeader = request.getHeader("Content-Range");
/*      */     
/* 1437 */     if (contentRangeHeader == null) {
/* 1438 */       return IGNORE;
/*      */     }
/*      */     
/* 1441 */     if (!this.allowPartialPut) {
/* 1442 */       response.sendError(400);
/* 1443 */       return null;
/*      */     }
/*      */     
/* 1446 */     ContentRange contentRange = ContentRange.parse(new StringReader(contentRangeHeader));
/*      */     
/* 1448 */     if (contentRange == null) {
/* 1449 */       response.sendError(400);
/* 1450 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1455 */     if (!contentRange.getUnits().equals("bytes")) {
/* 1456 */       response.sendError(400);
/* 1457 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1462 */     Range range = new Range();
/* 1463 */     range.start = contentRange.getStart();
/* 1464 */     range.end = contentRange.getEnd();
/* 1465 */     range.length = contentRange.getLength();
/*      */     
/* 1467 */     if (!range.validate()) {
/* 1468 */       response.sendError(400);
/* 1469 */       return null;
/*      */     }
/*      */     
/* 1472 */     return range;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ArrayList<Range> parseRange(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */     throws IOException
/*      */   {
/* 1495 */     String headerValue = request.getHeader("If-Range");
/*      */     
/* 1497 */     if (headerValue != null)
/*      */     {
/* 1499 */       long headerValueTime = -1L;
/*      */       try {
/* 1501 */         headerValueTime = request.getDateHeader("If-Range");
/*      */       }
/*      */       catch (IllegalArgumentException localIllegalArgumentException) {}
/*      */       
/*      */ 
/* 1506 */       String eTag = generateETag(resource);
/* 1507 */       long lastModified = resource.getLastModified();
/*      */       
/* 1509 */       if (headerValueTime == -1L)
/*      */       {
/*      */ 
/* 1512 */         if (!eTag.equals(headerValue.trim())) {
/* 1513 */           return FULL;
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 1519 */       else if (Math.abs(lastModified - headerValueTime) > 1000L) {
/* 1520 */         return FULL;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1525 */     long fileLength = resource.getContentLength();
/*      */     
/* 1527 */     if (fileLength == 0L)
/*      */     {
/*      */ 
/* 1530 */       return FULL;
/*      */     }
/*      */     
/*      */ 
/* 1534 */     String rangeHeader = request.getHeader("Range");
/*      */     
/* 1536 */     if (rangeHeader == null)
/*      */     {
/* 1538 */       return FULL;
/*      */     }
/*      */     
/* 1541 */     Ranges ranges = Ranges.parse(new StringReader(rangeHeader));
/*      */     
/* 1543 */     if (ranges == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1549 */       response.addHeader("Content-Range", "bytes */" + fileLength);
/* 1550 */       response.sendError(416);
/* 1551 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1556 */     if (!ranges.getUnits().equals("bytes"))
/*      */     {
/* 1558 */       return FULL;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1563 */     ArrayList<Range> result = new ArrayList();
/*      */     
/* 1565 */     for (Ranges.Entry entry : ranges.getEntries()) {
/* 1566 */       Range currentRange = new Range();
/* 1567 */       if (entry.getStart() == -1L) {
/* 1568 */         currentRange.start = (fileLength - entry.getEnd());
/* 1569 */         if (currentRange.start < 0L) {
/* 1570 */           currentRange.start = 0L;
/*      */         }
/* 1572 */         currentRange.end = (fileLength - 1L);
/* 1573 */       } else if (entry.getEnd() == -1L) {
/* 1574 */         currentRange.start = entry.getStart();
/* 1575 */         currentRange.end = (fileLength - 1L);
/*      */       } else {
/* 1577 */         currentRange.start = entry.getStart();
/* 1578 */         currentRange.end = entry.getEnd();
/*      */       }
/* 1580 */       currentRange.length = fileLength;
/*      */       
/* 1582 */       if (!currentRange.validate()) {
/* 1583 */         response.addHeader("Content-Range", "bytes */" + fileLength);
/* 1584 */         response.sendError(416);
/* 1585 */         return null;
/*      */       }
/*      */       
/* 1588 */       result.add(currentRange);
/*      */     }
/*      */     
/* 1591 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected InputStream render(String contextPath, WebResource resource, String encoding)
/*      */     throws IOException, ServletException
/*      */   {
/* 1613 */     return render(null, contextPath, resource, encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputStream render(HttpServletRequest request, String contextPath, WebResource resource, String encoding)
/*      */     throws IOException, ServletException
/*      */   {
/* 1632 */     Source xsltSource = findXsltSource(resource);
/*      */     
/* 1634 */     if (xsltSource == null) {
/* 1635 */       return renderHtml(request, contextPath, resource, encoding);
/*      */     }
/* 1637 */     return renderXml(request, contextPath, resource, xsltSource, encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected InputStream renderXml(String contextPath, WebResource resource, Source xsltSource, String encoding)
/*      */     throws ServletException, IOException
/*      */   {
/* 1662 */     return renderXml(null, contextPath, resource, xsltSource, encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputStream renderXml(HttpServletRequest request, String contextPath, WebResource resource, Source xsltSource, String encoding)
/*      */     throws IOException, ServletException
/*      */   {
/* 1684 */     StringBuilder sb = new StringBuilder();
/*      */     
/* 1686 */     sb.append("<?xml version=\"1.0\"?>");
/* 1687 */     sb.append("<listing ");
/* 1688 */     sb.append(" contextPath='");
/* 1689 */     sb.append(contextPath);
/* 1690 */     sb.append('\'');
/* 1691 */     sb.append(" directory='");
/* 1692 */     sb.append(resource.getName());
/* 1693 */     sb.append("' ");
/* 1694 */     sb.append(" hasParent='").append(!resource.getName().equals("/"));
/* 1695 */     sb.append("'>");
/*      */     
/* 1697 */     sb.append("<entries>");
/*      */     
/* 1699 */     String[] entries = this.resources.list(resource.getWebappPath());
/*      */     
/*      */ 
/* 1702 */     String rewrittenContextPath = rewriteUrl(contextPath);
/* 1703 */     String directoryWebappPath = resource.getWebappPath();
/*      */     
/* 1705 */     for (String entry : entries)
/*      */     {
/* 1707 */       if ((!entry.equalsIgnoreCase("WEB-INF")) && 
/* 1708 */         (!entry.equalsIgnoreCase("META-INF")) && 
/* 1709 */         (!entry.equalsIgnoreCase(this.localXsltFile)))
/*      */       {
/*      */ 
/*      */ 
/* 1713 */         if (!(directoryWebappPath + entry).equals(this.contextXsltFile))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1718 */           WebResource childResource = this.resources.getResource(directoryWebappPath + entry);
/* 1719 */           if (childResource.exists())
/*      */           {
/*      */ 
/*      */ 
/* 1723 */             sb.append("<entry");
/* 1724 */             sb.append(" type='")
/* 1725 */               .append(childResource.isDirectory() ? "dir" : "file")
/* 1726 */               .append('\'');
/* 1727 */             sb.append(" urlPath='")
/* 1728 */               .append(rewrittenContextPath)
/* 1729 */               .append(rewriteUrl(directoryWebappPath + entry))
/* 1730 */               .append(childResource.isDirectory() ? "/" : "")
/* 1731 */               .append('\'');
/* 1732 */             if (childResource.isFile())
/*      */             {
/*      */ 
/* 1735 */               sb.append(" size='").append(renderSize(childResource.getContentLength())).append('\'');
/*      */             }
/*      */             
/*      */ 
/* 1739 */             sb.append(" date='").append(childResource.getLastModifiedHttp()).append('\'');
/*      */             
/* 1741 */             sb.append('>');
/* 1742 */             sb.append(Escape.htmlElementContent(entry));
/* 1743 */             if (childResource.isDirectory()) {
/* 1744 */               sb.append('/');
/*      */             }
/* 1746 */             sb.append("</entry>");
/*      */           } } } }
/* 1748 */     sb.append("</entries>");
/*      */     
/* 1750 */     String readme = getReadme(resource, encoding);
/*      */     
/* 1752 */     if (readme != null) {
/* 1753 */       sb.append("<readme><![CDATA[");
/* 1754 */       sb.append(readme);
/* 1755 */       sb.append("]]></readme>");
/*      */     }
/*      */     
/* 1758 */     sb.append("</listing>");
/*      */     
/*      */     ClassLoader original;
/*      */     
/*      */     ClassLoader original;
/* 1763 */     if (Globals.IS_SECURITY_ENABLED) {
/* 1764 */       PrivilegedGetTccl pa = new PrivilegedGetTccl();
/* 1765 */       original = (ClassLoader)AccessController.doPrivileged(pa);
/*      */     } else {
/* 1767 */       original = Thread.currentThread().getContextClassLoader();
/*      */     }
/*      */     try {
/* 1770 */       if (Globals.IS_SECURITY_ENABLED)
/*      */       {
/* 1772 */         PrivilegedSetTccl pa = new PrivilegedSetTccl(DefaultServlet.class.getClassLoader());
/* 1773 */         AccessController.doPrivileged(pa);
/*      */       } else {
/* 1775 */         Thread.currentThread().setContextClassLoader(DefaultServlet.class
/* 1776 */           .getClassLoader());
/*      */       }
/*      */       
/* 1779 */       TransformerFactory tFactory = TransformerFactory.newInstance();
/* 1780 */       Source xmlSource = new StreamSource(new StringReader(sb.toString()));
/* 1781 */       Transformer transformer = tFactory.newTransformer(xsltSource);
/*      */       
/* 1783 */       ByteArrayOutputStream stream = new ByteArrayOutputStream();
/* 1784 */       OutputStreamWriter osWriter = new OutputStreamWriter(stream, StandardCharsets.UTF_8);
/* 1785 */       StreamResult out = new StreamResult(osWriter);
/* 1786 */       transformer.transform(xmlSource, out);
/* 1787 */       osWriter.flush();
/* 1788 */       PrivilegedSetTccl pa; return new ByteArrayInputStream(stream.toByteArray());
/*      */     } catch (TransformerException e) {
/* 1790 */       throw new ServletException(sm.getString("defaultServlet.xslError"), e);
/*      */     } finally {
/* 1792 */       if (Globals.IS_SECURITY_ENABLED) {
/* 1793 */         PrivilegedSetTccl pa = new PrivilegedSetTccl(original);
/* 1794 */         AccessController.doPrivileged(pa);
/*      */       } else {
/* 1796 */         Thread.currentThread().setContextClassLoader(original);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected InputStream renderHtml(String contextPath, WebResource resource, String encoding)
/*      */     throws IOException
/*      */   {
/* 1819 */     return renderHtml(null, contextPath, resource, encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputStream renderHtml(HttpServletRequest request, String contextPath, WebResource resource, String encoding)
/*      */     throws IOException
/*      */   {
/* 1839 */     ByteArrayOutputStream stream = new ByteArrayOutputStream();
/* 1840 */     OutputStreamWriter osWriter = new OutputStreamWriter(stream, StandardCharsets.UTF_8);
/* 1841 */     PrintWriter writer = new PrintWriter(osWriter);
/*      */     
/* 1843 */     StringBuilder sb = new StringBuilder();
/*      */     
/* 1845 */     String directoryWebappPath = resource.getWebappPath();
/* 1846 */     WebResource[] entries = this.resources.listResources(directoryWebappPath);
/*      */     
/*      */ 
/* 1849 */     String rewrittenContextPath = rewriteUrl(contextPath);
/*      */     
/*      */ 
/* 1852 */     sb.append("<!doctype html><html>\r\n");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1857 */     sb.append("<head>\r\n");
/* 1858 */     sb.append("<title>");
/* 1859 */     sb.append(sm.getString("directory.title", new Object[] { directoryWebappPath }));
/* 1860 */     sb.append("</title>\r\n");
/* 1861 */     sb.append("<style>");
/* 1862 */     sb.append("body {font-family:Tahoma,Arial,sans-serif;} h1, h2, h3, b {color:white;background-color:#525D76;} h1 {font-size:22px;} h2 {font-size:16px;} h3 {font-size:14px;} p {font-size:12px;} a {color:black;} .line {height:1px;background-color:#525D76;border:none;}");
/* 1863 */     sb.append("</style> ");
/* 1864 */     sb.append("</head>\r\n");
/* 1865 */     sb.append("<body>");
/* 1866 */     sb.append("<h1>");
/* 1867 */     sb.append(sm.getString("directory.title", new Object[] { directoryWebappPath }));
/*      */     
/*      */ 
/* 1870 */     String parentDirectory = directoryWebappPath;
/* 1871 */     if (parentDirectory.endsWith("/"))
/*      */     {
/* 1873 */       parentDirectory = parentDirectory.substring(0, parentDirectory.length() - 1);
/*      */     }
/* 1875 */     int slash = parentDirectory.lastIndexOf('/');
/* 1876 */     if (slash >= 0) {
/* 1877 */       String parent = directoryWebappPath.substring(0, slash);
/* 1878 */       sb.append(" - <a href=\"");
/* 1879 */       sb.append(rewrittenContextPath);
/* 1880 */       if (parent.equals("")) {
/* 1881 */         parent = "/";
/*      */       }
/* 1883 */       sb.append(rewriteUrl(parent));
/* 1884 */       if (!parent.endsWith("/")) {
/* 1885 */         sb.append('/');
/*      */       }
/* 1887 */       sb.append("\">");
/* 1888 */       sb.append("<b>");
/* 1889 */       sb.append(sm.getString("directory.parent", new Object[] { parent }));
/* 1890 */       sb.append("</b>");
/* 1891 */       sb.append("</a>");
/*      */     }
/*      */     
/* 1894 */     sb.append("</h1>");
/* 1895 */     sb.append("<hr class=\"line\">");
/*      */     
/* 1897 */     sb.append("<table width=\"100%\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\">\r\n");
/*      */     
/*      */     DefaultServlet.SortManager.Order order;
/*      */     DefaultServlet.SortManager.Order order;
/* 1901 */     if ((this.sortListings) && (null != request)) {
/* 1902 */       order = this.sortManager.getOrder(request.getQueryString());
/*      */     } else {
/* 1904 */       order = null;
/*      */     }
/*      */     
/* 1907 */     sb.append("<tr>\r\n");
/* 1908 */     sb.append("<td align=\"left\"><font size=\"+1\"><strong>");
/* 1909 */     if ((this.sortListings) && (null != request)) {
/* 1910 */       sb.append("<a href=\"?C=N;O=");
/* 1911 */       sb.append(getOrderChar(order, 'N'));
/* 1912 */       sb.append("\">");
/* 1913 */       sb.append(sm.getString("directory.filename"));
/* 1914 */       sb.append("</a>");
/*      */     } else {
/* 1916 */       sb.append(sm.getString("directory.filename"));
/*      */     }
/* 1918 */     sb.append("</strong></font></td>\r\n");
/* 1919 */     sb.append("<td align=\"center\"><font size=\"+1\"><strong>");
/* 1920 */     if ((this.sortListings) && (null != request)) {
/* 1921 */       sb.append("<a href=\"?C=S;O=");
/* 1922 */       sb.append(getOrderChar(order, 'S'));
/* 1923 */       sb.append("\">");
/* 1924 */       sb.append(sm.getString("directory.size"));
/* 1925 */       sb.append("</a>");
/*      */     } else {
/* 1927 */       sb.append(sm.getString("directory.size"));
/*      */     }
/* 1929 */     sb.append("</strong></font></td>\r\n");
/* 1930 */     sb.append("<td align=\"right\"><font size=\"+1\"><strong>");
/* 1931 */     if ((this.sortListings) && (null != request)) {
/* 1932 */       sb.append("<a href=\"?C=M;O=");
/* 1933 */       sb.append(getOrderChar(order, 'M'));
/* 1934 */       sb.append("\">");
/* 1935 */       sb.append(sm.getString("directory.lastModified"));
/* 1936 */       sb.append("</a>");
/*      */     } else {
/* 1938 */       sb.append(sm.getString("directory.lastModified"));
/*      */     }
/* 1940 */     sb.append("</strong></font></td>\r\n");
/* 1941 */     sb.append("</tr>");
/*      */     
/* 1943 */     if ((null != this.sortManager) && (null != request)) {
/* 1944 */       this.sortManager.sort(entries, request.getQueryString());
/*      */     }
/*      */     
/* 1947 */     boolean shade = false;
/* 1948 */     for (WebResource childResource : entries) {
/* 1949 */       String filename = childResource.getName();
/* 1950 */       if ((!filename.equalsIgnoreCase("WEB-INF")) && 
/* 1951 */         (!filename.equalsIgnoreCase("META-INF")))
/*      */       {
/*      */ 
/*      */ 
/* 1955 */         if (childResource.exists())
/*      */         {
/*      */ 
/*      */ 
/* 1959 */           sb.append("<tr");
/* 1960 */           if (shade) {
/* 1961 */             sb.append(" bgcolor=\"#eeeeee\"");
/*      */           }
/* 1963 */           sb.append(">\r\n");
/* 1964 */           shade = !shade;
/*      */           
/* 1966 */           sb.append("<td align=\"left\">&nbsp;&nbsp;\r\n");
/* 1967 */           sb.append("<a href=\"");
/* 1968 */           sb.append(rewrittenContextPath);
/* 1969 */           sb.append(rewriteUrl(childResource.getWebappPath()));
/* 1970 */           if (childResource.isDirectory()) {
/* 1971 */             sb.append('/');
/*      */           }
/* 1973 */           sb.append("\"><tt>");
/* 1974 */           sb.append(Escape.htmlElementContent(filename));
/* 1975 */           if (childResource.isDirectory()) {
/* 1976 */             sb.append('/');
/*      */           }
/* 1978 */           sb.append("</tt></a></td>\r\n");
/*      */           
/* 1980 */           sb.append("<td align=\"right\"><tt>");
/* 1981 */           if (childResource.isDirectory()) {
/* 1982 */             sb.append("&nbsp;");
/*      */           } else {
/* 1984 */             sb.append(renderSize(childResource.getContentLength()));
/*      */           }
/* 1986 */           sb.append("</tt></td>\r\n");
/*      */           
/* 1988 */           sb.append("<td align=\"right\"><tt>");
/* 1989 */           sb.append(childResource.getLastModifiedHttp());
/* 1990 */           sb.append("</tt></td>\r\n");
/*      */           
/* 1992 */           sb.append("</tr>\r\n");
/*      */         }
/*      */       }
/*      */     }
/* 1996 */     sb.append("</table>\r\n");
/*      */     
/* 1998 */     sb.append("<hr class=\"line\">");
/*      */     
/* 2000 */     String readme = getReadme(resource, encoding);
/* 2001 */     if (readme != null) {
/* 2002 */       sb.append(readme);
/* 2003 */       sb.append("<hr class=\"line\">");
/*      */     }
/*      */     
/* 2006 */     if (this.showServerInfo) {
/* 2007 */       sb.append("<h3>").append(ServerInfo.getServerInfo()).append("</h3>");
/*      */     }
/* 2009 */     sb.append("</body>\r\n");
/* 2010 */     sb.append("</html>\r\n");
/*      */     
/*      */ 
/* 2013 */     writer.write(sb.toString());
/* 2014 */     writer.flush();
/* 2015 */     return new ByteArrayInputStream(stream.toByteArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String renderSize(long size)
/*      */   {
/* 2028 */     long leftSide = size / 1024L;
/* 2029 */     long rightSide = size % 1024L / 103L;
/* 2030 */     if ((leftSide == 0L) && (rightSide == 0L) && (size > 0L)) {
/* 2031 */       rightSide = 1L;
/*      */     }
/*      */     
/* 2034 */     return "" + leftSide + "." + rightSide + " kb";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getReadme(WebResource directory, String encoding)
/*      */   {
/* 2047 */     if (this.readmeFile != null) {
/* 2048 */       WebResource resource = this.resources.getResource(directory
/* 2049 */         .getWebappPath() + this.readmeFile);
/* 2050 */       StringWriter buffer; if (resource.isFile()) {
/* 2051 */         buffer = new StringWriter();
/* 2052 */         InputStreamReader reader = null;
/* 2053 */         try { InputStream is = resource.getInputStream();Throwable localThrowable3 = null;
/* 2054 */           try { if (encoding != null) {
/* 2055 */               reader = new InputStreamReader(is, encoding);
/*      */             } else {
/* 2057 */               reader = new InputStreamReader(is);
/*      */             }
/* 2059 */             copyRange(reader, new PrintWriter(buffer));
/*      */           }
/*      */           catch (Throwable localThrowable1)
/*      */           {
/* 2053 */             localThrowable3 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/* 2060 */             if (is != null) { if (localThrowable3 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else { is.close();
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2070 */           return buffer.toString();
/*      */         }
/*      */         catch (IOException e)
/*      */         {
/* 2061 */           log(sm.getString("defaultServlet.readerCloseFailed"), e);
/*      */         } finally {
/* 2063 */           if (reader != null) {
/*      */             try {
/* 2065 */               reader.close();
/*      */             }
/*      */             catch (IOException localIOException3) {}
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2072 */       if (this.debug > 10) {
/* 2073 */         log("readme '" + this.readmeFile + "' not found");
/*      */       }
/*      */       
/* 2076 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 2080 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Source findXsltSource(WebResource directory)
/*      */     throws IOException
/*      */   {
/* 2093 */     if (this.localXsltFile != null) {
/* 2094 */       WebResource resource = this.resources.getResource(directory
/* 2095 */         .getWebappPath() + this.localXsltFile);
/* 2096 */       if (resource.isFile()) {
/* 2097 */         InputStream is = resource.getInputStream();
/* 2098 */         if (is != null) {
/* 2099 */           if (Globals.IS_SECURITY_ENABLED) {
/* 2100 */             return secureXslt(is);
/*      */           }
/* 2102 */           return new StreamSource(is);
/*      */         }
/*      */       }
/*      */       
/* 2106 */       if (this.debug > 10) {
/* 2107 */         log("localXsltFile '" + this.localXsltFile + "' not found");
/*      */       }
/*      */     }
/*      */     
/* 2111 */     if (this.contextXsltFile != null)
/*      */     {
/* 2113 */       InputStream is = getServletContext().getResourceAsStream(this.contextXsltFile);
/* 2114 */       if (is != null) {
/* 2115 */         if (Globals.IS_SECURITY_ENABLED) {
/* 2116 */           return secureXslt(is);
/*      */         }
/* 2118 */         return new StreamSource(is);
/*      */       }
/*      */       
/*      */ 
/* 2122 */       if (this.debug > 10) {
/* 2123 */         log("contextXsltFile '" + this.contextXsltFile + "' not found");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2130 */     if (this.globalXsltFile != null) {
/* 2131 */       File f = validateGlobalXsltFile();
/* 2132 */       if (f != null) {
/* 2133 */         long globalXsltFileSize = f.length();
/* 2134 */         if (globalXsltFileSize > 2147483647L) {
/* 2135 */           log("globalXsltFile [" + f.getAbsolutePath() + "] is too big to buffer");
/*      */         } else {
/* 2137 */           FileInputStream fis = new FileInputStream(f);Throwable localThrowable3 = null;
/* 2138 */           try { byte[] b = new byte[(int)f.length()];
/* 2139 */             IOTools.readFully(fis, b);
/* 2140 */             return new StreamSource(new ByteArrayInputStream(b));
/*      */           }
/*      */           catch (Throwable localThrowable1)
/*      */           {
/* 2137 */             localThrowable3 = localThrowable1;throw localThrowable1;
/*      */           }
/*      */           finally
/*      */           {
/* 2141 */             if (fis != null) if (localThrowable3 != null) try { fis.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else fis.close();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2146 */     return null;
/*      */   }
/*      */   
/*      */   private File validateGlobalXsltFile()
/*      */   {
/* 2151 */     Context context = this.resources.getContext();
/*      */     
/* 2153 */     File baseConf = new File(context.getCatalinaBase(), "conf");
/* 2154 */     File result = validateGlobalXsltFile(baseConf);
/* 2155 */     if (result == null) {
/* 2156 */       File homeConf = new File(context.getCatalinaHome(), "conf");
/* 2157 */       if (!baseConf.equals(homeConf)) {
/* 2158 */         result = validateGlobalXsltFile(homeConf);
/*      */       }
/*      */     }
/*      */     
/* 2162 */     return result;
/*      */   }
/*      */   
/*      */   private File validateGlobalXsltFile(File base)
/*      */   {
/* 2167 */     File candidate = new File(this.globalXsltFile);
/* 2168 */     if (!candidate.isAbsolute()) {
/* 2169 */       candidate = new File(base, this.globalXsltFile);
/*      */     }
/*      */     
/* 2172 */     if (!candidate.isFile()) {
/* 2173 */       return null;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 2178 */       if (!candidate.getCanonicalFile().toPath().startsWith(base.getCanonicalFile().toPath())) {
/* 2179 */         return null;
/*      */       }
/*      */     } catch (IOException ioe) {
/* 2182 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 2186 */     String nameLower = candidate.getName().toLowerCase(Locale.ENGLISH);
/* 2187 */     if ((!nameLower.endsWith(".xslt")) && (!nameLower.endsWith(".xsl"))) {
/* 2188 */       return null;
/*      */     }
/*      */     
/* 2191 */     return candidate;
/*      */   }
/*      */   
/*      */ 
/*      */   private Source secureXslt(InputStream is)
/*      */   {
/* 2197 */     result = null;
/*      */     try {
/* 2199 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 2200 */       builder.setEntityResolver(secureEntityResolver);
/* 2201 */       Document document = builder.parse(is);
/* 2202 */       return new DOMSource(document);
/*      */     } catch (ParserConfigurationException|SAXException|IOException e) {
/* 2204 */       if (this.debug > 0) {
/* 2205 */         log(e.getMessage(), e);
/*      */       }
/*      */     } finally {
/* 2208 */       if (is != null) {
/*      */         try {
/* 2210 */           is.close();
/*      */         }
/*      */         catch (IOException localIOException2) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkSendfile(HttpServletRequest request, HttpServletResponse response, WebResource resource, long length, Range range)
/*      */   {
/* 2238 */     if ((this.sendfileSize > 0) && (length > this.sendfileSize)) {
/*      */       String canonicalPath;
/* 2240 */       if ((Boolean.TRUE.equals(request.getAttribute("org.apache.tomcat.sendfile.support"))) && 
/* 2241 */         (request.getClass().getName().equals("org.apache.catalina.connector.RequestFacade")) && 
/* 2242 */         (response.getClass().getName().equals("org.apache.catalina.connector.ResponseFacade")) && 
/* 2243 */         (resource.isFile()) && 
/* 2244 */         ((canonicalPath = resource.getCanonicalPath()) != null))
/*      */       {
/* 2246 */         request.setAttribute("org.apache.tomcat.sendfile.filename", canonicalPath);
/* 2247 */         if (range == null) {
/* 2248 */           request.setAttribute("org.apache.tomcat.sendfile.start", Long.valueOf(0L));
/* 2249 */           request.setAttribute("org.apache.tomcat.sendfile.end", Long.valueOf(length));
/*      */         } else {
/* 2251 */           request.setAttribute("org.apache.tomcat.sendfile.start", Long.valueOf(range.start));
/* 2252 */           request.setAttribute("org.apache.tomcat.sendfile.end", Long.valueOf(range.end + 1L));
/*      */         }
/* 2254 */         return true;
/*      */       } }
/* 2256 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkIfMatch(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */     throws IOException
/*      */   {
/* 2274 */     String headerValue = request.getHeader("If-Match");
/* 2275 */     if (headerValue != null)
/*      */     {
/*      */       boolean conditionSatisfied;
/*      */       boolean conditionSatisfied;
/* 2279 */       if (!headerValue.equals("*")) {
/* 2280 */         String resourceETag = generateETag(resource);
/* 2281 */         boolean conditionSatisfied; if (resourceETag == null) {
/* 2282 */           conditionSatisfied = false;
/*      */         }
/*      */         else {
/* 2285 */           Boolean matched = EntityTag.compareEntityTag(new StringReader(headerValue), false, resourceETag);
/* 2286 */           if (matched == null) {
/* 2287 */             if (this.debug > 10) {
/* 2288 */               log("DefaultServlet.checkIfMatch:  Invalid header value [" + headerValue + "]");
/*      */             }
/* 2290 */             response.sendError(400);
/* 2291 */             return false;
/*      */           }
/* 2293 */           conditionSatisfied = matched.booleanValue();
/*      */         }
/*      */       } else {
/* 2296 */         conditionSatisfied = true;
/*      */       }
/*      */       
/* 2299 */       if (!conditionSatisfied) {
/* 2300 */         response.sendError(412);
/* 2301 */         return false;
/*      */       }
/*      */     }
/* 2304 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkIfModifiedSince(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */   {
/*      */     try
/*      */     {
/* 2321 */       long headerValue = request.getDateHeader("If-Modified-Since");
/* 2322 */       long lastModified = resource.getLastModified();
/* 2323 */       if (headerValue != -1L)
/*      */       {
/*      */ 
/*      */ 
/* 2327 */         if ((request.getHeader("If-None-Match") == null) && (lastModified < headerValue + 1000L))
/*      */         {
/*      */ 
/*      */ 
/* 2331 */           response.setStatus(304);
/* 2332 */           response.setHeader("ETag", generateETag(resource));
/*      */           
/* 2334 */           return false;
/*      */         }
/*      */       }
/*      */     } catch (IllegalArgumentException illegalArgument) {
/* 2338 */       return true;
/*      */     }
/* 2340 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkIfNoneMatch(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */     throws IOException
/*      */   {
/* 2358 */     String headerValue = request.getHeader("If-None-Match");
/* 2359 */     if (headerValue != null)
/*      */     {
/*      */ 
/*      */ 
/* 2363 */       String resourceETag = generateETag(resource);
/* 2364 */       boolean conditionSatisfied; boolean conditionSatisfied; if (!headerValue.equals("*")) { boolean conditionSatisfied;
/* 2365 */         if (resourceETag == null) {
/* 2366 */           conditionSatisfied = false;
/*      */         }
/*      */         else {
/* 2369 */           Boolean matched = EntityTag.compareEntityTag(new StringReader(headerValue), true, resourceETag);
/* 2370 */           if (matched == null) {
/* 2371 */             if (this.debug > 10) {
/* 2372 */               log("DefaultServlet.checkIfNoneMatch:  Invalid header value [" + headerValue + "]");
/*      */             }
/* 2374 */             response.sendError(400);
/* 2375 */             return false;
/*      */           }
/* 2377 */           conditionSatisfied = matched.booleanValue();
/*      */         }
/*      */       } else {
/* 2380 */         conditionSatisfied = true;
/*      */       }
/*      */       
/* 2383 */       if (conditionSatisfied)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 2388 */         if (("GET".equals(request.getMethod())) || ("HEAD".equals(request.getMethod()))) {
/* 2389 */           response.setStatus(304);
/* 2390 */           response.setHeader("ETag", resourceETag);
/*      */         } else {
/* 2392 */           response.sendError(412);
/*      */         }
/* 2394 */         return false;
/*      */       }
/*      */     }
/* 2397 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkIfUnmodifiedSince(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/* 2416 */       long lastModified = resource.getLastModified();
/* 2417 */       long headerValue = request.getDateHeader("If-Unmodified-Since");
/* 2418 */       if ((headerValue != -1L) && 
/* 2419 */         (lastModified >= headerValue + 1000L))
/*      */       {
/*      */ 
/* 2422 */         response.sendError(412);
/* 2423 */         return false;
/*      */       }
/*      */     }
/*      */     catch (IllegalArgumentException illegalArgument) {
/* 2427 */       return true;
/*      */     }
/* 2429 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String generateETag(WebResource resource)
/*      */   {
/* 2444 */     return resource.getETag();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void copy(InputStream is, ServletOutputStream ostream)
/*      */     throws IOException
/*      */   {
/* 2460 */     IOException exception = null;
/* 2461 */     InputStream istream = new BufferedInputStream(is, this.input);
/*      */     
/*      */ 
/* 2464 */     exception = copyRange(istream, ostream);
/*      */     
/*      */ 
/* 2467 */     istream.close();
/*      */     
/*      */ 
/* 2470 */     if (exception != null) {
/* 2471 */       throw exception;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void copy(InputStream is, PrintWriter writer, String encoding)
/*      */     throws IOException
/*      */   {
/* 2488 */     IOException exception = null;
/*      */     Reader reader;
/*      */     Reader reader;
/* 2491 */     if (encoding == null) {
/* 2492 */       reader = new InputStreamReader(is);
/*      */     } else {
/* 2494 */       reader = new InputStreamReader(is, encoding);
/*      */     }
/*      */     
/*      */ 
/* 2498 */     exception = copyRange(reader, writer);
/*      */     
/*      */ 
/* 2501 */     reader.close();
/*      */     
/*      */ 
/* 2504 */     if (exception != null) {
/* 2505 */       throw exception;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void copy(WebResource resource, ServletOutputStream ostream, Range range)
/*      */     throws IOException
/*      */   {
/* 2524 */     IOException exception = null;
/*      */     
/* 2526 */     InputStream resourceInputStream = resource.getInputStream();
/* 2527 */     InputStream istream = new BufferedInputStream(resourceInputStream, this.input);
/*      */     
/* 2529 */     exception = copyRange(istream, ostream, range.start, range.end);
/*      */     
/*      */ 
/* 2532 */     istream.close();
/*      */     
/*      */ 
/* 2535 */     if (exception != null) {
/* 2536 */       throw exception;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void copy(WebResource resource, ServletOutputStream ostream, Iterator<Range> ranges, String contentType)
/*      */     throws IOException
/*      */   {
/* 2558 */     IOException exception = null;
/*      */     
/* 2560 */     while ((exception == null) && (ranges.hasNext()))
/*      */     {
/* 2562 */       InputStream resourceInputStream = resource.getInputStream();
/* 2563 */       InputStream istream = new BufferedInputStream(resourceInputStream, this.input);Throwable localThrowable3 = null;
/*      */       try {
/* 2565 */         Range currentRange = (Range)ranges.next();
/*      */         
/*      */ 
/* 2568 */         ostream.println();
/* 2569 */         ostream.println("--CATALINA_MIME_BOUNDARY");
/* 2570 */         if (contentType != null) {
/* 2571 */           ostream.println("Content-Type: " + contentType);
/*      */         }
/* 2573 */         ostream.println("Content-Range: bytes " + currentRange.start + "-" + currentRange.end + "/" + currentRange.length);
/*      */         
/*      */ 
/* 2576 */         ostream.println();
/*      */         
/*      */ 
/* 2579 */         exception = copyRange(istream, ostream, currentRange.start, currentRange.end);
/*      */       }
/*      */       catch (Throwable localThrowable1)
/*      */       {
/* 2563 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2581 */         if (istream != null) if (localThrowable3 != null) try { istream.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else istream.close();
/*      */       }
/*      */     }
/* 2584 */     ostream.println();
/* 2585 */     ostream.print("--CATALINA_MIME_BOUNDARY--");
/*      */     
/*      */ 
/* 2588 */     if (exception != null) {
/* 2589 */       throw exception;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected IOException copyRange(InputStream istream, ServletOutputStream ostream)
/*      */   {
/* 2608 */     exception = null;
/* 2609 */     byte[] buffer = new byte[this.input];
/* 2610 */     int len = buffer.length;
/*      */     try {
/*      */       for (;;) {
/* 2613 */         len = istream.read(buffer);
/* 2614 */         if (len == -1) {
/*      */           break;
/*      */         }
/* 2617 */         ostream.write(buffer, 0, len);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2624 */       return exception;
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 2619 */       exception = e;
/* 2620 */       len = -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected IOException copyRange(Reader reader, PrintWriter writer)
/*      */   {
/* 2641 */     exception = null;
/* 2642 */     char[] buffer = new char[this.input];
/* 2643 */     int len = buffer.length;
/*      */     try {
/*      */       for (;;) {
/* 2646 */         len = reader.read(buffer);
/* 2647 */         if (len == -1) {
/*      */           break;
/*      */         }
/* 2650 */         writer.write(buffer, 0, len);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2657 */       return exception;
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 2652 */       exception = e;
/* 2653 */       len = -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected IOException copyRange(InputStream istream, ServletOutputStream ostream, long start, long end)
/*      */   {
/* 2677 */     if (this.debug > 10) {
/* 2678 */       log("Serving bytes:" + start + "-" + end);
/*      */     }
/*      */     
/* 2681 */     long skipped = 0L;
/*      */     try {
/* 2683 */       skipped = istream.skip(start);
/*      */     } catch (IOException e) {
/* 2685 */       return e;
/*      */     }
/* 2687 */     if (skipped < start) {
/* 2688 */       return new IOException(sm.getString("defaultServlet.skipfail", new Object[] {
/* 2689 */         Long.valueOf(skipped), Long.valueOf(start) }));
/*      */     }
/*      */     
/* 2692 */     IOException exception = null;
/* 2693 */     long bytesToRead = end - start + 1L;
/*      */     
/* 2695 */     byte[] buffer = new byte[this.input];
/* 2696 */     int len = buffer.length;
/* 2697 */     while ((bytesToRead > 0L) && (len >= buffer.length)) {
/*      */       try {
/* 2699 */         len = istream.read(buffer);
/* 2700 */         if (bytesToRead >= len) {
/* 2701 */           ostream.write(buffer, 0, len);
/* 2702 */           bytesToRead -= len;
/*      */         } else {
/* 2704 */           ostream.write(buffer, 0, (int)bytesToRead);
/* 2705 */           bytesToRead = 0L;
/*      */         }
/*      */       } catch (IOException e) {
/* 2708 */         exception = e;
/* 2709 */         len = -1;
/*      */       }
/* 2711 */       if (len < buffer.length) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 2716 */     return exception;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class Range
/*      */   {
/*      */     public long start;
/*      */     
/*      */ 
/*      */     public long end;
/*      */     
/*      */     public long length;
/*      */     
/*      */ 
/*      */     public boolean validate()
/*      */     {
/* 2733 */       if (this.end >= this.length) {
/* 2734 */         this.end = (this.length - 1L);
/*      */       }
/* 2736 */       return (this.start >= 0L) && (this.end >= 0L) && (this.start <= this.end) && (this.length > 0L);
/*      */     }
/*      */   }
/*      */   
/*      */   protected static class CompressionFormat implements Serializable {
/*      */     private static final long serialVersionUID = 1L;
/*      */     public final String extension;
/*      */     public final String encoding;
/*      */     
/*      */     public CompressionFormat(String extension, String encoding) {
/* 2746 */       this.extension = extension;
/* 2747 */       this.encoding = encoding;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class PrecompressedResource
/*      */   {
/*      */     public final WebResource resource;
/*      */     public final DefaultServlet.CompressionFormat format;
/*      */     
/*      */     private PrecompressedResource(WebResource resource, DefaultServlet.CompressionFormat format) {
/* 2757 */       this.resource = resource;
/* 2758 */       this.format = format;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class SecureEntityResolver
/*      */     implements EntityResolver2
/*      */   {
/*      */     public InputSource resolveEntity(String publicId, String systemId)
/*      */       throws SAXException, IOException
/*      */     {
/* 2772 */       throw new SAXException(DefaultServlet.sm.getString("defaultServlet.blockExternalEntity", new Object[] { publicId, systemId }));
/*      */     }
/*      */     
/*      */ 
/*      */     public InputSource getExternalSubset(String name, String baseURI)
/*      */       throws SAXException, IOException
/*      */     {
/* 2779 */       throw new SAXException(DefaultServlet.sm.getString("defaultServlet.blockExternalSubset", new Object[] { name, baseURI }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public InputSource resolveEntity(String name, String publicId, String baseURI, String systemId)
/*      */       throws SAXException, IOException
/*      */     {
/* 2787 */       throw new SAXException(DefaultServlet.sm.getString("defaultServlet.blockExternalEntity2", new Object[] { name, publicId, baseURI, systemId }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private char getOrderChar(DefaultServlet.SortManager.Order order, char column)
/*      */   {
/* 2803 */     if (column == order.column) {
/* 2804 */       if (order.ascending) {
/* 2805 */         return 'D';
/*      */       }
/* 2807 */       return 'A';
/*      */     }
/*      */     
/* 2810 */     return 'D';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void destroy() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class SortManager
/*      */   {
/*      */     protected Comparator<WebResource> defaultResourceComparator;
/*      */     
/*      */ 
/*      */ 
/*      */     protected Comparator<WebResource> resourceNameComparator;
/*      */     
/*      */ 
/*      */ 
/*      */     protected Comparator<WebResource> resourceNameComparatorAsc;
/*      */     
/*      */ 
/*      */ 
/*      */     protected Comparator<WebResource> resourceSizeComparator;
/*      */     
/*      */ 
/*      */ 
/*      */     protected Comparator<WebResource> resourceSizeComparatorAsc;
/*      */     
/*      */ 
/*      */ 
/*      */     protected Comparator<WebResource> resourceLastModifiedComparator;
/*      */     
/*      */ 
/*      */ 
/*      */     protected Comparator<WebResource> resourceLastModifiedComparatorAsc;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public SortManager(boolean directoriesFirst)
/*      */     {
/* 2855 */       this.resourceNameComparator = new DefaultServlet.ResourceNameComparator(null);
/* 2856 */       this.resourceNameComparatorAsc = Collections.reverseOrder(this.resourceNameComparator);
/* 2857 */       this.resourceSizeComparator = new DefaultServlet.ResourceSizeComparator(this.resourceNameComparator);
/* 2858 */       this.resourceSizeComparatorAsc = Collections.reverseOrder(this.resourceSizeComparator);
/* 2859 */       this.resourceLastModifiedComparator = new DefaultServlet.ResourceLastModifiedDateComparator(this.resourceNameComparator);
/* 2860 */       this.resourceLastModifiedComparatorAsc = Collections.reverseOrder(this.resourceLastModifiedComparator);
/*      */       
/* 2862 */       if (directoriesFirst) {
/* 2863 */         this.resourceNameComparator = new DefaultServlet.DirsFirstComparator(this.resourceNameComparator);
/* 2864 */         this.resourceNameComparatorAsc = new DefaultServlet.DirsFirstComparator(this.resourceNameComparatorAsc);
/* 2865 */         this.resourceSizeComparator = new DefaultServlet.DirsFirstComparator(this.resourceSizeComparator);
/* 2866 */         this.resourceSizeComparatorAsc = new DefaultServlet.DirsFirstComparator(this.resourceSizeComparatorAsc);
/* 2867 */         this.resourceLastModifiedComparator = new DefaultServlet.DirsFirstComparator(this.resourceLastModifiedComparator);
/* 2868 */         this.resourceLastModifiedComparatorAsc = new DefaultServlet.DirsFirstComparator(this.resourceLastModifiedComparatorAsc);
/*      */       }
/*      */       
/* 2871 */       this.defaultResourceComparator = this.resourceNameComparator;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void sort(WebResource[] resources, String order)
/*      */     {
/* 2883 */       Comparator<WebResource> comparator = getComparator(order);
/*      */       
/* 2885 */       if (null != comparator) {
/* 2886 */         Arrays.sort(resources, comparator);
/*      */       }
/*      */     }
/*      */     
/*      */     public Comparator<WebResource> getComparator(String order) {
/* 2891 */       return getComparator(getOrder(order));
/*      */     }
/*      */     
/*      */     public Comparator<WebResource> getComparator(Order order) {
/* 2895 */       if (null == order) {
/* 2896 */         return this.defaultResourceComparator;
/*      */       }
/*      */       
/* 2899 */       if ('N' == order.column) {
/* 2900 */         if (order.ascending) {
/* 2901 */           return this.resourceNameComparatorAsc;
/*      */         }
/* 2903 */         return this.resourceNameComparator;
/*      */       }
/*      */       
/*      */ 
/* 2907 */       if ('S' == order.column) {
/* 2908 */         if (order.ascending) {
/* 2909 */           return this.resourceSizeComparatorAsc;
/*      */         }
/* 2911 */         return this.resourceSizeComparator;
/*      */       }
/*      */       
/*      */ 
/* 2915 */       if ('M' == order.column) {
/* 2916 */         if (order.ascending) {
/* 2917 */           return this.resourceLastModifiedComparatorAsc;
/*      */         }
/* 2919 */         return this.resourceLastModifiedComparator;
/*      */       }
/*      */       
/*      */ 
/* 2923 */       return this.defaultResourceComparator;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Order getOrder(String order)
/*      */     {
/* 2938 */       if ((null == order) || (0 == order.trim().length())) {
/* 2939 */         return Order.DEFAULT;
/*      */       }
/*      */       
/* 2942 */       String[] options = order.split(";");
/*      */       
/* 2944 */       if (0 == options.length) {
/* 2945 */         return Order.DEFAULT;
/*      */       }
/*      */       
/* 2948 */       char column = '\000';
/* 2949 */       boolean ascending = false;
/*      */       
/* 2951 */       for (String option : options) {
/* 2952 */         option = option.trim();
/*      */         
/* 2954 */         if (2 < option.length()) {
/* 2955 */           char opt = option.charAt(0);
/* 2956 */           if ('C' == opt) {
/* 2957 */             column = option.charAt(2);
/* 2958 */           } else if ('O' == opt) {
/* 2959 */             ascending = 'A' == option.charAt(2);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2964 */       if ('N' == column) {
/* 2965 */         if (ascending) {
/* 2966 */           return Order.NAME_ASC;
/*      */         }
/* 2968 */         return Order.NAME;
/*      */       }
/*      */       
/*      */ 
/* 2972 */       if ('S' == column) {
/* 2973 */         if (ascending) {
/* 2974 */           return Order.SIZE_ASC;
/*      */         }
/* 2976 */         return Order.SIZE;
/*      */       }
/*      */       
/*      */ 
/* 2980 */       if ('M' == column) {
/* 2981 */         if (ascending) {
/* 2982 */           return Order.LAST_MODIFIED_ASC;
/*      */         }
/* 2984 */         return Order.LAST_MODIFIED;
/*      */       }
/*      */       
/*      */ 
/* 2988 */       return Order.DEFAULT;
/*      */     }
/*      */     
/*      */     public static class Order {
/*      */       final char column;
/*      */       final boolean ascending;
/*      */       
/*      */       public Order(char column, boolean ascending) {
/* 2996 */         this.column = column;
/* 2997 */         this.ascending = ascending;
/*      */       }
/*      */       
/* 3000 */       public static final Order NAME = new Order('N', false);
/* 3001 */       public static final Order NAME_ASC = new Order('N', true);
/* 3002 */       public static final Order SIZE = new Order('S', false);
/* 3003 */       public static final Order SIZE_ASC = new Order('S', true);
/* 3004 */       public static final Order LAST_MODIFIED = new Order('M', false);
/* 3005 */       public static final Order LAST_MODIFIED_ASC = new Order('M', true);
/*      */       
/* 3007 */       public static final Order DEFAULT = NAME;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class DirsFirstComparator implements Comparator<WebResource>
/*      */   {
/*      */     private final Comparator<WebResource> base;
/*      */     
/*      */     public DirsFirstComparator(Comparator<WebResource> core) {
/* 3016 */       this.base = core;
/*      */     }
/*      */     
/*      */     public int compare(WebResource r1, WebResource r2)
/*      */     {
/* 3021 */       if (r1.isDirectory()) {
/* 3022 */         if (r2.isDirectory()) {
/* 3023 */           return this.base.compare(r1, r2);
/*      */         }
/* 3025 */         return -1;
/*      */       }
/* 3027 */       if (r2.isDirectory()) {
/* 3028 */         return 1;
/*      */       }
/* 3030 */       return this.base.compare(r1, r2);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class ResourceNameComparator implements Comparator<WebResource>
/*      */   {
/*      */     public int compare(WebResource r1, WebResource r2)
/*      */     {
/* 3038 */       return r1.getName().compareTo(r2.getName());
/*      */     }
/*      */   }
/*      */   
/*      */   private static class ResourceSizeComparator implements Comparator<WebResource>
/*      */   {
/*      */     private Comparator<WebResource> base;
/*      */     
/*      */     public ResourceSizeComparator(Comparator<WebResource> base) {
/* 3047 */       this.base = base;
/*      */     }
/*      */     
/*      */     public int compare(WebResource r1, WebResource r2)
/*      */     {
/* 3052 */       int c = Long.compare(r1.getContentLength(), r2.getContentLength());
/*      */       
/* 3054 */       if (0 == c) {
/* 3055 */         return this.base.compare(r1, r2);
/*      */       }
/* 3057 */       return c;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class ResourceLastModifiedDateComparator implements Comparator<WebResource>
/*      */   {
/*      */     private Comparator<WebResource> base;
/*      */     
/*      */     public ResourceLastModifiedDateComparator(Comparator<WebResource> base) {
/* 3066 */       this.base = base;
/*      */     }
/*      */     
/*      */     public int compare(WebResource r1, WebResource r2)
/*      */     {
/* 3071 */       int c = Long.compare(r1.getLastModified(), r2.getLastModified());
/*      */       
/* 3073 */       if (0 == c) {
/* 3074 */         return this.base.compare(r1, r2);
/*      */       }
/* 3076 */       return c;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static enum BomConfig
/*      */   {
/* 3086 */     TRUE("true", true, true), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3091 */     FALSE("false", true, false), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3096 */     PASS_THROUGH("pass-through", false, false);
/*      */     
/*      */     final String configurationValue;
/*      */     final boolean stripBom;
/*      */     final boolean useBomEncoding;
/*      */     
/*      */     private BomConfig(String configurationValue, boolean stripBom, boolean useBomEncoding) {
/* 3103 */       this.configurationValue = configurationValue;
/* 3104 */       this.stripBom = stripBom;
/* 3105 */       this.useBomEncoding = useBomEncoding;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\servlets\DefaultServlet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */