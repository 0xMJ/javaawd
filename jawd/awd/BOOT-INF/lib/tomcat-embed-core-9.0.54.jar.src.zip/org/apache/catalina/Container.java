/*     */ package org.apache.catalina;
/*     */ 
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.io.File;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.juli.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface Container
/*     */   extends Lifecycle
/*     */ {
/*     */   public static final String ADD_CHILD_EVENT = "addChild";
/*     */   public static final String ADD_VALVE_EVENT = "addValve";
/*     */   public static final String REMOVE_CHILD_EVENT = "removeChild";
/*     */   public static final String REMOVE_VALVE_EVENT = "removeValve";
/*     */   
/*     */   public abstract Log getLogger();
/*     */   
/*     */   public abstract String getLogName();
/*     */   
/*     */   public abstract ObjectName getObjectName();
/*     */   
/*     */   public abstract String getDomain();
/*     */   
/*     */   public abstract String getMBeanKeyProperties();
/*     */   
/*     */   public abstract Pipeline getPipeline();
/*     */   
/*     */   public abstract Cluster getCluster();
/*     */   
/*     */   public abstract void setCluster(Cluster paramCluster);
/*     */   
/*     */   public abstract int getBackgroundProcessorDelay();
/*     */   
/*     */   public abstract void setBackgroundProcessorDelay(int paramInt);
/*     */   
/*     */   public abstract String getName();
/*     */   
/*     */   public abstract void setName(String paramString);
/*     */   
/*     */   public abstract Container getParent();
/*     */   
/*     */   public abstract void setParent(Container paramContainer);
/*     */   
/*     */   public abstract ClassLoader getParentClassLoader();
/*     */   
/*     */   public abstract void setParentClassLoader(ClassLoader paramClassLoader);
/*     */   
/*     */   public abstract Realm getRealm();
/*     */   
/*     */   public abstract void setRealm(Realm paramRealm);
/*     */   
/*     */   public static String getConfigPath(Container container, String resourceName)
/*     */   {
/* 308 */     StringBuilder result = new StringBuilder();
/* 309 */     Container host = null;
/* 310 */     Container engine = null;
/* 311 */     while (container != null) {
/* 312 */       if ((container instanceof Host)) {
/* 313 */         host = container;
/* 314 */       } else if ((container instanceof Engine)) {
/* 315 */         engine = container;
/*     */       }
/* 317 */       container = container.getParent();
/*     */     }
/* 319 */     if ((host != null) && (((Host)host).getXmlBase() != null)) {
/* 320 */       result.append(((Host)host).getXmlBase()).append('/');
/*     */     } else {
/* 322 */       result.append("conf/");
/* 323 */       if (engine != null) {
/* 324 */         result.append(engine.getName()).append('/');
/*     */       }
/* 326 */       if (host != null) {
/* 327 */         result.append(host.getName()).append('/');
/*     */       }
/*     */     }
/* 330 */     result.append(resourceName);
/* 331 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Service getService(Container container)
/*     */   {
/* 341 */     while ((container != null) && (!(container instanceof Engine))) {
/* 342 */       container = container.getParent();
/*     */     }
/* 344 */     if (container == null) {
/* 345 */       return null;
/*     */     }
/* 347 */     return ((Engine)container).getService();
/*     */   }
/*     */   
/*     */   public abstract void backgroundProcess();
/*     */   
/*     */   public abstract void addChild(Container paramContainer);
/*     */   
/*     */   public abstract void addContainerListener(ContainerListener paramContainerListener);
/*     */   
/*     */   public abstract void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
/*     */   
/*     */   public abstract Container findChild(String paramString);
/*     */   
/*     */   public abstract Container[] findChildren();
/*     */   
/*     */   public abstract ContainerListener[] findContainerListeners();
/*     */   
/*     */   public abstract void removeChild(Container paramContainer);
/*     */   
/*     */   public abstract void removeContainerListener(ContainerListener paramContainerListener);
/*     */   
/*     */   public abstract void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener);
/*     */   
/*     */   public abstract void fireContainerEvent(String paramString, Object paramObject);
/*     */   
/*     */   public abstract void logAccess(Request paramRequest, Response paramResponse, long paramLong, boolean paramBoolean);
/*     */   
/*     */   public abstract AccessLog getAccessLog();
/*     */   
/*     */   public abstract int getStartStopThreads();
/*     */   
/*     */   public abstract void setStartStopThreads(int paramInt);
/*     */   
/*     */   public abstract File getCatalinaBase();
/*     */   
/*     */   public abstract File getCatalinaHome();
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\Container.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */