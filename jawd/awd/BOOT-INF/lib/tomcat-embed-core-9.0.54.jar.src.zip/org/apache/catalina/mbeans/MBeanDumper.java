/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Set;
/*     */ import java.util.StringJoiner;
/*     */ import javax.management.JMRuntimeException;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.openmbean.CompositeData;
/*     */ import javax.management.openmbean.CompositeType;
/*     */ import javax.management.openmbean.TabularData;
/*     */ import javax.management.openmbean.TabularType;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MBeanDumper
/*     */ {
/*  41 */   private static final Log log = LogFactory.getLog(MBeanDumper.class);
/*  42 */   protected static final StringManager sm = StringManager.getManager(MBeanDumper.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String CRLF = "\r\n";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String dumpBeans(MBeanServer mbeanServer, Set<ObjectName> names)
/*     */   {
/*  55 */     StringBuilder buf = new StringBuilder();
/*  56 */     for (ObjectName oname : names) {
/*  57 */       buf.append("Name: ");
/*  58 */       buf.append(oname.toString());
/*  59 */       buf.append("\r\n");
/*     */       try
/*     */       {
/*  62 */         MBeanInfo minfo = mbeanServer.getMBeanInfo(oname);
/*     */         
/*  64 */         String code = minfo.getClassName();
/*  65 */         if ("org.apache.commons.modeler.BaseModelMBean".equals(code)) {
/*  66 */           code = (String)mbeanServer.getAttribute(oname, "modelerType");
/*     */         }
/*  68 */         buf.append("modelerType: ");
/*  69 */         buf.append(code);
/*  70 */         buf.append("\r\n");
/*     */         
/*  72 */         MBeanAttributeInfo[] attrs = minfo.getAttributes();
/*  73 */         Object value = null;
/*     */         
/*  75 */         for (MBeanAttributeInfo attr : attrs)
/*  76 */           if (attr.isReadable())
/*     */           {
/*     */ 
/*  79 */             String attName = attr.getName();
/*  80 */             if (!"modelerType".equals(attName))
/*     */             {
/*     */ 
/*  83 */               if ((attName.indexOf('=') < 0) && (attName.indexOf(':') < 0) && 
/*  84 */                 (attName.indexOf(' ') < 0))
/*     */               {
/*     */ 
/*     */                 try
/*     */                 {
/*  89 */                   value = mbeanServer.getAttribute(oname, attName);
/*     */                 } catch (JMRuntimeException rme) {
/*  91 */                   Throwable cause = rme.getCause();
/*  92 */                   if ((cause instanceof UnsupportedOperationException)) {
/*  93 */                     if (log.isDebugEnabled()) {
/*  94 */                       log.debug(sm.getString("mBeanDumper.getAttributeError", new Object[] { attName, oname }), rme);
/*     */                     }
/*  96 */                   } else if ((cause instanceof NullPointerException)) {
/*  97 */                     if (log.isDebugEnabled()) {
/*  98 */                       log.debug(sm.getString("mBeanDumper.getAttributeError", new Object[] { attName, oname }), rme);
/*     */                     }
/*     */                   } else {
/* 101 */                     log.error(sm.getString("mBeanDumper.getAttributeError", new Object[] { attName, oname }), rme);
/*     */                   }
/* 103 */                   continue;
/*     */                 } catch (Throwable t) {
/* 105 */                   ExceptionUtils.handleThrowable(t);
/* 106 */                   log.error(sm.getString("mBeanDumper.getAttributeError", new Object[] { attName, oname }), t);
/* 107 */                   continue;
/*     */                 }
/* 109 */                 if (value != null)
/*     */                 {
/*     */                   try
/*     */                   {
/*     */ 
/* 114 */                     Class<?> c = value.getClass();
/* 115 */                     int j; String valueString; String valueString; if (c.isArray()) {
/* 116 */                       int len = Array.getLength(value);
/*     */                       
/* 118 */                       StringBuilder sb = new StringBuilder("Array[" + c.getComponentType().getName() + "] of length " + len);
/* 119 */                       if (len > 0) {
/* 120 */                         sb.append("\r\n");
/*     */                       }
/* 122 */                       for (j = 0; j < len; j++) {
/* 123 */                         Object item = Array.get(value, j);
/* 124 */                         sb.append(tableItemToString(item));
/* 125 */                         if (j < len - 1) {
/* 126 */                           sb.append("\r\n");
/*     */                         }
/*     */                       }
/* 129 */                       valueString = sb.toString(); } else { String valueString;
/* 130 */                       if (TabularData.class.isInstance(value)) {
/* 131 */                         TabularData tab = (TabularData)TabularData.class.cast(value);
/* 132 */                         StringJoiner joiner = new StringJoiner("\r\n");
/* 133 */                         joiner.add("TabularData[" + tab
/* 134 */                           .getTabularType().getRowType().getTypeName() + "] of length " + tab
/* 135 */                           .size());
/* 136 */                         for (Object item : tab.values()) {
/* 137 */                           joiner.add(tableItemToString(item));
/*     */                         }
/* 139 */                         valueString = joiner.toString();
/*     */                       } else {
/* 141 */                         valueString = valueToString(value);
/*     */                       } }
/* 143 */                     buf.append(attName);
/* 144 */                     buf.append(": ");
/* 145 */                     buf.append(valueString);
/* 146 */                     buf.append("\r\n");
/*     */                   } catch (Throwable t) {
/* 148 */                     ExceptionUtils.handleThrowable(t);
/*     */                   } }
/*     */               } }
/*     */           }
/* 152 */       } catch (Throwable t) { ExceptionUtils.handleThrowable(t);
/*     */       }
/* 154 */       buf.append("\r\n");
/*     */     }
/* 156 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escape(String value)
/*     */   {
/* 164 */     int idx = value.indexOf('\n');
/* 165 */     if (idx < 0) {
/* 166 */       return value;
/*     */     }
/*     */     
/* 169 */     int prev = 0;
/* 170 */     StringBuilder sb = new StringBuilder();
/* 171 */     while (idx >= 0) {
/* 172 */       appendHead(sb, value, prev, idx);
/* 173 */       sb.append("\\n\n ");
/* 174 */       prev = idx + 1;
/* 175 */       if (idx == value.length() - 1) {
/*     */         break;
/*     */       }
/* 178 */       idx = value.indexOf('\n', idx + 1);
/*     */     }
/* 180 */     if (prev < value.length()) {
/* 181 */       appendHead(sb, value, prev, value.length());
/*     */     }
/* 183 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static void appendHead(StringBuilder sb, String value, int start, int end)
/*     */   {
/* 188 */     if (end < 1) {
/* 189 */       return;
/*     */     }
/*     */     
/* 192 */     int pos = start;
/* 193 */     while (end - pos > 78) {
/* 194 */       sb.append(value.substring(pos, pos + 78));
/* 195 */       sb.append("\n ");
/* 196 */       pos += 78;
/*     */     }
/* 198 */     sb.append(value.substring(pos, end));
/*     */   }
/*     */   
/*     */   private static String tableItemToString(Object item)
/*     */   {
/* 203 */     if (item == null) {
/* 204 */       return "\tNULL VALUE";
/*     */     }
/*     */     try {
/* 207 */       return "\t" + valueToString(item);
/*     */     } catch (Throwable t) {
/* 209 */       ExceptionUtils.handleThrowable(t); }
/* 210 */     return "\tNON-STRINGABLE VALUE";
/*     */   }
/*     */   
/*     */ 
/*     */   private static String valueToString(Object value)
/*     */   {
/*     */     String valueString;
/*     */     String valueString;
/* 218 */     if (CompositeData.class.isInstance(value)) {
/* 219 */       StringBuilder sb = new StringBuilder("{");
/* 220 */       String sep = "";
/* 221 */       CompositeData composite = (CompositeData)CompositeData.class.cast(value);
/* 222 */       Set<String> keys = composite.getCompositeType().keySet();
/* 223 */       for (String key : keys) {
/* 224 */         sb.append(sep).append(key).append('=').append(composite.get(key));
/* 225 */         sep = ", ";
/*     */       }
/* 227 */       sb.append('}');
/* 228 */       valueString = sb.toString();
/*     */     } else {
/* 230 */       valueString = value.toString();
/*     */     }
/* 232 */     return escape(valueString);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\MBeanDumper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */