/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QuotedStringTokenizer
/*     */ {
/*  28 */   protected static final StringManager sm = StringManager.getManager(QuotedStringTokenizer.class);
/*     */   
/*     */   private Iterator<String> tokenIterator;
/*     */   private int tokenCount;
/*  32 */   private int returnedTokens = 0;
/*     */   
/*     */   static enum WordMode {
/*  35 */     SPACES,  QUOTED,  ESCAPED,  SIMPLE,  COMMENT;
/*     */     
/*     */     private WordMode() {} }
/*     */   
/*     */   public QuotedStringTokenizer(String text) { List<String> tokens;
/*  40 */     List<String> tokens; if (text != null) {
/*  41 */       tokens = tokenizeText(text);
/*     */     } else {
/*  43 */       tokens = Collections.emptyList();
/*     */     }
/*  45 */     this.tokenCount = tokens.size();
/*  46 */     this.tokenIterator = tokens.iterator();
/*     */   }
/*     */   
/*     */   private List<String> tokenizeText(String inputText) {
/*  50 */     List<String> tokens = new ArrayList();
/*  51 */     int pos = 0;
/*  52 */     int length = inputText.length();
/*  53 */     WordMode currentMode = WordMode.SPACES;
/*  54 */     StringBuilder currentToken = new StringBuilder();
/*  55 */     while (pos < length) {
/*  56 */       char currentChar = inputText.charAt(pos);
/*  57 */       switch (currentMode) {
/*     */       case SPACES: 
/*  59 */         currentMode = handleSpaces(currentToken, currentChar);
/*  60 */         break;
/*     */       case QUOTED: 
/*  62 */         currentMode = handleQuoted(tokens, currentToken, currentChar);
/*  63 */         break;
/*     */       case ESCAPED: 
/*  65 */         currentToken.append(currentChar);
/*  66 */         currentMode = WordMode.QUOTED;
/*  67 */         break;
/*     */       case SIMPLE: 
/*  69 */         currentMode = handleSimple(tokens, currentToken, currentChar);
/*  70 */         break;
/*     */       case COMMENT: 
/*  72 */         if ((currentChar == '\r') || (currentChar == '\n')) {
/*  73 */           currentMode = WordMode.SPACES;
/*     */         }
/*     */         break;
/*     */       default: 
/*  77 */         throw new IllegalStateException(sm.getString("quotedStringTokenizer.tokenizeError", new Object[] { inputText, 
/*  78 */           Integer.valueOf(pos), currentMode }));
/*     */       }
/*  80 */       pos++;
/*     */     }
/*  82 */     String possibleLastToken = currentToken.toString();
/*  83 */     if (!possibleLastToken.isEmpty()) {
/*  84 */       tokens.add(possibleLastToken);
/*     */     }
/*  86 */     return tokens;
/*     */   }
/*     */   
/*     */   private WordMode handleSimple(List<String> tokens, StringBuilder currentToken, char currentChar) {
/*  90 */     if (Character.isWhitespace(currentChar)) {
/*  91 */       tokens.add(currentToken.toString());
/*  92 */       currentToken.setLength(0);
/*  93 */       return WordMode.SPACES;
/*     */     }
/*  95 */     currentToken.append(currentChar);
/*     */     
/*  97 */     return WordMode.SIMPLE;
/*     */   }
/*     */   
/*     */   private WordMode handleQuoted(List<String> tokens, StringBuilder currentToken, char currentChar) {
/* 101 */     if (currentChar == '"') {
/* 102 */       tokens.add(currentToken.toString());
/* 103 */       currentToken.setLength(0);
/* 104 */       return WordMode.SPACES; }
/* 105 */     if (currentChar == '\\') {
/* 106 */       return WordMode.ESCAPED;
/*     */     }
/* 108 */     currentToken.append(currentChar);
/*     */     
/* 110 */     return WordMode.QUOTED;
/*     */   }
/*     */   
/*     */   private WordMode handleSpaces(StringBuilder currentToken, char currentChar) {
/* 114 */     if (!Character.isWhitespace(currentChar)) {
/* 115 */       if (currentChar == '"')
/* 116 */         return WordMode.QUOTED;
/* 117 */       if (currentChar == '#') {
/* 118 */         return WordMode.COMMENT;
/*     */       }
/* 120 */       currentToken.append(currentChar);
/* 121 */       return WordMode.SIMPLE;
/*     */     }
/*     */     
/* 124 */     return WordMode.SPACES;
/*     */   }
/*     */   
/*     */   public boolean hasMoreTokens() {
/* 128 */     return this.tokenIterator.hasNext();
/*     */   }
/*     */   
/*     */   public String nextToken() {
/* 132 */     this.returnedTokens += 1;
/* 133 */     return (String)this.tokenIterator.next();
/*     */   }
/*     */   
/*     */   public int countTokens() {
/* 137 */     return this.tokenCount - this.returnedTokens;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\rewrite\QuotedStringTokenizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */