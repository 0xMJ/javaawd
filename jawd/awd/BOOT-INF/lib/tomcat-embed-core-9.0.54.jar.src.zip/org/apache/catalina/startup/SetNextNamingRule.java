/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*     */ import org.apache.tomcat.util.IntrospectionUtils;
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.digester.Rule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetNextNamingRule
/*     */   extends Rule
/*     */ {
/*     */   protected final String methodName;
/*     */   protected final String paramType;
/*     */   
/*     */   public SetNextNamingRule(String methodName, String paramType)
/*     */   {
/*  54 */     this.methodName = methodName;
/*  55 */     this.paramType = paramType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void end(String namespace, String name)
/*     */     throws Exception
/*     */   {
/*  91 */     Object child = this.digester.peek(0);
/*  92 */     Object parent = this.digester.peek(1);
/*  93 */     boolean context = false;
/*     */     
/*  95 */     NamingResourcesImpl namingResources = null;
/*  96 */     if ((parent instanceof Context)) {
/*  97 */       namingResources = ((Context)parent).getNamingResources();
/*  98 */       context = true;
/*     */     } else {
/* 100 */       namingResources = (NamingResourcesImpl)parent;
/*     */     }
/*     */     
/*     */ 
/* 104 */     IntrospectionUtils.callMethod1(namingResources, this.methodName, child, this.paramType, this.digester
/* 105 */       .getClassLoader());
/*     */     
/* 107 */     StringBuilder code = this.digester.getGeneratedCode();
/* 108 */     if (code != null) {
/* 109 */       if (context) {
/* 110 */         code.append(this.digester.toVariableName(parent)).append(".getNamingResources()");
/*     */       } else {
/* 112 */         code.append(this.digester.toVariableName(namingResources));
/*     */       }
/* 114 */       code.append(".").append(this.methodName).append('(');
/* 115 */       code.append(this.digester.toVariableName(child)).append(");");
/* 116 */       code.append(System.lineSeparator());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 126 */     StringBuilder sb = new StringBuilder("SetNextRule[");
/* 127 */     sb.append("methodName=");
/* 128 */     sb.append(this.methodName);
/* 129 */     sb.append(", paramType=");
/* 130 */     sb.append(this.paramType);
/* 131 */     sb.append(']');
/* 132 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\SetNextNamingRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */