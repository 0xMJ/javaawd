/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorPageSupport
/*     */ {
/*  33 */   private Map<String, ErrorPage> exceptionPages = new ConcurrentHashMap();
/*     */   
/*     */ 
/*  36 */   private Map<Integer, ErrorPage> statusPages = new ConcurrentHashMap();
/*     */   
/*     */   public void add(ErrorPage errorPage)
/*     */   {
/*  40 */     String exceptionType = errorPage.getExceptionType();
/*  41 */     if (exceptionType == null) {
/*  42 */       this.statusPages.put(Integer.valueOf(errorPage.getErrorCode()), errorPage);
/*     */     } else {
/*  44 */       this.exceptionPages.put(exceptionType, errorPage);
/*     */     }
/*     */   }
/*     */   
/*     */   public void remove(ErrorPage errorPage)
/*     */   {
/*  50 */     String exceptionType = errorPage.getExceptionType();
/*  51 */     if (exceptionType == null) {
/*  52 */       this.statusPages.remove(Integer.valueOf(errorPage.getErrorCode()), errorPage);
/*     */     } else {
/*  54 */       this.exceptionPages.remove(exceptionType, errorPage);
/*     */     }
/*     */   }
/*     */   
/*     */   public ErrorPage find(int statusCode)
/*     */   {
/*  60 */     return (ErrorPage)this.statusPages.get(Integer.valueOf(statusCode));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ErrorPage find(String exceptionType)
/*     */   {
/*  73 */     return (ErrorPage)this.exceptionPages.get(exceptionType);
/*     */   }
/*     */   
/*     */   public ErrorPage find(Throwable exceptionType)
/*     */   {
/*  78 */     if (exceptionType == null) {
/*  79 */       return null;
/*     */     }
/*  81 */     Class<?> clazz = exceptionType.getClass();
/*  82 */     String name = clazz.getName();
/*  83 */     while (!Object.class.equals(clazz)) {
/*  84 */       ErrorPage errorPage = (ErrorPage)this.exceptionPages.get(name);
/*  85 */       if (errorPage != null) {
/*  86 */         return errorPage;
/*     */       }
/*  88 */       clazz = clazz.getSuperclass();
/*  89 */       if (clazz == null) {
/*     */         break;
/*     */       }
/*  92 */       name = clazz.getName();
/*     */     }
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   public ErrorPage[] findAll()
/*     */   {
/*  99 */     Set<ErrorPage> errorPages = new HashSet();
/* 100 */     errorPages.addAll(this.exceptionPages.values());
/* 101 */     errorPages.addAll(this.statusPages.values());
/* 102 */     return (ErrorPage[])errorPages.toArray(new ErrorPage[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\ErrorPageSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */