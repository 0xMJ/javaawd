/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Set;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.digester.ObjectCreateRule;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListenerCreateRule
/*     */   extends ObjectCreateRule
/*     */ {
/*  37 */   private static final Log log = LogFactory.getLog(ListenerCreateRule.class);
/*  38 */   protected static final StringManager sm = StringManager.getManager(ListenerCreateRule.class);
/*     */   
/*     */   public ListenerCreateRule(String className, String attributeName) {
/*  41 */     super(className, attributeName);
/*     */   }
/*     */   
/*     */   public void begin(String namespace, String name, Attributes attributes)
/*     */     throws Exception
/*     */   {
/*  47 */     if ("true".equals(attributes.getValue("optional"))) {
/*     */       try {
/*  49 */         super.begin(namespace, name, attributes);
/*     */       } catch (Exception e) {
/*  51 */         String className = getRealClassName(attributes);
/*  52 */         if (log.isDebugEnabled()) {
/*  53 */           log.info(sm.getString("listener.createFailed", new Object[] { className }), e);
/*     */         } else {
/*  55 */           log.info(sm.getString("listener.createFailed", new Object[] { className }));
/*     */         }
/*  57 */         Object instance = new OptionalListener(className);
/*  58 */         this.digester.push(instance);
/*  59 */         StringBuilder code = this.digester.getGeneratedCode();
/*  60 */         if (code != null) {
/*  61 */           code.append(OptionalListener.class.getName().replace('$', '.')).append(' ');
/*  62 */           code.append(this.digester.toVariableName(instance)).append(" = new ");
/*  63 */           code.append(OptionalListener.class.getName().replace('$', '.')).append("(\"").append(className).append("\");");
/*  64 */           code.append(System.lineSeparator());
/*     */         }
/*     */       }
/*     */     } else {
/*  68 */       super.begin(namespace, name, attributes);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class OptionalListener implements LifecycleListener {
/*     */     protected final String className;
/*  74 */     protected final HashMap<String, String> properties = new HashMap();
/*     */     
/*  76 */     public OptionalListener(String className) { this.className = className; }
/*     */     
/*     */ 
/*     */ 
/*     */     public String getClassName()
/*     */     {
/*  82 */       return this.className;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void lifecycleEvent(LifecycleEvent event) {}
/*     */     
/*     */ 
/*     */ 
/*     */     public Set<String> getProperties()
/*     */     {
/*  93 */       return this.properties.keySet();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getProperty(String name)
/*     */     {
/* 102 */       return this.properties.get(name);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean setProperty(String name, String value)
/*     */     {
/* 112 */       this.properties.put(name, value);
/* 113 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\ListenerCreateRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */