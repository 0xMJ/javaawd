/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Enumeration;
/*     */ import java.util.EventListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterRegistration;
/*     */ import javax.servlet.FilterRegistration.Dynamic;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRegistration;
/*     */ import javax.servlet.ServletRegistration.Dynamic;
/*     */ import javax.servlet.SessionCookieConfig;
/*     */ import javax.servlet.SessionTrackingMode;
/*     */ import javax.servlet.descriptor.JspConfigDescriptor;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationContextFacade
/*     */   implements ServletContext
/*     */ {
/*     */   private final Map<String, Class<?>[]> classCache;
/*     */   private final Map<String, Method> objectCache;
/*     */   private final ApplicationContext context;
/*     */   
/*     */   public ApplicationContextFacade(ApplicationContext context)
/*     */   {
/*  84 */     this.context = context;
/*     */     
/*  86 */     this.classCache = new HashMap();
/*  87 */     this.objectCache = new ConcurrentHashMap();
/*  88 */     initClassCache();
/*     */   }
/*     */   
/*     */   private void initClassCache()
/*     */   {
/*  93 */     Class<?>[] clazz = { String.class };
/*  94 */     this.classCache.put("getContext", clazz);
/*  95 */     this.classCache.put("getMimeType", clazz);
/*  96 */     this.classCache.put("getResourcePaths", clazz);
/*  97 */     this.classCache.put("getResource", clazz);
/*  98 */     this.classCache.put("getResourceAsStream", clazz);
/*  99 */     this.classCache.put("getRequestDispatcher", clazz);
/* 100 */     this.classCache.put("getNamedDispatcher", clazz);
/* 101 */     this.classCache.put("getServlet", clazz);
/* 102 */     this.classCache.put("setInitParameter", new Class[] { String.class, String.class });
/* 103 */     this.classCache.put("createServlet", new Class[] { Class.class });
/* 104 */     this.classCache.put("addServlet", new Class[] { String.class, String.class });
/* 105 */     this.classCache.put("createFilter", new Class[] { Class.class });
/* 106 */     this.classCache.put("addFilter", new Class[] { String.class, String.class });
/* 107 */     this.classCache.put("createListener", new Class[] { Class.class });
/* 108 */     this.classCache.put("addListener", clazz);
/* 109 */     this.classCache.put("getFilterRegistration", clazz);
/* 110 */     this.classCache.put("getServletRegistration", clazz);
/* 111 */     this.classCache.put("getInitParameter", clazz);
/* 112 */     this.classCache.put("setAttribute", new Class[] { String.class, Object.class });
/* 113 */     this.classCache.put("removeAttribute", clazz);
/* 114 */     this.classCache.put("getRealPath", clazz);
/* 115 */     this.classCache.put("getAttribute", clazz);
/* 116 */     this.classCache.put("log", clazz);
/* 117 */     this.classCache.put("setSessionTrackingModes", new Class[] { Set.class });
/* 118 */     this.classCache.put("addJspFile", new Class[] { String.class, String.class });
/* 119 */     this.classCache.put("declareRoles", new Class[] { String[].class });
/* 120 */     this.classCache.put("setSessionTimeout", new Class[] { Integer.TYPE });
/* 121 */     this.classCache.put("setRequestCharacterEncoding", new Class[] { String.class });
/* 122 */     this.classCache.put("setResponseCharacterEncoding", new Class[] { String.class });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletContext getContext(String uripath)
/*     */   {
/* 140 */     ServletContext theContext = null;
/* 141 */     if (SecurityUtil.isPackageProtectionEnabled())
/*     */     {
/* 143 */       theContext = (ServletContext)doPrivileged("getContext", new Object[] { uripath });
/*     */     } else {
/* 145 */       theContext = this.context.getContext(uripath);
/*     */     }
/* 147 */     if ((theContext != null) && ((theContext instanceof ApplicationContext)))
/*     */     {
/* 149 */       theContext = ((ApplicationContext)theContext).getFacade();
/*     */     }
/* 151 */     return theContext;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getMajorVersion()
/*     */   {
/* 157 */     return this.context.getMajorVersion();
/*     */   }
/*     */   
/*     */ 
/*     */   public int getMinorVersion()
/*     */   {
/* 163 */     return this.context.getMinorVersion();
/*     */   }
/*     */   
/*     */ 
/*     */   public String getMimeType(String file)
/*     */   {
/* 169 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 170 */       return (String)doPrivileged("getMimeType", new Object[] { file });
/*     */     }
/* 172 */     return this.context.getMimeType(file);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<String> getResourcePaths(String path)
/*     */   {
/* 179 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 180 */       return (Set)doPrivileged("getResourcePaths", new Object[] { path });
/*     */     }
/*     */     
/* 183 */     return this.context.getResourcePaths(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public URL getResource(String path)
/*     */     throws MalformedURLException
/*     */   {
/* 191 */     if (Globals.IS_SECURITY_ENABLED) {
/*     */       try {
/* 193 */         return (URL)invokeMethod(this.context, "getResource", new Object[] { path });
/*     */       }
/*     */       catch (Throwable t) {
/* 196 */         ExceptionUtils.handleThrowable(t);
/* 197 */         if ((t instanceof MalformedURLException)) {
/* 198 */           throw ((MalformedURLException)t);
/*     */         }
/* 200 */         return null;
/*     */       }
/*     */     }
/* 203 */     return this.context.getResource(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public InputStream getResourceAsStream(String path)
/*     */   {
/* 210 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 211 */       return (InputStream)doPrivileged("getResourceAsStream", new Object[] { path });
/*     */     }
/*     */     
/* 214 */     return this.context.getResourceAsStream(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RequestDispatcher getRequestDispatcher(String path)
/*     */   {
/* 221 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 222 */       return (RequestDispatcher)doPrivileged("getRequestDispatcher", new Object[] { path });
/*     */     }
/*     */     
/* 225 */     return this.context.getRequestDispatcher(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RequestDispatcher getNamedDispatcher(String name)
/*     */   {
/* 232 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 233 */       return (RequestDispatcher)doPrivileged("getNamedDispatcher", new Object[] { name });
/*     */     }
/*     */     
/* 236 */     return this.context.getNamedDispatcher(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Servlet getServlet(String name)
/*     */     throws ServletException
/*     */   {
/* 248 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 250 */         return (Servlet)invokeMethod(this.context, "getServlet", new Object[] { name });
/*     */       }
/*     */       catch (Throwable t) {
/* 253 */         ExceptionUtils.handleThrowable(t);
/* 254 */         if ((t instanceof ServletException)) {
/* 255 */           throw ((ServletException)t);
/*     */         }
/* 257 */         return null;
/*     */       }
/*     */     }
/* 260 */     return this.context.getServlet(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Enumeration<Servlet> getServlets()
/*     */   {
/* 272 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 273 */       return (Enumeration)doPrivileged("getServlets", null);
/*     */     }
/* 275 */     return this.context.getServlets();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Enumeration<String> getServletNames()
/*     */   {
/* 287 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 288 */       return (Enumeration)doPrivileged("getServletNames", null);
/*     */     }
/* 290 */     return this.context.getServletNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void log(String msg)
/*     */   {
/* 297 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 298 */       doPrivileged("log", new Object[] { msg });
/*     */     } else {
/* 300 */       this.context.log(msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void log(Exception exception, String msg)
/*     */   {
/* 312 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 313 */       doPrivileged("log", new Class[] { Exception.class, String.class }, new Object[] { exception, msg });
/*     */     }
/*     */     else {
/* 316 */       this.context.log(exception, msg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void log(String message, Throwable throwable)
/*     */   {
/* 323 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 324 */       doPrivileged("log", new Class[] { String.class, Throwable.class }, new Object[] { message, throwable });
/*     */     }
/*     */     else {
/* 327 */       this.context.log(message, throwable);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getRealPath(String path)
/*     */   {
/* 334 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 335 */       return (String)doPrivileged("getRealPath", new Object[] { path });
/*     */     }
/* 337 */     return this.context.getRealPath(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getServerInfo()
/*     */   {
/* 344 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 345 */       return (String)doPrivileged("getServerInfo", null);
/*     */     }
/* 347 */     return this.context.getServerInfo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getInitParameter(String name)
/*     */   {
/* 354 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 355 */       return (String)doPrivileged("getInitParameter", new Object[] { name });
/*     */     }
/*     */     
/* 358 */     return this.context.getInitParameter(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getInitParameterNames()
/*     */   {
/* 366 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 367 */       return (Enumeration)doPrivileged("getInitParameterNames", null);
/*     */     }
/*     */     
/* 370 */     return this.context.getInitParameterNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getAttribute(String name)
/*     */   {
/* 377 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 378 */       return doPrivileged("getAttribute", new Object[] { name });
/*     */     }
/* 380 */     return this.context.getAttribute(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getAttributeNames()
/*     */   {
/* 388 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 389 */       return (Enumeration)doPrivileged("getAttributeNames", null);
/*     */     }
/*     */     
/* 392 */     return this.context.getAttributeNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAttribute(String name, Object object)
/*     */   {
/* 399 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 400 */       doPrivileged("setAttribute", new Object[] { name, object });
/*     */     } else {
/* 402 */       this.context.setAttribute(name, object);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeAttribute(String name)
/*     */   {
/* 409 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 410 */       doPrivileged("removeAttribute", new Object[] { name });
/*     */     } else {
/* 412 */       this.context.removeAttribute(name);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getServletContextName()
/*     */   {
/* 419 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 420 */       return (String)doPrivileged("getServletContextName", null);
/*     */     }
/* 422 */     return this.context.getServletContextName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getContextPath()
/*     */   {
/* 429 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 430 */       return (String)doPrivileged("getContextPath", null);
/*     */     }
/* 432 */     return this.context.getContextPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilterRegistration.Dynamic addFilter(String filterName, String className)
/*     */   {
/* 440 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 441 */       return (FilterRegistration.Dynamic)doPrivileged("addFilter", new Object[] { filterName, className });
/*     */     }
/*     */     
/* 444 */     return this.context.addFilter(filterName, className);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilterRegistration.Dynamic addFilter(String filterName, Filter filter)
/*     */   {
/* 452 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 453 */       return (FilterRegistration.Dynamic)doPrivileged("addFilter", new Class[] { String.class, Filter.class }, new Object[] { filterName, filter });
/*     */     }
/*     */     
/*     */ 
/* 457 */     return this.context.addFilter(filterName, filter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilterRegistration.Dynamic addFilter(String filterName, Class<? extends Filter> filterClass)
/*     */   {
/* 465 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 466 */       return (FilterRegistration.Dynamic)doPrivileged("addFilter", new Class[] { String.class, Class.class }, new Object[] { filterName, filterClass });
/*     */     }
/*     */     
/*     */ 
/* 470 */     return this.context.addFilter(filterName, filterClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <T extends Filter> T createFilter(Class<T> c)
/*     */     throws ServletException
/*     */   {
/* 478 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 480 */         return (Filter)invokeMethod(this.context, "createFilter", new Object[] { c });
/*     */       }
/*     */       catch (Throwable t) {
/* 483 */         ExceptionUtils.handleThrowable(t);
/* 484 */         if ((t instanceof ServletException)) {
/* 485 */           throw ((ServletException)t);
/*     */         }
/* 487 */         return null;
/*     */       }
/*     */     }
/* 490 */     return this.context.createFilter(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public FilterRegistration getFilterRegistration(String filterName)
/*     */   {
/* 497 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 498 */       return (FilterRegistration)doPrivileged("getFilterRegistration", new Object[] { filterName });
/*     */     }
/*     */     
/* 501 */     return this.context.getFilterRegistration(filterName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletRegistration.Dynamic addServlet(String servletName, String className)
/*     */   {
/* 509 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 510 */       return (ServletRegistration.Dynamic)doPrivileged("addServlet", new Object[] { servletName, className });
/*     */     }
/*     */     
/* 513 */     return this.context.addServlet(servletName, className);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletRegistration.Dynamic addServlet(String servletName, Servlet servlet)
/*     */   {
/* 521 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 522 */       return (ServletRegistration.Dynamic)doPrivileged("addServlet", new Class[] { String.class, Servlet.class }, new Object[] { servletName, servlet });
/*     */     }
/*     */     
/*     */ 
/* 526 */     return this.context.addServlet(servletName, servlet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletRegistration.Dynamic addServlet(String servletName, Class<? extends Servlet> servletClass)
/*     */   {
/* 534 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 535 */       return (ServletRegistration.Dynamic)doPrivileged("addServlet", new Class[] { String.class, Class.class }, new Object[] { servletName, servletClass });
/*     */     }
/*     */     
/*     */ 
/* 539 */     return this.context.addServlet(servletName, servletClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ServletRegistration.Dynamic addJspFile(String jspName, String jspFile)
/*     */   {
/* 546 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 547 */       return (ServletRegistration.Dynamic)doPrivileged("addJspFile", new Object[] { jspName, jspFile });
/*     */     }
/*     */     
/* 550 */     return this.context.addJspFile(jspName, jspFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Servlet> T createServlet(Class<T> c)
/*     */     throws ServletException
/*     */   {
/* 559 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 561 */         return (Servlet)invokeMethod(this.context, "createServlet", new Object[] { c });
/*     */       }
/*     */       catch (Throwable t) {
/* 564 */         ExceptionUtils.handleThrowable(t);
/* 565 */         if ((t instanceof ServletException)) {
/* 566 */           throw ((ServletException)t);
/*     */         }
/* 568 */         return null;
/*     */       }
/*     */     }
/* 571 */     return this.context.createServlet(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ServletRegistration getServletRegistration(String servletName)
/*     */   {
/* 578 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 579 */       return (ServletRegistration)doPrivileged("getServletRegistration", new Object[] { servletName });
/*     */     }
/*     */     
/* 582 */     return this.context.getServletRegistration(servletName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<SessionTrackingMode> getDefaultSessionTrackingModes()
/*     */   {
/* 590 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 591 */       return 
/* 592 */         (Set)doPrivileged("getDefaultSessionTrackingModes", null);
/*     */     }
/* 594 */     return this.context.getDefaultSessionTrackingModes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<SessionTrackingMode> getEffectiveSessionTrackingModes()
/*     */   {
/* 601 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 602 */       return 
/* 603 */         (Set)doPrivileged("getEffectiveSessionTrackingModes", null);
/*     */     }
/* 605 */     return this.context.getEffectiveSessionTrackingModes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SessionCookieConfig getSessionCookieConfig()
/*     */   {
/* 612 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 613 */       return 
/* 614 */         (SessionCookieConfig)doPrivileged("getSessionCookieConfig", null);
/*     */     }
/* 616 */     return this.context.getSessionCookieConfig();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSessionTrackingModes(Set<SessionTrackingMode> sessionTrackingModes)
/*     */   {
/* 624 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 625 */       doPrivileged("setSessionTrackingModes", new Object[] { sessionTrackingModes });
/*     */     }
/*     */     else {
/* 628 */       this.context.setSessionTrackingModes(sessionTrackingModes);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean setInitParameter(String name, String value)
/*     */   {
/* 635 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 636 */       return 
/* 637 */         ((Boolean)doPrivileged("setInitParameter", new Object[] { name, value })).booleanValue();
/*     */     }
/* 639 */     return this.context.setInitParameter(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addListener(Class<? extends EventListener> listenerClass)
/*     */   {
/* 646 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 647 */       doPrivileged("addListener", new Class[] { Class.class }, new Object[] { listenerClass });
/*     */     }
/*     */     else
/*     */     {
/* 651 */       this.context.addListener(listenerClass);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void addListener(String className)
/*     */   {
/* 658 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 659 */       doPrivileged("addListener", new Object[] { className });
/*     */     }
/*     */     else {
/* 662 */       this.context.addListener(className);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends EventListener> void addListener(T t)
/*     */   {
/* 669 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 670 */       doPrivileged("addListener", new Class[] { EventListener.class }, new Object[] { t });
/*     */     }
/*     */     else
/*     */     {
/* 674 */       this.context.addListener(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <T extends EventListener> T createListener(Class<T> c)
/*     */     throws ServletException
/*     */   {
/* 683 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 685 */         return (EventListener)invokeMethod(this.context, "createListener", new Object[] { c });
/*     */       }
/*     */       catch (Throwable t) {
/* 688 */         ExceptionUtils.handleThrowable(t);
/* 689 */         if ((t instanceof ServletException)) {
/* 690 */           throw ((ServletException)t);
/*     */         }
/* 692 */         return null;
/*     */       }
/*     */     }
/* 695 */     return this.context.createListener(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void declareRoles(String... roleNames)
/*     */   {
/* 702 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 703 */       doPrivileged("declareRoles", new Object[] { roleNames });
/*     */     } else {
/* 705 */       this.context.declareRoles(roleNames);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ClassLoader getClassLoader()
/*     */   {
/* 712 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 713 */       return (ClassLoader)doPrivileged("getClassLoader", null);
/*     */     }
/* 715 */     return this.context.getClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEffectiveMajorVersion()
/*     */   {
/* 722 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 723 */       return 
/* 724 */         ((Integer)doPrivileged("getEffectiveMajorVersion", null)).intValue();
/*     */     }
/* 726 */     return this.context.getEffectiveMajorVersion();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEffectiveMinorVersion()
/*     */   {
/* 733 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 734 */       return 
/* 735 */         ((Integer)doPrivileged("getEffectiveMinorVersion", null)).intValue();
/*     */     }
/* 737 */     return this.context.getEffectiveMinorVersion();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, ? extends FilterRegistration> getFilterRegistrations()
/*     */   {
/* 745 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 746 */       return (Map)doPrivileged("getFilterRegistrations", null);
/*     */     }
/*     */     
/* 749 */     return this.context.getFilterRegistrations();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JspConfigDescriptor getJspConfigDescriptor()
/*     */   {
/* 756 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 757 */       return (JspConfigDescriptor)doPrivileged("getJspConfigDescriptor", null);
/*     */     }
/*     */     
/* 760 */     return this.context.getJspConfigDescriptor();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, ? extends ServletRegistration> getServletRegistrations()
/*     */   {
/* 768 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 769 */       return (Map)doPrivileged("getServletRegistrations", null);
/*     */     }
/*     */     
/* 772 */     return this.context.getServletRegistrations();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getVirtualServerName()
/*     */   {
/* 779 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 780 */       return (String)doPrivileged("getVirtualServerName", null);
/*     */     }
/* 782 */     return this.context.getVirtualServerName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getSessionTimeout()
/*     */   {
/* 789 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 790 */       return ((Integer)doPrivileged("getSessionTimeout", null)).intValue();
/*     */     }
/* 792 */     return this.context.getSessionTimeout();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSessionTimeout(int sessionTimeout)
/*     */   {
/* 799 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 800 */       doPrivileged("setSessionTimeout", new Object[] { Integer.valueOf(sessionTimeout) });
/*     */     } else {
/* 802 */       this.context.setSessionTimeout(sessionTimeout);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getRequestCharacterEncoding()
/*     */   {
/* 809 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 810 */       return (String)doPrivileged("getRequestCharacterEncoding", null);
/*     */     }
/* 812 */     return this.context.getRequestCharacterEncoding();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRequestCharacterEncoding(String encoding)
/*     */   {
/* 819 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 820 */       doPrivileged("setRequestCharacterEncoding", new Object[] { encoding });
/*     */     } else {
/* 822 */       this.context.setRequestCharacterEncoding(encoding);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getResponseCharacterEncoding()
/*     */   {
/* 829 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 830 */       return (String)doPrivileged("getResponseCharacterEncoding", null);
/*     */     }
/* 832 */     return this.context.getResponseCharacterEncoding();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setResponseCharacterEncoding(String encoding)
/*     */   {
/* 839 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 840 */       doPrivileged("setResponseCharacterEncoding", new Object[] { encoding });
/*     */     } else {
/* 842 */       this.context.setResponseCharacterEncoding(encoding);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object doPrivileged(String methodName, Object[] params)
/*     */   {
/*     */     try
/*     */     {
/* 855 */       return invokeMethod(this.context, methodName, params);
/*     */     } catch (Throwable t) {
/* 857 */       ExceptionUtils.handleThrowable(t);
/* 858 */       throw new RuntimeException(t.getMessage(), t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object invokeMethod(ApplicationContext appContext, String methodName, Object[] params)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 877 */       Method method = (Method)this.objectCache.get(methodName);
/* 878 */       if (method == null)
/*     */       {
/* 880 */         method = appContext.getClass().getMethod(methodName, (Class[])this.classCache.get(methodName));
/* 881 */         this.objectCache.put(methodName, method);
/*     */       }
/*     */       
/* 884 */       return executeMethod(method, appContext, params);
/*     */     } catch (Exception ex) { Object localObject1;
/* 886 */       handleException(ex);
/* 887 */       return null;
/*     */     } finally {
/* 889 */       params = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object doPrivileged(String methodName, Class<?>[] clazz, Object[] params)
/*     */   {
/*     */     try
/*     */     {
/* 905 */       Method method = this.context.getClass().getMethod(methodName, clazz);
/* 906 */       return executeMethod(method, this.context, params);
/*     */     } catch (Exception ex) {
/*     */       try {
/* 909 */         handleException(ex);
/*     */       } catch (Throwable t) {
/* 911 */         ExceptionUtils.handleThrowable(t);
/* 912 */         throw new RuntimeException(t.getMessage());
/*     */       }
/* 914 */       return null;
/*     */     } finally {
/* 916 */       params = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object executeMethod(Method method, ApplicationContext context, Object[] params)
/*     */     throws PrivilegedActionException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 935 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 936 */       return AccessController.doPrivileged(new PrivilegedExecuteMethod(method, context, params));
/*     */     }
/*     */     
/* 939 */     return method.invoke(context, params);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void handleException(Exception ex)
/*     */     throws Throwable
/*     */   {
/* 954 */     if ((ex instanceof PrivilegedActionException)) {
/* 955 */       ex = ((PrivilegedActionException)ex).getException();
/*     */     }
/*     */     Throwable realException;
/* 958 */     if ((ex instanceof InvocationTargetException)) {
/* 959 */       Throwable realException = ex.getCause();
/* 960 */       if (realException == null) {
/* 961 */         realException = ex;
/*     */       }
/*     */     } else {
/* 964 */       realException = ex;
/*     */     }
/*     */     
/* 967 */     throw realException;
/*     */   }
/*     */   
/*     */   private static class PrivilegedExecuteMethod implements PrivilegedExceptionAction<Object>
/*     */   {
/*     */     private final Method method;
/*     */     private final ApplicationContext context;
/*     */     private final Object[] params;
/*     */     
/*     */     public PrivilegedExecuteMethod(Method method, ApplicationContext context, Object[] params)
/*     */     {
/* 978 */       this.method = method;
/* 979 */       this.context = context;
/* 980 */       this.params = params;
/*     */     }
/*     */     
/*     */     public Object run() throws Exception
/*     */     {
/* 985 */       return this.method.invoke(this.context, this.params);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\ApplicationContextFacade.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */