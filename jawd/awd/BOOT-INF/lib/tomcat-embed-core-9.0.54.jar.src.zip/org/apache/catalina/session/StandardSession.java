/*      */ package org.apache.catalina.session;
/*      */ 
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.IOException;
/*      */ import java.io.NotSerializableException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.ObjectStreamException;
/*      */ import java.io.Serializable;
/*      */ import java.io.WriteAbortedException;
/*      */ import java.security.AccessController;
/*      */ import java.security.Principal;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.http.HttpSession;
/*      */ import javax.servlet.http.HttpSessionActivationListener;
/*      */ import javax.servlet.http.HttpSessionAttributeListener;
/*      */ import javax.servlet.http.HttpSessionBindingEvent;
/*      */ import javax.servlet.http.HttpSessionBindingListener;
/*      */ import javax.servlet.http.HttpSessionContext;
/*      */ import javax.servlet.http.HttpSessionEvent;
/*      */ import javax.servlet.http.HttpSessionIdListener;
/*      */ import javax.servlet.http.HttpSessionListener;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.SessionEvent;
/*      */ import org.apache.catalina.SessionListener;
/*      */ import org.apache.catalina.TomcatPrincipal;
/*      */ import org.apache.catalina.security.SecurityUtil;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StandardSession
/*      */   implements HttpSession, Session, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   94 */   protected static final boolean STRICT_SERVLET_COMPLIANCE = Globals.STRICT_SERVLET_COMPLIANCE;
/*      */   
/*   96 */   static { String activityCheck = System.getProperty("org.apache.catalina.session.StandardSession.ACTIVITY_CHECK");
/*      */     
/*   98 */     if (activityCheck == null) {
/*   99 */       ACTIVITY_CHECK = STRICT_SERVLET_COMPLIANCE;
/*      */     } else {
/*  101 */       ACTIVITY_CHECK = Boolean.parseBoolean(activityCheck);
/*      */     }
/*      */     
/*  104 */     String lastAccessAtStart = System.getProperty("org.apache.catalina.session.StandardSession.LAST_ACCESS_AT_START");
/*      */     
/*  106 */     if (lastAccessAtStart == null) {
/*  107 */       LAST_ACCESS_AT_START = STRICT_SERVLET_COMPLIANCE;
/*      */     } else {
/*  109 */       LAST_ACCESS_AT_START = Boolean.parseBoolean(lastAccessAtStart);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final boolean ACTIVITY_CHECK;
/*      */   
/*      */ 
/*      */ 
/*      */   protected static final boolean LAST_ACCESS_AT_START;
/*      */   
/*      */ 
/*      */   public StandardSession(Manager manager)
/*      */   {
/*  125 */     this.manager = manager;
/*      */     
/*      */ 
/*  128 */     if (ACTIVITY_CHECK) {
/*  129 */       this.accessCount = new AtomicInteger();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  141 */   protected static final String[] EMPTY_ARRAY = new String[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  147 */   protected ConcurrentMap<String, Object> attributes = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  155 */   protected transient String authType = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  162 */   protected long creationTime = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  170 */   protected volatile transient boolean expiring = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  177 */   protected transient StandardSessionFacade facade = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  183 */   protected String id = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  189 */   protected volatile long lastAccessedTime = this.creationTime;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  195 */   protected transient ArrayList<SessionListener> listeners = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  201 */   protected transient Manager manager = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  209 */   protected volatile int maxInactiveInterval = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  215 */   protected volatile boolean isNew = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  221 */   protected volatile boolean isValid = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  229 */   protected transient Map<String, Object> notes = new Hashtable();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  237 */   protected transient Principal principal = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  243 */   protected static final StringManager sm = StringManager.getManager(StandardSession.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  251 */   protected static volatile HttpSessionContext sessionContext = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  258 */   protected final transient PropertyChangeSupport support = new PropertyChangeSupport(this);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  265 */   protected volatile long thisAccessedTime = this.creationTime;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  271 */   protected transient AtomicInteger accessCount = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAuthType()
/*      */   {
/*  283 */     return this.authType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAuthType(String authType)
/*      */   {
/*  295 */     String oldAuthType = this.authType;
/*  296 */     this.authType = authType;
/*  297 */     this.support.firePropertyChange("authType", oldAuthType, this.authType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCreationTime(long time)
/*      */   {
/*  310 */     this.creationTime = time;
/*  311 */     this.lastAccessedTime = time;
/*  312 */     this.thisAccessedTime = time;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getId()
/*      */   {
/*  322 */     return this.id;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getIdInternal()
/*      */   {
/*  331 */     return this.id;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setId(String id)
/*      */   {
/*  342 */     setId(id, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setId(String id, boolean notify)
/*      */   {
/*  352 */     if ((this.id != null) && (this.manager != null)) {
/*  353 */       this.manager.remove(this);
/*      */     }
/*      */     
/*  356 */     this.id = id;
/*      */     
/*  358 */     if (this.manager != null) {
/*  359 */       this.manager.add(this);
/*      */     }
/*      */     
/*  362 */     if (notify) {
/*  363 */       tellNew();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void tellNew()
/*      */   {
/*  375 */     fireSessionEvent("createSession", null);
/*      */     
/*      */ 
/*  378 */     Context context = this.manager.getContext();
/*  379 */     Object[] listeners = context.getApplicationLifecycleListeners();
/*  380 */     if ((listeners != null) && (listeners.length > 0))
/*      */     {
/*  382 */       HttpSessionEvent event = new HttpSessionEvent(getSession());
/*  383 */       for (Object o : listeners) {
/*  384 */         if ((o instanceof HttpSessionListener))
/*      */         {
/*      */ 
/*  387 */           HttpSessionListener listener = (HttpSessionListener)o;
/*      */           try {
/*  389 */             context.fireContainerEvent("beforeSessionCreated", listener);
/*  390 */             listener.sessionCreated(event);
/*  391 */             context.fireContainerEvent("afterSessionCreated", listener);
/*      */           } catch (Throwable t) {
/*  393 */             ExceptionUtils.handleThrowable(t);
/*      */             try {
/*  395 */               context.fireContainerEvent("afterSessionCreated", listener);
/*      */             }
/*      */             catch (Exception localException) {}
/*      */             
/*  399 */             this.manager.getContext().getLogger().error(sm.getString("standardSession.sessionEvent"), t);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void tellChangedSessionId(String newId, String oldId, boolean notifySessionListeners, boolean notifyContainerListeners)
/*      */   {
/*  419 */     Context context = this.manager.getContext();
/*      */     
/*  421 */     if (notifyContainerListeners) {
/*  422 */       context.fireContainerEvent("changeSessionId", new String[] { oldId, newId });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  427 */     if (notifySessionListeners) {
/*  428 */       Object[] listeners = context.getApplicationEventListeners();
/*  429 */       if ((listeners != null) && (listeners.length > 0))
/*      */       {
/*  431 */         HttpSessionEvent event = new HttpSessionEvent(getSession());
/*      */         
/*  433 */         for (Object listener : listeners) {
/*  434 */           if ((listener instanceof HttpSessionIdListener))
/*      */           {
/*      */ 
/*      */ 
/*  438 */             HttpSessionIdListener idListener = (HttpSessionIdListener)listener;
/*      */             try
/*      */             {
/*  441 */               idListener.sessionIdChanged(event, oldId);
/*      */             }
/*      */             catch (Throwable t) {
/*  444 */               this.manager.getContext().getLogger().error(sm.getString("standardSession.sessionEvent"), t);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getThisAccessedTime()
/*      */   {
/*  462 */     if (!isValidInternal())
/*      */     {
/*  464 */       throw new IllegalStateException(sm.getString("standardSession.getThisAccessedTime.ise"));
/*      */     }
/*      */     
/*  467 */     return this.thisAccessedTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getThisAccessedTimeInternal()
/*      */   {
/*  476 */     return this.thisAccessedTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLastAccessedTime()
/*      */   {
/*  489 */     if (!isValidInternal())
/*      */     {
/*  491 */       throw new IllegalStateException(sm.getString("standardSession.getLastAccessedTime.ise"));
/*      */     }
/*      */     
/*  494 */     return this.lastAccessedTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLastAccessedTimeInternal()
/*      */   {
/*  503 */     return this.lastAccessedTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getIdleTime()
/*      */   {
/*  512 */     if (!isValidInternal())
/*      */     {
/*  514 */       throw new IllegalStateException(sm.getString("standardSession.getIdleTime.ise"));
/*      */     }
/*      */     
/*  517 */     return getIdleTimeInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getIdleTimeInternal()
/*      */   {
/*  526 */     long timeNow = System.currentTimeMillis();
/*      */     long timeIdle;
/*  528 */     long timeIdle; if (LAST_ACCESS_AT_START) {
/*  529 */       timeIdle = timeNow - this.lastAccessedTime;
/*      */     } else {
/*  531 */       timeIdle = timeNow - this.thisAccessedTime;
/*      */     }
/*  533 */     return timeIdle;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Manager getManager()
/*      */   {
/*  541 */     return this.manager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setManager(Manager manager)
/*      */   {
/*  552 */     this.manager = manager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxInactiveInterval()
/*      */   {
/*  563 */     return this.maxInactiveInterval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxInactiveInterval(int interval)
/*      */   {
/*  576 */     this.maxInactiveInterval = interval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNew(boolean isNew)
/*      */   {
/*  587 */     this.isNew = isNew;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal getPrincipal()
/*      */   {
/*  600 */     return this.principal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPrincipal(Principal principal)
/*      */   {
/*  615 */     Principal oldPrincipal = this.principal;
/*  616 */     this.principal = principal;
/*  617 */     this.support.firePropertyChange("principal", oldPrincipal, this.principal);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpSession getSession()
/*      */   {
/*  628 */     if (this.facade == null) {
/*  629 */       if (SecurityUtil.isPackageProtectionEnabled()) {
/*  630 */         this.facade = ((StandardSessionFacade)AccessController.doPrivileged(new PrivilegedNewSessionFacade(this)));
/*      */       } else {
/*  632 */         this.facade = new StandardSessionFacade(this);
/*      */       }
/*      */     }
/*  635 */     return this.facade;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isValid()
/*      */   {
/*  645 */     if (!this.isValid) {
/*  646 */       return false;
/*      */     }
/*      */     
/*  649 */     if (this.expiring) {
/*  650 */       return true;
/*      */     }
/*      */     
/*  653 */     if ((ACTIVITY_CHECK) && (this.accessCount.get() > 0)) {
/*  654 */       return true;
/*      */     }
/*      */     
/*  657 */     if (this.maxInactiveInterval > 0) {
/*  658 */       int timeIdle = (int)(getIdleTimeInternal() / 1000L);
/*  659 */       if (timeIdle >= this.maxInactiveInterval) {
/*  660 */         expire(true);
/*      */       }
/*      */     }
/*      */     
/*  664 */     return this.isValid;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValid(boolean isValid)
/*      */   {
/*  675 */     this.isValid = isValid;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void access()
/*      */   {
/*  690 */     this.thisAccessedTime = System.currentTimeMillis();
/*      */     
/*  692 */     if (ACTIVITY_CHECK) {
/*  693 */       this.accessCount.incrementAndGet();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void endAccess()
/*      */   {
/*  705 */     this.isNew = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  711 */     if (LAST_ACCESS_AT_START) {
/*  712 */       this.lastAccessedTime = this.thisAccessedTime;
/*  713 */       this.thisAccessedTime = System.currentTimeMillis();
/*      */     } else {
/*  715 */       this.thisAccessedTime = System.currentTimeMillis();
/*  716 */       this.lastAccessedTime = this.thisAccessedTime;
/*      */     }
/*      */     
/*  719 */     if (ACTIVITY_CHECK) {
/*  720 */       this.accessCount.decrementAndGet();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSessionListener(SessionListener listener)
/*      */   {
/*  732 */     this.listeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void expire()
/*      */   {
/*  744 */     expire(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void expire(boolean notify)
/*      */   {
/*  761 */     if (!this.isValid) {
/*  762 */       return;
/*      */     }
/*      */     
/*  765 */     synchronized (this)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  770 */       if ((this.expiring) || (!this.isValid)) {
/*  771 */         return;
/*      */       }
/*      */       
/*  774 */       if (this.manager == null) {
/*  775 */         return;
/*      */       }
/*      */       
/*      */ 
/*  779 */       this.expiring = true;
/*      */       
/*      */ 
/*      */ 
/*  783 */       Context context = this.manager.getContext();
/*      */       
/*      */       HttpSessionEvent event;
/*      */       int i;
/*      */       int j;
/*  788 */       if (notify) {
/*  789 */         ClassLoader oldContextClassLoader = null;
/*      */         try {
/*  791 */           oldContextClassLoader = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*  792 */           Object[] listeners = context.getApplicationLifecycleListeners();
/*  793 */           if ((listeners != null) && (listeners.length > 0))
/*      */           {
/*  795 */             event = new HttpSessionEvent(getSession());
/*  796 */             for (i = 0; i < listeners.length; i++) {
/*  797 */               j = listeners.length - 1 - i;
/*  798 */               if ((listeners[j] instanceof HttpSessionListener))
/*      */               {
/*      */ 
/*  801 */                 HttpSessionListener listener = (HttpSessionListener)listeners[j];
/*      */                 try
/*      */                 {
/*  804 */                   context.fireContainerEvent("beforeSessionDestroyed", listener);
/*      */                   
/*  806 */                   listener.sessionDestroyed(event);
/*  807 */                   context.fireContainerEvent("afterSessionDestroyed", listener);
/*      */                 }
/*      */                 catch (Throwable t) {
/*  810 */                   ExceptionUtils.handleThrowable(t);
/*      */                   try {
/*  812 */                     context.fireContainerEvent("afterSessionDestroyed", listener);
/*      */                   }
/*      */                   catch (Exception localException1) {}
/*      */                   
/*      */ 
/*      */ 
/*  818 */                   this.manager.getContext().getLogger().error(sm.getString("standardSession.sessionEvent"), t);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*  823 */         } finally { context.unbind(Globals.IS_SECURITY_ENABLED, oldContextClassLoader);
/*      */         }
/*      */       }
/*      */       
/*  827 */       if (ACTIVITY_CHECK) {
/*  828 */         this.accessCount.set(0);
/*      */       }
/*      */       
/*      */ 
/*  832 */       this.manager.remove(this, true);
/*      */       
/*      */ 
/*  835 */       if (notify) {
/*  836 */         fireSessionEvent("destroySession", null);
/*      */       }
/*      */       
/*      */ 
/*  840 */       if ((this.principal instanceof TomcatPrincipal)) {
/*  841 */         TomcatPrincipal gp = (TomcatPrincipal)this.principal;
/*      */         try {
/*  843 */           gp.logout();
/*      */         } catch (Exception e) {
/*  845 */           this.manager.getContext().getLogger().error(sm
/*  846 */             .getString("standardSession.logoutfail"), e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  852 */       setValid(false);
/*  853 */       this.expiring = false;
/*      */       
/*      */ 
/*  856 */       String[] keys = keys();
/*  857 */       ClassLoader oldContextClassLoader = null;
/*      */       try {
/*  859 */         oldContextClassLoader = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*  860 */         for (String key : keys) {
/*  861 */           removeAttributeInternal(key, notify);
/*      */         }
/*      */       } finally {
/*  864 */         context.unbind(Globals.IS_SECURITY_ENABLED, oldContextClassLoader);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void passivate()
/*      */   {
/*  878 */     fireSessionEvent("passivateSession", null);
/*      */     
/*      */ 
/*  881 */     HttpSessionEvent event = null;
/*  882 */     String[] keys = keys();
/*  883 */     for (String key : keys) {
/*  884 */       Object attribute = this.attributes.get(key);
/*  885 */       if ((attribute instanceof HttpSessionActivationListener)) {
/*  886 */         if (event == null) {
/*  887 */           event = new HttpSessionEvent(getSession());
/*      */         }
/*      */         try {
/*  890 */           ((HttpSessionActivationListener)attribute).sessionWillPassivate(event);
/*      */         } catch (Throwable t) {
/*  892 */           ExceptionUtils.handleThrowable(t);
/*  893 */           this.manager.getContext().getLogger().error(sm.getString("standardSession.attributeEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void activate()
/*      */   {
/*  908 */     if (ACTIVITY_CHECK) {
/*  909 */       this.accessCount = new AtomicInteger();
/*      */     }
/*      */     
/*      */ 
/*  913 */     fireSessionEvent("activateSession", null);
/*      */     
/*      */ 
/*  916 */     HttpSessionEvent event = null;
/*  917 */     String[] keys = keys();
/*  918 */     for (String key : keys) {
/*  919 */       Object attribute = this.attributes.get(key);
/*  920 */       if ((attribute instanceof HttpSessionActivationListener)) {
/*  921 */         if (event == null) {
/*  922 */           event = new HttpSessionEvent(getSession());
/*      */         }
/*      */         try {
/*  925 */           ((HttpSessionActivationListener)attribute).sessionDidActivate(event);
/*      */         } catch (Throwable t) {
/*  927 */           ExceptionUtils.handleThrowable(t);
/*  928 */           this.manager.getContext().getLogger().error(sm.getString("standardSession.attributeEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getNote(String name)
/*      */   {
/*  943 */     return this.notes.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Iterator<String> getNoteNames()
/*      */   {
/*  953 */     return this.notes.keySet().iterator();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void recycle()
/*      */   {
/*  965 */     this.attributes.clear();
/*  966 */     setAuthType(null);
/*  967 */     this.creationTime = 0L;
/*  968 */     this.expiring = false;
/*  969 */     this.id = null;
/*  970 */     this.lastAccessedTime = 0L;
/*  971 */     this.maxInactiveInterval = -1;
/*  972 */     this.notes.clear();
/*  973 */     setPrincipal(null);
/*  974 */     this.isNew = false;
/*  975 */     this.isValid = false;
/*  976 */     this.manager = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeNote(String name)
/*      */   {
/*  990 */     this.notes.remove(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSessionListener(SessionListener listener)
/*      */   {
/* 1001 */     this.listeners.remove(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNote(String name, Object value)
/*      */   {
/* 1016 */     this.notes.put(name, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1026 */     StringBuilder sb = new StringBuilder();
/* 1027 */     sb.append("StandardSession[");
/* 1028 */     sb.append(this.id);
/* 1029 */     sb.append(']');
/* 1030 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readObjectData(ObjectInputStream stream)
/*      */     throws ClassNotFoundException, IOException
/*      */   {
/* 1050 */     doReadObject(stream);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeObjectData(ObjectOutputStream stream)
/*      */     throws IOException
/*      */   {
/* 1067 */     doWriteObject(stream);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getCreationTime()
/*      */   {
/* 1084 */     if (!isValidInternal())
/*      */     {
/* 1086 */       throw new IllegalStateException(sm.getString("standardSession.getCreationTime.ise"));
/*      */     }
/*      */     
/* 1089 */     return this.creationTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getCreationTimeInternal()
/*      */   {
/* 1099 */     return this.creationTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletContext getServletContext()
/*      */   {
/* 1108 */     if (this.manager == null) {
/* 1109 */       return null;
/*      */     }
/* 1111 */     Context context = this.manager.getContext();
/* 1112 */     return context.getServletContext();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public HttpSessionContext getSessionContext()
/*      */   {
/* 1126 */     if (sessionContext == null) {
/* 1127 */       sessionContext = new StandardSessionContext();
/*      */     }
/* 1129 */     return sessionContext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getAttribute(String name)
/*      */   {
/* 1147 */     if (!isValidInternal())
/*      */     {
/* 1149 */       throw new IllegalStateException(sm.getString("standardSession.getAttribute.ise"));
/*      */     }
/*      */     
/* 1152 */     if (name == null) {
/* 1153 */       return null;
/*      */     }
/*      */     
/* 1156 */     return this.attributes.get(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<String> getAttributeNames()
/*      */   {
/* 1170 */     if (!isValidInternal())
/*      */     {
/* 1172 */       throw new IllegalStateException(sm.getString("standardSession.getAttributeNames.ise"));
/*      */     }
/*      */     
/* 1175 */     Set<String> names = new HashSet(this.attributes.keySet());
/* 1176 */     return Collections.enumeration(names);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public Object getValue(String name)
/*      */   {
/* 1196 */     return getAttribute(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String[] getValueNames()
/*      */   {
/* 1214 */     if (!isValidInternal())
/*      */     {
/* 1216 */       throw new IllegalStateException(sm.getString("standardSession.getValueNames.ise"));
/*      */     }
/*      */     
/* 1219 */     return keys();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void invalidate()
/*      */   {
/* 1232 */     if (!isValidInternal())
/*      */     {
/* 1234 */       throw new IllegalStateException(sm.getString("standardSession.invalidate.ise"));
/*      */     }
/*      */     
/*      */ 
/* 1238 */     expire();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isNew()
/*      */   {
/* 1255 */     if (!isValidInternal())
/*      */     {
/* 1257 */       throw new IllegalStateException(sm.getString("standardSession.isNew.ise"));
/*      */     }
/*      */     
/* 1260 */     return this.isNew;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void putValue(String name, Object value)
/*      */   {
/* 1286 */     setAttribute(name, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAttribute(String name)
/*      */   {
/* 1308 */     removeAttribute(name, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAttribute(String name, boolean notify)
/*      */   {
/* 1332 */     if (!isValidInternal())
/*      */     {
/* 1334 */       throw new IllegalStateException(sm.getString("standardSession.removeAttribute.ise"));
/*      */     }
/*      */     
/* 1337 */     removeAttributeInternal(name, notify);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void removeValue(String name)
/*      */   {
/* 1363 */     removeAttribute(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAttribute(String name, Object value)
/*      */   {
/* 1387 */     setAttribute(name, value, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAttribute(String name, Object value, boolean notify)
/*      */   {
/* 1411 */     if (name == null)
/*      */     {
/* 1413 */       throw new IllegalArgumentException(sm.getString("standardSession.setAttribute.namenull"));
/*      */     }
/*      */     
/*      */ 
/* 1417 */     if (value == null) {
/* 1418 */       removeAttribute(name);
/* 1419 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1423 */     if (!isValidInternal())
/*      */     {
/* 1425 */       throw new IllegalStateException(sm.getString("standardSession.setAttribute.ise", new Object[] {getIdInternal() }));
/*      */     }
/*      */     
/* 1428 */     Context context = this.manager.getContext();
/*      */     
/* 1430 */     if ((context.getDistributable()) && (!isAttributeDistributable(name, value)) && (!exclude(name, value))) {
/* 1431 */       throw new IllegalArgumentException(sm.getString("standardSession.setAttribute.iae", new Object[] { name }));
/*      */     }
/*      */     
/* 1434 */     HttpSessionBindingEvent event = null;
/*      */     
/*      */ 
/* 1437 */     if ((notify) && ((value instanceof HttpSessionBindingListener)))
/*      */     {
/*      */ 
/* 1440 */       Object oldValue = this.attributes.get(name);
/* 1441 */       if ((value != oldValue) || (this.manager.getNotifyBindingListenerOnUnchangedValue())) {
/* 1442 */         event = new HttpSessionBindingEvent(getSession(), name, value);
/*      */         try {
/* 1444 */           ((HttpSessionBindingListener)value).valueBound(event);
/*      */         } catch (Throwable t) {
/* 1446 */           this.manager.getContext().getLogger().error(sm
/* 1447 */             .getString("standardSession.bindingEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1453 */     Object unbound = this.attributes.put(name, value);
/*      */     
/*      */ 
/* 1456 */     if ((notify) && ((unbound instanceof HttpSessionBindingListener)))
/*      */     {
/*      */ 
/* 1459 */       if ((unbound != value) || (this.manager.getNotifyBindingListenerOnUnchangedValue())) {
/*      */         try
/*      */         {
/* 1462 */           ((HttpSessionBindingListener)unbound).valueUnbound(new HttpSessionBindingEvent(getSession(), name));
/*      */         } catch (Throwable t) {
/* 1464 */           ExceptionUtils.handleThrowable(t);
/* 1465 */           this.manager.getContext().getLogger()
/* 1466 */             .error(sm.getString("standardSession.bindingEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1471 */     if (!notify) {
/* 1472 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1476 */     Object[] listeners = context.getApplicationEventListeners();
/* 1477 */     if (listeners == null) {
/* 1478 */       return;
/*      */     }
/* 1480 */     for (Object o : listeners) {
/* 1481 */       if ((o instanceof HttpSessionAttributeListener))
/*      */       {
/*      */ 
/* 1484 */         HttpSessionAttributeListener listener = (HttpSessionAttributeListener)o;
/*      */         try {
/* 1486 */           if (unbound != null) {
/* 1487 */             if ((unbound != value) || (this.manager.getNotifyAttributeListenerOnUnchangedValue())) {
/* 1488 */               context.fireContainerEvent("beforeSessionAttributeReplaced", listener);
/* 1489 */               if (event == null) {
/* 1490 */                 event = new HttpSessionBindingEvent(getSession(), name, unbound);
/*      */               }
/* 1492 */               listener.attributeReplaced(event);
/* 1493 */               context.fireContainerEvent("afterSessionAttributeReplaced", listener);
/*      */             }
/*      */           } else {
/* 1496 */             context.fireContainerEvent("beforeSessionAttributeAdded", listener);
/* 1497 */             if (event == null) {
/* 1498 */               event = new HttpSessionBindingEvent(getSession(), name, value);
/*      */             }
/* 1500 */             listener.attributeAdded(event);
/* 1501 */             context.fireContainerEvent("afterSessionAttributeAdded", listener);
/*      */           }
/*      */         } catch (Throwable t) {
/* 1504 */           ExceptionUtils.handleThrowable(t);
/*      */           try {
/* 1506 */             if (unbound != null) {
/* 1507 */               if ((unbound != value) || 
/* 1508 */                 (this.manager.getNotifyAttributeListenerOnUnchangedValue())) {
/* 1509 */                 context.fireContainerEvent("afterSessionAttributeReplaced", listener);
/*      */               }
/*      */             } else {
/* 1512 */               context.fireContainerEvent("afterSessionAttributeAdded", listener);
/*      */             }
/*      */           }
/*      */           catch (Exception localException) {}
/*      */           
/* 1517 */           this.manager.getContext().getLogger().error(sm
/* 1518 */             .getString("standardSession.attributeEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isValidInternal()
/*      */   {
/* 1531 */     return this.isValid;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAttributeDistributable(String name, Object value)
/*      */   {
/* 1543 */     return value instanceof Serializable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doReadObject(ObjectInputStream stream)
/*      */     throws ClassNotFoundException, IOException
/*      */   {
/* 1563 */     this.authType = null;
/* 1564 */     this.creationTime = ((Long)stream.readObject()).longValue();
/* 1565 */     this.lastAccessedTime = ((Long)stream.readObject()).longValue();
/* 1566 */     this.maxInactiveInterval = ((Integer)stream.readObject()).intValue();
/* 1567 */     this.isNew = ((Boolean)stream.readObject()).booleanValue();
/* 1568 */     this.isValid = ((Boolean)stream.readObject()).booleanValue();
/* 1569 */     this.thisAccessedTime = ((Long)stream.readObject()).longValue();
/* 1570 */     this.principal = null;
/*      */     
/* 1572 */     this.id = ((String)stream.readObject());
/* 1573 */     if (this.manager.getContext().getLogger().isDebugEnabled())
/*      */     {
/* 1575 */       this.manager.getContext().getLogger().debug("readObject() loading session " + this.id);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1580 */     Object nextObject = stream.readObject();
/* 1581 */     if (!(nextObject instanceof Integer)) {
/* 1582 */       setAuthType((String)nextObject);
/*      */       try {
/* 1584 */         setPrincipal((Principal)stream.readObject());
/*      */       } catch (ClassNotFoundException|ObjectStreamException e) {
/* 1586 */         String msg = sm.getString("standardSession.principalNotDeserializable", new Object[] { this.id });
/* 1587 */         if (this.manager.getContext().getLogger().isDebugEnabled()) {
/* 1588 */           this.manager.getContext().getLogger().debug(msg, e);
/*      */         } else {
/* 1590 */           this.manager.getContext().getLogger().warn(msg);
/*      */         }
/* 1592 */         throw e;
/*      */       }
/*      */       
/* 1595 */       nextObject = stream.readObject();
/*      */     }
/*      */     
/*      */ 
/* 1599 */     if (this.attributes == null) {
/* 1600 */       this.attributes = new ConcurrentHashMap();
/*      */     }
/* 1602 */     int n = ((Integer)nextObject).intValue();
/* 1603 */     boolean isValidSave = this.isValid;
/* 1604 */     this.isValid = true;
/* 1605 */     for (int i = 0; i < n; i++) {
/* 1606 */       String name = (String)stream.readObject();
/*      */       try
/*      */       {
/* 1609 */         value = stream.readObject();
/*      */       } catch (WriteAbortedException wae) { Object value;
/* 1611 */         if ((wae.getCause() instanceof NotSerializableException)) {
/* 1612 */           String msg = sm.getString("standardSession.notDeserializable", new Object[] { name, this.id });
/* 1613 */           if (this.manager.getContext().getLogger().isDebugEnabled()) {
/* 1614 */             this.manager.getContext().getLogger().debug(msg, wae);
/*      */           } else {
/* 1616 */             this.manager.getContext().getLogger().warn(msg);
/*      */           }
/*      */           
/* 1619 */           continue;
/*      */         }
/* 1621 */         throw wae; }
/*      */       Object value;
/* 1623 */       if (this.manager.getContext().getLogger().isDebugEnabled()) {
/* 1624 */         this.manager.getContext().getLogger().debug("  loading attribute '" + name + "' with value '" + value + "'");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1629 */       if (!exclude(name, value))
/*      */       {
/*      */ 
/*      */ 
/* 1633 */         if (null != value)
/* 1634 */           this.attributes.put(name, value);
/*      */       }
/*      */     }
/* 1637 */     this.isValid = isValidSave;
/*      */     
/* 1639 */     if (this.listeners == null) {
/* 1640 */       this.listeners = new ArrayList();
/*      */     }
/*      */     
/* 1643 */     if (this.notes == null) {
/* 1644 */       this.notes = new Hashtable();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doWriteObject(ObjectOutputStream stream)
/*      */     throws IOException
/*      */   {
/* 1671 */     stream.writeObject(Long.valueOf(this.creationTime));
/* 1672 */     stream.writeObject(Long.valueOf(this.lastAccessedTime));
/* 1673 */     stream.writeObject(Integer.valueOf(this.maxInactiveInterval));
/* 1674 */     stream.writeObject(Boolean.valueOf(this.isNew));
/* 1675 */     stream.writeObject(Boolean.valueOf(this.isValid));
/* 1676 */     stream.writeObject(Long.valueOf(this.thisAccessedTime));
/* 1677 */     stream.writeObject(this.id);
/* 1678 */     if (this.manager.getContext().getLogger().isDebugEnabled())
/*      */     {
/* 1680 */       this.manager.getContext().getLogger().debug("writeObject() storing session " + this.id);
/*      */     }
/*      */     
/*      */ 
/* 1684 */     String sessionAuthType = null;
/* 1685 */     Principal sessionPrincipal = null;
/* 1686 */     if (getPersistAuthentication()) {
/* 1687 */       sessionAuthType = getAuthType();
/* 1688 */       sessionPrincipal = getPrincipal();
/* 1689 */       if (!(sessionPrincipal instanceof Serializable)) {
/* 1690 */         sessionPrincipal = null;
/* 1691 */         this.manager.getContext().getLogger().warn(sm
/* 1692 */           .getString("standardSession.principalNotSerializable", new Object[] { this.id }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1697 */     stream.writeObject(sessionAuthType);
/*      */     try {
/* 1699 */       stream.writeObject(sessionPrincipal);
/*      */     } catch (NotSerializableException e) {
/* 1701 */       this.manager.getContext().getLogger().warn(sm
/* 1702 */         .getString("standardSession.principalNotSerializable", new Object[] { this.id }), e);
/*      */     }
/*      */     
/*      */ 
/* 1706 */     String[] keys = keys();
/* 1707 */     List<String> saveNames = new ArrayList();
/* 1708 */     List<Object> saveValues = new ArrayList();
/* 1709 */     for (String key : keys) {
/* 1710 */       Object value = this.attributes.get(key);
/* 1711 */       if (value != null)
/*      */       {
/* 1713 */         if ((isAttributeDistributable(key, value)) && (!exclude(key, value))) {
/* 1714 */           saveNames.add(key);
/* 1715 */           saveValues.add(value);
/*      */         } else {
/* 1717 */           removeAttributeInternal(key, true);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1722 */     int n = saveNames.size();
/* 1723 */     stream.writeObject(Integer.valueOf(n));
/* 1724 */     for (int i = 0; i < n; i++) {
/* 1725 */       stream.writeObject(saveNames.get(i));
/*      */       try {
/* 1727 */         stream.writeObject(saveValues.get(i));
/* 1728 */         if (this.manager.getContext().getLogger().isDebugEnabled()) {
/* 1729 */           this.manager.getContext().getLogger().debug("  storing attribute '" + 
/* 1730 */             (String)saveNames.get(i) + "' with value '" + saveValues.get(i) + "'");
/*      */         }
/*      */       } catch (NotSerializableException e) {
/* 1733 */         this.manager.getContext().getLogger().warn(sm
/* 1734 */           .getString("standardSession.notSerializable", new Object[] {saveNames.get(i), this.id }), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean getPersistAuthentication()
/*      */   {
/* 1747 */     if ((this.manager instanceof ManagerBase)) {
/* 1748 */       return ((ManagerBase)this.manager).getPersistAuthentication();
/*      */     }
/* 1750 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean exclude(String name, Object value)
/*      */   {
/* 1772 */     if (Constants.excludedAttributeNames.contains(name)) {
/* 1773 */       return true;
/*      */     }
/*      */     
/*      */ 
/* 1777 */     Manager manager = getManager();
/* 1778 */     if (manager == null)
/*      */     {
/*      */ 
/* 1781 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1785 */     return !manager.willAttributeDistribute(name, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fireSessionEvent(String type, Object data)
/*      */   {
/* 1800 */     if (this.listeners.size() < 1) {
/* 1801 */       return;
/*      */     }
/* 1803 */     SessionEvent event = new SessionEvent(this, type, data);
/* 1804 */     SessionListener[] list = new SessionListener[0];
/* 1805 */     synchronized (this.listeners) {
/* 1806 */       list = (SessionListener[])this.listeners.toArray(list);
/*      */     }
/*      */     
/* 1809 */     for (SessionListener sessionListener : list) {
/* 1810 */       sessionListener.sessionEvent(event);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String[] keys()
/*      */   {
/* 1823 */     return (String[])this.attributes.keySet().toArray(EMPTY_ARRAY);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void removeAttributeInternal(String name, boolean notify)
/*      */   {
/* 1844 */     if (name == null) {
/* 1845 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1849 */     Object value = this.attributes.remove(name);
/*      */     
/*      */ 
/* 1852 */     if ((!notify) || (value == null)) {
/* 1853 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1857 */     HttpSessionBindingEvent event = null;
/* 1858 */     if ((value instanceof HttpSessionBindingListener)) {
/* 1859 */       event = new HttpSessionBindingEvent(getSession(), name, value);
/* 1860 */       ((HttpSessionBindingListener)value).valueUnbound(event);
/*      */     }
/*      */     
/*      */ 
/* 1864 */     Context context = this.manager.getContext();
/* 1865 */     Object[] listeners = context.getApplicationEventListeners();
/* 1866 */     if (listeners == null) {
/* 1867 */       return;
/*      */     }
/* 1869 */     for (Object o : listeners) {
/* 1870 */       if ((o instanceof HttpSessionAttributeListener))
/*      */       {
/*      */ 
/* 1873 */         HttpSessionAttributeListener listener = (HttpSessionAttributeListener)o;
/*      */         try {
/* 1875 */           context.fireContainerEvent("beforeSessionAttributeRemoved", listener);
/* 1876 */           if (event == null) {
/* 1877 */             event = new HttpSessionBindingEvent(getSession(), name, value);
/*      */           }
/* 1879 */           listener.attributeRemoved(event);
/* 1880 */           context.fireContainerEvent("afterSessionAttributeRemoved", listener);
/*      */         } catch (Throwable t) {
/* 1882 */           ExceptionUtils.handleThrowable(t);
/*      */           try {
/* 1884 */             context.fireContainerEvent("afterSessionAttributeRemoved", listener);
/*      */           }
/*      */           catch (Exception localException) {}
/*      */           
/* 1888 */           this.manager.getContext().getLogger().error(sm.getString("standardSession.attributeEvent"), t);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static class PrivilegedNewSessionFacade implements PrivilegedAction<StandardSessionFacade>
/*      */   {
/*      */     private final HttpSession session;
/*      */     
/*      */     public PrivilegedNewSessionFacade(HttpSession session)
/*      */     {
/* 1900 */       this.session = session;
/*      */     }
/*      */     
/*      */     public StandardSessionFacade run()
/*      */     {
/* 1905 */       return new StandardSessionFacade(this.session);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\session\StandardSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */