/*      */ package org.apache.catalina.users;
/*      */ 
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import javax.sql.DataSource;
/*      */ import org.apache.catalina.Group;
/*      */ import org.apache.catalina.Role;
/*      */ import org.apache.catalina.User;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DataSourceUserDatabase
/*      */   extends SparseUserDatabase
/*      */ {
/*   44 */   private static final Log log = LogFactory.getLog(DataSourceUserDatabase.class);
/*   45 */   private static final StringManager sm = StringManager.getManager(DataSourceUserDatabase.class);
/*      */   protected final DataSource dataSource;
/*      */   
/*   48 */   public DataSourceUserDatabase(DataSource dataSource, String id) { this.dataSource = dataSource;
/*   49 */     this.id = id;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final String id;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   64 */   protected final ConcurrentHashMap<String, User> createdUsers = new ConcurrentHashMap();
/*   65 */   protected final ConcurrentHashMap<String, User> modifiedUsers = new ConcurrentHashMap();
/*   66 */   protected final ConcurrentHashMap<String, User> removedUsers = new ConcurrentHashMap();
/*      */   
/*   68 */   protected final ConcurrentHashMap<String, Group> createdGroups = new ConcurrentHashMap();
/*   69 */   protected final ConcurrentHashMap<String, Group> modifiedGroups = new ConcurrentHashMap();
/*   70 */   protected final ConcurrentHashMap<String, Group> removedGroups = new ConcurrentHashMap();
/*      */   
/*   72 */   protected final ConcurrentHashMap<String, Role> createdRoles = new ConcurrentHashMap();
/*   73 */   protected final ConcurrentHashMap<String, Role> modifiedRoles = new ConcurrentHashMap();
/*   74 */   protected final ConcurrentHashMap<String, Role> removedRoles = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   83 */   private String preparedAllUsers = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   89 */   private String preparedAllGroups = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   95 */   private String preparedAllRoles = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  101 */   private String preparedGroup = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  107 */   private String preparedRole = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  113 */   private String preparedUserRoles = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  119 */   private String preparedUser = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  125 */   private String preparedUserGroups = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  131 */   private String preparedGroupRoles = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  137 */   protected String dataSourceName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  143 */   protected String roleNameCol = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  149 */   protected String roleAndGroupDescriptionCol = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  155 */   protected String groupNameCol = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  161 */   protected String userCredCol = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  167 */   protected String userFullNameCol = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  173 */   protected String userNameCol = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  179 */   protected String userRoleTable = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  185 */   protected String userGroupTable = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  191 */   protected String groupRoleTable = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  197 */   protected String userTable = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  203 */   protected String groupTable = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  209 */   protected String roleTable = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  215 */   private volatile boolean connectionSuccess = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  221 */   protected boolean readonly = true;
/*      */   
/*      */ 
/*  224 */   private final ReentrantReadWriteLock dbLock = new ReentrantReadWriteLock();
/*  225 */   private final Lock readLock = this.dbLock.readLock();
/*  226 */   private final Lock writeLock = this.dbLock.writeLock();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getDataSourceName()
/*      */   {
/*  236 */     return this.dataSourceName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDataSourceName(String dataSourceName)
/*      */   {
/*  245 */     this.dataSourceName = dataSourceName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getRoleNameCol()
/*      */   {
/*  252 */     return this.roleNameCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRoleNameCol(String roleNameCol)
/*      */   {
/*  261 */     this.roleNameCol = roleNameCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getUserCredCol()
/*      */   {
/*  268 */     return this.userCredCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserCredCol(String userCredCol)
/*      */   {
/*  277 */     this.userCredCol = userCredCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getUserNameCol()
/*      */   {
/*  284 */     return this.userNameCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserNameCol(String userNameCol)
/*      */   {
/*  293 */     this.userNameCol = userNameCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getUserRoleTable()
/*      */   {
/*  300 */     return this.userRoleTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserRoleTable(String userRoleTable)
/*      */   {
/*  309 */     this.userRoleTable = userRoleTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getUserTable()
/*      */   {
/*  316 */     return this.userTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserTable(String userTable)
/*      */   {
/*  325 */     this.userTable = userTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRoleAndGroupDescriptionCol()
/*      */   {
/*  333 */     return this.roleAndGroupDescriptionCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRoleAndGroupDescriptionCol(String roleAndGroupDescriptionCol)
/*      */   {
/*  340 */     this.roleAndGroupDescriptionCol = roleAndGroupDescriptionCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getGroupNameCol()
/*      */   {
/*  347 */     return this.groupNameCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGroupNameCol(String groupNameCol)
/*      */   {
/*  354 */     this.groupNameCol = groupNameCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getUserFullNameCol()
/*      */   {
/*  361 */     return this.userFullNameCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUserFullNameCol(String userFullNameCol)
/*      */   {
/*  368 */     this.userFullNameCol = userFullNameCol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getUserGroupTable()
/*      */   {
/*  375 */     return this.userGroupTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUserGroupTable(String userGroupTable)
/*      */   {
/*  382 */     this.userGroupTable = userGroupTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getGroupRoleTable()
/*      */   {
/*  389 */     return this.groupRoleTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGroupRoleTable(String groupRoleTable)
/*      */   {
/*  396 */     this.groupRoleTable = groupRoleTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getGroupTable()
/*      */   {
/*  403 */     return this.groupTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGroupTable(String groupTable)
/*      */   {
/*  410 */     this.groupTable = groupTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getRoleTable()
/*      */   {
/*  417 */     return this.roleTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setRoleTable(String roleTable)
/*      */   {
/*  424 */     this.roleTable = roleTable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getReadonly()
/*      */   {
/*  431 */     return this.readonly;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setReadonly(boolean readonly)
/*      */   {
/*  438 */     this.readonly = readonly;
/*      */   }
/*      */   
/*      */   public String getId()
/*      */   {
/*  443 */     return this.id;
/*      */   }
/*      */   
/*      */   public Iterator<Group> getGroups()
/*      */   {
/*  448 */     this.readLock.lock();
/*      */     try {
/*  450 */       HashMap<String, Group> groups = new HashMap();
/*  451 */       groups.putAll(this.createdGroups);
/*  452 */       groups.putAll(this.modifiedGroups);
/*      */       
/*  454 */       Connection dbConnection = openConnection();
/*  455 */       if ((dbConnection != null) && (this.preparedAllGroups != null)) {
/*  456 */         try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedAllGroups);Throwable localThrowable6 = null;
/*  457 */           try { ResultSet rs = stmt.executeQuery();Throwable localThrowable7 = null;
/*  458 */             try { while (rs.next()) {
/*  459 */                 String groupName = rs.getString(1);
/*  460 */                 if ((groupName != null) && 
/*  461 */                   (!groups.containsKey(groupName)) && (!this.removedGroups.containsKey(groupName))) {
/*  462 */                   Group group = findGroupInternal(dbConnection, groupName);
/*  463 */                   if (group != null) {
/*  464 */                     groups.put(groupName, group);
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */             catch (Throwable localThrowable1)
/*      */             {
/*  457 */               localThrowable7 = localThrowable1;throw localThrowable1;
/*      */             }
/*      */             finally {}
/*      */           }
/*      */           catch (Throwable localThrowable4)
/*      */           {
/*  456 */             localThrowable6 = localThrowable4;throw localThrowable4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  470 */             if (stmt != null) if (localThrowable6 != null) try { stmt.close(); } catch (Throwable localThrowable5) {} else stmt.close();
/*  471 */           } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */         } finally {
/*  473 */           closeConnection(dbConnection);
/*      */         }
/*      */       }
/*  476 */       return groups.values().iterator();
/*      */     } finally {
/*  478 */       this.readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public Iterator<Role> getRoles()
/*      */   {
/*  484 */     this.readLock.lock();
/*      */     try {
/*  486 */       HashMap<String, Role> roles = new HashMap();
/*  487 */       roles.putAll(this.createdRoles);
/*  488 */       roles.putAll(this.modifiedRoles);
/*      */       
/*  490 */       Connection dbConnection = openConnection();
/*  491 */       if ((dbConnection != null) && (this.preparedAllRoles != null)) {
/*  492 */         try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedAllRoles);Throwable localThrowable6 = null;
/*  493 */           try { ResultSet rs = stmt.executeQuery();Throwable localThrowable7 = null;
/*  494 */             try { while (rs.next()) {
/*  495 */                 String roleName = rs.getString(1);
/*  496 */                 if ((roleName != null) && 
/*  497 */                   (!roles.containsKey(roleName)) && (!this.removedRoles.containsKey(roleName))) {
/*  498 */                   Role role = findRoleInternal(dbConnection, roleName);
/*  499 */                   if (role != null) {
/*  500 */                     roles.put(roleName, role);
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */             catch (Throwable localThrowable1)
/*      */             {
/*  493 */               localThrowable7 = localThrowable1;throw localThrowable1;
/*      */             }
/*      */             finally {}
/*      */           }
/*      */           catch (Throwable localThrowable4)
/*      */           {
/*  492 */             localThrowable6 = localThrowable4;throw localThrowable4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  506 */             if (stmt != null) if (localThrowable6 != null) try { stmt.close(); } catch (Throwable localThrowable5) {} else stmt.close();
/*  507 */           } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */         } finally {
/*  509 */           closeConnection(dbConnection);
/*      */         }
/*      */       }
/*  512 */       return roles.values().iterator();
/*      */     } finally {
/*  514 */       this.readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public Iterator<User> getUsers()
/*      */   {
/*  520 */     this.readLock.lock();
/*      */     try {
/*  522 */       HashMap<String, User> users = new HashMap();
/*  523 */       users.putAll(this.createdUsers);
/*  524 */       users.putAll(this.modifiedUsers);
/*      */       
/*  526 */       Connection dbConnection = openConnection();
/*  527 */       if (dbConnection != null) {
/*  528 */         try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedAllUsers);Throwable localThrowable6 = null;
/*  529 */           try { ResultSet rs = stmt.executeQuery();Throwable localThrowable7 = null;
/*  530 */             try { while (rs.next()) {
/*  531 */                 String userName = rs.getString(1);
/*  532 */                 if ((userName != null) && 
/*  533 */                   (!users.containsKey(userName)) && (!this.removedUsers.containsKey(userName))) {
/*  534 */                   User user = findUserInternal(dbConnection, userName);
/*  535 */                   if (user != null) {
/*  536 */                     users.put(userName, user);
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */             catch (Throwable localThrowable1)
/*      */             {
/*  529 */               localThrowable7 = localThrowable1;throw localThrowable1;
/*      */             }
/*      */             finally {}
/*      */           }
/*      */           catch (Throwable localThrowable4)
/*      */           {
/*  528 */             localThrowable6 = localThrowable4;throw localThrowable4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  542 */             if (stmt != null) if (localThrowable6 != null) try { stmt.close(); } catch (Throwable localThrowable5) {} else stmt.close();
/*  543 */           } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */         } finally {
/*  545 */           closeConnection(dbConnection);
/*      */         }
/*      */       }
/*  548 */       return users.values().iterator();
/*      */     } finally {
/*  550 */       this.readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public void close()
/*      */     throws Exception
/*      */   {}
/*      */   
/*      */   public Group createGroup(String groupname, String description)
/*      */   {
/*  560 */     this.readLock.lock();
/*      */     try {
/*  562 */       Group group = new GenericGroup(this, groupname, description, null);
/*  563 */       this.createdGroups.put(groupname, group);
/*  564 */       this.modifiedGroups.remove(groupname);
/*  565 */       return group;
/*      */     } finally {
/*  567 */       this.readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public Role createRole(String rolename, String description)
/*      */   {
/*  573 */     this.readLock.lock();
/*      */     try {
/*  575 */       Role role = new GenericRole(this, rolename, description);
/*  576 */       this.createdRoles.put(rolename, role);
/*  577 */       this.modifiedRoles.remove(rolename);
/*  578 */       return role;
/*      */     } finally {
/*  580 */       this.readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public User createUser(String username, String password, String fullName)
/*      */   {
/*  586 */     this.readLock.lock();
/*      */     try {
/*  588 */       User user = new GenericUser(this, username, password, fullName, null, null);
/*  589 */       this.createdUsers.put(username, user);
/*  590 */       this.modifiedUsers.remove(username);
/*  591 */       return user;
/*      */     } finally {
/*  593 */       this.readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public Group findGroup(String groupname)
/*      */   {
/*  599 */     this.readLock.lock();
/*      */     try
/*      */     {
/*  602 */       Group group = (Group)this.createdGroups.get(groupname);
/*  603 */       Group localGroup1; if (group != null) {
/*  604 */         return group;
/*      */       }
/*  606 */       group = (Group)this.modifiedGroups.get(groupname);
/*  607 */       if (group != null) {
/*  608 */         return group;
/*      */       }
/*  610 */       group = (Group)this.removedGroups.get(groupname);
/*  611 */       if (group != null) {
/*  612 */         return null;
/*      */       }
/*      */       Connection dbConnection;
/*  615 */       if (isGroupStoreDefined()) {
/*  616 */         dbConnection = openConnection();
/*  617 */         Group localGroup2; if (dbConnection == null) {
/*  618 */           return null;
/*      */         }
/*      */         try {
/*  621 */           localGroup2 = findGroupInternal(dbConnection, groupname);
/*      */           
/*  623 */           closeConnection(dbConnection);return localGroup2;
/*      */         } finally {
/*  623 */           closeConnection(dbConnection);
/*      */         }
/*      */       }
/*  626 */       return null;
/*      */     }
/*      */     finally {
/*  629 */       this.readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public Group findGroupInternal(Connection dbConnection, String groupName) {
/*  634 */     Group group = null;
/*  635 */     try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedGroup);Throwable localThrowable12 = null;
/*  636 */       try { stmt.setString(1, groupName);
/*  637 */         ResultSet rs = stmt.executeQuery();Throwable localThrowable13 = null;
/*  638 */         try { if ((rs.next()) && 
/*  639 */             (rs.getString(1) != null)) {
/*  640 */             String description = this.roleAndGroupDescriptionCol != null ? rs.getString(2) : null;
/*  641 */             ArrayList<Role> groupRoles = new ArrayList();
/*  642 */             if (groupName != null) {
/*  643 */               groupName = groupName.trim();
/*  644 */               try { PreparedStatement stmt2 = dbConnection.prepareStatement(this.preparedGroupRoles);Throwable localThrowable14 = null;
/*  645 */                 try { stmt2.setString(1, groupName);
/*  646 */                   ResultSet rs2 = stmt2.executeQuery();Throwable localThrowable15 = null;
/*  647 */                   try { while (rs2.next()) {
/*  648 */                       String roleName = rs2.getString(1);
/*  649 */                       if (roleName != null) {
/*  650 */                         Role groupRole = findRoleInternal(dbConnection, roleName);
/*  651 */                         if (groupRole != null) {
/*  652 */                           groupRoles.add(groupRole);
/*      */                         }
/*      */                       }
/*      */                     }
/*      */                   }
/*      */                   catch (Throwable localThrowable1)
/*      */                   {
/*  646 */                     localThrowable15 = localThrowable1;throw localThrowable1;
/*      */                   }
/*      */                   finally {}
/*      */                 }
/*      */                 catch (Throwable localThrowable4)
/*      */                 {
/*  644 */                   localThrowable14 = localThrowable4;throw localThrowable4;
/*      */ 
/*      */ 
/*      */ 
/*      */                 }
/*      */                 finally {}
/*      */ 
/*      */ 
/*      */ 
/*      */               }
/*      */               catch (SQLException e)
/*      */               {
/*      */ 
/*      */ 
/*  658 */                 log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */               }
/*      */             }
/*  661 */             group = new GenericGroup(this, groupName, description, groupRoles);
/*      */           }
/*      */         }
/*      */         catch (Throwable localThrowable7)
/*      */         {
/*  637 */           localThrowable13 = localThrowable7;throw localThrowable7;
/*      */         }
/*      */         finally {}
/*      */       }
/*      */       catch (Throwable localThrowable10)
/*      */       {
/*  635 */         localThrowable12 = localThrowable10;throw localThrowable10;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  665 */         if (stmt != null) if (localThrowable12 != null) try { stmt.close(); } catch (Throwable localThrowable11) { localThrowable12.addSuppressed(localThrowable11); } else stmt.close();
/*  666 */       } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */     }
/*  668 */     return group;
/*      */   }
/*      */   
/*      */   public Role findRole(String rolename)
/*      */   {
/*  673 */     this.readLock.lock();
/*      */     try
/*      */     {
/*  676 */       Role role = (Role)this.createdRoles.get(rolename);
/*  677 */       Role localRole1; if (role != null) {
/*  678 */         return role;
/*      */       }
/*  680 */       role = (Role)this.modifiedRoles.get(rolename);
/*  681 */       if (role != null) {
/*  682 */         return role;
/*      */       }
/*  684 */       role = (Role)this.removedRoles.get(rolename);
/*  685 */       if (role != null) {
/*  686 */         return null;
/*      */       }
/*      */       Connection dbConnection;
/*  689 */       if ((this.userRoleTable != null) && (this.roleNameCol != null)) {
/*  690 */         dbConnection = openConnection();
/*  691 */         Role localRole2; if (dbConnection == null) {
/*  692 */           return null;
/*      */         }
/*      */         try {
/*  695 */           localRole2 = findRoleInternal(dbConnection, rolename);
/*      */           
/*  697 */           closeConnection(dbConnection);return localRole2;
/*      */         } finally {
/*  697 */           closeConnection(dbConnection);
/*      */         }
/*      */       }
/*  700 */       return null;
/*      */     }
/*      */     finally {
/*  703 */       this.readLock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public Role findRoleInternal(Connection dbConnection, String roleName) {
/*  708 */     Role role = null;
/*  709 */     try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedRole);Throwable localThrowable6 = null;
/*  710 */       try { stmt.setString(1, roleName);
/*  711 */         ResultSet rs = stmt.executeQuery();Throwable localThrowable7 = null;
/*  712 */         try { if ((rs.next()) && 
/*  713 */             (rs.getString(1) != null)) {
/*  714 */             String description = this.roleAndGroupDescriptionCol != null ? rs.getString(2) : null;
/*  715 */             role = new GenericRole(this, roleName, description);
/*      */           }
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/*  711 */           localThrowable7 = localThrowable1;throw localThrowable1;
/*      */         }
/*      */         finally {}
/*      */       }
/*      */       catch (Throwable localThrowable4)
/*      */       {
/*  709 */         localThrowable6 = localThrowable4;throw localThrowable4;
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  719 */         if (stmt != null) if (localThrowable6 != null) try { stmt.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else stmt.close();
/*  720 */       } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */     }
/*  722 */     return role;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public User findUser(String username)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   4: invokeinterface 46 1 0
/*      */     //   9: aload_0
/*      */     //   10: getfield 4	org/apache/catalina/users/DataSourceUserDatabase:createdUsers	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   13: aload_1
/*      */     //   14: invokevirtual 83	java/util/concurrent/ConcurrentHashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   17: checkcast 92	org/apache/catalina/User
/*      */     //   20: astore_2
/*      */     //   21: aload_2
/*      */     //   22: ifnull +16 -> 38
/*      */     //   25: aload_2
/*      */     //   26: astore_3
/*      */     //   27: aload_0
/*      */     //   28: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   31: invokeinterface 72 1 0
/*      */     //   36: aload_3
/*      */     //   37: areturn
/*      */     //   38: aload_0
/*      */     //   39: getfield 5	org/apache/catalina/users/DataSourceUserDatabase:modifiedUsers	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   42: aload_1
/*      */     //   43: invokevirtual 83	java/util/concurrent/ConcurrentHashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   46: checkcast 92	org/apache/catalina/User
/*      */     //   49: astore_2
/*      */     //   50: aload_2
/*      */     //   51: ifnull +16 -> 67
/*      */     //   54: aload_2
/*      */     //   55: astore_3
/*      */     //   56: aload_0
/*      */     //   57: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   60: invokeinterface 72 1 0
/*      */     //   65: aload_3
/*      */     //   66: areturn
/*      */     //   67: aload_0
/*      */     //   68: getfield 6	org/apache/catalina/users/DataSourceUserDatabase:removedUsers	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   71: aload_1
/*      */     //   72: invokevirtual 83	java/util/concurrent/ConcurrentHashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   75: checkcast 92	org/apache/catalina/User
/*      */     //   78: astore_2
/*      */     //   79: aload_2
/*      */     //   80: ifnull +16 -> 96
/*      */     //   83: aconst_null
/*      */     //   84: astore_3
/*      */     //   85: aload_0
/*      */     //   86: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   89: invokeinterface 72 1 0
/*      */     //   94: aload_3
/*      */     //   95: areturn
/*      */     //   96: aload_0
/*      */     //   97: invokevirtual 50	org/apache/catalina/users/DataSourceUserDatabase:openConnection	()Ljava/sql/Connection;
/*      */     //   100: astore_3
/*      */     //   101: aload_3
/*      */     //   102: ifnonnull +18 -> 120
/*      */     //   105: aconst_null
/*      */     //   106: astore 4
/*      */     //   108: aload_0
/*      */     //   109: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   112: invokeinterface 72 1 0
/*      */     //   117: aload 4
/*      */     //   119: areturn
/*      */     //   120: aload_0
/*      */     //   121: aload_3
/*      */     //   122: aload_1
/*      */     //   123: invokevirtual 74	org/apache/catalina/users/DataSourceUserDatabase:findUserInternal	(Ljava/sql/Connection;Ljava/lang/String;)Lorg/apache/catalina/User;
/*      */     //   126: astore 4
/*      */     //   128: aload_0
/*      */     //   129: aload_3
/*      */     //   130: invokevirtual 63	org/apache/catalina/users/DataSourceUserDatabase:closeConnection	(Ljava/sql/Connection;)V
/*      */     //   133: aload_0
/*      */     //   134: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   137: invokeinterface 72 1 0
/*      */     //   142: aload 4
/*      */     //   144: areturn
/*      */     //   145: astore 5
/*      */     //   147: aload_0
/*      */     //   148: aload_3
/*      */     //   149: invokevirtual 63	org/apache/catalina/users/DataSourceUserDatabase:closeConnection	(Ljava/sql/Connection;)V
/*      */     //   152: aload 5
/*      */     //   154: athrow
/*      */     //   155: astore 6
/*      */     //   157: aload_0
/*      */     //   158: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   161: invokeinterface 72 1 0
/*      */     //   166: aload 6
/*      */     //   168: athrow
/*      */     // Line number table:
/*      */     //   Java source line #727	-> byte code offset #0
/*      */     //   Java source line #730	-> byte code offset #9
/*      */     //   Java source line #731	-> byte code offset #21
/*      */     //   Java source line #732	-> byte code offset #25
/*      */     //   Java source line #753	-> byte code offset #27
/*      */     //   Java source line #732	-> byte code offset #36
/*      */     //   Java source line #734	-> byte code offset #38
/*      */     //   Java source line #735	-> byte code offset #50
/*      */     //   Java source line #736	-> byte code offset #54
/*      */     //   Java source line #753	-> byte code offset #56
/*      */     //   Java source line #736	-> byte code offset #65
/*      */     //   Java source line #738	-> byte code offset #67
/*      */     //   Java source line #739	-> byte code offset #79
/*      */     //   Java source line #740	-> byte code offset #83
/*      */     //   Java source line #753	-> byte code offset #85
/*      */     //   Java source line #740	-> byte code offset #94
/*      */     //   Java source line #743	-> byte code offset #96
/*      */     //   Java source line #744	-> byte code offset #101
/*      */     //   Java source line #745	-> byte code offset #105
/*      */     //   Java source line #753	-> byte code offset #108
/*      */     //   Java source line #745	-> byte code offset #117
/*      */     //   Java source line #748	-> byte code offset #120
/*      */     //   Java source line #750	-> byte code offset #128
/*      */     //   Java source line #753	-> byte code offset #133
/*      */     //   Java source line #748	-> byte code offset #142
/*      */     //   Java source line #750	-> byte code offset #145
/*      */     //   Java source line #751	-> byte code offset #152
/*      */     //   Java source line #753	-> byte code offset #155
/*      */     //   Java source line #754	-> byte code offset #166
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	169	0	this	DataSourceUserDatabase
/*      */     //   0	169	1	username	String
/*      */     //   20	60	2	user	User
/*      */     //   26	69	3	localUser1	User
/*      */     //   100	49	3	dbConnection	Connection
/*      */     //   106	37	4	localUser2	User
/*      */     //   145	8	5	localObject1	Object
/*      */     //   155	12	6	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   120	128	145	finally
/*      */     //   145	147	145	finally
/*      */     //   9	27	155	finally
/*      */     //   38	56	155	finally
/*      */     //   67	85	155	finally
/*      */     //   96	108	155	finally
/*      */     //   120	133	155	finally
/*      */     //   145	157	155	finally
/*      */   }
/*      */   
/*      */   public User findUserInternal(Connection dbConnection, String userName)
/*      */   {
/*  758 */     String dbCredentials = null;
/*  759 */     String fullName = null;
/*      */     try {
/*  761 */       PreparedStatement stmt = dbConnection.prepareStatement(this.preparedUser);Throwable localThrowable18 = null;
/*  762 */       try { stmt.setString(1, userName);
/*      */         
/*  764 */         ResultSet rs = stmt.executeQuery();Throwable localThrowable19 = null;
/*  765 */         try { if (rs.next()) {
/*  766 */             dbCredentials = rs.getString(1);
/*  767 */             if (this.userFullNameCol != null) {
/*  768 */               fullName = rs.getString(2);
/*      */             }
/*      */           }
/*      */           
/*  772 */           dbCredentials = dbCredentials != null ? dbCredentials.trim() : null;
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/*  764 */           localThrowable19 = localThrowable1;throw localThrowable1;
/*      */         }
/*      */         finally {}
/*      */       }
/*      */       catch (Throwable localThrowable4)
/*      */       {
/*  761 */         localThrowable18 = localThrowable4;throw localThrowable4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  774 */         if (stmt != null) if (localThrowable18 != null) try { stmt.close(); } catch (Throwable localThrowable5) { localThrowable18.addSuppressed(localThrowable5); } else stmt.close();
/*  775 */       } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */     }
/*      */     
/*      */ 
/*  779 */     ArrayList<Group> groups = new ArrayList();
/*  780 */     if (isGroupStoreDefined()) {
/*  781 */       try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedUserGroups);localThrowable4 = null;
/*  782 */         try { stmt.setString(1, userName);
/*  783 */           ResultSet rs = stmt.executeQuery();localThrowable1 = null;
/*  784 */           try { while (rs.next()) {
/*  785 */               String groupName = rs.getString(1);
/*  786 */               if (groupName != null) {
/*  787 */                 Group group = findGroupInternal(dbConnection, groupName);
/*  788 */                 if (group != null) {
/*  789 */                   groups.add(group);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (Throwable localThrowable24)
/*      */           {
/*  783 */             localThrowable1 = localThrowable24;throw localThrowable24;
/*      */           }
/*      */           finally {}
/*      */         }
/*      */         catch (Throwable localThrowable21)
/*      */         {
/*  781 */           localThrowable4 = localThrowable21;throw localThrowable21;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         finally
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  794 */           if (stmt != null) if (localThrowable4 != null) try { stmt.close(); } catch (Throwable localThrowable11) { localThrowable4.addSuppressed(localThrowable11); } else stmt.close();
/*  795 */         } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */       }
/*      */     }
/*      */     
/*  799 */     Object roles = new ArrayList();
/*  800 */     if ((this.userRoleTable != null) && (this.roleNameCol != null)) {
/*  801 */       try { PreparedStatement stmt = dbConnection.prepareStatement(this.preparedUserRoles);Throwable localThrowable22 = null;
/*  802 */         try { stmt.setString(1, userName);
/*  803 */           ResultSet rs = stmt.executeQuery();Throwable localThrowable25 = null;
/*  804 */           try { while (rs.next()) {
/*  805 */               String roleName = rs.getString(1);
/*  806 */               if (roleName != null) {
/*  807 */                 Role role = findRoleInternal(dbConnection, roleName);
/*  808 */                 if (role != null) {
/*  809 */                   ((ArrayList)roles).add(role);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (Throwable localThrowable13)
/*      */           {
/*  803 */             localThrowable25 = localThrowable13;throw localThrowable13;
/*      */           }
/*      */           finally {}
/*      */         }
/*      */         catch (Throwable localThrowable16)
/*      */         {
/*  801 */           localThrowable22 = localThrowable16;throw localThrowable16;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         finally
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  814 */           if (stmt != null) if (localThrowable22 != null) try { stmt.close(); } catch (Throwable localThrowable17) { localThrowable22.addSuppressed(localThrowable17); } else stmt.close();
/*  815 */         } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */       }
/*      */     }
/*      */     
/*  819 */     User user = new GenericUser(this, userName, dbCredentials, fullName, groups, (List)roles);
/*  820 */     return user;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void modifiedGroup(Group group)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   4: invokeinterface 46 1 0
/*      */     //   9: aload_1
/*      */     //   10: invokeinterface 93 1 0
/*      */     //   15: astore_2
/*      */     //   16: aload_0
/*      */     //   17: getfield 7	org/apache/catalina/users/DataSourceUserDatabase:createdGroups	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   20: aload_2
/*      */     //   21: invokevirtual 56	java/util/concurrent/ConcurrentHashMap:containsKey	(Ljava/lang/Object;)Z
/*      */     //   24: ifne +24 -> 48
/*      */     //   27: aload_0
/*      */     //   28: getfield 9	org/apache/catalina/users/DataSourceUserDatabase:removedGroups	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   31: aload_2
/*      */     //   32: invokevirtual 56	java/util/concurrent/ConcurrentHashMap:containsKey	(Ljava/lang/Object;)Z
/*      */     //   35: ifne +13 -> 48
/*      */     //   38: aload_0
/*      */     //   39: getfield 8	org/apache/catalina/users/DataSourceUserDatabase:modifiedGroups	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   42: aload_2
/*      */     //   43: aload_1
/*      */     //   44: invokevirtual 77	java/util/concurrent/ConcurrentHashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   47: pop
/*      */     //   48: aload_0
/*      */     //   49: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   52: invokeinterface 72 1 0
/*      */     //   57: goto +15 -> 72
/*      */     //   60: astore_3
/*      */     //   61: aload_0
/*      */     //   62: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   65: invokeinterface 72 1 0
/*      */     //   70: aload_3
/*      */     //   71: athrow
/*      */     //   72: return
/*      */     // Line number table:
/*      */     //   Java source line #825	-> byte code offset #0
/*      */     //   Java source line #827	-> byte code offset #9
/*      */     //   Java source line #828	-> byte code offset #16
/*      */     //   Java source line #829	-> byte code offset #38
/*      */     //   Java source line #832	-> byte code offset #48
/*      */     //   Java source line #833	-> byte code offset #57
/*      */     //   Java source line #832	-> byte code offset #60
/*      */     //   Java source line #833	-> byte code offset #70
/*      */     //   Java source line #834	-> byte code offset #72
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	73	0	this	DataSourceUserDatabase
/*      */     //   0	73	1	group	Group
/*      */     //   15	28	2	name	String
/*      */     //   60	11	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   9	48	60	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void modifiedRole(Role role)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   4: invokeinterface 46 1 0
/*      */     //   9: aload_1
/*      */     //   10: invokeinterface 94 1 0
/*      */     //   15: astore_2
/*      */     //   16: aload_0
/*      */     //   17: getfield 10	org/apache/catalina/users/DataSourceUserDatabase:createdRoles	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   20: aload_2
/*      */     //   21: invokevirtual 56	java/util/concurrent/ConcurrentHashMap:containsKey	(Ljava/lang/Object;)Z
/*      */     //   24: ifne +24 -> 48
/*      */     //   27: aload_0
/*      */     //   28: getfield 12	org/apache/catalina/users/DataSourceUserDatabase:removedRoles	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   31: aload_2
/*      */     //   32: invokevirtual 56	java/util/concurrent/ConcurrentHashMap:containsKey	(Ljava/lang/Object;)Z
/*      */     //   35: ifne +13 -> 48
/*      */     //   38: aload_0
/*      */     //   39: getfield 11	org/apache/catalina/users/DataSourceUserDatabase:modifiedRoles	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   42: aload_2
/*      */     //   43: aload_1
/*      */     //   44: invokevirtual 77	java/util/concurrent/ConcurrentHashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   47: pop
/*      */     //   48: aload_0
/*      */     //   49: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   52: invokeinterface 72 1 0
/*      */     //   57: goto +15 -> 72
/*      */     //   60: astore_3
/*      */     //   61: aload_0
/*      */     //   62: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   65: invokeinterface 72 1 0
/*      */     //   70: aload_3
/*      */     //   71: athrow
/*      */     //   72: return
/*      */     // Line number table:
/*      */     //   Java source line #838	-> byte code offset #0
/*      */     //   Java source line #840	-> byte code offset #9
/*      */     //   Java source line #841	-> byte code offset #16
/*      */     //   Java source line #842	-> byte code offset #38
/*      */     //   Java source line #845	-> byte code offset #48
/*      */     //   Java source line #846	-> byte code offset #57
/*      */     //   Java source line #845	-> byte code offset #60
/*      */     //   Java source line #846	-> byte code offset #70
/*      */     //   Java source line #847	-> byte code offset #72
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	73	0	this	DataSourceUserDatabase
/*      */     //   0	73	1	role	Role
/*      */     //   15	28	2	name	String
/*      */     //   60	11	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   9	48	60	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void modifiedUser(User user)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   4: invokeinterface 46 1 0
/*      */     //   9: aload_1
/*      */     //   10: invokeinterface 95 1 0
/*      */     //   15: astore_2
/*      */     //   16: aload_0
/*      */     //   17: getfield 4	org/apache/catalina/users/DataSourceUserDatabase:createdUsers	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   20: aload_2
/*      */     //   21: invokevirtual 56	java/util/concurrent/ConcurrentHashMap:containsKey	(Ljava/lang/Object;)Z
/*      */     //   24: ifne +24 -> 48
/*      */     //   27: aload_0
/*      */     //   28: getfield 6	org/apache/catalina/users/DataSourceUserDatabase:removedUsers	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   31: aload_2
/*      */     //   32: invokevirtual 56	java/util/concurrent/ConcurrentHashMap:containsKey	(Ljava/lang/Object;)Z
/*      */     //   35: ifne +13 -> 48
/*      */     //   38: aload_0
/*      */     //   39: getfield 5	org/apache/catalina/users/DataSourceUserDatabase:modifiedUsers	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   42: aload_2
/*      */     //   43: aload_1
/*      */     //   44: invokevirtual 77	java/util/concurrent/ConcurrentHashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   47: pop
/*      */     //   48: aload_0
/*      */     //   49: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   52: invokeinterface 72 1 0
/*      */     //   57: goto +15 -> 72
/*      */     //   60: astore_3
/*      */     //   61: aload_0
/*      */     //   62: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   65: invokeinterface 72 1 0
/*      */     //   70: aload_3
/*      */     //   71: athrow
/*      */     //   72: return
/*      */     // Line number table:
/*      */     //   Java source line #851	-> byte code offset #0
/*      */     //   Java source line #853	-> byte code offset #9
/*      */     //   Java source line #854	-> byte code offset #16
/*      */     //   Java source line #855	-> byte code offset #38
/*      */     //   Java source line #858	-> byte code offset #48
/*      */     //   Java source line #859	-> byte code offset #57
/*      */     //   Java source line #858	-> byte code offset #60
/*      */     //   Java source line #859	-> byte code offset #70
/*      */     //   Java source line #860	-> byte code offset #72
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	73	0	this	DataSourceUserDatabase
/*      */     //   0	73	1	user	User
/*      */     //   15	28	2	name	String
/*      */     //   60	11	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   9	48	60	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void open()
/*      */     throws Exception
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 65	org/apache/catalina/users/DataSourceUserDatabase:log	Lorg/apache/juli/logging/Log;
/*      */     //   3: invokeinterface 96 1 0
/*      */     //   8: ifeq +86 -> 94
/*      */     //   11: getstatic 65	org/apache/catalina/users/DataSourceUserDatabase:log	Lorg/apache/juli/logging/Log;
/*      */     //   14: new 97	java/lang/StringBuilder
/*      */     //   17: dup
/*      */     //   18: invokespecial 98	java/lang/StringBuilder:<init>	()V
/*      */     //   21: ldc 99
/*      */     //   23: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   26: aload_0
/*      */     //   27: getfield 29	org/apache/catalina/users/DataSourceUserDatabase:userRoleTable	Ljava/lang/String;
/*      */     //   30: ifnull +14 -> 44
/*      */     //   33: aload_0
/*      */     //   34: getfield 23	org/apache/catalina/users/DataSourceUserDatabase:roleNameCol	Ljava/lang/String;
/*      */     //   37: ifnull +7 -> 44
/*      */     //   40: iconst_1
/*      */     //   41: goto +4 -> 45
/*      */     //   44: iconst_0
/*      */     //   45: invokestatic 101	java/lang/Boolean:toString	(Z)Ljava/lang/String;
/*      */     //   48: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   51: ldc 102
/*      */     //   53: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   56: aload_0
/*      */     //   57: invokevirtual 103	org/apache/catalina/users/DataSourceUserDatabase:isRoleStoreDefined	()Z
/*      */     //   60: invokestatic 101	java/lang/Boolean:toString	(Z)Ljava/lang/String;
/*      */     //   63: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   66: ldc 104
/*      */     //   68: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   71: aload_0
/*      */     //   72: invokevirtual 103	org/apache/catalina/users/DataSourceUserDatabase:isRoleStoreDefined	()Z
/*      */     //   75: invokestatic 101	java/lang/Boolean:toString	(Z)Ljava/lang/String;
/*      */     //   78: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   81: ldc 105
/*      */     //   83: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   86: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   89: invokeinterface 107 2 0
/*      */     //   94: aload_0
/*      */     //   95: getfield 43	org/apache/catalina/users/DataSourceUserDatabase:writeLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   98: invokeinterface 46 1 0
/*      */     //   103: new 97	java/lang/StringBuilder
/*      */     //   106: dup
/*      */     //   107: ldc 108
/*      */     //   109: invokespecial 109	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   112: astore_1
/*      */     //   113: aload_1
/*      */     //   114: aload_0
/*      */     //   115: getfield 26	org/apache/catalina/users/DataSourceUserDatabase:userCredCol	Ljava/lang/String;
/*      */     //   118: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   121: pop
/*      */     //   122: aload_0
/*      */     //   123: getfield 27	org/apache/catalina/users/DataSourceUserDatabase:userFullNameCol	Ljava/lang/String;
/*      */     //   126: ifnull +17 -> 143
/*      */     //   129: aload_1
/*      */     //   130: ldc 110
/*      */     //   132: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   135: aload_0
/*      */     //   136: getfield 27	org/apache/catalina/users/DataSourceUserDatabase:userFullNameCol	Ljava/lang/String;
/*      */     //   139: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   142: pop
/*      */     //   143: aload_1
/*      */     //   144: ldc 111
/*      */     //   146: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   149: pop
/*      */     //   150: aload_1
/*      */     //   151: aload_0
/*      */     //   152: getfield 32	org/apache/catalina/users/DataSourceUserDatabase:userTable	Ljava/lang/String;
/*      */     //   155: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   158: pop
/*      */     //   159: aload_1
/*      */     //   160: ldc 112
/*      */     //   162: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   165: pop
/*      */     //   166: aload_1
/*      */     //   167: aload_0
/*      */     //   168: getfield 28	org/apache/catalina/users/DataSourceUserDatabase:userNameCol	Ljava/lang/String;
/*      */     //   171: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   174: pop
/*      */     //   175: aload_1
/*      */     //   176: ldc 113
/*      */     //   178: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   181: pop
/*      */     //   182: aload_0
/*      */     //   183: aload_1
/*      */     //   184: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   187: putfield 19	org/apache/catalina/users/DataSourceUserDatabase:preparedUser	Ljava/lang/String;
/*      */     //   190: new 97	java/lang/StringBuilder
/*      */     //   193: dup
/*      */     //   194: ldc 108
/*      */     //   196: invokespecial 109	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   199: astore_1
/*      */     //   200: aload_1
/*      */     //   201: aload_0
/*      */     //   202: getfield 28	org/apache/catalina/users/DataSourceUserDatabase:userNameCol	Ljava/lang/String;
/*      */     //   205: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   208: pop
/*      */     //   209: aload_1
/*      */     //   210: ldc 111
/*      */     //   212: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   215: pop
/*      */     //   216: aload_1
/*      */     //   217: aload_0
/*      */     //   218: getfield 32	org/apache/catalina/users/DataSourceUserDatabase:userTable	Ljava/lang/String;
/*      */     //   221: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   224: pop
/*      */     //   225: aload_0
/*      */     //   226: aload_1
/*      */     //   227: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   230: putfield 13	org/apache/catalina/users/DataSourceUserDatabase:preparedAllUsers	Ljava/lang/String;
/*      */     //   233: new 97	java/lang/StringBuilder
/*      */     //   236: dup
/*      */     //   237: ldc 108
/*      */     //   239: invokespecial 109	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   242: astore_1
/*      */     //   243: aload_1
/*      */     //   244: aload_0
/*      */     //   245: getfield 23	org/apache/catalina/users/DataSourceUserDatabase:roleNameCol	Ljava/lang/String;
/*      */     //   248: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   251: pop
/*      */     //   252: aload_1
/*      */     //   253: ldc 111
/*      */     //   255: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   258: pop
/*      */     //   259: aload_1
/*      */     //   260: aload_0
/*      */     //   261: getfield 29	org/apache/catalina/users/DataSourceUserDatabase:userRoleTable	Ljava/lang/String;
/*      */     //   264: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   267: pop
/*      */     //   268: aload_1
/*      */     //   269: ldc 112
/*      */     //   271: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   274: pop
/*      */     //   275: aload_1
/*      */     //   276: aload_0
/*      */     //   277: getfield 28	org/apache/catalina/users/DataSourceUserDatabase:userNameCol	Ljava/lang/String;
/*      */     //   280: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   283: pop
/*      */     //   284: aload_1
/*      */     //   285: ldc 113
/*      */     //   287: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   290: pop
/*      */     //   291: aload_0
/*      */     //   292: aload_1
/*      */     //   293: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   296: putfield 18	org/apache/catalina/users/DataSourceUserDatabase:preparedUserRoles	Ljava/lang/String;
/*      */     //   299: aload_0
/*      */     //   300: invokevirtual 85	org/apache/catalina/users/DataSourceUserDatabase:isGroupStoreDefined	()Z
/*      */     //   303: ifeq +265 -> 568
/*      */     //   306: new 97	java/lang/StringBuilder
/*      */     //   309: dup
/*      */     //   310: ldc 108
/*      */     //   312: invokespecial 109	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   315: astore_1
/*      */     //   316: aload_1
/*      */     //   317: aload_0
/*      */     //   318: getfield 25	org/apache/catalina/users/DataSourceUserDatabase:groupNameCol	Ljava/lang/String;
/*      */     //   321: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   324: pop
/*      */     //   325: aload_1
/*      */     //   326: ldc 111
/*      */     //   328: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   331: pop
/*      */     //   332: aload_1
/*      */     //   333: aload_0
/*      */     //   334: getfield 30	org/apache/catalina/users/DataSourceUserDatabase:userGroupTable	Ljava/lang/String;
/*      */     //   337: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   340: pop
/*      */     //   341: aload_1
/*      */     //   342: ldc 112
/*      */     //   344: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   347: pop
/*      */     //   348: aload_1
/*      */     //   349: aload_0
/*      */     //   350: getfield 28	org/apache/catalina/users/DataSourceUserDatabase:userNameCol	Ljava/lang/String;
/*      */     //   353: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   356: pop
/*      */     //   357: aload_1
/*      */     //   358: ldc 113
/*      */     //   360: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   363: pop
/*      */     //   364: aload_0
/*      */     //   365: aload_1
/*      */     //   366: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   369: putfield 20	org/apache/catalina/users/DataSourceUserDatabase:preparedUserGroups	Ljava/lang/String;
/*      */     //   372: new 97	java/lang/StringBuilder
/*      */     //   375: dup
/*      */     //   376: ldc 108
/*      */     //   378: invokespecial 109	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   381: astore_1
/*      */     //   382: aload_1
/*      */     //   383: aload_0
/*      */     //   384: getfield 23	org/apache/catalina/users/DataSourceUserDatabase:roleNameCol	Ljava/lang/String;
/*      */     //   387: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   390: pop
/*      */     //   391: aload_1
/*      */     //   392: ldc 111
/*      */     //   394: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   397: pop
/*      */     //   398: aload_1
/*      */     //   399: aload_0
/*      */     //   400: getfield 31	org/apache/catalina/users/DataSourceUserDatabase:groupRoleTable	Ljava/lang/String;
/*      */     //   403: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   406: pop
/*      */     //   407: aload_1
/*      */     //   408: ldc 112
/*      */     //   410: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   413: pop
/*      */     //   414: aload_1
/*      */     //   415: aload_0
/*      */     //   416: getfield 25	org/apache/catalina/users/DataSourceUserDatabase:groupNameCol	Ljava/lang/String;
/*      */     //   419: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   422: pop
/*      */     //   423: aload_1
/*      */     //   424: ldc 113
/*      */     //   426: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   429: pop
/*      */     //   430: aload_0
/*      */     //   431: aload_1
/*      */     //   432: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   435: putfield 21	org/apache/catalina/users/DataSourceUserDatabase:preparedGroupRoles	Ljava/lang/String;
/*      */     //   438: new 97	java/lang/StringBuilder
/*      */     //   441: dup
/*      */     //   442: ldc 108
/*      */     //   444: invokespecial 109	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   447: astore_1
/*      */     //   448: aload_1
/*      */     //   449: aload_0
/*      */     //   450: getfield 25	org/apache/catalina/users/DataSourceUserDatabase:groupNameCol	Ljava/lang/String;
/*      */     //   453: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   456: pop
/*      */     //   457: aload_0
/*      */     //   458: getfield 24	org/apache/catalina/users/DataSourceUserDatabase:roleAndGroupDescriptionCol	Ljava/lang/String;
/*      */     //   461: ifnull +17 -> 478
/*      */     //   464: aload_1
/*      */     //   465: ldc 110
/*      */     //   467: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   470: aload_0
/*      */     //   471: getfield 24	org/apache/catalina/users/DataSourceUserDatabase:roleAndGroupDescriptionCol	Ljava/lang/String;
/*      */     //   474: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   477: pop
/*      */     //   478: aload_1
/*      */     //   479: ldc 111
/*      */     //   481: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   484: pop
/*      */     //   485: aload_1
/*      */     //   486: aload_0
/*      */     //   487: getfield 33	org/apache/catalina/users/DataSourceUserDatabase:groupTable	Ljava/lang/String;
/*      */     //   490: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   493: pop
/*      */     //   494: aload_1
/*      */     //   495: ldc 112
/*      */     //   497: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   500: pop
/*      */     //   501: aload_1
/*      */     //   502: aload_0
/*      */     //   503: getfield 25	org/apache/catalina/users/DataSourceUserDatabase:groupNameCol	Ljava/lang/String;
/*      */     //   506: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   509: pop
/*      */     //   510: aload_1
/*      */     //   511: ldc 113
/*      */     //   513: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   516: pop
/*      */     //   517: aload_0
/*      */     //   518: aload_1
/*      */     //   519: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   522: putfield 16	org/apache/catalina/users/DataSourceUserDatabase:preparedGroup	Ljava/lang/String;
/*      */     //   525: new 97	java/lang/StringBuilder
/*      */     //   528: dup
/*      */     //   529: ldc 108
/*      */     //   531: invokespecial 109	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   534: astore_1
/*      */     //   535: aload_1
/*      */     //   536: aload_0
/*      */     //   537: getfield 25	org/apache/catalina/users/DataSourceUserDatabase:groupNameCol	Ljava/lang/String;
/*      */     //   540: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   543: pop
/*      */     //   544: aload_1
/*      */     //   545: ldc 111
/*      */     //   547: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   550: pop
/*      */     //   551: aload_1
/*      */     //   552: aload_0
/*      */     //   553: getfield 33	org/apache/catalina/users/DataSourceUserDatabase:groupTable	Ljava/lang/String;
/*      */     //   556: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   559: pop
/*      */     //   560: aload_0
/*      */     //   561: aload_1
/*      */     //   562: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   565: putfield 14	org/apache/catalina/users/DataSourceUserDatabase:preparedAllGroups	Ljava/lang/String;
/*      */     //   568: aload_0
/*      */     //   569: invokevirtual 103	org/apache/catalina/users/DataSourceUserDatabase:isRoleStoreDefined	()Z
/*      */     //   572: ifeq +136 -> 708
/*      */     //   575: new 97	java/lang/StringBuilder
/*      */     //   578: dup
/*      */     //   579: ldc 108
/*      */     //   581: invokespecial 109	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   584: astore_1
/*      */     //   585: aload_1
/*      */     //   586: aload_0
/*      */     //   587: getfield 23	org/apache/catalina/users/DataSourceUserDatabase:roleNameCol	Ljava/lang/String;
/*      */     //   590: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   593: pop
/*      */     //   594: aload_0
/*      */     //   595: getfield 24	org/apache/catalina/users/DataSourceUserDatabase:roleAndGroupDescriptionCol	Ljava/lang/String;
/*      */     //   598: ifnull +17 -> 615
/*      */     //   601: aload_1
/*      */     //   602: ldc 110
/*      */     //   604: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   607: aload_0
/*      */     //   608: getfield 24	org/apache/catalina/users/DataSourceUserDatabase:roleAndGroupDescriptionCol	Ljava/lang/String;
/*      */     //   611: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   614: pop
/*      */     //   615: aload_1
/*      */     //   616: ldc 111
/*      */     //   618: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   621: pop
/*      */     //   622: aload_1
/*      */     //   623: aload_0
/*      */     //   624: getfield 34	org/apache/catalina/users/DataSourceUserDatabase:roleTable	Ljava/lang/String;
/*      */     //   627: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   630: pop
/*      */     //   631: aload_1
/*      */     //   632: ldc 112
/*      */     //   634: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   637: pop
/*      */     //   638: aload_1
/*      */     //   639: aload_0
/*      */     //   640: getfield 23	org/apache/catalina/users/DataSourceUserDatabase:roleNameCol	Ljava/lang/String;
/*      */     //   643: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   646: pop
/*      */     //   647: aload_1
/*      */     //   648: ldc 113
/*      */     //   650: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   653: pop
/*      */     //   654: aload_0
/*      */     //   655: aload_1
/*      */     //   656: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   659: putfield 17	org/apache/catalina/users/DataSourceUserDatabase:preparedRole	Ljava/lang/String;
/*      */     //   662: new 97	java/lang/StringBuilder
/*      */     //   665: dup
/*      */     //   666: ldc 108
/*      */     //   668: invokespecial 109	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   671: astore_1
/*      */     //   672: aload_1
/*      */     //   673: aload_0
/*      */     //   674: getfield 23	org/apache/catalina/users/DataSourceUserDatabase:roleNameCol	Ljava/lang/String;
/*      */     //   677: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   680: pop
/*      */     //   681: aload_1
/*      */     //   682: ldc 111
/*      */     //   684: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   687: pop
/*      */     //   688: aload_1
/*      */     //   689: aload_0
/*      */     //   690: getfield 34	org/apache/catalina/users/DataSourceUserDatabase:roleTable	Ljava/lang/String;
/*      */     //   693: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   696: pop
/*      */     //   697: aload_0
/*      */     //   698: aload_1
/*      */     //   699: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   702: putfield 15	org/apache/catalina/users/DataSourceUserDatabase:preparedAllRoles	Ljava/lang/String;
/*      */     //   705: goto +83 -> 788
/*      */     //   708: aload_0
/*      */     //   709: getfield 29	org/apache/catalina/users/DataSourceUserDatabase:userRoleTable	Ljava/lang/String;
/*      */     //   712: ifnull +76 -> 788
/*      */     //   715: aload_0
/*      */     //   716: getfield 23	org/apache/catalina/users/DataSourceUserDatabase:roleNameCol	Ljava/lang/String;
/*      */     //   719: ifnull +69 -> 788
/*      */     //   722: new 97	java/lang/StringBuilder
/*      */     //   725: dup
/*      */     //   726: ldc 108
/*      */     //   728: invokespecial 109	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*      */     //   731: astore_1
/*      */     //   732: aload_1
/*      */     //   733: aload_0
/*      */     //   734: getfield 23	org/apache/catalina/users/DataSourceUserDatabase:roleNameCol	Ljava/lang/String;
/*      */     //   737: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   740: pop
/*      */     //   741: aload_1
/*      */     //   742: ldc 111
/*      */     //   744: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   747: pop
/*      */     //   748: aload_1
/*      */     //   749: aload_0
/*      */     //   750: getfield 29	org/apache/catalina/users/DataSourceUserDatabase:userRoleTable	Ljava/lang/String;
/*      */     //   753: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   756: pop
/*      */     //   757: aload_1
/*      */     //   758: ldc 112
/*      */     //   760: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   763: pop
/*      */     //   764: aload_1
/*      */     //   765: aload_0
/*      */     //   766: getfield 23	org/apache/catalina/users/DataSourceUserDatabase:roleNameCol	Ljava/lang/String;
/*      */     //   769: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   772: pop
/*      */     //   773: aload_1
/*      */     //   774: ldc 113
/*      */     //   776: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   779: pop
/*      */     //   780: aload_0
/*      */     //   781: aload_1
/*      */     //   782: invokevirtual 106	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   785: putfield 17	org/apache/catalina/users/DataSourceUserDatabase:preparedRole	Ljava/lang/String;
/*      */     //   788: aload_0
/*      */     //   789: getfield 43	org/apache/catalina/users/DataSourceUserDatabase:writeLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   792: invokeinterface 72 1 0
/*      */     //   797: goto +15 -> 812
/*      */     //   800: astore_2
/*      */     //   801: aload_0
/*      */     //   802: getfield 43	org/apache/catalina/users/DataSourceUserDatabase:writeLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   805: invokeinterface 72 1 0
/*      */     //   810: aload_2
/*      */     //   811: athrow
/*      */     //   812: return
/*      */     // Line number table:
/*      */     //   Java source line #865	-> byte code offset #0
/*      */     //   Java source line #867	-> byte code offset #11
/*      */     //   Java source line #868	-> byte code offset #45
/*      */     //   Java source line #869	-> byte code offset #57
/*      */     //   Java source line #870	-> byte code offset #72
/*      */     //   Java source line #867	-> byte code offset #89
/*      */     //   Java source line #873	-> byte code offset #94
/*      */     //   Java source line #876	-> byte code offset #103
/*      */     //   Java source line #877	-> byte code offset #113
/*      */     //   Java source line #878	-> byte code offset #122
/*      */     //   Java source line #879	-> byte code offset #129
/*      */     //   Java source line #881	-> byte code offset #143
/*      */     //   Java source line #882	-> byte code offset #150
/*      */     //   Java source line #883	-> byte code offset #159
/*      */     //   Java source line #884	-> byte code offset #166
/*      */     //   Java source line #885	-> byte code offset #175
/*      */     //   Java source line #886	-> byte code offset #182
/*      */     //   Java source line #888	-> byte code offset #190
/*      */     //   Java source line #889	-> byte code offset #200
/*      */     //   Java source line #890	-> byte code offset #209
/*      */     //   Java source line #891	-> byte code offset #216
/*      */     //   Java source line #892	-> byte code offset #225
/*      */     //   Java source line #894	-> byte code offset #233
/*      */     //   Java source line #895	-> byte code offset #243
/*      */     //   Java source line #896	-> byte code offset #252
/*      */     //   Java source line #897	-> byte code offset #259
/*      */     //   Java source line #898	-> byte code offset #268
/*      */     //   Java source line #899	-> byte code offset #275
/*      */     //   Java source line #900	-> byte code offset #284
/*      */     //   Java source line #901	-> byte code offset #291
/*      */     //   Java source line #903	-> byte code offset #299
/*      */     //   Java source line #904	-> byte code offset #306
/*      */     //   Java source line #905	-> byte code offset #316
/*      */     //   Java source line #906	-> byte code offset #325
/*      */     //   Java source line #907	-> byte code offset #332
/*      */     //   Java source line #908	-> byte code offset #341
/*      */     //   Java source line #909	-> byte code offset #348
/*      */     //   Java source line #910	-> byte code offset #357
/*      */     //   Java source line #911	-> byte code offset #364
/*      */     //   Java source line #913	-> byte code offset #372
/*      */     //   Java source line #914	-> byte code offset #382
/*      */     //   Java source line #915	-> byte code offset #391
/*      */     //   Java source line #916	-> byte code offset #398
/*      */     //   Java source line #917	-> byte code offset #407
/*      */     //   Java source line #918	-> byte code offset #414
/*      */     //   Java source line #919	-> byte code offset #423
/*      */     //   Java source line #920	-> byte code offset #430
/*      */     //   Java source line #922	-> byte code offset #438
/*      */     //   Java source line #923	-> byte code offset #448
/*      */     //   Java source line #924	-> byte code offset #457
/*      */     //   Java source line #925	-> byte code offset #464
/*      */     //   Java source line #927	-> byte code offset #478
/*      */     //   Java source line #928	-> byte code offset #485
/*      */     //   Java source line #929	-> byte code offset #494
/*      */     //   Java source line #930	-> byte code offset #501
/*      */     //   Java source line #931	-> byte code offset #510
/*      */     //   Java source line #932	-> byte code offset #517
/*      */     //   Java source line #934	-> byte code offset #525
/*      */     //   Java source line #935	-> byte code offset #535
/*      */     //   Java source line #936	-> byte code offset #544
/*      */     //   Java source line #937	-> byte code offset #551
/*      */     //   Java source line #938	-> byte code offset #560
/*      */     //   Java source line #941	-> byte code offset #568
/*      */     //   Java source line #943	-> byte code offset #575
/*      */     //   Java source line #944	-> byte code offset #585
/*      */     //   Java source line #945	-> byte code offset #594
/*      */     //   Java source line #946	-> byte code offset #601
/*      */     //   Java source line #948	-> byte code offset #615
/*      */     //   Java source line #949	-> byte code offset #622
/*      */     //   Java source line #950	-> byte code offset #631
/*      */     //   Java source line #951	-> byte code offset #638
/*      */     //   Java source line #952	-> byte code offset #647
/*      */     //   Java source line #953	-> byte code offset #654
/*      */     //   Java source line #955	-> byte code offset #662
/*      */     //   Java source line #956	-> byte code offset #672
/*      */     //   Java source line #957	-> byte code offset #681
/*      */     //   Java source line #958	-> byte code offset #688
/*      */     //   Java source line #959	-> byte code offset #697
/*      */     //   Java source line #960	-> byte code offset #708
/*      */     //   Java source line #962	-> byte code offset #722
/*      */     //   Java source line #963	-> byte code offset #732
/*      */     //   Java source line #964	-> byte code offset #741
/*      */     //   Java source line #965	-> byte code offset #748
/*      */     //   Java source line #966	-> byte code offset #757
/*      */     //   Java source line #967	-> byte code offset #764
/*      */     //   Java source line #968	-> byte code offset #773
/*      */     //   Java source line #969	-> byte code offset #780
/*      */     //   Java source line #973	-> byte code offset #788
/*      */     //   Java source line #974	-> byte code offset #797
/*      */     //   Java source line #973	-> byte code offset #800
/*      */     //   Java source line #974	-> byte code offset #810
/*      */     //   Java source line #976	-> byte code offset #812
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	813	0	this	DataSourceUserDatabase
/*      */     //   112	670	1	temp	StringBuilder
/*      */     //   800	11	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   103	788	800	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void removeGroup(Group group)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   4: invokeinterface 46 1 0
/*      */     //   9: aload_1
/*      */     //   10: invokeinterface 93 1 0
/*      */     //   15: astore_2
/*      */     //   16: aload_0
/*      */     //   17: getfield 7	org/apache/catalina/users/DataSourceUserDatabase:createdGroups	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   20: aload_2
/*      */     //   21: invokevirtual 78	java/util/concurrent/ConcurrentHashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   24: pop
/*      */     //   25: aload_0
/*      */     //   26: getfield 8	org/apache/catalina/users/DataSourceUserDatabase:modifiedGroups	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   29: aload_2
/*      */     //   30: invokevirtual 78	java/util/concurrent/ConcurrentHashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   33: pop
/*      */     //   34: aload_0
/*      */     //   35: getfield 9	org/apache/catalina/users/DataSourceUserDatabase:removedGroups	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   38: aload_2
/*      */     //   39: aload_1
/*      */     //   40: invokevirtual 77	java/util/concurrent/ConcurrentHashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   43: pop
/*      */     //   44: aload_0
/*      */     //   45: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   48: invokeinterface 72 1 0
/*      */     //   53: goto +15 -> 68
/*      */     //   56: astore_3
/*      */     //   57: aload_0
/*      */     //   58: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   61: invokeinterface 72 1 0
/*      */     //   66: aload_3
/*      */     //   67: athrow
/*      */     //   68: return
/*      */     // Line number table:
/*      */     //   Java source line #980	-> byte code offset #0
/*      */     //   Java source line #982	-> byte code offset #9
/*      */     //   Java source line #983	-> byte code offset #16
/*      */     //   Java source line #984	-> byte code offset #25
/*      */     //   Java source line #985	-> byte code offset #34
/*      */     //   Java source line #987	-> byte code offset #44
/*      */     //   Java source line #988	-> byte code offset #53
/*      */     //   Java source line #987	-> byte code offset #56
/*      */     //   Java source line #988	-> byte code offset #66
/*      */     //   Java source line #989	-> byte code offset #68
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	69	0	this	DataSourceUserDatabase
/*      */     //   0	69	1	group	Group
/*      */     //   15	24	2	name	String
/*      */     //   56	11	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   9	44	56	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void removeRole(Role role)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   4: invokeinterface 46 1 0
/*      */     //   9: aload_1
/*      */     //   10: invokeinterface 94 1 0
/*      */     //   15: astore_2
/*      */     //   16: aload_0
/*      */     //   17: getfield 10	org/apache/catalina/users/DataSourceUserDatabase:createdRoles	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   20: aload_2
/*      */     //   21: invokevirtual 78	java/util/concurrent/ConcurrentHashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   24: pop
/*      */     //   25: aload_0
/*      */     //   26: getfield 11	org/apache/catalina/users/DataSourceUserDatabase:modifiedRoles	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   29: aload_2
/*      */     //   30: invokevirtual 78	java/util/concurrent/ConcurrentHashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   33: pop
/*      */     //   34: aload_0
/*      */     //   35: getfield 12	org/apache/catalina/users/DataSourceUserDatabase:removedRoles	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   38: aload_2
/*      */     //   39: aload_1
/*      */     //   40: invokevirtual 77	java/util/concurrent/ConcurrentHashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   43: pop
/*      */     //   44: aload_0
/*      */     //   45: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   48: invokeinterface 72 1 0
/*      */     //   53: goto +15 -> 68
/*      */     //   56: astore_3
/*      */     //   57: aload_0
/*      */     //   58: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   61: invokeinterface 72 1 0
/*      */     //   66: aload_3
/*      */     //   67: athrow
/*      */     //   68: return
/*      */     // Line number table:
/*      */     //   Java source line #993	-> byte code offset #0
/*      */     //   Java source line #995	-> byte code offset #9
/*      */     //   Java source line #996	-> byte code offset #16
/*      */     //   Java source line #997	-> byte code offset #25
/*      */     //   Java source line #998	-> byte code offset #34
/*      */     //   Java source line #1000	-> byte code offset #44
/*      */     //   Java source line #1001	-> byte code offset #53
/*      */     //   Java source line #1000	-> byte code offset #56
/*      */     //   Java source line #1001	-> byte code offset #66
/*      */     //   Java source line #1002	-> byte code offset #68
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	69	0	this	DataSourceUserDatabase
/*      */     //   0	69	1	role	Role
/*      */     //   15	24	2	name	String
/*      */     //   56	11	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   9	44	56	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void removeUser(User user)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   4: invokeinterface 46 1 0
/*      */     //   9: aload_1
/*      */     //   10: invokeinterface 95 1 0
/*      */     //   15: astore_2
/*      */     //   16: aload_0
/*      */     //   17: getfield 4	org/apache/catalina/users/DataSourceUserDatabase:createdUsers	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   20: aload_2
/*      */     //   21: invokevirtual 78	java/util/concurrent/ConcurrentHashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   24: pop
/*      */     //   25: aload_0
/*      */     //   26: getfield 5	org/apache/catalina/users/DataSourceUserDatabase:modifiedUsers	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   29: aload_2
/*      */     //   30: invokevirtual 78	java/util/concurrent/ConcurrentHashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   33: pop
/*      */     //   34: aload_0
/*      */     //   35: getfield 6	org/apache/catalina/users/DataSourceUserDatabase:removedUsers	Ljava/util/concurrent/ConcurrentHashMap;
/*      */     //   38: aload_2
/*      */     //   39: aload_1
/*      */     //   40: invokevirtual 77	java/util/concurrent/ConcurrentHashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   43: pop
/*      */     //   44: aload_0
/*      */     //   45: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   48: invokeinterface 72 1 0
/*      */     //   53: goto +15 -> 68
/*      */     //   56: astore_3
/*      */     //   57: aload_0
/*      */     //   58: getfield 41	org/apache/catalina/users/DataSourceUserDatabase:readLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   61: invokeinterface 72 1 0
/*      */     //   66: aload_3
/*      */     //   67: athrow
/*      */     //   68: return
/*      */     // Line number table:
/*      */     //   Java source line #1006	-> byte code offset #0
/*      */     //   Java source line #1008	-> byte code offset #9
/*      */     //   Java source line #1009	-> byte code offset #16
/*      */     //   Java source line #1010	-> byte code offset #25
/*      */     //   Java source line #1011	-> byte code offset #34
/*      */     //   Java source line #1013	-> byte code offset #44
/*      */     //   Java source line #1014	-> byte code offset #53
/*      */     //   Java source line #1013	-> byte code offset #56
/*      */     //   Java source line #1014	-> byte code offset #66
/*      */     //   Java source line #1015	-> byte code offset #68
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	69	0	this	DataSourceUserDatabase
/*      */     //   0	69	1	user	User
/*      */     //   15	24	2	name	String
/*      */     //   56	11	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   9	44	56	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void save()
/*      */     throws Exception
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 36	org/apache/catalina/users/DataSourceUserDatabase:readonly	Z
/*      */     //   4: ifeq +4 -> 8
/*      */     //   7: return
/*      */     //   8: aload_0
/*      */     //   9: invokevirtual 50	org/apache/catalina/users/DataSourceUserDatabase:openConnection	()Ljava/sql/Connection;
/*      */     //   12: astore_1
/*      */     //   13: aload_1
/*      */     //   14: ifnonnull +4 -> 18
/*      */     //   17: return
/*      */     //   18: aload_0
/*      */     //   19: getfield 43	org/apache/catalina/users/DataSourceUserDatabase:writeLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   22: invokeinterface 46 1 0
/*      */     //   27: aload_0
/*      */     //   28: aload_1
/*      */     //   29: invokevirtual 114	org/apache/catalina/users/DataSourceUserDatabase:saveInternal	(Ljava/sql/Connection;)V
/*      */     //   32: aload_0
/*      */     //   33: aload_1
/*      */     //   34: invokevirtual 63	org/apache/catalina/users/DataSourceUserDatabase:closeConnection	(Ljava/sql/Connection;)V
/*      */     //   37: goto +11 -> 48
/*      */     //   40: astore_2
/*      */     //   41: aload_0
/*      */     //   42: aload_1
/*      */     //   43: invokevirtual 63	org/apache/catalina/users/DataSourceUserDatabase:closeConnection	(Ljava/sql/Connection;)V
/*      */     //   46: aload_2
/*      */     //   47: athrow
/*      */     //   48: aload_0
/*      */     //   49: getfield 43	org/apache/catalina/users/DataSourceUserDatabase:writeLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   52: invokeinterface 72 1 0
/*      */     //   57: goto +15 -> 72
/*      */     //   60: astore_3
/*      */     //   61: aload_0
/*      */     //   62: getfield 43	org/apache/catalina/users/DataSourceUserDatabase:writeLock	Ljava/util/concurrent/locks/Lock;
/*      */     //   65: invokeinterface 72 1 0
/*      */     //   70: aload_3
/*      */     //   71: athrow
/*      */     //   72: return
/*      */     // Line number table:
/*      */     //   Java source line #1019	-> byte code offset #0
/*      */     //   Java source line #1020	-> byte code offset #7
/*      */     //   Java source line #1023	-> byte code offset #8
/*      */     //   Java source line #1024	-> byte code offset #13
/*      */     //   Java source line #1025	-> byte code offset #17
/*      */     //   Java source line #1028	-> byte code offset #18
/*      */     //   Java source line #1031	-> byte code offset #27
/*      */     //   Java source line #1033	-> byte code offset #32
/*      */     //   Java source line #1034	-> byte code offset #37
/*      */     //   Java source line #1033	-> byte code offset #40
/*      */     //   Java source line #1034	-> byte code offset #46
/*      */     //   Java source line #1036	-> byte code offset #48
/*      */     //   Java source line #1037	-> byte code offset #57
/*      */     //   Java source line #1036	-> byte code offset #60
/*      */     //   Java source line #1037	-> byte code offset #70
/*      */     //   Java source line #1038	-> byte code offset #72
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	73	0	this	DataSourceUserDatabase
/*      */     //   12	31	1	dbConnection	Connection
/*      */     //   40	7	2	localObject1	Object
/*      */     //   60	11	3	localObject2	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   27	32	40	finally
/*      */     //   27	48	60	finally
/*      */   }
/*      */   
/*      */   protected void saveInternal(Connection dbConnection)
/*      */   {
/* 1042 */     StringBuilder temp = null;
/* 1043 */     StringBuilder tempRelation = null;
/* 1044 */     StringBuilder tempRelationDelete = null;
/*      */     StringBuilder tempRelationDelete2;
/* 1046 */     if (isRoleStoreDefined())
/*      */     {
/*      */ 
/* 1049 */       if (!this.removedRoles.isEmpty()) {
/* 1050 */         temp = new StringBuilder("DELETE FROM ");
/* 1051 */         temp.append(this.roleTable);
/* 1052 */         temp.append(" WHERE ").append(this.roleNameCol);
/* 1053 */         temp.append(" = ?");
/* 1054 */         if (this.groupRoleTable != null) {
/* 1055 */           tempRelationDelete = new StringBuilder("DELETE FROM ");
/* 1056 */           tempRelationDelete.append(this.groupRoleTable);
/* 1057 */           tempRelationDelete.append(" WHERE ");
/* 1058 */           tempRelationDelete.append(this.roleNameCol);
/* 1059 */           tempRelationDelete.append(" = ?");
/*      */         }
/* 1061 */         tempRelationDelete2 = new StringBuilder("DELETE FROM ");
/* 1062 */         tempRelationDelete2.append(this.userRoleTable);
/* 1063 */         tempRelationDelete2.append(" WHERE ");
/* 1064 */         tempRelationDelete2.append(this.roleNameCol);
/* 1065 */         tempRelationDelete2.append(" = ?");
/* 1066 */         for (Role role : this.removedRoles.values()) { Throwable localThrowable75;
/* 1067 */           if (tempRelationDelete != null)
/* 1068 */             try { PreparedStatement stmt = dbConnection.prepareStatement(tempRelationDelete.toString());localThrowable75 = null;
/* 1069 */               try { stmt.setString(1, role.getRolename());
/* 1070 */                 stmt.executeUpdate();
/*      */               }
/*      */               catch (Throwable localThrowable1)
/*      */               {
/* 1068 */                 localThrowable75 = localThrowable1;throw localThrowable1;
/*      */               }
/*      */               finally {
/* 1071 */                 if (stmt != null) if (localThrowable75 != null) try { stmt.close(); } catch (Throwable localThrowable2) { localThrowable75.addSuppressed(localThrowable2); } else stmt.close();
/* 1072 */               } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */             }
/*      */           try {
/* 1075 */             PreparedStatement stmt = dbConnection.prepareStatement(tempRelationDelete2.toString());localThrowable75 = null;
/* 1076 */             try { stmt.setString(1, role.getRolename());
/* 1077 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable4)
/*      */             {
/* 1075 */               localThrowable75 = localThrowable4;throw localThrowable4;
/*      */             }
/*      */             finally {
/* 1078 */               if (stmt != null) if (localThrowable75 != null) try { stmt.close(); } catch (Throwable localThrowable5) { localThrowable75.addSuppressed(localThrowable5); } else stmt.close();
/* 1079 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/* 1081 */           try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString());localThrowable75 = null;
/* 1082 */             try { stmt.setString(1, role.getRolename());
/* 1083 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable7)
/*      */             {
/* 1081 */               localThrowable75 = localThrowable7;throw localThrowable7;
/*      */             }
/*      */             finally {
/* 1084 */               if (stmt != null) if (localThrowable75 != null) try { stmt.close(); } catch (Throwable localThrowable8) { localThrowable75.addSuppressed(localThrowable8); } else stmt.close();
/* 1085 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/*      */         }
/* 1088 */         this.removedRoles.clear();
/*      */       }
/*      */       
/*      */ 
/* 1092 */       if (!this.createdRoles.isEmpty()) {
/* 1093 */         temp = new StringBuilder("INSERT INTO ");
/* 1094 */         temp.append(this.roleTable);
/* 1095 */         temp.append('(').append(this.roleNameCol);
/* 1096 */         if (this.roleAndGroupDescriptionCol != null) {
/* 1097 */           temp.append(',').append(this.roleAndGroupDescriptionCol);
/*      */         }
/* 1099 */         temp.append(") VALUES (?");
/* 1100 */         if (this.roleAndGroupDescriptionCol != null) {
/* 1101 */           temp.append(", ?");
/*      */         }
/* 1103 */         temp.append(')');
/* 1104 */         for (Role role : this.createdRoles.values()) {
/* 1105 */           try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString());e = null;
/* 1106 */             try { stmt.setString(1, role.getRolename());
/* 1107 */               if (this.roleAndGroupDescriptionCol != null) {
/* 1108 */                 stmt.setString(2, role.getDescription());
/*      */               }
/* 1110 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable77)
/*      */             {
/* 1105 */               e = localThrowable77;throw localThrowable77;
/*      */ 
/*      */             }
/*      */             finally
/*      */             {
/*      */ 
/* 1111 */               if (stmt != null) if (e != null) try { stmt.close(); } catch (Throwable localThrowable11) { e.addSuppressed(localThrowable11); } else stmt.close();
/* 1112 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/*      */         }
/* 1115 */         this.createdRoles.clear();
/*      */       }
/*      */       
/*      */ 
/* 1119 */       if ((!this.modifiedRoles.isEmpty()) && (this.roleAndGroupDescriptionCol != null)) {
/* 1120 */         temp = new StringBuilder("UPDATE ");
/* 1121 */         temp.append(this.roleTable);
/* 1122 */         temp.append(" SET ").append(this.roleAndGroupDescriptionCol);
/* 1123 */         temp.append(" = ? WHERE ").append(this.roleNameCol);
/* 1124 */         temp.append(" = ?");
/* 1125 */         for (Role role : this.modifiedRoles.values()) {
/* 1126 */           try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString());e = null;
/* 1127 */             try { stmt.setString(1, role.getDescription());
/* 1128 */               stmt.setString(2, role.getRolename());
/* 1129 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable79)
/*      */             {
/* 1126 */               e = localThrowable79;throw localThrowable79;
/*      */             }
/*      */             finally
/*      */             {
/* 1130 */               if (stmt != null) if (e != null) try { stmt.close(); } catch (Throwable localThrowable14) { e.addSuppressed(localThrowable14); } else stmt.close();
/* 1131 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/*      */         }
/* 1134 */         this.modifiedRoles.clear();
/*      */       }
/*      */     }
/* 1137 */     else if ((this.userRoleTable != null) && (this.roleNameCol != null))
/*      */     {
/* 1139 */       tempRelationDelete = new StringBuilder("DELETE FROM ");
/* 1140 */       tempRelationDelete.append(this.userRoleTable);
/* 1141 */       tempRelationDelete.append(" WHERE ");
/* 1142 */       tempRelationDelete.append(this.roleNameCol);
/* 1143 */       tempRelationDelete.append(" = ?");
/* 1144 */       for (Role role : this.removedRoles.values()) {
/* 1145 */         try { PreparedStatement stmt = dbConnection.prepareStatement(tempRelationDelete.toString());e = null;
/* 1146 */           try { stmt.setString(1, role.getRolename());
/* 1147 */             stmt.executeUpdate();
/*      */           }
/*      */           catch (Throwable localThrowable81)
/*      */           {
/* 1145 */             e = localThrowable81;throw localThrowable81;
/*      */           }
/*      */           finally {
/* 1148 */             if (stmt != null) if (e != null) try { stmt.close(); } catch (Throwable localThrowable17) { e.addSuppressed(localThrowable17); } else stmt.close();
/* 1149 */           } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */         }
/*      */       }
/* 1152 */       this.removedRoles.clear();
/*      */     }
/*      */     Object roles;
/* 1155 */     if (isGroupStoreDefined())
/*      */     {
/* 1157 */       tempRelation = new StringBuilder("INSERT INTO ");
/* 1158 */       tempRelation.append(this.groupRoleTable);
/* 1159 */       tempRelation.append('(').append(this.groupNameCol).append(", ");
/* 1160 */       tempRelation.append(this.roleNameCol);
/* 1161 */       tempRelation.append(") VALUES (?, ?)");
/* 1162 */       String groupRoleRelation = tempRelation.toString();
/*      */       
/* 1164 */       tempRelationDelete = new StringBuilder("DELETE FROM ");
/* 1165 */       tempRelationDelete.append(this.groupRoleTable);
/* 1166 */       tempRelationDelete.append(" WHERE ");
/* 1167 */       tempRelationDelete.append(this.groupNameCol);
/* 1168 */       tempRelationDelete.append(" = ?");
/* 1169 */       String groupRoleRelationDelete = tempRelationDelete.toString();
/*      */       
/*      */       StringBuilder tempRelationDelete2;
/* 1172 */       if (!this.removedGroups.isEmpty()) {
/* 1173 */         temp = new StringBuilder("DELETE FROM ");
/* 1174 */         temp.append(this.groupTable);
/* 1175 */         temp.append(" WHERE ").append(this.groupNameCol);
/* 1176 */         temp.append(" = ?");
/* 1177 */         tempRelationDelete2 = new StringBuilder("DELETE FROM ");
/* 1178 */         tempRelationDelete2.append(this.userGroupTable);
/* 1179 */         tempRelationDelete2.append(" WHERE ");
/* 1180 */         tempRelationDelete2.append(this.groupNameCol);
/* 1181 */         tempRelationDelete2.append(" = ?");
/* 1182 */         for (Group group : this.removedGroups.values()) { Throwable localThrowable82;
/* 1183 */           try { PreparedStatement stmt = dbConnection.prepareStatement(groupRoleRelationDelete);localThrowable82 = null;
/* 1184 */             try { stmt.setString(1, group.getGroupname());
/* 1185 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable19)
/*      */             {
/* 1183 */               localThrowable82 = localThrowable19;throw localThrowable19;
/*      */             }
/*      */             finally {
/* 1186 */               if (stmt != null) if (localThrowable82 != null) try { stmt.close(); } catch (Throwable localThrowable20) { localThrowable82.addSuppressed(localThrowable20); } else stmt.close();
/* 1187 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/* 1189 */           try { PreparedStatement stmt = dbConnection.prepareStatement(tempRelationDelete2.toString());localThrowable82 = null;
/* 1190 */             try { stmt.setString(1, group.getGroupname());
/* 1191 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable22)
/*      */             {
/* 1189 */               localThrowable82 = localThrowable22;throw localThrowable22;
/*      */             }
/*      */             finally {
/* 1192 */               if (stmt != null) if (localThrowable82 != null) try { stmt.close(); } catch (Throwable localThrowable23) { localThrowable82.addSuppressed(localThrowable23); } else stmt.close();
/* 1193 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/* 1195 */           try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString());localThrowable82 = null;
/* 1196 */             try { stmt.setString(1, group.getGroupname());
/* 1197 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable25)
/*      */             {
/* 1195 */               localThrowable82 = localThrowable25;throw localThrowable25;
/*      */             }
/*      */             finally {
/* 1198 */               if (stmt != null) if (localThrowable82 != null) try { stmt.close(); } catch (Throwable localThrowable26) { localThrowable82.addSuppressed(localThrowable26); } else stmt.close();
/* 1199 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/*      */         }
/* 1202 */         this.removedGroups.clear();
/*      */       }
/*      */       
/*      */       Role role;
/* 1206 */       if (!this.createdGroups.isEmpty()) {
/* 1207 */         temp = new StringBuilder("INSERT INTO ");
/* 1208 */         temp.append(this.groupTable);
/* 1209 */         temp.append('(').append(this.groupNameCol);
/* 1210 */         if (this.roleAndGroupDescriptionCol != null) {
/* 1211 */           temp.append(',').append(this.roleAndGroupDescriptionCol);
/*      */         }
/* 1213 */         temp.append(") VALUES (?");
/* 1214 */         if (this.roleAndGroupDescriptionCol != null) {
/* 1215 */           temp.append(", ?");
/*      */         }
/* 1217 */         temp.append(')');
/* 1218 */         for (Group group : this.createdGroups.values()) {
/* 1219 */           try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString());e = null;
/* 1220 */             try { stmt.setString(1, group.getGroupname());
/* 1221 */               if (this.roleAndGroupDescriptionCol != null) {
/* 1222 */                 stmt.setString(2, group.getDescription());
/*      */               }
/* 1224 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable84)
/*      */             {
/* 1219 */               e = localThrowable84;throw localThrowable84;
/*      */ 
/*      */             }
/*      */             finally
/*      */             {
/*      */ 
/* 1225 */               if (stmt != null) if (e != null) try { stmt.close(); } catch (Throwable localThrowable29) { e.addSuppressed(localThrowable29); } else stmt.close();
/* 1226 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/* 1228 */           Object roles = group.getRoles();
/* 1229 */           while (((Iterator)roles).hasNext()) {
/* 1230 */             role = (Role)((Iterator)roles).next();
/* 1231 */             try { PreparedStatement stmt = dbConnection.prepareStatement(groupRoleRelation);localThrowable25 = null;
/* 1232 */               try { stmt.setString(1, group.getGroupname());
/* 1233 */                 stmt.setString(2, role.getRolename());
/* 1234 */                 stmt.executeUpdate();
/*      */               }
/*      */               catch (Throwable localThrowable90)
/*      */               {
/* 1231 */                 localThrowable25 = localThrowable90;throw localThrowable90;
/*      */               }
/*      */               finally
/*      */               {
/* 1235 */                 if (stmt != null) if (localThrowable25 != null) try { stmt.close(); } catch (Throwable localThrowable32) { localThrowable25.addSuppressed(localThrowable32); } else stmt.close();
/* 1236 */               } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */             }
/*      */           }
/*      */         }
/* 1240 */         this.createdGroups.clear();
/*      */       }
/*      */       
/*      */ 
/* 1244 */       if (!this.modifiedGroups.isEmpty()) {
/* 1245 */         if (this.roleAndGroupDescriptionCol != null) {
/* 1246 */           temp = new StringBuilder("UPDATE ");
/* 1247 */           temp.append(this.groupTable);
/* 1248 */           temp.append(" SET ").append(this.roleAndGroupDescriptionCol);
/* 1249 */           temp.append(" = ? WHERE ").append(this.groupNameCol);
/* 1250 */           temp.append(" = ?");
/*      */         }
/* 1252 */         for (Group group : this.modifiedGroups.values()) {
/* 1253 */           if (temp != null)
/* 1254 */             try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString());role = null;
/* 1255 */               try { stmt.setString(1, group.getDescription());
/* 1256 */                 stmt.setString(2, group.getGroupname());
/* 1257 */                 stmt.executeUpdate();
/*      */               }
/*      */               catch (Throwable localThrowable86)
/*      */               {
/* 1254 */                 role = localThrowable86;throw localThrowable86;
/*      */               }
/*      */               finally
/*      */               {
/* 1258 */                 if (stmt != null) if (role != null) try { stmt.close(); } catch (Throwable localThrowable35) { role.addSuppressed(localThrowable35); } else stmt.close();
/* 1259 */               } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */             }
/*      */           try {
/* 1262 */             PreparedStatement stmt = dbConnection.prepareStatement(groupRoleRelationDelete);role = null;
/* 1263 */             try { stmt.setString(1, group.getGroupname());
/* 1264 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable88)
/*      */             {
/* 1262 */               role = localThrowable88;throw localThrowable88;
/*      */             }
/*      */             finally {
/* 1265 */               if (stmt != null) if (role != null) try { stmt.close(); } catch (Throwable localThrowable38) { role.addSuppressed(localThrowable38); } else stmt.close();
/* 1266 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/* 1268 */           roles = group.getRoles();
/* 1269 */           while (((Iterator)roles).hasNext()) {
/* 1270 */             Role role = (Role)((Iterator)roles).next();
/* 1271 */             try { PreparedStatement stmt = dbConnection.prepareStatement(groupRoleRelation);localThrowable25 = null;
/* 1272 */               try { stmt.setString(1, group.getGroupname());
/* 1273 */                 stmt.setString(2, role.getRolename());
/* 1274 */                 stmt.executeUpdate();
/*      */               }
/*      */               catch (Throwable localThrowable92)
/*      */               {
/* 1271 */                 localThrowable25 = localThrowable92;throw localThrowable92;
/*      */               }
/*      */               finally
/*      */               {
/* 1275 */                 if (stmt != null) if (localThrowable25 != null) try { stmt.close(); } catch (Throwable localThrowable41) { localThrowable25.addSuppressed(localThrowable41); } else stmt.close();
/* 1276 */               } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */             }
/*      */           }
/*      */         }
/* 1280 */         this.modifiedGroups.clear();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1285 */     String userRoleRelation = null;
/* 1286 */     String userRoleRelationDelete = null;
/* 1287 */     if ((this.userRoleTable != null) && (this.roleNameCol != null)) {
/* 1288 */       tempRelation = new StringBuilder("INSERT INTO ");
/* 1289 */       tempRelation.append(this.userRoleTable);
/* 1290 */       tempRelation.append('(').append(this.userNameCol).append(", ");
/* 1291 */       tempRelation.append(this.roleNameCol);
/* 1292 */       tempRelation.append(") VALUES (?, ?)");
/* 1293 */       userRoleRelation = tempRelation.toString();
/*      */       
/* 1295 */       tempRelationDelete = new StringBuilder("DELETE FROM ");
/* 1296 */       tempRelationDelete.append(this.userRoleTable);
/* 1297 */       tempRelationDelete.append(" WHERE ");
/* 1298 */       tempRelationDelete.append(this.userNameCol);
/* 1299 */       tempRelationDelete.append(" = ?");
/* 1300 */       userRoleRelationDelete = tempRelationDelete.toString();
/*      */     }
/* 1302 */     String userGroupRelation = null;
/* 1303 */     String userGroupRelationDelete = null;
/* 1304 */     if (isGroupStoreDefined()) {
/* 1305 */       tempRelation = new StringBuilder("INSERT INTO ");
/* 1306 */       tempRelation.append(this.userGroupTable);
/* 1307 */       tempRelation.append('(').append(this.userNameCol).append(", ");
/* 1308 */       tempRelation.append(this.groupNameCol);
/* 1309 */       tempRelation.append(") VALUES (?, ?)");
/* 1310 */       userGroupRelation = tempRelation.toString();
/*      */       
/* 1312 */       tempRelationDelete = new StringBuilder("DELETE FROM ");
/* 1313 */       tempRelationDelete.append(this.userGroupTable);
/* 1314 */       tempRelationDelete.append(" WHERE ");
/* 1315 */       tempRelationDelete.append(this.userNameCol);
/* 1316 */       tempRelationDelete.append(" = ?");
/* 1317 */       userGroupRelationDelete = tempRelationDelete.toString();
/*      */     }
/*      */     
/*      */ 
/* 1321 */     if (!this.removedUsers.isEmpty()) {
/* 1322 */       temp = new StringBuilder("DELETE FROM ");
/* 1323 */       temp.append(this.userTable);
/* 1324 */       temp.append(" WHERE ").append(this.userNameCol);
/* 1325 */       temp.append(" = ?");
/* 1326 */       for (roles = this.removedUsers.values().iterator(); ((Iterator)roles).hasNext();) { User user = (User)((Iterator)roles).next();
/* 1327 */         if (userRoleRelationDelete != null) {
/* 1328 */           try { PreparedStatement stmt = dbConnection.prepareStatement(userRoleRelationDelete);localThrowable25 = null;
/* 1329 */             try { stmt.setString(1, user.getUsername());
/* 1330 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable94)
/*      */             {
/* 1328 */               localThrowable25 = localThrowable94;throw localThrowable94;
/*      */             }
/*      */             finally {
/* 1331 */               if (stmt != null) if (localThrowable25 != null) try { stmt.close(); } catch (Throwable localThrowable44) { localThrowable25.addSuppressed(localThrowable44); } else stmt.close();
/* 1332 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/*      */         }
/* 1335 */         if (userGroupRelationDelete != null)
/* 1336 */           try { PreparedStatement stmt = dbConnection.prepareStatement(userGroupRelationDelete);localThrowable25 = null;
/* 1337 */             try { stmt.setString(1, user.getUsername());
/* 1338 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable96)
/*      */             {
/* 1336 */               localThrowable25 = localThrowable96;throw localThrowable96;
/*      */             }
/*      */             finally {
/* 1339 */               if (stmt != null) if (localThrowable25 != null) try { stmt.close(); } catch (Throwable localThrowable47) { localThrowable25.addSuppressed(localThrowable47); } else stmt.close();
/* 1340 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/*      */         try {
/* 1343 */           PreparedStatement stmt = dbConnection.prepareStatement(temp.toString());localThrowable25 = null;
/* 1344 */           try { stmt.setString(1, user.getUsername());
/* 1345 */             stmt.executeUpdate();
/*      */           }
/*      */           catch (Throwable localThrowable98)
/*      */           {
/* 1343 */             localThrowable25 = localThrowable98;throw localThrowable98;
/*      */           }
/*      */           finally {
/* 1346 */             if (stmt != null) if (localThrowable25 != null) try { stmt.close(); } catch (Throwable localThrowable50) { localThrowable25.addSuppressed(localThrowable50); } else stmt.close();
/* 1347 */           } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */         }
/*      */       }
/* 1350 */       this.removedUsers.clear();
/*      */     }
/*      */     
/*      */     Group group;
/* 1354 */     if (!this.createdUsers.isEmpty()) {
/* 1355 */       temp = new StringBuilder("INSERT INTO ");
/* 1356 */       temp.append(this.userTable);
/* 1357 */       temp.append('(').append(this.userNameCol);
/* 1358 */       temp.append(", ").append(this.userCredCol);
/* 1359 */       if (this.userFullNameCol != null) {
/* 1360 */         temp.append(',').append(this.userFullNameCol);
/*      */       }
/* 1362 */       temp.append(") VALUES (?, ?");
/* 1363 */       if (this.userFullNameCol != null) {
/* 1364 */         temp.append(", ?");
/*      */       }
/* 1366 */       temp.append(')');
/* 1367 */       for (roles = this.createdUsers.values().iterator(); ((Iterator)roles).hasNext();) { User user = (User)((Iterator)roles).next();
/* 1368 */         try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString());localThrowable25 = null;
/* 1369 */           try { stmt.setString(1, user.getUsername());
/* 1370 */             stmt.setString(2, user.getPassword());
/* 1371 */             if (this.userFullNameCol != null) {
/* 1372 */               stmt.setString(3, user.getFullName());
/*      */             }
/* 1374 */             stmt.executeUpdate();
/*      */           }
/*      */           catch (Throwable localThrowable100)
/*      */           {
/* 1368 */             localThrowable25 = localThrowable100;throw localThrowable100;
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/* 1375 */             if (stmt != null) if (localThrowable25 != null) try { stmt.close(); } catch (Throwable localThrowable53) { localThrowable25.addSuppressed(localThrowable53); } else stmt.close();
/* 1376 */           } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */         }
/* 1378 */         if (userRoleRelation != null) {
/* 1379 */           Object roles = user.getRoles();
/* 1380 */           while (((Iterator)roles).hasNext()) {
/* 1381 */             Role role = (Role)((Iterator)roles).next();
/* 1382 */             try { PreparedStatement stmt = dbConnection.prepareStatement(userRoleRelation);localThrowable5 = null;
/* 1383 */               try { stmt.setString(1, user.getUsername());
/* 1384 */                 stmt.setString(2, role.getRolename());
/* 1385 */                 stmt.executeUpdate();
/*      */               }
/*      */               catch (Throwable localThrowable108)
/*      */               {
/* 1382 */                 localThrowable5 = localThrowable108;throw localThrowable108;
/*      */               }
/*      */               finally
/*      */               {
/* 1386 */                 if (stmt != null) if (localThrowable5 != null) try { stmt.close(); } catch (Throwable localThrowable56) { localThrowable5.addSuppressed(localThrowable56); } else stmt.close();
/* 1387 */               } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */             }
/*      */           }
/*      */         }
/* 1391 */         if (userGroupRelation != null) {
/* 1392 */           Object groups = user.getGroups();
/* 1393 */           while (((Iterator)groups).hasNext()) {
/* 1394 */             group = (Group)((Iterator)groups).next();
/* 1395 */             try { PreparedStatement stmt = dbConnection.prepareStatement(userGroupRelation);localThrowable5 = null;
/* 1396 */               try { stmt.setString(1, user.getUsername());
/* 1397 */                 stmt.setString(2, group.getGroupname());
/* 1398 */                 stmt.executeUpdate();
/*      */               }
/*      */               catch (Throwable localThrowable110)
/*      */               {
/* 1395 */                 localThrowable5 = localThrowable110;throw localThrowable110;
/*      */               }
/*      */               finally
/*      */               {
/* 1399 */                 if (stmt != null) if (localThrowable5 != null) try { stmt.close(); } catch (Throwable localThrowable59) { localThrowable5.addSuppressed(localThrowable59); } else stmt.close();
/* 1400 */               } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1405 */       this.createdUsers.clear();
/*      */     }
/*      */     
/*      */ 
/* 1409 */     if (!this.modifiedUsers.isEmpty()) {
/* 1410 */       temp = new StringBuilder("UPDATE ");
/* 1411 */       temp.append(this.userTable);
/* 1412 */       temp.append(" SET ").append(this.userCredCol);
/* 1413 */       temp.append(" = ?");
/* 1414 */       if (this.userFullNameCol != null) {
/* 1415 */         temp.append(", ").append(this.userFullNameCol).append(" = ?");
/*      */       }
/* 1417 */       temp.append(" WHERE ").append(this.userNameCol);
/* 1418 */       temp.append(" = ?");
/* 1419 */       for (roles = this.modifiedUsers.values().iterator(); ((Iterator)roles).hasNext();) { User user = (User)((Iterator)roles).next();
/* 1420 */         try { PreparedStatement stmt = dbConnection.prepareStatement(temp.toString());group = null;
/* 1421 */           try { stmt.setString(1, user.getPassword());
/* 1422 */             if (this.userFullNameCol != null) {
/* 1423 */               stmt.setString(2, user.getFullName());
/* 1424 */               stmt.setString(3, user.getUsername());
/*      */             } else {
/* 1426 */               stmt.setString(2, user.getUsername());
/*      */             }
/* 1428 */             stmt.executeUpdate();
/*      */           }
/*      */           catch (Throwable localThrowable102)
/*      */           {
/* 1420 */             group = localThrowable102;throw localThrowable102;
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           finally
/*      */           {
/*      */ 
/*      */ 
/* 1429 */             if (stmt != null) if (group != null) try { stmt.close(); } catch (Throwable localThrowable62) { group.addSuppressed(localThrowable62); } else stmt.close();
/* 1430 */           } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */         }
/* 1432 */         if (userRoleRelationDelete != null) {
/* 1433 */           try { PreparedStatement stmt = dbConnection.prepareStatement(userRoleRelationDelete);group = null;
/* 1434 */             try { stmt.setString(1, user.getUsername());
/* 1435 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable104)
/*      */             {
/* 1433 */               group = localThrowable104;throw localThrowable104;
/*      */             }
/*      */             finally {
/* 1436 */               if (stmt != null) if (group != null) try { stmt.close(); } catch (Throwable localThrowable65) { group.addSuppressed(localThrowable65); } else stmt.close();
/* 1437 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/*      */         }
/* 1440 */         if (userGroupRelationDelete != null) {
/* 1441 */           try { PreparedStatement stmt = dbConnection.prepareStatement(userGroupRelationDelete);group = null;
/* 1442 */             try { stmt.setString(1, user.getUsername());
/* 1443 */               stmt.executeUpdate();
/*      */             }
/*      */             catch (Throwable localThrowable106)
/*      */             {
/* 1441 */               group = localThrowable106;throw localThrowable106;
/*      */             }
/*      */             finally {
/* 1444 */               if (stmt != null) if (group != null) try { stmt.close(); } catch (Throwable localThrowable68) { group.addSuppressed(localThrowable68); } else stmt.close();
/* 1445 */             } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */           }
/*      */         }
/* 1448 */         if (userRoleRelation != null) {
/* 1449 */           Object roles = user.getRoles();
/* 1450 */           while (((Iterator)roles).hasNext()) {
/* 1451 */             Role role = (Role)((Iterator)roles).next();
/* 1452 */             try { PreparedStatement stmt = dbConnection.prepareStatement(userRoleRelation);localThrowable5 = null;
/* 1453 */               try { stmt.setString(1, user.getUsername());
/* 1454 */                 stmt.setString(2, role.getRolename());
/* 1455 */                 stmt.executeUpdate();
/*      */               }
/*      */               catch (Throwable localThrowable112)
/*      */               {
/* 1452 */                 localThrowable5 = localThrowable112;throw localThrowable112;
/*      */               }
/*      */               finally
/*      */               {
/* 1456 */                 if (stmt != null) if (localThrowable5 != null) try { stmt.close(); } catch (Throwable localThrowable71) { localThrowable5.addSuppressed(localThrowable71); } else stmt.close();
/* 1457 */               } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */             }
/*      */           }
/*      */         }
/* 1461 */         if (userGroupRelation != null) {
/* 1462 */           Object groups = user.getGroups();
/* 1463 */           while (((Iterator)groups).hasNext()) {
/* 1464 */             Group group = (Group)((Iterator)groups).next();
/* 1465 */             try { PreparedStatement stmt = dbConnection.prepareStatement(userGroupRelation);localThrowable5 = null;
/* 1466 */               try { stmt.setString(1, user.getUsername());
/* 1467 */                 stmt.setString(2, group.getGroupname());
/* 1468 */                 stmt.executeUpdate();
/*      */               }
/*      */               catch (Throwable localThrowable114)
/*      */               {
/* 1465 */                 localThrowable5 = localThrowable114;throw localThrowable114;
/*      */               }
/*      */               finally
/*      */               {
/* 1469 */                 if (stmt != null) if (localThrowable5 != null) try { stmt.close(); } catch (Throwable localThrowable74) { localThrowable5.addSuppressed(localThrowable74); } else stmt.close();
/* 1470 */               } } catch (SQLException e) { log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1475 */       this.modifiedGroups.clear();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isAvailable()
/*      */   {
/* 1482 */     return this.connectionSuccess;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isGroupStoreDefined()
/*      */   {
/* 1490 */     return (this.groupTable != null) && (this.userGroupTable != null) && (this.groupNameCol != null) && (this.groupRoleTable != null) && 
/* 1491 */       (isRoleStoreDefined());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isRoleStoreDefined()
/*      */   {
/* 1500 */     return (this.roleTable != null) && (this.userRoleTable != null) && (this.roleNameCol != null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Connection openConnection()
/*      */   {
/* 1510 */     if (this.dataSource == null) {
/* 1511 */       return null;
/*      */     }
/*      */     try {
/* 1514 */       Connection connection = this.dataSource.getConnection();
/* 1515 */       this.connectionSuccess = true;
/* 1516 */       return connection;
/*      */     } catch (Exception e) {
/* 1518 */       this.connectionSuccess = false;
/*      */       
/* 1520 */       log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */     }
/* 1522 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void closeConnection(Connection dbConnection)
/*      */   {
/* 1533 */     if (dbConnection == null) {
/* 1534 */       return;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1539 */       if (!dbConnection.getAutoCommit()) {
/* 1540 */         dbConnection.commit();
/*      */       }
/*      */     } catch (SQLException e) {
/* 1543 */       log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1548 */       dbConnection.close();
/*      */     } catch (SQLException e) {
/* 1550 */       log.error(sm.getString("dataSourceUserDatabase.exception"), e);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\users\DataSourceUserDatabase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */