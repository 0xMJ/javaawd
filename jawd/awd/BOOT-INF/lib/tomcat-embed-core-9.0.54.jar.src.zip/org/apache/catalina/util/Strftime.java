/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Strftime
/*     */ {
/*  51 */   protected static final Properties translate = new Properties();
/*  52 */   static { translate.put("a", "EEE");
/*  53 */     translate.put("A", "EEEE");
/*  54 */     translate.put("b", "MMM");
/*  55 */     translate.put("B", "MMMM");
/*  56 */     translate.put("c", "EEE MMM d HH:mm:ss yyyy");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  61 */     translate.put("d", "dd");
/*  62 */     translate.put("D", "MM/dd/yy");
/*  63 */     translate.put("e", "dd");
/*  64 */     translate.put("F", "yyyy-MM-dd");
/*  65 */     translate.put("g", "yy");
/*  66 */     translate.put("G", "yyyy");
/*  67 */     translate.put("H", "HH");
/*  68 */     translate.put("h", "MMM");
/*  69 */     translate.put("I", "hh");
/*  70 */     translate.put("j", "DDD");
/*  71 */     translate.put("k", "HH");
/*  72 */     translate.put("l", "hh");
/*  73 */     translate.put("m", "MM");
/*  74 */     translate.put("M", "mm");
/*  75 */     translate.put("n", "\n");
/*  76 */     translate.put("p", "a");
/*  77 */     translate.put("P", "a");
/*  78 */     translate.put("r", "hh:mm:ss a");
/*  79 */     translate.put("R", "HH:mm");
/*     */     
/*     */ 
/*  82 */     translate.put("S", "ss");
/*  83 */     translate.put("t", "\t");
/*  84 */     translate.put("T", "HH:mm:ss");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */     translate.put("V", "ww");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */     translate.put("X", "HH:mm:ss");
/*  99 */     translate.put("x", "MM/dd/yy");
/* 100 */     translate.put("y", "yy");
/* 101 */     translate.put("Y", "yyyy");
/* 102 */     translate.put("Z", "z");
/* 103 */     translate.put("z", "Z");
/* 104 */     translate.put("%", "%");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Strftime(String origFormat, Locale locale)
/*     */   {
/* 115 */     String convertedFormat = convertDateFormat(origFormat);
/* 116 */     this.simpleDateFormat = new SimpleDateFormat(convertedFormat, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String format(Date date)
/*     */   {
/* 126 */     return this.simpleDateFormat.format(date);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TimeZone getTimeZone()
/*     */   {
/* 135 */     return this.simpleDateFormat.getTimeZone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeZone(TimeZone timeZone)
/*     */   {
/* 145 */     this.simpleDateFormat.setTimeZone(timeZone);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String convertDateFormat(String pattern)
/*     */   {
/* 157 */     boolean inside = false;
/* 158 */     boolean mark = false;
/* 159 */     boolean modifiedCommand = false;
/*     */     
/* 161 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 163 */     for (int i = 0; i < pattern.length(); i++) {
/* 164 */       char c = pattern.charAt(i);
/*     */       
/* 166 */       if ((c == '%') && (!mark)) {
/* 167 */         mark = true;
/*     */       }
/* 169 */       else if (mark) {
/* 170 */         if (modifiedCommand)
/*     */         {
/* 172 */           modifiedCommand = false;
/* 173 */           mark = false;
/*     */         } else {
/* 175 */           inside = translateCommand(buf, pattern, i, inside);
/*     */           
/* 177 */           if ((c == 'O') || (c == 'E')) {
/* 178 */             modifiedCommand = true;
/*     */           } else {
/* 180 */             mark = false;
/*     */           }
/*     */         }
/*     */       } else {
/* 184 */         if ((!inside) && (c != ' '))
/*     */         {
/* 186 */           buf.append('\'');
/* 187 */           inside = true;
/*     */         }
/*     */         
/* 190 */         buf.append(c);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 195 */     if (buf.length() > 0) {
/* 196 */       char lastChar = buf.charAt(buf.length() - 1);
/*     */       
/* 198 */       if ((lastChar != '\'') && (inside)) {
/* 199 */         buf.append('\'');
/*     */       }
/*     */     }
/* 202 */     return buf.toString();
/*     */   }
/*     */   
/*     */   protected String quote(String str, boolean insideQuotes) {
/* 206 */     String retVal = str;
/* 207 */     if (!insideQuotes) {
/* 208 */       retVal = '\'' + retVal + '\'';
/*     */     }
/* 210 */     return retVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final SimpleDateFormat simpleDateFormat;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean translateCommand(StringBuilder buf, String pattern, int index, boolean oldInside)
/*     */   {
/* 224 */     char firstChar = pattern.charAt(index);
/* 225 */     boolean newInside = oldInside;
/*     */     
/*     */ 
/*     */ 
/* 229 */     if ((firstChar == 'O') || (firstChar == 'E')) {
/* 230 */       if (index + 1 < pattern.length()) {
/* 231 */         newInside = translateCommand(buf, pattern, index + 1, oldInside);
/*     */       } else {
/* 233 */         buf.append(quote("%" + firstChar, oldInside));
/*     */       }
/*     */     } else {
/* 236 */       String command = translate.getProperty(String.valueOf(firstChar));
/*     */       
/*     */ 
/* 239 */       if (command == null) {
/* 240 */         buf.append(quote("%" + firstChar, oldInside));
/*     */       }
/*     */       else {
/* 243 */         if (oldInside) {
/* 244 */           buf.append('\'');
/*     */         }
/* 246 */         buf.append(command);
/* 247 */         newInside = false;
/*     */       }
/*     */     }
/* 250 */     return newInside;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\Strftime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */