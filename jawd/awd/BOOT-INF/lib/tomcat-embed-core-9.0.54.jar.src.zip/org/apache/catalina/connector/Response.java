/*      */ package org.apache.catalina.connector;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.nio.charset.Charset;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Enumeration;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.function.Supplier;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.SessionTrackingMode;
/*      */ import javax.servlet.http.Cookie;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpServletResponseWrapper;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.security.SecurityUtil;
/*      */ import org.apache.catalina.util.SessionConfig;
/*      */ import org.apache.coyote.ActionCode;
/*      */ import org.apache.coyote.Constants;
/*      */ import org.apache.coyote.ContinueResponseTiming;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.buf.CharChunk;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.buf.UEncoder;
/*      */ import org.apache.tomcat.util.buf.UEncoder.SafeCharsSet;
/*      */ import org.apache.tomcat.util.buf.UriUtil;
/*      */ import org.apache.tomcat.util.http.CookieProcessor;
/*      */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*      */ import org.apache.tomcat.util.http.MimeHeaders;
/*      */ import org.apache.tomcat.util.http.parser.MediaTypeCache;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.Escape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Response
/*      */   implements HttpServletResponse
/*      */ {
/*   75 */   private static final Log log = LogFactory.getLog(Response.class);
/*   76 */   protected static final StringManager sm = StringManager.getManager(Response.class);
/*      */   
/*   78 */   private static final MediaTypeCache MEDIA_TYPE_CACHE = new MediaTypeCache(100);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   89 */   private static final boolean ENFORCE_ENCODING_IN_GET_WRITER = Boolean.parseBoolean(
/*   90 */     System.getProperty("org.apache.catalina.connector.Response.ENFORCE_ENCODING_IN_GET_WRITER", "true"));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*  102 */   protected SimpleDateFormat format = null;
/*      */   protected org.apache.coyote.Response coyoteResponse;
/*      */   protected final OutputBuffer outputBuffer;
/*      */   
/*      */   public Response() {
/*  107 */     this(8192);
/*      */   }
/*      */   
/*      */   public Response(int outputBufferSize)
/*      */   {
/*  112 */     this.outputBuffer = new OutputBuffer(outputBufferSize);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCoyoteResponse(org.apache.coyote.Response coyoteResponse)
/*      */   {
/*  129 */     this.coyoteResponse = coyoteResponse;
/*  130 */     this.outputBuffer.setResponse(coyoteResponse);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public org.apache.coyote.Response getCoyoteResponse()
/*      */   {
/*  137 */     return this.coyoteResponse;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context getContext()
/*      */   {
/*  145 */     return this.request.getContext();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected CoyoteOutputStream outputStream;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected CoyoteWriter writer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  170 */   protected boolean appCommitted = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  176 */   protected boolean included = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  182 */   private boolean isCharacterEncodingSet = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  188 */   protected boolean usingOutputStream = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  194 */   protected boolean usingWriter = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  200 */   protected final UEncoder urlEncoder = new UEncoder(UEncoder.SafeCharsSet.WITH_SLASH);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  206 */   protected final CharChunk redirectURLCC = new CharChunk();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  213 */   private final List<Cookie> cookies = new ArrayList();
/*      */   
/*  215 */   private HttpServletResponse applicationResponse = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void recycle()
/*      */   {
/*  226 */     this.cookies.clear();
/*  227 */     this.outputBuffer.recycle();
/*  228 */     this.usingOutputStream = false;
/*  229 */     this.usingWriter = false;
/*  230 */     this.appCommitted = false;
/*  231 */     this.included = false;
/*  232 */     this.isCharacterEncodingSet = false;
/*      */     
/*  234 */     this.applicationResponse = null;
/*  235 */     if (getRequest().getDiscardFacades()) {
/*  236 */       if (this.facade != null) {
/*  237 */         this.facade.clear();
/*  238 */         this.facade = null;
/*      */       }
/*  240 */       if (this.outputStream != null) {
/*  241 */         this.outputStream.clear();
/*  242 */         this.outputStream = null;
/*      */       }
/*  244 */       if (this.writer != null) {
/*  245 */         this.writer.clear();
/*  246 */         this.writer = null;
/*      */       }
/*  248 */     } else if (this.writer != null) {
/*  249 */       this.writer.recycle();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public List<Cookie> getCookies()
/*      */   {
/*  256 */     return this.cookies;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getContentWritten()
/*      */   {
/*  268 */     return this.outputBuffer.getContentWritten();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getBytesWritten(boolean flush)
/*      */   {
/*  278 */     if (flush) {
/*      */       try {
/*  280 */         this.outputBuffer.flush();
/*      */       }
/*      */       catch (IOException localIOException) {}
/*      */     }
/*      */     
/*  285 */     return getCoyoteResponse().getBytesWritten(flush);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAppCommitted(boolean appCommitted)
/*      */   {
/*  294 */     this.appCommitted = appCommitted;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAppCommitted()
/*      */   {
/*  304 */     return (this.appCommitted) || (isCommitted()) || (isSuspended()) || (
/*  305 */       (getContentLength() > 0) && 
/*  306 */       (getContentWritten() >= getContentLength()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  313 */   protected Request request = null;
/*      */   
/*      */ 
/*      */ 
/*      */   public Request getRequest()
/*      */   {
/*  319 */     return this.request;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequest(Request request)
/*      */   {
/*  328 */     this.request = request;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  335 */   protected ResponseFacade facade = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HttpServletResponse getResponse()
/*      */   {
/*  343 */     if (this.facade == null) {
/*  344 */       this.facade = new ResponseFacade(this);
/*      */     }
/*  346 */     if (this.applicationResponse == null) {
/*  347 */       this.applicationResponse = this.facade;
/*      */     }
/*  349 */     return this.applicationResponse;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setResponse(HttpServletResponse applicationResponse)
/*      */   {
/*  364 */     ServletResponse r = applicationResponse;
/*  365 */     while ((r instanceof HttpServletResponseWrapper)) {
/*  366 */       r = ((HttpServletResponseWrapper)r).getResponse();
/*      */     }
/*  368 */     if (r != this.facade) {
/*  369 */       throw new IllegalArgumentException(sm.getString("response.illegalWrap"));
/*      */     }
/*  371 */     this.applicationResponse = applicationResponse;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSuspended(boolean suspended)
/*      */   {
/*  381 */     this.outputBuffer.setSuspended(suspended);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSuspended()
/*      */   {
/*  391 */     return this.outputBuffer.isSuspended();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isClosed()
/*      */   {
/*  401 */     return this.outputBuffer.isClosed();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setError()
/*      */   {
/*  411 */     return getCoyoteResponse().setError();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isError()
/*      */   {
/*  421 */     return getCoyoteResponse().isError();
/*      */   }
/*      */   
/*      */   public boolean isErrorReportRequired()
/*      */   {
/*  426 */     return getCoyoteResponse().isErrorReportRequired();
/*      */   }
/*      */   
/*      */   public boolean setErrorReported()
/*      */   {
/*  431 */     return getCoyoteResponse().setErrorReported();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void finishResponse()
/*      */     throws IOException
/*      */   {
/*  443 */     this.outputBuffer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getContentLength()
/*      */   {
/*  451 */     return getCoyoteResponse().getContentLength();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getContentType()
/*      */   {
/*  461 */     return getCoyoteResponse().getContentType();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PrintWriter getReporter()
/*      */     throws IOException
/*      */   {
/*  478 */     if (this.outputBuffer.isNew()) {
/*  479 */       this.outputBuffer.checkConverter();
/*  480 */       if (this.writer == null) {
/*  481 */         this.writer = new CoyoteWriter(this.outputBuffer);
/*      */       }
/*  483 */       return this.writer;
/*      */     }
/*  485 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void flushBuffer()
/*      */     throws IOException
/*      */   {
/*  500 */     this.outputBuffer.flush();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getBufferSize()
/*      */   {
/*  509 */     return this.outputBuffer.getBufferSize();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCharacterEncoding()
/*      */   {
/*  518 */     String charset = getCoyoteResponse().getCharacterEncoding();
/*  519 */     if (charset != null) {
/*  520 */       return charset;
/*      */     }
/*      */     
/*  523 */     Context context = getContext();
/*  524 */     String result = null;
/*  525 */     if (context != null) {
/*  526 */       result = context.getResponseCharacterEncoding();
/*      */     }
/*      */     
/*  529 */     if (result == null) {
/*  530 */       result = Constants.DEFAULT_BODY_CHARSET.name();
/*      */     }
/*      */     
/*  533 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServletOutputStream getOutputStream()
/*      */     throws IOException
/*      */   {
/*  548 */     if (this.usingWriter)
/*      */     {
/*  550 */       throw new IllegalStateException(sm.getString("coyoteResponse.getOutputStream.ise"));
/*      */     }
/*      */     
/*  553 */     this.usingOutputStream = true;
/*  554 */     if (this.outputStream == null) {
/*  555 */       this.outputStream = new CoyoteOutputStream(this.outputBuffer);
/*      */     }
/*  557 */     return this.outputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Locale getLocale()
/*      */   {
/*  567 */     return getCoyoteResponse().getLocale();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PrintWriter getWriter()
/*      */     throws IOException
/*      */   {
/*  582 */     if (this.usingOutputStream)
/*      */     {
/*  584 */       throw new IllegalStateException(sm.getString("coyoteResponse.getWriter.ise"));
/*      */     }
/*      */     
/*  587 */     if (ENFORCE_ENCODING_IN_GET_WRITER)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  600 */       setCharacterEncoding(getCharacterEncoding());
/*      */     }
/*      */     
/*  603 */     this.usingWriter = true;
/*  604 */     this.outputBuffer.checkConverter();
/*  605 */     if (this.writer == null) {
/*  606 */       this.writer = new CoyoteWriter(this.outputBuffer);
/*      */     }
/*  608 */     return this.writer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCommitted()
/*      */   {
/*  619 */     return getCoyoteResponse().isCommitted();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reset()
/*      */   {
/*  632 */     if (this.included) {
/*  633 */       return;
/*      */     }
/*      */     
/*  636 */     getCoyoteResponse().reset();
/*  637 */     this.outputBuffer.reset();
/*  638 */     this.usingOutputStream = false;
/*  639 */     this.usingWriter = false;
/*  640 */     this.isCharacterEncodingSet = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetBuffer()
/*      */   {
/*  652 */     resetBuffer(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetBuffer(boolean resetWriterStreamFlags)
/*      */   {
/*  669 */     if (isCommitted())
/*      */     {
/*  671 */       throw new IllegalStateException(sm.getString("coyoteResponse.resetBuffer.ise"));
/*      */     }
/*      */     
/*  674 */     this.outputBuffer.reset(resetWriterStreamFlags);
/*      */     
/*  676 */     if (resetWriterStreamFlags) {
/*  677 */       this.usingOutputStream = false;
/*  678 */       this.usingWriter = false;
/*  679 */       this.isCharacterEncodingSet = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBufferSize(int size)
/*      */   {
/*  696 */     if ((isCommitted()) || (!this.outputBuffer.isNew()))
/*      */     {
/*  698 */       throw new IllegalStateException(sm.getString("coyoteResponse.setBufferSize.ise"));
/*      */     }
/*      */     
/*  701 */     this.outputBuffer.setBufferSize(size);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContentLength(int length)
/*      */   {
/*  714 */     setContentLengthLong(length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setContentLengthLong(long length)
/*      */   {
/*  720 */     if (isCommitted()) {
/*  721 */       return;
/*      */     }
/*      */     
/*      */ 
/*  725 */     if (this.included) {
/*  726 */       return;
/*      */     }
/*      */     
/*  729 */     getCoyoteResponse().setContentLength(length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContentType(String type)
/*      */   {
/*  741 */     if (isCommitted()) {
/*  742 */       return;
/*      */     }
/*      */     
/*      */ 
/*  746 */     if (this.included) {
/*  747 */       return;
/*      */     }
/*      */     
/*  750 */     if (type == null) {
/*  751 */       getCoyoteResponse().setContentType(null);
/*      */       try {
/*  753 */         getCoyoteResponse().setCharacterEncoding(null);
/*      */       }
/*      */       catch (UnsupportedEncodingException localUnsupportedEncodingException1) {}
/*      */       
/*  757 */       this.isCharacterEncodingSet = false;
/*  758 */       return;
/*      */     }
/*      */     
/*  761 */     String[] m = MEDIA_TYPE_CACHE.parse(type);
/*  762 */     if (m == null)
/*      */     {
/*      */ 
/*  765 */       getCoyoteResponse().setContentTypeNoCharset(type);
/*  766 */       return;
/*      */     }
/*      */     
/*      */ 
/*  770 */     if (m[1] == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  775 */       getCoyoteResponse().setContentTypeNoCharset(type);
/*      */     }
/*      */     else {
/*  778 */       getCoyoteResponse().setContentTypeNoCharset(m[0]);
/*      */       
/*      */ 
/*  781 */       if (!this.usingWriter) {
/*      */         try {
/*  783 */           getCoyoteResponse().setCharacterEncoding(m[1]);
/*      */         } catch (UnsupportedEncodingException e) {
/*  785 */           log.warn(sm.getString("coyoteResponse.encoding.invalid", new Object[] { m[1] }), e);
/*      */         }
/*      */         
/*  788 */         this.isCharacterEncodingSet = true;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCharacterEncoding(String charset)
/*      */   {
/*  804 */     if (isCommitted()) {
/*  805 */       return;
/*      */     }
/*      */     
/*      */ 
/*  809 */     if (this.included) {
/*  810 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  815 */     if (this.usingWriter) {
/*  816 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  820 */       getCoyoteResponse().setCharacterEncoding(charset);
/*      */     } catch (UnsupportedEncodingException e) {
/*  822 */       log.warn(sm.getString("coyoteResponse.encoding.invalid", new Object[] { charset }), e);
/*  823 */       return;
/*      */     }
/*  825 */     if (charset == null) {
/*  826 */       this.isCharacterEncodingSet = false;
/*      */     } else {
/*  828 */       this.isCharacterEncodingSet = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocale(Locale locale)
/*      */   {
/*  842 */     if (isCommitted()) {
/*  843 */       return;
/*      */     }
/*      */     
/*      */ 
/*  847 */     if (this.included) {
/*  848 */       return;
/*      */     }
/*      */     
/*  851 */     getCoyoteResponse().setLocale(locale);
/*      */     
/*      */ 
/*      */ 
/*  855 */     if (this.usingWriter) {
/*  856 */       return;
/*      */     }
/*      */     
/*  859 */     if (this.isCharacterEncodingSet) {
/*  860 */       return;
/*      */     }
/*      */     
/*  863 */     if (locale == null) {
/*      */       try {
/*  865 */         getCoyoteResponse().setCharacterEncoding(null);
/*      */ 
/*      */       }
/*      */       catch (UnsupportedEncodingException localUnsupportedEncodingException1) {}
/*      */     }
/*      */     else
/*      */     {
/*  872 */       Context context = getContext();
/*  873 */       if (context != null) {
/*  874 */         String charset = context.getCharset(locale);
/*  875 */         if (charset != null) {
/*      */           try {
/*  877 */             getCoyoteResponse().setCharacterEncoding(charset);
/*      */           } catch (UnsupportedEncodingException e) {
/*  879 */             log.warn(sm.getString("coyoteResponse.encoding.invalid", new Object[] { charset }), e);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getHeader(String name)
/*      */   {
/*  892 */     return getCoyoteResponse().getMimeHeaders().getHeader(name);
/*      */   }
/*      */   
/*      */ 
/*      */   public Collection<String> getHeaderNames()
/*      */   {
/*  898 */     MimeHeaders headers = getCoyoteResponse().getMimeHeaders();
/*  899 */     int n = headers.size();
/*  900 */     List<String> result = new ArrayList(n);
/*  901 */     for (int i = 0; i < n; i++) {
/*  902 */       result.add(headers.getName(i).toString());
/*      */     }
/*  904 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Collection<String> getHeaders(String name)
/*      */   {
/*  911 */     Enumeration<String> enumeration = getCoyoteResponse().getMimeHeaders().values(name);
/*  912 */     Set<String> result = new LinkedHashSet();
/*  913 */     while (enumeration.hasMoreElements()) {
/*  914 */       result.add(enumeration.nextElement());
/*      */     }
/*  916 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMessage()
/*      */   {
/*  925 */     return getCoyoteResponse().getMessage();
/*      */   }
/*      */   
/*      */ 
/*      */   public int getStatus()
/*      */   {
/*  931 */     return getCoyoteResponse().getStatus();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCookie(Cookie cookie)
/*      */   {
/*  947 */     if ((this.included) || (isCommitted())) {
/*  948 */       return;
/*      */     }
/*      */     
/*  951 */     this.cookies.add(cookie);
/*      */     
/*  953 */     String header = generateCookieString(cookie);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  958 */     addHeader("Set-Cookie", header, getContext().getCookieProcessor().getCharset());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSessionCookieInternal(Cookie cookie)
/*      */   {
/*  968 */     if (isCommitted()) {
/*  969 */       return;
/*      */     }
/*      */     
/*  972 */     String name = cookie.getName();
/*  973 */     String headername = "Set-Cookie";
/*  974 */     String startsWith = name + "=";
/*  975 */     String header = generateCookieString(cookie);
/*  976 */     boolean set = false;
/*  977 */     MimeHeaders headers = getCoyoteResponse().getMimeHeaders();
/*  978 */     int n = headers.size();
/*  979 */     for (int i = 0; i < n; i++) {
/*  980 */       if ((headers.getName(i).toString().equals("Set-Cookie")) && 
/*  981 */         (headers.getValue(i).toString().startsWith(startsWith))) {
/*  982 */         headers.getValue(i).setString(header);
/*  983 */         set = true;
/*      */       }
/*      */     }
/*      */     
/*  987 */     if (!set) {
/*  988 */       addHeader("Set-Cookie", header);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String generateCookieString(Cookie cookie)
/*      */   {
/*  997 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*  998 */       return (String)AccessController.doPrivileged(new PrivilegedGenerateCookieString(
/*  999 */         getContext(), cookie, this.request.getRequest()));
/*      */     }
/* 1001 */     return getContext().getCookieProcessor().generateHeader(cookie, this.request.getRequest());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addDateHeader(String name, long value)
/*      */   {
/* 1015 */     if ((name == null) || (name.length() == 0)) {
/* 1016 */       return;
/*      */     }
/*      */     
/* 1019 */     if (isCommitted()) {
/* 1020 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1024 */     if (this.included) {
/* 1025 */       return;
/*      */     }
/*      */     
/* 1028 */     addHeader(name, FastHttpDateFormat.formatDate(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addHeader(String name, String value)
/*      */   {
/* 1040 */     addHeader(name, value, null);
/*      */   }
/*      */   
/*      */ 
/*      */   private void addHeader(String name, String value, Charset charset)
/*      */   {
/* 1046 */     if ((name == null) || (name.length() == 0) || (value == null)) {
/* 1047 */       return;
/*      */     }
/*      */     
/* 1050 */     if (isCommitted()) {
/* 1051 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1055 */     if (this.included) {
/* 1056 */       return;
/*      */     }
/*      */     
/* 1059 */     char cc = name.charAt(0);
/* 1060 */     if (((cc == 'C') || (cc == 'c')) && 
/* 1061 */       (checkSpecialHeader(name, value))) {
/* 1062 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1066 */     getCoyoteResponse().addHeader(name, value, charset);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean checkSpecialHeader(String name, String value)
/*      */   {
/* 1080 */     if (name.equalsIgnoreCase("Content-Type")) {
/* 1081 */       setContentType(value);
/* 1082 */       return true;
/*      */     }
/* 1084 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addIntHeader(String name, int value)
/*      */   {
/* 1097 */     if ((name == null) || (name.length() == 0)) {
/* 1098 */       return;
/*      */     }
/*      */     
/* 1101 */     if (isCommitted()) {
/* 1102 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1106 */     if (this.included) {
/* 1107 */       return;
/*      */     }
/*      */     
/* 1110 */     addHeader(name, "" + value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsHeader(String name)
/*      */   {
/* 1125 */     char cc = name.charAt(0);
/* 1126 */     if ((cc == 'C') || (cc == 'c')) {
/* 1127 */       if (name.equalsIgnoreCase("Content-Type"))
/*      */       {
/* 1129 */         return getCoyoteResponse().getContentType() != null;
/*      */       }
/* 1131 */       if (name.equalsIgnoreCase("Content-Length"))
/*      */       {
/* 1133 */         return getCoyoteResponse().getContentLengthLong() != -1L;
/*      */       }
/*      */     }
/*      */     
/* 1137 */     return getCoyoteResponse().containsHeader(name);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTrailerFields(Supplier<Map<String, String>> supplier)
/*      */   {
/* 1143 */     getCoyoteResponse().setTrailerFields(supplier);
/*      */   }
/*      */   
/*      */ 
/*      */   public Supplier<Map<String, String>> getTrailerFields()
/*      */   {
/* 1149 */     return getCoyoteResponse().getTrailerFields();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String encodeRedirectURL(String url)
/*      */   {
/* 1162 */     if (isEncodeable(toAbsolute(url))) {
/* 1163 */       return toEncoded(url, this.request.getSessionInternal().getIdInternal());
/*      */     }
/* 1165 */     return url;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String encodeRedirectUrl(String url)
/*      */   {
/* 1183 */     return encodeRedirectURL(url);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String encodeURL(String url)
/*      */   {
/*      */     try
/*      */     {
/* 1199 */       absolute = toAbsolute(url);
/*      */     } catch (IllegalArgumentException iae) {
/*      */       String absolute;
/* 1202 */       return url;
/*      */     }
/*      */     String absolute;
/* 1205 */     if (isEncodeable(absolute))
/*      */     {
/* 1207 */       if (url.equalsIgnoreCase("")) {
/* 1208 */         url = absolute;
/* 1209 */       } else if ((url.equals(absolute)) && (!hasPath(url))) {
/* 1210 */         url = url + '/';
/*      */       }
/* 1212 */       return toEncoded(url, this.request.getSessionInternal().getIdInternal());
/*      */     }
/* 1214 */     return url;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String encodeUrl(String url)
/*      */   {
/* 1233 */     return encodeURL(url);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void sendAcknowledgement()
/*      */     throws IOException
/*      */   {
/* 1247 */     sendAcknowledgement(ContinueResponseTiming.ALWAYS);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendAcknowledgement(ContinueResponseTiming continueResponseTiming)
/*      */     throws IOException
/*      */   {
/* 1262 */     if (isCommitted()) {
/* 1263 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1267 */     if (this.included) {
/* 1268 */       return;
/*      */     }
/*      */     
/* 1271 */     getCoyoteResponse().action(ActionCode.ACK, continueResponseTiming);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendError(int status)
/*      */     throws IOException
/*      */   {
/* 1287 */     sendError(status, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendError(int status, String message)
/*      */     throws IOException
/*      */   {
/* 1304 */     if (isCommitted())
/*      */     {
/* 1306 */       throw new IllegalStateException(sm.getString("coyoteResponse.sendError.ise"));
/*      */     }
/*      */     
/*      */ 
/* 1310 */     if (this.included) {
/* 1311 */       return;
/*      */     }
/*      */     
/* 1314 */     setError();
/*      */     
/* 1316 */     getCoyoteResponse().setStatus(status);
/* 1317 */     getCoyoteResponse().setMessage(message);
/*      */     
/*      */ 
/* 1320 */     resetBuffer();
/*      */     
/*      */ 
/* 1323 */     setSuspended(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendRedirect(String location)
/*      */     throws IOException
/*      */   {
/* 1338 */     sendRedirect(location, 302);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendRedirect(String location, int status)
/*      */     throws IOException
/*      */   {
/* 1352 */     if (isCommitted()) {
/* 1353 */       throw new IllegalStateException(sm.getString("coyoteResponse.sendRedirect.ise"));
/*      */     }
/*      */     
/*      */ 
/* 1357 */     if (this.included) {
/* 1358 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1362 */     resetBuffer(true);
/*      */     
/*      */     try
/*      */     {
/*      */       String locationUri;
/*      */       String locationUri;
/* 1368 */       if ((getRequest().getCoyoteRequest().getSupportsRelativeRedirects()) && 
/* 1369 */         (getContext().getUseRelativeRedirects())) {
/* 1370 */         locationUri = location;
/*      */       } else {
/* 1372 */         locationUri = toAbsolute(location);
/*      */       }
/* 1374 */       setStatus(status);
/* 1375 */       setHeader("Location", locationUri);
/* 1376 */       if (getContext().getSendRedirectBody()) {
/* 1377 */         PrintWriter writer = getWriter();
/* 1378 */         writer.print(sm.getString("coyoteResponse.sendRedirect.note", new Object[] {
/* 1379 */           Escape.htmlElementContent(locationUri) }));
/* 1380 */         flushBuffer();
/*      */       }
/*      */     } catch (IllegalArgumentException e) {
/* 1383 */       log.warn(sm.getString("response.sendRedirectFail", new Object[] { location }), e);
/* 1384 */       setStatus(404);
/*      */     }
/*      */     
/*      */ 
/* 1388 */     setSuspended(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDateHeader(String name, long value)
/*      */   {
/* 1401 */     if ((name == null) || (name.length() == 0)) {
/* 1402 */       return;
/*      */     }
/*      */     
/* 1405 */     if (isCommitted()) {
/* 1406 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1410 */     if (this.included) {
/* 1411 */       return;
/*      */     }
/*      */     
/* 1414 */     setHeader(name, FastHttpDateFormat.formatDate(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeader(String name, String value)
/*      */   {
/* 1427 */     if ((name == null) || (name.length() == 0) || (value == null)) {
/* 1428 */       return;
/*      */     }
/*      */     
/* 1431 */     if (isCommitted()) {
/* 1432 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1436 */     if (this.included) {
/* 1437 */       return;
/*      */     }
/*      */     
/* 1440 */     char cc = name.charAt(0);
/* 1441 */     if (((cc == 'C') || (cc == 'c')) && 
/* 1442 */       (checkSpecialHeader(name, value))) {
/* 1443 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1447 */     getCoyoteResponse().setHeader(name, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIntHeader(String name, int value)
/*      */   {
/* 1460 */     if ((name == null) || (name.length() == 0)) {
/* 1461 */       return;
/*      */     }
/*      */     
/* 1464 */     if (isCommitted()) {
/* 1465 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1469 */     if (this.included) {
/* 1470 */       return;
/*      */     }
/*      */     
/* 1473 */     setHeader(name, "" + value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStatus(int status)
/*      */   {
/* 1485 */     setStatus(status, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setStatus(int status, String message)
/*      */   {
/* 1503 */     if (isCommitted()) {
/* 1504 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1508 */     if (this.included) {
/* 1509 */       return;
/*      */     }
/*      */     
/* 1512 */     getCoyoteResponse().setStatus(status);
/* 1513 */     getCoyoteResponse().setMessage(message);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isEncodeable(String location)
/*      */   {
/* 1536 */     if (location == null) {
/* 1537 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1541 */     if (location.startsWith("#")) {
/* 1542 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1546 */     Request hreq = this.request;
/* 1547 */     Session session = hreq.getSessionInternal(false);
/* 1548 */     if (session == null) {
/* 1549 */       return false;
/*      */     }
/* 1551 */     if (hreq.isRequestedSessionIdFromCookie()) {
/* 1552 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1557 */     if (!hreq.getServletContext().getEffectiveSessionTrackingModes().contains(SessionTrackingMode.URL)) {
/* 1558 */       return false;
/*      */     }
/*      */     
/* 1561 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/* 1562 */       Boolean result = (Boolean)AccessController.doPrivileged(new PrivilegedDoIsEncodable(
/* 1563 */         getContext(), hreq, session, location));
/* 1564 */       return result.booleanValue();
/*      */     }
/* 1566 */     return doIsEncodeable(getContext(), hreq, session, location);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean doIsEncodeable(Context context, Request hreq, Session session, String location)
/*      */   {
/* 1574 */     URL url = null;
/*      */     try {
/* 1576 */       url = new URL(location);
/*      */     } catch (MalformedURLException e) {
/* 1578 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1582 */     if (!hreq.getScheme().equalsIgnoreCase(url.getProtocol())) {
/* 1583 */       return false;
/*      */     }
/* 1585 */     if (!hreq.getServerName().equalsIgnoreCase(url.getHost())) {
/* 1586 */       return false;
/*      */     }
/* 1588 */     int serverPort = hreq.getServerPort();
/* 1589 */     if (serverPort == -1) {
/* 1590 */       if ("https".equals(hreq.getScheme())) {
/* 1591 */         serverPort = 443;
/*      */       } else {
/* 1593 */         serverPort = 80;
/*      */       }
/*      */     }
/* 1596 */     int urlPort = url.getPort();
/* 1597 */     if (urlPort == -1) {
/* 1598 */       if ("https".equals(url.getProtocol())) {
/* 1599 */         urlPort = 443;
/*      */       } else {
/* 1601 */         urlPort = 80;
/*      */       }
/*      */     }
/* 1604 */     if (serverPort != urlPort) {
/* 1605 */       return false;
/*      */     }
/*      */     
/* 1608 */     String contextPath = context.getPath();
/* 1609 */     if (contextPath != null) {
/* 1610 */       String file = url.getFile();
/* 1611 */       if (!file.startsWith(contextPath)) {
/* 1612 */         return false;
/*      */       }
/*      */       
/* 1615 */       String tok = ";" + SessionConfig.getSessionUriParamName(context) + "=" + session.getIdInternal();
/* 1616 */       if (file.indexOf(tok, contextPath.length()) >= 0) {
/* 1617 */         return false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1622 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String toAbsolute(String location)
/*      */   {
/* 1640 */     if (location == null) {
/* 1641 */       return location;
/*      */     }
/*      */     
/* 1644 */     boolean leadingSlash = location.startsWith("/");
/*      */     
/* 1646 */     if (location.startsWith("//"))
/*      */     {
/* 1648 */       this.redirectURLCC.recycle();
/*      */       
/* 1650 */       String scheme = this.request.getScheme();
/*      */       try {
/* 1652 */         this.redirectURLCC.append(scheme, 0, scheme.length());
/* 1653 */         this.redirectURLCC.append(':');
/* 1654 */         this.redirectURLCC.append(location, 0, location.length());
/* 1655 */         return this.redirectURLCC.toString();
/*      */       } catch (IOException e) {
/* 1657 */         throw new IllegalArgumentException(location, e);
/*      */       }
/*      */     }
/* 1660 */     if ((leadingSlash) || (!UriUtil.hasScheme(location)))
/*      */     {
/* 1662 */       this.redirectURLCC.recycle();
/*      */       
/* 1664 */       String scheme = this.request.getScheme();
/* 1665 */       String name = this.request.getServerName();
/* 1666 */       int port = this.request.getServerPort();
/*      */       try
/*      */       {
/* 1669 */         this.redirectURLCC.append(scheme, 0, scheme.length());
/* 1670 */         this.redirectURLCC.append("://", 0, 3);
/* 1671 */         this.redirectURLCC.append(name, 0, name.length());
/* 1672 */         if (((scheme.equals("http")) && (port != 80)) || (
/* 1673 */           (scheme.equals("https")) && (port != 443))) {
/* 1674 */           this.redirectURLCC.append(':');
/* 1675 */           String portS = port + "";
/* 1676 */           this.redirectURLCC.append(portS, 0, portS.length());
/*      */         }
/* 1678 */         if (!leadingSlash) {
/* 1679 */           String relativePath = this.request.getDecodedRequestURI();
/* 1680 */           int pos = relativePath.lastIndexOf('/');
/* 1681 */           CharChunk encodedURI = null;
/* 1682 */           if (SecurityUtil.isPackageProtectionEnabled()) {
/*      */             try {
/* 1684 */               encodedURI = (CharChunk)AccessController.doPrivileged(new PrivilegedEncodeUrl(this.urlEncoder, relativePath, pos));
/*      */             }
/*      */             catch (PrivilegedActionException pae) {
/* 1687 */               throw new IllegalArgumentException(location, pae.getException());
/*      */             }
/*      */           } else {
/* 1690 */             encodedURI = this.urlEncoder.encodeURL(relativePath, 0, pos);
/*      */           }
/* 1692 */           this.redirectURLCC.append(encodedURI);
/* 1693 */           encodedURI.recycle();
/* 1694 */           this.redirectURLCC.append('/');
/*      */         }
/* 1696 */         this.redirectURLCC.append(location, 0, location.length());
/*      */         
/* 1698 */         normalize(this.redirectURLCC);
/*      */       } catch (IOException e) {
/* 1700 */         throw new IllegalArgumentException(location, e);
/*      */       }
/*      */       
/* 1703 */       return this.redirectURLCC.toString();
/*      */     }
/*      */     
/*      */ 
/* 1707 */     return location;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void normalize(CharChunk cc)
/*      */   {
/* 1722 */     int truncate = cc.indexOf('?');
/* 1723 */     if (truncate == -1) {
/* 1724 */       truncate = cc.indexOf('#');
/*      */     }
/* 1726 */     char[] truncateCC = null;
/* 1727 */     if (truncate > -1) {
/* 1728 */       truncateCC = Arrays.copyOfRange(cc.getBuffer(), cc
/* 1729 */         .getStart() + truncate, cc.getEnd());
/* 1730 */       cc.setEnd(cc.getStart() + truncate);
/*      */     }
/*      */     
/* 1733 */     if ((cc.endsWith("/.")) || (cc.endsWith("/.."))) {
/*      */       try {
/* 1735 */         cc.append('/');
/*      */       } catch (IOException e) {
/* 1737 */         throw new IllegalArgumentException(cc.toString(), e);
/*      */       }
/*      */     }
/*      */     
/* 1741 */     char[] c = cc.getChars();
/* 1742 */     int start = cc.getStart();
/* 1743 */     int end = cc.getEnd();
/* 1744 */     int index = 0;
/* 1745 */     int startIndex = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1750 */     for (int i = 0; i < 3; i++) {
/* 1751 */       startIndex = cc.indexOf('/', startIndex + 1);
/*      */     }
/*      */     
/*      */ 
/* 1755 */     index = startIndex;
/*      */     for (;;) {
/* 1757 */       index = cc.indexOf("/./", 0, 3, index);
/* 1758 */       if (index < 0) {
/*      */         break;
/*      */       }
/* 1761 */       copyChars(c, start + index, start + index + 2, end - start - index - 2);
/*      */       
/* 1763 */       end -= 2;
/* 1764 */       cc.setEnd(end);
/*      */     }
/*      */     
/*      */ 
/* 1768 */     index = startIndex;
/*      */     for (;;)
/*      */     {
/* 1771 */       index = cc.indexOf("/../", 0, 4, index);
/* 1772 */       if (index < 0) {
/*      */         break;
/*      */       }
/*      */       
/* 1776 */       if (index == startIndex) {
/* 1777 */         throw new IllegalArgumentException();
/*      */       }
/* 1779 */       int index2 = -1;
/* 1780 */       for (int pos = start + index - 1; (pos >= 0) && (index2 < 0); pos--) {
/* 1781 */         if (c[pos] == '/') {
/* 1782 */           index2 = pos;
/*      */         }
/*      */       }
/* 1785 */       copyChars(c, start + index2, start + index + 3, end - start - index - 3);
/*      */       
/* 1787 */       end = end + index2 - index - 3;
/* 1788 */       cc.setEnd(end);
/* 1789 */       index = index2;
/*      */     }
/*      */     
/*      */ 
/* 1793 */     if (truncateCC != null) {
/*      */       try {
/* 1795 */         cc.append(truncateCC, 0, truncateCC.length);
/*      */       } catch (IOException ioe) {
/* 1797 */         throw new IllegalArgumentException(ioe);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void copyChars(char[] c, int dest, int src, int len) {
/* 1803 */     System.arraycopy(c, src, c, dest, len);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean hasPath(String uri)
/*      */   {
/* 1814 */     int pos = uri.indexOf("://");
/* 1815 */     if (pos < 0) {
/* 1816 */       return false;
/*      */     }
/* 1818 */     pos = uri.indexOf('/', pos + 3);
/* 1819 */     if (pos < 0) {
/* 1820 */       return false;
/*      */     }
/* 1822 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String toEncoded(String url, String sessionId)
/*      */   {
/* 1834 */     if ((url == null) || (sessionId == null)) {
/* 1835 */       return url;
/*      */     }
/*      */     
/* 1838 */     String path = url;
/* 1839 */     String query = "";
/* 1840 */     String anchor = "";
/* 1841 */     int question = url.indexOf('?');
/* 1842 */     if (question >= 0) {
/* 1843 */       path = url.substring(0, question);
/* 1844 */       query = url.substring(question);
/*      */     }
/* 1846 */     int pound = path.indexOf('#');
/* 1847 */     if (pound >= 0) {
/* 1848 */       anchor = path.substring(pound);
/* 1849 */       path = path.substring(0, pound);
/*      */     }
/* 1851 */     StringBuilder sb = new StringBuilder(path);
/* 1852 */     if (sb.length() > 0) {
/* 1853 */       sb.append(';');
/* 1854 */       sb.append(SessionConfig.getSessionUriParamName(this.request
/* 1855 */         .getContext()));
/* 1856 */       sb.append('=');
/* 1857 */       sb.append(sessionId);
/*      */     }
/* 1859 */     sb.append(anchor);
/* 1860 */     sb.append(query);
/* 1861 */     return sb.toString();
/*      */   }
/*      */   
/*      */   private static class PrivilegedGenerateCookieString implements PrivilegedAction<String>
/*      */   {
/*      */     private final Context context;
/*      */     private final Cookie cookie;
/*      */     private final HttpServletRequest request;
/*      */     
/*      */     public PrivilegedGenerateCookieString(Context context, Cookie cookie, HttpServletRequest request)
/*      */     {
/* 1872 */       this.context = context;
/* 1873 */       this.cookie = cookie;
/* 1874 */       this.request = request;
/*      */     }
/*      */     
/*      */     public String run()
/*      */     {
/* 1879 */       return this.context.getCookieProcessor().generateHeader(this.cookie, this.request);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class PrivilegedDoIsEncodable
/*      */     implements PrivilegedAction<Boolean>
/*      */   {
/*      */     private final Context context;
/*      */     private final Request hreq;
/*      */     private final Session session;
/*      */     private final String location;
/*      */     
/*      */     public PrivilegedDoIsEncodable(Context context, Request hreq, Session session, String location)
/*      */     {
/* 1893 */       this.context = context;
/* 1894 */       this.hreq = hreq;
/* 1895 */       this.session = session;
/* 1896 */       this.location = location;
/*      */     }
/*      */     
/*      */     public Boolean run()
/*      */     {
/* 1901 */       return Boolean.valueOf(Response.doIsEncodeable(this.context, this.hreq, this.session, this.location));
/*      */     }
/*      */   }
/*      */   
/*      */   private static class PrivilegedEncodeUrl implements PrivilegedExceptionAction<CharChunk>
/*      */   {
/*      */     private final UEncoder urlEncoder;
/*      */     private final String relativePath;
/*      */     private final int end;
/*      */     
/*      */     public PrivilegedEncodeUrl(UEncoder urlEncoder, String relativePath, int end)
/*      */     {
/* 1913 */       this.urlEncoder = urlEncoder;
/* 1914 */       this.relativePath = relativePath;
/* 1915 */       this.end = end;
/*      */     }
/*      */     
/*      */     public CharChunk run() throws IOException
/*      */     {
/* 1920 */       return this.urlEncoder.encodeURL(this.relativePath, 0, this.end);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\connector\Response.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */