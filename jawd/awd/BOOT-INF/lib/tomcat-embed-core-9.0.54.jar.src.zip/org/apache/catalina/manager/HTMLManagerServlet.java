/*      */ package org.apache.catalina.manager;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.net.InetAddress;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Set;
/*      */ import javax.servlet.RequestDispatcher;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpSession;
/*      */ import javax.servlet.http.Part;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.DistributedManager;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.manager.util.BaseSessionComparator;
/*      */ import org.apache.catalina.manager.util.SessionUtils;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.Escape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class HTMLManagerServlet
/*      */   extends ManagerServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   static final String APPLICATION_MESSAGE = "message";
/*      */   static final String APPLICATION_ERROR = "error";
/*      */   static final String sessionsListJspPath = "/WEB-INF/jsp/sessionsList.jsp";
/*      */   static final String sessionDetailJspPath = "/WEB-INF/jsp/sessionDetail.jsp";
/*      */   static final String connectorCiphersJspPath = "/WEB-INF/jsp/connectorCiphers.jsp";
/*      */   static final String connectorCertsJspPath = "/WEB-INF/jsp/connectorCerts.jsp";
/*      */   static final String connectorTrustedCertsJspPath = "/WEB-INF/jsp/connectorTrustedCerts.jsp";
/*   89 */   private boolean showProxySessions = false;
/*      */   
/*      */   private static final String APPS_HEADER_SECTION = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"6\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"header-left\"><small>{1}</small></td>\n <td class=\"header-left\"><small>{2}</small></td>\n <td class=\"header-center\"><small>{3}</small></td>\n <td class=\"header-center\"><small>{4}</small></td>\n <td class=\"header-left\"><small>{5}</small></td>\n <td class=\"header-left\"><small>{6}</small></td>\n</tr>\n";
/*      */   
/*      */   private static final String APPS_ROW_DETAILS_SECTION = "<tr>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{0}</small></td>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{1}</small></td>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{2}</small></td>\n <td class=\"row-center\" bgcolor=\"{6}\" rowspan=\"2\"><small>{3}</small></td>\n <td class=\"row-center\" bgcolor=\"{6}\" rowspan=\"2\"><small><a href=\"{4}\">{5}</a></small></td>\n";
/*      */   private static final String MANAGER_APP_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\">\n  <small>\n  &nbsp;{1}&nbsp;\n  &nbsp;{3}&nbsp;\n  &nbsp;{5}&nbsp;\n  &nbsp;{7}&nbsp;\n  </small>\n </td>\n</tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n";
/*      */   private static final String STARTED_DEPLOYED_APPS_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\">\n  &nbsp;<small>{1}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">  <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{4}\">  <small><input type=\"submit\" value=\"{5}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{6}\">  &nbsp;&nbsp;<small><input type=\"submit\" value=\"{7}\"></small>  </form>\n </td>\n </tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n";
/*      */   private static final String STOPPED_DEPLOYED_APPS_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\" rowspan=\"2\">\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">  <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  &nbsp;<small>{3}</small>&nbsp;\n  &nbsp;<small>{5}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{6}\">  <small><input type=\"submit\" value=\"{7}\"></small>  </form>\n </td>\n</tr>\n<tr></tr>\n";
/*      */   private static final String STARTED_NONDEPLOYED_APPS_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\">\n  &nbsp;<small>{1}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">  <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{4}\">  <small><input type=\"submit\" value=\"{5}\"></small>  </form>\n  &nbsp;<small>{7}</small>&nbsp;\n </td>\n </tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n";
/*      */   private static final String STOPPED_NONDEPLOYED_APPS_ROW_BUTTON_SECTION = " <td class=\"row-left\" bgcolor=\"{13}\" rowspan=\"2\">\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">  <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  &nbsp;<small>{3}</small>&nbsp;\n  &nbsp;<small>{5}</small>&nbsp;\n  &nbsp;<small>{7}</small>&nbsp;\n </td>\n</tr>\n<tr></tr>\n";
/*      */   private static final String DEPLOY_SECTION = "</table>\n<br>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployPath\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{4}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployVersion\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{5}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployConfig\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{6}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployWar\" size=\"40\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{7}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n";
/*      */   private static final String UPLOAD_SECTION = "<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{0}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{1}\" enctype=\"multipart/form-data\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{2}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"file\" name=\"deployWar\" size=\"40\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{3}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>\n\n";
/*      */   private static final String CONFIG_SECTION = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"tlsHostName\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{4}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>";
/*      */   private static final String DIAGNOSTICS_SECTION = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{2}\">\n   <input type=\"submit\" value=\"{4}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{3}</small>\n </td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{5}</small></td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{6}\">\n   <input type=\"submit\" value=\"{7}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{8}</small>\n </td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{9}\">\n   <input type=\"submit\" value=\"{10}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{11}</small>\n </td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{12}\">\n   <input type=\"submit\" value=\"{13}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{14}</small>\n </td>\n</tr>\n</table>\n<br>";
/*      */   
/*      */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  107 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request
/*  108 */       .getLocales());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  113 */     String command = request.getPathInfo();
/*      */     
/*  115 */     String path = request.getParameter("path");
/*  116 */     ContextName cn = null;
/*  117 */     if (path != null) {
/*  118 */       cn = new ContextName(path, request.getParameter("version"));
/*      */     }
/*      */     
/*      */ 
/*  122 */     response.setContentType("text/html; charset=utf-8");
/*      */     
/*  124 */     String message = "";
/*      */     
/*  126 */     if ((command != null) && (!command.equals("/")))
/*      */     {
/*  128 */       if (!command.equals("/list"))
/*      */       {
/*  130 */         if (command.equals("/sessions")) {
/*      */           try {
/*  132 */             doSessions(cn, request, response, smClient);
/*  133 */             return;
/*      */           } catch (Exception e) {
/*  135 */             log(sm.getString("htmlManagerServlet.error.sessions", new Object[] { cn }), e);
/*  136 */             message = smClient.getString("managerServlet.exception", new Object[] {e
/*  137 */               .toString() });
/*      */           }
/*  139 */         } else if (command.equals("/sslConnectorCiphers")) {
/*  140 */           sslConnectorCiphers(request, response, smClient);
/*  141 */         } else if (command.equals("/sslConnectorCerts")) {
/*  142 */           sslConnectorCerts(request, response, smClient);
/*  143 */         } else if (command.equals("/sslConnectorTrustedCerts")) {
/*  144 */           sslConnectorTrustedCerts(request, response, smClient);
/*  145 */         } else if ((command.equals("/upload")) || (command.equals("/deploy")) || 
/*  146 */           (command.equals("/reload")) || (command.equals("/undeploy")) || 
/*  147 */           (command.equals("/expire")) || (command.equals("/start")) || 
/*  148 */           (command.equals("/stop")))
/*      */         {
/*  150 */           message = smClient.getString("managerServlet.postCommand", new Object[] { command });
/*      */         }
/*      */         else
/*  153 */           message = smClient.getString("managerServlet.unknownCommand", new Object[] { command });
/*      */       }
/*      */     }
/*  156 */     list(request, response, message, smClient);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doPost(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  173 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request
/*  174 */       .getLocales());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  179 */     String command = request.getPathInfo();
/*      */     
/*  181 */     String path = request.getParameter("path");
/*  182 */     ContextName cn = null;
/*  183 */     if (path != null) {
/*  184 */       cn = new ContextName(path, request.getParameter("version"));
/*      */     }
/*      */     
/*  187 */     String deployPath = request.getParameter("deployPath");
/*  188 */     String deployWar = request.getParameter("deployWar");
/*  189 */     String deployConfig = request.getParameter("deployConfig");
/*  190 */     ContextName deployCn = null;
/*  191 */     if ((deployPath != null) && (deployPath.length() > 0)) {
/*  192 */       deployCn = new ContextName(deployPath, request.getParameter("deployVersion"));
/*  193 */     } else if ((deployConfig != null) && (deployConfig.length() > 0)) {
/*  194 */       deployCn = ContextName.extractFromPath(deployConfig);
/*  195 */     } else if ((deployWar != null) && (deployWar.length() > 0)) {
/*  196 */       deployCn = ContextName.extractFromPath(deployWar);
/*      */     }
/*      */     
/*  199 */     String tlsHostName = request.getParameter("tlsHostName");
/*      */     
/*      */ 
/*  202 */     response.setContentType("text/html; charset=utf-8");
/*      */     
/*  204 */     String message = "";
/*      */     
/*  206 */     if ((command != null) && (command.length() != 0))
/*      */     {
/*      */ 
/*  209 */       if (command.equals("/upload")) {
/*  210 */         message = upload(request, smClient);
/*  211 */       } else if (command.equals("/deploy")) {
/*  212 */         message = deployInternal(deployConfig, deployCn, deployWar, smClient);
/*      */       }
/*  214 */       else if (command.equals("/reload")) {
/*  215 */         message = reload(cn, smClient);
/*  216 */       } else if (command.equals("/undeploy")) {
/*  217 */         message = undeploy(cn, smClient);
/*  218 */       } else if (command.equals("/expire")) {
/*  219 */         message = expireSessions(cn, request, smClient);
/*  220 */       } else if (command.equals("/start")) {
/*  221 */         message = start(cn, smClient);
/*  222 */       } else if (command.equals("/stop")) {
/*  223 */         message = stop(cn, smClient);
/*  224 */       } else if (command.equals("/findleaks")) {
/*  225 */         message = findleaks(smClient);
/*  226 */       } else if (command.equals("/sslReload")) {
/*  227 */         message = sslReload(tlsHostName, smClient);
/*      */       }
/*      */       else {
/*  230 */         doGet(request, response);
/*  231 */         return;
/*      */       }
/*      */     }
/*  234 */     list(request, response, message, smClient);
/*      */   }
/*      */   
/*      */   protected String upload(HttpServletRequest request, StringManager smClient)
/*      */   {
/*  239 */     String message = "";
/*      */     
/*      */     try
/*      */     {
/*  243 */       Part warPart = request.getPart("deployWar");
/*  244 */       if (warPart == null) {
/*  245 */         message = smClient.getString("htmlManagerServlet.deployUploadNoFile");
/*      */       }
/*      */       else
/*      */       {
/*  249 */         String filename = warPart.getSubmittedFileName();
/*  250 */         if (!filename.toLowerCase(Locale.ENGLISH).endsWith(".war")) {
/*  251 */           message = smClient.getString("htmlManagerServlet.deployUploadNotWar", new Object[] { filename });
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  256 */           if (filename.lastIndexOf('\\') >= 0)
/*      */           {
/*  258 */             filename = filename.substring(filename.lastIndexOf('\\') + 1);
/*      */           }
/*  260 */           if (filename.lastIndexOf('/') >= 0)
/*      */           {
/*  262 */             filename = filename.substring(filename.lastIndexOf('/') + 1);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  267 */           File file = new File(this.host.getAppBaseFile(), filename);
/*  268 */           if (file.exists()) {
/*  269 */             message = smClient.getString("htmlManagerServlet.deployUploadWarExists", new Object[] { filename });
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*  275 */             ContextName cn = new ContextName(filename, true);
/*  276 */             String name = cn.getName();
/*      */             
/*  278 */             if ((this.host.findChild(name) != null) && (!isDeployed(name))) {
/*  279 */               message = smClient.getString("htmlManagerServlet.deployUploadInServerXml", new Object[] { filename });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/*  285 */             else if (tryAddServiced(name)) {
/*      */               try {
/*  287 */                 warPart.write(file.getAbsolutePath());
/*      */               } finally {
/*  289 */                 removeServiced(name);
/*      */               }
/*      */               
/*  292 */               check(name);
/*      */             } else {
/*  294 */               message = smClient.getString("managerServlet.inService", new Object[] { name });
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/*  300 */       message = smClient.getString("htmlManagerServlet.deployUploadFail", new Object[] { e.getMessage() });
/*  301 */       log(message, e);
/*      */     }
/*  303 */     return message;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String deployInternal(String config, ContextName cn, String war, StringManager smClient)
/*      */   {
/*  319 */     StringWriter stringWriter = new StringWriter();
/*  320 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  322 */     super.deploy(printWriter, config, cn, war, false, smClient);
/*      */     
/*  324 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void list(HttpServletRequest request, HttpServletResponse response, String message, StringManager smClient)
/*      */     throws IOException
/*      */   {
/*  342 */     if (this.debug >= 1) {
/*  343 */       log("list: Listing contexts for virtual host '" + this.host
/*  344 */         .getName() + "'");
/*      */     }
/*      */     
/*  347 */     PrintWriter writer = response.getWriter();
/*      */     
/*  349 */     Object[] args = new Object[2];
/*  350 */     args[0] = request.getContextPath();
/*  351 */     args[1] = smClient.getString("htmlManagerServlet.title");
/*      */     
/*      */ 
/*  354 */     writer.print(MessageFormat.format(Constants.HTML_HEADER_SECTION, args));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  359 */     writer.print(
/*  360 */       MessageFormat.format(Constants.BODY_HEADER_SECTION, args));
/*      */     
/*      */ 
/*  363 */     args = new Object[3];
/*  364 */     args[0] = smClient.getString("htmlManagerServlet.messageLabel");
/*  365 */     if ((message == null) || (message.length() == 0)) {
/*  366 */       args[1] = "OK";
/*      */     } else {
/*  368 */       args[1] = Escape.htmlElementContent(message);
/*      */     }
/*  370 */     writer.print(MessageFormat.format(Constants.MESSAGE_SECTION, args));
/*      */     
/*      */ 
/*  373 */     args = new Object[9];
/*  374 */     args[0] = smClient.getString("htmlManagerServlet.manager");
/*  375 */     args[1] = response.encodeURL(request.getContextPath() + "/html/list");
/*  376 */     args[2] = smClient.getString("htmlManagerServlet.list");
/*  377 */     args[3] = 
/*      */     
/*  379 */       (request.getContextPath() + "/" + smClient.getString("htmlManagerServlet.helpHtmlManagerFile"));
/*  380 */     args[4] = smClient.getString("htmlManagerServlet.helpHtmlManager");
/*  381 */     args[5] = 
/*      */     
/*  383 */       (request.getContextPath() + "/" + smClient.getString("htmlManagerServlet.helpManagerFile"));
/*  384 */     args[6] = smClient.getString("htmlManagerServlet.helpManager");
/*  385 */     args[7] = response
/*  386 */       .encodeURL(request.getContextPath() + "/status");
/*  387 */     args[8] = smClient.getString("statusServlet.title");
/*  388 */     writer.print(MessageFormat.format(Constants.MANAGER_SECTION, args));
/*      */     
/*      */ 
/*  391 */     args = new Object[7];
/*  392 */     args[0] = smClient.getString("htmlManagerServlet.appsTitle");
/*  393 */     args[1] = smClient.getString("htmlManagerServlet.appsPath");
/*  394 */     args[2] = smClient.getString("htmlManagerServlet.appsVersion");
/*  395 */     args[3] = smClient.getString("htmlManagerServlet.appsName");
/*  396 */     args[4] = smClient.getString("htmlManagerServlet.appsAvailable");
/*  397 */     args[5] = smClient.getString("htmlManagerServlet.appsSessions");
/*  398 */     args[6] = smClient.getString("htmlManagerServlet.appsTasks");
/*  399 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"6\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td class=\"header-left\"><small>{1}</small></td>\n <td class=\"header-left\"><small>{2}</small></td>\n <td class=\"header-center\"><small>{3}</small></td>\n <td class=\"header-center\"><small>{4}</small></td>\n <td class=\"header-left\"><small>{5}</small></td>\n <td class=\"header-left\"><small>{6}</small></td>\n</tr>\n", args));
/*      */     
/*      */ 
/*      */ 
/*  403 */     Container[] children = this.host.findChildren();
/*  404 */     String[] contextNames = new String[children.length];
/*  405 */     for (int i = 0; i < children.length; i++) {
/*  406 */       contextNames[i] = children[i].getName();
/*      */     }
/*      */     
/*  409 */     Arrays.sort(contextNames);
/*      */     
/*  411 */     String appsStart = smClient.getString("htmlManagerServlet.appsStart");
/*  412 */     String appsStop = smClient.getString("htmlManagerServlet.appsStop");
/*  413 */     String appsReload = smClient.getString("htmlManagerServlet.appsReload");
/*      */     
/*  415 */     String appsUndeploy = smClient.getString("htmlManagerServlet.appsUndeploy");
/*  416 */     String appsExpire = smClient.getString("htmlManagerServlet.appsExpire");
/*      */     
/*  418 */     String noVersion = "<i>" + smClient.getString("htmlManagerServlet.noVersion") + "</i>";
/*      */     
/*  420 */     boolean isHighlighted = true;
/*  421 */     boolean isDeployed = true;
/*  422 */     String highlightColor = null;
/*      */     
/*  424 */     for (String contextName : contextNames) {
/*  425 */       Context ctxt = (Context)this.host.findChild(contextName);
/*      */       
/*  427 */       if (ctxt != null)
/*      */       {
/*  429 */         isHighlighted = !isHighlighted;
/*  430 */         if (isHighlighted) {
/*  431 */           highlightColor = "#C3F3C3";
/*      */         } else {
/*  433 */           highlightColor = "#FFFFFF";
/*      */         }
/*      */         
/*  436 */         String contextPath = ctxt.getPath();
/*  437 */         String displayPath = contextPath;
/*  438 */         if (displayPath.equals("")) {
/*  439 */           displayPath = "/";
/*      */         }
/*      */         
/*  442 */         StringBuilder tmp = new StringBuilder();
/*  443 */         tmp.append("path=");
/*  444 */         tmp.append(URLEncoder.DEFAULT.encode(displayPath, StandardCharsets.UTF_8));
/*  445 */         String webappVersion = ctxt.getWebappVersion();
/*  446 */         if ((webappVersion != null) && (webappVersion.length() > 0)) {
/*  447 */           tmp.append("&version=");
/*  448 */           tmp.append(URLEncoder.DEFAULT.encode(webappVersion, StandardCharsets.UTF_8));
/*      */         }
/*      */         
/*  451 */         String pathVersion = tmp.toString();
/*      */         try
/*      */         {
/*  454 */           isDeployed = isDeployed(contextName);
/*      */         }
/*      */         catch (Exception e) {
/*  457 */           isDeployed = false;
/*      */         }
/*      */         
/*  460 */         args = new Object[7];
/*  461 */         args[0] = 
/*      */         
/*      */ 
/*      */ 
/*  465 */           ("<a href=\"" + URLEncoder.DEFAULT.encode(new StringBuilder().append(contextPath).append("/").toString(), StandardCharsets.UTF_8) + "\" " + "rel=\"noopener noreferrer\"" + ">" + Escape.htmlElementContent(displayPath) + "</a>");
/*  466 */         if ((webappVersion == null) || (webappVersion.isEmpty())) {
/*  467 */           args[1] = noVersion;
/*      */         } else {
/*  469 */           args[1] = Escape.htmlElementContent(webappVersion);
/*      */         }
/*  471 */         if (ctxt.getDisplayName() == null) {
/*  472 */           args[2] = "&nbsp;";
/*      */         } else {
/*  474 */           args[2] = Escape.htmlElementContent(ctxt.getDisplayName());
/*      */         }
/*  476 */         args[3] = Boolean.valueOf(ctxt.getState().isAvailable());
/*  477 */         args[4] = Escape.htmlElementContent(response.encodeURL(request.getContextPath() + "/html/sessions?" + pathVersion));
/*      */         
/*  479 */         Manager manager = ctxt.getManager();
/*  480 */         if (((manager instanceof DistributedManager)) && (this.showProxySessions)) {
/*  481 */           args[5] = Integer.valueOf(((DistributedManager)manager)
/*  482 */             .getActiveSessionsFull());
/*  483 */         } else if (manager != null) {
/*  484 */           args[5] = Integer.valueOf(manager.getActiveSessions());
/*      */         } else {
/*  486 */           args[5] = Integer.valueOf(0);
/*      */         }
/*      */         
/*  489 */         args[6] = highlightColor;
/*      */         
/*  491 */         writer
/*  492 */           .print(MessageFormat.format("<tr>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{0}</small></td>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{1}</small></td>\n <td class=\"row-left\" bgcolor=\"{6}\" rowspan=\"2\"><small>{2}</small></td>\n <td class=\"row-center\" bgcolor=\"{6}\" rowspan=\"2\"><small>{3}</small></td>\n <td class=\"row-center\" bgcolor=\"{6}\" rowspan=\"2\"><small><a href=\"{4}\">{5}</a></small></td>\n", args));
/*      */         
/*  494 */         args = new Object[14];
/*  495 */         args[0] = Escape.htmlElementContent(response.encodeURL(request
/*  496 */           .getContextPath() + "/html/start?" + pathVersion));
/*  497 */         args[1] = appsStart;
/*  498 */         args[2] = Escape.htmlElementContent(response.encodeURL(request
/*  499 */           .getContextPath() + "/html/stop?" + pathVersion));
/*  500 */         args[3] = appsStop;
/*  501 */         args[4] = Escape.htmlElementContent(response.encodeURL(request
/*  502 */           .getContextPath() + "/html/reload?" + pathVersion));
/*  503 */         args[5] = appsReload;
/*  504 */         args[6] = Escape.htmlElementContent(response.encodeURL(request
/*  505 */           .getContextPath() + "/html/undeploy?" + pathVersion));
/*  506 */         args[7] = appsUndeploy;
/*  507 */         args[8] = Escape.htmlElementContent(response.encodeURL(request
/*  508 */           .getContextPath() + "/html/expire?" + pathVersion));
/*  509 */         args[9] = appsExpire;
/*  510 */         args[10] = smClient.getString("htmlManagerServlet.expire.explain");
/*  511 */         if (manager == null) {
/*  512 */           args[11] = smClient.getString("htmlManagerServlet.noManager");
/*      */         } else {
/*  514 */           args[11] = Integer.valueOf(ctxt.getSessionTimeout());
/*      */         }
/*  516 */         args[12] = smClient.getString("htmlManagerServlet.expire.unit");
/*  517 */         args[13] = highlightColor;
/*      */         
/*  519 */         if (ctxt.getName().equals(this.context.getName())) {
/*  520 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\">\n  <small>\n  &nbsp;{1}&nbsp;\n  &nbsp;{3}&nbsp;\n  &nbsp;{5}&nbsp;\n  &nbsp;{7}&nbsp;\n  </small>\n </td>\n</tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n", args));
/*      */         }
/*  522 */         else if ((ctxt.getState().isAvailable()) && (isDeployed)) {
/*  523 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\">\n  &nbsp;<small>{1}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">  <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{4}\">  <small><input type=\"submit\" value=\"{5}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{6}\">  &nbsp;&nbsp;<small><input type=\"submit\" value=\"{7}\"></small>  </form>\n </td>\n </tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n", args));
/*      */         }
/*  525 */         else if ((ctxt.getState().isAvailable()) && (!isDeployed)) {
/*  526 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\">\n  &nbsp;<small>{1}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{2}\">  <small><input type=\"submit\" value=\"{3}\"></small>  </form>\n  <form class=\"inline\" method=\"POST\" action=\"{4}\">  <small><input type=\"submit\" value=\"{5}\"></small>  </form>\n  &nbsp;<small>{7}</small>&nbsp;\n </td>\n </tr><tr>\n <td class=\"row-left\" bgcolor=\"{13}\">\n  <form method=\"POST\" action=\"{8}\">\n  <small>\n  &nbsp;<input type=\"submit\" value=\"{9}\">&nbsp;{10}&nbsp;<input type=\"text\" name=\"idle\" size=\"5\" value=\"{11}\">&nbsp;{12}&nbsp;\n  </small>\n  </form>\n </td>\n</tr>\n", args));
/*      */         }
/*  528 */         else if ((!ctxt.getState().isAvailable()) && (isDeployed)) {
/*  529 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\" rowspan=\"2\">\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">  <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  &nbsp;<small>{3}</small>&nbsp;\n  &nbsp;<small>{5}</small>&nbsp;\n  <form class=\"inline\" method=\"POST\" action=\"{6}\">  <small><input type=\"submit\" value=\"{7}\"></small>  </form>\n </td>\n</tr>\n<tr></tr>\n", args));
/*      */         }
/*      */         else {
/*  532 */           writer.print(MessageFormat.format(" <td class=\"row-left\" bgcolor=\"{13}\" rowspan=\"2\">\n  <form class=\"inline\" method=\"POST\" action=\"{0}\">  <small><input type=\"submit\" value=\"{1}\"></small>  </form>\n  &nbsp;<small>{3}</small>&nbsp;\n  &nbsp;<small>{5}</small>&nbsp;\n  &nbsp;<small>{7}</small>&nbsp;\n </td>\n</tr>\n<tr></tr>\n", args));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  540 */     args = new Object[8];
/*  541 */     args[0] = smClient.getString("htmlManagerServlet.deployTitle");
/*  542 */     args[1] = smClient.getString("htmlManagerServlet.deployServer");
/*  543 */     args[2] = response.encodeURL(request.getContextPath() + "/html/deploy");
/*  544 */     args[3] = smClient.getString("htmlManagerServlet.deployPath");
/*  545 */     args[4] = smClient.getString("htmlManagerServlet.deployVersion");
/*  546 */     args[5] = smClient.getString("htmlManagerServlet.deployConfig");
/*  547 */     args[6] = smClient.getString("htmlManagerServlet.deployWar");
/*  548 */     args[7] = smClient.getString("htmlManagerServlet.deployButton");
/*  549 */     writer.print(MessageFormat.format("</table>\n<br>\n<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployPath\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{4}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployVersion\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{5}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployConfig\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  <small>{6}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"deployWar\" size=\"40\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{7}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n", args));
/*      */     
/*  551 */     args = new Object[4];
/*  552 */     args[0] = smClient.getString("htmlManagerServlet.deployUpload");
/*  553 */     args[1] = response.encodeURL(request.getContextPath() + "/html/upload");
/*  554 */     args[2] = smClient.getString("htmlManagerServlet.deployUploadFile");
/*  555 */     args[3] = smClient.getString("htmlManagerServlet.deployButton");
/*  556 */     writer.print(MessageFormat.format("<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{0}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{1}\" enctype=\"multipart/form-data\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{2}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"file\" name=\"deployWar\" size=\"40\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{3}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>\n\n", args));
/*      */     
/*      */ 
/*  559 */     args = new Object[5];
/*  560 */     args[0] = smClient.getString("htmlManagerServlet.configTitle");
/*  561 */     args[1] = smClient.getString("htmlManagerServlet.configSslReloadTitle");
/*  562 */     args[2] = response.encodeURL(request.getContextPath() + "/html/sslReload");
/*  563 */     args[3] = smClient.getString("htmlManagerServlet.configSslHostName");
/*  564 */     args[4] = smClient.getString("htmlManagerServlet.configReloadButton");
/*  565 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td colspan=\"2\">\n<form method=\"post\" action=\"{2}\">\n<table cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td class=\"row-right\">\n  <small>{3}</small>\n </td>\n <td class=\"row-left\">\n  <input type=\"text\" name=\"tlsHostName\" size=\"20\">\n </td>\n</tr>\n<tr>\n <td class=\"row-right\">\n  &nbsp;\n </td>\n <td class=\"row-left\">\n  <input type=\"submit\" value=\"{4}\">\n </td>\n</tr>\n</table>\n</form>\n</td>\n</tr>\n</table>\n<br>", args));
/*      */     
/*      */ 
/*  568 */     args = new Object[15];
/*  569 */     args[0] = smClient.getString("htmlManagerServlet.diagnosticsTitle");
/*  570 */     args[1] = smClient.getString("htmlManagerServlet.diagnosticsLeak");
/*  571 */     args[2] = response.encodeURL(request
/*  572 */       .getContextPath() + "/html/findleaks");
/*  573 */     args[3] = smClient.getString("htmlManagerServlet.diagnosticsLeakWarning");
/*  574 */     args[4] = smClient.getString("htmlManagerServlet.diagnosticsLeakButton");
/*  575 */     args[5] = smClient.getString("htmlManagerServlet.diagnosticsSsl");
/*  576 */     args[6] = response.encodeURL(request
/*  577 */       .getContextPath() + "/html/sslConnectorCiphers");
/*  578 */     args[7] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorCipherButton");
/*  579 */     args[8] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorCipherText");
/*  580 */     args[9] = response.encodeURL(request
/*  581 */       .getContextPath() + "/html/sslConnectorCerts");
/*  582 */     args[10] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorCertsButton");
/*  583 */     args[11] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorCertsText");
/*  584 */     args[12] = response.encodeURL(request
/*  585 */       .getContextPath() + "/html/sslConnectorTrustedCerts");
/*  586 */     args[13] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorTrustedCertsButton");
/*  587 */     args[14] = smClient.getString("htmlManagerServlet.diagnosticsSslConnectorTrustedCertsText");
/*  588 */     writer.print(MessageFormat.format("<table border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\n<tr>\n <td colspan=\"2\" class=\"title\">{0}</td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{1}</small></td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{2}\">\n   <input type=\"submit\" value=\"{4}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{3}</small>\n </td>\n</tr>\n<tr>\n <td colspan=\"2\" class=\"header-left\"><small>{5}</small></td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{6}\">\n   <input type=\"submit\" value=\"{7}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{8}</small>\n </td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{9}\">\n   <input type=\"submit\" value=\"{10}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{11}</small>\n </td>\n</tr>\n<tr>\n <td class=\"row-left\">\n  <form method=\"post\" action=\"{12}\">\n   <input type=\"submit\" value=\"{13}\">\n  </form>\n </td>\n <td class=\"row-left\">\n  <small>{14}</small>\n </td>\n</tr>\n</table>\n<br>", args));
/*      */     
/*      */ 
/*  591 */     args = new Object[9];
/*  592 */     args[0] = smClient.getString("htmlManagerServlet.serverTitle");
/*  593 */     args[1] = smClient.getString("htmlManagerServlet.serverVersion");
/*  594 */     args[2] = smClient.getString("htmlManagerServlet.serverJVMVersion");
/*  595 */     args[3] = smClient.getString("htmlManagerServlet.serverJVMVendor");
/*  596 */     args[4] = smClient.getString("htmlManagerServlet.serverOSName");
/*  597 */     args[5] = smClient.getString("htmlManagerServlet.serverOSVersion");
/*  598 */     args[6] = smClient.getString("htmlManagerServlet.serverOSArch");
/*  599 */     args[7] = smClient.getString("htmlManagerServlet.serverHostname");
/*  600 */     args[8] = smClient.getString("htmlManagerServlet.serverIPAddress");
/*  601 */     writer.print(
/*  602 */       MessageFormat.format(Constants.SERVER_HEADER_SECTION, args));
/*      */     
/*      */ 
/*  605 */     args = new Object[8];
/*  606 */     args[0] = ServerInfo.getServerInfo();
/*  607 */     args[1] = System.getProperty("java.runtime.version");
/*  608 */     args[2] = System.getProperty("java.vm.vendor");
/*  609 */     args[3] = System.getProperty("os.name");
/*  610 */     args[4] = System.getProperty("os.version");
/*  611 */     args[5] = System.getProperty("os.arch");
/*      */     try {
/*  613 */       InetAddress address = InetAddress.getLocalHost();
/*  614 */       args[6] = address.getHostName();
/*  615 */       args[7] = address.getHostAddress();
/*      */     } catch (UnknownHostException e) {
/*  617 */       args[6] = "-";
/*  618 */       args[7] = "-";
/*      */     }
/*  620 */     writer.print(MessageFormat.format(Constants.SERVER_ROW_SECTION, args));
/*      */     
/*      */ 
/*  623 */     writer.print(Constants.HTML_TAIL_SECTION);
/*      */     
/*      */ 
/*  626 */     writer.flush();
/*  627 */     writer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String reload(ContextName cn, StringManager smClient)
/*      */   {
/*  641 */     StringWriter stringWriter = new StringWriter();
/*  642 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  644 */     super.reload(printWriter, cn, smClient);
/*      */     
/*  646 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String undeploy(ContextName cn, StringManager smClient)
/*      */   {
/*  660 */     StringWriter stringWriter = new StringWriter();
/*  661 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  663 */     super.undeploy(printWriter, cn, smClient);
/*      */     
/*  665 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String sessions(ContextName cn, int idle, StringManager smClient)
/*      */   {
/*  681 */     StringWriter stringWriter = new StringWriter();
/*  682 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  684 */     super.sessions(printWriter, cn, idle, smClient);
/*      */     
/*  686 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String start(ContextName cn, StringManager smClient)
/*      */   {
/*  700 */     StringWriter stringWriter = new StringWriter();
/*  701 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  703 */     super.start(printWriter, cn, smClient);
/*      */     
/*  705 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String stop(ContextName cn, StringManager smClient)
/*      */   {
/*  719 */     StringWriter stringWriter = new StringWriter();
/*  720 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  722 */     super.stop(printWriter, cn, smClient);
/*      */     
/*  724 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String findleaks(StringManager smClient)
/*      */   {
/*  738 */     StringBuilder msg = new StringBuilder();
/*      */     
/*  740 */     StringWriter stringWriter = new StringWriter();
/*  741 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  743 */     super.findleaks(false, printWriter, smClient);
/*      */     
/*  745 */     String writerText = stringWriter.toString();
/*      */     
/*  747 */     if (writerText.length() > 0) {
/*  748 */       if (!writerText.startsWith("FAIL -")) {
/*  749 */         msg.append(smClient.getString("htmlManagerServlet.findleaksList"));
/*      */       }
/*      */       
/*  752 */       msg.append(writerText);
/*      */     } else {
/*  754 */       msg.append(smClient.getString("htmlManagerServlet.findleaksNone"));
/*      */     }
/*      */     
/*  757 */     return msg.toString();
/*      */   }
/*      */   
/*      */   protected String sslReload(String tlsHostName, StringManager smClient)
/*      */   {
/*  762 */     StringWriter stringWriter = new StringWriter();
/*  763 */     PrintWriter printWriter = new PrintWriter(stringWriter);
/*      */     
/*  765 */     super.sslReload(printWriter, tlsHostName, smClient);
/*      */     
/*  767 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */   protected void sslConnectorCiphers(HttpServletRequest request, HttpServletResponse response, StringManager smClient)
/*      */     throws ServletException, IOException
/*      */   {
/*  773 */     request.setAttribute("cipherList", getConnectorCiphers(smClient));
/*  774 */     getServletContext().getRequestDispatcher("/WEB-INF/jsp/connectorCiphers.jsp")
/*  775 */       .forward(request, response);
/*      */   }
/*      */   
/*      */   protected void sslConnectorCerts(HttpServletRequest request, HttpServletResponse response, StringManager smClient)
/*      */     throws ServletException, IOException
/*      */   {
/*  781 */     request.setAttribute("certList", getConnectorCerts(smClient));
/*  782 */     getServletContext().getRequestDispatcher("/WEB-INF/jsp/connectorCerts.jsp")
/*  783 */       .forward(request, response);
/*      */   }
/*      */   
/*      */   protected void sslConnectorTrustedCerts(HttpServletRequest request, HttpServletResponse response, StringManager smClient)
/*      */     throws ServletException, IOException
/*      */   {
/*  789 */     request.setAttribute("trustedCertList", getConnectorTrustedCerts(smClient));
/*  790 */     getServletContext().getRequestDispatcher("/WEB-INF/jsp/connectorTrustedCerts.jsp")
/*  791 */       .forward(request, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServletInfo()
/*      */   {
/*  800 */     return "HTMLManagerServlet, Copyright (c) 1999-2021, The Apache Software Foundation";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void init()
/*      */     throws ServletException
/*      */   {
/*  808 */     super.init();
/*      */     
/*      */ 
/*  811 */     String value = null;
/*  812 */     value = getServletConfig().getInitParameter("showProxySessions");
/*  813 */     this.showProxySessions = Boolean.parseBoolean(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String expireSessions(ContextName cn, HttpServletRequest req, StringManager smClient)
/*      */   {
/*  829 */     int idle = -1;
/*  830 */     String idleParam = req.getParameter("idle");
/*  831 */     if (idleParam != null) {
/*      */       try {
/*  833 */         idle = Integer.parseInt(idleParam);
/*      */       } catch (NumberFormatException e) {
/*  835 */         log(sm.getString("managerServlet.error.idleParam", new Object[] { idleParam }));
/*      */       }
/*      */     }
/*  838 */     return sessions(cn, idle, smClient);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doSessions(ContextName cn, HttpServletRequest req, HttpServletResponse resp, StringManager smClient)
/*      */     throws ServletException, IOException
/*      */   {
/*  854 */     req.setAttribute("path", cn.getPath());
/*  855 */     req.setAttribute("version", cn.getVersion());
/*  856 */     String action = req.getParameter("action");
/*  857 */     if (this.debug >= 1) {
/*  858 */       log("sessions: Session action '" + action + "' for web application '" + cn
/*  859 */         .getDisplayName() + "'");
/*      */     }
/*  861 */     if ("sessionDetail".equals(action)) {
/*  862 */       String sessionId = req.getParameter("sessionId");
/*  863 */       displaySessionDetailPage(req, resp, cn, sessionId, smClient);
/*  864 */       return; }
/*  865 */     if ("invalidateSessions".equals(action)) {
/*  866 */       String[] sessionIds = req.getParameterValues("sessionIds");
/*  867 */       int i = invalidateSessions(cn, sessionIds, smClient);
/*  868 */       req.setAttribute("message", "" + i + " sessions invalidated.");
/*  869 */     } else if ("removeSessionAttribute".equals(action)) {
/*  870 */       String sessionId = req.getParameter("sessionId");
/*  871 */       String name = req.getParameter("attributeName");
/*      */       
/*  873 */       boolean removed = removeSessionAttribute(cn, sessionId, name, smClient);
/*  874 */       String outMessage = "Session did not contain any attribute named '" + name + "'";
/*  875 */       req.setAttribute("message", outMessage);
/*  876 */       displaySessionDetailPage(req, resp, cn, sessionId, smClient);
/*  877 */       return;
/*      */     }
/*  879 */     displaySessionsListPage(cn, req, resp, smClient);
/*      */   }
/*      */   
/*      */   protected List<Session> getSessionsForName(ContextName cn, StringManager smClient)
/*      */   {
/*  884 */     if ((cn == null) || ((!cn.getPath().startsWith("/")) && 
/*  885 */       (!cn.getPath().equals("")))) {
/*  886 */       String path = null;
/*  887 */       if (cn != null) {
/*  888 */         path = cn.getPath();
/*      */       }
/*  890 */       throw new IllegalArgumentException(smClient.getString("managerServlet.invalidPath", new Object[] {
/*      */       
/*  892 */         Escape.htmlElementContent(path) }));
/*      */     }
/*      */     
/*  895 */     Context ctxt = (Context)this.host.findChild(cn.getName());
/*  896 */     if (null == ctxt) {
/*  897 */       throw new IllegalArgumentException(smClient.getString("managerServlet.noContext", new Object[] {
/*      */       
/*  899 */         Escape.htmlElementContent(cn.getDisplayName()) }));
/*      */     }
/*  901 */     Manager manager = ctxt.getManager();
/*  902 */     List<Session> sessions = new ArrayList(Arrays.asList(manager.findSessions()));
/*  903 */     if (((manager instanceof DistributedManager)) && (this.showProxySessions))
/*      */     {
/*      */ 
/*  906 */       Set<String> sessionIds = ((DistributedManager)manager).getSessionIdsFull();
/*      */       
/*  908 */       for (Session session : sessions) {
/*  909 */         sessionIds.remove(session.getId());
/*      */       }
/*      */       
/*  912 */       for (String sessionId : sessionIds) {
/*  913 */         sessions.add(new DummyProxySession(sessionId));
/*      */       }
/*      */     }
/*  916 */     return sessions;
/*      */   }
/*      */   
/*      */ 
/*      */   protected Session getSessionForNameAndId(ContextName cn, String id, StringManager smClient)
/*      */   {
/*  922 */     List<Session> sessions = getSessionsForName(cn, smClient);
/*  923 */     if (sessions.isEmpty()) {
/*  924 */       return null;
/*      */     }
/*  926 */     for (Session session : sessions) {
/*  927 */       if (session.getId().equals(id)) {
/*  928 */         return session;
/*      */       }
/*      */     }
/*  931 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void displaySessionsListPage(ContextName cn, HttpServletRequest req, HttpServletResponse resp, StringManager smClient)
/*      */     throws ServletException, IOException
/*      */   {
/*  947 */     List<Session> sessions = getSessionsForName(cn, smClient);
/*  948 */     String sortBy = req.getParameter("sort");
/*  949 */     String orderBy = null;
/*  950 */     if ((null != sortBy) && (!"".equals(sortBy.trim()))) {
/*  951 */       Comparator<Session> comparator = getComparator(sortBy);
/*  952 */       if (comparator != null) {
/*  953 */         orderBy = req.getParameter("order");
/*  954 */         if ("DESC".equalsIgnoreCase(orderBy)) {
/*  955 */           comparator = Collections.reverseOrder(comparator);
/*  956 */           orderBy = "ASC";
/*      */         } else {
/*  958 */           orderBy = "DESC";
/*      */         }
/*      */         try {
/*  961 */           sessions.sort(comparator);
/*      */         }
/*      */         catch (IllegalStateException ise) {
/*  964 */           req.setAttribute("error", "Can't sort session list: one session is invalidated");
/*      */         }
/*      */       } else {
/*  967 */         log(sm.getString("htmlManagerServlet.error.sortOrder", new Object[] { sortBy }));
/*      */       }
/*      */     }
/*      */     
/*  971 */     req.setAttribute("sort", sortBy);
/*  972 */     req.setAttribute("order", orderBy);
/*  973 */     req.setAttribute("activeSessions", sessions);
/*      */     
/*      */ 
/*      */ 
/*  977 */     resp.setHeader("Pragma", "No-cache");
/*  978 */     resp.setHeader("Cache-Control", "no-cache,no-store,max-age=0");
/*  979 */     resp.setDateHeader("Expires", 0L);
/*  980 */     getServletContext().getRequestDispatcher("/WEB-INF/jsp/sessionsList.jsp").include(req, resp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void displaySessionDetailPage(HttpServletRequest req, HttpServletResponse resp, ContextName cn, String sessionId, StringManager smClient)
/*      */     throws ServletException, IOException
/*      */   {
/*  997 */     Session session = getSessionForNameAndId(cn, sessionId, smClient);
/*      */     
/*      */ 
/*      */ 
/* 1001 */     resp.setHeader("Pragma", "No-cache");
/* 1002 */     resp.setHeader("Cache-Control", "no-cache,no-store,max-age=0");
/* 1003 */     resp.setDateHeader("Expires", 0L);
/* 1004 */     req.setAttribute("currentSession", session);
/* 1005 */     getServletContext().getRequestDispatcher(resp.encodeURL("/WEB-INF/jsp/sessionDetail.jsp")).include(req, resp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int invalidateSessions(ContextName cn, String[] sessionIds, StringManager smClient)
/*      */   {
/* 1019 */     if (null == sessionIds) {
/* 1020 */       return 0;
/*      */     }
/* 1022 */     int nbAffectedSessions = 0;
/* 1023 */     for (String sessionId : sessionIds)
/*      */     {
/* 1025 */       HttpSession session = getSessionForNameAndId(cn, sessionId, smClient).getSession();
/* 1026 */       if (null == session)
/*      */       {
/* 1028 */         if (this.debug >= 1) {
/* 1029 */           log("Cannot invalidate null session " + sessionId);
/*      */         }
/*      */       }
/*      */       else {
/*      */         try {
/* 1034 */           session.invalidate();
/* 1035 */           nbAffectedSessions++;
/* 1036 */           if (this.debug >= 1) {
/* 1037 */             log("Invalidating session id " + sessionId);
/*      */           }
/*      */         } catch (IllegalStateException ise) {
/* 1040 */           if (this.debug >= 1)
/* 1041 */             log("Cannot invalidate already invalidated session id " + sessionId);
/*      */         }
/*      */       }
/*      */     }
/* 1045 */     return nbAffectedSessions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean removeSessionAttribute(ContextName cn, String sessionId, String attributeName, StringManager smClient)
/*      */   {
/* 1060 */     HttpSession session = getSessionForNameAndId(cn, sessionId, smClient).getSession();
/* 1061 */     if (null == session)
/*      */     {
/* 1063 */       if (this.debug >= 1) {
/* 1064 */         log("Cannot remove attribute '" + attributeName + "' for null session " + sessionId);
/*      */       }
/* 1066 */       return false;
/*      */     }
/* 1068 */     boolean wasPresent = null != session.getAttribute(attributeName);
/*      */     try {
/* 1070 */       session.removeAttribute(attributeName);
/*      */     } catch (IllegalStateException ise) {
/* 1072 */       if (this.debug >= 1) {
/* 1073 */         log("Cannot remote attribute '" + attributeName + "' for invalidated session id " + sessionId);
/*      */       }
/*      */     }
/* 1076 */     return wasPresent;
/*      */   }
/*      */   
/*      */   protected Comparator<Session> getComparator(String sortBy) {
/* 1080 */     Comparator<Session> comparator = null;
/* 1081 */     if ("CreationTime".equalsIgnoreCase(sortBy)) {
/* 1082 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Date> getComparableObject(Session session) {
/* 1085 */           return new Date(session.getCreationTime());
/*      */         }
/*      */       };
/* 1088 */     } else if ("id".equalsIgnoreCase(sortBy)) {
/* 1089 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<String> getComparableObject(Session session) {
/* 1092 */           return session.getId();
/*      */         }
/*      */       };
/* 1095 */     } else if ("LastAccessedTime".equalsIgnoreCase(sortBy)) {
/* 1096 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Date> getComparableObject(Session session) {
/* 1099 */           return new Date(session.getLastAccessedTime());
/*      */         }
/*      */       };
/* 1102 */     } else if ("MaxInactiveInterval".equalsIgnoreCase(sortBy)) {
/* 1103 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Integer> getComparableObject(Session session) {
/* 1106 */           return Integer.valueOf(session.getMaxInactiveInterval());
/*      */         }
/*      */       };
/* 1109 */     } else if ("new".equalsIgnoreCase(sortBy)) {
/* 1110 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Boolean> getComparableObject(Session session) {
/* 1113 */           return Boolean.valueOf(session.getSession().isNew());
/*      */         }
/*      */       };
/* 1116 */     } else if ("locale".equalsIgnoreCase(sortBy)) {
/* 1117 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<String> getComparableObject(Session session) {
/* 1120 */           return JspHelper.guessDisplayLocaleFromSession(session);
/*      */         }
/*      */       };
/* 1123 */     } else if ("user".equalsIgnoreCase(sortBy)) {
/* 1124 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<String> getComparableObject(Session session) {
/* 1127 */           return JspHelper.guessDisplayUserFromSession(session);
/*      */         }
/*      */       };
/* 1130 */     } else if ("UsedTime".equalsIgnoreCase(sortBy)) {
/* 1131 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Date> getComparableObject(Session session) {
/* 1134 */           return new Date(SessionUtils.getUsedTimeForSession(session));
/*      */         }
/*      */       };
/* 1137 */     } else if ("InactiveTime".equalsIgnoreCase(sortBy)) {
/* 1138 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Date> getComparableObject(Session session) {
/* 1141 */           return new Date(SessionUtils.getInactiveTimeForSession(session));
/*      */         }
/*      */       };
/* 1144 */     } else if ("TTL".equalsIgnoreCase(sortBy)) {
/* 1145 */       comparator = new BaseSessionComparator()
/*      */       {
/*      */         public Comparable<Date> getComparableObject(Session session) {
/* 1148 */           return new Date(SessionUtils.getTTLForSession(session));
/*      */         }
/*      */       };
/*      */     }
/* 1152 */     return comparator;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\manager\HTMLManagerServlet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */