/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.management.ObjectName;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Loader;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.loader.WebappClassLoaderBase;
/*     */ import org.apache.catalina.util.ContextName;
/*     */ import org.apache.catalina.valves.ErrorReportValve;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardHost
/*     */   extends ContainerBase
/*     */   implements Host
/*     */ {
/*  60 */   private static final Log log = LogFactory.getLog(StandardHost.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardHost()
/*     */   {
/*  71 */     this.pipeline.setBasic(new StandardHostValve());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */   private String[] aliases = new String[0];
/*     */   
/*  84 */   private final Object aliasesLock = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   private String appBase = "webapps";
/*  91 */   private volatile File appBaseFile = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  96 */   private String xmlBase = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 101 */   private volatile File hostConfigBase = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 106 */   private boolean autoDeploy = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */   private String configClass = "org.apache.catalina.startup.ContextConfig";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */   private String contextClass = "org.apache.catalina.core.StandardContext";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */   private boolean deployOnStartup = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */   private boolean deployXML = !Globals.IS_SECURITY_ENABLED;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 142 */   private boolean copyXML = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */   private String errorReportValveClass = "org.apache.catalina.valves.ErrorReportValve";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */   private boolean unpackWARs = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 162 */   private String workDir = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */   private boolean createDirs = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 175 */   private final Map<ClassLoader, String> childClassLoaders = new WeakHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */   private Pattern deployIgnore = null;
/*     */   
/*     */ 
/* 187 */   private boolean undeployOldVersions = false;
/*     */   
/* 189 */   private boolean failCtxIfServletStartFails = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getUndeployOldVersions()
/*     */   {
/* 196 */     return this.undeployOldVersions;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setUndeployOldVersions(boolean undeployOldVersions)
/*     */   {
/* 202 */     this.undeployOldVersions = undeployOldVersions;
/*     */   }
/*     */   
/*     */ 
/*     */   public ExecutorService getStartStopExecutor()
/*     */   {
/* 208 */     return this.startStopExecutor;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getAppBase()
/*     */   {
/* 214 */     return this.appBase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public File getAppBaseFile()
/*     */   {
/* 221 */     if (this.appBaseFile != null) {
/* 222 */       return this.appBaseFile;
/*     */     }
/*     */     
/* 225 */     File file = new File(getAppBase());
/*     */     
/*     */ 
/* 228 */     if (!file.isAbsolute()) {
/* 229 */       file = new File(getCatalinaBase(), file.getPath());
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 234 */       file = file.getCanonicalFile();
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */     
/*     */ 
/* 239 */     this.appBaseFile = file;
/* 240 */     return file;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setAppBase(String appBase)
/*     */   {
/* 246 */     if (appBase.trim().equals("")) {
/* 247 */       log.warn(sm.getString("standardHost.problematicAppBase", new Object[] { getName() }));
/*     */     }
/* 249 */     String oldAppBase = this.appBase;
/* 250 */     this.appBase = appBase;
/* 251 */     this.support.firePropertyChange("appBase", oldAppBase, this.appBase);
/* 252 */     this.appBaseFile = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getXmlBase()
/*     */   {
/* 261 */     return this.xmlBase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXmlBase(String xmlBase)
/*     */   {
/* 270 */     String oldXmlBase = this.xmlBase;
/* 271 */     this.xmlBase = xmlBase;
/* 272 */     this.support.firePropertyChange("xmlBase", oldXmlBase, this.xmlBase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public File getConfigBaseFile()
/*     */   {
/* 281 */     if (this.hostConfigBase != null) {
/* 282 */       return this.hostConfigBase;
/*     */     }
/* 284 */     String path = null;
/* 285 */     if (getXmlBase() != null) {
/* 286 */       path = getXmlBase();
/*     */     } else {
/* 288 */       StringBuilder xmlDir = new StringBuilder("conf");
/* 289 */       Container parent = getParent();
/* 290 */       if ((parent instanceof Engine)) {
/* 291 */         xmlDir.append('/');
/* 292 */         xmlDir.append(parent.getName());
/*     */       }
/* 294 */       xmlDir.append('/');
/* 295 */       xmlDir.append(getName());
/* 296 */       path = xmlDir.toString();
/*     */     }
/* 298 */     File file = new File(path);
/* 299 */     if (!file.isAbsolute()) {
/* 300 */       file = new File(getCatalinaBase(), path);
/*     */     }
/*     */     try {
/* 303 */       file = file.getCanonicalFile();
/*     */     }
/*     */     catch (IOException localIOException) {}
/* 306 */     this.hostConfigBase = file;
/* 307 */     return file;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getCreateDirs()
/*     */   {
/* 317 */     return this.createDirs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCreateDirs(boolean createDirs)
/*     */   {
/* 326 */     this.createDirs = createDirs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAutoDeploy()
/*     */   {
/* 335 */     return this.autoDeploy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoDeploy(boolean autoDeploy)
/*     */   {
/* 347 */     boolean oldAutoDeploy = this.autoDeploy;
/* 348 */     this.autoDeploy = autoDeploy;
/* 349 */     this.support.firePropertyChange("autoDeploy", oldAutoDeploy, this.autoDeploy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getConfigClass()
/*     */   {
/* 361 */     return this.configClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConfigClass(String configClass)
/*     */   {
/* 374 */     String oldConfigClass = this.configClass;
/* 375 */     this.configClass = configClass;
/* 376 */     this.support.firePropertyChange("configClass", oldConfigClass, this.configClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContextClass()
/*     */   {
/* 387 */     return this.contextClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContextClass(String contextClass)
/*     */   {
/* 399 */     String oldContextClass = this.contextClass;
/* 400 */     this.contextClass = contextClass;
/* 401 */     this.support.firePropertyChange("contextClass", oldContextClass, this.contextClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getDeployOnStartup()
/*     */   {
/* 414 */     return this.deployOnStartup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDeployOnStartup(boolean deployOnStartup)
/*     */   {
/* 426 */     boolean oldDeployOnStartup = this.deployOnStartup;
/* 427 */     this.deployOnStartup = deployOnStartup;
/* 428 */     this.support.firePropertyChange("deployOnStartup", oldDeployOnStartup, this.deployOnStartup);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDeployXML()
/*     */   {
/* 438 */     return this.deployXML;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDeployXML(boolean deployXML)
/*     */   {
/* 448 */     this.deployXML = deployXML;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCopyXML()
/*     */   {
/* 456 */     return this.copyXML;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCopyXML(boolean copyXML)
/*     */   {
/* 466 */     this.copyXML = copyXML;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getErrorReportValveClass()
/*     */   {
/* 475 */     return this.errorReportValveClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setErrorReportValveClass(String errorReportValveClass)
/*     */   {
/* 487 */     String oldErrorReportValveClassClass = this.errorReportValveClass;
/* 488 */     this.errorReportValveClass = errorReportValveClass;
/* 489 */     this.support.firePropertyChange("errorReportValveClass", oldErrorReportValveClassClass, this.errorReportValveClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 502 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 517 */     if (name == null)
/*     */     {
/* 519 */       throw new IllegalArgumentException(sm.getString("standardHost.nullName"));
/*     */     }
/*     */     
/* 522 */     name = name.toLowerCase(Locale.ENGLISH);
/*     */     
/* 524 */     String oldName = this.name;
/* 525 */     this.name = name;
/* 526 */     this.support.firePropertyChange("name", oldName, this.name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUnpackWARs()
/*     */   {
/* 535 */     return this.unpackWARs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUnpackWARs(boolean unpackWARs)
/*     */   {
/* 545 */     this.unpackWARs = unpackWARs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWorkDir()
/*     */   {
/* 553 */     return this.workDir;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWorkDir(String workDir)
/*     */   {
/* 563 */     this.workDir = workDir;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDeployIgnore()
/*     */   {
/* 574 */     if (this.deployIgnore == null) {
/* 575 */       return null;
/*     */     }
/* 577 */     return this.deployIgnore.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pattern getDeployIgnorePattern()
/*     */   {
/* 588 */     return this.deployIgnore;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDeployIgnore(String deployIgnore)
/*     */   {
/*     */     String oldDeployIgnore;
/*     */     
/*     */ 
/*     */     String oldDeployIgnore;
/*     */     
/*     */ 
/* 602 */     if (this.deployIgnore == null) {
/* 603 */       oldDeployIgnore = null;
/*     */     } else {
/* 605 */       oldDeployIgnore = this.deployIgnore.toString();
/*     */     }
/* 607 */     if (deployIgnore == null) {
/* 608 */       this.deployIgnore = null;
/*     */     } else {
/* 610 */       this.deployIgnore = Pattern.compile(deployIgnore);
/*     */     }
/* 612 */     this.support.firePropertyChange("deployIgnore", oldDeployIgnore, deployIgnore);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFailCtxIfServletStartFails()
/*     */   {
/* 622 */     return this.failCtxIfServletStartFails;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFailCtxIfServletStartFails(boolean failCtxIfServletStartFails)
/*     */   {
/* 633 */     boolean oldFailCtxIfServletStartFails = this.failCtxIfServletStartFails;
/* 634 */     this.failCtxIfServletStartFails = failCtxIfServletStartFails;
/* 635 */     this.support.firePropertyChange("failCtxIfServletStartFails", oldFailCtxIfServletStartFails, failCtxIfServletStartFails);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addAlias(String alias)
/*     */   {
/* 652 */     alias = alias.toLowerCase(Locale.ENGLISH);
/*     */     
/* 654 */     synchronized (this.aliasesLock)
/*     */     {
/* 656 */       for (String s : this.aliases) {
/* 657 */         if (s.equals(alias)) {
/* 658 */           return;
/*     */         }
/*     */       }
/*     */       
/* 662 */       String[] newAliases = (String[])Arrays.copyOf(this.aliases, this.aliases.length + 1);
/* 663 */       newAliases[this.aliases.length] = alias;
/* 664 */       this.aliases = newAliases;
/*     */     }
/*     */     
/* 667 */     fireContainerEvent("addAlias", alias);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addChild(Container child)
/*     */   {
/* 681 */     if (!(child instanceof Context))
/*     */     {
/* 683 */       throw new IllegalArgumentException(sm.getString("standardHost.notContext"));
/*     */     }
/*     */     
/* 686 */     child.addLifecycleListener(new MemoryLeakTrackingListener(null));
/*     */     
/*     */ 
/*     */ 
/* 690 */     Context context = (Context)child;
/* 691 */     if (context.getPath() == null) {
/* 692 */       ContextName cn = new ContextName(context.getDocBase(), true);
/* 693 */       context.setPath(cn.getPath());
/*     */     }
/*     */     
/* 696 */     super.addChild(child);
/*     */   }
/*     */   
/*     */ 
/*     */   private class MemoryLeakTrackingListener
/*     */     implements LifecycleListener
/*     */   {
/*     */     private MemoryLeakTrackingListener() {}
/*     */     
/*     */ 
/*     */     public void lifecycleEvent(LifecycleEvent event)
/*     */     {
/* 708 */       if ((event.getType().equals("after_start")) && 
/* 709 */         ((event.getSource() instanceof Context))) {
/* 710 */         Context context = (Context)event.getSource();
/* 711 */         StandardHost.this.childClassLoaders.put(context.getLoader().getClassLoader(), context
/* 712 */           .getServletContext().getContextPath());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findReloadedContextMemoryLeaks()
/*     */   {
/* 729 */     System.gc();
/*     */     
/* 731 */     List<String> result = new ArrayList();
/*     */     
/*     */ 
/* 734 */     for (Map.Entry<ClassLoader, String> entry : this.childClassLoaders.entrySet()) {
/* 735 */       ClassLoader cl = (ClassLoader)entry.getKey();
/* 736 */       if (((cl instanceof WebappClassLoaderBase)) && 
/* 737 */         (!((WebappClassLoaderBase)cl).getState().isAvailable())) {
/* 738 */         result.add(entry.getValue());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 743 */     return (String[])result.toArray(new String[0]);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public String[] findAliases()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 7	org/apache/catalina/core/StandardHost:aliasesLock	Ljava/lang/Object;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 4	org/apache/catalina/core/StandardHost:aliases	[Ljava/lang/String;
/*     */     //   11: aload_1
/*     */     //   12: monitorexit
/*     */     //   13: areturn
/*     */     //   14: astore_2
/*     */     //   15: aload_1
/*     */     //   16: monitorexit
/*     */     //   17: aload_2
/*     */     //   18: athrow
/*     */     // Line number table:
/*     */     //   Java source line #752	-> byte code offset #0
/*     */     //   Java source line #753	-> byte code offset #7
/*     */     //   Java source line #754	-> byte code offset #14
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	19	0	this	StandardHost
/*     */     //   5	11	1	Ljava/lang/Object;	Object
/*     */     //   14	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	13	14	finally
/*     */     //   14	17	14	finally
/*     */   }
/*     */   
/*     */   public void removeAlias(String alias)
/*     */   {
/* 766 */     alias = alias.toLowerCase(Locale.ENGLISH);
/*     */     
/* 768 */     synchronized (this.aliasesLock)
/*     */     {
/*     */ 
/* 771 */       int n = -1;
/* 772 */       for (int i = 0; i < this.aliases.length; i++) {
/* 773 */         if (this.aliases[i].equals(alias)) {
/* 774 */           n = i;
/* 775 */           break;
/*     */         }
/*     */       }
/* 778 */       if (n < 0) {
/* 779 */         return;
/*     */       }
/*     */       
/*     */ 
/* 783 */       int j = 0;
/* 784 */       String[] results = new String[this.aliases.length - 1];
/* 785 */       for (int i = 0; i < this.aliases.length; i++) {
/* 786 */         if (i != n) {
/* 787 */           results[(j++)] = this.aliases[i];
/*     */         }
/*     */       }
/* 790 */       this.aliases = results;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 795 */     fireContainerEvent("removeAlias", alias);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 811 */     String errorValve = getErrorReportValveClass();
/* 812 */     if ((errorValve != null) && (!errorValve.equals(""))) {
/*     */       try {
/* 814 */         boolean found = false;
/* 815 */         Valve[] valves = getPipeline().getValves();
/* 816 */         for (Valve valve : valves) {
/* 817 */           if (errorValve.equals(valve.getClass().getName())) {
/* 818 */             found = true;
/* 819 */             break;
/*     */           }
/*     */         }
/* 822 */         if (!found)
/*     */         {
/*     */ 
/* 825 */           Valve valve = ErrorReportValve.class.getName().equals(errorValve) ? new ErrorReportValve() : (Valve)Class.forName(errorValve).getConstructor(new Class[0]).newInstance(new Object[0]);
/* 826 */           getPipeline().addValve(valve);
/*     */         }
/*     */       } catch (Throwable t) {
/* 829 */         ExceptionUtils.handleThrowable(t);
/* 830 */         log.error(sm.getString("standardHost.invalidErrorReportValveClass", new Object[] { errorValve }), t);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 835 */     super.startInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getValveNames()
/*     */     throws Exception
/*     */   {
/* 846 */     Valve[] valves = getPipeline().getValves();
/* 847 */     String[] mbeanNames = new String[valves.length];
/* 848 */     for (int i = 0; i < valves.length; i++) {
/* 849 */       if ((valves[i] instanceof JmxEnabled)) {
/* 850 */         ObjectName oname = ((JmxEnabled)valves[i]).getObjectName();
/* 851 */         if (oname != null) {
/* 852 */           mbeanNames[i] = oname.toString();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 857 */     return mbeanNames;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public String[] getAliases()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 7	org/apache/catalina/core/StandardHost:aliasesLock	Ljava/lang/Object;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 4	org/apache/catalina/core/StandardHost:aliases	[Ljava/lang/String;
/*     */     //   11: aload_1
/*     */     //   12: monitorexit
/*     */     //   13: areturn
/*     */     //   14: astore_2
/*     */     //   15: aload_1
/*     */     //   16: monitorexit
/*     */     //   17: aload_2
/*     */     //   18: athrow
/*     */     // Line number table:
/*     */     //   Java source line #861	-> byte code offset #0
/*     */     //   Java source line #862	-> byte code offset #7
/*     */     //   Java source line #863	-> byte code offset #14
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	19	0	this	StandardHost
/*     */     //   5	11	1	Ljava/lang/Object;	Object
/*     */     //   14	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	13	14	finally
/*     */     //   14	17	14	finally
/*     */   }
/*     */   
/*     */   protected String getObjectNameKeyProperties()
/*     */   {
/* 869 */     StringBuilder keyProperties = new StringBuilder("type=Host");
/* 870 */     keyProperties.append(getMBeanKeyProperties());
/*     */     
/* 872 */     return keyProperties.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\StandardHost.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */