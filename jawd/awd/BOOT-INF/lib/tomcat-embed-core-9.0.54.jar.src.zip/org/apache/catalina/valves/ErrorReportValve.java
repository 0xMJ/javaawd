/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.util.Locale;
/*     */ import java.util.Scanner;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.util.ErrorPageSupport;
/*     */ import org.apache.catalina.util.IOTools;
/*     */ import org.apache.catalina.util.ServerInfo;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.security.Escape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorReportValve
/*     */   extends ValveBase
/*     */ {
/*  60 */   private boolean showReport = true;
/*     */   
/*  62 */   private boolean showServerInfo = true;
/*     */   
/*  64 */   private final ErrorPageSupport errorPageSupport = new ErrorPageSupport();
/*     */   
/*     */ 
/*     */ 
/*     */   public ErrorReportValve()
/*     */   {
/*  70 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void invoke(Request request, org.apache.catalina.connector.Response response)
/*     */     throws IOException, ServletException
/*     */   {
/*  92 */     getNext().invoke(request, response);
/*     */     
/*  94 */     if (response.isCommitted()) {
/*  95 */       if (response.setErrorReported())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 100 */         AtomicBoolean ioAllowed = new AtomicBoolean(true);
/* 101 */         response.getCoyoteResponse().action(ActionCode.IS_IO_ALLOWED, ioAllowed);
/*     */         
/* 103 */         if (ioAllowed.get())
/*     */         {
/*     */           try
/*     */           {
/* 107 */             response.flushBuffer();
/*     */           } catch (Throwable t) {
/* 109 */             ExceptionUtils.handleThrowable(t);
/*     */           }
/*     */           
/*     */ 
/* 113 */           response.getCoyoteResponse().action(ActionCode.CLOSE_NOW, request
/* 114 */             .getAttribute("javax.servlet.error.exception"));
/*     */         }
/*     */       }
/* 117 */       return;
/*     */     }
/*     */     
/* 120 */     Throwable throwable = (Throwable)request.getAttribute("javax.servlet.error.exception");
/*     */     
/*     */ 
/*     */ 
/* 124 */     if ((request.isAsync()) && (!request.isAsyncCompleting())) {
/* 125 */       return;
/*     */     }
/*     */     
/* 128 */     if ((throwable != null) && (!response.isError()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */       response.reset();
/* 135 */       response.sendError(500);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 141 */     response.setSuspended(false);
/*     */     try
/*     */     {
/* 144 */       report(request, response, throwable);
/*     */     } catch (Throwable tt) {
/* 146 */       ExceptionUtils.handleThrowable(tt);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void report(Request request, org.apache.catalina.connector.Response response, Throwable throwable)
/*     */   {
/* 164 */     int statusCode = response.getStatus();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */     if ((statusCode < 400) || (response.getContentWritten() > 0L) || (!response.setErrorReported())) {
/* 171 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 176 */     AtomicBoolean result = new AtomicBoolean(false);
/* 177 */     response.getCoyoteResponse().action(ActionCode.IS_IO_ALLOWED, result);
/* 178 */     if (!result.get()) {
/* 179 */       return;
/*     */     }
/*     */     
/* 182 */     ErrorPage errorPage = null;
/* 183 */     if (throwable != null) {
/* 184 */       errorPage = this.errorPageSupport.find(throwable);
/*     */     }
/* 186 */     if (errorPage == null) {
/* 187 */       errorPage = this.errorPageSupport.find(statusCode);
/*     */     }
/* 189 */     if (errorPage == null)
/*     */     {
/* 191 */       errorPage = this.errorPageSupport.find(0);
/*     */     }
/*     */     
/*     */ 
/* 195 */     if ((errorPage != null) && 
/* 196 */       (sendErrorPage(errorPage.getLocation(), response)))
/*     */     {
/*     */ 
/* 199 */       return;
/*     */     }
/*     */     
/*     */ 
/* 203 */     String message = Escape.htmlElementContent(response.getMessage());
/* 204 */     if (message == null) {
/* 205 */       if (throwable != null) {
/* 206 */         String exceptionMessage = throwable.getMessage();
/* 207 */         if ((exceptionMessage != null) && (exceptionMessage.length() > 0)) {
/* 208 */           Scanner scanner = new Scanner(exceptionMessage);Throwable localThrowable4 = null;
/* 209 */           try { message = Escape.htmlElementContent(scanner.nextLine());
/*     */           }
/*     */           catch (Throwable localThrowable2)
/*     */           {
/* 208 */             localThrowable4 = localThrowable2;throw localThrowable2;
/*     */           } finally {
/* 210 */             if (scanner != null) if (localThrowable4 != null) try { scanner.close(); } catch (Throwable localThrowable3) { localThrowable4.addSuppressed(localThrowable3); } else scanner.close();
/*     */           }
/*     */         } }
/* 213 */       if (message == null) {
/* 214 */         message = "";
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 220 */     String reason = null;
/* 221 */     String description = null;
/* 222 */     StringManager smClient = StringManager.getManager("org.apache.catalina.valves", request
/* 223 */       .getLocales());
/* 224 */     response.setLocale(smClient.getLocale());
/*     */     try {
/* 226 */       reason = smClient.getString("http." + statusCode + ".reason");
/* 227 */       description = smClient.getString("http." + statusCode + ".desc");
/*     */     } catch (Throwable t) {
/* 229 */       ExceptionUtils.handleThrowable(t);
/*     */     }
/* 231 */     if ((reason == null) || (description == null)) {
/* 232 */       if (message.isEmpty()) {
/* 233 */         return;
/*     */       }
/* 235 */       reason = smClient.getString("errorReportValve.unknownReason");
/* 236 */       description = smClient.getString("errorReportValve.noDescription");
/*     */     }
/*     */     
/*     */ 
/* 240 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 242 */     sb.append("<!doctype html><html lang=\"");
/* 243 */     sb.append(smClient.getLocale().getLanguage()).append("\">");
/* 244 */     sb.append("<head>");
/* 245 */     sb.append("<title>");
/* 246 */     sb.append(smClient.getString("errorReportValve.statusHeader", new Object[] {
/* 247 */       String.valueOf(statusCode), reason }));
/* 248 */     sb.append("</title>");
/* 249 */     sb.append("<style type=\"text/css\">");
/* 250 */     sb.append("body {font-family:Tahoma,Arial,sans-serif;} h1, h2, h3, b {color:white;background-color:#525D76;} h1 {font-size:22px;} h2 {font-size:16px;} h3 {font-size:14px;} p {font-size:12px;} a {color:black;} .line {height:1px;background-color:#525D76;border:none;}");
/* 251 */     sb.append("</style>");
/* 252 */     sb.append("</head><body>");
/* 253 */     sb.append("<h1>");
/* 254 */     sb.append(smClient.getString("errorReportValve.statusHeader", new Object[] {
/* 255 */       String.valueOf(statusCode), reason })).append("</h1>");
/* 256 */     if (isShowReport()) {
/* 257 */       sb.append("<hr class=\"line\" />");
/* 258 */       sb.append("<p><b>");
/* 259 */       sb.append(smClient.getString("errorReportValve.type"));
/* 260 */       sb.append("</b> ");
/* 261 */       if (throwable != null) {
/* 262 */         sb.append(smClient.getString("errorReportValve.exceptionReport"));
/*     */       } else {
/* 264 */         sb.append(smClient.getString("errorReportValve.statusReport"));
/*     */       }
/* 266 */       sb.append("</p>");
/* 267 */       if (!message.isEmpty()) {
/* 268 */         sb.append("<p><b>");
/* 269 */         sb.append(smClient.getString("errorReportValve.message"));
/* 270 */         sb.append("</b> ");
/* 271 */         sb.append(message).append("</p>");
/*     */       }
/* 273 */       sb.append("<p><b>");
/* 274 */       sb.append(smClient.getString("errorReportValve.description"));
/* 275 */       sb.append("</b> ");
/* 276 */       sb.append(description);
/* 277 */       sb.append("</p>");
/* 278 */       if (throwable != null) {
/* 279 */         String stackTrace = getPartialServletStackTrace(throwable);
/* 280 */         sb.append("<p><b>");
/* 281 */         sb.append(smClient.getString("errorReportValve.exception"));
/* 282 */         sb.append("</b></p><pre>");
/* 283 */         sb.append(Escape.htmlElementContent(stackTrace));
/* 284 */         sb.append("</pre>");
/*     */         
/* 286 */         int loops = 0;
/* 287 */         Throwable rootCause = throwable.getCause();
/* 288 */         while ((rootCause != null) && (loops < 10)) {
/* 289 */           stackTrace = getPartialServletStackTrace(rootCause);
/* 290 */           sb.append("<p><b>");
/* 291 */           sb.append(smClient.getString("errorReportValve.rootCause"));
/* 292 */           sb.append("</b></p><pre>");
/* 293 */           sb.append(Escape.htmlElementContent(stackTrace));
/* 294 */           sb.append("</pre>");
/*     */           
/* 296 */           rootCause = rootCause.getCause();
/* 297 */           loops++;
/*     */         }
/*     */         
/* 300 */         sb.append("<p><b>");
/* 301 */         sb.append(smClient.getString("errorReportValve.note"));
/* 302 */         sb.append("</b> ");
/* 303 */         sb.append(smClient.getString("errorReportValve.rootCauseInLogs"));
/* 304 */         sb.append("</p>");
/*     */       }
/*     */       
/* 307 */       sb.append("<hr class=\"line\" />");
/*     */     }
/* 309 */     if (isShowServerInfo()) {
/* 310 */       sb.append("<h3>").append(ServerInfo.getServerInfo()).append("</h3>");
/*     */     }
/* 312 */     sb.append("</body></html>");
/*     */     try
/*     */     {
/*     */       try {
/* 316 */         response.setContentType("text/html");
/* 317 */         response.setCharacterEncoding("utf-8");
/*     */       } catch (Throwable t) {
/* 319 */         ExceptionUtils.handleThrowable(t);
/* 320 */         if (this.container.getLogger().isDebugEnabled()) {
/* 321 */           this.container.getLogger().debug("status.setContentType", t);
/*     */         }
/*     */       }
/* 324 */       Object writer = response.getReporter();
/* 325 */       if (writer != null)
/*     */       {
/*     */ 
/* 328 */         ((Writer)writer).write(sb.toString());
/* 329 */         response.finishResponse();
/*     */       }
/*     */     }
/*     */     catch (IOException|IllegalStateException localIOException1) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPartialServletStackTrace(Throwable t)
/*     */   {
/* 345 */     StringBuilder trace = new StringBuilder();
/* 346 */     trace.append(t.toString()).append(System.lineSeparator());
/* 347 */     StackTraceElement[] elements = t.getStackTrace();
/* 348 */     int pos = elements.length;
/* 349 */     for (int i = elements.length - 1; i >= 0; i--)
/*     */     {
/* 351 */       if ((elements[i].getClassName().startsWith("org.apache.catalina.core.ApplicationFilterChain")) && 
/* 352 */         (elements[i].getMethodName().equals("internalDoFilter"))) {
/* 353 */         pos = i;
/* 354 */         break;
/*     */       }
/*     */     }
/* 357 */     for (int i = 0; i < pos; i++)
/*     */     {
/* 359 */       if (!elements[i].getClassName().startsWith("org.apache.catalina.core.")) {
/* 360 */         trace.append('\t').append(elements[i].toString()).append(System.lineSeparator());
/*     */       }
/*     */     }
/* 363 */     return trace.toString();
/*     */   }
/*     */   
/*     */   private boolean sendErrorPage(String location, org.apache.catalina.connector.Response response)
/*     */   {
/* 368 */     File file = new File(location);
/* 369 */     if (!file.isAbsolute()) {
/* 370 */       file = new File(getContainer().getCatalinaBase(), location);
/*     */     }
/* 372 */     if ((!file.isFile()) || (!file.canRead())) {
/* 373 */       getContainer().getLogger().warn(sm
/* 374 */         .getString("errorReportValve.errorPageNotFound", new Object[] { location }));
/* 375 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 380 */     response.setContentType("text/html");
/* 381 */     response.setCharacterEncoding("UTF-8");
/*     */     try {
/* 383 */       OutputStream os = response.getOutputStream();Throwable localThrowable6 = null;
/* 384 */       try { InputStream is = new FileInputStream(file);Throwable localThrowable7 = null;
/* 385 */         try { IOTools.flow(is, os);
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 383 */           localThrowable7 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable4) { localThrowable6 = localThrowable4;throw localThrowable4;
/*     */       }
/*     */       finally {
/* 386 */         if (os != null) if (localThrowable6 != null) try { os.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else os.close();
/* 387 */       } } catch (IOException e) { getContainer().getLogger().warn(sm
/* 388 */         .getString("errorReportValve.errorPageIOException", new Object[] { location }), e);
/* 389 */       return false;
/*     */     }
/*     */     
/* 392 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShowReport(boolean showReport)
/*     */   {
/* 402 */     this.showReport = showReport;
/*     */   }
/*     */   
/*     */   public boolean isShowReport() {
/* 406 */     return this.showReport;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShowServerInfo(boolean showServerInfo)
/*     */   {
/* 415 */     this.showServerInfo = showServerInfo;
/*     */   }
/*     */   
/*     */   public boolean isShowServerInfo() {
/* 419 */     return this.showServerInfo;
/*     */   }
/*     */   
/*     */   public boolean setProperty(String name, String value)
/*     */   {
/* 424 */     if (name.startsWith("errorCode.")) {
/* 425 */       int code = Integer.parseInt(name.substring(10));
/* 426 */       ErrorPage ep = new ErrorPage();
/* 427 */       ep.setErrorCode(code);
/* 428 */       ep.setLocation(value);
/* 429 */       this.errorPageSupport.add(ep);
/* 430 */       return true; }
/* 431 */     if (name.startsWith("exceptionType.")) {
/* 432 */       String className = name.substring(14);
/* 433 */       ErrorPage ep = new ErrorPage();
/* 434 */       ep.setExceptionType(className);
/* 435 */       ep.setLocation(value);
/* 436 */       this.errorPageSupport.add(ep);
/* 437 */       return true;
/*     */     }
/* 439 */     return false;
/*     */   }
/*     */   
/*     */   public String getProperty(String name) { String result;
/*     */     String result;
/* 444 */     if (name.startsWith("errorCode.")) {
/* 445 */       int code = Integer.parseInt(name.substring(10));
/* 446 */       ErrorPage ep = this.errorPageSupport.find(code);
/* 447 */       String result; if (ep == null) {
/* 448 */         result = null;
/*     */       } else
/* 450 */         result = ep.getLocation();
/*     */     } else { String result;
/* 452 */       if (name.startsWith("exceptionType.")) {
/* 453 */         String className = name.substring(14);
/* 454 */         ErrorPage ep = this.errorPageSupport.find(className);
/* 455 */         String result; if (ep == null) {
/* 456 */           result = null;
/*     */         } else {
/* 458 */           result = ep.getLocation();
/*     */         }
/*     */       } else {
/* 461 */         result = null;
/*     */       } }
/* 463 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\ErrorReportValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */