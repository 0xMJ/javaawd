/*     */ package org.apache.catalina.session;
/*     */ 
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.nio.file.Path;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FileStore
/*     */   extends StoreBase
/*     */ {
/*  48 */   private static final Log log = LogFactory.getLog(FileStore.class);
/*  49 */   private static final StringManager sm = StringManager.getManager(FileStore.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String FILE_EXT = ".session";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private String directory = ".";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   private File directoryFile = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String storeName = "fileStore";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String threadName = "FileStore";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDirectory()
/*     */   {
/*  94 */     return this.directory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDirectory(String path)
/*     */   {
/* 104 */     String oldDirectory = this.directory;
/* 105 */     this.directory = path;
/* 106 */     this.directoryFile = null;
/* 107 */     this.support.firePropertyChange("directory", oldDirectory, this.directory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getThreadName()
/*     */   {
/* 115 */     return "FileStore";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStoreName()
/*     */   {
/* 124 */     return "fileStore";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSize()
/*     */     throws IOException
/*     */   {
/* 136 */     File dir = directory();
/* 137 */     if (dir == null) {
/* 138 */       return 0;
/*     */     }
/* 140 */     String[] files = dir.list();
/*     */     
/*     */ 
/* 143 */     int keycount = 0;
/* 144 */     if (files != null) {
/* 145 */       for (String file : files) {
/* 146 */         if (file.endsWith(".session")) {
/* 147 */           keycount++;
/*     */         }
/*     */       }
/*     */     }
/* 151 */     return keycount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */     throws IOException
/*     */   {
/* 164 */     String[] keys = keys();
/* 165 */     for (String key : keys) {
/* 166 */       remove(key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] keys()
/*     */     throws IOException
/*     */   {
/* 181 */     File dir = directory();
/* 182 */     if (dir == null) {
/* 183 */       return new String[0];
/*     */     }
/* 185 */     String[] files = dir.list();
/*     */     
/*     */ 
/* 188 */     if ((files == null) || (files.length < 1)) {
/* 189 */       return new String[0];
/*     */     }
/*     */     
/*     */ 
/* 193 */     List<String> list = new ArrayList();
/* 194 */     int n = ".session".length();
/* 195 */     for (String file : files) {
/* 196 */       if (file.endsWith(".session")) {
/* 197 */         list.add(file.substring(0, file.length() - n));
/*     */       }
/*     */     }
/* 200 */     return (String[])list.toArray(new String[0]);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Session load(String id)
/*     */     throws java.lang.ClassNotFoundException, IOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: invokespecial 25	org/apache/catalina/session/FileStore:file	(Ljava/lang/String;)Ljava/io/File;
/*     */     //   5: astore_2
/*     */     //   6: aload_2
/*     */     //   7: ifnull +10 -> 17
/*     */     //   10: aload_2
/*     */     //   11: invokevirtual 26	java/io/File:exists	()Z
/*     */     //   14: ifne +5 -> 19
/*     */     //   17: aconst_null
/*     */     //   18: areturn
/*     */     //   19: aload_0
/*     */     //   20: invokevirtual 27	org/apache/catalina/session/FileStore:getManager	()Lorg/apache/catalina/Manager;
/*     */     //   23: invokeinterface 28 1 0
/*     */     //   28: astore_3
/*     */     //   29: aload_3
/*     */     //   30: invokeinterface 29 1 0
/*     */     //   35: astore 4
/*     */     //   37: aload 4
/*     */     //   39: invokeinterface 30 1 0
/*     */     //   44: ifeq +53 -> 97
/*     */     //   47: aload 4
/*     */     //   49: getstatic 31	org/apache/catalina/session/FileStore:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   52: new 32	java/lang/StringBuilder
/*     */     //   55: dup
/*     */     //   56: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*     */     //   59: aload_0
/*     */     //   60: invokevirtual 34	org/apache/catalina/session/FileStore:getStoreName	()Ljava/lang/String;
/*     */     //   63: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   66: ldc 36
/*     */     //   68: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   71: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   74: iconst_2
/*     */     //   75: anewarray 38	java/lang/Object
/*     */     //   78: dup
/*     */     //   79: iconst_0
/*     */     //   80: aload_1
/*     */     //   81: aastore
/*     */     //   82: dup
/*     */     //   83: iconst_1
/*     */     //   84: aload_2
/*     */     //   85: invokevirtual 39	java/io/File:getAbsolutePath	()Ljava/lang/String;
/*     */     //   88: aastore
/*     */     //   89: invokevirtual 40	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   92: invokeinterface 41 2 0
/*     */     //   97: aload_3
/*     */     //   98: getstatic 42	org/apache/catalina/Globals:IS_SECURITY_ENABLED	Z
/*     */     //   101: aconst_null
/*     */     //   102: invokeinterface 43 3 0
/*     */     //   107: astore 5
/*     */     //   109: new 44	java/io/FileInputStream
/*     */     //   112: dup
/*     */     //   113: aload_2
/*     */     //   114: invokevirtual 39	java/io/File:getAbsolutePath	()Ljava/lang/String;
/*     */     //   117: invokespecial 45	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
/*     */     //   120: astore 6
/*     */     //   122: aconst_null
/*     */     //   123: astore 7
/*     */     //   125: aload_0
/*     */     //   126: aload 6
/*     */     //   128: invokevirtual 46	org/apache/catalina/session/FileStore:getObjectInputStream	(Ljava/io/InputStream;)Ljava/io/ObjectInputStream;
/*     */     //   131: astore 8
/*     */     //   133: aconst_null
/*     */     //   134: astore 9
/*     */     //   136: aload_0
/*     */     //   137: getfield 47	org/apache/catalina/session/FileStore:manager	Lorg/apache/catalina/Manager;
/*     */     //   140: invokeinterface 48 1 0
/*     */     //   145: checkcast 49	org/apache/catalina/session/StandardSession
/*     */     //   148: astore 10
/*     */     //   150: aload 10
/*     */     //   152: aload 8
/*     */     //   154: invokevirtual 50	org/apache/catalina/session/StandardSession:readObjectData	(Ljava/io/ObjectInputStream;)V
/*     */     //   157: aload 10
/*     */     //   159: aload_0
/*     */     //   160: getfield 47	org/apache/catalina/session/FileStore:manager	Lorg/apache/catalina/Manager;
/*     */     //   163: invokevirtual 51	org/apache/catalina/session/StandardSession:setManager	(Lorg/apache/catalina/Manager;)V
/*     */     //   166: aload 10
/*     */     //   168: astore 11
/*     */     //   170: aload 8
/*     */     //   172: ifnull +33 -> 205
/*     */     //   175: aload 9
/*     */     //   177: ifnull +23 -> 200
/*     */     //   180: aload 8
/*     */     //   182: invokevirtual 52	java/io/ObjectInputStream:close	()V
/*     */     //   185: goto +20 -> 205
/*     */     //   188: astore 12
/*     */     //   190: aload 9
/*     */     //   192: aload 12
/*     */     //   194: invokevirtual 54	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   197: goto +8 -> 205
/*     */     //   200: aload 8
/*     */     //   202: invokevirtual 52	java/io/ObjectInputStream:close	()V
/*     */     //   205: aload 6
/*     */     //   207: ifnull +33 -> 240
/*     */     //   210: aload 7
/*     */     //   212: ifnull +23 -> 235
/*     */     //   215: aload 6
/*     */     //   217: invokevirtual 55	java/io/FileInputStream:close	()V
/*     */     //   220: goto +20 -> 240
/*     */     //   223: astore 12
/*     */     //   225: aload 7
/*     */     //   227: aload 12
/*     */     //   229: invokevirtual 54	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   232: goto +8 -> 240
/*     */     //   235: aload 6
/*     */     //   237: invokevirtual 55	java/io/FileInputStream:close	()V
/*     */     //   240: aload_3
/*     */     //   241: getstatic 42	org/apache/catalina/Globals:IS_SECURITY_ENABLED	Z
/*     */     //   244: aload 5
/*     */     //   246: invokeinterface 56 3 0
/*     */     //   251: aload 11
/*     */     //   253: areturn
/*     */     //   254: astore 10
/*     */     //   256: aload 10
/*     */     //   258: astore 9
/*     */     //   260: aload 10
/*     */     //   262: athrow
/*     */     //   263: astore 13
/*     */     //   265: aload 8
/*     */     //   267: ifnull +33 -> 300
/*     */     //   270: aload 9
/*     */     //   272: ifnull +23 -> 295
/*     */     //   275: aload 8
/*     */     //   277: invokevirtual 52	java/io/ObjectInputStream:close	()V
/*     */     //   280: goto +20 -> 300
/*     */     //   283: astore 14
/*     */     //   285: aload 9
/*     */     //   287: aload 14
/*     */     //   289: invokevirtual 54	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   292: goto +8 -> 300
/*     */     //   295: aload 8
/*     */     //   297: invokevirtual 52	java/io/ObjectInputStream:close	()V
/*     */     //   300: aload 13
/*     */     //   302: athrow
/*     */     //   303: astore 8
/*     */     //   305: aload 8
/*     */     //   307: astore 7
/*     */     //   309: aload 8
/*     */     //   311: athrow
/*     */     //   312: astore 15
/*     */     //   314: aload 6
/*     */     //   316: ifnull +33 -> 349
/*     */     //   319: aload 7
/*     */     //   321: ifnull +23 -> 344
/*     */     //   324: aload 6
/*     */     //   326: invokevirtual 55	java/io/FileInputStream:close	()V
/*     */     //   329: goto +20 -> 349
/*     */     //   332: astore 16
/*     */     //   334: aload 7
/*     */     //   336: aload 16
/*     */     //   338: invokevirtual 54	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   341: goto +8 -> 349
/*     */     //   344: aload 6
/*     */     //   346: invokevirtual 55	java/io/FileInputStream:close	()V
/*     */     //   349: aload 15
/*     */     //   351: athrow
/*     */     //   352: astore 6
/*     */     //   354: aload 4
/*     */     //   356: invokeinterface 30 1 0
/*     */     //   361: ifeq +12 -> 373
/*     */     //   364: aload 4
/*     */     //   366: ldc 58
/*     */     //   368: invokeinterface 41 2 0
/*     */     //   373: aconst_null
/*     */     //   374: astore 7
/*     */     //   376: aload_3
/*     */     //   377: getstatic 42	org/apache/catalina/Globals:IS_SECURITY_ENABLED	Z
/*     */     //   380: aload 5
/*     */     //   382: invokeinterface 56 3 0
/*     */     //   387: aload 7
/*     */     //   389: areturn
/*     */     //   390: astore 17
/*     */     //   392: aload_3
/*     */     //   393: getstatic 42	org/apache/catalina/Globals:IS_SECURITY_ENABLED	Z
/*     */     //   396: aload 5
/*     */     //   398: invokeinterface 56 3 0
/*     */     //   403: aload 17
/*     */     //   405: athrow
/*     */     // Line number table:
/*     */     //   Java source line #217	-> byte code offset #0
/*     */     //   Java source line #218	-> byte code offset #6
/*     */     //   Java source line #219	-> byte code offset #17
/*     */     //   Java source line #222	-> byte code offset #19
/*     */     //   Java source line #223	-> byte code offset #29
/*     */     //   Java source line #225	-> byte code offset #37
/*     */     //   Java source line #226	-> byte code offset #47
/*     */     //   Java source line #229	-> byte code offset #97
/*     */     //   Java source line #231	-> byte code offset #109
/*     */     //   Java source line #232	-> byte code offset #125
/*     */     //   Java source line #231	-> byte code offset #133
/*     */     //   Java source line #234	-> byte code offset #136
/*     */     //   Java source line #235	-> byte code offset #150
/*     */     //   Java source line #236	-> byte code offset #157
/*     */     //   Java source line #237	-> byte code offset #166
/*     */     //   Java source line #238	-> byte code offset #170
/*     */     //   Java source line #244	-> byte code offset #240
/*     */     //   Java source line #237	-> byte code offset #251
/*     */     //   Java source line #231	-> byte code offset #254
/*     */     //   Java source line #238	-> byte code offset #263
/*     */     //   Java source line #231	-> byte code offset #303
/*     */     //   Java source line #238	-> byte code offset #312
/*     */     //   Java source line #239	-> byte code offset #354
/*     */     //   Java source line #240	-> byte code offset #364
/*     */     //   Java source line #242	-> byte code offset #373
/*     */     //   Java source line #244	-> byte code offset #376
/*     */     //   Java source line #242	-> byte code offset #387
/*     */     //   Java source line #244	-> byte code offset #390
/*     */     //   Java source line #245	-> byte code offset #403
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	406	0	this	FileStore
/*     */     //   0	406	1	id	String
/*     */     //   5	109	2	file	File
/*     */     //   28	365	3	context	Context
/*     */     //   35	330	4	contextLog	Log
/*     */     //   107	290	5	oldThreadContextCL	ClassLoader
/*     */     //   120	225	6	fis	java.io.FileInputStream
/*     */     //   352	3	6	e	java.io.FileNotFoundException
/*     */     //   123	265	7	localThrowable6	Throwable
/*     */     //   131	165	8	ois	java.io.ObjectInputStream
/*     */     //   303	7	8	localThrowable4	Throwable
/*     */     //   134	152	9	localThrowable7	Throwable
/*     */     //   148	19	10	session	StandardSession
/*     */     //   254	7	10	localThrowable2	Throwable
/*     */     //   168	84	11	localStandardSession1	StandardSession
/*     */     //   188	5	12	localThrowable	Throwable
/*     */     //   223	5	12	localThrowable1	Throwable
/*     */     //   263	38	13	localObject1	Object
/*     */     //   283	5	14	localThrowable3	Throwable
/*     */     //   312	38	15	localObject2	Object
/*     */     //   332	5	16	localThrowable5	Throwable
/*     */     //   390	14	17	localObject3	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   180	185	188	java/lang/Throwable
/*     */     //   215	220	223	java/lang/Throwable
/*     */     //   136	170	254	java/lang/Throwable
/*     */     //   136	170	263	finally
/*     */     //   254	265	263	finally
/*     */     //   275	280	283	java/lang/Throwable
/*     */     //   125	205	303	java/lang/Throwable
/*     */     //   254	303	303	java/lang/Throwable
/*     */     //   125	205	312	finally
/*     */     //   254	314	312	finally
/*     */     //   324	329	332	java/lang/Throwable
/*     */     //   109	240	352	java/io/FileNotFoundException
/*     */     //   254	352	352	java/io/FileNotFoundException
/*     */     //   109	240	390	finally
/*     */     //   254	376	390	finally
/*     */     //   390	392	390	finally
/*     */   }
/*     */   
/*     */   public void remove(String id)
/*     */     throws IOException
/*     */   {
/* 260 */     File file = file(id);
/* 261 */     if (file == null) {
/* 262 */       return;
/*     */     }
/* 264 */     if (this.manager.getContext().getLogger().isDebugEnabled()) {
/* 265 */       this.manager.getContext().getLogger().debug(sm.getString(getStoreName() + ".removing", new Object[] { id, file
/* 266 */         .getAbsolutePath() }));
/*     */     }
/*     */     
/* 269 */     if ((file.exists()) && (!file.delete())) {
/* 270 */       throw new IOException(sm.getString("fileStore.deleteSessionFailed", new Object[] { file }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void save(Session session)
/*     */     throws IOException
/*     */   {
/* 286 */     File file = file(session.getIdInternal());
/* 287 */     if (file == null) {
/* 288 */       return;
/*     */     }
/* 290 */     if (this.manager.getContext().getLogger().isDebugEnabled()) {
/* 291 */       this.manager.getContext().getLogger().debug(sm.getString(getStoreName() + ".saving", new Object[] {session
/* 292 */         .getIdInternal(), file.getAbsolutePath() }));
/*     */     }
/*     */     
/* 295 */     FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());Throwable localThrowable6 = null;
/* 296 */     try { ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(fos));Throwable localThrowable7 = null;
/* 297 */       try { ((StandardSession)session).writeObjectData(oos);
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 295 */         localThrowable7 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable4) { localThrowable6 = localThrowable4;throw localThrowable4;
/*     */     }
/*     */     finally {
/* 298 */       if (fos != null) { if (localThrowable6 != null) try { fos.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else { fos.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private File directory()
/*     */     throws IOException
/*     */   {
/* 310 */     if (this.directory == null) {
/* 311 */       return null;
/*     */     }
/* 313 */     if (this.directoryFile != null)
/*     */     {
/* 315 */       return this.directoryFile;
/*     */     }
/* 317 */     File file = new File(this.directory);
/* 318 */     if (!file.isAbsolute()) {
/* 319 */       Context context = this.manager.getContext();
/* 320 */       ServletContext servletContext = context.getServletContext();
/* 321 */       File work = (File)servletContext.getAttribute("javax.servlet.context.tempdir");
/* 322 */       file = new File(work, this.directory);
/*     */     }
/* 324 */     if ((!file.exists()) || (!file.isDirectory())) {
/* 325 */       if ((!file.delete()) && (file.exists())) {
/* 326 */         throw new IOException(sm.getString("fileStore.deleteFailed", new Object[] { file }));
/*     */       }
/* 328 */       if ((!file.mkdirs()) && (!file.isDirectory())) {
/* 329 */         throw new IOException(sm.getString("fileStore.createFailed", new Object[] { file }));
/*     */       }
/*     */     }
/* 332 */     this.directoryFile = file;
/* 333 */     return file;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private File file(String id)
/*     */     throws IOException
/*     */   {
/* 345 */     File storageDir = directory();
/* 346 */     if (storageDir == null) {
/* 347 */       return null;
/*     */     }
/*     */     
/* 350 */     String filename = id + ".session";
/* 351 */     File file = new File(storageDir, filename);
/*     */     
/*     */ 
/* 354 */     if (!file.getCanonicalFile().toPath().startsWith(storageDir.getCanonicalFile().toPath())) {
/* 355 */       log.warn(sm.getString("fileStore.invalid", new Object[] { file.getPath(), id }));
/* 356 */       return null;
/*     */     }
/*     */     
/* 359 */     return file;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\session\FileStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */