/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletRequest;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ApplicationFilterFactory
/*     */ {
/*     */   public static ApplicationFilterChain createFilterChain(ServletRequest request, Wrapper wrapper, Servlet servlet)
/*     */   {
/*  57 */     if (servlet == null) {
/*  58 */       return null;
/*     */     }
/*     */     
/*     */ 
/*  62 */     ApplicationFilterChain filterChain = null;
/*  63 */     if ((request instanceof Request)) {
/*  64 */       Request req = (Request)request;
/*  65 */       if (Globals.IS_SECURITY_ENABLED)
/*     */       {
/*  67 */         filterChain = new ApplicationFilterChain();
/*     */       } else {
/*  69 */         filterChain = (ApplicationFilterChain)req.getFilterChain();
/*  70 */         if (filterChain == null) {
/*  71 */           filterChain = new ApplicationFilterChain();
/*  72 */           req.setFilterChain(filterChain);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/*  77 */       filterChain = new ApplicationFilterChain();
/*     */     }
/*     */     
/*  80 */     filterChain.setServlet(servlet);
/*  81 */     filterChain.setServletSupportsAsync(wrapper.isAsyncSupported());
/*     */     
/*     */ 
/*  84 */     StandardContext context = (StandardContext)wrapper.getParent();
/*  85 */     FilterMap[] filterMaps = context.findFilterMaps();
/*     */     
/*     */ 
/*  88 */     if ((filterMaps == null) || (filterMaps.length == 0)) {
/*  89 */       return filterChain;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  94 */     DispatcherType dispatcher = (DispatcherType)request.getAttribute("org.apache.catalina.core.DISPATCHER_TYPE");
/*     */     
/*  96 */     String requestPath = null;
/*  97 */     Object attribute = request.getAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH");
/*  98 */     if (attribute != null) {
/*  99 */       requestPath = attribute.toString();
/*     */     }
/*     */     
/* 102 */     String servletName = wrapper.getName();
/*     */     
/*     */ 
/* 105 */     for (FilterMap filterMap : filterMaps) {
/* 106 */       if (matchDispatcher(filterMap, dispatcher))
/*     */       {
/*     */ 
/* 109 */         if (matchFiltersURL(filterMap, requestPath))
/*     */         {
/*     */ 
/*     */ 
/* 113 */           ApplicationFilterConfig filterConfig = (ApplicationFilterConfig)context.findFilterConfig(filterMap.getFilterName());
/* 114 */           if (filterConfig != null)
/*     */           {
/*     */ 
/*     */ 
/* 118 */             filterChain.addFilter(filterConfig); }
/*     */         }
/*     */       }
/*     */     }
/* 122 */     for (FilterMap filterMap : filterMaps) {
/* 123 */       if (matchDispatcher(filterMap, dispatcher))
/*     */       {
/*     */ 
/* 126 */         if (matchFiltersServlet(filterMap, servletName))
/*     */         {
/*     */ 
/*     */ 
/* 130 */           ApplicationFilterConfig filterConfig = (ApplicationFilterConfig)context.findFilterConfig(filterMap.getFilterName());
/* 131 */           if (filterConfig != null)
/*     */           {
/*     */ 
/*     */ 
/* 135 */             filterChain.addFilter(filterConfig); }
/*     */         }
/*     */       }
/*     */     }
/* 139 */     return filterChain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean matchFiltersURL(FilterMap filterMap, String requestPath)
/*     */   {
/* 158 */     if (filterMap.getMatchAllUrlPatterns()) {
/* 159 */       return true;
/*     */     }
/*     */     
/* 162 */     if (requestPath == null) {
/* 163 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 167 */     String[] testPaths = filterMap.getURLPatterns();
/*     */     
/* 169 */     for (String testPath : testPaths) {
/* 170 */       if (matchFiltersURL(testPath, requestPath)) {
/* 171 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 176 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean matchFiltersURL(String testPath, String requestPath)
/*     */   {
/* 191 */     if (testPath == null) {
/* 192 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 196 */     if (testPath.equals(requestPath)) {
/* 197 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 201 */     if (testPath.equals("/*")) {
/* 202 */       return true;
/*     */     }
/* 204 */     if (testPath.endsWith("/*")) {
/* 205 */       if (testPath.regionMatches(0, requestPath, 0, testPath
/* 206 */         .length() - 2)) {
/* 207 */         if (requestPath.length() == testPath.length() - 2)
/* 208 */           return true;
/* 209 */         if ('/' == requestPath.charAt(testPath.length() - 2)) {
/* 210 */           return true;
/*     */         }
/*     */       }
/* 213 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 217 */     if (testPath.startsWith("*.")) {
/* 218 */       int slash = requestPath.lastIndexOf('/');
/* 219 */       int period = requestPath.lastIndexOf('.');
/* 220 */       if ((slash >= 0) && (period > slash) && 
/* 221 */         (period != requestPath.length() - 1))
/*     */       {
/* 223 */         if (requestPath.length() - period == testPath.length() - 1) {
/* 224 */           return testPath.regionMatches(2, requestPath, period + 1, testPath
/* 225 */             .length() - 2);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 230 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean matchFiltersServlet(FilterMap filterMap, String servletName)
/*     */   {
/* 246 */     if (servletName == null) {
/* 247 */       return false;
/*     */     }
/*     */     
/* 250 */     if (filterMap.getMatchAllServletNames()) {
/* 251 */       return true;
/*     */     }
/* 253 */     String[] servletNames = filterMap.getServletNames();
/* 254 */     for (String name : servletNames) {
/* 255 */       if (servletName.equals(name)) {
/* 256 */         return true;
/*     */       }
/*     */     }
/* 259 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean matchDispatcher(FilterMap filterMap, DispatcherType type)
/*     */   {
/* 270 */     switch (type) {
/*     */     case FORWARD: 
/* 272 */       if ((filterMap.getDispatcherMapping() & 0x2) != 0) {
/* 273 */         return true;
/*     */       }
/*     */       break;
/*     */     case INCLUDE: 
/* 277 */       if ((filterMap.getDispatcherMapping() & 0x4) != 0) {
/* 278 */         return true;
/*     */       }
/*     */       break;
/*     */     case REQUEST: 
/* 282 */       if ((filterMap.getDispatcherMapping() & 0x8) != 0) {
/* 283 */         return true;
/*     */       }
/*     */       break;
/*     */     case ERROR: 
/* 287 */       if ((filterMap.getDispatcherMapping() & 0x1) != 0) {
/* 288 */         return true;
/*     */       }
/*     */       break;
/*     */     case ASYNC: 
/* 292 */       if ((filterMap.getDispatcherMapping() & 0x10) != 0) {
/* 293 */         return true;
/*     */       }
/*     */       break;
/*     */     }
/* 297 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\ApplicationFilterFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */