/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.catalina.security.SecurityClassLoad;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Bootstrap
/*     */ {
/*  50 */   private static final Log log = LogFactory.getLog(Bootstrap.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  55 */   private static final Object daemonLock = new Object();
/*  56 */   private static volatile Bootstrap daemon = null;
/*     */   
/*     */   private static final File catalinaBaseFile;
/*     */   
/*     */   private static final File catalinaHomeFile;
/*  61 */   private static final Pattern PATH_PATTERN = Pattern.compile("(\"[^\"]*\")|(([^,])*)");
/*     */   
/*     */   static
/*     */   {
/*  65 */     String userDir = System.getProperty("user.dir");
/*     */     
/*     */ 
/*  68 */     String home = System.getProperty("catalina.home");
/*  69 */     File homeFile = null;
/*     */     
/*  71 */     if (home != null) {
/*  72 */       File f = new File(home);
/*     */       try {
/*  74 */         homeFile = f.getCanonicalFile();
/*     */       } catch (IOException ioe) {
/*  76 */         homeFile = f.getAbsoluteFile();
/*     */       }
/*     */     }
/*     */     
/*  80 */     if (homeFile == null)
/*     */     {
/*     */ 
/*  83 */       File bootstrapJar = new File(userDir, "bootstrap.jar");
/*     */       
/*  85 */       if (bootstrapJar.exists()) {
/*  86 */         File f = new File(userDir, "..");
/*     */         try {
/*  88 */           homeFile = f.getCanonicalFile();
/*     */         } catch (IOException ioe) {
/*  90 */           homeFile = f.getAbsoluteFile();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  95 */     if (homeFile == null)
/*     */     {
/*  97 */       File f = new File(userDir);
/*     */       try {
/*  99 */         homeFile = f.getCanonicalFile();
/*     */       } catch (IOException ioe) {
/* 101 */         homeFile = f.getAbsoluteFile();
/*     */       }
/*     */     }
/*     */     
/* 105 */     catalinaHomeFile = homeFile;
/* 106 */     System.setProperty("catalina.home", catalinaHomeFile
/* 107 */       .getPath());
/*     */     
/*     */ 
/* 110 */     String base = System.getProperty("catalina.base");
/* 111 */     if (base == null) {
/* 112 */       catalinaBaseFile = catalinaHomeFile;
/*     */     } else {
/* 114 */       File baseFile = new File(base);
/*     */       try {
/* 116 */         baseFile = baseFile.getCanonicalFile();
/*     */       } catch (IOException ioe) {
/* 118 */         baseFile = baseFile.getAbsoluteFile();
/*     */       }
/* 120 */       catalinaBaseFile = baseFile;
/*     */     }
/* 122 */     System.setProperty("catalina.base", catalinaBaseFile
/* 123 */       .getPath());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */   private Object catalinaDaemon = null;
/*     */   
/* 134 */   ClassLoader commonLoader = null;
/* 135 */   ClassLoader catalinaLoader = null;
/* 136 */   ClassLoader sharedLoader = null;
/*     */   
/*     */ 
/*     */ 
/*     */   private void initClassLoaders()
/*     */   {
/*     */     try
/*     */     {
/* 144 */       this.commonLoader = createClassLoader("common", null);
/* 145 */       if (this.commonLoader == null)
/*     */       {
/* 147 */         this.commonLoader = getClass().getClassLoader();
/*     */       }
/* 149 */       this.catalinaLoader = createClassLoader("server", this.commonLoader);
/* 150 */       this.sharedLoader = createClassLoader("shared", this.commonLoader);
/*     */     } catch (Throwable t) {
/* 152 */       handleThrowable(t);
/* 153 */       log.error("Class loader creation threw exception", t);
/* 154 */       System.exit(1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private ClassLoader createClassLoader(String name, ClassLoader parent)
/*     */     throws Exception
/*     */   {
/* 162 */     String value = CatalinaProperties.getProperty(name + ".loader");
/* 163 */     if ((value == null) || (value.equals(""))) {
/* 164 */       return parent;
/*     */     }
/*     */     
/* 167 */     value = replace(value);
/*     */     
/* 169 */     List<ClassLoaderFactory.Repository> repositories = new ArrayList();
/*     */     
/* 171 */     String[] repositoryPaths = getPaths(value);
/*     */     
/* 173 */     for (String repository : repositoryPaths)
/*     */     {
/*     */       try
/*     */       {
/* 177 */         URL url = new URL(repository);
/* 178 */         repositories.add(new ClassLoaderFactory.Repository(repository, ClassLoaderFactory.RepositoryType.URL));
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (MalformedURLException localMalformedURLException)
/*     */       {
/*     */ 
/* 185 */         if (repository.endsWith("*.jar"))
/*     */         {
/* 187 */           repository = repository.substring(0, repository.length() - "*.jar".length());
/* 188 */           repositories.add(new ClassLoaderFactory.Repository(repository, ClassLoaderFactory.RepositoryType.GLOB));
/* 189 */         } else if (repository.endsWith(".jar")) {
/* 190 */           repositories.add(new ClassLoaderFactory.Repository(repository, ClassLoaderFactory.RepositoryType.JAR));
/*     */         } else {
/* 192 */           repositories.add(new ClassLoaderFactory.Repository(repository, ClassLoaderFactory.RepositoryType.DIR));
/*     */         }
/*     */       }
/*     */     }
/* 196 */     return ClassLoaderFactory.createClassLoader(repositories, parent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String replace(String str)
/*     */   {
/* 209 */     String result = str;
/* 210 */     int pos_start = str.indexOf("${");
/* 211 */     if (pos_start >= 0) {
/* 212 */       StringBuilder builder = new StringBuilder();
/* 213 */       int pos_end = -1;
/* 214 */       while (pos_start >= 0) {
/* 215 */         builder.append(str, pos_end + 1, pos_start);
/* 216 */         pos_end = str.indexOf('}', pos_start + 2);
/* 217 */         if (pos_end < 0) {
/* 218 */           pos_end = pos_start - 1;
/* 219 */           break;
/*     */         }
/* 221 */         String propName = str.substring(pos_start + 2, pos_end);
/*     */         String replacement;
/* 223 */         String replacement; if (propName.length() == 0) {
/* 224 */           replacement = null; } else { String replacement;
/* 225 */           if ("catalina.home".equals(propName)) {
/* 226 */             replacement = getCatalinaHome(); } else { String replacement;
/* 227 */             if ("catalina.base".equals(propName)) {
/* 228 */               replacement = getCatalinaBase();
/*     */             } else
/* 230 */               replacement = System.getProperty(propName);
/*     */           } }
/* 232 */         if (replacement != null) {
/* 233 */           builder.append(replacement);
/*     */         } else {
/* 235 */           builder.append(str, pos_start, pos_end + 1);
/*     */         }
/* 237 */         pos_start = str.indexOf("${", pos_end + 1);
/*     */       }
/* 239 */       builder.append(str, pos_end + 1, str.length());
/* 240 */       result = builder.toString();
/*     */     }
/* 242 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init()
/*     */     throws Exception
/*     */   {
/* 252 */     initClassLoaders();
/*     */     
/* 254 */     Thread.currentThread().setContextClassLoader(this.catalinaLoader);
/*     */     
/* 256 */     SecurityClassLoad.securityClassLoad(this.catalinaLoader);
/*     */     
/*     */ 
/* 259 */     if (log.isDebugEnabled()) {
/* 260 */       log.debug("Loading startup class");
/*     */     }
/* 262 */     Class<?> startupClass = this.catalinaLoader.loadClass("org.apache.catalina.startup.Catalina");
/* 263 */     Object startupInstance = startupClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */     
/*     */ 
/* 266 */     if (log.isDebugEnabled()) {
/* 267 */       log.debug("Setting startup class properties");
/*     */     }
/* 269 */     String methodName = "setParentClassLoader";
/* 270 */     Class<?>[] paramTypes = new Class[1];
/* 271 */     paramTypes[0] = Class.forName("java.lang.ClassLoader");
/* 272 */     Object[] paramValues = new Object[1];
/* 273 */     paramValues[0] = this.sharedLoader;
/*     */     
/* 275 */     Method method = startupInstance.getClass().getMethod(methodName, paramTypes);
/* 276 */     method.invoke(startupInstance, paramValues);
/*     */     
/* 278 */     this.catalinaDaemon = startupInstance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void load(String[] arguments)
/*     */     throws Exception
/*     */   {
/* 288 */     String methodName = "load";
/*     */     Object[] param;
/*     */     Class<?>[] paramTypes;
/* 291 */     Object[] param; if ((arguments == null) || (arguments.length == 0)) {
/* 292 */       Class<?>[] paramTypes = null;
/* 293 */       param = null;
/*     */     } else {
/* 295 */       paramTypes = new Class[1];
/* 296 */       paramTypes[0] = arguments.getClass();
/* 297 */       param = new Object[1];
/* 298 */       param[0] = arguments;
/*     */     }
/*     */     
/* 301 */     Method method = this.catalinaDaemon.getClass().getMethod(methodName, paramTypes);
/* 302 */     if (log.isDebugEnabled()) {
/* 303 */       log.debug("Calling startup class " + method);
/*     */     }
/* 305 */     method.invoke(this.catalinaDaemon, param);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object getServer()
/*     */     throws Exception
/*     */   {
/* 314 */     String methodName = "getServer";
/* 315 */     Method method = this.catalinaDaemon.getClass().getMethod(methodName, new Class[0]);
/* 316 */     return method.invoke(this.catalinaDaemon, new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init(String[] arguments)
/*     */     throws Exception
/*     */   {
/* 330 */     init();
/* 331 */     load(arguments);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */     throws Exception
/*     */   {
/* 340 */     if (this.catalinaDaemon == null) {
/* 341 */       init();
/*     */     }
/*     */     
/* 344 */     Method method = this.catalinaDaemon.getClass().getMethod("start", (Class[])null);
/* 345 */     method.invoke(this.catalinaDaemon, (Object[])null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */     throws Exception
/*     */   {
/* 354 */     Method method = this.catalinaDaemon.getClass().getMethod("stop", (Class[])null);
/* 355 */     method.invoke(this.catalinaDaemon, (Object[])null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stopServer()
/*     */     throws Exception
/*     */   {
/* 366 */     Method method = this.catalinaDaemon.getClass().getMethod("stopServer", (Class[])null);
/* 367 */     method.invoke(this.catalinaDaemon, (Object[])null);
/*     */   }
/*     */   
/*     */ 
/*     */   public void stopServer(String[] arguments)
/*     */     throws Exception
/*     */   {
/*     */     Object[] param;
/*     */     
/*     */     Class<?>[] paramTypes;
/*     */     
/*     */     Object[] param;
/*     */     
/* 380 */     if ((arguments == null) || (arguments.length == 0)) {
/* 381 */       Class<?>[] paramTypes = null;
/* 382 */       param = null;
/*     */     } else {
/* 384 */       paramTypes = new Class[1];
/* 385 */       paramTypes[0] = arguments.getClass();
/* 386 */       param = new Object[1];
/* 387 */       param[0] = arguments;
/*     */     }
/*     */     
/* 390 */     Method method = this.catalinaDaemon.getClass().getMethod("stopServer", paramTypes);
/* 391 */     method.invoke(this.catalinaDaemon, param);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAwait(boolean await)
/*     */     throws Exception
/*     */   {
/* 403 */     Class<?>[] paramTypes = new Class[1];
/* 404 */     paramTypes[0] = Boolean.TYPE;
/* 405 */     Object[] paramValues = new Object[1];
/* 406 */     paramValues[0] = Boolean.valueOf(await);
/*     */     
/* 408 */     Method method = this.catalinaDaemon.getClass().getMethod("setAwait", paramTypes);
/* 409 */     method.invoke(this.catalinaDaemon, paramValues);
/*     */   }
/*     */   
/*     */   public boolean getAwait() throws Exception {
/* 413 */     Class<?>[] paramTypes = new Class[0];
/* 414 */     Object[] paramValues = new Object[0];
/*     */     
/* 416 */     Method method = this.catalinaDaemon.getClass().getMethod("getAwait", paramTypes);
/* 417 */     Boolean b = (Boolean)method.invoke(this.catalinaDaemon, paramValues);
/* 418 */     return b.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 440 */     synchronized (daemonLock) {
/* 441 */       if (daemon == null)
/*     */       {
/* 443 */         Bootstrap bootstrap = new Bootstrap();
/*     */         try {
/* 445 */           bootstrap.init();
/*     */         } catch (Throwable t) {
/* 447 */           handleThrowable(t);
/* 448 */           t.printStackTrace();
/* 449 */           return;
/*     */         }
/* 451 */         daemon = bootstrap;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 456 */         Thread.currentThread().setContextClassLoader(daemon.catalinaLoader);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 461 */       String command = "start";
/* 462 */       if (args.length > 0) {
/* 463 */         command = args[(args.length - 1)];
/*     */       }
/*     */       
/* 466 */       if (command.equals("startd")) {
/* 467 */         args[(args.length - 1)] = "start";
/* 468 */         daemon.load(args);
/* 469 */         daemon.start();
/* 470 */       } else if (command.equals("stopd")) {
/* 471 */         args[(args.length - 1)] = "stop";
/* 472 */         daemon.stop();
/* 473 */       } else if (command.equals("start")) {
/* 474 */         daemon.setAwait(true);
/* 475 */         daemon.load(args);
/* 476 */         daemon.start();
/* 477 */         if (null == daemon.getServer()) {
/* 478 */           System.exit(1);
/*     */         }
/* 480 */       } else if (command.equals("stop")) {
/* 481 */         daemon.stopServer(args);
/* 482 */       } else if (command.equals("configtest")) {
/* 483 */         daemon.load(args);
/* 484 */         if (null == daemon.getServer()) {
/* 485 */           System.exit(1);
/*     */         }
/* 487 */         System.exit(0);
/*     */       } else {
/* 489 */         log.warn("Bootstrap: command \"" + command + "\" does not exist.");
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/* 493 */       if (((t instanceof InvocationTargetException)) && 
/* 494 */         (t.getCause() != null)) {
/* 495 */         t = t.getCause();
/*     */       }
/* 497 */       handleThrowable(t);
/* 498 */       t.printStackTrace();
/* 499 */       System.exit(1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCatalinaHome()
/*     */   {
/* 510 */     return catalinaHomeFile.getPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCatalinaBase()
/*     */   {
/* 521 */     return catalinaBaseFile.getPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static File getCatalinaHomeFile()
/*     */   {
/* 531 */     return catalinaHomeFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static File getCatalinaBaseFile()
/*     */   {
/* 542 */     return catalinaBaseFile;
/*     */   }
/*     */   
/*     */ 
/*     */   static void handleThrowable(Throwable t)
/*     */   {
/* 548 */     if ((t instanceof ThreadDeath)) {
/* 549 */       throw ((ThreadDeath)t);
/*     */     }
/* 551 */     if ((t instanceof StackOverflowError))
/*     */     {
/* 553 */       return;
/*     */     }
/* 555 */     if ((t instanceof VirtualMachineError)) {
/* 556 */       throw ((VirtualMachineError)t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static Throwable unwrapInvocationTargetException(Throwable t)
/*     */   {
/* 563 */     if (((t instanceof InvocationTargetException)) && (t.getCause() != null)) {
/* 564 */       return t.getCause();
/*     */     }
/* 566 */     return t;
/*     */   }
/*     */   
/*     */ 
/*     */   protected static String[] getPaths(String value)
/*     */   {
/* 572 */     List<String> result = new ArrayList();
/* 573 */     Matcher matcher = PATH_PATTERN.matcher(value);
/*     */     
/* 575 */     while (matcher.find()) {
/* 576 */       String path = value.substring(matcher.start(), matcher.end());
/*     */       
/* 578 */       path = path.trim();
/* 579 */       if (path.length() != 0)
/*     */       {
/*     */ 
/*     */ 
/* 583 */         char first = path.charAt(0);
/* 584 */         char last = path.charAt(path.length() - 1);
/*     */         
/* 586 */         if ((first == '"') && (last == '"') && (path.length() > 1)) {
/* 587 */           path = path.substring(1, path.length() - 1);
/* 588 */           path = path.trim();
/* 589 */           if (path.length() != 0) {}
/*     */ 
/*     */         }
/* 592 */         else if (path.contains("\""))
/*     */         {
/*     */ 
/*     */ 
/* 596 */           throw new IllegalArgumentException("The double quote [\"] character can only be used to quote paths. It must not appear in a path. This loader path is not valid: [" + value + "]");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 603 */         result.add(path);
/*     */       }
/*     */     }
/* 606 */     return (String[])result.toArray(new String[0]);
/*     */   }
/*     */   
/*     */   public void destroy() {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\Bootstrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */