/*    */ package org.apache.catalina.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TLSUtil
/*    */ {
/*    */   public static boolean isTLSRequestAttribute(String name)
/*    */   {
/* 36 */     switch (name) {
/*    */     case "javax.servlet.request.X509Certificate": 
/*    */     case "javax.servlet.request.cipher_suite": 
/*    */     case "javax.servlet.request.key_size": 
/*    */     case "javax.servlet.request.ssl_session_id": 
/*    */     case "javax.servlet.request.ssl_session_mgr": 
/*    */     case "org.apache.tomcat.util.net.secure_protocol_version": 
/*    */     case "org.apache.tomcat.util.net.secure_requested_protocol_versions": 
/*    */     case "org.apache.tomcat.util.net.secure_requested_ciphers": 
/* 45 */       return true;
/*    */     }
/* 47 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\TLSUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */