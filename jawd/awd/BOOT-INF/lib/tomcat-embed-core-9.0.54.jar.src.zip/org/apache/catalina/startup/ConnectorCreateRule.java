/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.coyote.http11.AbstractHttp11JsseProtocol;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.IntrospectionUtils;
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.digester.Rule;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectorCreateRule
/*     */   extends Rule
/*     */ {
/*  40 */   private static final Log log = LogFactory.getLog(ConnectorCreateRule.class);
/*  41 */   protected static final StringManager sm = StringManager.getManager(ConnectorCreateRule.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void begin(String namespace, String name, Attributes attributes)
/*     */     throws Exception
/*     */   {
/*  58 */     Service svc = (Service)this.digester.peek();
/*  59 */     org.apache.catalina.Executor ex = null;
/*  60 */     String executorName = attributes.getValue("executor");
/*  61 */     if (executorName != null) {
/*  62 */       ex = svc.getExecutor(executorName);
/*     */     }
/*  64 */     String protocolName = attributes.getValue("protocol");
/*  65 */     Connector con = new Connector(protocolName);
/*  66 */     if (ex != null) {
/*  67 */       setExecutor(con, ex);
/*     */     }
/*  69 */     String sslImplementationName = attributes.getValue("sslImplementationName");
/*  70 */     if (sslImplementationName != null) {
/*  71 */       setSSLImplementationName(con, sslImplementationName);
/*     */     }
/*  73 */     this.digester.push(con);
/*     */     
/*  75 */     StringBuilder code = this.digester.getGeneratedCode();
/*  76 */     if (code != null) {
/*  77 */       code.append(System.lineSeparator());
/*  78 */       code.append(Connector.class.getName()).append(' ').append(this.digester.toVariableName(con));
/*  79 */       code.append(" = new ").append(Connector.class.getName());
/*  80 */       code.append("(new ").append(con.getProtocolHandlerClassName()).append("());");
/*  81 */       code.append(System.lineSeparator());
/*  82 */       if (ex != null) {
/*  83 */         code.append(this.digester.toVariableName(con)).append(".getProtocolHandler().setExecutor(");
/*  84 */         code.append(this.digester.toVariableName(svc)).append(".getExecutor(").append(executorName);
/*  85 */         code.append("));");
/*  86 */         code.append(System.lineSeparator());
/*     */       }
/*  88 */       if (sslImplementationName != null) {
/*  89 */         code.append("((").append(AbstractHttp11JsseProtocol.class.getName()).append("<?>) ");
/*  90 */         code.append(this.digester.toVariableName(con)).append(".getProtocolHandler()).setSslImplementationName(\"");
/*  91 */         code.append(sslImplementationName).append("\");");
/*  92 */         code.append(System.lineSeparator());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static void setExecutor(Connector con, org.apache.catalina.Executor ex) throws Exception {
/*  98 */     Method m = IntrospectionUtils.findMethod(con.getProtocolHandler().getClass(), "setExecutor", new Class[] { java.util.concurrent.Executor.class });
/*  99 */     if (m != null) {
/* 100 */       m.invoke(con.getProtocolHandler(), new Object[] { ex });
/*     */     } else {
/* 102 */       log.warn(sm.getString("connector.noSetExecutor", new Object[] { con }));
/*     */     }
/*     */   }
/*     */   
/*     */   private static void setSSLImplementationName(Connector con, String sslImplementationName) throws Exception {
/* 107 */     Method m = IntrospectionUtils.findMethod(con.getProtocolHandler().getClass(), "setSslImplementationName", new Class[] { String.class });
/* 108 */     if (m != null) {
/* 109 */       m.invoke(con.getProtocolHandler(), new Object[] { sslImplementationName });
/*     */     } else {
/* 111 */       log.warn(sm.getString("connector.noSetSSLImplementationName", new Object[] { con }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void end(String namespace, String name)
/*     */     throws Exception
/*     */   {
/* 126 */     this.digester.pop();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\ConnectorCreateRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */