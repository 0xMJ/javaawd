/*      */ package org.apache.catalina.session;
/*      */ 
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.IOException;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import org.apache.catalina.Lifecycle;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.Store;
/*      */ import org.apache.catalina.StoreManager;
/*      */ import org.apache.catalina.security.SecurityUtil;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class PersistentManagerBase
/*      */   extends ManagerBase
/*      */   implements StoreManager
/*      */ {
/*   53 */   private final Log log = LogFactory.getLog(PersistentManagerBase.class);
/*      */   
/*      */   private static final String name = "PersistentManagerBase";
/*      */   private static final String PERSISTED_LAST_ACCESSED_TIME = "org.apache.catalina.session.PersistentManagerBase.persistedLastAccessedTime";
/*      */   
/*      */   private class PrivilegedStoreClear
/*      */     implements PrivilegedExceptionAction<Void>
/*      */   {
/*      */     PrivilegedStoreClear() {}
/*      */     
/*      */     public Void run()
/*      */       throws Exception
/*      */     {
/*   66 */       PersistentManagerBase.this.store.clear();
/*   67 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   private class PrivilegedStoreRemove implements PrivilegedExceptionAction<Void>
/*      */   {
/*      */     private String id;
/*      */     
/*      */     PrivilegedStoreRemove(String id)
/*      */     {
/*   77 */       this.id = id;
/*      */     }
/*      */     
/*      */     public Void run() throws Exception
/*      */     {
/*   82 */       PersistentManagerBase.this.store.remove(this.id);
/*   83 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   private class PrivilegedStoreLoad implements PrivilegedExceptionAction<Session>
/*      */   {
/*      */     private String id;
/*      */     
/*      */     PrivilegedStoreLoad(String id)
/*      */     {
/*   93 */       this.id = id;
/*      */     }
/*      */     
/*      */     public Session run() throws Exception
/*      */     {
/*   98 */       return PersistentManagerBase.this.store.load(this.id);
/*      */     }
/*      */   }
/*      */   
/*      */   private class PrivilegedStoreSave implements PrivilegedExceptionAction<Void>
/*      */   {
/*      */     private Session session;
/*      */     
/*      */     PrivilegedStoreSave(Session session)
/*      */     {
/*  108 */       this.session = session;
/*      */     }
/*      */     
/*      */     public Void run() throws Exception
/*      */     {
/*  113 */       PersistentManagerBase.this.store.save(this.session);
/*  114 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private class PrivilegedStoreKeys
/*      */     implements PrivilegedExceptionAction<String[]>
/*      */   {
/*      */     PrivilegedStoreKeys() {}
/*      */     
/*      */     public String[] run()
/*      */       throws Exception
/*      */     {
/*  127 */       return PersistentManagerBase.this.store.keys();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  148 */   protected Store store = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  155 */   protected boolean saveOnRestart = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  162 */   protected int maxIdleBackup = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  171 */   protected int minIdleSwap = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  179 */   protected int maxIdleSwap = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  185 */   private final Map<String, Object> sessionSwapInLocks = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  191 */   private final ThreadLocal<Session> sessionToSwapIn = new ThreadLocal();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxIdleBackup()
/*      */   {
/*  206 */     return this.maxIdleBackup;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxIdleBackup(int backup)
/*      */   {
/*  233 */     if (backup == this.maxIdleBackup) {
/*  234 */       return;
/*      */     }
/*  236 */     int oldBackup = this.maxIdleBackup;
/*  237 */     this.maxIdleBackup = backup;
/*  238 */     this.support.firePropertyChange("maxIdleBackup", 
/*  239 */       Integer.valueOf(oldBackup), 
/*  240 */       Integer.valueOf(this.maxIdleBackup));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxIdleSwap()
/*      */   {
/*  251 */     return this.maxIdleSwap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxIdleSwap(int max)
/*      */   {
/*  265 */     if (max == this.maxIdleSwap) {
/*  266 */       return;
/*      */     }
/*  268 */     int oldMaxIdleSwap = this.maxIdleSwap;
/*  269 */     this.maxIdleSwap = max;
/*  270 */     this.support.firePropertyChange("maxIdleSwap", 
/*  271 */       Integer.valueOf(oldMaxIdleSwap), 
/*  272 */       Integer.valueOf(this.maxIdleSwap));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMinIdleSwap()
/*      */   {
/*  283 */     return this.minIdleSwap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMinIdleSwap(int min)
/*      */   {
/*  297 */     if (this.minIdleSwap == min) {
/*  298 */       return;
/*      */     }
/*  300 */     int oldMinIdleSwap = this.minIdleSwap;
/*  301 */     this.minIdleSwap = min;
/*  302 */     this.support.firePropertyChange("minIdleSwap", 
/*  303 */       Integer.valueOf(oldMinIdleSwap), 
/*  304 */       Integer.valueOf(this.minIdleSwap));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isLoaded(String id)
/*      */   {
/*      */     try
/*      */     {
/*  318 */       if (super.findSession(id) != null) {
/*  319 */         return true;
/*      */       }
/*      */     } catch (IOException e) {
/*  322 */       this.log.error(sm.getString("persistentManager.isLoadedError", new Object[] { id }), e);
/*      */     }
/*  324 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getName()
/*      */   {
/*  330 */     return "PersistentManagerBase";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStore(Store store)
/*      */   {
/*  341 */     this.store = store;
/*  342 */     store.setManager(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Store getStore()
/*      */   {
/*  352 */     return this.store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSaveOnRestart()
/*      */   {
/*  365 */     return this.saveOnRestart;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSaveOnRestart(boolean saveOnRestart)
/*      */   {
/*  381 */     if (saveOnRestart == this.saveOnRestart) {
/*  382 */       return;
/*      */     }
/*      */     
/*  385 */     boolean oldSaveOnRestart = this.saveOnRestart;
/*  386 */     this.saveOnRestart = saveOnRestart;
/*  387 */     this.support.firePropertyChange("saveOnRestart", 
/*  388 */       Boolean.valueOf(oldSaveOnRestart), 
/*  389 */       Boolean.valueOf(this.saveOnRestart));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearStore()
/*      */   {
/*  402 */     if (this.store == null) {
/*  403 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  407 */       if (SecurityUtil.isPackageProtectionEnabled()) {
/*      */         try {
/*  409 */           AccessController.doPrivileged(new PrivilegedStoreClear());
/*      */         } catch (PrivilegedActionException e) {
/*  411 */           this.log.error(sm.getString("persistentManager.storeClearError"), e.getException());
/*      */         }
/*      */       } else {
/*  414 */         this.store.clear();
/*      */       }
/*      */     } catch (IOException e) {
/*  417 */       this.log.error(sm.getString("persistentManager.storeClearError"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void processExpires()
/*      */   {
/*  431 */     long timeNow = System.currentTimeMillis();
/*  432 */     Session[] sessions = findSessions();
/*  433 */     int expireHere = 0;
/*  434 */     if (this.log.isDebugEnabled()) {
/*  435 */       this.log.debug("Start expire sessions " + getName() + " at " + timeNow + " sessioncount " + sessions.length);
/*      */     }
/*  437 */     for (Session session : sessions) {
/*  438 */       if (!session.isValid()) {
/*  439 */         this.expiredSessions.incrementAndGet();
/*  440 */         expireHere++;
/*      */       }
/*      */     }
/*  443 */     processPersistenceChecks();
/*  444 */     if ((getStore() instanceof StoreBase)) {
/*  445 */       ((StoreBase)getStore()).processExpires();
/*      */     }
/*      */     
/*  448 */     long timeEnd = System.currentTimeMillis();
/*  449 */     if (this.log.isDebugEnabled()) {
/*  450 */       this.log.debug("End expire sessions " + getName() + " processingTime " + (timeEnd - timeNow) + " expired sessions: " + expireHere);
/*      */     }
/*  452 */     this.processingTime += timeEnd - timeNow;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void processPersistenceChecks()
/*      */   {
/*  463 */     processMaxIdleSwaps();
/*  464 */     processMaxActiveSwaps();
/*  465 */     processMaxIdleBackups();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Session findSession(String id)
/*      */     throws IOException
/*      */   {
/*  479 */     Session session = super.findSession(id);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  486 */     if (session != null) {
/*  487 */       synchronized (session) {
/*  488 */         session = super.findSession(session.getIdInternal());
/*  489 */         if (session != null)
/*      */         {
/*      */ 
/*  492 */           session.access();
/*  493 */           session.endAccess();
/*      */         }
/*      */       }
/*      */     }
/*  497 */     if (session != null) {
/*  498 */       return session;
/*      */     }
/*      */     
/*      */ 
/*  502 */     session = swapIn(id);
/*  503 */     return session;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSuper(Session session)
/*      */   {
/*  514 */     super.remove(session, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void load()
/*      */   {
/*  531 */     this.sessions.clear();
/*      */     
/*  533 */     if (this.store == null) {
/*  534 */       return;
/*      */     }
/*      */     
/*  537 */     String[] ids = null;
/*      */     try {
/*  539 */       if (SecurityUtil.isPackageProtectionEnabled()) {
/*      */         try {
/*  541 */           ids = (String[])AccessController.doPrivileged(new PrivilegedStoreKeys());
/*      */         } catch (PrivilegedActionException e) {
/*  543 */           this.log.error(sm.getString("persistentManager.storeLoadKeysError"), e
/*  544 */             .getException());
/*  545 */           return;
/*      */         }
/*      */       } else {
/*  548 */         ids = this.store.keys();
/*      */       }
/*      */     } catch (IOException e) {
/*  551 */       this.log.error(sm.getString("persistentManager.storeLoadKeysError"), e);
/*  552 */       return;
/*      */     }
/*      */     
/*  555 */     int n = ids.length;
/*  556 */     if (n == 0) {
/*  557 */       return;
/*      */     }
/*      */     
/*  560 */     if (this.log.isDebugEnabled()) {
/*  561 */       this.log.debug(sm.getString("persistentManager.loading", new Object[] { String.valueOf(n) }));
/*      */     }
/*      */     
/*  564 */     for (String id : ids) {
/*      */       try {
/*  566 */         swapIn(id);
/*      */       } catch (IOException e) {
/*  568 */         this.log.error(sm.getString("persistentManager.storeLoadError"), e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(Session session, boolean update)
/*      */   {
/*  583 */     super.remove(session, update);
/*      */     
/*  585 */     if (this.store != null) {
/*  586 */       removeSession(session.getIdInternal());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void removeSession(String id)
/*      */   {
/*      */     try
/*      */     {
/*  599 */       if (SecurityUtil.isPackageProtectionEnabled()) {
/*      */         try {
/*  601 */           AccessController.doPrivileged(new PrivilegedStoreRemove(id));
/*      */         } catch (PrivilegedActionException e) {
/*  603 */           this.log.error(sm.getString("persistentManager.removeError"), e.getException());
/*      */         }
/*      */       } else {
/*  606 */         this.store.remove(id);
/*      */       }
/*      */     } catch (IOException e) {
/*  609 */       this.log.error(sm.getString("persistentManager.removeError"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void unload()
/*      */   {
/*  625 */     if (this.store == null) {
/*  626 */       return;
/*      */     }
/*      */     
/*  629 */     Session[] sessions = findSessions();
/*  630 */     int n = sessions.length;
/*  631 */     if (n == 0) {
/*  632 */       return;
/*      */     }
/*      */     
/*  635 */     if (this.log.isDebugEnabled()) {
/*  636 */       this.log.debug(sm.getString("persistentManager.unloading", new Object[] {
/*  637 */         String.valueOf(n) }));
/*      */     }
/*      */     
/*  640 */     for (Session session : sessions) {
/*      */       try {
/*  642 */         swapOut(session);
/*      */       }
/*      */       catch (IOException localIOException) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getActiveSessionsFull()
/*      */   {
/*  654 */     int result = getActiveSessions();
/*      */     try
/*      */     {
/*  657 */       result += getStore().getSize();
/*      */     } catch (IOException ioe) {
/*  659 */       this.log.warn(sm.getString("persistentManager.storeSizeException"));
/*      */     }
/*  661 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Set<String> getSessionIdsFull()
/*      */   {
/*  668 */     Set<String> sessionIds = new HashSet(this.sessions.keySet());
/*      */     try
/*      */     {
/*  671 */       sessionIds.addAll(Arrays.asList(getStore().keys()));
/*      */     } catch (IOException e) {
/*  673 */       this.log.warn(sm.getString("persistentManager.storeKeysException"));
/*      */     }
/*  675 */     return sessionIds;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Session swapIn(String id)
/*      */     throws IOException
/*      */   {
/*  694 */     if (this.store == null) {
/*  695 */       return null;
/*      */     }
/*      */     
/*  698 */     Object swapInLock = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  708 */     synchronized (this) {
/*  709 */       swapInLock = this.sessionSwapInLocks.get(id);
/*  710 */       if (swapInLock == null) {
/*  711 */         swapInLock = new Object();
/*  712 */         this.sessionSwapInLocks.put(id, swapInLock);
/*      */       }
/*      */     }
/*      */     
/*  716 */     Session session = null;
/*      */     
/*  718 */     synchronized (swapInLock)
/*      */     {
/*      */ 
/*  721 */       session = (Session)this.sessions.get(id);
/*      */       
/*  723 */       if (session == null) {
/*  724 */         Session currentSwapInSession = (Session)this.sessionToSwapIn.get();
/*      */         try {
/*  726 */           if ((currentSwapInSession == null) || (!id.equals(currentSwapInSession.getId()))) {
/*  727 */             session = loadSessionFromStore(id);
/*  728 */             this.sessionToSwapIn.set(session);
/*      */             
/*  730 */             if ((session != null) && (!session.isValid())) {
/*  731 */               this.log.error(sm.getString("persistentManager.swapInInvalid", new Object[] { id }));
/*  732 */               session.expire();
/*  733 */               removeSession(id);
/*  734 */               session = null;
/*      */             }
/*      */             
/*  737 */             if (session != null) {
/*  738 */               reactivateLoadedSession(id, session);
/*      */             }
/*      */           }
/*      */         } finally {
/*  742 */           this.sessionToSwapIn.remove();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  748 */     synchronized (this) {
/*  749 */       this.sessionSwapInLocks.remove(id);
/*      */     }
/*      */     
/*  752 */     return session;
/*      */   }
/*      */   
/*      */   private void reactivateLoadedSession(String id, Session session)
/*      */   {
/*  757 */     if (this.log.isDebugEnabled()) {
/*  758 */       this.log.debug(sm.getString("persistentManager.swapIn", new Object[] { id }));
/*      */     }
/*      */     
/*  761 */     session.setManager(this);
/*      */     
/*  763 */     ((StandardSession)session).tellNew();
/*  764 */     add(session);
/*  765 */     ((StandardSession)session).activate();
/*      */     
/*      */ 
/*      */ 
/*  769 */     session.access();
/*  770 */     session.endAccess();
/*      */   }
/*      */   
/*      */   private Session loadSessionFromStore(String id) throws IOException {
/*      */     try {
/*  775 */       if (SecurityUtil.isPackageProtectionEnabled()) {
/*  776 */         return securedStoreLoad(id);
/*      */       }
/*  778 */       return this.store.load(id);
/*      */     }
/*      */     catch (ClassNotFoundException e) {
/*  781 */       String msg = sm.getString("persistentManager.deserializeError", new Object[] { id });
/*      */       
/*  783 */       this.log.error(msg, e);
/*  784 */       throw new IllegalStateException(msg, e);
/*      */     }
/*      */   }
/*      */   
/*      */   private Session securedStoreLoad(String id) throws IOException, ClassNotFoundException
/*      */   {
/*      */     try {
/*  791 */       return (Session)AccessController.doPrivileged(new PrivilegedStoreLoad(id));
/*      */     }
/*      */     catch (PrivilegedActionException ex) {
/*  794 */       Exception e = ex.getException();
/*  795 */       this.log.error(sm.getString("persistentManager.swapInException", new Object[] { id }), e);
/*      */       
/*      */ 
/*  798 */       if ((e instanceof IOException))
/*  799 */         throw ((IOException)e);
/*  800 */       if ((e instanceof ClassNotFoundException)) {
/*  801 */         throw ((ClassNotFoundException)e);
/*      */       }
/*      */     }
/*  804 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void swapOut(Session session)
/*      */     throws IOException
/*      */   {
/*  819 */     if ((this.store == null) || (!session.isValid())) {
/*  820 */       return;
/*      */     }
/*      */     
/*  823 */     ((StandardSession)session).passivate();
/*  824 */     writeSession(session);
/*  825 */     super.remove(session, true);
/*  826 */     session.recycle();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void writeSession(Session session)
/*      */     throws IOException
/*      */   {
/*  840 */     if ((this.store == null) || (!session.isValid())) {
/*  841 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  845 */       if (SecurityUtil.isPackageProtectionEnabled()) {
/*      */         try {
/*  847 */           AccessController.doPrivileged(new PrivilegedStoreSave(session));
/*      */         } catch (PrivilegedActionException ex) {
/*  849 */           Exception exception = ex.getException();
/*  850 */           if ((exception instanceof IOException)) {
/*  851 */             throw ((IOException)exception);
/*      */           }
/*  853 */           this.log.error(sm.getString("persistentManager.serializeError", new Object[] {session
/*  854 */             .getIdInternal(), exception }));
/*      */         }
/*      */       } else {
/*  857 */         this.store.save(session);
/*      */       }
/*      */     } catch (IOException e) {
/*  860 */       this.log.error(sm.getString("persistentManager.serializeError", new Object[] { session.getIdInternal(), e }));
/*  861 */       throw e;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void startInternal()
/*      */     throws LifecycleException
/*      */   {
/*  877 */     super.startInternal();
/*      */     
/*  879 */     if (this.store == null) {
/*  880 */       this.log.error("No Store configured, persistence disabled");
/*  881 */     } else if ((this.store instanceof Lifecycle)) {
/*  882 */       ((Lifecycle)this.store).start();
/*      */     }
/*      */     
/*  885 */     setState(LifecycleState.STARTING);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/*  899 */     if (this.log.isDebugEnabled()) {
/*  900 */       this.log.debug("Stopping");
/*      */     }
/*      */     
/*  903 */     setState(LifecycleState.STOPPING);
/*      */     
/*  905 */     if ((getStore() != null) && (this.saveOnRestart)) {
/*  906 */       unload();
/*      */     }
/*      */     else {
/*  909 */       Session[] sessions = findSessions();
/*  910 */       for (Session value : sessions) {
/*  911 */         StandardSession session = (StandardSession)value;
/*  912 */         if (session.isValid())
/*      */         {
/*      */ 
/*  915 */           session.expire();
/*      */         }
/*      */       }
/*      */     }
/*  919 */     if ((getStore() instanceof Lifecycle)) {
/*  920 */       ((Lifecycle)getStore()).stop();
/*      */     }
/*      */     
/*      */ 
/*  924 */     super.stopInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processMaxIdleSwaps()
/*      */   {
/*  936 */     if ((!getState().isAvailable()) || (this.maxIdleSwap < 0)) {
/*  937 */       return;
/*      */     }
/*      */     
/*  940 */     Session[] sessions = findSessions();
/*      */     
/*      */ 
/*  943 */     if (this.maxIdleSwap >= 0) {
/*  944 */       for (Session value : sessions) {
/*  945 */         StandardSession session = (StandardSession)value;
/*  946 */         synchronized (session) {
/*  947 */           if (session.isValid())
/*      */           {
/*      */ 
/*  950 */             int timeIdle = (int)(session.getIdleTimeInternal() / 1000L);
/*  951 */             if ((timeIdle >= this.maxIdleSwap) && (timeIdle >= this.minIdleSwap)) {
/*  952 */               if ((session.accessCount != null) && 
/*  953 */                 (session.accessCount.get() > 0)) {
/*      */                 continue;
/*      */               }
/*      */               
/*  957 */               if (this.log.isDebugEnabled()) {
/*  958 */                 this.log.debug(sm
/*  959 */                   .getString("persistentManager.swapMaxIdle", new Object[] {session
/*  960 */                   .getIdInternal(), 
/*  961 */                   Integer.valueOf(timeIdle) }));
/*      */               }
/*      */               try {
/*  964 */                 swapOut(session);
/*      */               }
/*      */               catch (IOException localIOException) {}
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processMaxActiveSwaps()
/*      */   {
/*  981 */     if ((!getState().isAvailable()) || (this.minIdleSwap < 0) || (getMaxActiveSessions() < 0)) {
/*  982 */       return;
/*      */     }
/*      */     
/*  985 */     Session[] sessions = findSessions();
/*      */     
/*      */ 
/*  988 */     int limit = (int)(getMaxActiveSessions() * 0.9D);
/*      */     
/*  990 */     if (limit >= sessions.length) {
/*  991 */       return;
/*      */     }
/*      */     
/*  994 */     if (this.log.isDebugEnabled()) {
/*  995 */       this.log.debug(sm
/*  996 */         .getString("persistentManager.tooManyActive", new Object[] {
/*  997 */         Integer.valueOf(sessions.length) }));
/*      */     }
/*      */     
/* 1000 */     int toswap = sessions.length - limit;
/*      */     
/* 1002 */     for (int i = 0; (i < sessions.length) && (toswap > 0); i++) {
/* 1003 */       StandardSession session = (StandardSession)sessions[i];
/* 1004 */       synchronized (session) {
/* 1005 */         int timeIdle = (int)(session.getIdleTimeInternal() / 1000L);
/* 1006 */         if (timeIdle >= this.minIdleSwap) {
/* 1007 */           if ((session.accessCount != null) && 
/* 1008 */             (session.accessCount.get() > 0)) {
/*      */             continue;
/*      */           }
/*      */           
/* 1012 */           if (this.log.isDebugEnabled()) {
/* 1013 */             this.log.debug(sm
/* 1014 */               .getString("persistentManager.swapTooManyActive", new Object[] {session
/* 1015 */               .getIdInternal(), 
/* 1016 */               Integer.valueOf(timeIdle) }));
/*      */           }
/*      */           try {
/* 1019 */             swapOut(session);
/*      */           }
/*      */           catch (IOException localIOException) {}
/*      */           
/* 1023 */           toswap--;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void processMaxIdleBackups()
/*      */   {
/* 1036 */     if ((!getState().isAvailable()) || (this.maxIdleBackup < 0)) {
/* 1037 */       return;
/*      */     }
/*      */     
/* 1040 */     Session[] sessions = findSessions();
/*      */     
/*      */ 
/* 1043 */     if (this.maxIdleBackup >= 0) {
/* 1044 */       for (Session value : sessions) {
/* 1045 */         StandardSession session = (StandardSession)value;
/* 1046 */         synchronized (session) {
/* 1047 */           if (session.isValid())
/*      */           {
/*      */ 
/* 1050 */             long lastAccessedTime = session.getLastAccessedTimeInternal();
/*      */             
/* 1052 */             Long persistedLastAccessedTime = (Long)session.getNote("org.apache.catalina.session.PersistentManagerBase.persistedLastAccessedTime");
/* 1053 */             if ((persistedLastAccessedTime == null) || 
/* 1054 */               (lastAccessedTime != persistedLastAccessedTime.longValue()))
/*      */             {
/*      */ 
/* 1057 */               int timeIdle = (int)(session.getIdleTimeInternal() / 1000L);
/* 1058 */               if (timeIdle >= this.maxIdleBackup) {
/* 1059 */                 if (this.log.isDebugEnabled()) {
/* 1060 */                   this.log.debug(sm
/* 1061 */                     .getString("persistentManager.backupMaxIdle", new Object[] {session
/* 1062 */                     .getIdInternal(), 
/* 1063 */                     Integer.valueOf(timeIdle) }));
/*      */                 }
/*      */                 try
/*      */                 {
/* 1067 */                   writeSession(session);
/*      */                 }
/*      */                 catch (IOException localIOException) {}
/*      */                 
/* 1071 */                 session.setNote("org.apache.catalina.session.PersistentManagerBase.persistedLastAccessedTime", 
/* 1072 */                   Long.valueOf(lastAccessedTime));
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\session\PersistentManagerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */