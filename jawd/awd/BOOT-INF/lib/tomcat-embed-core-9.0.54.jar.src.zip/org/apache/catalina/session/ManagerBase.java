/*      */ package org.apache.catalina.session;
/*      */ 
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Deque;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.regex.PatternSyntaxException;
/*      */ import javax.servlet.http.HttpSession;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.Lifecycle;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.SessionIdGenerator;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.catalina.util.SessionIdGeneratorBase;
/*      */ import org.apache.catalina.util.StandardSessionIdGenerator;
/*      */ import org.apache.catalina.util.ToStringUtil;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ManagerBase
/*      */   extends LifecycleMBeanBase
/*      */   implements Manager
/*      */ {
/*   64 */   private final Log log = LogFactory.getLog(ManagerBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Context context;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final String name = "ManagerBase";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   87 */   protected String secureRandomClass = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   98 */   protected String secureRandomAlgorithm = "SHA1PRNG";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  108 */   protected String secureRandomProvider = null;
/*      */   
/*  110 */   protected SessionIdGenerator sessionIdGenerator = null;
/*  111 */   protected Class<? extends SessionIdGenerator> sessionIdGeneratorClass = null;
/*      */   
/*      */ 
/*      */   protected volatile int sessionMaxAliveTime;
/*      */   
/*      */ 
/*  117 */   private final Object sessionMaxAliveTimeUpdateLock = new Object();
/*      */   
/*      */ 
/*      */   protected static final int TIMING_STATS_CACHE_SIZE = 100;
/*      */   
/*  122 */   protected final Deque<SessionTiming> sessionCreationTiming = new LinkedList();
/*      */   
/*      */ 
/*  125 */   protected final Deque<SessionTiming> sessionExpirationTiming = new LinkedList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  131 */   protected final AtomicLong expiredSessions = new AtomicLong(0L);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  138 */   protected Map<String, Session> sessions = new ConcurrentHashMap();
/*      */   
/*      */ 
/*  141 */   protected long sessionCounter = 0L;
/*      */   
/*  143 */   protected volatile int maxActive = 0;
/*      */   
/*  145 */   private final Object maxActiveUpdateLock = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  150 */   protected int maxActiveSessions = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  155 */   protected int rejectedSessions = 0;
/*      */   
/*      */ 
/*  158 */   protected volatile int duplicates = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  163 */   protected long processingTime = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  168 */   private int count = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  177 */   protected int processExpiresFrequency = 6;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  182 */   protected static final StringManager sm = StringManager.getManager(ManagerBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  187 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*      */   
/*      */ 
/*      */   private Pattern sessionAttributeNamePattern;
/*      */   
/*      */   private Pattern sessionAttributeValueClassNamePattern;
/*      */   
/*      */   private boolean warnOnSessionAttributeFilterFailure;
/*      */   
/*      */   private boolean notifyBindingListenerOnUnchangedValue;
/*      */   
/*  198 */   private boolean notifyAttributeListenerOnUnchangedValue = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  204 */   private boolean persistAuthentication = false;
/*      */   
/*      */ 
/*      */ 
/*      */   public ManagerBase()
/*      */   {
/*  210 */     if (Globals.IS_SECURITY_ENABLED)
/*      */     {
/*      */ 
/*      */ 
/*  214 */       setSessionAttributeValueClassNameFilter("java\\.lang\\.(?:Boolean|Integer|Long|Number|String)|org\\.apache\\.catalina\\.realm\\.GenericPrincipal\\$SerializablePrincipal|\\[Ljava.lang.String;");
/*      */       
/*      */ 
/*      */ 
/*  218 */       setWarnOnSessionAttributeFilterFailure(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getNotifyAttributeListenerOnUnchangedValue()
/*      */   {
/*  227 */     return this.notifyAttributeListenerOnUnchangedValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNotifyAttributeListenerOnUnchangedValue(boolean notifyAttributeListenerOnUnchangedValue)
/*      */   {
/*  234 */     this.notifyAttributeListenerOnUnchangedValue = notifyAttributeListenerOnUnchangedValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getNotifyBindingListenerOnUnchangedValue()
/*      */   {
/*  240 */     return this.notifyBindingListenerOnUnchangedValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNotifyBindingListenerOnUnchangedValue(boolean notifyBindingListenerOnUnchangedValue)
/*      */   {
/*  246 */     this.notifyBindingListenerOnUnchangedValue = notifyBindingListenerOnUnchangedValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionAttributeNameFilter()
/*      */   {
/*  261 */     if (this.sessionAttributeNamePattern == null) {
/*  262 */       return null;
/*      */     }
/*  264 */     return this.sessionAttributeNamePattern.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionAttributeNameFilter(String sessionAttributeNameFilter)
/*      */     throws PatternSyntaxException
/*      */   {
/*  282 */     if ((sessionAttributeNameFilter == null) || (sessionAttributeNameFilter.length() == 0)) {
/*  283 */       this.sessionAttributeNamePattern = null;
/*      */     } else {
/*  285 */       this.sessionAttributeNamePattern = Pattern.compile(sessionAttributeNameFilter);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Pattern getSessionAttributeNamePattern()
/*      */   {
/*  298 */     return this.sessionAttributeNamePattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionAttributeValueClassNameFilter()
/*      */   {
/*  313 */     if (this.sessionAttributeValueClassNamePattern == null) {
/*  314 */       return null;
/*      */     }
/*  316 */     return this.sessionAttributeValueClassNamePattern.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Pattern getSessionAttributeValueClassNamePattern()
/*      */   {
/*  329 */     return this.sessionAttributeValueClassNamePattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionAttributeValueClassNameFilter(String sessionAttributeValueClassNameFilter)
/*      */     throws PatternSyntaxException
/*      */   {
/*  348 */     if ((sessionAttributeValueClassNameFilter == null) || 
/*  349 */       (sessionAttributeValueClassNameFilter.length() == 0)) {
/*  350 */       this.sessionAttributeValueClassNamePattern = null;
/*      */     }
/*      */     else {
/*  353 */       this.sessionAttributeValueClassNamePattern = Pattern.compile(sessionAttributeValueClassNameFilter);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getWarnOnSessionAttributeFilterFailure()
/*      */   {
/*  365 */     return this.warnOnSessionAttributeFilterFailure;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWarnOnSessionAttributeFilterFailure(boolean warnOnSessionAttributeFilterFailure)
/*      */   {
/*  379 */     this.warnOnSessionAttributeFilterFailure = warnOnSessionAttributeFilterFailure;
/*      */   }
/*      */   
/*      */ 
/*      */   public Context getContext()
/*      */   {
/*  385 */     return this.context;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setContext(Context context)
/*      */   {
/*  391 */     if (this.context == context)
/*      */     {
/*  393 */       return;
/*      */     }
/*  395 */     if (!getState().equals(LifecycleState.NEW)) {
/*  396 */       throw new IllegalStateException(sm.getString("managerBase.setContextNotNew"));
/*      */     }
/*  398 */     Context oldContext = this.context;
/*  399 */     this.context = context;
/*  400 */     this.support.firePropertyChange("context", oldContext, this.context);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getClassName()
/*      */   {
/*  408 */     return getClass().getName();
/*      */   }
/*      */   
/*      */ 
/*      */   public SessionIdGenerator getSessionIdGenerator()
/*      */   {
/*  414 */     if (this.sessionIdGenerator != null)
/*  415 */       return this.sessionIdGenerator;
/*  416 */     if (this.sessionIdGeneratorClass != null) {
/*      */       try {
/*  418 */         this.sessionIdGenerator = ((SessionIdGenerator)this.sessionIdGeneratorClass.getConstructor(new Class[0]).newInstance(new Object[0]));
/*  419 */         return this.sessionIdGenerator;
/*      */       }
/*      */       catch (ReflectiveOperationException localReflectiveOperationException) {}
/*      */     }
/*      */     
/*  424 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSessionIdGenerator(SessionIdGenerator sessionIdGenerator)
/*      */   {
/*  430 */     this.sessionIdGenerator = sessionIdGenerator;
/*  431 */     this.sessionIdGeneratorClass = sessionIdGenerator.getClass();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  439 */     return "ManagerBase";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getSecureRandomClass()
/*      */   {
/*  446 */     return this.secureRandomClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureRandomClass(String secureRandomClass)
/*      */   {
/*  458 */     String oldSecureRandomClass = this.secureRandomClass;
/*  459 */     this.secureRandomClass = secureRandomClass;
/*  460 */     this.support.firePropertyChange("secureRandomClass", oldSecureRandomClass, this.secureRandomClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecureRandomAlgorithm()
/*      */   {
/*  470 */     return this.secureRandomAlgorithm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureRandomAlgorithm(String secureRandomAlgorithm)
/*      */   {
/*  481 */     this.secureRandomAlgorithm = secureRandomAlgorithm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecureRandomProvider()
/*      */   {
/*  489 */     return this.secureRandomProvider;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureRandomProvider(String secureRandomProvider)
/*      */   {
/*  500 */     this.secureRandomProvider = secureRandomProvider;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getRejectedSessions()
/*      */   {
/*  506 */     return this.rejectedSessions;
/*      */   }
/*      */   
/*      */ 
/*      */   public long getExpiredSessions()
/*      */   {
/*  512 */     return this.expiredSessions.get();
/*      */   }
/*      */   
/*      */ 
/*      */   public void setExpiredSessions(long expiredSessions)
/*      */   {
/*  518 */     this.expiredSessions.set(expiredSessions);
/*      */   }
/*      */   
/*      */   public long getProcessingTime() {
/*  522 */     return this.processingTime;
/*      */   }
/*      */   
/*      */   public void setProcessingTime(long processingTime)
/*      */   {
/*  527 */     this.processingTime = processingTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getProcessExpiresFrequency()
/*      */   {
/*  534 */     return this.processExpiresFrequency;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProcessExpiresFrequency(int processExpiresFrequency)
/*      */   {
/*  544 */     if (processExpiresFrequency <= 0) {
/*  545 */       return;
/*      */     }
/*      */     
/*  548 */     int oldProcessExpiresFrequency = this.processExpiresFrequency;
/*  549 */     this.processExpiresFrequency = processExpiresFrequency;
/*  550 */     this.support.firePropertyChange("processExpiresFrequency", 
/*  551 */       Integer.valueOf(oldProcessExpiresFrequency), 
/*  552 */       Integer.valueOf(this.processExpiresFrequency));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getPersistAuthentication()
/*      */   {
/*  565 */     return this.persistAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPersistAuthentication(boolean persistAuthentication)
/*      */   {
/*  576 */     this.persistAuthentication = persistAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void backgroundProcess()
/*      */   {
/*  589 */     this.count = ((this.count + 1) % this.processExpiresFrequency);
/*  590 */     if (this.count == 0) {
/*  591 */       processExpires();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void processExpires()
/*      */   {
/*  600 */     long timeNow = System.currentTimeMillis();
/*  601 */     Session[] sessions = findSessions();
/*  602 */     int expireHere = 0;
/*      */     
/*  604 */     if (this.log.isDebugEnabled()) {
/*  605 */       this.log.debug("Start expire sessions " + getName() + " at " + timeNow + " sessioncount " + sessions.length);
/*      */     }
/*  607 */     for (Session session : sessions) {
/*  608 */       if ((session != null) && (!session.isValid())) {
/*  609 */         expireHere++;
/*      */       }
/*      */     }
/*  612 */     long timeEnd = System.currentTimeMillis();
/*  613 */     if (this.log.isDebugEnabled()) {
/*  614 */       this.log.debug("End expire sessions " + getName() + " processingTime " + (timeEnd - timeNow) + " expired sessions: " + expireHere);
/*      */     }
/*  616 */     this.processingTime += timeEnd - timeNow;
/*      */   }
/*      */   
/*      */ 
/*      */   protected void initInternal()
/*      */     throws LifecycleException
/*      */   {
/*  623 */     super.initInternal();
/*      */     
/*  625 */     if (this.context == null) {
/*  626 */       throw new LifecycleException(sm.getString("managerBase.contextNull"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void startInternal()
/*      */     throws LifecycleException
/*      */   {
/*  636 */     while (this.sessionCreationTiming.size() < 100) {
/*  637 */       this.sessionCreationTiming.add(null);
/*      */     }
/*  639 */     while (this.sessionExpirationTiming.size() < 100) {
/*  640 */       this.sessionExpirationTiming.add(null);
/*      */     }
/*      */     
/*      */ 
/*  644 */     SessionIdGenerator sessionIdGenerator = getSessionIdGenerator();
/*  645 */     if (sessionIdGenerator == null) {
/*  646 */       sessionIdGenerator = new StandardSessionIdGenerator();
/*  647 */       setSessionIdGenerator(sessionIdGenerator);
/*      */     }
/*      */     
/*  650 */     sessionIdGenerator.setJvmRoute(getJvmRoute());
/*  651 */     if ((sessionIdGenerator instanceof SessionIdGeneratorBase)) {
/*  652 */       SessionIdGeneratorBase sig = (SessionIdGeneratorBase)sessionIdGenerator;
/*  653 */       sig.setSecureRandomAlgorithm(getSecureRandomAlgorithm());
/*  654 */       sig.setSecureRandomClass(getSecureRandomClass());
/*  655 */       sig.setSecureRandomProvider(getSecureRandomProvider());
/*      */     }
/*      */     
/*  658 */     if ((sessionIdGenerator instanceof Lifecycle)) {
/*  659 */       ((Lifecycle)sessionIdGenerator).start();
/*      */     }
/*      */     else {
/*  662 */       if (this.log.isDebugEnabled()) {
/*  663 */         this.log.debug("Force random number initialization starting");
/*      */       }
/*  665 */       sessionIdGenerator.generateSessionId();
/*  666 */       if (this.log.isDebugEnabled()) {
/*  667 */         this.log.debug("Force random number initialization completed");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/*  675 */     if ((this.sessionIdGenerator instanceof Lifecycle)) {
/*  676 */       ((Lifecycle)this.sessionIdGenerator).stop();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void add(Session session)
/*      */   {
/*  683 */     this.sessions.put(session.getIdInternal(), session);
/*  684 */     int size = getActiveSessions();
/*  685 */     if (size > this.maxActive) {
/*  686 */       synchronized (this.maxActiveUpdateLock) {
/*  687 */         if (size > this.maxActive) {
/*  688 */           this.maxActive = size;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/*  697 */     this.support.addPropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Session createSession(String sessionId)
/*      */   {
/*  704 */     if ((this.maxActiveSessions >= 0) && 
/*  705 */       (getActiveSessions() >= this.maxActiveSessions)) {
/*  706 */       this.rejectedSessions += 1;
/*      */       
/*  708 */       throw new TooManyActiveSessionsException(sm.getString("managerBase.createSession.ise"), this.maxActiveSessions);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  713 */     Session session = createEmptySession();
/*      */     
/*      */ 
/*  716 */     session.setNew(true);
/*  717 */     session.setValid(true);
/*  718 */     session.setCreationTime(System.currentTimeMillis());
/*  719 */     session.setMaxInactiveInterval(getContext().getSessionTimeout() * 60);
/*  720 */     String id = sessionId;
/*  721 */     if (id == null) {
/*  722 */       id = generateSessionId();
/*      */     }
/*  724 */     session.setId(id);
/*  725 */     this.sessionCounter += 1L;
/*      */     
/*  727 */     SessionTiming timing = new SessionTiming(session.getCreationTime(), 0);
/*  728 */     synchronized (this.sessionCreationTiming) {
/*  729 */       this.sessionCreationTiming.add(timing);
/*  730 */       this.sessionCreationTiming.poll();
/*      */     }
/*  732 */     return session;
/*      */   }
/*      */   
/*      */ 
/*      */   public Session createEmptySession()
/*      */   {
/*  738 */     return getNewSession();
/*      */   }
/*      */   
/*      */   public Session findSession(String id)
/*      */     throws IOException
/*      */   {
/*  744 */     if (id == null) {
/*  745 */       return null;
/*      */     }
/*  747 */     return (Session)this.sessions.get(id);
/*      */   }
/*      */   
/*      */ 
/*      */   public Session[] findSessions()
/*      */   {
/*  753 */     return (Session[])this.sessions.values().toArray(new Session[0]);
/*      */   }
/*      */   
/*      */ 
/*      */   public void remove(Session session)
/*      */   {
/*  759 */     remove(session, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(Session session, boolean update)
/*      */   {
/*  767 */     if (update) {
/*  768 */       long timeNow = System.currentTimeMillis();
/*      */       
/*  770 */       int timeAlive = (int)(timeNow - session.getCreationTimeInternal()) / 1000;
/*  771 */       updateSessionMaxAliveTime(timeAlive);
/*  772 */       this.expiredSessions.incrementAndGet();
/*  773 */       SessionTiming timing = new SessionTiming(timeNow, timeAlive);
/*  774 */       synchronized (this.sessionExpirationTiming) {
/*  775 */         this.sessionExpirationTiming.add(timing);
/*  776 */         this.sessionExpirationTiming.poll();
/*      */       }
/*      */     }
/*      */     
/*  780 */     if (session.getIdInternal() != null) {
/*  781 */       this.sessions.remove(session.getIdInternal());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/*  788 */     this.support.removePropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */   public void changeSessionId(Session session)
/*      */   {
/*  794 */     rotateSessionId(session);
/*      */   }
/*      */   
/*      */ 
/*      */   public String rotateSessionId(Session session)
/*      */   {
/*  800 */     String newId = generateSessionId();
/*  801 */     changeSessionId(session, newId, true, true);
/*  802 */     return newId;
/*      */   }
/*      */   
/*      */ 
/*      */   public void changeSessionId(Session session, String newId)
/*      */   {
/*  808 */     changeSessionId(session, newId, true, true);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void changeSessionId(Session session, String newId, boolean notifySessionListeners, boolean notifyContainerListeners)
/*      */   {
/*  814 */     String oldId = session.getIdInternal();
/*  815 */     session.setId(newId, false);
/*  816 */     session.tellChangedSessionId(newId, oldId, notifySessionListeners, notifyContainerListeners);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean willAttributeDistribute(String name, Object value)
/*      */   {
/*  831 */     Pattern sessionAttributeNamePattern = getSessionAttributeNamePattern();
/*  832 */     if ((sessionAttributeNamePattern != null) && 
/*  833 */       (!sessionAttributeNamePattern.matcher(name).matches())) {
/*  834 */       if ((getWarnOnSessionAttributeFilterFailure()) || (this.log.isDebugEnabled())) {
/*  835 */         String msg = sm.getString("managerBase.sessionAttributeNameFilter", new Object[] { name, sessionAttributeNamePattern });
/*      */         
/*  837 */         if (getWarnOnSessionAttributeFilterFailure()) {
/*  838 */           this.log.warn(msg);
/*      */         } else {
/*  840 */           this.log.debug(msg);
/*      */         }
/*      */       }
/*  843 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  847 */     Pattern sessionAttributeValueClassNamePattern = getSessionAttributeValueClassNamePattern();
/*  848 */     if ((value != null) && (sessionAttributeValueClassNamePattern != null))
/*      */     {
/*  850 */       if (!sessionAttributeValueClassNamePattern.matcher(value.getClass().getName()).matches()) {
/*  851 */         if ((getWarnOnSessionAttributeFilterFailure()) || (this.log.isDebugEnabled())) {
/*  852 */           String msg = sm.getString("managerBase.sessionAttributeValueClassNameFilter", new Object[] { name, value
/*  853 */             .getClass().getName(), sessionAttributeValueClassNamePattern });
/*  854 */           if (getWarnOnSessionAttributeFilterFailure()) {
/*  855 */             this.log.warn(msg);
/*      */           } else {
/*  857 */             this.log.debug(msg);
/*      */           }
/*      */         }
/*  860 */         return false;
/*      */       }
/*      */     }
/*      */     
/*  864 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected StandardSession getNewSession()
/*      */   {
/*  876 */     return new StandardSession(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String generateSessionId()
/*      */   {
/*  886 */     String result = null;
/*      */     do
/*      */     {
/*  889 */       if (result != null)
/*      */       {
/*      */ 
/*      */ 
/*  893 */         this.duplicates += 1;
/*      */       }
/*      */       
/*  896 */       result = this.sessionIdGenerator.generateSessionId();
/*      */     }
/*  898 */     while (this.sessions.containsKey(result));
/*      */     
/*  900 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Engine getEngine()
/*      */   {
/*  913 */     Engine e = null;
/*  914 */     for (Container c = getContext(); (e == null) && (c != null); c = c.getParent()) {
/*  915 */       if ((c instanceof Engine)) {
/*  916 */         e = (Engine)c;
/*      */       }
/*      */     }
/*  919 */     return e;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getJvmRoute()
/*      */   {
/*  928 */     Engine e = getEngine();
/*  929 */     return e == null ? null : e.getJvmRoute();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSessionCounter(long sessionCounter)
/*      */   {
/*  938 */     this.sessionCounter = sessionCounter;
/*      */   }
/*      */   
/*      */ 
/*      */   public long getSessionCounter()
/*      */   {
/*  944 */     return this.sessionCounter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDuplicates()
/*      */   {
/*  955 */     return this.duplicates;
/*      */   }
/*      */   
/*      */   public void setDuplicates(int duplicates)
/*      */   {
/*  960 */     this.duplicates = duplicates;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getActiveSessions()
/*      */   {
/*  966 */     return this.sessions.size();
/*      */   }
/*      */   
/*      */ 
/*      */   public int getMaxActive()
/*      */   {
/*  972 */     return this.maxActive;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setMaxActive(int maxActive)
/*      */   {
/*  978 */     synchronized (this.maxActiveUpdateLock) {
/*  979 */       this.maxActive = maxActive;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxActiveSessions()
/*      */   {
/*  989 */     return this.maxActiveSessions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxActiveSessions(int max)
/*      */   {
/* 1001 */     int oldMaxActiveSessions = this.maxActiveSessions;
/* 1002 */     this.maxActiveSessions = max;
/* 1003 */     this.support.firePropertyChange("maxActiveSessions", 
/* 1004 */       Integer.valueOf(oldMaxActiveSessions), 
/* 1005 */       Integer.valueOf(this.maxActiveSessions));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getSessionMaxAliveTime()
/*      */   {
/* 1012 */     return this.sessionMaxAliveTime;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSessionMaxAliveTime(int sessionMaxAliveTime)
/*      */   {
/* 1018 */     synchronized (this.sessionMaxAliveTimeUpdateLock) {
/* 1019 */       this.sessionMaxAliveTime = sessionMaxAliveTime;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateSessionMaxAliveTime(int sessionAliveTime)
/*      */   {
/* 1032 */     if (sessionAliveTime > this.sessionMaxAliveTime) {
/* 1033 */       synchronized (this.sessionMaxAliveTimeUpdateLock) {
/* 1034 */         if (sessionAliveTime > this.sessionMaxAliveTime) {
/* 1035 */           this.sessionMaxAliveTime = sessionAliveTime;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSessionAverageAliveTime()
/*      */   {
/*      */     List<SessionTiming> copy;
/*      */     
/*      */ 
/*      */ 
/* 1051 */     synchronized (this.sessionExpirationTiming) {
/* 1052 */       copy = new ArrayList(this.sessionExpirationTiming);
/*      */     }
/*      */     
/*      */     List<SessionTiming> copy;
/* 1056 */     int counter = 0;
/* 1057 */     int result = 0;
/*      */     
/*      */ 
/* 1060 */     for (SessionTiming timing : copy) {
/* 1061 */       if (timing != null) {
/* 1062 */         int timeAlive = timing.getDuration();
/* 1063 */         counter++;
/*      */         
/* 1065 */         result = result * ((counter - 1) / counter) + timeAlive / counter;
/*      */       }
/*      */     }
/*      */     
/* 1069 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSessionCreateRate()
/*      */   {
/*      */     List<SessionTiming> copy;
/*      */     
/*      */ 
/*      */ 
/* 1082 */     synchronized (this.sessionCreationTiming) {
/* 1083 */       copy = new ArrayList(this.sessionCreationTiming);
/*      */     }
/*      */     List<SessionTiming> copy;
/* 1086 */     return calculateRate(copy);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSessionExpireRate()
/*      */   {
/*      */     List<SessionTiming> copy;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1102 */     synchronized (this.sessionExpirationTiming) {
/* 1103 */       copy = new ArrayList(this.sessionExpirationTiming);
/*      */     }
/*      */     List<SessionTiming> copy;
/* 1106 */     return calculateRate(copy);
/*      */   }
/*      */   
/*      */ 
/*      */   private static int calculateRate(List<SessionTiming> sessionTiming)
/*      */   {
/* 1112 */     long now = System.currentTimeMillis();
/* 1113 */     long oldest = now;
/* 1114 */     int counter = 0;
/* 1115 */     int result = 0;
/*      */     
/*      */ 
/* 1118 */     for (SessionTiming timing : sessionTiming) {
/* 1119 */       if (timing != null) {
/* 1120 */         counter++;
/* 1121 */         if (timing.getTimestamp() < oldest) {
/* 1122 */           oldest = timing.getTimestamp();
/*      */         }
/*      */       }
/*      */     }
/* 1126 */     if (counter > 0) {
/* 1127 */       if (oldest < now) {
/* 1128 */         result = 60000 * counter / (int)(now - oldest);
/*      */       }
/*      */       else {
/* 1131 */         result = Integer.MAX_VALUE;
/*      */       }
/*      */     }
/* 1134 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String listSessionIds()
/*      */   {
/* 1144 */     StringBuilder sb = new StringBuilder();
/* 1145 */     for (String s : this.sessions.keySet()) {
/* 1146 */       sb.append(s).append(' ');
/*      */     }
/* 1148 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSessionAttribute(String sessionId, String key)
/*      */   {
/* 1162 */     Session s = (Session)this.sessions.get(sessionId);
/* 1163 */     if (s == null) {
/* 1164 */       if (this.log.isInfoEnabled()) {
/* 1165 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1167 */       return null;
/*      */     }
/* 1169 */     Object o = s.getSession().getAttribute(key);
/* 1170 */     if (o == null) {
/* 1171 */       return null;
/*      */     }
/* 1173 */     return o.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public HashMap<String, String> getSession(String sessionId)
/*      */   {
/* 1190 */     Session s = (Session)this.sessions.get(sessionId);
/* 1191 */     if (s == null) {
/* 1192 */       if (this.log.isInfoEnabled()) {
/* 1193 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1195 */       return null;
/*      */     }
/*      */     
/* 1198 */     Enumeration<String> ee = s.getSession().getAttributeNames();
/* 1199 */     if ((ee == null) || (!ee.hasMoreElements())) {
/* 1200 */       return null;
/*      */     }
/*      */     
/* 1203 */     HashMap<String, String> map = new HashMap();
/* 1204 */     while (ee.hasMoreElements()) {
/* 1205 */       String attrName = (String)ee.nextElement();
/* 1206 */       map.put(attrName, getSessionAttribute(sessionId, attrName));
/*      */     }
/*      */     
/* 1209 */     return map;
/*      */   }
/*      */   
/*      */   public void expireSession(String sessionId)
/*      */   {
/* 1214 */     Session s = (Session)this.sessions.get(sessionId);
/* 1215 */     if (s == null) {
/* 1216 */       if (this.log.isInfoEnabled()) {
/* 1217 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1219 */       return;
/*      */     }
/* 1221 */     s.expire();
/*      */   }
/*      */   
/*      */   public long getThisAccessedTimestamp(String sessionId) {
/* 1225 */     Session s = (Session)this.sessions.get(sessionId);
/* 1226 */     if (s == null) {
/* 1227 */       if (this.log.isInfoEnabled()) {
/* 1228 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1230 */       return -1L;
/*      */     }
/* 1232 */     return s.getThisAccessedTime();
/*      */   }
/*      */   
/*      */   public String getThisAccessedTime(String sessionId) {
/* 1236 */     Session s = (Session)this.sessions.get(sessionId);
/* 1237 */     if (s == null) {
/* 1238 */       if (this.log.isInfoEnabled()) {
/* 1239 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1241 */       return "";
/*      */     }
/* 1243 */     return new Date(s.getThisAccessedTime()).toString();
/*      */   }
/*      */   
/*      */   public long getLastAccessedTimestamp(String sessionId) {
/* 1247 */     Session s = (Session)this.sessions.get(sessionId);
/* 1248 */     if (s == null) {
/* 1249 */       if (this.log.isInfoEnabled()) {
/* 1250 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1252 */       return -1L;
/*      */     }
/* 1254 */     return s.getLastAccessedTime();
/*      */   }
/*      */   
/*      */   public String getLastAccessedTime(String sessionId) {
/* 1258 */     Session s = (Session)this.sessions.get(sessionId);
/* 1259 */     if (s == null) {
/* 1260 */       if (this.log.isInfoEnabled()) {
/* 1261 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1263 */       return "";
/*      */     }
/* 1265 */     return new Date(s.getLastAccessedTime()).toString();
/*      */   }
/*      */   
/*      */   public String getCreationTime(String sessionId) {
/* 1269 */     Session s = (Session)this.sessions.get(sessionId);
/* 1270 */     if (s == null) {
/* 1271 */       if (this.log.isInfoEnabled()) {
/* 1272 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1274 */       return "";
/*      */     }
/* 1276 */     return new Date(s.getCreationTime()).toString();
/*      */   }
/*      */   
/*      */   public long getCreationTimestamp(String sessionId) {
/* 1280 */     Session s = (Session)this.sessions.get(sessionId);
/* 1281 */     if (s == null) {
/* 1282 */       if (this.log.isInfoEnabled()) {
/* 1283 */         this.log.info(sm.getString("managerBase.sessionNotFound", new Object[] { sessionId }));
/*      */       }
/* 1285 */       return -1L;
/*      */     }
/* 1287 */     return s.getCreationTime();
/*      */   }
/*      */   
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1293 */     return ToStringUtil.toString(this, this.context);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getObjectNameKeyProperties()
/*      */   {
/* 1301 */     StringBuilder name = new StringBuilder("type=Manager");
/*      */     
/* 1303 */     name.append(",host=");
/* 1304 */     name.append(this.context.getParent().getName());
/*      */     
/* 1306 */     name.append(",context=");
/* 1307 */     String contextName = this.context.getName();
/* 1308 */     if (!contextName.startsWith("/")) {
/* 1309 */       name.append('/');
/*      */     }
/* 1311 */     name.append(contextName);
/*      */     
/* 1313 */     return name.toString();
/*      */   }
/*      */   
/*      */   public String getDomainInternal()
/*      */   {
/* 1318 */     return this.context.getDomain();
/*      */   }
/*      */   
/*      */ 
/*      */   protected static final class SessionTiming
/*      */   {
/*      */     private final long timestamp;
/*      */     private final int duration;
/*      */     
/*      */     public SessionTiming(long timestamp, int duration)
/*      */     {
/* 1329 */       this.timestamp = timestamp;
/* 1330 */       this.duration = duration;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public long getTimestamp()
/*      */     {
/* 1338 */       return this.timestamp;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getDuration()
/*      */     {
/* 1346 */       return this.duration;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\session\ManagerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */