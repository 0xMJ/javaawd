/*     */ package org.apache.catalina.manager;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Set;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.OperationsException;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.openmbean.CompositeData;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.mbeans.MBeanDumper;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMXProxyServlet
/*     */   extends HttpServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  55 */   private static final String[] NO_PARAMETERS = new String[0];
/*     */   
/*  57 */   private static final StringManager sm = StringManager.getManager(JMXProxyServlet.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */   protected transient MBeanServer mBeanServer = null;
/*     */   
/*     */ 
/*     */ 
/*     */   protected transient Registry registry;
/*     */   
/*     */ 
/*     */ 
/*     */   public void init()
/*     */     throws ServletException
/*     */   {
/*  74 */     this.registry = Registry.getRegistry(null, null);
/*  75 */     this.mBeanServer = Registry.getRegistry(null, null).getMBeanServer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws IOException, ServletException
/*     */   {
/*  91 */     response.setContentType("text/plain;charset=utf-8");
/*     */     
/*     */ 
/*     */ 
/*  95 */     response.setHeader("X-Content-Type-Options", "nosniff");
/*  96 */     PrintWriter writer = response.getWriter();
/*     */     
/*  98 */     if (this.mBeanServer == null) {
/*  99 */       writer.println("Error - No mbean server");
/* 100 */       return;
/*     */     }
/*     */     
/* 103 */     String qry = request.getParameter("set");
/* 104 */     if (qry != null) {
/* 105 */       String name = request.getParameter("att");
/* 106 */       String val = request.getParameter("val");
/*     */       
/* 108 */       setAttribute(writer, qry, name, val);
/* 109 */       return;
/*     */     }
/* 111 */     qry = request.getParameter("get");
/* 112 */     if (qry != null) {
/* 113 */       String name = request.getParameter("att");
/* 114 */       getAttribute(writer, qry, name, request.getParameter("key"));
/* 115 */       return;
/*     */     }
/* 117 */     qry = request.getParameter("invoke");
/* 118 */     if (qry != null) {
/* 119 */       String opName = request.getParameter("op");
/* 120 */       String[] params = getInvokeParameters(request.getParameter("ps"));
/* 121 */       invokeOperation(writer, qry, opName, params);
/* 122 */       return;
/*     */     }
/* 124 */     qry = request.getParameter("qry");
/* 125 */     if (qry == null) {
/* 126 */       qry = "*:*";
/*     */     }
/*     */     
/* 129 */     listBeans(writer, qry);
/*     */   }
/*     */   
/*     */   public void getAttribute(PrintWriter writer, String onameStr, String att, String key)
/*     */   {
/*     */     try {
/* 135 */       ObjectName oname = new ObjectName(onameStr);
/* 136 */       Object value = this.mBeanServer.getAttribute(oname, att);
/*     */       
/* 138 */       if ((null != key) && ((value instanceof CompositeData))) {
/* 139 */         value = ((CompositeData)value).get(key);
/*     */       }
/*     */       String valueStr;
/*     */       String valueStr;
/* 143 */       if (value != null) {
/* 144 */         valueStr = value.toString();
/*     */       } else {
/* 146 */         valueStr = "<null>";
/*     */       }
/*     */       
/* 149 */       writer.print("OK - Attribute get '");
/* 150 */       writer.print(onameStr);
/* 151 */       writer.print("' - ");
/* 152 */       writer.print(att);
/*     */       
/* 154 */       if (null != key) {
/* 155 */         writer.print(" - key '");
/* 156 */         writer.print(key);
/* 157 */         writer.print("'");
/*     */       }
/*     */       
/* 160 */       writer.print(" = ");
/*     */       
/* 162 */       writer.println(MBeanDumper.escape(valueStr));
/*     */     } catch (Exception ex) {
/* 164 */       writer.println("Error - " + ex.toString());
/* 165 */       ex.printStackTrace(writer);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setAttribute(PrintWriter writer, String onameStr, String att, String val)
/*     */   {
/*     */     try {
/* 172 */       setAttributeInternal(onameStr, att, val);
/* 173 */       writer.println("OK - Attribute set");
/*     */     } catch (Exception ex) {
/* 175 */       writer.println("Error - " + ex.toString());
/* 176 */       ex.printStackTrace(writer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void listBeans(PrintWriter writer, String qry)
/*     */   {
/* 183 */     Set<ObjectName> names = null;
/*     */     try {
/* 185 */       names = this.mBeanServer.queryNames(new ObjectName(qry), null);
/* 186 */       writer.println("OK - Number of results: " + names.size());
/* 187 */       writer.println();
/*     */     } catch (Exception ex) {
/* 189 */       writer.println("Error - " + ex.toString());
/* 190 */       ex.printStackTrace(writer);
/* 191 */       return;
/*     */     }
/*     */     
/* 194 */     String dump = MBeanDumper.dumpBeans(this.mBeanServer, names);
/* 195 */     writer.print(dump);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSupported(String type)
/*     */   {
/* 206 */     return true;
/*     */   }
/*     */   
/*     */   private void invokeOperation(PrintWriter writer, String onameStr, String op, String[] valuesStr)
/*     */   {
/*     */     try
/*     */     {
/* 213 */       Object retVal = invokeOperationInternal(onameStr, op, valuesStr);
/* 214 */       if (retVal != null) {
/* 215 */         writer.println("OK - Operation " + op + " returned:");
/* 216 */         output("", writer, retVal);
/*     */       } else {
/* 218 */         writer.println("OK - Operation " + op + " without return value");
/*     */       }
/*     */     } catch (Exception ex) {
/* 221 */       writer.println("Error - " + ex.toString());
/* 222 */       ex.printStackTrace(writer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] getInvokeParameters(String paramString)
/*     */   {
/* 237 */     if (paramString == null) {
/* 238 */       return NO_PARAMETERS;
/*     */     }
/* 240 */     return paramString.split(",");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setAttributeInternal(String onameStr, String attributeName, String value)
/*     */     throws OperationsException, MBeanException, ReflectionException
/*     */   {
/* 250 */     ObjectName oname = new ObjectName(onameStr);
/* 251 */     String type = this.registry.getType(oname, attributeName);
/* 252 */     Object valueObj = this.registry.convertValue(type, value);
/* 253 */     this.mBeanServer.setAttribute(oname, new Attribute(attributeName, valueObj));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object invokeOperationInternal(String onameStr, String operation, String[] parameters)
/*     */     throws OperationsException, MBeanException, ReflectionException
/*     */   {
/* 270 */     ObjectName oname = new ObjectName(onameStr);
/* 271 */     int paramCount = null == parameters ? 0 : parameters.length;
/* 272 */     MBeanOperationInfo methodInfo = this.registry.getMethodInfo(oname, operation, paramCount);
/* 273 */     if (null == methodInfo)
/*     */     {
/* 275 */       MBeanInfo info = null;
/*     */       try {
/* 277 */         info = this.registry.getMBeanServer().getMBeanInfo(oname);
/*     */       } catch (InstanceNotFoundException infe) {
/* 279 */         throw infe;
/*     */       } catch (Exception e) {
/* 281 */         throw new IllegalArgumentException(sm.getString("jmxProxyServlet.noBeanFound", new Object[] { onameStr }), e);
/*     */       }
/*     */       
/* 284 */       throw new IllegalArgumentException(sm.getString("jmxProxyServlet.noOperationOnBean", new Object[] { operation, 
/* 285 */         Integer.valueOf(paramCount), onameStr, info.getClassName() }));
/*     */     }
/*     */     
/* 288 */     MBeanParameterInfo[] signature = methodInfo.getSignature();
/* 289 */     String[] signatureTypes = new String[signature.length];
/* 290 */     Object[] values = new Object[signature.length];
/* 291 */     for (int i = 0; i < signature.length; i++) {
/* 292 */       MBeanParameterInfo pi = signature[i];
/* 293 */       signatureTypes[i] = pi.getType();
/* 294 */       values[i] = this.registry.convertValue(pi.getType(), parameters[i]);
/*     */     }
/*     */     
/* 297 */     return this.mBeanServer.invoke(oname, operation, values, signatureTypes);
/*     */   }
/*     */   
/*     */   private void output(String indent, PrintWriter writer, Object result)
/*     */   {
/* 302 */     if ((result instanceof Object[])) {
/* 303 */       for (Object obj : (Object[])result)
/* 304 */         output("  " + indent, writer, obj);
/*     */     } else {
/*     */       String strValue;
/*     */       String strValue;
/* 308 */       if (result != null) {
/* 309 */         strValue = result.toString();
/*     */       } else {
/* 311 */         strValue = "<null>";
/*     */       }
/* 313 */       writer.println(indent + strValue);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\manager\JMXProxyServlet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */