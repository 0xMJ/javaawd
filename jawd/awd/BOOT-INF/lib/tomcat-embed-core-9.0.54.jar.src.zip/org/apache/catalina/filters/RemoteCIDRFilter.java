/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.catalina.util.NetMask;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RemoteCIDRFilter
/*     */   extends FilterBase
/*     */ {
/*     */   private static final String PLAIN_TEXT_MIME_TYPE = "text/plain";
/*  49 */   private final Log log = LogFactory.getLog(RemoteCIDRFilter.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  54 */   private final List<NetMask> allow = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private final List<NetMask> deny = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAllow()
/*     */   {
/*  69 */     return this.allow.toString().replace("[", "").replace("]", "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllow(String input)
/*     */   {
/*  81 */     List<String> messages = fillFromInput(input, this.allow);
/*     */     
/*  83 */     if (messages.isEmpty()) {
/*  84 */       return;
/*     */     }
/*     */     
/*  87 */     for (String message : messages) {
/*  88 */       this.log.error(message);
/*     */     }
/*     */     
/*  91 */     throw new IllegalArgumentException(sm.getString("remoteCidrFilter.invalid", new Object[] { "allow" }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDeny()
/*     */   {
/* 102 */     return this.deny.toString().replace("[", "").replace("]", "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDeny(String input)
/*     */   {
/* 114 */     List<String> messages = fillFromInput(input, this.deny);
/*     */     
/* 116 */     if (messages.isEmpty()) {
/* 117 */       return;
/*     */     }
/*     */     
/* 120 */     for (String message : messages) {
/* 121 */       this.log.error(message);
/*     */     }
/*     */     
/* 124 */     throw new IllegalArgumentException(sm.getString("remoteCidrFilter.invalid", new Object[] { "deny" }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isConfigProblemFatal()
/*     */   {
/* 133 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/* 141 */     if (isAllowed(request.getRemoteAddr())) {
/* 142 */       chain.doFilter(request, response);
/* 143 */       return;
/*     */     }
/*     */     
/* 146 */     if (!(response instanceof HttpServletResponse)) {
/* 147 */       sendErrorWhenNotHttp(response);
/* 148 */       return;
/*     */     }
/*     */     
/* 151 */     ((HttpServletResponse)response).sendError(403);
/*     */   }
/*     */   
/*     */ 
/*     */   public Log getLogger()
/*     */   {
/* 157 */     return this.log;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isAllowed(String property)
/*     */   {
/*     */     try
/*     */     {
/* 171 */       addr = InetAddress.getByName(property);
/*     */     }
/*     */     catch (UnknownHostException e) {
/*     */       InetAddress addr;
/* 175 */       this.log.error(sm.getString("remoteCidrFilter.noRemoteIp"), e);
/* 176 */       return false;
/*     */     }
/*     */     InetAddress addr;
/* 179 */     for (NetMask nm : this.deny) {
/* 180 */       if (nm.matches(addr)) {
/* 181 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 185 */     for (NetMask nm : this.allow) {
/* 186 */       if (nm.matches(addr)) {
/* 187 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 192 */     if ((!this.deny.isEmpty()) && (this.allow.isEmpty())) {
/* 193 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 197 */     return false;
/*     */   }
/*     */   
/*     */   private void sendErrorWhenNotHttp(ServletResponse response) throws IOException
/*     */   {
/* 202 */     PrintWriter writer = response.getWriter();
/* 203 */     response.setContentType("text/plain");
/* 204 */     writer.write(sm.getString("http.403"));
/* 205 */     writer.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<String> fillFromInput(String input, List<NetMask> target)
/*     */   {
/* 218 */     target.clear();
/* 219 */     if ((input == null) || (input.isEmpty())) {
/* 220 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 223 */     List<String> messages = new LinkedList();
/*     */     
/*     */ 
/* 226 */     for (String s : input.split("\\s*,\\s*")) {
/*     */       try {
/* 228 */         NetMask nm = new NetMask(s);
/* 229 */         target.add(nm);
/*     */       } catch (IllegalArgumentException e) {
/* 231 */         messages.add(s + ": " + e.getMessage());
/*     */       }
/*     */     }
/*     */     
/* 235 */     return Collections.unmodifiableList(messages);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\filters\RemoteCIDRFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */