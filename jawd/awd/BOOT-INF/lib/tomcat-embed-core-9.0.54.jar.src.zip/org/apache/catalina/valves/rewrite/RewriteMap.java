/*    */ package org.apache.catalina.valves.rewrite;
/*    */ 
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface RewriteMap
/*    */ {
/*    */   public abstract String setParameters(String paramString);
/*    */   
/*    */   public void setParameters(String... params)
/*    */   {
/* 57 */     if (params == null) {
/* 58 */       return;
/*    */     }
/* 60 */     if (params.length > 1)
/*    */     {
/* 62 */       throw new IllegalArgumentException(StringManager.getManager(RewriteMap.class).getString("rewriteMap.tooManyParameters"));
/*    */     }
/* 64 */     setParameters(params[0]);
/*    */   }
/*    */   
/*    */   public abstract String lookup(String paramString);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\rewrite\RewriteMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */