/*      */ package org.apache.catalina.manager;
/*      */ 
/*      */ import java.io.PrintWriter;
/*      */ import java.lang.management.ManagementFactory;
/*      */ import java.lang.management.MemoryPoolMXBean;
/*      */ import java.lang.management.MemoryUsage;
/*      */ import java.lang.reflect.Method;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Iterator;
/*      */ import java.util.Set;
/*      */ import java.util.SortedMap;
/*      */ import java.util.TreeMap;
/*      */ import java.util.Vector;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.ObjectInstance;
/*      */ import javax.management.ObjectName;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.security.Escape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StatusTransformer
/*      */ {
/*      */   public static void setContentType(HttpServletResponse response, int mode)
/*      */   {
/*   56 */     if (mode == 0) {
/*   57 */       response.setContentType("text/html;charset=utf-8");
/*   58 */     } else if (mode == 1) {
/*   59 */       response.setContentType("text/xml;charset=utf-8");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void writeHeader(PrintWriter writer, Object[] args, int mode)
/*      */   {
/*   73 */     if (mode == 0)
/*      */     {
/*   75 */       writer.print(MessageFormat.format(Constants.HTML_HEADER_SECTION, args));
/*      */ 
/*      */     }
/*   78 */     else if (mode == 1) {
/*   79 */       writer.write("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
/*   80 */       writer.print(
/*   81 */         MessageFormat.format("<?xml-stylesheet type=\"text/xsl\" href=\"{0}/xform.xsl\" ?>\n", args));
/*   82 */       writer.write("<status>");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void writeBody(PrintWriter writer, Object[] args, int mode)
/*      */   {
/*   96 */     if (mode == 0) {
/*   97 */       writer.print(
/*   98 */         MessageFormat.format(Constants.BODY_HEADER_SECTION, args));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void writeManager(PrintWriter writer, Object[] args, int mode)
/*      */   {
/*  112 */     if (mode == 0) {
/*  113 */       writer.print(MessageFormat.format(Constants.MANAGER_SECTION, args));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static void writePageHeading(PrintWriter writer, Object[] args, int mode)
/*      */   {
/*  120 */     if (mode == 0) {
/*  121 */       writer.print(
/*  122 */         MessageFormat.format(Constants.SERVER_HEADER_SECTION, args));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static void writeServerInfo(PrintWriter writer, Object[] args, int mode)
/*      */   {
/*  129 */     if (mode == 0) {
/*  130 */       writer.print(MessageFormat.format(Constants.SERVER_ROW_SECTION, args));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void writeFooter(PrintWriter writer, int mode)
/*      */   {
/*  136 */     if (mode == 0)
/*      */     {
/*  138 */       writer.print(Constants.HTML_TAIL_SECTION);
/*  139 */     } else if (mode == 1) {
/*  140 */       writer.write("</status>");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void writeOSState(PrintWriter writer, int mode, Object[] args)
/*      */   {
/*  154 */     long[] result = new long[16];
/*  155 */     boolean ok = false;
/*      */     try {
/*  157 */       String methodName = "info";
/*  158 */       Class<?>[] paramTypes = new Class[1];
/*  159 */       paramTypes[0] = result.getClass();
/*  160 */       Object[] paramValues = new Object[1];
/*  161 */       paramValues[0] = result;
/*      */       
/*  163 */       Method method = Class.forName("org.apache.tomcat.jni.OS").getMethod(methodName, paramTypes);
/*  164 */       method.invoke(null, paramValues);
/*  165 */       ok = true;
/*      */     } catch (Throwable t) {
/*  167 */       t = ExceptionUtils.unwrapInvocationTargetException(t);
/*  168 */       ExceptionUtils.handleThrowable(t);
/*      */     }
/*      */     
/*  171 */     if (ok) {
/*  172 */       if (mode == 0) {
/*  173 */         writer.print("<h1>OS</h1>");
/*      */         
/*  175 */         writer.print("<p>");
/*  176 */         writer.print(args[0]);
/*  177 */         writer.print(' ');
/*  178 */         writer.print(formatSize(Long.valueOf(result[0]), true));
/*  179 */         writer.print(' ');
/*  180 */         writer.print(args[1]);
/*  181 */         writer.print(' ');
/*  182 */         writer.print(formatSize(Long.valueOf(result[1]), true));
/*  183 */         writer.print(' ');
/*  184 */         writer.print(args[2]);
/*  185 */         writer.print(' ');
/*  186 */         writer.print(formatSize(Long.valueOf(result[2]), true));
/*  187 */         writer.print(' ');
/*  188 */         writer.print(args[3]);
/*  189 */         writer.print(' ');
/*  190 */         writer.print(formatSize(Long.valueOf(result[3]), true));
/*  191 */         writer.print(' ');
/*  192 */         writer.print(args[4]);
/*  193 */         writer.print(' ');
/*  194 */         writer.print(Long.valueOf(result[6]));
/*  195 */         writer.print("<br>");
/*  196 */         writer.print(args[5]);
/*  197 */         writer.print(' ');
/*  198 */         writer.print(formatTime(Long.valueOf(result[11] / 1000L), true));
/*  199 */         writer.print(' ');
/*  200 */         writer.print(args[6]);
/*  201 */         writer.print(' ');
/*  202 */         writer.print(formatTime(Long.valueOf(result[12] / 1000L), true));
/*  203 */         writer.print("</p>");
/*  204 */       } else if (mode != 1) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void writeVMState(PrintWriter writer, int mode, Object[] args)
/*      */     throws Exception
/*      */   {
/*  223 */     SortedMap<String, MemoryPoolMXBean> memoryPoolMBeans = new TreeMap();
/*  224 */     for (MemoryPoolMXBean mbean : ManagementFactory.getMemoryPoolMXBeans()) {
/*  225 */       String sortKey = mbean.getType() + ":" + mbean.getName();
/*  226 */       memoryPoolMBeans.put(sortKey, mbean);
/*      */     }
/*      */     
/*  229 */     if (mode == 0) {
/*  230 */       writer.print("<h1>JVM</h1>");
/*      */       
/*  232 */       writer.print("<p>");
/*  233 */       writer.print(args[0]);
/*  234 */       writer.print(' ');
/*  235 */       writer.print(formatSize(
/*  236 */         Long.valueOf(Runtime.getRuntime().freeMemory()), true));
/*  237 */       writer.print(' ');
/*  238 */       writer.print(args[1]);
/*  239 */       writer.print(' ');
/*  240 */       writer.print(formatSize(
/*  241 */         Long.valueOf(Runtime.getRuntime().totalMemory()), true));
/*  242 */       writer.print(' ');
/*  243 */       writer.print(args[2]);
/*  244 */       writer.print(' ');
/*  245 */       writer.print(formatSize(
/*  246 */         Long.valueOf(Runtime.getRuntime().maxMemory()), true));
/*  247 */       writer.print("</p>");
/*      */       
/*  249 */       writer.write("<table border=\"0\"><thead><tr><th>" + args[3] + "</th><th>" + args[4] + "</th><th>" + args[5] + "</th><th>" + args[6] + "</th><th>" + args[7] + "</th><th>" + args[8] + "</th></tr></thead><tbody>");
/*  250 */       for (MemoryPoolMXBean memoryPoolMBean : memoryPoolMBeans.values()) {
/*  251 */         MemoryUsage usage = memoryPoolMBean.getUsage();
/*  252 */         writer.write("<tr><td>");
/*  253 */         writer.print(memoryPoolMBean.getName());
/*  254 */         writer.write("</td><td>");
/*  255 */         writer.print(memoryPoolMBean.getType());
/*  256 */         writer.write("</td><td>");
/*  257 */         writer.print(formatSize(Long.valueOf(usage.getInit()), true));
/*  258 */         writer.write("</td><td>");
/*  259 */         writer.print(formatSize(Long.valueOf(usage.getCommitted()), true));
/*  260 */         writer.write("</td><td>");
/*  261 */         writer.print(formatSize(Long.valueOf(usage.getMax()), true));
/*  262 */         writer.write("</td><td>");
/*  263 */         writer.print(formatSize(Long.valueOf(usage.getUsed()), true));
/*  264 */         if (usage.getMax() > 0L) {
/*  265 */           writer.write(" (" + usage
/*  266 */             .getUsed() * 100L / usage.getMax() + "%)");
/*      */         }
/*  268 */         writer.write("</td></tr>");
/*      */       }
/*  270 */       writer.write("</tbody></table>");
/*  271 */     } else if (mode == 1) {
/*  272 */       writer.write("<jvm>");
/*      */       
/*  274 */       writer.write("<memory");
/*  275 */       writer.write(" free='" + Runtime.getRuntime().freeMemory() + "'");
/*  276 */       writer.write(" total='" + Runtime.getRuntime().totalMemory() + "'");
/*  277 */       writer.write(" max='" + Runtime.getRuntime().maxMemory() + "'/>");
/*      */       
/*  279 */       for (MemoryPoolMXBean memoryPoolMBean : memoryPoolMBeans.values()) {
/*  280 */         MemoryUsage usage = memoryPoolMBean.getUsage();
/*  281 */         writer.write("<memorypool");
/*  282 */         writer.write(" name='" + Escape.xml("", memoryPoolMBean.getName()) + "'");
/*  283 */         writer.write(" type='" + memoryPoolMBean.getType() + "'");
/*  284 */         writer.write(" usageInit='" + usage.getInit() + "'");
/*  285 */         writer.write(" usageCommitted='" + usage.getCommitted() + "'");
/*  286 */         writer.write(" usageMax='" + usage.getMax() + "'");
/*  287 */         writer.write(" usageUsed='" + usage.getUsed() + "'/>");
/*      */       }
/*      */       
/*  290 */       writer.write("</jvm>");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void writeConnectorState(PrintWriter writer, ObjectName tpName, String name, MBeanServer mBeanServer, Vector<ObjectName> globalRequestProcessors, Vector<ObjectName> requestProcessors, int mode, Object[] args)
/*      */     throws Exception
/*      */   {
/*  314 */     if (mode == 0) {
/*  315 */       writer.print("<h1>");
/*  316 */       writer.print(name);
/*  317 */       writer.print("</h1>");
/*      */       
/*  319 */       writer.print("<p>");
/*  320 */       writer.print(args[0]);
/*  321 */       writer.print(' ');
/*  322 */       writer.print(mBeanServer.getAttribute(tpName, "maxThreads"));
/*  323 */       writer.print(' ');
/*  324 */       writer.print(args[1]);
/*  325 */       writer.print(' ');
/*  326 */       writer.print(mBeanServer.getAttribute(tpName, "currentThreadCount"));
/*  327 */       writer.print(' ');
/*  328 */       writer.print(args[2]);
/*  329 */       writer.print(' ');
/*  330 */       writer.print(mBeanServer.getAttribute(tpName, "currentThreadsBusy"));
/*  331 */       writer.print(' ');
/*  332 */       writer.print(args[3]);
/*  333 */       writer.print(' ');
/*  334 */       writer.print(mBeanServer.getAttribute(tpName, "keepAliveCount"));
/*      */       
/*  336 */       writer.print("<br>");
/*      */       
/*  338 */       ObjectName grpName = null;
/*      */       
/*  340 */       Enumeration<ObjectName> enumeration = globalRequestProcessors.elements();
/*      */       
/*  342 */       while (enumeration.hasMoreElements()) {
/*  343 */         ObjectName objectName = (ObjectName)enumeration.nextElement();
/*  344 */         if ((name.equals(objectName.getKeyProperty("name"))) && (objectName.getKeyProperty("Upgrade") == null)) {
/*  345 */           grpName = objectName;
/*      */         }
/*      */       }
/*      */       
/*  349 */       if (grpName == null) {
/*  350 */         return;
/*      */       }
/*      */       
/*  353 */       writer.print(args[4]);
/*  354 */       writer.print(' ');
/*  355 */       writer.print(formatTime(mBeanServer
/*  356 */         .getAttribute(grpName, "maxTime"), false));
/*  357 */       writer.print(' ');
/*  358 */       writer.print(args[5]);
/*  359 */       writer.print(' ');
/*  360 */       writer.print(formatTime(mBeanServer
/*  361 */         .getAttribute(grpName, "processingTime"), true));
/*  362 */       writer.print(' ');
/*  363 */       writer.print(args[6]);
/*  364 */       writer.print(' ');
/*  365 */       writer.print(mBeanServer.getAttribute(grpName, "requestCount"));
/*  366 */       writer.print(' ');
/*  367 */       writer.print(args[7]);
/*  368 */       writer.print(' ');
/*  369 */       writer.print(mBeanServer.getAttribute(grpName, "errorCount"));
/*  370 */       writer.print(' ');
/*  371 */       writer.print(args[8]);
/*  372 */       writer.print(' ');
/*  373 */       writer.print(formatSize(mBeanServer
/*  374 */         .getAttribute(grpName, "bytesReceived"), true));
/*  375 */       writer.print(' ');
/*  376 */       writer.print(args[9]);
/*  377 */       writer.print(' ');
/*  378 */       writer.print(formatSize(mBeanServer
/*  379 */         .getAttribute(grpName, "bytesSent"), true));
/*  380 */       writer.print("</p>");
/*      */       
/*  382 */       writer.print("<table border=\"0\"><tr><th>" + args[10] + "</th><th>" + args[11] + "</th><th>" + args[12] + "</th><th>" + args[13] + "</th><th>" + args[14] + "</th><th>" + args[15] + "</th><th>" + args[16] + "</th><th>" + args[17] + "</th></tr>");
/*      */       
/*  384 */       enumeration = requestProcessors.elements();
/*  385 */       while (enumeration.hasMoreElements()) {
/*  386 */         ObjectName objectName = (ObjectName)enumeration.nextElement();
/*  387 */         if (name.equals(objectName.getKeyProperty("worker"))) {
/*  388 */           writer.print("<tr>");
/*  389 */           writeProcessorState(writer, objectName, mBeanServer, mode);
/*  390 */           writer.print("</tr>");
/*      */         }
/*      */       }
/*      */       
/*  394 */       writer.print("</table>");
/*      */       
/*  396 */       writer.print("<p>");
/*  397 */       writer.print(args[18]);
/*  398 */       writer.print("</p>");
/*  399 */     } else if (mode == 1) {
/*  400 */       writer.write("<connector name='" + name + "'>");
/*      */       
/*  402 */       writer.write("<threadInfo ");
/*  403 */       writer.write(" maxThreads=\"" + mBeanServer.getAttribute(tpName, "maxThreads") + "\"");
/*  404 */       writer.write(" currentThreadCount=\"" + mBeanServer.getAttribute(tpName, "currentThreadCount") + "\"");
/*  405 */       writer.write(" currentThreadsBusy=\"" + mBeanServer.getAttribute(tpName, "currentThreadsBusy") + "\"");
/*  406 */       writer.write(" />");
/*      */       
/*  408 */       ObjectName grpName = null;
/*      */       
/*  410 */       Enumeration<ObjectName> enumeration = globalRequestProcessors.elements();
/*      */       
/*  412 */       while (enumeration.hasMoreElements()) {
/*  413 */         ObjectName objectName = (ObjectName)enumeration.nextElement();
/*  414 */         if ((name.equals(objectName.getKeyProperty("name"))) && (objectName.getKeyProperty("Upgrade") == null)) {
/*  415 */           grpName = objectName;
/*      */         }
/*      */       }
/*      */       
/*  419 */       if (grpName != null)
/*      */       {
/*  421 */         writer.write("<requestInfo ");
/*  422 */         writer.write(" maxTime=\"" + mBeanServer.getAttribute(grpName, "maxTime") + "\"");
/*  423 */         writer.write(" processingTime=\"" + mBeanServer.getAttribute(grpName, "processingTime") + "\"");
/*  424 */         writer.write(" requestCount=\"" + mBeanServer.getAttribute(grpName, "requestCount") + "\"");
/*  425 */         writer.write(" errorCount=\"" + mBeanServer.getAttribute(grpName, "errorCount") + "\"");
/*  426 */         writer.write(" bytesReceived=\"" + mBeanServer.getAttribute(grpName, "bytesReceived") + "\"");
/*  427 */         writer.write(" bytesSent=\"" + mBeanServer.getAttribute(grpName, "bytesSent") + "\"");
/*  428 */         writer.write(" />");
/*      */         
/*  430 */         writer.write("<workers>");
/*  431 */         enumeration = requestProcessors.elements();
/*  432 */         while (enumeration.hasMoreElements()) {
/*  433 */           ObjectName objectName = (ObjectName)enumeration.nextElement();
/*  434 */           if (name.equals(objectName.getKeyProperty("worker"))) {
/*  435 */             writeProcessorState(writer, objectName, mBeanServer, mode);
/*      */           }
/*      */         }
/*  438 */         writer.write("</workers>");
/*      */       }
/*      */       
/*  441 */       writer.write("</connector>");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static void writeProcessorState(PrintWriter writer, ObjectName pName, MBeanServer mBeanServer, int mode)
/*      */     throws Exception
/*      */   {
/*  463 */     Integer stageValue = (Integer)mBeanServer.getAttribute(pName, "stage");
/*  464 */     int stage = stageValue.intValue();
/*  465 */     boolean fullStatus = true;
/*  466 */     boolean showRequest = true;
/*  467 */     String stageStr = null;
/*      */     
/*  469 */     switch (stage)
/*      */     {
/*      */     case 1: 
/*  472 */       stageStr = "P";
/*  473 */       fullStatus = false;
/*  474 */       break;
/*      */     case 2: 
/*  476 */       stageStr = "P";
/*  477 */       fullStatus = false;
/*  478 */       break;
/*      */     case 3: 
/*  480 */       stageStr = "S";
/*  481 */       break;
/*      */     case 4: 
/*  483 */       stageStr = "F";
/*  484 */       break;
/*      */     case 5: 
/*  486 */       stageStr = "F";
/*  487 */       break;
/*      */     case 7: 
/*  489 */       stageStr = "R";
/*  490 */       fullStatus = false;
/*  491 */       break;
/*      */     case 6: 
/*  493 */       stageStr = "K";
/*  494 */       fullStatus = true;
/*  495 */       showRequest = false;
/*  496 */       break;
/*      */     case 0: 
/*  498 */       stageStr = "R";
/*  499 */       fullStatus = false;
/*  500 */       break;
/*      */     
/*      */     default: 
/*  503 */       stageStr = "?";
/*  504 */       fullStatus = false;
/*      */     }
/*      */     
/*      */     
/*  508 */     if (mode == 0) {
/*  509 */       writer.write("<td><strong>");
/*  510 */       writer.write(stageStr);
/*  511 */       writer.write("</strong></td>");
/*      */       
/*  513 */       if (fullStatus) {
/*  514 */         writer.write("<td>");
/*  515 */         writer.print(formatTime(mBeanServer
/*  516 */           .getAttribute(pName, "requestProcessingTime"), false));
/*  517 */         writer.write("</td>");
/*  518 */         writer.write("<td>");
/*  519 */         if (showRequest) {
/*  520 */           writer.print(formatSize(mBeanServer
/*  521 */             .getAttribute(pName, "requestBytesSent"), false));
/*      */         } else {
/*  523 */           writer.write("?");
/*      */         }
/*  525 */         writer.write("</td>");
/*  526 */         writer.write("<td>");
/*  527 */         if (showRequest) {
/*  528 */           writer.print(formatSize(mBeanServer
/*  529 */             .getAttribute(pName, "requestBytesReceived"), false));
/*      */         }
/*      */         else {
/*  532 */           writer.write("?");
/*      */         }
/*  534 */         writer.write("</td>");
/*  535 */         writer.write("<td>");
/*  536 */         writer.print(Escape.htmlElementContent(mBeanServer
/*  537 */           .getAttribute(pName, "remoteAddrForwarded")));
/*  538 */         writer.write("</td>");
/*  539 */         writer.write("<td>");
/*  540 */         writer.print(Escape.htmlElementContent(mBeanServer
/*  541 */           .getAttribute(pName, "remoteAddr")));
/*  542 */         writer.write("</td>");
/*  543 */         writer.write("<td nowrap>");
/*  544 */         writer.write(Escape.htmlElementContent(mBeanServer
/*  545 */           .getAttribute(pName, "virtualHost")));
/*  546 */         writer.write("</td>");
/*  547 */         writer.write("<td nowrap class=\"row-left\">");
/*  548 */         if (showRequest) {
/*  549 */           writer.write(Escape.htmlElementContent(mBeanServer
/*  550 */             .getAttribute(pName, "method")));
/*  551 */           writer.write(32);
/*  552 */           writer.write(Escape.htmlElementContent(mBeanServer
/*  553 */             .getAttribute(pName, "currentUri")));
/*      */           
/*  555 */           String queryString = (String)mBeanServer.getAttribute(pName, "currentQueryString");
/*  556 */           if ((queryString != null) && (!queryString.equals(""))) {
/*  557 */             writer.write("?");
/*  558 */             writer.print(Escape.htmlElementContent(queryString));
/*      */           }
/*  560 */           writer.write(32);
/*  561 */           writer.write(Escape.htmlElementContent(mBeanServer
/*  562 */             .getAttribute(pName, "protocol")));
/*      */         } else {
/*  564 */           writer.write("?");
/*      */         }
/*  566 */         writer.write("</td>");
/*      */       } else {
/*  568 */         writer.write("<td>?</td><td>?</td><td>?</td><td>?</td><td>?</td><td>?</td>");
/*      */       }
/*  570 */     } else if (mode == 1) {
/*  571 */       writer.write("<worker ");
/*  572 */       writer.write(" stage=\"" + stageStr + "\"");
/*      */       
/*  574 */       if (fullStatus) {
/*  575 */         writer.write(" requestProcessingTime=\"" + mBeanServer
/*      */         
/*  577 */           .getAttribute(pName, "requestProcessingTime") + "\"");
/*  578 */         writer.write(" requestBytesSent=\"");
/*  579 */         if (showRequest) {
/*  580 */           writer.write("" + mBeanServer
/*  581 */             .getAttribute(pName, "requestBytesSent"));
/*      */         } else {
/*  583 */           writer.write("0");
/*      */         }
/*  585 */         writer.write("\"");
/*  586 */         writer.write(" requestBytesReceived=\"");
/*  587 */         if (showRequest) {
/*  588 */           writer.write("" + mBeanServer
/*  589 */             .getAttribute(pName, "requestBytesReceived"));
/*      */         } else {
/*  591 */           writer.write("0");
/*      */         }
/*  593 */         writer.write("\"");
/*  594 */         writer.write(" remoteAddr=\"" + 
/*  595 */           Escape.htmlElementContent(mBeanServer
/*  596 */           .getAttribute(pName, "remoteAddr")) + "\"");
/*  597 */         writer.write(" virtualHost=\"" + 
/*  598 */           Escape.htmlElementContent(mBeanServer
/*  599 */           .getAttribute(pName, "virtualHost")) + "\"");
/*      */         
/*      */ 
/*  601 */         if (showRequest) {
/*  602 */           writer.write(" method=\"" + 
/*  603 */             Escape.htmlElementContent(mBeanServer
/*  604 */             .getAttribute(pName, "method")) + "\"");
/*  605 */           writer.write(" currentUri=\"" + 
/*  606 */             Escape.htmlElementContent(mBeanServer
/*  607 */             .getAttribute(pName, "currentUri")) + "\"");
/*      */           
/*      */ 
/*  610 */           String queryString = (String)mBeanServer.getAttribute(pName, "currentQueryString");
/*  611 */           if ((queryString != null) && (!queryString.equals(""))) {
/*  612 */             writer.write(" currentQueryString=\"" + 
/*  613 */               Escape.htmlElementContent(queryString) + "\"");
/*      */           } else {
/*  615 */             writer.write(" currentQueryString=\"&#63;\"");
/*      */           }
/*  617 */           writer.write(" protocol=\"" + 
/*  618 */             Escape.htmlElementContent(mBeanServer
/*  619 */             .getAttribute(pName, "protocol")) + "\"");
/*      */         }
/*      */         else {
/*  621 */           writer.write(" method=\"&#63;\"");
/*  622 */           writer.write(" currentUri=\"&#63;\"");
/*  623 */           writer.write(" currentQueryString=\"&#63;\"");
/*  624 */           writer.write(" protocol=\"&#63;\"");
/*      */         }
/*      */       } else {
/*  627 */         writer.write(" requestProcessingTime=\"0\"");
/*  628 */         writer.write(" requestBytesSent=\"0\"");
/*  629 */         writer.write(" requestBytesReceived=\"0\"");
/*  630 */         writer.write(" remoteAddr=\"&#63;\"");
/*  631 */         writer.write(" virtualHost=\"&#63;\"");
/*  632 */         writer.write(" method=\"&#63;\"");
/*  633 */         writer.write(" currentUri=\"&#63;\"");
/*  634 */         writer.write(" currentQueryString=\"&#63;\"");
/*  635 */         writer.write(" protocol=\"&#63;\"");
/*      */       }
/*  637 */       writer.write(" />");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void writeDetailedState(PrintWriter writer, MBeanServer mBeanServer, int mode)
/*      */     throws Exception
/*      */   {
/*  655 */     if (mode == 0) {
/*  656 */       ObjectName queryHosts = new ObjectName("*:j2eeType=WebModule,*");
/*  657 */       Set<ObjectName> hostsON = mBeanServer.queryNames(queryHosts, null);
/*      */       
/*      */ 
/*  660 */       writer.print("<h1>");
/*  661 */       writer.print("Application list");
/*  662 */       writer.print("</h1>");
/*      */       
/*  664 */       writer.print("<p>");
/*  665 */       int count = 0;
/*  666 */       Iterator<ObjectName> iterator = hostsON.iterator();
/*  667 */       while (iterator.hasNext()) {
/*  668 */         ObjectName contextON = (ObjectName)iterator.next();
/*  669 */         String webModuleName = contextON.getKeyProperty("name");
/*  670 */         if (webModuleName.startsWith("//")) {
/*  671 */           webModuleName = webModuleName.substring(2);
/*      */         }
/*  673 */         int slash = webModuleName.indexOf('/');
/*  674 */         if (slash == -1) {
/*  675 */           count++;
/*      */         }
/*      */         else
/*      */         {
/*  679 */           writer.print("<a href=\"#" + count++ + ".0\">");
/*  680 */           writer.print(Escape.htmlElementContent(webModuleName));
/*  681 */           writer.print("</a>");
/*  682 */           if (iterator.hasNext()) {
/*  683 */             writer.print("<br>");
/*      */           }
/*      */         }
/*      */       }
/*  687 */       writer.print("</p>");
/*      */       
/*      */ 
/*  690 */       count = 0;
/*  691 */       iterator = hostsON.iterator();
/*  692 */       while (iterator.hasNext()) {
/*  693 */         ObjectName contextON = (ObjectName)iterator.next();
/*  694 */         writer.print("<a class=\"A.name\" name=\"" + count++ + ".0\">");
/*      */         
/*  696 */         writeContext(writer, contextON, mBeanServer, mode);
/*      */       }
/*      */     }
/*  699 */     else if (mode != 1) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static void writeContext(PrintWriter writer, ObjectName objectName, MBeanServer mBeanServer, int mode)
/*      */     throws Exception
/*      */   {
/*  720 */     if (mode == 0) {
/*  721 */       String webModuleName = objectName.getKeyProperty("name");
/*  722 */       String name = webModuleName;
/*  723 */       if (name == null) {
/*  724 */         return;
/*      */       }
/*      */       
/*  727 */       String hostName = null;
/*  728 */       String contextName = null;
/*  729 */       if (name.startsWith("//")) {
/*  730 */         name = name.substring(2);
/*      */       }
/*  732 */       int slash = name.indexOf('/');
/*  733 */       if (slash != -1) {
/*  734 */         hostName = name.substring(0, slash);
/*  735 */         contextName = name.substring(slash);
/*      */       } else {
/*  737 */         return;
/*      */       }
/*      */       
/*      */ 
/*  741 */       ObjectName queryManager = new ObjectName(objectName.getDomain() + ":type=Manager,context=" + contextName + ",host=" + hostName + ",*");
/*      */       
/*      */ 
/*  744 */       Set<ObjectName> managersON = mBeanServer.queryNames(queryManager, null);
/*  745 */       ObjectName managerON = null;
/*  746 */       for (ObjectName aManagersON : managersON) {
/*  747 */         managerON = aManagersON;
/*      */       }
/*      */       
/*      */ 
/*  751 */       ObjectName queryJspMonitor = new ObjectName(objectName.getDomain() + ":type=JspMonitor,WebModule=" + webModuleName + ",*");
/*      */       
/*      */ 
/*  754 */       Set<ObjectName> jspMonitorONs = mBeanServer.queryNames(queryJspMonitor, null);
/*      */       
/*      */ 
/*  757 */       if (contextName.equals("/")) {
/*  758 */         contextName = "";
/*      */       }
/*      */       
/*  761 */       writer.print("<h1>");
/*  762 */       writer.print(Escape.htmlElementContent(name));
/*  763 */       writer.print("</h1>");
/*  764 */       writer.print("</a>");
/*      */       
/*  766 */       writer.print("<p>");
/*  767 */       Object startTime = mBeanServer.getAttribute(objectName, "startTime");
/*      */       
/*  769 */       writer.print(" Start time: " + new Date(((Long)startTime)
/*  770 */         .longValue()));
/*  771 */       writer.print(" Startup time: ");
/*  772 */       writer.print(formatTime(mBeanServer
/*  773 */         .getAttribute(objectName, "startupTime"), false));
/*  774 */       writer.print(" TLD scan time: ");
/*  775 */       writer.print(formatTime(mBeanServer
/*  776 */         .getAttribute(objectName, "tldScanTime"), false));
/*  777 */       if (managerON != null) {
/*  778 */         writeManager(writer, managerON, mBeanServer, mode);
/*      */       }
/*  780 */       if (jspMonitorONs != null) {
/*  781 */         writeJspMonitor(writer, jspMonitorONs, mBeanServer, mode);
/*      */       }
/*  783 */       writer.print("</p>");
/*      */       
/*  785 */       String onStr = objectName.getDomain() + ":j2eeType=Servlet,WebModule=" + webModuleName + ",*";
/*      */       
/*  787 */       ObjectName servletObjectName = new ObjectName(onStr);
/*      */       
/*  789 */       Set<ObjectInstance> set = mBeanServer.queryMBeans(servletObjectName, null);
/*  790 */       for (ObjectInstance oi : set) {
/*  791 */         writeWrapper(writer, oi.getObjectName(), mBeanServer, mode);
/*      */       }
/*      */     }
/*  794 */     else if (mode != 1) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void writeManager(PrintWriter writer, ObjectName objectName, MBeanServer mBeanServer, int mode)
/*      */     throws Exception
/*      */   {
/*  814 */     if (mode == 0) {
/*  815 */       writer.print("<br>");
/*  816 */       writer.print(" Active sessions: ");
/*  817 */       writer.print(mBeanServer
/*  818 */         .getAttribute(objectName, "activeSessions"));
/*  819 */       writer.print(" Session count: ");
/*  820 */       writer.print(mBeanServer
/*  821 */         .getAttribute(objectName, "sessionCounter"));
/*  822 */       writer.print(" Max active sessions: ");
/*  823 */       writer.print(mBeanServer.getAttribute(objectName, "maxActive"));
/*  824 */       writer.print(" Rejected session creations: ");
/*  825 */       writer.print(mBeanServer
/*  826 */         .getAttribute(objectName, "rejectedSessions"));
/*  827 */       writer.print(" Expired sessions: ");
/*  828 */       writer.print(mBeanServer
/*  829 */         .getAttribute(objectName, "expiredSessions"));
/*  830 */       writer.print(" Longest session alive time: ");
/*  831 */       writer.print(formatSeconds(mBeanServer.getAttribute(objectName, "sessionMaxAliveTime")));
/*      */       
/*      */ 
/*  834 */       writer.print(" Average session alive time: ");
/*  835 */       writer.print(formatSeconds(mBeanServer.getAttribute(objectName, "sessionAverageAliveTime")));
/*      */       
/*      */ 
/*  838 */       writer.print(" Processing time: ");
/*  839 */       writer.print(formatTime(mBeanServer
/*  840 */         .getAttribute(objectName, "processingTime"), false));
/*  841 */     } else if (mode != 1) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void writeJspMonitor(PrintWriter writer, Set<ObjectName> jspMonitorONs, MBeanServer mBeanServer, int mode)
/*      */     throws Exception
/*      */   {
/*  863 */     int jspCount = 0;
/*  864 */     int jspReloadCount = 0;
/*      */     
/*  866 */     for (ObjectName jspMonitorON : jspMonitorONs) {
/*  867 */       Object obj = mBeanServer.getAttribute(jspMonitorON, "jspCount");
/*  868 */       jspCount += ((Integer)obj).intValue();
/*  869 */       obj = mBeanServer.getAttribute(jspMonitorON, "jspReloadCount");
/*  870 */       jspReloadCount += ((Integer)obj).intValue();
/*      */     }
/*      */     
/*  873 */     if (mode == 0) {
/*  874 */       writer.print("<br>");
/*  875 */       writer.print(" JSPs loaded: ");
/*  876 */       writer.print(jspCount);
/*  877 */       writer.print(" JSPs reloaded: ");
/*  878 */       writer.print(jspReloadCount);
/*  879 */     } else if (mode != 1) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void writeWrapper(PrintWriter writer, ObjectName objectName, MBeanServer mBeanServer, int mode)
/*      */     throws Exception
/*      */   {
/*  898 */     if (mode == 0) {
/*  899 */       String servletName = objectName.getKeyProperty("name");
/*      */       
/*      */ 
/*  902 */       String[] mappings = (String[])mBeanServer.invoke(objectName, "findMappings", null, null);
/*      */       
/*  904 */       writer.print("<h2>");
/*  905 */       writer.print(Escape.htmlElementContent(servletName));
/*  906 */       if ((mappings != null) && (mappings.length > 0)) {
/*  907 */         writer.print(" [ ");
/*  908 */         for (int i = 0; i < mappings.length; i++) {
/*  909 */           writer.print(Escape.htmlElementContent(mappings[i]));
/*  910 */           if (i < mappings.length - 1) {
/*  911 */             writer.print(" , ");
/*      */           }
/*      */         }
/*  914 */         writer.print(" ] ");
/*      */       }
/*  916 */       writer.print("</h2>");
/*      */       
/*  918 */       writer.print("<p>");
/*  919 */       writer.print(" Processing time: ");
/*  920 */       writer.print(formatTime(mBeanServer
/*  921 */         .getAttribute(objectName, "processingTime"), true));
/*  922 */       writer.print(" Max time: ");
/*  923 */       writer.print(formatTime(mBeanServer
/*  924 */         .getAttribute(objectName, "maxTime"), false));
/*  925 */       writer.print(" Request count: ");
/*  926 */       writer.print(mBeanServer.getAttribute(objectName, "requestCount"));
/*  927 */       writer.print(" Error count: ");
/*  928 */       writer.print(mBeanServer.getAttribute(objectName, "errorCount"));
/*  929 */       writer.print(" Load time: ");
/*  930 */       writer.print(formatTime(mBeanServer
/*  931 */         .getAttribute(objectName, "loadTime"), false));
/*  932 */       writer.print(" Classloading time: ");
/*  933 */       writer.print(formatTime(mBeanServer
/*  934 */         .getAttribute(objectName, "classLoadTime"), false));
/*  935 */       writer.print("</p>");
/*  936 */     } else if (mode != 1) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String formatSize(Object obj, boolean mb)
/*      */   {
/*  952 */     long bytes = -1L;
/*      */     
/*  954 */     if ((obj instanceof Long)) {
/*  955 */       bytes = ((Long)obj).longValue();
/*  956 */     } else if ((obj instanceof Integer)) {
/*  957 */       bytes = ((Integer)obj).intValue();
/*      */     }
/*      */     
/*  960 */     if (mb) {
/*  961 */       StringBuilder buff = new StringBuilder();
/*  962 */       if (bytes < 0L) {
/*  963 */         buff.append('-');
/*  964 */         bytes = -bytes;
/*      */       }
/*  966 */       long mbytes = bytes / 1048576L;
/*  967 */       long rest = (bytes - mbytes * 1048576L) * 100L / 1048576L;
/*      */       
/*  969 */       buff.append(mbytes).append('.');
/*  970 */       if (rest < 10L) {
/*  971 */         buff.append('0');
/*      */       }
/*  973 */       buff.append(rest).append(" MB");
/*  974 */       return buff.toString();
/*      */     }
/*  976 */     return bytes / 1024L + " KB";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String formatTime(Object obj, boolean seconds)
/*      */   {
/*  991 */     long time = -1L;
/*      */     
/*  993 */     if ((obj instanceof Long)) {
/*  994 */       time = ((Long)obj).longValue();
/*  995 */     } else if ((obj instanceof Integer)) {
/*  996 */       time = ((Integer)obj).intValue();
/*      */     }
/*      */     
/*  999 */     if (seconds) {
/* 1000 */       return (float)time / 1000.0F + " s";
/*      */     }
/* 1002 */     return time + " ms";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String formatSeconds(Object obj)
/*      */   {
/* 1015 */     long time = -1L;
/*      */     
/* 1017 */     if ((obj instanceof Long)) {
/* 1018 */       time = ((Long)obj).longValue();
/* 1019 */     } else if ((obj instanceof Integer)) {
/* 1020 */       time = ((Integer)obj).intValue();
/*      */     }
/*      */     
/* 1023 */     return time + " s";
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\manager\StatusTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */