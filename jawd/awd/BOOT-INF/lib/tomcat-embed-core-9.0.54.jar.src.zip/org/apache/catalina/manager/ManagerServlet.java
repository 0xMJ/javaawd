/*      */ package org.apache.catalina.manager;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.security.cert.Certificate;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.MalformedObjectNameException;
/*      */ import javax.management.ObjectName;
/*      */ import javax.naming.Binding;
/*      */ import javax.naming.NamingEnumeration;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletInputStream;
/*      */ import javax.servlet.UnavailableException;
/*      */ import javax.servlet.http.HttpServlet;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.ContainerServlet;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Manager;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.Connector;
/*      */ import org.apache.catalina.core.StandardHost;
/*      */ import org.apache.catalina.startup.ExpandWar;
/*      */ import org.apache.catalina.util.ContextName;
/*      */ import org.apache.catalina.util.IOTools;
/*      */ import org.apache.catalina.util.ServerInfo;
/*      */ import org.apache.coyote.ProtocolHandler;
/*      */ import org.apache.coyote.http11.AbstractHttp11Protocol;
/*      */ import org.apache.tomcat.util.Diagnostics;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.IntrospectionUtils;
/*      */ import org.apache.tomcat.util.buf.StringUtils;
/*      */ import org.apache.tomcat.util.modeler.Registry;
/*      */ import org.apache.tomcat.util.net.SSLContext;
/*      */ import org.apache.tomcat.util.net.SSLHostConfig;
/*      */ import org.apache.tomcat.util.net.SSLHostConfigCertificate;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.Escape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ManagerServlet
/*      */   extends HttpServlet
/*      */   implements ContainerServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*  178 */   protected File configBase = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  184 */   protected transient org.apache.catalina.Context context = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  190 */   protected int debug = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  196 */   protected File versioned = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  202 */   protected transient Host host = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  208 */   protected transient MBeanServer mBeanServer = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  214 */   protected ObjectName oname = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  221 */   protected transient javax.naming.Context global = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  228 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.manager");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  234 */   protected transient Wrapper wrapper = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Wrapper getWrapper()
/*      */   {
/*  245 */     return this.wrapper;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWrapper(Wrapper wrapper)
/*      */   {
/*  257 */     this.wrapper = wrapper;
/*  258 */     if (wrapper == null) {
/*  259 */       this.context = null;
/*  260 */       this.host = null;
/*  261 */       this.oname = null;
/*      */     } else {
/*  263 */       this.context = ((org.apache.catalina.Context)wrapper.getParent());
/*  264 */       this.host = ((Host)this.context.getParent());
/*  265 */       Engine engine = (Engine)this.host.getParent();
/*      */       
/*  267 */       String name = engine.getName() + ":type=Deployer,host=" + this.host.getName();
/*      */       try {
/*  269 */         this.oname = new ObjectName(name);
/*      */       } catch (Exception e) {
/*  271 */         log(sm.getString("managerServlet.objectNameFail", new Object[] { name }), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  276 */     this.mBeanServer = Registry.getRegistry(null, null).getMBeanServer();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void destroy() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  309 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request
/*  310 */       .getLocales());
/*      */     
/*      */ 
/*  313 */     String command = request.getPathInfo();
/*  314 */     if (command == null) {
/*  315 */       command = request.getServletPath();
/*      */     }
/*      */     
/*  318 */     String path = request.getParameter("path");
/*  319 */     String war = request.getParameter("war");
/*  320 */     String config = request.getParameter("config");
/*  321 */     ContextName cn = null;
/*  322 */     if (path != null) {
/*  323 */       cn = new ContextName(path, request.getParameter("version"));
/*  324 */     } else if (config != null) {
/*  325 */       cn = ContextName.extractFromPath(config);
/*  326 */     } else if (war != null) {
/*  327 */       cn = ContextName.extractFromPath(war);
/*      */     }
/*      */     
/*  330 */     String type = request.getParameter("type");
/*  331 */     String tag = request.getParameter("tag");
/*  332 */     boolean update = false;
/*  333 */     if ((request.getParameter("update") != null) && 
/*  334 */       (request.getParameter("update").equals("true"))) {
/*  335 */       update = true;
/*      */     }
/*  337 */     String tlsHostName = request.getParameter("tlsHostName");
/*      */     
/*  339 */     boolean statusLine = false;
/*  340 */     if ("true".equals(request.getParameter("statusLine"))) {
/*  341 */       statusLine = true;
/*      */     }
/*      */     
/*      */ 
/*  345 */     response.setContentType("text/plain; charset=utf-8");
/*      */     
/*      */ 
/*      */ 
/*  349 */     response.setHeader("X-Content-Type-Options", "nosniff");
/*  350 */     PrintWriter writer = response.getWriter();
/*      */     
/*      */ 
/*  353 */     if (command == null) {
/*  354 */       writer.println(smClient.getString("managerServlet.noCommand"));
/*  355 */     } else if (command.equals("/deploy")) {
/*  356 */       if ((war != null) || (config != null)) {
/*  357 */         deploy(writer, config, cn, war, update, smClient);
/*  358 */       } else if (tag != null) {
/*  359 */         deploy(writer, cn, tag, smClient);
/*      */       } else {
/*  361 */         writer.println(smClient.getString("managerServlet.invalidCommand", new Object[] { command }));
/*      */       }
/*      */     }
/*  364 */     else if (command.equals("/list")) {
/*  365 */       list(writer, smClient);
/*  366 */     } else if (command.equals("/reload")) {
/*  367 */       reload(writer, cn, smClient);
/*  368 */     } else if (command.equals("/resources")) {
/*  369 */       resources(writer, type, smClient);
/*  370 */     } else if (command.equals("/save")) {
/*  371 */       save(writer, path, smClient);
/*  372 */     } else if (command.equals("/serverinfo")) {
/*  373 */       serverinfo(writer, smClient);
/*  374 */     } else if (command.equals("/sessions")) {
/*  375 */       expireSessions(writer, cn, request, smClient);
/*  376 */     } else if (command.equals("/expire")) {
/*  377 */       expireSessions(writer, cn, request, smClient);
/*  378 */     } else if (command.equals("/start")) {
/*  379 */       start(writer, cn, smClient);
/*  380 */     } else if (command.equals("/stop")) {
/*  381 */       stop(writer, cn, smClient);
/*  382 */     } else if (command.equals("/undeploy")) {
/*  383 */       undeploy(writer, cn, smClient);
/*  384 */     } else if (command.equals("/findleaks")) {
/*  385 */       findleaks(statusLine, writer, smClient);
/*  386 */     } else if (command.equals("/vminfo")) {
/*  387 */       vmInfo(writer, smClient, request.getLocales());
/*  388 */     } else if (command.equals("/threaddump")) {
/*  389 */       threadDump(writer, smClient, request.getLocales());
/*  390 */     } else if (command.equals("/sslConnectorCiphers")) {
/*  391 */       sslConnectorCiphers(writer, smClient);
/*  392 */     } else if (command.equals("/sslConnectorCerts")) {
/*  393 */       sslConnectorCerts(writer, smClient);
/*  394 */     } else if (command.equals("/sslConnectorTrustedCerts")) {
/*  395 */       sslConnectorTrustedCerts(writer, smClient);
/*  396 */     } else if (command.equals("/sslReload")) {
/*  397 */       sslReload(writer, tlsHostName, smClient);
/*      */     } else {
/*  399 */       writer.println(smClient.getString("managerServlet.unknownCommand", new Object[] { command }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  404 */     writer.flush();
/*  405 */     writer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doPut(HttpServletRequest request, HttpServletResponse response)
/*      */     throws IOException, ServletException
/*      */   {
/*  424 */     StringManager smClient = StringManager.getManager("org.apache.catalina.manager", request
/*  425 */       .getLocales());
/*      */     
/*      */ 
/*  428 */     String command = request.getPathInfo();
/*  429 */     if (command == null) {
/*  430 */       command = request.getServletPath();
/*      */     }
/*  432 */     String path = request.getParameter("path");
/*  433 */     ContextName cn = null;
/*  434 */     if (path != null) {
/*  435 */       cn = new ContextName(path, request.getParameter("version"));
/*      */     }
/*  437 */     String config = request.getParameter("config");
/*  438 */     String tag = request.getParameter("tag");
/*  439 */     boolean update = false;
/*  440 */     if ((request.getParameter("update") != null) && 
/*  441 */       (request.getParameter("update").equals("true"))) {
/*  442 */       update = true;
/*      */     }
/*      */     
/*      */ 
/*  446 */     response.setContentType("text/plain;charset=utf-8");
/*      */     
/*      */ 
/*      */ 
/*  450 */     response.setHeader("X-Content-Type-Options", "nosniff");
/*  451 */     PrintWriter writer = response.getWriter();
/*      */     
/*      */ 
/*  454 */     if (command == null) {
/*  455 */       writer.println(smClient.getString("managerServlet.noCommand"));
/*  456 */     } else if (command.equals("/deploy")) {
/*  457 */       deploy(writer, config, cn, tag, update, request, smClient);
/*      */     } else {
/*  459 */       writer.println(smClient.getString("managerServlet.unknownCommand", new Object[] { command }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  464 */     writer.flush();
/*  465 */     writer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init()
/*      */     throws ServletException
/*      */   {
/*  477 */     if ((this.wrapper == null) || (this.context == null))
/*      */     {
/*  479 */       throw new UnavailableException(sm.getString("managerServlet.noWrapper"));
/*      */     }
/*      */     
/*      */ 
/*  483 */     String value = null;
/*      */     try {
/*  485 */       value = getServletConfig().getInitParameter("debug");
/*  486 */       this.debug = Integer.parseInt(value);
/*      */     } catch (Throwable t) {
/*  488 */       ExceptionUtils.handleThrowable(t);
/*      */     }
/*      */     
/*      */ 
/*  492 */     Server server = ((Engine)this.host.getParent()).getService().getServer();
/*  493 */     if (server != null) {
/*  494 */       this.global = server.getGlobalNamingContext();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  499 */     this.versioned = ((File)getServletContext().getAttribute("javax.servlet.context.tempdir"));
/*      */     
/*  501 */     this.configBase = new File(this.context.getCatalinaBase(), "conf");
/*  502 */     Container container = this.context;
/*  503 */     Container host = null;
/*  504 */     Container engine = null;
/*  505 */     while (container != null) {
/*  506 */       if ((container instanceof Host)) {
/*  507 */         host = container;
/*      */       }
/*  509 */       if ((container instanceof Engine)) {
/*  510 */         engine = container;
/*      */       }
/*  512 */       container = container.getParent();
/*      */     }
/*  514 */     if (engine != null) {
/*  515 */       this.configBase = new File(this.configBase, engine.getName());
/*      */     }
/*  517 */     if (host != null) {
/*  518 */       this.configBase = new File(this.configBase, host.getName());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  523 */     if (this.debug >= 1) {
/*  524 */       log("init: Associated with Deployer '" + this.oname + "'");
/*      */       
/*  526 */       if (this.global != null) {
/*  527 */         log("init: Global resources are available");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void findleaks(boolean statusLine, PrintWriter writer, StringManager smClient)
/*      */   {
/*  548 */     if (!(this.host instanceof StandardHost)) {
/*  549 */       writer.println(smClient.getString("managerServlet.findleaksFail"));
/*  550 */       return;
/*      */     }
/*      */     
/*      */ 
/*  554 */     String[] results = ((StandardHost)this.host).findReloadedContextMemoryLeaks();
/*      */     
/*  556 */     if (results.length > 0) {
/*  557 */       if (statusLine) {
/*  558 */         writer.println(smClient
/*  559 */           .getString("managerServlet.findleaksList"));
/*      */       }
/*  561 */       for (String result : results) {
/*  562 */         if (result.isEmpty()) {
/*  563 */           result = "/";
/*      */         }
/*  565 */         writer.println(result);
/*      */       }
/*  567 */     } else if (statusLine) {
/*  568 */       writer.println(smClient.getString("managerServlet.findleaksNone"));
/*      */     }
/*      */   }
/*      */   
/*      */   protected void sslReload(PrintWriter writer, String tlsHostName, StringManager smClient)
/*      */   {
/*  574 */     Connector[] connectors = getConnectors();
/*  575 */     boolean found = false;
/*  576 */     for (Connector connector : connectors) {
/*  577 */       if (Boolean.TRUE.equals(connector.getProperty("SSLEnabled"))) {
/*  578 */         ProtocolHandler protocol = connector.getProtocolHandler();
/*  579 */         if ((protocol instanceof AbstractHttp11Protocol)) {
/*  580 */           AbstractHttp11Protocol<?> http11Protoocol = (AbstractHttp11Protocol)protocol;
/*  581 */           if ((tlsHostName == null) || (tlsHostName.length() == 0)) {
/*  582 */             found = true;
/*  583 */             http11Protoocol.reloadSslHostConfigs();
/*      */           } else {
/*  585 */             SSLHostConfig[] sslHostConfigs = http11Protoocol.findSslHostConfigs();
/*  586 */             for (SSLHostConfig sslHostConfig : sslHostConfigs)
/*      */             {
/*      */ 
/*  589 */               if (sslHostConfig.getHostName().equalsIgnoreCase(tlsHostName)) {
/*  590 */                 found = true;
/*  591 */                 http11Protoocol.reloadSslHostConfig(tlsHostName);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  598 */     if (found) {
/*  599 */       if ((tlsHostName == null) || (tlsHostName.length() == 0)) {
/*  600 */         writer.println(smClient.getString("managerServlet.sslReloadAll"));
/*      */       } else {
/*  602 */         writer.println(smClient.getString("managerServlet.sslReload", new Object[] { tlsHostName }));
/*      */       }
/*      */     } else {
/*  605 */       writer.println(smClient.getString("managerServlet.sslReloadFail"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void vmInfo(PrintWriter writer, StringManager smClient, Enumeration<Locale> requestedLocales)
/*      */   {
/*  619 */     writer.println(smClient.getString("managerServlet.vminfo"));
/*  620 */     writer.print(Diagnostics.getVMInfo(requestedLocales));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void threadDump(PrintWriter writer, StringManager smClient, Enumeration<Locale> requestedLocales)
/*      */   {
/*  632 */     writer.println(smClient.getString("managerServlet.threaddump"));
/*  633 */     writer.print(Diagnostics.getThreadDump(requestedLocales));
/*      */   }
/*      */   
/*      */   protected void sslConnectorCiphers(PrintWriter writer, StringManager smClient)
/*      */   {
/*  638 */     writer.println(smClient.getString("managerServlet.sslConnectorCiphers"));
/*  639 */     Map<String, List<String>> connectorCiphers = getConnectorCiphers(smClient);
/*  640 */     for (Map.Entry<String, List<String>> entry : connectorCiphers.entrySet()) {
/*  641 */       writer.println((String)entry.getKey());
/*  642 */       for (String cipher : (List)entry.getValue()) {
/*  643 */         writer.print("  ");
/*  644 */         writer.println(cipher);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void sslConnectorCerts(PrintWriter writer, StringManager smClient)
/*      */   {
/*  651 */     writer.println(smClient.getString("managerServlet.sslConnectorCerts"));
/*  652 */     Map<String, List<String>> connectorCerts = getConnectorCerts(smClient);
/*  653 */     for (Map.Entry<String, List<String>> entry : connectorCerts.entrySet()) {
/*  654 */       writer.println((String)entry.getKey());
/*  655 */       for (String cert : (List)entry.getValue()) {
/*  656 */         writer.println(cert);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void sslConnectorTrustedCerts(PrintWriter writer, StringManager smClient)
/*      */   {
/*  663 */     writer.println(smClient.getString("managerServlet.sslConnectorTrustedCerts"));
/*  664 */     Map<String, List<String>> connectorTrustedCerts = getConnectorTrustedCerts(smClient);
/*  665 */     for (Map.Entry<String, List<String>> entry : connectorTrustedCerts.entrySet()) {
/*  666 */       writer.println((String)entry.getKey());
/*  667 */       for (String cert : (List)entry.getValue()) {
/*  668 */         writer.println(cert);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void save(PrintWriter writer, String path, StringManager smClient)
/*      */   {
/*      */     try
/*      */     {
/*  686 */       storeConfigOname = new ObjectName("Catalina:type=StoreConfig");
/*      */     } catch (MalformedObjectNameException e) {
/*      */       ObjectName storeConfigOname;
/*  689 */       log(sm.getString("managerServlet.exception"), e);
/*  690 */       writer.println(smClient.getString("managerServlet.exception", new Object[] { e.toString() })); return;
/*      */     }
/*      */     
/*      */     ObjectName storeConfigOname;
/*  694 */     if (!this.mBeanServer.isRegistered(storeConfigOname)) {
/*  695 */       writer.println(smClient.getString("managerServlet.storeConfig.noMBean", new Object[] { storeConfigOname }));
/*      */       
/*  697 */       return;
/*      */     }
/*      */     
/*  700 */     if ((path == null) || (path.length() == 0) || (!path.startsWith("/"))) {
/*      */       try {
/*  702 */         this.mBeanServer.invoke(storeConfigOname, "storeConfig", null, null);
/*  703 */         writer.println(smClient.getString("managerServlet.saved"));
/*      */       } catch (Exception e) {
/*  705 */         log(sm.getString("managerServlet.error.storeConfig"), e);
/*  706 */         writer.println(smClient.getString("managerServlet.exception", new Object[] {e
/*  707 */           .toString() }));
/*      */       }
/*      */     } else {
/*  710 */       String contextPath = path;
/*  711 */       if (path.equals("/")) {
/*  712 */         contextPath = "";
/*      */       }
/*  714 */       org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(contextPath);
/*  715 */       if (context == null) {
/*  716 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] { path }));
/*      */         
/*  718 */         return;
/*      */       }
/*      */       try {
/*  721 */         Boolean result = (Boolean)this.mBeanServer.invoke(storeConfigOname, "store", new Object[] { context }, new String[] { "org.apache.catalina.Context" });
/*      */         
/*      */ 
/*  724 */         if (result.booleanValue()) {
/*  725 */           writer.println(smClient.getString("managerServlet.savedContext", new Object[] { path }));
/*      */         } else {
/*  727 */           writer.println(smClient.getString("managerServlet.savedContextFail", new Object[] { path }));
/*      */         }
/*      */       } catch (Exception e) {
/*  730 */         log(sm.getString("managerServlet.error.storeContextConfig", new Object[] { path }), e);
/*  731 */         writer.println(smClient.getString("managerServlet.exception", new Object[] {e
/*  732 */           .toString() }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deploy(PrintWriter writer, String config, ContextName cn, String tag, boolean update, HttpServletRequest request, StringManager smClient)
/*      */   {
/*  754 */     if ((config != null) && (config.length() == 0)) {
/*  755 */       config = null;
/*      */     }
/*      */     
/*  758 */     if (this.debug >= 1) {
/*  759 */       if (config == null) {
/*  760 */         log("deploy: Deploying web application '" + cn + "'");
/*      */       } else {
/*  762 */         log("deploy: Deploying web application '" + cn + "' with context configuration at '" + config + "'");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  768 */     if (!validateContextName(cn, writer, smClient)) {
/*  769 */       return;
/*      */     }
/*  771 */     String name = cn.getName();
/*  772 */     String baseName = cn.getBaseName();
/*  773 */     String displayPath = cn.getDisplayName();
/*      */     
/*      */ 
/*      */ 
/*  777 */     org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(name);
/*  778 */     if ((context != null) && (!update)) {
/*  779 */       writer.println(smClient.getString("managerServlet.alreadyContext", new Object[] { displayPath }));
/*      */       
/*  781 */       return;
/*      */     }
/*      */     
/*  784 */     if ((config != null) && (config.startsWith("file:"))) {
/*  785 */       config = config.substring("file:".length());
/*      */     }
/*      */     
/*  788 */     File deployedWar = new File(this.host.getAppBaseFile(), baseName + ".war");
/*      */     
/*      */     File uploadedWar;
/*      */     File uploadedWar;
/*  792 */     if (tag == null) {
/*  793 */       if (update)
/*      */       {
/*      */ 
/*      */ 
/*  797 */         File uploadedWar = new File(deployedWar.getAbsolutePath() + ".tmp");
/*  798 */         if ((uploadedWar.exists()) && (!uploadedWar.delete())) {
/*  799 */           writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { uploadedWar }));
/*      */         }
/*      */       }
/*      */       else {
/*  803 */         uploadedWar = deployedWar;
/*      */       }
/*      */     } else {
/*  806 */       File uploadPath = new File(this.versioned, tag);
/*  807 */       if ((!uploadPath.mkdirs()) && (!uploadPath.isDirectory())) {
/*  808 */         writer.println(smClient.getString("managerServlet.mkdirFail", new Object[] { uploadPath }));
/*      */         
/*  810 */         return;
/*      */       }
/*  812 */       uploadedWar = new File(uploadPath, baseName + ".war");
/*      */     }
/*  814 */     if (this.debug >= 2) {
/*  815 */       log("Uploading WAR file to " + uploadedWar);
/*      */     }
/*      */     try
/*      */     {
/*  819 */       if (tryAddServiced(name)) {
/*      */         try {
/*  821 */           if (config != null) {
/*  822 */             if ((!this.configBase.mkdirs()) && (!this.configBase.isDirectory())) {
/*  823 */               writer.println(smClient.getString("managerServlet.mkdirFail", new Object[] { this.configBase }));
/*      */               
/*  825 */               return;
/*      */             }
/*  827 */             if (!ExpandWar.copy(new File(config), new File(this.configBase, baseName + ".xml")))
/*      */             {
/*  829 */               throw new Exception(sm.getString("managerServlet.copyError", new Object[] { config }));
/*      */             }
/*      */           }
/*      */           
/*  833 */           uploadWar(writer, request, uploadedWar, smClient);
/*  834 */           if ((update) && (tag == null)) {
/*  835 */             if ((deployedWar.exists()) && (!deployedWar.delete())) {
/*  836 */               writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { deployedWar }));
/*      */               
/*  838 */               return;
/*      */             }
/*      */             
/*  841 */             if (!uploadedWar.renameTo(deployedWar)) {
/*  842 */               writer.println(smClient.getString("managerServlet.renameFail", new Object[] { uploadedWar, deployedWar }));
/*      */               
/*  844 */               return;
/*      */             }
/*      */           }
/*  847 */           if (tag != null)
/*      */           {
/*  849 */             ExpandWar.copy(uploadedWar, deployedWar);
/*      */           }
/*      */         } finally {
/*  852 */           removeServiced(name);
/*      */         }
/*      */         
/*  855 */         check(name);
/*      */       } else {
/*  857 */         writer.println(smClient.getString("managerServlet.inService", new Object[] { displayPath }));
/*      */       }
/*      */     } catch (Exception e) {
/*  860 */       log(sm.getString("managerServlet.error.deploy", new Object[] { displayPath }), e);
/*  861 */       writer.println(smClient.getString("managerServlet.exception", new Object[] {e
/*  862 */         .toString() }));
/*  863 */       return;
/*      */     }
/*      */     
/*  866 */     writeDeployResult(writer, smClient, name, displayPath);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deploy(PrintWriter writer, ContextName cn, String tag, StringManager smClient)
/*      */   {
/*  885 */     if (!validateContextName(cn, writer, smClient)) {
/*  886 */       return;
/*      */     }
/*      */     
/*  889 */     String baseName = cn.getBaseName();
/*  890 */     String name = cn.getName();
/*  891 */     String displayPath = cn.getDisplayName();
/*      */     
/*      */ 
/*  894 */     File localWar = new File(new File(this.versioned, tag), baseName + ".war");
/*      */     
/*  896 */     File deployedWar = new File(this.host.getAppBaseFile(), baseName + ".war");
/*      */     
/*      */     try
/*      */     {
/*  900 */       if (tryAddServiced(name)) {
/*      */         try {
/*  902 */           if (!deployedWar.delete()) {
/*  903 */             writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { deployedWar }));
/*      */             
/*  905 */             return;
/*      */           }
/*  907 */           ExpandWar.copy(localWar, deployedWar);
/*      */         } finally {
/*  909 */           removeServiced(name);
/*      */         }
/*      */         
/*  912 */         check(name);
/*      */       } else {
/*  914 */         writer.println(smClient.getString("managerServlet.inService", new Object[] { displayPath }));
/*      */       }
/*      */     } catch (Exception e) {
/*  917 */       log(sm.getString("managerServlet.error.deploy", new Object[] { displayPath }), e);
/*  918 */       writer.println(smClient.getString("managerServlet.exception", new Object[] {e
/*  919 */         .toString() }));
/*  920 */       return;
/*      */     }
/*      */     
/*  923 */     writeDeployResult(writer, smClient, name, displayPath);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void deploy(PrintWriter writer, String config, ContextName cn, String war, boolean update, StringManager smClient)
/*      */   {
/*  941 */     if ((config != null) && (config.length() == 0)) {
/*  942 */       config = null;
/*      */     }
/*  944 */     if ((war != null) && (war.length() == 0)) {
/*  945 */       war = null;
/*      */     }
/*      */     
/*  948 */     if (this.debug >= 1) {
/*  949 */       if (config != null) {
/*  950 */         if (war != null) {
/*  951 */           log("install: Installing context configuration at '" + config + "' from '" + war + "'");
/*      */         }
/*      */         else {
/*  954 */           log("install: Installing context configuration at '" + config + "'");
/*      */         }
/*      */         
/*      */       }
/*  958 */       else if (cn != null) {
/*  959 */         log("install: Installing web application '" + cn + "' from '" + war + "'");
/*      */       }
/*      */       else {
/*  962 */         log("install: Installing web application from '" + war + "'");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  967 */     if (!validateContextName(cn, writer, smClient)) {
/*  968 */       return;
/*      */     }
/*      */     
/*  971 */     String name = cn.getName();
/*  972 */     String baseName = cn.getBaseName();
/*  973 */     String displayPath = cn.getDisplayName();
/*      */     
/*      */ 
/*      */ 
/*  977 */     org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(name);
/*  978 */     if ((context != null) && (!update)) {
/*  979 */       writer.println(smClient.getString("managerServlet.alreadyContext", new Object[] { displayPath }));
/*      */       
/*  981 */       return;
/*      */     }
/*      */     
/*  984 */     if ((config != null) && (config.startsWith("file:"))) {
/*  985 */       config = config.substring("file:".length());
/*      */     }
/*  987 */     if ((war != null) && (war.startsWith("file:"))) {
/*  988 */       war = war.substring("file:".length());
/*      */     }
/*      */     try
/*      */     {
/*  992 */       if (tryAddServiced(name)) {
/*      */         try {
/*  994 */           if (config != null) {
/*  995 */             if ((!this.configBase.mkdirs()) && (!this.configBase.isDirectory())) {
/*  996 */               writer.println(smClient.getString("managerServlet.mkdirFail", new Object[] { this.configBase }));
/*      */               
/*  998 */               return;
/*      */             }
/* 1000 */             File localConfig = new File(this.configBase, baseName + ".xml");
/* 1001 */             if ((localConfig.isFile()) && (!localConfig.delete())) {
/* 1002 */               writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { localConfig }));
/*      */               
/* 1004 */               return;
/*      */             }
/* 1006 */             ExpandWar.copy(new File(config), localConfig);
/*      */           }
/* 1008 */           if (war != null) { File localWar;
/*      */             File localWar;
/* 1010 */             if (war.endsWith(".war")) {
/* 1011 */               localWar = new File(this.host.getAppBaseFile(), baseName + ".war");
/*      */             } else {
/* 1013 */               localWar = new File(this.host.getAppBaseFile(), baseName);
/*      */             }
/* 1015 */             if ((localWar.exists()) && (!ExpandWar.delete(localWar))) {
/* 1016 */               writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { localWar }));
/*      */               
/* 1018 */               return;
/*      */             }
/* 1020 */             ExpandWar.copy(new File(war), localWar);
/*      */           }
/*      */         } finally {
/* 1023 */           removeServiced(name);
/*      */         }
/*      */         
/* 1026 */         check(name);
/*      */       } else {
/* 1028 */         writer.println(smClient.getString("managerServlet.inService", new Object[] { displayPath }));
/*      */       }
/* 1030 */       writeDeployResult(writer, smClient, name, displayPath);
/*      */     } catch (Throwable t) {
/* 1032 */       ExceptionUtils.handleThrowable(t);
/* 1033 */       log(sm.getString("managerServlet.error.deploy", new Object[] { displayPath }), t);
/* 1034 */       writer.println(smClient.getString("managerServlet.exception", new Object[] {t
/* 1035 */         .toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void writeDeployResult(PrintWriter writer, StringManager smClient, String name, String displayPath)
/*      */   {
/* 1043 */     org.apache.catalina.Context deployed = (org.apache.catalina.Context)this.host.findChild(name);
/* 1044 */     if ((deployed != null) && (deployed.getConfigured()) && 
/* 1045 */       (deployed.getState().isAvailable())) {
/* 1046 */       writer.println(smClient.getString("managerServlet.deployed", new Object[] { displayPath }));
/*      */     }
/* 1048 */     else if ((deployed != null) && (!deployed.getState().isAvailable())) {
/* 1049 */       writer.println(smClient.getString("managerServlet.deployedButNotStarted", new Object[] { displayPath }));
/*      */     }
/*      */     else
/*      */     {
/* 1053 */       writer.println(smClient.getString("managerServlet.deployFailed", new Object[] { displayPath }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void list(PrintWriter writer, StringManager smClient)
/*      */   {
/* 1067 */     if (this.debug >= 1) {
/* 1068 */       log("list: Listing contexts for virtual host '" + this.host
/* 1069 */         .getName() + "'");
/*      */     }
/*      */     
/* 1072 */     writer.println(smClient.getString("managerServlet.listed", new Object[] {this.host
/* 1073 */       .getName() }));
/* 1074 */     Container[] contexts = this.host.findChildren();
/* 1075 */     for (Container container : contexts) {
/* 1076 */       org.apache.catalina.Context context = (org.apache.catalina.Context)container;
/* 1077 */       if (context != null) {
/* 1078 */         String displayPath = context.getPath();
/* 1079 */         if (displayPath.equals("")) {
/* 1080 */           displayPath = "/";
/*      */         }
/* 1082 */         List<String> parts = null;
/* 1083 */         if (context.getState().isAvailable()) {
/* 1084 */           parts = Arrays.asList(new String[] { displayPath, "running", "" + context
/*      */           
/*      */ 
/* 1087 */             .getManager().findSessions().length, context
/* 1088 */             .getDocBase() });
/*      */         } else {
/* 1090 */           parts = Arrays.asList(new String[] { displayPath, "stopped", "0", context
/*      */           
/*      */ 
/*      */ 
/* 1094 */             .getDocBase() });
/*      */         }
/* 1096 */         writer.println(StringUtils.join(parts, ':'));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void reload(PrintWriter writer, ContextName cn, StringManager smClient)
/*      */   {
/* 1112 */     if (this.debug >= 1) {
/* 1113 */       log("restart: Reloading web application '" + cn + "'");
/*      */     }
/*      */     
/* 1116 */     if (!validateContextName(cn, writer, smClient)) {
/* 1117 */       return;
/*      */     }
/*      */     try
/*      */     {
/* 1121 */       org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(cn.getName());
/* 1122 */       if (context == null) {
/* 1123 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] {
/* 1124 */           Escape.htmlElementContent(cn.getDisplayName()) }));
/* 1125 */         return;
/*      */       }
/*      */       
/* 1128 */       if (context.getName().equals(this.context.getName())) {
/* 1129 */         writer.println(smClient.getString("managerServlet.noSelf"));
/* 1130 */         return;
/*      */       }
/* 1132 */       context.reload();
/* 1133 */       writer.println(smClient.getString("managerServlet.reloaded", new Object[] {cn
/* 1134 */         .getDisplayName() }));
/*      */     } catch (Throwable t) {
/* 1136 */       ExceptionUtils.handleThrowable(t);
/* 1137 */       log(sm.getString("managerServlet.error.reload", new Object[] { cn.getDisplayName() }), t);
/* 1138 */       writer.println(smClient.getString("managerServlet.exception", new Object[] {t
/* 1139 */         .toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void resources(PrintWriter writer, String type, StringManager smClient)
/*      */   {
/* 1156 */     if (this.debug >= 1) {
/* 1157 */       if (type != null) {
/* 1158 */         log("resources:  Listing resources of type " + type);
/*      */       } else {
/* 1160 */         log("resources:  Listing resources of all types");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1165 */     if (this.global == null) {
/* 1166 */       writer.println(smClient.getString("managerServlet.noGlobal"));
/* 1167 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1171 */     if (type != null) {
/* 1172 */       writer.println(smClient.getString("managerServlet.resourcesType", new Object[] { type }));
/*      */     }
/*      */     else {
/* 1175 */       writer.println(smClient.getString("managerServlet.resourcesAll"));
/*      */     }
/*      */     
/* 1178 */     printResources(writer, "", this.global, type, smClient);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected void printResources(PrintWriter writer, String prefix, javax.naming.Context namingContext, String type, Class<?> clazz, StringManager smClient)
/*      */   {
/* 1202 */     printResources(writer, prefix, namingContext, type, smClient);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void printResources(PrintWriter writer, String prefix, javax.naming.Context namingContext, String type, StringManager smClient)
/*      */   {
/*      */     try
/*      */     {
/* 1220 */       NamingEnumeration<Binding> items = namingContext.listBindings("");
/* 1221 */       while (items.hasMore()) {
/* 1222 */         Binding item = (Binding)items.next();
/* 1223 */         Object obj = item.getObject();
/* 1224 */         if ((obj instanceof javax.naming.Context)) {
/* 1225 */           printResources(writer, prefix + item.getName() + "/", (javax.naming.Context)obj, type, smClient);
/*      */ 
/*      */         }
/* 1228 */         else if ((type == null) || ((obj != null) && 
/* 1229 */           (IntrospectionUtils.isInstance(obj.getClass(), type))))
/*      */         {
/*      */ 
/* 1232 */           writer.print(prefix + item.getName());
/* 1233 */           writer.print(':');
/* 1234 */           writer.print(item.getClassName());
/*      */           
/* 1236 */           writer.println();
/*      */         }
/*      */       }
/*      */     } catch (Throwable t) {
/* 1240 */       ExceptionUtils.handleThrowable(t);
/* 1241 */       log(sm.getString("managerServlet.error.resources", new Object[] { type }), t);
/* 1242 */       writer.println(smClient.getString("managerServlet.exception", new Object[] {t
/* 1243 */         .toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void serverinfo(PrintWriter writer, StringManager smClient)
/*      */   {
/* 1254 */     if (this.debug >= 1) {
/* 1255 */       log("serverinfo");
/*      */     }
/*      */     try {
/* 1258 */       writer.println(smClient.getString("managerServlet.serverInfo", new Object[] { ServerInfo.getServerInfo(), 
/* 1259 */         System.getProperty("os.name"), System.getProperty("os.version"), System.getProperty("os.arch"), 
/* 1260 */         System.getProperty("java.runtime.version"), System.getProperty("java.vm.vendor") }));
/*      */     } catch (Throwable t) {
/* 1262 */       ExceptionUtils.handleThrowable(t);
/* 1263 */       log(sm.getString("managerServlet.error.serverInfo"), t);
/* 1264 */       writer.println(smClient.getString("managerServlet.exception", new Object[] {t
/* 1265 */         .toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void sessions(PrintWriter writer, ContextName cn, int idle, StringManager smClient)
/*      */   {
/* 1282 */     if (this.debug >= 1) {
/* 1283 */       log("sessions: Session information for web application '" + cn + "'");
/* 1284 */       if (idle >= 0) {
/* 1285 */         log("sessions: Session expiration for " + idle + " minutes '" + cn + "'");
/*      */       }
/*      */     }
/*      */     
/* 1289 */     if (!validateContextName(cn, writer, smClient)) {
/* 1290 */       return;
/*      */     }
/*      */     
/* 1293 */     String displayPath = cn.getDisplayName();
/*      */     try
/*      */     {
/* 1296 */       org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(cn.getName());
/* 1297 */       if (context == null) {
/* 1298 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] {
/* 1299 */           Escape.htmlElementContent(displayPath) }));
/* 1300 */         return;
/*      */       }
/* 1302 */       Manager manager = context.getManager();
/* 1303 */       if (manager == null) {
/* 1304 */         writer.println(smClient.getString("managerServlet.noManager", new Object[] {
/* 1305 */           Escape.htmlElementContent(displayPath) }));
/* 1306 */         return;
/*      */       }
/* 1308 */       int maxCount = 60;
/* 1309 */       int histoInterval = 1;
/* 1310 */       int maxInactiveInterval = context.getSessionTimeout();
/* 1311 */       if (maxInactiveInterval > 0) {
/* 1312 */         histoInterval = maxInactiveInterval / maxCount;
/* 1313 */         if (histoInterval * maxCount < maxInactiveInterval) {
/* 1314 */           histoInterval++;
/*      */         }
/* 1316 */         if (0 == histoInterval) {
/* 1317 */           histoInterval = 1;
/*      */         }
/* 1319 */         maxCount = maxInactiveInterval / histoInterval;
/* 1320 */         if (histoInterval * maxCount < maxInactiveInterval) {
/* 1321 */           maxCount++;
/*      */         }
/*      */       }
/*      */       
/* 1325 */       writer.println(smClient.getString("managerServlet.sessions", new Object[] { displayPath }));
/*      */       
/* 1327 */       writer.println(smClient.getString("managerServlet.sessiondefaultmax", new Object[] { "" + maxInactiveInterval }));
/*      */       
/*      */ 
/* 1330 */       Session[] sessions = manager.findSessions();
/* 1331 */       int[] timeout = new int[maxCount + 1];
/* 1332 */       int notimeout = 0;
/* 1333 */       int expired = 0;
/* 1334 */       for (Session session : sessions) {
/* 1335 */         int time = (int)(session.getIdleTimeInternal() / 1000L);
/* 1336 */         if ((idle >= 0) && (time >= idle * 60)) {
/* 1337 */           session.expire();
/* 1338 */           expired++;
/*      */         }
/* 1340 */         time = time / 60 / histoInterval;
/* 1341 */         if (time < 0) {
/* 1342 */           notimeout++;
/* 1343 */         } else if (time >= maxCount) {
/* 1344 */           timeout[maxCount] += 1;
/*      */         } else {
/* 1346 */           timeout[time] += 1;
/*      */         }
/*      */       }
/* 1349 */       if (timeout[0] > 0) {
/* 1350 */         writer.println(smClient.getString("managerServlet.sessiontimeout", new Object[] { "<" + histoInterval, "" + timeout[0] }));
/*      */       }
/*      */       
/*      */ 
/* 1354 */       for (int i = 1; i < maxCount; i++) {
/* 1355 */         if (timeout[i] > 0) {
/* 1356 */           writer.println(smClient.getString("managerServlet.sessiontimeout", new Object[] { "" + i * histoInterval + " - <" + (i + 1) * histoInterval, "" + timeout[i] }));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1362 */       if (timeout[maxCount] > 0) {
/* 1363 */         writer.println(smClient.getString("managerServlet.sessiontimeout", new Object[] { ">=" + maxCount * histoInterval, "" + timeout[maxCount] }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1368 */       if (notimeout > 0) {
/* 1369 */         writer.println(smClient.getString("managerServlet.sessiontimeout.unlimited", new Object[] { "" + notimeout }));
/*      */       }
/*      */       
/*      */ 
/* 1373 */       if (idle >= 0) {
/* 1374 */         writer.println(smClient.getString("managerServlet.sessiontimeout.expired", new Object[] { ">" + idle, "" + expired }));
/*      */       }
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/* 1379 */       ExceptionUtils.handleThrowable(t);
/* 1380 */       log(sm.getString("managerServlet.error.sessions", new Object[] { displayPath }), t);
/* 1381 */       writer.println(smClient.getString("managerServlet.exception", new Object[] {t
/* 1382 */         .toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void expireSessions(PrintWriter writer, ContextName cn, HttpServletRequest req, StringManager smClient)
/*      */   {
/* 1398 */     int idle = -1;
/* 1399 */     String idleParam = req.getParameter("idle");
/* 1400 */     if (idleParam != null) {
/*      */       try {
/* 1402 */         idle = Integer.parseInt(idleParam);
/*      */       } catch (NumberFormatException e) {
/* 1404 */         log(sm.getString("managerServlet.error.idleParam", new Object[] { idleParam }));
/*      */       }
/*      */     }
/* 1407 */     sessions(writer, cn, idle, smClient);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void start(PrintWriter writer, ContextName cn, StringManager smClient)
/*      */   {
/* 1420 */     if (this.debug >= 1) {
/* 1421 */       log("start: Starting web application '" + cn + "'");
/*      */     }
/*      */     
/* 1424 */     if (!validateContextName(cn, writer, smClient)) {
/* 1425 */       return;
/*      */     }
/*      */     
/* 1428 */     String displayPath = cn.getDisplayName();
/*      */     try
/*      */     {
/* 1431 */       org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(cn.getName());
/* 1432 */       if (context == null) {
/* 1433 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] {
/* 1434 */           Escape.htmlElementContent(displayPath) }));
/* 1435 */         return;
/*      */       }
/* 1437 */       context.start();
/* 1438 */       if (context.getState().isAvailable()) {
/* 1439 */         writer.println(smClient.getString("managerServlet.started", new Object[] { displayPath }));
/*      */       }
/*      */       else {
/* 1442 */         writer.println(smClient.getString("managerServlet.startFailed", new Object[] { displayPath }));
/*      */       }
/*      */     }
/*      */     catch (Throwable t) {
/* 1446 */       ExceptionUtils.handleThrowable(t);
/* 1447 */       log(sm.getString("managerServlet.error.start", new Object[] { displayPath }), t);
/* 1448 */       writer.println(smClient.getString("managerServlet.startFailed", new Object[] { displayPath }));
/*      */       
/* 1450 */       writer.println(smClient.getString("managerServlet.exception", new Object[] {t
/* 1451 */         .toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void stop(PrintWriter writer, ContextName cn, StringManager smClient)
/*      */   {
/* 1467 */     if (this.debug >= 1) {
/* 1468 */       log("stop: Stopping web application '" + cn + "'");
/*      */     }
/*      */     
/* 1471 */     if (!validateContextName(cn, writer, smClient)) {
/* 1472 */       return;
/*      */     }
/*      */     
/* 1475 */     String displayPath = cn.getDisplayName();
/*      */     try
/*      */     {
/* 1478 */       org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(cn.getName());
/* 1479 */       if (context == null) {
/* 1480 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] {
/* 1481 */           Escape.htmlElementContent(displayPath) }));
/* 1482 */         return;
/*      */       }
/*      */       
/* 1485 */       if (context.getName().equals(this.context.getName())) {
/* 1486 */         writer.println(smClient.getString("managerServlet.noSelf"));
/* 1487 */         return;
/*      */       }
/* 1489 */       context.stop();
/* 1490 */       writer.println(smClient.getString("managerServlet.stopped", new Object[] { displayPath }));
/*      */     }
/*      */     catch (Throwable t) {
/* 1493 */       ExceptionUtils.handleThrowable(t);
/* 1494 */       log(sm.getString("managerServlet.error.stop", new Object[] { displayPath }), t);
/* 1495 */       writer.println(smClient.getString("managerServlet.exception", new Object[] {t
/* 1496 */         .toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void undeploy(PrintWriter writer, ContextName cn, StringManager smClient)
/*      */   {
/* 1512 */     if (this.debug >= 1) {
/* 1513 */       log("undeploy: Undeploying web application at '" + cn + "'");
/*      */     }
/*      */     
/* 1516 */     if (!validateContextName(cn, writer, smClient)) {
/* 1517 */       return;
/*      */     }
/*      */     
/* 1520 */     String name = cn.getName();
/* 1521 */     String baseName = cn.getBaseName();
/* 1522 */     String displayPath = cn.getDisplayName();
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1527 */       org.apache.catalina.Context context = (org.apache.catalina.Context)this.host.findChild(name);
/* 1528 */       if (context == null) {
/* 1529 */         writer.println(smClient.getString("managerServlet.noContext", new Object[] {
/* 1530 */           Escape.htmlElementContent(displayPath) }));
/* 1531 */         return;
/*      */       }
/*      */       
/* 1534 */       if (!isDeployed(name)) {
/* 1535 */         writer.println(smClient.getString("managerServlet.notDeployed", new Object[] {
/* 1536 */           Escape.htmlElementContent(displayPath) }));
/* 1537 */         return;
/*      */       }
/*      */       
/* 1540 */       if (tryAddServiced(name))
/*      */       {
/*      */         try {
/* 1543 */           context.stop();
/*      */         } catch (Throwable t) {
/* 1545 */           ExceptionUtils.handleThrowable(t);
/*      */         }
/*      */         try {
/* 1548 */           File war = new File(this.host.getAppBaseFile(), baseName + ".war");
/* 1549 */           File dir = new File(this.host.getAppBaseFile(), baseName);
/* 1550 */           File xml = new File(this.configBase, baseName + ".xml");
/* 1551 */           if ((war.exists()) && (!war.delete())) {
/* 1552 */             writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { war }));
/*      */             
/* 1554 */             return; }
/* 1555 */           if ((dir.exists()) && (!ExpandWar.delete(dir, false))) {
/* 1556 */             writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { dir }));
/*      */             
/* 1558 */             return; }
/* 1559 */           if ((xml.exists()) && (!xml.delete())) {
/* 1560 */             writer.println(smClient.getString("managerServlet.deleteFail", new Object[] { xml }));
/*      */             
/* 1562 */             return;
/*      */           }
/*      */         } finally {
/* 1565 */           removeServiced(name);
/*      */         }
/*      */         
/* 1568 */         check(name);
/*      */       } else {
/* 1570 */         writer.println(smClient.getString("managerServlet.inService", new Object[] { displayPath }));
/*      */       }
/* 1572 */       writer.println(smClient.getString("managerServlet.undeployed", new Object[] { displayPath }));
/*      */     }
/*      */     catch (Throwable t) {
/* 1575 */       ExceptionUtils.handleThrowable(t);
/* 1576 */       log(sm.getString("managerServlet.error.undeploy", new Object[] { displayPath }), t);
/* 1577 */       writer.println(smClient.getString("managerServlet.exception", new Object[] {t
/* 1578 */         .toString() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isDeployed(String name)
/*      */     throws Exception
/*      */   {
/* 1596 */     String[] params = { name };
/* 1597 */     String[] signature = { "java.lang.String" };
/*      */     
/* 1599 */     Boolean result = (Boolean)this.mBeanServer.invoke(this.oname, "isDeployed", params, signature);
/* 1600 */     return result.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void check(String name)
/*      */     throws Exception
/*      */   {
/* 1612 */     String[] params = { name };
/* 1613 */     String[] signature = { "java.lang.String" };
/* 1614 */     this.mBeanServer.invoke(this.oname, "check", params, signature);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected boolean isServiced(String name)
/*      */     throws Exception
/*      */   {
/* 1629 */     String[] params = { name };
/* 1630 */     String[] signature = { "java.lang.String" };
/*      */     
/* 1632 */     Boolean result = (Boolean)this.mBeanServer.invoke(this.oname, "isServiced", params, signature);
/* 1633 */     return result.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected void addServiced(String name)
/*      */     throws Exception
/*      */   {
/* 1648 */     String[] params = { name };
/* 1649 */     String[] signature = { "java.lang.String" };
/* 1650 */     this.mBeanServer.invoke(this.oname, "addServiced", params, signature);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean tryAddServiced(String name)
/*      */     throws Exception
/*      */   {
/* 1662 */     String[] params = { name };
/* 1663 */     String[] signature = { "java.lang.String" };
/* 1664 */     Boolean result = (Boolean)this.mBeanServer.invoke(this.oname, "tryAddServiced", params, signature);
/* 1665 */     return result.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void removeServiced(String name)
/*      */     throws Exception
/*      */   {
/* 1677 */     String[] params = { name };
/* 1678 */     String[] signature = { "java.lang.String" };
/* 1679 */     this.mBeanServer.invoke(this.oname, "removeServiced", params, signature);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void uploadWar(PrintWriter writer, HttpServletRequest request, File war, StringManager smClient)
/*      */     throws IOException
/*      */   {
/* 1698 */     if ((war.exists()) && (!war.delete())) {
/* 1699 */       String msg = smClient.getString("managerServlet.deleteFail", new Object[] { war });
/* 1700 */       throw new IOException(msg);
/*      */     }
/*      */     try {
/* 1703 */       ServletInputStream istream = request.getInputStream();Throwable localThrowable6 = null;
/* 1704 */       try { OutputStream ostream = new FileOutputStream(war);Throwable localThrowable7 = null;
/* 1705 */         try { IOTools.flow(istream, ostream);
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/* 1703 */           localThrowable7 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable4) { localThrowable6 = localThrowable4;throw localThrowable4;
/*      */       }
/*      */       finally {
/* 1706 */         if (istream != null) if (localThrowable6 != null) try { istream.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else istream.close();
/* 1707 */       } } catch (IOException e) { if ((war.exists()) && (!war.delete())) {
/* 1708 */         writer.println(smClient
/* 1709 */           .getString("managerServlet.deleteFail", new Object[] { war }));
/*      */       }
/* 1711 */       throw e;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static boolean validateContextName(ContextName cn, PrintWriter writer, StringManager smClient)
/*      */   {
/* 1721 */     if ((cn != null) && (
/* 1722 */       (cn.getPath().startsWith("/")) || (cn.getPath().equals("")))) {
/* 1723 */       return true;
/*      */     }
/*      */     
/* 1726 */     String path = null;
/* 1727 */     if (cn != null) {
/* 1728 */       path = Escape.htmlElementContent(cn.getPath());
/*      */     }
/* 1730 */     writer.println(smClient.getString("managerServlet.invalidPath", new Object[] { path }));
/* 1731 */     return false;
/*      */   }
/*      */   
/*      */   protected Map<String, List<String>> getConnectorCiphers(StringManager smClient) {
/* 1735 */     Map<String, List<String>> result = new HashMap();
/*      */     
/* 1737 */     Connector[] connectors = getConnectors();
/* 1738 */     for (Connector connector : connectors) {
/* 1739 */       if (Boolean.TRUE.equals(connector.getProperty("SSLEnabled"))) {
/* 1740 */         SSLHostConfig[] sslHostConfigs = connector.getProtocolHandler().findSslHostConfigs();
/* 1741 */         for (SSLHostConfig sslHostConfig : sslHostConfigs) {
/* 1742 */           String name = connector.toString() + "-" + sslHostConfig.getHostName();
/*      */           
/* 1744 */           result.put(name, new ArrayList(new LinkedHashSet(
/* 1745 */             Arrays.asList(sslHostConfig.getEnabledCiphers()))));
/*      */         }
/*      */       } else {
/* 1748 */         ArrayList<String> cipherList = new ArrayList(1);
/* 1749 */         cipherList.add(smClient.getString("managerServlet.notSslConnector"));
/* 1750 */         result.put(connector.toString(), cipherList);
/*      */       }
/*      */     }
/* 1753 */     return result;
/*      */   }
/*      */   
/*      */   protected Map<String, List<String>> getConnectorCerts(StringManager smClient)
/*      */   {
/* 1758 */     Map<String, List<String>> result = new HashMap();
/*      */     
/* 1760 */     Connector[] connectors = getConnectors();
/* 1761 */     for (Connector connector : connectors) {
/* 1762 */       if (Boolean.TRUE.equals(connector.getProperty("SSLEnabled"))) {
/* 1763 */         SSLHostConfig[] sslHostConfigs = connector.getProtocolHandler().findSslHostConfigs();
/* 1764 */         for (SSLHostConfig sslHostConfig : sslHostConfigs) {
/* 1765 */           if (sslHostConfig.getOpenSslContext().longValue() == 0L)
/*      */           {
/*      */ 
/* 1768 */             Set<SSLHostConfigCertificate> sslHostConfigCerts = sslHostConfig.getCertificates();
/* 1769 */             for (SSLHostConfigCertificate sslHostConfigCert : sslHostConfigCerts)
/*      */             {
/* 1771 */               String name = connector.toString() + "-" + sslHostConfig.getHostName() + "-" + sslHostConfigCert.getType();
/* 1772 */               List<String> certList = new ArrayList();
/* 1773 */               SSLContext sslContext = sslHostConfigCert.getSslContext();
/* 1774 */               String alias = sslHostConfigCert.getCertificateKeyAlias();
/* 1775 */               if (alias == null) {
/* 1776 */                 alias = "tomcat";
/*      */               }
/* 1778 */               X509Certificate[] certs = sslContext.getCertificateChain(alias);
/* 1779 */               if (certs == null) {
/* 1780 */                 certList.add(smClient.getString("managerServlet.certsNotAvailable"));
/*      */               } else {
/* 1782 */                 for (Certificate cert : certs) {
/* 1783 */                   certList.add(cert.toString());
/*      */                 }
/*      */               }
/* 1786 */               result.put(name, certList);
/*      */             }
/*      */           } else {
/* 1789 */             List<String> certList = new ArrayList();
/* 1790 */             certList.add(smClient.getString("managerServlet.certsNotAvailable"));
/* 1791 */             String name = connector.toString() + "-" + sslHostConfig.getHostName();
/* 1792 */             result.put(name, certList);
/*      */           }
/*      */         }
/*      */       } else {
/* 1796 */         List<String> certList = new ArrayList(1);
/* 1797 */         certList.add(smClient.getString("managerServlet.notSslConnector"));
/* 1798 */         result.put(connector.toString(), certList);
/*      */       }
/*      */     }
/*      */     
/* 1802 */     return result;
/*      */   }
/*      */   
/*      */   protected Map<String, List<String>> getConnectorTrustedCerts(StringManager smClient)
/*      */   {
/* 1807 */     Map<String, List<String>> result = new HashMap();
/*      */     
/* 1809 */     Connector[] connectors = getConnectors();
/* 1810 */     for (Connector connector : connectors) {
/* 1811 */       if (Boolean.TRUE.equals(connector.getProperty("SSLEnabled"))) {
/* 1812 */         SSLHostConfig[] sslHostConfigs = connector.getProtocolHandler().findSslHostConfigs();
/* 1813 */         for (SSLHostConfig sslHostConfig : sslHostConfigs) {
/* 1814 */           String name = connector.toString() + "-" + sslHostConfig.getHostName();
/* 1815 */           List<String> certList = new ArrayList();
/* 1816 */           if (sslHostConfig.getOpenSslContext().longValue() == 0L)
/*      */           {
/*      */ 
/* 1819 */             SSLContext sslContext = ((SSLHostConfigCertificate)sslHostConfig.getCertificates().iterator().next()).getSslContext();
/* 1820 */             X509Certificate[] certs = sslContext.getAcceptedIssuers();
/* 1821 */             if (certs == null) {
/* 1822 */               certList.add(smClient.getString("managerServlet.certsNotAvailable"));
/* 1823 */             } else if (certs.length == 0) {
/* 1824 */               certList.add(smClient.getString("managerServlet.trustedCertsNotConfigured"));
/*      */             } else {
/* 1826 */               for (Certificate cert : certs) {
/* 1827 */                 certList.add(cert.toString());
/*      */               }
/*      */             }
/*      */           } else {
/* 1831 */             certList.add(smClient.getString("managerServlet.certsNotAvailable"));
/*      */           }
/* 1833 */           result.put(name, certList);
/*      */         }
/*      */       } else {
/* 1836 */         List<String> certList = new ArrayList(1);
/* 1837 */         certList.add(smClient.getString("managerServlet.notSslConnector"));
/* 1838 */         result.put(connector.toString(), certList);
/*      */       }
/*      */     }
/*      */     
/* 1842 */     return result;
/*      */   }
/*      */   
/*      */   private Connector[] getConnectors()
/*      */   {
/* 1847 */     Engine e = (Engine)this.host.getParent();
/* 1848 */     Service s = e.getService();
/* 1849 */     return s.findConnectors();
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\manager\ManagerServlet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */