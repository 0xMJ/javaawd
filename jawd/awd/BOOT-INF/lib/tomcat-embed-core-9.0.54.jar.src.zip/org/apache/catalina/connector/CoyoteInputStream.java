/*     */ package org.apache.catalina.connector;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import javax.servlet.ReadListener;
/*     */ import javax.servlet.ServletInputStream;
/*     */ import org.apache.catalina.security.SecurityUtil;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoyoteInputStream
/*     */   extends ServletInputStream
/*     */ {
/*  38 */   protected static final StringManager sm = StringManager.getManager(CoyoteInputStream.class);
/*     */   
/*     */   protected InputBuffer ib;
/*     */   
/*     */ 
/*     */   protected CoyoteInputStream(InputBuffer ib)
/*     */   {
/*  45 */     this.ib = ib;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void clear()
/*     */   {
/*  53 */     this.ib = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/*  62 */     throw new CloneNotSupportedException();
/*     */   }
/*     */   
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  68 */     checkNonBlockingRead();
/*     */     
/*  70 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try
/*     */       {
/*  73 */         Integer result = (Integer)AccessController.doPrivileged(new PrivilegedRead(this.ib));
/*  74 */         return result.intValue();
/*     */       } catch (PrivilegedActionException pae) {
/*  76 */         Exception e = pae.getException();
/*  77 */         if ((e instanceof IOException)) {
/*  78 */           throw ((IOException)e);
/*     */         }
/*  80 */         throw new RuntimeException(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/*  84 */     return this.ib.readByte();
/*     */   }
/*     */   
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/*  91 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/*  93 */         Integer result = (Integer)AccessController.doPrivileged(new PrivilegedAvailable(this.ib));
/*  94 */         return result.intValue();
/*     */       } catch (PrivilegedActionException pae) {
/*  96 */         Exception e = pae.getException();
/*  97 */         if ((e instanceof IOException)) {
/*  98 */           throw ((IOException)e);
/*     */         }
/* 100 */         throw new RuntimeException(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/* 104 */     return this.ib.available();
/*     */   }
/*     */   
/*     */   public int read(byte[] b)
/*     */     throws IOException
/*     */   {
/* 110 */     return read(b, 0, b.length);
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 116 */     checkNonBlockingRead();
/*     */     
/* 118 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 120 */         Integer result = (Integer)AccessController.doPrivileged(new PrivilegedReadArray(this.ib, b, off, len));
/*     */         
/* 122 */         return result.intValue();
/*     */       } catch (PrivilegedActionException pae) {
/* 124 */         Exception e = pae.getException();
/* 125 */         if ((e instanceof IOException)) {
/* 126 */           throw ((IOException)e);
/*     */         }
/* 128 */         throw new RuntimeException(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/* 132 */     return this.ib.read(b, off, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(ByteBuffer b)
/*     */     throws IOException
/*     */   {
/* 149 */     checkNonBlockingRead();
/*     */     
/* 151 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 153 */         Integer result = (Integer)AccessController.doPrivileged(new PrivilegedReadBuffer(this.ib, b));
/* 154 */         return result.intValue();
/*     */       } catch (PrivilegedActionException pae) {
/* 156 */         Exception e = pae.getException();
/* 157 */         if ((e instanceof IOException)) {
/* 158 */           throw ((IOException)e);
/*     */         }
/* 160 */         throw new RuntimeException(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/* 164 */     return this.ib.read(b);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 177 */     if (SecurityUtil.isPackageProtectionEnabled()) {
/*     */       try {
/* 179 */         AccessController.doPrivileged(new PrivilegedClose(this.ib));
/*     */       } catch (PrivilegedActionException pae) {
/* 181 */         Exception e = pae.getException();
/* 182 */         if ((e instanceof IOException)) {
/* 183 */           throw ((IOException)e);
/*     */         }
/* 185 */         throw new RuntimeException(e.getMessage(), e);
/*     */       }
/*     */       
/*     */     } else {
/* 189 */       this.ib.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isFinished()
/*     */   {
/* 195 */     return this.ib.isFinished();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isReady()
/*     */   {
/* 201 */     return this.ib.isReady();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setReadListener(ReadListener listener)
/*     */   {
/* 207 */     this.ib.setReadListener(listener);
/*     */   }
/*     */   
/*     */   private void checkNonBlockingRead()
/*     */   {
/* 212 */     if ((!this.ib.isBlocking()) && (!this.ib.isReady())) {
/* 213 */       throw new IllegalStateException(sm.getString("coyoteInputStream.nbNotready"));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedAvailable implements PrivilegedExceptionAction<Integer>
/*     */   {
/*     */     private final InputBuffer inputBuffer;
/*     */     
/*     */     public PrivilegedAvailable(InputBuffer inputBuffer)
/*     */     {
/* 223 */       this.inputBuffer = inputBuffer;
/*     */     }
/*     */     
/*     */     public Integer run() throws IOException
/*     */     {
/* 228 */       return Integer.valueOf(this.inputBuffer.available());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedClose implements PrivilegedExceptionAction<Void>
/*     */   {
/*     */     private final InputBuffer inputBuffer;
/*     */     
/*     */     public PrivilegedClose(InputBuffer inputBuffer)
/*     */     {
/* 238 */       this.inputBuffer = inputBuffer;
/*     */     }
/*     */     
/*     */     public Void run() throws IOException
/*     */     {
/* 243 */       this.inputBuffer.close();
/* 244 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedRead implements PrivilegedExceptionAction<Integer>
/*     */   {
/*     */     private final InputBuffer inputBuffer;
/*     */     
/*     */     public PrivilegedRead(InputBuffer inputBuffer)
/*     */     {
/* 254 */       this.inputBuffer = inputBuffer;
/*     */     }
/*     */     
/*     */     public Integer run() throws IOException
/*     */     {
/* 259 */       Integer integer = Integer.valueOf(this.inputBuffer.readByte());
/* 260 */       return integer;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedReadArray implements PrivilegedExceptionAction<Integer>
/*     */   {
/*     */     private final InputBuffer inputBuffer;
/*     */     private final byte[] buf;
/*     */     private final int off;
/*     */     private final int len;
/*     */     
/*     */     public PrivilegedReadArray(InputBuffer inputBuffer, byte[] buf, int off, int len)
/*     */     {
/* 273 */       this.inputBuffer = inputBuffer;
/* 274 */       this.buf = buf;
/* 275 */       this.off = off;
/* 276 */       this.len = len;
/*     */     }
/*     */     
/*     */     public Integer run() throws IOException
/*     */     {
/* 281 */       Integer integer = Integer.valueOf(this.inputBuffer.read(this.buf, this.off, this.len));
/* 282 */       return integer;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedReadBuffer implements PrivilegedExceptionAction<Integer>
/*     */   {
/*     */     private final InputBuffer inputBuffer;
/*     */     private final ByteBuffer bb;
/*     */     
/*     */     public PrivilegedReadBuffer(InputBuffer inputBuffer, ByteBuffer bb)
/*     */     {
/* 293 */       this.inputBuffer = inputBuffer;
/* 294 */       this.bb = bb;
/*     */     }
/*     */     
/*     */     public Integer run() throws IOException
/*     */     {
/* 299 */       Integer integer = Integer.valueOf(this.inputBuffer.read(this.bb));
/* 300 */       return integer;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\connector\CoyoteInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */