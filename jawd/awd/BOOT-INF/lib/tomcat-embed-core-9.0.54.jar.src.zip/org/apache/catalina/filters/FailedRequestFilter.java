/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.http.Parameters.FailReason;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FailedRequestFilter
/*     */   extends FilterBase
/*     */ {
/*  49 */   private final Log log = LogFactory.getLog(FailedRequestFilter.class);
/*     */   
/*     */   protected Log getLogger()
/*     */   {
/*  53 */     return this.log;
/*     */   }
/*     */   
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  59 */     if (!isGoodRequest(request)) {
/*  60 */       Parameters.FailReason reason = (Parameters.FailReason)request.getAttribute("org.apache.catalina.parameter_parse_failed_reason");
/*     */       
/*     */       int status;
/*     */       int status;
/*     */       int status;
/*  65 */       switch (reason)
/*     */       {
/*     */       case IO_ERROR: 
/*  68 */         status = 500;
/*  69 */         break;
/*     */       case POST_TOO_LARGE: 
/*  71 */         status = 413;
/*  72 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       case TOO_MANY_PARAMETERS: 
/*     */       case UNKNOWN: 
/*     */       case INVALID_CONTENT_TYPE: 
/*     */       case MULTIPART_CONFIG_INVALID: 
/*     */       case NO_NAME: 
/*     */       case REQUEST_BODY_INCOMPLETE: 
/*     */       case URL_DECODING: 
/*     */       case CLIENT_DISCONNECT: 
/*     */       default: 
/*  90 */         status = 400;
/*     */       }
/*     */       
/*     */       
/*  94 */       ((HttpServletResponse)response).sendError(status);
/*  95 */       return;
/*     */     }
/*  97 */     chain.doFilter(request, response);
/*     */   }
/*     */   
/*     */   private boolean isGoodRequest(ServletRequest request)
/*     */   {
/* 102 */     request.getParameter("none");
/*     */     
/* 104 */     if (request.getAttribute("org.apache.catalina.parameter_parse_failed") != null) {
/* 105 */       return false;
/*     */     }
/* 107 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean isConfigProblemFatal()
/*     */   {
/* 112 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\filters\FailedRequestFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */