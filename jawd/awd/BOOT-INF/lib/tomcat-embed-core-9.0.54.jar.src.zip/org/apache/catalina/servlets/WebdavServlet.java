/*      */ package org.apache.catalina.servlets;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringReader;
/*      */ import java.io.StringWriter;
/*      */ import java.io.Writer;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Locale;
/*      */ import java.util.Stack;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Vector;
/*      */ import javax.servlet.DispatcherType;
/*      */ import javax.servlet.ServletConfig;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.connector.RequestFacade;
/*      */ import org.apache.catalina.util.DOMWriter;
/*      */ import org.apache.catalina.util.URLEncoder;
/*      */ import org.apache.catalina.util.XMLWriter;
/*      */ import org.apache.tomcat.util.buf.UDecoder;
/*      */ import org.apache.tomcat.util.http.ConcurrentDateFormat;
/*      */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*      */ import org.apache.tomcat.util.http.RequestUtil;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.ConcurrentMessageDigest;
/*      */ import org.apache.tomcat.util.security.MD5Encoder;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.EntityResolver;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WebdavServlet
/*      */   extends DefaultServlet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*  138 */   private static final URLEncoder URL_ENCODER_XML = (URLEncoder)URLEncoder.DEFAULT.clone();
/*      */   private static final String METHOD_PROPFIND = "PROPFIND";
/*      */   
/*      */   static {
/*  142 */     URL_ENCODER_XML.removeSafeCharacter('&');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final String METHOD_PROPPATCH = "PROPPATCH";
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String METHOD_MKCOL = "MKCOL";
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String METHOD_COPY = "COPY";
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String METHOD_MOVE = "MOVE";
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String METHOD_LOCK = "LOCK";
/*      */   
/*      */ 
/*      */ 
/*      */   private static final String METHOD_UNLOCK = "UNLOCK";
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int FIND_BY_PROPERTY = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int FIND_ALL_PROP = 1;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int FIND_PROPERTY_NAMES = 2;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int LOCK_CREATION = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int LOCK_REFRESH = 1;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int DEFAULT_TIMEOUT = 3600;
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int MAX_TIMEOUT = 604800;
/*      */   
/*      */ 
/*      */ 
/*      */   protected static final String DEFAULT_NAMESPACE = "DAV:";
/*      */   
/*      */ 
/*      */ 
/*  205 */   protected static final ConcurrentDateFormat creationDateFormat = new ConcurrentDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US, 
/*      */   
/*  207 */     TimeZone.getTimeZone("GMT"));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  218 */   private final Hashtable<String, LockInfo> resourceLocks = new Hashtable();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  229 */   private final Hashtable<String, Vector<String>> lockNullResources = new Hashtable();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  239 */   private final Vector<LockInfo> collectionLocks = new Vector();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  245 */   private String secret = "catalina";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  252 */   private int maxDepth = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  259 */   private boolean allowSpecialPaths = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void init()
/*      */     throws ServletException
/*      */   {
/*  272 */     super.init();
/*      */     
/*  274 */     if (getServletConfig().getInitParameter("secret") != null) {
/*  275 */       this.secret = getServletConfig().getInitParameter("secret");
/*      */     }
/*      */     
/*  278 */     if (getServletConfig().getInitParameter("maxDepth") != null) {
/*  279 */       this.maxDepth = Integer.parseInt(
/*  280 */         getServletConfig().getInitParameter("maxDepth"));
/*      */     }
/*      */     
/*  283 */     if (getServletConfig().getInitParameter("allowSpecialPaths") != null) {
/*  284 */       this.allowSpecialPaths = Boolean.parseBoolean(
/*  285 */         getServletConfig().getInitParameter("allowSpecialPaths"));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DocumentBuilder getDocumentBuilder()
/*      */     throws ServletException
/*      */   {
/*  301 */     DocumentBuilder documentBuilder = null;
/*  302 */     DocumentBuilderFactory documentBuilderFactory = null;
/*      */     try {
/*  304 */       documentBuilderFactory = DocumentBuilderFactory.newInstance();
/*  305 */       documentBuilderFactory.setNamespaceAware(true);
/*  306 */       documentBuilderFactory.setExpandEntityReferences(false);
/*  307 */       documentBuilder = documentBuilderFactory.newDocumentBuilder();
/*  308 */       documentBuilder.setEntityResolver(new WebdavResolver(
/*  309 */         getServletContext()));
/*      */     }
/*      */     catch (ParserConfigurationException e) {
/*  312 */       throw new ServletException(sm.getString("webdavservlet.jaxpfailed"));
/*      */     }
/*  314 */     return documentBuilder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void service(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  325 */     String path = getRelativePath(req);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  330 */     if (req.getDispatcherType() == DispatcherType.ERROR) {
/*  331 */       doGet(req, resp);
/*  332 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  340 */     if (isSpecialPath(path)) {
/*  341 */       resp.sendError(404);
/*  342 */       return;
/*      */     }
/*      */     
/*  345 */     String method = req.getMethod();
/*      */     
/*  347 */     if (this.debug > 0) {
/*  348 */       log("[" + method + "] " + path);
/*      */     }
/*      */     
/*  351 */     if (method.equals("PROPFIND")) {
/*  352 */       doPropfind(req, resp);
/*  353 */     } else if (method.equals("PROPPATCH")) {
/*  354 */       doProppatch(req, resp);
/*  355 */     } else if (method.equals("MKCOL")) {
/*  356 */       doMkcol(req, resp);
/*  357 */     } else if (method.equals("COPY")) {
/*  358 */       doCopy(req, resp);
/*  359 */     } else if (method.equals("MOVE")) {
/*  360 */       doMove(req, resp);
/*  361 */     } else if (method.equals("LOCK")) {
/*  362 */       doLock(req, resp);
/*  363 */     } else if (method.equals("UNLOCK")) {
/*  364 */       doUnlock(req, resp);
/*      */     }
/*      */     else {
/*  367 */       super.service(req, resp);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean isSpecialPath(String path)
/*      */   {
/*  380 */     return (!this.allowSpecialPaths) && (
/*  381 */       (path.toUpperCase(Locale.ENGLISH).startsWith("/WEB-INF")) || 
/*  382 */       (path.toUpperCase(Locale.ENGLISH).startsWith("/META-INF")));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkIfHeaders(HttpServletRequest request, HttpServletResponse response, WebResource resource)
/*      */     throws IOException
/*      */   {
/*  392 */     if (!super.checkIfHeaders(request, response, resource)) {
/*  393 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  397 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String rewriteUrl(String path)
/*      */   {
/*  409 */     return URL_ENCODER_XML.encode(path, StandardCharsets.UTF_8);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getRelativePath(HttpServletRequest request)
/*      */   {
/*  423 */     return getRelativePath(request, false);
/*      */   }
/*      */   
/*      */   protected String getRelativePath(HttpServletRequest request, boolean allowEmptyPath)
/*      */   {
/*      */     String pathInfo;
/*      */     String pathInfo;
/*  430 */     if (request.getAttribute("javax.servlet.include.request_uri") != null)
/*      */     {
/*  432 */       pathInfo = (String)request.getAttribute("javax.servlet.include.path_info");
/*      */     } else {
/*  434 */       pathInfo = request.getPathInfo();
/*      */     }
/*      */     
/*  437 */     StringBuilder result = new StringBuilder();
/*  438 */     if (pathInfo != null) {
/*  439 */       result.append(pathInfo);
/*      */     }
/*  441 */     if (result.length() == 0) {
/*  442 */       result.append('/');
/*      */     }
/*      */     
/*  445 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getPathPrefix(HttpServletRequest request)
/*      */   {
/*  455 */     String contextPath = request.getContextPath();
/*  456 */     if (request.getServletPath() != null) {
/*  457 */       contextPath = contextPath + request.getServletPath();
/*      */     }
/*  459 */     return contextPath;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doOptions(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  475 */     resp.addHeader("DAV", "1,2");
/*  476 */     resp.addHeader("Allow", determineMethodsAllowed(req));
/*  477 */     resp.addHeader("MS-Author-Via", "DAV");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doPropfind(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  491 */     if (!this.listings) {
/*  492 */       sendNotAllowed(req, resp);
/*  493 */       return;
/*      */     }
/*      */     
/*  496 */     String path = getRelativePath(req);
/*  497 */     if ((path.length() > 1) && (path.endsWith("/"))) {
/*  498 */       path = path.substring(0, path.length() - 1);
/*      */     }
/*      */     
/*      */ 
/*  502 */     Vector<String> properties = null;
/*      */     
/*  504 */     int depth = this.maxDepth;
/*      */     
/*  506 */     int type = 1;
/*      */     
/*  508 */     String depthStr = req.getHeader("Depth");
/*      */     
/*  510 */     if (depthStr == null) {
/*  511 */       depth = this.maxDepth;
/*      */     }
/*  513 */     else if (depthStr.equals("0")) {
/*  514 */       depth = 0;
/*  515 */     } else if (depthStr.equals("1")) {
/*  516 */       depth = 1;
/*  517 */     } else if (depthStr.equals("infinity")) {
/*  518 */       depth = this.maxDepth;
/*      */     }
/*      */     
/*      */ 
/*  522 */     Node propNode = null;
/*      */     
/*  524 */     if (req.getContentLengthLong() > 0L) {
/*  525 */       DocumentBuilder documentBuilder = getDocumentBuilder();
/*      */       
/*      */       try
/*      */       {
/*  529 */         Document document = documentBuilder.parse(new InputSource(req.getInputStream()));
/*      */         
/*      */ 
/*  532 */         Element rootElement = document.getDocumentElement();
/*  533 */         NodeList childList = rootElement.getChildNodes();
/*      */         
/*  535 */         for (int i = 0; i < childList.getLength(); i++) {
/*  536 */           Node currentNode = childList.item(i);
/*  537 */           switch (currentNode.getNodeType()) {
/*      */           case 3: 
/*      */             break;
/*      */           case 1: 
/*  541 */             if (currentNode.getNodeName().endsWith("prop")) {
/*  542 */               type = 0;
/*  543 */               propNode = currentNode;
/*      */             }
/*  545 */             if (currentNode.getNodeName().endsWith("propname")) {
/*  546 */               type = 2;
/*      */             }
/*  548 */             if (currentNode.getNodeName().endsWith("allprop")) {
/*  549 */               type = 1;
/*      */             }
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (SAXException|IOException e) {
/*  556 */         resp.sendError(400);
/*  557 */         return;
/*      */       }
/*      */     }
/*      */     
/*  561 */     if (type == 0) {
/*  562 */       properties = new Vector();
/*      */       
/*      */ 
/*  565 */       NodeList childList = propNode.getChildNodes();
/*      */       
/*  567 */       for (int i = 0; i < childList.getLength(); i++) {
/*  568 */         Node currentNode = childList.item(i);
/*  569 */         switch (currentNode.getNodeType()) {
/*      */         case 3: 
/*      */           break;
/*      */         case 1: 
/*  573 */           String nodeName = currentNode.getNodeName();
/*  574 */           String propertyName = null;
/*  575 */           if (nodeName.indexOf(':') != -1)
/*      */           {
/*  577 */             propertyName = nodeName.substring(nodeName.indexOf(':') + 1);
/*      */           } else {
/*  579 */             propertyName = nodeName;
/*      */           }
/*      */           
/*  582 */           properties.addElement(propertyName);
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  589 */     WebResource resource = this.resources.getResource(path);
/*      */     XMLWriter generatedXML;
/*  591 */     if (!resource.exists()) {
/*  592 */       int slash = path.lastIndexOf('/');
/*  593 */       if (slash != -1) {
/*  594 */         String parentPath = path.substring(0, slash);
/*      */         
/*  596 */         Vector<String> currentLockNullResources = (Vector)this.lockNullResources.get(parentPath);
/*  597 */         if (currentLockNullResources != null)
/*      */         {
/*  599 */           Enumeration<String> lockNullResourcesList = currentLockNullResources.elements();
/*  600 */           while (lockNullResourcesList.hasMoreElements())
/*      */           {
/*  602 */             String lockNullPath = (String)lockNullResourcesList.nextElement();
/*  603 */             if (lockNullPath.equals(path)) {
/*  604 */               resp.setStatus(207);
/*  605 */               resp.setContentType("text/xml; charset=UTF-8");
/*      */               
/*      */ 
/*  608 */               generatedXML = new XMLWriter(resp.getWriter());
/*  609 */               generatedXML.writeXMLHeader();
/*  610 */               generatedXML.writeElement("D", "DAV:", "multistatus", 0);
/*      */               
/*      */ 
/*  613 */               parseLockNullProperties(req, generatedXML, lockNullPath, type, properties);
/*      */               
/*  615 */               generatedXML.writeElement("D", "multistatus", 1);
/*      */               
/*  617 */               generatedXML.sendData();
/*  618 */               return;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  625 */     if (!resource.exists()) {
/*  626 */       resp.sendError(404);
/*  627 */       return;
/*      */     }
/*      */     
/*  630 */     resp.setStatus(207);
/*      */     
/*  632 */     resp.setContentType("text/xml; charset=UTF-8");
/*      */     
/*      */ 
/*  635 */     XMLWriter generatedXML = new XMLWriter(resp.getWriter());
/*  636 */     generatedXML.writeXMLHeader();
/*      */     
/*  638 */     generatedXML.writeElement("D", "DAV:", "multistatus", 0);
/*      */     
/*      */ 
/*  641 */     if (depth == 0) {
/*  642 */       parseProperties(req, generatedXML, path, type, properties);
/*      */     }
/*      */     else
/*      */     {
/*  646 */       Stack<String> stack = new Stack();
/*  647 */       stack.push(path);
/*      */       
/*      */ 
/*  650 */       Stack<String> stackBelow = new Stack();
/*      */       
/*  652 */       while ((!stack.isEmpty()) && (depth >= 0))
/*      */       {
/*  654 */         String currentPath = (String)stack.pop();
/*  655 */         parseProperties(req, generatedXML, currentPath, type, properties);
/*      */         
/*      */ 
/*  658 */         resource = this.resources.getResource(currentPath);
/*      */         
/*  660 */         if ((resource.isDirectory()) && (depth > 0))
/*      */         {
/*  662 */           String[] entries = this.resources.list(currentPath);
/*  663 */           for (String entry : entries) {
/*  664 */             String newPath = currentPath;
/*  665 */             if (!newPath.endsWith("/")) {
/*  666 */               newPath = newPath + "/";
/*      */             }
/*  668 */             newPath = newPath + entry;
/*  669 */             stackBelow.push(newPath);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  674 */           String lockPath = currentPath;
/*  675 */           if (lockPath.endsWith("/"))
/*      */           {
/*  677 */             lockPath = lockPath.substring(0, lockPath.length() - 1);
/*      */           }
/*      */           
/*  680 */           Object currentLockNullResources = (Vector)this.lockNullResources.get(lockPath);
/*  681 */           if (currentLockNullResources != null)
/*      */           {
/*  683 */             Object lockNullResourcesList = ((Vector)currentLockNullResources).elements();
/*  684 */             while (((Enumeration)lockNullResourcesList).hasMoreElements())
/*      */             {
/*  686 */               String lockNullPath = (String)((Enumeration)lockNullResourcesList).nextElement();
/*      */               
/*  688 */               parseLockNullProperties(req, generatedXML, lockNullPath, type, properties);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  695 */         if (stack.isEmpty()) {
/*  696 */           depth--;
/*  697 */           stack = stackBelow;
/*  698 */           stackBelow = new Stack();
/*      */         }
/*      */         
/*  701 */         generatedXML.sendData();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  706 */     generatedXML.writeElement("D", "multistatus", 1);
/*      */     
/*  708 */     generatedXML.sendData();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doProppatch(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/*  722 */     if (this.readOnly) {
/*  723 */       resp.sendError(403);
/*  724 */       return;
/*      */     }
/*      */     
/*  727 */     if (isLocked(req)) {
/*  728 */       resp.sendError(423);
/*  729 */       return;
/*      */     }
/*      */     
/*  732 */     resp.sendError(501);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doMkcol(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  747 */     String path = getRelativePath(req);
/*      */     
/*  749 */     WebResource resource = this.resources.getResource(path);
/*      */     
/*      */ 
/*      */ 
/*  753 */     if (resource.exists()) {
/*  754 */       sendNotAllowed(req, resp);
/*  755 */       return;
/*      */     }
/*      */     
/*  758 */     if (this.readOnly) {
/*  759 */       resp.sendError(403);
/*  760 */       return;
/*      */     }
/*      */     
/*  763 */     if (isLocked(req)) {
/*  764 */       resp.sendError(423);
/*  765 */       return;
/*      */     }
/*      */     
/*  768 */     if (req.getContentLengthLong() > 0L) {
/*  769 */       DocumentBuilder documentBuilder = getDocumentBuilder();
/*      */       try
/*      */       {
/*  772 */         documentBuilder.parse(new InputSource(req.getInputStream()));
/*      */         
/*  774 */         resp.sendError(501);
/*  775 */         return;
/*      */       }
/*      */       catch (SAXException saxe)
/*      */       {
/*  779 */         resp.sendError(415);
/*  780 */         return;
/*      */       }
/*      */     }
/*      */     
/*  784 */     if (this.resources.mkdir(path)) {
/*  785 */       resp.setStatus(201);
/*      */       
/*  787 */       this.lockNullResources.remove(path);
/*      */     } else {
/*  789 */       resp.sendError(409);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doDelete(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  805 */     if (this.readOnly) {
/*  806 */       sendNotAllowed(req, resp);
/*  807 */       return;
/*      */     }
/*      */     
/*  810 */     if (isLocked(req)) {
/*  811 */       resp.sendError(423);
/*  812 */       return;
/*      */     }
/*      */     
/*  815 */     deleteResource(req, resp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doPut(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  833 */     if (isLocked(req)) {
/*  834 */       resp.sendError(423);
/*  835 */       return;
/*      */     }
/*      */     
/*  838 */     String path = getRelativePath(req);
/*  839 */     WebResource resource = this.resources.getResource(path);
/*  840 */     if (resource.isDirectory()) {
/*  841 */       sendNotAllowed(req, resp);
/*  842 */       return;
/*      */     }
/*      */     
/*  845 */     super.doPut(req, resp);
/*      */     
/*      */ 
/*  848 */     this.lockNullResources.remove(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doCopy(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/*  861 */     if (this.readOnly) {
/*  862 */       resp.sendError(403);
/*  863 */       return;
/*      */     }
/*      */     
/*  866 */     copyResource(req, resp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doMove(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/*  880 */     if (this.readOnly) {
/*  881 */       resp.sendError(403);
/*  882 */       return;
/*      */     }
/*      */     
/*  885 */     if (isLocked(req)) {
/*  886 */       resp.sendError(423);
/*  887 */       return;
/*      */     }
/*      */     
/*  890 */     String path = getRelativePath(req);
/*      */     
/*  892 */     if (copyResource(req, resp)) {
/*  893 */       deleteResource(path, req, resp, false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doLock(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws ServletException, IOException
/*      */   {
/*  909 */     if (this.readOnly) {
/*  910 */       resp.sendError(403);
/*  911 */       return;
/*      */     }
/*      */     
/*  914 */     if (isLocked(req)) {
/*  915 */       resp.sendError(423);
/*  916 */       return;
/*      */     }
/*      */     
/*  919 */     LockInfo lock = new LockInfo(this.maxDepth);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  925 */     String depthStr = req.getHeader("Depth");
/*      */     
/*  927 */     if (depthStr == null) {
/*  928 */       lock.depth = this.maxDepth;
/*      */     }
/*  930 */     else if (depthStr.equals("0")) {
/*  931 */       lock.depth = 0;
/*      */     } else {
/*  933 */       lock.depth = this.maxDepth;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  939 */     int lockDuration = 3600;
/*  940 */     String lockDurationStr = req.getHeader("Timeout");
/*  941 */     if (lockDurationStr == null) {
/*  942 */       lockDuration = 3600;
/*      */     } else {
/*  944 */       int commaPos = lockDurationStr.indexOf(',');
/*      */       
/*  946 */       if (commaPos != -1) {
/*  947 */         lockDurationStr = lockDurationStr.substring(0, commaPos);
/*      */       }
/*  949 */       if (lockDurationStr.startsWith("Second-")) {
/*  950 */         lockDuration = Integer.parseInt(lockDurationStr.substring(7));
/*      */       }
/*  952 */       else if (lockDurationStr.equalsIgnoreCase("infinity")) {
/*  953 */         lockDuration = 604800;
/*      */       } else {
/*      */         try {
/*  956 */           lockDuration = Integer.parseInt(lockDurationStr);
/*      */         } catch (NumberFormatException e) {
/*  958 */           lockDuration = 604800;
/*      */         }
/*      */       }
/*      */       
/*  962 */       if (lockDuration == 0) {
/*  963 */         lockDuration = 3600;
/*      */       }
/*  965 */       if (lockDuration > 604800) {
/*  966 */         lockDuration = 604800;
/*      */       }
/*      */     }
/*  969 */     lock.expiresAt = (System.currentTimeMillis() + lockDuration * 1000);
/*      */     
/*  971 */     int lockRequestType = 0;
/*      */     
/*  973 */     Node lockInfoNode = null;
/*      */     
/*  975 */     DocumentBuilder documentBuilder = getDocumentBuilder();
/*      */     try
/*      */     {
/*  978 */       Document document = documentBuilder.parse(new InputSource(req
/*  979 */         .getInputStream()));
/*      */       
/*      */ 
/*  982 */       Element rootElement = document.getDocumentElement();
/*  983 */       lockInfoNode = rootElement;
/*      */     } catch (IOException|SAXException e) {
/*  985 */       lockRequestType = 1;
/*      */     }
/*      */     
/*  988 */     if (lockInfoNode != null)
/*      */     {
/*      */ 
/*      */ 
/*  992 */       NodeList childList = lockInfoNode.getChildNodes();
/*  993 */       StringWriter strWriter = null;
/*  994 */       DOMWriter domWriter = null;
/*      */       
/*  996 */       Node lockScopeNode = null;
/*  997 */       Node lockTypeNode = null;
/*  998 */       Node lockOwnerNode = null;
/*      */       
/* 1000 */       for (int i = 0; i < childList.getLength(); i++) {
/* 1001 */         Node currentNode = childList.item(i);
/* 1002 */         switch (currentNode.getNodeType()) {
/*      */         case 3: 
/*      */           break;
/*      */         case 1: 
/* 1006 */           String nodeName = currentNode.getNodeName();
/* 1007 */           if (nodeName.endsWith("lockscope")) {
/* 1008 */             lockScopeNode = currentNode;
/*      */           }
/* 1010 */           if (nodeName.endsWith("locktype")) {
/* 1011 */             lockTypeNode = currentNode;
/*      */           }
/* 1013 */           if (nodeName.endsWith("owner")) {
/* 1014 */             lockOwnerNode = currentNode;
/*      */           }
/*      */           break;
/*      */         }
/*      */         
/*      */       }
/* 1020 */       if (lockScopeNode != null)
/*      */       {
/* 1022 */         childList = lockScopeNode.getChildNodes();
/* 1023 */         for (int i = 0; i < childList.getLength(); i++) {
/* 1024 */           Node currentNode = childList.item(i);
/* 1025 */           switch (currentNode.getNodeType()) {
/*      */           case 3: 
/*      */             break;
/*      */           case 1: 
/* 1029 */             String tempScope = currentNode.getNodeName();
/* 1030 */             if (tempScope.indexOf(':') != -1)
/*      */             {
/* 1032 */               lock.scope = tempScope.substring(tempScope.indexOf(':') + 1);
/*      */             } else {
/* 1034 */               lock.scope = tempScope;
/*      */             }
/*      */             break;
/*      */           }
/*      */           
/*      */         }
/* 1040 */         if (lock.scope == null)
/*      */         {
/* 1042 */           resp.setStatus(400);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1047 */         resp.setStatus(400);
/*      */       }
/*      */       
/* 1050 */       if (lockTypeNode != null)
/*      */       {
/* 1052 */         childList = lockTypeNode.getChildNodes();
/* 1053 */         for (int i = 0; i < childList.getLength(); i++) {
/* 1054 */           Node currentNode = childList.item(i);
/* 1055 */           switch (currentNode.getNodeType()) {
/*      */           case 3: 
/*      */             break;
/*      */           case 1: 
/* 1059 */             String tempType = currentNode.getNodeName();
/* 1060 */             if (tempType.indexOf(':') != -1)
/*      */             {
/* 1062 */               lock.type = tempType.substring(tempType.indexOf(':') + 1);
/*      */             } else {
/* 1064 */               lock.type = tempType;
/*      */             }
/*      */             break;
/*      */           }
/*      */           
/*      */         }
/* 1070 */         if (lock.type == null)
/*      */         {
/* 1072 */           resp.setStatus(400);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1077 */         resp.setStatus(400);
/*      */       }
/*      */       
/* 1080 */       if (lockOwnerNode != null)
/*      */       {
/* 1082 */         childList = lockOwnerNode.getChildNodes();
/* 1083 */         for (int i = 0; i < childList.getLength(); i++) {
/* 1084 */           Node currentNode = childList.item(i);
/* 1085 */           switch (currentNode.getNodeType()) {
/*      */           case 3: 
/* 1087 */             lock.owner += currentNode.getNodeValue();
/* 1088 */             break;
/*      */           case 1: 
/* 1090 */             strWriter = new StringWriter();
/* 1091 */             domWriter = new DOMWriter(strWriter);
/* 1092 */             domWriter.print(currentNode);
/* 1093 */             lock.owner += strWriter.toString();
/*      */           }
/*      */           
/*      */         }
/*      */         
/* 1098 */         if (lock.owner == null)
/*      */         {
/* 1100 */           resp.setStatus(400);
/*      */         }
/*      */       }
/*      */       else {
/* 1104 */         lock.owner = "";
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1109 */     String path = getRelativePath(req);
/*      */     
/* 1111 */     lock.path = path;
/*      */     
/* 1113 */     WebResource resource = this.resources.getResource(path);
/*      */     
/* 1115 */     Enumeration<LockInfo> locksList = null;
/*      */     
/* 1117 */     if (lockRequestType == 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1123 */       String lockTokenStr = req.getServletPath() + "-" + lock.type + "-" + lock.scope + "-" + req.getUserPrincipal() + "-" + lock.depth + "-" + lock.owner + "-" + lock.tokens + "-" + lock.expiresAt + "-" + System.currentTimeMillis() + "-" + this.secret;
/*      */       
/* 1125 */       String lockToken = MD5Encoder.encode(ConcurrentMessageDigest.digestMD5(new byte[][] {lockTokenStr
/* 1126 */         .getBytes(StandardCharsets.ISO_8859_1) }));
/*      */       
/* 1128 */       if ((resource.isDirectory()) && (lock.depth == this.maxDepth))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1134 */         Vector<String> lockPaths = new Vector();
/* 1135 */         locksList = this.collectionLocks.elements();
/* 1136 */         while (locksList.hasMoreElements()) {
/* 1137 */           LockInfo currentLock = (LockInfo)locksList.nextElement();
/* 1138 */           if (currentLock.hasExpired()) {
/* 1139 */             this.resourceLocks.remove(currentLock.path);
/*      */ 
/*      */           }
/* 1142 */           else if ((currentLock.path.startsWith(lock.path)) && (
/* 1143 */             (currentLock.isExclusive()) || 
/* 1144 */             (lock.isExclusive())))
/*      */           {
/* 1146 */             lockPaths.addElement(currentLock.path);
/*      */           }
/*      */         }
/* 1149 */         locksList = this.resourceLocks.elements();
/* 1150 */         while (locksList.hasMoreElements()) {
/* 1151 */           LockInfo currentLock = (LockInfo)locksList.nextElement();
/* 1152 */           if (currentLock.hasExpired()) {
/* 1153 */             this.resourceLocks.remove(currentLock.path);
/*      */ 
/*      */           }
/* 1156 */           else if ((currentLock.path.startsWith(lock.path)) && (
/* 1157 */             (currentLock.isExclusive()) || 
/* 1158 */             (lock.isExclusive())))
/*      */           {
/* 1160 */             lockPaths.addElement(currentLock.path);
/*      */           }
/*      */         }
/*      */         
/* 1164 */         if (!lockPaths.isEmpty())
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1169 */           Enumeration<String> lockPathsList = lockPaths.elements();
/*      */           
/* 1171 */           resp.setStatus(409);
/*      */           
/* 1173 */           XMLWriter generatedXML = new XMLWriter();
/* 1174 */           generatedXML.writeXMLHeader();
/*      */           
/* 1176 */           generatedXML.writeElement("D", "DAV:", "multistatus", 0);
/*      */           
/*      */ 
/* 1179 */           while (lockPathsList.hasMoreElements()) {
/* 1180 */             generatedXML.writeElement("D", "response", 0);
/*      */             
/* 1182 */             generatedXML.writeElement("D", "href", 0);
/*      */             
/* 1184 */             generatedXML.writeText((String)lockPathsList.nextElement());
/* 1185 */             generatedXML.writeElement("D", "href", 1);
/*      */             
/* 1187 */             generatedXML.writeElement("D", "status", 0);
/*      */             
/* 1189 */             generatedXML
/* 1190 */               .writeText("HTTP/1.1 423 ");
/*      */             
/* 1192 */             generatedXML.writeElement("D", "status", 1);
/*      */             
/*      */ 
/* 1195 */             generatedXML.writeElement("D", "response", 1);
/*      */           }
/*      */           
/*      */ 
/* 1199 */           generatedXML.writeElement("D", "multistatus", 1);
/*      */           
/*      */ 
/* 1202 */           Writer writer = resp.getWriter();
/* 1203 */           writer.write(generatedXML.toString());
/* 1204 */           writer.close();
/*      */           
/* 1206 */           return;
/*      */         }
/*      */         
/*      */ 
/* 1210 */         boolean addLock = true;
/*      */         
/*      */ 
/* 1213 */         locksList = this.collectionLocks.elements();
/* 1214 */         while (locksList.hasMoreElements())
/*      */         {
/* 1216 */           LockInfo currentLock = (LockInfo)locksList.nextElement();
/* 1217 */           if (currentLock.path.equals(lock.path))
/*      */           {
/* 1219 */             if (currentLock.isExclusive()) {
/* 1220 */               resp.sendError(423);
/* 1221 */               return;
/*      */             }
/* 1223 */             if (lock.isExclusive()) {
/* 1224 */               resp.sendError(423);
/* 1225 */               return;
/*      */             }
/*      */             
/*      */ 
/* 1229 */             currentLock.tokens.addElement(lockToken);
/* 1230 */             lock = currentLock;
/* 1231 */             addLock = false;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1237 */         if (addLock) {
/* 1238 */           lock.tokens.addElement(lockToken);
/* 1239 */           this.collectionLocks.addElement(lock);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1247 */         LockInfo presentLock = (LockInfo)this.resourceLocks.get(lock.path);
/* 1248 */         if (presentLock != null)
/*      */         {
/* 1250 */           if ((presentLock.isExclusive()) || (lock.isExclusive()))
/*      */           {
/*      */ 
/* 1253 */             resp.sendError(412);
/* 1254 */             return;
/*      */           }
/* 1256 */           presentLock.tokens.addElement(lockToken);
/* 1257 */           lock = presentLock;
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1262 */           lock.tokens.addElement(lockToken);
/* 1263 */           this.resourceLocks.put(lock.path, lock);
/*      */           
/*      */ 
/* 1266 */           if (!resource.exists())
/*      */           {
/*      */ 
/* 1269 */             int slash = lock.path.lastIndexOf('/');
/* 1270 */             String parentPath = lock.path.substring(0, slash);
/*      */             
/*      */ 
/* 1273 */             Vector<String> lockNulls = (Vector)this.lockNullResources.get(parentPath);
/* 1274 */             if (lockNulls == null) {
/* 1275 */               lockNulls = new Vector();
/* 1276 */               this.lockNullResources.put(parentPath, lockNulls);
/*      */             }
/*      */             
/* 1279 */             lockNulls.addElement(lock.path);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1284 */           resp.addHeader("Lock-Token", "<opaquelocktoken:" + lockToken + ">");
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1292 */     if (lockRequestType == 1)
/*      */     {
/* 1294 */       String ifHeader = req.getHeader("If");
/* 1295 */       if (ifHeader == null) {
/* 1296 */         ifHeader = "";
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1301 */       LockInfo toRenew = (LockInfo)this.resourceLocks.get(path);
/* 1302 */       Enumeration<String> tokenList = null;
/*      */       
/* 1304 */       if (toRenew != null)
/*      */       {
/* 1306 */         tokenList = toRenew.tokens.elements();
/* 1307 */         while (tokenList.hasMoreElements()) {
/* 1308 */           String token = (String)tokenList.nextElement();
/* 1309 */           if (ifHeader.contains(token)) {
/* 1310 */             toRenew.expiresAt = lock.expiresAt;
/* 1311 */             lock = toRenew;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1319 */       Enumeration<LockInfo> collectionLocksList = this.collectionLocks.elements();
/* 1320 */       while (collectionLocksList.hasMoreElements()) {
/* 1321 */         toRenew = (LockInfo)collectionLocksList.nextElement();
/* 1322 */         if (path.equals(toRenew.path))
/*      */         {
/* 1324 */           tokenList = toRenew.tokens.elements();
/* 1325 */           while (tokenList.hasMoreElements()) {
/* 1326 */             String token = (String)tokenList.nextElement();
/* 1327 */             if (ifHeader.contains(token)) {
/* 1328 */               toRenew.expiresAt = lock.expiresAt;
/* 1329 */               lock = toRenew;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1340 */     XMLWriter generatedXML = new XMLWriter();
/* 1341 */     generatedXML.writeXMLHeader();
/* 1342 */     generatedXML.writeElement("D", "DAV:", "prop", 0);
/*      */     
/*      */ 
/* 1345 */     generatedXML.writeElement("D", "lockdiscovery", 0);
/*      */     
/* 1347 */     lock.toXML(generatedXML);
/*      */     
/* 1349 */     generatedXML.writeElement("D", "lockdiscovery", 1);
/*      */     
/* 1351 */     generatedXML.writeElement("D", "prop", 1);
/*      */     
/* 1353 */     resp.setStatus(200);
/* 1354 */     resp.setContentType("text/xml; charset=UTF-8");
/* 1355 */     Writer writer = resp.getWriter();
/* 1356 */     writer.write(generatedXML.toString());
/* 1357 */     writer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void doUnlock(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/* 1371 */     if (this.readOnly) {
/* 1372 */       resp.sendError(403);
/* 1373 */       return;
/*      */     }
/*      */     
/* 1376 */     if (isLocked(req)) {
/* 1377 */       resp.sendError(423);
/* 1378 */       return;
/*      */     }
/*      */     
/* 1381 */     String path = getRelativePath(req);
/*      */     
/* 1383 */     String lockTokenHeader = req.getHeader("Lock-Token");
/* 1384 */     if (lockTokenHeader == null) {
/* 1385 */       lockTokenHeader = "";
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1390 */     LockInfo lock = (LockInfo)this.resourceLocks.get(path);
/* 1391 */     Enumeration<String> tokenList = null;
/* 1392 */     if (lock != null)
/*      */     {
/*      */ 
/*      */ 
/* 1396 */       tokenList = lock.tokens.elements();
/* 1397 */       while (tokenList.hasMoreElements()) {
/* 1398 */         String token = (String)tokenList.nextElement();
/* 1399 */         if (lockTokenHeader.contains(token)) {
/* 1400 */           lock.tokens.removeElement(token);
/*      */         }
/*      */       }
/*      */       
/* 1404 */       if (lock.tokens.isEmpty()) {
/* 1405 */         this.resourceLocks.remove(path);
/*      */         
/* 1407 */         this.lockNullResources.remove(path);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1414 */     Enumeration<LockInfo> collectionLocksList = this.collectionLocks.elements();
/* 1415 */     while (collectionLocksList.hasMoreElements()) {
/* 1416 */       lock = (LockInfo)collectionLocksList.nextElement();
/* 1417 */       if (path.equals(lock.path))
/*      */       {
/* 1419 */         tokenList = lock.tokens.elements();
/* 1420 */         while (tokenList.hasMoreElements()) {
/* 1421 */           String token = (String)tokenList.nextElement();
/* 1422 */           if (lockTokenHeader.contains(token)) {
/* 1423 */             lock.tokens.removeElement(token);
/* 1424 */             break;
/*      */           }
/*      */         }
/*      */         
/* 1428 */         if (lock.tokens.isEmpty()) {
/* 1429 */           this.collectionLocks.removeElement(lock);
/*      */           
/* 1431 */           this.lockNullResources.remove(path);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1437 */     resp.setStatus(204);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isLocked(HttpServletRequest req)
/*      */   {
/* 1455 */     String path = getRelativePath(req);
/*      */     
/* 1457 */     String ifHeader = req.getHeader("If");
/* 1458 */     if (ifHeader == null) {
/* 1459 */       ifHeader = "";
/*      */     }
/*      */     
/* 1462 */     String lockTokenHeader = req.getHeader("Lock-Token");
/* 1463 */     if (lockTokenHeader == null) {
/* 1464 */       lockTokenHeader = "";
/*      */     }
/*      */     
/* 1467 */     return isLocked(path, ifHeader + lockTokenHeader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isLocked(String path, String ifHeader)
/*      */   {
/* 1485 */     LockInfo lock = (LockInfo)this.resourceLocks.get(path);
/* 1486 */     Enumeration<String> tokenList = null;
/* 1487 */     if ((lock != null) && (lock.hasExpired())) {
/* 1488 */       this.resourceLocks.remove(path);
/* 1489 */     } else if (lock != null)
/*      */     {
/*      */ 
/*      */ 
/* 1493 */       tokenList = lock.tokens.elements();
/* 1494 */       boolean tokenMatch = false;
/* 1495 */       while (tokenList.hasMoreElements()) {
/* 1496 */         String token = (String)tokenList.nextElement();
/* 1497 */         if (ifHeader.contains(token)) {
/* 1498 */           tokenMatch = true;
/* 1499 */           break;
/*      */         }
/*      */       }
/* 1502 */       if (!tokenMatch) {
/* 1503 */         return true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1510 */     Enumeration<LockInfo> collectionLocksList = this.collectionLocks.elements();
/* 1511 */     while (collectionLocksList.hasMoreElements()) {
/* 1512 */       lock = (LockInfo)collectionLocksList.nextElement();
/* 1513 */       if (lock.hasExpired()) {
/* 1514 */         this.collectionLocks.removeElement(lock);
/* 1515 */       } else if (path.startsWith(lock.path))
/*      */       {
/* 1517 */         tokenList = lock.tokens.elements();
/* 1518 */         boolean tokenMatch = false;
/* 1519 */         while (tokenList.hasMoreElements()) {
/* 1520 */           String token = (String)tokenList.nextElement();
/* 1521 */           if (ifHeader.contains(token)) {
/* 1522 */             tokenMatch = true;
/* 1523 */             break;
/*      */           }
/*      */         }
/* 1526 */         if (!tokenMatch) {
/* 1527 */           return true;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1533 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean copyResource(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/* 1552 */     String destinationPath = req.getHeader("Destination");
/*      */     
/* 1554 */     if (destinationPath == null) {
/* 1555 */       resp.sendError(400);
/* 1556 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1560 */     destinationPath = UDecoder.URLDecode(destinationPath, StandardCharsets.UTF_8);
/*      */     
/* 1562 */     int protocolIndex = destinationPath.indexOf("://");
/* 1563 */     if (protocolIndex >= 0)
/*      */     {
/*      */ 
/*      */ 
/* 1567 */       int firstSeparator = destinationPath.indexOf('/', protocolIndex + 4);
/* 1568 */       if (firstSeparator < 0) {
/* 1569 */         destinationPath = "/";
/*      */       } else {
/* 1571 */         destinationPath = destinationPath.substring(firstSeparator);
/*      */       }
/*      */     } else {
/* 1574 */       String hostName = req.getServerName();
/* 1575 */       if ((hostName != null) && (destinationPath.startsWith(hostName))) {
/* 1576 */         destinationPath = destinationPath.substring(hostName.length());
/*      */       }
/*      */       
/* 1579 */       int portIndex = destinationPath.indexOf(':');
/* 1580 */       if (portIndex >= 0) {
/* 1581 */         destinationPath = destinationPath.substring(portIndex);
/*      */       }
/*      */       
/* 1584 */       if (destinationPath.startsWith(":")) {
/* 1585 */         int firstSeparator = destinationPath.indexOf('/');
/* 1586 */         if (firstSeparator < 0) {
/* 1587 */           destinationPath = "/";
/*      */         }
/*      */         else {
/* 1590 */           destinationPath = destinationPath.substring(firstSeparator);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1596 */     destinationPath = RequestUtil.normalize(destinationPath);
/*      */     
/* 1598 */     String contextPath = req.getContextPath();
/* 1599 */     if ((contextPath != null) && 
/* 1600 */       (destinationPath.startsWith(contextPath))) {
/* 1601 */       destinationPath = destinationPath.substring(contextPath.length());
/*      */     }
/*      */     
/* 1604 */     String pathInfo = req.getPathInfo();
/* 1605 */     if (pathInfo != null) {
/* 1606 */       String servletPath = req.getServletPath();
/* 1607 */       if ((servletPath != null) && 
/* 1608 */         (destinationPath.startsWith(servletPath)))
/*      */       {
/* 1610 */         destinationPath = destinationPath.substring(servletPath.length());
/*      */       }
/*      */     }
/*      */     
/* 1614 */     if (this.debug > 0) {
/* 1615 */       log("Dest path :" + destinationPath);
/*      */     }
/*      */     
/*      */ 
/* 1619 */     if (isSpecialPath(destinationPath)) {
/* 1620 */       resp.sendError(403);
/* 1621 */       return false;
/*      */     }
/*      */     
/* 1624 */     String path = getRelativePath(req);
/*      */     
/* 1626 */     if (destinationPath.equals(path)) {
/* 1627 */       resp.sendError(403);
/* 1628 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1633 */     boolean overwrite = true;
/* 1634 */     String overwriteHeader = req.getHeader("Overwrite");
/*      */     
/* 1636 */     if (overwriteHeader != null) {
/* 1637 */       if (overwriteHeader.equalsIgnoreCase("T")) {
/* 1638 */         overwrite = true;
/*      */       } else {
/* 1640 */         overwrite = false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1646 */     WebResource destination = this.resources.getResource(destinationPath);
/*      */     
/* 1648 */     if (overwrite)
/*      */     {
/* 1650 */       if (destination.exists()) {
/* 1651 */         if (!deleteResource(destinationPath, req, resp, true)) {
/* 1652 */           return false;
/*      */         }
/*      */       } else {
/* 1655 */         resp.setStatus(201);
/*      */       }
/*      */       
/*      */     }
/* 1659 */     else if (destination.exists()) {
/* 1660 */       resp.sendError(412);
/* 1661 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1667 */     Hashtable<String, Integer> errorList = new Hashtable();
/*      */     
/* 1669 */     boolean result = copyResource(errorList, path, destinationPath);
/*      */     
/* 1671 */     if ((!result) || (!errorList.isEmpty())) {
/* 1672 */       if (errorList.size() == 1) {
/* 1673 */         resp.sendError(((Integer)errorList.elements().nextElement()).intValue());
/*      */       } else {
/* 1675 */         sendReport(req, resp, errorList);
/*      */       }
/* 1677 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1681 */     if (destination.exists()) {
/* 1682 */       resp.setStatus(204);
/*      */     } else {
/* 1684 */       resp.setStatus(201);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1689 */     this.lockNullResources.remove(destinationPath);
/*      */     
/* 1691 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean copyResource(Hashtable<String, Integer> errorList, String source, String dest)
/*      */   {
/* 1707 */     if (this.debug > 1) {
/* 1708 */       log("Copy: " + source + " To: " + dest);
/*      */     }
/*      */     
/* 1711 */     WebResource sourceResource = this.resources.getResource(source);
/*      */     
/* 1713 */     if (sourceResource.isDirectory()) {
/* 1714 */       if (!this.resources.mkdir(dest)) {
/* 1715 */         WebResource destResource = this.resources.getResource(dest);
/* 1716 */         if (!destResource.isDirectory()) {
/* 1717 */           errorList.put(dest, Integer.valueOf(409));
/* 1718 */           return false;
/*      */         }
/*      */       }
/*      */       
/* 1722 */       String[] entries = this.resources.list(source);
/* 1723 */       for (String entry : entries) {
/* 1724 */         String childDest = dest;
/* 1725 */         if (!childDest.equals("/")) {
/* 1726 */           childDest = childDest + "/";
/*      */         }
/* 1728 */         childDest = childDest + entry;
/* 1729 */         String childSrc = source;
/* 1730 */         if (!childSrc.equals("/")) {
/* 1731 */           childSrc = childSrc + "/";
/*      */         }
/* 1733 */         childSrc = childSrc + entry;
/* 1734 */         copyResource(errorList, childSrc, childDest);
/*      */       }
/* 1736 */     } else if (sourceResource.isFile()) {
/* 1737 */       WebResource destResource = this.resources.getResource(dest);
/* 1738 */       Object parent; WebResource parentResource; if ((!destResource.exists()) && (!destResource.getWebappPath().endsWith("/"))) {
/* 1739 */         int lastSlash = destResource.getWebappPath().lastIndexOf('/');
/* 1740 */         if (lastSlash > 0) {
/* 1741 */           parent = destResource.getWebappPath().substring(0, lastSlash);
/* 1742 */           parentResource = this.resources.getResource((String)parent);
/* 1743 */           if (!parentResource.isDirectory()) {
/* 1744 */             errorList.put(source, Integer.valueOf(409));
/* 1745 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1751 */       if ((!destResource.exists()) && (dest.endsWith("/")) && (dest.length() > 1))
/*      */       {
/*      */ 
/* 1754 */         dest = dest.substring(0, dest.length() - 1); }
/*      */       try {
/* 1756 */         InputStream is = sourceResource.getInputStream();parent = null;
/* 1757 */         try { if (!this.resources.write(dest, is, false)) {
/* 1758 */             errorList.put(source, Integer.valueOf(500));
/* 1759 */             return false;
/*      */           }
/*      */         }
/*      */         catch (Throwable localThrowable5)
/*      */         {
/* 1756 */           parent = localThrowable5;throw localThrowable5;
/*      */ 
/*      */         }
/*      */         finally
/*      */         {
/* 1761 */           if (is != null) if (parent != null) try { is.close(); } catch (Throwable localThrowable3) { ((Throwable)parent).addSuppressed(localThrowable3); } else is.close();
/* 1762 */         } } catch (IOException e) { log(sm.getString("webdavservlet.inputstreamclosefail", new Object[] { source }), e);
/*      */       }
/*      */     } else {
/* 1765 */       errorList.put(source, Integer.valueOf(500));
/* 1766 */       return false;
/*      */     }
/* 1768 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean deleteResource(HttpServletRequest req, HttpServletResponse resp)
/*      */     throws IOException
/*      */   {
/* 1784 */     String path = getRelativePath(req);
/*      */     
/* 1786 */     return deleteResource(path, req, resp, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean deleteResource(String path, HttpServletRequest req, HttpServletResponse resp, boolean setStatus)
/*      */     throws IOException
/*      */   {
/* 1806 */     String ifHeader = req.getHeader("If");
/* 1807 */     if (ifHeader == null) {
/* 1808 */       ifHeader = "";
/*      */     }
/*      */     
/* 1811 */     String lockTokenHeader = req.getHeader("Lock-Token");
/* 1812 */     if (lockTokenHeader == null) {
/* 1813 */       lockTokenHeader = "";
/*      */     }
/*      */     
/* 1816 */     if (isLocked(path, ifHeader + lockTokenHeader)) {
/* 1817 */       resp.sendError(423);
/* 1818 */       return false;
/*      */     }
/*      */     
/* 1821 */     WebResource resource = this.resources.getResource(path);
/*      */     
/* 1823 */     if (!resource.exists()) {
/* 1824 */       resp.sendError(404);
/* 1825 */       return false;
/*      */     }
/*      */     
/* 1828 */     if (!resource.isDirectory()) {
/* 1829 */       if (!resource.delete()) {
/* 1830 */         resp.sendError(500);
/* 1831 */         return false;
/*      */       }
/*      */     }
/*      */     else {
/* 1835 */       Hashtable<String, Integer> errorList = new Hashtable();
/*      */       
/* 1837 */       deleteCollection(req, path, errorList);
/* 1838 */       if (!resource.delete()) {
/* 1839 */         errorList.put(path, 
/* 1840 */           Integer.valueOf(500));
/*      */       }
/*      */       
/* 1843 */       if (!errorList.isEmpty()) {
/* 1844 */         sendReport(req, resp, errorList);
/* 1845 */         return false;
/*      */       }
/*      */     }
/* 1848 */     if (setStatus) {
/* 1849 */       resp.setStatus(204);
/*      */     }
/* 1851 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void deleteCollection(HttpServletRequest req, String path, Hashtable<String, Integer> errorList)
/*      */   {
/* 1865 */     if (this.debug > 1) {
/* 1866 */       log("Delete:" + path);
/*      */     }
/*      */     
/*      */ 
/* 1870 */     if (isSpecialPath(path)) {
/* 1871 */       errorList.put(path, Integer.valueOf(403));
/* 1872 */       return;
/*      */     }
/*      */     
/* 1875 */     String ifHeader = req.getHeader("If");
/* 1876 */     if (ifHeader == null) {
/* 1877 */       ifHeader = "";
/*      */     }
/*      */     
/* 1880 */     String lockTokenHeader = req.getHeader("Lock-Token");
/* 1881 */     if (lockTokenHeader == null) {
/* 1882 */       lockTokenHeader = "";
/*      */     }
/*      */     
/* 1885 */     String[] entries = this.resources.list(path);
/*      */     
/* 1887 */     for (String entry : entries) {
/* 1888 */       String childName = path;
/* 1889 */       if (!childName.equals("/")) {
/* 1890 */         childName = childName + "/";
/*      */       }
/* 1892 */       childName = childName + entry;
/*      */       
/* 1894 */       if (isLocked(childName, ifHeader + lockTokenHeader))
/*      */       {
/* 1896 */         errorList.put(childName, Integer.valueOf(423));
/*      */       }
/*      */       else {
/* 1899 */         WebResource childResource = this.resources.getResource(childName);
/* 1900 */         if (childResource.isDirectory()) {
/* 1901 */           deleteCollection(req, childName, errorList);
/*      */         }
/*      */         
/* 1904 */         if ((!childResource.delete()) && 
/* 1905 */           (!childResource.isDirectory()))
/*      */         {
/*      */ 
/* 1908 */           errorList.put(childName, Integer.valueOf(500));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void sendReport(HttpServletRequest req, HttpServletResponse resp, Hashtable<String, Integer> errorList)
/*      */     throws IOException
/*      */   {
/* 1930 */     resp.setStatus(207);
/*      */     
/* 1932 */     String absoluteUri = req.getRequestURI();
/* 1933 */     String relativePath = getRelativePath(req);
/*      */     
/* 1935 */     XMLWriter generatedXML = new XMLWriter();
/* 1936 */     generatedXML.writeXMLHeader();
/*      */     
/* 1938 */     generatedXML.writeElement("D", "DAV:", "multistatus", 0);
/*      */     
/*      */ 
/* 1941 */     Enumeration<String> pathList = errorList.keys();
/* 1942 */     while (pathList.hasMoreElements())
/*      */     {
/* 1944 */       String errorPath = (String)pathList.nextElement();
/* 1945 */       int errorCode = ((Integer)errorList.get(errorPath)).intValue();
/*      */       
/* 1947 */       generatedXML.writeElement("D", "response", 0);
/*      */       
/* 1949 */       generatedXML.writeElement("D", "href", 0);
/* 1950 */       String toAppend = errorPath.substring(relativePath.length());
/* 1951 */       if (!toAppend.startsWith("/")) {
/* 1952 */         toAppend = "/" + toAppend;
/*      */       }
/* 1954 */       generatedXML.writeText(absoluteUri + toAppend);
/* 1955 */       generatedXML.writeElement("D", "href", 1);
/* 1956 */       generatedXML.writeElement("D", "status", 0);
/* 1957 */       generatedXML.writeText("HTTP/1.1 " + errorCode + " ");
/* 1958 */       generatedXML.writeElement("D", "status", 1);
/*      */       
/* 1960 */       generatedXML.writeElement("D", "response", 1);
/*      */     }
/*      */     
/*      */ 
/* 1964 */     generatedXML.writeElement("D", "multistatus", 1);
/*      */     
/* 1966 */     Writer writer = resp.getWriter();
/* 1967 */     writer.write(generatedXML.toString());
/* 1968 */     writer.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseProperties(HttpServletRequest req, XMLWriter generatedXML, String path, int type, Vector<String> propertiesVector)
/*      */   {
/* 1989 */     if (isSpecialPath(path)) {
/* 1990 */       return;
/*      */     }
/*      */     
/* 1993 */     WebResource resource = this.resources.getResource(path);
/* 1994 */     if (!resource.exists())
/*      */     {
/*      */ 
/* 1997 */       return;
/*      */     }
/*      */     
/* 2000 */     String href = req.getContextPath() + req.getServletPath();
/* 2001 */     if ((href.endsWith("/")) && (path.startsWith("/"))) {
/* 2002 */       href = href + path.substring(1);
/*      */     } else {
/* 2004 */       href = href + path;
/*      */     }
/* 2006 */     if ((resource.isDirectory()) && (!href.endsWith("/"))) {
/* 2007 */       href = href + "/";
/*      */     }
/*      */     
/* 2010 */     String rewrittenUrl = rewriteUrl(href);
/*      */     
/* 2012 */     generatePropFindResponse(generatedXML, rewrittenUrl, path, type, propertiesVector, resource
/* 2013 */       .isFile(), false, resource.getCreation(), resource.getLastModified(), resource
/* 2014 */       .getContentLength(), getServletContext().getMimeType(resource.getName()), 
/* 2015 */       generateETag(resource));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseLockNullProperties(HttpServletRequest req, XMLWriter generatedXML, String path, int type, Vector<String> propertiesVector)
/*      */   {
/* 2035 */     if (isSpecialPath(path)) {
/* 2036 */       return;
/*      */     }
/*      */     
/*      */ 
/* 2040 */     LockInfo lock = (LockInfo)this.resourceLocks.get(path);
/*      */     
/* 2042 */     if (lock == null) {
/* 2043 */       return;
/*      */     }
/*      */     
/* 2046 */     String absoluteUri = req.getRequestURI();
/* 2047 */     String relativePath = getRelativePath(req);
/* 2048 */     String toAppend = path.substring(relativePath.length());
/* 2049 */     if (!toAppend.startsWith("/")) {
/* 2050 */       toAppend = "/" + toAppend;
/*      */     }
/*      */     
/* 2053 */     String rewrittenUrl = rewriteUrl(RequestUtil.normalize(absoluteUri + toAppend));
/*      */     
/*      */ 
/* 2056 */     generatePropFindResponse(generatedXML, rewrittenUrl, path, type, propertiesVector, true, true, lock.creationDate
/* 2057 */       .getTime(), lock.creationDate.getTime(), 0L, "", "");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void generatePropFindResponse(XMLWriter generatedXML, String rewrittenUrl, String path, int propFindType, Vector<String> propertiesVector, boolean isFile, boolean isLockNull, long created, long lastModified, long contentLength, String contentType, String eTag)
/*      */   {
/* 2067 */     generatedXML.writeElement("D", "response", 0);
/* 2068 */     String status = "HTTP/1.1 200 ";
/*      */     
/*      */ 
/* 2071 */     generatedXML.writeElement("D", "href", 0);
/* 2072 */     generatedXML.writeText(rewrittenUrl);
/* 2073 */     generatedXML.writeElement("D", "href", 1);
/*      */     
/* 2075 */     String resourceName = path;
/* 2076 */     int lastSlash = path.lastIndexOf('/');
/* 2077 */     if (lastSlash != -1) {
/* 2078 */       resourceName = resourceName.substring(lastSlash + 1);
/*      */     }
/*      */     
/* 2081 */     switch (propFindType)
/*      */     {
/*      */ 
/*      */     case 1: 
/* 2085 */       generatedXML.writeElement("D", "propstat", 0);
/* 2086 */       generatedXML.writeElement("D", "prop", 0);
/*      */       
/* 2088 */       generatedXML.writeProperty("D", "creationdate", getISOCreationDate(created));
/* 2089 */       generatedXML.writeElement("D", "displayname", 0);
/* 2090 */       generatedXML.writeData(resourceName);
/* 2091 */       generatedXML.writeElement("D", "displayname", 1);
/* 2092 */       if (isFile) {
/* 2093 */         generatedXML.writeProperty("D", "getlastmodified", 
/* 2094 */           FastHttpDateFormat.formatDate(lastModified));
/* 2095 */         generatedXML.writeProperty("D", "getcontentlength", Long.toString(contentLength));
/* 2096 */         if (contentType != null) {
/* 2097 */           generatedXML.writeProperty("D", "getcontenttype", contentType);
/*      */         }
/* 2099 */         generatedXML.writeProperty("D", "getetag", eTag);
/* 2100 */         if (isLockNull) {
/* 2101 */           generatedXML.writeElement("D", "resourcetype", 0);
/* 2102 */           generatedXML.writeElement("D", "lock-null", 2);
/* 2103 */           generatedXML.writeElement("D", "resourcetype", 1);
/*      */         } else {
/* 2105 */           generatedXML.writeElement("D", "resourcetype", 2);
/*      */         }
/*      */       } else {
/* 2108 */         generatedXML.writeProperty("D", "getlastmodified", 
/* 2109 */           FastHttpDateFormat.formatDate(lastModified));
/* 2110 */         generatedXML.writeElement("D", "resourcetype", 0);
/* 2111 */         generatedXML.writeElement("D", "collection", 2);
/* 2112 */         generatedXML.writeElement("D", "resourcetype", 1);
/*      */       }
/*      */       
/* 2115 */       generatedXML.writeProperty("D", "source", "");
/*      */       
/* 2117 */       String supportedLocks = "<D:lockentry><D:lockscope><D:exclusive/></D:lockscope><D:locktype><D:write/></D:locktype></D:lockentry><D:lockentry><D:lockscope><D:shared/></D:lockscope><D:locktype><D:write/></D:locktype></D:lockentry>";
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2124 */       generatedXML.writeElement("D", "supportedlock", 0);
/* 2125 */       generatedXML.writeText(supportedLocks);
/* 2126 */       generatedXML.writeElement("D", "supportedlock", 1);
/*      */       
/* 2128 */       generateLockDiscovery(path, generatedXML);
/*      */       
/* 2130 */       generatedXML.writeElement("D", "prop", 1);
/* 2131 */       generatedXML.writeElement("D", "status", 0);
/* 2132 */       generatedXML.writeText(status);
/* 2133 */       generatedXML.writeElement("D", "status", 1);
/* 2134 */       generatedXML.writeElement("D", "propstat", 1);
/*      */       
/* 2136 */       break;
/*      */     
/*      */ 
/*      */     case 2: 
/* 2140 */       generatedXML.writeElement("D", "propstat", 0);
/* 2141 */       generatedXML.writeElement("D", "prop", 0);
/*      */       
/* 2143 */       generatedXML.writeElement("D", "creationdate", 2);
/* 2144 */       generatedXML.writeElement("D", "displayname", 2);
/* 2145 */       if (isFile) {
/* 2146 */         generatedXML.writeElement("D", "getcontentlanguage", 2);
/* 2147 */         generatedXML.writeElement("D", "getcontentlength", 2);
/* 2148 */         generatedXML.writeElement("D", "getcontenttype", 2);
/* 2149 */         generatedXML.writeElement("D", "getetag", 2);
/* 2150 */         generatedXML.writeElement("D", "getlastmodified", 2);
/*      */       }
/* 2152 */       generatedXML.writeElement("D", "resourcetype", 2);
/* 2153 */       generatedXML.writeElement("D", "source", 2);
/* 2154 */       generatedXML.writeElement("D", "lockdiscovery", 2);
/*      */       
/* 2156 */       generatedXML.writeElement("D", "prop", 1);
/* 2157 */       generatedXML.writeElement("D", "status", 0);
/* 2158 */       generatedXML.writeText(status);
/* 2159 */       generatedXML.writeElement("D", "status", 1);
/* 2160 */       generatedXML.writeElement("D", "propstat", 1);
/*      */       
/* 2162 */       break;
/*      */     
/*      */ 
/*      */     case 0: 
/* 2166 */       Vector<String> propertiesNotFound = new Vector();
/*      */       
/*      */ 
/*      */ 
/* 2170 */       generatedXML.writeElement("D", "propstat", 0);
/* 2171 */       generatedXML.writeElement("D", "prop", 0);
/*      */       
/* 2173 */       Enumeration<String> properties = propertiesVector.elements();
/*      */       
/* 2175 */       while (properties.hasMoreElements())
/*      */       {
/* 2177 */         String property = (String)properties.nextElement();
/*      */         
/* 2179 */         if (property.equals("creationdate")) {
/* 2180 */           generatedXML.writeProperty("D", "creationdate", getISOCreationDate(created));
/* 2181 */         } else if (property.equals("displayname")) {
/* 2182 */           generatedXML.writeElement("D", "displayname", 0);
/* 2183 */           generatedXML.writeData(resourceName);
/* 2184 */           generatedXML.writeElement("D", "displayname", 1);
/* 2185 */         } else if (property.equals("getcontentlanguage")) {
/* 2186 */           if (isFile) {
/* 2187 */             generatedXML.writeElement("D", "getcontentlanguage", 2);
/*      */           }
/*      */           else {
/* 2190 */             propertiesNotFound.addElement(property);
/*      */           }
/* 2192 */         } else if (property.equals("getcontentlength")) {
/* 2193 */           if (isFile) {
/* 2194 */             generatedXML.writeProperty("D", "getcontentlength", 
/* 2195 */               Long.toString(contentLength));
/*      */           } else {
/* 2197 */             propertiesNotFound.addElement(property);
/*      */           }
/* 2199 */         } else if (property.equals("getcontenttype")) {
/* 2200 */           if (isFile) {
/* 2201 */             generatedXML.writeProperty("D", "getcontenttype", contentType);
/*      */           } else {
/* 2203 */             propertiesNotFound.addElement(property);
/*      */           }
/* 2205 */         } else if (property.equals("getetag")) {
/* 2206 */           if (isFile) {
/* 2207 */             generatedXML.writeProperty("D", "getetag", eTag);
/*      */           } else {
/* 2209 */             propertiesNotFound.addElement(property);
/*      */           }
/* 2211 */         } else if (property.equals("getlastmodified")) {
/* 2212 */           if (isFile) {
/* 2213 */             generatedXML.writeProperty("D", "getlastmodified", 
/* 2214 */               FastHttpDateFormat.formatDate(lastModified));
/*      */           } else {
/* 2216 */             propertiesNotFound.addElement(property);
/*      */           }
/* 2218 */         } else if (property.equals("resourcetype")) {
/* 2219 */           if (isFile) {
/* 2220 */             if (isLockNull) {
/* 2221 */               generatedXML.writeElement("D", "resourcetype", 0);
/* 2222 */               generatedXML.writeElement("D", "lock-null", 2);
/* 2223 */               generatedXML.writeElement("D", "resourcetype", 1);
/*      */             } else {
/* 2225 */               generatedXML.writeElement("D", "resourcetype", 2);
/*      */             }
/*      */           } else {
/* 2228 */             generatedXML.writeElement("D", "resourcetype", 0);
/* 2229 */             generatedXML.writeElement("D", "collection", 2);
/* 2230 */             generatedXML.writeElement("D", "resourcetype", 1);
/*      */           }
/* 2232 */         } else if (property.equals("source")) {
/* 2233 */           generatedXML.writeProperty("D", "source", "");
/* 2234 */         } else if (property.equals("supportedlock")) {
/* 2235 */           String supportedLocks = "<D:lockentry><D:lockscope><D:exclusive/></D:lockscope><D:locktype><D:write/></D:locktype></D:lockentry><D:lockentry><D:lockscope><D:shared/></D:lockscope><D:locktype><D:write/></D:locktype></D:lockentry>";
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2242 */           generatedXML.writeElement("D", "supportedlock", 0);
/* 2243 */           generatedXML.writeText(supportedLocks);
/* 2244 */           generatedXML.writeElement("D", "supportedlock", 1);
/* 2245 */         } else if (property.equals("lockdiscovery")) {
/* 2246 */           if (!generateLockDiscovery(path, generatedXML)) {
/* 2247 */             propertiesNotFound.addElement(property);
/*      */           }
/*      */         } else {
/* 2250 */           propertiesNotFound.addElement(property);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 2255 */       generatedXML.writeElement("D", "prop", 1);
/* 2256 */       generatedXML.writeElement("D", "status", 0);
/* 2257 */       generatedXML.writeText(status);
/* 2258 */       generatedXML.writeElement("D", "status", 1);
/* 2259 */       generatedXML.writeElement("D", "propstat", 1);
/*      */       
/* 2261 */       Enumeration<String> propertiesNotFoundList = propertiesNotFound.elements();
/*      */       
/* 2263 */       if (propertiesNotFoundList.hasMoreElements())
/*      */       {
/* 2265 */         status = "HTTP/1.1 404 ";
/*      */         
/* 2267 */         generatedXML.writeElement("D", "propstat", 0);
/* 2268 */         generatedXML.writeElement("D", "prop", 0);
/*      */         
/* 2270 */         while (propertiesNotFoundList.hasMoreElements()) {
/* 2271 */           generatedXML.writeElement("D", (String)propertiesNotFoundList.nextElement(), 2);
/*      */         }
/*      */         
/*      */ 
/* 2275 */         generatedXML.writeElement("D", "prop", 1);
/* 2276 */         generatedXML.writeElement("D", "status", 0);
/* 2277 */         generatedXML.writeText(status);
/* 2278 */         generatedXML.writeElement("D", "status", 1);
/* 2279 */         generatedXML.writeElement("D", "propstat", 1);
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     }
/*      */     
/*      */     
/* 2287 */     generatedXML.writeElement("D", "response", 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean generateLockDiscovery(String path, XMLWriter generatedXML)
/*      */   {
/* 2301 */     LockInfo resourceLock = (LockInfo)this.resourceLocks.get(path);
/* 2302 */     Enumeration<LockInfo> collectionLocksList = this.collectionLocks.elements();
/*      */     
/* 2304 */     boolean wroteStart = false;
/*      */     
/* 2306 */     if (resourceLock != null) {
/* 2307 */       wroteStart = true;
/* 2308 */       generatedXML.writeElement("D", "lockdiscovery", 0);
/* 2309 */       resourceLock.toXML(generatedXML);
/*      */     }
/*      */     
/* 2312 */     while (collectionLocksList.hasMoreElements()) {
/* 2313 */       LockInfo currentLock = (LockInfo)collectionLocksList.nextElement();
/* 2314 */       if (path.startsWith(currentLock.path)) {
/* 2315 */         if (!wroteStart) {
/* 2316 */           wroteStart = true;
/* 2317 */           generatedXML.writeElement("D", "lockdiscovery", 0);
/*      */         }
/*      */         
/* 2320 */         currentLock.toXML(generatedXML);
/*      */       }
/*      */     }
/*      */     
/* 2324 */     if (wroteStart) {
/* 2325 */       generatedXML.writeElement("D", "lockdiscovery", 1);
/*      */     } else {
/* 2327 */       return false;
/*      */     }
/*      */     
/* 2330 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getISOCreationDate(long creationDate)
/*      */   {
/* 2340 */     return creationDateFormat.format(new Date(creationDate));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String determineMethodsAllowed(HttpServletRequest req)
/*      */   {
/* 2354 */     WebResource resource = this.resources.getResource(getRelativePath(req));
/*      */     
/*      */ 
/*      */ 
/* 2358 */     StringBuilder methodsAllowed = new StringBuilder("OPTIONS, GET, POST, HEAD");
/*      */     
/*      */ 
/* 2361 */     if (!this.readOnly) {
/* 2362 */       methodsAllowed.append(", DELETE");
/* 2363 */       if (!resource.isDirectory()) {
/* 2364 */         methodsAllowed.append(", PUT");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2369 */     if (((req instanceof RequestFacade)) && 
/* 2370 */       (((RequestFacade)req).getAllowTrace())) {
/* 2371 */       methodsAllowed.append(", TRACE");
/*      */     }
/*      */     
/* 2374 */     methodsAllowed.append(", LOCK, UNLOCK, PROPPATCH, COPY, MOVE");
/*      */     
/* 2376 */     if (this.listings) {
/* 2377 */       methodsAllowed.append(", PROPFIND");
/*      */     }
/*      */     
/* 2380 */     if (!resource.exists()) {
/* 2381 */       methodsAllowed.append(", MKCOL");
/*      */     }
/*      */     
/* 2384 */     return methodsAllowed.toString();
/*      */   }
/*      */   
/*      */ 
/*      */   private static class LockInfo
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */     private final int maxDepth;
/*      */     
/*      */ 
/*      */     public LockInfo(int maxDepth)
/*      */     {
/* 2398 */       this.maxDepth = maxDepth;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2406 */     String path = "/";
/* 2407 */     String type = "write";
/* 2408 */     String scope = "exclusive";
/* 2409 */     int depth = 0;
/* 2410 */     String owner = "";
/* 2411 */     Vector<String> tokens = new Vector();
/* 2412 */     long expiresAt = 0L;
/* 2413 */     Date creationDate = new Date();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String toString()
/*      */     {
/* 2424 */       StringBuilder result = new StringBuilder("Type:");
/* 2425 */       result.append(this.type);
/* 2426 */       result.append("\nScope:");
/* 2427 */       result.append(this.scope);
/* 2428 */       result.append("\nDepth:");
/* 2429 */       result.append(this.depth);
/* 2430 */       result.append("\nOwner:");
/* 2431 */       result.append(this.owner);
/* 2432 */       result.append("\nExpiration:");
/* 2433 */       result.append(FastHttpDateFormat.formatDate(this.expiresAt));
/* 2434 */       Enumeration<String> tokensList = this.tokens.elements();
/* 2435 */       while (tokensList.hasMoreElements()) {
/* 2436 */         result.append("\nToken:");
/* 2437 */         result.append((String)tokensList.nextElement());
/*      */       }
/* 2439 */       result.append("\n");
/* 2440 */       return result.toString();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean hasExpired()
/*      */     {
/* 2448 */       return System.currentTimeMillis() > this.expiresAt;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isExclusive()
/*      */     {
/* 2456 */       return this.scope.equals("exclusive");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void toXML(XMLWriter generatedXML)
/*      */     {
/* 2468 */       generatedXML.writeElement("D", "activelock", 0);
/*      */       
/* 2470 */       generatedXML.writeElement("D", "locktype", 0);
/* 2471 */       generatedXML.writeElement("D", this.type, 2);
/* 2472 */       generatedXML.writeElement("D", "locktype", 1);
/*      */       
/* 2474 */       generatedXML.writeElement("D", "lockscope", 0);
/* 2475 */       generatedXML.writeElement("D", this.scope, 2);
/* 2476 */       generatedXML.writeElement("D", "lockscope", 1);
/*      */       
/* 2478 */       generatedXML.writeElement("D", "depth", 0);
/* 2479 */       if (this.depth == this.maxDepth) {
/* 2480 */         generatedXML.writeText("Infinity");
/*      */       } else {
/* 2482 */         generatedXML.writeText("0");
/*      */       }
/* 2484 */       generatedXML.writeElement("D", "depth", 1);
/*      */       
/* 2486 */       generatedXML.writeElement("D", "owner", 0);
/* 2487 */       generatedXML.writeText(this.owner);
/* 2488 */       generatedXML.writeElement("D", "owner", 1);
/*      */       
/* 2490 */       generatedXML.writeElement("D", "timeout", 0);
/* 2491 */       long timeout = (this.expiresAt - System.currentTimeMillis()) / 1000L;
/* 2492 */       generatedXML.writeText("Second-" + timeout);
/* 2493 */       generatedXML.writeElement("D", "timeout", 1);
/*      */       
/* 2495 */       generatedXML.writeElement("D", "locktoken", 0);
/* 2496 */       Enumeration<String> tokensList = this.tokens.elements();
/* 2497 */       while (tokensList.hasMoreElements()) {
/* 2498 */         generatedXML.writeElement("D", "href", 0);
/* 2499 */         generatedXML.writeText("opaquelocktoken:" + 
/* 2500 */           (String)tokensList.nextElement());
/* 2501 */         generatedXML.writeElement("D", "href", 1);
/*      */       }
/* 2503 */       generatedXML.writeElement("D", "locktoken", 1);
/*      */       
/* 2505 */       generatedXML.writeElement("D", "activelock", 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class WebdavResolver
/*      */     implements EntityResolver
/*      */   {
/*      */     private ServletContext context;
/*      */     
/*      */ 
/*      */ 
/*      */     public WebdavResolver(ServletContext theContext)
/*      */     {
/* 2521 */       this.context = theContext;
/*      */     }
/*      */     
/*      */     public InputSource resolveEntity(String publicId, String systemId)
/*      */     {
/* 2526 */       this.context.log(DefaultServlet.sm.getString("webdavservlet.externalEntityIgnored", new Object[] { publicId, systemId }));
/*      */       
/* 2528 */       return new InputSource(new StringReader("Ignored external entity"));
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\servlets\WebdavServlet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */