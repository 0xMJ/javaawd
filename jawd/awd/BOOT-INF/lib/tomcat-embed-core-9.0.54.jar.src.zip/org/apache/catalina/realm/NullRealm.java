/*    */ package org.apache.catalina.realm;
/*    */ 
/*    */ import java.security.Principal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullRealm
/*    */   extends RealmBase
/*    */ {
/*    */   protected String getPassword(String username)
/*    */   {
/* 31 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   protected Principal getPrincipal(String username)
/*    */   {
/* 37 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\NullRealm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */