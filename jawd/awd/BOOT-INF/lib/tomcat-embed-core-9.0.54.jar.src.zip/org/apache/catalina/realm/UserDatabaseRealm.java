/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import java.security.Principal;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.naming.Context;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.naming.ContextBindings;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UserDatabaseRealm
/*     */   extends RealmBase
/*     */ {
/*  54 */   protected volatile UserDatabase database = null;
/*  55 */   private final Object databaseLock = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */   protected String resourceName = "UserDatabase";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private boolean localJndiResource = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   private boolean useStaticPrincipal = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getResourceName()
/*     */   {
/*  83 */     return this.resourceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceName(String resourceName)
/*     */   {
/*  94 */     this.resourceName = resourceName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getUseStaticPrincipal()
/*     */   {
/* 102 */     return this.useStaticPrincipal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseStaticPrincipal(boolean useStaticPrincipal)
/*     */   {
/* 111 */     this.useStaticPrincipal = useStaticPrincipal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getLocalJndiResource()
/*     */   {
/* 124 */     return this.localJndiResource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocalJndiResource(boolean localJndiResource)
/*     */   {
/* 136 */     this.localJndiResource = localJndiResource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void backgroundProcess()
/*     */   {
/* 144 */     UserDatabase database = getUserDatabase();
/* 145 */     if (database != null) {
/* 146 */       database.backgroundProcess();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPassword(String username)
/*     */   {
/* 156 */     UserDatabase database = getUserDatabase();
/* 157 */     if (database == null) {
/* 158 */       return null;
/*     */     }
/*     */     
/* 161 */     User user = database.findUser(username);
/*     */     
/* 163 */     if (user == null) {
/* 164 */       return null;
/*     */     }
/*     */     
/* 167 */     return user.getPassword();
/*     */   }
/*     */   
/*     */   public static String[] getRoles(User user)
/*     */   {
/* 172 */     Set<String> roles = new HashSet();
/* 173 */     Iterator<Role> uroles = user.getRoles();
/* 174 */     while (uroles.hasNext()) {
/* 175 */       Role role = (Role)uroles.next();
/* 176 */       roles.add(role.getName());
/*     */     }
/* 178 */     Iterator<Group> groups = user.getGroups();
/* 179 */     while (groups.hasNext()) {
/* 180 */       Group group = (Group)groups.next();
/* 181 */       uroles = group.getRoles();
/* 182 */       while (uroles.hasNext()) {
/* 183 */         Role role = (Role)uroles.next();
/* 184 */         roles.add(role.getName());
/*     */       }
/*     */     }
/* 187 */     return (String[])roles.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Principal getPrincipal(String username)
/*     */   {
/* 196 */     UserDatabase database = getUserDatabase();
/* 197 */     if (database == null) {
/* 198 */       return null;
/*     */     }
/* 200 */     User user = database.findUser(username);
/* 201 */     if (user == null) {
/* 202 */       return null;
/*     */     }
/* 204 */     if (this.useStaticPrincipal) {
/* 205 */       return new GenericPrincipal(username, null, Arrays.asList(getRoles(user)));
/*     */     }
/* 207 */     return new UserDatabasePrincipal(user, database);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private UserDatabase getUserDatabase()
/*     */   {
/* 219 */     if (this.database == null) {
/* 220 */       synchronized (this.databaseLock) {
/* 221 */         if (this.database == null) {
/*     */           try {
/* 223 */             Context context = null;
/* 224 */             if (this.localJndiResource) {
/* 225 */               context = ContextBindings.getClassLoader();
/* 226 */               context = (Context)context.lookup("comp/env");
/*     */             } else {
/* 228 */               context = getServer().getGlobalNamingContext();
/*     */             }
/* 230 */             this.database = ((UserDatabase)context.lookup(this.resourceName));
/*     */           } catch (Throwable e) {
/* 232 */             ExceptionUtils.handleThrowable(e);
/* 233 */             if (this.containerLog != null) {
/* 234 */               this.containerLog.error(sm.getString("userDatabaseRealm.lookup", new Object[] { this.resourceName }), e);
/*     */             }
/* 236 */             this.database = null;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 241 */     return this.database;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 252 */     if (!this.localJndiResource) {
/* 253 */       UserDatabase database = getUserDatabase();
/* 254 */       if (database == null) {
/* 255 */         throw new LifecycleException(sm.getString("userDatabaseRealm.noDatabase", new Object[] { this.resourceName }));
/*     */       }
/*     */     }
/*     */     
/* 259 */     super.startInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 275 */     super.stopInternal();
/*     */     
/*     */ 
/* 278 */     this.database = null;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAvailable()
/*     */   {
/* 284 */     return this.database == null ? false : this.database.isAvailable();
/*     */   }
/*     */   
/*     */   public static final class UserDatabasePrincipal extends GenericPrincipal
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final transient UserDatabase database;
/*     */     
/*     */     public UserDatabasePrincipal(User user, UserDatabase database) {
/* 293 */       super(null, null);
/* 294 */       this.database = database;
/*     */     }
/*     */     
/*     */     public String[] getRoles()
/*     */     {
/* 299 */       if (this.database == null) {
/* 300 */         return new String[0];
/*     */       }
/* 302 */       User user = this.database.findUser(this.name);
/* 303 */       if (user == null) {
/* 304 */         return new String[0];
/*     */       }
/* 306 */       Set<String> roles = new HashSet();
/* 307 */       Iterator<Role> uroles = user.getRoles();
/* 308 */       while (uroles.hasNext()) {
/* 309 */         Role role = (Role)uroles.next();
/* 310 */         roles.add(role.getName());
/*     */       }
/* 312 */       Iterator<Group> groups = user.getGroups();
/* 313 */       while (groups.hasNext()) {
/* 314 */         Group group = (Group)groups.next();
/* 315 */         uroles = group.getRoles();
/* 316 */         while (uroles.hasNext()) {
/* 317 */           Role role = (Role)uroles.next();
/* 318 */           roles.add(role.getName());
/*     */         }
/*     */       }
/* 321 */       return (String[])roles.toArray(new String[0]);
/*     */     }
/*     */     
/*     */     public boolean hasRole(String role)
/*     */     {
/* 326 */       if ("*".equals(role))
/* 327 */         return true;
/* 328 */       if (role == null) {
/* 329 */         return false;
/*     */       }
/* 331 */       if (this.database == null) {
/* 332 */         return super.hasRole(role);
/*     */       }
/* 334 */       Role dbrole = this.database.findRole(role);
/* 335 */       if (dbrole == null) {
/* 336 */         return false;
/*     */       }
/* 338 */       User user = this.database.findUser(this.name);
/* 339 */       if (user == null) {
/* 340 */         return false;
/*     */       }
/* 342 */       if (user.isInRole(dbrole)) {
/* 343 */         return true;
/*     */       }
/* 345 */       Iterator<Group> groups = user.getGroups();
/* 346 */       while (groups.hasNext()) {
/* 347 */         Group group = (Group)groups.next();
/* 348 */         if (group.isInRole(dbrole)) {
/* 349 */           return true;
/*     */         }
/*     */       }
/* 352 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Object writeReplace()
/*     */       throws ObjectStreamException
/*     */     {
/* 364 */       return new GenericPrincipal(getName(), null, Arrays.asList(getRoles()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\UserDatabaseRealm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */