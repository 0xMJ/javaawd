/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.digester.RuleSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamingRuleSet
/*     */   implements RuleSet
/*     */ {
/*     */   protected final String prefix;
/*     */   
/*     */   public NamingRuleSet()
/*     */   {
/*  46 */     this("");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NamingRuleSet(String prefix)
/*     */   {
/*  58 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRuleInstances(Digester digester)
/*     */   {
/*  76 */     digester.addObjectCreate(this.prefix + "Ejb", "org.apache.tomcat.util.descriptor.web.ContextEjb");
/*     */     
/*  78 */     digester.addSetProperties(this.prefix + "Ejb");
/*  79 */     digester.addRule(this.prefix + "Ejb", new SetNextNamingRule("addEjb", "org.apache.tomcat.util.descriptor.web.ContextEjb"));
/*     */     
/*     */ 
/*     */ 
/*  83 */     digester.addObjectCreate(this.prefix + "Environment", "org.apache.tomcat.util.descriptor.web.ContextEnvironment");
/*     */     
/*  85 */     digester.addSetProperties(this.prefix + "Environment");
/*  86 */     digester.addRule(this.prefix + "Environment", new SetNextNamingRule("addEnvironment", "org.apache.tomcat.util.descriptor.web.ContextEnvironment"));
/*     */     
/*     */ 
/*     */ 
/*  90 */     digester.addObjectCreate(this.prefix + "LocalEjb", "org.apache.tomcat.util.descriptor.web.ContextLocalEjb");
/*     */     
/*  92 */     digester.addSetProperties(this.prefix + "LocalEjb");
/*  93 */     digester.addRule(this.prefix + "LocalEjb", new SetNextNamingRule("addLocalEjb", "org.apache.tomcat.util.descriptor.web.ContextLocalEjb"));
/*     */     
/*     */ 
/*     */ 
/*  97 */     digester.addObjectCreate(this.prefix + "Resource", "org.apache.tomcat.util.descriptor.web.ContextResource");
/*     */     
/*  99 */     digester.addSetProperties(this.prefix + "Resource");
/* 100 */     digester.addRule(this.prefix + "Resource", new SetNextNamingRule("addResource", "org.apache.tomcat.util.descriptor.web.ContextResource"));
/*     */     
/*     */ 
/*     */ 
/* 104 */     digester.addObjectCreate(this.prefix + "ResourceEnvRef", "org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef");
/*     */     
/* 106 */     digester.addSetProperties(this.prefix + "ResourceEnvRef");
/* 107 */     digester.addRule(this.prefix + "ResourceEnvRef", new SetNextNamingRule("addResourceEnvRef", "org.apache.tomcat.util.descriptor.web.ContextResourceEnvRef"));
/*     */     
/*     */ 
/*     */ 
/* 111 */     digester.addObjectCreate(this.prefix + "ServiceRef", "org.apache.tomcat.util.descriptor.web.ContextService");
/*     */     
/* 113 */     digester.addSetProperties(this.prefix + "ServiceRef");
/* 114 */     digester.addRule(this.prefix + "ServiceRef", new SetNextNamingRule("addService", "org.apache.tomcat.util.descriptor.web.ContextService"));
/*     */     
/*     */ 
/*     */ 
/* 118 */     digester.addObjectCreate(this.prefix + "Transaction", "org.apache.tomcat.util.descriptor.web.ContextTransaction");
/*     */     
/* 120 */     digester.addSetProperties(this.prefix + "Transaction");
/* 121 */     digester.addRule(this.prefix + "Transaction", new SetNextNamingRule("setTransaction", "org.apache.tomcat.util.descriptor.web.ContextTransaction"));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\NamingRuleSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */