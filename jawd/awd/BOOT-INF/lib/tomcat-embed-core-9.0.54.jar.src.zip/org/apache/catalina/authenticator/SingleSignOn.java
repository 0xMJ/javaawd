/*     */ package org.apache.catalina.authenticator;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.SessionCookieConfig;
/*     */ import javax.servlet.http.Cookie;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Realm;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.catalina.SessionListener;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.valves.ValveBase;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleSignOn
/*     */   extends ValveBase
/*     */ {
/*  62 */   private static final StringManager sm = StringManager.getManager(SingleSignOn.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private Engine engine;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SingleSignOn()
/*     */   {
/*  73 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   protected Map<String, SingleSignOnEntry> cache = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   private boolean requireReauthentication = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String cookieDomain;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 100 */   private String cookieName = Constants.SINGLE_SIGN_ON_COOKIE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCookieDomain()
/*     */   {
/* 111 */     return this.cookieDomain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCookieDomain(String cookieDomain)
/*     */   {
/* 121 */     if ((cookieDomain != null) && (cookieDomain.trim().length() == 0)) {
/* 122 */       this.cookieDomain = null;
/*     */     } else {
/* 124 */       this.cookieDomain = cookieDomain;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCookieName()
/*     */   {
/* 133 */     return this.cookieName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCookieName(String cookieName)
/*     */   {
/* 142 */     this.cookieName = cookieName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getRequireReauthentication()
/*     */   {
/* 164 */     return this.requireReauthentication;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequireReauthentication(boolean required)
/*     */   {
/* 209 */     this.requireReauthentication = required;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void invoke(Request request, Response response)
/*     */     throws IOException, ServletException
/*     */   {
/* 228 */     request.removeNote("org.apache.catalina.request.SSOID");
/*     */     
/*     */ 
/* 231 */     if (this.containerLog.isDebugEnabled()) {
/* 232 */       this.containerLog.debug(sm.getString("singleSignOn.debug.invoke", new Object[] { request.getRequestURI() }));
/*     */     }
/* 234 */     if (request.getUserPrincipal() != null) {
/* 235 */       if (this.containerLog.isDebugEnabled()) {
/* 236 */         this.containerLog.debug(sm.getString("singleSignOn.debug.hasPrincipal", new Object[] {request
/* 237 */           .getUserPrincipal().getName() }));
/*     */       }
/* 239 */       getNext().invoke(request, response);
/* 240 */       return;
/*     */     }
/*     */     
/*     */ 
/* 244 */     if (this.containerLog.isDebugEnabled()) {
/* 245 */       this.containerLog.debug(sm.getString("singleSignOn.debug.cookieCheck"));
/*     */     }
/* 247 */     Cookie cookie = null;
/* 248 */     Cookie[] cookies = request.getCookies();
/* 249 */     if (cookies != null) {
/* 250 */       for (Cookie value : cookies) {
/* 251 */         if (this.cookieName.equals(value.getName())) {
/* 252 */           cookie = value;
/* 253 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 257 */     if (cookie == null) {
/* 258 */       if (this.containerLog.isDebugEnabled()) {
/* 259 */         this.containerLog.debug(sm.getString("singleSignOn.debug.cookieNotFound"));
/*     */       }
/* 261 */       getNext().invoke(request, response);
/* 262 */       return;
/*     */     }
/*     */     
/*     */ 
/* 266 */     if (this.containerLog.isDebugEnabled()) {
/* 267 */       this.containerLog.debug(sm.getString("singleSignOn.debug.principalCheck", new Object[] {cookie
/* 268 */         .getValue() }));
/*     */     }
/* 270 */     SingleSignOnEntry entry = (SingleSignOnEntry)this.cache.get(cookie.getValue());
/* 271 */     if (entry != null) {
/* 272 */       if (this.containerLog.isDebugEnabled()) {
/* 273 */         this.containerLog.debug(sm.getString("singleSignOn.debug.principalFound", new Object[] {entry
/* 274 */           .getPrincipal() != null ? entry.getPrincipal().getName() : "", entry
/* 275 */           .getAuthType() }));
/*     */       }
/* 277 */       request.setNote("org.apache.catalina.request.SSOID", cookie.getValue());
/*     */       
/* 279 */       if (!getRequireReauthentication()) {
/* 280 */         request.setAuthType(entry.getAuthType());
/* 281 */         request.setUserPrincipal(entry.getPrincipal());
/*     */       }
/*     */     } else {
/* 284 */       if (this.containerLog.isDebugEnabled()) {
/* 285 */         this.containerLog.debug(sm.getString("singleSignOn.debug.principalNotFound", new Object[] {cookie
/* 286 */           .getValue() }));
/*     */       }
/*     */       
/* 289 */       cookie.setValue("REMOVE");
/*     */       
/* 291 */       cookie.setMaxAge(0);
/*     */       
/*     */ 
/* 294 */       cookie.setPath("/");
/* 295 */       String domain = getCookieDomain();
/* 296 */       if (domain != null) {
/* 297 */         cookie.setDomain(domain);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 302 */       cookie.setSecure(request.isSecure());
/* 303 */       if ((request.getServletContext().getSessionCookieConfig().isHttpOnly()) || 
/* 304 */         (request.getContext().getUseHttpOnly())) {
/* 305 */         cookie.setHttpOnly(true);
/*     */       }
/*     */       
/* 308 */       response.addCookie(cookie);
/*     */     }
/*     */     
/*     */ 
/* 312 */     getNext().invoke(request, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void sessionDestroyed(String ssoId, Session session)
/*     */   {
/* 329 */     if (!getState().isAvailable()) {
/* 330 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 337 */     if (((session.getMaxInactiveInterval() > 0) && 
/* 338 */       (session.getIdleTimeInternal() >= session.getMaxInactiveInterval() * 1000)) || 
/* 339 */       (!session.getManager().getContext().getState().isAvailable())) {
/* 340 */       if (this.containerLog.isDebugEnabled()) {
/* 341 */         this.containerLog.debug(sm.getString("singleSignOn.debug.sessionTimeout", new Object[] { ssoId, session }));
/*     */       }
/*     */       
/* 344 */       removeSession(ssoId, session);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 349 */       if (this.containerLog.isDebugEnabled()) {
/* 350 */         this.containerLog.debug(sm.getString("singleSignOn.debug.sessionLogout", new Object[] { ssoId, session }));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 357 */       removeSession(ssoId, session);
/*     */       
/*     */ 
/* 360 */       if (this.cache.containsKey(ssoId)) {
/* 361 */         deregister(ssoId);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean associate(String ssoId, Session session)
/*     */   {
/* 378 */     SingleSignOnEntry sso = (SingleSignOnEntry)this.cache.get(ssoId);
/* 379 */     if (sso == null) {
/* 380 */       if (this.containerLog.isDebugEnabled()) {
/* 381 */         this.containerLog.debug(sm.getString("singleSignOn.debug.associateFail", new Object[] { ssoId, session }));
/*     */       }
/*     */       
/* 384 */       return false;
/*     */     }
/* 386 */     if (this.containerLog.isDebugEnabled()) {
/* 387 */       this.containerLog.debug(sm.getString("singleSignOn.debug.associate", new Object[] { ssoId, session }));
/*     */     }
/*     */     
/* 390 */     sso.addSession(this, ssoId, session);
/* 391 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void deregister(String ssoId)
/*     */   {
/* 405 */     SingleSignOnEntry sso = (SingleSignOnEntry)this.cache.remove(ssoId);
/*     */     
/* 407 */     if (sso == null) {
/* 408 */       if (this.containerLog.isDebugEnabled()) {
/* 409 */         this.containerLog.debug(sm.getString("singleSignOn.debug.deregisterFail", new Object[] { ssoId }));
/*     */       }
/* 411 */       return;
/*     */     }
/*     */     
/*     */ 
/* 415 */     Set<SingleSignOnSessionKey> ssoKeys = sso.findSessions();
/* 416 */     if ((ssoKeys.size() == 0) && 
/* 417 */       (this.containerLog.isDebugEnabled())) {
/* 418 */       this.containerLog.debug(sm.getString("singleSignOn.debug.deregisterNone", new Object[] { ssoId }));
/*     */     }
/*     */     
/* 421 */     for (SingleSignOnSessionKey ssoKey : ssoKeys) {
/* 422 */       if (this.containerLog.isDebugEnabled()) {
/* 423 */         this.containerLog.debug(sm.getString("singleSignOn.debug.deregister", new Object[] { ssoKey, ssoId }));
/*     */       }
/*     */       
/* 426 */       expire(ssoKey);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void expire(SingleSignOnSessionKey key)
/*     */   {
/* 436 */     if (this.engine == null) {
/* 437 */       this.containerLog.warn(sm.getString("singleSignOn.sessionExpire.engineNull", new Object[] { key }));
/* 438 */       return;
/*     */     }
/* 440 */     Container host = this.engine.findChild(key.getHostName());
/* 441 */     if (host == null) {
/* 442 */       this.containerLog.warn(sm.getString("singleSignOn.sessionExpire.hostNotFound", new Object[] { key }));
/* 443 */       return;
/*     */     }
/* 445 */     Context context = (Context)host.findChild(key.getContextName());
/* 446 */     if (context == null) {
/* 447 */       this.containerLog.warn(sm.getString("singleSignOn.sessionExpire.contextNotFound", new Object[] { key }));
/* 448 */       return;
/*     */     }
/* 450 */     Manager manager = context.getManager();
/* 451 */     if (manager == null) {
/* 452 */       this.containerLog.warn(sm.getString("singleSignOn.sessionExpire.managerNotFound", new Object[] { key }));
/* 453 */       return;
/*     */     }
/* 455 */     Session session = null;
/*     */     try {
/* 457 */       session = manager.findSession(key.getSessionId());
/*     */     } catch (IOException e) {
/* 459 */       this.containerLog.warn(sm.getString("singleSignOn.sessionExpire.managerError", new Object[] { key }), e);
/* 460 */       return;
/*     */     }
/* 462 */     if (session == null) {
/* 463 */       this.containerLog.warn(sm.getString("singleSignOn.sessionExpire.sessionNotFound", new Object[] { key }));
/* 464 */       return;
/*     */     }
/* 466 */     session.expire();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean reauthenticate(String ssoId, Realm realm, Request request)
/*     */   {
/* 494 */     if ((ssoId == null) || (realm == null)) {
/* 495 */       return false;
/*     */     }
/*     */     
/* 498 */     boolean reauthenticated = false;
/*     */     
/* 500 */     SingleSignOnEntry entry = (SingleSignOnEntry)this.cache.get(ssoId);
/* 501 */     if ((entry != null) && (entry.getCanReauthenticate()))
/*     */     {
/* 503 */       String username = entry.getUsername();
/* 504 */       if (username != null)
/*     */       {
/* 506 */         Principal reauthPrincipal = realm.authenticate(username, entry.getPassword());
/* 507 */         if (reauthPrincipal != null) {
/* 508 */           reauthenticated = true;
/*     */           
/* 510 */           request.setAuthType(entry.getAuthType());
/* 511 */           request.setUserPrincipal(reauthPrincipal);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 516 */     return reauthenticated;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void register(String ssoId, Principal principal, String authType, String username, String password)
/*     */   {
/* 534 */     if (this.containerLog.isDebugEnabled()) {
/* 535 */       this.containerLog.debug(sm.getString("singleSignOn.debug.register", new Object[] { ssoId, principal != null ? principal
/* 536 */         .getName() : "", authType }));
/*     */     }
/*     */     
/* 539 */     this.cache.put(ssoId, new SingleSignOnEntry(principal, authType, username, password));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean update(String ssoId, Principal principal, String authType, String username, String password)
/*     */   {
/* 574 */     SingleSignOnEntry sso = (SingleSignOnEntry)this.cache.get(ssoId);
/* 575 */     if ((sso != null) && (!sso.getCanReauthenticate())) {
/* 576 */       if (this.containerLog.isDebugEnabled()) {
/* 577 */         this.containerLog.debug(sm.getString("singleSignOn.debug.update", new Object[] { ssoId, authType }));
/*     */       }
/*     */       
/* 580 */       sso.updateCredentials(principal, authType, username, password);
/* 581 */       return true;
/*     */     }
/* 583 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void removeSession(String ssoId, Session session)
/*     */   {
/* 596 */     if (this.containerLog.isDebugEnabled()) {
/* 597 */       this.containerLog.debug(sm.getString("singleSignOn.debug.removeSession", new Object[] { session, ssoId }));
/*     */     }
/*     */     
/*     */ 
/* 601 */     SingleSignOnEntry entry = (SingleSignOnEntry)this.cache.get(ssoId);
/* 602 */     if (entry == null) {
/* 603 */       return;
/*     */     }
/*     */     
/*     */ 
/* 607 */     entry.removeSession(session);
/*     */     
/*     */ 
/*     */ 
/* 611 */     if (entry.findSessions().size() == 0) {
/* 612 */       deregister(ssoId);
/*     */     }
/*     */   }
/*     */   
/*     */   protected SessionListener getSessionListener(String ssoId)
/*     */   {
/* 618 */     return new SingleSignOnListener(ssoId);
/*     */   }
/*     */   
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 624 */     Container c = getContainer();
/* 625 */     while ((c != null) && (!(c instanceof Engine))) {
/* 626 */       c = c.getParent();
/*     */     }
/* 628 */     if (c != null) {
/* 629 */       this.engine = ((Engine)c);
/*     */     }
/* 631 */     super.startInternal();
/*     */   }
/*     */   
/*     */   protected synchronized void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 637 */     super.stopInternal();
/* 638 */     this.engine = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\authenticator\SingleSignOn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */