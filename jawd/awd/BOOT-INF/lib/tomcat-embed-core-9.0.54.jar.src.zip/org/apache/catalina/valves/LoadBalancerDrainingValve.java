/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.SessionCookieConfig;
/*     */ import javax.servlet.http.Cookie;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.connector.Response;
/*     */ import org.apache.catalina.util.SessionConfig;
/*     */ import org.apache.juli.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadBalancerDrainingValve
/*     */   extends ValveBase
/*     */ {
/*     */   public static final String ATTRIBUTE_KEY_JK_LB_ACTIVATION = "JK_LB_ACTIVATION";
/*  75 */   private int _redirectStatusCode = 307;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String _ignoreCookieName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String _ignoreCookieValue;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoadBalancerDrainingValve()
/*     */   {
/*  96 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRedirectStatusCode(int code)
/*     */   {
/* 111 */     this._redirectStatusCode = code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIgnoreCookieName()
/*     */   {
/* 124 */     return this._ignoreCookieName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreCookieName(String cookieName)
/*     */   {
/* 141 */     this._ignoreCookieName = cookieName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIgnoreCookieValue()
/*     */   {
/* 154 */     return this._ignoreCookieValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreCookieValue(String cookieValue)
/*     */   {
/* 170 */     this._ignoreCookieValue = cookieValue;
/*     */   }
/*     */   
/*     */   public void invoke(Request request, Response response) throws IOException, ServletException
/*     */   {
/* 175 */     if (("DIS".equals(request.getAttribute("JK_LB_ACTIVATION"))) && 
/* 176 */       (!request.isRequestedSessionIdValid()))
/*     */     {
/* 178 */       if (this.containerLog.isDebugEnabled()) {
/* 179 */         this.containerLog.debug("Load-balancer is in DISABLED state; draining this node");
/*     */       }
/*     */       
/* 182 */       boolean ignoreRebalance = false;
/* 183 */       Cookie sessionCookie = null;
/*     */       
/* 185 */       Cookie[] cookies = request.getCookies();
/*     */       
/* 187 */       String sessionCookieName = SessionConfig.getSessionCookieName(request.getContext());
/*     */       
/* 189 */       if (null != cookies) {
/* 190 */         for (Cookie cookie : cookies) {
/* 191 */           String cookieName = cookie.getName();
/* 192 */           if (this.containerLog.isTraceEnabled()) {
/* 193 */             this.containerLog.trace("Checking cookie " + cookieName + "=" + cookie.getValue());
/*     */           }
/*     */           
/* 196 */           if ((sessionCookieName.equals(cookieName)) && 
/* 197 */             (request.getRequestedSessionId().equals(cookie.getValue()))) {
/* 198 */             sessionCookie = cookie;
/* 199 */           } else if ((null != this._ignoreCookieName) && 
/* 200 */             (this._ignoreCookieName.equals(cookieName)) && (null != this._ignoreCookieValue))
/*     */           {
/* 202 */             if (this._ignoreCookieValue.equals(cookie.getValue()))
/*     */             {
/* 204 */               ignoreRebalance = true;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 209 */       if (ignoreRebalance) {
/* 210 */         if (this.containerLog.isDebugEnabled()) {
/* 211 */           this.containerLog.debug("Client is presenting a valid " + this._ignoreCookieName + " cookie, re-balancing is being skipped");
/*     */         }
/*     */         
/*     */ 
/* 215 */         getNext().invoke(request, response);
/*     */         
/* 217 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 222 */       if (null != sessionCookie) {
/* 223 */         sessionCookie.setPath(SessionConfig.getSessionCookiePath(request.getContext()));
/* 224 */         sessionCookie.setMaxAge(0);
/* 225 */         sessionCookie.setValue("");
/*     */         
/* 227 */         SessionCookieConfig sessionCookieConfig = request.getContext().getServletContext().getSessionCookieConfig();
/* 228 */         sessionCookie.setSecure((request.isSecure()) || (sessionCookieConfig.isSecure()));
/* 229 */         response.addCookie(sessionCookie);
/*     */       }
/*     */       
/*     */ 
/* 233 */       String uri = request.getRequestURI();
/* 234 */       String sessionURIParamName = SessionConfig.getSessionUriParamName(request.getContext());
/* 235 */       if (uri.contains(";" + sessionURIParamName + "=")) {
/* 236 */         uri = uri.replaceFirst(";" + sessionURIParamName + "=[^&?]*", "");
/*     */       }
/*     */       
/* 239 */       String queryString = request.getQueryString();
/*     */       
/* 241 */       if (null != queryString) {
/* 242 */         uri = uri + "?" + queryString;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 247 */       response.setHeader("Location", uri);
/* 248 */       response.setStatus(this._redirectStatusCode);
/*     */     } else {
/* 250 */       getNext().invoke(request, response);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\LoadBalancerDrainingValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */