/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.compat.JrePlatform;
/*     */ import org.apache.tomcat.util.http.RequestUtil;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFileResourceSet
/*     */   extends AbstractResourceSet
/*     */ {
/*  32 */   private static final Log log = LogFactory.getLog(AbstractFileResourceSet.class);
/*     */   
/*  34 */   protected static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   
/*     */   private File fileBase;
/*     */   private String absoluteBase;
/*     */   private String canonicalBase;
/*  39 */   private boolean readOnly = false;
/*     */   
/*     */   protected AbstractFileResourceSet(String internalPath) {
/*  42 */     setInternalPath(internalPath);
/*     */   }
/*     */   
/*     */   protected final File getFileBase() {
/*  46 */     return this.fileBase;
/*     */   }
/*     */   
/*     */   public void setReadOnly(boolean readOnly)
/*     */   {
/*  51 */     this.readOnly = readOnly;
/*     */   }
/*     */   
/*     */   public boolean isReadOnly()
/*     */   {
/*  56 */     return this.readOnly;
/*     */   }
/*     */   
/*     */   protected final File file(String name, boolean mustExist)
/*     */   {
/*  61 */     if (name.equals("/")) {
/*  62 */       name = "";
/*     */     }
/*  64 */     File file = new File(this.fileBase, name);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  69 */     if ((name.endsWith("/")) && (file.isFile())) {
/*  70 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  75 */     if ((mustExist) && (!file.canRead())) {
/*  76 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  81 */     if (getRoot().getAllowLinking()) {
/*  82 */       return file;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  87 */     if ((JrePlatform.IS_WINDOWS) && (isInvalidWindowsFilename(name))) {
/*  88 */       return null;
/*     */     }
/*     */     
/*     */ 
/*  92 */     String canPath = null;
/*     */     try {
/*  94 */       canPath = file.getCanonicalPath();
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */     
/*  98 */     if ((canPath == null) || (!canPath.startsWith(this.canonicalBase))) {
/*  99 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */     String absPath = normalize(file.getAbsolutePath());
/* 110 */     if (this.absoluteBase.length() > absPath.length()) {
/* 111 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 117 */     absPath = absPath.substring(this.absoluteBase.length());
/* 118 */     canPath = canPath.substring(this.canonicalBase.length());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */     if (canPath.length() > 0) {
/* 132 */       canPath = normalize(canPath);
/*     */     }
/* 134 */     if (!canPath.equals(absPath)) {
/* 135 */       if (!canPath.equalsIgnoreCase(absPath))
/*     */       {
/*     */ 
/*     */ 
/* 139 */         logIgnoredSymlink(getRoot().getContext().getName(), absPath, canPath);
/*     */       }
/* 141 */       return null;
/*     */     }
/*     */     
/* 144 */     return file;
/*     */   }
/*     */   
/*     */   protected void logIgnoredSymlink(String contextPath, String absPath, String canPath)
/*     */   {
/* 149 */     String msg = sm.getString("abstractFileResourceSet.canonicalfileCheckFailed", new Object[] { contextPath, absPath, canPath });
/*     */     
/*     */ 
/* 152 */     if ((absPath.startsWith("/META-INF/")) || (absPath.startsWith("/WEB-INF/"))) {
/* 153 */       log.error(msg);
/*     */     } else {
/* 155 */       log.warn(msg);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isInvalidWindowsFilename(String name) {
/* 160 */     int len = name.length();
/* 161 */     if (len == 0) {
/* 162 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 166 */     for (int i = 0; i < len; i++) {
/* 167 */       char c = name.charAt(i);
/* 168 */       if ((c == '"') || (c == '<') || (c == '>') || (c == ':'))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 175 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 182 */     if (name.charAt(len - 1) == ' ') {
/* 183 */       return true;
/*     */     }
/* 185 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String normalize(String path)
/*     */   {
/* 199 */     return RequestUtil.normalize(path, File.separatorChar == '\\');
/*     */   }
/*     */   
/*     */   public URL getBaseUrl()
/*     */   {
/*     */     try {
/* 205 */       return getFileBase().toURI().toURL();
/*     */     } catch (MalformedURLException e) {}
/* 207 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void gc() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 226 */     this.fileBase = new File(getBase(), getInternalPath());
/* 227 */     checkType(this.fileBase);
/*     */     
/* 229 */     this.absoluteBase = normalize(this.fileBase.getAbsolutePath());
/*     */     try
/*     */     {
/* 232 */       this.canonicalBase = this.fileBase.getCanonicalPath();
/*     */     } catch (IOException e) {
/* 234 */       throw new IllegalArgumentException(e);
/*     */     }
/*     */     
/*     */ 
/* 238 */     if ("/".equals(this.absoluteBase)) {
/* 239 */       this.absoluteBase = "";
/*     */     }
/* 241 */     if ("/".equals(this.canonicalBase)) {
/* 242 */       this.canonicalBase = "";
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void checkType(File paramFile);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\webresources\AbstractFileResourceSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */