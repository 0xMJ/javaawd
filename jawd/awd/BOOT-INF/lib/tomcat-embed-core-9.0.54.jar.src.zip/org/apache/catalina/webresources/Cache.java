/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cache
/*     */ {
/*  33 */   private static final Log log = LogFactory.getLog(Cache.class);
/*  34 */   protected static final StringManager sm = StringManager.getManager(Cache.class);
/*     */   
/*     */   private static final long TARGET_FREE_PERCENT_GET = 5L;
/*     */   
/*     */   private static final long TARGET_FREE_PERCENT_BACKGROUND = 10L;
/*     */   
/*     */   private static final int OBJECT_MAX_SIZE_FACTOR = 20;
/*     */   
/*     */   private final StandardRoot root;
/*  43 */   private final AtomicLong size = new AtomicLong(0L);
/*     */   
/*  45 */   private long ttl = 5000L;
/*  46 */   private long maxSize = 10485760L;
/*  47 */   private int objectMaxSize = (int)this.maxSize / 20;
/*     */   
/*  49 */   private AtomicLong lookupCount = new AtomicLong(0L);
/*  50 */   private AtomicLong hitCount = new AtomicLong(0L);
/*     */   
/*  52 */   private final ConcurrentMap<String, CachedResource> resourceCache = new ConcurrentHashMap();
/*     */   
/*     */   public Cache(StandardRoot root)
/*     */   {
/*  56 */     this.root = root;
/*     */   }
/*     */   
/*     */   protected WebResource getResource(String path, boolean useClassLoaderResources)
/*     */   {
/*  61 */     if (noCache(path)) {
/*  62 */       return this.root.getResourceInternal(path, useClassLoaderResources);
/*     */     }
/*     */     
/*  65 */     this.lookupCount.incrementAndGet();
/*     */     
/*  67 */     CachedResource cacheEntry = (CachedResource)this.resourceCache.get(path);
/*     */     
/*  69 */     if ((cacheEntry != null) && (!cacheEntry.validateResource(useClassLoaderResources))) {
/*  70 */       removeCacheEntry(path);
/*  71 */       cacheEntry = null;
/*     */     }
/*     */     
/*  74 */     if (cacheEntry == null)
/*     */     {
/*  76 */       int objectMaxSizeBytes = getObjectMaxSizeBytes();
/*  77 */       CachedResource newCacheEntry = new CachedResource(this, this.root, path, getTtl(), objectMaxSizeBytes, useClassLoaderResources);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  82 */       cacheEntry = (CachedResource)this.resourceCache.putIfAbsent(path, newCacheEntry);
/*     */       
/*  84 */       if (cacheEntry == null)
/*     */       {
/*  86 */         cacheEntry = newCacheEntry;
/*  87 */         cacheEntry.validateResource(useClassLoaderResources);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*  92 */         long delta = cacheEntry.getSize();
/*  93 */         this.size.addAndGet(delta);
/*     */         
/*  95 */         if (this.size.get() > this.maxSize)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 100 */           long targetSize = this.maxSize * 95L / 100L;
/* 101 */           long newSize = evict(targetSize, this.resourceCache.values().iterator());
/* 102 */           if (newSize > this.maxSize)
/*     */           {
/*     */ 
/* 105 */             removeCacheEntry(path);
/* 106 */             log.warn(sm.getString("cache.addFail", new Object[] { path, this.root.getContext().getName() }));
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 111 */         if (cacheEntry.usesClassLoaderResources() != useClassLoaderResources)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */           cacheEntry = newCacheEntry;
/*     */         }
/*     */         
/* 130 */         cacheEntry.validateResource(useClassLoaderResources);
/*     */       }
/*     */     } else {
/* 133 */       this.hitCount.incrementAndGet();
/*     */     }
/*     */     
/* 136 */     return cacheEntry;
/*     */   }
/*     */   
/*     */   protected WebResource[] getResources(String path, boolean useClassLoaderResources) {
/* 140 */     this.lookupCount.incrementAndGet();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 145 */     CachedResource cacheEntry = (CachedResource)this.resourceCache.get(path);
/*     */     
/* 147 */     if ((cacheEntry != null) && (!cacheEntry.validateResources(useClassLoaderResources))) {
/* 148 */       removeCacheEntry(path);
/* 149 */       cacheEntry = null;
/*     */     }
/*     */     
/* 152 */     if (cacheEntry == null)
/*     */     {
/* 154 */       int objectMaxSizeBytes = getObjectMaxSizeBytes();
/* 155 */       CachedResource newCacheEntry = new CachedResource(this, this.root, path, getTtl(), objectMaxSizeBytes, useClassLoaderResources);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 160 */       cacheEntry = (CachedResource)this.resourceCache.putIfAbsent(path, newCacheEntry);
/*     */       
/* 162 */       if (cacheEntry == null)
/*     */       {
/* 164 */         cacheEntry = newCacheEntry;
/* 165 */         cacheEntry.validateResources(useClassLoaderResources);
/*     */         
/*     */ 
/* 168 */         long delta = cacheEntry.getSize();
/* 169 */         this.size.addAndGet(delta);
/*     */         
/* 171 */         if (this.size.get() > this.maxSize)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 176 */           long targetSize = this.maxSize * 95L / 100L;
/* 177 */           long newSize = evict(targetSize, this.resourceCache.values().iterator());
/* 178 */           if (newSize > this.maxSize)
/*     */           {
/*     */ 
/* 181 */             removeCacheEntry(path);
/* 182 */             log.warn(sm.getString("cache.addFail", new Object[] { path }));
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 188 */         cacheEntry.validateResources(useClassLoaderResources);
/*     */       }
/*     */     } else {
/* 191 */       this.hitCount.incrementAndGet();
/*     */     }
/*     */     
/* 194 */     return cacheEntry.getWebResources();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void backgroundProcess()
/*     */   {
/* 201 */     TreeSet<CachedResource> orderedResources = new TreeSet(new EvictionOrder(null));
/*     */     
/* 203 */     orderedResources.addAll(this.resourceCache.values());
/*     */     
/* 205 */     Iterator<CachedResource> iter = orderedResources.iterator();
/*     */     
/* 207 */     long targetSize = this.maxSize * 90L / 100L;
/*     */     
/* 209 */     long newSize = evict(targetSize, iter);
/*     */     
/* 211 */     if (newSize > targetSize) {
/* 212 */       log.info(sm.getString("cache.backgroundEvictFail", new Object[] {
/* 213 */         Long.valueOf(10L), this.root
/* 214 */         .getContext().getName(), 
/* 215 */         Long.valueOf(newSize / 1024L) }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean noCache(String path)
/*     */   {
/* 222 */     if (((path.endsWith(".class")) && (
/* 223 */       (path.startsWith("/WEB-INF/classes/")) || (path.startsWith("/WEB-INF/lib/")))) || (
/*     */       
/* 225 */       (path.startsWith("/WEB-INF/lib/")) && (path.endsWith(".jar")))) {
/* 226 */       return true;
/*     */     }
/* 228 */     return false;
/*     */   }
/*     */   
/*     */   private long evict(long targetSize, Iterator<CachedResource> iter)
/*     */   {
/* 233 */     long now = System.currentTimeMillis();
/*     */     
/* 235 */     long newSize = this.size.get();
/*     */     
/* 237 */     while ((newSize > targetSize) && (iter.hasNext())) {
/* 238 */       CachedResource resource = (CachedResource)iter.next();
/*     */       
/*     */ 
/* 241 */       if (resource.getNextCheck() <= now)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 246 */         removeCacheEntry(resource.getWebappPath());
/*     */         
/* 248 */         newSize = this.size.get();
/*     */       }
/*     */     }
/* 251 */     return newSize;
/*     */   }
/*     */   
/*     */ 
/*     */   void removeCacheEntry(String path)
/*     */   {
/* 257 */     CachedResource cachedResource = (CachedResource)this.resourceCache.remove(path);
/* 258 */     if (cachedResource != null) {
/* 259 */       long delta = cachedResource.getSize();
/* 260 */       this.size.addAndGet(-delta);
/*     */     }
/*     */   }
/*     */   
/*     */   public long getTtl() {
/* 265 */     return this.ttl;
/*     */   }
/*     */   
/*     */   public void setTtl(long ttl) {
/* 269 */     this.ttl = ttl;
/*     */   }
/*     */   
/*     */   public long getMaxSize()
/*     */   {
/* 274 */     return this.maxSize / 1024L;
/*     */   }
/*     */   
/*     */   public void setMaxSize(long maxSize)
/*     */   {
/* 279 */     this.maxSize = (maxSize * 1024L);
/*     */   }
/*     */   
/*     */   public long getLookupCount() {
/* 283 */     return this.lookupCount.get();
/*     */   }
/*     */   
/*     */   public long getHitCount() {
/* 287 */     return this.hitCount.get();
/*     */   }
/*     */   
/*     */   public void setObjectMaxSize(int objectMaxSize) {
/* 291 */     if (objectMaxSize * 1024L > 2147483647L) {
/* 292 */       log.warn(sm.getString("cache.objectMaxSizeTooBigBytes", new Object[] { Integer.valueOf(objectMaxSize) }));
/* 293 */       this.objectMaxSize = Integer.MAX_VALUE;
/*     */     }
/*     */     
/* 296 */     this.objectMaxSize = (objectMaxSize * 1024);
/*     */   }
/*     */   
/*     */   public int getObjectMaxSize()
/*     */   {
/* 301 */     return this.objectMaxSize / 1024;
/*     */   }
/*     */   
/*     */   public int getObjectMaxSizeBytes() {
/* 305 */     return this.objectMaxSize;
/*     */   }
/*     */   
/*     */   void enforceObjectMaxSizeLimit() {
/* 309 */     long limit = this.maxSize / 20L;
/* 310 */     if (limit > 2147483647L) {
/* 311 */       return;
/*     */     }
/* 313 */     if (this.objectMaxSize > limit) {
/* 314 */       log.warn(sm.getString("cache.objectMaxSizeTooBig", new Object[] {
/* 315 */         Integer.valueOf(this.objectMaxSize / 1024), Integer.valueOf((int)limit / 1024) }));
/* 316 */       this.objectMaxSize = ((int)limit);
/*     */     }
/*     */   }
/*     */   
/*     */   public void clear() {
/* 321 */     this.resourceCache.clear();
/* 322 */     this.size.set(0L);
/*     */   }
/*     */   
/*     */   public long getSize() {
/* 326 */     return this.size.get() / 1024L;
/*     */   }
/*     */   
/*     */   private static class EvictionOrder implements Comparator<CachedResource>
/*     */   {
/*     */     public int compare(CachedResource cr1, CachedResource cr2)
/*     */     {
/* 333 */       long nc1 = cr1.getNextCheck();
/* 334 */       long nc2 = cr2.getNextCheck();
/*     */       
/*     */ 
/*     */ 
/* 338 */       if (nc1 == nc2)
/* 339 */         return 0;
/* 340 */       if (nc1 > nc2) {
/* 341 */         return -1;
/*     */       }
/* 343 */       return 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\webresources\Cache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */