/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import javax.management.MBeanException;
/*     */ import org.apache.catalina.Executor;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceMBean
/*     */   extends BaseCatalinaMBean<Service>
/*     */ {
/*     */   public void addConnector(String address, int port, boolean isAjp, boolean isSSL)
/*     */     throws MBeanException
/*     */   {
/*  40 */     Service service = (Service)doGetManagedResource();
/*  41 */     String protocol = isAjp ? "AJP/1.3" : "HTTP/1.1";
/*  42 */     Connector connector = new Connector(protocol);
/*  43 */     if ((address != null) && (address.length() > 0)) {
/*  44 */       connector.setProperty("address", address);
/*     */     }
/*  46 */     connector.setPort(port);
/*  47 */     connector.setSecure(isSSL);
/*  48 */     connector.setScheme(isSSL ? "https" : "http");
/*     */     
/*  50 */     service.addConnector(connector);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addExecutor(String type)
/*     */     throws MBeanException
/*     */   {
/*  60 */     Service service = (Service)doGetManagedResource();
/*  61 */     Executor executor = (Executor)newInstance(type);
/*  62 */     service.addExecutor(executor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findConnectors()
/*     */     throws MBeanException
/*     */   {
/*  73 */     Service service = (Service)doGetManagedResource();
/*     */     
/*  75 */     Connector[] connectors = service.findConnectors();
/*  76 */     String[] str = new String[connectors.length];
/*     */     
/*  78 */     for (int i = 0; i < connectors.length; i++) {
/*  79 */       str[i] = connectors[i].toString();
/*     */     }
/*     */     
/*  82 */     return str;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] findExecutors()
/*     */     throws MBeanException
/*     */   {
/*  93 */     Service service = (Service)doGetManagedResource();
/*     */     
/*  95 */     Executor[] executors = service.findExecutors();
/*  96 */     String[] str = new String[executors.length];
/*     */     
/*  98 */     for (int i = 0; i < executors.length; i++) {
/*  99 */       str[i] = executors[i].toString();
/*     */     }
/*     */     
/* 102 */     return str;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExecutor(String name)
/*     */     throws MBeanException
/*     */   {
/* 113 */     Service service = (Service)doGetManagedResource();
/* 114 */     Executor executor = service.getExecutor(name);
/* 115 */     return executor.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\ServiceMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */