/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.Principal;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.CertificateParsingException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.tomcat.util.buf.MessageBytes;
/*     */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*     */ import org.apache.tomcat.util.net.SSLSupport;
/*     */ import org.apache.tomcat.util.net.jsse.PEMFile;
/*     */ import org.apache.tomcat.util.net.openssl.ciphers.Cipher;
/*     */ import org.apache.tomcat.util.net.openssl.ciphers.EncryptionLevel;
/*     */ import org.apache.tomcat.util.net.openssl.ciphers.OpenSSLCipherConfigurationParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolverImpl
/*     */   extends Resolver
/*     */ {
/*  45 */   protected Request request = null;
/*     */   
/*     */   public ResolverImpl(Request request) {
/*  48 */     this.request = request;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String resolve(String key)
/*     */   {
/*  59 */     if (key.equals("HTTP_USER_AGENT"))
/*  60 */       return this.request.getHeader("user-agent");
/*  61 */     if (key.equals("HTTP_REFERER"))
/*  62 */       return this.request.getHeader("referer");
/*  63 */     if (key.equals("HTTP_COOKIE"))
/*  64 */       return this.request.getHeader("cookie");
/*  65 */     if (key.equals("HTTP_FORWARDED"))
/*  66 */       return this.request.getHeader("forwarded");
/*  67 */     if (key.equals("HTTP_HOST"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  72 */       return this.request.getServerName(); }
/*  73 */     if (key.equals("HTTP_PROXY_CONNECTION"))
/*  74 */       return this.request.getHeader("proxy-connection");
/*  75 */     if (key.equals("HTTP_ACCEPT"))
/*  76 */       return this.request.getHeader("accept");
/*  77 */     if (key.equals("REMOTE_ADDR"))
/*  78 */       return this.request.getRemoteAddr();
/*  79 */     if (key.equals("REMOTE_HOST"))
/*  80 */       return this.request.getRemoteHost();
/*  81 */     if (key.equals("REMOTE_PORT"))
/*  82 */       return String.valueOf(this.request.getRemotePort());
/*  83 */     if (key.equals("REMOTE_USER"))
/*  84 */       return this.request.getRemoteUser();
/*  85 */     if (key.equals("REMOTE_IDENT"))
/*  86 */       return this.request.getRemoteUser();
/*  87 */     if (key.equals("REQUEST_METHOD"))
/*  88 */       return this.request.getMethod();
/*  89 */     if (key.equals("SCRIPT_FILENAME"))
/*  90 */       return this.request.getServletContext().getRealPath(this.request.getServletPath());
/*  91 */     if (key.equals("REQUEST_PATH"))
/*  92 */       return this.request.getRequestPathMB().toString();
/*  93 */     if (key.equals("CONTEXT_PATH"))
/*  94 */       return this.request.getContextPath();
/*  95 */     if (key.equals("SERVLET_PATH"))
/*  96 */       return emptyStringIfNull(this.request.getServletPath());
/*  97 */     if (key.equals("PATH_INFO"))
/*  98 */       return emptyStringIfNull(this.request.getPathInfo());
/*  99 */     if (key.equals("QUERY_STRING"))
/* 100 */       return emptyStringIfNull(this.request.getQueryString());
/* 101 */     if (key.equals("AUTH_TYPE"))
/* 102 */       return this.request.getAuthType();
/* 103 */     if (key.equals("DOCUMENT_ROOT"))
/* 104 */       return this.request.getServletContext().getRealPath("/");
/* 105 */     if (key.equals("SERVER_NAME"))
/* 106 */       return this.request.getLocalName();
/* 107 */     if (key.equals("SERVER_ADDR"))
/* 108 */       return this.request.getLocalAddr();
/* 109 */     if (key.equals("SERVER_PORT"))
/* 110 */       return String.valueOf(this.request.getLocalPort());
/* 111 */     if (key.equals("SERVER_PROTOCOL"))
/* 112 */       return this.request.getProtocol();
/* 113 */     if (key.equals("SERVER_SOFTWARE"))
/* 114 */       return "tomcat";
/* 115 */     if (key.equals("THE_REQUEST"))
/* 116 */       return 
/* 117 */         this.request.getMethod() + " " + this.request.getRequestURI() + " " + this.request.getProtocol();
/* 118 */     if (key.equals("REQUEST_URI"))
/* 119 */       return this.request.getRequestURI();
/* 120 */     if (key.equals("REQUEST_FILENAME"))
/* 121 */       return this.request.getPathTranslated();
/* 122 */     if (key.equals("HTTPS"))
/* 123 */       return this.request.isSecure() ? "on" : "off";
/* 124 */     if (key.equals("TIME_YEAR"))
/* 125 */       return String.valueOf(Calendar.getInstance().get(1));
/* 126 */     if (key.equals("TIME_MON"))
/* 127 */       return String.valueOf(Calendar.getInstance().get(2));
/* 128 */     if (key.equals("TIME_DAY"))
/* 129 */       return String.valueOf(Calendar.getInstance().get(5));
/* 130 */     if (key.equals("TIME_HOUR"))
/* 131 */       return String.valueOf(Calendar.getInstance().get(11));
/* 132 */     if (key.equals("TIME_MIN"))
/* 133 */       return String.valueOf(Calendar.getInstance().get(12));
/* 134 */     if (key.equals("TIME_SEC"))
/* 135 */       return String.valueOf(Calendar.getInstance().get(13));
/* 136 */     if (key.equals("TIME_WDAY"))
/* 137 */       return String.valueOf(Calendar.getInstance().get(7));
/* 138 */     if (key.equals("TIME")) {
/* 139 */       return FastHttpDateFormat.getCurrentDate();
/*     */     }
/* 141 */     return null;
/*     */   }
/*     */   
/*     */   public String resolveEnv(String key)
/*     */   {
/* 146 */     Object result = this.request.getAttribute(key);
/* 147 */     return result != null ? result.toString() : System.getProperty(key);
/*     */   }
/*     */   
/*     */   public String resolveSsl(String key)
/*     */   {
/* 152 */     SSLSupport sslSupport = (SSLSupport)this.request.getAttribute("javax.servlet.request.ssl_session_mgr");
/*     */     
/*     */     try
/*     */     {
/* 156 */       if (key.equals("HTTPS"))
/* 157 */         return String.valueOf(sslSupport != null);
/* 158 */       if (key.equals("SSL_PROTOCOL"))
/* 159 */         return sslSupport.getProtocol();
/* 160 */       if (key.equals("SSL_SESSION_ID"))
/* 161 */         return sslSupport.getSessionId();
/* 162 */       if (!key.equals("SSL_SESSION_RESUMED"))
/*     */       {
/* 164 */         if (!key.equals("SSL_SECURE_RENEG"))
/*     */         {
/* 166 */           if (!key.equals("SSL_COMPRESS_METHOD"))
/*     */           {
/* 168 */             if (!key.equals("SSL_TLS_SNI"))
/*     */             {
/* 170 */               if (key.equals("SSL_CIPHER"))
/* 171 */                 return sslSupport.getCipherSuite();
/* 172 */               if (key.equals("SSL_CIPHER_EXPORT")) {
/* 173 */                 String cipherSuite = sslSupport.getCipherSuite();
/* 174 */                 Set<Cipher> cipherList = OpenSSLCipherConfigurationParser.parse(cipherSuite);
/* 175 */                 if (cipherList.size() == 1) {
/* 176 */                   Cipher cipher = (Cipher)cipherList.iterator().next();
/* 177 */                   if ((cipher.getLevel().equals(EncryptionLevel.EXP40)) || 
/* 178 */                     (cipher.getLevel().equals(EncryptionLevel.EXP56))) {
/* 179 */                     return "true";
/*     */                   }
/* 181 */                   return "false";
/*     */                 }
/*     */               }
/* 184 */               else if (key.equals("SSL_CIPHER_ALGKEYSIZE")) {
/* 185 */                 String cipherSuite = sslSupport.getCipherSuite();
/* 186 */                 Set<Cipher> cipherList = OpenSSLCipherConfigurationParser.parse(cipherSuite);
/* 187 */                 if (cipherList.size() == 1) {
/* 188 */                   Cipher cipher = (Cipher)cipherList.iterator().next();
/* 189 */                   return String.valueOf(cipher.getAlg_bits());
/*     */                 }
/* 191 */               } else { if (key.equals("SSL_CIPHER_USEKEYSIZE"))
/* 192 */                   return sslSupport.getKeySize().toString();
/* 193 */                 if (key.startsWith("SSL_CLIENT_")) {
/* 194 */                   X509Certificate[] certificates = sslSupport.getPeerCertificateChain();
/* 195 */                   if ((certificates != null) && (certificates.length > 0)) {
/* 196 */                     key = key.substring("SSL_CLIENT_".length());
/* 197 */                     String result = resolveSslCertificates(key, certificates);
/* 198 */                     if (result != null)
/* 199 */                       return result;
/* 200 */                     if (key.startsWith("SAN_OTHER_msUPN_"))
/*     */                     {
/* 202 */                       key = key.substring("SAN_OTHER_msUPN_".length());
/*     */                     }
/* 204 */                     else if (!key.equals("CERT_RFC4523_CEA"))
/*     */                     {
/* 206 */                       if (!key.equals("VERIFY")) {}
/*     */                     }
/*     */                   }
/*     */                 }
/* 210 */                 else if (key.startsWith("SSL_SERVER_")) {
/* 211 */                   X509Certificate[] certificates = sslSupport.getLocalCertificateChain();
/* 212 */                   if ((certificates != null) && (certificates.length > 0)) {
/* 213 */                     key = key.substring("SSL_SERVER_".length());
/* 214 */                     String result = resolveSslCertificates(key, certificates);
/* 215 */                     if (result != null)
/* 216 */                       return result;
/* 217 */                     if (key.startsWith("SAN_OTHER_dnsSRV_"))
/*     */                     {
/* 219 */                       key = key.substring("SAN_OTHER_dnsSRV_".length()); }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             } }
/*     */         }
/*     */       }
/*     */     } catch (IOException localIOException) {}
/* 227 */     return null;
/*     */   }
/*     */   
/*     */   private String resolveSslCertificates(String key, X509Certificate[] certificates) {
/* 231 */     if (key.equals("M_VERSION"))
/* 232 */       return String.valueOf(certificates[0].getVersion());
/* 233 */     if (key.equals("M_SERIAL"))
/* 234 */       return certificates[0].getSerialNumber().toString();
/* 235 */     if (key.equals("S_DN"))
/* 236 */       return certificates[0].getSubjectDN().getName();
/* 237 */     if (key.startsWith("S_DN_")) {
/* 238 */       key = key.substring("S_DN_".length());
/* 239 */       return resolveComponent(certificates[0].getSubjectX500Principal().getName(), key); }
/* 240 */     if (key.startsWith("SAN_Email_"))
/*     */     {
/* 242 */       key = key.substring("SAN_Email_".length());
/* 243 */       return resolveAlternateName(certificates[0], 1, Integer.parseInt(key)); }
/* 244 */     if (key.startsWith("SAN_DNS_"))
/*     */     {
/* 246 */       key = key.substring("SAN_DNS_".length());
/* 247 */       return resolveAlternateName(certificates[0], 2, Integer.parseInt(key)); }
/* 248 */     if (key.equals("I_DN"))
/* 249 */       return certificates[0].getIssuerDN().getName();
/* 250 */     if (key.startsWith("I_DN_")) {
/* 251 */       key = key.substring("I_DN_".length());
/* 252 */       return resolveComponent(certificates[0].getIssuerX500Principal().getName(), key); }
/* 253 */     if (key.equals("V_START"))
/* 254 */       return String.valueOf(certificates[0].getNotBefore().getTime());
/* 255 */     if (key.equals("V_END"))
/* 256 */       return String.valueOf(certificates[0].getNotAfter().getTime());
/* 257 */     if (key.equals("V_REMAIN")) {
/* 258 */       long remain = certificates[0].getNotAfter().getTime() - System.currentTimeMillis();
/* 259 */       if (remain < 0L) {
/* 260 */         remain = 0L;
/*     */       }
/*     */       
/* 263 */       return String.valueOf(TimeUnit.MILLISECONDS.toDays(remain)); }
/* 264 */     if (key.equals("A_SIG"))
/* 265 */       return certificates[0].getSigAlgName();
/* 266 */     if (key.equals("A_KEY"))
/* 267 */       return certificates[0].getPublicKey().getAlgorithm();
/* 268 */     if (key.equals("CERT")) {
/*     */       try {
/* 270 */         return PEMFile.toPEM(certificates[0]);
/*     */       }
/*     */       catch (CertificateEncodingException localCertificateEncodingException) {}
/* 273 */     } else if (key.startsWith("CERT_CHAIN_")) {
/* 274 */       key = key.substring("CERT_CHAIN_".length());
/*     */       try {
/* 276 */         return PEMFile.toPEM(certificates[Integer.parseInt(key)]);
/*     */       }
/*     */       catch (NumberFormatException|ArrayIndexOutOfBoundsException|CertificateEncodingException localNumberFormatException) {}
/*     */     }
/*     */     
/*     */ 
/* 282 */     return null;
/*     */   }
/*     */   
/*     */   private String resolveComponent(String fullDN, String component) {
/* 286 */     HashMap<String, String> components = new HashMap();
/* 287 */     StringTokenizer tokenizer = new StringTokenizer(fullDN, ",");
/* 288 */     while (tokenizer.hasMoreElements()) {
/* 289 */       String token = tokenizer.nextToken().trim();
/* 290 */       int pos = token.indexOf('=');
/* 291 */       if ((pos > 0) && (pos + 1 < token.length())) {
/* 292 */         components.put(token.substring(0, pos), token.substring(pos + 1));
/*     */       }
/*     */     }
/* 295 */     return (String)components.get(component);
/*     */   }
/*     */   
/*     */   private String resolveAlternateName(X509Certificate certificate, int type, int n) {
/*     */     try {
/* 300 */       Collection<List<?>> alternateNames = certificate.getSubjectAlternativeNames();
/* 301 */       if (alternateNames != null) {
/* 302 */         List<String> elements = new ArrayList();
/* 303 */         for (List<?> alternateName : alternateNames) {
/* 304 */           Integer alternateNameType = (Integer)alternateName.get(0);
/* 305 */           if (alternateNameType.intValue() == type) {
/* 306 */             elements.add(String.valueOf(alternateName.get(1)));
/*     */           }
/*     */         }
/* 309 */         if (elements.size() > n) {
/* 310 */           return (String)elements.get(n);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (NumberFormatException|ArrayIndexOutOfBoundsException|CertificateParsingException localNumberFormatException) {}
/*     */     
/*     */ 
/* 317 */     return null;
/*     */   }
/*     */   
/*     */   public String resolveHttp(String key)
/*     */   {
/* 322 */     String header = this.request.getHeader(key);
/* 323 */     if (header == null) {
/* 324 */       return "";
/*     */     }
/* 326 */     return header;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean resolveResource(int type, String name)
/*     */   {
/* 332 */     WebResourceRoot resources = this.request.getContext().getResources();
/* 333 */     WebResource resource = resources.getResource(name);
/* 334 */     if (!resource.exists()) {
/* 335 */       return false;
/*     */     }
/* 337 */     switch (type) {
/*     */     case 0: 
/* 339 */       return resource.isDirectory();
/*     */     case 1: 
/* 341 */       return resource.isFile();
/*     */     case 2: 
/* 343 */       return (resource.isFile()) && (resource.getContentLength() > 0L);
/*     */     }
/* 345 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   private static final String emptyStringIfNull(String value)
/*     */   {
/* 351 */     if (value == null) {
/* 352 */       return "";
/*     */     }
/* 354 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */   public Charset getUriCharset()
/*     */   {
/* 360 */     return this.request.getConnector().getURICharset();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\rewrite\ResolverImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */