/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericUser<UD extends UserDatabase>
/*     */   extends AbstractUser
/*     */ {
/*     */   protected final UD database;
/*     */   
/*     */   GenericUser(UD database, String username, String password, String fullName, List<Group> groups, List<Role> roles)
/*     */   {
/*  58 */     this.database = database;
/*  59 */     this.username = username;
/*  60 */     this.password = password;
/*  61 */     this.fullName = fullName;
/*  62 */     if (groups != null) {
/*  63 */       this.groups.addAll(groups);
/*     */     }
/*  65 */     if (roles != null) {
/*  66 */       this.roles.addAll(roles);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */   protected final CopyOnWriteArrayList<Group> groups = new CopyOnWriteArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   protected final CopyOnWriteArrayList<Role> roles = new CopyOnWriteArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<Group> getGroups()
/*     */   {
/* 101 */     return this.groups.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<Role> getRoles()
/*     */   {
/* 110 */     return this.roles.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UserDatabase getUserDatabase()
/*     */   {
/* 119 */     return this.database;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addGroup(Group group)
/*     */   {
/* 133 */     if (this.groups.addIfAbsent(group)) {
/* 134 */       this.database.modifiedUser(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRole(Role role)
/*     */   {
/* 146 */     if (this.roles.addIfAbsent(role)) {
/* 147 */       this.database.modifiedUser(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInGroup(Group group)
/*     */   {
/* 159 */     return this.groups.contains(group);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInRole(Role role)
/*     */   {
/* 172 */     return this.roles.contains(role);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeGroup(Group group)
/*     */   {
/* 183 */     if (this.groups.remove(group)) {
/* 184 */       this.database.modifiedUser(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeGroups()
/*     */   {
/* 194 */     if (!this.groups.isEmpty()) {
/* 195 */       this.groups.clear();
/* 196 */       this.database.modifiedUser(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRole(Role role)
/*     */   {
/* 208 */     if (this.roles.remove(role)) {
/* 209 */       this.database.modifiedUser(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRoles()
/*     */   {
/* 219 */     if (!this.roles.isEmpty()) {
/* 220 */       this.database.modifiedUser(this);
/*     */     }
/* 222 */     this.roles.clear();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setFullName(String fullName)
/*     */   {
/* 228 */     this.database.modifiedUser(this);
/* 229 */     super.setFullName(fullName);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 235 */     this.database.modifiedUser(this);
/* 236 */     super.setPassword(password);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 242 */     this.database.modifiedUser(this);
/*     */     
/* 244 */     super.setUsername(username);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 249 */     if ((obj instanceof GenericUser)) {
/* 250 */       GenericUser<?> user = (GenericUser)obj;
/* 251 */       return (user.database == this.database) && (this.username.equals(user.getUsername()));
/*     */     }
/* 253 */     return super.equals(obj);
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 259 */     int prime = 31;
/* 260 */     int result = 1;
/* 261 */     result = 31 * result + (this.database == null ? 0 : this.database.hashCode());
/* 262 */     result = 31 * result + (this.username == null ? 0 : this.username.hashCode());
/* 263 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\users\GenericUser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */