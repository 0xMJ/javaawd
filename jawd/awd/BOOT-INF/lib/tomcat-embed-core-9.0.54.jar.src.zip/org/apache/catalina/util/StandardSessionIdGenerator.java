/*    */ package org.apache.catalina.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardSessionIdGenerator
/*    */   extends SessionIdGeneratorBase
/*    */ {
/*    */   public String generateSessionId(String route)
/*    */   {
/* 24 */     byte[] random = new byte[16];
/* 25 */     int sessionIdLength = getSessionIdLength();
/*    */     
/*    */ 
/*    */ 
/* 29 */     StringBuilder buffer = new StringBuilder(2 * sessionIdLength + 20);
/*    */     
/* 31 */     int resultLenBytes = 0;
/* 33 */     for (; 
/* 33 */         resultLenBytes < sessionIdLength; 
/*    */         
/*    */ 
/*    */ 
/* 37 */         goto 42)
/*    */     {
/* 34 */       getRandomBytes(random);
/* 35 */       int j = 0;
/* 36 */       if ((j < random.length) && (resultLenBytes < sessionIdLength))
/*    */       {
/* 38 */         byte b1 = (byte)((random[j] & 0xF0) >> 4);
/* 39 */         byte b2 = (byte)(random[j] & 0xF);
/* 40 */         if (b1 < 10) {
/* 41 */           buffer.append((char)(48 + b1));
/*    */         } else {
/* 43 */           buffer.append((char)(65 + (b1 - 10)));
/*    */         }
/* 45 */         if (b2 < 10) {
/* 46 */           buffer.append((char)(48 + b2));
/*    */         } else {
/* 48 */           buffer.append((char)(65 + (b2 - 10)));
/*    */         }
/* 50 */         resultLenBytes++;j++;
/*    */       }
/*    */     }
/*    */     
/* 54 */     if ((route != null) && (route.length() > 0)) {
/* 55 */       buffer.append('.').append(route);
/*    */     } else {
/* 57 */       String jvmRoute = getJvmRoute();
/* 58 */       if ((jvmRoute != null) && (jvmRoute.length() > 0)) {
/* 59 */         buffer.append('.').append(jvmRoute);
/*    */       }
/*    */     }
/*    */     
/* 63 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\StandardSessionIdGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */