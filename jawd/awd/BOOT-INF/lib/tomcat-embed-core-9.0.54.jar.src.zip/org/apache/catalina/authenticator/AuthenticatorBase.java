/*      */ package org.apache.catalina.authenticator;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.security.Principal;
/*      */ import java.util.Iterator;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.Set;
/*      */ import javax.security.auth.Subject;
/*      */ import javax.security.auth.callback.CallbackHandler;
/*      */ import javax.security.auth.message.AuthException;
/*      */ import javax.security.auth.message.AuthStatus;
/*      */ import javax.security.auth.message.MessageInfo;
/*      */ import javax.security.auth.message.config.AuthConfigFactory;
/*      */ import javax.security.auth.message.config.AuthConfigProvider;
/*      */ import javax.security.auth.message.config.RegistrationListener;
/*      */ import javax.security.auth.message.config.ServerAuthConfig;
/*      */ import javax.security.auth.message.config.ServerAuthContext;
/*      */ import javax.servlet.DispatcherType;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.SessionCookieConfig;
/*      */ import javax.servlet.http.Cookie;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.catalina.Authenticator;
/*      */ import org.apache.catalina.Contained;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.Pipeline;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Session;
/*      */ import org.apache.catalina.TomcatPrincipal;
/*      */ import org.apache.catalina.Valve;
/*      */ import org.apache.catalina.authenticator.jaspic.MessageInfoImpl;
/*      */ import org.apache.catalina.connector.Response;
/*      */ import org.apache.catalina.filters.CorsFilter;
/*      */ import org.apache.catalina.realm.GenericPrincipal;
/*      */ import org.apache.catalina.util.SessionIdGeneratorBase;
/*      */ import org.apache.catalina.util.StandardSessionIdGenerator;
/*      */ import org.apache.catalina.valves.ValveBase;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*      */ import org.apache.tomcat.util.descriptor.web.FilterMap;
/*      */ import org.apache.tomcat.util.descriptor.web.LoginConfig;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
/*      */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*      */ import org.apache.tomcat.util.http.RequestUtil;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AuthenticatorBase
/*      */   extends ValveBase
/*      */   implements Authenticator, RegistrationListener
/*      */ {
/*   95 */   private final Log log = LogFactory.getLog(AuthenticatorBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  100 */   private static final String DATE_ONE = FastHttpDateFormat.formatDate(1L);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  105 */   protected static final StringManager sm = StringManager.getManager(AuthenticatorBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */   protected static final String AUTH_HEADER_NAME = "WWW-Authenticate";
/*      */   
/*      */ 
/*      */   protected static final String REALM_NAME = "Authentication required";
/*      */   
/*      */ 
/*      */ 
/*      */   protected static String getRealmName(Context context)
/*      */   {
/*  118 */     if (context == null)
/*      */     {
/*  120 */       return "Authentication required";
/*      */     }
/*      */     
/*  123 */     LoginConfig config = context.getLoginConfig();
/*  124 */     if (config == null) {
/*  125 */       return "Authentication required";
/*      */     }
/*      */     
/*  128 */     String result = config.getRealmName();
/*  129 */     if (result == null) {
/*  130 */       return "Authentication required";
/*      */     }
/*      */     
/*  133 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   public AuthenticatorBase()
/*      */   {
/*  139 */     super(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  154 */   protected boolean alwaysUseSession = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  160 */   protected boolean cache = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  166 */   protected boolean changeSessionIdOnAuthentication = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  171 */   protected Context context = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  177 */   protected boolean disableProxyCaching = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  183 */   protected boolean securePagesWithPragma = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  192 */   protected String secureRandomClass = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  203 */   protected String secureRandomAlgorithm = "SHA1PRNG";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  213 */   protected String secureRandomProvider = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  220 */   protected String jaspicCallbackHandlerClass = "org.apache.catalina.authenticator.jaspic.CallbackHandlerImpl";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  233 */   protected boolean sendAuthInfoResponseHeaders = false;
/*      */   
/*  235 */   protected SessionIdGeneratorBase sessionIdGenerator = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  241 */   protected SingleSignOn sso = null;
/*      */   
/*  243 */   private AllowCorsPreflight allowCorsPreflight = AllowCorsPreflight.NEVER;
/*      */   
/*  245 */   private volatile String jaspicAppContextID = null;
/*  246 */   private volatile Optional<AuthConfigProvider> jaspicProvider = null;
/*  247 */   private volatile CallbackHandler jaspicCallbackHandler = null;
/*      */   
/*      */ 
/*      */ 
/*      */   public String getAllowCorsPreflight()
/*      */   {
/*  253 */     return this.allowCorsPreflight.name().toLowerCase(Locale.ENGLISH);
/*      */   }
/*      */   
/*      */   public void setAllowCorsPreflight(String allowCorsPreflight) {
/*  257 */     this.allowCorsPreflight = AllowCorsPreflight.valueOf(allowCorsPreflight.trim().toUpperCase(Locale.ENGLISH));
/*      */   }
/*      */   
/*      */   public boolean getAlwaysUseSession() {
/*  261 */     return this.alwaysUseSession;
/*      */   }
/*      */   
/*      */   public void setAlwaysUseSession(boolean alwaysUseSession) {
/*  265 */     this.alwaysUseSession = alwaysUseSession;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getCache()
/*      */   {
/*  275 */     return this.cache;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCache(boolean cache)
/*      */   {
/*  285 */     this.cache = cache;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Container getContainer()
/*      */   {
/*  293 */     return this.context;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContainer(Container container)
/*      */   {
/*  305 */     if ((container != null) && (!(container instanceof Context))) {
/*  306 */       throw new IllegalArgumentException(sm.getString("authenticator.notContext"));
/*      */     }
/*      */     
/*  309 */     super.setContainer(container);
/*  310 */     this.context = ((Context)container);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDisableProxyCaching()
/*      */   {
/*  322 */     return this.disableProxyCaching;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDisableProxyCaching(boolean nocache)
/*      */   {
/*  334 */     this.disableProxyCaching = nocache;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSecurePagesWithPragma()
/*      */   {
/*  345 */     return this.securePagesWithPragma;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecurePagesWithPragma(boolean securePagesWithPragma)
/*      */   {
/*  358 */     this.securePagesWithPragma = securePagesWithPragma;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getChangeSessionIdOnAuthentication()
/*      */   {
/*  369 */     return this.changeSessionIdOnAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setChangeSessionIdOnAuthentication(boolean changeSessionIdOnAuthentication)
/*      */   {
/*  381 */     this.changeSessionIdOnAuthentication = changeSessionIdOnAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecureRandomClass()
/*      */   {
/*  391 */     return this.secureRandomClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureRandomClass(String secureRandomClass)
/*      */   {
/*  401 */     this.secureRandomClass = secureRandomClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecureRandomAlgorithm()
/*      */   {
/*  410 */     return this.secureRandomAlgorithm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureRandomAlgorithm(String secureRandomAlgorithm)
/*      */   {
/*  420 */     this.secureRandomAlgorithm = secureRandomAlgorithm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecureRandomProvider()
/*      */   {
/*  429 */     return this.secureRandomProvider;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureRandomProvider(String secureRandomProvider)
/*      */   {
/*  439 */     this.secureRandomProvider = secureRandomProvider;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getJaspicCallbackHandlerClass()
/*      */   {
/*  448 */     return this.jaspicCallbackHandlerClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setJaspicCallbackHandlerClass(String jaspicCallbackHandlerClass)
/*      */   {
/*  458 */     this.jaspicCallbackHandlerClass = jaspicCallbackHandlerClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSendAuthInfoResponseHeaders()
/*      */   {
/*  468 */     return this.sendAuthInfoResponseHeaders;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSendAuthInfoResponseHeaders(boolean sendAuthInfoResponseHeaders)
/*      */   {
/*  479 */     this.sendAuthInfoResponseHeaders = sendAuthInfoResponseHeaders;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void invoke(org.apache.catalina.connector.Request request, Response response)
/*      */     throws IOException, ServletException
/*      */   {
/*  501 */     if (this.log.isDebugEnabled()) {
/*  502 */       this.log.debug("Security checking request " + request.getMethod() + " " + request
/*  503 */         .getRequestURI());
/*      */     }
/*      */     
/*      */ 
/*  507 */     if (this.cache) {
/*  508 */       Principal principal = request.getUserPrincipal();
/*  509 */       if (principal == null) {
/*  510 */         Session session = request.getSessionInternal(false);
/*  511 */         if (session != null) {
/*  512 */           principal = session.getPrincipal();
/*  513 */           if (principal != null) {
/*  514 */             if (this.log.isDebugEnabled()) {
/*  515 */               this.log.debug("We have cached auth type " + session.getAuthType() + " for principal " + principal);
/*      */             }
/*      */             
/*  518 */             request.setAuthType(session.getAuthType());
/*  519 */             request.setUserPrincipal(principal);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  525 */     boolean authRequired = isContinuationRequired(request);
/*      */     
/*  527 */     Realm realm = this.context.getRealm();
/*      */     
/*  529 */     SecurityConstraint[] constraints = realm.findSecurityConstraints(request, this.context);
/*      */     
/*  531 */     AuthConfigProvider jaspicProvider = getJaspicProvider();
/*  532 */     if (jaspicProvider != null) {
/*  533 */       authRequired = true;
/*      */     }
/*      */     
/*  536 */     if ((constraints == null) && (!this.context.getPreemptiveAuthentication()) && (!authRequired)) {
/*  537 */       if (this.log.isDebugEnabled()) {
/*  538 */         this.log.debug("Not subject to any constraint");
/*      */       }
/*  540 */       getNext().invoke(request, response);
/*  541 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  546 */     if ((constraints != null) && (this.disableProxyCaching) && 
/*  547 */       (!"POST".equalsIgnoreCase(request.getMethod()))) {
/*  548 */       if (this.securePagesWithPragma)
/*      */       {
/*  550 */         response.setHeader("Pragma", "No-cache");
/*  551 */         response.setHeader("Cache-Control", "no-cache");
/*  552 */         response.setHeader("Expires", DATE_ONE);
/*      */       } else {
/*  554 */         response.setHeader("Cache-Control", "private");
/*      */       }
/*      */     }
/*      */     
/*  558 */     if (constraints != null)
/*      */     {
/*  560 */       if (this.log.isDebugEnabled()) {
/*  561 */         this.log.debug("Calling hasUserDataPermission()");
/*      */       }
/*  563 */       if (!realm.hasUserDataPermission(request, response, constraints)) {
/*  564 */         if (this.log.isDebugEnabled()) {
/*  565 */           this.log.debug("Failed hasUserDataPermission() test");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  571 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  577 */     boolean hasAuthConstraint = false;
/*  578 */     if (constraints != null) {
/*  579 */       hasAuthConstraint = true;
/*  580 */       for (int i = 0; (i < constraints.length) && (hasAuthConstraint); i++) {
/*  581 */         if (!constraints[i].getAuthConstraint()) {
/*  582 */           hasAuthConstraint = false;
/*  583 */         } else if ((!constraints[i].getAllRoles()) && 
/*  584 */           (!constraints[i].getAuthenticatedUsers())) {
/*  585 */           String[] roles = constraints[i].findAuthRoles();
/*  586 */           if ((roles == null) || (roles.length == 0)) {
/*  587 */             hasAuthConstraint = false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  593 */     if ((!authRequired) && (hasAuthConstraint)) {
/*  594 */       authRequired = true;
/*      */     }
/*      */     
/*  597 */     if ((!authRequired) && (this.context.getPreemptiveAuthentication()) && 
/*  598 */       (isPreemptiveAuthPossible(request))) {
/*  599 */       authRequired = true;
/*      */     }
/*      */     
/*  602 */     JaspicState jaspicState = null;
/*      */     
/*  604 */     if (((authRequired) || (constraints != null)) && (allowCorsPreflightBypass(request))) {
/*  605 */       if (this.log.isDebugEnabled()) {
/*  606 */         this.log.debug("CORS Preflight request bypassing authentication");
/*      */       }
/*  608 */       getNext().invoke(request, response);
/*  609 */       return;
/*      */     }
/*      */     
/*  612 */     if (authRequired) {
/*  613 */       if (this.log.isDebugEnabled()) {
/*  614 */         this.log.debug("Calling authenticate()");
/*      */       }
/*      */       
/*  617 */       if (jaspicProvider != null) {
/*  618 */         jaspicState = getJaspicState(jaspicProvider, request, response, hasAuthConstraint);
/*  619 */         if (jaspicState == null) {
/*  620 */           return;
/*      */         }
/*      */       }
/*      */       
/*  624 */       if ((jaspicProvider != null) || (doAuthenticate(request, response))) { if (jaspicProvider != null)
/*      */         {
/*  626 */           if (authenticateJaspic(request, response, jaspicState, false)) {} }
/*  627 */       } else { if (this.log.isDebugEnabled()) {
/*  628 */           this.log.debug("Failed authenticate() test");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  634 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  639 */     if (constraints != null) {
/*  640 */       if (this.log.isDebugEnabled()) {
/*  641 */         this.log.debug("Calling accessControl()");
/*      */       }
/*  643 */       if (!realm.hasResourcePermission(request, response, constraints, this.context)) {
/*  644 */         if (this.log.isDebugEnabled()) {
/*  645 */           this.log.debug("Failed accessControl() test");
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  651 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  656 */     if (this.log.isDebugEnabled()) {
/*  657 */       this.log.debug("Successfully passed all security constraints");
/*      */     }
/*  659 */     getNext().invoke(request, response);
/*      */     
/*  661 */     if (jaspicProvider != null) {
/*  662 */       secureResponseJspic(request, response, jaspicState);
/*      */     }
/*      */   }
/*      */   
/*      */   protected boolean allowCorsPreflightBypass(org.apache.catalina.connector.Request request)
/*      */   {
/*  668 */     boolean allowBypass = false;
/*      */     
/*  670 */     if (this.allowCorsPreflight != AllowCorsPreflight.NEVER)
/*      */     {
/*      */ 
/*  673 */       if ("OPTIONS".equals(request.getMethod())) {
/*  674 */         String originHeader = request.getHeader("Origin");
/*  675 */         if ((originHeader != null) && 
/*  676 */           (!originHeader.isEmpty()) && 
/*  677 */           (RequestUtil.isValidOrigin(originHeader)) && 
/*  678 */           (!RequestUtil.isSameOrigin(request, originHeader)))
/*      */         {
/*  680 */           String accessControlRequestMethodHeader = request.getHeader("Access-Control-Request-Method");
/*  681 */           if ((accessControlRequestMethodHeader != null) && 
/*  682 */             (!accessControlRequestMethodHeader.isEmpty()))
/*      */           {
/*  684 */             if (this.allowCorsPreflight == AllowCorsPreflight.ALWAYS) {
/*  685 */               allowBypass = true;
/*  686 */             } else if ((this.allowCorsPreflight == AllowCorsPreflight.FILTER) && 
/*  687 */               (DispatcherType.REQUEST == request.getDispatcherType()))
/*      */             {
/*      */ 
/*      */ 
/*  691 */               for (FilterDef filterDef : request.getContext().findFilterDefs()) {
/*  692 */                 if (CorsFilter.class.getName().equals(filterDef.getFilterClass())) {
/*  693 */                   for (FilterMap filterMap : this.context.findFilterMaps()) {
/*  694 */                     if (filterMap.getFilterName().equals(filterDef.getFilterName())) {
/*  695 */                       if ((filterMap.getDispatcherMapping() & 0x8) <= 0) break;
/*  696 */                       for (String urlPattern : filterMap.getURLPatterns()) {
/*  697 */                         if ("/*".equals(urlPattern)) {
/*  698 */                           allowBypass = true;
/*      */                           
/*  700 */                           break;
/*      */                         }
/*      */                       }
/*      */                       
/*      */ 
/*      */                       break;
/*      */                     }
/*      */                   }
/*      */                   
/*      */ 
/*  710 */                   break;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  721 */     return allowBypass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean authenticate(org.apache.catalina.connector.Request request, HttpServletResponse httpResponse)
/*      */     throws IOException
/*      */   {
/*  729 */     AuthConfigProvider jaspicProvider = getJaspicProvider();
/*      */     
/*  731 */     if (jaspicProvider == null) {
/*  732 */       return doAuthenticate(request, httpResponse);
/*      */     }
/*  734 */     Response response = request.getResponse();
/*  735 */     JaspicState jaspicState = getJaspicState(jaspicProvider, request, response, true);
/*  736 */     if (jaspicState == null) {
/*  737 */       return false;
/*      */     }
/*      */     
/*  740 */     boolean result = authenticateJaspic(request, response, jaspicState, true);
/*      */     
/*  742 */     secureResponseJspic(request, response, jaspicState);
/*      */     
/*  744 */     return result;
/*      */   }
/*      */   
/*      */   private void secureResponseJspic(org.apache.catalina.connector.Request request, Response response, JaspicState state)
/*      */   {
/*      */     try
/*      */     {
/*  751 */       state.serverAuthContext.secureResponse(state.messageInfo, null);
/*  752 */       request.setRequest((HttpServletRequest)state.messageInfo.getRequestMessage());
/*  753 */       response.setResponse((HttpServletResponse)state.messageInfo.getResponseMessage());
/*      */     } catch (AuthException e) {
/*  755 */       this.log.warn(sm.getString("authenticator.jaspicSecureResponseFail"), e);
/*      */     }
/*      */   }
/*      */   
/*      */   private JaspicState getJaspicState(AuthConfigProvider jaspicProvider, org.apache.catalina.connector.Request request, Response response, boolean authMandatory)
/*      */     throws IOException
/*      */   {
/*  762 */     JaspicState jaspicState = new JaspicState(null);
/*      */     
/*      */ 
/*  765 */     jaspicState.messageInfo = new MessageInfoImpl(request.getRequest(), response.getResponse(), authMandatory);
/*      */     try
/*      */     {
/*  768 */       CallbackHandler callbackHandler = getCallbackHandler();
/*  769 */       ServerAuthConfig serverAuthConfig = jaspicProvider.getServerAuthConfig("HttpServlet", this.jaspicAppContextID, callbackHandler);
/*      */       
/*  771 */       String authContextID = serverAuthConfig.getAuthContextID(jaspicState.messageInfo);
/*  772 */       jaspicState.serverAuthContext = serverAuthConfig.getAuthContext(authContextID, null, null);
/*      */     } catch (AuthException e) {
/*  774 */       this.log.warn(sm.getString("authenticator.jaspicServerAuthContextFail"), e);
/*  775 */       response.sendError(500);
/*  776 */       return null;
/*      */     }
/*      */     
/*  779 */     return jaspicState;
/*      */   }
/*      */   
/*      */   private CallbackHandler getCallbackHandler()
/*      */   {
/*  784 */     CallbackHandler handler = this.jaspicCallbackHandler;
/*  785 */     if (handler == null) {
/*  786 */       handler = createCallbackHandler();
/*      */     }
/*  788 */     return handler;
/*      */   }
/*      */   
/*      */   private CallbackHandler createCallbackHandler()
/*      */   {
/*  793 */     CallbackHandler callbackHandler = null;
/*      */     
/*  795 */     Class<?> clazz = null;
/*      */     try {
/*  797 */       clazz = Class.forName(this.jaspicCallbackHandlerClass, true, 
/*  798 */         Thread.currentThread().getContextClassLoader());
/*      */     }
/*      */     catch (ClassNotFoundException localClassNotFoundException) {}
/*      */     
/*      */     try
/*      */     {
/*  804 */       if (clazz == null) {
/*  805 */         clazz = Class.forName(this.jaspicCallbackHandlerClass);
/*      */       }
/*  807 */       callbackHandler = (CallbackHandler)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */     } catch (ReflectiveOperationException e) {
/*  809 */       throw new SecurityException(e);
/*      */     }
/*      */     
/*  812 */     if ((callbackHandler instanceof Contained)) {
/*  813 */       ((Contained)callbackHandler).setContainer(getContainer());
/*      */     }
/*      */     
/*  816 */     this.jaspicCallbackHandler = callbackHandler;
/*  817 */     return callbackHandler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected abstract boolean doAuthenticate(org.apache.catalina.connector.Request paramRequest, HttpServletResponse paramHttpServletResponse)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isContinuationRequired(org.apache.catalina.connector.Request request)
/*      */   {
/*  852 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void associate(String ssoId, Session session)
/*      */   {
/*  867 */     if (this.sso == null) {
/*  868 */       return;
/*      */     }
/*  870 */     this.sso.associate(ssoId, session);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean authenticateJaspic(org.apache.catalina.connector.Request request, Response response, JaspicState state, boolean requirePrincipal)
/*      */   {
/*  878 */     boolean cachedAuth = checkForCachedAuthentication(request, response, false);
/*  879 */     Subject client = new Subject();
/*      */     try
/*      */     {
/*  882 */       authStatus = state.serverAuthContext.validateRequest(state.messageInfo, client, null);
/*      */     } catch (AuthException e) { AuthStatus authStatus;
/*  884 */       this.log.debug(sm.getString("authenticator.loginFail"), e);
/*  885 */       return false;
/*      */     }
/*      */     AuthStatus authStatus;
/*  888 */     request.setRequest((HttpServletRequest)state.messageInfo.getRequestMessage());
/*  889 */     response.setResponse((HttpServletResponse)state.messageInfo.getResponseMessage());
/*      */     
/*  891 */     if (authStatus == AuthStatus.SUCCESS) {
/*  892 */       GenericPrincipal principal = getPrincipal(client);
/*  893 */       if (this.log.isDebugEnabled()) {
/*  894 */         this.log.debug("Authenticated user: " + principal);
/*      */       }
/*  896 */       if (principal == null) {
/*  897 */         request.setUserPrincipal(null);
/*  898 */         request.setAuthType(null);
/*  899 */         if (requirePrincipal) {
/*  900 */           return false;
/*      */         }
/*  902 */       } else if ((!cachedAuth) || (!principal.getUserPrincipal().equals(request.getUserPrincipal())))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  907 */         Boolean register = null;
/*  908 */         String authType = "JASPIC";
/*      */         
/*  910 */         Map map = state.messageInfo.getMap();
/*      */         
/*  912 */         String registerValue = (String)map.get("javax.servlet.http.registerSession");
/*  913 */         if (registerValue != null) {
/*  914 */           register = Boolean.valueOf(registerValue);
/*      */         }
/*  916 */         String authTypeValue = (String)map.get("javax.servlet.http.authType");
/*  917 */         if (authTypeValue != null) {
/*  918 */           authType = authTypeValue;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  928 */         if (register != null) {
/*  929 */           register(request, response, principal, authType, null, null, (this.alwaysUseSession) || 
/*  930 */             (register.booleanValue()), register.booleanValue());
/*      */         } else {
/*  932 */           register(request, response, principal, authType, null, null);
/*      */         }
/*      */       }
/*  935 */       request.setNote("org.apache.catalina.authenticator.jaspic.SUBJECT", client);
/*  936 */       return true;
/*      */     }
/*  938 */     return false;
/*      */   }
/*      */   
/*      */   private GenericPrincipal getPrincipal(Subject subject)
/*      */   {
/*  943 */     if (subject == null) {
/*  944 */       return null;
/*      */     }
/*      */     
/*  947 */     Set<GenericPrincipal> principals = subject.getPrivateCredentials(GenericPrincipal.class);
/*  948 */     if (principals.isEmpty()) {
/*  949 */       return null;
/*      */     }
/*      */     
/*  952 */     return (GenericPrincipal)principals.iterator().next();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean checkForCachedAuthentication(org.apache.catalina.connector.Request request, HttpServletResponse response, boolean useSSO)
/*      */   {
/*  975 */     Principal principal = request.getUserPrincipal();
/*  976 */     String ssoId = (String)request.getNote("org.apache.catalina.request.SSOID");
/*  977 */     if (principal != null) {
/*  978 */       if (this.log.isDebugEnabled()) {
/*  979 */         this.log.debug(sm.getString("authenticator.check.found", new Object[] { principal.getName() }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  984 */       if (ssoId != null) {
/*  985 */         associate(ssoId, request.getSessionInternal(true));
/*      */       }
/*  987 */       return true;
/*      */     }
/*      */     
/*      */ 
/*  991 */     if ((useSSO) && (ssoId != null)) {
/*  992 */       if (this.log.isDebugEnabled()) {
/*  993 */         this.log.debug(sm.getString("authenticator.check.sso", new Object[] { ssoId }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1003 */       if (reauthenticateFromSSO(ssoId, request)) {
/* 1004 */         return true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1010 */     if (request.getCoyoteRequest().getRemoteUserNeedsAuthorization()) {
/* 1011 */       String username = request.getCoyoteRequest().getRemoteUser().toString();
/* 1012 */       if (username != null) {
/* 1013 */         if (this.log.isDebugEnabled()) {
/* 1014 */           this.log.debug(sm.getString("authenticator.check.authorize", new Object[] { username }));
/*      */         }
/* 1016 */         Principal authorized = this.context.getRealm().authenticate(username);
/* 1017 */         if (authorized == null)
/*      */         {
/*      */ 
/* 1020 */           if (this.log.isDebugEnabled()) {
/* 1021 */             this.log.debug(sm.getString("authenticator.check.authorizeFail", new Object[] { username }));
/*      */           }
/* 1023 */           authorized = new GenericPrincipal(username, null, null);
/*      */         }
/* 1025 */         String authType = request.getAuthType();
/* 1026 */         if ((authType == null) || (authType.length() == 0)) {
/* 1027 */           authType = getAuthMethod();
/*      */         }
/* 1029 */         register(request, response, authorized, authType, username, null);
/* 1030 */         return true;
/*      */       }
/*      */     }
/* 1033 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean reauthenticateFromSSO(String ssoId, org.apache.catalina.connector.Request request)
/*      */   {
/* 1049 */     if ((this.sso == null) || (ssoId == null)) {
/* 1050 */       return false;
/*      */     }
/*      */     
/* 1053 */     boolean reauthenticated = false;
/*      */     
/* 1055 */     Container parent = getContainer();
/* 1056 */     if (parent != null) {
/* 1057 */       Realm realm = parent.getRealm();
/* 1058 */       if (realm != null) {
/* 1059 */         reauthenticated = this.sso.reauthenticate(ssoId, realm, request);
/*      */       }
/*      */     }
/*      */     
/* 1063 */     if (reauthenticated) {
/* 1064 */       associate(ssoId, request.getSessionInternal(true));
/*      */       
/* 1066 */       if (this.log.isDebugEnabled()) {
/* 1067 */         this.log.debug("Reauthenticated cached principal '" + request
/* 1068 */           .getUserPrincipal().getName() + "' with auth type '" + request
/* 1069 */           .getAuthType() + "'");
/*      */       }
/*      */     }
/*      */     
/* 1073 */     return reauthenticated;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void register(org.apache.catalina.connector.Request request, HttpServletResponse response, Principal principal, String authType, String username, String password)
/*      */   {
/* 1097 */     register(request, response, principal, authType, username, password, this.alwaysUseSession, this.cache);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void register(org.apache.catalina.connector.Request request, HttpServletResponse response, Principal principal, String authType, String username, String password, boolean alwaysUseSession, boolean cache)
/*      */   {
/* 1129 */     if (this.log.isDebugEnabled()) {
/* 1130 */       String name = principal == null ? "none" : principal.getName();
/* 1131 */       this.log.debug("Authenticated '" + name + "' with type '" + authType + "'");
/*      */     }
/*      */     
/*      */ 
/* 1135 */     request.setAuthType(authType);
/* 1136 */     request.setUserPrincipal(principal);
/*      */     
/* 1138 */     if ((this.sendAuthInfoResponseHeaders) && 
/* 1139 */       (Boolean.TRUE.equals(request.getAttribute("org.apache.tomcat.request.forwarded")))) {
/* 1140 */       response.setHeader("remote-user", request.getRemoteUser());
/* 1141 */       response.setHeader("auth-type", request.getAuthType());
/*      */     }
/*      */     
/* 1144 */     Session session = request.getSessionInternal(false);
/*      */     
/* 1146 */     if (session != null)
/*      */     {
/*      */ 
/* 1149 */       if ((getChangeSessionIdOnAuthentication()) && (principal != null)) {
/* 1150 */         String newSessionId = changeSessionID(request, session);
/*      */         
/* 1152 */         if (session.getNote("org.apache.catalina.authenticator.SESSION_ID") != null) {
/* 1153 */           session.setNote("org.apache.catalina.authenticator.SESSION_ID", newSessionId);
/*      */         }
/*      */       }
/* 1156 */     } else if (alwaysUseSession) {
/* 1157 */       session = request.getSessionInternal(true);
/*      */     }
/*      */     
/*      */ 
/* 1161 */     if ((session != null) && (cache)) {
/* 1162 */       session.setAuthType(authType);
/* 1163 */       session.setPrincipal(principal);
/*      */     }
/*      */     
/*      */ 
/* 1167 */     if (this.sso == null) {
/* 1168 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1174 */     String ssoId = (String)request.getNote("org.apache.catalina.request.SSOID");
/* 1175 */     if (ssoId == null)
/*      */     {
/* 1177 */       ssoId = this.sessionIdGenerator.generateSessionId();
/* 1178 */       Cookie cookie = new Cookie(this.sso.getCookieName(), ssoId);
/* 1179 */       cookie.setMaxAge(-1);
/* 1180 */       cookie.setPath("/");
/*      */       
/*      */ 
/* 1183 */       cookie.setSecure(request.isSecure());
/*      */       
/*      */ 
/* 1186 */       String ssoDomain = this.sso.getCookieDomain();
/* 1187 */       if (ssoDomain != null) {
/* 1188 */         cookie.setDomain(ssoDomain);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1193 */       if ((request.getServletContext().getSessionCookieConfig().isHttpOnly()) || 
/* 1194 */         (request.getContext().getUseHttpOnly())) {
/* 1195 */         cookie.setHttpOnly(true);
/*      */       }
/*      */       
/* 1198 */       response.addCookie(cookie);
/*      */       
/*      */ 
/* 1201 */       this.sso.register(ssoId, principal, authType, username, password);
/* 1202 */       request.setNote("org.apache.catalina.request.SSOID", ssoId);
/*      */     }
/*      */     else {
/* 1205 */       if (principal == null)
/*      */       {
/* 1207 */         this.sso.deregister(ssoId);
/* 1208 */         request.removeNote("org.apache.catalina.request.SSOID");
/* 1209 */         return;
/*      */       }
/*      */       
/* 1212 */       this.sso.update(ssoId, principal, authType, username, password);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1222 */     if (session == null) {
/* 1223 */       session = request.getSessionInternal(true);
/*      */     }
/* 1225 */     this.sso.associate(ssoId, session);
/*      */   }
/*      */   
/*      */ 
/*      */   protected String changeSessionID(org.apache.catalina.connector.Request request, Session session)
/*      */   {
/* 1231 */     String oldId = null;
/* 1232 */     if (this.log.isDebugEnabled()) {
/* 1233 */       oldId = session.getId();
/*      */     }
/* 1235 */     String newId = request.changeSessionId();
/* 1236 */     if (this.log.isDebugEnabled()) {
/* 1237 */       this.log.debug(sm.getString("authenticator.changeSessionId", new Object[] { oldId, newId }));
/*      */     }
/* 1239 */     return newId;
/*      */   }
/*      */   
/*      */   public void login(String username, String password, org.apache.catalina.connector.Request request)
/*      */     throws ServletException
/*      */   {
/* 1245 */     Principal principal = doLogin(request, username, password);
/* 1246 */     register(request, request.getResponse(), principal, getAuthMethod(), username, password);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected abstract String getAuthMethod();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Principal doLogin(org.apache.catalina.connector.Request request, String username, String password)
/*      */     throws ServletException
/*      */   {
/* 1266 */     Principal p = this.context.getRealm().authenticate(username, password);
/* 1267 */     if (p == null) {
/* 1268 */       throw new ServletException(sm.getString("authenticator.loginFail"));
/*      */     }
/* 1270 */     return p;
/*      */   }
/*      */   
/*      */   public void logout(org.apache.catalina.connector.Request request)
/*      */   {
/* 1275 */     AuthConfigProvider provider = getJaspicProvider();
/* 1276 */     if (provider != null) {
/* 1277 */       MessageInfo messageInfo = new MessageInfoImpl(request, request.getResponse(), true);
/* 1278 */       Subject client = (Subject)request.getNote("org.apache.catalina.authenticator.jaspic.SUBJECT");
/* 1279 */       if (client != null) {
/*      */         try
/*      */         {
/* 1282 */           ServerAuthConfig serverAuthConfig = provider.getServerAuthConfig("HttpServlet", this.jaspicAppContextID, 
/* 1283 */             getCallbackHandler());
/* 1284 */           String authContextID = serverAuthConfig.getAuthContextID(messageInfo);
/* 1285 */           ServerAuthContext serverAuthContext = serverAuthConfig.getAuthContext(authContextID, null, null);
/* 1286 */           serverAuthContext.cleanSubject(messageInfo, client);
/*      */         } catch (AuthException e) {
/* 1288 */           this.log.debug(sm.getString("authenticator.jaspicCleanSubjectFail"), e);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1293 */     Principal p = request.getPrincipal();
/* 1294 */     if ((p instanceof TomcatPrincipal)) {
/*      */       try {
/* 1296 */         ((TomcatPrincipal)p).logout();
/*      */       } catch (Throwable t) {
/* 1298 */         ExceptionUtils.handleThrowable(t);
/* 1299 */         this.log.debug(sm.getString("authenticator.tomcatPrincipalLogoutFail"), t);
/*      */       }
/*      */     }
/*      */     
/* 1303 */     register(request, request.getResponse(), null, null, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void startInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1317 */     ServletContext servletContext = this.context.getServletContext();
/*      */     
/* 1319 */     this.jaspicAppContextID = (servletContext.getVirtualServerName() + " " + servletContext.getContextPath());
/*      */     
/*      */ 
/*      */ 
/* 1323 */     Container parent = this.context.getParent();
/* 1324 */     while ((this.sso == null) && (parent != null)) {
/* 1325 */       Valve[] valves = parent.getPipeline().getValves();
/* 1326 */       for (Valve valve : valves) {
/* 1327 */         if ((valve instanceof SingleSignOn)) {
/* 1328 */           this.sso = ((SingleSignOn)valve);
/* 1329 */           break;
/*      */         }
/*      */       }
/* 1332 */       if (this.sso == null) {
/* 1333 */         parent = parent.getParent();
/*      */       }
/*      */     }
/* 1336 */     if (this.log.isDebugEnabled()) {
/* 1337 */       if (this.sso != null) {
/* 1338 */         this.log.debug("Found SingleSignOn Valve at " + this.sso);
/*      */       } else {
/* 1340 */         this.log.debug("No SingleSignOn Valve is present");
/*      */       }
/*      */     }
/*      */     
/* 1344 */     this.sessionIdGenerator = new StandardSessionIdGenerator();
/* 1345 */     this.sessionIdGenerator.setSecureRandomAlgorithm(getSecureRandomAlgorithm());
/* 1346 */     this.sessionIdGenerator.setSecureRandomClass(getSecureRandomClass());
/* 1347 */     this.sessionIdGenerator.setSecureRandomProvider(getSecureRandomProvider());
/*      */     
/* 1349 */     super.startInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1364 */     super.stopInternal();
/*      */     
/* 1366 */     this.sso = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isPreemptiveAuthPossible(org.apache.catalina.connector.Request request)
/*      */   {
/* 1380 */     return false;
/*      */   }
/*      */   
/*      */   private AuthConfigProvider getJaspicProvider()
/*      */   {
/* 1385 */     Optional<AuthConfigProvider> provider = this.jaspicProvider;
/* 1386 */     if (provider == null) {
/* 1387 */       provider = findJaspicProvider();
/*      */     }
/* 1389 */     return (AuthConfigProvider)provider.orElse(null);
/*      */   }
/*      */   
/*      */   private Optional<AuthConfigProvider> findJaspicProvider()
/*      */   {
/* 1394 */     AuthConfigFactory factory = AuthConfigFactory.getFactory();
/*      */     Optional<AuthConfigProvider> provider;
/* 1396 */     Optional<AuthConfigProvider> provider; if (factory == null) {
/* 1397 */       provider = Optional.empty();
/*      */     } else {
/* 1399 */       provider = Optional.ofNullable(factory
/* 1400 */         .getConfigProvider("HttpServlet", this.jaspicAppContextID, this));
/*      */     }
/* 1402 */     this.jaspicProvider = provider;
/* 1403 */     return provider;
/*      */   }
/*      */   
/*      */ 
/*      */   public void notify(String layer, String appContext)
/*      */   {
/* 1409 */     findJaspicProvider();
/*      */   }
/*      */   
/*      */   private static class JaspicState
/*      */   {
/* 1414 */     public MessageInfo messageInfo = null;
/* 1415 */     public ServerAuthContext serverAuthContext = null;
/*      */   }
/*      */   
/*      */   protected static enum AllowCorsPreflight
/*      */   {
/* 1420 */     NEVER, 
/* 1421 */     FILTER, 
/* 1422 */     ALWAYS;
/*      */     
/*      */     private AllowCorsPreflight() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\authenticator\AuthenticatorBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */