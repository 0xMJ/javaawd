/*      */ package org.apache.catalina.connector;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.InetAddress;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashSet;
/*      */ import javax.management.ObjectName;
/*      */ import org.apache.catalina.Executor;
/*      */ import org.apache.catalina.Globals;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.core.AprLifecycleListener;
/*      */ import org.apache.catalina.core.AprStatus;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.coyote.AbstractProtocol;
/*      */ import org.apache.coyote.Adapter;
/*      */ import org.apache.coyote.ProtocolHandler;
/*      */ import org.apache.coyote.UpgradeProtocol;
/*      */ import org.apache.coyote.ajp.AjpAprProtocol;
/*      */ import org.apache.coyote.ajp.AjpNioProtocol;
/*      */ import org.apache.coyote.http11.AbstractHttp11JsseProtocol;
/*      */ import org.apache.coyote.http11.Http11AprProtocol;
/*      */ import org.apache.coyote.http11.Http11NioProtocol;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.IntrospectionUtils;
/*      */ import org.apache.tomcat.util.buf.B2CConverter;
/*      */ import org.apache.tomcat.util.buf.CharsetUtil;
/*      */ import org.apache.tomcat.util.buf.EncodedSolidusHandling;
/*      */ import org.apache.tomcat.util.buf.UDecoder;
/*      */ import org.apache.tomcat.util.net.SSLHostConfig;
/*      */ import org.apache.tomcat.util.net.openssl.OpenSSLImplementation;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Connector
/*      */   extends LifecycleMBeanBase
/*      */ {
/*   60 */   private static final Log log = LogFactory.getLog(Connector.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   67 */   public static final boolean RECYCLE_FACADES = Boolean.parseBoolean(System.getProperty("org.apache.catalina.connector.RECYCLE_FACADES", "false"));
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String INTERNAL_EXECUTOR_NAME = "Internal";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Connector()
/*      */   {
/*   79 */     this("HTTP/1.1");
/*      */   }
/*      */   
/*      */ 
/*      */   public Connector(String protocol)
/*      */   {
/*   85 */     boolean apr = (AprStatus.getUseAprConnector()) && (AprStatus.isInstanceCreated()) && (AprLifecycleListener.isAprAvailable());
/*   86 */     ProtocolHandler p = null;
/*      */     try {
/*   88 */       p = ProtocolHandler.create(protocol, apr);
/*      */     } catch (Exception e) {
/*   90 */       log.error(sm.getString("coyoteConnector.protocolHandlerInstantiationFailed"), e);
/*      */     }
/*      */     
/*   93 */     if (p != null) {
/*   94 */       this.protocolHandler = p;
/*   95 */       this.protocolHandlerClassName = this.protocolHandler.getClass().getName();
/*      */     } else {
/*   97 */       this.protocolHandler = null;
/*   98 */       this.protocolHandlerClassName = protocol;
/*      */     }
/*      */     
/*  101 */     setThrowOnFailure(Boolean.getBoolean("org.apache.catalina.startup.EXIT_ON_INIT_FAILURE"));
/*      */   }
/*      */   
/*      */   public Connector(ProtocolHandler protocolHandler)
/*      */   {
/*  106 */     this.protocolHandlerClassName = protocolHandler.getClass().getName();
/*  107 */     this.protocolHandler = protocolHandler;
/*      */     
/*  109 */     setThrowOnFailure(Boolean.getBoolean("org.apache.catalina.startup.EXIT_ON_INIT_FAILURE"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  118 */   protected Service service = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  124 */   protected boolean allowTrace = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  130 */   protected long asyncTimeout = 30000L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  136 */   protected boolean enableLookups = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  142 */   protected boolean xpoweredBy = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  151 */   protected String proxyName = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  160 */   protected int proxyPort = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  170 */   protected boolean discardFacades = RECYCLE_FACADES;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  176 */   protected int redirectPort = 443;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  183 */   protected String scheme = "http";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  190 */   protected boolean secure = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  196 */   protected static final StringManager sm = StringManager.getManager(Connector.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  203 */   private int maxCookieCount = 200;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  210 */   protected int maxParameterCount = 10000;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  216 */   protected int maxPostSize = 2097152;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  223 */   protected int maxSavePostSize = 4096;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  229 */   protected String parseBodyMethods = "POST";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected HashSet<String> parseBodyMethodsSet;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  240 */   protected boolean useIPVHosts = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final String protocolHandlerClassName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final ProtocolHandler protocolHandler;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  259 */   protected Adapter adapter = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  265 */   private Charset uriCharset = StandardCharsets.UTF_8;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  271 */   private EncodedSolidusHandling encodedSolidusHandling = UDecoder.ALLOW_ENCODED_SLASH ? EncodedSolidusHandling.DECODE : EncodedSolidusHandling.REJECT;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  279 */   protected boolean useBodyEncodingForURI = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getProperty(String name)
/*      */   {
/*  291 */     if (this.protocolHandler == null) {
/*  292 */       return null;
/*      */     }
/*  294 */     return IntrospectionUtils.getProperty(this.protocolHandler, name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setProperty(String name, String value)
/*      */   {
/*  306 */     if (this.protocolHandler == null) {
/*  307 */       return false;
/*      */     }
/*  309 */     return IntrospectionUtils.setProperty(this.protocolHandler, name, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public Object getAttribute(String name)
/*      */   {
/*  324 */     return getProperty(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setAttribute(String name, Object value)
/*      */   {
/*  339 */     setProperty(name, String.valueOf(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Service getService()
/*      */   {
/*  347 */     return this.service;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setService(Service service)
/*      */   {
/*  357 */     this.service = service;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAllowTrace()
/*      */   {
/*  366 */     return this.allowTrace;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowTrace(boolean allowTrace)
/*      */   {
/*  376 */     this.allowTrace = allowTrace;
/*  377 */     setProperty("allowTrace", String.valueOf(allowTrace));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getAsyncTimeout()
/*      */   {
/*  385 */     return this.asyncTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAsyncTimeout(long asyncTimeout)
/*      */   {
/*  395 */     this.asyncTimeout = asyncTimeout;
/*  396 */     setProperty("asyncTimeout", String.valueOf(asyncTimeout));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDiscardFacades()
/*      */   {
/*  406 */     return (this.discardFacades) || (Globals.IS_SECURITY_ENABLED);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDiscardFacades(boolean discardFacades)
/*      */   {
/*  415 */     this.discardFacades = discardFacades;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getEnableLookups()
/*      */   {
/*  423 */     return this.enableLookups;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEnableLookups(boolean enableLookups)
/*      */   {
/*  433 */     this.enableLookups = enableLookups;
/*  434 */     setProperty("enableLookups", String.valueOf(enableLookups));
/*      */   }
/*      */   
/*      */   public int getMaxCookieCount()
/*      */   {
/*  439 */     return this.maxCookieCount;
/*      */   }
/*      */   
/*      */   public void setMaxCookieCount(int maxCookieCount)
/*      */   {
/*  444 */     this.maxCookieCount = maxCookieCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxParameterCount()
/*      */   {
/*  454 */     return this.maxParameterCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxParameterCount(int maxParameterCount)
/*      */   {
/*  466 */     this.maxParameterCount = maxParameterCount;
/*  467 */     setProperty("maxParameterCount", String.valueOf(maxParameterCount));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxPostSize()
/*      */   {
/*  476 */     return this.maxPostSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxPostSize(int maxPostSize)
/*      */   {
/*  488 */     this.maxPostSize = maxPostSize;
/*  489 */     setProperty("maxPostSize", String.valueOf(maxPostSize));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxSavePostSize()
/*      */   {
/*  498 */     return this.maxSavePostSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaxSavePostSize(int maxSavePostSize)
/*      */   {
/*  510 */     this.maxSavePostSize = maxSavePostSize;
/*  511 */     setProperty("maxSavePostSize", String.valueOf(maxSavePostSize));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getParseBodyMethods()
/*      */   {
/*  519 */     return this.parseBodyMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParseBodyMethods(String methods)
/*      */   {
/*  531 */     HashSet<String> methodSet = new HashSet();
/*      */     
/*  533 */     if (null != methods) {
/*  534 */       methodSet.addAll(Arrays.asList(methods.split("\\s*,\\s*")));
/*      */     }
/*      */     
/*  537 */     if (methodSet.contains("TRACE")) {
/*  538 */       throw new IllegalArgumentException(sm.getString("coyoteConnector.parseBodyMethodNoTrace"));
/*      */     }
/*      */     
/*  541 */     this.parseBodyMethods = methods;
/*  542 */     this.parseBodyMethodsSet = methodSet;
/*  543 */     setProperty("parseBodyMethods", methods);
/*      */   }
/*      */   
/*      */   protected boolean isParseBodyMethod(String method)
/*      */   {
/*  548 */     return this.parseBodyMethodsSet.contains(method);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPort()
/*      */   {
/*  560 */     if ((this.protocolHandler instanceof AbstractProtocol)) {
/*  561 */       return ((AbstractProtocol)this.protocolHandler).getPort();
/*      */     }
/*      */     
/*  564 */     Object port = getProperty("port");
/*  565 */     if ((port instanceof Integer)) {
/*  566 */       return ((Integer)port).intValue();
/*      */     }
/*      */     
/*  569 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(int port)
/*      */   {
/*  579 */     setProperty("port", String.valueOf(port));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getPortOffset()
/*      */   {
/*  586 */     if ((this.protocolHandler instanceof AbstractProtocol)) {
/*  587 */       return ((AbstractProtocol)this.protocolHandler).getPortOffset();
/*      */     }
/*      */     
/*  590 */     Object port = getProperty("portOffset");
/*  591 */     if ((port instanceof Integer)) {
/*  592 */       return ((Integer)port).intValue();
/*      */     }
/*      */     
/*  595 */     return 0;
/*      */   }
/*      */   
/*      */   public void setPortOffset(int portOffset)
/*      */   {
/*  600 */     setProperty("portOffset", String.valueOf(portOffset));
/*      */   }
/*      */   
/*      */   public int getPortWithOffset()
/*      */   {
/*  605 */     int port = getPort();
/*      */     
/*  607 */     if (port > 0) {
/*  608 */       return port + getPortOffset();
/*      */     }
/*  610 */     return port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLocalPort()
/*      */   {
/*  620 */     return ((Integer)getProperty("localPort")).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProtocol()
/*      */   {
/*  628 */     boolean apr = AprStatus.getUseAprConnector();
/*  629 */     if (((!apr) && (Http11NioProtocol.class.getName().equals(this.protocolHandlerClassName))) || ((apr) && 
/*  630 */       (Http11AprProtocol.class.getName().equals(this.protocolHandlerClassName))))
/*  631 */       return "HTTP/1.1";
/*  632 */     if (((!apr) && (AjpNioProtocol.class.getName().equals(this.protocolHandlerClassName))) || ((apr) && 
/*  633 */       (AjpAprProtocol.class.getName().equals(this.protocolHandlerClassName)))) {
/*  634 */       return "AJP/1.3";
/*      */     }
/*  636 */     return this.protocolHandlerClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProtocolHandlerClassName()
/*      */   {
/*  644 */     return this.protocolHandlerClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ProtocolHandler getProtocolHandler()
/*      */   {
/*  652 */     return this.protocolHandler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyName()
/*      */   {
/*  660 */     return this.proxyName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyName(String proxyName)
/*      */   {
/*  671 */     if ((proxyName != null) && (proxyName.length() > 0)) {
/*  672 */       this.proxyName = proxyName;
/*      */     } else {
/*  674 */       this.proxyName = null;
/*      */     }
/*  676 */     setProperty("proxyName", this.proxyName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getProxyPort()
/*      */   {
/*  684 */     return this.proxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyPort(int proxyPort)
/*      */   {
/*  694 */     this.proxyPort = proxyPort;
/*  695 */     setProperty("proxyPort", String.valueOf(proxyPort));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRedirectPort()
/*      */   {
/*  705 */     return this.redirectPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRedirectPort(int redirectPort)
/*      */   {
/*  715 */     this.redirectPort = redirectPort;
/*  716 */     setProperty("redirectPort", String.valueOf(redirectPort));
/*      */   }
/*      */   
/*      */   public int getRedirectPortWithOffset()
/*      */   {
/*  721 */     return getRedirectPort() + getPortOffset();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getScheme()
/*      */   {
/*  730 */     return this.scheme;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setScheme(String scheme)
/*      */   {
/*  741 */     this.scheme = scheme;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSecure()
/*      */   {
/*  750 */     return this.secure;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecure(boolean secure)
/*      */   {
/*  761 */     this.secure = secure;
/*  762 */     setProperty("secure", Boolean.toString(secure));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getURIEncoding()
/*      */   {
/*  771 */     return this.uriCharset.name();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Charset getURICharset()
/*      */   {
/*  781 */     return this.uriCharset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setURIEncoding(String URIEncoding)
/*      */   {
/*      */     try
/*      */     {
/*  791 */       Charset charset = B2CConverter.getCharset(URIEncoding);
/*  792 */       if (!CharsetUtil.isAsciiSuperset(charset)) {
/*  793 */         log.error(sm.getString("coyoteConnector.notAsciiSuperset", new Object[] { URIEncoding }));
/*      */       }
/*  795 */       this.uriCharset = charset;
/*      */     } catch (UnsupportedEncodingException e) {
/*  797 */       log.error(sm.getString("coyoteConnector.invalidEncoding", new Object[] { URIEncoding, this.uriCharset.name() }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseBodyEncodingForURI()
/*      */   {
/*  806 */     return this.useBodyEncodingForURI;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseBodyEncodingForURI(boolean useBodyEncodingForURI)
/*      */   {
/*  816 */     this.useBodyEncodingForURI = useBodyEncodingForURI;
/*  817 */     setProperty("useBodyEncodingForURI", String.valueOf(useBodyEncodingForURI));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getXpoweredBy()
/*      */   {
/*  828 */     return this.xpoweredBy;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setXpoweredBy(boolean xpoweredBy)
/*      */   {
/*  841 */     this.xpoweredBy = xpoweredBy;
/*  842 */     setProperty("xpoweredBy", String.valueOf(xpoweredBy));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseIPVHosts(boolean useIPVHosts)
/*      */   {
/*  853 */     this.useIPVHosts = useIPVHosts;
/*  854 */     setProperty("useIPVHosts", String.valueOf(useIPVHosts));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getUseIPVHosts()
/*      */   {
/*  864 */     return this.useIPVHosts;
/*      */   }
/*      */   
/*      */   public String getExecutorName()
/*      */   {
/*  869 */     Object obj = this.protocolHandler.getExecutor();
/*  870 */     if ((obj instanceof Executor)) {
/*  871 */       return ((Executor)obj).getName();
/*      */     }
/*  873 */     return "Internal";
/*      */   }
/*      */   
/*      */   public void addSslHostConfig(SSLHostConfig sslHostConfig)
/*      */   {
/*  878 */     this.protocolHandler.addSslHostConfig(sslHostConfig);
/*      */   }
/*      */   
/*      */   public SSLHostConfig[] findSslHostConfigs()
/*      */   {
/*  883 */     return this.protocolHandler.findSslHostConfigs();
/*      */   }
/*      */   
/*      */   public void addUpgradeProtocol(UpgradeProtocol upgradeProtocol)
/*      */   {
/*  888 */     this.protocolHandler.addUpgradeProtocol(upgradeProtocol);
/*      */   }
/*      */   
/*      */   public UpgradeProtocol[] findUpgradeProtocols()
/*      */   {
/*  893 */     return this.protocolHandler.findUpgradeProtocols();
/*      */   }
/*      */   
/*      */   public String getEncodedSolidusHandling()
/*      */   {
/*  898 */     return this.encodedSolidusHandling.getValue();
/*      */   }
/*      */   
/*      */   public void setEncodedSolidusHandling(String encodedSolidusHandling)
/*      */   {
/*  903 */     this.encodedSolidusHandling = EncodedSolidusHandling.fromString(encodedSolidusHandling);
/*      */   }
/*      */   
/*      */   public EncodedSolidusHandling getEncodedSolidusHandlingInternal()
/*      */   {
/*  908 */     return this.encodedSolidusHandling;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Request createRequest()
/*      */   {
/*  921 */     return new Request(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Response createResponse()
/*      */   {
/*  932 */     int size = this.protocolHandler.getDesiredBufferSize();
/*  933 */     if (size > 0) {
/*  934 */       return new Response(size);
/*      */     }
/*  936 */     return new Response();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected String createObjectNameKeyProperties(String type)
/*      */   {
/*  943 */     Object addressObj = getProperty("address");
/*      */     
/*  945 */     StringBuilder sb = new StringBuilder("type=");
/*  946 */     sb.append(type);
/*  947 */     String id = this.protocolHandler != null ? this.protocolHandler.getId() : null;
/*  948 */     if (id != null)
/*      */     {
/*  950 */       sb.append(",port=0,address=");
/*  951 */       sb.append(ObjectName.quote(id));
/*      */     } else {
/*  953 */       sb.append(",port=");
/*  954 */       int port = getPortWithOffset();
/*  955 */       if (port > 0) {
/*  956 */         sb.append(port);
/*      */       } else {
/*  958 */         sb.append("auto-");
/*  959 */         sb.append(getProperty("nameIndex"));
/*      */       }
/*  961 */       String address = "";
/*  962 */       if ((addressObj instanceof InetAddress)) {
/*  963 */         address = ((InetAddress)addressObj).getHostAddress();
/*  964 */       } else if (addressObj != null) {
/*  965 */         address = addressObj.toString();
/*      */       }
/*  967 */       if (address.length() > 0) {
/*  968 */         sb.append(",address=");
/*  969 */         sb.append(ObjectName.quote(address));
/*      */       }
/*      */     }
/*  972 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void pause()
/*      */   {
/*      */     try
/*      */     {
/*  981 */       if (this.protocolHandler != null) {
/*  982 */         this.protocolHandler.pause();
/*      */       }
/*      */     } catch (Exception e) {
/*  985 */       log.error(sm.getString("coyoteConnector.protocolHandlerPauseFailed"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void resume()
/*      */   {
/*      */     try
/*      */     {
/*  995 */       if (this.protocolHandler != null) {
/*  996 */         this.protocolHandler.resume();
/*      */       }
/*      */     } catch (Exception e) {
/*  999 */       log.error(sm.getString("coyoteConnector.protocolHandlerResumeFailed"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void initInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1007 */     super.initInternal();
/*      */     
/* 1009 */     if (this.protocolHandler == null)
/*      */     {
/* 1011 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerInstantiationFailed"));
/*      */     }
/*      */     
/*      */ 
/* 1015 */     this.adapter = new CoyoteAdapter(this);
/* 1016 */     this.protocolHandler.setAdapter(this.adapter);
/* 1017 */     if (this.service != null) {
/* 1018 */       this.protocolHandler.setUtilityExecutor(this.service.getServer().getUtilityExecutor());
/*      */     }
/*      */     
/*      */ 
/* 1022 */     if (null == this.parseBodyMethodsSet) {
/* 1023 */       setParseBodyMethods(getParseBodyMethods());
/*      */     }
/*      */     
/* 1026 */     if ((this.protocolHandler.isAprRequired()) && (!AprStatus.isInstanceCreated())) {
/* 1027 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerNoAprListener", new Object[] {
/* 1028 */         getProtocolHandlerClassName() }));
/*      */     }
/* 1030 */     if ((this.protocolHandler.isAprRequired()) && (!AprStatus.isAprAvailable())) {
/* 1031 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerNoAprLibrary", new Object[] {
/* 1032 */         getProtocolHandlerClassName() }));
/*      */     }
/* 1034 */     if ((AprStatus.isAprAvailable()) && (AprStatus.getUseOpenSSL()) && ((this.protocolHandler instanceof AbstractHttp11JsseProtocol)))
/*      */     {
/* 1036 */       AbstractHttp11JsseProtocol<?> jsseProtocolHandler = (AbstractHttp11JsseProtocol)this.protocolHandler;
/*      */       
/* 1038 */       if ((jsseProtocolHandler.isSSLEnabled()) && 
/* 1039 */         (jsseProtocolHandler.getSslImplementationName() == null))
/*      */       {
/* 1041 */         jsseProtocolHandler.setSslImplementationName(OpenSSLImplementation.class.getName());
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/* 1046 */       this.protocolHandler.init();
/*      */     }
/*      */     catch (Exception e) {
/* 1049 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerInitializationFailed"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void startInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1063 */     String id = this.protocolHandler != null ? this.protocolHandler.getId() : null;
/* 1064 */     if ((id == null) && (getPortWithOffset() < 0)) {
/* 1065 */       throw new LifecycleException(sm.getString("coyoteConnector.invalidPort", new Object[] {
/* 1066 */         Integer.valueOf(getPortWithOffset()) }));
/*      */     }
/*      */     
/* 1069 */     setState(LifecycleState.STARTING);
/*      */     try
/*      */     {
/* 1072 */       this.protocolHandler.start();
/*      */     }
/*      */     catch (Exception e) {
/* 1075 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerStartFailed"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1088 */     setState(LifecycleState.STOPPING);
/*      */     try
/*      */     {
/* 1091 */       if (this.protocolHandler != null) {
/* 1092 */         this.protocolHandler.stop();
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1096 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerStopFailed"), e);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void destroyInternal() throws LifecycleException
/*      */   {
/*      */     try
/*      */     {
/* 1104 */       if (this.protocolHandler != null) {
/* 1105 */         this.protocolHandler.destroy();
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1109 */       throw new LifecycleException(sm.getString("coyoteConnector.protocolHandlerDestroyFailed"), e);
/*      */     }
/*      */     
/* 1112 */     if (getService() != null) {
/* 1113 */       getService().removeConnector(this);
/*      */     }
/*      */     
/* 1116 */     super.destroyInternal();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1127 */     StringBuilder sb = new StringBuilder("Connector[");
/* 1128 */     sb.append(getProtocol());
/* 1129 */     sb.append('-');
/* 1130 */     String id = this.protocolHandler != null ? this.protocolHandler.getId() : null;
/* 1131 */     if (id != null) {
/* 1132 */       sb.append(id);
/*      */     } else {
/* 1134 */       int port = getPortWithOffset();
/* 1135 */       if (port > 0) {
/* 1136 */         sb.append(port);
/*      */       } else {
/* 1138 */         sb.append("auto-");
/* 1139 */         sb.append(getProperty("nameIndex"));
/*      */       }
/*      */     }
/* 1142 */     sb.append(']');
/* 1143 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getDomainInternal()
/*      */   {
/* 1151 */     Service s = getService();
/* 1152 */     if (s == null) {
/* 1153 */       return null;
/*      */     }
/* 1155 */     return this.service.getDomain();
/*      */   }
/*      */   
/*      */ 
/*      */   protected String getObjectNameKeyProperties()
/*      */   {
/* 1161 */     return createObjectNameKeyProperties("Connector");
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\connector\Connector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */