/*    */ package org.apache.catalina.users;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemoryRole
/*    */   extends GenericRole<MemoryUserDatabase>
/*    */ {
/*    */   MemoryRole(MemoryUserDatabase database, String rolename, String description)
/*    */   {
/* 43 */     super(database, rolename, description);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 52 */     StringBuilder sb = new StringBuilder("<role rolename=\"");
/* 53 */     sb.append(this.rolename);
/* 54 */     sb.append("\"");
/* 55 */     if (this.description != null) {
/* 56 */       sb.append(" description=\"");
/* 57 */       sb.append(this.description);
/* 58 */       sb.append("\"");
/*    */     }
/* 60 */     sb.append("/>");
/* 61 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\users\MemoryRole.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */