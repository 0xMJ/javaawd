/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpHeaderSecurityFilter
/*     */   extends FilterBase
/*     */ {
/*  41 */   private final Log log = LogFactory.getLog(HttpHeaderSecurityFilter.class);
/*     */   
/*     */   private static final String HSTS_HEADER_NAME = "Strict-Transport-Security";
/*     */   
/*  45 */   private boolean hstsEnabled = true;
/*  46 */   private int hstsMaxAgeSeconds = 0;
/*  47 */   private boolean hstsIncludeSubDomains = false;
/*  48 */   private boolean hstsPreload = false;
/*     */   
/*     */   private String hstsHeaderValue;
/*     */   
/*     */   private static final String ANTI_CLICK_JACKING_HEADER_NAME = "X-Frame-Options";
/*  53 */   private boolean antiClickJackingEnabled = true;
/*  54 */   private XFrameOption antiClickJackingOption = XFrameOption.DENY;
/*     */   
/*     */   private URI antiClickJackingUri;
/*     */   
/*     */   private String antiClickJackingHeaderValue;
/*     */   private static final String BLOCK_CONTENT_TYPE_SNIFFING_HEADER_NAME = "X-Content-Type-Options";
/*     */   private static final String BLOCK_CONTENT_TYPE_SNIFFING_HEADER_VALUE = "nosniff";
/*  61 */   private boolean blockContentTypeSniffingEnabled = true;
/*     */   
/*     */   private static final String XSS_PROTECTION_HEADER_NAME = "X-XSS-Protection";
/*     */   
/*     */   private static final String XSS_PROTECTION_HEADER_VALUE = "1; mode=block";
/*  66 */   private boolean xssProtectionEnabled = true;
/*     */   
/*     */   public void init(FilterConfig filterConfig) throws ServletException
/*     */   {
/*  70 */     super.init(filterConfig);
/*     */     
/*     */ 
/*  73 */     StringBuilder hstsValue = new StringBuilder("max-age=");
/*  74 */     hstsValue.append(this.hstsMaxAgeSeconds);
/*  75 */     if (this.hstsIncludeSubDomains) {
/*  76 */       hstsValue.append(";includeSubDomains");
/*     */     }
/*  78 */     if (this.hstsPreload) {
/*  79 */       hstsValue.append(";preload");
/*     */     }
/*  81 */     this.hstsHeaderValue = hstsValue.toString();
/*     */     
/*     */ 
/*  84 */     StringBuilder cjValue = new StringBuilder(this.antiClickJackingOption.headerValue);
/*  85 */     if (this.antiClickJackingOption == XFrameOption.ALLOW_FROM) {
/*  86 */       cjValue.append(' ');
/*  87 */       cjValue.append(this.antiClickJackingUri);
/*     */     }
/*  89 */     this.antiClickJackingHeaderValue = cjValue.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  97 */     if ((response instanceof HttpServletResponse)) {
/*  98 */       HttpServletResponse httpResponse = (HttpServletResponse)response;
/*     */       
/* 100 */       if (response.isCommitted()) {
/* 101 */         throw new ServletException(sm.getString("httpHeaderSecurityFilter.committed"));
/*     */       }
/*     */       
/*     */ 
/* 105 */       if ((this.hstsEnabled) && (request.isSecure())) {
/* 106 */         httpResponse.setHeader("Strict-Transport-Security", this.hstsHeaderValue);
/*     */       }
/*     */       
/*     */ 
/* 110 */       if (this.antiClickJackingEnabled) {
/* 111 */         httpResponse.setHeader("X-Frame-Options", this.antiClickJackingHeaderValue);
/*     */       }
/*     */       
/*     */ 
/* 115 */       if (this.blockContentTypeSniffingEnabled) {
/* 116 */         httpResponse.setHeader("X-Content-Type-Options", "nosniff");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 121 */       if (this.xssProtectionEnabled) {
/* 122 */         httpResponse.setHeader("X-XSS-Protection", "1; mode=block");
/*     */       }
/*     */     }
/*     */     
/* 126 */     chain.doFilter(request, response);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Log getLogger()
/*     */   {
/* 132 */     return this.log;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isConfigProblemFatal()
/*     */   {
/* 140 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isHstsEnabled()
/*     */   {
/* 145 */     return this.hstsEnabled;
/*     */   }
/*     */   
/*     */   public void setHstsEnabled(boolean hstsEnabled)
/*     */   {
/* 150 */     this.hstsEnabled = hstsEnabled;
/*     */   }
/*     */   
/*     */   public int getHstsMaxAgeSeconds()
/*     */   {
/* 155 */     return this.hstsMaxAgeSeconds;
/*     */   }
/*     */   
/*     */   public void setHstsMaxAgeSeconds(int hstsMaxAgeSeconds)
/*     */   {
/* 160 */     if (hstsMaxAgeSeconds < 0) {
/* 161 */       this.hstsMaxAgeSeconds = 0;
/*     */     } else {
/* 163 */       this.hstsMaxAgeSeconds = hstsMaxAgeSeconds;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isHstsIncludeSubDomains()
/*     */   {
/* 169 */     return this.hstsIncludeSubDomains;
/*     */   }
/*     */   
/*     */   public void setHstsIncludeSubDomains(boolean hstsIncludeSubDomains)
/*     */   {
/* 174 */     this.hstsIncludeSubDomains = hstsIncludeSubDomains;
/*     */   }
/*     */   
/*     */   public boolean isHstsPreload()
/*     */   {
/* 179 */     return this.hstsPreload;
/*     */   }
/*     */   
/*     */   public void setHstsPreload(boolean hstsPreload)
/*     */   {
/* 184 */     this.hstsPreload = hstsPreload;
/*     */   }
/*     */   
/*     */   public boolean isAntiClickJackingEnabled()
/*     */   {
/* 189 */     return this.antiClickJackingEnabled;
/*     */   }
/*     */   
/*     */   public void setAntiClickJackingEnabled(boolean antiClickJackingEnabled)
/*     */   {
/* 194 */     this.antiClickJackingEnabled = antiClickJackingEnabled;
/*     */   }
/*     */   
/*     */   public String getAntiClickJackingOption()
/*     */   {
/* 199 */     return this.antiClickJackingOption.toString();
/*     */   }
/*     */   
/*     */   public void setAntiClickJackingOption(String antiClickJackingOption)
/*     */   {
/* 204 */     for (XFrameOption option : ) {
/* 205 */       if (option.getHeaderValue().equalsIgnoreCase(antiClickJackingOption)) {
/* 206 */         this.antiClickJackingOption = option;
/* 207 */         return;
/*     */       }
/*     */     }
/*     */     
/* 211 */     throw new IllegalArgumentException(sm.getString("httpHeaderSecurityFilter.clickjack.invalid", new Object[] { antiClickJackingOption }));
/*     */   }
/*     */   
/*     */   public String getAntiClickJackingUri()
/*     */   {
/* 216 */     return this.antiClickJackingUri.toString();
/*     */   }
/*     */   
/*     */   public boolean isBlockContentTypeSniffingEnabled()
/*     */   {
/* 221 */     return this.blockContentTypeSniffingEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBlockContentTypeSniffingEnabled(boolean blockContentTypeSniffingEnabled)
/*     */   {
/* 227 */     this.blockContentTypeSniffingEnabled = blockContentTypeSniffingEnabled;
/*     */   }
/*     */   
/*     */   public void setAntiClickJackingUri(String antiClickJackingUri)
/*     */   {
/*     */     try
/*     */     {
/* 234 */       uri = new URI(antiClickJackingUri);
/*     */     } catch (URISyntaxException e) { URI uri;
/* 236 */       throw new IllegalArgumentException(e); }
/*     */     URI uri;
/* 238 */     this.antiClickJackingUri = uri;
/*     */   }
/*     */   
/*     */   public boolean isXssProtectionEnabled()
/*     */   {
/* 243 */     return this.xssProtectionEnabled;
/*     */   }
/*     */   
/*     */   public void setXssProtectionEnabled(boolean xssProtectionEnabled)
/*     */   {
/* 248 */     this.xssProtectionEnabled = xssProtectionEnabled;
/*     */   }
/*     */   
/*     */   private static enum XFrameOption
/*     */   {
/* 253 */     DENY("DENY"), 
/* 254 */     SAME_ORIGIN("SAMEORIGIN"), 
/* 255 */     ALLOW_FROM("ALLOW-FROM");
/*     */     
/*     */     private final String headerValue;
/*     */     
/*     */     private XFrameOption(String headerValue)
/*     */     {
/* 261 */       this.headerValue = headerValue;
/*     */     }
/*     */     
/*     */     public String getHeaderValue() {
/* 265 */       return this.headerValue;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\filters\HttpHeaderSecurityFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */