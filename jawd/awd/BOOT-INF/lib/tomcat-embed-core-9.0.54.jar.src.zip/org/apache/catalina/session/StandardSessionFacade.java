/*     */ package org.apache.catalina.session;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.HttpSessionContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardSessionFacade
/*     */   implements HttpSession
/*     */ {
/*     */   private final HttpSession session;
/*     */   
/*     */   public StandardSessionFacade(HttpSession session)
/*     */   {
/*  39 */     this.session = session;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getCreationTime()
/*     */   {
/*  55 */     return this.session.getCreationTime();
/*     */   }
/*     */   
/*     */ 
/*     */   public String getId()
/*     */   {
/*  61 */     return this.session.getId();
/*     */   }
/*     */   
/*     */ 
/*     */   public long getLastAccessedTime()
/*     */   {
/*  67 */     return this.session.getLastAccessedTime();
/*     */   }
/*     */   
/*     */ 
/*     */   public ServletContext getServletContext()
/*     */   {
/*  73 */     return this.session.getServletContext();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setMaxInactiveInterval(int interval)
/*     */   {
/*  79 */     this.session.setMaxInactiveInterval(interval);
/*     */   }
/*     */   
/*     */ 
/*     */   public int getMaxInactiveInterval()
/*     */   {
/*  85 */     return this.session.getMaxInactiveInterval();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public HttpSessionContext getSessionContext()
/*     */   {
/*  96 */     return this.session.getSessionContext();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getAttribute(String name)
/*     */   {
/* 102 */     return this.session.getAttribute(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Object getValue(String name)
/*     */   {
/* 113 */     return this.session.getAttribute(name);
/*     */   }
/*     */   
/*     */ 
/*     */   public Enumeration<String> getAttributeNames()
/*     */   {
/* 119 */     return this.session.getAttributeNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public String[] getValueNames()
/*     */   {
/* 130 */     return this.session.getValueNames();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setAttribute(String name, Object value)
/*     */   {
/* 136 */     this.session.setAttribute(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void putValue(String name, Object value)
/*     */   {
/* 147 */     this.session.setAttribute(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeAttribute(String name)
/*     */   {
/* 153 */     this.session.removeAttribute(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void removeValue(String name)
/*     */   {
/* 164 */     this.session.removeAttribute(name);
/*     */   }
/*     */   
/*     */ 
/*     */   public void invalidate()
/*     */   {
/* 170 */     this.session.invalidate();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isNew()
/*     */   {
/* 176 */     return this.session.isNew();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\session\StandardSessionFacade.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */