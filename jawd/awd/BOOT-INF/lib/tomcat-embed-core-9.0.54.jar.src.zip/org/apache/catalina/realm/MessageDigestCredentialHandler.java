/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Arrays;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.buf.HexUtils;
/*     */ import org.apache.tomcat.util.codec.binary.Base64;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.security.ConcurrentMessageDigest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageDigestCredentialHandler
/*     */   extends DigestCredentialHandlerBase
/*     */ {
/*  56 */   private static final Log log = LogFactory.getLog(MessageDigestCredentialHandler.class);
/*     */   
/*     */   public static final int DEFAULT_ITERATIONS = 1;
/*     */   
/*  60 */   private Charset encoding = StandardCharsets.UTF_8;
/*  61 */   private String algorithm = null;
/*     */   
/*     */   public String getEncoding()
/*     */   {
/*  65 */     return this.encoding.name();
/*     */   }
/*     */   
/*     */   public void setEncoding(String encodingName)
/*     */   {
/*  70 */     if (encodingName == null) {
/*  71 */       this.encoding = StandardCharsets.UTF_8;
/*     */     } else {
/*     */       try {
/*  74 */         this.encoding = B2CConverter.getCharset(encodingName);
/*     */       } catch (UnsupportedEncodingException e) {
/*  76 */         log.error(sm.getString("mdCredentialHandler.unknownEncoding", new Object[] { encodingName, this.encoding.name() }));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getAlgorithm()
/*     */   {
/*  84 */     return this.algorithm;
/*     */   }
/*     */   
/*     */   public void setAlgorithm(String algorithm)
/*     */     throws NoSuchAlgorithmException
/*     */   {
/*  90 */     ConcurrentMessageDigest.init(algorithm);
/*  91 */     this.algorithm = algorithm;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean matches(String inputCredentials, String storedCredentials)
/*     */   {
/*  97 */     if ((inputCredentials == null) || (storedCredentials == null)) {
/*  98 */       return false;
/*     */     }
/*     */     
/* 101 */     if (getAlgorithm() == null)
/*     */     {
/* 103 */       return storedCredentials.equals(inputCredentials);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 108 */     if ((storedCredentials.startsWith("{MD5}")) || (storedCredentials.startsWith("{SHA}")))
/*     */     {
/*     */ 
/* 111 */       String base64ServerDigest = storedCredentials.substring(5);
/* 112 */       byte[] userDigest = ConcurrentMessageDigest.digest(
/* 113 */         getAlgorithm(), new byte[][] { inputCredentials.getBytes(StandardCharsets.ISO_8859_1) });
/* 114 */       String base64UserDigest = Base64.encodeBase64String(userDigest);
/* 115 */       return base64UserDigest.equals(base64ServerDigest); }
/* 116 */     if (storedCredentials.startsWith("{SSHA}"))
/*     */     {
/*     */ 
/*     */ 
/* 120 */       String serverDigestPlusSalt = storedCredentials.substring(6);
/* 121 */       byte[] serverDigestPlusSaltBytes = Base64.decodeBase64(serverDigestPlusSalt);
/*     */       
/*     */ 
/* 124 */       int digestLength = 20;
/* 125 */       byte[] serverDigestBytes = new byte[20];
/* 126 */       System.arraycopy(serverDigestPlusSaltBytes, 0, serverDigestBytes, 0, 20);
/*     */       
/*     */ 
/* 129 */       int saltLength = serverDigestPlusSaltBytes.length - 20;
/* 130 */       byte[] serverSaltBytes = new byte[saltLength];
/* 131 */       System.arraycopy(serverDigestPlusSaltBytes, 20, serverSaltBytes, 0, saltLength);
/*     */       
/*     */ 
/*     */ 
/* 135 */       byte[] userDigestBytes = ConcurrentMessageDigest.digest(getAlgorithm(), new byte[][] {inputCredentials
/* 136 */         .getBytes(StandardCharsets.ISO_8859_1), serverSaltBytes });
/*     */       
/*     */ 
/* 139 */       return Arrays.equals(userDigestBytes, serverDigestBytes); }
/* 140 */     if (storedCredentials.indexOf('$') > -1) {
/* 141 */       return matchesSaltIterationsEncoded(inputCredentials, storedCredentials);
/*     */     }
/*     */     
/* 144 */     String userDigest = mutate(inputCredentials, null, 1);
/* 145 */     if (userDigest == null)
/*     */     {
/*     */ 
/* 148 */       return false;
/*     */     }
/* 150 */     return storedCredentials.equalsIgnoreCase(userDigest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String mutate(String inputCredentials, byte[] salt, int iterations)
/*     */   {
/* 158 */     if (this.algorithm == null) {
/* 159 */       return inputCredentials;
/*     */     }
/* 161 */     byte[] inputCredentialbytes = inputCredentials.getBytes(this.encoding);
/*     */     byte[] userDigest;
/* 163 */     byte[] userDigest; if (salt == null) {
/* 164 */       userDigest = ConcurrentMessageDigest.digest(this.algorithm, iterations, new byte[][] { inputCredentialbytes });
/*     */     } else {
/* 166 */       userDigest = ConcurrentMessageDigest.digest(this.algorithm, iterations, new byte[][] { salt, inputCredentialbytes });
/*     */     }
/* 168 */     return HexUtils.toHexString(userDigest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int getDefaultIterations()
/*     */   {
/* 175 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Log getLog()
/*     */   {
/* 181 */     return log;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\MessageDigestCredentialHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */