/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.Wrapper;
/*     */ import org.apache.catalina.connector.ClientAbortException;
/*     */ import org.apache.catalina.connector.Request;
/*     */ import org.apache.catalina.valves.ValveBase;
/*     */ import org.apache.coyote.ActionCode;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.descriptor.web.ErrorPage;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StandardHostValve
/*     */   extends ValveBase
/*     */ {
/*  54 */   private static final Log log = LogFactory.getLog(StandardHostValve.class);
/*  55 */   private static final StringManager sm = StringManager.getManager(StandardHostValve.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  60 */   private static final ClassLoader MY_CLASSLOADER = StandardHostValve.class.getClassLoader();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   static final boolean STRICT_SERVLET_COMPLIANCE = Globals.STRICT_SERVLET_COMPLIANCE;
/*     */   
/*  69 */   static { String accessSession = System.getProperty("org.apache.catalina.core.StandardHostValve.ACCESS_SESSION");
/*     */     
/*  71 */     if (accessSession == null) {
/*  72 */       ACCESS_SESSION = STRICT_SERVLET_COMPLIANCE;
/*     */     } else {
/*  74 */       ACCESS_SESSION = Boolean.parseBoolean(accessSession);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public StandardHostValve()
/*     */   {
/*  81 */     super(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final boolean ACCESS_SESSION;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void invoke(Request request, org.apache.catalina.connector.Response response)
/*     */     throws IOException, ServletException
/*     */   {
/* 103 */     Context context = request.getContext();
/* 104 */     if (context == null)
/*     */     {
/* 106 */       if (!response.isError()) {
/* 107 */         response.sendError(404);
/*     */       }
/* 109 */       return;
/*     */     }
/*     */     
/* 112 */     if (request.isAsyncSupported()) {
/* 113 */       request.setAsyncSupported(context.getPipeline().isAsyncSupported());
/*     */     }
/*     */     
/* 116 */     boolean asyncAtStart = request.isAsync();
/*     */     try
/*     */     {
/* 119 */       context.bind(Globals.IS_SECURITY_ENABLED, MY_CLASSLOADER);
/*     */       
/* 121 */       if ((!asyncAtStart) && (!context.fireRequestInitEvent(request.getRequest())))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 126 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 134 */         if (!response.isErrorReportRequired()) {
/* 135 */           context.getPipeline().getFirst().invoke(request, response);
/*     */         }
/*     */       } catch (Throwable t) {
/* 138 */         ExceptionUtils.handleThrowable(t);
/* 139 */         this.container.getLogger().error("Exception Processing " + request.getRequestURI(), t);
/*     */         
/*     */ 
/* 142 */         if (!response.isErrorReportRequired()) {
/* 143 */           request.setAttribute("javax.servlet.error.exception", t);
/* 144 */           throwable(request, response, t);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 151 */       response.setSuspended(false);
/*     */       
/* 153 */       Throwable t = (Throwable)request.getAttribute("javax.servlet.error.exception");
/*     */       
/*     */ 
/*     */ 
/* 157 */       if (!context.getState().isAvailable()) {
/* 158 */         return;
/*     */       }
/*     */       
/*     */ 
/* 162 */       if (response.isErrorReportRequired())
/*     */       {
/*     */ 
/* 165 */         AtomicBoolean result = new AtomicBoolean(false);
/* 166 */         response.getCoyoteResponse().action(ActionCode.IS_IO_ALLOWED, result);
/* 167 */         if (result.get()) {
/* 168 */           if (t != null) {
/* 169 */             throwable(request, response, t);
/*     */           } else {
/* 171 */             status(request, response);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 176 */       if ((!request.isAsync()) && (!asyncAtStart)) {
/* 177 */         context.fireRequestDestroyEvent(request.getRequest());
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 182 */       if (ACCESS_SESSION) {
/* 183 */         request.getSession(false);
/*     */       }
/*     */       
/* 186 */       context.unbind(Globals.IS_SECURITY_ENABLED, MY_CLASSLOADER);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void status(Request request, org.apache.catalina.connector.Response response)
/*     */   {
/* 204 */     int statusCode = response.getStatus();
/*     */     
/*     */ 
/* 207 */     Context context = request.getContext();
/* 208 */     if (context == null) {
/* 209 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 217 */     if (!response.isError()) {
/* 218 */       return;
/*     */     }
/*     */     
/* 221 */     ErrorPage errorPage = context.findErrorPage(statusCode);
/* 222 */     if (errorPage == null)
/*     */     {
/* 224 */       errorPage = context.findErrorPage(0);
/*     */     }
/* 226 */     if ((errorPage != null) && (response.isErrorReportRequired())) {
/* 227 */       response.setAppCommitted(false);
/* 228 */       request.setAttribute("javax.servlet.error.status_code", 
/* 229 */         Integer.valueOf(statusCode));
/*     */       
/* 231 */       String message = response.getMessage();
/* 232 */       if (message == null) {
/* 233 */         message = "";
/*     */       }
/* 235 */       request.setAttribute("javax.servlet.error.message", message);
/* 236 */       request.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", errorPage
/* 237 */         .getLocation());
/* 238 */       request.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", DispatcherType.ERROR);
/*     */       
/*     */ 
/*     */ 
/* 242 */       Wrapper wrapper = request.getWrapper();
/* 243 */       if (wrapper != null) {
/* 244 */         request.setAttribute("javax.servlet.error.servlet_name", wrapper
/* 245 */           .getName());
/*     */       }
/* 247 */       request.setAttribute("javax.servlet.error.request_uri", request
/* 248 */         .getRequestURI());
/* 249 */       if (custom(request, response, errorPage)) {
/* 250 */         response.setErrorReported();
/*     */         try {
/* 252 */           response.finishResponse();
/*     */         }
/*     */         catch (ClientAbortException localClientAbortException) {}catch (IOException e)
/*     */         {
/* 256 */           this.container.getLogger().warn("Exception Processing " + errorPage, e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void throwable(Request request, org.apache.catalina.connector.Response response, Throwable throwable)
/*     */   {
/* 276 */     Context context = request.getContext();
/* 277 */     if (context == null) {
/* 278 */       return;
/*     */     }
/*     */     
/* 281 */     Throwable realError = throwable;
/*     */     
/* 283 */     if ((realError instanceof ServletException)) {
/* 284 */       realError = ((ServletException)realError).getRootCause();
/* 285 */       if (realError == null) {
/* 286 */         realError = throwable;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 291 */     if ((realError instanceof ClientAbortException)) {
/* 292 */       if (log.isDebugEnabled())
/*     */       {
/* 294 */         log.debug(sm.getString("standardHost.clientAbort", new Object[] {realError
/* 295 */           .getCause().getMessage() }));
/*     */       }
/* 297 */       return;
/*     */     }
/*     */     
/* 300 */     ErrorPage errorPage = context.findErrorPage(throwable);
/* 301 */     if ((errorPage == null) && (realError != throwable)) {
/* 302 */       errorPage = context.findErrorPage(realError);
/*     */     }
/*     */     
/* 305 */     if (errorPage != null) {
/* 306 */       if (response.setErrorReported()) {
/* 307 */         response.setAppCommitted(false);
/* 308 */         request.setAttribute("org.apache.catalina.core.DISPATCHER_REQUEST_PATH", errorPage
/* 309 */           .getLocation());
/* 310 */         request.setAttribute("org.apache.catalina.core.DISPATCHER_TYPE", DispatcherType.ERROR);
/*     */         
/* 312 */         request.setAttribute("javax.servlet.error.status_code", 
/* 313 */           Integer.valueOf(500));
/* 314 */         request.setAttribute("javax.servlet.error.message", throwable
/* 315 */           .getMessage());
/* 316 */         request.setAttribute("javax.servlet.error.exception", realError);
/*     */         
/* 318 */         Wrapper wrapper = request.getWrapper();
/* 319 */         if (wrapper != null) {
/* 320 */           request.setAttribute("javax.servlet.error.servlet_name", wrapper
/* 321 */             .getName());
/*     */         }
/* 323 */         request.setAttribute("javax.servlet.error.request_uri", request
/* 324 */           .getRequestURI());
/* 325 */         request.setAttribute("javax.servlet.error.exception_type", realError
/* 326 */           .getClass());
/* 327 */         if (custom(request, response, errorPage)) {
/*     */           try {
/* 329 */             response.finishResponse();
/*     */           } catch (IOException e) {
/* 331 */             this.container.getLogger().warn("Exception Processing " + errorPage, e);
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 340 */       response.setStatus(500);
/*     */       
/* 342 */       response.setError();
/*     */       
/* 344 */       status(request, response);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean custom(Request request, org.apache.catalina.connector.Response response, ErrorPage errorPage)
/*     */   {
/* 364 */     if (this.container.getLogger().isDebugEnabled()) {
/* 365 */       this.container.getLogger().debug("Processing " + errorPage);
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 371 */       ServletContext servletContext = request.getContext().getServletContext();
/*     */       
/* 373 */       RequestDispatcher rd = servletContext.getRequestDispatcher(errorPage.getLocation());
/*     */       
/* 375 */       if (rd == null) {
/* 376 */         this.container.getLogger().error(sm
/* 377 */           .getString("standardHostValue.customStatusFailed", new Object[] {errorPage.getLocation() }));
/* 378 */         return false;
/*     */       }
/*     */       
/* 381 */       if (response.isCommitted())
/*     */       {
/*     */ 
/* 384 */         rd.include(request.getRequest(), response.getResponse());
/*     */         
/*     */ 
/*     */         try
/*     */         {
/* 389 */           response.flushBuffer();
/*     */         } catch (Throwable t) {
/* 391 */           ExceptionUtils.handleThrowable(t);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 396 */         response.getCoyoteResponse().action(ActionCode.CLOSE_NOW, request
/* 397 */           .getAttribute("javax.servlet.error.exception"));
/*     */       }
/*     */       else {
/* 400 */         response.resetBuffer(true);
/* 401 */         response.setContentLength(-1);
/*     */         
/* 403 */         rd.forward(request.getRequest(), response.getResponse());
/*     */         
/*     */ 
/* 406 */         response.setSuspended(false);
/*     */       }
/*     */       
/*     */ 
/* 410 */       return true;
/*     */     }
/*     */     catch (Throwable t) {
/* 413 */       ExceptionUtils.handleThrowable(t);
/*     */       
/* 415 */       this.container.getLogger().error("Exception Processing " + errorPage, t); }
/* 416 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\StandardHostValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */