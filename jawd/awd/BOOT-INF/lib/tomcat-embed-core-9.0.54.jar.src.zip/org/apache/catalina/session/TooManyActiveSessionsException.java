/*    */ package org.apache.catalina.session;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TooManyActiveSessionsException
/*    */   extends IllegalStateException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final int maxActiveSessions;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TooManyActiveSessionsException(String message, int maxActive)
/*    */   {
/* 40 */     super(message);
/* 41 */     this.maxActiveSessions = maxActive;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getMaxActiveSessions()
/*    */   {
/* 50 */     return this.maxActiveSessions;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\session\TooManyActiveSessionsException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */