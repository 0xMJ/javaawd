package org.apache.catalina.core;

public class Constants
{
  @Deprecated
  public static final String Package = "org.apache.catalina.core";
  public static final int MAJOR_VERSION = 4;
  public static final int MINOR_VERSION = 0;
  public static final String JSP_SERVLET_CLASS = "org.apache.jasper.servlet.JspServlet";
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\Constants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */