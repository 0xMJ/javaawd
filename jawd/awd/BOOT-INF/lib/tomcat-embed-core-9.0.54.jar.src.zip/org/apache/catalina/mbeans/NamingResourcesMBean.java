/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.deploy.NamingResourcesImpl;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextEnvironment;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResourceLink;
/*     */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*     */ import org.apache.tomcat.util.modeler.ManagedBean;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamingResourcesMBean
/*     */   extends BaseModelMBean
/*     */ {
/*  42 */   private static final StringManager sm = StringManager.getManager(NamingResourcesMBean.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */   protected final Registry registry = MBeanUtils.createRegistry();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   protected final ManagedBean managed = this.registry.findManagedBean("NamingResources");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getEnvironments()
/*     */   {
/*  66 */     ContextEnvironment[] envs = ((NamingResourcesImpl)this.resource).findEnvironments();
/*  67 */     List<String> results = new ArrayList();
/*  68 */     for (ContextEnvironment env : envs) {
/*     */       try {
/*  70 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), env);
/*  71 */         results.add(oname.toString());
/*     */       }
/*     */       catch (MalformedObjectNameException e) {
/*  74 */         throw new IllegalArgumentException(sm.getString("namingResourcesMBean.createObjectNameError.environment", new Object[] { env }), e);
/*     */       }
/*     */     }
/*  77 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getResources()
/*     */   {
/*  87 */     ContextResource[] resources = ((NamingResourcesImpl)this.resource).findResources();
/*  88 */     List<String> results = new ArrayList();
/*  89 */     for (ContextResource contextResource : resources) {
/*     */       try {
/*  91 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), contextResource);
/*  92 */         results.add(oname.toString());
/*     */       }
/*     */       catch (MalformedObjectNameException e) {
/*  95 */         throw new IllegalArgumentException(sm.getString("namingResourcesMBean.createObjectNameError.resource", new Object[] { contextResource }), e);
/*     */       }
/*     */     }
/*  98 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getResourceLinks()
/*     */   {
/* 109 */     ContextResourceLink[] resourceLinks = ((NamingResourcesImpl)this.resource).findResourceLinks();
/* 110 */     List<String> results = new ArrayList();
/* 111 */     for (ContextResourceLink resourceLink : resourceLinks) {
/*     */       try
/*     */       {
/* 114 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), resourceLink);
/* 115 */         results.add(oname.toString());
/*     */       }
/*     */       catch (MalformedObjectNameException e) {
/* 118 */         throw new IllegalArgumentException(sm.getString("namingResourcesMBean.createObjectNameError.resourceLink", new Object[] { resourceLink }), e);
/*     */       }
/*     */     }
/* 121 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String addEnvironment(String envName, String type, String value)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 139 */     NamingResourcesImpl nresources = (NamingResourcesImpl)this.resource;
/* 140 */     if (nresources == null) {
/* 141 */       return null;
/*     */     }
/* 143 */     ContextEnvironment env = nresources.findEnvironment(envName);
/* 144 */     if (env != null) {
/* 145 */       throw new IllegalArgumentException(sm.getString("namingResourcesMBean.addAlreadyExists.environment", new Object[] { envName }));
/*     */     }
/* 147 */     env = new ContextEnvironment();
/* 148 */     env.setName(envName);
/* 149 */     env.setType(type);
/* 150 */     env.setValue(value);
/* 151 */     nresources.addEnvironment(env);
/*     */     
/*     */ 
/* 154 */     ManagedBean managed = this.registry.findManagedBean("ContextEnvironment");
/* 155 */     ObjectName oname = MBeanUtils.createObjectName(managed.getDomain(), env);
/* 156 */     return oname.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String addResource(String resourceName, String type)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 171 */     NamingResourcesImpl nresources = (NamingResourcesImpl)this.resource;
/* 172 */     if (nresources == null) {
/* 173 */       return null;
/*     */     }
/* 175 */     ContextResource resource = nresources.findResource(resourceName);
/* 176 */     if (resource != null) {
/* 177 */       throw new IllegalArgumentException(sm.getString("namingResourcesMBean.addAlreadyExists.resource", new Object[] { resourceName }));
/*     */     }
/* 179 */     resource = new ContextResource();
/* 180 */     resource.setName(resourceName);
/* 181 */     resource.setType(type);
/* 182 */     nresources.addResource(resource);
/*     */     
/*     */ 
/* 185 */     ManagedBean managed = this.registry.findManagedBean("ContextResource");
/* 186 */     ObjectName oname = MBeanUtils.createObjectName(managed.getDomain(), resource);
/* 187 */     return oname.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String addResourceLink(String resourceLinkName, String type)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 202 */     NamingResourcesImpl nresources = (NamingResourcesImpl)this.resource;
/* 203 */     if (nresources == null) {
/* 204 */       return null;
/*     */     }
/*     */     
/* 207 */     ContextResourceLink resourceLink = nresources.findResourceLink(resourceLinkName);
/* 208 */     if (resourceLink != null) {
/* 209 */       throw new IllegalArgumentException(sm.getString("namingResourcesMBean.addAlreadyExists.resourceLink", new Object[] { resourceLinkName }));
/*     */     }
/* 211 */     resourceLink = new ContextResourceLink();
/* 212 */     resourceLink.setName(resourceLinkName);
/* 213 */     resourceLink.setType(type);
/* 214 */     nresources.addResourceLink(resourceLink);
/*     */     
/*     */ 
/* 217 */     ManagedBean managed = this.registry.findManagedBean("ContextResourceLink");
/* 218 */     ObjectName oname = MBeanUtils.createObjectName(managed.getDomain(), resourceLink);
/* 219 */     return oname.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeEnvironment(String envName)
/*     */   {
/* 229 */     NamingResourcesImpl nresources = (NamingResourcesImpl)this.resource;
/* 230 */     if (nresources == null) {
/* 231 */       return;
/*     */     }
/* 233 */     ContextEnvironment env = nresources.findEnvironment(envName);
/* 234 */     if (env == null) {
/* 235 */       throw new IllegalArgumentException(sm.getString("namingResourcesMBean.removeNotFound.environment", new Object[] { envName }));
/*     */     }
/* 237 */     nresources.removeEnvironment(envName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeResource(String resourceName)
/*     */   {
/* 247 */     resourceName = ObjectName.unquote(resourceName);
/* 248 */     NamingResourcesImpl nresources = (NamingResourcesImpl)this.resource;
/* 249 */     if (nresources == null) {
/* 250 */       return;
/*     */     }
/* 252 */     ContextResource resource = nresources.findResource(resourceName);
/* 253 */     if (resource == null) {
/* 254 */       throw new IllegalArgumentException(sm.getString("namingResourcesMBean.removeNotFound.resource", new Object[] { resourceName }));
/*     */     }
/* 256 */     nresources.removeResource(resourceName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeResourceLink(String resourceLinkName)
/*     */   {
/* 266 */     resourceLinkName = ObjectName.unquote(resourceLinkName);
/* 267 */     NamingResourcesImpl nresources = (NamingResourcesImpl)this.resource;
/* 268 */     if (nresources == null) {
/* 269 */       return;
/*     */     }
/* 271 */     ContextResourceLink resourceLink = nresources.findResourceLink(resourceLinkName);
/* 272 */     if (resourceLink == null) {
/* 273 */       throw new IllegalArgumentException(sm.getString("namingResourcesMBean.removeNotFound.resourceLink", new Object[] { resourceLinkName }));
/*     */     }
/* 275 */     nresources.removeResourceLink(resourceLinkName);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\NamingResourcesMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */