/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericGroup<UD extends UserDatabase>
/*     */   extends AbstractGroup
/*     */ {
/*     */   protected final UD database;
/*     */   
/*     */   GenericGroup(UD database, String groupname, String description, List<Role> roles)
/*     */   {
/*  57 */     this.database = database;
/*  58 */     this.groupname = groupname;
/*  59 */     this.description = description;
/*  60 */     if (roles != null) {
/*  61 */       this.roles.addAll(roles);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   protected final CopyOnWriteArrayList<Role> roles = new CopyOnWriteArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<Role> getRoles()
/*     */   {
/*  90 */     return this.roles.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UserDatabase getUserDatabase()
/*     */   {
/*  99 */     return this.database;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<User> getUsers()
/*     */   {
/* 108 */     List<User> results = new ArrayList();
/* 109 */     Iterator<User> users = this.database.getUsers();
/* 110 */     while (users.hasNext()) {
/* 111 */       User user = (User)users.next();
/* 112 */       if (user.isInGroup(this)) {
/* 113 */         results.add(user);
/*     */       }
/*     */     }
/* 116 */     return results.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRole(Role role)
/*     */   {
/* 130 */     if (this.roles.addIfAbsent(role)) {
/* 131 */       this.database.modifiedGroup(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInRole(Role role)
/*     */   {
/* 143 */     return this.roles.contains(role);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRole(Role role)
/*     */   {
/* 154 */     if (this.roles.remove(role)) {
/* 155 */       this.database.modifiedGroup(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRoles()
/*     */   {
/* 165 */     if (!this.roles.isEmpty()) {
/* 166 */       this.roles.clear();
/* 167 */       this.database.modifiedGroup(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 174 */     if ((obj instanceof GenericGroup)) {
/* 175 */       GenericGroup<?> group = (GenericGroup)obj;
/* 176 */       return (group.database == this.database) && (this.groupname.equals(group.getGroupname()));
/*     */     }
/* 178 */     return super.equals(obj);
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 184 */     int prime = 31;
/* 185 */     int result = 1;
/* 186 */     result = 31 * result + (this.database == null ? 0 : this.database.hashCode());
/* 187 */     result = 31 * result + (this.groupname == null ? 0 : this.groupname.hashCode());
/* 188 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\users\GenericGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */