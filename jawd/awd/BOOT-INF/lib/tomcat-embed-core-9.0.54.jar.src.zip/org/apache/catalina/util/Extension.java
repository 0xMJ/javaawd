/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Extension
/*     */ {
/*  52 */   private String extensionName = null;
/*     */   
/*     */   public String getExtensionName()
/*     */   {
/*  56 */     return this.extensionName;
/*     */   }
/*     */   
/*     */   public void setExtensionName(String extensionName) {
/*  60 */     this.extensionName = extensionName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private String implementationURL = null;
/*     */   
/*     */   public String getImplementationURL() {
/*  70 */     return this.implementationURL;
/*     */   }
/*     */   
/*     */   public void setImplementationURL(String implementationURL) {
/*  74 */     this.implementationURL = implementationURL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */   private String implementationVendor = null;
/*     */   
/*     */   public String getImplementationVendor() {
/*  85 */     return this.implementationVendor;
/*     */   }
/*     */   
/*     */   public void setImplementationVendor(String implementationVendor) {
/*  89 */     this.implementationVendor = implementationVendor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */   private String implementationVendorId = null;
/*     */   
/*     */   public String getImplementationVendorId() {
/* 100 */     return this.implementationVendorId;
/*     */   }
/*     */   
/*     */   public void setImplementationVendorId(String implementationVendorId) {
/* 104 */     this.implementationVendorId = implementationVendorId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */   private String implementationVersion = null;
/*     */   
/*     */   public String getImplementationVersion() {
/* 115 */     return this.implementationVersion;
/*     */   }
/*     */   
/*     */   public void setImplementationVersion(String implementationVersion) {
/* 119 */     this.implementationVersion = implementationVersion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */   private String specificationVendor = null;
/*     */   
/*     */   public String getSpecificationVendor() {
/* 130 */     return this.specificationVendor;
/*     */   }
/*     */   
/*     */   public void setSpecificationVendor(String specificationVendor) {
/* 134 */     this.specificationVendor = specificationVendor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 142 */   private String specificationVersion = null;
/*     */   
/*     */   public String getSpecificationVersion() {
/* 145 */     return this.specificationVersion;
/*     */   }
/*     */   
/*     */   public void setSpecificationVersion(String specificationVersion) {
/* 149 */     this.specificationVersion = specificationVersion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */   private boolean fulfilled = false;
/*     */   
/*     */   public void setFulfilled(boolean fulfilled) {
/* 160 */     this.fulfilled = fulfilled;
/*     */   }
/*     */   
/*     */   public boolean isFulfilled() {
/* 164 */     return this.fulfilled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCompatibleWith(Extension required)
/*     */   {
/* 182 */     if (this.extensionName == null) {
/* 183 */       return false;
/*     */     }
/* 185 */     if (!this.extensionName.equals(required.getExtensionName())) {
/* 186 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 190 */     if ((required.getSpecificationVersion() != null) && 
/* 191 */       (!isNewer(this.specificationVersion, required
/* 192 */       .getSpecificationVersion()))) {
/* 193 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 198 */     if (required.getImplementationVendorId() != null) {
/* 199 */       if (this.implementationVendorId == null) {
/* 200 */         return false;
/*     */       }
/* 202 */       if (!this.implementationVendorId.equals(required
/* 203 */         .getImplementationVendorId())) {
/* 204 */         return false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 209 */     if ((required.getImplementationVersion() != null) && 
/* 210 */       (!isNewer(this.implementationVersion, required
/* 211 */       .getImplementationVersion()))) {
/* 212 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 217 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 223 */     StringBuilder sb = new StringBuilder("Extension[");
/* 224 */     sb.append(this.extensionName);
/* 225 */     if (this.implementationURL != null) {
/* 226 */       sb.append(", implementationURL=");
/* 227 */       sb.append(this.implementationURL);
/*     */     }
/* 229 */     if (this.implementationVendor != null) {
/* 230 */       sb.append(", implementationVendor=");
/* 231 */       sb.append(this.implementationVendor);
/*     */     }
/* 233 */     if (this.implementationVendorId != null) {
/* 234 */       sb.append(", implementationVendorId=");
/* 235 */       sb.append(this.implementationVendorId);
/*     */     }
/* 237 */     if (this.implementationVersion != null) {
/* 238 */       sb.append(", implementationVersion=");
/* 239 */       sb.append(this.implementationVersion);
/*     */     }
/* 241 */     if (this.specificationVendor != null) {
/* 242 */       sb.append(", specificationVendor=");
/* 243 */       sb.append(this.specificationVendor);
/*     */     }
/* 245 */     if (this.specificationVersion != null) {
/* 246 */       sb.append(", specificationVersion=");
/* 247 */       sb.append(this.specificationVersion);
/*     */     }
/* 249 */     sb.append(']');
/* 250 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isNewer(String first, String second)
/*     */     throws NumberFormatException
/*     */   {
/* 270 */     if ((first == null) || (second == null)) {
/* 271 */       return false;
/*     */     }
/* 273 */     if (first.equals(second)) {
/* 274 */       return true;
/*     */     }
/*     */     
/* 277 */     StringTokenizer fTok = new StringTokenizer(first, ".", true);
/* 278 */     StringTokenizer sTok = new StringTokenizer(second, ".", true);
/* 279 */     int fVersion = 0;
/* 280 */     int sVersion = 0;
/* 281 */     while ((fTok.hasMoreTokens()) || (sTok.hasMoreTokens())) {
/* 282 */       if (fTok.hasMoreTokens()) {
/* 283 */         fVersion = Integer.parseInt(fTok.nextToken());
/*     */       } else {
/* 285 */         fVersion = 0;
/*     */       }
/* 287 */       if (sTok.hasMoreTokens()) {
/* 288 */         sVersion = Integer.parseInt(sTok.nextToken());
/*     */       } else {
/* 290 */         sVersion = 0;
/*     */       }
/* 292 */       if (fVersion < sVersion)
/* 293 */         return false;
/* 294 */       if (fVersion > sVersion) {
/* 295 */         return true;
/*     */       }
/* 297 */       if (fTok.hasMoreTokens()) {
/* 298 */         fTok.nextToken();
/*     */       }
/* 300 */       if (sTok.hasMoreTokens()) {
/* 301 */         sTok.nextToken();
/*     */       }
/*     */     }
/*     */     
/* 305 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\Extension.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */