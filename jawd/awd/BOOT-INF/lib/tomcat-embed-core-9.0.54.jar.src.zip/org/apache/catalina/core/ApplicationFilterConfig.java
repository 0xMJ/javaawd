/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.management.ObjectName;
/*     */ import javax.naming.NamingException;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.descriptor.web.FilterDef;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.modeler.Util;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ApplicationFilterConfig
/*     */   implements FilterConfig, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  59 */   static final StringManager sm = StringManager.getManager(ApplicationFilterConfig.class);
/*     */   
/*  61 */   private transient Log log = LogFactory.getLog(ApplicationFilterConfig.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private static final List<String> emptyString = Collections.emptyList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final transient Context context;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ApplicationFilterConfig(Context context, FilterDef filterDef)
/*     */     throws ClassCastException, ReflectiveOperationException, ServletException, NamingException, IllegalArgumentException, SecurityException
/*     */   {
/*  97 */     this.context = context;
/*  98 */     this.filterDef = filterDef;
/*     */     
/* 100 */     if (filterDef.getFilter() == null) {
/* 101 */       getFilter();
/*     */     } else {
/* 103 */       this.filter = filterDef.getFilter();
/* 104 */       context.getInstanceManager().newInstance(this.filter);
/* 105 */       initFilter();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */   private transient Filter filter = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final FilterDef filterDef;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjectName oname;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFilterName()
/*     */   {
/* 143 */     return this.filterDef.getFilterName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFilterClass()
/*     */   {
/* 150 */     return this.filterDef.getFilterClass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getInitParameter(String name)
/*     */   {
/* 163 */     Map<String, String> map = this.filterDef.getParameterMap();
/* 164 */     if (map == null) {
/* 165 */       return null;
/*     */     }
/*     */     
/* 168 */     return (String)map.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enumeration<String> getInitParameterNames()
/*     */   {
/* 179 */     Map<String, String> map = this.filterDef.getParameterMap();
/*     */     
/* 181 */     if (map == null) {
/* 182 */       return Collections.enumeration(emptyString);
/*     */     }
/*     */     
/* 185 */     return Collections.enumeration(map.keySet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServletContext getServletContext()
/*     */   {
/* 195 */     return this.context.getServletContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 205 */     StringBuilder sb = new StringBuilder("ApplicationFilterConfig[");
/* 206 */     sb.append("name=");
/* 207 */     sb.append(this.filterDef.getFilterName());
/* 208 */     sb.append(", filterClass=");
/* 209 */     sb.append(this.filterDef.getFilterClass());
/* 210 */     sb.append(']');
/* 211 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<String, String> getFilterInitParameterMap()
/*     */   {
/* 217 */     return Collections.unmodifiableMap(this.filterDef.getParameterMap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Filter getFilter()
/*     */     throws ClassCastException, ReflectiveOperationException, ServletException, NamingException, IllegalArgumentException, SecurityException
/*     */   {
/* 243 */     if (this.filter != null) {
/* 244 */       return this.filter;
/*     */     }
/*     */     
/*     */ 
/* 248 */     String filterClass = this.filterDef.getFilterClass();
/* 249 */     this.filter = ((Filter)this.context.getInstanceManager().newInstance(filterClass));
/*     */     
/* 251 */     initFilter();
/*     */     
/* 253 */     return this.filter;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void initFilter()
/*     */     throws ServletException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 6	org/apache/catalina/core/ApplicationFilterConfig:context	Lorg/apache/catalina/Context;
/*     */     //   4: instanceof 33
/*     */     //   7: ifeq +87 -> 94
/*     */     //   10: aload_0
/*     */     //   11: getfield 6	org/apache/catalina/core/ApplicationFilterConfig:context	Lorg/apache/catalina/Context;
/*     */     //   14: invokeinterface 34 1 0
/*     */     //   19: ifeq +75 -> 94
/*     */     //   22: invokestatic 35	org/apache/tomcat/util/log/SystemLogHandler:startCapture	()V
/*     */     //   25: aload_0
/*     */     //   26: getfield 5	org/apache/catalina/core/ApplicationFilterConfig:filter	Ljavax/servlet/Filter;
/*     */     //   29: aload_0
/*     */     //   30: invokeinterface 36 2 0
/*     */     //   35: invokestatic 37	org/apache/tomcat/util/log/SystemLogHandler:stopCapture	()Ljava/lang/String;
/*     */     //   38: astore_1
/*     */     //   39: aload_1
/*     */     //   40: ifnull +20 -> 60
/*     */     //   43: aload_1
/*     */     //   44: invokevirtual 38	java/lang/String:length	()I
/*     */     //   47: ifle +13 -> 60
/*     */     //   50: aload_0
/*     */     //   51: invokevirtual 39	org/apache/catalina/core/ApplicationFilterConfig:getServletContext	()Ljavax/servlet/ServletContext;
/*     */     //   54: aload_1
/*     */     //   55: invokeinterface 40 2 0
/*     */     //   60: goto +31 -> 91
/*     */     //   63: astore_2
/*     */     //   64: invokestatic 37	org/apache/tomcat/util/log/SystemLogHandler:stopCapture	()Ljava/lang/String;
/*     */     //   67: astore_3
/*     */     //   68: aload_3
/*     */     //   69: ifnull +20 -> 89
/*     */     //   72: aload_3
/*     */     //   73: invokevirtual 38	java/lang/String:length	()I
/*     */     //   76: ifle +13 -> 89
/*     */     //   79: aload_0
/*     */     //   80: invokevirtual 39	org/apache/catalina/core/ApplicationFilterConfig:getServletContext	()Ljavax/servlet/ServletContext;
/*     */     //   83: aload_3
/*     */     //   84: invokeinterface 40 2 0
/*     */     //   89: aload_2
/*     */     //   90: athrow
/*     */     //   91: goto +13 -> 104
/*     */     //   94: aload_0
/*     */     //   95: getfield 5	org/apache/catalina/core/ApplicationFilterConfig:filter	Ljavax/servlet/Filter;
/*     */     //   98: aload_0
/*     */     //   99: invokeinterface 36 2 0
/*     */     //   104: aload_0
/*     */     //   105: invokespecial 41	org/apache/catalina/core/ApplicationFilterConfig:registerJMX	()V
/*     */     //   108: return
/*     */     // Line number table:
/*     */     //   Java source line #258	-> byte code offset #0
/*     */     //   Java source line #259	-> byte code offset #14
/*     */     //   Java source line #261	-> byte code offset #22
/*     */     //   Java source line #262	-> byte code offset #25
/*     */     //   Java source line #264	-> byte code offset #35
/*     */     //   Java source line #265	-> byte code offset #39
/*     */     //   Java source line #266	-> byte code offset #50
/*     */     //   Java source line #268	-> byte code offset #60
/*     */     //   Java source line #264	-> byte code offset #63
/*     */     //   Java source line #265	-> byte code offset #68
/*     */     //   Java source line #266	-> byte code offset #79
/*     */     //   Java source line #268	-> byte code offset #89
/*     */     //   Java source line #270	-> byte code offset #94
/*     */     //   Java source line #274	-> byte code offset #104
/*     */     //   Java source line #275	-> byte code offset #108
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	109	0	this	ApplicationFilterConfig
/*     */     //   38	17	1	capturedlog	String
/*     */     //   63	27	2	localObject	Object
/*     */     //   67	17	3	capturedlog	String
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   22	35	63	finally
/*     */   }
/*     */   
/*     */   FilterDef getFilterDef()
/*     */   {
/* 281 */     return this.filterDef;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   void release()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial 42	org/apache/catalina/core/ApplicationFilterConfig:unregisterJMX	()V
/*     */     //   4: aload_0
/*     */     //   5: getfield 5	org/apache/catalina/core/ApplicationFilterConfig:filter	Ljavax/servlet/Filter;
/*     */     //   8: ifnull +195 -> 203
/*     */     //   11: getstatic 43	org/apache/catalina/Globals:IS_SECURITY_ENABLED	Z
/*     */     //   14: ifeq +35 -> 49
/*     */     //   17: ldc 44
/*     */     //   19: aload_0
/*     */     //   20: getfield 5	org/apache/catalina/core/ApplicationFilterConfig:filter	Ljavax/servlet/Filter;
/*     */     //   23: invokestatic 45	org/apache/catalina/security/SecurityUtil:doAsPrivilege	(Ljava/lang/String;Ljavax/servlet/Filter;)V
/*     */     //   26: aload_0
/*     */     //   27: getfield 5	org/apache/catalina/core/ApplicationFilterConfig:filter	Ljavax/servlet/Filter;
/*     */     //   30: invokestatic 46	org/apache/catalina/security/SecurityUtil:remove	(Ljava/lang/Object;)V
/*     */     //   33: goto +13 -> 46
/*     */     //   36: astore_1
/*     */     //   37: aload_0
/*     */     //   38: getfield 5	org/apache/catalina/core/ApplicationFilterConfig:filter	Ljavax/servlet/Filter;
/*     */     //   41: invokestatic 46	org/apache/catalina/security/SecurityUtil:remove	(Ljava/lang/Object;)V
/*     */     //   44: aload_1
/*     */     //   45: athrow
/*     */     //   46: goto +12 -> 58
/*     */     //   49: aload_0
/*     */     //   50: getfield 5	org/apache/catalina/core/ApplicationFilterConfig:filter	Ljavax/servlet/Filter;
/*     */     //   53: invokeinterface 47 1 0
/*     */     //   58: goto +55 -> 113
/*     */     //   61: astore_1
/*     */     //   62: aload_1
/*     */     //   63: invokestatic 49	org/apache/tomcat/util/ExceptionUtils:handleThrowable	(Ljava/lang/Throwable;)V
/*     */     //   66: aload_0
/*     */     //   67: getfield 6	org/apache/catalina/core/ApplicationFilterConfig:context	Lorg/apache/catalina/Context;
/*     */     //   70: invokeinterface 50 1 0
/*     */     //   75: getstatic 51	org/apache/catalina/core/ApplicationFilterConfig:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   78: ldc 52
/*     */     //   80: iconst_2
/*     */     //   81: anewarray 53	java/lang/Object
/*     */     //   84: dup
/*     */     //   85: iconst_0
/*     */     //   86: aload_0
/*     */     //   87: getfield 7	org/apache/catalina/core/ApplicationFilterConfig:filterDef	Lorg/apache/tomcat/util/descriptor/web/FilterDef;
/*     */     //   90: invokevirtual 13	org/apache/tomcat/util/descriptor/web/FilterDef:getFilterName	()Ljava/lang/String;
/*     */     //   93: aastore
/*     */     //   94: dup
/*     */     //   95: iconst_1
/*     */     //   96: aload_0
/*     */     //   97: getfield 7	org/apache/catalina/core/ApplicationFilterConfig:filterDef	Lorg/apache/tomcat/util/descriptor/web/FilterDef;
/*     */     //   100: invokevirtual 14	org/apache/tomcat/util/descriptor/web/FilterDef:getFilterClass	()Ljava/lang/String;
/*     */     //   103: aastore
/*     */     //   104: invokevirtual 54	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   107: aload_1
/*     */     //   108: invokeinterface 55 3 0
/*     */     //   113: aload_0
/*     */     //   114: getfield 6	org/apache/catalina/core/ApplicationFilterConfig:context	Lorg/apache/catalina/Context;
/*     */     //   117: invokeinterface 56 1 0
/*     */     //   122: ifne +81 -> 203
/*     */     //   125: aload_0
/*     */     //   126: getfield 6	org/apache/catalina/core/ApplicationFilterConfig:context	Lorg/apache/catalina/Context;
/*     */     //   129: invokeinterface 10 1 0
/*     */     //   134: aload_0
/*     */     //   135: getfield 5	org/apache/catalina/core/ApplicationFilterConfig:filter	Ljavax/servlet/Filter;
/*     */     //   138: invokeinterface 57 2 0
/*     */     //   143: goto +60 -> 203
/*     */     //   146: astore_1
/*     */     //   147: aload_1
/*     */     //   148: invokestatic 59	org/apache/tomcat/util/ExceptionUtils:unwrapInvocationTargetException	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*     */     //   151: astore_2
/*     */     //   152: aload_2
/*     */     //   153: invokestatic 49	org/apache/tomcat/util/ExceptionUtils:handleThrowable	(Ljava/lang/Throwable;)V
/*     */     //   156: aload_0
/*     */     //   157: getfield 6	org/apache/catalina/core/ApplicationFilterConfig:context	Lorg/apache/catalina/Context;
/*     */     //   160: invokeinterface 50 1 0
/*     */     //   165: getstatic 51	org/apache/catalina/core/ApplicationFilterConfig:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   168: ldc 60
/*     */     //   170: iconst_2
/*     */     //   171: anewarray 53	java/lang/Object
/*     */     //   174: dup
/*     */     //   175: iconst_0
/*     */     //   176: aload_0
/*     */     //   177: getfield 7	org/apache/catalina/core/ApplicationFilterConfig:filterDef	Lorg/apache/tomcat/util/descriptor/web/FilterDef;
/*     */     //   180: invokevirtual 13	org/apache/tomcat/util/descriptor/web/FilterDef:getFilterName	()Ljava/lang/String;
/*     */     //   183: aastore
/*     */     //   184: dup
/*     */     //   185: iconst_1
/*     */     //   186: aload_0
/*     */     //   187: getfield 7	org/apache/catalina/core/ApplicationFilterConfig:filterDef	Lorg/apache/tomcat/util/descriptor/web/FilterDef;
/*     */     //   190: invokevirtual 14	org/apache/tomcat/util/descriptor/web/FilterDef:getFilterClass	()Ljava/lang/String;
/*     */     //   193: aastore
/*     */     //   194: invokevirtual 54	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   197: aload_2
/*     */     //   198: invokeinterface 55 3 0
/*     */     //   203: aload_0
/*     */     //   204: aconst_null
/*     */     //   205: putfield 5	org/apache/catalina/core/ApplicationFilterConfig:filter	Ljavax/servlet/Filter;
/*     */     //   208: return
/*     */     // Line number table:
/*     */     //   Java source line #290	-> byte code offset #0
/*     */     //   Java source line #292	-> byte code offset #4
/*     */     //   Java source line #294	-> byte code offset #11
/*     */     //   Java source line #296	-> byte code offset #17
/*     */     //   Java source line #298	-> byte code offset #26
/*     */     //   Java source line #299	-> byte code offset #33
/*     */     //   Java source line #298	-> byte code offset #36
/*     */     //   Java source line #299	-> byte code offset #44
/*     */     //   Java source line #301	-> byte code offset #49
/*     */     //   Java source line #309	-> byte code offset #58
/*     */     //   Java source line #303	-> byte code offset #61
/*     */     //   Java source line #304	-> byte code offset #62
/*     */     //   Java source line #305	-> byte code offset #66
/*     */     //   Java source line #307	-> byte code offset #90
/*     */     //   Java source line #308	-> byte code offset #100
/*     */     //   Java source line #305	-> byte code offset #104
/*     */     //   Java source line #310	-> byte code offset #113
/*     */     //   Java source line #312	-> byte code offset #125
/*     */     //   Java source line #320	-> byte code offset #143
/*     */     //   Java source line #313	-> byte code offset #146
/*     */     //   Java source line #314	-> byte code offset #147
/*     */     //   Java source line #315	-> byte code offset #148
/*     */     //   Java source line #316	-> byte code offset #152
/*     */     //   Java source line #317	-> byte code offset #156
/*     */     //   Java source line #319	-> byte code offset #180
/*     */     //   Java source line #318	-> byte code offset #194
/*     */     //   Java source line #317	-> byte code offset #198
/*     */     //   Java source line #323	-> byte code offset #203
/*     */     //   Java source line #325	-> byte code offset #208
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	209	0	this	ApplicationFilterConfig
/*     */     //   36	9	1	localObject	Object
/*     */     //   61	47	1	t	Throwable
/*     */     //   146	2	1	e	Exception
/*     */     //   151	47	2	t	Throwable
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   17	26	36	finally
/*     */     //   11	58	61	java/lang/Throwable
/*     */     //   125	143	146	java/lang/Exception
/*     */   }
/*     */   
/*     */   private void registerJMX()
/*     */   {
/* 331 */     String parentName = this.context.getName();
/* 332 */     if (!parentName.startsWith("/")) {
/* 333 */       parentName = "/" + parentName;
/*     */     }
/*     */     
/* 336 */     String hostName = this.context.getParent().getName();
/* 337 */     hostName = hostName == null ? "DEFAULT" : hostName;
/*     */     
/*     */ 
/* 340 */     String domain = this.context.getParent().getParent().getName();
/*     */     
/* 342 */     String webMod = "//" + hostName + parentName;
/* 343 */     String onameStr = null;
/* 344 */     String filterName = this.filterDef.getFilterName();
/* 345 */     if (Util.objectNameValueNeedsQuote(filterName)) {
/* 346 */       filterName = ObjectName.quote(filterName);
/*     */     }
/* 348 */     if ((this.context instanceof StandardContext)) {
/* 349 */       StandardContext standardContext = (StandardContext)this.context;
/*     */       
/*     */ 
/*     */ 
/* 353 */       onameStr = domain + ":j2eeType=Filter,WebModule=" + webMod + ",name=" + filterName + ",J2EEApplication=" + standardContext.getJ2EEApplication() + ",J2EEServer=" + standardContext.getJ2EEServer();
/*     */     } else {
/* 355 */       onameStr = domain + ":j2eeType=Filter,name=" + filterName + ",WebModule=" + webMod;
/*     */     }
/*     */     try
/*     */     {
/* 359 */       this.oname = new ObjectName(onameStr);
/* 360 */       Registry.getRegistry(null, null).registerComponent(this, this.oname, null);
/*     */     } catch (Exception ex) {
/* 362 */       this.log.warn(sm.getString("applicationFilterConfig.jmxRegisterFail", new Object[] {
/* 363 */         getFilterClass(), getFilterName() }), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void unregisterJMX()
/*     */   {
/* 370 */     if (this.oname != null) {
/*     */       try {
/* 372 */         Registry.getRegistry(null, null).unregisterComponent(this.oname);
/* 373 */         if (this.log.isDebugEnabled()) {
/* 374 */           this.log.debug(sm.getString("applicationFilterConfig.jmxUnregister", new Object[] {
/* 375 */             getFilterClass(), getFilterName() }));
/*     */         }
/*     */       } catch (Exception ex) {
/* 378 */         this.log.warn(sm.getString("applicationFilterConfig.jmxUnregisterFail", new Object[] {
/* 379 */           getFilterClass(), getFilterName() }), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream ois)
/*     */     throws ClassNotFoundException, IOException
/*     */   {
/* 389 */     ois.defaultReadObject();
/* 390 */     this.log = LogFactory.getLog(ApplicationFilterConfig.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\ApplicationFilterConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */