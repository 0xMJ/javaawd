/*    */ package org.apache.catalina.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AprStatus
/*    */ {
/* 23 */   private static volatile boolean aprInitialized = false;
/* 24 */   private static volatile boolean aprAvailable = false;
/* 25 */   private static volatile boolean useAprConnector = false;
/* 26 */   private static volatile boolean useOpenSSL = true;
/* 27 */   private static volatile boolean instanceCreated = false;
/*    */   
/*    */   public static boolean isAprInitialized()
/*    */   {
/* 31 */     return aprInitialized;
/*    */   }
/*    */   
/*    */   public static boolean isAprAvailable() {
/* 35 */     return aprAvailable;
/*    */   }
/*    */   
/*    */   public static boolean getUseAprConnector() {
/* 39 */     return useAprConnector;
/*    */   }
/*    */   
/*    */   public static boolean getUseOpenSSL() {
/* 43 */     return useOpenSSL;
/*    */   }
/*    */   
/*    */   public static boolean isInstanceCreated() {
/* 47 */     return instanceCreated;
/*    */   }
/*    */   
/*    */   public static void setAprInitialized(boolean aprInitialized) {
/* 51 */     aprInitialized = aprInitialized;
/*    */   }
/*    */   
/*    */   public static void setAprAvailable(boolean aprAvailable) {
/* 55 */     aprAvailable = aprAvailable;
/*    */   }
/*    */   
/*    */   public static void setUseAprConnector(boolean useAprConnector) {
/* 59 */     useAprConnector = useAprConnector;
/*    */   }
/*    */   
/*    */   public static void setUseOpenSSL(boolean useOpenSSL) {
/* 63 */     useOpenSSL = useOpenSSL;
/*    */   }
/*    */   
/*    */   public static void setInstanceCreated(boolean instanceCreated) {
/* 67 */     instanceCreated = instanceCreated;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\AprStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */