/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import org.apache.tomcat.util.security.Escape;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMWriter
/*     */ {
/*     */   private final PrintWriter out;
/*     */   
/*     */   public DOMWriter(Writer writer)
/*     */   {
/*  38 */     this.out = new PrintWriter(writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void print(Node node)
/*     */   {
/*  49 */     if (node == null) {
/*  50 */       return;
/*     */     }
/*     */     
/*  53 */     int type = node.getNodeType();
/*  54 */     switch (type)
/*     */     {
/*     */     case 9: 
/*  57 */       print(((Document)node).getDocumentElement());
/*  58 */       this.out.flush();
/*  59 */       break;
/*     */     
/*     */ 
/*     */     case 1: 
/*  63 */       this.out.print('<');
/*  64 */       this.out.print(node.getLocalName());
/*  65 */       Attr[] attrs = sortAttributes(node.getAttributes());
/*  66 */       for (Attr attr : attrs) {
/*  67 */         this.out.print(' ');
/*  68 */         this.out.print(attr.getLocalName());
/*     */         
/*  70 */         this.out.print("=\"");
/*  71 */         this.out.print(Escape.xml("", true, attr.getNodeValue()));
/*  72 */         this.out.print('"');
/*     */       }
/*  74 */       this.out.print('>');
/*  75 */       printChildren(node);
/*  76 */       break;
/*     */     
/*     */ 
/*     */     case 5: 
/*  80 */       printChildren(node);
/*  81 */       break;
/*     */     
/*     */ 
/*     */     case 4: 
/*  85 */       this.out.print(Escape.xml("", true, node.getNodeValue()));
/*  86 */       break;
/*     */     
/*     */ 
/*     */     case 3: 
/*  90 */       this.out.print(Escape.xml("", true, node.getNodeValue()));
/*  91 */       break;
/*     */     
/*     */ 
/*     */     case 7: 
/*  95 */       this.out.print("<?");
/*  96 */       this.out.print(node.getLocalName());
/*     */       
/*  98 */       String data = node.getNodeValue();
/*  99 */       if ((data != null) && (data.length() > 0)) {
/* 100 */         this.out.print(' ');
/* 101 */         this.out.print(data);
/*     */       }
/* 103 */       this.out.print("?>");
/*     */     }
/*     */     
/*     */     
/* 107 */     if (type == 1) {
/* 108 */       this.out.print("</");
/* 109 */       this.out.print(node.getLocalName());
/* 110 */       this.out.print('>');
/*     */     }
/*     */     
/* 113 */     this.out.flush();
/*     */   }
/*     */   
/*     */ 
/*     */   private void printChildren(Node node)
/*     */   {
/* 119 */     NodeList children = node.getChildNodes();
/* 120 */     if (children != null) {
/* 121 */       int len = children.getLength();
/* 122 */       for (int i = 0; i < len; i++) {
/* 123 */         print(children.item(i));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Attr[] sortAttributes(NamedNodeMap attrs)
/*     */   {
/* 135 */     if (attrs == null) {
/* 136 */       return new Attr[0];
/*     */     }
/*     */     
/* 139 */     int len = attrs.getLength();
/* 140 */     Attr[] array = new Attr[len];
/* 141 */     for (int i = 0; i < len; i++) {
/* 142 */       array[i] = ((Attr)attrs.item(i));
/*     */     }
/* 144 */     for (int i = 0; i < len - 1; i++) {
/* 145 */       String name = null;
/* 146 */       name = array[i].getLocalName();
/* 147 */       int index = i;
/* 148 */       for (int j = i + 1; j < len; j++) {
/* 149 */         String curName = null;
/* 150 */         curName = array[j].getLocalName();
/* 151 */         if (curName.compareTo(name) < 0) {
/* 152 */           name = curName;
/* 153 */           index = j;
/*     */         }
/*     */       }
/* 156 */       if (index != i) {
/* 157 */         Attr temp = array[i];
/* 158 */         array[i] = array[index];
/* 159 */         array[index] = temp;
/*     */       }
/*     */     }
/*     */     
/* 163 */     return array;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\DOMWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */