/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Random;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CsrfPreventionFilterBase
/*     */   extends FilterBase
/*     */ {
/*  34 */   private final Log log = LogFactory.getLog(CsrfPreventionFilterBase.class);
/*     */   
/*  36 */   private String randomClass = SecureRandom.class.getName();
/*     */   
/*     */   private Random randomSource;
/*     */   
/*  40 */   private int denyStatus = 403;
/*     */   
/*     */   protected Log getLogger()
/*     */   {
/*  44 */     return this.log;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getDenyStatus()
/*     */   {
/*  51 */     return this.denyStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDenyStatus(int denyStatus)
/*     */   {
/*  62 */     this.denyStatus = denyStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRandomClass(String randomClass)
/*     */   {
/*  73 */     this.randomClass = randomClass;
/*     */   }
/*     */   
/*     */   public void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/*  79 */     super.init(filterConfig);
/*     */     try
/*     */     {
/*  82 */       Class<?> clazz = Class.forName(this.randomClass);
/*  83 */       this.randomSource = ((Random)clazz.getConstructor(new Class[0]).newInstance(new Object[0]));
/*     */     } catch (ReflectiveOperationException e) {
/*  85 */       ServletException se = new ServletException(sm.getString("csrfPrevention.invalidRandomClass", new Object[] { this.randomClass }), e);
/*     */       
/*  87 */       throw se;
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean isConfigProblemFatal()
/*     */   {
/*  93 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String generateNonce()
/*     */   {
/* 104 */     byte[] random = new byte[16];
/*     */     
/*     */ 
/* 107 */     StringBuilder buffer = new StringBuilder();
/*     */     
/* 109 */     this.randomSource.nextBytes(random);
/*     */     
/* 111 */     for (byte b : random) {
/* 112 */       byte b1 = (byte)((b & 0xF0) >> 4);
/* 113 */       byte b2 = (byte)(b & 0xF);
/* 114 */       if (b1 < 10) {
/* 115 */         buffer.append((char)(48 + b1));
/*     */       } else {
/* 117 */         buffer.append((char)(65 + (b1 - 10)));
/*     */       }
/* 119 */       if (b2 < 10) {
/* 120 */         buffer.append((char)(48 + b2));
/*     */       } else {
/* 122 */         buffer.append((char)(65 + (b2 - 10)));
/*     */       }
/*     */     }
/*     */     
/* 126 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   protected String getRequestedPath(HttpServletRequest request) {
/* 130 */     String path = request.getServletPath();
/* 131 */     if (request.getPathInfo() != null) {
/* 132 */       path = path + request.getPathInfo();
/*     */     }
/* 134 */     return path;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\filters\CsrfPreventionFilterBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */