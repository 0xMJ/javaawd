/*    */ package org.apache.catalina.valves;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.catalina.connector.Connector;
/*    */ import org.apache.catalina.connector.Request;
/*    */ import org.apache.catalina.connector.Response;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RemoteHostValve
/*    */   extends RequestFilterValve
/*    */ {
/* 37 */   private static final Log log = LogFactory.getLog(RemoteHostValve.class);
/*    */   
/*    */ 
/*    */   public void invoke(Request request, Response response)
/*    */     throws IOException, ServletException
/*    */   {
/*    */     String property;
/*    */     String property;
/* 45 */     if (getAddConnectorPort())
/*    */     {
/* 47 */       property = request.getRequest().getRemoteHost() + ";" + request.getConnector().getPortWithOffset();
/*    */     } else {
/* 49 */       property = request.getRequest().getRemoteHost();
/*    */     }
/* 51 */     process(property, request, response);
/*    */   }
/*    */   
/*    */ 
/*    */   protected Log getLog()
/*    */   {
/* 57 */     return log;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\RemoteHostValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */