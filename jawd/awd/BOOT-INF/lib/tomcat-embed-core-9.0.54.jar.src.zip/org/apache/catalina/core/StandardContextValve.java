/*    */ package org.apache.catalina.core;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import org.apache.catalina.Container;
/*    */ import org.apache.catalina.Pipeline;
/*    */ import org.apache.catalina.Valve;
/*    */ import org.apache.catalina.Wrapper;
/*    */ import org.apache.catalina.connector.Request;
/*    */ import org.apache.catalina.connector.Response;
/*    */ import org.apache.catalina.valves.ValveBase;
/*    */ import org.apache.coyote.ContinueResponseTiming;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.tomcat.util.buf.MessageBytes;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StandardContextValve
/*    */   extends ValveBase
/*    */ {
/* 44 */   private static final StringManager sm = StringManager.getManager(StandardContextValve.class);
/*    */   
/*    */   public StandardContextValve() {
/* 47 */     super(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final void invoke(Request request, Response response)
/*    */     throws IOException, ServletException
/*    */   {
/* 67 */     MessageBytes requestPathMB = request.getRequestPathMB();
/* 68 */     if ((requestPathMB.startsWithIgnoreCase("/META-INF/", 0)) || 
/* 69 */       (requestPathMB.equalsIgnoreCase("/META-INF")) || 
/* 70 */       (requestPathMB.startsWithIgnoreCase("/WEB-INF/", 0)) || 
/* 71 */       (requestPathMB.equalsIgnoreCase("/WEB-INF"))) {
/* 72 */       response.sendError(404);
/* 73 */       return;
/*    */     }
/*    */     
/*    */ 
/* 77 */     Wrapper wrapper = request.getWrapper();
/* 78 */     if ((wrapper == null) || (wrapper.isUnavailable())) {
/* 79 */       response.sendError(404);
/* 80 */       return;
/*    */     }
/*    */     
/*    */     try
/*    */     {
/* 85 */       response.sendAcknowledgement(ContinueResponseTiming.IMMEDIATELY);
/*    */     } catch (IOException ioe) {
/* 87 */       this.container.getLogger().error(sm.getString("standardContextValve.acknowledgeException"), ioe);
/*    */       
/* 89 */       request.setAttribute("javax.servlet.error.exception", ioe);
/* 90 */       response.sendError(500);
/* 91 */       return;
/*    */     }
/*    */     
/* 94 */     if (request.isAsyncSupported()) {
/* 95 */       request.setAsyncSupported(wrapper.getPipeline().isAsyncSupported());
/*    */     }
/* 97 */     wrapper.getPipeline().getFirst().invoke(request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\StandardContextValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */