/*     */ package org.apache.catalina.realm;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.callback.NameCallback;
/*     */ import javax.security.auth.callback.PasswordCallback;
/*     */ import javax.security.auth.callback.TextInputCallback;
/*     */ import javax.security.auth.callback.UnsupportedCallbackException;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.CredentialHandler;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JAASCallbackHandler
/*     */   implements CallbackHandler
/*     */ {
/*     */   public JAASCallbackHandler(JAASRealm realm, String username, String password)
/*     */   {
/*  64 */     this(realm, username, password, null, null, null, null, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JAASCallbackHandler(JAASRealm realm, String username, String password, String nonce, String nc, String cnonce, String qop, String realmName, String md5a2, String authMethod)
/*     */   {
/*  88 */     this.realm = realm;
/*  89 */     this.username = username;
/*     */     
/*  91 */     if ((password != null) && (realm.hasMessageDigest())) {
/*  92 */       this.password = realm.getCredentialHandler().mutate(password);
/*     */     } else {
/*  94 */       this.password = password;
/*     */     }
/*  96 */     this.nonce = nonce;
/*  97 */     this.nc = nc;
/*  98 */     this.cnonce = cnonce;
/*  99 */     this.qop = qop;
/* 100 */     this.realmName = realmName;
/* 101 */     this.md5a2 = md5a2;
/* 102 */     this.authMethod = authMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */   protected static final StringManager sm = StringManager.getManager(JAASCallbackHandler.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final JAASRealm realm;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String username;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String nonce;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String nc;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String cnonce;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String qop;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String realmName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String md5a2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String authMethod;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handle(Callback[] callbacks)
/*     */     throws IOException, UnsupportedCallbackException
/*     */   {
/* 183 */     for (Callback callback : callbacks)
/*     */     {
/* 185 */       if ((callback instanceof NameCallback)) {
/* 186 */         if (this.realm.getContainer().getLogger().isTraceEnabled()) {
/* 187 */           this.realm.getContainer().getLogger().trace(sm.getString("jaasCallback.username", new Object[] { this.username }));
/*     */         }
/* 189 */         ((NameCallback)callback).setName(this.username);
/*     */       }
/* 191 */       else if ((callback instanceof PasswordCallback)) { char[] passwordcontents;
/*     */         char[] passwordcontents;
/* 193 */         if (this.password != null) {
/* 194 */           passwordcontents = this.password.toCharArray();
/*     */         } else {
/* 196 */           passwordcontents = new char[0];
/*     */         }
/*     */         
/* 199 */         ((PasswordCallback)callback).setPassword(passwordcontents);
/*     */       }
/* 201 */       else if ((callback instanceof TextInputCallback)) {
/* 202 */         TextInputCallback cb = (TextInputCallback)callback;
/* 203 */         if (cb.getPrompt().equals("nonce")) {
/* 204 */           cb.setText(this.nonce);
/*     */         }
/* 206 */         else if (cb.getPrompt().equals("nc")) {
/* 207 */           cb.setText(this.nc);
/*     */         }
/* 209 */         else if (cb.getPrompt().equals("cnonce")) {
/* 210 */           cb.setText(this.cnonce);
/*     */         }
/* 212 */         else if (cb.getPrompt().equals("qop")) {
/* 213 */           cb.setText(this.qop);
/*     */         }
/* 215 */         else if (cb.getPrompt().equals("realmName")) {
/* 216 */           cb.setText(this.realmName);
/*     */         }
/* 218 */         else if (cb.getPrompt().equals("md5a2")) {
/* 219 */           cb.setText(this.md5a2);
/*     */         }
/* 221 */         else if (cb.getPrompt().equals("authMethod")) {
/* 222 */           cb.setText(this.authMethod);
/*     */         }
/* 224 */         else if (cb.getPrompt().equals("catalinaBase")) {
/* 225 */           cb.setText(this.realm.getContainer().getCatalinaBase().getAbsolutePath());
/*     */         } else {
/* 227 */           throw new UnsupportedCallbackException(callback);
/*     */         }
/*     */       } else {
/* 230 */         throw new UnsupportedCallbackException(callback);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\JAASCallbackHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */