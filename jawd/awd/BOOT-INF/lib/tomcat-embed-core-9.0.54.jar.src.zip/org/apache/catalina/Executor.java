package org.apache.catalina;

import java.util.concurrent.TimeUnit;

public abstract interface Executor
  extends java.util.concurrent.Executor, Lifecycle
{
  public abstract String getName();
  
  @Deprecated
  public abstract void execute(Runnable paramRunnable, long paramLong, TimeUnit paramTimeUnit);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\Executor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */