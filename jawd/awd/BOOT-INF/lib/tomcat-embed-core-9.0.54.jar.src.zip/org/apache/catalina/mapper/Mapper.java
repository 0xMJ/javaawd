/*      */ package org.apache.catalina.mapper;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import javax.servlet.http.MappingMatch;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.WebResource;
/*      */ import org.apache.catalina.WebResourceRoot;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.buf.Ascii;
/*      */ import org.apache.tomcat.util.buf.CharChunk;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Mapper
/*      */ {
/*   51 */   private static final Log log = LogFactory.getLog(Mapper.class);
/*      */   
/*   53 */   private static final StringManager sm = StringManager.getManager(Mapper.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   62 */   volatile MappedHost[] hosts = new MappedHost[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   68 */   private volatile String defaultHostName = null;
/*   69 */   private volatile MappedHost defaultHost = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   76 */   private final Map<Context, ContextVersion> contextObjectToContextVersionMap = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void setDefaultHostName(String defaultHostName)
/*      */   {
/*   88 */     this.defaultHostName = renameWildcardHost(defaultHostName);
/*   89 */     if (this.defaultHostName == null) {
/*   90 */       this.defaultHost = null;
/*      */     } else {
/*   92 */       this.defaultHost = ((MappedHost)exactFind(this.hosts, this.defaultHostName));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void addHost(String name, String[] aliases, Host host)
/*      */   {
/*  106 */     name = renameWildcardHost(name);
/*  107 */     MappedHost[] newHosts = new MappedHost[this.hosts.length + 1];
/*  108 */     MappedHost newHost = new MappedHost(name, host);
/*  109 */     if (insertMap(this.hosts, newHosts, newHost)) {
/*  110 */       this.hosts = newHosts;
/*  111 */       if (newHost.name.equals(this.defaultHostName)) {
/*  112 */         this.defaultHost = newHost;
/*      */       }
/*  114 */       if (log.isDebugEnabled()) {
/*  115 */         log.debug(sm.getString("mapper.addHost.success", new Object[] { name }));
/*      */       }
/*      */     } else {
/*  118 */       MappedHost duplicate = this.hosts[find(this.hosts, name)];
/*  119 */       if (duplicate.object == host)
/*      */       {
/*      */ 
/*  122 */         if (log.isDebugEnabled()) {
/*  123 */           log.debug(sm.getString("mapper.addHost.sameHost", new Object[] { name }));
/*      */         }
/*  125 */         newHost = duplicate;
/*      */       } else {
/*  127 */         log.error(sm.getString("mapper.duplicateHost", new Object[] { name, duplicate
/*  128 */           .getRealHostName() }));
/*      */         
/*      */ 
/*  131 */         return;
/*      */       }
/*      */     }
/*  134 */     List<MappedHost> newAliases = new ArrayList(aliases.length);
/*  135 */     for (String alias : aliases) {
/*  136 */       alias = renameWildcardHost(alias);
/*  137 */       MappedHost newAlias = new MappedHost(alias, newHost);
/*  138 */       if (addHostAliasImpl(newAlias)) {
/*  139 */         newAliases.add(newAlias);
/*      */       }
/*      */     }
/*  142 */     newHost.addAliases(newAliases);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void removeHost(String name)
/*      */   {
/*  152 */     name = renameWildcardHost(name);
/*      */     
/*  154 */     MappedHost host = (MappedHost)exactFind(this.hosts, name);
/*  155 */     if ((host == null) || (host.isAlias())) {
/*  156 */       return;
/*      */     }
/*  158 */     MappedHost[] newHosts = (MappedHost[])this.hosts.clone();
/*      */     
/*  160 */     int j = 0;
/*  161 */     for (int i = 0; i < newHosts.length; i++) {
/*  162 */       if (newHosts[i].getRealHost() != host) {
/*  163 */         newHosts[(j++)] = newHosts[i];
/*      */       }
/*      */     }
/*  166 */     this.hosts = ((MappedHost[])Arrays.copyOf(newHosts, j));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void addHostAlias(String name, String alias)
/*      */   {
/*  175 */     MappedHost realHost = (MappedHost)exactFind(this.hosts, name);
/*  176 */     if (realHost == null)
/*      */     {
/*      */ 
/*  179 */       return;
/*      */     }
/*  181 */     alias = renameWildcardHost(alias);
/*  182 */     MappedHost newAlias = new MappedHost(alias, realHost);
/*  183 */     if (addHostAliasImpl(newAlias)) {
/*  184 */       realHost.addAlias(newAlias);
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized boolean addHostAliasImpl(MappedHost newAlias) {
/*  189 */     MappedHost[] newHosts = new MappedHost[this.hosts.length + 1];
/*  190 */     if (insertMap(this.hosts, newHosts, newAlias)) {
/*  191 */       this.hosts = newHosts;
/*  192 */       if (newAlias.name.equals(this.defaultHostName)) {
/*  193 */         this.defaultHost = newAlias;
/*      */       }
/*  195 */       if (log.isDebugEnabled()) {
/*  196 */         log.debug(sm.getString("mapper.addHostAlias.success", new Object[] { newAlias.name, newAlias
/*  197 */           .getRealHostName() }));
/*      */       }
/*  199 */       return true;
/*      */     }
/*  201 */     MappedHost duplicate = this.hosts[find(this.hosts, newAlias.name)];
/*  202 */     if (duplicate.getRealHost() == newAlias.getRealHost())
/*      */     {
/*      */ 
/*      */ 
/*  206 */       if (log.isDebugEnabled()) {
/*  207 */         log.debug(sm.getString("mapper.addHostAlias.sameHost", new Object[] { newAlias.name, newAlias
/*  208 */           .getRealHostName() }));
/*      */       }
/*  210 */       return false;
/*      */     }
/*  212 */     log.error(sm.getString("mapper.duplicateHostAlias", new Object[] { newAlias.name, newAlias
/*  213 */       .getRealHostName(), duplicate.getRealHostName() }));
/*  214 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void removeHostAlias(String alias)
/*      */   {
/*  223 */     alias = renameWildcardHost(alias);
/*      */     
/*  225 */     MappedHost hostMapping = (MappedHost)exactFind(this.hosts, alias);
/*  226 */     if ((hostMapping == null) || (!hostMapping.isAlias())) {
/*  227 */       return;
/*      */     }
/*  229 */     MappedHost[] newHosts = new MappedHost[this.hosts.length - 1];
/*  230 */     if (removeMap(this.hosts, newHosts, alias)) {
/*  231 */       this.hosts = newHosts;
/*  232 */       hostMapping.getRealHost().removeAlias(hostMapping);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void updateContextList(MappedHost realHost, ContextList newContextList)
/*      */   {
/*  244 */     realHost.contextList = newContextList;
/*  245 */     for (MappedHost alias : realHost.getAliases()) {
/*  246 */       alias.contextList = newContextList;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addContextVersion(String hostName, Host host, String path, String version, Context context, String[] welcomeResources, WebResourceRoot resources, Collection<WrapperMappingInfo> wrappers)
/*      */   {
/*  266 */     hostName = renameWildcardHost(hostName);
/*      */     
/*  268 */     MappedHost mappedHost = (MappedHost)exactFind(this.hosts, hostName);
/*  269 */     if (mappedHost == null) {
/*  270 */       addHost(hostName, new String[0], host);
/*  271 */       mappedHost = (MappedHost)exactFind(this.hosts, hostName);
/*  272 */       if (mappedHost == null) {
/*  273 */         log.error(sm.getString("mapper.addContext.noHost", new Object[] { hostName }));
/*  274 */         return;
/*      */       }
/*      */     }
/*  277 */     if (mappedHost.isAlias()) {
/*  278 */       log.error(sm.getString("mapper.addContext.hostIsAlias", new Object[] { hostName }));
/*  279 */       return;
/*      */     }
/*  281 */     int slashCount = slashCount(path);
/*  282 */     synchronized (mappedHost) {
/*  283 */       ContextVersion newContextVersion = new ContextVersion(version, path, slashCount, context, resources, welcomeResources);
/*      */       
/*  285 */       if (wrappers != null) {
/*  286 */         addWrappers(newContextVersion, wrappers);
/*      */       }
/*      */       
/*  289 */       ContextList contextList = mappedHost.contextList;
/*  290 */       MappedContext mappedContext = (MappedContext)exactFind(contextList.contexts, path);
/*  291 */       if (mappedContext == null) {
/*  292 */         mappedContext = new MappedContext(path, newContextVersion);
/*  293 */         ContextList newContextList = contextList.addContext(mappedContext, slashCount);
/*      */         
/*  295 */         if (newContextList != null) {
/*  296 */           updateContextList(mappedHost, newContextList);
/*  297 */           this.contextObjectToContextVersionMap.put(context, newContextVersion);
/*      */         }
/*      */       } else {
/*  300 */         ContextVersion[] contextVersions = mappedContext.versions;
/*  301 */         ContextVersion[] newContextVersions = new ContextVersion[contextVersions.length + 1];
/*  302 */         if (insertMap(contextVersions, newContextVersions, newContextVersion))
/*      */         {
/*  304 */           mappedContext.versions = newContextVersions;
/*  305 */           this.contextObjectToContextVersionMap.put(context, newContextVersion);
/*      */         }
/*      */         else
/*      */         {
/*  309 */           int pos = find(contextVersions, version);
/*  310 */           if ((pos >= 0) && (contextVersions[pos].name.equals(version))) {
/*  311 */             contextVersions[pos] = newContextVersion;
/*  312 */             this.contextObjectToContextVersionMap.put(context, newContextVersion);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeContextVersion(Context ctxt, String hostName, String path, String version)
/*      */   {
/*  332 */     hostName = renameWildcardHost(hostName);
/*  333 */     this.contextObjectToContextVersionMap.remove(ctxt);
/*      */     
/*  335 */     MappedHost host = (MappedHost)exactFind(this.hosts, hostName);
/*  336 */     if ((host == null) || (host.isAlias())) {
/*  337 */       return;
/*      */     }
/*      */     
/*  340 */     synchronized (host) {
/*  341 */       ContextList contextList = host.contextList;
/*  342 */       MappedContext context = (MappedContext)exactFind(contextList.contexts, path);
/*  343 */       if (context == null) {
/*  344 */         return;
/*      */       }
/*      */       
/*  347 */       ContextVersion[] contextVersions = context.versions;
/*  348 */       ContextVersion[] newContextVersions = new ContextVersion[contextVersions.length - 1];
/*      */       
/*  350 */       if (removeMap(contextVersions, newContextVersions, version)) {
/*  351 */         if (newContextVersions.length == 0)
/*      */         {
/*  353 */           ContextList newContextList = contextList.removeContext(path);
/*  354 */           if (newContextList != null) {
/*  355 */             updateContextList(host, newContextList);
/*      */           }
/*      */         } else {
/*  358 */           context.versions = newContextVersions;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void pauseContextVersion(Context ctxt, String hostName, String contextPath, String version)
/*      */   {
/*  376 */     hostName = renameWildcardHost(hostName);
/*  377 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, true);
/*      */     
/*  379 */     if ((contextVersion == null) || (!ctxt.equals(contextVersion.object))) {
/*  380 */       return;
/*      */     }
/*  382 */     contextVersion.markPaused();
/*      */   }
/*      */   
/*      */ 
/*      */   private ContextVersion findContextVersion(String hostName, String contextPath, String version, boolean silent)
/*      */   {
/*  388 */     MappedHost host = (MappedHost)exactFind(this.hosts, hostName);
/*  389 */     if ((host == null) || (host.isAlias())) {
/*  390 */       if (!silent) {
/*  391 */         log.error(sm.getString("mapper.findContext.noHostOrAlias", new Object[] { hostName }));
/*      */       }
/*  393 */       return null;
/*      */     }
/*  395 */     MappedContext context = (MappedContext)exactFind(host.contextList.contexts, contextPath);
/*      */     
/*  397 */     if (context == null) {
/*  398 */       if (!silent) {
/*  399 */         log.error(sm.getString("mapper.findContext.noContext", new Object[] { contextPath }));
/*      */       }
/*  401 */       return null;
/*      */     }
/*  403 */     ContextVersion contextVersion = (ContextVersion)exactFind(context.versions, version);
/*  404 */     if (contextVersion == null) {
/*  405 */       if (!silent) {
/*  406 */         log.error(sm.getString("mapper.findContext.noContextVersion", new Object[] { contextPath, version }));
/*      */       }
/*  408 */       return null;
/*      */     }
/*  410 */     return contextVersion;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void addWrapper(String hostName, String contextPath, String version, String path, Wrapper wrapper, boolean jspWildCard, boolean resourceOnly)
/*      */   {
/*  417 */     hostName = renameWildcardHost(hostName);
/*  418 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*      */     
/*  420 */     if (contextVersion == null) {
/*  421 */       return;
/*      */     }
/*  423 */     addWrapper(contextVersion, path, wrapper, jspWildCard, resourceOnly);
/*      */   }
/*      */   
/*      */   public void addWrappers(String hostName, String contextPath, String version, Collection<WrapperMappingInfo> wrappers)
/*      */   {
/*  428 */     hostName = renameWildcardHost(hostName);
/*  429 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*      */     
/*  431 */     if (contextVersion == null) {
/*  432 */       return;
/*      */     }
/*  434 */     addWrappers(contextVersion, wrappers);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addWrappers(ContextVersion contextVersion, Collection<WrapperMappingInfo> wrappers)
/*      */   {
/*  445 */     for (WrapperMappingInfo wrapper : wrappers) {
/*  446 */       addWrapper(contextVersion, wrapper.getMapping(), wrapper
/*  447 */         .getWrapper(), wrapper.isJspWildCard(), wrapper
/*  448 */         .isResourceOnly());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addWrapper(ContextVersion context, String path, Wrapper wrapper, boolean jspWildCard, boolean resourceOnly)
/*      */   {
/*  466 */     synchronized (context) {
/*  467 */       if (path.endsWith("/*"))
/*      */       {
/*  469 */         String name = path.substring(0, path.length() - 2);
/*  470 */         MappedWrapper newWrapper = new MappedWrapper(name, wrapper, jspWildCard, resourceOnly);
/*      */         
/*  472 */         MappedWrapper[] oldWrappers = context.wildcardWrappers;
/*  473 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length + 1];
/*  474 */         if (insertMap(oldWrappers, newWrappers, newWrapper)) {
/*  475 */           context.wildcardWrappers = newWrappers;
/*  476 */           int slashCount = slashCount(newWrapper.name);
/*  477 */           if (slashCount > context.nesting) {
/*  478 */             context.nesting = slashCount;
/*      */           }
/*      */         }
/*  481 */       } else if (path.startsWith("*."))
/*      */       {
/*  483 */         String name = path.substring(2);
/*  484 */         MappedWrapper newWrapper = new MappedWrapper(name, wrapper, jspWildCard, resourceOnly);
/*      */         
/*  486 */         MappedWrapper[] oldWrappers = context.extensionWrappers;
/*  487 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length + 1];
/*      */         
/*  489 */         if (insertMap(oldWrappers, newWrappers, newWrapper)) {
/*  490 */           context.extensionWrappers = newWrappers;
/*      */         }
/*  492 */       } else if (path.equals("/"))
/*      */       {
/*  494 */         MappedWrapper newWrapper = new MappedWrapper("", wrapper, jspWildCard, resourceOnly);
/*      */         
/*  496 */         context.defaultWrapper = newWrapper;
/*      */       } else {
/*      */         String name;
/*      */         String name;
/*  500 */         if (path.length() == 0)
/*      */         {
/*      */ 
/*  503 */           name = "/";
/*      */         } else {
/*  505 */           name = path;
/*      */         }
/*  507 */         MappedWrapper newWrapper = new MappedWrapper(name, wrapper, jspWildCard, resourceOnly);
/*      */         
/*  509 */         MappedWrapper[] oldWrappers = context.exactWrappers;
/*  510 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length + 1];
/*  511 */         if (insertMap(oldWrappers, newWrappers, newWrapper)) {
/*  512 */           context.exactWrappers = newWrappers;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWrapper(String hostName, String contextPath, String version, String path)
/*      */   {
/*  529 */     hostName = renameWildcardHost(hostName);
/*  530 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, true);
/*      */     
/*  532 */     if ((contextVersion == null) || (contextVersion.isPaused())) {
/*  533 */       return;
/*      */     }
/*  535 */     removeWrapper(contextVersion, path);
/*      */   }
/*      */   
/*      */   protected void removeWrapper(ContextVersion context, String path)
/*      */   {
/*  540 */     if (log.isDebugEnabled()) {
/*  541 */       log.debug(sm.getString("mapper.removeWrapper", new Object[] { context.name, path }));
/*      */     }
/*      */     
/*  544 */     synchronized (context) {
/*  545 */       if (path.endsWith("/*"))
/*      */       {
/*  547 */         String name = path.substring(0, path.length() - 2);
/*  548 */         MappedWrapper[] oldWrappers = context.wildcardWrappers;
/*  549 */         if (oldWrappers.length == 0) {
/*  550 */           return;
/*      */         }
/*  552 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length - 1];
/*      */         
/*  554 */         if (removeMap(oldWrappers, newWrappers, name))
/*      */         {
/*  556 */           context.nesting = 0;
/*  557 */           for (MappedWrapper newWrapper : newWrappers) {
/*  558 */             int slashCount = slashCount(newWrapper.name);
/*  559 */             if (slashCount > context.nesting) {
/*  560 */               context.nesting = slashCount;
/*      */             }
/*      */           }
/*  563 */           context.wildcardWrappers = newWrappers;
/*      */         }
/*  565 */       } else if (path.startsWith("*."))
/*      */       {
/*  567 */         String name = path.substring(2);
/*  568 */         MappedWrapper[] oldWrappers = context.extensionWrappers;
/*  569 */         if (oldWrappers.length == 0) {
/*  570 */           return;
/*      */         }
/*  572 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length - 1];
/*      */         
/*  574 */         if (removeMap(oldWrappers, newWrappers, name)) {
/*  575 */           context.extensionWrappers = newWrappers;
/*      */         }
/*  577 */       } else if (path.equals("/"))
/*      */       {
/*  579 */         context.defaultWrapper = null;
/*      */       } else {
/*      */         String name;
/*      */         String name;
/*  583 */         if (path.length() == 0)
/*      */         {
/*      */ 
/*  586 */           name = "/";
/*      */         } else {
/*  588 */           name = path;
/*      */         }
/*  590 */         MappedWrapper[] oldWrappers = context.exactWrappers;
/*  591 */         if (oldWrappers.length == 0) {
/*  592 */           return;
/*      */         }
/*  594 */         MappedWrapper[] newWrappers = new MappedWrapper[oldWrappers.length - 1];
/*      */         
/*  596 */         if (removeMap(oldWrappers, newWrappers, name)) {
/*  597 */           context.exactWrappers = newWrappers;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addWelcomeFile(String hostName, String contextPath, String version, String welcomeFile)
/*      */   {
/*  614 */     hostName = renameWildcardHost(hostName);
/*  615 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*  616 */     if (contextVersion == null) {
/*  617 */       return;
/*      */     }
/*  619 */     int len = contextVersion.welcomeResources.length + 1;
/*  620 */     String[] newWelcomeResources = new String[len];
/*  621 */     System.arraycopy(contextVersion.welcomeResources, 0, newWelcomeResources, 0, len - 1);
/*  622 */     newWelcomeResources[(len - 1)] = welcomeFile;
/*  623 */     contextVersion.welcomeResources = newWelcomeResources;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeWelcomeFile(String hostName, String contextPath, String version, String welcomeFile)
/*      */   {
/*  637 */     hostName = renameWildcardHost(hostName);
/*  638 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*  639 */     if ((contextVersion == null) || (contextVersion.isPaused())) {
/*  640 */       return;
/*      */     }
/*  642 */     int match = -1;
/*  643 */     for (int i = 0; i < contextVersion.welcomeResources.length; i++) {
/*  644 */       if (welcomeFile.equals(contextVersion.welcomeResources[i])) {
/*  645 */         match = i;
/*  646 */         break;
/*      */       }
/*      */     }
/*  649 */     if (match > -1) {
/*  650 */       int len = contextVersion.welcomeResources.length - 1;
/*  651 */       String[] newWelcomeResources = new String[len];
/*  652 */       System.arraycopy(contextVersion.welcomeResources, 0, newWelcomeResources, 0, match);
/*  653 */       if (match < len) {
/*  654 */         System.arraycopy(contextVersion.welcomeResources, match + 1, newWelcomeResources, match, len - match);
/*      */       }
/*      */       
/*  657 */       contextVersion.welcomeResources = newWelcomeResources;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearWelcomeFiles(String hostName, String contextPath, String version)
/*      */   {
/*  670 */     hostName = renameWildcardHost(hostName);
/*  671 */     ContextVersion contextVersion = findContextVersion(hostName, contextPath, version, false);
/*  672 */     if (contextVersion == null) {
/*  673 */       return;
/*      */     }
/*  675 */     contextVersion.welcomeResources = new String[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void map(MessageBytes host, MessageBytes uri, String version, MappingData mappingData)
/*      */     throws IOException
/*      */   {
/*  693 */     if (host.isNull()) {
/*  694 */       String defaultHostName = this.defaultHostName;
/*  695 */       if (defaultHostName == null) {
/*  696 */         return;
/*      */       }
/*  698 */       host.getCharChunk().append(defaultHostName);
/*      */     }
/*  700 */     host.toChars();
/*  701 */     uri.toChars();
/*  702 */     internalMap(host.getCharChunk(), uri.getCharChunk(), version, mappingData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void map(Context context, MessageBytes uri, MappingData mappingData)
/*      */     throws IOException
/*      */   {
/*  721 */     ContextVersion contextVersion = (ContextVersion)this.contextObjectToContextVersionMap.get(context);
/*  722 */     uri.toChars();
/*  723 */     CharChunk uricc = uri.getCharChunk();
/*  724 */     uricc.setLimit(-1);
/*  725 */     internalMapWrapper(contextVersion, uricc, mappingData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void internalMap(CharChunk host, CharChunk uri, String version, MappingData mappingData)
/*      */     throws IOException
/*      */   {
/*  739 */     if (mappingData.host != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  744 */       throw new AssertionError();
/*      */     }
/*      */     
/*      */ 
/*  748 */     MappedHost[] hosts = this.hosts;
/*  749 */     MappedHost mappedHost = (MappedHost)exactFindIgnoreCase(hosts, host);
/*  750 */     if (mappedHost == null)
/*      */     {
/*      */ 
/*  753 */       int firstDot = host.indexOf('.');
/*  754 */       if (firstDot > -1) {
/*  755 */         int offset = host.getOffset();
/*      */         try {
/*  757 */           host.setOffset(firstDot + offset);
/*  758 */           mappedHost = (MappedHost)exactFindIgnoreCase(hosts, host);
/*      */         }
/*      */         finally {
/*  761 */           host.setOffset(offset);
/*      */         }
/*      */       }
/*  764 */       if (mappedHost == null) {
/*  765 */         mappedHost = this.defaultHost;
/*  766 */         if (mappedHost == null) {
/*  767 */           return;
/*      */         }
/*      */       }
/*      */     }
/*  771 */     mappingData.host = ((Host)mappedHost.object);
/*      */     
/*  773 */     if (uri.isNull())
/*      */     {
/*  775 */       return;
/*      */     }
/*      */     
/*  778 */     uri.setLimit(-1);
/*      */     
/*      */ 
/*  781 */     ContextList contextList = mappedHost.contextList;
/*  782 */     MappedContext[] contexts = contextList.contexts;
/*  783 */     int pos = find(contexts, uri);
/*  784 */     if (pos == -1) {
/*  785 */       return;
/*      */     }
/*      */     
/*  788 */     int lastSlash = -1;
/*  789 */     int uriEnd = uri.getEnd();
/*  790 */     int length = -1;
/*  791 */     boolean found = false;
/*  792 */     MappedContext context = null;
/*  793 */     while (pos >= 0) {
/*  794 */       context = contexts[pos];
/*  795 */       if (uri.startsWith(context.name)) {
/*  796 */         length = context.name.length();
/*  797 */         if (uri.getLength() == length) {
/*  798 */           found = true;
/*  799 */           break; }
/*  800 */         if (uri.startsWithIgnoreCase("/", length)) {
/*  801 */           found = true;
/*  802 */           break;
/*      */         }
/*      */       }
/*  805 */       if (lastSlash == -1) {
/*  806 */         lastSlash = nthSlash(uri, contextList.nesting + 1);
/*      */       } else {
/*  808 */         lastSlash = lastSlash(uri);
/*      */       }
/*  810 */       uri.setEnd(lastSlash);
/*  811 */       pos = find(contexts, uri);
/*      */     }
/*  813 */     uri.setEnd(uriEnd);
/*      */     
/*  815 */     if (!found) {
/*  816 */       if (contexts[0].name.equals("")) {
/*  817 */         context = contexts[0];
/*      */       } else {
/*  819 */         context = null;
/*      */       }
/*      */     }
/*  822 */     if (context == null) {
/*  823 */       return;
/*      */     }
/*      */     
/*  826 */     mappingData.contextPath.setString(context.name);
/*      */     
/*  828 */     ContextVersion contextVersion = null;
/*  829 */     ContextVersion[] contextVersions = context.versions;
/*  830 */     int versionCount = contextVersions.length;
/*  831 */     if (versionCount > 1) {
/*  832 */       Context[] contextObjects = new Context[contextVersions.length];
/*  833 */       for (int i = 0; i < contextObjects.length; i++) {
/*  834 */         contextObjects[i] = ((Context)contextVersions[i].object);
/*      */       }
/*  836 */       mappingData.contexts = contextObjects;
/*  837 */       if (version != null) {
/*  838 */         contextVersion = (ContextVersion)exactFind(contextVersions, version);
/*      */       }
/*      */     }
/*  841 */     if (contextVersion == null)
/*      */     {
/*      */ 
/*  844 */       contextVersion = contextVersions[(versionCount - 1)];
/*      */     }
/*  846 */     mappingData.context = ((Context)contextVersion.object);
/*  847 */     mappingData.contextSlashCount = contextVersion.slashCount;
/*      */     
/*      */ 
/*  850 */     if (!contextVersion.isPaused()) {
/*  851 */       internalMapWrapper(contextVersion, uri, mappingData);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void internalMapWrapper(ContextVersion contextVersion, CharChunk path, MappingData mappingData)
/*      */     throws IOException
/*      */   {
/*  866 */     int pathOffset = path.getOffset();
/*  867 */     int pathEnd = path.getEnd();
/*  868 */     boolean noServletPath = false;
/*      */     
/*  870 */     int length = contextVersion.path.length();
/*  871 */     if (length == pathEnd - pathOffset) {
/*  872 */       noServletPath = true;
/*      */     }
/*  874 */     int servletPath = pathOffset + length;
/*  875 */     path.setOffset(servletPath);
/*      */     
/*      */ 
/*  878 */     MappedWrapper[] exactWrappers = contextVersion.exactWrappers;
/*  879 */     internalMapExactWrapper(exactWrappers, path, mappingData);
/*      */     
/*      */ 
/*  882 */     boolean checkJspWelcomeFiles = false;
/*  883 */     MappedWrapper[] wildcardWrappers = contextVersion.wildcardWrappers;
/*  884 */     if (mappingData.wrapper == null) {
/*  885 */       internalMapWildcardWrapper(wildcardWrappers, contextVersion.nesting, path, mappingData);
/*      */       
/*  887 */       if ((mappingData.wrapper != null) && (mappingData.jspWildCard)) {
/*  888 */         char[] buf = path.getBuffer();
/*  889 */         if (buf[(pathEnd - 1)] == '/')
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  898 */           mappingData.wrapper = null;
/*  899 */           checkJspWelcomeFiles = true;
/*      */         }
/*      */         else {
/*  902 */           mappingData.wrapperPath.setChars(buf, path.getStart(), path
/*  903 */             .getLength());
/*  904 */           mappingData.pathInfo.recycle();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  909 */     if ((mappingData.wrapper == null) && (noServletPath) && 
/*  910 */       (((Context)contextVersion.object).getMapperContextRootRedirectEnabled()))
/*      */     {
/*  912 */       path.append('/');
/*  913 */       pathEnd = path.getEnd();
/*  914 */       mappingData.redirectPath
/*  915 */         .setChars(path.getBuffer(), pathOffset, pathEnd - pathOffset);
/*  916 */       path.setEnd(pathEnd - 1);
/*  917 */       return;
/*      */     }
/*      */     
/*      */ 
/*  921 */     MappedWrapper[] extensionWrappers = contextVersion.extensionWrappers;
/*  922 */     if ((mappingData.wrapper == null) && (!checkJspWelcomeFiles)) {
/*  923 */       internalMapExtensionWrapper(extensionWrappers, path, mappingData, true);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  928 */     if (mappingData.wrapper == null) {
/*  929 */       boolean checkWelcomeFiles = checkJspWelcomeFiles;
/*  930 */       if (!checkWelcomeFiles) {
/*  931 */         char[] buf = path.getBuffer();
/*  932 */         checkWelcomeFiles = buf[(pathEnd - 1)] == '/';
/*      */       }
/*  934 */       if (checkWelcomeFiles) {
/*  935 */         for (int i = 0; 
/*  936 */             (i < contextVersion.welcomeResources.length) && (mappingData.wrapper == null); i++) {
/*  937 */           path.setOffset(pathOffset);
/*  938 */           path.setEnd(pathEnd);
/*  939 */           path.append(contextVersion.welcomeResources[i], 0, contextVersion.welcomeResources[i]
/*  940 */             .length());
/*  941 */           path.setOffset(servletPath);
/*      */           
/*      */ 
/*  944 */           internalMapExactWrapper(exactWrappers, path, mappingData);
/*      */           
/*      */ 
/*  947 */           if (mappingData.wrapper == null)
/*      */           {
/*  949 */             internalMapWildcardWrapper(wildcardWrappers, contextVersion.nesting, path, mappingData);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  955 */           if ((mappingData.wrapper == null) && (contextVersion.resources != null))
/*      */           {
/*  957 */             String pathStr = path.toString();
/*      */             
/*  959 */             WebResource file = contextVersion.resources.getResource(pathStr);
/*  960 */             if ((file != null) && (file.isFile())) {
/*  961 */               internalMapExtensionWrapper(extensionWrappers, path, mappingData, true);
/*      */               
/*  963 */               if ((mappingData.wrapper == null) && (contextVersion.defaultWrapper != null))
/*      */               {
/*  965 */                 mappingData.wrapper = ((Wrapper)contextVersion.defaultWrapper.object);
/*      */                 
/*  967 */                 mappingData.requestPath
/*  968 */                   .setChars(path.getBuffer(), path.getStart(), path
/*  969 */                   .getLength());
/*  970 */                 mappingData.wrapperPath
/*  971 */                   .setChars(path.getBuffer(), path.getStart(), path
/*  972 */                   .getLength());
/*  973 */                 mappingData.requestPath.setString(pathStr);
/*  974 */                 mappingData.wrapperPath.setString(pathStr);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*  980 */         path.setOffset(servletPath);
/*  981 */         path.setEnd(pathEnd);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  993 */     if (mappingData.wrapper == null) {
/*  994 */       boolean checkWelcomeFiles = checkJspWelcomeFiles;
/*  995 */       if (!checkWelcomeFiles) {
/*  996 */         char[] buf = path.getBuffer();
/*  997 */         checkWelcomeFiles = buf[(pathEnd - 1)] == '/';
/*      */       }
/*  999 */       if (checkWelcomeFiles) {
/* 1000 */         for (int i = 0; 
/* 1001 */             (i < contextVersion.welcomeResources.length) && (mappingData.wrapper == null); i++) {
/* 1002 */           path.setOffset(pathOffset);
/* 1003 */           path.setEnd(pathEnd);
/* 1004 */           path.append(contextVersion.welcomeResources[i], 0, contextVersion.welcomeResources[i]
/* 1005 */             .length());
/* 1006 */           path.setOffset(servletPath);
/* 1007 */           internalMapExtensionWrapper(extensionWrappers, path, mappingData, false);
/*      */         }
/*      */         
/*      */ 
/* 1011 */         path.setOffset(servletPath);
/* 1012 */         path.setEnd(pathEnd);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1018 */     if ((mappingData.wrapper == null) && (!checkJspWelcomeFiles)) {
/* 1019 */       if (contextVersion.defaultWrapper != null) {
/* 1020 */         mappingData.wrapper = ((Wrapper)contextVersion.defaultWrapper.object);
/* 1021 */         mappingData.requestPath
/* 1022 */           .setChars(path.getBuffer(), path.getStart(), path.getLength());
/* 1023 */         mappingData.wrapperPath
/* 1024 */           .setChars(path.getBuffer(), path.getStart(), path.getLength());
/* 1025 */         mappingData.matchType = MappingMatch.DEFAULT;
/*      */       }
/*      */       
/* 1028 */       char[] buf = path.getBuffer();
/* 1029 */       if ((contextVersion.resources != null) && (buf[(pathEnd - 1)] != '/')) {
/* 1030 */         String pathStr = path.toString();
/*      */         
/*      */ 
/* 1033 */         if (((Context)contextVersion.object).getMapperDirectoryRedirectEnabled()) {
/*      */           WebResource file;
/*      */           WebResource file;
/* 1036 */           if (pathStr.length() == 0) {
/* 1037 */             file = contextVersion.resources.getResource("/");
/*      */           } else {
/* 1039 */             file = contextVersion.resources.getResource(pathStr);
/*      */           }
/* 1041 */           if ((file != null) && (file.isDirectory()))
/*      */           {
/*      */ 
/*      */ 
/* 1045 */             path.setOffset(pathOffset);
/* 1046 */             path.append('/');
/* 1047 */             mappingData.redirectPath
/* 1048 */               .setChars(path.getBuffer(), path.getStart(), path.getLength());
/*      */           } else {
/* 1050 */             mappingData.requestPath.setString(pathStr);
/* 1051 */             mappingData.wrapperPath.setString(pathStr);
/*      */           }
/*      */         } else {
/* 1054 */           mappingData.requestPath.setString(pathStr);
/* 1055 */           mappingData.wrapperPath.setString(pathStr);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1060 */     path.setOffset(pathOffset);
/* 1061 */     path.setEnd(pathEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void internalMapExactWrapper(MappedWrapper[] wrappers, CharChunk path, MappingData mappingData)
/*      */   {
/* 1071 */     MappedWrapper wrapper = (MappedWrapper)exactFind(wrappers, path);
/* 1072 */     if (wrapper != null) {
/* 1073 */       mappingData.requestPath.setString(wrapper.name);
/* 1074 */       mappingData.wrapper = ((Wrapper)wrapper.object);
/* 1075 */       if (path.equals("/"))
/*      */       {
/* 1077 */         mappingData.pathInfo.setString("/");
/* 1078 */         mappingData.wrapperPath.setString("");
/*      */         
/* 1080 */         mappingData.contextPath.setString("");
/* 1081 */         mappingData.matchType = MappingMatch.CONTEXT_ROOT;
/*      */       } else {
/* 1083 */         mappingData.wrapperPath.setString(wrapper.name);
/* 1084 */         mappingData.matchType = MappingMatch.EXACT;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void internalMapWildcardWrapper(MappedWrapper[] wrappers, int nesting, CharChunk path, MappingData mappingData)
/*      */   {
/* 1097 */     int pathEnd = path.getEnd();
/*      */     
/* 1099 */     int lastSlash = -1;
/* 1100 */     int length = -1;
/* 1101 */     int pos = find(wrappers, path);
/* 1102 */     if (pos != -1) {
/* 1103 */       boolean found = false;
/* 1104 */       while (pos >= 0) {
/* 1105 */         if (path.startsWith(wrappers[pos].name)) {
/* 1106 */           length = wrappers[pos].name.length();
/* 1107 */           if (path.getLength() == length) {
/* 1108 */             found = true;
/* 1109 */             break; }
/* 1110 */           if (path.startsWithIgnoreCase("/", length)) {
/* 1111 */             found = true;
/* 1112 */             break;
/*      */           }
/*      */         }
/* 1115 */         if (lastSlash == -1) {
/* 1116 */           lastSlash = nthSlash(path, nesting + 1);
/*      */         } else {
/* 1118 */           lastSlash = lastSlash(path);
/*      */         }
/* 1120 */         path.setEnd(lastSlash);
/* 1121 */         pos = find(wrappers, path);
/*      */       }
/* 1123 */       path.setEnd(pathEnd);
/* 1124 */       if (found) {
/* 1125 */         mappingData.wrapperPath.setString(wrappers[pos].name);
/* 1126 */         if (path.getLength() > length)
/*      */         {
/* 1128 */           mappingData.pathInfo.setChars(path.getBuffer(), path
/* 1129 */             .getOffset() + length, path
/* 1130 */             .getLength() - length);
/*      */         }
/*      */         
/* 1133 */         mappingData.requestPath.setChars(path.getBuffer(), path.getOffset(), path.getLength());
/* 1134 */         mappingData.wrapper = ((Wrapper)wrappers[pos].object);
/* 1135 */         mappingData.jspWildCard = wrappers[pos].jspWildCard;
/* 1136 */         mappingData.matchType = MappingMatch.PATH;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void internalMapExtensionWrapper(MappedWrapper[] wrappers, CharChunk path, MappingData mappingData, boolean resourceExpected)
/*      */   {
/* 1152 */     char[] buf = path.getBuffer();
/* 1153 */     int pathEnd = path.getEnd();
/* 1154 */     int servletPath = path.getOffset();
/* 1155 */     int slash = -1;
/* 1156 */     for (int i = pathEnd - 1; i >= servletPath; i--) {
/* 1157 */       if (buf[i] == '/') {
/* 1158 */         slash = i;
/* 1159 */         break;
/*      */       }
/*      */     }
/* 1162 */     if (slash >= 0) {
/* 1163 */       int period = -1;
/* 1164 */       for (int i = pathEnd - 1; i > slash; i--) {
/* 1165 */         if (buf[i] == '.') {
/* 1166 */           period = i;
/* 1167 */           break;
/*      */         }
/*      */       }
/* 1170 */       if (period >= 0) {
/* 1171 */         path.setOffset(period + 1);
/* 1172 */         path.setEnd(pathEnd);
/* 1173 */         MappedWrapper wrapper = (MappedWrapper)exactFind(wrappers, path);
/* 1174 */         if ((wrapper != null) && ((resourceExpected) || (!wrapper.resourceOnly)))
/*      */         {
/* 1176 */           mappingData.wrapperPath.setChars(buf, servletPath, pathEnd - servletPath);
/*      */           
/* 1178 */           mappingData.requestPath.setChars(buf, servletPath, pathEnd - servletPath);
/*      */           
/* 1180 */           mappingData.wrapper = ((Wrapper)wrapper.object);
/* 1181 */           mappingData.matchType = MappingMatch.EXTENSION;
/*      */         }
/* 1183 */         path.setOffset(servletPath);
/* 1184 */         path.setEnd(pathEnd);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> int find(MapElement<T>[] map, CharChunk name)
/*      */   {
/* 1196 */     return find(map, name, name.getStart(), name.getEnd());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> int find(MapElement<T>[] map, CharChunk name, int start, int end)
/*      */   {
/* 1208 */     int a = 0;
/* 1209 */     int b = map.length - 1;
/*      */     
/*      */ 
/* 1212 */     if (b == -1) {
/* 1213 */       return -1;
/*      */     }
/*      */     
/* 1216 */     if (compare(name, start, end, map[0].name) < 0) {
/* 1217 */       return -1;
/*      */     }
/* 1219 */     if (b == 0) {
/* 1220 */       return 0;
/*      */     }
/*      */     
/* 1223 */     int i = 0;
/*      */     for (;;) {
/* 1225 */       i = b + a >>> 1;
/* 1226 */       int result = compare(name, start, end, map[i].name);
/* 1227 */       if (result == 1) {
/* 1228 */         a = i;
/* 1229 */       } else { if (result == 0) {
/* 1230 */           return i;
/*      */         }
/* 1232 */         b = i;
/*      */       }
/* 1234 */       if (b - a == 1) {
/* 1235 */         int result2 = compare(name, start, end, map[b].name);
/* 1236 */         if (result2 < 0) {
/* 1237 */           return a;
/*      */         }
/* 1239 */         return b;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> int findIgnoreCase(MapElement<T>[] map, CharChunk name)
/*      */   {
/* 1252 */     return findIgnoreCase(map, name, name.getStart(), name.getEnd());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> int findIgnoreCase(MapElement<T>[] map, CharChunk name, int start, int end)
/*      */   {
/* 1264 */     int a = 0;
/* 1265 */     int b = map.length - 1;
/*      */     
/*      */ 
/* 1268 */     if (b == -1) {
/* 1269 */       return -1;
/*      */     }
/* 1271 */     if (compareIgnoreCase(name, start, end, map[0].name) < 0) {
/* 1272 */       return -1;
/*      */     }
/* 1274 */     if (b == 0) {
/* 1275 */       return 0;
/*      */     }
/*      */     
/* 1278 */     int i = 0;
/*      */     for (;;) {
/* 1280 */       i = b + a >>> 1;
/* 1281 */       int result = compareIgnoreCase(name, start, end, map[i].name);
/* 1282 */       if (result == 1) {
/* 1283 */         a = i;
/* 1284 */       } else { if (result == 0) {
/* 1285 */           return i;
/*      */         }
/* 1287 */         b = i;
/*      */       }
/* 1289 */       if (b - a == 1) {
/* 1290 */         int result2 = compareIgnoreCase(name, start, end, map[b].name);
/* 1291 */         if (result2 < 0) {
/* 1292 */           return a;
/*      */         }
/* 1294 */         return b;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> int find(MapElement<T>[] map, String name)
/*      */   {
/* 1310 */     int a = 0;
/* 1311 */     int b = map.length - 1;
/*      */     
/*      */ 
/* 1314 */     if (b == -1) {
/* 1315 */       return -1;
/*      */     }
/*      */     
/* 1318 */     if (name.compareTo(map[0].name) < 0) {
/* 1319 */       return -1;
/*      */     }
/* 1321 */     if (b == 0) {
/* 1322 */       return 0;
/*      */     }
/*      */     
/* 1325 */     int i = 0;
/*      */     for (;;) {
/* 1327 */       i = b + a >>> 1;
/* 1328 */       int result = name.compareTo(map[i].name);
/* 1329 */       if (result > 0) {
/* 1330 */         a = i;
/* 1331 */       } else { if (result == 0) {
/* 1332 */           return i;
/*      */         }
/* 1334 */         b = i;
/*      */       }
/* 1336 */       if (b - a == 1) {
/* 1337 */         int result2 = name.compareTo(map[b].name);
/* 1338 */         if (result2 < 0) {
/* 1339 */           return a;
/*      */         }
/* 1341 */         return b;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T, E extends MapElement<T>> E exactFind(E[] map, String name)
/*      */   {
/* 1357 */     int pos = find(map, name);
/* 1358 */     if (pos >= 0) {
/* 1359 */       E result = map[pos];
/* 1360 */       if (name.equals(result.name)) {
/* 1361 */         return result;
/*      */       }
/*      */     }
/* 1364 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T, E extends MapElement<T>> E exactFind(E[] map, CharChunk name)
/*      */   {
/* 1374 */     int pos = find(map, name);
/* 1375 */     if (pos >= 0) {
/* 1376 */       E result = map[pos];
/* 1377 */       if (name.equals(result.name)) {
/* 1378 */         return result;
/*      */       }
/*      */     }
/* 1381 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T, E extends MapElement<T>> E exactFindIgnoreCase(E[] map, CharChunk name)
/*      */   {
/* 1392 */     int pos = findIgnoreCase(map, name);
/* 1393 */     if (pos >= 0) {
/* 1394 */       E result = map[pos];
/* 1395 */       if (name.equalsIgnoreCase(result.name)) {
/* 1396 */         return result;
/*      */       }
/*      */     }
/* 1399 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int compare(CharChunk name, int start, int end, String compareTo)
/*      */   {
/* 1409 */     int result = 0;
/* 1410 */     char[] c = name.getBuffer();
/* 1411 */     int len = compareTo.length();
/* 1412 */     if (end - start < len) {
/* 1413 */       len = end - start;
/*      */     }
/* 1415 */     for (int i = 0; (i < len) && (result == 0); i++) {
/* 1416 */       if (c[(i + start)] > compareTo.charAt(i)) {
/* 1417 */         result = 1;
/* 1418 */       } else if (c[(i + start)] < compareTo.charAt(i)) {
/* 1419 */         result = -1;
/*      */       }
/*      */     }
/* 1422 */     if (result == 0) {
/* 1423 */       if (compareTo.length() > end - start) {
/* 1424 */         result = -1;
/* 1425 */       } else if (compareTo.length() < end - start) {
/* 1426 */         result = 1;
/*      */       }
/*      */     }
/* 1429 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int compareIgnoreCase(CharChunk name, int start, int end, String compareTo)
/*      */   {
/* 1439 */     int result = 0;
/* 1440 */     char[] c = name.getBuffer();
/* 1441 */     int len = compareTo.length();
/* 1442 */     if (end - start < len) {
/* 1443 */       len = end - start;
/*      */     }
/* 1445 */     for (int i = 0; (i < len) && (result == 0); i++) {
/* 1446 */       if (Ascii.toLower(c[(i + start)]) > Ascii.toLower(compareTo.charAt(i))) {
/* 1447 */         result = 1;
/* 1448 */       } else if (Ascii.toLower(c[(i + start)]) < Ascii.toLower(compareTo.charAt(i))) {
/* 1449 */         result = -1;
/*      */       }
/*      */     }
/* 1452 */     if (result == 0) {
/* 1453 */       if (compareTo.length() > end - start) {
/* 1454 */         result = -1;
/* 1455 */       } else if (compareTo.length() < end - start) {
/* 1456 */         result = 1;
/*      */       }
/*      */     }
/* 1459 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int lastSlash(CharChunk name)
/*      */   {
/* 1467 */     char[] c = name.getBuffer();
/* 1468 */     int end = name.getEnd();
/* 1469 */     int start = name.getStart();
/* 1470 */     int pos = end;
/*      */     
/* 1472 */     while (pos > start) {
/* 1473 */       if (c[(--pos)] == '/') {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 1478 */     return pos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int nthSlash(CharChunk name, int n)
/*      */   {
/* 1486 */     char[] c = name.getBuffer();
/* 1487 */     int end = name.getEnd();
/* 1488 */     int start = name.getStart();
/* 1489 */     int pos = start;
/* 1490 */     int count = 0;
/*      */     
/* 1492 */     while (pos < end) {
/* 1493 */       if (c[(pos++)] == '/') { count++; if (count == n) {
/* 1494 */           pos--;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1499 */     return pos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int slashCount(String name)
/*      */   {
/* 1507 */     int pos = -1;
/* 1508 */     int count = 0;
/* 1509 */     while ((pos = name.indexOf('/', pos + 1)) != -1) {
/* 1510 */       count++;
/*      */     }
/* 1512 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> boolean insertMap(MapElement<T>[] oldMap, MapElement<T>[] newMap, MapElement<T> newElement)
/*      */   {
/* 1522 */     int pos = find(oldMap, newElement.name);
/* 1523 */     if ((pos != -1) && (newElement.name.equals(oldMap[pos].name))) {
/* 1524 */       return false;
/*      */     }
/* 1526 */     System.arraycopy(oldMap, 0, newMap, 0, pos + 1);
/* 1527 */     newMap[(pos + 1)] = newElement;
/*      */     
/* 1529 */     System.arraycopy(oldMap, pos + 1, newMap, pos + 2, oldMap.length - pos - 1);
/* 1530 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final <T> boolean removeMap(MapElement<T>[] oldMap, MapElement<T>[] newMap, String name)
/*      */   {
/* 1539 */     int pos = find(oldMap, name);
/* 1540 */     if ((pos != -1) && (name.equals(oldMap[pos].name))) {
/* 1541 */       System.arraycopy(oldMap, 0, newMap, 0, pos);
/* 1542 */       System.arraycopy(oldMap, pos + 1, newMap, pos, oldMap.length - pos - 1);
/*      */       
/* 1544 */       return true;
/*      */     }
/* 1546 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String renameWildcardHost(String hostName)
/*      */   {
/* 1558 */     if ((hostName != null) && (hostName.startsWith("*."))) {
/* 1559 */       return hostName.substring(1);
/*      */     }
/* 1561 */     return hostName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static abstract class MapElement<T>
/*      */   {
/*      */     public final String name;
/*      */     
/*      */     public final T object;
/*      */     
/*      */ 
/*      */     public MapElement(String name, T object)
/*      */     {
/* 1575 */       this.name = name;
/* 1576 */       this.object = object;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final class MappedHost
/*      */     extends Mapper.MapElement<Host>
/*      */   {
/*      */     public volatile Mapper.ContextList contextList;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final MappedHost realHost;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private final List<MappedHost> aliases;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public MappedHost(String name, Host host)
/*      */     {
/* 1607 */       super(host);
/* 1608 */       this.realHost = this;
/* 1609 */       this.contextList = new Mapper.ContextList();
/* 1610 */       this.aliases = new CopyOnWriteArrayList();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public MappedHost(String alias, MappedHost realHost)
/*      */     {
/* 1620 */       super(realHost.object);
/* 1621 */       this.realHost = realHost;
/* 1622 */       this.contextList = realHost.contextList;
/* 1623 */       this.aliases = null;
/*      */     }
/*      */     
/*      */     public boolean isAlias() {
/* 1627 */       return this.realHost != this;
/*      */     }
/*      */     
/*      */     public MappedHost getRealHost() {
/* 1631 */       return this.realHost;
/*      */     }
/*      */     
/*      */     public String getRealHostName() {
/* 1635 */       return this.realHost.name;
/*      */     }
/*      */     
/*      */     public Collection<MappedHost> getAliases() {
/* 1639 */       return this.aliases;
/*      */     }
/*      */     
/*      */     public void addAlias(MappedHost alias) {
/* 1643 */       this.aliases.add(alias);
/*      */     }
/*      */     
/*      */     public void addAliases(Collection<? extends MappedHost> c) {
/* 1647 */       this.aliases.addAll(c);
/*      */     }
/*      */     
/*      */     public void removeAlias(MappedHost alias) {
/* 1651 */       this.aliases.remove(alias);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static final class ContextList
/*      */   {
/*      */     public final Mapper.MappedContext[] contexts;
/*      */     
/*      */     public final int nesting;
/*      */     
/*      */ 
/*      */     public ContextList()
/*      */     {
/* 1665 */       this(new Mapper.MappedContext[0], 0);
/*      */     }
/*      */     
/*      */     private ContextList(Mapper.MappedContext[] contexts, int nesting) {
/* 1669 */       this.contexts = contexts;
/* 1670 */       this.nesting = nesting;
/*      */     }
/*      */     
/*      */     public ContextList addContext(Mapper.MappedContext mappedContext, int slashCount)
/*      */     {
/* 1675 */       Mapper.MappedContext[] newContexts = new Mapper.MappedContext[this.contexts.length + 1];
/* 1676 */       if (Mapper.insertMap(this.contexts, newContexts, mappedContext)) {
/* 1677 */         return new ContextList(newContexts, Math.max(this.nesting, slashCount));
/*      */       }
/*      */       
/* 1680 */       return null;
/*      */     }
/*      */     
/*      */     public ContextList removeContext(String path) {
/* 1684 */       Mapper.MappedContext[] newContexts = new Mapper.MappedContext[this.contexts.length - 1];
/* 1685 */       if (Mapper.removeMap(this.contexts, newContexts, path)) {
/* 1686 */         int newNesting = 0;
/* 1687 */         for (Mapper.MappedContext context : newContexts) {
/* 1688 */           newNesting = Math.max(newNesting, Mapper.slashCount(context.name));
/*      */         }
/* 1690 */         return new ContextList(newContexts, newNesting);
/*      */       }
/* 1692 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static final class MappedContext
/*      */     extends Mapper.MapElement<Void>
/*      */   {
/*      */     public volatile Mapper.ContextVersion[] versions;
/*      */     
/*      */     public MappedContext(String name, Mapper.ContextVersion firstVersion)
/*      */     {
/* 1704 */       super(null);
/* 1705 */       this.versions = new Mapper.ContextVersion[] { firstVersion };
/*      */     }
/*      */   }
/*      */   
/*      */   protected static final class ContextVersion extends Mapper.MapElement<Context> {
/*      */     public final String path;
/*      */     public final int slashCount;
/*      */     public final WebResourceRoot resources;
/*      */     public String[] welcomeResources;
/* 1714 */     public Mapper.MappedWrapper defaultWrapper = null;
/* 1715 */     public Mapper.MappedWrapper[] exactWrappers = new Mapper.MappedWrapper[0];
/* 1716 */     public Mapper.MappedWrapper[] wildcardWrappers = new Mapper.MappedWrapper[0];
/* 1717 */     public Mapper.MappedWrapper[] extensionWrappers = new Mapper.MappedWrapper[0];
/* 1718 */     public int nesting = 0;
/*      */     
/*      */     private volatile boolean paused;
/*      */     
/*      */     public ContextVersion(String version, String path, int slashCount, Context context, WebResourceRoot resources, String[] welcomeResources)
/*      */     {
/* 1724 */       super(context);
/* 1725 */       this.path = path;
/* 1726 */       this.slashCount = slashCount;
/* 1727 */       this.resources = resources;
/* 1728 */       this.welcomeResources = welcomeResources;
/*      */     }
/*      */     
/*      */     public boolean isPaused() {
/* 1732 */       return this.paused;
/*      */     }
/*      */     
/*      */     public void markPaused() {
/* 1736 */       this.paused = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static class MappedWrapper
/*      */     extends Mapper.MapElement<Wrapper>
/*      */   {
/*      */     public final boolean jspWildCard;
/*      */     
/*      */     public final boolean resourceOnly;
/*      */     
/*      */     public MappedWrapper(String name, Wrapper wrapper, boolean jspWildCard, boolean resourceOnly)
/*      */     {
/* 1750 */       super(wrapper);
/* 1751 */       this.jspWildCard = jspWildCard;
/* 1752 */       this.resourceOnly = resourceOnly;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mapper\Mapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */