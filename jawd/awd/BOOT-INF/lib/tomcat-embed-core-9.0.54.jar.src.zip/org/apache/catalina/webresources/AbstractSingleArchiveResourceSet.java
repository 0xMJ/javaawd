/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.tomcat.util.buf.UriUtil;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSingleArchiveResourceSet
/*     */   extends AbstractArchiveResourceSet
/*     */ {
/*     */   private volatile Boolean multiRelease;
/*     */   
/*     */   public AbstractSingleArchiveResourceSet() {}
/*     */   
/*     */   public AbstractSingleArchiveResourceSet(WebResourceRoot root, String webAppMount, String base, String internalPath)
/*     */     throws IllegalArgumentException
/*     */   {
/*  50 */     setRoot(root);
/*  51 */     setWebAppMount(webAppMount);
/*  52 */     setBase(base);
/*  53 */     setInternalPath(internalPath);
/*     */     
/*  55 */     if (getRoot().getState().isAvailable()) {
/*     */       try {
/*  57 */         start();
/*     */       } catch (LifecycleException e) {
/*  59 */         throw new IllegalStateException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected Map<String, JarEntry> getArchiveEntries(boolean single)
/*     */   {
/*  67 */     synchronized (this.archiveLock) {
/*  68 */       if ((this.archiveEntries == null) && (!single)) {
/*  69 */         JarFile jarFile = null;
/*  70 */         this.archiveEntries = new HashMap();
/*     */         try {
/*  72 */           jarFile = openJarFile();
/*  73 */           Enumeration<JarEntry> entries = jarFile.entries();
/*  74 */           while (entries.hasMoreElements()) {
/*  75 */             JarEntry entry = (JarEntry)entries.nextElement();
/*  76 */             this.archiveEntries.put(entry.getName(), entry);
/*     */           }
/*     */         }
/*     */         catch (IOException ioe) {
/*  80 */           this.archiveEntries = null;
/*  81 */           throw new IllegalStateException(ioe);
/*     */         } finally {
/*  83 */           if (jarFile != null) {
/*  84 */             closeJarFile();
/*     */           }
/*     */         }
/*     */       }
/*  88 */       return this.archiveEntries;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected JarEntry getArchiveEntry(String pathInArchive)
/*     */   {
/*  95 */     JarFile jarFile = null;
/*     */     try {
/*  97 */       jarFile = openJarFile();
/*  98 */       return jarFile.getJarEntry(pathInArchive);
/*     */     }
/*     */     catch (IOException ioe) {
/* 101 */       throw new IllegalStateException(ioe);
/*     */     } finally {
/* 103 */       if (jarFile != null) {
/* 104 */         closeJarFile();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean isMultiRelease()
/*     */   {
/* 112 */     if (this.multiRelease == null) {
/* 113 */       synchronized (this.archiveLock) {
/* 114 */         if (this.multiRelease == null) {
/* 115 */           JarFile jarFile = null;
/*     */           try {
/* 117 */             jarFile = openJarFile();
/* 118 */             this.multiRelease = Boolean.valueOf(
/* 119 */               JreCompat.getInstance().jarFileIsMultiRelease(jarFile));
/*     */           }
/*     */           catch (IOException ioe) {
/* 122 */             throw new IllegalStateException(ioe);
/*     */           } finally {
/* 124 */             if (jarFile != null) {
/* 125 */               closeJarFile();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 132 */     return this.multiRelease.booleanValue();
/*     */   }
/*     */   
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/*     */     try
/*     */     {
/* 140 */       JarFile jarFile = JreCompat.getInstance().jarFileNewInstance(getBase());Throwable localThrowable3 = null;
/* 141 */       try { setManifest(jarFile.getManifest());
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 140 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*     */       } finally {
/* 142 */         if (jarFile != null) if (localThrowable3 != null) try { jarFile.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else jarFile.close();
/* 143 */       } } catch (IOException ioe) { throw new IllegalArgumentException(ioe);
/*     */     }
/*     */     try
/*     */     {
/* 147 */       setBaseUrl(UriUtil.buildJarSafeUrl(new File(getBase())));
/*     */     } catch (MalformedURLException e) {
/* 149 */       throw new IllegalArgumentException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\webresources\AbstractSingleArchiveResourceSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */