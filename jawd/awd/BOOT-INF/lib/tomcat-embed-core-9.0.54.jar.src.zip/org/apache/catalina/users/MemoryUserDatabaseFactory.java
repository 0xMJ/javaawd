/*     */ package org.apache.catalina.users;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryUserDatabaseFactory
/*     */   implements ObjectFactory
/*     */ {
/*     */   public Object getObjectInstance(Object obj, Name name, Context nameCtx, Hashtable<?, ?> environment)
/*     */     throws Exception
/*     */   {
/*  76 */     if ((obj == null) || (!(obj instanceof Reference))) {
/*  77 */       return null;
/*     */     }
/*  79 */     Reference ref = (Reference)obj;
/*  80 */     if (!"org.apache.catalina.UserDatabase".equals(ref.getClassName())) {
/*  81 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  86 */     MemoryUserDatabase database = new MemoryUserDatabase(name.toString());
/*  87 */     RefAddr ra = null;
/*     */     
/*  89 */     ra = ref.get("pathname");
/*  90 */     if (ra != null) {
/*  91 */       database.setPathname(ra.getContent().toString());
/*     */     }
/*     */     
/*  94 */     ra = ref.get("readonly");
/*  95 */     if (ra != null) {
/*  96 */       database.setReadonly(Boolean.parseBoolean(ra.getContent().toString()));
/*     */     }
/*     */     
/*  99 */     ra = ref.get("watchSource");
/* 100 */     if (ra != null) {
/* 101 */       database.setWatchSource(Boolean.parseBoolean(ra.getContent().toString()));
/*     */     }
/*     */     
/*     */ 
/* 105 */     database.open();
/*     */     
/* 107 */     if (!database.getReadonly()) {
/* 108 */       database.save();
/*     */     }
/* 110 */     return database;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\users\MemoryUserDatabaseFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */