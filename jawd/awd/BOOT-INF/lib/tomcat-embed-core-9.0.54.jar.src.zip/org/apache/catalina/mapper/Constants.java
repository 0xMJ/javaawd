package org.apache.catalina.mapper;

public final class Constants
{
  public static final String Package = "org.apache.catalina.mapper";
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mapper\Constants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */