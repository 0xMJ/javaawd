/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.awt.Toolkit;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.Security;
/*     */ import java.sql.DriverManager;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.startup.SafeForkJoinWorkerThreadFactory;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ import org.apache.tomcat.util.compat.JreVendor;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.ls.DOMImplementationLS;
/*     */ import org.w3c.dom.ls.LSSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JreMemoryLeakPreventionListener
/*     */   implements LifecycleListener
/*     */ {
/*  61 */   private static final Log log = LogFactory.getLog(JreMemoryLeakPreventionListener.class);
/*  62 */   private static final StringManager sm = StringManager.getManager(JreMemoryLeakPreventionListener.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String FORK_JOIN_POOL_THREAD_FACTORY_PROPERTY = "java.util.concurrent.ForkJoinPool.common.threadFactory";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  72 */   private boolean appContextProtection = false;
/*  73 */   public boolean isAppContextProtection() { return this.appContextProtection; }
/*     */   
/*  75 */   public void setAppContextProtection(boolean appContextProtection) { this.appContextProtection = appContextProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */   private boolean awtThreadProtection = false;
/*  85 */   public boolean isAWTThreadProtection() { return this.awtThreadProtection; }
/*     */   
/*  87 */   public void setAWTThreadProtection(boolean awtThreadProtection) { this.awtThreadProtection = awtThreadProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */   private boolean gcDaemonProtection = true;
/* 100 */   public boolean isGcDaemonProtection() { return this.gcDaemonProtection; }
/*     */   
/* 102 */   public void setGcDaemonProtection(boolean gcDaemonProtection) { this.gcDaemonProtection = gcDaemonProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */   private boolean tokenPollerProtection = true;
/* 115 */   public boolean isTokenPollerProtection() { return this.tokenPollerProtection; }
/*     */   
/* 117 */   public void setTokenPollerProtection(boolean tokenPollerProtection) { this.tokenPollerProtection = tokenPollerProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */   private boolean urlCacheProtection = true;
/* 127 */   public boolean isUrlCacheProtection() { return this.urlCacheProtection; }
/*     */   
/* 129 */   public void setUrlCacheProtection(boolean urlCacheProtection) { this.urlCacheProtection = urlCacheProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 139 */   private boolean xmlParsingProtection = true;
/* 140 */   public boolean isXmlParsingProtection() { return this.xmlParsingProtection; }
/*     */   
/* 142 */   public void setXmlParsingProtection(boolean xmlParsingProtection) { this.xmlParsingProtection = xmlParsingProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */   private boolean ldapPoolProtection = true;
/* 156 */   public boolean isLdapPoolProtection() { return this.ldapPoolProtection; }
/*     */   
/* 158 */   public void setLdapPoolProtection(boolean ldapPoolProtection) { this.ldapPoolProtection = ldapPoolProtection; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 167 */   private boolean driverManagerProtection = true;
/*     */   
/* 169 */   public boolean isDriverManagerProtection() { return this.driverManagerProtection; }
/*     */   
/*     */   public void setDriverManagerProtection(boolean driverManagerProtection) {
/* 172 */     this.driverManagerProtection = driverManagerProtection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */   private boolean forkJoinCommonPoolProtection = true;
/*     */   
/* 184 */   public boolean getForkJoinCommonPoolProtection() { return this.forkJoinCommonPoolProtection; }
/*     */   
/*     */   public void setForkJoinCommonPoolProtection(boolean forkJoinCommonPoolProtection) {
/* 187 */     this.forkJoinCommonPoolProtection = forkJoinCommonPoolProtection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 195 */   private String classesToInitialize = null;
/*     */   
/* 197 */   public String getClassesToInitialize() { return this.classesToInitialize; }
/*     */   
/*     */   public void setClassesToInitialize(String classesToInitialize) {
/* 200 */     this.classesToInitialize = classesToInitialize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void lifecycleEvent(LifecycleEvent event)
/*     */   {
/* 208 */     if ("before_init".equals(event.getType()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 221 */       if (this.driverManagerProtection) {
/* 222 */         DriverManager.getDrivers();
/*     */       }
/*     */       
/* 225 */       ClassLoader loader = Thread.currentThread().getContextClassLoader();
/*     */       
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 231 */         Thread.currentThread().setContextClassLoader(
/* 232 */           ClassLoader.getSystemClassLoader());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 252 */         if (this.appContextProtection) {
/* 253 */           ImageIO.getCacheDirectory();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 259 */         if ((this.awtThreadProtection) && (!JreCompat.isJre9Available())) {
/* 260 */           Toolkit.getDefaultToolkit();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 277 */         if ((this.gcDaemonProtection) && (!JreCompat.isJre9Available())) {
/*     */           try {
/* 279 */             Class<?> clazz = Class.forName("sun.misc.GC");
/* 280 */             Method method = clazz.getDeclaredMethod("requestLatency", new Class[] { Long.TYPE });
/*     */             
/*     */ 
/* 283 */             method.invoke(null, new Object[] { Long.valueOf(9223372036854775806L) });
/*     */           } catch (ClassNotFoundException e) {
/* 285 */             if (JreVendor.IS_ORACLE_JVM) {
/* 286 */               log.error(sm.getString("jreLeakListener.gcDaemonFail"), e);
/*     */             }
/*     */             else {
/* 289 */               log.debug(sm.getString("jreLeakListener.gcDaemonFail"), e);
/*     */             }
/*     */           }
/*     */           catch (SecurityException|NoSuchMethodException|IllegalArgumentException|IllegalAccessException e)
/*     */           {
/* 294 */             log.error(sm.getString("jreLeakListener.gcDaemonFail"), e);
/*     */           }
/*     */           catch (InvocationTargetException e) {
/* 297 */             ExceptionUtils.handleThrowable(e.getCause());
/* 298 */             log.error(sm.getString("jreLeakListener.gcDaemonFail"), e);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 313 */         if ((this.tokenPollerProtection) && (!JreCompat.isJre9Available())) {
/* 314 */           Security.getProviders();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 335 */         if (this.urlCacheProtection) {
/*     */           try {
/* 337 */             JreCompat.getInstance().disableCachingForJarUrlConnections();
/*     */           } catch (IOException e) {
/* 339 */             log.error(sm.getString("jreLeakListener.jarUrlConnCacheFail"), e);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 346 */         if ((this.xmlParsingProtection) && (!JreCompat.isJre9Available()))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 354 */           DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/*     */           try {
/* 356 */             DocumentBuilder documentBuilder = factory.newDocumentBuilder();
/*     */             
/*     */ 
/* 359 */             Document document = documentBuilder.newDocument();
/* 360 */             document.createElement("dummy");
/*     */             
/* 362 */             DOMImplementationLS implementation = (DOMImplementationLS)document.getImplementation();
/* 363 */             implementation.createLSSerializer().writeToString(document);
/*     */             
/*     */ 
/* 366 */             document.normalize();
/*     */           } catch (ParserConfigurationException e) {
/* 368 */             log.error(sm.getString("jreLeakListener.xmlParseFail"), e);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 376 */         if ((this.ldapPoolProtection) && (!JreCompat.isJre9Available())) {
/*     */           try {
/* 378 */             Class.forName("com.sun.jndi.ldap.LdapPoolManager");
/*     */           } catch (ClassNotFoundException e) {
/* 380 */             if (JreVendor.IS_ORACLE_JVM) {
/* 381 */               log.error(sm.getString("jreLeakListener.ldapPoolManagerFail"), e);
/*     */             }
/*     */             else {
/* 384 */               log.debug(sm.getString("jreLeakListener.ldapPoolManagerFail"), e);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 394 */         if ((this.forkJoinCommonPoolProtection) && (!JreCompat.isJre9Available()))
/*     */         {
/* 396 */           if (System.getProperty("java.util.concurrent.ForkJoinPool.common.threadFactory") == null) {
/* 397 */             System.setProperty("java.util.concurrent.ForkJoinPool.common.threadFactory", SafeForkJoinWorkerThreadFactory.class
/* 398 */               .getName());
/*     */           }
/*     */         }
/*     */         
/* 402 */         if (this.classesToInitialize != null) {
/* 403 */           StringTokenizer strTok = new StringTokenizer(this.classesToInitialize, ", \r\n\t");
/*     */           
/* 405 */           while (strTok.hasMoreTokens()) {
/* 406 */             String classNameToLoad = strTok.nextToken();
/*     */             try {
/* 408 */               Class.forName(classNameToLoad);
/*     */             } catch (ClassNotFoundException e) {
/* 410 */               log.error(sm
/* 411 */                 .getString("jreLeakListener.classToInitializeFail", new Object[] { classNameToLoad }), e);
/*     */             }
/*     */             
/*     */           }
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 419 */         Thread.currentThread().setContextClassLoader(loader);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\JreMemoryLeakPreventionListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */