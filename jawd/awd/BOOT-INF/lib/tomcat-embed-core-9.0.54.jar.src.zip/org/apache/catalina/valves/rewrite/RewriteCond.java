/*     */ package org.apache.catalina.valves.rewrite;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RewriteCond
/*     */ {
/*     */   public static abstract class Condition
/*     */   {
/*     */     public abstract boolean evaluate(String paramString, Resolver paramResolver);
/*     */   }
/*     */   
/*     */   public static class PatternCondition
/*     */     extends RewriteCond.Condition
/*     */   {
/*     */     public Pattern pattern;
/*  31 */     private ThreadLocal<Matcher> matcher = new ThreadLocal();
/*     */     
/*     */     public boolean evaluate(String value, Resolver resolver)
/*     */     {
/*  35 */       Matcher m = this.pattern.matcher(value);
/*  36 */       if (m.matches()) {
/*  37 */         this.matcher.set(m);
/*  38 */         return true;
/*     */       }
/*  40 */       return false;
/*     */     }
/*     */     
/*     */     public Matcher getMatcher()
/*     */     {
/*  45 */       return (Matcher)this.matcher.get();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class LexicalCondition
/*     */     extends RewriteCond.Condition
/*     */   {
/*  55 */     public int type = 0;
/*     */     public String condition;
/*     */     
/*     */     public boolean evaluate(String value, Resolver resolver)
/*     */     {
/*  60 */       int result = value.compareTo(this.condition);
/*  61 */       switch (this.type) {
/*     */       case -1: 
/*  63 */         return result < 0;
/*     */       case 0: 
/*  65 */         return result == 0;
/*     */       case 1: 
/*  67 */         return result > 0;
/*     */       }
/*  69 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class ResourceCondition
/*     */     extends RewriteCond.Condition
/*     */   {
/*  81 */     public int type = 0;
/*     */     
/*     */     public boolean evaluate(String value, Resolver resolver)
/*     */     {
/*  85 */       return resolver.resolveResource(this.type, value);
/*     */     }
/*     */   }
/*     */   
/*  89 */   protected String testString = null;
/*  90 */   protected String condPattern = null;
/*  91 */   protected String flagsString = null;
/*     */   
/*     */   public String getCondPattern() {
/*  94 */     return this.condPattern;
/*     */   }
/*     */   
/*     */   public void setCondPattern(String condPattern) {
/*  98 */     this.condPattern = condPattern;
/*     */   }
/*     */   
/*     */   public String getTestString() {
/* 102 */     return this.testString;
/*     */   }
/*     */   
/*     */   public void setTestString(String testString) {
/* 106 */     this.testString = testString;
/*     */   }
/*     */   
/*     */   public final String getFlagsString() {
/* 110 */     return this.flagsString;
/*     */   }
/*     */   
/*     */   public final void setFlagsString(String flagsString) {
/* 114 */     this.flagsString = flagsString;
/*     */   }
/*     */   
/*     */   public void parse(Map<String, RewriteMap> maps) {
/* 118 */     this.test = new Substitution();
/* 119 */     this.test.setSub(this.testString);
/* 120 */     this.test.parse(maps);
/* 121 */     if (this.condPattern.startsWith("!")) {
/* 122 */       this.positive = false;
/* 123 */       this.condPattern = this.condPattern.substring(1);
/*     */     }
/* 125 */     if (this.condPattern.startsWith("<")) {
/* 126 */       LexicalCondition ncondition = new LexicalCondition();
/* 127 */       ncondition.type = -1;
/* 128 */       ncondition.condition = this.condPattern.substring(1);
/* 129 */       this.condition = ncondition;
/* 130 */     } else if (this.condPattern.startsWith(">")) {
/* 131 */       LexicalCondition ncondition = new LexicalCondition();
/* 132 */       ncondition.type = 1;
/* 133 */       ncondition.condition = this.condPattern.substring(1);
/* 134 */       this.condition = ncondition;
/* 135 */     } else if (this.condPattern.startsWith("=")) {
/* 136 */       LexicalCondition ncondition = new LexicalCondition();
/* 137 */       ncondition.type = 0;
/* 138 */       ncondition.condition = this.condPattern.substring(1);
/* 139 */       this.condition = ncondition;
/* 140 */     } else if (this.condPattern.equals("-d")) {
/* 141 */       ResourceCondition ncondition = new ResourceCondition();
/* 142 */       ncondition.type = 0;
/* 143 */       this.condition = ncondition;
/* 144 */     } else if (this.condPattern.equals("-f")) {
/* 145 */       ResourceCondition ncondition = new ResourceCondition();
/* 146 */       ncondition.type = 1;
/* 147 */       this.condition = ncondition;
/* 148 */     } else if (this.condPattern.equals("-s")) {
/* 149 */       ResourceCondition ncondition = new ResourceCondition();
/* 150 */       ncondition.type = 2;
/* 151 */       this.condition = ncondition;
/*     */     } else {
/* 153 */       PatternCondition ncondition = new PatternCondition();
/* 154 */       int flags = 0;
/* 155 */       if (isNocase()) {
/* 156 */         flags |= 0x2;
/*     */       }
/* 158 */       ncondition.pattern = Pattern.compile(this.condPattern, flags);
/* 159 */       this.condition = ncondition;
/*     */     }
/*     */   }
/*     */   
/*     */   public Matcher getMatcher() {
/* 164 */     if ((this.condition instanceof PatternCondition)) {
/* 165 */       return ((PatternCondition)this.condition).getMatcher();
/*     */     }
/* 167 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 175 */     return "RewriteCond " + this.testString + " " + this.condPattern + (this.flagsString != null ? " " + this.flagsString : "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 180 */   protected boolean positive = true;
/*     */   
/* 182 */   protected Substitution test = null;
/*     */   
/* 184 */   protected Condition condition = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */   public boolean nocase = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 197 */   public boolean ornext = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evaluate(Matcher rule, Matcher cond, Resolver resolver)
/*     */   {
/* 208 */     String value = this.test.evaluate(rule, cond, resolver);
/* 209 */     if (this.positive) {
/* 210 */       return this.condition.evaluate(value, resolver);
/*     */     }
/* 212 */     return !this.condition.evaluate(value, resolver);
/*     */   }
/*     */   
/*     */   public boolean isNocase()
/*     */   {
/* 217 */     return this.nocase;
/*     */   }
/*     */   
/*     */   public void setNocase(boolean nocase) {
/* 221 */     this.nocase = nocase;
/*     */   }
/*     */   
/*     */   public boolean isOrnext() {
/* 225 */     return this.ornext;
/*     */   }
/*     */   
/*     */   public void setOrnext(boolean ornext) {
/* 229 */     this.ornext = ornext;
/*     */   }
/*     */   
/*     */   public boolean isPositive() {
/* 233 */     return this.positive;
/*     */   }
/*     */   
/*     */   public void setPositive(boolean positive) {
/* 237 */     this.positive = positive;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\rewrite\RewriteCond.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */