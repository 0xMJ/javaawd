/*    */ package org.apache.catalina.core;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import org.apache.catalina.Host;
/*    */ import org.apache.catalina.Pipeline;
/*    */ import org.apache.catalina.Valve;
/*    */ import org.apache.catalina.connector.Request;
/*    */ import org.apache.catalina.connector.Response;
/*    */ import org.apache.catalina.valves.ValveBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StandardEngineValve
/*    */   extends ValveBase
/*    */ {
/*    */   public StandardEngineValve()
/*    */   {
/* 41 */     super(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final void invoke(Request request, Response response)
/*    */     throws IOException, ServletException
/*    */   {
/* 63 */     Host host = request.getHost();
/* 64 */     if (host == null)
/*    */     {
/*    */ 
/*    */ 
/* 68 */       if (!response.isError()) {
/* 69 */         response.sendError(404);
/*    */       }
/* 71 */       return;
/*    */     }
/* 73 */     if (request.isAsyncSupported()) {
/* 74 */       request.setAsyncSupported(host.getPipeline().isAsyncSupported());
/*    */     }
/*    */     
/*    */ 
/* 78 */     host.getPipeline().getFirst().invoke(request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\StandardEngineValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */