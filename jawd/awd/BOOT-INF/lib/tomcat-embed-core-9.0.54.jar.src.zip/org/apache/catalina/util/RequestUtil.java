/*    */ package org.apache.catalina.util;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RequestUtil
/*    */ {
/*    */   public static StringBuffer getRequestURL(HttpServletRequest request)
/*    */   {
/* 40 */     StringBuffer url = new StringBuffer();
/* 41 */     String scheme = request.getScheme();
/* 42 */     int port = request.getServerPort();
/* 43 */     if (port < 0)
/*    */     {
/* 45 */       port = 80;
/*    */     }
/*    */     
/* 48 */     url.append(scheme);
/* 49 */     url.append("://");
/* 50 */     url.append(request.getServerName());
/* 51 */     if (((scheme.equals("http")) && (port != 80)) || (
/* 52 */       (scheme.equals("https")) && (port != 443))) {
/* 53 */       url.append(':');
/* 54 */       url.append(port);
/*    */     }
/* 56 */     url.append(request.getRequestURI());
/*    */     
/* 58 */     return url;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\RequestUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */