/*    */ package org.apache.catalina.core;
/*    */ 
/*    */ import org.apache.catalina.LifecycleEvent;
/*    */ import org.apache.catalina.LifecycleListener;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JniLifecycleListener
/*    */   implements LifecycleListener
/*    */ {
/* 40 */   private static final Log log = LogFactory.getLog(JniLifecycleListener.class);
/* 41 */   protected static final StringManager sm = StringManager.getManager(JniLifecycleListener.class);
/*    */   
/* 43 */   private String libraryName = "";
/* 44 */   private String libraryPath = "";
/*    */   
/*    */ 
/*    */   public void lifecycleEvent(LifecycleEvent event)
/*    */   {
/* 49 */     if ("before_start".equals(event.getType()))
/*    */     {
/* 51 */       if (!this.libraryName.isEmpty()) {
/* 52 */         System.loadLibrary(this.libraryName);
/* 53 */         log.info(sm.getString("jniLifecycleListener.load.name", new Object[] { this.libraryName }));
/* 54 */       } else if (!this.libraryPath.isEmpty()) {
/* 55 */         System.load(this.libraryPath);
/* 56 */         log.info(sm.getString("jniLifecycleListener.load.path", new Object[] { this.libraryPath }));
/*    */       } else {
/* 58 */         throw new IllegalArgumentException(sm.getString("jniLifecycleListener.missingPathOrName"));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void setLibraryName(String libraryName)
/*    */   {
/* 65 */     if (!this.libraryPath.isEmpty()) {
/* 66 */       throw new IllegalArgumentException(sm.getString("jniLifecycleListener.bothPathAndName"));
/*    */     }
/*    */     
/* 69 */     this.libraryName = libraryName;
/*    */   }
/*    */   
/*    */   public String getLibraryName() {
/* 73 */     return this.libraryName;
/*    */   }
/*    */   
/*    */   public void setLibraryPath(String libraryPath)
/*    */   {
/* 78 */     if (!this.libraryName.isEmpty()) {
/* 79 */       throw new IllegalArgumentException(sm.getString("jniLifecycleListener.bothPathAndName"));
/*    */     }
/*    */     
/* 82 */     this.libraryPath = libraryPath;
/*    */   }
/*    */   
/*    */   public String getLibraryPath() {
/* 86 */     return this.libraryPath;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\JniLifecycleListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */