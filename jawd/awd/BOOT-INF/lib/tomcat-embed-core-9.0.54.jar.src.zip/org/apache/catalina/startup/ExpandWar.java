/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Enumeration;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipException;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpandWar
/*     */ {
/*  49 */   private static final Log log = LogFactory.getLog(ExpandWar.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String expand(Host host, URL war, String pathname)
/*     */     throws IOException
/*     */   {
/*  81 */     JarURLConnection juc = (JarURLConnection)war.openConnection();
/*  82 */     juc.setUseCaches(false);
/*  83 */     URL jarFileUrl = juc.getJarFileURL();
/*  84 */     URLConnection jfuc = jarFileUrl.openConnection();
/*     */     
/*  86 */     boolean success = false;
/*  87 */     File docBase = new File(host.getAppBaseFile(), pathname);
/*  88 */     File warTracker = new File(host.getAppBaseFile(), pathname + "/META-INF/war-tracker");
/*  89 */     long warLastModified = -1L;
/*     */     
/*  91 */     InputStream is = jfuc.getInputStream();Throwable localThrowable9 = null;
/*     */     try {
/*  93 */       warLastModified = jfuc.getLastModified();
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/*  91 */       localThrowable9 = localThrowable1;throw localThrowable1;
/*     */     }
/*     */     finally {
/*  94 */       if (is != null) if (localThrowable9 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable9.addSuppressed(localThrowable2); } else { is.close();
/*     */         }
/*     */     }
/*  97 */     if (docBase.exists())
/*     */     {
/*     */ 
/*     */ 
/* 101 */       if ((!warTracker.exists()) || (warTracker.lastModified() == warLastModified))
/*     */       {
/* 103 */         success = true;
/* 104 */         return docBase.getAbsolutePath();
/*     */       }
/*     */       
/*     */ 
/* 108 */       log.info(sm.getString("expandWar.deleteOld", new Object[] { docBase }));
/* 109 */       if (!delete(docBase)) {
/* 110 */         throw new IOException(sm.getString("expandWar.deleteFailed", new Object[] { docBase }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 115 */     if ((!docBase.mkdir()) && (!docBase.isDirectory())) {
/* 116 */       throw new IOException(sm.getString("expandWar.createFailed", new Object[] { docBase }));
/*     */     }
/*     */     
/*     */ 
/* 120 */     Path canonicalDocBasePath = docBase.getCanonicalFile().toPath();
/*     */     
/*     */ 
/* 123 */     File warTrackerParent = warTracker.getParentFile();
/* 124 */     if ((!warTrackerParent.isDirectory()) && (!warTrackerParent.mkdirs())) {
/* 125 */       throw new IOException(sm.getString("expandWar.createFailed", new Object[] { warTrackerParent.getAbsolutePath() }));
/*     */     }
/*     */     try {
/* 128 */       JarFile jarFile = juc.getJarFile();Throwable localThrowable10 = null;
/*     */       try {
/* 130 */         Enumeration<JarEntry> jarEntries = jarFile.entries();
/* 131 */         while (jarEntries.hasMoreElements()) {
/* 132 */           JarEntry jarEntry = (JarEntry)jarEntries.nextElement();
/* 133 */           String name = jarEntry.getName();
/* 134 */           File expandedFile = new File(docBase, name);
/* 135 */           if (!expandedFile.getCanonicalFile().toPath().startsWith(canonicalDocBasePath))
/*     */           {
/*     */ 
/*     */ 
/* 139 */             throw new IllegalArgumentException(sm.getString("expandWar.illegalPath", new Object[] { war, name, expandedFile
/* 140 */               .getCanonicalPath(), canonicalDocBasePath }));
/*     */           }
/*     */           
/* 143 */           int last = name.lastIndexOf('/');
/* 144 */           if (last >= 0)
/*     */           {
/* 146 */             File parent = new File(docBase, name.substring(0, last));
/* 147 */             if ((!parent.mkdirs()) && (!parent.isDirectory()))
/*     */             {
/* 149 */               throw new IOException(sm.getString("expandWar.createFailed", new Object[] { parent }));
/*     */             }
/*     */           }
/* 152 */           if (!name.endsWith("/"))
/*     */           {
/*     */ 
/*     */ 
/* 156 */             InputStream input = jarFile.getInputStream(jarEntry);Throwable localThrowable11 = null;
/* 157 */             try { if (null == input) {
/* 158 */                 throw new ZipException(sm.getString("expandWar.missingJarEntry", new Object[] {jarEntry
/* 159 */                   .getName() }));
/*     */               }
/*     */               
/*     */ 
/* 163 */               expand(input, expandedFile);
/* 164 */               long lastModified = jarEntry.getTime();
/* 165 */               if ((lastModified != -1L) && (lastModified != 0L) && 
/* 166 */                 (!expandedFile.setLastModified(lastModified)))
/*     */               {
/* 168 */                 throw new IOException(sm.getString("expandWar.lastModifiedFailed", new Object[] { expandedFile }));
/*     */               }
/*     */             }
/*     */             catch (Throwable localThrowable4)
/*     */             {
/* 156 */               localThrowable11 = localThrowable4;throw localThrowable4;
/*     */             }
/*     */             finally {}
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 176 */         if (!warTracker.createNewFile()) {
/* 177 */           throw new IOException(sm.getString("expandWar.createFileFailed", new Object[] { warTracker }));
/*     */         }
/* 179 */         if (!warTracker.setLastModified(warLastModified)) {
/* 180 */           throw new IOException(sm.getString("expandWar.lastModifiedFailed", new Object[] { warTracker }));
/*     */         }
/*     */         
/* 183 */         success = true;
/*     */       }
/*     */       catch (Throwable localThrowable7)
/*     */       {
/* 128 */         localThrowable10 = localThrowable7;throw localThrowable7;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */         if (jarFile != null) if (localThrowable10 != null) try { jarFile.close(); } catch (Throwable localThrowable8) { localThrowable10.addSuppressed(localThrowable8); } else jarFile.close();
/* 185 */       } } catch (IOException e) { throw e;
/*     */     } finally {
/* 187 */       if (!success)
/*     */       {
/*     */ 
/* 190 */         deleteDir(docBase);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 195 */     return docBase.getAbsolutePath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void validate(Host host, URL war, String pathname)
/*     */     throws IOException
/*     */   {
/* 214 */     File docBase = new File(host.getAppBaseFile(), pathname);
/*     */     
/*     */ 
/* 217 */     Path canonicalDocBasePath = docBase.getCanonicalFile().toPath();
/* 218 */     JarURLConnection juc = (JarURLConnection)war.openConnection();
/* 219 */     juc.setUseCaches(false);
/* 220 */     try { JarFile jarFile = juc.getJarFile();Throwable localThrowable3 = null;
/* 221 */       try { Enumeration<JarEntry> jarEntries = jarFile.entries();
/* 222 */         while (jarEntries.hasMoreElements()) {
/* 223 */           JarEntry jarEntry = (JarEntry)jarEntries.nextElement();
/* 224 */           String name = jarEntry.getName();
/* 225 */           File expandedFile = new File(docBase, name);
/* 226 */           if (!expandedFile.getCanonicalFile().toPath().startsWith(canonicalDocBasePath))
/*     */           {
/*     */ 
/*     */ 
/* 230 */             throw new IllegalArgumentException(sm.getString("expandWar.illegalPath", new Object[] { war, name, expandedFile
/* 231 */               .getCanonicalPath(), canonicalDocBasePath }));
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 220 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 235 */         if (jarFile != null) if (localThrowable3 != null) try { jarFile.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else jarFile.close();
/* 236 */       } } catch (IOException e) { throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean copy(File src, File dest)
/*     */   {
/* 250 */     boolean result = true;
/*     */     
/* 252 */     String[] files = null;
/* 253 */     if (src.isDirectory()) {
/* 254 */       files = src.list();
/* 255 */       result = dest.mkdir();
/*     */     } else {
/* 257 */       files = new String[1];
/* 258 */       files[0] = "";
/*     */     }
/* 260 */     if (files == null) {
/* 261 */       files = new String[0];
/*     */     }
/* 263 */     for (int i = 0; (i < files.length) && (result); i++) {
/* 264 */       File fileSrc = new File(src, files[i]);
/* 265 */       File fileDest = new File(dest, files[i]);
/* 266 */       if (fileSrc.isDirectory())
/* 267 */         result = copy(fileSrc, fileDest); else {
/*     */         try {
/* 269 */           FileChannel ic = new FileInputStream(fileSrc).getChannel();Throwable localThrowable6 = null;
/* 270 */           try { FileChannel oc = new FileOutputStream(fileDest).getChannel();Throwable localThrowable7 = null;
/* 271 */             try { ic.transferTo(0L, ic.size(), oc);
/*     */             }
/*     */             catch (Throwable localThrowable1)
/*     */             {
/* 269 */               localThrowable7 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable4) { localThrowable6 = localThrowable4;throw localThrowable4;
/*     */           }
/*     */           finally {
/* 272 */             if (ic != null) if (localThrowable6 != null) try { ic.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else ic.close();
/* 273 */           } } catch (IOException e) { log.error(sm.getString("expandWar.copy", new Object[] { fileSrc, fileDest }), e);
/* 274 */           result = false;
/*     */         }
/*     */       }
/*     */     }
/* 278 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean delete(File dir)
/*     */   {
/* 291 */     return delete(dir, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean delete(File dir, boolean logFailure)
/*     */   {
/*     */     boolean result;
/*     */     
/*     */ 
/*     */ 
/*     */     boolean result;
/*     */     
/*     */ 
/* 306 */     if (dir.isDirectory()) {
/* 307 */       result = deleteDir(dir, logFailure);
/*     */     } else { boolean result;
/* 309 */       if (dir.exists()) {
/* 310 */         result = dir.delete();
/*     */       } else {
/* 312 */         result = true;
/*     */       }
/*     */     }
/* 315 */     if ((logFailure) && (!result)) {
/* 316 */       log.error(sm.getString("expandWar.deleteFailed", new Object[] {dir
/* 317 */         .getAbsolutePath() }));
/*     */     }
/* 319 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean deleteDir(File dir)
/*     */   {
/* 331 */     return deleteDir(dir, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean deleteDir(File dir, boolean logFailure)
/*     */   {
/* 346 */     String[] files = dir.list();
/* 347 */     if (files == null) {
/* 348 */       files = new String[0];
/*     */     }
/* 350 */     for (String s : files) {
/* 351 */       File file = new File(dir, s);
/* 352 */       if (file.isDirectory()) {
/* 353 */         deleteDir(file, logFailure);
/*     */       } else {
/* 355 */         file.delete();
/*     */       }
/*     */     }
/*     */     boolean result;
/*     */     boolean result;
/* 360 */     if (dir.exists()) {
/* 361 */       result = dir.delete();
/*     */     } else {
/* 363 */       result = true;
/*     */     }
/*     */     
/* 366 */     if ((logFailure) && (!result)) {
/* 367 */       log.error(sm.getString("expandWar.deleteFailed", new Object[] {dir
/* 368 */         .getAbsolutePath() }));
/*     */     }
/*     */     
/* 371 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void expand(InputStream input, File file)
/*     */     throws IOException
/*     */   {
/* 384 */     BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(file));Throwable localThrowable3 = null;
/*     */     try {
/* 386 */       byte[] buffer = new byte['ࠀ'];
/*     */       for (;;) {
/* 388 */         int n = input.read(buffer);
/* 389 */         if (n <= 0) {
/*     */           break;
/*     */         }
/* 392 */         output.write(buffer, 0, n);
/*     */       }
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 384 */       localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 394 */       if (output != null) if (localThrowable3 != null) try { output.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else output.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\ExpandWar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */