/*      */ package org.apache.catalina.startup;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileWriter;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.ConnectException;
/*      */ import java.net.Socket;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.logging.LogManager;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.connector.Connector;
/*      */ import org.apache.catalina.core.StandardContext;
/*      */ import org.apache.catalina.security.SecurityConfig;
/*      */ import org.apache.juli.ClassLoaderLogManager;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.digester.Digester;
/*      */ import org.apache.tomcat.util.digester.Digester.GeneratedCodeLoader;
/*      */ import org.apache.tomcat.util.digester.Rule;
/*      */ import org.apache.tomcat.util.digester.RuleSet;
/*      */ import org.apache.tomcat.util.file.ConfigFileLoader;
/*      */ import org.apache.tomcat.util.file.ConfigurationSource;
/*      */ import org.apache.tomcat.util.file.ConfigurationSource.Resource;
/*      */ import org.apache.tomcat.util.log.SystemLogHandler;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.xml.sax.Attributes;
/*      */ import org.xml.sax.InputSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Catalina
/*      */ {
/*   82 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String SERVER_XML = "conf/server.xml";
/*      */   
/*      */ 
/*      */ 
/*   91 */   protected boolean await = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   96 */   protected String configFile = "conf/server.xml";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  102 */   protected ClassLoader parentClassLoader = Catalina.class
/*  103 */     .getClassLoader();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  109 */   protected Server server = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  115 */   protected boolean useShutdownHook = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  121 */   protected Thread shutdownHook = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  127 */   protected boolean useNaming = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  133 */   protected boolean loaded = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  139 */   protected boolean generateCode = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  145 */   protected File generatedCodeLocation = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  151 */   protected String generatedCodeLocationParameter = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  157 */   protected String generatedCodePackage = "catalinaembedded";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  163 */   protected boolean useGeneratedCode = false;
/*      */   
/*      */ 
/*      */ 
/*      */   public Catalina()
/*      */   {
/*  169 */     setSecurityProtection();
/*  170 */     ExceptionUtils.preload();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setConfigFile(String file)
/*      */   {
/*  177 */     this.configFile = file;
/*      */   }
/*      */   
/*      */   public String getConfigFile()
/*      */   {
/*  182 */     return this.configFile;
/*      */   }
/*      */   
/*      */   public void setUseShutdownHook(boolean useShutdownHook)
/*      */   {
/*  187 */     this.useShutdownHook = useShutdownHook;
/*      */   }
/*      */   
/*      */   public boolean getUseShutdownHook()
/*      */   {
/*  192 */     return this.useShutdownHook;
/*      */   }
/*      */   
/*      */   public boolean getGenerateCode()
/*      */   {
/*  197 */     return this.generateCode;
/*      */   }
/*      */   
/*      */   public void setGenerateCode(boolean generateCode)
/*      */   {
/*  202 */     this.generateCode = generateCode;
/*      */   }
/*      */   
/*      */   public boolean getUseGeneratedCode()
/*      */   {
/*  207 */     return this.useGeneratedCode;
/*      */   }
/*      */   
/*      */   public void setUseGeneratedCode(boolean useGeneratedCode)
/*      */   {
/*  212 */     this.useGeneratedCode = useGeneratedCode;
/*      */   }
/*      */   
/*      */   public File getGeneratedCodeLocation()
/*      */   {
/*  217 */     return this.generatedCodeLocation;
/*      */   }
/*      */   
/*      */   public void setGeneratedCodeLocation(File generatedCodeLocation)
/*      */   {
/*  222 */     this.generatedCodeLocation = generatedCodeLocation;
/*      */   }
/*      */   
/*      */   public String getGeneratedCodePackage()
/*      */   {
/*  227 */     return this.generatedCodePackage;
/*      */   }
/*      */   
/*      */   public void setGeneratedCodePackage(String generatedCodePackage)
/*      */   {
/*  232 */     this.generatedCodePackage = generatedCodePackage;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setParentClassLoader(ClassLoader parentClassLoader)
/*      */   {
/*  242 */     this.parentClassLoader = parentClassLoader;
/*      */   }
/*      */   
/*      */   public ClassLoader getParentClassLoader() {
/*  246 */     if (this.parentClassLoader != null) {
/*  247 */       return this.parentClassLoader;
/*      */     }
/*  249 */     return ClassLoader.getSystemClassLoader();
/*      */   }
/*      */   
/*      */   public void setServer(Server server) {
/*  253 */     this.server = server;
/*      */   }
/*      */   
/*      */   public Server getServer()
/*      */   {
/*  258 */     return this.server;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUseNaming()
/*      */   {
/*  266 */     return this.useNaming;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseNaming(boolean useNaming)
/*      */   {
/*  276 */     this.useNaming = useNaming;
/*      */   }
/*      */   
/*      */   public void setAwait(boolean b) {
/*  280 */     this.await = b;
/*      */   }
/*      */   
/*      */   public boolean isAwait() {
/*  284 */     return this.await;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean arguments(String[] args)
/*      */   {
/*  298 */     boolean isConfig = false;
/*  299 */     boolean isGenerateCode = false;
/*      */     
/*  301 */     if (args.length < 1) {
/*  302 */       usage();
/*  303 */       return false;
/*      */     }
/*      */     
/*  306 */     for (String arg : args) {
/*  307 */       if (isConfig) {
/*  308 */         this.configFile = arg;
/*  309 */         isConfig = false;
/*  310 */       } else if (arg.equals("-config")) {
/*  311 */         isConfig = true;
/*  312 */       } else if (arg.equals("-generateCode")) {
/*  313 */         setGenerateCode(true);
/*  314 */         isGenerateCode = true;
/*  315 */       } else if (arg.equals("-useGeneratedCode")) {
/*  316 */         setUseGeneratedCode(true);
/*  317 */         isGenerateCode = false;
/*  318 */       } else if (arg.equals("-nonaming")) {
/*  319 */         setUseNaming(false);
/*  320 */         isGenerateCode = false;
/*  321 */       } else { if (arg.equals("-help")) {
/*  322 */           usage();
/*  323 */           return false; }
/*  324 */         if (arg.equals("start")) {
/*  325 */           isGenerateCode = false;
/*      */         }
/*  327 */         else if (arg.equals("configtest")) {
/*  328 */           isGenerateCode = false;
/*      */         }
/*  330 */         else if (arg.equals("stop")) {
/*  331 */           isGenerateCode = false;
/*      */         }
/*  333 */         else if (isGenerateCode) {
/*  334 */           this.generatedCodeLocationParameter = arg;
/*  335 */           isGenerateCode = false;
/*      */         } else {
/*  337 */           usage();
/*  338 */           return false;
/*      */         }
/*      */       }
/*      */     }
/*  342 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected File configFile()
/*      */   {
/*  352 */     File file = new File(this.configFile);
/*  353 */     if (!file.isAbsolute()) {
/*  354 */       file = new File(Bootstrap.getCatalinaBase(), this.configFile);
/*      */     }
/*  356 */     return file;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Digester createStartDigester()
/*      */   {
/*  367 */     Digester digester = new Digester();
/*  368 */     digester.setValidating(false);
/*  369 */     digester.setRulesValidation(true);
/*  370 */     Map<Class<?>, List<String>> fakeAttributes = new HashMap();
/*      */     
/*  372 */     List<String> objectAttrs = new ArrayList();
/*  373 */     objectAttrs.add("className");
/*  374 */     fakeAttributes.put(Object.class, objectAttrs);
/*      */     
/*  376 */     List<String> contextAttrs = new ArrayList();
/*  377 */     contextAttrs.add("source");
/*  378 */     fakeAttributes.put(StandardContext.class, contextAttrs);
/*      */     
/*  380 */     List<String> connectorAttrs = new ArrayList();
/*  381 */     connectorAttrs.add("portOffset");
/*  382 */     fakeAttributes.put(Connector.class, connectorAttrs);
/*  383 */     digester.setFakeAttributes(fakeAttributes);
/*  384 */     digester.setUseContextClassLoader(true);
/*      */     
/*      */ 
/*  387 */     digester.addObjectCreate("Server", "org.apache.catalina.core.StandardServer", "className");
/*      */     
/*      */ 
/*  390 */     digester.addSetProperties("Server");
/*  391 */     digester.addSetNext("Server", "setServer", "org.apache.catalina.Server");
/*      */     
/*      */ 
/*      */ 
/*  395 */     digester.addObjectCreate("Server/GlobalNamingResources", "org.apache.catalina.deploy.NamingResourcesImpl");
/*      */     
/*  397 */     digester.addSetProperties("Server/GlobalNamingResources");
/*  398 */     digester.addSetNext("Server/GlobalNamingResources", "setGlobalNamingResources", "org.apache.catalina.deploy.NamingResourcesImpl");
/*      */     
/*      */ 
/*      */ 
/*  402 */     digester.addRule("Server/Listener", new ListenerCreateRule(null, "className"));
/*      */     
/*  404 */     digester.addSetProperties("Server/Listener");
/*  405 */     digester.addSetNext("Server/Listener", "addLifecycleListener", "org.apache.catalina.LifecycleListener");
/*      */     
/*      */ 
/*      */ 
/*  409 */     digester.addObjectCreate("Server/Service", "org.apache.catalina.core.StandardService", "className");
/*      */     
/*      */ 
/*  412 */     digester.addSetProperties("Server/Service");
/*  413 */     digester.addSetNext("Server/Service", "addService", "org.apache.catalina.Service");
/*      */     
/*      */ 
/*      */ 
/*  417 */     digester.addObjectCreate("Server/Service/Listener", null, "className");
/*      */     
/*      */ 
/*  420 */     digester.addSetProperties("Server/Service/Listener");
/*  421 */     digester.addSetNext("Server/Service/Listener", "addLifecycleListener", "org.apache.catalina.LifecycleListener");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  426 */     digester.addObjectCreate("Server/Service/Executor", "org.apache.catalina.core.StandardThreadExecutor", "className");
/*      */     
/*      */ 
/*  429 */     digester.addSetProperties("Server/Service/Executor");
/*      */     
/*  431 */     digester.addSetNext("Server/Service/Executor", "addExecutor", "org.apache.catalina.Executor");
/*      */     
/*      */ 
/*      */ 
/*  435 */     digester.addRule("Server/Service/Connector", new ConnectorCreateRule());
/*      */     
/*  437 */     digester.addSetProperties("Server/Service/Connector", new String[] { "executor", "sslImplementationName", "protocol" });
/*      */     
/*  439 */     digester.addSetNext("Server/Service/Connector", "addConnector", "org.apache.catalina.connector.Connector");
/*      */     
/*      */ 
/*      */ 
/*  443 */     digester.addRule("Server/Service/Connector", new AddPortOffsetRule());
/*      */     
/*  445 */     digester.addObjectCreate("Server/Service/Connector/SSLHostConfig", "org.apache.tomcat.util.net.SSLHostConfig");
/*      */     
/*  447 */     digester.addSetProperties("Server/Service/Connector/SSLHostConfig");
/*  448 */     digester.addSetNext("Server/Service/Connector/SSLHostConfig", "addSslHostConfig", "org.apache.tomcat.util.net.SSLHostConfig");
/*      */     
/*      */ 
/*      */ 
/*  452 */     digester.addRule("Server/Service/Connector/SSLHostConfig/Certificate", new CertificateCreateRule());
/*      */     
/*  454 */     digester.addSetProperties("Server/Service/Connector/SSLHostConfig/Certificate", new String[] { "type" });
/*  455 */     digester.addSetNext("Server/Service/Connector/SSLHostConfig/Certificate", "addCertificate", "org.apache.tomcat.util.net.SSLHostConfigCertificate");
/*      */     
/*      */ 
/*      */ 
/*  459 */     digester.addObjectCreate("Server/Service/Connector/SSLHostConfig/OpenSSLConf", "org.apache.tomcat.util.net.openssl.OpenSSLConf");
/*      */     
/*  461 */     digester.addSetProperties("Server/Service/Connector/SSLHostConfig/OpenSSLConf");
/*  462 */     digester.addSetNext("Server/Service/Connector/SSLHostConfig/OpenSSLConf", "setOpenSslConf", "org.apache.tomcat.util.net.openssl.OpenSSLConf");
/*      */     
/*      */ 
/*      */ 
/*  466 */     digester.addObjectCreate("Server/Service/Connector/SSLHostConfig/OpenSSLConf/OpenSSLConfCmd", "org.apache.tomcat.util.net.openssl.OpenSSLConfCmd");
/*      */     
/*  468 */     digester.addSetProperties("Server/Service/Connector/SSLHostConfig/OpenSSLConf/OpenSSLConfCmd");
/*  469 */     digester.addSetNext("Server/Service/Connector/SSLHostConfig/OpenSSLConf/OpenSSLConfCmd", "addCmd", "org.apache.tomcat.util.net.openssl.OpenSSLConfCmd");
/*      */     
/*      */ 
/*      */ 
/*  473 */     digester.addObjectCreate("Server/Service/Connector/Listener", null, "className");
/*      */     
/*      */ 
/*  476 */     digester.addSetProperties("Server/Service/Connector/Listener");
/*  477 */     digester.addSetNext("Server/Service/Connector/Listener", "addLifecycleListener", "org.apache.catalina.LifecycleListener");
/*      */     
/*      */ 
/*      */ 
/*  481 */     digester.addObjectCreate("Server/Service/Connector/UpgradeProtocol", null, "className");
/*      */     
/*      */ 
/*  484 */     digester.addSetProperties("Server/Service/Connector/UpgradeProtocol");
/*  485 */     digester.addSetNext("Server/Service/Connector/UpgradeProtocol", "addUpgradeProtocol", "org.apache.coyote.UpgradeProtocol");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  490 */     digester.addRuleSet(new NamingRuleSet("Server/GlobalNamingResources/"));
/*  491 */     digester.addRuleSet(new EngineRuleSet("Server/Service/"));
/*  492 */     digester.addRuleSet(new HostRuleSet("Server/Service/Engine/"));
/*  493 */     digester.addRuleSet(new ContextRuleSet("Server/Service/Engine/Host/"));
/*  494 */     addClusterRuleSet(digester, "Server/Service/Engine/Host/Cluster/");
/*  495 */     digester.addRuleSet(new NamingRuleSet("Server/Service/Engine/Host/Context/"));
/*      */     
/*      */ 
/*  498 */     digester.addRule("Server/Service/Engine", new SetParentClassLoaderRule(this.parentClassLoader));
/*      */     
/*  500 */     addClusterRuleSet(digester, "Server/Service/Engine/Cluster/");
/*      */     
/*  502 */     return digester;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addClusterRuleSet(Digester digester, String prefix)
/*      */   {
/*  510 */     Class<?> clazz = null;
/*  511 */     Constructor<?> constructor = null;
/*      */     try {
/*  513 */       clazz = Class.forName("org.apache.catalina.ha.ClusterRuleSet");
/*  514 */       constructor = clazz.getConstructor(new Class[] { String.class });
/*  515 */       RuleSet ruleSet = (RuleSet)constructor.newInstance(new Object[] { prefix });
/*  516 */       digester.addRuleSet(ruleSet);
/*      */     } catch (Exception e) {
/*  518 */       if (log.isDebugEnabled()) {
/*  519 */         log.debug(sm.getString("catalina.noCluster", new Object[] {e
/*  520 */           .getClass().getName() + ": " + e.getMessage() }), e);
/*  521 */       } else if (log.isInfoEnabled()) {
/*  522 */         log.info(sm.getString("catalina.noCluster", new Object[] {e
/*  523 */           .getClass().getName() + ": " + e.getMessage() }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Digester createStopDigester()
/*      */   {
/*  535 */     Digester digester = new Digester();
/*  536 */     digester.setUseContextClassLoader(true);
/*      */     
/*      */ 
/*  539 */     digester.addObjectCreate("Server", "org.apache.catalina.core.StandardServer", "className");
/*      */     
/*      */ 
/*  542 */     digester.addSetProperties("Server");
/*  543 */     digester.addSetNext("Server", "setServer", "org.apache.catalina.Server");
/*      */     
/*      */ 
/*      */ 
/*  547 */     return digester;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void parseServerXml(boolean start)
/*      */   {
/*  554 */     ConfigFileLoader.setSource(new CatalinaBaseConfigurationSource(Bootstrap.getCatalinaBaseFile(), getConfigFile()));
/*  555 */     File file = configFile();
/*      */     
/*  557 */     if ((this.useGeneratedCode) && (!Digester.isGeneratedCodeLoaderSet()))
/*      */     {
/*  559 */       String loaderClassName = this.generatedCodePackage + ".DigesterGeneratedCodeLoader";
/*      */       try
/*      */       {
/*  562 */         Digester.GeneratedCodeLoader loader = (Digester.GeneratedCodeLoader)Catalina.class.getClassLoader().loadClass(loaderClassName).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/*  563 */         Digester.setGeneratedCodeLoader(loader);
/*      */       } catch (Exception e) {
/*  565 */         if (log.isDebugEnabled()) {
/*  566 */           log.info(sm.getString("catalina.noLoader", new Object[] { loaderClassName }), e);
/*      */         } else {
/*  568 */           log.info(sm.getString("catalina.noLoader", new Object[] { loaderClassName }));
/*      */         }
/*      */         
/*  571 */         this.useGeneratedCode = false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  576 */     File serverXmlLocation = null;
/*  577 */     String xmlClassName = null;
/*  578 */     if ((this.generateCode) || (this.useGeneratedCode)) {
/*  579 */       xmlClassName = this.generatedCodePackage + ".ServerXmlStop";
/*      */     }
/*  581 */     if (this.generateCode) {
/*  582 */       if (this.generatedCodeLocationParameter != null) {
/*  583 */         this.generatedCodeLocation = new File(this.generatedCodeLocationParameter);
/*  584 */         if (!this.generatedCodeLocation.isAbsolute()) {
/*  585 */           this.generatedCodeLocation = new File(Bootstrap.getCatalinaHomeFile(), this.generatedCodeLocationParameter);
/*      */         }
/*      */       } else {
/*  588 */         this.generatedCodeLocation = new File(Bootstrap.getCatalinaHomeFile(), "work");
/*      */       }
/*  590 */       serverXmlLocation = new File(this.generatedCodeLocation, this.generatedCodePackage);
/*  591 */       if ((!serverXmlLocation.isDirectory()) && (!serverXmlLocation.mkdirs())) {
/*  592 */         log.warn(sm.getString("catalina.generatedCodeLocationError", new Object[] { this.generatedCodeLocation.getAbsolutePath() }));
/*      */         
/*  594 */         this.generateCode = false;
/*      */       }
/*      */     }
/*      */     
/*  598 */     ServerXml serverXml = null;
/*  599 */     if (this.useGeneratedCode) {
/*  600 */       serverXml = (ServerXml)Digester.loadGeneratedClass(xmlClassName);
/*      */     }
/*      */     
/*  603 */     if (serverXml != null)
/*  604 */       serverXml.load(this); else {
/*      */       try {
/*  606 */         ConfigurationSource.Resource resource = ConfigFileLoader.getSource().getServerXml();Throwable localThrowable6 = null;
/*      */         try {
/*  608 */           Digester digester = start ? createStartDigester() : createStopDigester();
/*  609 */           InputStream inputStream = resource.getInputStream();
/*  610 */           InputSource inputSource = new InputSource(resource.getURI().toURL().toString());
/*  611 */           inputSource.setByteStream(inputStream);
/*  612 */           digester.push(this);
/*  613 */           if (this.generateCode) {
/*  614 */             digester.startGeneratingCode();
/*  615 */             generateClassHeader(digester, start);
/*      */           }
/*  617 */           digester.parse(inputSource);
/*  618 */           if (this.generateCode) {
/*  619 */             generateClassFooter(digester);
/*  620 */             FileWriter writer = new FileWriter(new File(serverXmlLocation, start ? "ServerXml.java" : "ServerXmlStop.java"));Throwable localThrowable7 = null;
/*      */             try {
/*  622 */               writer.write(digester.getGeneratedCode().toString());
/*      */             }
/*      */             catch (Throwable localThrowable1)
/*      */             {
/*  620 */               localThrowable7 = localThrowable1;throw localThrowable1;
/*      */             }
/*      */             finally {}
/*      */             
/*  624 */             digester.endGeneratingCode();
/*  625 */             Digester.addGeneratedClass(xmlClassName);
/*      */           }
/*      */         }
/*      */         catch (Throwable localThrowable4)
/*      */         {
/*  606 */           localThrowable6 = localThrowable4;throw localThrowable4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         finally
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  627 */           if (resource != null) if (localThrowable6 != null) try { resource.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else resource.close();
/*  628 */         } } catch (Exception e) { log.warn(sm.getString("catalina.configFail", new Object[] { file.getAbsolutePath() }), e);
/*  629 */         if ((file.exists()) && (!file.canRead())) {
/*  630 */           log.warn(sm.getString("catalina.incorrectPermissions"));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void stopServer() {
/*  637 */     stopServer(null);
/*      */   }
/*      */   
/*      */   public void stopServer(String[] arguments)
/*      */   {
/*  642 */     if (arguments != null) {
/*  643 */       arguments(arguments);
/*      */     }
/*      */     
/*  646 */     Server s = getServer();
/*  647 */     if (s == null) {
/*  648 */       parseServerXml(false);
/*  649 */       if (getServer() == null) {
/*  650 */         log.error(sm.getString("catalina.stopError"));
/*  651 */         System.exit(1);
/*      */       }
/*      */     }
/*      */     else {
/*      */       try {
/*  656 */         s.stop();
/*  657 */         s.destroy();
/*      */       } catch (LifecycleException e) {
/*  659 */         log.error(sm.getString("catalina.stopError"), e);
/*      */       }
/*  661 */       return;
/*      */     }
/*      */     
/*      */ 
/*  665 */     s = getServer();
/*  666 */     if (s.getPortWithOffset() > 0) {
/*  667 */       try { Socket socket = new Socket(s.getAddress(), s.getPortWithOffset());Throwable localThrowable6 = null;
/*  668 */         try { OutputStream stream = socket.getOutputStream();Throwable localThrowable7 = null;
/*  669 */           try { String shutdown = s.getShutdown();
/*  670 */             for (int i = 0; i < shutdown.length(); i++) {
/*  671 */               stream.write(shutdown.charAt(i));
/*      */             }
/*  673 */             stream.flush();
/*      */           }
/*      */           catch (Throwable localThrowable1)
/*      */           {
/*  667 */             localThrowable7 = localThrowable1;throw localThrowable1; } finally {} } catch (Throwable localThrowable4) { localThrowable6 = localThrowable4;throw localThrowable4;
/*      */ 
/*      */ 
/*      */         }
/*      */         finally
/*      */         {
/*      */ 
/*  674 */           if (socket != null) if (localThrowable6 != null) try { socket.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else socket.close();
/*  675 */         } } catch (ConnectException ce) { log.error(sm.getString("catalina.stopServer.connectException", new Object[] { s.getAddress(), 
/*  676 */           String.valueOf(s.getPortWithOffset()), String.valueOf(s.getPort()), 
/*  677 */           String.valueOf(s.getPortOffset()) }));
/*  678 */         log.error(sm.getString("catalina.stopError"), ce);
/*  679 */         System.exit(1);
/*      */       } catch (IOException e) {
/*  681 */         log.error(sm.getString("catalina.stopError"), e);
/*  682 */         System.exit(1);
/*      */       }
/*      */     } else {
/*  685 */       log.error(sm.getString("catalina.stopServer"));
/*  686 */       System.exit(1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void load()
/*      */   {
/*  696 */     if (this.loaded) {
/*  697 */       return;
/*      */     }
/*  699 */     this.loaded = true;
/*      */     
/*  701 */     long t1 = System.nanoTime();
/*      */     
/*  703 */     initDirs();
/*      */     
/*      */ 
/*  706 */     initNaming();
/*      */     
/*      */ 
/*  709 */     parseServerXml(true);
/*  710 */     Server s = getServer();
/*  711 */     if (s == null) {
/*  712 */       return;
/*      */     }
/*      */     
/*  715 */     getServer().setCatalina(this);
/*  716 */     getServer().setCatalinaHome(Bootstrap.getCatalinaHomeFile());
/*  717 */     getServer().setCatalinaBase(Bootstrap.getCatalinaBaseFile());
/*      */     
/*      */ 
/*  720 */     initStreams();
/*      */     
/*      */     try
/*      */     {
/*  724 */       getServer().init();
/*      */     } catch (LifecycleException e) {
/*  726 */       if (Boolean.getBoolean("org.apache.catalina.startup.EXIT_ON_INIT_FAILURE")) {
/*  727 */         throw new Error(e);
/*      */       }
/*  729 */       log.error(sm.getString("catalina.initError"), e);
/*      */     }
/*      */     
/*      */ 
/*  733 */     if (log.isInfoEnabled()) {
/*  734 */       log.info(sm.getString("catalina.init", new Object[] { Long.toString(TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - t1)) }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void load(String[] args)
/*      */   {
/*      */     try
/*      */     {
/*  745 */       if (arguments(args)) {
/*  746 */         load();
/*      */       }
/*      */     } catch (Exception e) {
/*  749 */       e.printStackTrace(System.out);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void start()
/*      */   {
/*  759 */     if (getServer() == null) {
/*  760 */       load();
/*      */     }
/*      */     
/*  763 */     if (getServer() == null) {
/*  764 */       log.fatal(sm.getString("catalina.noServer"));
/*  765 */       return;
/*      */     }
/*      */     
/*  768 */     long t1 = System.nanoTime();
/*      */     
/*      */     try
/*      */     {
/*  772 */       getServer().start();
/*      */     } catch (LifecycleException e) {
/*  774 */       log.fatal(sm.getString("catalina.serverStartFail"), e);
/*      */       try {
/*  776 */         getServer().destroy();
/*      */       } catch (LifecycleException e1) {
/*  778 */         log.debug("destroy() failed for failed Server ", e1);
/*      */       }
/*  780 */       return;
/*      */     }
/*      */     
/*  783 */     if (log.isInfoEnabled()) {
/*  784 */       log.info(sm.getString("catalina.startup", new Object[] { Long.toString(TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - t1)) }));
/*      */     }
/*      */     
/*  787 */     if (this.generateCode)
/*      */     {
/*  789 */       generateLoader();
/*      */     }
/*      */     
/*      */ 
/*  793 */     if (this.useShutdownHook) {
/*  794 */       if (this.shutdownHook == null) {
/*  795 */         this.shutdownHook = new CatalinaShutdownHook();
/*      */       }
/*  797 */       Runtime.getRuntime().addShutdownHook(this.shutdownHook);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  802 */       LogManager logManager = LogManager.getLogManager();
/*  803 */       if ((logManager instanceof ClassLoaderLogManager)) {
/*  804 */         ((ClassLoaderLogManager)logManager).setUseShutdownHook(false);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  809 */     if (this.await) {
/*  810 */       await();
/*  811 */       stop();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stop()
/*      */   {
/*      */     try
/*      */     {
/*  824 */       if (this.useShutdownHook) {
/*  825 */         Runtime.getRuntime().removeShutdownHook(this.shutdownHook);
/*      */         
/*      */ 
/*      */ 
/*  829 */         LogManager logManager = LogManager.getLogManager();
/*  830 */         if ((logManager instanceof ClassLoaderLogManager)) {
/*  831 */           ((ClassLoaderLogManager)logManager).setUseShutdownHook(true);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Throwable t) {
/*  836 */       ExceptionUtils.handleThrowable(t);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  843 */       Server s = getServer();
/*  844 */       LifecycleState state = s.getState();
/*  845 */       if ((LifecycleState.STOPPING_PREP.compareTo(state) > 0) || 
/*  846 */         (LifecycleState.DESTROYED.compareTo(state) < 0))
/*      */       {
/*      */ 
/*  849 */         s.stop();
/*  850 */         s.destroy();
/*      */       }
/*      */     } catch (LifecycleException e) {
/*  853 */       log.error(sm.getString("catalina.stopError"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void await()
/*      */   {
/*  864 */     getServer().await();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void usage()
/*      */   {
/*  874 */     System.out.println(sm.getString("catalina.usage"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected void initDirs() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initStreams()
/*      */   {
/*  889 */     System.setOut(new SystemLogHandler(System.out));
/*  890 */     System.setErr(new SystemLogHandler(System.err));
/*      */   }
/*      */   
/*      */ 
/*      */   protected void initNaming()
/*      */   {
/*  896 */     if (!this.useNaming) {
/*  897 */       log.info(sm.getString("catalina.noNaming"));
/*  898 */       System.setProperty("catalina.useNaming", "false");
/*      */     } else {
/*  900 */       System.setProperty("catalina.useNaming", "true");
/*  901 */       String value = "org.apache.naming";
/*      */       
/*  903 */       String oldValue = System.getProperty("java.naming.factory.url.pkgs");
/*  904 */       if (oldValue != null) {
/*  905 */         value = value + ":" + oldValue;
/*      */       }
/*  907 */       System.setProperty("java.naming.factory.url.pkgs", value);
/*  908 */       if (log.isDebugEnabled()) {
/*  909 */         log.debug("Setting naming prefix=" + value);
/*      */       }
/*      */       
/*  912 */       value = System.getProperty("java.naming.factory.initial");
/*  913 */       if (value == null)
/*      */       {
/*  915 */         System.setProperty("java.naming.factory.initial", "org.apache.naming.java.javaURLContextFactory");
/*      */       }
/*      */       else {
/*  918 */         log.debug("INITIAL_CONTEXT_FACTORY already set " + value);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setSecurityProtection()
/*      */   {
/*  928 */     SecurityConfig securityConfig = SecurityConfig.newInstance();
/*  929 */     securityConfig.setPackageDefinition();
/*  930 */     securityConfig.setPackageAccess();
/*      */   }
/*      */   
/*      */   protected void generateLoader()
/*      */   {
/*  935 */     String loaderClassName = "DigesterGeneratedCodeLoader";
/*  936 */     StringBuilder code = new StringBuilder();
/*  937 */     code.append("package ").append(this.generatedCodePackage).append(";").append(System.lineSeparator());
/*  938 */     code.append("public class ").append(loaderClassName);
/*  939 */     code.append(" implements org.apache.tomcat.util.digester.Digester.GeneratedCodeLoader {").append(System.lineSeparator());
/*  940 */     code.append("public Object loadGeneratedCode(String className) {").append(System.lineSeparator());
/*  941 */     code.append("switch (className) {").append(System.lineSeparator());
/*  942 */     for (String generatedClassName : Digester.getGeneratedClasses()) {
/*  943 */       code.append("case \"").append(generatedClassName).append("\" : return new ").append(generatedClassName);
/*  944 */       code.append("();").append(System.lineSeparator());
/*      */     }
/*  946 */     code.append("default: return null; }").append(System.lineSeparator());
/*  947 */     code.append("}}").append(System.lineSeparator());
/*  948 */     File loaderLocation = new File(this.generatedCodeLocation, this.generatedCodePackage);
/*  949 */     try { FileWriter writer = new FileWriter(new File(loaderLocation, loaderClassName + ".java"));Throwable localThrowable3 = null;
/*  950 */       try { writer.write(code.toString());
/*      */       }
/*      */       catch (Throwable localThrowable1)
/*      */       {
/*  949 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*      */       } finally {
/*  951 */         if (writer != null) if (localThrowable3 != null) try { writer.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else writer.close();
/*      */       }
/*  953 */     } catch (IOException e) { log.debug("Error writing code loader", e);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void generateClassHeader(Digester digester, boolean start)
/*      */   {
/*  959 */     StringBuilder code = digester.getGeneratedCode();
/*  960 */     code.append("package ").append(this.generatedCodePackage).append(";").append(System.lineSeparator());
/*  961 */     code.append("public class ServerXml");
/*  962 */     if (!start) {
/*  963 */       code.append("Stop");
/*      */     }
/*  965 */     code.append(" implements ");
/*  966 */     code.append(ServerXml.class.getName().replace('$', '.')).append(" {").append(System.lineSeparator());
/*  967 */     code.append("public void load(").append(Catalina.class.getName());
/*  968 */     code.append(' ').append(digester.toVariableName(this)).append(") {").append(System.lineSeparator());
/*      */   }
/*      */   
/*      */   protected void generateClassFooter(Digester digester)
/*      */   {
/*  973 */     StringBuilder code = digester.getGeneratedCode();
/*  974 */     code.append('}').append(System.lineSeparator());
/*  975 */     code.append('}').append(System.lineSeparator());
/*      */   }
/*      */   
/*      */ 
/*      */   public static abstract interface ServerXml
/*      */   {
/*      */     public abstract void load(Catalina paramCatalina);
/*      */   }
/*      */   
/*      */ 
/*      */   protected class CatalinaShutdownHook
/*      */     extends Thread
/*      */   {
/*      */     protected CatalinaShutdownHook() {}
/*      */     
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       try
/*      */       {
/*  995 */         if (Catalina.this.getServer() != null)
/*  996 */           Catalina.this.stop();
/*      */       } catch (Throwable ex) {
/*      */         LogManager logManager;
/*  999 */         ExceptionUtils.handleThrowable(ex);
/* 1000 */         Catalina.log.error(Catalina.sm.getString("catalina.shutdownHookFail"), ex);
/*      */       }
/*      */       finally {
/*      */         LogManager logManager;
/* 1004 */         LogManager logManager = LogManager.getLogManager();
/* 1005 */         if ((logManager instanceof ClassLoaderLogManager)) {
/* 1006 */           ((ClassLoaderLogManager)logManager).shutdown();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/* 1013 */   private static final Log log = LogFactory.getLog(Catalina.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final class SetParentClassLoaderRule
/*      */     extends Rule
/*      */   {
/*      */     public SetParentClassLoaderRule(ClassLoader parentClassLoader)
/*      */     {
/* 1025 */       this.parentClassLoader = parentClassLoader;
/*      */     }
/*      */     
/*      */ 
/* 1029 */     ClassLoader parentClassLoader = null;
/*      */     
/*      */ 
/*      */     public void begin(String namespace, String name, Attributes attributes)
/*      */       throws Exception
/*      */     {
/* 1035 */       if (this.digester.getLogger().isDebugEnabled()) {
/* 1036 */         this.digester.getLogger().debug("Setting parent class loader");
/*      */       }
/*      */       
/* 1039 */       Container top = (Container)this.digester.peek();
/* 1040 */       top.setParentClassLoader(this.parentClassLoader);
/*      */       
/* 1042 */       StringBuilder code = this.digester.getGeneratedCode();
/* 1043 */       if (code != null) {
/* 1044 */         code.append(this.digester.toVariableName(top)).append(".setParentClassLoader(");
/* 1045 */         code.append(this.digester.toVariableName(Catalina.this)).append(".getParentClassLoader());");
/* 1046 */         code.append(System.lineSeparator());
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\Catalina.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */