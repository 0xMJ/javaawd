/*    */ package org.apache.catalina.mbeans;
/*    */ 
/*    */ import javax.management.Attribute;
/*    */ import javax.management.AttributeNotFoundException;
/*    */ import javax.management.MBeanException;
/*    */ import javax.management.ReflectionException;
/*    */ import javax.management.RuntimeOperationsException;
/*    */ import org.apache.catalina.connector.Connector;
/*    */ import org.apache.tomcat.util.IntrospectionUtils;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectorMBean
/*    */   extends ClassNameMBean<Connector>
/*    */ {
/* 37 */   private static final StringManager sm = StringManager.getManager(ConnectorMBean.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object getAttribute(String name)
/*    */     throws AttributeNotFoundException, MBeanException, ReflectionException
/*    */   {
/* 56 */     if (name == null)
/*    */     {
/*    */ 
/* 59 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullName")), sm.getString("mBean.nullName"));
/*    */     }
/*    */     
/* 62 */     Connector connector = (Connector)doGetManagedResource();
/* 63 */     return IntrospectionUtils.getProperty(connector, name);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setAttribute(Attribute attribute)
/*    */     throws AttributeNotFoundException, MBeanException, ReflectionException
/*    */   {
/* 85 */     if (attribute == null)
/*    */     {
/* 87 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullAttribute")), sm.getString("mBean.nullAttribute"));
/*    */     }
/* 89 */     String name = attribute.getName();
/* 90 */     Object value = attribute.getValue();
/* 91 */     if (name == null)
/*    */     {
/*    */ 
/* 94 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullName")), sm.getString("mBean.nullName"));
/*    */     }
/*    */     
/* 97 */     Connector connector = (Connector)doGetManagedResource();
/* 98 */     IntrospectionUtils.setProperty(connector, name, String.valueOf(value));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\ConnectorMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */