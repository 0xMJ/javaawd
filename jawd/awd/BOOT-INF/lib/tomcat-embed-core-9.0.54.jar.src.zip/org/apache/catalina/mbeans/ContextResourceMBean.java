/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import javax.management.Attribute;
/*     */ import javax.management.AttributeNotFoundException;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import org.apache.tomcat.util.descriptor.web.ContextResource;
/*     */ import org.apache.tomcat.util.descriptor.web.NamingResources;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextResourceMBean
/*     */   extends BaseCatalinaMBean<ContextResource>
/*     */ {
/*  37 */   private static final StringManager sm = StringManager.getManager(ContextResourceMBean.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getAttribute(String name)
/*     */     throws AttributeNotFoundException, MBeanException, ReflectionException
/*     */   {
/*  56 */     if (name == null)
/*     */     {
/*     */ 
/*  59 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullName")), sm.getString("mBean.nullName"));
/*     */     }
/*     */     
/*  62 */     ContextResource cr = (ContextResource)doGetManagedResource();
/*     */     
/*  64 */     String value = null;
/*  65 */     if ("auth".equals(name))
/*  66 */       return cr.getAuth();
/*  67 */     if ("description".equals(name))
/*  68 */       return cr.getDescription();
/*  69 */     if ("name".equals(name))
/*  70 */       return cr.getName();
/*  71 */     if ("scope".equals(name))
/*  72 */       return cr.getScope();
/*  73 */     if ("type".equals(name)) {
/*  74 */       return cr.getType();
/*     */     }
/*  76 */     value = (String)cr.getProperty(name);
/*  77 */     if (value == null) {
/*  78 */       throw new AttributeNotFoundException(sm.getString("mBean.attributeNotFound", new Object[] { name }));
/*     */     }
/*     */     
/*     */ 
/*  82 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttribute(Attribute attribute)
/*     */     throws AttributeNotFoundException, MBeanException, ReflectionException
/*     */   {
/* 104 */     if (attribute == null)
/*     */     {
/*     */ 
/* 107 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullAttribute")), sm.getString("mBean.nullAttribute"));
/*     */     }
/* 109 */     String name = attribute.getName();
/* 110 */     Object value = attribute.getValue();
/* 111 */     if (name == null)
/*     */     {
/*     */ 
/* 114 */       throw new RuntimeOperationsException(new IllegalArgumentException(sm.getString("mBean.nullName")), sm.getString("mBean.nullName"));
/*     */     }
/*     */     
/* 117 */     ContextResource cr = (ContextResource)doGetManagedResource();
/*     */     
/* 119 */     if ("auth".equals(name)) {
/* 120 */       cr.setAuth((String)value);
/* 121 */     } else if ("description".equals(name)) {
/* 122 */       cr.setDescription((String)value);
/* 123 */     } else if ("name".equals(name)) {
/* 124 */       cr.setName((String)value);
/* 125 */     } else if ("scope".equals(name)) {
/* 126 */       cr.setScope((String)value);
/* 127 */     } else if ("type".equals(name)) {
/* 128 */       cr.setType((String)value);
/*     */     } else {
/* 130 */       cr.setProperty(name, "" + value);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 135 */     NamingResources nr = cr.getNamingResources();
/* 136 */     nr.removeResource(cr.getName());
/* 137 */     nr.addResource(cr);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\ContextResourceMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */