/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.tomcat.util.IntrospectionUtils;
/*     */ import org.apache.tomcat.util.digester.Digester;
/*     */ import org.apache.tomcat.util.digester.Rule;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LifecycleListenerRule
/*     */   extends Rule
/*     */ {
/*     */   private final String attributeName;
/*     */   private final String listenerClass;
/*     */   
/*     */   public LifecycleListenerRule(String listenerClass, String attributeName)
/*     */   {
/*  57 */     this.listenerClass = listenerClass;
/*  58 */     this.attributeName = attributeName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void begin(String namespace, String name, Attributes attributes)
/*     */     throws Exception
/*     */   {
/*  93 */     Container c = (Container)this.digester.peek();
/*  94 */     Container p = null;
/*  95 */     Object obj = this.digester.peek(1);
/*  96 */     if ((obj instanceof Container)) {
/*  97 */       p = (Container)obj;
/*     */     }
/*     */     
/* 100 */     String className = null;
/*     */     
/*     */ 
/* 103 */     if (this.attributeName != null) {
/* 104 */       String value = attributes.getValue(this.attributeName);
/* 105 */       if (value != null) {
/* 106 */         className = value;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 111 */     if ((p != null) && (className == null))
/*     */     {
/* 113 */       String configClass = (String)IntrospectionUtils.getProperty(p, this.attributeName);
/* 114 */       if ((configClass != null) && (configClass.length() > 0)) {
/* 115 */         className = configClass;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 120 */     if (className == null) {
/* 121 */       className = this.listenerClass;
/*     */     }
/*     */     
/*     */ 
/* 125 */     Class<?> clazz = Class.forName(className);
/* 126 */     LifecycleListener listener = (LifecycleListener)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */     
/*     */ 
/* 129 */     c.addLifecycleListener(listener);
/*     */     
/* 131 */     StringBuilder code = this.digester.getGeneratedCode();
/* 132 */     if (code != null) {
/* 133 */       code.append(this.digester.toVariableName(c)).append(".addLifecycleListener(");
/* 134 */       code.append("new ").append(className).append("());").append(System.lineSeparator());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\LifecycleListenerRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */