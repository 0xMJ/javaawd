/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Engine;
/*     */ import org.apache.catalina.Executor;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Server;
/*     */ import org.apache.catalina.Service;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.mapper.Mapper;
/*     */ import org.apache.catalina.mapper.MapperListener;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.coyote.ProtocolHandler;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardService
/*     */   extends LifecycleMBeanBase
/*     */   implements Service
/*     */ {
/*  53 */   private static final Log log = LogFactory.getLog(StandardService.class);
/*  54 */   private static final StringManager sm = StringManager.getManager(StandardService.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */   private String name = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */   private Server server = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  73 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   protected Connector[] connectors = new Connector[0];
/*  80 */   private final Object connectorsLock = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  85 */   protected final ArrayList<Executor> executors = new ArrayList();
/*     */   
/*  87 */   private Engine engine = null;
/*     */   
/*  89 */   private ClassLoader parentClassLoader = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  94 */   protected final Mapper mapper = new Mapper();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */   protected final MapperListener mapperListener = new MapperListener(this);
/*     */   
/*     */ 
/* 103 */   private long gracefulStopAwaitMillis = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */   public long getGracefulStopAwaitMillis()
/*     */   {
/* 109 */     return this.gracefulStopAwaitMillis;
/*     */   }
/*     */   
/*     */   public void setGracefulStopAwaitMillis(long gracefulStopAwaitMillis)
/*     */   {
/* 114 */     this.gracefulStopAwaitMillis = gracefulStopAwaitMillis;
/*     */   }
/*     */   
/*     */ 
/*     */   public Mapper getMapper()
/*     */   {
/* 120 */     return this.mapper;
/*     */   }
/*     */   
/*     */ 
/*     */   public Engine getContainer()
/*     */   {
/* 126 */     return this.engine;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setContainer(Engine engine)
/*     */   {
/* 132 */     Engine oldEngine = this.engine;
/* 133 */     if (oldEngine != null) {
/* 134 */       oldEngine.setService(null);
/*     */     }
/* 136 */     this.engine = engine;
/* 137 */     if (this.engine != null) {
/* 138 */       this.engine.setService(this);
/*     */     }
/* 140 */     if (getState().isAvailable()) {
/* 141 */       if (this.engine != null) {
/*     */         try {
/* 143 */           this.engine.start();
/*     */         } catch (LifecycleException e) {
/* 145 */           log.error(sm.getString("standardService.engine.startFailed"), e);
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 150 */         this.mapperListener.stop();
/*     */       } catch (LifecycleException e) {
/* 152 */         log.error(sm.getString("standardService.mapperListener.stopFailed"), e);
/*     */       }
/*     */       try {
/* 155 */         this.mapperListener.start();
/*     */       } catch (LifecycleException e) {
/* 157 */         log.error(sm.getString("standardService.mapperListener.startFailed"), e);
/*     */       }
/* 159 */       if (oldEngine != null) {
/*     */         try {
/* 161 */           oldEngine.stop();
/*     */         } catch (LifecycleException e) {
/* 163 */           log.error(sm.getString("standardService.engine.stopFailed"), e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 169 */     this.support.firePropertyChange("container", oldEngine, this.engine);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 178 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 189 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Server getServer()
/*     */   {
/* 198 */     return this.server;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServer(Server server)
/*     */   {
/* 209 */     this.server = server;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addConnector(Connector connector)
/*     */   {
/* 224 */     synchronized (this.connectorsLock) {
/* 225 */       connector.setService(this);
/* 226 */       Connector[] results = new Connector[this.connectors.length + 1];
/* 227 */       System.arraycopy(this.connectors, 0, results, 0, this.connectors.length);
/* 228 */       results[this.connectors.length] = connector;
/* 229 */       this.connectors = results;
/*     */     }
/*     */     try
/*     */     {
/* 233 */       if (getState().isAvailable()) {
/* 234 */         connector.start();
/*     */       }
/*     */     }
/*     */     catch (LifecycleException e) {
/* 238 */       throw new IllegalArgumentException(sm.getString("standardService.connector.startFailed", new Object[] { connector }), e);
/*     */     }
/*     */     
/*     */ 
/* 242 */     this.support.firePropertyChange("connector", null, connector);
/*     */   }
/*     */   
/*     */   public ObjectName[] getConnectorNames()
/*     */   {
/* 247 */     ObjectName[] results = new ObjectName[this.connectors.length];
/* 248 */     for (int i = 0; i < results.length; i++) {
/* 249 */       results[i] = this.connectors[i].getObjectName();
/*     */     }
/* 251 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/* 261 */     this.support.addPropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connector[] findConnectors()
/*     */   {
/* 270 */     return this.connectors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeConnector(Connector connector)
/*     */   {
/* 284 */     synchronized (this.connectorsLock) {
/* 285 */       int j = -1;
/* 286 */       for (int i = 0; i < this.connectors.length; i++) {
/* 287 */         if (connector == this.connectors[i]) {
/* 288 */           j = i;
/* 289 */           break;
/*     */         }
/*     */       }
/* 292 */       if (j < 0) {
/* 293 */         return;
/*     */       }
/* 295 */       if (this.connectors[j].getState().isAvailable()) {
/*     */         try {
/* 297 */           this.connectors[j].stop();
/*     */         } catch (LifecycleException e) {
/* 299 */           log.error(sm.getString("standardService.connector.stopFailed", new Object[] { this.connectors[j] }), e);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 304 */       connector.setService(null);
/* 305 */       int k = 0;
/* 306 */       Connector[] results = new Connector[this.connectors.length - 1];
/* 307 */       for (int i = 0; i < this.connectors.length; i++) {
/* 308 */         if (i != j) {
/* 309 */           results[(k++)] = this.connectors[i];
/*     */         }
/*     */       }
/* 312 */       this.connectors = results;
/*     */       
/*     */ 
/* 315 */       this.support.firePropertyChange("connector", connector, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/* 326 */     this.support.removePropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 335 */     StringBuilder sb = new StringBuilder("StandardService[");
/* 336 */     sb.append(getName());
/* 337 */     sb.append(']');
/* 338 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addExecutor(Executor ex)
/*     */   {
/* 348 */     synchronized (this.executors) {
/* 349 */       if (!this.executors.contains(ex)) {
/* 350 */         this.executors.add(ex);
/* 351 */         if (getState().isAvailable()) {
/*     */           try {
/* 353 */             ex.start();
/*     */           } catch (LifecycleException x) {
/* 355 */             log.error(sm.getString("standardService.executor.start"), x);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Executor[] findExecutors()
/*     */   {
/* 369 */     synchronized (this.executors) {
/* 370 */       Executor[] arr = new Executor[this.executors.size()];
/* 371 */       this.executors.toArray(arr);
/* 372 */       return arr;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Executor getExecutor(String executorName)
/*     */   {
/* 384 */     synchronized (this.executors) {
/* 385 */       for (Executor executor : this.executors) {
/* 386 */         if (executorName.equals(executor.getName())) {
/* 387 */           return executor;
/*     */         }
/*     */       }
/*     */     }
/* 391 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeExecutor(Executor ex)
/*     */   {
/* 401 */     synchronized (this.executors) {
/* 402 */       if ((this.executors.remove(ex)) && (getState().isAvailable())) {
/*     */         try {
/* 404 */           ex.stop();
/*     */         } catch (LifecycleException e) {
/* 406 */           log.error(sm.getString("standardService.executor.stop"), e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 424 */     if (log.isInfoEnabled()) {
/* 425 */       log.info(sm.getString("standardService.start.name", new Object[] { this.name }));
/*     */     }
/* 427 */     setState(LifecycleState.STARTING);
/*     */     
/*     */ 
/* 430 */     if (this.engine != null)
/* 431 */       synchronized (this.engine) {
/* 432 */         this.engine.start();
/*     */       }
/*     */     Object localObject2;
/*     */     Executor executor;
/* 436 */     synchronized (this.executors) {
/* 437 */       for (localObject2 = this.executors.iterator(); ((Iterator)localObject2).hasNext();) { executor = (Executor)((Iterator)localObject2).next();
/* 438 */         executor.start();
/*     */       }
/*     */     }
/*     */     
/* 442 */     this.mapperListener.start();
/*     */     
/*     */ 
/* 445 */     synchronized (this.connectorsLock) {
/* 446 */       localObject2 = this.connectors;executor = localObject2.length; for (Executor localExecutor1 = 0; localExecutor1 < executor; localExecutor1++) { Connector connector = localObject2[localExecutor1];
/*     */         
/* 448 */         if (connector.getState() != LifecycleState.FAILED) {
/* 449 */           connector.start();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/*     */     long waitMillis;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 467 */     synchronized (this.connectorsLock)
/*     */     {
/*     */ 
/*     */ 
/* 471 */       for (connector : this.connectors) {
/* 472 */         connector.getProtocolHandler().closeServerSocketGraceful();
/*     */       }
/*     */       
/*     */ 
/* 476 */       waitMillis = this.gracefulStopAwaitMillis;
/* 477 */       if (waitMillis > 0L) {
/* 478 */         arrayOfConnector2 = this.connectors;connector = arrayOfConnector2.length; for (Connector localConnector1 = 0; localConnector1 < connector; localConnector1++) { Connector connector = arrayOfConnector2[localConnector1];
/* 479 */           waitMillis = connector.getProtocolHandler().awaitConnectionsClose(waitMillis);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 484 */       Connector[] arrayOfConnector2 = this.connectors;Connector connector = arrayOfConnector2.length; for (Connector localConnector2 = 0; localConnector2 < connector; localConnector2++) { Connector connector = arrayOfConnector2[localConnector2];
/* 485 */         connector.pause();
/*     */       }
/*     */     }
/*     */     
/* 489 */     if (log.isInfoEnabled()) {
/* 490 */       log.info(sm.getString("standardService.stop.name", new Object[] { this.name }));
/*     */     }
/* 492 */     setState(LifecycleState.STOPPING);
/*     */     
/*     */ 
/* 495 */     if (this.engine != null) {
/* 496 */       synchronized (this.engine) {
/* 497 */         this.engine.stop();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 502 */     synchronized (this.connectorsLock) {
/* 503 */       for (Connector connector : this.connectors) {
/* 504 */         if (LifecycleState.STARTED.equals(connector
/* 505 */           .getState()))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 511 */           connector.stop();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 517 */     if (this.mapperListener.getState() != LifecycleState.INITIALIZED) {
/* 518 */       this.mapperListener.stop();
/*     */     }
/*     */     
/* 521 */     synchronized (this.executors) {
/* 522 */       for (waitMillis = this.executors.iterator(); ((Iterator)waitMillis).hasNext();) { Executor executor = (Executor)((Iterator)waitMillis).next();
/* 523 */         executor.stop();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInternal()
/*     */     throws LifecycleException
/*     */   {
/* 536 */     super.initInternal();
/*     */     
/* 538 */     if (this.engine != null) {
/* 539 */       this.engine.init();
/*     */     }
/*     */     
/*     */ 
/* 543 */     Executor[] arrayOfExecutor = findExecutors();int i = arrayOfExecutor.length; Executor executor; for (Executor localExecutor1 = 0; localExecutor1 < i; localExecutor1++) { executor = arrayOfExecutor[localExecutor1];
/* 544 */       if ((executor instanceof JmxEnabled)) {
/* 545 */         ((JmxEnabled)executor).setDomain(getDomain());
/*     */       }
/* 547 */       executor.init();
/*     */     }
/*     */     
/*     */ 
/* 551 */     this.mapperListener.init();
/*     */     
/*     */ 
/* 554 */     synchronized (this.connectorsLock) {
/* 555 */       Connector[] arrayOfConnector = this.connectors;localExecutor1 = arrayOfConnector.length; for (executor = 0; executor < localExecutor1; executor++) { Connector connector = arrayOfConnector[executor];
/* 556 */         connector.init();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void destroyInternal()
/*     */     throws LifecycleException
/*     */   {
/* 564 */     this.mapperListener.destroy();
/*     */     
/*     */ 
/* 567 */     synchronized (this.connectorsLock) {
/* 568 */       for (Connector connector : this.connectors) {
/* 569 */         connector.destroy();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 574 */     for (Executor executor : findExecutors()) {
/* 575 */       executor.destroy();
/*     */     }
/*     */     
/* 578 */     if (this.engine != null) {
/* 579 */       this.engine.destroy();
/*     */     }
/*     */     
/* 582 */     super.destroyInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassLoader getParentClassLoader()
/*     */   {
/* 591 */     if (this.parentClassLoader != null) {
/* 592 */       return this.parentClassLoader;
/*     */     }
/* 594 */     if (this.server != null) {
/* 595 */       return this.server.getParentClassLoader();
/*     */     }
/* 597 */     return ClassLoader.getSystemClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParentClassLoader(ClassLoader parent)
/*     */   {
/* 608 */     ClassLoader oldParentClassLoader = this.parentClassLoader;
/* 609 */     this.parentClassLoader = parent;
/* 610 */     this.support.firePropertyChange("parentClassLoader", oldParentClassLoader, this.parentClassLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getDomainInternal()
/*     */   {
/* 617 */     String domain = null;
/* 618 */     Container engine = getContainer();
/*     */     
/*     */ 
/* 621 */     if (engine != null) {
/* 622 */       domain = engine.getName();
/*     */     }
/*     */     
/*     */ 
/* 626 */     if (domain == null) {
/* 627 */       domain = getName();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 632 */     return domain;
/*     */   }
/*     */   
/*     */ 
/*     */   public final String getObjectNameKeyProperties()
/*     */   {
/* 638 */     return "type=Service";
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\StandardService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */