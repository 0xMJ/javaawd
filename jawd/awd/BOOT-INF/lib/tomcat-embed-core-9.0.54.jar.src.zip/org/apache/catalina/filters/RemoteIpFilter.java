/*      */ package org.apache.catalina.filters;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.net.InetAddress;
/*      */ import java.net.UnknownHostException;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.servlet.FilterChain;
/*      */ import javax.servlet.GenericFilter;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletRequestWrapper;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletRequestWrapper;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.PushBuilder;
/*      */ import org.apache.catalina.connector.RequestFacade;
/*      */ import org.apache.catalina.util.RequestUtil;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.http.FastHttpDateFormat;
/*      */ import org.apache.tomcat.util.http.parser.Host;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RemoteIpFilter
/*      */   extends GenericFilter
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   
/*      */   public static class XForwardedRequest
/*      */     extends HttpServletRequestWrapper
/*      */   {
/*      */     protected final Map<String, List<String>> headers;
/*      */     protected String localName;
/*      */     protected int localPort;
/*      */     protected String remoteAddr;
/*      */     protected String remoteHost;
/*      */     protected String scheme;
/*      */     protected boolean secure;
/*      */     protected String serverName;
/*      */     protected int serverPort;
/*      */     
/*      */     public XForwardedRequest(HttpServletRequest request)
/*      */     {
/*  478 */       super();
/*  479 */       this.localName = request.getLocalName();
/*  480 */       this.localPort = request.getLocalPort();
/*  481 */       this.remoteAddr = request.getRemoteAddr();
/*  482 */       this.remoteHost = request.getRemoteHost();
/*  483 */       this.scheme = request.getScheme();
/*  484 */       this.secure = request.isSecure();
/*  485 */       this.serverName = request.getServerName();
/*  486 */       this.serverPort = request.getServerPort();
/*      */       
/*  488 */       this.headers = new HashMap();
/*  489 */       for (Enumeration<String> headerNames = request.getHeaderNames(); headerNames.hasMoreElements();) {
/*  490 */         String header = (String)headerNames.nextElement();
/*  491 */         this.headers.put(header, Collections.list(request.getHeaders(header)));
/*      */       }
/*      */     }
/*      */     
/*      */     public long getDateHeader(String name)
/*      */     {
/*  497 */       String value = getHeader(name);
/*  498 */       if (value == null) {
/*  499 */         return -1L;
/*      */       }
/*  501 */       long date = FastHttpDateFormat.parseDate(value);
/*  502 */       if (date == -1L) {
/*  503 */         throw new IllegalArgumentException(value);
/*      */       }
/*  505 */       return date;
/*      */     }
/*      */     
/*      */     public String getHeader(String name)
/*      */     {
/*  510 */       Map.Entry<String, List<String>> header = getHeaderEntry(name);
/*  511 */       if ((header == null) || (header.getValue() == null) || (((List)header.getValue()).isEmpty())) {
/*  512 */         return null;
/*      */       }
/*  514 */       return (String)((List)header.getValue()).get(0);
/*      */     }
/*      */     
/*      */     protected Map.Entry<String, List<String>> getHeaderEntry(String name) {
/*  518 */       for (Map.Entry<String, List<String>> entry : this.headers.entrySet()) {
/*  519 */         if (((String)entry.getKey()).equalsIgnoreCase(name)) {
/*  520 */           return entry;
/*      */         }
/*      */       }
/*  523 */       return null;
/*      */     }
/*      */     
/*      */     public Enumeration<String> getHeaderNames()
/*      */     {
/*  528 */       return Collections.enumeration(this.headers.keySet());
/*      */     }
/*      */     
/*      */     public Enumeration<String> getHeaders(String name)
/*      */     {
/*  533 */       Map.Entry<String, List<String>> header = getHeaderEntry(name);
/*  534 */       if ((header == null) || (header.getValue() == null)) {
/*  535 */         return Collections.enumeration(Collections.emptyList());
/*      */       }
/*  537 */       return Collections.enumeration((Collection)header.getValue());
/*      */     }
/*      */     
/*      */     public int getIntHeader(String name)
/*      */     {
/*  542 */       String value = getHeader(name);
/*  543 */       if (value == null) {
/*  544 */         return -1;
/*      */       }
/*  546 */       return Integer.parseInt(value);
/*      */     }
/*      */     
/*      */     public String getLocalName()
/*      */     {
/*  551 */       return this.localName;
/*      */     }
/*      */     
/*      */     public int getLocalPort()
/*      */     {
/*  556 */       return this.localPort;
/*      */     }
/*      */     
/*      */     public String getRemoteAddr()
/*      */     {
/*  561 */       return this.remoteAddr;
/*      */     }
/*      */     
/*      */     public String getRemoteHost()
/*      */     {
/*  566 */       return this.remoteHost;
/*      */     }
/*      */     
/*      */     public String getScheme()
/*      */     {
/*  571 */       return this.scheme;
/*      */     }
/*      */     
/*      */     public String getServerName()
/*      */     {
/*  576 */       return this.serverName;
/*      */     }
/*      */     
/*      */     public int getServerPort()
/*      */     {
/*  581 */       return this.serverPort;
/*      */     }
/*      */     
/*      */     public boolean isSecure()
/*      */     {
/*  586 */       return this.secure;
/*      */     }
/*      */     
/*      */     public void removeHeader(String name) {
/*  590 */       Map.Entry<String, List<String>> header = getHeaderEntry(name);
/*  591 */       if (header != null) {
/*  592 */         this.headers.remove(header.getKey());
/*      */       }
/*      */     }
/*      */     
/*      */     public void setHeader(String name, String value) {
/*  597 */       List<String> values = Collections.singletonList(value);
/*  598 */       Map.Entry<String, List<String>> header = getHeaderEntry(name);
/*  599 */       if (header == null) {
/*  600 */         this.headers.put(name, values);
/*      */       } else {
/*  602 */         header.setValue(values);
/*      */       }
/*      */     }
/*      */     
/*      */     public void setLocalName(String localName)
/*      */     {
/*  608 */       this.localName = localName;
/*      */     }
/*      */     
/*      */     public void setLocalPort(int localPort) {
/*  612 */       this.localPort = localPort;
/*      */     }
/*      */     
/*      */     public void setRemoteAddr(String remoteAddr) {
/*  616 */       this.remoteAddr = remoteAddr;
/*      */     }
/*      */     
/*      */     public void setRemoteHost(String remoteHost) {
/*  620 */       this.remoteHost = remoteHost;
/*      */     }
/*      */     
/*      */     public void setScheme(String scheme) {
/*  624 */       this.scheme = scheme;
/*      */     }
/*      */     
/*      */     public void setSecure(boolean secure) {
/*  628 */       this.secure = secure;
/*      */     }
/*      */     
/*      */     public void setServerName(String serverName) {
/*  632 */       this.serverName = serverName;
/*      */     }
/*      */     
/*      */     public void setServerPort(int serverPort) {
/*  636 */       this.serverPort = serverPort;
/*      */     }
/*      */     
/*      */     public StringBuffer getRequestURL()
/*      */     {
/*  641 */       return RequestUtil.getRequestURL(this);
/*      */     }
/*      */     
/*      */     public PushBuilder newPushBuilder()
/*      */     {
/*  646 */       ServletRequest current = getRequest();
/*  647 */       while ((current instanceof ServletRequestWrapper)) {
/*  648 */         current = ((ServletRequestWrapper)current).getRequest();
/*      */       }
/*  650 */       if ((current instanceof RequestFacade)) {
/*  651 */         return ((RequestFacade)current).newPushBuilder(this);
/*      */       }
/*  653 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  662 */   private static final Pattern commaSeparatedValuesPattern = Pattern.compile("\\s*,\\s*");
/*      */   
/*      */ 
/*      */   protected static final String HTTP_SERVER_PORT_PARAMETER = "httpServerPort";
/*      */   
/*      */ 
/*      */   protected static final String HTTPS_SERVER_PORT_PARAMETER = "httpsServerPort";
/*      */   
/*      */   protected static final String INTERNAL_PROXIES_PARAMETER = "internalProxies";
/*      */   
/*  672 */   private transient Log log = LogFactory.getLog(RemoteIpFilter.class);
/*  673 */   protected static final StringManager sm = StringManager.getManager(RemoteIpFilter.class);
/*      */   
/*      */ 
/*      */   protected static final String PROTOCOL_HEADER_PARAMETER = "protocolHeader";
/*      */   
/*      */ 
/*      */   protected static final String PROTOCOL_HEADER_HTTPS_VALUE_PARAMETER = "protocolHeaderHttpsValue";
/*      */   
/*      */ 
/*      */   protected static final String HOST_HEADER_PARAMETER = "hostHeader";
/*      */   
/*      */ 
/*      */   protected static final String PORT_HEADER_PARAMETER = "portHeader";
/*      */   
/*      */   protected static final String CHANGE_LOCAL_NAME_PARAMETER = "changeLocalName";
/*      */   
/*      */   protected static final String CHANGE_LOCAL_PORT_PARAMETER = "changeLocalPort";
/*      */   
/*      */   protected static final String PROXIES_HEADER_PARAMETER = "proxiesHeader";
/*      */   
/*      */   protected static final String REMOTE_IP_HEADER_PARAMETER = "remoteIpHeader";
/*      */   
/*      */   protected static final String TRUSTED_PROXIES_PARAMETER = "trustedProxies";
/*      */   
/*      */   protected static final String ENABLE_LOOKUPS_PARAMETER = "enableLookups";
/*      */   
/*      */ 
/*      */   protected static String[] commaDelimitedListToStringArray(String commaDelimitedStrings)
/*      */   {
/*  702 */     return (commaDelimitedStrings == null) || (commaDelimitedStrings.length() == 0) ? new String[0] : commaSeparatedValuesPattern
/*  703 */       .split(commaDelimitedStrings);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String listToCommaDelimitedString(List<String> stringList)
/*      */   {
/*  713 */     if (stringList == null) {
/*  714 */       return "";
/*      */     }
/*  716 */     StringBuilder result = new StringBuilder();
/*  717 */     for (Iterator<String> it = stringList.iterator(); it.hasNext();) {
/*  718 */       Object element = it.next();
/*  719 */       if (element != null) {
/*  720 */         result.append(element);
/*  721 */         if (it.hasNext()) {
/*  722 */           result.append(", ");
/*      */         }
/*      */       }
/*      */     }
/*  726 */     return result.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  732 */   private int httpServerPort = 80;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  737 */   private int httpsServerPort = 443;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  742 */   private Pattern internalProxies = Pattern.compile("10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|192\\.168\\.\\d{1,3}\\.\\d{1,3}|169\\.254\\.\\d{1,3}\\.\\d{1,3}|127\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|172\\.1[6-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.2[0-9]{1}\\.\\d{1,3}\\.\\d{1,3}|172\\.3[0-1]{1}\\.\\d{1,3}\\.\\d{1,3}|0:0:0:0:0:0:0:1|::1");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  755 */   private String protocolHeader = "X-Forwarded-Proto";
/*      */   
/*  757 */   private String protocolHeaderHttpsValue = "https";
/*      */   
/*  759 */   private String hostHeader = null;
/*      */   
/*  761 */   private boolean changeLocalName = false;
/*      */   
/*  763 */   private String portHeader = null;
/*      */   
/*  765 */   private boolean changeLocalPort = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  770 */   private String proxiesHeader = "X-Forwarded-By";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  775 */   private String remoteIpHeader = "X-Forwarded-For";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  780 */   private boolean requestAttributesEnabled = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  785 */   private Pattern trustedProxies = null;
/*      */   
/*      */   private boolean enableLookups;
/*      */   
/*      */   public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
/*      */     throws IOException, ServletException
/*      */   {
/*  792 */     boolean isInternal = (this.internalProxies != null) && (this.internalProxies.matcher(request.getRemoteAddr()).matches());
/*      */     
/*  794 */     if ((isInternal) || ((this.trustedProxies != null) && 
/*  795 */       (this.trustedProxies.matcher(request.getRemoteAddr()).matches()))) {
/*  796 */       String remoteIp = null;
/*  797 */       LinkedList<String> proxiesHeaderValue = new LinkedList();
/*  798 */       StringBuilder concatRemoteIpHeaderValue = new StringBuilder();
/*      */       
/*  800 */       for (Enumeration<String> e = request.getHeaders(this.remoteIpHeader); e.hasMoreElements();) {
/*  801 */         if (concatRemoteIpHeaderValue.length() > 0) {
/*  802 */           concatRemoteIpHeaderValue.append(", ");
/*      */         }
/*      */         
/*  805 */         concatRemoteIpHeaderValue.append((String)e.nextElement());
/*      */       }
/*      */       
/*  808 */       String[] remoteIpHeaderValue = commaDelimitedListToStringArray(concatRemoteIpHeaderValue.toString());
/*      */       
/*  810 */       if (!isInternal) {
/*  811 */         proxiesHeaderValue.addFirst(request.getRemoteAddr());
/*      */       }
/*      */       
/*  814 */       for (int idx = remoteIpHeaderValue.length - 1; idx >= 0; idx--) {
/*  815 */         String currentRemoteIp = remoteIpHeaderValue[idx];
/*  816 */         remoteIp = currentRemoteIp;
/*  817 */         if ((this.internalProxies == null) || (!this.internalProxies.matcher(currentRemoteIp).matches()))
/*      */         {
/*  819 */           if ((this.trustedProxies != null) && 
/*  820 */             (this.trustedProxies.matcher(currentRemoteIp).matches())) {
/*  821 */             proxiesHeaderValue.addFirst(currentRemoteIp);
/*      */           } else {
/*  823 */             idx--;
/*  824 */             break;
/*      */           }
/*      */         }
/*      */       }
/*  828 */       LinkedList<String> newRemoteIpHeaderValue = new LinkedList();
/*  829 */       for (; idx >= 0; idx--) {
/*  830 */         String currentRemoteIp = remoteIpHeaderValue[idx];
/*  831 */         newRemoteIpHeaderValue.addFirst(currentRemoteIp);
/*      */       }
/*      */       
/*  834 */       XForwardedRequest xRequest = new XForwardedRequest(request);
/*  835 */       if (remoteIp != null)
/*      */       {
/*  837 */         xRequest.setRemoteAddr(remoteIp);
/*  838 */         if (getEnableLookups())
/*      */         {
/*      */ 
/*      */           try
/*      */           {
/*      */ 
/*  844 */             InetAddress inetAddress = InetAddress.getByName(remoteIp);
/*      */             
/*  846 */             xRequest.setRemoteHost(inetAddress.getCanonicalHostName());
/*      */           } catch (UnknownHostException e) {
/*  848 */             this.log.debug(sm.getString("remoteIpFilter.invalidRemoteAddress", new Object[] { remoteIp }), e);
/*  849 */             xRequest.setRemoteHost(remoteIp);
/*      */           }
/*      */         } else {
/*  852 */           xRequest.setRemoteHost(remoteIp);
/*      */         }
/*      */         
/*  855 */         if (proxiesHeaderValue.size() == 0) {
/*  856 */           xRequest.removeHeader(this.proxiesHeader);
/*      */         } else {
/*  858 */           String commaDelimitedListOfProxies = listToCommaDelimitedString(proxiesHeaderValue);
/*  859 */           xRequest.setHeader(this.proxiesHeader, commaDelimitedListOfProxies);
/*      */         }
/*  861 */         if (newRemoteIpHeaderValue.size() == 0) {
/*  862 */           xRequest.removeHeader(this.remoteIpHeader);
/*      */         } else {
/*  864 */           String commaDelimitedRemoteIpHeaderValue = listToCommaDelimitedString(newRemoteIpHeaderValue);
/*  865 */           xRequest.setHeader(this.remoteIpHeader, commaDelimitedRemoteIpHeaderValue);
/*      */         }
/*      */       }
/*      */       
/*  869 */       if (this.protocolHeader != null) {
/*  870 */         String protocolHeaderValue = request.getHeader(this.protocolHeader);
/*  871 */         if (protocolHeaderValue != null)
/*      */         {
/*      */ 
/*  874 */           if (isForwardedProtoHeaderValueSecure(protocolHeaderValue)) {
/*  875 */             xRequest.setSecure(true);
/*  876 */             xRequest.setScheme("https");
/*  877 */             setPorts(xRequest, this.httpsServerPort);
/*      */           } else {
/*  879 */             xRequest.setSecure(false);
/*  880 */             xRequest.setScheme("http");
/*  881 */             setPorts(xRequest, this.httpServerPort);
/*      */           }
/*      */         }
/*      */       }
/*  885 */       if (this.hostHeader != null) {
/*  886 */         String hostHeaderValue = request.getHeader(this.hostHeader);
/*  887 */         if (hostHeaderValue != null) {
/*      */           try {
/*  889 */             int portIndex = Host.parse(hostHeaderValue);
/*  890 */             if (portIndex > -1) {
/*  891 */               this.log.debug(sm.getString("remoteIpFilter.invalidHostWithPort", new Object[] { hostHeaderValue, this.hostHeader }));
/*  892 */               hostHeaderValue = hostHeaderValue.substring(0, portIndex);
/*      */             }
/*      */             
/*  895 */             xRequest.setServerName(hostHeaderValue);
/*  896 */             if (isChangeLocalName()) {
/*  897 */               xRequest.setLocalName(hostHeaderValue);
/*      */             }
/*      */           }
/*      */           catch (IllegalArgumentException iae) {
/*  901 */             this.log.debug(sm.getString("remoteIpFilter.invalidHostHeader", new Object[] { hostHeaderValue, this.hostHeader }));
/*      */           }
/*      */         }
/*      */       }
/*  905 */       request.setAttribute("org.apache.tomcat.request.forwarded", Boolean.TRUE);
/*      */       
/*  907 */       if (this.log.isDebugEnabled()) {
/*  908 */         this.log.debug("Incoming request " + request.getRequestURI() + " with originalRemoteAddr [" + request.getRemoteAddr() + "], originalRemoteHost=[" + request
/*  909 */           .getRemoteHost() + "], originalSecure=[" + request.isSecure() + "], originalScheme=[" + request
/*  910 */           .getScheme() + "], originalServerName=[" + request.getServerName() + "], originalServerPort=[" + request
/*  911 */           .getServerPort() + "] will be seen as newRemoteAddr=[" + xRequest
/*  912 */           .getRemoteAddr() + "], newRemoteHost=[" + xRequest
/*  913 */           .getRemoteHost() + "], newSecure=[" + xRequest.isSecure() + "], newScheme=[" + xRequest
/*  914 */           .getScheme() + "], newServerName=[" + xRequest.getServerName() + "], newServerPort=[" + xRequest
/*  915 */           .getServerPort() + "]");
/*      */       }
/*  917 */       if (this.requestAttributesEnabled) {
/*  918 */         request.setAttribute("org.apache.catalina.AccessLog.RemoteAddr", xRequest
/*  919 */           .getRemoteAddr());
/*  920 */         request.setAttribute("org.apache.tomcat.remoteAddr", xRequest
/*  921 */           .getRemoteAddr());
/*  922 */         request.setAttribute("org.apache.catalina.AccessLog.RemoteHost", xRequest
/*  923 */           .getRemoteHost());
/*  924 */         request.setAttribute("org.apache.catalina.AccessLog.Protocol", xRequest
/*  925 */           .getProtocol());
/*  926 */         request.setAttribute("org.apache.catalina.AccessLog.ServerName", xRequest
/*  927 */           .getServerName());
/*  928 */         request.setAttribute("org.apache.catalina.AccessLog.ServerPort", 
/*  929 */           Integer.valueOf(xRequest.getServerPort()));
/*      */       }
/*  931 */       chain.doFilter(xRequest, response);
/*      */     } else {
/*  933 */       if (this.log.isDebugEnabled()) {
/*  934 */         this.log.debug("Skip RemoteIpFilter for request " + request.getRequestURI() + " with originalRemoteAddr '" + request
/*  935 */           .getRemoteAddr() + "'");
/*      */       }
/*  937 */       chain.doFilter(request, response);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isForwardedProtoHeaderValueSecure(String protocolHeaderValue)
/*      */   {
/*  947 */     if (!protocolHeaderValue.contains(",")) {
/*  948 */       return this.protocolHeaderHttpsValue.equalsIgnoreCase(protocolHeaderValue);
/*      */     }
/*  950 */     String[] forwardedProtocols = commaDelimitedListToStringArray(protocolHeaderValue);
/*  951 */     if (forwardedProtocols.length == 0) {
/*  952 */       return false;
/*      */     }
/*  954 */     for (String forwardedProtocol : forwardedProtocols) {
/*  955 */       if (!this.protocolHeaderHttpsValue.equalsIgnoreCase(forwardedProtocol)) {
/*  956 */         return false;
/*      */       }
/*      */     }
/*  959 */     return true;
/*      */   }
/*      */   
/*      */   private void setPorts(XForwardedRequest xrequest, int defaultPort) {
/*  963 */     int port = defaultPort;
/*  964 */     if (getPortHeader() != null) {
/*  965 */       String portHeaderValue = xrequest.getHeader(getPortHeader());
/*  966 */       if (portHeaderValue != null) {
/*      */         try {
/*  968 */           port = Integer.parseInt(portHeaderValue);
/*      */         } catch (NumberFormatException nfe) {
/*  970 */           this.log.debug("Invalid port value [" + portHeaderValue + "] provided in header [" + 
/*  971 */             getPortHeader() + "]");
/*      */         }
/*      */       }
/*      */     }
/*  975 */     xrequest.setServerPort(port);
/*  976 */     if (isChangeLocalPort()) {
/*  977 */       xrequest.setLocalPort(port);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*      */     throws IOException, ServletException
/*      */   {
/*  987 */     if (((request instanceof HttpServletRequest)) && ((response instanceof HttpServletResponse))) {
/*  988 */       doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
/*      */     } else {
/*  990 */       chain.doFilter(request, response);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isChangeLocalName() {
/*  995 */     return this.changeLocalName;
/*      */   }
/*      */   
/*      */   public boolean isChangeLocalPort() {
/*  999 */     return this.changeLocalPort;
/*      */   }
/*      */   
/*      */   public int getHttpsServerPort() {
/* 1003 */     return this.httpsServerPort;
/*      */   }
/*      */   
/*      */   public Pattern getInternalProxies() {
/* 1007 */     return this.internalProxies;
/*      */   }
/*      */   
/*      */   public String getProtocolHeader() {
/* 1011 */     return this.protocolHeader;
/*      */   }
/*      */   
/*      */   public String getPortHeader() {
/* 1015 */     return this.portHeader;
/*      */   }
/*      */   
/*      */   public String getProtocolHeaderHttpsValue() {
/* 1019 */     return this.protocolHeaderHttpsValue;
/*      */   }
/*      */   
/*      */   public String getProxiesHeader() {
/* 1023 */     return this.proxiesHeader;
/*      */   }
/*      */   
/*      */   public String getRemoteIpHeader() {
/* 1027 */     return this.remoteIpHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getRequestAttributesEnabled()
/*      */   {
/* 1036 */     return this.requestAttributesEnabled;
/*      */   }
/*      */   
/*      */   public Pattern getTrustedProxies() {
/* 1040 */     return this.trustedProxies;
/*      */   }
/*      */   
/*      */   public boolean getEnableLookups() {
/* 1044 */     return this.enableLookups;
/*      */   }
/*      */   
/*      */   public void init() throws ServletException
/*      */   {
/* 1049 */     if (getInitParameter("internalProxies") != null) {
/* 1050 */       setInternalProxies(getInitParameter("internalProxies"));
/*      */     }
/*      */     
/* 1053 */     if (getInitParameter("protocolHeader") != null) {
/* 1054 */       setProtocolHeader(getInitParameter("protocolHeader"));
/*      */     }
/*      */     
/* 1057 */     if (getInitParameter("protocolHeaderHttpsValue") != null) {
/* 1058 */       setProtocolHeaderHttpsValue(getInitParameter("protocolHeaderHttpsValue"));
/*      */     }
/*      */     
/* 1061 */     if (getInitParameter("hostHeader") != null) {
/* 1062 */       setHostHeader(getInitParameter("hostHeader"));
/*      */     }
/*      */     
/* 1065 */     if (getInitParameter("portHeader") != null) {
/* 1066 */       setPortHeader(getInitParameter("portHeader"));
/*      */     }
/*      */     
/* 1069 */     if (getInitParameter("changeLocalName") != null) {
/* 1070 */       setChangeLocalName(Boolean.parseBoolean(getInitParameter("changeLocalName")));
/*      */     }
/*      */     
/* 1073 */     if (getInitParameter("changeLocalPort") != null) {
/* 1074 */       setChangeLocalPort(Boolean.parseBoolean(getInitParameter("changeLocalPort")));
/*      */     }
/*      */     
/* 1077 */     if (getInitParameter("proxiesHeader") != null) {
/* 1078 */       setProxiesHeader(getInitParameter("proxiesHeader"));
/*      */     }
/*      */     
/* 1081 */     if (getInitParameter("remoteIpHeader") != null) {
/* 1082 */       setRemoteIpHeader(getInitParameter("remoteIpHeader"));
/*      */     }
/*      */     
/* 1085 */     if (getInitParameter("trustedProxies") != null) {
/* 1086 */       setTrustedProxies(getInitParameter("trustedProxies"));
/*      */     }
/*      */     
/* 1089 */     if (getInitParameter("httpServerPort") != null) {
/*      */       try {
/* 1091 */         setHttpServerPort(Integer.parseInt(getInitParameter("httpServerPort")));
/*      */       } catch (NumberFormatException e) {
/* 1093 */         throw new NumberFormatException(sm.getString("remoteIpFilter.invalidNumber", new Object[] { "httpServerPort", e.getLocalizedMessage() }));
/*      */       }
/*      */     }
/*      */     
/* 1097 */     if (getInitParameter("httpsServerPort") != null) {
/*      */       try {
/* 1099 */         setHttpsServerPort(Integer.parseInt(getInitParameter("httpsServerPort")));
/*      */       } catch (NumberFormatException e) {
/* 1101 */         throw new NumberFormatException(sm.getString("remoteIpFilter.invalidNumber", new Object[] { "httpsServerPort", e.getLocalizedMessage() }));
/*      */       }
/*      */     }
/*      */     
/* 1105 */     if (getInitParameter("enableLookups") != null) {
/* 1106 */       setEnableLookups(Boolean.parseBoolean(getInitParameter("enableLookups")));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setChangeLocalName(boolean changeLocalName)
/*      */   {
/* 1123 */     this.changeLocalName = changeLocalName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setChangeLocalPort(boolean changeLocalPort)
/*      */   {
/* 1139 */     this.changeLocalPort = changeLocalPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHttpServerPort(int httpServerPort)
/*      */   {
/* 1153 */     this.httpServerPort = httpServerPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHttpsServerPort(int httpsServerPort)
/*      */   {
/* 1166 */     this.httpsServerPort = httpsServerPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInternalProxies(String internalProxies)
/*      */   {
/* 1179 */     if ((internalProxies == null) || (internalProxies.length() == 0)) {
/* 1180 */       this.internalProxies = null;
/*      */     } else {
/* 1182 */       this.internalProxies = Pattern.compile(internalProxies);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHostHeader(String hostHeader)
/*      */   {
/* 1197 */     this.hostHeader = hostHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPortHeader(String portHeader)
/*      */   {
/* 1212 */     this.portHeader = portHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProtocolHeader(String protocolHeader)
/*      */   {
/* 1226 */     this.protocolHeader = protocolHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProtocolHeaderHttpsValue(String protocolHeaderHttpsValue)
/*      */   {
/* 1239 */     this.protocolHeaderHttpsValue = protocolHeaderHttpsValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxiesHeader(String proxiesHeader)
/*      */   {
/* 1260 */     this.proxiesHeader = proxiesHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRemoteIpHeader(String remoteIpHeader)
/*      */   {
/* 1276 */     this.remoteIpHeader = remoteIpHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRequestAttributesEnabled(boolean requestAttributesEnabled)
/*      */   {
/* 1299 */     this.requestAttributesEnabled = requestAttributesEnabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTrustedProxies(String trustedProxies)
/*      */   {
/* 1313 */     if ((trustedProxies == null) || (trustedProxies.length() == 0)) {
/* 1314 */       this.trustedProxies = null;
/*      */     } else {
/* 1316 */       this.trustedProxies = Pattern.compile(trustedProxies);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setEnableLookups(boolean enableLookups) {
/* 1321 */     this.enableLookups = enableLookups;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readObject(ObjectInputStream ois)
/*      */     throws ClassNotFoundException, IOException
/*      */   {
/* 1330 */     ois.defaultReadObject();
/* 1331 */     this.log = LogFactory.getLog(RemoteIpFilter.class);
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\filters\RemoteIpFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */