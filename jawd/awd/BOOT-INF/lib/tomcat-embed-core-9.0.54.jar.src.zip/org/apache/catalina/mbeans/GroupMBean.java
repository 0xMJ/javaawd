/*     */ package org.apache.catalina.mbeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Group;
/*     */ import org.apache.catalina.Role;
/*     */ import org.apache.catalina.User;
/*     */ import org.apache.catalina.UserDatabase;
/*     */ import org.apache.tomcat.util.modeler.BaseModelMBean;
/*     */ import org.apache.tomcat.util.modeler.ManagedBean;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupMBean
/*     */   extends BaseModelMBean
/*     */ {
/*  42 */   private static final StringManager sm = StringManager.getManager(GroupMBean.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  47 */   protected final Registry registry = MBeanUtils.createRegistry();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */   protected final ManagedBean managed = this.registry.findManagedBean("Group");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getRoles()
/*     */   {
/*  61 */     Group group = (Group)this.resource;
/*  62 */     List<String> results = new ArrayList();
/*  63 */     Iterator<Role> roles = group.getRoles();
/*  64 */     while (roles.hasNext()) {
/*  65 */       Role role = null;
/*     */       try {
/*  67 */         role = (Role)roles.next();
/*  68 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), role);
/*  69 */         results.add(oname.toString());
/*     */       } catch (MalformedObjectNameException e) {
/*  71 */         throw new IllegalArgumentException(sm.getString("userMBean.createError.role", new Object[] { role }), e);
/*     */       }
/*     */     }
/*  74 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getUsers()
/*     */   {
/*  83 */     Group group = (Group)this.resource;
/*  84 */     List<String> results = new ArrayList();
/*  85 */     Iterator<User> users = group.getUsers();
/*  86 */     while (users.hasNext()) {
/*  87 */       User user = null;
/*     */       try {
/*  89 */         user = (User)users.next();
/*  90 */         ObjectName oname = MBeanUtils.createObjectName(this.managed.getDomain(), user);
/*  91 */         results.add(oname.toString());
/*     */       } catch (MalformedObjectNameException e) {
/*  93 */         throw new IllegalArgumentException(sm.getString("userMBean.createError.user", new Object[] { user }), e);
/*     */       }
/*     */     }
/*  96 */     return (String[])results.toArray(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRole(String rolename)
/*     */   {
/* 107 */     Group group = (Group)this.resource;
/* 108 */     if (group == null) {
/* 109 */       return;
/*     */     }
/* 111 */     Role role = group.getUserDatabase().findRole(rolename);
/* 112 */     if (role == null) {
/* 113 */       throw new IllegalArgumentException(sm.getString("userMBean.invalidRole", new Object[] { rolename }));
/*     */     }
/* 115 */     group.addRole(role);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRole(String rolename)
/*     */   {
/* 126 */     Group group = (Group)this.resource;
/* 127 */     if (group == null) {
/* 128 */       return;
/*     */     }
/* 130 */     Role role = group.getUserDatabase().findRole(rolename);
/* 131 */     if (role == null) {
/* 132 */       throw new IllegalArgumentException(sm.getString("userMBean.invalidRole", new Object[] { rolename }));
/*     */     }
/* 134 */     group.removeRole(role);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\mbeans\GroupMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */