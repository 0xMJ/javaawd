/*      */ package org.apache.catalina.realm;
/*      */ 
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.security.Principal;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import javax.servlet.annotation.ServletSecurity.TransportGuarantee;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import org.apache.catalina.Container;
/*      */ import org.apache.catalina.Context;
/*      */ import org.apache.catalina.CredentialHandler;
/*      */ import org.apache.catalina.Engine;
/*      */ import org.apache.catalina.Host;
/*      */ import org.apache.catalina.LifecycleException;
/*      */ import org.apache.catalina.LifecycleState;
/*      */ import org.apache.catalina.Realm;
/*      */ import org.apache.catalina.Server;
/*      */ import org.apache.catalina.Service;
/*      */ import org.apache.catalina.Wrapper;
/*      */ import org.apache.catalina.connector.Connector;
/*      */ import org.apache.catalina.connector.Request;
/*      */ import org.apache.catalina.connector.Response;
/*      */ import org.apache.catalina.util.LifecycleMBeanBase;
/*      */ import org.apache.catalina.util.SessionConfig;
/*      */ import org.apache.catalina.util.ToStringUtil;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.IntrospectionUtils;
/*      */ import org.apache.tomcat.util.buf.B2CConverter;
/*      */ import org.apache.tomcat.util.buf.MessageBytes;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityCollection;
/*      */ import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.ConcurrentMessageDigest;
/*      */ import org.apache.tomcat.util.security.MD5Encoder;
/*      */ import org.ietf.jgss.GSSContext;
/*      */ import org.ietf.jgss.GSSCredential;
/*      */ import org.ietf.jgss.GSSException;
/*      */ import org.ietf.jgss.GSSName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class RealmBase
/*      */   extends LifecycleMBeanBase
/*      */   implements Realm
/*      */ {
/*   74 */   private static final Log log = LogFactory.getLog(RealmBase.class);
/*      */   
/*   76 */   private static final List<Class<? extends DigestCredentialHandlerBase>> credentialHandlerClasses = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/*   83 */     credentialHandlerClasses.add(MessageDigestCredentialHandler.class);
/*   84 */     credentialHandlerClasses.add(SecretKeyCredentialHandler.class);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   93 */   protected Container container = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   99 */   protected Log containerLog = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private CredentialHandler credentialHandler;
/*      */   
/*      */ 
/*      */ 
/*  108 */   protected static final StringManager sm = StringManager.getManager(RealmBase.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  114 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  120 */   protected boolean validate = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String x509UsernameRetrieverClassName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected X509UsernameRetriever x509UsernameRetriever;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  136 */   protected AllRolesMode allRolesMode = AllRolesMode.STRICT_MODE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  143 */   protected boolean stripRealmForGss = true;
/*      */   
/*      */ 
/*  146 */   private int transportGuaranteeRedirectStatus = 302;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTransportGuaranteeRedirectStatus()
/*      */   {
/*  157 */     return this.transportGuaranteeRedirectStatus;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTransportGuaranteeRedirectStatus(int transportGuaranteeRedirectStatus)
/*      */   {
/*  169 */     this.transportGuaranteeRedirectStatus = transportGuaranteeRedirectStatus;
/*      */   }
/*      */   
/*      */ 
/*      */   public CredentialHandler getCredentialHandler()
/*      */   {
/*  175 */     return this.credentialHandler;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCredentialHandler(CredentialHandler credentialHandler)
/*      */   {
/*  181 */     this.credentialHandler = credentialHandler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Container getContainer()
/*      */   {
/*  190 */     return this.container;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContainer(Container container)
/*      */   {
/*  202 */     Container oldContainer = this.container;
/*  203 */     this.container = container;
/*  204 */     this.support.firePropertyChange("container", oldContainer, this.container);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAllRolesMode()
/*      */   {
/*  213 */     return this.allRolesMode.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllRolesMode(String allRolesMode)
/*      */   {
/*  222 */     this.allRolesMode = AllRolesMode.toMode(allRolesMode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getValidate()
/*      */   {
/*  231 */     return this.validate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValidate(boolean validate)
/*      */   {
/*  242 */     this.validate = validate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getX509UsernameRetrieverClassName()
/*      */   {
/*  253 */     return this.x509UsernameRetrieverClassName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setX509UsernameRetrieverClassName(String className)
/*      */   {
/*  266 */     this.x509UsernameRetrieverClassName = className;
/*      */   }
/*      */   
/*      */   public boolean isStripRealmForGss() {
/*  270 */     return this.stripRealmForGss;
/*      */   }
/*      */   
/*      */   public void setStripRealmForGss(boolean stripRealmForGss)
/*      */   {
/*  275 */     this.stripRealmForGss = stripRealmForGss;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/*  290 */     this.support.addPropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(String username)
/*      */   {
/*  304 */     if (username == null) {
/*  305 */       return null;
/*      */     }
/*      */     
/*  308 */     if (this.containerLog.isTraceEnabled()) {
/*  309 */       this.containerLog.trace(sm.getString("realmBase.authenticateSuccess", new Object[] { username }));
/*      */     }
/*      */     
/*  312 */     return getPrincipal(username);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(String username, String credentials)
/*      */   {
/*  329 */     if ((username == null) || (credentials == null)) {
/*  330 */       if (this.containerLog.isTraceEnabled()) {
/*  331 */         this.containerLog.trace(sm.getString("realmBase.authenticateFailure", new Object[] { username }));
/*      */       }
/*      */       
/*  334 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  338 */     String serverCredentials = getPassword(username);
/*      */     
/*  340 */     if (serverCredentials == null)
/*      */     {
/*      */ 
/*  343 */       getCredentialHandler().mutate(credentials);
/*      */       
/*  345 */       if (this.containerLog.isTraceEnabled()) {
/*  346 */         this.containerLog.trace(sm.getString("realmBase.authenticateFailure", new Object[] { username }));
/*      */       }
/*      */       
/*  349 */       return null;
/*      */     }
/*      */     
/*  352 */     boolean validated = getCredentialHandler().matches(credentials, serverCredentials);
/*      */     
/*  354 */     if (validated) {
/*  355 */       if (this.containerLog.isTraceEnabled()) {
/*  356 */         this.containerLog.trace(sm.getString("realmBase.authenticateSuccess", new Object[] { username }));
/*      */       }
/*      */       
/*  359 */       return getPrincipal(username);
/*      */     }
/*  361 */     if (this.containerLog.isTraceEnabled()) {
/*  362 */       this.containerLog.trace(sm.getString("realmBase.authenticateFailure", new Object[] { username }));
/*      */     }
/*      */     
/*  365 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(String username, String clientDigest, String nonce, String nc, String cnonce, String qop, String realm, String md5a2)
/*      */   {
/*  395 */     String md5a1 = getDigest(username, realm);
/*  396 */     if (md5a1 == null) {
/*  397 */       return null;
/*      */     }
/*  399 */     md5a1 = md5a1.toLowerCase(Locale.ENGLISH);
/*      */     String serverDigestValue;
/*  401 */     String serverDigestValue; if (qop == null) {
/*  402 */       serverDigestValue = md5a1 + ":" + nonce + ":" + md5a2;
/*      */     } else {
/*  404 */       serverDigestValue = md5a1 + ":" + nonce + ":" + nc + ":" + cnonce + ":" + qop + ":" + md5a2;
/*      */     }
/*      */     
/*      */ 
/*  408 */     byte[] valueBytes = null;
/*      */     try {
/*  410 */       valueBytes = serverDigestValue.getBytes(getDigestCharset());
/*      */     } catch (UnsupportedEncodingException uee) {
/*  412 */       throw new IllegalArgumentException(sm.getString("realmBase.invalidDigestEncoding", new Object[] { getDigestEncoding() }), uee);
/*      */     }
/*      */     
/*  415 */     String serverDigest = MD5Encoder.encode(ConcurrentMessageDigest.digestMD5(new byte[][] { valueBytes }));
/*      */     
/*  417 */     if (log.isDebugEnabled()) {
/*  418 */       log.debug("Digest : " + clientDigest + " Username:" + username + " ClientDigest:" + clientDigest + " nonce:" + nonce + " nc:" + nc + " cnonce:" + cnonce + " qop:" + qop + " realm:" + realm + "md5a2:" + md5a2 + " Server digest:" + serverDigest);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  425 */     if (serverDigest.equals(clientDigest)) {
/*  426 */       return getPrincipal(username);
/*      */     }
/*      */     
/*  429 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(X509Certificate[] certs)
/*      */   {
/*  443 */     if ((certs == null) || (certs.length < 1)) {
/*  444 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  448 */     if (log.isDebugEnabled()) {
/*  449 */       log.debug("Authenticating client certificate chain");
/*      */     }
/*  451 */     if (this.validate) {
/*  452 */       for (X509Certificate cert : certs) {
/*  453 */         if (log.isDebugEnabled()) {
/*  454 */           log.debug(" Checking validity for '" + cert
/*  455 */             .getSubjectDN().getName() + "'");
/*      */         }
/*      */         try {
/*  458 */           cert.checkValidity();
/*      */         } catch (Exception e) {
/*  460 */           if (log.isDebugEnabled()) {
/*  461 */             log.debug("  Validity exception", e);
/*      */           }
/*  463 */           return null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  469 */     return getPrincipal(certs[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(GSSContext gssContext, boolean storeCred)
/*      */   {
/*  478 */     if (gssContext.isEstablished()) {
/*  479 */       GSSName gssName = null;
/*      */       try {
/*  481 */         gssName = gssContext.getSrcName();
/*      */       } catch (GSSException e) {
/*  483 */         log.warn(sm.getString("realmBase.gssNameFail"), e);
/*      */       }
/*      */       
/*  486 */       if (gssName != null) {
/*  487 */         GSSCredential gssCredential = null;
/*  488 */         if (storeCred) {
/*  489 */           if (gssContext.getCredDelegState()) {
/*      */             try {
/*  491 */               gssCredential = gssContext.getDelegCred();
/*      */             } catch (GSSException e) {
/*  493 */               log.warn(sm.getString("realmBase.delegatedCredentialFail", new Object[] { gssName }), e);
/*      */             }
/*      */             
/*      */           }
/*  497 */           else if (log.isDebugEnabled()) {
/*  498 */             log.debug(sm.getString("realmBase.credentialNotDelegated", new Object[] { gssName }));
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  504 */         return getPrincipal(gssName, gssCredential);
/*      */       }
/*      */     } else {
/*  507 */       log.error(sm.getString("realmBase.gssContextNotEstablished"));
/*      */     }
/*      */     
/*      */ 
/*  511 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Principal authenticate(GSSName gssName, GSSCredential gssCredential)
/*      */   {
/*  520 */     if (gssName == null) {
/*  521 */       return null;
/*      */     }
/*      */     
/*  524 */     return getPrincipal(gssName, gssCredential);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SecurityConstraint[] findSecurityConstraints(Request request, Context context)
/*      */   {
/*  550 */     ArrayList<SecurityConstraint> results = null;
/*      */     
/*  552 */     SecurityConstraint[] constraints = context.findConstraints();
/*  553 */     if ((constraints == null) || (constraints.length == 0)) {
/*  554 */       if (log.isDebugEnabled()) {
/*  555 */         log.debug("  No applicable constraints defined");
/*      */       }
/*  557 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  561 */     String uri = request.getRequestPathMB().toString();
/*      */     
/*      */ 
/*  564 */     if ((uri == null) || (uri.length() == 0)) {
/*  565 */       uri = "/";
/*      */     }
/*      */     
/*  568 */     String method = request.getMethod();
/*      */     
/*  570 */     boolean found = false;
/*  571 */     SecurityCollection localSecurityCollection1; SecurityCollection securityCollection; String pattern; for (int i = 0; i < constraints.length; i++) {
/*  572 */       SecurityCollection[] collections = constraints[i].findCollections();
/*      */       
/*      */ 
/*      */ 
/*  576 */       if (collections != null)
/*      */       {
/*      */ 
/*      */ 
/*  580 */         if (log.isDebugEnabled()) {
/*  581 */           log.debug("  Checking constraint '" + constraints[i] + "' against " + method + " " + uri + " --> " + constraints[i]
/*      */           
/*  583 */             .included(uri, method));
/*      */         }
/*      */         
/*  586 */         SecurityCollection[] arrayOfSecurityCollection1 = collections;int i = arrayOfSecurityCollection1.length; for (localSecurityCollection1 = 0; localSecurityCollection1 < i; localSecurityCollection1++) { securityCollection = arrayOfSecurityCollection1[localSecurityCollection1];
/*  587 */           String[] patterns = securityCollection.findPatterns();
/*      */           
/*      */ 
/*      */ 
/*  591 */           if (patterns != null)
/*      */           {
/*      */ 
/*      */ 
/*  595 */             for (pattern : patterns)
/*      */             {
/*  597 */               if ((uri.equals(pattern)) || ((pattern.length() == 0) && (uri.equals("/")))) {
/*  598 */                 found = true;
/*  599 */                 if (securityCollection.findMethod(method)) {
/*  600 */                   if (results == null) {
/*  601 */                     results = new ArrayList();
/*      */                   }
/*  603 */                   results.add(constraints[i]);
/*      */                 }
/*      */               } }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  610 */     if (found) {
/*  611 */       return resultsToArray(results);
/*      */     }
/*      */     
/*  614 */     int longest = -1;
/*      */     
/*  616 */     for (i = 0; i < constraints.length; i++) {
/*  617 */       SecurityCollection[] collection = constraints[i].findCollections();
/*      */       
/*      */ 
/*      */ 
/*  621 */       if (collection != null)
/*      */       {
/*      */ 
/*      */ 
/*  625 */         if (log.isDebugEnabled()) {
/*  626 */           log.debug("  Checking constraint '" + constraints[i] + "' against " + method + " " + uri + " --> " + constraints[i]
/*      */           
/*  628 */             .included(uri, method));
/*      */         }
/*      */         
/*  631 */         SecurityCollection[] arrayOfSecurityCollection2 = collection;localSecurityCollection1 = arrayOfSecurityCollection2.length; for (securityCollection = 0; securityCollection < localSecurityCollection1; securityCollection++) { SecurityCollection securityCollection = arrayOfSecurityCollection2[securityCollection];
/*  632 */           String[] patterns = securityCollection.findPatterns();
/*      */           
/*      */ 
/*      */ 
/*  636 */           if (patterns != null)
/*      */           {
/*      */ 
/*      */ 
/*  640 */             boolean matched = false;
/*  641 */             int length = -1;
/*  642 */             for (String pattern : patterns) {
/*  643 */               if ((pattern.startsWith("/")) && (pattern.endsWith("/*")) && 
/*  644 */                 (pattern.length() >= longest))
/*      */               {
/*  646 */                 if (pattern.length() == 2) {
/*  647 */                   matched = true;
/*  648 */                   length = pattern.length();
/*  649 */                 } else if ((pattern.regionMatches(0, uri, 0, pattern.length() - 1)) || (
/*  650 */                   (pattern.length() - 2 == uri.length()) && 
/*  651 */                   (pattern.regionMatches(0, uri, 0, pattern.length() - 2)))) {
/*  652 */                   matched = true;
/*  653 */                   length = pattern.length();
/*      */                 }
/*      */               }
/*      */             }
/*  657 */             if (matched) {
/*  658 */               if (length > longest) {
/*  659 */                 found = false;
/*  660 */                 if (results != null) {
/*  661 */                   results.clear();
/*      */                 }
/*  663 */                 longest = length;
/*      */               }
/*  665 */               if (securityCollection.findMethod(method)) {
/*  666 */                 found = true;
/*  667 */                 if (results == null) {
/*  668 */                   results = new ArrayList();
/*      */                 }
/*  670 */                 results.add(constraints[i]);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       } }
/*  676 */     if (found)
/*  677 */       return resultsToArray(results);
/*      */     boolean matched;
/*      */     int pos;
/*  680 */     int j; int slash; int dot; for (i = 0; i < constraints.length; i++) {
/*  681 */       SecurityCollection[] collection = constraints[i].findCollections();
/*      */       
/*      */ 
/*      */ 
/*  685 */       if (collection != null)
/*      */       {
/*      */ 
/*      */ 
/*  689 */         if (log.isDebugEnabled()) {
/*  690 */           log.debug("  Checking constraint '" + constraints[i] + "' against " + method + " " + uri + " --> " + constraints[i]
/*      */           
/*  692 */             .included(uri, method));
/*      */         }
/*      */         
/*  695 */         matched = false;
/*  696 */         pos = -1;
/*  697 */         for (j = 0; j < collection.length; j++) {
/*  698 */           String[] patterns = collection[j].findPatterns();
/*      */           
/*      */ 
/*      */ 
/*  702 */           if (patterns != null)
/*      */           {
/*      */ 
/*      */ 
/*  706 */             for (int k = 0; (k < patterns.length) && (!matched); k++) {
/*  707 */               String pattern = patterns[k];
/*  708 */               if (pattern.startsWith("*.")) {
/*  709 */                 slash = uri.lastIndexOf('/');
/*  710 */                 dot = uri.lastIndexOf('.');
/*  711 */                 if ((slash >= 0) && (dot > slash) && 
/*  712 */                   (dot != uri.length() - 1) && 
/*  713 */                   (uri.length() - dot == pattern.length() - 1) && 
/*  714 */                   (pattern.regionMatches(1, uri, dot, uri.length() - dot))) {
/*  715 */                   matched = true;
/*  716 */                   pos = j;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*  722 */         if (matched) {
/*  723 */           found = true;
/*  724 */           if (collection[pos].findMethod(method)) {
/*  725 */             if (results == null) {
/*  726 */               results = new ArrayList();
/*      */             }
/*  728 */             results.add(constraints[i]);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  733 */     if (found) {
/*  734 */       return resultsToArray(results);
/*      */     }
/*      */     
/*  737 */     for (i = 0; i < constraints.length; i++) {
/*  738 */       SecurityCollection[] collection = constraints[i].findCollections();
/*      */       
/*      */ 
/*      */ 
/*  742 */       if (collection != null)
/*      */       {
/*      */ 
/*      */ 
/*  746 */         if (log.isDebugEnabled()) {
/*  747 */           log.debug("  Checking constraint '" + constraints[i] + "' against " + method + " " + uri + " --> " + constraints[i]
/*      */           
/*  749 */             .included(uri, method));
/*      */         }
/*      */         
/*  752 */         for (SecurityCollection securityCollection : collection) {
/*  753 */           String[] patterns = securityCollection.findPatterns();
/*      */           
/*      */ 
/*      */ 
/*  757 */           if (patterns != null)
/*      */           {
/*      */ 
/*      */ 
/*  761 */             boolean matched = false;
/*  762 */             for (String pattern : patterns) {
/*  763 */               if (pattern.equals("/")) {
/*  764 */                 matched = true;
/*  765 */                 break;
/*      */               }
/*      */             }
/*  768 */             if (matched) {
/*  769 */               if (results == null) {
/*  770 */                 results = new ArrayList();
/*      */               }
/*  772 */               results.add(constraints[i]);
/*      */             }
/*      */           }
/*      */         }
/*      */       } }
/*  777 */     if (results == null)
/*      */     {
/*  779 */       if (log.isDebugEnabled()) {
/*  780 */         log.debug("  No applicable constraint located");
/*      */       }
/*      */     }
/*  783 */     return resultsToArray(results);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private SecurityConstraint[] resultsToArray(ArrayList<SecurityConstraint> results)
/*      */   {
/*  791 */     if ((results == null) || (results.size() == 0)) {
/*  792 */       return null;
/*      */     }
/*  794 */     SecurityConstraint[] array = new SecurityConstraint[results.size()];
/*  795 */     results.toArray(array);
/*  796 */     return array;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasResourcePermission(Request request, Response response, SecurityConstraint[] constraints, Context context)
/*      */     throws IOException
/*      */   {
/*  819 */     if ((constraints == null) || (constraints.length == 0)) {
/*  820 */       return true;
/*      */     }
/*      */     
/*      */ 
/*  824 */     Principal principal = request.getPrincipal();
/*  825 */     boolean status = false;
/*  826 */     boolean denyfromall = false;
/*  827 */     for (SecurityConstraint constraint : constraints) { String[] roles;
/*      */       String[] roles;
/*  829 */       if (constraint.getAllRoles())
/*      */       {
/*  831 */         roles = request.getContext().findSecurityRoles();
/*      */       } else {
/*  833 */         roles = constraint.findAuthRoles();
/*      */       }
/*      */       
/*  836 */       if (roles == null) {
/*  837 */         roles = new String[0];
/*      */       }
/*      */       
/*  840 */       if (log.isDebugEnabled()) {
/*  841 */         log.debug("  Checking roles " + principal);
/*      */       }
/*      */       
/*  844 */       if ((constraint.getAuthenticatedUsers()) && (principal != null)) {
/*  845 */         if (log.isDebugEnabled()) {
/*  846 */           log.debug("Passing all authenticated users");
/*      */         }
/*  848 */         status = true;
/*      */       }
/*  850 */       else if ((roles.length == 0) && (!constraint.getAllRoles()) && 
/*  851 */         (!constraint.getAuthenticatedUsers())) {
/*  852 */         if (constraint.getAuthConstraint()) {
/*  853 */           if (log.isDebugEnabled()) {
/*  854 */             log.debug("No roles");
/*      */           }
/*  856 */           status = false;
/*  857 */           denyfromall = true;
/*  858 */           break;
/*      */         }
/*      */         
/*  861 */         if (log.isDebugEnabled()) {
/*  862 */           log.debug("Passing all access");
/*      */         }
/*  864 */         status = true;
/*  865 */       } else if (principal == null) {
/*  866 */         if (log.isDebugEnabled()) {
/*  867 */           log.debug("  No user authenticated, cannot grant access");
/*      */         }
/*      */       } else {
/*  870 */         for (String role : roles) {
/*  871 */           if (hasRole(request.getWrapper(), principal, role)) {
/*  872 */             status = true;
/*  873 */             if (log.isDebugEnabled()) {
/*  874 */               log.debug("Role found:  " + role);
/*      */             }
/*  876 */           } else if (log.isDebugEnabled()) {
/*  877 */             log.debug("No role found:  " + role);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  883 */     if ((!denyfromall) && (this.allRolesMode != AllRolesMode.STRICT_MODE) && (!status) && (principal != null))
/*      */     {
/*  885 */       if (log.isDebugEnabled()) {
/*  886 */         log.debug("Checking for all roles mode: " + this.allRolesMode);
/*      */       }
/*      */       
/*  889 */       for (SecurityConstraint constraint : constraints)
/*      */       {
/*      */ 
/*  892 */         if (constraint.getAllRoles()) {
/*  893 */           if (this.allRolesMode == AllRolesMode.AUTH_ONLY_MODE) {
/*  894 */             if (log.isDebugEnabled()) {
/*  895 */               log.debug("Granting access for role-name=*, auth-only");
/*      */             }
/*  897 */             status = true;
/*  898 */             break;
/*      */           }
/*      */           
/*      */ 
/*  902 */           String[] roles = request.getContext().findSecurityRoles();
/*  903 */           if ((roles.length == 0) && (this.allRolesMode == AllRolesMode.STRICT_AUTH_ONLY_MODE)) {
/*  904 */             if (log.isDebugEnabled()) {
/*  905 */               log.debug("Granting access for role-name=*, strict auth-only");
/*      */             }
/*  907 */             status = true;
/*  908 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  915 */     if (!status)
/*      */     {
/*  917 */       response.sendError(403, sm
/*  918 */         .getString("realmBase.forbidden"));
/*      */     }
/*  920 */     return status;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasRole(Wrapper wrapper, Principal principal, String role)
/*      */   {
/*  936 */     if (wrapper != null) {
/*  937 */       String realRole = wrapper.findSecurityReference(role);
/*  938 */       if (realRole != null) {
/*  939 */         role = realRole;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  944 */     if ((principal == null) || (role == null)) {
/*  945 */       return false;
/*      */     }
/*      */     
/*  948 */     boolean result = hasRoleInternal(principal, role);
/*      */     
/*  950 */     if (log.isDebugEnabled()) {
/*  951 */       String name = principal.getName();
/*  952 */       if (result) {
/*  953 */         log.debug(sm.getString("realmBase.hasRoleSuccess", new Object[] { name, role }));
/*      */       } else {
/*  955 */         log.debug(sm.getString("realmBase.hasRoleFailure", new Object[] { name, role }));
/*      */       }
/*      */     }
/*      */     
/*  959 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean hasRoleInternal(Principal principal, String role)
/*      */   {
/*  981 */     if (!(principal instanceof GenericPrincipal)) {
/*  982 */       return false;
/*      */     }
/*      */     
/*  985 */     GenericPrincipal gp = (GenericPrincipal)principal;
/*  986 */     return gp.hasRole(role);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasUserDataPermission(Request request, Response response, SecurityConstraint[] constraints)
/*      */     throws IOException
/*      */   {
/* 1009 */     if ((constraints == null) || (constraints.length == 0)) {
/* 1010 */       if (log.isDebugEnabled()) {
/* 1011 */         log.debug("  No applicable security constraint defined");
/*      */       }
/* 1013 */       return true;
/*      */     }
/* 1015 */     for (SecurityConstraint constraint : constraints) {
/* 1016 */       String userConstraint = constraint.getUserConstraint();
/* 1017 */       if (userConstraint == null) {
/* 1018 */         if (log.isDebugEnabled()) {
/* 1019 */           log.debug("  No applicable user data constraint defined");
/*      */         }
/* 1021 */         return true;
/*      */       }
/* 1023 */       if (userConstraint.equals(ServletSecurity.TransportGuarantee.NONE.name())) {
/* 1024 */         if (log.isDebugEnabled()) {
/* 1025 */           log.debug("  User data constraint has no restrictions");
/*      */         }
/* 1027 */         return true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1032 */     if (request.getRequest().isSecure()) {
/* 1033 */       if (log.isDebugEnabled()) {
/* 1034 */         log.debug("  User data constraint already satisfied");
/*      */       }
/* 1036 */       return true;
/*      */     }
/*      */     
/* 1039 */     int redirectPort = request.getConnector().getRedirectPortWithOffset();
/*      */     
/*      */ 
/* 1042 */     if (redirectPort <= 0) {
/* 1043 */       if (log.isDebugEnabled()) {
/* 1044 */         log.debug("  SSL redirect is disabled");
/*      */       }
/*      */       
/* 1047 */       response.sendError(403, request
/* 1048 */         .getRequestURI());
/* 1049 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 1053 */     StringBuilder file = new StringBuilder();
/* 1054 */     String protocol = "https";
/* 1055 */     String host = request.getServerName();
/*      */     
/* 1057 */     file.append(protocol).append("://").append(host);
/*      */     
/* 1059 */     if (redirectPort != 443) {
/* 1060 */       file.append(':').append(redirectPort);
/*      */     }
/*      */     
/* 1063 */     file.append(request.getRequestURI());
/* 1064 */     String requestedSessionId = request.getRequestedSessionId();
/* 1065 */     if ((requestedSessionId != null) && 
/* 1066 */       (request.isRequestedSessionIdFromURL())) {
/* 1067 */       file.append(';');
/* 1068 */       file.append(SessionConfig.getSessionUriParamName(request
/* 1069 */         .getContext()));
/* 1070 */       file.append('=');
/* 1071 */       file.append(requestedSessionId);
/*      */     }
/* 1073 */     String queryString = request.getQueryString();
/* 1074 */     if (queryString != null) {
/* 1075 */       file.append('?');
/* 1076 */       file.append(queryString);
/*      */     }
/* 1078 */     if (log.isDebugEnabled()) {
/* 1079 */       log.debug("  Redirecting to " + file.toString());
/*      */     }
/* 1081 */     response.sendRedirect(file.toString(), this.transportGuaranteeRedirectStatus);
/* 1082 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*      */   {
/* 1095 */     this.support.removePropertyChangeListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void initInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1103 */     super.initInternal();
/*      */     
/*      */ 
/* 1106 */     if (this.container != null) {
/* 1107 */       this.containerLog = this.container.getLogger();
/*      */     }
/*      */     
/* 1110 */     this.x509UsernameRetriever = createUsernameRetriever(this.x509UsernameRetrieverClassName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void startInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1123 */     if (this.credentialHandler == null) {
/* 1124 */       this.credentialHandler = new MessageDigestCredentialHandler();
/*      */     }
/*      */     
/* 1127 */     setState(LifecycleState.STARTING);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void stopInternal()
/*      */     throws LifecycleException
/*      */   {
/* 1141 */     setState(LifecycleState.STOPPING);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1150 */     return ToStringUtil.toString(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected boolean hasMessageDigest()
/*      */   {
/* 1157 */     CredentialHandler ch = this.credentialHandler;
/* 1158 */     if ((ch instanceof MessageDigestCredentialHandler)) {
/* 1159 */       return ((MessageDigestCredentialHandler)ch).getAlgorithm() != null;
/*      */     }
/* 1161 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getDigest(String username, String realmName)
/*      */   {
/* 1172 */     if (hasMessageDigest())
/*      */     {
/* 1174 */       return getPassword(username);
/*      */     }
/*      */     
/*      */ 
/* 1178 */     String digestValue = username + ":" + realmName + ":" + getPassword(username);
/*      */     
/* 1180 */     byte[] valueBytes = null;
/*      */     try {
/* 1182 */       valueBytes = digestValue.getBytes(getDigestCharset());
/*      */     } catch (UnsupportedEncodingException uee) {
/* 1184 */       throw new IllegalArgumentException(sm.getString("realmBase.invalidDigestEncoding", new Object[] { getDigestEncoding() }), uee);
/*      */     }
/*      */     
/* 1187 */     return MD5Encoder.encode(ConcurrentMessageDigest.digestMD5(new byte[][] { valueBytes }));
/*      */   }
/*      */   
/*      */   private String getDigestEncoding()
/*      */   {
/* 1192 */     CredentialHandler ch = this.credentialHandler;
/* 1193 */     if ((ch instanceof MessageDigestCredentialHandler)) {
/* 1194 */       return ((MessageDigestCredentialHandler)ch).getEncoding();
/*      */     }
/* 1196 */     return null;
/*      */   }
/*      */   
/*      */   private Charset getDigestCharset() throws UnsupportedEncodingException
/*      */   {
/* 1201 */     String charset = getDigestEncoding();
/* 1202 */     if (charset == null) {
/* 1203 */       return StandardCharsets.ISO_8859_1;
/*      */     }
/* 1205 */     return B2CConverter.getCharset(charset);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Principal getPrincipal(X509Certificate usercert)
/*      */   {
/* 1224 */     String username = this.x509UsernameRetriever.getUsername(usercert);
/*      */     
/* 1226 */     if (log.isDebugEnabled()) {
/* 1227 */       log.debug(sm.getString("realmBase.gotX509Username", new Object[] { username }));
/*      */     }
/*      */     
/* 1230 */     return getPrincipal(username);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected Principal getPrincipal(String username, GSSCredential gssCredential)
/*      */   {
/* 1254 */     Principal p = getPrincipal(username);
/*      */     
/* 1256 */     if ((p instanceof GenericPrincipal)) {
/* 1257 */       ((GenericPrincipal)p).setGssCredential(gssCredential);
/*      */     }
/*      */     
/* 1260 */     return p;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Principal getPrincipal(GSSName gssName, GSSCredential gssCredential)
/*      */   {
/* 1273 */     String name = gssName.toString();
/*      */     
/* 1275 */     if (isStripRealmForGss()) {
/* 1276 */       int i = name.indexOf('@');
/* 1277 */       if (i > 0)
/*      */       {
/* 1279 */         name = name.substring(0, i);
/*      */       }
/*      */     }
/*      */     
/* 1283 */     Principal p = getPrincipal(name);
/*      */     
/* 1285 */     if ((p instanceof GenericPrincipal)) {
/* 1286 */       ((GenericPrincipal)p).setGssCredential(gssCredential);
/*      */     }
/*      */     
/* 1289 */     return p;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Server getServer()
/*      */   {
/* 1301 */     Container c = this.container;
/* 1302 */     if ((c instanceof Context)) {
/* 1303 */       c = c.getParent();
/*      */     }
/* 1305 */     if ((c instanceof Host)) {
/* 1306 */       c = c.getParent();
/*      */     }
/* 1308 */     if ((c instanceof Engine)) {
/* 1309 */       Service s = ((Engine)c).getService();
/* 1310 */       if (s != null) {
/* 1311 */         return s.getServer();
/*      */       }
/*      */     }
/* 1314 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void main(String[] args)
/*      */   {
/* 1358 */     int saltLength = -1;
/* 1359 */     int iterations = -1;
/* 1360 */     int keyLength = -1;
/*      */     
/* 1362 */     String encoding = Charset.defaultCharset().name();
/*      */     
/*      */ 
/* 1365 */     String algorithm = null;
/* 1366 */     String handlerClassName = null;
/*      */     
/* 1368 */     if (args.length == 0) {
/* 1369 */       usage();
/* 1370 */       return;
/*      */     }
/*      */     
/* 1373 */     int argIndex = 0;
/*      */     
/* 1375 */     while ((args.length > argIndex + 2) && (args[argIndex].length() == 2) && 
/* 1376 */       (args[argIndex].charAt(0) == '-')) {
/* 1377 */       switch (args[argIndex].charAt(1)) {
/*      */       case 'a': 
/* 1379 */         algorithm = args[(argIndex + 1)];
/* 1380 */         break;
/*      */       
/*      */       case 'e': 
/* 1383 */         encoding = args[(argIndex + 1)];
/* 1384 */         break;
/*      */       
/*      */       case 'i': 
/* 1387 */         iterations = Integer.parseInt(args[(argIndex + 1)]);
/* 1388 */         break;
/*      */       
/*      */       case 's': 
/* 1391 */         saltLength = Integer.parseInt(args[(argIndex + 1)]);
/* 1392 */         break;
/*      */       
/*      */       case 'k': 
/* 1395 */         keyLength = Integer.parseInt(args[(argIndex + 1)]);
/* 1396 */         break;
/*      */       
/*      */       case 'h': 
/* 1399 */         handlerClassName = args[(argIndex + 1)];
/* 1400 */         break;
/*      */       case 'b': case 'c': case 'd': case 'f': case 'g': case 'j': case 'l': 
/*      */       case 'm': case 'n': case 'o': case 'p': case 'q': case 'r': default: 
/* 1403 */         usage();
/* 1404 */         return;
/*      */       }
/*      */       
/* 1407 */       argIndex += 2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1419 */     if ((algorithm == null) && (handlerClassName == null)) {
/* 1420 */       algorithm = "SHA-512";
/*      */     }
/*      */     
/* 1423 */     CredentialHandler handler = null;
/*      */     
/* 1425 */     if (handlerClassName == null) {
/* 1426 */       for (Class<? extends DigestCredentialHandlerBase> clazz : credentialHandlerClasses) {
/*      */         try {
/* 1428 */           handler = (CredentialHandler)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 1429 */           if (IntrospectionUtils.setProperty(handler, "algorithm", algorithm)) {
/*      */             break;
/*      */           }
/*      */         }
/*      */         catch (ReflectiveOperationException e) {
/* 1434 */           throw new RuntimeException(e);
/*      */         }
/*      */       }
/*      */     } else {
/*      */       try {
/* 1439 */         Object clazz = Class.forName(handlerClassName);
/* 1440 */         handler = (DigestCredentialHandlerBase)((Class)clazz).getConstructor(new Class[0]).newInstance(new Object[0]);
/* 1441 */         IntrospectionUtils.setProperty(handler, "algorithm", algorithm);
/*      */       } catch (ReflectiveOperationException e) {
/* 1443 */         throw new RuntimeException(e);
/*      */       }
/*      */     }
/*      */     
/* 1447 */     if (handler == null) {
/* 1448 */       throw new RuntimeException(new NoSuchAlgorithmException(algorithm));
/*      */     }
/*      */     
/* 1451 */     IntrospectionUtils.setProperty(handler, "encoding", encoding);
/* 1452 */     if (iterations > 0) {
/* 1453 */       IntrospectionUtils.setProperty(handler, "iterations", Integer.toString(iterations));
/*      */     }
/* 1455 */     if (saltLength > -1) {
/* 1456 */       IntrospectionUtils.setProperty(handler, "saltLength", Integer.toString(saltLength));
/*      */     }
/* 1458 */     if (keyLength > 0) {
/* 1459 */       IntrospectionUtils.setProperty(handler, "keyLength", Integer.toString(keyLength));
/*      */     }
/* 1462 */     for (; 
/* 1462 */         argIndex < args.length; argIndex++) {
/* 1463 */       String credential = args[argIndex];
/* 1464 */       System.out.print(credential + ":");
/* 1465 */       System.out.println(handler.mutate(credential));
/*      */     }
/*      */   }
/*      */   
/*      */   private static void usage()
/*      */   {
/* 1471 */     System.out.println("Usage: RealmBase [-a <algorithm>] [-e <encoding>] [-i <iterations>] [-s <salt-length>] [-k <key-length>] [-h <handler-class-name>] <credentials>");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getObjectNameKeyProperties()
/*      */   {
/* 1482 */     StringBuilder keyProperties = new StringBuilder("type=Realm");
/* 1483 */     keyProperties.append(getRealmSuffix());
/* 1484 */     keyProperties.append(this.container.getMBeanKeyProperties());
/*      */     
/* 1486 */     return keyProperties.toString();
/*      */   }
/*      */   
/*      */   public String getDomainInternal()
/*      */   {
/* 1491 */     return this.container.getDomain();
/*      */   }
/*      */   
/* 1494 */   protected String realmPath = "/realm0";
/*      */   
/*      */   public String getRealmPath() {
/* 1497 */     return this.realmPath;
/*      */   }
/*      */   
/*      */   public void setRealmPath(String theRealmPath) {
/* 1501 */     this.realmPath = theRealmPath;
/*      */   }
/*      */   
/*      */   protected String getRealmSuffix() {
/* 1505 */     return ",realmPath=" + getRealmPath();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class AllRolesMode
/*      */   {
/*      */     private final String name;
/*      */     
/*      */ 
/* 1515 */     public static final AllRolesMode STRICT_MODE = new AllRolesMode("strict");
/*      */     
/*      */ 
/* 1518 */     public static final AllRolesMode AUTH_ONLY_MODE = new AllRolesMode("authOnly");
/*      */     
/*      */ 
/* 1521 */     public static final AllRolesMode STRICT_AUTH_ONLY_MODE = new AllRolesMode("strictAuthOnly");
/*      */     
/*      */     static AllRolesMode toMode(String name) {
/*      */       AllRolesMode mode;
/* 1525 */       if (name.equalsIgnoreCase(STRICT_MODE.name)) {
/* 1526 */         mode = STRICT_MODE; } else { AllRolesMode mode;
/* 1527 */         if (name.equalsIgnoreCase(AUTH_ONLY_MODE.name)) {
/* 1528 */           mode = AUTH_ONLY_MODE; } else { AllRolesMode mode;
/* 1529 */           if (name.equalsIgnoreCase(STRICT_AUTH_ONLY_MODE.name)) {
/* 1530 */             mode = STRICT_AUTH_ONLY_MODE;
/*      */           }
/*      */           else
/* 1533 */             throw new IllegalStateException(RealmBase.sm.getString("realmBase.unknownAllRolesMode", new Object[] { name })); } }
/*      */       AllRolesMode mode;
/* 1535 */       return mode;
/*      */     }
/*      */     
/*      */     private AllRolesMode(String name) {
/* 1539 */       this.name = name;
/*      */     }
/*      */     
/*      */     public boolean equals(Object o)
/*      */     {
/* 1544 */       boolean equals = false;
/* 1545 */       if ((o instanceof AllRolesMode)) {
/* 1546 */         AllRolesMode mode = (AllRolesMode)o;
/* 1547 */         equals = this.name.equals(mode.name);
/*      */       }
/* 1549 */       return equals;
/*      */     }
/*      */     
/*      */     public int hashCode()
/*      */     {
/* 1554 */       return this.name.hashCode();
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/* 1559 */       return this.name;
/*      */     }
/*      */   }
/*      */   
/*      */   private static X509UsernameRetriever createUsernameRetriever(String className) throws LifecycleException
/*      */   {
/* 1565 */     if ((null == className) || (className.trim().isEmpty())) {
/* 1566 */       return new X509SubjectDnRetriever();
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1571 */       Class<? extends X509UsernameRetriever> clazz = Class.forName(className);
/* 1572 */       return (X509UsernameRetriever)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */     } catch (ReflectiveOperationException e) {
/* 1574 */       throw new LifecycleException(sm.getString("realmBase.createUsernameRetriever.newInstance", new Object[] { className }), e);
/*      */     } catch (ClassCastException e) {
/* 1576 */       throw new LifecycleException(sm.getString("realmBase.createUsernameRetriever.ClassCastException", new Object[] { className }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public String[] getRoles(Principal principal)
/*      */   {
/* 1583 */     if ((principal instanceof GenericPrincipal)) {
/* 1584 */       return ((GenericPrincipal)principal).getRoles();
/*      */     }
/*      */     
/* 1587 */     String className = principal.getClass().getSimpleName();
/* 1588 */     throw new IllegalStateException(sm.getString("realmBase.cannotGetRoles", new Object[] { className }));
/*      */   }
/*      */   
/*      */   public void backgroundProcess() {}
/*      */   
/*      */   protected abstract String getPassword(String paramString);
/*      */   
/*      */   protected abstract Principal getPrincipal(String paramString);
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\realm\RealmBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */