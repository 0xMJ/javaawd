/*     */ package org.apache.catalina.filters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsrfPreventionFilter
/*     */   extends CsrfPreventionFilterBase
/*     */ {
/*  50 */   private final Log log = LogFactory.getLog(CsrfPreventionFilter.class);
/*     */   
/*  52 */   private final Set<String> entryPoints = new HashSet();
/*     */   
/*  54 */   private int nonceCacheSize = 5;
/*     */   
/*  56 */   private String nonceRequestParameterName = "org.apache.catalina.filters.CSRF_NONCE";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEntryPoints(String entryPoints)
/*     */   {
/*  69 */     String[] values = entryPoints.split(",");
/*  70 */     for (String value : values) {
/*  71 */       this.entryPoints.add(value.trim());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNonceCacheSize(int nonceCacheSize)
/*     */   {
/*  85 */     this.nonceCacheSize = nonceCacheSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNonceRequestParameterName(String parameterName)
/*     */   {
/*  95 */     this.nonceRequestParameterName = parameterName;
/*     */   }
/*     */   
/*     */   public void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/* 101 */     super.init(filterConfig);
/*     */     
/*     */ 
/* 104 */     filterConfig.getServletContext().setAttribute("org.apache.catalina.filters.CSRF_NONCE_PARAM_NAME", this.nonceRequestParameterName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/* 113 */     ServletResponse wResponse = null;
/*     */     
/* 115 */     if (((request instanceof HttpServletRequest)) && ((response instanceof HttpServletResponse)))
/*     */     {
/*     */ 
/* 118 */       HttpServletRequest req = (HttpServletRequest)request;
/* 119 */       HttpServletResponse res = (HttpServletResponse)response;
/*     */       
/* 121 */       boolean skipNonceCheck = false;
/*     */       
/* 123 */       if (("GET".equals(req.getMethod())) && 
/* 124 */         (this.entryPoints.contains(getRequestedPath(req)))) {
/* 125 */         if (this.log.isTraceEnabled()) {
/* 126 */           this.log.trace("Skipping CSRF nonce-check for GET request to entry point " + getRequestedPath(req));
/*     */         }
/*     */         
/* 129 */         skipNonceCheck = true;
/*     */       }
/*     */       
/* 132 */       HttpSession session = req.getSession(false);
/*     */       
/*     */ 
/*     */ 
/* 136 */       LruCache<String> nonceCache = session == null ? null : (LruCache)session.getAttribute("org.apache.catalina.filters.CSRF_NONCE");
/*     */       
/*     */ 
/* 139 */       if (!skipNonceCheck)
/*     */       {
/* 141 */         String previousNonce = req.getParameter(this.nonceRequestParameterName);
/*     */         
/* 143 */         if (previousNonce == null) {
/* 144 */           if (this.log.isDebugEnabled()) {
/* 145 */             this.log.debug("Rejecting request for " + getRequestedPath(req) + ", session " + (null == session ? "(none)" : session
/*     */             
/* 147 */               .getId()) + " with no CSRF nonce found in request");
/*     */           }
/*     */           
/*     */ 
/* 151 */           res.sendError(getDenyStatus());
/* 152 */           return; }
/* 153 */         if (nonceCache == null) {
/* 154 */           if (this.log.isDebugEnabled()) {
/* 155 */             this.log.debug("Rejecting request for " + getRequestedPath(req) + ", session " + (null == session ? "(none)" : session
/*     */             
/* 157 */               .getId()) + " due to empty / missing nonce cache");
/*     */           }
/*     */           
/*     */ 
/* 161 */           res.sendError(getDenyStatus());
/* 162 */           return; }
/* 163 */         if (!nonceCache.contains(previousNonce)) {
/* 164 */           if (this.log.isDebugEnabled()) {
/* 165 */             this.log.debug("Rejecting request for " + getRequestedPath(req) + ", session " + (null == session ? "(none)" : session
/*     */             
/* 167 */               .getId()) + " due to invalid nonce " + previousNonce);
/*     */           }
/*     */           
/*     */ 
/* 171 */           res.sendError(getDenyStatus());
/* 172 */           return;
/*     */         }
/* 174 */         if (this.log.isTraceEnabled()) {
/* 175 */           this.log.trace("Allowing request to " + getRequestedPath(req) + " with valid CSRF nonce " + previousNonce);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 180 */       if (nonceCache == null) {
/* 181 */         if (this.log.isDebugEnabled()) {
/* 182 */           this.log.debug("Creating new CSRF nonce cache with size=" + this.nonceCacheSize + " for session " + (null == session ? "(will create)" : session.getId()));
/*     */         }
/*     */         
/* 185 */         nonceCache = new LruCache(this.nonceCacheSize);
/* 186 */         if (session == null) {
/* 187 */           if (this.log.isDebugEnabled()) {
/* 188 */             this.log.debug("Creating new session to store CSRF nonce cache");
/*     */           }
/*     */           
/* 191 */           session = req.getSession(true);
/*     */         }
/* 193 */         session.setAttribute("org.apache.catalina.filters.CSRF_NONCE", nonceCache);
/*     */       }
/*     */       
/*     */ 
/* 197 */       String newNonce = generateNonce();
/*     */       
/* 199 */       nonceCache.add(newNonce);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 204 */       request.setAttribute("org.apache.catalina.filters.CSRF_REQUEST_NONCE", newNonce);
/*     */       
/* 206 */       wResponse = new CsrfResponseWrapper(res, this.nonceRequestParameterName, newNonce);
/*     */     } else {
/* 208 */       wResponse = response;
/*     */     }
/*     */     
/* 211 */     chain.doFilter(request, wResponse);
/*     */   }
/*     */   
/*     */   protected static class CsrfResponseWrapper
/*     */     extends HttpServletResponseWrapper
/*     */   {
/*     */     private final String nonceRequestParameterName;
/*     */     private final String nonce;
/*     */     
/*     */     public CsrfResponseWrapper(HttpServletResponse response, String nonceRequestParameterName, String nonce)
/*     */     {
/* 222 */       super();
/* 223 */       this.nonceRequestParameterName = nonceRequestParameterName;
/* 224 */       this.nonce = nonce;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public String encodeRedirectUrl(String url)
/*     */     {
/* 230 */       return encodeRedirectURL(url);
/*     */     }
/*     */     
/*     */     public String encodeRedirectURL(String url)
/*     */     {
/* 235 */       return addNonce(super.encodeRedirectURL(url));
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public String encodeUrl(String url)
/*     */     {
/* 241 */       return encodeURL(url);
/*     */     }
/*     */     
/*     */     public String encodeURL(String url)
/*     */     {
/* 246 */       return addNonce(super.encodeURL(url));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private String addNonce(String url)
/*     */     {
/* 256 */       if ((url == null) || (this.nonce == null)) {
/* 257 */         return url;
/*     */       }
/*     */       
/* 260 */       String path = url;
/* 261 */       String query = "";
/* 262 */       String anchor = "";
/* 263 */       int pound = path.indexOf('#');
/* 264 */       if (pound >= 0) {
/* 265 */         anchor = path.substring(pound);
/* 266 */         path = path.substring(0, pound);
/*     */       }
/* 268 */       int question = path.indexOf('?');
/* 269 */       if (question >= 0) {
/* 270 */         query = path.substring(question);
/* 271 */         path = path.substring(0, question);
/*     */       }
/* 273 */       StringBuilder sb = new StringBuilder(path);
/* 274 */       if (query.length() > 0) {
/* 275 */         sb.append(query);
/* 276 */         sb.append('&');
/*     */       } else {
/* 278 */         sb.append('?');
/*     */       }
/* 280 */       sb.append(this.nonceRequestParameterName);
/* 281 */       sb.append('=');
/* 282 */       sb.append(this.nonce);
/* 283 */       sb.append(anchor);
/* 284 */       return sb.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected static class LruCache<T>
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final Map<T, T> cache;
/*     */     
/*     */     public LruCache(final int cacheSize)
/*     */     {
/* 297 */       this.cache = new LinkedHashMap() {
/*     */         private static final long serialVersionUID = 1L;
/*     */         
/*     */         protected boolean removeEldestEntry(Map.Entry<T, T> eldest) {
/* 301 */           if (size() > cacheSize) {
/* 302 */             return true;
/*     */           }
/* 304 */           return false;
/*     */         }
/*     */       };
/*     */     }
/*     */     
/*     */     public void add(T key) {
/* 310 */       synchronized (this.cache) {
/* 311 */         this.cache.put(key, null);
/*     */       }
/*     */     }
/*     */     
/*     */     /* Error */
/*     */     public boolean contains(T key)
/*     */     {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: getfield 4	org/apache/catalina/filters/CsrfPreventionFilter$LruCache:cache	Ljava/util/Map;
/*     */       //   4: dup
/*     */       //   5: astore_2
/*     */       //   6: monitorenter
/*     */       //   7: aload_0
/*     */       //   8: getfield 4	org/apache/catalina/filters/CsrfPreventionFilter$LruCache:cache	Ljava/util/Map;
/*     */       //   11: aload_1
/*     */       //   12: invokeinterface 6 2 0
/*     */       //   17: aload_2
/*     */       //   18: monitorexit
/*     */       //   19: ireturn
/*     */       //   20: astore_3
/*     */       //   21: aload_2
/*     */       //   22: monitorexit
/*     */       //   23: aload_3
/*     */       //   24: athrow
/*     */       // Line number table:
/*     */       //   Java source line #316	-> byte code offset #0
/*     */       //   Java source line #317	-> byte code offset #7
/*     */       //   Java source line #318	-> byte code offset #20
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	25	0	this	LruCache<T>
/*     */       //   0	25	1	key	T
/*     */       //   5	17	2	Ljava/lang/Object;	Object
/*     */       //   20	4	3	localObject1	Object
/*     */       // Exception table:
/*     */       //   from	to	target	type
/*     */       //   7	19	20	finally
/*     */       //   20	23	20	finally
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\filters\CsrfPreventionFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */