/*     */ package org.apache.catalina.startup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Host;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UserConfig
/*     */   implements LifecycleListener
/*     */ {
/*  51 */   private static final Log log = LogFactory.getLog(UserConfig.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */   private String configClass = "org.apache.catalina.startup.ContextConfig";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private String contextClass = "org.apache.catalina.core.StandardContext";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   private String directoryName = "public_html";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */   private String homeBase = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */   private Host host = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */   private static final StringManager sm = StringManager.getManager("org.apache.catalina.startup");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */   private String userClass = "org.apache.catalina.startup.PasswdUserDatabase";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */   Pattern allow = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 108 */   Pattern deny = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getConfigClass()
/*     */   {
/* 117 */     return this.configClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConfigClass(String configClass)
/*     */   {
/* 127 */     this.configClass = configClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContextClass()
/*     */   {
/* 135 */     return this.contextClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContextClass(String contextClass)
/*     */   {
/* 145 */     this.contextClass = contextClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDirectoryName()
/*     */   {
/* 153 */     return this.directoryName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDirectoryName(String directoryName)
/*     */   {
/* 163 */     this.directoryName = directoryName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHomeBase()
/*     */   {
/* 171 */     return this.homeBase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHomeBase(String homeBase)
/*     */   {
/* 181 */     this.homeBase = homeBase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUserClass()
/*     */   {
/* 189 */     return this.userClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserClass(String userClass)
/*     */   {
/* 198 */     this.userClass = userClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getAllow()
/*     */   {
/* 205 */     if (this.allow == null) {
/* 206 */       return null;
/*     */     }
/* 208 */     return this.allow.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllow(String allow)
/*     */   {
/* 218 */     if ((allow == null) || (allow.length() == 0)) {
/* 219 */       this.allow = null;
/*     */     } else {
/* 221 */       this.allow = Pattern.compile(allow);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDeny()
/*     */   {
/* 230 */     if (this.deny == null) {
/* 231 */       return null;
/*     */     }
/* 233 */     return this.deny.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDeny(String deny)
/*     */   {
/* 243 */     if ((deny == null) || (deny.length() == 0)) {
/* 244 */       this.deny = null;
/*     */     } else {
/* 246 */       this.deny = Pattern.compile(deny);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void lifecycleEvent(LifecycleEvent event)
/*     */   {
/*     */     try
/*     */     {
/* 263 */       this.host = ((Host)event.getLifecycle());
/*     */     } catch (ClassCastException e) {
/* 265 */       log.error(sm.getString("hostConfig.cce", new Object[] { event.getLifecycle() }), e);
/* 266 */       return;
/*     */     }
/*     */     
/*     */ 
/* 270 */     if (event.getType().equals("start")) {
/* 271 */       start();
/* 272 */     } else if (event.getType().equals("stop")) {
/* 273 */       stop();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void deploy()
/*     */   {
/* 288 */     if (this.host.getLogger().isDebugEnabled()) {
/* 289 */       this.host.getLogger().debug(sm.getString("userConfig.deploying"));
/*     */     }
/*     */     
/*     */ 
/* 293 */     UserDatabase database = null;
/*     */     try {
/* 295 */       Class<?> clazz = Class.forName(this.userClass);
/* 296 */       database = (UserDatabase)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 297 */       database.setUserConfig(this);
/*     */     } catch (Exception e) {
/* 299 */       this.host.getLogger().error(sm.getString("userConfig.database"), e);
/* 300 */       return;
/*     */     }
/*     */     
/* 303 */     ExecutorService executor = this.host.getStartStopExecutor();
/* 304 */     List<Future<?>> results = new ArrayList();
/*     */     
/*     */ 
/* 307 */     Enumeration<String> users = database.getUsers();
/* 308 */     String user; while (users.hasMoreElements()) {
/* 309 */       user = (String)users.nextElement();
/* 310 */       if (isDeployAllowed(user))
/*     */       {
/*     */ 
/* 313 */         String home = database.getHome(user);
/* 314 */         results.add(executor.submit(new DeployUserDirectory(this, user, home)));
/*     */       }
/*     */     }
/* 317 */     for (Future<?> result : results) {
/*     */       try {
/* 319 */         result.get();
/*     */       } catch (Exception e) {
/* 321 */         this.host.getLogger().error(sm.getString("userConfig.deploy.threaded.error"), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void deploy(String user, String home)
/*     */   {
/* 337 */     String contextPath = "/~" + user;
/* 338 */     if (this.host.findChild(contextPath) != null) {
/* 339 */       return;
/*     */     }
/* 341 */     File app = new File(home, this.directoryName);
/* 342 */     if ((!app.exists()) || (!app.isDirectory())) {
/* 343 */       return;
/*     */     }
/*     */     
/* 346 */     this.host.getLogger().info(sm.getString("userConfig.deploy", new Object[] { user }));
/*     */     
/*     */     try
/*     */     {
/* 350 */       Class<?> clazz = Class.forName(this.contextClass);
/* 351 */       Context context = (Context)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 352 */       context.setPath(contextPath);
/* 353 */       context.setDocBase(app.toString());
/* 354 */       clazz = Class.forName(this.configClass);
/* 355 */       LifecycleListener listener = (LifecycleListener)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 356 */       context.addLifecycleListener(listener);
/* 357 */       this.host.addChild(context);
/*     */     } catch (Exception e) {
/* 359 */       this.host.getLogger().error(sm.getString("userConfig.error", new Object[] { user }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void start()
/*     */   {
/* 370 */     if (this.host.getLogger().isDebugEnabled()) {
/* 371 */       this.host.getLogger().debug(sm.getString("userConfig.start"));
/*     */     }
/*     */     
/* 374 */     deploy();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void stop()
/*     */   {
/* 384 */     if (this.host.getLogger().isDebugEnabled()) {
/* 385 */       this.host.getLogger().debug(sm.getString("userConfig.stop"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isDeployAllowed(String user)
/*     */   {
/* 397 */     if ((this.deny != null) && (this.deny.matcher(user).matches())) {
/* 398 */       return false;
/*     */     }
/* 400 */     if (this.allow != null) {
/* 401 */       if (this.allow.matcher(user).matches()) {
/* 402 */         return true;
/*     */       }
/* 404 */       return false;
/*     */     }
/*     */     
/* 407 */     return true;
/*     */   }
/*     */   
/*     */   private static class DeployUserDirectory implements Runnable
/*     */   {
/*     */     private UserConfig config;
/*     */     private String user;
/*     */     private String home;
/*     */     
/*     */     public DeployUserDirectory(UserConfig config, String user, String home) {
/* 417 */       this.config = config;
/* 418 */       this.user = user;
/* 419 */       this.home = home;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 424 */       this.config.deploy(this.user, this.home);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\startup\UserConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */