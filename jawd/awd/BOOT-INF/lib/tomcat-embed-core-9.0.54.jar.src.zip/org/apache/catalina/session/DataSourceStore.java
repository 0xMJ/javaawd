/*     */ package org.apache.catalina.session;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.Manager;
/*     */ import org.apache.catalina.Session;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSourceStore
/*     */   extends JDBCStore
/*     */ {
/*     */   public String[] expiredKeys()
/*     */     throws IOException
/*     */   {
/*  58 */     return keys(true);
/*     */   }
/*     */   
/*     */   public String[] keys() throws IOException
/*     */   {
/*  63 */     return keys(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] keys(boolean expiredOnly)
/*     */     throws IOException
/*     */   {
/*  78 */     String[] keys = null;
/*  79 */     int numberOfTries = 2;
/*  80 */     while (numberOfTries > 0)
/*     */     {
/*  82 */       Connection _conn = getConnection();
/*  83 */       if (_conn == null) {
/*  84 */         return new String[0];
/*     */       }
/*     */       try
/*     */       {
/*  88 */         String keysSql = "SELECT " + this.sessionIdCol + " FROM " + this.sessionTable + " WHERE " + this.sessionAppCol + " = ?";
/*     */         
/*  90 */         if (expiredOnly) {
/*  91 */           keysSql = keysSql + " AND (" + this.sessionLastAccessedCol + " + " + this.sessionMaxInactiveCol + " * 1000 < ?)";
/*     */         }
/*     */         
/*  94 */         PreparedStatement preparedKeysSql = _conn.prepareStatement(keysSql);Throwable localThrowable6 = null;
/*  95 */         try { preparedKeysSql.setString(1, getName());
/*  96 */           if (expiredOnly) {
/*  97 */             preparedKeysSql.setLong(2, System.currentTimeMillis());
/*     */           }
/*  99 */           ResultSet rst = preparedKeysSql.executeQuery();Throwable localThrowable7 = null;
/* 100 */           try { List<String> tmpkeys = new ArrayList();
/* 101 */             if (rst != null) {
/* 102 */               while (rst.next()) {
/* 103 */                 tmpkeys.add(rst.getString(1));
/*     */               }
/*     */             }
/* 106 */             keys = (String[])tmpkeys.toArray(new String[0]);
/*     */             
/* 108 */             numberOfTries = 0;
/*     */           }
/*     */           catch (Throwable localThrowable1)
/*     */           {
/*  99 */             localThrowable7 = localThrowable1;throw localThrowable1;
/*     */           }
/*     */           finally {}
/*     */         }
/*     */         catch (Throwable localThrowable4)
/*     */         {
/*  94 */           localThrowable6 = localThrowable4;throw localThrowable4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */           if (preparedKeysSql != null) if (localThrowable6 != null) try { preparedKeysSql.close(); } catch (Throwable localThrowable5) {} else preparedKeysSql.close();
/*     */         }
/* 112 */       } catch (SQLException e) { this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/* 113 */         keys = new String[0];
/*     */       }
/*     */       finally {
/* 116 */         release(_conn);
/*     */       }
/* 118 */       numberOfTries--;
/*     */     }
/* 120 */     return keys;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSize()
/*     */     throws IOException
/*     */   {
/* 134 */     int size = 0;
/* 135 */     String sizeSql = "SELECT COUNT(" + this.sessionIdCol + ") FROM " + this.sessionTable + " WHERE " + this.sessionAppCol + " = ?";
/*     */     
/*     */ 
/*     */ 
/* 139 */     int numberOfTries = 2;
/* 140 */     while (numberOfTries > 0) {
/* 141 */       Connection _conn = getConnection();
/*     */       
/* 143 */       if (_conn == null) {
/* 144 */         return size;
/*     */       }
/*     */       try {
/* 147 */         PreparedStatement preparedSizeSql = _conn.prepareStatement(sizeSql);Throwable localThrowable6 = null;
/* 148 */         try { preparedSizeSql.setString(1, getName());
/* 149 */           ResultSet rst = preparedSizeSql.executeQuery();Throwable localThrowable7 = null;
/* 150 */           try { if (rst.next()) {
/* 151 */               size = rst.getInt(1);
/*     */             }
/*     */             
/* 154 */             numberOfTries = 0;
/*     */           }
/*     */           catch (Throwable localThrowable1)
/*     */           {
/* 149 */             localThrowable7 = localThrowable1;throw localThrowable1;
/*     */           }
/*     */           finally {}
/*     */         }
/*     */         catch (Throwable localThrowable4)
/*     */         {
/* 147 */           localThrowable6 = localThrowable4;throw localThrowable4;
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/*     */ 
/* 156 */           if (preparedSizeSql != null) if (localThrowable6 != null) try { preparedSizeSql.close(); } catch (Throwable localThrowable5) {} else preparedSizeSql.close();
/* 157 */         } } catch (SQLException e) { this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*     */       } finally {
/* 159 */         release(_conn);
/*     */       }
/* 161 */       numberOfTries--;
/*     */     }
/* 163 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Session load(String id)
/*     */     throws ClassNotFoundException, IOException
/*     */   {
/* 177 */     StandardSession _session = null;
/* 178 */     org.apache.catalina.Context context = getManager().getContext();
/* 179 */     Log contextLog = context.getLogger();
/*     */     
/* 181 */     int numberOfTries = 2;
/* 182 */     String loadSql = "SELECT " + this.sessionIdCol + ", " + this.sessionDataCol + " FROM " + this.sessionTable + " WHERE " + this.sessionIdCol + " = ? AND " + this.sessionAppCol + " = ?";
/*     */     
/*     */ 
/*     */ 
/* 186 */     while (numberOfTries > 0) {
/* 187 */       Connection _conn = getConnection();
/* 188 */       if (_conn == null) {
/* 189 */         return null;
/*     */       }
/*     */       
/* 192 */       ClassLoader oldThreadContextCL = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*     */       try {
/* 194 */         PreparedStatement preparedLoadSql = _conn.prepareStatement(loadSql);Throwable localThrowable9 = null;
/* 195 */         try { preparedLoadSql.setString(1, id);
/* 196 */           preparedLoadSql.setString(2, getName());
/* 197 */           ResultSet rst = preparedLoadSql.executeQuery();Throwable localThrowable10 = null;
/* 198 */           try { if (rst.next())
/*     */             {
/* 200 */               ObjectInputStream ois = getObjectInputStream(rst.getBinaryStream(2));Throwable localThrowable11 = null;
/* 201 */               try { if (contextLog.isDebugEnabled()) {
/* 202 */                   contextLog.debug(sm.getString(
/* 203 */                     getStoreName() + ".loading", new Object[] { id, this.sessionTable }));
/*     */                 }
/*     */                 
/* 206 */                 _session = (StandardSession)this.manager.createEmptySession();
/* 207 */                 _session.readObjectData(ois);
/* 208 */                 _session.setManager(this.manager);
/*     */               }
/*     */               catch (Throwable localThrowable1)
/*     */               {
/* 199 */                 localThrowable11 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */               }
/*     */               finally
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/* 209 */                 if (ois != null) if (localThrowable11 != null) try { ois.close(); } catch (Throwable localThrowable2) { localThrowable11.addSuppressed(localThrowable2); } else ois.close();
/* 210 */               } } else if (context.getLogger().isDebugEnabled()) {
/* 211 */               contextLog.debug(getStoreName() + ": No persisted data object found");
/*     */             }
/*     */             
/* 214 */             numberOfTries = 0;
/*     */           }
/*     */           catch (Throwable localThrowable4)
/*     */           {
/* 197 */             localThrowable10 = localThrowable4;throw localThrowable4;
/*     */           }
/*     */           finally {}
/*     */         }
/*     */         catch (Throwable localThrowable7)
/*     */         {
/* 194 */           localThrowable9 = localThrowable7;throw localThrowable7;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 216 */           if (preparedLoadSql != null) if (localThrowable9 != null) try { preparedLoadSql.close(); } catch (Throwable localThrowable8) { localThrowable9.addSuppressed(localThrowable8); } else preparedLoadSql.close();
/* 217 */         } } catch (SQLException e) { contextLog.error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*     */       } finally {
/* 219 */         context.unbind(Globals.IS_SECURITY_ENABLED, oldThreadContextCL);
/* 220 */         release(_conn);
/*     */       }
/* 222 */       numberOfTries--;
/*     */     }
/* 224 */     return _session;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove(String id)
/*     */     throws IOException
/*     */   {
/* 239 */     int numberOfTries = 2;
/* 240 */     while (numberOfTries > 0) {
/* 241 */       Connection _conn = getConnection();
/*     */       
/* 243 */       if (_conn == null) {
/* 244 */         return;
/*     */       }
/*     */       try
/*     */       {
/* 248 */         remove(id, _conn);
/*     */         
/* 250 */         numberOfTries = 0;
/*     */       } catch (SQLException e) {
/* 252 */         this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*     */       } finally {
/* 254 */         release(_conn);
/*     */       }
/* 256 */       numberOfTries--;
/*     */     }
/*     */     
/* 259 */     if (this.manager.getContext().getLogger().isDebugEnabled()) {
/* 260 */       this.manager.getContext().getLogger().debug(sm.getString(getStoreName() + ".removing", new Object[] { id, this.sessionTable }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void remove(String id, Connection _conn)
/*     */     throws SQLException
/*     */   {
/* 274 */     String removeSql = "DELETE FROM " + this.sessionTable + " WHERE " + this.sessionIdCol + " = ?  AND " + this.sessionAppCol + " = ?";
/*     */     
/*     */ 
/* 277 */     PreparedStatement preparedRemoveSql = _conn.prepareStatement(removeSql);Throwable localThrowable3 = null;
/* 278 */     try { preparedRemoveSql.setString(1, id);
/* 279 */       preparedRemoveSql.setString(2, getName());
/* 280 */       preparedRemoveSql.execute();
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 277 */       localThrowable3 = localThrowable1;throw localThrowable1;
/*     */     }
/*     */     finally
/*     */     {
/* 281 */       if (preparedRemoveSql != null) { if (localThrowable3 != null) try { preparedRemoveSql.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else { preparedRemoveSql.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void clear()
/*     */     throws IOException
/*     */   {
/* 291 */     String clearSql = "DELETE FROM " + this.sessionTable + " WHERE " + this.sessionAppCol + " = ?";
/*     */     
/*     */ 
/* 294 */     int numberOfTries = 2;
/* 295 */     while (numberOfTries > 0) {
/* 296 */       Connection _conn = getConnection();
/* 297 */       if (_conn == null) {
/* 298 */         return;
/*     */       }
/*     */       try {
/* 301 */         PreparedStatement preparedClearSql = _conn.prepareStatement(clearSql);Throwable localThrowable3 = null;
/* 302 */         try { preparedClearSql.setString(1, getName());
/* 303 */           preparedClearSql.execute();
/*     */           
/* 305 */           numberOfTries = 0;
/*     */         }
/*     */         catch (Throwable localThrowable1)
/*     */         {
/* 301 */           localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/* 306 */           if (preparedClearSql != null) if (localThrowable3 != null) try { preparedClearSql.close(); } catch (Throwable localThrowable2) {} else preparedClearSql.close();
/* 307 */         } } catch (SQLException e) { this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*     */       } finally {
/* 309 */         release(_conn);
/*     */       }
/* 311 */       numberOfTries--;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void save(Session session)
/*     */     throws IOException
/*     */   {
/* 323 */     ByteArrayOutputStream bos = null;
/* 324 */     String saveSql = "INSERT INTO " + this.sessionTable + " (" + this.sessionIdCol + ", " + this.sessionAppCol + ", " + this.sessionDataCol + ", " + this.sessionValidCol + ", " + this.sessionMaxInactiveCol + ", " + this.sessionLastAccessedCol + ") VALUES (?, ?, ?, ?, ?, ?)";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 331 */     synchronized (session) {
/* 332 */       int numberOfTries = 2;
/* 333 */       while (numberOfTries > 0) {
/* 334 */         Connection _conn = getConnection();
/* 335 */         if (_conn == null) {
/* 336 */           return;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 343 */           remove(session.getIdInternal(), _conn);
/*     */           
/* 345 */           bos = new ByteArrayOutputStream();
/* 346 */           ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(bos));Throwable localThrowable12 = null;
/*     */           try {
/* 348 */             ((StandardSession)session).writeObjectData(oos);
/*     */           }
/*     */           catch (Throwable localThrowable1)
/*     */           {
/* 346 */             localThrowable12 = localThrowable1;throw localThrowable1;
/*     */           }
/*     */           finally {
/* 349 */             if (oos != null) if (localThrowable12 != null) try { oos.close(); } catch (Throwable localThrowable2) {} else oos.close(); }
/* 350 */           byte[] obs = bos.toByteArray();
/* 351 */           int size = obs.length;
/* 352 */           ByteArrayInputStream bis = new ByteArrayInputStream(obs, 0, size);Throwable localThrowable13 = null;
/* 353 */           try { InputStream in = new BufferedInputStream(bis, size);Throwable localThrowable14 = null;
/* 354 */             try { PreparedStatement preparedSaveSql = _conn.prepareStatement(saveSql);Throwable localThrowable15 = null;
/* 355 */               try { preparedSaveSql.setString(1, session.getIdInternal());
/* 356 */                 preparedSaveSql.setString(2, getName());
/* 357 */                 preparedSaveSql.setBinaryStream(3, in, size);
/* 358 */                 preparedSaveSql.setString(4, session.isValid() ? "1" : "0");
/* 359 */                 preparedSaveSql.setInt(5, session.getMaxInactiveInterval());
/* 360 */                 preparedSaveSql.setLong(6, session.getLastAccessedTime());
/* 361 */                 preparedSaveSql.execute();
/*     */                 
/* 363 */                 numberOfTries = 0;
/*     */               }
/*     */               catch (Throwable localThrowable4)
/*     */               {
/* 352 */                 localThrowable15 = localThrowable4;throw localThrowable4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               }
/*     */               finally
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 364 */                 if (preparedSaveSql != null) if (localThrowable15 != null) try { preparedSaveSql.close(); } catch (Throwable localThrowable5) {} else preparedSaveSql.close();
/*     */               }
/*     */             }
/*     */             catch (Throwable localThrowable7)
/*     */             {
/* 352 */               localThrowable14 = localThrowable7;throw localThrowable7; } finally {} } catch (Throwable localThrowable10) { localThrowable13 = localThrowable10;throw localThrowable10;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*     */           finally
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 364 */             if (bis != null) if (localThrowable13 != null) try { bis.close(); } catch (Throwable localThrowable11) {} else bis.close();
/*     */           }
/* 366 */         } catch (SQLException e) { this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".SQLException", new Object[] { e }));
/*     */         }
/*     */         catch (IOException localIOException) {}finally
/*     */         {
/* 370 */           release(_conn);
/*     */         }
/* 372 */         numberOfTries--;
/*     */       }
/*     */     }
/*     */     
/* 376 */     if (this.manager.getContext().getLogger().isDebugEnabled()) {
/* 377 */       this.manager.getContext().getLogger().debug(sm.getString(getStoreName() + ".saving", new Object[] {session
/* 378 */         .getIdInternal(), this.sessionTable }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Connection open()
/*     */     throws SQLException
/*     */   {
/* 395 */     if ((this.dataSourceName != null) && (this.dataSource == null)) {
/* 396 */       org.apache.catalina.Context context = getManager().getContext();
/* 397 */       ClassLoader oldThreadContextCL = null;
/* 398 */       if (getLocalDataSource()) {
/* 399 */         oldThreadContextCL = context.bind(Globals.IS_SECURITY_ENABLED, null);
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 404 */         javax.naming.Context initCtx = new InitialContext();
/* 405 */         javax.naming.Context envCtx = (javax.naming.Context)initCtx.lookup("java:comp/env");
/* 406 */         this.dataSource = ((DataSource)envCtx.lookup(this.dataSourceName));
/*     */       } catch (NamingException e) {
/* 408 */         context.getLogger().error(sm
/* 409 */           .getString(getStoreName() + ".wrongDataSource", new Object[] { this.dataSourceName }), e);
/*     */       }
/*     */       finally {
/* 412 */         if (getLocalDataSource()) {
/* 413 */           context.unbind(Globals.IS_SECURITY_ENABLED, oldThreadContextCL);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 418 */     if (this.dataSource != null) {
/* 419 */       return this.dataSource.getConnection();
/*     */     }
/* 421 */     throw new IllegalStateException(sm.getString(getStoreName() + ".missingDataSource"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void close(Connection dbConnection)
/*     */   {
/* 434 */     if (dbConnection == null) {
/* 435 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 440 */       if (!dbConnection.getAutoCommit()) {
/* 441 */         dbConnection.commit();
/*     */       }
/*     */     } catch (SQLException e) {
/* 444 */       this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".commitSQLException"), e);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 449 */       dbConnection.close();
/*     */     } catch (SQLException e) {
/* 451 */       this.manager.getContext().getLogger().error(sm.getString(getStoreName() + ".close", new Object[] { e.toString() }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\session\DataSourceStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */