/*     */ package org.apache.catalina.webresources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.WebResource;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.util.ResourceSet;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractArchiveResourceSet
/*     */   extends AbstractResourceSet
/*     */ {
/*     */   private URL baseUrl;
/*     */   private String baseUrlString;
/*  39 */   private JarFile archive = null;
/*  40 */   protected Map<String, JarEntry> archiveEntries = null;
/*  41 */   protected final Object archiveLock = new Object();
/*  42 */   private long archiveUseCount = 0L;
/*     */   private JarContents jarContents;
/*     */   
/*     */   protected final void setBaseUrl(URL baseUrl) {
/*  46 */     this.baseUrl = baseUrl;
/*  47 */     if (baseUrl == null) {
/*  48 */       this.baseUrlString = null;
/*     */     } else {
/*  50 */       this.baseUrlString = baseUrl.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public final URL getBaseUrl()
/*     */   {
/*  56 */     return this.baseUrl;
/*     */   }
/*     */   
/*     */   protected final String getBaseUrlString() {
/*  60 */     return this.baseUrlString;
/*     */   }
/*     */   
/*     */ 
/*     */   public final String[] list(String path)
/*     */   {
/*  66 */     checkPath(path);
/*  67 */     String webAppMount = getWebAppMount();
/*     */     
/*  69 */     ArrayList<String> result = new ArrayList();
/*  70 */     String pathInJar; if (path.startsWith(webAppMount))
/*     */     {
/*  72 */       pathInJar = getInternalPath() + path.substring(webAppMount.length());
/*     */       
/*  74 */       if ((pathInJar.length() > 0) && (pathInJar.charAt(0) == '/')) {
/*  75 */         pathInJar = pathInJar.substring(1);
/*     */       }
/*  77 */       for (String name : getArchiveEntries(false).keySet()) {
/*  78 */         if ((name.length() > pathInJar.length()) && 
/*  79 */           (name.startsWith(pathInJar))) {
/*  80 */           if (name.charAt(name.length() - 1) == '/') {
/*  81 */             name = name.substring(pathInJar
/*  82 */               .length(), name.length() - 1);
/*     */           } else {
/*  84 */             name = name.substring(pathInJar.length());
/*     */           }
/*  86 */           if (name.length() != 0)
/*     */           {
/*     */ 
/*  89 */             if (name.charAt(0) == '/') {
/*  90 */               name = name.substring(1);
/*     */             }
/*  92 */             if ((name.length() > 0) && (name.lastIndexOf('/') == -1))
/*  93 */               result.add(name);
/*     */           }
/*     */         }
/*     */       }
/*     */     } else {
/*  98 */       if (!path.endsWith("/")) {
/*  99 */         path = path + "/";
/*     */       }
/* 101 */       if (webAppMount.startsWith(path)) {
/* 102 */         int i = webAppMount.indexOf('/', path.length());
/* 103 */         if (i == -1) {
/* 104 */           return new String[] { webAppMount.substring(path.length()) };
/*     */         }
/* 106 */         return new String[] {webAppMount
/* 107 */           .substring(path.length(), i) };
/*     */       }
/*     */     }
/*     */     
/* 111 */     return (String[])result.toArray(new String[0]);
/*     */   }
/*     */   
/*     */   public final Set<String> listWebAppPaths(String path)
/*     */   {
/* 116 */     checkPath(path);
/* 117 */     String webAppMount = getWebAppMount();
/*     */     
/* 119 */     ResourceSet<String> result = new ResourceSet();
/* 120 */     String pathInJar; if (path.startsWith(webAppMount))
/*     */     {
/* 122 */       pathInJar = getInternalPath() + path.substring(webAppMount.length());
/*     */       
/*     */ 
/* 125 */       if (pathInJar.length() > 0) {
/* 126 */         if (pathInJar.charAt(pathInJar.length() - 1) != '/') {
/* 127 */           pathInJar = pathInJar.substring(1) + '/';
/*     */         }
/* 129 */         if (pathInJar.charAt(0) == '/') {
/* 130 */           pathInJar = pathInJar.substring(1);
/*     */         }
/*     */       }
/*     */       
/* 134 */       for (String name : getArchiveEntries(false).keySet()) {
/* 135 */         if ((name.length() > pathInJar.length()) && (name.startsWith(pathInJar))) {
/* 136 */           int nextSlash = name.indexOf('/', pathInJar.length());
/* 137 */           if ((nextSlash != -1) && (nextSlash != name.length() - 1)) {
/* 138 */             name = name.substring(0, nextSlash + 1);
/*     */           }
/* 140 */           result.add(webAppMount + '/' + name.substring(getInternalPath().length()));
/*     */         }
/*     */       }
/*     */     } else {
/* 144 */       if (!path.endsWith("/")) {
/* 145 */         path = path + "/";
/*     */       }
/* 147 */       if (webAppMount.startsWith(path)) {
/* 148 */         int i = webAppMount.indexOf('/', path.length());
/* 149 */         if (i == -1) {
/* 150 */           result.add(webAppMount + "/");
/*     */         } else {
/* 152 */           result.add(webAppMount.substring(0, i + 1));
/*     */         }
/*     */       }
/*     */     }
/* 156 */     result.setLocked(true);
/* 157 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Map<String, JarEntry> getArchiveEntries(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract JarEntry getArchiveEntry(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean mkdir(String path)
/*     */   {
/* 190 */     checkPath(path);
/*     */     
/* 192 */     return false;
/*     */   }
/*     */   
/*     */   public final boolean write(String path, InputStream is, boolean overwrite)
/*     */   {
/* 197 */     checkPath(path);
/*     */     
/* 199 */     if (is == null)
/*     */     {
/* 201 */       throw new NullPointerException(sm.getString("dirResourceSet.writeNpe"));
/*     */     }
/*     */     
/* 204 */     return false;
/*     */   }
/*     */   
/*     */   public final WebResource getResource(String path)
/*     */   {
/* 209 */     checkPath(path);
/* 210 */     String webAppMount = getWebAppMount();
/* 211 */     WebResourceRoot root = getRoot();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 217 */     if ((this.jarContents != null) && (!this.jarContents.mightContainResource(path, webAppMount))) {
/* 218 */       return new EmptyResource(root, path);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 239 */     if (path.startsWith(webAppMount)) {
/* 240 */       String pathInJar = getInternalPath() + path.substring(webAppMount
/* 241 */         .length());
/*     */       
/* 243 */       if ((pathInJar.length() > 0) && (pathInJar.charAt(0) == '/')) {
/* 244 */         pathInJar = pathInJar.substring(1);
/*     */       }
/* 246 */       if (pathInJar.equals(""))
/*     */       {
/*     */ 
/* 249 */         if (!path.endsWith("/")) {
/* 250 */           path = path + "/";
/*     */         }
/* 252 */         return new JarResourceRoot(root, new File(getBase()), this.baseUrlString, path);
/*     */       }
/*     */       
/* 255 */       JarEntry jarEntry = null;
/* 256 */       if (isMultiRelease())
/*     */       {
/* 258 */         jarEntry = getArchiveEntry(pathInJar);
/*     */       } else {
/* 260 */         Map<String, JarEntry> jarEntries = getArchiveEntries(true);
/* 261 */         if (pathInJar.charAt(pathInJar.length() - 1) != '/') {
/* 262 */           if (jarEntries == null) {
/* 263 */             jarEntry = getArchiveEntry(pathInJar + '/');
/*     */           } else {
/* 265 */             jarEntry = (JarEntry)jarEntries.get(pathInJar + '/');
/*     */           }
/* 267 */           if (jarEntry != null) {
/* 268 */             path = path + '/';
/*     */           }
/*     */         }
/* 271 */         if (jarEntry == null) {
/* 272 */           if (jarEntries == null) {
/* 273 */             jarEntry = getArchiveEntry(pathInJar);
/*     */           } else {
/* 275 */             jarEntry = (JarEntry)jarEntries.get(pathInJar);
/*     */           }
/*     */         }
/*     */       }
/* 279 */       if (jarEntry == null) {
/* 280 */         return new EmptyResource(root, path);
/*     */       }
/* 282 */       return createArchiveResource(jarEntry, path, getManifest());
/*     */     }
/*     */     
/*     */ 
/* 286 */     return new EmptyResource(root, path);
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract boolean isMultiRelease();
/*     */   
/*     */ 
/*     */   protected abstract WebResource createArchiveResource(JarEntry paramJarEntry, String paramString, Manifest paramManifest);
/*     */   
/*     */   public final boolean isReadOnly()
/*     */   {
/* 297 */     return true;
/*     */   }
/*     */   
/*     */   public void setReadOnly(boolean readOnly)
/*     */   {
/* 302 */     if (readOnly)
/*     */     {
/* 304 */       return;
/*     */     }
/*     */     
/*     */ 
/* 308 */     throw new IllegalArgumentException(sm.getString("abstractArchiveResourceSet.setReadOnlyFalse"));
/*     */   }
/*     */   
/*     */   protected JarFile openJarFile() throws IOException {
/* 312 */     synchronized (this.archiveLock) {
/* 313 */       if (this.archive == null) {
/* 314 */         this.archive = JreCompat.getInstance().jarFileNewInstance(getBase());
/* 315 */         WebResourceRoot root = getRoot();
/* 316 */         if ((root.getContext() != null) && (root.getContext().getUseBloomFilterForArchives())) {
/* 317 */           this.jarContents = new JarContents(this.archive);
/*     */         }
/*     */       }
/* 320 */       this.archiveUseCount += 1L;
/* 321 */       return this.archive;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void closeJarFile() {
/* 326 */     synchronized (this.archiveLock) {
/* 327 */       this.archiveUseCount -= 1L;
/*     */     }
/*     */   }
/*     */   
/*     */   public void gc()
/*     */   {
/* 333 */     synchronized (this.archiveLock) {
/* 334 */       if ((this.archive != null) && (this.archiveUseCount == 0L)) {
/*     */         try {
/* 336 */           this.archive.close();
/*     */         }
/*     */         catch (IOException localIOException) {}
/*     */         
/* 340 */         this.archive = null;
/* 341 */         this.archiveEntries = null;
/* 342 */         this.jarContents = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\webresources\AbstractArchiveResourceSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */