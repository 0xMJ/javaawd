/*     */ package org.apache.catalina.valves;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.CharArrayWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.B2CConverter;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AccessLogValve
/*     */   extends AbstractAccessLogValve
/*     */ {
/*  65 */   private static final Log log = LogFactory.getLog(AccessLogValve.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   private volatile String dateStamp = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   private String directory = "logs";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  90 */   protected volatile String prefix = "access_log";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   protected boolean rotatable = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   protected boolean renameOnRotate = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private boolean buffered = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */   protected volatile String suffix = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */   protected PrintWriter writer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */   protected SimpleDateFormat fileDateFormatter = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */   protected File currentLogFile = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 139 */   private volatile long rotationLastChecked = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 145 */   private boolean checkExists = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 150 */   protected String fileDateFormat = ".yyyy-MM-dd";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */   protected volatile String encoding = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 163 */   private int maxDays = -1;
/* 164 */   private volatile boolean checkForOldLogs = false;
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMaxDays()
/*     */   {
/* 170 */     return this.maxDays;
/*     */   }
/*     */   
/*     */   public void setMaxDays(int maxDays)
/*     */   {
/* 175 */     this.maxDays = maxDays;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDirectory()
/*     */   {
/* 183 */     return this.directory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDirectory(String directory)
/*     */   {
/* 193 */     this.directory = directory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCheckExists()
/*     */   {
/* 202 */     return this.checkExists;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCheckExists(boolean checkExists)
/*     */   {
/* 214 */     this.checkExists = checkExists;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPrefix()
/*     */   {
/* 223 */     return this.prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrefix(String prefix)
/*     */   {
/* 233 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRotatable()
/*     */   {
/* 243 */     return this.rotatable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRotatable(boolean rotatable)
/*     */   {
/* 253 */     this.rotatable = rotatable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRenameOnRotate()
/*     */   {
/* 264 */     return this.renameOnRotate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRenameOnRotate(boolean renameOnRotate)
/*     */   {
/* 275 */     this.renameOnRotate = renameOnRotate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBuffered()
/*     */   {
/* 284 */     return this.buffered;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBuffered(boolean buffered)
/*     */   {
/* 294 */     this.buffered = buffered;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSuffix()
/*     */   {
/* 302 */     return this.suffix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSuffix(String suffix)
/*     */   {
/* 312 */     this.suffix = suffix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFileDateFormat()
/*     */   {
/* 319 */     return this.fileDateFormat;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setFileDateFormat(String fileDateFormat)
/*     */   {
/*     */     String newFormat;
/*     */     
/*     */     String newFormat;
/*     */     
/* 329 */     if (fileDateFormat == null) {
/* 330 */       newFormat = "";
/*     */     } else {
/* 332 */       newFormat = fileDateFormat;
/*     */     }
/* 334 */     this.fileDateFormat = newFormat;
/*     */     
/* 336 */     synchronized (this) {
/* 337 */       this.fileDateFormatter = new SimpleDateFormat(newFormat, Locale.US);
/* 338 */       this.fileDateFormatter.setTimeZone(TimeZone.getDefault());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 349 */     return this.encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncoding(String encoding)
/*     */   {
/* 358 */     if ((encoding != null) && (encoding.length() > 0)) {
/* 359 */       this.encoding = encoding;
/*     */     } else {
/* 361 */       this.encoding = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void backgroundProcess()
/*     */   {
/* 374 */     if ((getState().isAvailable()) && (getEnabled()) && (this.writer != null) && (this.buffered))
/*     */     {
/* 376 */       this.writer.flush();
/*     */     }
/*     */     
/* 379 */     int maxDays = this.maxDays;
/* 380 */     String prefix = this.prefix;
/* 381 */     String suffix = this.suffix;
/*     */     
/* 383 */     if ((this.rotatable) && (this.checkForOldLogs) && (maxDays > 0))
/*     */     {
/* 385 */       long deleteIfLastModifiedBefore = System.currentTimeMillis() - maxDays * 24L * 60L * 60L * 1000L;
/* 386 */       File dir = getDirectoryFile();
/* 387 */       if (dir.isDirectory()) {
/* 388 */         String[] oldAccessLogs = dir.list();
/*     */         
/* 390 */         if (oldAccessLogs != null) {
/* 391 */           for (String oldAccessLog : oldAccessLogs) {
/* 392 */             boolean match = false;
/*     */             
/* 394 */             if ((prefix != null) && (prefix.length() > 0)) {
/* 395 */               if (oldAccessLog.startsWith(prefix))
/*     */               {
/*     */ 
/* 398 */                 match = true;
/*     */               }
/*     */             }
/* 401 */             else if ((suffix != null) && (suffix.length() > 0)) {
/* 402 */               if (oldAccessLog.endsWith(suffix))
/*     */               {
/*     */ 
/* 405 */                 match = true;
/*     */               }
/*     */             }
/* 408 */             else if (match) {
/* 409 */               File file = new File(dir, oldAccessLog);
/* 410 */               if ((file.isFile()) && (file.lastModified() < deleteIfLastModifiedBefore) && 
/* 411 */                 (!file.delete())) {
/* 412 */                 log.warn(sm.getString("accessLogValve.deleteFail", new Object[] {file
/* 413 */                   .getAbsolutePath() }));
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 420 */       this.checkForOldLogs = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void rotate()
/*     */   {
/* 428 */     if (this.rotatable)
/*     */     {
/* 430 */       long systime = System.currentTimeMillis();
/* 431 */       if (systime - this.rotationLastChecked > 1000L) {
/* 432 */         synchronized (this) {
/* 433 */           if (systime - this.rotationLastChecked > 1000L) {
/* 434 */             this.rotationLastChecked = systime;
/*     */             
/*     */ 
/*     */ 
/* 438 */             String tsDate = this.fileDateFormatter.format(new Date(systime));
/*     */             
/*     */ 
/* 441 */             if (!this.dateStamp.equals(tsDate)) {
/* 442 */               close(true);
/* 443 */               this.dateStamp = tsDate;
/* 444 */               open();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean rotate(String newFileName)
/*     */   {
/* 462 */     if (this.currentLogFile != null) {
/* 463 */       File holder = this.currentLogFile;
/* 464 */       close(false);
/*     */       try {
/* 466 */         holder.renameTo(new File(newFileName));
/*     */       } catch (Throwable e) {
/* 468 */         ExceptionUtils.handleThrowable(e);
/* 469 */         log.error(sm.getString("accessLogValve.rotateFail"), e);
/*     */       }
/*     */       
/*     */ 
/* 473 */       this.dateStamp = this.fileDateFormatter.format(new Date(
/* 474 */         System.currentTimeMillis()));
/*     */       
/* 476 */       open();
/* 477 */       return true;
/*     */     }
/* 479 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private File getDirectoryFile()
/*     */   {
/* 488 */     File dir = new File(this.directory);
/* 489 */     if (!dir.isAbsolute()) {
/* 490 */       dir = new File(getContainer().getCatalinaBase(), this.directory);
/*     */     }
/* 492 */     return dir;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private File getLogFile(boolean useDateStamp)
/*     */   {
/* 506 */     File dir = getDirectoryFile();
/* 507 */     if ((!dir.mkdirs()) && (!dir.isDirectory())) {
/* 508 */       log.error(sm.getString("accessLogValve.openDirFail", new Object[] { dir }));
/*     */     }
/*     */     
/*     */     File pathname;
/*     */     File pathname;
/* 513 */     if (useDateStamp) {
/* 514 */       pathname = new File(dir.getAbsoluteFile(), this.prefix + this.dateStamp + this.suffix);
/*     */     }
/*     */     else {
/* 517 */       pathname = new File(dir.getAbsoluteFile(), this.prefix + this.suffix);
/*     */     }
/* 519 */     File parent = pathname.getParentFile();
/* 520 */     if ((!parent.mkdirs()) && (!parent.isDirectory())) {
/* 521 */       log.error(sm.getString("accessLogValve.openDirFail", new Object[] { parent }));
/*     */     }
/* 523 */     return pathname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void restore()
/*     */   {
/* 532 */     File newLogFile = getLogFile(false);
/* 533 */     File rotatedLogFile = getLogFile(true);
/* 534 */     if ((rotatedLogFile.exists()) && (!newLogFile.exists()) && 
/* 535 */       (!rotatedLogFile.equals(newLogFile))) {
/*     */       try {
/* 537 */         if (!rotatedLogFile.renameTo(newLogFile)) {
/* 538 */           log.error(sm.getString("accessLogValve.renameFail", new Object[] { rotatedLogFile, newLogFile }));
/*     */         }
/*     */       } catch (Throwable e) {
/* 541 */         ExceptionUtils.handleThrowable(e);
/* 542 */         log.error(sm.getString("accessLogValve.renameFail", new Object[] { rotatedLogFile, newLogFile }), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void close(boolean rename)
/*     */   {
/* 554 */     if (this.writer == null) {
/* 555 */       return;
/*     */     }
/* 557 */     this.writer.flush();
/* 558 */     this.writer.close();
/* 559 */     if ((rename) && (this.renameOnRotate)) {
/* 560 */       File newLogFile = getLogFile(true);
/* 561 */       if (!newLogFile.exists()) {
/*     */         try {
/* 563 */           if (!this.currentLogFile.renameTo(newLogFile)) {
/* 564 */             log.error(sm.getString("accessLogValve.renameFail", new Object[] { this.currentLogFile, newLogFile }));
/*     */           }
/*     */         } catch (Throwable e) {
/* 567 */           ExceptionUtils.handleThrowable(e);
/* 568 */           log.error(sm.getString("accessLogValve.renameFail", new Object[] { this.currentLogFile, newLogFile }), e);
/*     */         }
/*     */       } else {
/* 571 */         log.error(sm.getString("accessLogValve.alreadyExists", new Object[] { this.currentLogFile, newLogFile }));
/*     */       }
/*     */     }
/* 574 */     this.writer = null;
/* 575 */     this.dateStamp = "";
/* 576 */     this.currentLogFile = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void log(CharArrayWriter message)
/*     */   {
/* 589 */     rotate();
/*     */     
/*     */ 
/* 592 */     if (this.checkExists) {
/* 593 */       synchronized (this) {
/* 594 */         if ((this.currentLogFile != null) && (!this.currentLogFile.exists())) {
/*     */           try {
/* 596 */             close(false);
/*     */           } catch (Throwable e) {
/* 598 */             ExceptionUtils.handleThrowable(e);
/* 599 */             log.info(sm.getString("accessLogValve.closeFail"), e);
/*     */           }
/*     */           
/*     */ 
/* 603 */           this.dateStamp = this.fileDateFormatter.format(new Date(
/* 604 */             System.currentTimeMillis()));
/*     */           
/* 606 */           open();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 613 */       message.write(System.lineSeparator());
/* 614 */       synchronized (this) {
/* 615 */         if (this.writer != null) {
/* 616 */           message.writeTo(this.writer);
/* 617 */           if (!this.buffered) {
/* 618 */             this.writer.flush();
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (IOException ioe) {
/* 623 */       log.warn(sm.getString("accessLogValve.writeFail", new Object[] {message
/* 624 */         .toString() }), ioe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void open()
/*     */   {
/* 635 */     File pathname = getLogFile((this.rotatable) && (!this.renameOnRotate));
/*     */     
/* 637 */     Charset charset = null;
/* 638 */     if (this.encoding != null) {
/*     */       try {
/* 640 */         charset = B2CConverter.getCharset(this.encoding);
/*     */       } catch (UnsupportedEncodingException ex) {
/* 642 */         log.error(sm.getString("accessLogValve.unsupportedEncoding", new Object[] { this.encoding }), ex);
/*     */       }
/*     */     }
/*     */     
/* 646 */     if (charset == null) {
/* 647 */       charset = StandardCharsets.ISO_8859_1;
/*     */     }
/*     */     try
/*     */     {
/* 651 */       this.writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(pathname, true), charset), 128000), false);
/*     */       
/*     */ 
/*     */ 
/* 655 */       this.currentLogFile = pathname;
/*     */     } catch (IOException e) {
/* 657 */       this.writer = null;
/* 658 */       this.currentLogFile = null;
/* 659 */       log.error(sm.getString("accessLogValve.openFail", new Object[] { pathname, System.getProperty("user.name") }), e);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 664 */     this.checkForOldLogs = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 678 */     String format = getFileDateFormat();
/* 679 */     this.fileDateFormatter = new SimpleDateFormat(format, Locale.US);
/* 680 */     this.fileDateFormatter.setTimeZone(TimeZone.getDefault());
/* 681 */     this.dateStamp = this.fileDateFormatter.format(new Date(System.currentTimeMillis()));
/* 682 */     if ((this.rotatable) && (this.renameOnRotate)) {
/* 683 */       restore();
/*     */     }
/* 685 */     open();
/*     */     
/* 687 */     super.startInternal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 701 */     super.stopInternal();
/* 702 */     close(false);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\valves\AccessLogValve.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */