/*     */ package org.apache.catalina.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.catalina.Contained;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.JmxEnabled;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Pipeline;
/*     */ import org.apache.catalina.Valve;
/*     */ import org.apache.catalina.util.LifecycleBase;
/*     */ import org.apache.catalina.util.ToStringUtil;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardPipeline
/*     */   extends LifecycleBase
/*     */   implements Pipeline
/*     */ {
/*  54 */   private static final Log log = LogFactory.getLog(StandardPipeline.class);
/*  55 */   private static final StringManager sm = StringManager.getManager(StandardPipeline.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardPipeline()
/*     */   {
/*  65 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardPipeline(Container container)
/*     */   {
/*  79 */     setContainer(container);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   protected Valve basic = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   protected Container container = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   protected Valve first = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAsyncSupported()
/*     */   {
/* 109 */     Valve valve = this.first != null ? this.first : this.basic;
/* 110 */     boolean supported = true;
/* 111 */     while ((supported) && (valve != null)) {
/* 112 */       supported &= valve.isAsyncSupported();
/* 113 */       valve = valve.getNext();
/*     */     }
/* 115 */     return supported;
/*     */   }
/*     */   
/*     */ 
/*     */   public void findNonAsyncValves(Set<String> result)
/*     */   {
/* 121 */     Valve valve = this.first != null ? this.first : this.basic;
/* 122 */     while (valve != null) {
/* 123 */       if (!valve.isAsyncSupported()) {
/* 124 */         result.add(valve.getClass().getName());
/*     */       }
/* 126 */       valve = valve.getNext();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Container getContainer()
/*     */   {
/* 138 */     return this.container;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContainer(Container container)
/*     */   {
/* 149 */     this.container = container;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initInternal() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 170 */     Valve current = this.first;
/* 171 */     if (current == null) {
/* 172 */       current = this.basic;
/*     */     }
/* 174 */     while (current != null) {
/* 175 */       if ((current instanceof Lifecycle)) {
/* 176 */         ((Lifecycle)current).start();
/*     */       }
/* 178 */       current = current.getNext();
/*     */     }
/*     */     
/* 181 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/* 195 */     setState(LifecycleState.STOPPING);
/*     */     
/*     */ 
/* 198 */     Valve current = this.first;
/* 199 */     if (current == null) {
/* 200 */       current = this.basic;
/*     */     }
/* 202 */     while (current != null) {
/* 203 */       if ((current instanceof Lifecycle)) {
/* 204 */         ((Lifecycle)current).stop();
/*     */       }
/* 206 */       current = current.getNext();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void destroyInternal()
/*     */   {
/* 213 */     Valve[] valves = getValves();
/* 214 */     for (Valve valve : valves) {
/* 215 */       removeValve(valve);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 225 */     return ToStringUtil.toString(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Valve getBasic()
/*     */   {
/* 238 */     return this.basic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBasic(Valve valve)
/*     */   {
/* 258 */     Valve oldBasic = this.basic;
/* 259 */     if (oldBasic == valve) {
/* 260 */       return;
/*     */     }
/*     */     
/*     */ 
/* 264 */     if (oldBasic != null) {
/* 265 */       if ((getState().isAvailable()) && ((oldBasic instanceof Lifecycle))) {
/*     */         try {
/* 267 */           ((Lifecycle)oldBasic).stop();
/*     */         } catch (LifecycleException e) {
/* 269 */           log.error(sm.getString("standardPipeline.basic.stop"), e);
/*     */         }
/*     */       }
/* 272 */       if ((oldBasic instanceof Contained)) {
/*     */         try {
/* 274 */           ((Contained)oldBasic).setContainer(null);
/*     */         } catch (Throwable t) {
/* 276 */           ExceptionUtils.handleThrowable(t);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 282 */     if (valve == null) {
/* 283 */       return;
/*     */     }
/* 285 */     if ((valve instanceof Contained)) {
/* 286 */       ((Contained)valve).setContainer(this.container);
/*     */     }
/* 288 */     if ((getState().isAvailable()) && ((valve instanceof Lifecycle))) {
/*     */       try {
/* 290 */         ((Lifecycle)valve).start();
/*     */       } catch (LifecycleException e) {
/* 292 */         log.error(sm.getString("standardPipeline.basic.start"), e);
/* 293 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 298 */     Valve current = this.first;
/* 299 */     while (current != null) {
/* 300 */       if (current.getNext() == oldBasic) {
/* 301 */         current.setNext(valve);
/* 302 */         break;
/*     */       }
/* 304 */       current = current.getNext();
/*     */     }
/*     */     
/* 307 */     this.basic = valve;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addValve(Valve valve)
/*     */   {
/* 335 */     if ((valve instanceof Contained)) {
/* 336 */       ((Contained)valve).setContainer(this.container);
/*     */     }
/*     */     
/*     */ 
/* 340 */     if ((getState().isAvailable()) && 
/* 341 */       ((valve instanceof Lifecycle))) {
/*     */       try {
/* 343 */         ((Lifecycle)valve).start();
/*     */       } catch (LifecycleException e) {
/* 345 */         log.error(sm.getString("standardPipeline.valve.start"), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 351 */     if (this.first == null) {
/* 352 */       this.first = valve;
/* 353 */       valve.setNext(this.basic);
/*     */     } else {
/* 355 */       Valve current = this.first;
/* 356 */       while (current != null) {
/* 357 */         if (current.getNext() == this.basic) {
/* 358 */           current.setNext(valve);
/* 359 */           valve.setNext(this.basic);
/* 360 */           break;
/*     */         }
/* 362 */         current = current.getNext();
/*     */       }
/*     */     }
/*     */     
/* 366 */     this.container.fireContainerEvent("addValve", valve);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Valve[] getValves()
/*     */   {
/* 378 */     List<Valve> valveList = new ArrayList();
/* 379 */     Valve current = this.first;
/* 380 */     if (current == null) {
/* 381 */       current = this.basic;
/*     */     }
/* 383 */     while (current != null) {
/* 384 */       valveList.add(current);
/* 385 */       current = current.getNext();
/*     */     }
/*     */     
/* 388 */     return (Valve[])valveList.toArray(new Valve[0]);
/*     */   }
/*     */   
/*     */ 
/*     */   public ObjectName[] getValveObjectNames()
/*     */   {
/* 394 */     List<ObjectName> valveList = new ArrayList();
/* 395 */     Valve current = this.first;
/* 396 */     if (current == null) {
/* 397 */       current = this.basic;
/*     */     }
/* 399 */     while (current != null) {
/* 400 */       if ((current instanceof JmxEnabled)) {
/* 401 */         valveList.add(((JmxEnabled)current).getObjectName());
/*     */       }
/* 403 */       current = current.getNext();
/*     */     }
/*     */     
/* 406 */     return (ObjectName[])valveList.toArray(new ObjectName[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeValve(Valve valve)
/*     */   {
/*     */     Valve current;
/*     */     
/*     */ 
/*     */ 
/*     */     Valve current;
/*     */     
/*     */ 
/*     */ 
/* 422 */     if (this.first == valve) {
/* 423 */       this.first = this.first.getNext();
/* 424 */       current = null;
/*     */     } else {
/* 426 */       current = this.first;
/*     */     }
/* 428 */     while (current != null) {
/* 429 */       if (current.getNext() == valve) {
/* 430 */         current.setNext(valve.getNext());
/* 431 */         break;
/*     */       }
/* 433 */       current = current.getNext();
/*     */     }
/*     */     
/* 436 */     if (this.first == this.basic) {
/* 437 */       this.first = null;
/*     */     }
/*     */     
/* 440 */     if ((valve instanceof Contained)) {
/* 441 */       ((Contained)valve).setContainer(null);
/*     */     }
/*     */     
/* 444 */     if ((valve instanceof Lifecycle))
/*     */     {
/* 446 */       if (getState().isAvailable()) {
/*     */         try {
/* 448 */           ((Lifecycle)valve).stop();
/*     */         } catch (LifecycleException e) {
/* 450 */           log.error(sm.getString("standardPipeline.valve.stop"), e);
/*     */         }
/*     */       }
/*     */       try {
/* 454 */         ((Lifecycle)valve).destroy();
/*     */       } catch (LifecycleException e) {
/* 456 */         log.error(sm.getString("standardPipeline.valve.destroy"), e);
/*     */       }
/*     */     }
/*     */     
/* 460 */     this.container.fireContainerEvent("removeValve", valve);
/*     */   }
/*     */   
/*     */ 
/*     */   public Valve getFirst()
/*     */   {
/* 466 */     if (this.first != null) {
/* 467 */       return this.first;
/*     */     }
/*     */     
/* 470 */     return this.basic;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\core\StandardPipeline.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */