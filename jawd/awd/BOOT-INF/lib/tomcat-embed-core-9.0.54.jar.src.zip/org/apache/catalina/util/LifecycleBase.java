/*     */ package org.apache.catalina.util;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.apache.catalina.Lifecycle;
/*     */ import org.apache.catalina.Lifecycle.SingleUse;
/*     */ import org.apache.catalina.LifecycleEvent;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleListener;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LifecycleBase
/*     */   implements Lifecycle
/*     */ {
/*  39 */   private static final Log log = LogFactory.getLog(LifecycleBase.class);
/*     */   
/*  41 */   private static final StringManager sm = StringManager.getManager(LifecycleBase.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */   private final List<LifecycleListener> lifecycleListeners = new CopyOnWriteArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private volatile LifecycleState state = LifecycleState.NEW;
/*     */   
/*     */ 
/*  56 */   private boolean throwOnFailure = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getThrowOnFailure()
/*     */   {
/*  69 */     return this.throwOnFailure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setThrowOnFailure(boolean throwOnFailure)
/*     */   {
/*  83 */     this.throwOnFailure = throwOnFailure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLifecycleListener(LifecycleListener listener)
/*     */   {
/*  92 */     this.lifecycleListeners.add(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LifecycleListener[] findLifecycleListeners()
/*     */   {
/* 101 */     return (LifecycleListener[])this.lifecycleListeners.toArray(new LifecycleListener[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLifecycleListener(LifecycleListener listener)
/*     */   {
/* 110 */     this.lifecycleListeners.remove(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void fireLifecycleEvent(String type, Object data)
/*     */   {
/* 121 */     LifecycleEvent event = new LifecycleEvent(this, type, data);
/* 122 */     for (LifecycleListener listener : this.lifecycleListeners) {
/* 123 */       listener.lifecycleEvent(event);
/*     */     }
/*     */   }
/*     */   
/*     */   public final synchronized void init()
/*     */     throws LifecycleException
/*     */   {
/* 130 */     if (!this.state.equals(LifecycleState.NEW)) {
/* 131 */       invalidTransition("before_init");
/*     */     }
/*     */     try
/*     */     {
/* 135 */       setStateInternal(LifecycleState.INITIALIZING, null, false);
/* 136 */       initInternal();
/* 137 */       setStateInternal(LifecycleState.INITIALIZED, null, false);
/*     */     } catch (Throwable t) {
/* 139 */       handleSubClassException(t, "lifecycleBase.initFail", new Object[] { toString() });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void initInternal()
/*     */     throws LifecycleException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final synchronized void start()
/*     */     throws LifecycleException
/*     */   {
/* 159 */     if ((LifecycleState.STARTING_PREP.equals(this.state)) || (LifecycleState.STARTING.equals(this.state)) || 
/* 160 */       (LifecycleState.STARTED.equals(this.state)))
/*     */     {
/* 162 */       if (log.isDebugEnabled()) {
/* 163 */         Exception e = new LifecycleException();
/* 164 */         log.debug(sm.getString("lifecycleBase.alreadyStarted", new Object[] { toString() }), e);
/* 165 */       } else if (log.isInfoEnabled()) {
/* 166 */         log.info(sm.getString("lifecycleBase.alreadyStarted", new Object[] { toString() }));
/*     */       }
/*     */       
/* 169 */       return;
/*     */     }
/*     */     
/* 172 */     if (this.state.equals(LifecycleState.NEW)) {
/* 173 */       init();
/* 174 */     } else if (this.state.equals(LifecycleState.FAILED)) {
/* 175 */       stop();
/* 176 */     } else if ((!this.state.equals(LifecycleState.INITIALIZED)) && 
/* 177 */       (!this.state.equals(LifecycleState.STOPPED))) {
/* 178 */       invalidTransition("before_start");
/*     */     }
/*     */     try
/*     */     {
/* 182 */       setStateInternal(LifecycleState.STARTING_PREP, null, false);
/* 183 */       startInternal();
/* 184 */       if (this.state.equals(LifecycleState.FAILED))
/*     */       {
/*     */ 
/* 187 */         stop();
/* 188 */       } else if (!this.state.equals(LifecycleState.STARTING))
/*     */       {
/*     */ 
/* 191 */         invalidTransition("after_start");
/*     */       } else {
/* 193 */         setStateInternal(LifecycleState.STARTED, null, false);
/*     */       }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 198 */       handleSubClassException(t, "lifecycleBase.startFail", new Object[] { toString() });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void startInternal()
/*     */     throws LifecycleException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final synchronized void stop()
/*     */     throws LifecycleException
/*     */   {
/* 225 */     if ((LifecycleState.STOPPING_PREP.equals(this.state)) || (LifecycleState.STOPPING.equals(this.state)) || 
/* 226 */       (LifecycleState.STOPPED.equals(this.state)))
/*     */     {
/* 228 */       if (log.isDebugEnabled()) {
/* 229 */         Exception e = new LifecycleException();
/* 230 */         log.debug(sm.getString("lifecycleBase.alreadyStopped", new Object[] { toString() }), e);
/* 231 */       } else if (log.isInfoEnabled()) {
/* 232 */         log.info(sm.getString("lifecycleBase.alreadyStopped", new Object[] { toString() }));
/*     */       }
/*     */       
/* 235 */       return;
/*     */     }
/*     */     
/* 238 */     if (this.state.equals(LifecycleState.NEW)) {
/* 239 */       this.state = LifecycleState.STOPPED;
/* 240 */       return;
/*     */     }
/*     */     
/* 243 */     if ((!this.state.equals(LifecycleState.STARTED)) && (!this.state.equals(LifecycleState.FAILED))) {
/* 244 */       invalidTransition("before_stop");
/*     */     }
/*     */     try
/*     */     {
/* 248 */       if (this.state.equals(LifecycleState.FAILED))
/*     */       {
/*     */ 
/*     */ 
/* 252 */         fireLifecycleEvent("before_stop", null);
/*     */       } else {
/* 254 */         setStateInternal(LifecycleState.STOPPING_PREP, null, false);
/*     */       }
/*     */       
/* 257 */       stopInternal();
/*     */       
/*     */ 
/*     */ 
/* 261 */       if ((!this.state.equals(LifecycleState.STOPPING)) && (!this.state.equals(LifecycleState.FAILED))) {
/* 262 */         invalidTransition("after_stop");
/*     */       }
/*     */       
/* 265 */       setStateInternal(LifecycleState.STOPPED, null, false);
/*     */     } catch (Throwable t) {
/* 267 */       handleSubClassException(t, "lifecycleBase.stopFail", new Object[] { toString() });
/*     */     } finally {
/* 269 */       if ((this instanceof Lifecycle.SingleUse))
/*     */       {
/* 271 */         setStateInternal(LifecycleState.STOPPED, null, false);
/* 272 */         destroy();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void stopInternal()
/*     */     throws LifecycleException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final synchronized void destroy()
/*     */     throws LifecycleException
/*     */   {
/* 290 */     if (LifecycleState.FAILED.equals(this.state)) {
/*     */       try
/*     */       {
/* 293 */         stop();
/*     */       }
/*     */       catch (LifecycleException e) {
/* 296 */         log.error(sm.getString("lifecycleBase.destroyStopFail", new Object[] { toString() }), e);
/*     */       }
/*     */     }
/*     */     
/* 300 */     if ((LifecycleState.DESTROYING.equals(this.state)) || (LifecycleState.DESTROYED.equals(this.state))) {
/* 301 */       if (log.isDebugEnabled()) {
/* 302 */         Exception e = new LifecycleException();
/* 303 */         log.debug(sm.getString("lifecycleBase.alreadyDestroyed", new Object[] { toString() }), e);
/* 304 */       } else if ((log.isInfoEnabled()) && (!(this instanceof Lifecycle.SingleUse)))
/*     */       {
/*     */ 
/*     */ 
/* 308 */         log.info(sm.getString("lifecycleBase.alreadyDestroyed", new Object[] { toString() }));
/*     */       }
/*     */       
/* 311 */       return;
/*     */     }
/*     */     
/* 314 */     if ((!this.state.equals(LifecycleState.STOPPED)) && (!this.state.equals(LifecycleState.FAILED)) && 
/* 315 */       (!this.state.equals(LifecycleState.NEW)) && (!this.state.equals(LifecycleState.INITIALIZED))) {
/* 316 */       invalidTransition("before_destroy");
/*     */     }
/*     */     try
/*     */     {
/* 320 */       setStateInternal(LifecycleState.DESTROYING, null, false);
/* 321 */       destroyInternal();
/* 322 */       setStateInternal(LifecycleState.DESTROYED, null, false);
/*     */     } catch (Throwable t) {
/* 324 */       handleSubClassException(t, "lifecycleBase.destroyFail", new Object[] { toString() });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void destroyInternal()
/*     */     throws LifecycleException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LifecycleState getState()
/*     */   {
/* 343 */     return this.state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStateName()
/*     */   {
/* 352 */     return getState().toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void setState(LifecycleState state)
/*     */     throws LifecycleException
/*     */   {
/* 366 */     setStateInternal(state, null, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized void setState(LifecycleState state, Object data)
/*     */     throws LifecycleException
/*     */   {
/* 382 */     setStateInternal(state, data, true);
/*     */   }
/*     */   
/*     */ 
/*     */   private synchronized void setStateInternal(LifecycleState state, Object data, boolean check)
/*     */     throws LifecycleException
/*     */   {
/* 389 */     if (log.isDebugEnabled()) {
/* 390 */       log.debug(sm.getString("lifecycleBase.setState", new Object[] { this, state }));
/*     */     }
/*     */     
/* 393 */     if (check)
/*     */     {
/*     */ 
/*     */ 
/* 397 */       if (state == null) {
/* 398 */         invalidTransition("null");
/*     */         
/*     */ 
/* 401 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 408 */       if ((state != LifecycleState.FAILED) && ((this.state != LifecycleState.STARTING_PREP) || (state != LifecycleState.STARTING)) && ((this.state != LifecycleState.STOPPING_PREP) || (state != LifecycleState.STOPPING)) && ((this.state != LifecycleState.FAILED) || (state != LifecycleState.STOPPING)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 416 */         invalidTransition(state.name());
/*     */       }
/*     */     }
/*     */     
/* 420 */     this.state = state;
/* 421 */     String lifecycleEvent = state.getLifecycleEvent();
/* 422 */     if (lifecycleEvent != null) {
/* 423 */       fireLifecycleEvent(lifecycleEvent, data);
/*     */     }
/*     */   }
/*     */   
/*     */   private void invalidTransition(String type) throws LifecycleException
/*     */   {
/* 429 */     String msg = sm.getString("lifecycleBase.invalidTransition", new Object[] { type, toString(), this.state });
/* 430 */     throw new LifecycleException(msg);
/*     */   }
/*     */   
/*     */   private void handleSubClassException(Throwable t, String key, Object... args) throws LifecycleException
/*     */   {
/* 435 */     setStateInternal(LifecycleState.FAILED, null, false);
/* 436 */     ExceptionUtils.handleThrowable(t);
/* 437 */     String msg = sm.getString(key, args);
/* 438 */     if (getThrowOnFailure()) {
/* 439 */       if (!(t instanceof LifecycleException)) {
/* 440 */         t = new LifecycleException(msg, t);
/*     */       }
/* 442 */       throw ((LifecycleException)t);
/*     */     }
/* 444 */     log.error(msg, t);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\util\LifecycleBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */