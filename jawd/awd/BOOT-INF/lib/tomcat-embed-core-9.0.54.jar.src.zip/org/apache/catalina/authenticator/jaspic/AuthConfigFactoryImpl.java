/*     */ package org.apache.catalina.authenticator.jaspic;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import javax.security.auth.message.config.AuthConfigFactory;
/*     */ import javax.security.auth.message.config.AuthConfigFactory.RegistrationContext;
/*     */ import javax.security.auth.message.config.AuthConfigProvider;
/*     */ import javax.security.auth.message.config.RegistrationListener;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthConfigFactoryImpl
/*     */   extends AuthConfigFactory
/*     */ {
/*  43 */   private final Log log = LogFactory.getLog(AuthConfigFactoryImpl.class);
/*  44 */   private static final StringManager sm = StringManager.getManager(AuthConfigFactoryImpl.class);
/*     */   
/*     */   private static final String CONFIG_PATH = "conf/jaspic-providers.xml";
/*  47 */   private static final File CONFIG_FILE = new File(
/*  48 */     System.getProperty("catalina.base"), "conf/jaspic-providers.xml");
/*  49 */   private static final Object CONFIG_FILE_LOCK = new Object();
/*     */   
/*  51 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   
/*  53 */   private static String DEFAULT_REGISTRATION_ID = getRegistrationID(null, null);
/*     */   
/*  55 */   private final Map<String, RegistrationContextImpl> layerAppContextRegistrations = new ConcurrentHashMap();
/*     */   
/*  57 */   private final Map<String, RegistrationContextImpl> appContextRegistrations = new ConcurrentHashMap();
/*     */   
/*  59 */   private final Map<String, RegistrationContextImpl> layerRegistrations = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*  63 */   private final Map<String, RegistrationContextImpl> defaultRegistration = new ConcurrentHashMap(1);
/*     */   
/*     */ 
/*     */   public AuthConfigFactoryImpl()
/*     */   {
/*  68 */     loadPersistentRegistrations();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AuthConfigProvider getConfigProvider(String layer, String appContext, RegistrationListener listener)
/*     */   {
/*  76 */     RegistrationContextImpl registrationContext = findRegistrationContextImpl(layer, appContext);
/*  77 */     if (registrationContext != null) {
/*  78 */       if (listener != null) {
/*  79 */         RegistrationListenerWrapper wrapper = new RegistrationListenerWrapper(layer, appContext, listener);
/*     */         
/*  81 */         registrationContext.addListener(wrapper);
/*     */       }
/*  83 */       return registrationContext.getProvider();
/*     */     }
/*  85 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String registerConfigProvider(String className, Map properties, String layer, String appContext, String description)
/*     */   {
/*  94 */     String registrationID = doRegisterConfigProvider(className, properties, layer, appContext, description);
/*  95 */     savePersistentRegistrations();
/*  96 */     return registrationID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String doRegisterConfigProvider(String className, Map properties, String layer, String appContext, String description)
/*     */   {
/* 104 */     if (this.log.isDebugEnabled()) {
/* 105 */       this.log.debug(sm.getString("authConfigFactoryImpl.registerClass", new Object[] { className, layer, appContext }));
/*     */     }
/*     */     
/*     */ 
/* 109 */     AuthConfigProvider provider = null;
/* 110 */     if (className != null) {
/* 111 */       provider = createAuthConfigProvider(className, properties);
/*     */     }
/*     */     
/* 114 */     String registrationID = getRegistrationID(layer, appContext);
/* 115 */     RegistrationContextImpl registrationContextImpl = new RegistrationContextImpl(layer, appContext, description, true, provider, properties, null);
/*     */     
/* 117 */     addRegistrationContextImpl(layer, appContext, registrationID, registrationContextImpl);
/* 118 */     return registrationID;
/*     */   }
/*     */   
/*     */   private AuthConfigProvider createAuthConfigProvider(String className, Map properties)
/*     */     throws SecurityException
/*     */   {
/* 124 */     Class<?> clazz = null;
/* 125 */     AuthConfigProvider provider = null;
/*     */     try {
/* 127 */       clazz = Class.forName(className, true, Thread.currentThread().getContextClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException) {}
/*     */     try
/*     */     {
/* 132 */       if (clazz == null) {
/* 133 */         clazz = Class.forName(className);
/*     */       }
/* 135 */       Constructor<?> constructor = clazz.getConstructor(new Class[] { Map.class, AuthConfigFactory.class });
/* 136 */       provider = (AuthConfigProvider)constructor.newInstance(new Object[] { properties, null });
/*     */     } catch (ReflectiveOperationException|IllegalArgumentException e) {
/* 138 */       throw new SecurityException(e);
/*     */     }
/* 140 */     return provider;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String registerConfigProvider(AuthConfigProvider provider, String layer, String appContext, String description)
/*     */   {
/* 147 */     if (this.log.isDebugEnabled()) {
/* 148 */       this.log.debug(sm.getString("authConfigFactoryImpl.registerInstance", new Object[] {provider
/* 149 */         .getClass().getName(), layer, appContext }));
/*     */     }
/* 151 */     String registrationID = getRegistrationID(layer, appContext);
/* 152 */     RegistrationContextImpl registrationContextImpl = new RegistrationContextImpl(layer, appContext, description, false, provider, null, null);
/*     */     
/* 154 */     addRegistrationContextImpl(layer, appContext, registrationID, registrationContextImpl);
/* 155 */     return registrationID;
/*     */   }
/*     */   
/*     */ 
/*     */   private void addRegistrationContextImpl(String layer, String appContext, String registrationID, RegistrationContextImpl registrationContextImpl)
/*     */   {
/* 161 */     RegistrationContextImpl previous = null;
/*     */     
/*     */ 
/* 164 */     if ((layer != null) && (appContext != null)) {
/* 165 */       previous = (RegistrationContextImpl)this.layerAppContextRegistrations.put(registrationID, registrationContextImpl);
/* 166 */     } else if ((layer == null) && (appContext != null)) {
/* 167 */       previous = (RegistrationContextImpl)this.appContextRegistrations.put(registrationID, registrationContextImpl);
/* 168 */     } else if ((layer != null) && (appContext == null)) {
/* 169 */       previous = (RegistrationContextImpl)this.layerRegistrations.put(registrationID, registrationContextImpl);
/*     */     } else
/* 171 */       previous = (RegistrationContextImpl)this.defaultRegistration.put(registrationID, registrationContextImpl);
/*     */     RegistrationContextImpl registration;
/*     */     RegistrationListenerWrapper wrapper;
/* 174 */     RegistrationContextImpl registration; if (previous == null)
/*     */     {
/*     */       Iterator localIterator;
/*     */       
/*     */ 
/* 179 */       if ((layer != null) && (appContext != null))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 184 */         registration = (RegistrationContextImpl)this.appContextRegistrations.get(getRegistrationID(null, appContext));
/* 185 */         if (registration != null) {
/* 186 */           for (localIterator = registration.listeners.iterator(); localIterator.hasNext();) { wrapper = (RegistrationListenerWrapper)localIterator.next();
/* 187 */             if ((layer.equals(wrapper.getMessageLayer())) && 
/* 188 */               (appContext.equals(wrapper.getAppContext()))) {
/* 189 */               registration.listeners.remove(wrapper);
/* 190 */               wrapper.listener.notify(wrapper.messageLayer, wrapper.appContext);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 195 */       if (appContext != null)
/*     */       {
/*     */ 
/*     */ 
/* 199 */         for (registration = this.layerRegistrations.values().iterator(); registration.hasNext();) { registration = (RegistrationContextImpl)registration.next();
/* 200 */           for (RegistrationListenerWrapper wrapper : registration.listeners)
/* 201 */             if (appContext.equals(wrapper.getAppContext())) {
/* 202 */               registration.listeners.remove(wrapper);
/* 203 */               wrapper.listener.notify(wrapper.messageLayer, wrapper.appContext);
/*     */             }
/*     */         }
/*     */       }
/*     */       RegistrationContextImpl registration;
/* 208 */       if ((layer != null) || (appContext != null))
/*     */       {
/* 210 */         for (registration = this.defaultRegistration.values().iterator(); registration.hasNext();) { registration = (RegistrationContextImpl)registration.next();
/* 211 */           for (RegistrationListenerWrapper wrapper : registration.listeners) {
/* 212 */             if (((appContext != null) && (appContext.equals(wrapper.getAppContext()))) || ((layer != null) && 
/* 213 */               (layer.equals(wrapper.getMessageLayer())))) {
/* 214 */               registration.listeners.remove(wrapper);
/* 215 */               wrapper.listener.notify(wrapper.messageLayer, wrapper.appContext);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 222 */       for (RegistrationListenerWrapper wrapper : previous.listeners) {
/* 223 */         previous.listeners.remove(wrapper);
/* 224 */         wrapper.listener.notify(wrapper.messageLayer, wrapper.appContext);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean removeRegistration(String registrationID)
/*     */   {
/* 232 */     RegistrationContextImpl registration = null;
/* 233 */     if (DEFAULT_REGISTRATION_ID.equals(registrationID)) {
/* 234 */       registration = (RegistrationContextImpl)this.defaultRegistration.remove(registrationID);
/*     */     }
/* 236 */     if (registration == null) {
/* 237 */       registration = (RegistrationContextImpl)this.layerAppContextRegistrations.remove(registrationID);
/*     */     }
/* 239 */     if (registration == null) {
/* 240 */       registration = (RegistrationContextImpl)this.appContextRegistrations.remove(registrationID);
/*     */     }
/* 242 */     if (registration == null) {
/* 243 */       registration = (RegistrationContextImpl)this.layerRegistrations.remove(registrationID);
/*     */     }
/*     */     
/* 246 */     if (registration == null) {
/* 247 */       return false;
/*     */     }
/* 249 */     for (RegistrationListenerWrapper wrapper : registration.listeners) {
/* 250 */       wrapper.getListener().notify(wrapper.getMessageLayer(), wrapper.getAppContext());
/*     */     }
/* 252 */     if (registration.isPersistent()) {
/* 253 */       savePersistentRegistrations();
/*     */     }
/* 255 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] detachListener(RegistrationListener listener, String layer, String appContext)
/*     */   {
/* 262 */     String registrationID = getRegistrationID(layer, appContext);
/* 263 */     RegistrationContextImpl registrationContext = findRegistrationContextImpl(layer, appContext);
/* 264 */     if ((registrationContext != null) && (registrationContext.removeListener(listener))) {
/* 265 */       return new String[] { registrationID };
/*     */     }
/* 267 */     return EMPTY_STRING_ARRAY;
/*     */   }
/*     */   
/*     */ 
/*     */   public String[] getRegistrationIDs(AuthConfigProvider provider)
/*     */   {
/* 273 */     List<String> result = new ArrayList();
/* 274 */     if (provider == null) {
/* 275 */       result.addAll(this.layerAppContextRegistrations.keySet());
/* 276 */       result.addAll(this.appContextRegistrations.keySet());
/* 277 */       result.addAll(this.layerRegistrations.keySet());
/* 278 */       if (!this.defaultRegistration.isEmpty()) {
/* 279 */         result.add(DEFAULT_REGISTRATION_ID);
/*     */       }
/*     */     } else {
/* 282 */       findProvider(provider, this.layerAppContextRegistrations, result);
/* 283 */       findProvider(provider, this.appContextRegistrations, result);
/* 284 */       findProvider(provider, this.layerRegistrations, result);
/* 285 */       findProvider(provider, this.defaultRegistration, result);
/*     */     }
/* 287 */     return (String[])result.toArray(EMPTY_STRING_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */   private void findProvider(AuthConfigProvider provider, Map<String, RegistrationContextImpl> registrations, List<String> result)
/*     */   {
/* 293 */     for (Map.Entry<String, RegistrationContextImpl> entry : registrations.entrySet()) {
/* 294 */       if (provider.equals(((RegistrationContextImpl)entry.getValue()).getProvider())) {
/* 295 */         result.add(entry.getKey());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public AuthConfigFactory.RegistrationContext getRegistrationContext(String registrationID)
/*     */   {
/* 303 */     AuthConfigFactory.RegistrationContext result = (AuthConfigFactory.RegistrationContext)this.defaultRegistration.get(registrationID);
/* 304 */     if (result == null) {
/* 305 */       result = (AuthConfigFactory.RegistrationContext)this.layerAppContextRegistrations.get(registrationID);
/*     */     }
/* 307 */     if (result == null) {
/* 308 */       result = (AuthConfigFactory.RegistrationContext)this.appContextRegistrations.get(registrationID);
/*     */     }
/* 310 */     if (result == null) {
/* 311 */       result = (AuthConfigFactory.RegistrationContext)this.layerRegistrations.get(registrationID);
/*     */     }
/* 313 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public void refresh()
/*     */   {
/* 319 */     loadPersistentRegistrations();
/*     */   }
/*     */   
/*     */   private static String getRegistrationID(String layer, String appContext)
/*     */   {
/* 324 */     if ((layer != null) && (layer.length() == 0))
/*     */     {
/* 326 */       throw new IllegalArgumentException(sm.getString("authConfigFactoryImpl.zeroLengthMessageLayer"));
/*     */     }
/* 328 */     if ((appContext != null) && (appContext.length() == 0))
/*     */     {
/* 330 */       throw new IllegalArgumentException(sm.getString("authConfigFactoryImpl.zeroLengthAppContext"));
/*     */     }
/* 332 */     return (layer == null ? "" : layer) + ":" + (appContext == null ? "" : appContext);
/*     */   }
/*     */   
/*     */   private void loadPersistentRegistrations()
/*     */   {
/* 337 */     synchronized (CONFIG_FILE_LOCK) {
/* 338 */       if (this.log.isDebugEnabled()) {
/* 339 */         this.log.debug(sm.getString("authConfigFactoryImpl.load", new Object[] {CONFIG_FILE
/* 340 */           .getAbsolutePath() }));
/*     */       }
/* 342 */       if (!CONFIG_FILE.isFile()) {
/* 343 */         return;
/*     */       }
/* 345 */       PersistentProviderRegistrations.Providers providers = PersistentProviderRegistrations.loadProviders(CONFIG_FILE);
/* 346 */       for (PersistentProviderRegistrations.Provider provider : providers.getProviders()) {
/* 347 */         doRegisterConfigProvider(provider.getClassName(), provider.getProperties(), provider
/* 348 */           .getLayer(), provider.getAppContext(), provider.getDescription());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void savePersistentRegistrations()
/*     */   {
/* 355 */     synchronized (CONFIG_FILE_LOCK) {
/* 356 */       PersistentProviderRegistrations.Providers providers = new PersistentProviderRegistrations.Providers();
/* 357 */       savePersistentProviders(providers, this.layerAppContextRegistrations);
/* 358 */       savePersistentProviders(providers, this.appContextRegistrations);
/* 359 */       savePersistentProviders(providers, this.layerRegistrations);
/* 360 */       savePersistentProviders(providers, this.defaultRegistration);
/* 361 */       PersistentProviderRegistrations.writeProviders(providers, CONFIG_FILE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void savePersistentProviders(PersistentProviderRegistrations.Providers providers, Map<String, RegistrationContextImpl> registrations)
/*     */   {
/* 368 */     for (Map.Entry<String, RegistrationContextImpl> entry : registrations.entrySet()) {
/* 369 */       savePersistentProvider(providers, (RegistrationContextImpl)entry.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void savePersistentProvider(PersistentProviderRegistrations.Providers providers, RegistrationContextImpl registrationContextImpl)
/*     */   {
/* 376 */     if ((registrationContextImpl != null) && (registrationContextImpl.isPersistent())) {
/* 377 */       PersistentProviderRegistrations.Provider provider = new PersistentProviderRegistrations.Provider();
/* 378 */       provider.setAppContext(registrationContextImpl.getAppContext());
/* 379 */       if (registrationContextImpl.getProvider() != null) {
/* 380 */         provider.setClassName(registrationContextImpl.getProvider().getClass().getName());
/*     */       }
/* 382 */       provider.setDescription(registrationContextImpl.getDescription());
/* 383 */       provider.setLayer(registrationContextImpl.getMessageLayer());
/* 384 */       for (Map.Entry<String, String> property : registrationContextImpl.getProperties().entrySet()) {
/* 385 */         provider.addProperty((String)property.getKey(), (String)property.getValue());
/*     */       }
/* 387 */       providers.addProvider(provider);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private RegistrationContextImpl findRegistrationContextImpl(String layer, String appContext)
/*     */   {
/* 394 */     RegistrationContextImpl result = (RegistrationContextImpl)this.layerAppContextRegistrations.get(getRegistrationID(layer, appContext));
/* 395 */     if (result == null) {
/* 396 */       result = (RegistrationContextImpl)this.appContextRegistrations.get(getRegistrationID(null, appContext));
/*     */     }
/* 398 */     if (result == null) {
/* 399 */       result = (RegistrationContextImpl)this.layerRegistrations.get(getRegistrationID(layer, null));
/*     */     }
/* 401 */     if (result == null) {
/* 402 */       result = (RegistrationContextImpl)this.defaultRegistration.get(DEFAULT_REGISTRATION_ID);
/*     */     }
/* 404 */     return result;
/*     */   }
/*     */   
/*     */   private static class RegistrationContextImpl implements AuthConfigFactory.RegistrationContext {
/*     */     private final String messageLayer;
/*     */     private final String appContext;
/*     */     private final String description;
/*     */     
/* 412 */     private RegistrationContextImpl(String messageLayer, String appContext, String description, boolean persistent, AuthConfigProvider provider, Map<String, String> properties) { this.messageLayer = messageLayer;
/* 413 */       this.appContext = appContext;
/* 414 */       this.description = description;
/* 415 */       this.persistent = persistent;
/* 416 */       this.provider = provider;
/* 417 */       Map<String, String> propertiesCopy = new HashMap();
/* 418 */       if (properties != null) {
/* 419 */         propertiesCopy.putAll(properties);
/*     */       }
/* 421 */       this.properties = Collections.unmodifiableMap(propertiesCopy);
/*     */     }
/*     */     
/*     */ 
/*     */     private final boolean persistent;
/*     */     
/*     */     private final AuthConfigProvider provider;
/*     */     
/*     */     private final Map<String, String> properties;
/* 430 */     private final List<AuthConfigFactoryImpl.RegistrationListenerWrapper> listeners = new CopyOnWriteArrayList();
/*     */     
/*     */     public String getMessageLayer()
/*     */     {
/* 434 */       return this.messageLayer;
/*     */     }
/*     */     
/*     */ 
/*     */     public String getAppContext()
/*     */     {
/* 440 */       return this.appContext;
/*     */     }
/*     */     
/*     */     public String getDescription()
/*     */     {
/* 445 */       return this.description;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean isPersistent()
/*     */     {
/* 451 */       return this.persistent;
/*     */     }
/*     */     
/*     */     private AuthConfigProvider getProvider()
/*     */     {
/* 456 */       return this.provider;
/*     */     }
/*     */     
/*     */     private void addListener(AuthConfigFactoryImpl.RegistrationListenerWrapper listener)
/*     */     {
/* 461 */       if (listener != null) {
/* 462 */         this.listeners.add(listener);
/*     */       }
/*     */     }
/*     */     
/*     */     private Map<String, String> getProperties()
/*     */     {
/* 468 */       return this.properties;
/*     */     }
/*     */     
/*     */     private boolean removeListener(RegistrationListener listener)
/*     */     {
/* 473 */       boolean result = false;
/* 474 */       for (AuthConfigFactoryImpl.RegistrationListenerWrapper wrapper : this.listeners) {
/* 475 */         if (wrapper.getListener().equals(listener)) {
/* 476 */           this.listeners.remove(wrapper);
/* 477 */           result = true;
/*     */         }
/*     */       }
/* 480 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class RegistrationListenerWrapper
/*     */   {
/*     */     private final String messageLayer;
/*     */     
/*     */     private final String appContext;
/*     */     private final RegistrationListener listener;
/*     */     
/*     */     public RegistrationListenerWrapper(String messageLayer, String appContext, RegistrationListener listener)
/*     */     {
/* 494 */       this.messageLayer = messageLayer;
/* 495 */       this.appContext = appContext;
/* 496 */       this.listener = listener;
/*     */     }
/*     */     
/*     */     public String getMessageLayer()
/*     */     {
/* 501 */       return this.messageLayer;
/*     */     }
/*     */     
/*     */     public String getAppContext()
/*     */     {
/* 506 */       return this.appContext;
/*     */     }
/*     */     
/*     */     public RegistrationListener getListener()
/*     */     {
/* 511 */       return this.listener;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\authenticator\jaspic\AuthConfigFactoryImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */