/*      */ package org.apache.catalina.filters;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Set;
/*      */ import javax.servlet.FilterChain;
/*      */ import javax.servlet.GenericFilter;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.util.http.RequestUtil;
/*      */ import org.apache.tomcat.util.http.ResponseUtil;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CorsFilter
/*      */   extends GenericFilter
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   89 */   private static final StringManager sm = StringManager.getManager(CorsFilter.class);
/*      */   
/*   91 */   private transient Log log = LogFactory.getLog(CorsFilter.class);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   98 */   private final Collection<String> allowedOrigins = new HashSet();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean anyOriginAllowed;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  109 */   private final Collection<String> allowedHttpMethods = new HashSet();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  115 */   private final Collection<String> allowedHttpHeaders = new HashSet();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  122 */   private final Collection<String> exposedHeaders = new HashSet();
/*      */   
/*      */   private boolean supportsCredentials;
/*      */   private long preflightMaxAge;
/*      */   private boolean decorateRequest;
/*      */   public static final String RESPONSE_HEADER_ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
/*      */   public static final String RESPONSE_HEADER_ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";
/*      */   public static final String RESPONSE_HEADER_ACCESS_CONTROL_EXPOSE_HEADERS = "Access-Control-Expose-Headers";
/*      */   public static final String RESPONSE_HEADER_ACCESS_CONTROL_MAX_AGE = "Access-Control-Max-Age";
/*      */   public static final String RESPONSE_HEADER_ACCESS_CONTROL_ALLOW_METHODS = "Access-Control-Allow-Methods";
/*      */   public static final String RESPONSE_HEADER_ACCESS_CONTROL_ALLOW_HEADERS = "Access-Control-Allow-Headers";
/*      */   @Deprecated
/*      */   public static final String REQUEST_HEADER_VARY = "Vary";
/*      */   public static final String REQUEST_HEADER_ORIGIN = "Origin";
/*      */   public static final String REQUEST_HEADER_ACCESS_CONTROL_REQUEST_METHOD = "Access-Control-Request-Method";
/*      */   public static final String REQUEST_HEADER_ACCESS_CONTROL_REQUEST_HEADERS = "Access-Control-Request-Headers";
/*      */   public static final String HTTP_REQUEST_ATTRIBUTE_PREFIX = "cors.";
/*      */   public static final String HTTP_REQUEST_ATTRIBUTE_ORIGIN = "cors.request.origin";
/*      */   public static final String HTTP_REQUEST_ATTRIBUTE_IS_CORS_REQUEST = "cors.isCorsRequest";
/*      */   public static final String HTTP_REQUEST_ATTRIBUTE_REQUEST_TYPE = "cors.request.type";
/*      */   public static final String HTTP_REQUEST_ATTRIBUTE_REQUEST_HEADERS = "cors.request.headers";
/*      */   
/*      */   public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
/*      */     throws IOException, ServletException
/*      */   {
/*  147 */     if ((!(servletRequest instanceof HttpServletRequest)) || (!(servletResponse instanceof HttpServletResponse)))
/*      */     {
/*  149 */       throw new ServletException(sm.getString("corsFilter.onlyHttp"));
/*      */     }
/*      */     
/*      */ 
/*  153 */     HttpServletRequest request = (HttpServletRequest)servletRequest;
/*  154 */     HttpServletResponse response = (HttpServletResponse)servletResponse;
/*      */     
/*      */ 
/*  157 */     CORSRequestType requestType = checkRequestType(request);
/*      */     
/*      */ 
/*  160 */     if (isDecorateRequest()) {
/*  161 */       decorateCORSProperties(request, requestType);
/*      */     }
/*  163 */     switch (requestType)
/*      */     {
/*      */ 
/*      */     case SIMPLE: 
/*      */     case ACTUAL: 
/*  168 */       handleSimpleCORS(request, response, filterChain);
/*  169 */       break;
/*      */     
/*      */     case PRE_FLIGHT: 
/*  172 */       handlePreflightCORS(request, response, filterChain);
/*  173 */       break;
/*      */     
/*      */     case NOT_CORS: 
/*  176 */       handleNonCORS(request, response, filterChain);
/*  177 */       break;
/*      */     
/*      */     default: 
/*  180 */       handleInvalidCORS(request, response, filterChain);
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */   public void init()
/*      */     throws ServletException
/*      */   {
/*  188 */     parseAndStore(
/*  189 */       getInitParameter("cors.allowed.origins", ""), 
/*  190 */       getInitParameter("cors.allowed.methods", "GET,POST,HEAD,OPTIONS"), 
/*  191 */       getInitParameter("cors.allowed.headers", "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers"), 
/*  192 */       getInitParameter("cors.exposed.headers", ""), 
/*  193 */       getInitParameter("cors.support.credentials", "false"), 
/*  194 */       getInitParameter("cors.preflight.maxage", "1800"), 
/*  195 */       getInitParameter("cors.request.decorate", "true"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getInitParameter(String name, String defaultValue)
/*      */   {
/*  214 */     String value = getInitParameter(name);
/*  215 */     if (value != null) {
/*  216 */       return value;
/*      */     }
/*      */     
/*  219 */     return defaultValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void handleSimpleCORS(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*      */     throws IOException, ServletException
/*      */   {
/*  238 */     CORSRequestType requestType = checkRequestType(request);
/*  239 */     if ((requestType != CORSRequestType.SIMPLE) && (requestType != CORSRequestType.ACTUAL))
/*      */     {
/*      */ 
/*  242 */       throw new IllegalArgumentException(sm.getString("corsFilter.wrongType2", new Object[] { CORSRequestType.SIMPLE, CORSRequestType.ACTUAL }));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  247 */     String origin = request.getHeader("Origin");
/*  248 */     String method = request.getMethod();
/*      */     
/*      */ 
/*  251 */     if (!isOriginAllowed(origin)) {
/*  252 */       handleInvalidCORS(request, response, filterChain);
/*  253 */       return;
/*      */     }
/*      */     
/*  256 */     if (!getAllowedHttpMethods().contains(method)) {
/*  257 */       handleInvalidCORS(request, response, filterChain);
/*  258 */       return;
/*      */     }
/*      */     
/*  261 */     addStandardHeaders(request, response);
/*      */     
/*      */ 
/*  264 */     filterChain.doFilter(request, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void handlePreflightCORS(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*      */     throws IOException, ServletException
/*      */   {
/*  281 */     CORSRequestType requestType = checkRequestType(request);
/*  282 */     if (requestType != CORSRequestType.PRE_FLIGHT) {
/*  283 */       throw new IllegalArgumentException(sm.getString("corsFilter.wrongType1", new Object[] {CORSRequestType.PRE_FLIGHT
/*  284 */         .name().toLowerCase(Locale.ENGLISH) }));
/*      */     }
/*      */     
/*  287 */     String origin = request.getHeader("Origin");
/*      */     
/*      */ 
/*  290 */     if (!isOriginAllowed(origin)) {
/*  291 */       handleInvalidCORS(request, response, filterChain);
/*  292 */       return;
/*      */     }
/*      */     
/*      */ 
/*  296 */     String accessControlRequestMethod = request.getHeader("Access-Control-Request-Method");
/*      */     
/*  298 */     if (accessControlRequestMethod == null) {
/*  299 */       handleInvalidCORS(request, response, filterChain);
/*  300 */       return;
/*      */     }
/*  302 */     accessControlRequestMethod = accessControlRequestMethod.trim();
/*      */     
/*      */ 
/*      */ 
/*  306 */     String accessControlRequestHeadersHeader = request.getHeader("Access-Control-Request-Headers");
/*      */     
/*  308 */     List<String> accessControlRequestHeaders = new LinkedList();
/*  309 */     String[] headers; if ((accessControlRequestHeadersHeader != null) && 
/*  310 */       (!accessControlRequestHeadersHeader.trim().isEmpty())) {
/*  311 */       headers = accessControlRequestHeadersHeader.trim().split(",");
/*  312 */       for (String header : headers) {
/*  313 */         accessControlRequestHeaders.add(header.trim().toLowerCase(Locale.ENGLISH));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  318 */     if (!getAllowedHttpMethods().contains(accessControlRequestMethod)) {
/*  319 */       handleInvalidCORS(request, response, filterChain);
/*  320 */       return;
/*      */     }
/*      */     
/*      */ 
/*  324 */     if (!accessControlRequestHeaders.isEmpty()) {
/*  325 */       for (String header : accessControlRequestHeaders) {
/*  326 */         if (!getAllowedHttpHeaders().contains(header)) {
/*  327 */           handleInvalidCORS(request, response, filterChain);
/*  328 */           return;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  333 */     addStandardHeaders(request, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleNonCORS(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*      */     throws IOException, ServletException
/*      */   {
/*  354 */     addStandardHeaders(request, response);
/*      */     
/*      */ 
/*  357 */     filterChain.doFilter(request, response);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleInvalidCORS(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*      */   {
/*  370 */     String origin = request.getHeader("Origin");
/*  371 */     String method = request.getMethod();
/*  372 */     String accessControlRequestHeaders = request.getHeader("Access-Control-Request-Headers");
/*      */     
/*      */ 
/*  375 */     response.setContentType("text/plain");
/*  376 */     response.setStatus(403);
/*  377 */     response.resetBuffer();
/*      */     
/*  379 */     if (this.log.isDebugEnabled())
/*      */     {
/*  381 */       StringBuilder message = new StringBuilder("Invalid CORS request; Origin=");
/*  382 */       message.append(origin);
/*  383 */       message.append(";Method=");
/*  384 */       message.append(method);
/*  385 */       if (accessControlRequestHeaders != null) {
/*  386 */         message.append(";Access-Control-Request-Headers=");
/*  387 */         message.append(accessControlRequestHeaders);
/*      */       }
/*  389 */       this.log.debug(message.toString());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addStandardHeaders(HttpServletRequest request, HttpServletResponse response)
/*      */   {
/*  401 */     String method = request.getMethod();
/*  402 */     String origin = request.getHeader("Origin");
/*      */     
/*      */ 
/*      */ 
/*  406 */     boolean anyOriginAllowed = isAnyOriginAllowed();
/*  407 */     if (!anyOriginAllowed)
/*      */     {
/*      */ 
/*  410 */       ResponseUtil.addVaryFieldName(response, "Origin");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  419 */     if (anyOriginAllowed)
/*      */     {
/*  421 */       response.addHeader("Access-Control-Allow-Origin", "*");
/*      */     }
/*      */     else
/*      */     {
/*  425 */       response.addHeader("Access-Control-Allow-Origin", origin);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  431 */     if (isSupportsCredentials()) {
/*  432 */       response.addHeader("Access-Control-Allow-Credentials", "true");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  440 */     Collection<String> exposedHeaders = getExposedHeaders();
/*  441 */     if ((exposedHeaders != null) && (exposedHeaders.size() > 0)) {
/*  442 */       String exposedHeadersString = join(exposedHeaders, ",");
/*  443 */       response.addHeader("Access-Control-Expose-Headers", exposedHeadersString);
/*      */     }
/*      */     
/*      */ 
/*  447 */     if ("OPTIONS".equals(method))
/*      */     {
/*      */ 
/*      */ 
/*  451 */       ResponseUtil.addVaryFieldName(response, "Access-Control-Request-Method");
/*      */       
/*  453 */       ResponseUtil.addVaryFieldName(response, "Access-Control-Request-Headers");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  462 */       long preflightMaxAge = getPreflightMaxAge();
/*  463 */       if (preflightMaxAge > 0L) {
/*  464 */         response.addHeader("Access-Control-Max-Age", 
/*      */         
/*  466 */           String.valueOf(preflightMaxAge));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  471 */       Collection<String> allowedHttpMethods = getAllowedHttpMethods();
/*  472 */       if ((allowedHttpMethods != null) && (!allowedHttpMethods.isEmpty())) {
/*  473 */         response.addHeader("Access-Control-Allow-Methods", 
/*      */         
/*  475 */           join(allowedHttpMethods, ","));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  480 */       Collection<String> allowedHttpHeaders = getAllowedHttpHeaders();
/*  481 */       if ((allowedHttpHeaders != null) && (!allowedHttpHeaders.isEmpty())) {
/*  482 */         response.addHeader("Access-Control-Allow-Headers", 
/*      */         
/*  484 */           join(allowedHttpHeaders, ","));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static void decorateCORSProperties(HttpServletRequest request, CORSRequestType corsRequestType)
/*      */   {
/*  510 */     if (request == null) {
/*  511 */       throw new IllegalArgumentException(sm.getString("corsFilter.nullRequest"));
/*      */     }
/*      */     
/*  514 */     if (corsRequestType == null) {
/*  515 */       throw new IllegalArgumentException(sm.getString("corsFilter.nullRequestType"));
/*      */     }
/*      */     
/*  518 */     switch (corsRequestType) {
/*      */     case SIMPLE: 
/*      */     case ACTUAL: 
/*  521 */       request.setAttribute("cors.isCorsRequest", Boolean.TRUE);
/*      */       
/*  523 */       request.setAttribute("cors.request.origin", request
/*  524 */         .getHeader("Origin"));
/*  525 */       request.setAttribute("cors.request.type", corsRequestType
/*      */       
/*  527 */         .name().toLowerCase(Locale.ENGLISH));
/*  528 */       break;
/*      */     case PRE_FLIGHT: 
/*  530 */       request.setAttribute("cors.isCorsRequest", Boolean.TRUE);
/*      */       
/*      */ 
/*  533 */       request.setAttribute("cors.request.origin", request
/*  534 */         .getHeader("Origin"));
/*  535 */       request.setAttribute("cors.request.type", corsRequestType
/*      */       
/*  537 */         .name().toLowerCase(Locale.ENGLISH));
/*  538 */       String headers = request.getHeader("Access-Control-Request-Headers");
/*      */       
/*  540 */       if (headers == null) {
/*  541 */         headers = "";
/*      */       }
/*  543 */       request.setAttribute("cors.request.headers", headers);
/*      */       
/*  545 */       break;
/*      */     case NOT_CORS: 
/*  547 */       request.setAttribute("cors.isCorsRequest", Boolean.FALSE);
/*      */       
/*      */ 
/*  550 */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String join(Collection<String> elements, String joinSeparator)
/*      */   {
/*  569 */     String separator = ",";
/*  570 */     if (elements == null) {
/*  571 */       return null;
/*      */     }
/*  573 */     if (joinSeparator != null) {
/*  574 */       separator = joinSeparator;
/*      */     }
/*  576 */     StringBuilder buffer = new StringBuilder();
/*  577 */     boolean isFirst = true;
/*  578 */     for (String element : elements) {
/*  579 */       if (!isFirst) {
/*  580 */         buffer.append(separator);
/*      */       } else {
/*  582 */         isFirst = false;
/*      */       }
/*      */       
/*  585 */       if (element != null) {
/*  586 */         buffer.append(element);
/*      */       }
/*      */     }
/*      */     
/*  590 */     return buffer.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected CORSRequestType checkRequestType(HttpServletRequest request)
/*      */   {
/*  601 */     CORSRequestType requestType = CORSRequestType.INVALID_CORS;
/*  602 */     if (request == null)
/*      */     {
/*  604 */       throw new IllegalArgumentException(sm.getString("corsFilter.nullRequest"));
/*      */     }
/*  606 */     String originHeader = request.getHeader("Origin");
/*      */     
/*  608 */     if (originHeader != null) {
/*  609 */       if (originHeader.isEmpty()) {
/*  610 */         requestType = CORSRequestType.INVALID_CORS;
/*  611 */       } else if (!RequestUtil.isValidOrigin(originHeader)) {
/*  612 */         requestType = CORSRequestType.INVALID_CORS;
/*  613 */       } else { if (RequestUtil.isSameOrigin(request, originHeader)) {
/*  614 */           return CORSRequestType.NOT_CORS;
/*      */         }
/*  616 */         String method = request.getMethod();
/*  617 */         if (method != null) {
/*  618 */           if ("OPTIONS".equals(method))
/*      */           {
/*  620 */             String accessControlRequestMethodHeader = request.getHeader("Access-Control-Request-Method");
/*      */             
/*  622 */             if ((accessControlRequestMethodHeader != null) && 
/*  623 */               (!accessControlRequestMethodHeader.isEmpty())) {
/*  624 */               requestType = CORSRequestType.PRE_FLIGHT;
/*  625 */             } else if ((accessControlRequestMethodHeader != null) && 
/*  626 */               (accessControlRequestMethodHeader.isEmpty())) {
/*  627 */               requestType = CORSRequestType.INVALID_CORS;
/*      */             } else {
/*  629 */               requestType = CORSRequestType.ACTUAL;
/*      */             }
/*  631 */           } else if (("GET".equals(method)) || ("HEAD".equals(method))) {
/*  632 */             requestType = CORSRequestType.SIMPLE;
/*  633 */           } else if ("POST".equals(method)) {
/*  634 */             String mediaType = getMediaType(request.getContentType());
/*  635 */             if (mediaType != null)
/*      */             {
/*  637 */               if (SIMPLE_HTTP_REQUEST_CONTENT_TYPE_VALUES.contains(mediaType)) {
/*  638 */                 requestType = CORSRequestType.SIMPLE;
/*      */               } else {
/*  640 */                 requestType = CORSRequestType.ACTUAL;
/*      */               }
/*      */             }
/*      */           } else {
/*  644 */             requestType = CORSRequestType.ACTUAL;
/*      */           }
/*      */         }
/*      */       }
/*      */     } else {
/*  649 */       requestType = CORSRequestType.NOT_CORS;
/*      */     }
/*      */     
/*  652 */     return requestType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String getMediaType(String contentType)
/*      */   {
/*  661 */     if (contentType == null) {
/*  662 */       return null;
/*      */     }
/*  664 */     String result = contentType.toLowerCase(Locale.ENGLISH);
/*  665 */     int firstSemiColonIndex = result.indexOf(';');
/*  666 */     if (firstSemiColonIndex > -1) {
/*  667 */       result = result.substring(0, firstSemiColonIndex);
/*      */     }
/*  669 */     result = result.trim();
/*  670 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isOriginAllowed(String origin)
/*      */   {
/*  682 */     if (isAnyOriginAllowed()) {
/*  683 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  688 */     return getAllowedOrigins().contains(origin);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseAndStore(String allowedOrigins, String allowedHttpMethods, String allowedHttpHeaders, String exposedHeaders, String supportsCredentials, String preflightMaxAge, String decorateRequest)
/*      */     throws ServletException
/*      */   {
/*  718 */     if (allowedOrigins.trim().equals("*")) {
/*  719 */       this.anyOriginAllowed = true;
/*      */     } else {
/*  721 */       this.anyOriginAllowed = false;
/*  722 */       Set<String> setAllowedOrigins = parseStringToSet(allowedOrigins);
/*  723 */       this.allowedOrigins.clear();
/*  724 */       this.allowedOrigins.addAll(setAllowedOrigins);
/*      */     }
/*      */     
/*  727 */     Set<String> setAllowedHttpMethods = parseStringToSet(allowedHttpMethods);
/*  728 */     this.allowedHttpMethods.clear();
/*  729 */     this.allowedHttpMethods.addAll(setAllowedHttpMethods);
/*      */     
/*  731 */     Set<String> setAllowedHttpHeaders = parseStringToSet(allowedHttpHeaders);
/*  732 */     Set<String> lowerCaseHeaders = new HashSet();
/*  733 */     for (String header : setAllowedHttpHeaders) {
/*  734 */       String lowerCase = header.toLowerCase(Locale.ENGLISH);
/*  735 */       lowerCaseHeaders.add(lowerCase);
/*      */     }
/*  737 */     this.allowedHttpHeaders.clear();
/*  738 */     this.allowedHttpHeaders.addAll(lowerCaseHeaders);
/*      */     
/*  740 */     Object setExposedHeaders = parseStringToSet(exposedHeaders);
/*  741 */     this.exposedHeaders.clear();
/*  742 */     this.exposedHeaders.addAll((Collection)setExposedHeaders);
/*      */     
/*      */ 
/*  745 */     this.supportsCredentials = Boolean.parseBoolean(supportsCredentials);
/*      */     
/*  747 */     if ((this.supportsCredentials) && (this.anyOriginAllowed)) {
/*  748 */       throw new ServletException(sm.getString("corsFilter.invalidSupportsCredentials"));
/*      */     }
/*      */     try
/*      */     {
/*  752 */       if (!preflightMaxAge.isEmpty()) {
/*  753 */         this.preflightMaxAge = Long.parseLong(preflightMaxAge);
/*      */       } else {
/*  755 */         this.preflightMaxAge = 0L;
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException e) {
/*  759 */       throw new ServletException(sm.getString("corsFilter.invalidPreflightMaxAge"), e);
/*      */     }
/*      */     
/*      */ 
/*  763 */     this.decorateRequest = Boolean.parseBoolean(decorateRequest);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private Set<String> parseStringToSet(String data)
/*      */   {
/*      */     String[] splits;
/*      */     
/*      */ 
/*      */     String[] splits;
/*      */     
/*      */ 
/*  776 */     if ((data != null) && (data.length() > 0)) {
/*  777 */       splits = data.split(",");
/*      */     } else {
/*  779 */       splits = new String[0];
/*      */     }
/*      */     
/*  782 */     Set<String> set = new HashSet();
/*  783 */     if (splits.length > 0) {
/*  784 */       for (String split : splits) {
/*  785 */         set.add(split.trim());
/*      */       }
/*      */     }
/*      */     
/*  789 */     return set;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected static boolean isValidOrigin(String origin)
/*      */   {
/*  810 */     return RequestUtil.isValidOrigin(origin);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAnyOriginAllowed()
/*      */   {
/*  820 */     return this.anyOriginAllowed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<String> getExposedHeaders()
/*      */   {
/*  830 */     return this.exposedHeaders;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSupportsCredentials()
/*      */   {
/*  841 */     return this.supportsCredentials;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getPreflightMaxAge()
/*      */   {
/*  851 */     return this.preflightMaxAge;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<String> getAllowedOrigins()
/*      */   {
/*  862 */     return this.allowedOrigins;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<String> getAllowedHttpMethods()
/*      */   {
/*  872 */     return this.allowedHttpMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<String> getAllowedHttpHeaders()
/*      */   {
/*  882 */     return this.allowedHttpHeaders;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDecorateRequest()
/*      */   {
/*  893 */     return this.decorateRequest;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readObject(ObjectInputStream ois)
/*      */     throws ClassNotFoundException, IOException
/*      */   {
/*  903 */     ois.defaultReadObject();
/*  904 */     this.log = LogFactory.getLog(CorsFilter.class);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static enum CORSRequestType
/*      */   {
/* 1028 */     SIMPLE, 
/*      */     
/*      */ 
/*      */ 
/* 1032 */     ACTUAL, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1037 */     PRE_FLIGHT, 
/*      */     
/*      */ 
/*      */ 
/* 1041 */     NOT_CORS, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1046 */     INVALID_CORS;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private CORSRequestType() {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 1058 */   public static final Collection<String> SIMPLE_HTTP_REQUEST_CONTENT_TYPE_VALUES = Collections.unmodifiableSet(new HashSet(Arrays.asList(new String[] { "application/x-www-form-urlencoded", "multipart/form-data", "text/plain" })));
/*      */   public static final String DEFAULT_ALLOWED_ORIGINS = "";
/*      */   public static final String DEFAULT_ALLOWED_HTTP_METHODS = "GET,POST,HEAD,OPTIONS";
/*      */   public static final String DEFAULT_PREFLIGHT_MAXAGE = "1800";
/*      */   public static final String DEFAULT_SUPPORTS_CREDENTIALS = "false";
/*      */   public static final String DEFAULT_ALLOWED_HTTP_HEADERS = "Origin,Accept,X-Requested-With,Content-Type,Access-Control-Request-Method,Access-Control-Request-Headers";
/*      */   public static final String DEFAULT_EXPOSED_HEADERS = "";
/*      */   public static final String DEFAULT_DECORATE_REQUEST = "true";
/*      */   public static final String PARAM_CORS_ALLOWED_ORIGINS = "cors.allowed.origins";
/*      */   public static final String PARAM_CORS_SUPPORT_CREDENTIALS = "cors.support.credentials";
/*      */   public static final String PARAM_CORS_EXPOSED_HEADERS = "cors.exposed.headers";
/*      */   public static final String PARAM_CORS_ALLOWED_HEADERS = "cors.allowed.headers";
/*      */   public static final String PARAM_CORS_ALLOWED_METHODS = "cors.allowed.methods";
/*      */   public static final String PARAM_CORS_PREFLIGHT_MAXAGE = "cors.preflight.maxage";
/*      */   public static final String PARAM_CORS_REQUEST_DECORATE = "cors.request.decorate";
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\filters\CorsFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */