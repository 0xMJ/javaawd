/*    */ package org.apache.catalina.webresources;
/*    */ 
/*    */ import java.util.jar.JarEntry;
/*    */ import org.apache.juli.logging.Log;
/*    */ import org.apache.juli.logging.LogFactory;
/*    */ import org.apache.tomcat.util.buf.UriUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WarResource
/*    */   extends AbstractSingleArchiveResource
/*    */ {
/* 31 */   private static final Log log = LogFactory.getLog(WarResource.class);
/*    */   
/*    */ 
/*    */   public WarResource(AbstractArchiveResourceSet archiveResourceSet, String webAppPath, String baseUrl, JarEntry jarEntry)
/*    */   {
/* 36 */     super(archiveResourceSet, webAppPath, "war:" + baseUrl + UriUtil.getWarSeparator(), jarEntry, baseUrl);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected Log getLog()
/*    */   {
/* 43 */     return log;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\webresources\WarResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */