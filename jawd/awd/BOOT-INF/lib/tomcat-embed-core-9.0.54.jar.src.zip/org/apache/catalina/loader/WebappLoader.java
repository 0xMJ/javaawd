/*     */ package org.apache.catalina.loader;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.io.File;
/*     */ import java.io.FilePermission;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import javax.management.ObjectName;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.catalina.Container;
/*     */ import org.apache.catalina.Context;
/*     */ import org.apache.catalina.Globals;
/*     */ import org.apache.catalina.LifecycleException;
/*     */ import org.apache.catalina.LifecycleState;
/*     */ import org.apache.catalina.Loader;
/*     */ import org.apache.catalina.WebResourceRoot;
/*     */ import org.apache.catalina.util.LifecycleMBeanBase;
/*     */ import org.apache.catalina.util.ToStringUtil;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.buf.UDecoder;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ import org.apache.tomcat.util.modeler.Registry;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebappLoader
/*     */   extends LifecycleMBeanBase
/*     */   implements Loader, PropertyChangeListener
/*     */ {
/*  67 */   private static final Log log = LogFactory.getLog(WebappLoader.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebappLoader()
/*     */   {
/*  76 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public WebappLoader(ClassLoader parent)
/*     */   {
/*  93 */     this.parentClassLoader = parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   private WebappClassLoaderBase classLoader = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */   private Context context = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */   private boolean delegate = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */   private String loaderClass = ParallelWebappClassLoader.class.getName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */   private ClassLoader parentClassLoader = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */   private boolean reloadable = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 142 */   protected static final StringManager sm = StringManager.getManager("org.apache.catalina.loader");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */   protected final PropertyChangeSupport support = new PropertyChangeSupport(this);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */   private String classpath = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassLoader getClassLoader()
/*     */   {
/* 164 */     return this.classLoader;
/*     */   }
/*     */   
/*     */ 
/*     */   public Context getContext()
/*     */   {
/* 170 */     return this.context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setContext(Context context)
/*     */   {
/* 177 */     if (this.context == context) {
/* 178 */       return;
/*     */     }
/*     */     
/* 181 */     if (getState().isAvailable())
/*     */     {
/* 183 */       throw new IllegalStateException(sm.getString("webappLoader.setContext.ise"));
/*     */     }
/*     */     
/*     */ 
/* 187 */     if (this.context != null) {
/* 188 */       this.context.removePropertyChangeListener(this);
/*     */     }
/*     */     
/*     */ 
/* 192 */     Context oldContext = this.context;
/* 193 */     this.context = context;
/* 194 */     this.support.firePropertyChange("context", oldContext, this.context);
/*     */     
/*     */ 
/* 197 */     if (this.context != null) {
/* 198 */       setReloadable(this.context.getReloadable());
/* 199 */       this.context.addPropertyChangeListener(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getDelegate()
/*     */   {
/* 210 */     return this.delegate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDelegate(boolean delegate)
/*     */   {
/* 222 */     boolean oldDelegate = this.delegate;
/* 223 */     this.delegate = delegate;
/* 224 */     this.support.firePropertyChange("delegate", Boolean.valueOf(oldDelegate), 
/* 225 */       Boolean.valueOf(this.delegate));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLoaderClass()
/*     */   {
/* 233 */     return this.loaderClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoaderClass(String loaderClass)
/*     */   {
/* 243 */     this.loaderClass = loaderClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoaderInstance(WebappClassLoaderBase loaderInstance)
/*     */   {
/* 254 */     this.classLoader = loaderInstance;
/* 255 */     setLoaderClass(loaderInstance.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getReloadable()
/*     */   {
/* 264 */     return this.reloadable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReloadable(boolean reloadable)
/*     */   {
/* 276 */     boolean oldReloadable = this.reloadable;
/* 277 */     this.reloadable = reloadable;
/* 278 */     this.support.firePropertyChange("reloadable", 
/* 279 */       Boolean.valueOf(oldReloadable), 
/* 280 */       Boolean.valueOf(this.reloadable));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/* 294 */     this.support.addPropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void backgroundProcess()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 10	org/apache/catalina/loader/WebappLoader:reloadable	Z
/*     */     //   4: ifeq +121 -> 125
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual 34	org/apache/catalina/loader/WebappLoader:modified	()Z
/*     */     //   11: ifeq +114 -> 125
/*     */     //   14: invokestatic 35	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   17: ldc 36
/*     */     //   19: invokevirtual 37	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   22: invokevirtual 38	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   25: aload_0
/*     */     //   26: getfield 4	org/apache/catalina/loader/WebappLoader:context	Lorg/apache/catalina/Context;
/*     */     //   29: ifnull +12 -> 41
/*     */     //   32: aload_0
/*     */     //   33: getfield 4	org/apache/catalina/loader/WebappLoader:context	Lorg/apache/catalina/Context;
/*     */     //   36: invokeinterface 39 1 0
/*     */     //   41: aload_0
/*     */     //   42: getfield 4	org/apache/catalina/loader/WebappLoader:context	Lorg/apache/catalina/Context;
/*     */     //   45: ifnull +80 -> 125
/*     */     //   48: aload_0
/*     */     //   49: getfield 4	org/apache/catalina/loader/WebappLoader:context	Lorg/apache/catalina/Context;
/*     */     //   52: invokeinterface 40 1 0
/*     */     //   57: ifnull +68 -> 125
/*     */     //   60: invokestatic 35	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   63: aload_0
/*     */     //   64: getfield 4	org/apache/catalina/loader/WebappLoader:context	Lorg/apache/catalina/Context;
/*     */     //   67: invokeinterface 40 1 0
/*     */     //   72: invokeinterface 41 1 0
/*     */     //   77: invokevirtual 38	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   80: goto +45 -> 125
/*     */     //   83: astore_1
/*     */     //   84: aload_0
/*     */     //   85: getfield 4	org/apache/catalina/loader/WebappLoader:context	Lorg/apache/catalina/Context;
/*     */     //   88: ifnull +35 -> 123
/*     */     //   91: aload_0
/*     */     //   92: getfield 4	org/apache/catalina/loader/WebappLoader:context	Lorg/apache/catalina/Context;
/*     */     //   95: invokeinterface 40 1 0
/*     */     //   100: ifnull +23 -> 123
/*     */     //   103: invokestatic 35	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   106: aload_0
/*     */     //   107: getfield 4	org/apache/catalina/loader/WebappLoader:context	Lorg/apache/catalina/Context;
/*     */     //   110: invokeinterface 40 1 0
/*     */     //   115: invokeinterface 41 1 0
/*     */     //   120: invokevirtual 38	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   123: aload_1
/*     */     //   124: athrow
/*     */     //   125: return
/*     */     // Line number table:
/*     */     //   Java source line #306	-> byte code offset #0
/*     */     //   Java source line #308	-> byte code offset #14
/*     */     //   Java source line #309	-> byte code offset #19
/*     */     //   Java source line #310	-> byte code offset #25
/*     */     //   Java source line #311	-> byte code offset #32
/*     */     //   Java source line #314	-> byte code offset #41
/*     */     //   Java source line #315	-> byte code offset #60
/*     */     //   Java source line #316	-> byte code offset #67
/*     */     //   Java source line #314	-> byte code offset #83
/*     */     //   Java source line #315	-> byte code offset #103
/*     */     //   Java source line #316	-> byte code offset #110
/*     */     //   Java source line #318	-> byte code offset #123
/*     */     //   Java source line #320	-> byte code offset #125
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	126	0	this	WebappLoader
/*     */     //   83	41	1	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   14	41	83	finally
/*     */   }
/*     */   
/*     */   public String[] getLoaderRepositories()
/*     */   {
/* 324 */     if (this.classLoader == null) {
/* 325 */       return new String[0];
/*     */     }
/* 327 */     URL[] urls = this.classLoader.getURLs();
/* 328 */     String[] result = new String[urls.length];
/* 329 */     for (int i = 0; i < urls.length; i++) {
/* 330 */       result[i] = urls[i].toExternalForm();
/*     */     }
/* 332 */     return result;
/*     */   }
/*     */   
/*     */   public String getLoaderRepositoriesString() {
/* 336 */     String[] repositories = getLoaderRepositories();
/* 337 */     StringBuilder sb = new StringBuilder();
/* 338 */     for (String repository : repositories) {
/* 339 */       sb.append(repository).append(':');
/*     */     }
/* 341 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getClasspath()
/*     */   {
/* 352 */     return this.classpath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean modified()
/*     */   {
/* 362 */     return this.classLoader != null ? this.classLoader.modified() : false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/* 373 */     this.support.removePropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 382 */     return ToStringUtil.toString(this, this.context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startInternal()
/*     */     throws LifecycleException
/*     */   {
/* 396 */     if (log.isDebugEnabled()) {
/* 397 */       log.debug(sm.getString("webappLoader.starting"));
/*     */     }
/*     */     
/* 400 */     if (this.context.getResources() == null) {
/* 401 */       log.info(sm.getString("webappLoader.noResources", new Object[] { this.context }));
/* 402 */       setState(LifecycleState.STARTING);
/* 403 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 409 */       this.classLoader = createClassLoader();
/* 410 */       this.classLoader.setResources(this.context.getResources());
/* 411 */       this.classLoader.setDelegate(this.delegate);
/*     */       
/*     */ 
/* 414 */       setClassPath();
/*     */       
/* 416 */       setPermissions();
/*     */       
/* 418 */       this.classLoader.start();
/*     */       
/* 420 */       String contextName = this.context.getName();
/* 421 */       if (!contextName.startsWith("/")) {
/* 422 */         contextName = "/" + contextName;
/*     */       }
/*     */       
/*     */ 
/* 426 */       ObjectName cloname = new ObjectName(this.context.getDomain() + ":type=" + this.classLoader.getClass().getSimpleName() + ",host=" + this.context.getParent().getName() + ",context=" + contextName);
/* 427 */       Registry.getRegistry(null, null)
/* 428 */         .registerComponent(this.classLoader, cloname, null);
/*     */     }
/*     */     catch (Throwable t) {
/* 431 */       t = ExceptionUtils.unwrapInvocationTargetException(t);
/* 432 */       ExceptionUtils.handleThrowable(t);
/* 433 */       throw new LifecycleException(sm.getString("webappLoader.startError"), t);
/*     */     }
/*     */     
/* 436 */     setState(LifecycleState.STARTING);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected void stopInternal()
/*     */     throws LifecycleException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 54	org/apache/catalina/loader/WebappLoader:log	Lorg/apache/juli/logging/Log;
/*     */     //   3: invokeinterface 55 1 0
/*     */     //   8: ifeq +19 -> 27
/*     */     //   11: getstatic 54	org/apache/catalina/loader/WebappLoader:log	Lorg/apache/juli/logging/Log;
/*     */     //   14: getstatic 18	org/apache/catalina/loader/WebappLoader:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   17: ldc 91
/*     */     //   19: invokevirtual 20	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   22: invokeinterface 57 2 0
/*     */     //   27: aload_0
/*     */     //   28: getstatic 92	org/apache/catalina/LifecycleState:STOPPING	Lorg/apache/catalina/LifecycleState;
/*     */     //   31: invokevirtual 64	org/apache/catalina/loader/WebappLoader:setState	(Lorg/apache/catalina/LifecycleState;)V
/*     */     //   34: aload_0
/*     */     //   35: getfield 4	org/apache/catalina/loader/WebappLoader:context	Lorg/apache/catalina/Context;
/*     */     //   38: invokeinterface 93 1 0
/*     */     //   43: astore_1
/*     */     //   44: aload_1
/*     */     //   45: ldc 95
/*     */     //   47: invokeinterface 96 2 0
/*     */     //   52: aload_0
/*     */     //   53: getfield 3	org/apache/catalina/loader/WebappLoader:classLoader	Lorg/apache/catalina/loader/WebappClassLoaderBase;
/*     */     //   56: ifnull +178 -> 234
/*     */     //   59: aload_0
/*     */     //   60: getfield 3	org/apache/catalina/loader/WebappLoader:classLoader	Lorg/apache/catalina/loader/WebappClassLoaderBase;
/*     */     //   63: invokevirtual 97	org/apache/catalina/loader/WebappClassLoaderBase:stop	()V
/*     */     //   66: aload_0
/*     */     //   67: getfield 3	org/apache/catalina/loader/WebappLoader:classLoader	Lorg/apache/catalina/loader/WebappClassLoaderBase;
/*     */     //   70: invokevirtual 98	org/apache/catalina/loader/WebappClassLoaderBase:destroy	()V
/*     */     //   73: goto +13 -> 86
/*     */     //   76: astore_2
/*     */     //   77: aload_0
/*     */     //   78: getfield 3	org/apache/catalina/loader/WebappLoader:classLoader	Lorg/apache/catalina/loader/WebappClassLoaderBase;
/*     */     //   81: invokevirtual 98	org/apache/catalina/loader/WebappClassLoaderBase:destroy	()V
/*     */     //   84: aload_2
/*     */     //   85: athrow
/*     */     //   86: aload_0
/*     */     //   87: getfield 4	org/apache/catalina/loader/WebappLoader:context	Lorg/apache/catalina/Context;
/*     */     //   90: invokeinterface 71 1 0
/*     */     //   95: astore_2
/*     */     //   96: aload_2
/*     */     //   97: ldc 72
/*     */     //   99: invokevirtual 73	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*     */     //   102: ifne +23 -> 125
/*     */     //   105: new 46	java/lang/StringBuilder
/*     */     //   108: dup
/*     */     //   109: invokespecial 47	java/lang/StringBuilder:<init>	()V
/*     */     //   112: ldc 72
/*     */     //   114: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   117: aload_2
/*     */     //   118: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   121: invokevirtual 50	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   124: astore_2
/*     */     //   125: new 74	javax/management/ObjectName
/*     */     //   128: dup
/*     */     //   129: new 46	java/lang/StringBuilder
/*     */     //   132: dup
/*     */     //   133: invokespecial 47	java/lang/StringBuilder:<init>	()V
/*     */     //   136: aload_0
/*     */     //   137: getfield 4	org/apache/catalina/loader/WebappLoader:context	Lorg/apache/catalina/Context;
/*     */     //   140: invokeinterface 75 1 0
/*     */     //   145: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   148: ldc 76
/*     */     //   150: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   153: aload_0
/*     */     //   154: getfield 3	org/apache/catalina/loader/WebappLoader:classLoader	Lorg/apache/catalina/loader/WebappClassLoaderBase;
/*     */     //   157: invokevirtual 30	java/lang/Object:getClass	()Ljava/lang/Class;
/*     */     //   160: invokevirtual 77	java/lang/Class:getSimpleName	()Ljava/lang/String;
/*     */     //   163: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   166: ldc 78
/*     */     //   168: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   171: aload_0
/*     */     //   172: getfield 4	org/apache/catalina/loader/WebappLoader:context	Lorg/apache/catalina/Context;
/*     */     //   175: invokeinterface 79 1 0
/*     */     //   180: invokeinterface 80 1 0
/*     */     //   185: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   188: ldc 81
/*     */     //   190: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   193: aload_2
/*     */     //   194: invokevirtual 48	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   197: invokevirtual 50	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   200: invokespecial 82	javax/management/ObjectName:<init>	(Ljava/lang/String;)V
/*     */     //   203: astore_3
/*     */     //   204: aconst_null
/*     */     //   205: aconst_null
/*     */     //   206: invokestatic 83	org/apache/tomcat/util/modeler/Registry:getRegistry	(Ljava/lang/Object;Ljava/lang/Object;)Lorg/apache/tomcat/util/modeler/Registry;
/*     */     //   209: aload_3
/*     */     //   210: invokevirtual 99	org/apache/tomcat/util/modeler/Registry:unregisterComponent	(Ljavax/management/ObjectName;)V
/*     */     //   213: goto +21 -> 234
/*     */     //   216: astore_2
/*     */     //   217: getstatic 54	org/apache/catalina/loader/WebappLoader:log	Lorg/apache/juli/logging/Log;
/*     */     //   220: getstatic 18	org/apache/catalina/loader/WebappLoader:sm	Lorg/apache/tomcat/util/res/StringManager;
/*     */     //   223: ldc 101
/*     */     //   225: invokevirtual 20	org/apache/tomcat/util/res/StringManager:getString	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   228: aload_2
/*     */     //   229: invokeinterface 102 3 0
/*     */     //   234: aload_0
/*     */     //   235: aconst_null
/*     */     //   236: putfield 3	org/apache/catalina/loader/WebappLoader:classLoader	Lorg/apache/catalina/loader/WebappClassLoaderBase;
/*     */     //   239: return
/*     */     // Line number table:
/*     */     //   Java source line #450	-> byte code offset #0
/*     */     //   Java source line #451	-> byte code offset #11
/*     */     //   Java source line #454	-> byte code offset #27
/*     */     //   Java source line #457	-> byte code offset #34
/*     */     //   Java source line #458	-> byte code offset #44
/*     */     //   Java source line #461	-> byte code offset #52
/*     */     //   Java source line #463	-> byte code offset #59
/*     */     //   Java source line #465	-> byte code offset #66
/*     */     //   Java source line #466	-> byte code offset #73
/*     */     //   Java source line #465	-> byte code offset #76
/*     */     //   Java source line #466	-> byte code offset #84
/*     */     //   Java source line #470	-> byte code offset #86
/*     */     //   Java source line #471	-> byte code offset #96
/*     */     //   Java source line #472	-> byte code offset #105
/*     */     //   Java source line #474	-> byte code offset #125
/*     */     //   Java source line #475	-> byte code offset #157
/*     */     //   Java source line #476	-> byte code offset #175
/*     */     //   Java source line #477	-> byte code offset #204
/*     */     //   Java source line #480	-> byte code offset #213
/*     */     //   Java source line #478	-> byte code offset #216
/*     */     //   Java source line #479	-> byte code offset #217
/*     */     //   Java source line #484	-> byte code offset #234
/*     */     //   Java source line #485	-> byte code offset #239
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	240	0	this	WebappLoader
/*     */     //   43	2	1	servletContext	ServletContext
/*     */     //   76	9	2	localObject	Object
/*     */     //   95	99	2	contextName	String
/*     */     //   216	13	2	e	Exception
/*     */     //   203	7	3	cloname	ObjectName
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   59	66	76	finally
/*     */     //   86	213	216	java/lang/Exception
/*     */   }
/*     */   
/*     */   public void propertyChange(PropertyChangeEvent event)
/*     */   {
/* 500 */     if (!(event.getSource() instanceof Context)) {
/* 501 */       return;
/*     */     }
/*     */     
/*     */ 
/* 505 */     if (event.getPropertyName().equals("reloadable")) {
/*     */       try
/*     */       {
/* 508 */         setReloadable(((Boolean)event.getNewValue()).booleanValue());
/*     */       } catch (NumberFormatException e) {
/* 510 */         log.error(sm.getString("webappLoader.reloadable", new Object[] {event
/* 511 */           .getNewValue().toString() }));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private WebappClassLoaderBase createClassLoader()
/*     */     throws Exception
/*     */   {
/* 525 */     if (this.classLoader != null) {
/* 526 */       return this.classLoader;
/*     */     }
/*     */     
/* 529 */     if (this.parentClassLoader == null) {
/* 530 */       this.parentClassLoader = this.context.getParentClassLoader();
/*     */     } else {
/* 532 */       this.context.setParentClassLoader(this.parentClassLoader);
/*     */     }
/*     */     
/* 535 */     if (ParallelWebappClassLoader.class.getName().equals(this.loaderClass)) {
/* 536 */       return new ParallelWebappClassLoader(this.parentClassLoader);
/*     */     }
/*     */     
/* 539 */     Class<?> clazz = Class.forName(this.loaderClass);
/* 540 */     WebappClassLoaderBase classLoader = null;
/*     */     
/* 542 */     Class<?>[] argTypes = { ClassLoader.class };
/* 543 */     Object[] args = { this.parentClassLoader };
/* 544 */     Constructor<?> constr = clazz.getConstructor(argTypes);
/* 545 */     classLoader = (WebappClassLoaderBase)constr.newInstance(args);
/*     */     
/* 547 */     return classLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setPermissions()
/*     */   {
/* 556 */     if (!Globals.IS_SECURITY_ENABLED) {
/* 557 */       return;
/*     */     }
/* 559 */     if (this.context == null) {
/* 560 */       return;
/*     */     }
/*     */     
/*     */ 
/* 564 */     ServletContext servletContext = this.context.getServletContext();
/*     */     
/*     */ 
/*     */ 
/* 568 */     File workDir = (File)servletContext.getAttribute("javax.servlet.context.tempdir");
/* 569 */     if (workDir != null) {
/*     */       try {
/* 571 */         String workDirPath = workDir.getCanonicalPath();
/* 572 */         this.classLoader
/* 573 */           .addPermission(new FilePermission(workDirPath, "read,write"));
/* 574 */         this.classLoader
/* 575 */           .addPermission(new FilePermission(workDirPath + File.separator + "-", "read,write,delete"));
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 582 */     for (URL url : this.context.getResources().getBaseUrls()) {
/* 583 */       this.classLoader.addPermission(url);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setClassPath()
/*     */   {
/* 595 */     if (this.context == null) {
/* 596 */       return;
/*     */     }
/* 598 */     ServletContext servletContext = this.context.getServletContext();
/* 599 */     if (servletContext == null) {
/* 600 */       return;
/*     */     }
/*     */     
/* 603 */     StringBuilder classpath = new StringBuilder();
/*     */     
/*     */ 
/* 606 */     ClassLoader loader = getClassLoader();
/*     */     
/* 608 */     if ((this.delegate) && (loader != null))
/*     */     {
/* 610 */       loader = loader.getParent();
/*     */     }
/*     */     
/* 613 */     while ((loader != null) && 
/* 614 */       (buildClassPath(classpath, loader)))
/*     */     {
/*     */ 
/* 617 */       loader = loader.getParent();
/*     */     }
/*     */     
/* 620 */     if (this.delegate)
/*     */     {
/* 622 */       loader = getClassLoader();
/* 623 */       if (loader != null) {
/* 624 */         buildClassPath(classpath, loader);
/*     */       }
/*     */     }
/*     */     
/* 628 */     this.classpath = classpath.toString();
/*     */     
/*     */ 
/* 631 */     servletContext.setAttribute("org.apache.catalina.jsp_classpath", this.classpath);
/*     */   }
/*     */   
/*     */   private boolean buildClassPath(StringBuilder classpath, ClassLoader loader)
/*     */   {
/* 636 */     if ((loader instanceof URLClassLoader)) {
/* 637 */       URL[] repositories = ((URLClassLoader)loader).getURLs();
/* 638 */       for (URL url : repositories) {
/* 639 */         String repository = url.toString();
/* 640 */         if (repository.startsWith("file://")) {
/* 641 */           repository = UDecoder.URLDecode(repository.substring(7), StandardCharsets.UTF_8);
/* 642 */         } else { if (!repository.startsWith("file:")) continue;
/* 643 */           repository = UDecoder.URLDecode(repository.substring(5), StandardCharsets.UTF_8);
/*     */         }
/*     */         
/*     */ 
/* 647 */         if (repository != null)
/*     */         {
/*     */ 
/* 650 */           if (classpath.length() > 0) {
/* 651 */             classpath.append(File.pathSeparator);
/*     */           }
/* 653 */           classpath.append(repository);
/*     */         }
/* 655 */       } } else { if (loader == ClassLoader.getSystemClassLoader())
/*     */       {
/*     */ 
/* 658 */         String cp = System.getProperty("java.class.path");
/* 659 */         if ((cp != null) && (cp.length() > 0)) {
/* 660 */           if (classpath.length() > 0) {
/* 661 */             classpath.append(File.pathSeparator);
/*     */           }
/* 663 */           classpath.append(cp);
/*     */         }
/* 665 */         return false;
/*     */       }
/*     */       
/* 668 */       if (!JreCompat.isGraalAvailable()) {
/* 669 */         log.info(sm.getString("webappLoader.unknownClassLoader", new Object[] { loader, loader.getClass() }));
/*     */       }
/* 671 */       return false;
/*     */     }
/* 673 */     return true;
/*     */   }
/*     */   
/*     */   protected String getDomainInternal()
/*     */   {
/* 678 */     return this.context.getDomain();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getObjectNameKeyProperties()
/*     */   {
/* 685 */     StringBuilder name = new StringBuilder("type=Loader");
/*     */     
/* 687 */     name.append(",host=");
/* 688 */     name.append(this.context.getParent().getName());
/*     */     
/* 690 */     name.append(",context=");
/*     */     
/* 692 */     String contextName = this.context.getName();
/* 693 */     if (!contextName.startsWith("/")) {
/* 694 */       name.append('/');
/*     */     }
/* 696 */     name.append(contextName);
/*     */     
/* 698 */     return name.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-core-9.0.54.jar!\org\apache\catalina\loader\WebappLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */