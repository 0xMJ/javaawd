/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.util.Base64;
/*    */ import java.util.Base64.Encoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Base64Util
/*    */ {
/* 28 */   private static final Base64.Encoder encoder = ;
/*    */   
/*    */ 
/*    */ 
/*    */   public static String encode(String str)
/*    */   {
/* 34 */     return str != null ? encoder.encodeToString(str.getBytes()) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\META-INF\versions\9\org\apache\logging\log4j\util\Base64Util.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       0.7.1
 */