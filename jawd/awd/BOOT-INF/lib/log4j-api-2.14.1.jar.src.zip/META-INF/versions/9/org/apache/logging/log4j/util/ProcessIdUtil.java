/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProcessIdUtil
/*    */ {
/*    */   public static final String DEFAULT_PROCESSID = "-";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getProcessId()
/*    */   {
/*    */     try
/*    */     {
/* 25 */       return Long.toString(ProcessHandle.current().pid());
/*    */     } catch (Exception ex) {}
/* 27 */     return "-";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\META-INF\versions\9\org\apache\logging\log4j\util\ProcessIdUtil.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       0.7.1
 */