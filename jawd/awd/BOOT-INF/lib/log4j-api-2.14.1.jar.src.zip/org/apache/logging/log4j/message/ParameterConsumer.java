package org.apache.logging.log4j.message;

public abstract interface ParameterConsumer<S>
{
  public abstract void accept(Object paramObject, int paramInt, S paramS);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\message\ParameterConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */