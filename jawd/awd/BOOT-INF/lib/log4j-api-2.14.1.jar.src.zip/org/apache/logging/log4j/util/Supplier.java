package org.apache.logging.log4j.util;

public abstract interface Supplier<T>
{
  public abstract T get();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\util\Supplier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */