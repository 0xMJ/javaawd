package org.apache.logging.log4j.spi;

import java.util.Map;

public abstract interface ObjectThreadContextMap
  extends CleanableThreadContextMap
{
  public abstract <V> V getValue(String paramString);
  
  public abstract <V> void putValue(String paramString, V paramV);
  
  public abstract <V> void putAllValues(Map<String, V> paramMap);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\spi\ObjectThreadContextMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */