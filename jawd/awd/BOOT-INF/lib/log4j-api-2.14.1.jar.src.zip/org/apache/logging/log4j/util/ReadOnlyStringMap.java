package org.apache.logging.log4j.util;

import java.io.Serializable;
import java.util.Map;

public abstract interface ReadOnlyStringMap
  extends Serializable
{
  public abstract Map<String, String> toMap();
  
  public abstract boolean containsKey(String paramString);
  
  public abstract <V> void forEach(BiConsumer<String, ? super V> paramBiConsumer);
  
  public abstract <V, S> void forEach(TriConsumer<String, ? super V, S> paramTriConsumer, S paramS);
  
  public abstract <V> V getValue(String paramString);
  
  public abstract boolean isEmpty();
  
  public abstract int size();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\util\ReadOnlyStringMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */