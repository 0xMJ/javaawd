/*     */ package org.apache.logging.log4j.spi;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.util.LoaderUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLoggerAdapter<L>
/*     */   implements LoggerAdapter<L>, LoggerContextShutdownAware
/*     */ {
/*  41 */   protected final Map<LoggerContext, ConcurrentMap<String, L>> registry = new ConcurrentHashMap();
/*     */   
/*  43 */   private final ReadWriteLock lock = new ReentrantReadWriteLock(true);
/*     */   
/*     */   public L getLogger(String name)
/*     */   {
/*  47 */     LoggerContext context = getContext();
/*  48 */     ConcurrentMap<String, L> loggers = getLoggersInContext(context);
/*  49 */     L logger = loggers.get(name);
/*  50 */     if (logger != null) {
/*  51 */       return logger;
/*     */     }
/*  53 */     loggers.putIfAbsent(name, newLogger(name, context));
/*  54 */     return (L)loggers.get(name);
/*     */   }
/*     */   
/*     */   public void contextShutdown(LoggerContext loggerContext)
/*     */   {
/*  59 */     this.registry.remove(loggerContext);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public ConcurrentMap<String, L> getLoggersInContext(LoggerContext context)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 7	org/apache/logging/log4j/spi/AbstractLoggerAdapter:lock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   4: invokeinterface 14 1 0
/*     */     //   9: invokeinterface 15 1 0
/*     */     //   14: aload_0
/*     */     //   15: getfield 4	org/apache/logging/log4j/spi/AbstractLoggerAdapter:registry	Ljava/util/Map;
/*     */     //   18: aload_1
/*     */     //   19: invokeinterface 16 2 0
/*     */     //   24: checkcast 17	java/util/concurrent/ConcurrentMap
/*     */     //   27: astore_2
/*     */     //   28: aload_0
/*     */     //   29: getfield 7	org/apache/logging/log4j/spi/AbstractLoggerAdapter:lock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   32: invokeinterface 14 1 0
/*     */     //   37: invokeinterface 18 1 0
/*     */     //   42: goto +20 -> 62
/*     */     //   45: astore_3
/*     */     //   46: aload_0
/*     */     //   47: getfield 7	org/apache/logging/log4j/spi/AbstractLoggerAdapter:lock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   50: invokeinterface 14 1 0
/*     */     //   55: invokeinterface 18 1 0
/*     */     //   60: aload_3
/*     */     //   61: athrow
/*     */     //   62: aload_2
/*     */     //   63: ifnull +5 -> 68
/*     */     //   66: aload_2
/*     */     //   67: areturn
/*     */     //   68: aload_0
/*     */     //   69: getfield 7	org/apache/logging/log4j/spi/AbstractLoggerAdapter:lock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   72: invokeinterface 19 1 0
/*     */     //   77: invokeinterface 15 1 0
/*     */     //   82: aload_0
/*     */     //   83: getfield 4	org/apache/logging/log4j/spi/AbstractLoggerAdapter:registry	Ljava/util/Map;
/*     */     //   86: aload_1
/*     */     //   87: invokeinterface 16 2 0
/*     */     //   92: checkcast 17	java/util/concurrent/ConcurrentMap
/*     */     //   95: astore_2
/*     */     //   96: aload_2
/*     */     //   97: ifnonnull +40 -> 137
/*     */     //   100: new 2	java/util/concurrent/ConcurrentHashMap
/*     */     //   103: dup
/*     */     //   104: invokespecial 3	java/util/concurrent/ConcurrentHashMap:<init>	()V
/*     */     //   107: astore_2
/*     */     //   108: aload_0
/*     */     //   109: getfield 4	org/apache/logging/log4j/spi/AbstractLoggerAdapter:registry	Ljava/util/Map;
/*     */     //   112: aload_1
/*     */     //   113: aload_2
/*     */     //   114: invokeinterface 20 3 0
/*     */     //   119: pop
/*     */     //   120: aload_1
/*     */     //   121: instanceof 21
/*     */     //   124: ifeq +13 -> 137
/*     */     //   127: aload_1
/*     */     //   128: checkcast 21	org/apache/logging/log4j/spi/LoggerContextShutdownEnabled
/*     */     //   131: aload_0
/*     */     //   132: invokeinterface 22 2 0
/*     */     //   137: aload_2
/*     */     //   138: astore_3
/*     */     //   139: aload_0
/*     */     //   140: getfield 7	org/apache/logging/log4j/spi/AbstractLoggerAdapter:lock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   143: invokeinterface 19 1 0
/*     */     //   148: invokeinterface 18 1 0
/*     */     //   153: aload_3
/*     */     //   154: areturn
/*     */     //   155: astore 4
/*     */     //   157: aload_0
/*     */     //   158: getfield 7	org/apache/logging/log4j/spi/AbstractLoggerAdapter:lock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   161: invokeinterface 19 1 0
/*     */     //   166: invokeinterface 18 1 0
/*     */     //   171: aload 4
/*     */     //   173: athrow
/*     */     // Line number table:
/*     */     //   Java source line #70	-> byte code offset #0
/*     */     //   Java source line #72	-> byte code offset #14
/*     */     //   Java source line #74	-> byte code offset #28
/*     */     //   Java source line #75	-> byte code offset #42
/*     */     //   Java source line #74	-> byte code offset #45
/*     */     //   Java source line #75	-> byte code offset #60
/*     */     //   Java source line #77	-> byte code offset #62
/*     */     //   Java source line #78	-> byte code offset #66
/*     */     //   Java source line #80	-> byte code offset #68
/*     */     //   Java source line #82	-> byte code offset #82
/*     */     //   Java source line #83	-> byte code offset #96
/*     */     //   Java source line #84	-> byte code offset #100
/*     */     //   Java source line #85	-> byte code offset #108
/*     */     //   Java source line #86	-> byte code offset #120
/*     */     //   Java source line #87	-> byte code offset #127
/*     */     //   Java source line #90	-> byte code offset #137
/*     */     //   Java source line #92	-> byte code offset #139
/*     */     //   Java source line #90	-> byte code offset #153
/*     */     //   Java source line #92	-> byte code offset #155
/*     */     //   Java source line #93	-> byte code offset #171
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	174	0	this	AbstractLoggerAdapter<L>
/*     */     //   0	174	1	context	LoggerContext
/*     */     //   27	2	2	loggers	ConcurrentMap<String, L>
/*     */     //   62	76	2	loggers	ConcurrentMap<String, L>
/*     */     //   45	16	3	localObject1	Object
/*     */     //   155	17	4	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   14	28	45	finally
/*     */     //   82	139	155	finally
/*     */     //   155	157	155	finally
/*     */   }
/*     */   
/*     */   public Set<LoggerContext> getLoggerContexts()
/*     */   {
/* 100 */     return new HashSet(this.registry.keySet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract L newLogger(String paramString, LoggerContext paramLoggerContext);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract LoggerContext getContext();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LoggerContext getContext(Class<?> callerClass)
/*     */   {
/* 130 */     ClassLoader cl = null;
/* 131 */     if (callerClass != null) {
/* 132 */       cl = callerClass.getClassLoader();
/*     */     }
/* 134 */     if (cl == null) {
/* 135 */       cl = LoaderUtil.getThreadContextClassLoader();
/*     */     }
/* 137 */     return LogManager.getContext(cl, false);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void close()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 7	org/apache/logging/log4j/spi/AbstractLoggerAdapter:lock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   4: invokeinterface 19 1 0
/*     */     //   9: invokeinterface 15 1 0
/*     */     //   14: aload_0
/*     */     //   15: getfield 4	org/apache/logging/log4j/spi/AbstractLoggerAdapter:registry	Ljava/util/Map;
/*     */     //   18: invokeinterface 29 1 0
/*     */     //   23: aload_0
/*     */     //   24: getfield 7	org/apache/logging/log4j/spi/AbstractLoggerAdapter:lock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   27: invokeinterface 19 1 0
/*     */     //   32: invokeinterface 18 1 0
/*     */     //   37: goto +20 -> 57
/*     */     //   40: astore_1
/*     */     //   41: aload_0
/*     */     //   42: getfield 7	org/apache/logging/log4j/spi/AbstractLoggerAdapter:lock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   45: invokeinterface 19 1 0
/*     */     //   50: invokeinterface 18 1 0
/*     */     //   55: aload_1
/*     */     //   56: athrow
/*     */     //   57: return
/*     */     // Line number table:
/*     */     //   Java source line #142	-> byte code offset #0
/*     */     //   Java source line #144	-> byte code offset #14
/*     */     //   Java source line #146	-> byte code offset #23
/*     */     //   Java source line #147	-> byte code offset #37
/*     */     //   Java source line #146	-> byte code offset #40
/*     */     //   Java source line #147	-> byte code offset #55
/*     */     //   Java source line #148	-> byte code offset #57
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	58	0	this	AbstractLoggerAdapter<L>
/*     */     //   40	16	1	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   14	23	40	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\spi\AbstractLoggerAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */