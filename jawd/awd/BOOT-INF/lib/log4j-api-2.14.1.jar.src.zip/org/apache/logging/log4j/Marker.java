package org.apache.logging.log4j;

import java.io.Serializable;

public abstract interface Marker
  extends Serializable
{
  public abstract Marker addParents(Marker... paramVarArgs);
  
  public abstract boolean equals(Object paramObject);
  
  public abstract String getName();
  
  public abstract Marker[] getParents();
  
  public abstract int hashCode();
  
  public abstract boolean hasParents();
  
  public abstract boolean isInstanceOf(Marker paramMarker);
  
  public abstract boolean isInstanceOf(String paramString);
  
  public abstract boolean remove(Marker paramMarker);
  
  public abstract Marker setParents(Marker... paramVarArgs);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\Marker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */