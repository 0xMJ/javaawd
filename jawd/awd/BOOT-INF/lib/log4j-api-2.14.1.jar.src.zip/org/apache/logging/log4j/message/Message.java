package org.apache.logging.log4j.message;

import java.io.Serializable;

public abstract interface Message
  extends Serializable
{
  public abstract String getFormattedMessage();
  
  public abstract String getFormat();
  
  public abstract Object[] getParameters();
  
  public abstract Throwable getThrowable();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\message\Message.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */