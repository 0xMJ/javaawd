package org.apache.logging.log4j.message;

abstract interface Clearable
{
  public abstract void clear();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\message\Clearable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */