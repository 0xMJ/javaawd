/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StackLocator
/*     */ {
/*     */   static final int JDK_7u25_OFFSET;
/*     */   private static final Method GET_CALLER_CLASS;
/*     */   
/*     */   static
/*     */   {
/*  60 */     int java7u25CompensationOffset = 0;
/*     */     Method getCallerClass;
/*  62 */     try { Class<?> sunReflectionClass = LoaderUtil.loadClass("sun.reflect.Reflection");
/*  63 */       Method getCallerClass = sunReflectionClass.getDeclaredMethod("getCallerClass", new Class[] { Integer.TYPE });
/*  64 */       Object o = getCallerClass.invoke(null, new Object[] { Integer.valueOf(0) });
/*  65 */       getCallerClass.invoke(null, new Object[] { Integer.valueOf(0) });
/*  66 */       if ((o == null) || (o != sunReflectionClass)) {
/*  67 */         getCallerClass = null;
/*  68 */         java7u25CompensationOffset = -1;
/*     */       } else {
/*  70 */         o = getCallerClass.invoke(null, new Object[] { Integer.valueOf(1) });
/*  71 */         if (o == sunReflectionClass) {
/*  72 */           System.out.println("WARNING: Java 1.7.0_25 is in use which has a broken implementation of Reflection.getCallerClass().  Please consider upgrading to Java 1.7.0_40 or later.");
/*     */           
/*  74 */           java7u25CompensationOffset = 1;
/*     */         }
/*     */       }
/*     */     } catch (Exception|LinkageError e) {
/*  78 */       System.out.println("WARNING: sun.reflect.Reflection.getCallerClass is not supported. This will impact performance.");
/*  79 */       getCallerClass = null;
/*  80 */       java7u25CompensationOffset = -1;
/*     */     }
/*     */     
/*  83 */     GET_CALLER_CLASS = getCallerClass;
/*  84 */     JDK_7u25_OFFSET = java7u25CompensationOffset; }
/*     */   
/*  86 */   private static final StackLocator INSTANCE = new StackLocator();
/*     */   
/*     */   public static StackLocator getInstance()
/*     */   {
/*  90 */     return INSTANCE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @PerformanceSensitive
/*     */   public Class<?> getCallerClass(int depth)
/*     */   {
/* 102 */     if (depth < 0) {
/* 103 */       throw new IndexOutOfBoundsException(Integer.toString(depth));
/*     */     }
/* 105 */     if (GET_CALLER_CLASS == null) {
/* 106 */       return null;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 111 */       return (Class)GET_CALLER_CLASS.invoke(null, new Object[] { Integer.valueOf(depth + 1 + JDK_7u25_OFFSET) });
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/* 115 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   @PerformanceSensitive
/*     */   public Class<?> getCallerClass(String fqcn, String pkg)
/*     */   {
/* 122 */     boolean next = false;
/*     */     Class<?> clazz;
/* 124 */     for (int i = 2; null != (clazz = getCallerClass(i)); i++) {
/* 125 */       if (fqcn.equals(clazz.getName())) {
/* 126 */         next = true;
/*     */ 
/*     */       }
/* 129 */       else if ((next) && (clazz.getName().startsWith(pkg))) {
/* 130 */         return clazz;
/*     */       }
/*     */     }
/*     */     
/* 134 */     return null;
/*     */   }
/*     */   
/*     */   @PerformanceSensitive
/*     */   public Class<?> getCallerClass(Class<?> anchor)
/*     */   {
/* 140 */     boolean next = false;
/*     */     Class<?> clazz;
/* 142 */     for (int i = 2; null != (clazz = getCallerClass(i)); i++) {
/* 143 */       if (anchor.equals(clazz)) {
/* 144 */         next = true;
/*     */ 
/*     */       }
/* 147 */       else if (next) {
/* 148 */         return clazz;
/*     */       }
/*     */     }
/* 151 */     return Object.class;
/*     */   }
/*     */   
/*     */ 
/*     */   @PerformanceSensitive
/*     */   public Stack<Class<?>> getCurrentStackTrace()
/*     */   {
/* 158 */     if (PrivateSecurityManagerStackTraceUtil.isEnabled()) {
/* 159 */       return PrivateSecurityManagerStackTraceUtil.getCurrentStackTrace();
/*     */     }
/*     */     
/* 162 */     Stack<Class<?>> classes = new Stack();
/*     */     Class<?> clazz;
/* 164 */     for (int i = 1; null != (clazz = getCallerClass(i)); i++) {
/* 165 */       classes.push(clazz);
/*     */     }
/* 167 */     return classes;
/*     */   }
/*     */   
/*     */   public StackTraceElement calcLocation(String fqcnOfLogger) {
/* 171 */     if (fqcnOfLogger == null) {
/* 172 */       return null;
/*     */     }
/*     */     
/* 175 */     StackTraceElement[] stackTrace = new Throwable().getStackTrace();
/* 176 */     boolean found = false;
/* 177 */     for (int i = 0; i < stackTrace.length; i++) {
/* 178 */       String className = stackTrace[i].getClassName();
/* 179 */       if (fqcnOfLogger.equals(className))
/*     */       {
/* 181 */         found = true;
/*     */ 
/*     */       }
/* 184 */       else if ((found) && (!fqcnOfLogger.equals(className))) {
/* 185 */         return stackTrace[i];
/*     */       }
/*     */     }
/* 188 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public StackTraceElement getStackTraceElement(int depth)
/*     */   {
/* 194 */     StackTraceElement[] elements = new Throwable().getStackTrace();
/* 195 */     int i = 0;
/* 196 */     for (StackTraceElement element : elements) {
/* 197 */       if (isValid(element)) {
/* 198 */         if (i == depth) {
/* 199 */           return element;
/*     */         }
/* 201 */         i++;
/*     */       }
/*     */     }
/* 204 */     throw new IndexOutOfBoundsException(Integer.toString(depth));
/*     */   }
/*     */   
/*     */   private boolean isValid(StackTraceElement element)
/*     */   {
/* 209 */     if (element.isNativeMethod()) {
/* 210 */       return false;
/*     */     }
/* 212 */     String cn = element.getClassName();
/*     */     
/* 214 */     if (cn.startsWith("sun.reflect.")) {
/* 215 */       return false;
/*     */     }
/* 217 */     String mn = element.getMethodName();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 222 */     if ((cn.startsWith("java.lang.reflect.")) && ((mn.equals("invoke")) || (mn.equals("newInstance")))) {
/* 223 */       return false;
/*     */     }
/*     */     
/* 226 */     if (cn.startsWith("jdk.internal.reflect.")) {
/* 227 */       return false;
/*     */     }
/*     */     
/* 230 */     if ((cn.equals("java.lang.Class")) && (mn.equals("newInstance"))) {
/* 231 */       return false;
/*     */     }
/*     */     
/* 234 */     if ((cn.equals("java.lang.invoke.MethodHandle")) && (mn.startsWith("invoke"))) {
/* 235 */       return false;
/*     */     }
/*     */     
/* 238 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\util\StackLocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */