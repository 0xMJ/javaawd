package org.apache.logging.log4j.spi;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.message.Message;

public abstract interface LocationAwareLogger
{
  public abstract void logMessage(Level paramLevel, Marker paramMarker, String paramString, StackTraceElement paramStackTraceElement, Message paramMessage, Throwable paramThrowable);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\spi\LocationAwareLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */