/*    */ package org.apache.logging.log4j.spi;
/*    */ 
/*    */ import java.net.URI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface LoggerContextFactory
/*    */ {
/*    */   public void shutdown(String fqcn, ClassLoader loader, boolean currentContext, boolean allContexts)
/*    */   {
/* 36 */     if (hasContext(fqcn, loader, currentContext)) {
/* 37 */       LoggerContext ctx = getContext(fqcn, loader, null, currentContext);
/* 38 */       if ((ctx instanceof Terminable)) {
/* 39 */         ((Terminable)ctx).terminate();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean hasContext(String fqcn, ClassLoader loader, boolean currentContext)
/*    */   {
/* 54 */     return false;
/*    */   }
/*    */   
/*    */   public abstract LoggerContext getContext(String paramString, ClassLoader paramClassLoader, Object paramObject, boolean paramBoolean);
/*    */   
/*    */   public abstract LoggerContext getContext(String paramString1, ClassLoader paramClassLoader, Object paramObject, boolean paramBoolean, URI paramURI, String paramString2);
/*    */   
/*    */   public abstract void removeContext(LoggerContext paramLoggerContext);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\spi\LoggerContextFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */