/*     */ package org.apache.logging.log4j.util;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Strings
/*     */ {
/*     */   public static final String EMPTY = "";
/*  39 */   public static final String LINE_SEPARATOR = PropertiesUtil.getProperties().getStringProperty("line.separator", "\n");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String dquote(String str)
/*     */   {
/*  49 */     return '"' + str + '"';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isBlank(String s)
/*     */   {
/*  60 */     if ((s == null) || (s.isEmpty())) {
/*  61 */       return true;
/*     */     }
/*  63 */     for (int i = 0; i < s.length(); i++) {
/*  64 */       char c = s.charAt(i);
/*  65 */       if (!Character.isWhitespace(c)) {
/*  66 */         return false;
/*     */       }
/*     */     }
/*  69 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEmpty(CharSequence cs)
/*     */   {
/*  98 */     return (cs == null) || (cs.length() == 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNotBlank(String s)
/*     */   {
/* 108 */     return !isBlank(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNotEmpty(CharSequence cs)
/*     */   {
/* 132 */     return !isEmpty(cs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String join(Iterable<?> iterable, char separator)
/*     */   {
/* 147 */     if (iterable == null) {
/* 148 */       return null;
/*     */     }
/* 150 */     return join(iterable.iterator(), separator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String join(Iterator<?> iterator, char separator)
/*     */   {
/* 167 */     if (iterator == null) {
/* 168 */       return null;
/*     */     }
/* 170 */     if (!iterator.hasNext()) {
/* 171 */       return "";
/*     */     }
/* 173 */     Object first = iterator.next();
/* 174 */     if (!iterator.hasNext()) {
/* 175 */       return Objects.toString(first, "");
/*     */     }
/*     */     
/*     */ 
/* 179 */     StringBuilder buf = new StringBuilder(256);
/* 180 */     if (first != null) {
/* 181 */       buf.append(first);
/*     */     }
/*     */     
/* 184 */     while (iterator.hasNext()) {
/* 185 */       buf.append(separator);
/* 186 */       Object obj = iterator.next();
/* 187 */       if (obj != null) {
/* 188 */         buf.append(obj);
/*     */       }
/*     */     }
/*     */     
/* 192 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String left(String str, int len)
/*     */   {
/* 220 */     if (str == null) {
/* 221 */       return null;
/*     */     }
/* 223 */     if (len < 0) {
/* 224 */       return "";
/*     */     }
/* 226 */     if (str.length() <= len) {
/* 227 */       return str;
/*     */     }
/* 229 */     return str.substring(0, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String quote(String str)
/*     */   {
/* 239 */     return '\'' + str + '\'';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String trimToNull(String str)
/*     */   {
/* 267 */     String ts = str == null ? null : str.trim();
/* 268 */     return isEmpty(ts) ? null : ts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toRootUpperCase(String str)
/*     */   {
/* 282 */     return str.toUpperCase(Locale.ROOT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String repeat(String str, int count)
/*     */   {
/* 293 */     Objects.requireNonNull(str, "str");
/* 294 */     if (count < 0) {
/* 295 */       throw new IllegalArgumentException("count");
/*     */     }
/* 297 */     StringBuilder sb = new StringBuilder(str.length() * count);
/* 298 */     for (int index = 0; index < count; index++) {
/* 299 */       sb.append(str);
/*     */     }
/* 301 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\util\Strings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */