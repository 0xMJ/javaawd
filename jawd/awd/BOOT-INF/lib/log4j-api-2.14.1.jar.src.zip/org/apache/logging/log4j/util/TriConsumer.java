package org.apache.logging.log4j.util;

public abstract interface TriConsumer<K, V, S>
{
  public abstract void accept(K paramK, V paramV, S paramS);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\util\TriConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */