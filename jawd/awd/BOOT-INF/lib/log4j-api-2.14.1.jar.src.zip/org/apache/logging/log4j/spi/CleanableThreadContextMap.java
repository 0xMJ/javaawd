package org.apache.logging.log4j.spi;

public abstract interface CleanableThreadContextMap
  extends ThreadContextMap2
{
  public abstract void removeAll(Iterable<String> paramIterable);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\spi\CleanableThreadContextMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */