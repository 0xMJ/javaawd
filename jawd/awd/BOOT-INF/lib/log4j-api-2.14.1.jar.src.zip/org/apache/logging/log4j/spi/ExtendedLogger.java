package org.apache.logging.log4j.spi;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.message.Message;
import org.apache.logging.log4j.util.MessageSupplier;
import org.apache.logging.log4j.util.Supplier;

public abstract interface ExtendedLogger
  extends Logger
{
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, Message paramMessage, Throwable paramThrowable);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, CharSequence paramCharSequence, Throwable paramThrowable);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, Object paramObject, Throwable paramThrowable);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString, Throwable paramThrowable);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString, Object... paramVarArgs);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString, Object paramObject);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString, Object paramObject1, Object paramObject2);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString, Object paramObject1, Object paramObject2, Object paramObject3);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9);
  
  public abstract boolean isEnabled(Level paramLevel, Marker paramMarker, String paramString, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10);
  
  public abstract void logIfEnabled(String paramString, Level paramLevel, Marker paramMarker, Message paramMessage, Throwable paramThrowable);
  
  public abstract void logIfEnabled(String paramString, Level paramLevel, Marker paramMarker, CharSequence paramCharSequence, Throwable paramThrowable);
  
  public abstract void logIfEnabled(String paramString, Level paramLevel, Marker paramMarker, Object paramObject, Throwable paramThrowable);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Throwable paramThrowable);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Object... paramVarArgs);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Object paramObject);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Object paramObject1, Object paramObject2);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Object paramObject1, Object paramObject2, Object paramObject3);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10);
  
  public abstract void logMessage(String paramString, Level paramLevel, Marker paramMarker, Message paramMessage, Throwable paramThrowable);
  
  public abstract void logIfEnabled(String paramString, Level paramLevel, Marker paramMarker, MessageSupplier paramMessageSupplier, Throwable paramThrowable);
  
  public abstract void logIfEnabled(String paramString1, Level paramLevel, Marker paramMarker, String paramString2, Supplier<?>... paramVarArgs);
  
  public abstract void logIfEnabled(String paramString, Level paramLevel, Marker paramMarker, Supplier<?> paramSupplier, Throwable paramThrowable);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\spi\ExtendedLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */