/*     */ package org.apache.logging.log4j.spi;
/*     */ 
/*     */ import org.apache.logging.log4j.message.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface LoggerContext
/*     */ {
/*     */   public abstract Object getExternalContext();
/*     */   
/*     */   public Object getObject(String key)
/*     */   {
/*  38 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object putObject(String key, Object value)
/*     */   {
/*  49 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object putObjectIfAbsent(String key, Object value)
/*     */   {
/*  60 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object removeObject(String key)
/*     */   {
/*  70 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean removeObject(String key, Object value)
/*     */   {
/*  81 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ExtendedLogger getLogger(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExtendedLogger getLogger(Class<?> cls)
/*     */   {
/*  98 */     String canonicalName = cls.getCanonicalName();
/*  99 */     return getLogger(canonicalName != null ? canonicalName : cls.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ExtendedLogger getLogger(String paramString, MessageFactory paramMessageFactory);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExtendedLogger getLogger(Class<?> cls, MessageFactory messageFactory)
/*     */   {
/* 120 */     String canonicalName = cls.getCanonicalName();
/* 121 */     return getLogger(canonicalName != null ? canonicalName : cls.getName(), messageFactory);
/*     */   }
/*     */   
/*     */   public abstract boolean hasLogger(String paramString);
/*     */   
/*     */   public abstract boolean hasLogger(String paramString, MessageFactory paramMessageFactory);
/*     */   
/*     */   public abstract boolean hasLogger(String paramString, Class<? extends MessageFactory> paramClass);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\spi\LoggerContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */