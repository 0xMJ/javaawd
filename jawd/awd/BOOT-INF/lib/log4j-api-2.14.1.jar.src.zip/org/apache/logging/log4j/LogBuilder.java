/*    */ package org.apache.logging.log4j;
/*    */ 
/*    */ import org.apache.logging.log4j.message.Message;
/*    */ import org.apache.logging.log4j.util.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface LogBuilder
/*    */ {
/* 29 */   public static final LogBuilder NOOP = new LogBuilder() {};
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public LogBuilder withMarker(Marker marker)
/*    */   {
/* 37 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public LogBuilder withThrowable(Throwable throwable)
/*    */   {
/* 46 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public LogBuilder withLocation()
/*    */   {
/* 55 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public LogBuilder withLocation(StackTraceElement location)
/*    */   {
/* 64 */     return this;
/*    */   }
/*    */   
/*    */   public void log(CharSequence message) {}
/*    */   
/*    */   public void log(String message) {}
/*    */   
/*    */   public void log(String message, Object... params) {}
/*    */   
/*    */   public void log(String message, Supplier<?>... params) {}
/*    */   
/*    */   public void log(Message message) {}
/*    */   
/*    */   public void log(Supplier<Message> messageSupplier) {}
/*    */   
/*    */   public void log(Object message) {}
/*    */   
/*    */   public void log(String message, Object p0) {}
/*    */   
/*    */   public void log(String message, Object p0, Object p1) {}
/*    */   
/*    */   public void log(String message, Object p0, Object p1, Object p2) {}
/*    */   
/*    */   public void log(String message, Object p0, Object p1, Object p2, Object p3) {}
/*    */   
/*    */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4) {}
/*    */   
/*    */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5) {}
/*    */   
/*    */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6) {}
/*    */   
/*    */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7) {}
/*    */   
/*    */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8) {}
/*    */   
/*    */   public void log(String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9) {}
/*    */   
/*    */   public void log() {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\LogBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */