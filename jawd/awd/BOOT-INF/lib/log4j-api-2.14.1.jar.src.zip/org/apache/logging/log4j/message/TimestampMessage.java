package org.apache.logging.log4j.message;

public abstract interface TimestampMessage
{
  public abstract long getTimestamp();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\message\TimestampMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */