/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnvironmentPropertySource
/*    */   implements PropertySource
/*    */ {
/*    */   private static final String PREFIX = "LOG4J_";
/*    */   private static final int DEFAULT_PRIORITY = -100;
/*    */   
/*    */   public int getPriority()
/*    */   {
/* 37 */     return -100;
/*    */   }
/*    */   
/*    */   public void forEach(BiConsumer<String, String> action)
/*    */   {
/*    */     try
/*    */     {
/* 44 */       getenv = System.getenv();
/*    */     } catch (SecurityException e) {
/*    */       Map<String, String> getenv;
/* 47 */       LowLevelLogUtil.logException("The system environment variables are not available to Log4j due to security restrictions: " + e, e); return;
/*    */     }
/*    */     
/*    */     Map<String, String> getenv;
/*    */     
/* 52 */     for (Map.Entry<String, String> entry : getenv.entrySet()) {
/* 53 */       String key = (String)entry.getKey();
/* 54 */       if (key.startsWith("LOG4J_")) {
/* 55 */         action.accept(key.substring("LOG4J_".length()), entry.getValue());
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public CharSequence getNormalForm(Iterable<? extends CharSequence> tokens)
/*    */   {
/* 62 */     StringBuilder sb = new StringBuilder("LOG4J");
/* 63 */     for (CharSequence token : tokens) {
/* 64 */       sb.append('_');
/* 65 */       for (int i = 0; i < token.length(); i++) {
/* 66 */         sb.append(Character.toUpperCase(token.charAt(i)));
/*    */       }
/*    */     }
/* 69 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\util\EnvironmentPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */