/*     */ package org.apache.logging.log4j.status;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.Marker;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.apache.logging.log4j.message.MessageFactory;
/*     */ import org.apache.logging.log4j.message.ParameterizedNoReferenceMessageFactory;
/*     */ import org.apache.logging.log4j.simple.SimpleLogger;
/*     */ import org.apache.logging.log4j.spi.AbstractLogger;
/*     */ import org.apache.logging.log4j.util.PropertiesUtil;
/*     */ import org.apache.logging.log4j.util.Strings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StatusLogger
/*     */   extends AbstractLogger
/*     */ {
/*     */   public static final String MAX_STATUS_ENTRIES = "log4j2.status.entries";
/*     */   public static final String DEFAULT_STATUS_LISTENER_LEVEL = "log4j2.StatusLogger.level";
/*     */   public static final String STATUS_DATE_FORMAT = "log4j2.StatusLogger.DateFormat";
/*     */   private static final long serialVersionUID = 2L;
/*     */   private static final String NOT_AVAIL = "?";
/*  78 */   private static final PropertiesUtil PROPS = new PropertiesUtil("log4j2.StatusLogger.properties");
/*     */   
/*  80 */   private static final int MAX_ENTRIES = PROPS.getIntegerProperty("log4j2.status.entries", 200);
/*     */   
/*  82 */   private static final String DEFAULT_STATUS_LEVEL = PROPS.getStringProperty("log4j2.StatusLogger.level");
/*     */   
/*     */ 
/*  85 */   private static final StatusLogger STATUS_LOGGER = new StatusLogger(StatusLogger.class.getName(), ParameterizedNoReferenceMessageFactory.INSTANCE);
/*     */   
/*     */ 
/*     */   private final SimpleLogger logger;
/*     */   
/*  90 */   private final Collection<StatusListener> listeners = new CopyOnWriteArrayList();
/*     */   
/*  92 */   private final ReadWriteLock listenersLock = new ReentrantReadWriteLock();
/*     */   
/*     */ 
/*     */ 
/*  96 */   private final Queue<StatusData> messages = new BoundedQueue(MAX_ENTRIES);
/*     */   
/*  98 */   private final Lock msgLock = new ReentrantLock();
/*     */   
/*     */   private int listenersLevel;
/*     */   
/*     */ 
/*     */   private StatusLogger(String name, MessageFactory messageFactory)
/*     */   {
/* 105 */     super(name, messageFactory);
/* 106 */     String dateFormat = PROPS.getStringProperty("log4j2.StatusLogger.DateFormat", "");
/* 107 */     boolean showDateTime = !Strings.isEmpty(dateFormat);
/* 108 */     this.logger = new SimpleLogger("StatusLogger", Level.ERROR, false, true, showDateTime, false, dateFormat, messageFactory, PROPS, System.err);
/*     */     
/* 110 */     this.listenersLevel = Level.toLevel(DEFAULT_STATUS_LEVEL, Level.WARN).intLevel();
/*     */     
/*     */ 
/* 113 */     if (isDebugPropertyEnabled()) {
/* 114 */       this.logger.setLevel(Level.TRACE);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isDebugPropertyEnabled()
/*     */   {
/* 120 */     return PropertiesUtil.getProperties().getBooleanProperty("log4j2.debug", false, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static StatusLogger getLogger()
/*     */   {
/* 129 */     return STATUS_LOGGER;
/*     */   }
/*     */   
/*     */   public void setLevel(Level level) {
/* 133 */     this.logger.setLevel(level);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void registerListener(StatusListener listener)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 8	org/apache/logging/log4j/status/StatusLogger:listenersLock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   4: invokeinterface 41 1 0
/*     */     //   9: invokeinterface 42 1 0
/*     */     //   14: aload_0
/*     */     //   15: getfield 5	org/apache/logging/log4j/status/StatusLogger:listeners	Ljava/util/Collection;
/*     */     //   18: aload_1
/*     */     //   19: invokeinterface 43 2 0
/*     */     //   24: pop
/*     */     //   25: aload_1
/*     */     //   26: invokeinterface 44 1 0
/*     */     //   31: astore_2
/*     */     //   32: aload_0
/*     */     //   33: getfield 32	org/apache/logging/log4j/status/StatusLogger:listenersLevel	I
/*     */     //   36: aload_2
/*     */     //   37: invokevirtual 31	org/apache/logging/log4j/Level:intLevel	()I
/*     */     //   40: if_icmpge +11 -> 51
/*     */     //   43: aload_0
/*     */     //   44: aload_2
/*     */     //   45: invokevirtual 31	org/apache/logging/log4j/Level:intLevel	()I
/*     */     //   48: putfield 32	org/apache/logging/log4j/status/StatusLogger:listenersLevel	I
/*     */     //   51: aload_0
/*     */     //   52: getfield 8	org/apache/logging/log4j/status/StatusLogger:listenersLock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   55: invokeinterface 41 1 0
/*     */     //   60: invokeinterface 45 1 0
/*     */     //   65: goto +20 -> 85
/*     */     //   68: astore_3
/*     */     //   69: aload_0
/*     */     //   70: getfield 8	org/apache/logging/log4j/status/StatusLogger:listenersLock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   73: invokeinterface 41 1 0
/*     */     //   78: invokeinterface 45 1 0
/*     */     //   83: aload_3
/*     */     //   84: athrow
/*     */     //   85: return
/*     */     // Line number table:
/*     */     //   Java source line #142	-> byte code offset #0
/*     */     //   Java source line #144	-> byte code offset #14
/*     */     //   Java source line #145	-> byte code offset #25
/*     */     //   Java source line #146	-> byte code offset #32
/*     */     //   Java source line #147	-> byte code offset #43
/*     */     //   Java source line #150	-> byte code offset #51
/*     */     //   Java source line #151	-> byte code offset #65
/*     */     //   Java source line #150	-> byte code offset #68
/*     */     //   Java source line #151	-> byte code offset #83
/*     */     //   Java source line #152	-> byte code offset #85
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	86	0	this	StatusLogger
/*     */     //   0	86	1	listener	StatusListener
/*     */     //   31	14	2	lvl	Level
/*     */     //   68	16	3	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   14	51	68	finally
/*     */   }
/*     */   
/*     */   public void removeListener(StatusListener listener)
/*     */   {
/* 160 */     closeSilently(listener);
/* 161 */     this.listenersLock.writeLock().lock();
/*     */     try {
/* 163 */       this.listeners.remove(listener);
/* 164 */       int lowest = Level.toLevel(DEFAULT_STATUS_LEVEL, Level.WARN).intLevel();
/* 165 */       for (StatusListener statusListener : this.listeners) {
/* 166 */         int level = statusListener.getStatusLevel().intLevel();
/* 167 */         if (lowest < level) {
/* 168 */           lowest = level;
/*     */         }
/*     */       }
/* 171 */       this.listenersLevel = lowest;
/*     */     } finally {
/* 173 */       this.listenersLock.writeLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateListenerLevel(Level status) {
/* 178 */     if (status.intLevel() > this.listenersLevel) {
/* 179 */       this.listenersLevel = status.intLevel();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterable<StatusListener> getListeners()
/*     */   {
/* 189 */     return this.listeners;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void reset()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 8	org/apache/logging/log4j/status/StatusLogger:listenersLock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   4: invokeinterface 41 1 0
/*     */     //   9: invokeinterface 42 1 0
/*     */     //   14: aload_0
/*     */     //   15: getfield 5	org/apache/logging/log4j/status/StatusLogger:listeners	Ljava/util/Collection;
/*     */     //   18: invokeinterface 48 1 0
/*     */     //   23: astore_1
/*     */     //   24: aload_1
/*     */     //   25: invokeinterface 49 1 0
/*     */     //   30: ifeq +20 -> 50
/*     */     //   33: aload_1
/*     */     //   34: invokeinterface 50 1 0
/*     */     //   39: checkcast 51	org/apache/logging/log4j/status/StatusListener
/*     */     //   42: astore_2
/*     */     //   43: aload_2
/*     */     //   44: invokestatic 46	org/apache/logging/log4j/status/StatusLogger:closeSilently	(Ljava/io/Closeable;)V
/*     */     //   47: goto -23 -> 24
/*     */     //   50: aload_0
/*     */     //   51: getfield 5	org/apache/logging/log4j/status/StatusLogger:listeners	Ljava/util/Collection;
/*     */     //   54: invokeinterface 52 1 0
/*     */     //   59: aload_0
/*     */     //   60: getfield 8	org/apache/logging/log4j/status/StatusLogger:listenersLock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   63: invokeinterface 41 1 0
/*     */     //   68: invokeinterface 45 1 0
/*     */     //   73: aload_0
/*     */     //   74: invokevirtual 53	org/apache/logging/log4j/status/StatusLogger:clear	()V
/*     */     //   77: goto +33 -> 110
/*     */     //   80: astore_3
/*     */     //   81: aload_0
/*     */     //   82: getfield 5	org/apache/logging/log4j/status/StatusLogger:listeners	Ljava/util/Collection;
/*     */     //   85: invokeinterface 52 1 0
/*     */     //   90: aload_0
/*     */     //   91: getfield 8	org/apache/logging/log4j/status/StatusLogger:listenersLock	Ljava/util/concurrent/locks/ReadWriteLock;
/*     */     //   94: invokeinterface 41 1 0
/*     */     //   99: invokeinterface 45 1 0
/*     */     //   104: aload_0
/*     */     //   105: invokevirtual 53	org/apache/logging/log4j/status/StatusLogger:clear	()V
/*     */     //   108: aload_3
/*     */     //   109: athrow
/*     */     //   110: return
/*     */     // Line number table:
/*     */     //   Java source line #196	-> byte code offset #0
/*     */     //   Java source line #198	-> byte code offset #14
/*     */     //   Java source line #199	-> byte code offset #43
/*     */     //   Java source line #200	-> byte code offset #47
/*     */     //   Java source line #202	-> byte code offset #50
/*     */     //   Java source line #203	-> byte code offset #59
/*     */     //   Java source line #205	-> byte code offset #73
/*     */     //   Java source line #206	-> byte code offset #77
/*     */     //   Java source line #202	-> byte code offset #80
/*     */     //   Java source line #203	-> byte code offset #90
/*     */     //   Java source line #205	-> byte code offset #104
/*     */     //   Java source line #206	-> byte code offset #108
/*     */     //   Java source line #207	-> byte code offset #110
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	111	0	this	StatusLogger
/*     */     //   23	11	1	localIterator	java.util.Iterator
/*     */     //   42	2	2	listener	StatusListener
/*     */     //   80	29	3	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   14	50	80	finally
/*     */   }
/*     */   
/*     */   private static void closeSilently(Closeable resource)
/*     */   {
/*     */     try
/*     */     {
/* 211 */       resource.close();
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<StatusData> getStatusData()
/*     */   {
/* 223 */     this.msgLock.lock();
/*     */     try {
/* 225 */       return new ArrayList(this.messages);
/*     */     } finally {
/* 227 */       this.msgLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void clear()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 14	org/apache/logging/log4j/status/StatusLogger:msgLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   4: invokeinterface 42 1 0
/*     */     //   9: aload_0
/*     */     //   10: getfield 1	org/apache/logging/log4j/status/StatusLogger:messages	Ljava/util/Queue;
/*     */     //   13: invokeinterface 58 1 0
/*     */     //   18: aload_0
/*     */     //   19: getfield 14	org/apache/logging/log4j/status/StatusLogger:msgLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   22: invokeinterface 45 1 0
/*     */     //   27: goto +15 -> 42
/*     */     //   30: astore_1
/*     */     //   31: aload_0
/*     */     //   32: getfield 14	org/apache/logging/log4j/status/StatusLogger:msgLock	Ljava/util/concurrent/locks/Lock;
/*     */     //   35: invokeinterface 45 1 0
/*     */     //   40: aload_1
/*     */     //   41: athrow
/*     */     //   42: return
/*     */     // Line number table:
/*     */     //   Java source line #235	-> byte code offset #0
/*     */     //   Java source line #237	-> byte code offset #9
/*     */     //   Java source line #239	-> byte code offset #18
/*     */     //   Java source line #240	-> byte code offset #27
/*     */     //   Java source line #239	-> byte code offset #30
/*     */     //   Java source line #240	-> byte code offset #40
/*     */     //   Java source line #241	-> byte code offset #42
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	43	0	this	StatusLogger
/*     */     //   30	11	1	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   9	18	30	finally
/*     */   }
/*     */   
/*     */   public Level getLevel()
/*     */   {
/* 245 */     return this.logger.getLevel();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void logMessage(String fqcn, Level level, Marker marker, Message msg, Throwable t)
/*     */   {
/* 260 */     StackTraceElement element = null;
/* 261 */     if (fqcn != null) {
/* 262 */       element = getStackTraceElement(fqcn, Thread.currentThread().getStackTrace());
/*     */     }
/* 264 */     StatusData data = new StatusData(element, level, msg, t, null);
/* 265 */     this.msgLock.lock();
/*     */     try {
/* 267 */       this.messages.add(data);
/*     */     } finally {
/* 269 */       this.msgLock.unlock();
/*     */     }
/*     */     
/* 272 */     if ((isDebugPropertyEnabled()) || (this.listeners.size() <= 0)) {
/* 273 */       this.logger.logMessage(fqcn, level, marker, msg, t);
/*     */     } else {
/* 275 */       for (StatusListener listener : this.listeners) {
/* 276 */         if (data.getLevel().isMoreSpecificThan(listener.getStatusLevel())) {
/* 277 */           listener.log(data);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private StackTraceElement getStackTraceElement(String fqcn, StackTraceElement[] stackTrace) {
/* 284 */     if (fqcn == null) {
/* 285 */       return null;
/*     */     }
/* 287 */     boolean next = false;
/* 288 */     for (StackTraceElement element : stackTrace) {
/* 289 */       String className = element.getClassName();
/* 290 */       if ((next) && (!fqcn.equals(className))) {
/* 291 */         return element;
/*     */       }
/* 293 */       if (fqcn.equals(className))
/* 294 */         next = true; else {
/* 295 */         if ("?".equals(className))
/*     */           break;
/*     */       }
/*     */     }
/* 299 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Throwable t)
/*     */   {
/* 304 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message)
/*     */   {
/* 309 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object... params)
/*     */   {
/* 314 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0)
/*     */   {
/* 319 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1)
/*     */   {
/* 325 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2)
/*     */   {
/* 331 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3)
/*     */   {
/* 337 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4)
/*     */   {
/* 344 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5)
/*     */   {
/* 351 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6)
/*     */   {
/* 358 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7)
/*     */   {
/* 366 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8)
/*     */   {
/* 374 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEnabled(Level level, Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9)
/*     */   {
/* 382 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, CharSequence message, Throwable t)
/*     */   {
/* 387 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, Object message, Throwable t)
/*     */   {
/* 392 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, Marker marker, Message message, Throwable t)
/*     */   {
/* 397 */     return isEnabled(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isEnabled(Level level, Marker marker)
/*     */   {
/* 403 */     if (isDebugPropertyEnabled()) {
/* 404 */       return true;
/*     */     }
/* 406 */     if (this.listeners.size() > 0) {
/* 407 */       return this.listenersLevel >= level.intLevel();
/*     */     }
/* 409 */     return this.logger.isEnabled(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class BoundedQueue<E>
/*     */     extends ConcurrentLinkedQueue<E>
/*     */   {
/*     */     private static final long serialVersionUID = -3945953719763255337L;
/*     */     
/*     */     private final int size;
/*     */     
/*     */ 
/*     */     BoundedQueue(int size)
/*     */     {
/* 424 */       this.size = size;
/*     */     }
/*     */     
/*     */     public boolean add(E object)
/*     */     {
/* 429 */       super.add(object);
/* 430 */       while (StatusLogger.this.messages.size() > this.size) {
/* 431 */         StatusLogger.this.messages.poll();
/*     */       }
/* 433 */       return this.size > 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\status\StatusLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */