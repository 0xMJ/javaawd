package org.apache.logging.log4j.util;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.CLASS)
public @interface PerformanceSensitive
{
  String[] value() default {""};
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\util\PerformanceSensitive.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */