/*    */ package org.apache.logging.log4j.internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogManagerStatus
/*    */ {
/* 24 */   private static boolean initialized = false;
/*    */   
/*    */   public static void setInitialized(boolean managerStatus) {
/* 27 */     initialized = managerStatus;
/*    */   }
/*    */   
/*    */   public static boolean isInitialized() {
/* 31 */     return initialized;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\internal\LogManagerStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */