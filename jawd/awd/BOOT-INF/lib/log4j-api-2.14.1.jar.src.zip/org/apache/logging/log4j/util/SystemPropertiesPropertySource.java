/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import java.util.Properties;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemPropertiesPropertySource
/*    */   implements PropertySource
/*    */ {
/*    */   private static final int DEFAULT_PRIORITY = 100;
/*    */   private static final String PREFIX = "log4j2.";
/*    */   
/*    */   public int getPriority()
/*    */   {
/* 36 */     return 100;
/*    */   }
/*    */   
/*    */   public void forEach(BiConsumer<String, String> action)
/*    */   {
/*    */     try
/*    */     {
/* 43 */       properties = System.getProperties();
/*    */     }
/*    */     catch (SecurityException e)
/*    */     {
/*    */       Properties properties;
/*    */       
/*    */       return;
/*    */     }
/*    */     
/*    */     Properties properties;
/*    */     
/*    */     Object[] keySet;
/* 55 */     synchronized (properties) {
/* 56 */       keySet = properties.keySet().toArray();
/*    */     }
/*    */     
/*    */     Object[] keySet;
/* 60 */     for (Object key : keySet) {
/* 61 */       String keyStr = Objects.toString(key, null);
/* 62 */       action.accept(keyStr, properties.getProperty(keyStr));
/*    */     }
/*    */   }
/*    */   
/*    */   public CharSequence getNormalForm(Iterable<? extends CharSequence> tokens)
/*    */   {
/* 68 */     return "log4j2." + PropertySource.Util.joinAsCamelCase(tokens);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\util\SystemPropertiesPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */