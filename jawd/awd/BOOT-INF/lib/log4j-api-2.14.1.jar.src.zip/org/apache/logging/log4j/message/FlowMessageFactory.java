package org.apache.logging.log4j.message;

public abstract interface FlowMessageFactory
{
  public abstract EntryMessage newEntryMessage(Message paramMessage);
  
  public abstract ExitMessage newExitMessage(Object paramObject, Message paramMessage);
  
  public abstract ExitMessage newExitMessage(EntryMessage paramEntryMessage);
  
  public abstract ExitMessage newExitMessage(Object paramObject, EntryMessage paramEntryMessage);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\message\FlowMessageFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */