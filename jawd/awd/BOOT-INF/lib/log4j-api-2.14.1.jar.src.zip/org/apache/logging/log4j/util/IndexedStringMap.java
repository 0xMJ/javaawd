package org.apache.logging.log4j.util;

public abstract interface IndexedStringMap
  extends IndexedReadOnlyStringMap, StringMap
{}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\util\IndexedStringMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */