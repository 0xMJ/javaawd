package org.apache.logging.log4j.message;

public abstract interface MessageCollectionMessage<T>
  extends Message, Iterable<T>
{}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\message\MessageCollectionMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */