/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyFilePropertySource
/*    */   extends PropertiesPropertySource
/*    */ {
/*    */   public PropertyFilePropertySource(String fileName)
/*    */   {
/* 32 */     super(loadPropertiesFile(fileName));
/*    */   }
/*    */   
/*    */   private static Properties loadPropertiesFile(String fileName) {
/* 36 */     Properties props = new Properties();
/* 37 */     for (URL url : LoaderUtil.findResources(fileName)) {
/* 38 */       try { InputStream in = url.openStream();Throwable localThrowable3 = null;
/* 39 */         try { props.load(in);
/*    */         }
/*    */         catch (Throwable localThrowable1)
/*    */         {
/* 38 */           localThrowable3 = localThrowable1;throw localThrowable1;
/*    */         } finally {
/* 40 */           if (in != null) if (localThrowable3 != null) try { in.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else in.close();
/* 41 */         } } catch (IOException e) { LowLevelLogUtil.logException("Unable to read " + url, e);
/*    */       }
/*    */     }
/* 44 */     return props;
/*    */   }
/*    */   
/*    */   public int getPriority()
/*    */   {
/* 49 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\util\PropertyFilePropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */