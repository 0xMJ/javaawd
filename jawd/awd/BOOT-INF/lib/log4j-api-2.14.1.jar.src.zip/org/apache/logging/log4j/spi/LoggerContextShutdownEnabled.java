package org.apache.logging.log4j.spi;

import java.util.List;

public abstract interface LoggerContextShutdownEnabled
{
  public abstract void addShutdownListener(LoggerContextShutdownAware paramLoggerContextShutdownAware);
  
  public abstract List<LoggerContextShutdownAware> getListeners();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\spi\LoggerContextShutdownEnabled.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */