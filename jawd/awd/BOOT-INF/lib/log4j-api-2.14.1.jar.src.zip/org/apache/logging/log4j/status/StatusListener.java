package org.apache.logging.log4j.status;

import java.io.Closeable;
import java.util.EventListener;
import org.apache.logging.log4j.Level;

public abstract interface StatusListener
  extends Closeable, EventListener
{
  public abstract void log(StatusData paramStatusData);
  
  public abstract Level getStatusLevel();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\status\StatusListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */