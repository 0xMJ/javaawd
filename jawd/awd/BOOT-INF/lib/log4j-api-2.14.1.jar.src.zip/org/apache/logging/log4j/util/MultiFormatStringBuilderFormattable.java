package org.apache.logging.log4j.util;

import org.apache.logging.log4j.message.MultiformatMessage;

public abstract interface MultiFormatStringBuilderFormattable
  extends MultiformatMessage, StringBuilderFormattable
{
  public abstract void formatTo(String[] paramArrayOfString, StringBuilder paramStringBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\util\MultiFormatStringBuilderFormattable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */