/*    */ package org.apache.logging.log4j.util;
/*    */ 
/*    */ import java.util.NoSuchElementException;
/*    */ import java.util.Stack;
/*    */ import org.apache.logging.log4j.status.StatusLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StackLocatorUtil
/*    */ {
/* 32 */   private static StackLocator stackLocator = StackLocator.getInstance();
/*    */   
/*    */ 
/*    */ 
/*    */   private static volatile boolean errorLogged;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @PerformanceSensitive
/*    */   public static Class<?> getCallerClass(int depth)
/*    */   {
/* 44 */     return stackLocator.getCallerClass(depth + 1);
/*    */   }
/*    */   
/*    */   public static StackTraceElement getStackTraceElement(int depth) {
/* 48 */     return stackLocator.getStackTraceElement(depth + 1);
/*    */   }
/*    */   
/*    */   @PerformanceSensitive
/*    */   public static Class<?> getCallerClass(String fqcn)
/*    */   {
/* 54 */     return getCallerClass(fqcn, "");
/*    */   }
/*    */   
/*    */   @PerformanceSensitive
/*    */   public static Class<?> getCallerClass(String fqcn, String pkg)
/*    */   {
/* 60 */     return stackLocator.getCallerClass(fqcn, pkg);
/*    */   }
/*    */   
/*    */   @PerformanceSensitive
/*    */   public static Class<?> getCallerClass(Class<?> anchor)
/*    */   {
/* 66 */     return stackLocator.getCallerClass(anchor);
/*    */   }
/*    */   
/*    */   @PerformanceSensitive
/*    */   public static Stack<Class<?>> getCurrentStackTrace()
/*    */   {
/* 72 */     return stackLocator.getCurrentStackTrace();
/*    */   }
/*    */   
/*    */   public static StackTraceElement calcLocation(String fqcnOfLogger) {
/*    */     try {
/* 77 */       return stackLocator.calcLocation(fqcnOfLogger);
/*    */     } catch (NoSuchElementException ex) {
/* 79 */       if (!errorLogged) {
/* 80 */         errorLogged = true;
/* 81 */         StatusLogger.getLogger().warn("Unable to locate stack trace element for {}", fqcnOfLogger, ex);
/*    */       } }
/* 83 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\util\StackLocatorUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */