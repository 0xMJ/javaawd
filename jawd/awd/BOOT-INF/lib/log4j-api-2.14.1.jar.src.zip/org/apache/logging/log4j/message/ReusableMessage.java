package org.apache.logging.log4j.message;

import org.apache.logging.log4j.util.PerformanceSensitive;
import org.apache.logging.log4j.util.StringBuilderFormattable;

@PerformanceSensitive({"allocation"})
public abstract interface ReusableMessage
  extends Message, StringBuilderFormattable
{
  public abstract Object[] swapParameters(Object[] paramArrayOfObject);
  
  public abstract short getParameterCount();
  
  public abstract Message memento();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-api-2.14.1.jar!\org\apache\logging\log4j\message\ReusableMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */