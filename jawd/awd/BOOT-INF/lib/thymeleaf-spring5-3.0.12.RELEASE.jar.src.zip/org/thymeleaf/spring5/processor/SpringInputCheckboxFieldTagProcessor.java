/*     */ package org.thymeleaf.spring5.processor;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeDefinition;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.model.IModelFactory;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*     */ import org.thymeleaf.spring5.requestdata.RequestDataValueProcessorUtils;
/*     */ import org.thymeleaf.spring5.util.SpringSelectedValueComparator;
/*     */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*     */ import org.unbescape.html.HtmlEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringInputCheckboxFieldTagProcessor
/*     */   extends AbstractSpringFieldTagProcessor
/*     */ {
/*     */   public static final String CHECKBOX_INPUT_TYPE_ATTR_VALUE = "checkbox";
/*     */   private final boolean renderHiddenMarkersBeforeCheckboxes;
/*     */   
/*     */   public SpringInputCheckboxFieldTagProcessor(String dialectPrefix)
/*     */   {
/*  62 */     this(dialectPrefix, false);
/*     */   }
/*     */   
/*     */   public SpringInputCheckboxFieldTagProcessor(String dialectPrefix, boolean renderHiddenMarkersBeforeCheckboxes)
/*     */   {
/*  67 */     super(dialectPrefix, "input", "type", new String[] { "checkbox" }, true);
/*  68 */     this.renderHiddenMarkersBeforeCheckboxes = renderHiddenMarkersBeforeCheckboxes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IThymeleafBindStatus bindStatus, IElementTagStructureHandler structureHandler)
/*     */   {
/*  80 */     String name = bindStatus.getExpression();
/*  81 */     name = name == null ? "" : name;
/*     */     
/*  83 */     String id = computeId(context, tag, name, true);
/*     */     
/*  85 */     String value = null;
/*  86 */     boolean checked = false;
/*     */     
/*  88 */     Object boundValue = bindStatus.getValue();
/*  89 */     Class<?> valueType = bindStatus.getValueType();
/*     */     
/*  91 */     if ((Boolean.class.equals(valueType)) || (Boolean.TYPE.equals(valueType)))
/*     */     {
/*  93 */       if ((boundValue instanceof String)) {
/*  94 */         boundValue = Boolean.valueOf((String)boundValue);
/*     */       }
/*  96 */       Boolean booleanValue = boundValue != null ? (Boolean)boundValue : Boolean.FALSE;
/*  97 */       value = "true";
/*  98 */       checked = booleanValue.booleanValue();
/*     */     }
/*     */     else
/*     */     {
/* 102 */       value = tag.getAttributeValue(this.valueAttributeDefinition.getAttributeName());
/* 103 */       if (value == null) {
/* 104 */         throw new TemplateProcessingException("Attribute \"value\" is required in \"input(checkbox)\" tags when binding to non-boolean values");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 109 */       checked = SpringSelectedValueComparator.isSelected(bindStatus, HtmlEscape.unescapeHtml(value));
/*     */     }
/*     */     
/*     */ 
/* 113 */     StandardProcessorUtils.setAttribute(structureHandler, this.idAttributeDefinition, "id", id);
/* 114 */     StandardProcessorUtils.setAttribute(structureHandler, this.nameAttributeDefinition, "name", name);
/* 115 */     StandardProcessorUtils.setAttribute(structureHandler, this.valueAttributeDefinition, "value", 
/* 116 */       RequestDataValueProcessorUtils.processFormFieldValue(context, name, value, "checkbox"));
/* 117 */     if (checked) {
/* 118 */       StandardProcessorUtils.setAttribute(structureHandler, this.checkedAttributeDefinition, "checked", "checked");
/*     */     } else {
/* 120 */       structureHandler.removeAttribute(this.checkedAttributeDefinition.getAttributeName());
/*     */     }
/*     */     
/*     */ 
/* 124 */     if (!isDisabled(tag))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */       IModelFactory modelFactory = context.getModelFactory();
/*     */       
/* 135 */       IModel hiddenTagModel = modelFactory.createModel();
/*     */       
/* 137 */       String hiddenName = "_" + name;
/* 138 */       String hiddenValue = "on";
/*     */       
/* 140 */       Map<String, String> hiddenAttributes = new LinkedHashMap(4, 1.0F);
/* 141 */       hiddenAttributes.put("type", "hidden");
/* 142 */       hiddenAttributes.put("name", hiddenName);
/* 143 */       hiddenAttributes.put("value", RequestDataValueProcessorUtils.processFormFieldValue(context, hiddenName, "on", "hidden"));
/*     */       
/*     */ 
/* 146 */       IStandaloneElementTag hiddenTag = modelFactory.createStandaloneElementTag("input", hiddenAttributes, AttributeValueQuotes.DOUBLE, false, true);
/*     */       
/* 148 */       hiddenTagModel.add(hiddenTag);
/*     */       
/* 150 */       if (this.renderHiddenMarkersBeforeCheckboxes) {
/* 151 */         structureHandler.insertBefore(hiddenTagModel);
/*     */       } else {
/* 153 */         structureHandler.insertImmediatelyAfter(hiddenTagModel, false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean isDisabled(IProcessableElementTag tag)
/*     */   {
/* 164 */     return tag.hasAttribute(this.disabledAttributeDefinition.getAttributeName());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringInputCheckboxFieldTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */