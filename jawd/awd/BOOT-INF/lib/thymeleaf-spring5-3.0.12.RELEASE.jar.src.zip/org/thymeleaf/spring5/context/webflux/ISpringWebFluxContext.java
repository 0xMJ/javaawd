package org.thymeleaf.spring5.context.webflux;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebSession;
import org.thymeleaf.context.IContext;
import reactor.core.publisher.Mono;

public abstract interface ISpringWebFluxContext
  extends IContext
{
  public abstract ServerHttpRequest getRequest();
  
  public abstract ServerHttpResponse getResponse();
  
  public abstract Mono<WebSession> getSession();
  
  public abstract ServerWebExchange getExchange();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\webflux\ISpringWebFluxContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */