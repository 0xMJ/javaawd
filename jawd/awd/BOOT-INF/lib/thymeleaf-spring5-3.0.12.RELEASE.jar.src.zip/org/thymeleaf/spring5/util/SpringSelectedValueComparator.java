/*     */ package org.thymeleaf.spring5.util;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringSelectedValueComparator
/*     */ {
/*     */   public static boolean isSelected(IThymeleafBindStatus bindStatus, Object candidateValue)
/*     */   {
/*  58 */     if (bindStatus == null) {
/*  59 */       return candidateValue == null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  64 */     Object boundValue = bindStatus.getValue();
/*  65 */     if (ObjectUtils.nullSafeEquals(boundValue, candidateValue)) {
/*  66 */       return true;
/*     */     }
/*  68 */     Object actualValue = bindStatus.getActualValue();
/*  69 */     if ((actualValue != null) && (actualValue != boundValue) && 
/*  70 */       (ObjectUtils.nullSafeEquals(actualValue, candidateValue))) {
/*  71 */       return true;
/*     */     }
/*  73 */     if (actualValue != null) {
/*  74 */       boundValue = actualValue;
/*  75 */     } else if (boundValue == null) {
/*  76 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  81 */     boolean selected = false;
/*  82 */     if (boundValue.getClass().isArray()) {
/*  83 */       selected = collectionCompare(CollectionUtils.arrayToList(boundValue), candidateValue, bindStatus);
/*  84 */     } else if ((boundValue instanceof Collection)) {
/*  85 */       selected = collectionCompare((Collection)boundValue, candidateValue, bindStatus);
/*  86 */     } else if ((boundValue instanceof Map)) {
/*  87 */       selected = mapCompare((Map)boundValue, candidateValue, bindStatus);
/*     */     }
/*  89 */     if (!selected) {
/*  90 */       selected = exhaustiveCompare(boundValue, candidateValue, bindStatus.getEditor(), null);
/*     */     }
/*  92 */     return selected;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static boolean collectionCompare(Collection<?> boundCollection, Object candidateValue, IThymeleafBindStatus bindStatus)
/*     */   {
/*     */     try
/*     */     {
/* 101 */       if (boundCollection.contains(candidateValue)) {
/* 102 */         return true;
/*     */       }
/*     */     }
/*     */     catch (ClassCastException localClassCastException) {}
/*     */     
/* 107 */     return exhaustiveCollectionCompare(boundCollection, candidateValue, bindStatus);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static boolean mapCompare(Map<?, ?> boundMap, Object candidateValue, IThymeleafBindStatus bindStatus)
/*     */   {
/*     */     try
/*     */     {
/* 116 */       if (boundMap.containsKey(candidateValue)) {
/* 117 */         return true;
/*     */       }
/*     */     }
/*     */     catch (ClassCastException localClassCastException) {}
/*     */     
/* 122 */     return exhaustiveCollectionCompare(boundMap.keySet(), candidateValue, bindStatus);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean exhaustiveCollectionCompare(Collection<?> collection, Object candidateValue, IThymeleafBindStatus bindStatus)
/*     */   {
/* 130 */     Map<PropertyEditor, Object> convertedValueCache = new HashMap(1);
/* 131 */     PropertyEditor editor = null;
/* 132 */     boolean candidateIsString = candidateValue instanceof String;
/* 133 */     if (!candidateIsString) {
/* 134 */       editor = bindStatus.findEditor(candidateValue.getClass());
/*     */     }
/* 136 */     for (Object element : collection) {
/* 137 */       if ((editor == null) && (element != null) && (candidateIsString)) {
/* 138 */         editor = bindStatus.findEditor(element.getClass());
/*     */       }
/* 140 */       if (exhaustiveCompare(element, candidateValue, editor, convertedValueCache)) {
/* 141 */         return true;
/*     */       }
/*     */     }
/* 144 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean exhaustiveCompare(Object boundValue, Object candidate, PropertyEditor editor, Map<PropertyEditor, Object> convertedValueCache)
/*     */   {
/* 153 */     String candidateDisplayString = SpringValueFormatter.getDisplayString(candidate, editor, false);
/* 154 */     if ((boundValue != null) && (boundValue.getClass().isEnum())) {
/* 155 */       Enum<?> boundEnum = (Enum)boundValue;
/* 156 */       String enumCodeAsString = ObjectUtils.getDisplayString(boundEnum.name());
/* 157 */       if (enumCodeAsString.equals(candidateDisplayString)) {
/* 158 */         return true;
/*     */       }
/* 160 */       String enumLabelAsString = ObjectUtils.getDisplayString(boundEnum.toString());
/* 161 */       if (enumLabelAsString.equals(candidateDisplayString))
/* 162 */         return true;
/*     */     } else {
/* 164 */       if (ObjectUtils.getDisplayString(boundValue).equals(candidateDisplayString))
/* 165 */         return true;
/* 166 */       if ((editor != null) && ((candidate instanceof String)))
/*     */       {
/* 168 */         String candidateAsString = (String)candidate;
/*     */         Object candidateAsValue;
/* 170 */         Object candidateAsValue; if ((convertedValueCache != null) && (convertedValueCache.containsKey(editor))) {
/* 171 */           candidateAsValue = convertedValueCache.get(editor);
/*     */         } else {
/* 173 */           editor.setAsText(candidateAsString);
/* 174 */           candidateAsValue = editor.getValue();
/* 175 */           if (convertedValueCache != null) {
/* 176 */             convertedValueCache.put(editor, candidateAsValue);
/*     */           }
/*     */         }
/* 179 */         if (ObjectUtils.nullSafeEquals(boundValue, candidateAsValue))
/* 180 */           return true;
/*     */       }
/*     */     }
/* 183 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\util\SpringSelectedValueComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */