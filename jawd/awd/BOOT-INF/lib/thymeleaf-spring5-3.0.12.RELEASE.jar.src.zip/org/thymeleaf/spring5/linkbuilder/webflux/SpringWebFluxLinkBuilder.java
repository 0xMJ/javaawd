/*     */ package org.thymeleaf.spring5.linkbuilder.webflux;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.linkbuilder.StandardLinkBuilder;
/*     */ import org.thymeleaf.spring5.context.webflux.ISpringWebFluxContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringWebFluxLinkBuilder
/*     */   extends StandardLinkBuilder
/*     */ {
/*     */   protected String computeContextPath(IExpressionContext context, String base, Map<String, Object> parameters)
/*     */   {
/*  83 */     if (!(context instanceof ISpringWebFluxContext))
/*     */     {
/*     */ 
/*  86 */       throw new TemplateProcessingException("Link base \"" + base + "\" cannot be context relative (/...) unless the context used for executing the engine implements the " + ISpringWebFluxContext.class.getName() + " interface");
/*     */     }
/*     */     
/*     */ 
/*  90 */     ServerHttpRequest request = ((ISpringWebFluxContext)context).getRequest();
/*  91 */     return request.getPath().contextPath().value();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String processLink(IExpressionContext context, String link)
/*     */   {
/* 111 */     if (!(context instanceof ISpringWebFluxContext)) {
/* 112 */       return link;
/*     */     }
/*     */     
/* 115 */     ServerWebExchange exchange = ((ISpringWebFluxContext)context).getExchange();
/* 116 */     return exchange.transformUrl(link);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\linkbuilder\webflux\SpringWebFluxLinkBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */