/*     */ package org.thymeleaf.spring5.expression;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.spel.SpelCompilerMode;
/*     */ import org.springframework.expression.spel.SpelParserConfiguration;
/*     */ import org.springframework.expression.spel.standard.SpelExpression;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.cache.ExpressionCacheKey;
/*     */ import org.thymeleaf.cache.ICache;
/*     */ import org.thymeleaf.cache.ICacheManager;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*     */ import org.thymeleaf.spring5.util.FieldUtils;
/*     */ import org.thymeleaf.spring5.util.SpringStandardExpressionUtils;
/*     */ import org.thymeleaf.spring5.util.SpringValueFormatter;
/*     */ import org.thymeleaf.spring5.util.SpringVersionUtils;
/*     */ import org.thymeleaf.standard.expression.IStandardConversionService;
/*     */ import org.thymeleaf.standard.expression.IStandardVariableExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardVariableExpressionEvaluator;
/*     */ import org.thymeleaf.standard.expression.SelectionVariableExpression;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionExecutionContext;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.standard.expression.VariableExpression;
/*     */ import org.thymeleaf.standard.util.StandardExpressionUtils;
/*     */ import org.thymeleaf.util.ClassLoaderUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SPELVariableExpressionEvaluator
/*     */   implements IStandardVariableExpressionEvaluator
/*     */ {
/*  75 */   public static final SPELVariableExpressionEvaluator INSTANCE = new SPELVariableExpressionEvaluator();
/*     */   
/*     */ 
/*     */   private static final String EXPRESSION_CACHE_TYPE_SPEL = "spel";
/*     */   
/*  80 */   private static final Logger logger = LoggerFactory.getLogger(SPELVariableExpressionEvaluator.class);
/*     */   
/*  82 */   private static final SpelExpressionParser PARSER_WITHOUT_COMPILED_SPEL = new SpelExpressionParser();
/*     */   
/*     */ 
/*     */ 
/*     */   private static final SpelExpressionParser PARSER_WITH_COMPILED_SPEL;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  93 */     SpelExpressionParser spelCompilerExpressionParser = null;
/*  94 */     if (SpringVersionUtils.isSpring41AtLeast())
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/*     */ 
/*     */ 
/* 101 */         SpelParserConfiguration spelParserConfiguration = new SpelParserConfiguration(SpelCompilerMode.MIXED, ClassLoaderUtils.getClassLoader(SPELVariableExpressionEvaluator.class));
/* 102 */         spelCompilerExpressionParser = new SpelExpressionParser(spelParserConfiguration);
/*     */       } catch (Throwable t) {
/* 104 */         if (logger.isDebugEnabled())
/*     */         {
/*     */ 
/* 107 */           logger.warn("An error happened during the initialization of the Spring EL expression compiler. However, initialization was completed anyway. Note that compilation of SpEL expressions will not be available even if you configure your Spring dialect to use them.", t);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 112 */           logger.warn("An error happened during the initialization of the Spring EL expression compiler. However, initialization was completed anyway. Note that compilation of SpEL expressions will not be available even if you configure your Spring dialect to use them. For more info, set your log to at least DEBUG level: " + t
/*     */           
/*     */ 
/*     */ 
/* 116 */             .getMessage());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 121 */     PARSER_WITH_COMPILED_SPEL = spelCompilerExpressionParser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Object evaluate(IExpressionContext context, IStandardVariableExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 138 */     if (logger.isTraceEnabled()) {
/* 139 */       logger.trace("[THYMELEAF][{}] SpringEL expression: evaluating expression \"{}\" on target", TemplateEngine.threadIndex(), expression.getExpression());
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 144 */       String spelExpression = expression.getExpression();
/* 145 */       boolean useSelectionAsRoot = expression.getUseSelectionAsRoot();
/*     */       
/* 147 */       if (spelExpression == null) {
/* 148 */         throw new TemplateProcessingException("Expression content is null, which is not allowed");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 154 */       if (expContext.getPerformTypeConversion())
/*     */       {
/*     */ 
/* 157 */         if ((useSelectionAsRoot) || (!isLocalVariableOverriding(context, spelExpression)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 164 */           IThymeleafBindStatus bindStatus = FieldUtils.getBindStatusFromParsedExpression(context, true, useSelectionAsRoot, spelExpression);
/*     */           
/* 166 */           if (bindStatus != null)
/*     */           {
/* 168 */             return SpringValueFormatter.getDisplayString(bindStatus.getValue(), bindStatus.getEditor(), false);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 175 */       IEngineConfiguration configuration = context.getConfiguration();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */       ComputedSpelExpression exp = obtainComputedSpelExpression(configuration, expression, spelExpression, expContext);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */       IExpressionObjects expressionObjects = exp.mightNeedExpressionObjects ? context.getExpressionObjects() : null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 200 */       EvaluationContext evaluationContext = (EvaluationContext)context.getVariable("thymeleaf::EvaluationContext");
/*     */       
/* 202 */       if (evaluationContext == null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 214 */         evaluationContext = new ThymeleafEvaluationContextWrapper(new StandardEvaluationContext());
/*     */         
/* 216 */         if ((context instanceof IEngineContext)) {
/* 217 */           ((IEngineContext)context).setVariable("thymeleaf::EvaluationContext", evaluationContext);
/*     */         }
/*     */         
/*     */       }
/* 221 */       else if (!(evaluationContext instanceof IThymeleafEvaluationContext))
/*     */       {
/* 223 */         evaluationContext = new ThymeleafEvaluationContextWrapper(evaluationContext);
/*     */         
/* 225 */         if ((context instanceof IEngineContext)) {
/* 226 */           ((IEngineContext)context).setVariable("thymeleaf::EvaluationContext", evaluationContext);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 239 */       IThymeleafEvaluationContext thymeleafEvaluationContext = (IThymeleafEvaluationContext)evaluationContext;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 248 */       thymeleafEvaluationContext.setExpressionObjects(expressionObjects);
/* 249 */       thymeleafEvaluationContext.setVariableAccessRestricted(expContext.getRestrictVariableAccess());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 255 */       ITemplateContext templateContext = (context instanceof ITemplateContext) ? (ITemplateContext)context : null;
/*     */       
/*     */ 
/* 258 */       Object evaluationRoot = (useSelectionAsRoot) && (templateContext != null) && (templateContext.hasSelectionTarget()) ? templateContext.getSelectionTarget() : new SPELContextMapWrapper(context, thymeleafEvaluationContext);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 264 */       if (!expContext.getPerformTypeConversion()) {
/* 265 */         return exp.expression.getValue(thymeleafEvaluationContext, evaluationRoot);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 273 */       IStandardConversionService conversionService = StandardExpressions.getConversionService(configuration);
/*     */       
/* 275 */       if ((conversionService instanceof SpringStandardConversionService))
/*     */       {
/*     */ 
/*     */ 
/* 279 */         return exp.expression.getValue(thymeleafEvaluationContext, evaluationRoot, String.class);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 284 */       Object result = exp.expression.getValue(thymeleafEvaluationContext, evaluationRoot);
/* 285 */       return conversionService.convert(context, result, String.class);
/*     */     }
/*     */     catch (TemplateProcessingException e)
/*     */     {
/* 289 */       throw e;
/*     */     }
/*     */     catch (Exception e) {
/* 292 */       throw new TemplateProcessingException("Exception evaluating SpringEL expression: \"" + expression.getExpression() + "\"", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ComputedSpelExpression obtainComputedSpelExpression(IEngineConfiguration configuration, IStandardVariableExpression expression, String spelExpression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 307 */     if ((expression instanceof VariableExpression))
/*     */     {
/* 309 */       VariableExpression vexpression = (VariableExpression)expression;
/*     */       
/* 311 */       Object cachedExpression = vexpression.getCachedExpression();
/* 312 */       if ((cachedExpression != null) && ((cachedExpression instanceof ComputedSpelExpression))) {
/* 313 */         return (ComputedSpelExpression)cachedExpression;
/*     */       }
/* 315 */       cachedExpression = getExpression(configuration, spelExpression, expContext);
/* 316 */       if (cachedExpression != null) {
/* 317 */         vexpression.setCachedExpression(cachedExpression);
/*     */       }
/* 319 */       return (ComputedSpelExpression)cachedExpression;
/*     */     }
/*     */     
/*     */ 
/* 323 */     if ((expression instanceof SelectionVariableExpression))
/*     */     {
/* 325 */       SelectionVariableExpression vexpression = (SelectionVariableExpression)expression;
/*     */       
/* 327 */       Object cachedExpression = vexpression.getCachedExpression();
/* 328 */       if ((cachedExpression != null) && ((cachedExpression instanceof ComputedSpelExpression))) {
/* 329 */         return (ComputedSpelExpression)cachedExpression;
/*     */       }
/* 331 */       cachedExpression = getExpression(configuration, spelExpression, expContext);
/* 332 */       if (cachedExpression != null) {
/* 333 */         vexpression.setCachedExpression(cachedExpression);
/*     */       }
/* 335 */       return (ComputedSpelExpression)cachedExpression;
/*     */     }
/*     */     
/*     */ 
/* 339 */     return getExpression(configuration, spelExpression, expContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ComputedSpelExpression getExpression(IEngineConfiguration configuration, String spelExpression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 348 */     ComputedSpelExpression exp = null;
/* 349 */     ICache<ExpressionCacheKey, Object> cache = null;
/*     */     
/* 351 */     ICacheManager cacheManager = configuration.getCacheManager();
/* 352 */     if (cacheManager != null) {
/* 353 */       cache = cacheManager.getExpressionCache();
/* 354 */       if (cache != null) {
/* 355 */         exp = (ComputedSpelExpression)cache.get(new ExpressionCacheKey("spel", spelExpression));
/*     */       }
/*     */     }
/*     */     
/* 359 */     if (exp == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 364 */       SpelExpressionParser spelExpressionParser = (PARSER_WITH_COMPILED_SPEL != null) && (SpringStandardExpressions.isSpringELCompilerEnabled(configuration)) ? PARSER_WITH_COMPILED_SPEL : PARSER_WITHOUT_COMPILED_SPEL;
/*     */       
/* 366 */       if ((expContext.getRestrictInstantiationAndStatic()) && 
/* 367 */         (SpringStandardExpressionUtils.containsSpELInstantiationOrStatic(spelExpression))) {
/* 368 */         throw new TemplateProcessingException("Instantiation of new objects and access to static classes is forbidden in this context");
/*     */       }
/*     */       
/*     */ 
/* 372 */       boolean mightNeedExpressionObjects = StandardExpressionUtils.mightNeedExpressionObjects(spelExpression);
/*     */       
/* 374 */       SpelExpression spelExpressionObject = (SpelExpression)spelExpressionParser.parseExpression(spelExpression);
/*     */       
/* 376 */       exp = new ComputedSpelExpression(spelExpressionObject, mightNeedExpressionObjects);
/*     */       
/* 378 */       if ((cache != null) && (null != exp)) {
/* 379 */         cache.put(new ExpressionCacheKey("spel", spelExpression), exp);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 384 */     return exp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isLocalVariableOverriding(IExpressionContext context, String expression)
/*     */   {
/* 392 */     if (!(context instanceof IEngineContext))
/*     */     {
/* 394 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 398 */     IEngineContext engineContext = (IEngineContext)context;
/*     */     
/* 400 */     int dotPos = expression.indexOf('.');
/* 401 */     if (dotPos == -1) {
/* 402 */       return false;
/*     */     }
/*     */     
/* 405 */     String expressionFirstComponent = expression.substring(0, dotPos);
/* 406 */     return engineContext.isVariableLocal(expressionFirstComponent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 415 */     return "SpringEL";
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class ComputedSpelExpression
/*     */   {
/*     */     final SpelExpression expression;
/*     */     
/*     */     final boolean mightNeedExpressionObjects;
/*     */     
/*     */     ComputedSpelExpression(SpelExpression expression, boolean mightNeedExpressionObjects)
/*     */     {
/* 427 */       this.expression = expression;
/* 428 */       this.mightNeedExpressionObjects = mightNeedExpressionObjects;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\expression\SPELVariableExpressionEvaluator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */