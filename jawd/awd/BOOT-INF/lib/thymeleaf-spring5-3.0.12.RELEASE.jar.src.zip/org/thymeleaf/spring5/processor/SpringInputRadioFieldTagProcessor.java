/*    */ package org.thymeleaf.spring5.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeDefinition;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*    */ import org.thymeleaf.spring5.requestdata.RequestDataValueProcessorUtils;
/*    */ import org.thymeleaf.spring5.util.SpringSelectedValueComparator;
/*    */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*    */ import org.unbescape.html.HtmlEscape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringInputRadioFieldTagProcessor
/*    */   extends AbstractSpringFieldTagProcessor
/*    */ {
/*    */   public static final String RADIO_INPUT_TYPE_ATTR_VALUE = "radio";
/*    */   
/*    */   public SpringInputRadioFieldTagProcessor(String dialectPrefix)
/*    */   {
/* 50 */     super(dialectPrefix, "input", "type", new String[] { "radio" }, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IThymeleafBindStatus bindStatus, IElementTagStructureHandler structureHandler)
/*    */   {
/* 62 */     String name = bindStatus.getExpression();
/* 63 */     name = name == null ? "" : name;
/*    */     
/* 65 */     String id = computeId(context, tag, name, true);
/*    */     
/* 67 */     String value = tag.getAttributeValue(this.valueAttributeDefinition.getAttributeName());
/* 68 */     if (value == null) {
/* 69 */       throw new TemplateProcessingException("Attribute \"value\" is required in \"input(radio)\" tags");
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 74 */     boolean checked = SpringSelectedValueComparator.isSelected(bindStatus, HtmlEscape.unescapeHtml(value));
/*    */     
/*    */ 
/* 77 */     StandardProcessorUtils.setAttribute(structureHandler, this.idAttributeDefinition, "id", id);
/* 78 */     StandardProcessorUtils.setAttribute(structureHandler, this.nameAttributeDefinition, "name", name);
/* 79 */     StandardProcessorUtils.setAttribute(structureHandler, this.valueAttributeDefinition, "value", 
/* 80 */       RequestDataValueProcessorUtils.processFormFieldValue(context, name, value, "radio"));
/*    */     
/* 82 */     if (checked) {
/* 83 */       StandardProcessorUtils.setAttribute(structureHandler, this.checkedAttributeDefinition, "checked", "checked");
/*    */     } else {
/* 85 */       structureHandler.removeAttribute(this.checkedAttributeDefinition.getAttributeName());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringInputRadioFieldTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */