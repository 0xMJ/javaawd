package org.thymeleaf.spring5.context;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;
import org.springframework.ui.context.Theme;
import org.springframework.validation.Errors;

public abstract interface IThymeleafRequestContext
{
  public abstract MessageSource getMessageSource();
  
  public abstract Map<String, Object> getModel();
  
  public abstract Locale getLocale();
  
  public abstract TimeZone getTimeZone();
  
  public abstract void changeLocale(Locale paramLocale);
  
  public abstract void changeLocale(Locale paramLocale, TimeZone paramTimeZone);
  
  public abstract void setDefaultHtmlEscape(boolean paramBoolean);
  
  public abstract boolean isDefaultHtmlEscape();
  
  public abstract Boolean getDefaultHtmlEscape();
  
  public abstract String getContextPath();
  
  public abstract String getContextUrl(String paramString);
  
  public abstract String getContextUrl(String paramString, Map<String, ?> paramMap);
  
  public abstract String getRequestPath();
  
  public abstract String getQueryString();
  
  public abstract String getMessage(String paramString1, String paramString2);
  
  public abstract String getMessage(String paramString1, Object[] paramArrayOfObject, String paramString2);
  
  public abstract String getMessage(String paramString1, List<?> paramList, String paramString2);
  
  public abstract String getMessage(String paramString1, Object[] paramArrayOfObject, String paramString2, boolean paramBoolean);
  
  public abstract String getMessage(String paramString)
    throws NoSuchMessageException;
  
  public abstract String getMessage(String paramString, Object[] paramArrayOfObject)
    throws NoSuchMessageException;
  
  public abstract String getMessage(String paramString, List<?> paramList)
    throws NoSuchMessageException;
  
  public abstract String getMessage(String paramString, Object[] paramArrayOfObject, boolean paramBoolean)
    throws NoSuchMessageException;
  
  public abstract String getMessage(MessageSourceResolvable paramMessageSourceResolvable)
    throws NoSuchMessageException;
  
  public abstract String getMessage(MessageSourceResolvable paramMessageSourceResolvable, boolean paramBoolean)
    throws NoSuchMessageException;
  
  public abstract Optional<Errors> getErrors(String paramString);
  
  public abstract Optional<Errors> getErrors(String paramString, boolean paramBoolean);
  
  public abstract Theme getTheme();
  
  public abstract IThymeleafRequestDataValueProcessor getRequestDataValueProcessor();
  
  public abstract IThymeleafBindStatus getBindStatus(String paramString)
    throws IllegalStateException;
  
  public abstract IThymeleafBindStatus getBindStatus(String paramString, boolean paramBoolean)
    throws IllegalStateException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\IThymeleafRequestContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */