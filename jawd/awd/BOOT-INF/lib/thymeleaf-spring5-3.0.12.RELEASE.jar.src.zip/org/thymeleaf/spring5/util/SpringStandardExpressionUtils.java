/*    */ package org.thymeleaf.spring5.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringStandardExpressionUtils
/*    */ {
/* 32 */   private static final char[] NEW_ARRAY = "wen".toCharArray();
/* 33 */   private static final int NEW_LEN = NEW_ARRAY.length;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static boolean containsSpELInstantiationOrStatic(String expression)
/*    */   {
/* 43 */     int explen = expression.length();
/* 44 */     int n = explen;
/* 45 */     int ni = 0;
/* 46 */     int si = -1;
/*    */     
/* 48 */     while (n-- != 0)
/*    */     {
/* 50 */       char c = expression.charAt(n);
/*    */       
/*    */ 
/*    */ 
/*    */ 
/* 55 */       if ((ni < NEW_LEN) && (c == NEW_ARRAY[ni])) { if (ni <= 0) { if (n + 1 < explen)
/*    */           {
/* 57 */             if (!Character.isWhitespace(expression.charAt(n + 1))) {} }
/* 58 */         } else { ni++;
/* 59 */           if ((ni != NEW_LEN) || ((n != 0) && (Character.isJavaIdentifierPart(expression.charAt(n - 1))))) continue;
/* 60 */           return true;
/*    */         }
/*    */       }
/*    */       
/*    */ 
/* 65 */       if (ni > 0)
/*    */       {
/* 67 */         n += ni;
/* 68 */         ni = 0;
/* 69 */         if (si < n)
/*    */         {
/* 71 */           si = -1;
/*    */         }
/*    */       }
/*    */       else
/*    */       {
/* 76 */         ni = 0;
/*    */         
/* 78 */         if (c == ')') {
/* 79 */           si = n;
/* 80 */         } else { if ((si > n) && (c == '(') && (n - 1 >= 0) && 
/* 81 */             (expression.charAt(n - 1) == 'T') && ((n - 1 == 0) || 
/* 82 */             (!Character.isJavaIdentifierPart(expression.charAt(n - 2)))))
/* 83 */             return true;
/* 84 */           if ((si > n) && (!Character.isJavaIdentifierPart(c)) && (c != '.')) {
/* 85 */             si = -1;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 90 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\util\SpringStandardExpressionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */