/*     */ package org.thymeleaf.spring5.context.webmvc;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringWebMvcThymeleafBindStatus
/*     */   implements IThymeleafBindStatus
/*     */ {
/*     */   private final BindStatus bindStatus;
/*     */   
/*     */   SpringWebMvcThymeleafBindStatus(BindStatus bindStatus)
/*     */   {
/*  49 */     Validate.notNull(bindStatus, "BindStatus cannot be null");
/*  50 */     this.bindStatus = bindStatus;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getPath()
/*     */   {
/*  56 */     return this.bindStatus.getPath();
/*     */   }
/*     */   
/*     */   public String getExpression()
/*     */   {
/*  61 */     return this.bindStatus.getExpression();
/*     */   }
/*     */   
/*     */   public Object getValue()
/*     */   {
/*  66 */     return this.bindStatus.getValue();
/*     */   }
/*     */   
/*     */   public Class<?> getValueType()
/*     */   {
/*  71 */     return this.bindStatus.getValueType();
/*     */   }
/*     */   
/*     */   public Object getActualValue()
/*     */   {
/*  76 */     return this.bindStatus.getActualValue();
/*     */   }
/*     */   
/*     */   public String getDisplayValue()
/*     */   {
/*  81 */     return this.bindStatus.getDisplayValue();
/*     */   }
/*     */   
/*     */   public boolean isError()
/*     */   {
/*  86 */     return this.bindStatus.isError();
/*     */   }
/*     */   
/*     */   public String[] getErrorCodes()
/*     */   {
/*  91 */     return this.bindStatus.getErrorCodes();
/*     */   }
/*     */   
/*     */   public String getErrorCode()
/*     */   {
/*  96 */     return this.bindStatus.getErrorCode();
/*     */   }
/*     */   
/*     */   public String[] getErrorMessages()
/*     */   {
/* 101 */     return this.bindStatus.getErrorMessages();
/*     */   }
/*     */   
/*     */   public String getErrorMessage()
/*     */   {
/* 106 */     return this.bindStatus.getErrorMessage();
/*     */   }
/*     */   
/*     */   public String getErrorMessagesAsString(String delimiter)
/*     */   {
/* 111 */     return this.bindStatus.getErrorMessagesAsString(delimiter);
/*     */   }
/*     */   
/*     */   public Errors getErrors()
/*     */   {
/* 116 */     return this.bindStatus.getErrors();
/*     */   }
/*     */   
/*     */   public PropertyEditor getEditor()
/*     */   {
/* 121 */     return this.bindStatus.getEditor();
/*     */   }
/*     */   
/*     */   public PropertyEditor findEditor(Class<?> valueClass)
/*     */   {
/* 126 */     return this.bindStatus.findEditor(valueClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 134 */     return this.bindStatus.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\webmvc\SpringWebMvcThymeleafBindStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */