/*     */ package org.thymeleaf.spring5.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.context.expression.MapAccessor;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.ConstructorResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.MethodResolver;
/*     */ import org.springframework.expression.OperatorOverloader;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypeComparator;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypeLocator;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ import org.thymeleaf.standard.expression.RestrictedRequestAccessUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ThymeleafEvaluationContextWrapper
/*     */   implements IThymeleafEvaluationContext
/*     */ {
/*  64 */   private static final MapAccessor MAP_ACCESSOR_INSTANCE = new MapAccessor();
/*     */   
/*     */   private final EvaluationContext delegate;
/*     */   
/*     */   private final List<PropertyAccessor> propertyAccessors;
/*     */   
/*  70 */   private IExpressionObjects expressionObjects = null;
/*  71 */   private boolean requestParametersRestricted = false;
/*  72 */   private Map<String, Object> additionalVariables = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ThymeleafEvaluationContextWrapper(EvaluationContext delegate)
/*     */   {
/*  81 */     Validate.notNull(delegate, "Evaluation context delegate cannot be null");
/*     */     
/*  83 */     this.delegate = delegate;
/*     */     
/*  85 */     if ((this.delegate instanceof ThymeleafEvaluationContext))
/*     */     {
/*  87 */       this.propertyAccessors = null;
/*     */     }
/*  89 */     else if ((this.delegate instanceof StandardEvaluationContext))
/*     */     {
/*  91 */       ((StandardEvaluationContext)this.delegate).addPropertyAccessor(SPELContextPropertyAccessor.INSTANCE);
/*  92 */       ((StandardEvaluationContext)this.delegate).addPropertyAccessor(MAP_ACCESSOR_INSTANCE);
/*  93 */       this.propertyAccessors = null;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  99 */       this.propertyAccessors = new ArrayList(5);
/* 100 */       this.propertyAccessors.addAll(this.delegate.getPropertyAccessors());
/* 101 */       this.propertyAccessors.add(SPELContextPropertyAccessor.INSTANCE);
/* 102 */       this.propertyAccessors.add(MAP_ACCESSOR_INSTANCE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TypedValue getRootObject()
/*     */   {
/* 110 */     return this.delegate.getRootObject();
/*     */   }
/*     */   
/*     */   public List<ConstructorResolver> getConstructorResolvers() {
/* 114 */     return this.delegate.getConstructorResolvers();
/*     */   }
/*     */   
/*     */   public List<MethodResolver> getMethodResolvers() {
/* 118 */     return this.delegate.getMethodResolvers();
/*     */   }
/*     */   
/*     */   public List<PropertyAccessor> getPropertyAccessors() {
/* 122 */     return this.propertyAccessors == null ? this.delegate.getPropertyAccessors() : this.propertyAccessors;
/*     */   }
/*     */   
/*     */   public TypeLocator getTypeLocator() {
/* 126 */     return this.delegate.getTypeLocator();
/*     */   }
/*     */   
/*     */   public TypeConverter getTypeConverter() {
/* 130 */     return this.delegate.getTypeConverter();
/*     */   }
/*     */   
/*     */   public TypeComparator getTypeComparator() {
/* 134 */     return this.delegate.getTypeComparator();
/*     */   }
/*     */   
/*     */   public OperatorOverloader getOperatorOverloader() {
/* 138 */     return this.delegate.getOperatorOverloader();
/*     */   }
/*     */   
/*     */   public BeanResolver getBeanResolver() {
/* 142 */     return this.delegate.getBeanResolver();
/*     */   }
/*     */   
/*     */   public void setVariable(String name, Object value) {
/* 146 */     if (this.additionalVariables == null) {
/* 147 */       this.additionalVariables = new HashMap(5, 1.0F);
/*     */     }
/* 149 */     this.additionalVariables.put(name, value);
/*     */   }
/*     */   
/*     */   public Object lookupVariable(String name)
/*     */   {
/* 154 */     if ((this.expressionObjects != null) && (this.expressionObjects.containsObject(name)))
/*     */     {
/* 156 */       Object result = this.expressionObjects.getObject(name);
/* 157 */       if (result != null)
/*     */       {
/*     */ 
/* 160 */         if ((this.requestParametersRestricted) && (
/* 161 */           ("request".equals(name)) || 
/* 162 */           ("httpServletRequest".equals(name)))) {
/* 163 */           return RestrictedRequestAccessUtils.wrapRequestObject(result);
/*     */         }
/*     */         
/* 166 */         return result;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 171 */     if ((this.additionalVariables != null) && (this.additionalVariables.containsKey(name))) {
/* 172 */       Object result = this.additionalVariables.get(name);
/* 173 */       if (result != null) {
/* 174 */         return result;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 179 */     return this.delegate.lookupVariable(name);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isVariableAccessRestricted()
/*     */   {
/* 185 */     return this.requestParametersRestricted;
/*     */   }
/*     */   
/*     */   public void setVariableAccessRestricted(boolean restricted) {
/* 189 */     this.requestParametersRestricted = restricted;
/*     */   }
/*     */   
/*     */   public IExpressionObjects getExpressionObjects() {
/* 193 */     return this.expressionObjects;
/*     */   }
/*     */   
/*     */   public void setExpressionObjects(IExpressionObjects expressionObjects) {
/* 197 */     this.expressionObjects = expressionObjects;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\expression\ThymeleafEvaluationContextWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */