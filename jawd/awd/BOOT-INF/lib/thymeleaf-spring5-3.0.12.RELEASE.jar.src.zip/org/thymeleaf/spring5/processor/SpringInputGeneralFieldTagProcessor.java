/*     */ package org.thymeleaf.spring5.processor;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeDefinition;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*     */ import org.thymeleaf.spring5.requestdata.RequestDataValueProcessorUtils;
/*     */ import org.thymeleaf.spring5.util.SpringValueFormatter;
/*     */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringInputGeneralFieldTagProcessor
/*     */   extends AbstractSpringFieldTagProcessor
/*     */ {
/*     */   public static final String TEXT_INPUT_TYPE_ATTR_VALUE = "text";
/*     */   public static final String HIDDEN_INPUT_TYPE_ATTR_VALUE = "hidden";
/*     */   public static final String DATETIME_INPUT_TYPE_ATTR_VALUE = "datetime";
/*     */   public static final String DATETIMELOCAL_INPUT_TYPE_ATTR_VALUE = "datetime-local";
/*     */   public static final String DATE_INPUT_TYPE_ATTR_VALUE = "date";
/*     */   public static final String MONTH_INPUT_TYPE_ATTR_VALUE = "month";
/*     */   public static final String TIME_INPUT_TYPE_ATTR_VALUE = "time";
/*     */   public static final String WEEK_INPUT_TYPE_ATTR_VALUE = "week";
/*     */   public static final String NUMBER_INPUT_TYPE_ATTR_VALUE = "number";
/*     */   public static final String RANGE_INPUT_TYPE_ATTR_VALUE = "range";
/*     */   public static final String EMAIL_INPUT_TYPE_ATTR_VALUE = "email";
/*     */   public static final String URL_INPUT_TYPE_ATTR_VALUE = "url";
/*     */   public static final String SEARCH_INPUT_TYPE_ATTR_VALUE = "search";
/*     */   public static final String TEL_INPUT_TYPE_ATTR_VALUE = "tel";
/*     */   public static final String COLOR_INPUT_TYPE_ATTR_VALUE = "color";
/*  62 */   private static final String[] ALL_TYPE_ATTR_VALUES = { null, "text", "hidden", "datetime", "datetime-local", "date", "month", "time", "week", "number", "range", "email", "url", "search", "tel", "color" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringInputGeneralFieldTagProcessor(String dialectPrefix)
/*     */   {
/*  86 */     super(dialectPrefix, "input", "type", ALL_TYPE_ATTR_VALUES, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IThymeleafBindStatus bindStatus, IElementTagStructureHandler structureHandler)
/*     */   {
/*  98 */     String name = bindStatus.getExpression();
/*  99 */     name = name == null ? "" : name;
/*     */     
/* 101 */     String id = computeId(context, tag, name, false);
/*     */     
/*     */ 
/* 104 */     String type = tag.getAttributeValue(this.typeAttributeDefinition.getAttributeName());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */     String value = applyConversion(type) ? SpringValueFormatter.getDisplayString(bindStatus.getValue(), bindStatus.getEditor(), true) : SpringValueFormatter.getDisplayString(bindStatus.getActualValue(), true);
/*     */     
/* 113 */     StandardProcessorUtils.setAttribute(structureHandler, this.idAttributeDefinition, "id", id);
/* 114 */     StandardProcessorUtils.setAttribute(structureHandler, this.nameAttributeDefinition, "name", name);
/*     */     
/* 116 */     StandardProcessorUtils.setAttribute(structureHandler, this.valueAttributeDefinition, "value", 
/* 117 */       RequestDataValueProcessorUtils.processFormFieldValue(context, name, value, type));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static boolean applyConversion(String type)
/*     */   {
/* 124 */     return (type == null) || ((!"number".equalsIgnoreCase(type)) && (!"range".equalsIgnoreCase(type)));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringInputGeneralFieldTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */