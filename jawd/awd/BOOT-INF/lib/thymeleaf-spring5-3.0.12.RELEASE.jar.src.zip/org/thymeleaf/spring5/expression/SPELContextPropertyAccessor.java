/*     */ package org.thymeleaf.spring5.expression;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SPELContextPropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*  52 */   private static final Logger LOGGER = LoggerFactory.getLogger(SPELContextPropertyAccessor.class);
/*     */   
/*  54 */   static final SPELContextPropertyAccessor INSTANCE = new SPELContextPropertyAccessor();
/*     */   
/*     */   private static final String REQUEST_PARAMETERS_RESTRICTED_VARIABLE_NAME = "param";
/*  57 */   private static final Class<?>[] TARGET_CLASSES = { IContext.class };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?>[] getSpecificTargetClasses()
/*     */   {
/*  68 */     return TARGET_CLASSES;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canRead(EvaluationContext context, Object target, String name)
/*     */     throws AccessException
/*     */   {
/*  75 */     if (((context instanceof IThymeleafEvaluationContext)) && 
/*  76 */       (((IThymeleafEvaluationContext)context).isVariableAccessRestricted()) && 
/*  77 */       ("param".equals(name))) {
/*  78 */       throw new AccessException("Access to variable \"" + name + "\" is forbidden in this context. Note some restrictions apply to variable access. For example, direct access to request parameters is forbidden in preprocessing and unescaped expressions, in TEXT template mode, in fragment insertion specifications and in some specific attribute processors.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  86 */     return target != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TypedValue read(EvaluationContext evaluationContext, Object target, String name)
/*     */     throws AccessException
/*     */   {
/*  94 */     if (target == null) {
/*  95 */       throw new AccessException("Cannot read property of null target");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 108 */       if ("execInfo".equals(name)) {
/* 109 */         Object execInfoResult = checkExecInfo(name, evaluationContext);
/* 110 */         if (execInfoResult != null) {
/* 111 */           return new TypedValue(execInfoResult);
/*     */         }
/*     */       }
/*     */       
/* 115 */       IContext context = (IContext)target;
/* 116 */       return new TypedValue(context.getVariable(name));
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (ClassCastException e)
/*     */     {
/*     */ 
/* 123 */       throw new AccessException("Cannot read target of class " + target.getClass().getName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   static Object checkExecInfo(String propertyName, EvaluationContext context)
/*     */   {
/* 146 */     if ("execInfo".equals(propertyName)) {
/* 147 */       if (!(context instanceof IThymeleafEvaluationContext))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */         throw new TemplateProcessingException("Found Thymeleaf Standard Expression containing a call to the context variable \"execInfo\" (e.g. \"${execInfo.templateName}\"), which has been deprecated. The Execution Info should be now accessed as an expression object instead (e.g. \"${#execInfo.templateName}\"). Deprecated use is still allowed (will be removed in future versions of Thymeleaf) when the SpringEL EvaluationContext implements the " + IThymeleafEvaluationContext.class + " interface, but the current evaluation context of class " + context.getClass().getName() + " DOES NOT implement such interface.");
/*     */       }
/* 157 */       LOGGER.warn("[THYMELEAF][{}] Found Thymeleaf Standard Expression containing a call to the context variable \"execInfo\" (e.g. \"${execInfo.templateName}\"), which has been deprecated. The Execution Info should be now accessed as an expression object instead (e.g. \"${#execInfo.templateName}\"). Deprecated use is still allowed, but will be removed in future versions of Thymeleaf.", 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 163 */         TemplateEngine.threadIndex());
/* 164 */       return ((IThymeleafEvaluationContext)context).getExpressionObjects().getObject("execInfo");
/*     */     }
/* 166 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean canWrite(EvaluationContext context, Object target, String name)
/*     */     throws AccessException
/*     */   {
/* 175 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(EvaluationContext context, Object target, String name, Object newValue)
/*     */     throws AccessException
/*     */   {
/* 184 */     throw new AccessException("Cannot write to " + IContext.class.getName());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\expression\SPELContextPropertyAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */