/*    */ package org.thymeleaf.spring5.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeDefinition;
/*    */ import org.thymeleaf.engine.AttributeDefinitions;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.spring5.requestdata.RequestDataValueProcessorUtils;
/*    */ import org.thymeleaf.standard.processor.AbstractStandardExpressionAttributeTagProcessor;
/*    */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.Validate;
/*    */ import org.unbescape.html.HtmlEscape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringSrcTagProcessor
/*    */   extends AbstractStandardExpressionAttributeTagProcessor
/*    */   implements IAttributeDefinitionsAware
/*    */ {
/*    */   public static final int ATTR_PRECEDENCE = 1000;
/*    */   public static final String ATTR_NAME = "src";
/* 52 */   private static final TemplateMode TEMPLATE_MODE = TemplateMode.HTML;
/*    */   
/*    */   private AttributeDefinition targetAttributeDefinition;
/*    */   
/*    */   public SpringSrcTagProcessor(String dialectPrefix)
/*    */   {
/* 58 */     super(TEMPLATE_MODE, dialectPrefix, "src", 1000, false, true);
/*    */   }
/*    */   
/*    */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions)
/*    */   {
/* 63 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*    */     
/*    */ 
/* 66 */     this.targetAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "src");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler)
/*    */   {
/* 78 */     String newAttributeValue = HtmlEscape.escapeHtml4Xml(expressionResult == null ? "" : expressionResult.toString());
/*    */     
/*    */ 
/* 81 */     newAttributeValue = RequestDataValueProcessorUtils.processUrl(context, newAttributeValue);
/*    */     
/*    */ 
/* 84 */     StandardProcessorUtils.replaceAttribute(structureHandler, attributeName, this.targetAttributeDefinition, "src", newAttributeValue == null ? "" : newAttributeValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringSrcTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */