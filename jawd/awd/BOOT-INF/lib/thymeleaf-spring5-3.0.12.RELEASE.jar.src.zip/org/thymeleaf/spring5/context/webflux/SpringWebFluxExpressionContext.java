/*    */ package org.thymeleaf.spring5.context.webflux;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.ReactiveAdapterRegistry;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.expression.ExpressionObjects;
/*    */ import org.thymeleaf.expression.IExpressionObjects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringWebFluxExpressionContext
/*    */   extends SpringWebFluxContext
/*    */   implements IExpressionContext
/*    */ {
/*    */   private final IEngineConfiguration configuration;
/* 49 */   private IExpressionObjects expressionObjects = null;
/*    */   
/*    */ 
/*    */   public SpringWebFluxExpressionContext(IEngineConfiguration configuration, ServerWebExchange exchange)
/*    */   {
/* 54 */     this(configuration, exchange, null, null, null);
/*    */   }
/*    */   
/*    */   public SpringWebFluxExpressionContext(IEngineConfiguration configuration, ServerWebExchange exchange, Locale locale)
/*    */   {
/* 59 */     this(configuration, exchange, null, locale, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public SpringWebFluxExpressionContext(IEngineConfiguration configuration, ServerWebExchange exchange, Locale locale, Map<String, Object> variables)
/*    */   {
/* 66 */     this(configuration, exchange, null, locale, variables);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public SpringWebFluxExpressionContext(IEngineConfiguration configuration, ServerWebExchange exchange, ReactiveAdapterRegistry reactiveAdapterRegistry, Locale locale, Map<String, Object> variables)
/*    */   {
/* 74 */     super(exchange, reactiveAdapterRegistry, locale, variables);
/* 75 */     this.configuration = configuration;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public IEngineConfiguration getConfiguration()
/*    */   {
/* 82 */     return this.configuration;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public IExpressionObjects getExpressionObjects()
/*    */   {
/* 89 */     if (this.expressionObjects == null) {
/* 90 */       this.expressionObjects = new ExpressionObjects(this, this.configuration.getExpressionObjectFactory());
/*    */     }
/* 92 */     return this.expressionObjects;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\webflux\SpringWebFluxExpressionContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */