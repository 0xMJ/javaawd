/*     */ package org.thymeleaf.spring5.processor;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeDefinition;
/*     */ import org.thymeleaf.engine.AttributeDefinitions;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.processor.element.MatchingAttributeName;
/*     */ import org.thymeleaf.spring5.requestdata.RequestDataValueProcessorUtils;
/*     */ import org.thymeleaf.standard.processor.AbstractStandardExpressionAttributeTagProcessor;
/*     */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import org.unbescape.html.HtmlEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringValueTagProcessor
/*     */   extends AbstractStandardExpressionAttributeTagProcessor
/*     */   implements IAttributeDefinitionsAware
/*     */ {
/*     */   public static final int ATTR_PRECEDENCE = 1010;
/*     */   public static final String TARGET_ATTR_NAME = "value";
/*  53 */   private static final TemplateMode TEMPLATE_MODE = TemplateMode.HTML;
/*     */   
/*     */   private static final String TYPE_ATTR_NAME = "type";
/*     */   
/*     */   private static final String NAME_ATTR_NAME = "name";
/*     */   
/*     */   private AttributeDefinition targetAttributeDefinition;
/*     */   
/*     */   private AttributeDefinition fieldAttributeDefinition;
/*     */   private AttributeDefinition typeAttributeDefinition;
/*     */   private AttributeDefinition nameAttributeDefinition;
/*     */   
/*     */   public SpringValueTagProcessor(String dialectPrefix)
/*     */   {
/*  67 */     super(TEMPLATE_MODE, dialectPrefix, "value", 1010, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions)
/*     */   {
/*  74 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*     */     
/*     */ 
/*  77 */     String dialectPrefix = getMatchingAttributeName().getMatchingAttributeName().getPrefix();
/*  78 */     this.targetAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "value");
/*  79 */     this.fieldAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, dialectPrefix, "field");
/*  80 */     this.typeAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "type");
/*  81 */     this.nameAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "name");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler)
/*     */   {
/*  95 */     String newAttributeValue = HtmlEscape.escapeHtml4Xml(expressionResult == null ? "" : expressionResult.toString());
/*     */     
/*     */ 
/*     */ 
/*  99 */     if (!tag.hasAttribute(this.fieldAttributeDefinition.getAttributeName()))
/*     */     {
/*     */ 
/* 102 */       String nameValue = tag.getAttributeValue(this.nameAttributeDefinition.getAttributeName());
/* 103 */       String typeValue = tag.getAttributeValue(this.typeAttributeDefinition.getAttributeName());
/*     */       
/*     */ 
/* 106 */       newAttributeValue = RequestDataValueProcessorUtils.processFormFieldValue(context, nameValue, newAttributeValue, typeValue);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 111 */     StandardProcessorUtils.replaceAttribute(structureHandler, attributeName, this.targetAttributeDefinition, "value", newAttributeValue == null ? "" : newAttributeValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringValueTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */