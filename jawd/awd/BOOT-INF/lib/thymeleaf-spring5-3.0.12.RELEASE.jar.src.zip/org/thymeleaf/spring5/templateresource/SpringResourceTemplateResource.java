/*     */ package org.thymeleaf.spring5.templateresource;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringResourceTemplateResource
/*     */   implements ITemplateResource
/*     */ {
/*     */   private final Resource resource;
/*     */   private final String characterEncoding;
/*     */   
/*     */   public SpringResourceTemplateResource(ApplicationContext applicationContext, String location, String characterEncoding)
/*     */   {
/*  64 */     Validate.notNull(applicationContext, "Application Context cannot be null");
/*  65 */     Validate.notEmpty(location, "Resource Location cannot be null or empty");
/*     */     
/*     */ 
/*  68 */     this.resource = applicationContext.getResource(location);
/*  69 */     this.characterEncoding = characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringResourceTemplateResource(Resource resource, String characterEncoding)
/*     */   {
/*  79 */     Validate.notNull(resource, "Resource cannot be null");
/*     */     
/*     */ 
/*  82 */     this.resource = resource;
/*  83 */     this.characterEncoding = characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  89 */     return this.resource.getDescription();
/*     */   }
/*     */   
/*     */   public String getBaseName() {
/*  93 */     return computeBaseName(this.resource.getFilename());
/*     */   }
/*     */   
/*     */   public boolean exists() {
/*  97 */     return this.resource.exists();
/*     */   }
/*     */   
/*     */   public Reader reader()
/*     */     throws IOException
/*     */   {
/* 103 */     InputStream inputStream = this.resource.getInputStream();
/*     */     
/* 105 */     if (!StringUtils.isEmptyOrWhitespace(this.characterEncoding)) {
/* 106 */       return new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream), this.characterEncoding));
/*     */     }
/*     */     
/* 109 */     return new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream)));
/*     */   }
/*     */   
/*     */   public ITemplateResource relative(String relativeLocation)
/*     */   {
/*     */     try
/*     */     {
/* 116 */       relativeResource = this.resource.createRelative(relativeLocation);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */       Resource relativeResource;
/* 121 */       return new SpringResourceInvalidRelativeTemplateResource(getDescription(), relativeLocation, e); }
/*     */     Resource relativeResource;
/* 123 */     return new SpringResourceTemplateResource(relativeResource, this.characterEncoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static String computeBaseName(String path)
/*     */   {
/* 130 */     if ((path == null) || (path.length() == 0)) {
/* 131 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 135 */     String basePath = path.charAt(path.length() - 1) == '/' ? path.substring(0, path.length() - 1) : path;
/*     */     
/* 137 */     int slashPos = basePath.lastIndexOf('/');
/* 138 */     if (slashPos != -1) {
/* 139 */       int dotPos = basePath.lastIndexOf('.');
/* 140 */       if ((dotPos != -1) && (dotPos > slashPos + 1)) {
/* 141 */         return basePath.substring(slashPos + 1, dotPos);
/*     */       }
/* 143 */       return basePath.substring(slashPos + 1);
/*     */     }
/* 145 */     int dotPos = basePath.lastIndexOf('.');
/* 146 */     if (dotPos != -1) {
/* 147 */       return basePath.substring(0, dotPos);
/*     */     }
/*     */     
/*     */ 
/* 151 */     return basePath.length() > 0 ? basePath : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class SpringResourceInvalidRelativeTemplateResource
/*     */     implements ITemplateResource
/*     */   {
/*     */     private final String originalResourceDescription;
/*     */     
/*     */ 
/*     */     private final String relativeLocation;
/*     */     
/*     */ 
/*     */     private final IOException ioException;
/*     */     
/*     */ 
/*     */     SpringResourceInvalidRelativeTemplateResource(String originalResourceDescription, String relativeLocation, IOException ioException)
/*     */     {
/* 170 */       this.originalResourceDescription = originalResourceDescription;
/* 171 */       this.relativeLocation = relativeLocation;
/* 172 */       this.ioException = ioException;
/*     */     }
/*     */     
/*     */ 
/*     */     public String getDescription()
/*     */     {
/* 178 */       return 
/* 179 */         "Invalid relative resource for relative location \"" + this.relativeLocation + "\" and original resource " + this.originalResourceDescription + ": " + this.ioException.getMessage();
/*     */     }
/*     */     
/*     */     public String getBaseName()
/*     */     {
/* 184 */       return 
/* 185 */         "Invalid relative resource for relative location \"" + this.relativeLocation + "\" and original resource " + this.originalResourceDescription + ": " + this.ioException.getMessage();
/*     */     }
/*     */     
/*     */     public boolean exists()
/*     */     {
/* 190 */       return false;
/*     */     }
/*     */     
/*     */     public Reader reader() throws IOException
/*     */     {
/* 195 */       throw new IOException("Invalid relative resource", this.ioException);
/*     */     }
/*     */     
/*     */     public ITemplateResource relative(String relativeLocation)
/*     */     {
/* 200 */       return this;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 205 */       return getDescription();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\templateresource\SpringResourceTemplateResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */