/*     */ package org.thymeleaf.spring5.view;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Field;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.WebExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.spring5.ISpringTemplateEngine;
/*     */ import org.thymeleaf.spring5.context.webmvc.SpringWebMvcThymeleafRequestContext;
/*     */ import org.thymeleaf.spring5.expression.ThymeleafEvaluationContext;
/*     */ import org.thymeleaf.spring5.util.SpringContentTypeUtils;
/*     */ import org.thymeleaf.spring5.util.SpringRequestUtils;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression.ExecutedFragmentExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThymeleafView
/*     */   extends AbstractThymeleafView
/*     */ {
/*     */   private static final String pathVariablesSelector;
/*  84 */   private Set<String> markupSelectors = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  95 */     String pathVariablesSelectorValue = null;
/*     */     try
/*     */     {
/*  98 */       Field pathVariablesField = View.class.getDeclaredField("PATH_VARIABLES");
/*  99 */       pathVariablesSelectorValue = (String)pathVariablesField.get(null);
/*     */     } catch (NoSuchFieldException ignored) {
/* 101 */       pathVariablesSelectorValue = null;
/*     */     } catch (IllegalAccessException ignored) {
/* 103 */       pathVariablesSelectorValue = null;
/*     */     }
/* 105 */     pathVariablesSelector = pathVariablesSelectorValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ThymeleafView(String templateName)
/*     */   {
/* 130 */     super(templateName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMarkupSelector()
/*     */   {
/* 155 */     return (this.markupSelectors == null) || (this.markupSelectors.size() == 0) ? null : (String)this.markupSelectors.iterator().next();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMarkupSelector(String markupSelector)
/*     */   {
/* 179 */     this.markupSelectors = ((markupSelector == null) || (markupSelector.trim().length() == 0) ? null : Collections.singleton(markupSelector.trim()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void render(Map<String, ?> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 190 */     renderFragment(this.markupSelectors, model, request, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void renderFragment(Set<String> markupSelectorsToRender, Map<String, ?> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 199 */     ServletContext servletContext = getServletContext();
/* 200 */     String viewTemplateName = getTemplateName();
/* 201 */     ISpringTemplateEngine viewTemplateEngine = getTemplateEngine();
/*     */     
/* 203 */     if (viewTemplateName == null) {
/* 204 */       throw new IllegalArgumentException("Property 'templateName' is required");
/*     */     }
/* 206 */     if (getLocale() == null) {
/* 207 */       throw new IllegalArgumentException("Property 'locale' is required");
/*     */     }
/* 209 */     if (viewTemplateEngine == null) {
/* 210 */       throw new IllegalArgumentException("Property 'templateEngine' is required");
/*     */     }
/*     */     
/* 213 */     Map<String, Object> mergedModel = new HashMap(30);
/* 214 */     Map<String, Object> templateStaticVariables = getStaticVariables();
/* 215 */     if (templateStaticVariables != null) {
/* 216 */       mergedModel.putAll(templateStaticVariables);
/*     */     }
/* 218 */     if (pathVariablesSelector != null)
/*     */     {
/* 220 */       Map<String, Object> pathVars = (Map)request.getAttribute(pathVariablesSelector);
/* 221 */       if (pathVars != null) {
/* 222 */         mergedModel.putAll(pathVars);
/*     */       }
/*     */     }
/* 225 */     if (model != null) {
/* 226 */       mergedModel.putAll(model);
/*     */     }
/*     */     
/* 229 */     ApplicationContext applicationContext = getApplicationContext();
/*     */     
/*     */ 
/* 232 */     RequestContext requestContext = new RequestContext(request, response, getServletContext(), mergedModel);
/* 233 */     SpringWebMvcThymeleafRequestContext thymeleafRequestContext = new SpringWebMvcThymeleafRequestContext(requestContext, request);
/*     */     
/*     */ 
/*     */ 
/* 237 */     addRequestContextAsVariable(mergedModel, "springRequestContext", requestContext);
/*     */     
/* 239 */     addRequestContextAsVariable(mergedModel, "springMacroRequestContext", requestContext);
/*     */     
/*     */ 
/* 242 */     mergedModel.put("thymeleafRequestContext", thymeleafRequestContext);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 251 */     ConversionService conversionService = (ConversionService)request.getAttribute(ConversionService.class.getName());
/* 252 */     ThymeleafEvaluationContext evaluationContext = new ThymeleafEvaluationContext(applicationContext, conversionService);
/*     */     
/* 254 */     mergedModel.put("thymeleaf::EvaluationContext", evaluationContext);
/*     */     
/*     */ 
/* 257 */     IEngineConfiguration configuration = viewTemplateEngine.getConfiguration();
/*     */     
/* 259 */     WebExpressionContext context = new WebExpressionContext(configuration, request, response, servletContext, getLocale(), mergedModel);
/*     */     
/*     */     Set<String> markupSelectors;
/*     */     String templateName;
/*     */     Set<String> markupSelectors;
/* 264 */     if (!viewTemplateName.contains("::"))
/*     */     {
/*     */ 
/* 267 */       String templateName = viewTemplateName;
/* 268 */       markupSelectors = null;
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 275 */       SpringRequestUtils.checkViewNameNotInRequest(viewTemplateName, request);
/*     */       
/* 277 */       IStandardExpressionParser parser = StandardExpressions.getExpressionParser(configuration);
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 282 */         fragmentExpression = (FragmentExpression)parser.parseExpression(context, "~{" + viewTemplateName + "}");
/*     */       } catch (TemplateProcessingException e) { FragmentExpression fragmentExpression;
/* 284 */         throw new IllegalArgumentException("Invalid template name specification: '" + viewTemplateName + "'");
/*     */       }
/*     */       
/*     */       FragmentExpression fragmentExpression;
/* 288 */       FragmentExpression.ExecutedFragmentExpression fragment = FragmentExpression.createExecutedFragmentExpression(context, fragmentExpression);
/*     */       
/* 290 */       templateName = FragmentExpression.resolveTemplateName(fragment);
/* 291 */       markupSelectors = FragmentExpression.resolveFragments(fragment);
/* 292 */       Map<String, Object> nameFragmentParameters = fragment.getFragmentParameters();
/*     */       
/* 294 */       if (nameFragmentParameters != null)
/*     */       {
/* 296 */         if (fragment.hasSyntheticParameters())
/*     */         {
/*     */ 
/* 299 */           throw new IllegalArgumentException("Parameters in a view specification must be named (non-synthetic): '" + viewTemplateName + "'");
/*     */         }
/*     */         
/*     */ 
/* 303 */         context.setVariables(nameFragmentParameters);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 311 */     String templateContentType = getContentType();
/* 312 */     Locale templateLocale = getLocale();
/* 313 */     String templateCharacterEncoding = getCharacterEncoding();
/*     */     
/*     */     Set<String> processMarkupSelectors;
/*     */     Set<String> processMarkupSelectors;
/* 317 */     if ((markupSelectors != null) && (markupSelectors.size() > 0)) {
/* 318 */       if ((markupSelectorsToRender != null) && (markupSelectorsToRender.size() > 0))
/*     */       {
/*     */ 
/* 321 */         throw new IllegalArgumentException("A markup selector has been specified (" + Arrays.asList(new Set[] { markupSelectors }) + ") for a view that was already being executed as a fragment (" + Arrays.asList(new Set[] { markupSelectorsToRender }) + "). Only one fragment selection is allowed.");
/*     */       }
/*     */       
/* 324 */       processMarkupSelectors = markupSelectors;
/*     */     } else { Set<String> processMarkupSelectors;
/* 326 */       if ((markupSelectorsToRender != null) && (markupSelectorsToRender.size() > 0)) {
/* 327 */         processMarkupSelectors = markupSelectorsToRender;
/*     */       } else {
/* 329 */         processMarkupSelectors = null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 334 */     response.setLocale(templateLocale);
/*     */     
/* 336 */     if (!getForceContentType())
/*     */     {
/*     */ 
/* 339 */       String computedContentType = SpringContentTypeUtils.computeViewContentType(request, 
/*     */       
/* 341 */         templateContentType != null ? templateContentType : "text/html;charset=ISO-8859-1", 
/* 342 */         templateCharacterEncoding != null ? Charset.forName(templateCharacterEncoding) : null);
/*     */       
/* 344 */       response.setContentType(computedContentType);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 349 */       if (templateContentType != null) {
/* 350 */         response.setContentType(templateContentType);
/*     */       } else {
/* 352 */         response.setContentType("text/html;charset=ISO-8859-1");
/*     */       }
/* 354 */       if (templateCharacterEncoding != null) {
/* 355 */         response.setCharacterEncoding(templateCharacterEncoding);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 360 */     boolean producePartialOutputWhileProcessing = getProducePartialOutputWhileProcessing();
/*     */     
/*     */ 
/*     */ 
/* 364 */     Writer templateWriter = producePartialOutputWhileProcessing ? response.getWriter() : new FastStringWriter(1024);
/*     */     
/* 366 */     viewTemplateEngine.process(templateName, processMarkupSelectors, context, templateWriter);
/*     */     
/*     */ 
/* 369 */     if (!producePartialOutputWhileProcessing) {
/* 370 */       response.getWriter().write(templateWriter.toString());
/* 371 */       response.getWriter().flush();
/*     */     }
/*     */   }
/*     */   
/*     */   public ThymeleafView() {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\view\ThymeleafView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */