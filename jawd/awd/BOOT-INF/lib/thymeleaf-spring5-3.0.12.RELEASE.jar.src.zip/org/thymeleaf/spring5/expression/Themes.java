/*    */ package org.thymeleaf.spring5.expression;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.ui.context.Theme;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.spring5.context.IThymeleafRequestContext;
/*    */ import org.thymeleaf.spring5.context.SpringContextUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Themes
/*    */ {
/*    */   private final Theme theme;
/*    */   private final Locale locale;
/*    */   
/*    */   public Themes(IExpressionContext context)
/*    */   {
/* 53 */     this.locale = context.getLocale();
/* 54 */     IThymeleafRequestContext requestContext = SpringContextUtils.getRequestContext(context);
/* 55 */     this.theme = (requestContext != null ? requestContext.getTheme() : null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String code(String code)
/*    */   {
/* 67 */     if (this.theme == null) {
/* 68 */       throw new TemplateProcessingException("Theme cannot be resolved because RequestContext was not found. Are you using a Context object without a RequestContext variable?");
/*    */     }
/*    */     
/* 71 */     return this.theme.getMessageSource().getMessage(code, null, "", this.locale);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\expression\Themes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */