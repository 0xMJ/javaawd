/*     */ package org.thymeleaf.spring5.view;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletException;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.thymeleaf.spring5.ISpringTemplateEngine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractThymeleafView
/*     */   extends WebApplicationObjectSupport
/*     */   implements View, BeanNameAware
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "text/html;charset=ISO-8859-1";
/*     */   public static final boolean DEFAULT_PRODUCE_PARTIAL_OUTPUT_WHILE_PROCESSING = true;
/*  76 */   private String beanName = null;
/*  77 */   private String contentType = "text/html;charset=ISO-8859-1";
/*  78 */   private boolean contentTypeSet = false;
/*  79 */   private boolean forceContentType = false;
/*  80 */   private boolean forceContentTypeSet = false;
/*  81 */   private String characterEncoding = null;
/*  82 */   private boolean producePartialOutputWhileProcessing = true;
/*  83 */   private boolean producePartialOutputWhileProcessingSet = false;
/*  84 */   private ISpringTemplateEngine templateEngine = null;
/*  85 */   private String templateName = null;
/*  86 */   private Locale locale = null;
/*  87 */   private Map<String, Object> staticVariables = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractThymeleafView() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractThymeleafView(String templateName)
/*     */   {
/* 110 */     this.templateName = templateName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 138 */     return this.contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentType(String contentType)
/*     */   {
/* 162 */     this.contentType = contentType;
/* 163 */     this.contentTypeSet = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isContentTypeSet()
/*     */   {
/* 172 */     return this.contentTypeSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getForceContentType()
/*     */   {
/* 195 */     return this.forceContentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setForceContentType(boolean forceContentType)
/*     */   {
/* 217 */     this.forceContentType = forceContentType;
/* 218 */     this.forceContentTypeSet = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isForceContentTypeSet()
/*     */   {
/* 228 */     return this.forceContentTypeSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCharacterEncoding()
/*     */   {
/* 248 */     return this.characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharacterEncoding(String characterEncoding)
/*     */   {
/* 269 */     this.characterEncoding = characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getProducePartialOutputWhileProcessing()
/*     */   {
/* 302 */     return this.producePartialOutputWhileProcessing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProducePartialOutputWhileProcessing(boolean producePartialOutputWhileProcessing)
/*     */   {
/* 336 */     this.producePartialOutputWhileProcessing = producePartialOutputWhileProcessing;
/* 337 */     this.producePartialOutputWhileProcessingSet = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isProducePartialOutputWhileProcessingSet()
/*     */   {
/* 347 */     return this.producePartialOutputWhileProcessingSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBeanName()
/*     */   {
/* 361 */     return this.beanName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeanName(String beanName)
/*     */   {
/* 373 */     this.beanName = beanName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTemplateName()
/*     */   {
/* 391 */     return this.templateName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTemplateName(String templateName)
/*     */   {
/* 408 */     this.templateName = templateName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Locale getLocale()
/*     */   {
/* 421 */     return this.locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setLocale(Locale locale)
/*     */   {
/* 435 */     this.locale = locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ISpringTemplateEngine getTemplateEngine()
/*     */   {
/* 450 */     return this.templateEngine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setTemplateEngine(ISpringTemplateEngine templateEngine)
/*     */   {
/* 463 */     this.templateEngine = templateEngine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getStaticVariables()
/*     */   {
/* 483 */     if (this.staticVariables == null) {
/* 484 */       return Collections.emptyMap();
/*     */     }
/* 486 */     return Collections.unmodifiableMap(this.staticVariables);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addStaticVariable(String name, Object value)
/*     */   {
/* 505 */     if (this.staticVariables == null) {
/* 506 */       this.staticVariables = new HashMap(3, 1.0F);
/*     */     }
/* 508 */     this.staticVariables.put(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStaticVariables(Map<String, ?> variables)
/*     */   {
/* 532 */     if (variables != null) {
/* 533 */       if (this.staticVariables == null) {
/* 534 */         this.staticVariables = new HashMap(3, 1.0F);
/*     */       }
/* 536 */       this.staticVariables.putAll(variables);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void addRequestContextAsVariable(Map<String, Object> model, String variableName, RequestContext requestContext)
/*     */     throws ServletException
/*     */   {
/* 551 */     if (model.containsKey(variableName)) {
/* 552 */       throw new ServletException("Cannot expose request context in model attribute '" + variableName + "' because an existing model object of the same name");
/*     */     }
/*     */     
/*     */ 
/* 556 */     model.put(variableName, requestContext);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\view\AbstractThymeleafView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */