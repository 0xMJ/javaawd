/*    */ package org.thymeleaf.spring5.templateresolver;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.spring5.templateresource.SpringResourceTemplateResource;
/*    */ import org.thymeleaf.templateresolver.AbstractConfigurableTemplateResolver;
/*    */ import org.thymeleaf.templateresource.ITemplateResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringResourceTemplateResolver
/*    */   extends AbstractConfigurableTemplateResolver
/*    */   implements ApplicationContextAware
/*    */ {
/* 50 */   private ApplicationContext applicationContext = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setApplicationContext(ApplicationContext applicationContext)
/*    */     throws BeansException
/*    */   {
/* 61 */     this.applicationContext = applicationContext;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected ITemplateResource computeTemplateResource(IEngineConfiguration configuration, String ownerTemplate, String template, String resourceName, String characterEncoding, Map<String, Object> templateResolutionAttributes)
/*    */   {
/* 69 */     return new SpringResourceTemplateResource(this.applicationContext, resourceName, characterEncoding);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\templateresolver\SpringResourceTemplateResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */