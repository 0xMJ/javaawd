/*    */ package org.thymeleaf.spring5.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*    */ import org.thymeleaf.spring5.util.FieldUtils;
/*    */ import org.thymeleaf.spring5.util.SpringValueFormatter;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringUErrorsTagProcessor
/*    */   extends AbstractAttributeTagProcessor
/*    */ {
/*    */   private static final String ERROR_DELIMITER = "<br />";
/*    */   public static final int ATTR_PRECEDENCE = 1700;
/*    */   public static final String ATTR_NAME = "uerrors";
/*    */   
/*    */   public SpringUErrorsTagProcessor(String dialectPrefix)
/*    */   {
/* 52 */     super(TemplateMode.HTML, dialectPrefix, null, false, "uerrors", true, 1700, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*    */   {
/* 64 */     IThymeleafBindStatus bindStatus = FieldUtils.getBindStatus(context, attributeValue);
/*    */     
/* 66 */     if (bindStatus.isError())
/*    */     {
/* 68 */       StringBuilder strBuilder = new StringBuilder();
/* 69 */       String[] errorMsgs = bindStatus.getErrorMessages();
/*    */       
/* 71 */       for (int i = 0; i < errorMsgs.length; i++) {
/* 72 */         if (i > 0) {
/* 73 */           strBuilder.append("<br />");
/*    */         }
/* 75 */         String displayString = SpringValueFormatter.getDisplayString(errorMsgs[i], false);
/* 76 */         strBuilder.append(displayString);
/*    */       }
/*    */       
/* 79 */       structureHandler.setBody(strBuilder.toString(), false);
/*    */       
/*    */ 
/* 82 */       structureHandler.setLocalVariable("thymeleafFieldBindStatus", bindStatus);
/*    */     }
/*    */     else
/*    */     {
/* 86 */       structureHandler.removeElement();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringUErrorsTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */