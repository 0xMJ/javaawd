package org.thymeleaf.spring5.webflow.view;

import org.springframework.web.servlet.View;
import org.springframework.webflow.context.servlet.AjaxHandler;

public abstract interface AjaxEnabledView
  extends View
{
  public abstract AjaxHandler getAjaxHandler();
  
  public abstract void setAjaxHandler(AjaxHandler paramAjaxHandler);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\webflow\view\AjaxEnabledView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */