/*    */ package org.thymeleaf.spring5.expression;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.spring5.requestdata.RequestDataValueProcessorUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestDataValues
/*    */ {
/*    */   private ITemplateContext context;
/*    */   
/*    */   public RequestDataValues(ITemplateContext context)
/*    */   {
/* 69 */     this.context = context;
/*    */   }
/*    */   
/*    */ 
/*    */   public String action(String action, String httpMethod)
/*    */   {
/* 75 */     return RequestDataValueProcessorUtils.processAction(this.context, action, httpMethod);
/*    */   }
/*    */   
/*    */   public String url(String url)
/*    */   {
/* 80 */     return RequestDataValueProcessorUtils.processUrl(this.context, url);
/*    */   }
/*    */   
/*    */   public String formFieldValue(String name, String value, String type)
/*    */   {
/* 85 */     return RequestDataValueProcessorUtils.processFormFieldValue(this.context, name, value, type);
/*    */   }
/*    */   
/*    */   public Map<String, String> extraHiddenFields()
/*    */   {
/* 90 */     return RequestDataValueProcessorUtils.getExtraHiddenFields(this.context);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\expression\RequestDataValues.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */