/*     */ package org.thymeleaf.spring5.context.webflux;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.EngineContext;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.context.IEngineContextFactory;
/*     */ import org.thymeleaf.engine.TemplateData;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringWebFluxEngineContextFactory
/*     */   implements IEngineContextFactory
/*     */ {
/*     */   public IEngineContext createEngineContext(IEngineConfiguration configuration, TemplateData templateData, Map<String, Object> templateResolutionAttributes, IContext context)
/*     */   {
/*  71 */     Validate.notNull(context, "Context object cannot be null");
/*     */     
/*  73 */     Set<String> variableNames = context.getVariableNames();
/*     */     
/*  75 */     if ((variableNames == null) || (variableNames.isEmpty())) {
/*  76 */       if ((context instanceof ISpringWebFluxContext)) {
/*  77 */         ISpringWebFluxContext srContext = (ISpringWebFluxContext)context;
/*  78 */         return new SpringWebFluxEngineContext(configuration, templateData, templateResolutionAttributes, srContext
/*     */         
/*  80 */           .getExchange(), srContext.getLocale(), Collections.EMPTY_MAP);
/*     */       }
/*  82 */       return new EngineContext(configuration, templateData, templateResolutionAttributes, context
/*     */       
/*  84 */         .getLocale(), Collections.EMPTY_MAP);
/*     */     }
/*     */     
/*  87 */     Map<String, Object> variables = new LinkedHashMap(variableNames.size() + 1, 1.0F);
/*  88 */     for (String variableName : variableNames) {
/*  89 */       variables.put(variableName, context.getVariable(variableName));
/*     */     }
/*  91 */     if ((context instanceof ISpringWebFluxContext)) {
/*  92 */       ISpringWebFluxContext srContext = (ISpringWebFluxContext)context;
/*  93 */       return new SpringWebFluxEngineContext(configuration, templateData, templateResolutionAttributes, srContext
/*     */       
/*  95 */         .getExchange(), srContext.getLocale(), variables);
/*     */     }
/*     */     
/*  98 */     return new EngineContext(configuration, templateData, templateResolutionAttributes, context
/*     */     
/* 100 */       .getLocale(), variables);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\webflux\SpringWebFluxEngineContextFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */