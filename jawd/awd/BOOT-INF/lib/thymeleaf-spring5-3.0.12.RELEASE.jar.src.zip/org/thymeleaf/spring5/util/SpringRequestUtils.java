/*    */ package org.thymeleaf.spring5.util;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.util.StringUtils;
/*    */ import org.unbescape.uri.UriEscape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringRequestUtils
/*    */ {
/*    */   public static void checkViewNameNotInRequest(String viewName, HttpServletRequest request)
/*    */   {
/* 43 */     String vn = StringUtils.pack(viewName);
/*    */     
/* 45 */     String requestURI = StringUtils.pack(UriEscape.unescapeUriPath(request.getRequestURI()));
/*    */     
/* 47 */     boolean found = (requestURI != null) && (requestURI.contains(vn));
/* 48 */     if (!found) {
/* 49 */       Enumeration<String> paramNames = request.getParameterNames();
/* 52 */       for (; 
/*    */           
/* 52 */           (!found) && (paramNames.hasMoreElements()); 
/*    */           
/* 54 */           goto 86)
/*    */       {
/* 53 */         String[] paramValues = request.getParameterValues((String)paramNames.nextElement());
/* 54 */         int i = 0; if ((!found) && (i < paramValues.length)) {
/* 55 */           String paramValue = StringUtils.pack(UriEscape.unescapeUriQueryParam(paramValues[i]));
/* 56 */           if (paramValue.contains(vn)) {
/* 57 */             found = true;
/*    */           }
/* 54 */           i++;
/*    */         }
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 63 */     if (found) {
/* 64 */       throw new TemplateProcessingException("View name is an executable expression, and it is present in a literal manner in request path or parameters, which is forbidden for security reasons.");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\util\SpringRequestUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */