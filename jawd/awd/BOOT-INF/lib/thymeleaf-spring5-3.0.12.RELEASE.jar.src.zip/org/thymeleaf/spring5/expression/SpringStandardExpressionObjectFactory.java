/*     */ package org.thymeleaf.spring5.expression;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionObjectFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringStandardExpressionObjectFactory
/*     */   extends StandardExpressionObjectFactory
/*     */ {
/*     */   public static final String FIELDS_EXPRESSION_OBJECT_NAME = "fields";
/*     */   public static final String THEMES_EXPRESSION_OBJECT_NAME = "themes";
/*     */   public static final String MVC_EXPRESSION_OBJECT_NAME = "mvc";
/*     */   public static final String REQUESTDATAVALUES_EXPRESSION_OBJECT_NAME = "requestdatavalues";
/*     */   public static final Set<String> ALL_EXPRESSION_OBJECT_NAMES;
/*  53 */   private static final Mvc MVC_EXPRESSION_OBJECT = new Mvc();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  60 */     Set<String> allExpressionObjectNames = new LinkedHashSet();
/*  61 */     allExpressionObjectNames.addAll(StandardExpressionObjectFactory.ALL_EXPRESSION_OBJECT_NAMES);
/*  62 */     allExpressionObjectNames.add("fields");
/*  63 */     allExpressionObjectNames.add("themes");
/*  64 */     allExpressionObjectNames.add("mvc");
/*  65 */     allExpressionObjectNames.add("requestdatavalues");
/*     */     
/*  67 */     ALL_EXPRESSION_OBJECT_NAMES = Collections.unmodifiableSet(allExpressionObjectNames);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> getAllExpressionObjectNames()
/*     */   {
/*  83 */     return ALL_EXPRESSION_OBJECT_NAMES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object buildObject(IExpressionContext context, String expressionObjectName)
/*     */   {
/*  91 */     if ("mvc".equals(expressionObjectName)) {
/*  92 */       return MVC_EXPRESSION_OBJECT;
/*     */     }
/*  94 */     if ("themes".equals(expressionObjectName)) {
/*  95 */       return new Themes(context);
/*     */     }
/*  97 */     if ("fields".equals(expressionObjectName)) {
/*  98 */       return new Fields(context);
/*     */     }
/* 100 */     if ("requestdatavalues".equals(expressionObjectName)) {
/* 101 */       if ((context instanceof ITemplateContext)) {
/* 102 */         return new RequestDataValues((ITemplateContext)context);
/*     */       }
/* 104 */       return null;
/*     */     }
/*     */     
/* 107 */     return super.buildObject(context, expressionObjectName);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\expression\SpringStandardExpressionObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */