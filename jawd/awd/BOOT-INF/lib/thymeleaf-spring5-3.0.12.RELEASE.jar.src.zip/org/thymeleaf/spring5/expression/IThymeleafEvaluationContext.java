package org.thymeleaf.spring5.expression;

import org.springframework.expression.EvaluationContext;
import org.thymeleaf.expression.IExpressionObjects;

public abstract interface IThymeleafEvaluationContext
  extends EvaluationContext
{
  public abstract boolean isVariableAccessRestricted();
  
  public abstract void setVariableAccessRestricted(boolean paramBoolean);
  
  public abstract IExpressionObjects getExpressionObjects();
  
  public abstract void setExpressionObjects(IExpressionObjects paramIExpressionObjects);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\expression\IThymeleafEvaluationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */