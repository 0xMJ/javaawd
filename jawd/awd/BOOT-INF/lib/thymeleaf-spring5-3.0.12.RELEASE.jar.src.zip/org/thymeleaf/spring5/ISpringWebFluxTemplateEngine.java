package org.thymeleaf.spring5;

import java.nio.charset.Charset;
import java.util.Set;
import org.reactivestreams.Publisher;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import org.springframework.http.MediaType;
import org.thymeleaf.context.IContext;

public abstract interface ISpringWebFluxTemplateEngine
  extends ISpringTemplateEngine
{
  public abstract Publisher<DataBuffer> processStream(String paramString, Set<String> paramSet, IContext paramIContext, DataBufferFactory paramDataBufferFactory, MediaType paramMediaType, Charset paramCharset);
  
  public abstract Publisher<DataBuffer> processStream(String paramString, Set<String> paramSet, IContext paramIContext, DataBufferFactory paramDataBufferFactory, MediaType paramMediaType, Charset paramCharset, int paramInt);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\ISpringWebFluxTemplateEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */