/*    */ package org.thymeleaf.spring5.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractElementTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringOptionInSelectFieldTagProcessor
/*    */   extends AbstractElementTagProcessor
/*    */ {
/*    */   public static final int ATTR_PRECEDENCE = 1005;
/*    */   public static final String OPTION_TAG_NAME = "option";
/*    */   
/*    */   public SpringOptionInSelectFieldTagProcessor(String dialectPrefix)
/*    */   {
/* 48 */     super(TemplateMode.HTML, dialectPrefix, "option", false, null, false, 1005);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, IElementTagStructureHandler structureHandler)
/*    */   {
/* 61 */     AttributeName selectAttrNameToAdd = (AttributeName)context.getVariable("%%OPTION_IN_SELECT_ATTR_NAME%%");
/* 62 */     if (selectAttrNameToAdd == null)
/*    */     {
/* 64 */       return;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 71 */     String selectAttrValueToAdd = (String)context.getVariable("%%OPTION_IN_SELECT_ATTR_VALUE%%");
/*    */     
/* 73 */     if ((tag.hasAttribute(selectAttrNameToAdd)) && 
/* 74 */       (!selectAttrValueToAdd.equals(tag.getAttributeValue(selectAttrNameToAdd)))) {
/* 75 */       throw new TemplateProcessingException("If specified (which is not required), attribute \"" + selectAttrNameToAdd + "\" in \"option\" tag must have exactly the same value as in its containing \"select\" tag");
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 84 */     structureHandler.setAttribute(selectAttrNameToAdd.getCompleteAttributeNames()[0], selectAttrValueToAdd);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringOptionInSelectFieldTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */