/*     */ package org.thymeleaf.spring5.expression;
/*     */ 
/*     */ import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder.MethodArgumentBuilder;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ import org.thymeleaf.spring5.util.SpringVersionUtils;
/*     */ import org.thymeleaf.util.ClassLoaderUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mvc
/*     */ {
/*     */   private static final MvcUriComponentsBuilderDelegate mvcUriComponentsBuilderDelegate;
/*  44 */   private static final String SPRING41_MVC_URI_COMPONENTS_BUILDER_DELEGATE_CLASS_NAME = Mvc.class.getName() + "$Spring41MvcUriComponentsBuilderDelegate";
/*  45 */   private static final String NON_SPRING41_MVC_URI_COMPONENTS_BUILDER_DELEGATE_CLASS_NAME = Mvc.class.getName() + "$NonSpring41MvcUriComponentsBuilderDelegate";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  53 */     String delegateClassName = SpringVersionUtils.isSpring41AtLeast() ? SPRING41_MVC_URI_COMPONENTS_BUILDER_DELEGATE_CLASS_NAME : NON_SPRING41_MVC_URI_COMPONENTS_BUILDER_DELEGATE_CLASS_NAME;
/*     */     try
/*     */     {
/*  56 */       Class<?> implClass = ClassLoaderUtils.loadClass(delegateClassName);
/*  57 */       mvcUriComponentsBuilderDelegate = (MvcUriComponentsBuilderDelegate)implClass.newInstance();
/*     */     } catch (Exception e) {
/*  59 */       throw new ExceptionInInitializerError(new ConfigurationException("Thymeleaf could not initialize a delegate of class \"" + delegateClassName + "\" for taking care of the " + "mvc" + " expression utility object", e));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodArgumentBuilderWrapper url(String mappingName)
/*     */   {
/*  69 */     return mvcUriComponentsBuilderDelegate.fromMappingName(mappingName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static abstract interface MvcUriComponentsBuilderDelegate
/*     */   {
/*     */     public abstract Mvc.MethodArgumentBuilderWrapper fromMappingName(String paramString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static class Spring41MvcUriComponentsBuilderDelegate
/*     */     implements Mvc.MvcUriComponentsBuilderDelegate
/*     */   {
/*     */     public Mvc.MethodArgumentBuilderWrapper fromMappingName(String mappingName)
/*     */     {
/*  88 */       return new Mvc.Spring41MethodArgumentBuilderWrapper(MvcUriComponentsBuilder.fromMappingName(mappingName), null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class NonSpring41MvcUriComponentsBuilderDelegate
/*     */     implements Mvc.MvcUriComponentsBuilderDelegate
/*     */   {
/*     */     public Mvc.MethodArgumentBuilderWrapper fromMappingName(String mappingName)
/*     */     {
/* 101 */       throw new UnsupportedOperationException("MVC URI component building is only supported in Spring versions 4.1 or newer");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static abstract interface MethodArgumentBuilderWrapper
/*     */   {
/*     */     public abstract MethodArgumentBuilderWrapper arg(int paramInt, Object paramObject);
/*     */     
/*     */ 
/*     */     public abstract MethodArgumentBuilderWrapper encode();
/*     */     
/*     */ 
/*     */     public abstract String build();
/*     */     
/*     */ 
/*     */     public abstract String buildAndExpand(Object... paramVarArgs);
/*     */   }
/*     */   
/*     */   static class Spring41MethodArgumentBuilderWrapper
/*     */     implements Mvc.MethodArgumentBuilderWrapper
/*     */   {
/*     */     private final MvcUriComponentsBuilder.MethodArgumentBuilder builder;
/*     */     
/*     */     private Spring41MethodArgumentBuilderWrapper(MvcUriComponentsBuilder.MethodArgumentBuilder builder)
/*     */     {
/* 127 */       this.builder = builder;
/*     */     }
/*     */     
/*     */     public Mvc.MethodArgumentBuilderWrapper arg(int index, Object value) {
/* 131 */       return new Spring41MethodArgumentBuilderWrapper(this.builder.arg(index, value));
/*     */     }
/*     */     
/*     */     public Mvc.MethodArgumentBuilderWrapper encode() {
/* 135 */       if (!SpringVersionUtils.isSpringAtLeast(5, 0, 8)) {
/* 136 */         throw new IllegalStateException(String.format("At least Spring version 5.0.8.RELEASE is needed for executing MvcUriComponentsBuilder#encode() but detected Spring version is %s.", new Object[] {
/*     */         
/*     */ 
/* 139 */           SpringVersionUtils.getSpringVersion() }));
/*     */       }
/* 141 */       return new Spring41MethodArgumentBuilderWrapper(this.builder.encode());
/*     */     }
/*     */     
/*     */     public String build() {
/* 145 */       return this.builder.build();
/*     */     }
/*     */     
/*     */     public String buildAndExpand(Object... uriVariables) {
/* 149 */       return this.builder.buildAndExpand(uriVariables);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\expression\Mvc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */