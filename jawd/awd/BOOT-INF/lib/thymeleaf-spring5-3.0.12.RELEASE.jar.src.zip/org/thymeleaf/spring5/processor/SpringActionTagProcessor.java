/*     */ package org.thymeleaf.spring5.processor;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeDefinition;
/*     */ import org.thymeleaf.engine.AttributeDefinitions;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.model.IModelFactory;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.spring5.requestdata.RequestDataValueProcessorUtils;
/*     */ import org.thymeleaf.standard.processor.AbstractStandardExpressionAttributeTagProcessor;
/*     */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import org.unbescape.html.HtmlEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringActionTagProcessor
/*     */   extends AbstractStandardExpressionAttributeTagProcessor
/*     */   implements IAttributeDefinitionsAware
/*     */ {
/*     */   public static final int ATTR_PRECEDENCE = 1000;
/*     */   public static final String TARGET_ATTR_NAME = "action";
/*  59 */   private static final TemplateMode TEMPLATE_MODE = TemplateMode.HTML;
/*     */   
/*     */   private static final String METHOD_ATTR_NAME = "method";
/*     */   
/*     */   private static final String TYPE_ATTR_NAME = "type";
/*     */   
/*     */   private static final String NAME_ATTR_NAME = "name";
/*     */   
/*     */   private static final String VALUE_ATTR_NAME = "value";
/*     */   
/*     */   private static final String METHOD_ATTR_DEFAULT_VALUE = "GET";
/*     */   private AttributeDefinition targetAttributeDefinition;
/*     */   private AttributeDefinition methodAttributeDefinition;
/*     */   
/*     */   public SpringActionTagProcessor(String dialectPrefix)
/*     */   {
/*  75 */     super(TEMPLATE_MODE, dialectPrefix, "action", 1000, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions)
/*     */   {
/*  82 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*     */     
/*     */ 
/*  85 */     this.targetAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "action");
/*  86 */     this.methodAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "method");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler)
/*     */   {
/* 100 */     String newAttributeValue = HtmlEscape.escapeHtml4Xml(expressionResult == null ? "" : expressionResult.toString());
/*     */     
/*     */ 
/*     */ 
/* 104 */     String methodAttributeValue = tag.getAttributeValue(this.methodAttributeDefinition.getAttributeName());
/* 105 */     String httpMethod = methodAttributeValue == null ? "GET" : methodAttributeValue;
/*     */     
/*     */ 
/* 108 */     newAttributeValue = RequestDataValueProcessorUtils.processAction(context, newAttributeValue, httpMethod);
/*     */     
/*     */ 
/* 111 */     StandardProcessorUtils.replaceAttribute(structureHandler, attributeName, this.targetAttributeDefinition, "action", 
/* 112 */       newAttributeValue == null ? "" : newAttributeValue);
/*     */     
/*     */ 
/* 115 */     if ("form".equalsIgnoreCase(tag.getElementCompleteName()))
/*     */     {
/*     */ 
/* 118 */       Map<String, String> extraHiddenFields = RequestDataValueProcessorUtils.getExtraHiddenFields(context);
/*     */       
/* 120 */       if ((extraHiddenFields != null) && (extraHiddenFields.size() > 0))
/*     */       {
/* 122 */         IModelFactory modelFactory = context.getModelFactory();
/*     */         
/* 124 */         IModel extraHiddenElementTags = modelFactory.createModel();
/*     */         
/* 126 */         for (Map.Entry<String, String> extraHiddenField : extraHiddenFields.entrySet())
/*     */         {
/* 128 */           Map<String, String> extraHiddenAttributes = new LinkedHashMap(4, 1.0F);
/* 129 */           extraHiddenAttributes.put("type", "hidden");
/* 130 */           extraHiddenAttributes.put("name", (String)extraHiddenField.getKey());
/* 131 */           extraHiddenAttributes.put("value", (String)extraHiddenField.getValue());
/*     */           
/*     */ 
/* 134 */           IStandaloneElementTag extraHiddenElementTag = modelFactory.createStandaloneElementTag("input", extraHiddenAttributes, AttributeValueQuotes.DOUBLE, false, true);
/*     */           
/* 136 */           extraHiddenElementTags.add(extraHiddenElementTag);
/*     */         }
/*     */         
/*     */ 
/* 140 */         structureHandler.insertImmediatelyAfter(extraHiddenElementTags, false);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringActionTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */