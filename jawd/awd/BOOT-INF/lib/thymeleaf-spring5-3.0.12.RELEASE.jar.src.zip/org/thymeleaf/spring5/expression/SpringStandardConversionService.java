/*     */ package org.thymeleaf.spring5.expression;
/*     */ 
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.standard.expression.AbstractStandardConversionService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringStandardConversionService
/*     */   extends AbstractStandardConversionService
/*     */ {
/*  47 */   private static final TypeDescriptor TYPE_STRING = TypeDescriptor.valueOf(String.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String convertToString(IExpressionContext context, Object object)
/*     */   {
/*  63 */     if (object == null) {
/*  64 */       return null;
/*     */     }
/*  66 */     TypeDescriptor objectTypeDescriptor = TypeDescriptor.forObject(object);
/*  67 */     TypeConverter typeConverter = getSpringConversionService(context);
/*  68 */     if ((typeConverter == null) || (!typeConverter.canConvert(objectTypeDescriptor, TYPE_STRING))) {
/*  69 */       return super.convertToString(context, object);
/*     */     }
/*  71 */     return (String)typeConverter.convertValue(object, objectTypeDescriptor, TYPE_STRING);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected <T> T convertOther(IExpressionContext context, Object object, Class<T> targetClass)
/*     */   {
/*  81 */     if (object == null) {
/*  82 */       return null;
/*     */     }
/*  84 */     TypeDescriptor objectTypeDescriptor = TypeDescriptor.forObject(object);
/*  85 */     TypeDescriptor targetTypeDescriptor = TypeDescriptor.valueOf(targetClass);
/*  86 */     TypeConverter typeConverter = getSpringConversionService(context);
/*  87 */     if ((typeConverter == null) || (!typeConverter.canConvert(objectTypeDescriptor, targetTypeDescriptor))) {
/*  88 */       return (T)super.convertOther(context, object, targetClass);
/*     */     }
/*  90 */     return (T)typeConverter.convertValue(object, objectTypeDescriptor, targetTypeDescriptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static TypeConverter getSpringConversionService(IExpressionContext context)
/*     */   {
/* 103 */     EvaluationContext evaluationContext = (EvaluationContext)context.getVariable("thymeleaf::EvaluationContext");
/*     */     
/*     */ 
/* 106 */     if (evaluationContext != null) {
/* 107 */       return evaluationContext.getTypeConverter();
/*     */     }
/*     */     
/* 110 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\expression\SpringStandardConversionService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */