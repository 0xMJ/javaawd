/*    */ package org.thymeleaf.spring5.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*    */ import org.thymeleaf.spring5.util.FieldUtils;
/*    */ import org.thymeleaf.spring5.util.SpringValueFormatter;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.unbescape.html.HtmlEscape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringErrorsTagProcessor
/*    */   extends AbstractAttributeTagProcessor
/*    */ {
/*    */   private static final String ERROR_DELIMITER = "<br />";
/*    */   public static final int ATTR_PRECEDENCE = 1700;
/*    */   public static final String ATTR_NAME = "errors";
/*    */   
/*    */   public SpringErrorsTagProcessor(String dialectPrefix)
/*    */   {
/* 53 */     super(TemplateMode.HTML, dialectPrefix, null, false, "errors", true, 1700, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*    */   {
/* 65 */     IThymeleafBindStatus bindStatus = FieldUtils.getBindStatus(context, attributeValue);
/*    */     
/* 67 */     if (bindStatus.isError())
/*    */     {
/* 69 */       StringBuilder strBuilder = new StringBuilder();
/* 70 */       String[] errorMsgs = bindStatus.getErrorMessages();
/*    */       
/* 72 */       for (int i = 0; i < errorMsgs.length; i++) {
/* 73 */         if (i > 0) {
/* 74 */           strBuilder.append("<br />");
/*    */         }
/* 76 */         String displayString = SpringValueFormatter.getDisplayString(errorMsgs[i], false);
/* 77 */         strBuilder.append(HtmlEscape.escapeHtml4Xml(displayString));
/*    */       }
/*    */       
/* 80 */       structureHandler.setBody(strBuilder.toString(), false);
/*    */       
/*    */ 
/* 83 */       structureHandler.setLocalVariable("thymeleafFieldBindStatus", bindStatus);
/*    */     }
/*    */     else
/*    */     {
/* 87 */       structureHandler.removeElement();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringErrorsTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */