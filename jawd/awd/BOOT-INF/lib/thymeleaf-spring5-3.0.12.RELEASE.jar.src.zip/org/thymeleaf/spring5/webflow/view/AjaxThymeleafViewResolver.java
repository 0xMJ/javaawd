/*     */ package org.thymeleaf.spring5.webflow.view;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.view.RedirectView;
/*     */ import org.springframework.webflow.context.servlet.AjaxHandler;
/*     */ import org.springframework.webflow.context.servlet.DefaultAjaxHandler;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ import org.thymeleaf.spring5.view.ThymeleafViewResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AjaxThymeleafViewResolver
/*     */   extends ThymeleafViewResolver
/*     */ {
/*  57 */   private static final Logger vrlogger = LoggerFactory.getLogger(AjaxThymeleafViewResolver.class);
/*     */   
/*     */ 
/*  60 */   private AjaxHandler ajaxHandler = new DefaultAjaxHandler();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AjaxHandler getAjaxHandler()
/*     */   {
/*  82 */     return this.ajaxHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAjaxHandler(AjaxHandler ajaxHandler)
/*     */   {
/*  99 */     this.ajaxHandler = ajaxHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected View createView(String viewName, Locale locale)
/*     */     throws Exception
/*     */   {
/* 108 */     if (!canHandle(viewName, locale)) {
/* 109 */       return null;
/*     */     }
/*     */     
/* 112 */     if (this.ajaxHandler == null)
/*     */     {
/* 114 */       throw new ConfigurationException("[THYMELEAF] AJAX Handler set into " + AjaxThymeleafViewResolver.class.getSimpleName() + " instance is null.");
/*     */     }
/*     */     
/*     */ 
/* 118 */     if (viewName.startsWith("redirect:")) {
/* 119 */       vrlogger.trace("[THYMELEAF] View {} is a redirect. An AJAX-enabled RedirectView implementation will be handling the request.", viewName);
/*     */       
/*     */ 
/* 122 */       String redirectUrl = viewName.substring("redirect:".length());
/* 123 */       return new AjaxRedirectView(this.ajaxHandler, redirectUrl, 
/* 124 */         isRedirectContextRelative(), isRedirectHttp10Compatible());
/*     */     }
/*     */     
/* 127 */     View view = super.createView(viewName, locale);
/*     */     
/* 129 */     if ((view instanceof AjaxEnabledView))
/*     */     {
/*     */ 
/* 132 */       AjaxEnabledView ajaxEnabledView = (AjaxEnabledView)view;
/*     */       
/* 134 */       if ((ajaxEnabledView.getAjaxHandler() == null) && (getAjaxHandler() != null)) {
/* 135 */         ajaxEnabledView.setAjaxHandler(getAjaxHandler());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 140 */     return view;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class AjaxRedirectView
/*     */     extends RedirectView
/*     */   {
/* 150 */     private static final Logger vlogger = LoggerFactory.getLogger(AjaxRedirectView.class);
/*     */     
/* 152 */     private AjaxHandler ajaxHandler = new DefaultAjaxHandler();
/*     */     
/*     */     AjaxRedirectView(AjaxHandler ajaxHandler, String redirectUrl, boolean redirectContextRelative, boolean redirectHttp10Compatible)
/*     */     {
/* 156 */       super(redirectContextRelative, redirectHttp10Compatible);
/* 157 */       this.ajaxHandler = ajaxHandler;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected void sendRedirect(HttpServletRequest request, HttpServletResponse response, String targetUrl, boolean http10Compatible)
/*     */       throws IOException
/*     */     {
/* 165 */       if (this.ajaxHandler == null)
/*     */       {
/* 167 */         throw new ConfigurationException("[THYMELEAF] AJAX Handler set into " + AjaxThymeleafViewResolver.class.getSimpleName() + " instance is null.");
/*     */       }
/*     */       
/* 170 */       if (this.ajaxHandler.isAjaxRequest(request, response)) {
/* 171 */         if (vlogger.isTraceEnabled()) {
/* 172 */           vlogger.trace("[THYMELEAF] RedirectView for URL \"{}\" is an AJAX request. AjaxHandler of class {} will be in charge of processing the request.", targetUrl, this.ajaxHandler
/*     */           
/* 174 */             .getClass().getName());
/*     */         }
/* 176 */         this.ajaxHandler.sendAjaxRedirect(targetUrl, request, response, false);
/*     */       } else {
/* 178 */         vlogger.trace("[THYMELEAF] RedirectView for URL \"{}\" is not an AJAX request. Request will be handled as a normal redirect", targetUrl);
/*     */         
/*     */ 
/* 181 */         super.sendRedirect(request, response, targetUrl, http10Compatible);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\webflow\view\AjaxThymeleafViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */