/*    */ package org.thymeleaf.spring5.webflow.view;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.webflow.core.collection.MutableAttributeMap;
/*    */ import org.springframework.webflow.execution.RequestContext;
/*    */ import org.springframework.webflow.execution.RequestContextHolder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlowAjaxThymeleafView
/*    */   extends AjaxThymeleafView
/*    */ {
/*    */   protected Set<String> getRenderFragments(Map model, HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 71 */     RequestContext context = RequestContextHolder.getRequestContext();
/* 72 */     if (context == null) {
/* 73 */       return super.getRenderFragments(model, request, response);
/*    */     }
/*    */     
/* 76 */     String[] fragments = (String[])context.getFlashScope().get("flowRenderFragments");
/* 77 */     if ((fragments == null) || (fragments.length == 0)) {
/* 78 */       return super.getRenderFragments(model, request, response);
/*    */     }
/* 80 */     if (fragments.length == 1) {
/* 81 */       return Collections.singleton(fragments[0]);
/*    */     }
/* 83 */     return new HashSet(Arrays.asList(fragments));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\webflow\view\FlowAjaxThymeleafView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */