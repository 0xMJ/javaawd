/*    */ package org.thymeleaf.spring5.expression;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringStandardExpressions
/*    */ {
/*    */   public static final String ENABLE_SPRING_EL_COMPILER_ATTRIBUTE_NAME = "EnableSpringELCompiler";
/*    */   
/*    */   public static boolean isSpringELCompilerEnabled(IEngineConfiguration configuration)
/*    */   {
/* 68 */     Object enableSpringELCompiler = configuration.getExecutionAttributes().get("EnableSpringELCompiler");
/* 69 */     if (enableSpringELCompiler == null) {
/* 70 */       return false;
/*    */     }
/* 72 */     if (!(enableSpringELCompiler instanceof Boolean))
/*    */     {
/*    */ 
/*    */ 
/* 76 */       throw new TemplateProcessingException("A value for the \"EnableSpringELCompiler\" execution attribute has been specified, but it is not of the required type Boolean. (" + enableSpringELCompiler.getClass().getName() + ")");
/*    */     }
/* 78 */     return ((Boolean)enableSpringELCompiler).booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\expression\SpringStandardExpressions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */