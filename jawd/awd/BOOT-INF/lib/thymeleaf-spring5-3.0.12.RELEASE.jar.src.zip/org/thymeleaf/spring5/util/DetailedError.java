/*    */ package org.thymeleaf.spring5.util;
/*    */ 
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DetailedError
/*    */ {
/*    */   private static final String GLOBAL_FIELD_NAME = "[global]";
/*    */   private final String fieldName;
/*    */   private final String code;
/*    */   private final Object[] arguments;
/*    */   private final String message;
/*    */   
/*    */   public DetailedError(String code, Object[] arguments, String message)
/*    */   {
/* 43 */     this("[global]", code, arguments, message);
/*    */   }
/*    */   
/*    */ 
/*    */   public DetailedError(String fieldName, String code, Object[] arguments, String message)
/*    */   {
/* 49 */     Validate.notNull(fieldName, "Field name cannot be null");
/* 50 */     Validate.notNull(message, "Message cannot be null");
/* 51 */     this.fieldName = fieldName;
/* 52 */     this.code = code;
/* 53 */     this.arguments = arguments;
/* 54 */     this.message = message;
/*    */   }
/*    */   
/*    */   public String getFieldName() {
/* 58 */     return this.fieldName;
/*    */   }
/*    */   
/*    */   public String getCode() {
/* 62 */     return this.code;
/*    */   }
/*    */   
/*    */   public Object[] getArguments() {
/* 66 */     return this.arguments;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 70 */     return this.message;
/*    */   }
/*    */   
/*    */   public boolean isGlobal() {
/* 74 */     return "[global]".equalsIgnoreCase(this.fieldName);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 79 */     StringBuilder strBuilder = new StringBuilder();
/* 80 */     strBuilder.append(this.fieldName);
/* 81 */     strBuilder.append(":");
/* 82 */     strBuilder.append(this.message);
/* 83 */     return strBuilder.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\util\DetailedError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */