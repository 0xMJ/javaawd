/*     */ package org.thymeleaf.spring5.processor;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeDefinition;
/*     */ import org.thymeleaf.engine.AttributeDefinitions;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.AttributeNames;
/*     */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*     */ import org.thymeleaf.spring5.util.FieldUtils;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.standard.expression.VariableExpression;
/*     */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import org.unbescape.html.HtmlEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringErrorClassTagProcessor
/*     */   extends AbstractAttributeTagProcessor
/*     */   implements IAttributeDefinitionsAware
/*     */ {
/*     */   public static final int ATTR_PRECEDENCE = 1800;
/*     */   public static final String ATTR_NAME = "errorclass";
/*     */   public static final String TARGET_ATTR_NAME = "class";
/*  65 */   private static final TemplateMode TEMPLATE_MODE = TemplateMode.HTML;
/*     */   
/*     */ 
/*     */   private AttributeDefinition targetAttributeDefinition;
/*     */   
/*     */ 
/*     */   public SpringErrorClassTagProcessor(String dialectPrefix)
/*     */   {
/*  73 */     super(TEMPLATE_MODE, dialectPrefix, null, false, "errorclass", true, 1800, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions)
/*     */   {
/*  80 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*     */     
/*     */ 
/*  83 */     this.targetAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "class");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*     */   {
/*  96 */     IThymeleafBindStatus bindStatus = computeBindStatus(context, tag);
/*  97 */     if (bindStatus == null)
/*     */     {
/*  99 */       AttributeName fieldAttributeName = AttributeNames.forHTMLName(attributeName.getPrefix(), "field");
/*     */       
/*     */ 
/* 102 */       throw new TemplateProcessingException("Cannot apply \"" + attributeName + "\": this attribute requires the existence of a \"name\" (or " + Arrays.asList(fieldAttributeName.getCompleteAttributeNames()) + ") attribute with non-empty value in the same host tag.");
/*     */     }
/*     */     
/*     */ 
/* 106 */     if (bindStatus.isError())
/*     */     {
/* 108 */       IEngineConfiguration configuration = context.getConfiguration();
/* 109 */       IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(configuration);
/*     */       
/* 111 */       IStandardExpression expression = expressionParser.parseExpression(context, attributeValue);
/* 112 */       Object expressionResult = expression.execute(context);
/*     */       
/* 114 */       String newAttributeValue = HtmlEscape.escapeHtml4Xml(expressionResult == null ? null : expressionResult.toString());
/*     */       
/*     */ 
/* 117 */       if ((newAttributeValue != null) && (newAttributeValue.length() > 0))
/*     */       {
/* 119 */         AttributeName targetAttributeName = this.targetAttributeDefinition.getAttributeName();
/*     */         
/* 121 */         if (tag.hasAttribute(targetAttributeName)) {
/* 122 */           String currentValue = tag.getAttributeValue(targetAttributeName);
/* 123 */           if (currentValue.length() > 0) {
/* 124 */             newAttributeValue = currentValue + ' ' + newAttributeValue;
/*     */           }
/*     */         }
/*     */         
/* 128 */         StandardProcessorUtils.setAttribute(structureHandler, this.targetAttributeDefinition, "class", newAttributeValue);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static IThymeleafBindStatus computeBindStatus(IExpressionContext context, IProcessableElementTag tag)
/*     */   {
/* 152 */     IThymeleafBindStatus bindStatus = (IThymeleafBindStatus)context.getVariable("thymeleafFieldBindStatus");
/* 153 */     if (bindStatus != null) {
/* 154 */       return bindStatus;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 162 */     String fieldName = tag.getAttributeValue("name");
/* 163 */     if (StringUtils.isEmptyOrWhitespace(fieldName)) {
/* 164 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 168 */     VariableExpression boundExpression = (VariableExpression)context.getVariable("springBoundObjectExpression");
/*     */     
/* 170 */     if (boundExpression == null)
/*     */     {
/* 172 */       return FieldUtils.getBindStatusFromParsedExpression(context, false, fieldName);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 178 */     String boundExpressionStr = boundExpression.getExpression();
/*     */     String computedFieldName;
/* 180 */     String computedFieldName; if (boundExpressionStr.indexOf('.') == -1) {
/* 181 */       computedFieldName = boundExpressionStr + '.' + fieldName;
/*     */     } else {
/* 183 */       computedFieldName = boundExpressionStr.substring(0, boundExpressionStr.indexOf('.')) + '.' + fieldName;
/*     */     }
/*     */     
/*     */ 
/* 187 */     return FieldUtils.getBindStatusFromParsedExpression(context, false, computedFieldName);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringErrorClassTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */