package org.thymeleaf.spring5;

import org.springframework.context.MessageSource;
import org.thymeleaf.ITemplateEngine;

public abstract interface ISpringTemplateEngine
  extends ITemplateEngine
{
  public abstract void setTemplateEngineMessageSource(MessageSource paramMessageSource);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\ISpringTemplateEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */