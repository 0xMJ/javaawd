/*     */ package org.thymeleaf.spring5.processor;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.context.IdentifierSequences;
/*     */ import org.thymeleaf.engine.AttributeDefinition;
/*     */ import org.thymeleaf.engine.AttributeDefinitions;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*     */ import org.thymeleaf.spring5.util.FieldUtils;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSpringFieldTagProcessor
/*     */   extends AbstractAttributeTagProcessor
/*     */   implements IAttributeDefinitionsAware
/*     */ {
/*     */   public static final int ATTR_PRECEDENCE = 1700;
/*     */   public static final String ATTR_NAME = "field";
/*  56 */   private static final TemplateMode TEMPLATE_MODE = TemplateMode.HTML;
/*     */   
/*     */   protected static final String INPUT_TAG_NAME = "input";
/*     */   
/*     */   protected static final String SELECT_TAG_NAME = "select";
/*     */   
/*     */   protected static final String OPTION_TAG_NAME = "option";
/*     */   
/*     */   protected static final String TEXTAREA_TAG_NAME = "textarea";
/*     */   
/*     */   protected static final String ID_ATTR_NAME = "id";
/*     */   
/*     */   protected static final String TYPE_ATTR_NAME = "type";
/*     */   
/*     */   protected static final String NAME_ATTR_NAME = "name";
/*     */   
/*     */   protected static final String VALUE_ATTR_NAME = "value";
/*     */   
/*     */   protected static final String CHECKED_ATTR_NAME = "checked";
/*     */   
/*     */   protected static final String SELECTED_ATTR_NAME = "selected";
/*     */   
/*     */   protected static final String DISABLED_ATTR_NAME = "disabled";
/*     */   protected static final String MULTIPLE_ATTR_NAME = "multiple";
/*     */   private AttributeDefinition discriminatorAttributeDefinition;
/*     */   protected AttributeDefinition idAttributeDefinition;
/*     */   protected AttributeDefinition typeAttributeDefinition;
/*     */   protected AttributeDefinition nameAttributeDefinition;
/*     */   protected AttributeDefinition valueAttributeDefinition;
/*     */   protected AttributeDefinition checkedAttributeDefinition;
/*     */   protected AttributeDefinition selectedAttributeDefinition;
/*     */   protected AttributeDefinition disabledAttributeDefinition;
/*     */   protected AttributeDefinition multipleAttributeDefinition;
/*     */   private final String discriminatorAttrName;
/*     */   private final String[] discriminatorAttrValues;
/*     */   private final boolean removeAttribute;
/*     */   
/*     */   public AbstractSpringFieldTagProcessor(String dialectPrefix, String elementName, String discriminatorAttrName, String[] discriminatorAttrValues, boolean removeAttribute)
/*     */   {
/*  95 */     super(TEMPLATE_MODE, dialectPrefix, elementName, false, "field", true, 1700, false);
/*  96 */     this.discriminatorAttrName = discriminatorAttrName;
/*  97 */     this.discriminatorAttrValues = discriminatorAttrValues;
/*  98 */     this.removeAttribute = removeAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions)
/*     */   {
/* 105 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*     */     
/*     */ 
/*     */ 
/* 109 */     this.discriminatorAttributeDefinition = (this.discriminatorAttrName != null ? attributeDefinitions.forName(TEMPLATE_MODE, this.discriminatorAttrName) : null);
/* 110 */     this.idAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "id");
/* 111 */     this.typeAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "type");
/* 112 */     this.nameAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "name");
/* 113 */     this.valueAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "value");
/* 114 */     this.checkedAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "checked");
/* 115 */     this.selectedAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "selected");
/* 116 */     this.disabledAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "disabled");
/* 117 */     this.multipleAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "multiple");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean matchesDiscriminator(IProcessableElementTag tag)
/*     */   {
/* 125 */     if (this.discriminatorAttrName == null) {
/* 126 */       return true;
/*     */     }
/* 128 */     boolean hasDiscriminatorAttr = tag.hasAttribute(this.discriminatorAttributeDefinition.getAttributeName());
/* 129 */     if ((this.discriminatorAttrValues == null) || (this.discriminatorAttrValues.length == 0)) {
/* 130 */       return hasDiscriminatorAttr;
/*     */     }
/*     */     
/* 133 */     String discriminatorTagValue = hasDiscriminatorAttr ? tag.getAttributeValue(this.discriminatorAttributeDefinition.getAttributeName()) : null;
/* 134 */     for (int i = 0; i < this.discriminatorAttrValues.length; i++) {
/* 135 */       String discriminatorAttrValue = this.discriminatorAttrValues[i];
/* 136 */       if (discriminatorAttrValue == null) {
/* 137 */         if ((!hasDiscriminatorAttr) || (discriminatorTagValue == null)) {
/* 138 */           return true;
/*     */         }
/* 140 */       } else if (discriminatorAttrValue.equals(discriminatorTagValue)) {
/* 141 */         return true;
/*     */       }
/*     */     }
/* 144 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*     */   {
/* 164 */     if (!matchesDiscriminator(tag))
/*     */     {
/*     */ 
/* 167 */       return;
/*     */     }
/*     */     
/* 170 */     if (this.removeAttribute) {
/* 171 */       structureHandler.removeAttribute(attributeName);
/*     */     }
/*     */     
/* 174 */     IThymeleafBindStatus bindStatus = FieldUtils.getBindStatus(context, attributeValue);
/*     */     
/* 176 */     if (bindStatus == null) {
/* 177 */       throw new TemplateProcessingException("Cannot process attribute '" + attributeName + "': no associated BindStatus could be found for the intended form binding operations. This can be due to the lack of a proper management of the Spring RequestContext, which is usually done through the ThymeleafView or ThymeleafReactiveView");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */     structureHandler.setLocalVariable("thymeleafFieldBindStatus", bindStatus);
/*     */     
/* 187 */     doProcess(context, tag, attributeName, attributeValue, bindStatus, structureHandler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IProcessableElementTag paramIProcessableElementTag, AttributeName paramAttributeName, String paramString, IThymeleafBindStatus paramIThymeleafBindStatus, IElementTagStructureHandler paramIElementTagStructureHandler);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String computeId(ITemplateContext context, IProcessableElementTag tag, String name, boolean sequence)
/*     */   {
/* 212 */     String id = tag.getAttributeValue(this.idAttributeDefinition.getAttributeName());
/* 213 */     if (!org.thymeleaf.util.StringUtils.isEmptyOrWhitespace(id)) {
/* 214 */       return org.springframework.util.StringUtils.hasText(id) ? id : null;
/*     */     }
/*     */     
/* 217 */     id = FieldUtils.idFromName(name);
/* 218 */     if (sequence) {
/* 219 */       Integer count = context.getIdentifierSequences().getAndIncrementIDSeq(id);
/* 220 */       return id + count.toString();
/*     */     }
/* 222 */     return id;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\AbstractSpringFieldTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */