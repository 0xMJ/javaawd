/*     */ package org.thymeleaf.spring5.view;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.view.AbstractCachingViewResolver;
/*     */ import org.springframework.web.servlet.view.InternalResourceView;
/*     */ import org.springframework.web.servlet.view.RedirectView;
/*     */ import org.thymeleaf.spring5.ISpringTemplateEngine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThymeleafViewResolver
/*     */   extends AbstractCachingViewResolver
/*     */   implements Ordered
/*     */ {
/*  67 */   private static final Logger vrlogger = LoggerFactory.getLogger(ThymeleafViewResolver.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String REDIRECT_URL_PREFIX = "redirect:";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String FORWARD_URL_PREFIX = "forward:";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */   private boolean redirectContextRelative = true;
/*  93 */   private boolean redirectHttp10Compatible = true;
/*     */   
/*  95 */   private boolean alwaysProcessRedirectAndForward = true;
/*     */   
/*  97 */   private boolean producePartialOutputWhileProcessing = true;
/*     */   
/*  99 */   private Class<? extends AbstractThymeleafView> viewClass = ThymeleafView.class;
/* 100 */   private String[] viewNames = null;
/* 101 */   private String[] excludedViewNames = null;
/* 102 */   private int order = Integer.MAX_VALUE;
/*     */   
/*     */ 
/* 105 */   private final Map<String, Object> staticVariables = new LinkedHashMap(10);
/* 106 */   private String contentType = null;
/* 107 */   private boolean forceContentType = false;
/* 108 */   private String characterEncoding = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ISpringTemplateEngine templateEngine;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setViewClass(Class<? extends AbstractThymeleafView> viewClass)
/*     */   {
/* 136 */     if ((viewClass == null) || (!AbstractThymeleafView.class.isAssignableFrom(viewClass)))
/*     */     {
/*     */ 
/* 139 */       throw new IllegalArgumentException("Given view class [" + (viewClass != null ? viewClass.getName() : null) + "] is not of type [" + AbstractThymeleafView.class.getName() + "]");
/*     */     }
/* 141 */     this.viewClass = viewClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<? extends AbstractThymeleafView> getViewClass()
/*     */   {
/* 153 */     return this.viewClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ISpringTemplateEngine getTemplateEngine()
/*     */   {
/* 166 */     return this.templateEngine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTemplateEngine(ISpringTemplateEngine templateEngine)
/*     */   {
/* 179 */     this.templateEngine = templateEngine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getStaticVariables()
/*     */   {
/* 199 */     return Collections.unmodifiableMap(this.staticVariables);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addStaticVariable(String name, Object value)
/*     */   {
/* 218 */     this.staticVariables.put(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStaticVariables(Map<String, ?> variables)
/*     */   {
/* 242 */     if (variables != null) {
/* 243 */       for (Map.Entry<String, ?> entry : variables.entrySet()) {
/* 244 */         addStaticVariable((String)entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/* 265 */     this.order = order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 282 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentType(String contentType)
/*     */   {
/* 308 */     this.contentType = contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 335 */     return this.contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getForceContentType()
/*     */   {
/* 358 */     return this.forceContentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setForceContentType(boolean forceContentType)
/*     */   {
/* 380 */     this.forceContentType = forceContentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharacterEncoding(String characterEncoding)
/*     */   {
/* 410 */     this.characterEncoding = characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCharacterEncoding()
/*     */   {
/* 438 */     return this.characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRedirectContextRelative(boolean redirectContextRelative)
/*     */   {
/* 461 */     this.redirectContextRelative = redirectContextRelative;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRedirectContextRelative()
/*     */   {
/* 478 */     return this.redirectContextRelative;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRedirectHttp10Compatible(boolean redirectHttp10Compatible)
/*     */   {
/* 508 */     this.redirectHttp10Compatible = redirectHttp10Compatible;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRedirectHttp10Compatible()
/*     */   {
/* 524 */     return this.redirectHttp10Compatible;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlwaysProcessRedirectAndForward(boolean alwaysProcessRedirectAndForward)
/*     */   {
/* 552 */     this.alwaysProcessRedirectAndForward = alwaysProcessRedirectAndForward;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAlwaysProcessRedirectAndForward()
/*     */   {
/* 580 */     return this.alwaysProcessRedirectAndForward;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getProducePartialOutputWhileProcessing()
/*     */   {
/* 615 */     return this.producePartialOutputWhileProcessing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProducePartialOutputWhileProcessing(boolean producePartialOutputWhileProcessing)
/*     */   {
/* 649 */     this.producePartialOutputWhileProcessing = producePartialOutputWhileProcessing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setViewNames(String[] viewNames)
/*     */   {
/* 681 */     this.viewNames = viewNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getViewNames()
/*     */   {
/* 711 */     return this.viewNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExcludedViewNames(String[] excludedViewNames)
/*     */   {
/* 732 */     this.excludedViewNames = excludedViewNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getExcludedViewNames()
/*     */   {
/* 751 */     return this.excludedViewNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean canHandle(String viewName, Locale locale)
/*     */   {
/* 758 */     String[] viewNamesToBeProcessed = getViewNames();
/* 759 */     String[] viewNamesNotToBeProcessed = getExcludedViewNames();
/* 760 */     return ((viewNamesToBeProcessed == null) || (PatternMatchUtils.simpleMatch(viewNamesToBeProcessed, viewName))) && ((viewNamesNotToBeProcessed == null) || 
/* 761 */       (!PatternMatchUtils.simpleMatch(viewNamesNotToBeProcessed, viewName)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected View createView(String viewName, Locale locale)
/*     */     throws Exception
/*     */   {
/* 770 */     if ((!this.alwaysProcessRedirectAndForward) && (!canHandle(viewName, locale))) {
/* 771 */       vrlogger.trace("[THYMELEAF] View \"{}\" cannot be handled by ThymeleafViewResolver. Passing on to the next resolver in the chain.", viewName);
/* 772 */       return null;
/*     */     }
/*     */     
/* 775 */     if (viewName.startsWith("redirect:")) {
/* 776 */       vrlogger.trace("[THYMELEAF] View \"{}\" is a redirect, and will not be handled directly by ThymeleafViewResolver.", viewName);
/* 777 */       String redirectUrl = viewName.substring("redirect:".length(), viewName.length());
/* 778 */       RedirectView view = new RedirectView(redirectUrl, isRedirectContextRelative(), isRedirectHttp10Compatible());
/* 779 */       return (View)getApplicationContext().getAutowireCapableBeanFactory().initializeBean(view, "redirect:");
/*     */     }
/*     */     
/* 782 */     if (viewName.startsWith("forward:"))
/*     */     {
/*     */ 
/* 785 */       vrlogger.trace("[THYMELEAF] View \"{}\" is a forward, and will not be handled directly by ThymeleafViewResolver.", viewName);
/* 786 */       String forwardUrl = viewName.substring("forward:".length(), viewName.length());
/* 787 */       return new InternalResourceView(forwardUrl);
/*     */     }
/*     */     
/* 790 */     if ((this.alwaysProcessRedirectAndForward) && (!canHandle(viewName, locale))) {
/* 791 */       vrlogger.trace("[THYMELEAF] View \"{}\" cannot be handled by ThymeleafViewResolver. Passing on to the next resolver in the chain.", viewName);
/* 792 */       return null;
/*     */     }
/* 794 */     vrlogger.trace("[THYMELEAF] View {} will be handled by ThymeleafViewResolver and a {} instance will be created for it", viewName, 
/* 795 */       getViewClass().getSimpleName());
/* 796 */     return loadView(viewName, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected View loadView(String viewName, Locale locale)
/*     */     throws Exception
/*     */   {
/* 805 */     AutowireCapableBeanFactory beanFactory = getApplicationContext().getAutowireCapableBeanFactory();
/*     */     
/* 807 */     boolean viewBeanExists = beanFactory.containsBean(viewName);
/* 808 */     Class<?> viewBeanType = viewBeanExists ? beanFactory.getType(viewName) : null;
/*     */     AbstractThymeleafView view;
/*     */     AbstractThymeleafView view;
/* 811 */     if ((viewBeanExists) && (viewBeanType != null) && (AbstractThymeleafView.class.isAssignableFrom(viewBeanType)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 824 */       BeanDefinition viewBeanDefinition = (beanFactory instanceof ConfigurableListableBeanFactory) ? ((ConfigurableListableBeanFactory)beanFactory).getBeanDefinition(viewName) : null;
/*     */       AbstractThymeleafView view;
/* 826 */       if ((viewBeanDefinition == null) || (!viewBeanDefinition.isPrototype()))
/*     */       {
/* 828 */         AbstractThymeleafView viewInstance = (AbstractThymeleafView)BeanUtils.instantiateClass(getViewClass());
/* 829 */         view = (AbstractThymeleafView)beanFactory.configureBean(viewInstance, viewName);
/*     */       }
/*     */       else {
/* 832 */         view = (AbstractThymeleafView)beanFactory.getBean(viewName);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 837 */       AbstractThymeleafView viewInstance = (AbstractThymeleafView)BeanUtils.instantiateClass(getViewClass());
/*     */       AbstractThymeleafView view;
/* 839 */       if ((viewBeanExists) && (viewBeanType == null))
/*     */       {
/*     */ 
/*     */ 
/* 843 */         beanFactory.autowireBeanProperties(viewInstance, 0, false);
/*     */         
/* 845 */         beanFactory.applyBeanPropertyValues(viewInstance, viewName);
/*     */         
/* 847 */         view = (AbstractThymeleafView)beanFactory.initializeBean(viewInstance, viewName);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 853 */         beanFactory.autowireBeanProperties(viewInstance, 0, false);
/*     */         
/* 855 */         view = (AbstractThymeleafView)beanFactory.initializeBean(viewInstance, viewName);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 861 */     view.setTemplateEngine(getTemplateEngine());
/* 862 */     view.setStaticVariables(getStaticVariables());
/*     */     
/*     */ 
/*     */ 
/* 866 */     if (view.getTemplateName() == null) {
/* 867 */       view.setTemplateName(viewName);
/*     */     }
/*     */     
/* 870 */     if (!view.isForceContentTypeSet()) {
/* 871 */       view.setForceContentType(getForceContentType());
/*     */     }
/* 873 */     if ((!view.isContentTypeSet()) && (getContentType() != null)) {
/* 874 */       view.setContentType(getContentType());
/*     */     }
/* 876 */     if ((view.getLocale() == null) && (locale != null)) {
/* 877 */       view.setLocale(locale);
/*     */     }
/* 879 */     if ((view.getCharacterEncoding() == null) && (getCharacterEncoding() != null)) {
/* 880 */       view.setCharacterEncoding(getCharacterEncoding());
/*     */     }
/* 882 */     if (!view.isProducePartialOutputWhileProcessingSet()) {
/* 883 */       view.setProducePartialOutputWhileProcessing(getProducePartialOutputWhileProcessing());
/*     */     }
/*     */     
/* 886 */     return view;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\view\ThymeleafViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */