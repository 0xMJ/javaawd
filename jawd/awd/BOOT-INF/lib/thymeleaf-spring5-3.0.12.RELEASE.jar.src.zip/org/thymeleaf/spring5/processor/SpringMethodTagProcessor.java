/*     */ package org.thymeleaf.spring5.processor;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeDefinition;
/*     */ import org.thymeleaf.engine.AttributeDefinitions;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.model.IModelFactory;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.spring5.requestdata.RequestDataValueProcessorUtils;
/*     */ import org.thymeleaf.standard.processor.AbstractStandardExpressionAttributeTagProcessor;
/*     */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import org.unbescape.html.HtmlEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringMethodTagProcessor
/*     */   extends AbstractStandardExpressionAttributeTagProcessor
/*     */   implements IAttributeDefinitionsAware
/*     */ {
/*     */   public static final int ATTR_PRECEDENCE = 990;
/*     */   public static final String TARGET_ATTR_NAME = "method";
/*  59 */   private static final TemplateMode TEMPLATE_MODE = TemplateMode.HTML;
/*     */   
/*     */   private static final String TYPE_ATTR_NAME = "type";
/*     */   
/*     */   private static final String NAME_ATTR_NAME = "name";
/*     */   
/*     */   private static final String VALUE_ATTR_NAME = "value";
/*     */   
/*     */   private AttributeDefinition targetAttributeDefinition;
/*     */   
/*     */   public SpringMethodTagProcessor(String dialectPrefix)
/*     */   {
/*  71 */     super(TEMPLATE_MODE, dialectPrefix, "method", 990, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions)
/*     */   {
/*  78 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*     */     
/*     */ 
/*  81 */     this.targetAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "method");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler)
/*     */   {
/*  95 */     String newAttributeValue = HtmlEscape.escapeHtml4Xml(expressionResult == null ? null : expressionResult.toString());
/*     */     
/*     */ 
/*  98 */     if ((newAttributeValue == null) || (newAttributeValue.length() == 0)) {
/*  99 */       structureHandler.removeAttribute(this.targetAttributeDefinition.getAttributeName());
/* 100 */       structureHandler.removeAttribute(attributeName);
/*     */     } else {
/* 102 */       StandardProcessorUtils.replaceAttribute(structureHandler, attributeName, this.targetAttributeDefinition, "method", newAttributeValue);
/*     */     }
/*     */     
/*     */ 
/* 106 */     if ((newAttributeValue != null) && ("form".equalsIgnoreCase(tag.getElementCompleteName())))
/*     */     {
/* 108 */       if (!isMethodBrowserSupported(newAttributeValue))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */         StandardProcessorUtils.setAttribute(structureHandler, this.targetAttributeDefinition, "method", "post");
/*     */         
/* 117 */         IModelFactory modelFactory = context.getModelFactory();
/*     */         
/* 119 */         IModel hiddenMethodModel = modelFactory.createModel();
/*     */         
/* 121 */         String type = "hidden";
/* 122 */         String name = "_method";
/* 123 */         String value = RequestDataValueProcessorUtils.processFormFieldValue(context, "_method", newAttributeValue, "hidden");
/*     */         
/* 125 */         Map<String, String> hiddenAttributes = new LinkedHashMap(4, 1.0F);
/* 126 */         hiddenAttributes.put("type", "hidden");
/* 127 */         hiddenAttributes.put("name", "_method");
/* 128 */         hiddenAttributes.put("value", value);
/*     */         
/*     */ 
/* 131 */         IStandaloneElementTag hiddenMethodElementTag = modelFactory.createStandaloneElementTag("input", hiddenAttributes, AttributeValueQuotes.DOUBLE, false, true);
/*     */         
/* 133 */         hiddenMethodModel.add(hiddenMethodElementTag);
/*     */         
/* 135 */         structureHandler.insertImmediatelyAfter(hiddenMethodModel, false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isMethodBrowserSupported(String method)
/*     */   {
/* 150 */     return ("get".equalsIgnoreCase(method)) || ("post".equalsIgnoreCase(method));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringMethodTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */