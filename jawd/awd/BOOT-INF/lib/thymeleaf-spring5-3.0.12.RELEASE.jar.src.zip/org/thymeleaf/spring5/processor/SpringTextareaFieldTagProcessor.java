/*    */ package org.thymeleaf.spring5.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*    */ import org.thymeleaf.spring5.requestdata.RequestDataValueProcessorUtils;
/*    */ import org.thymeleaf.spring5.util.SpringValueFormatter;
/*    */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*    */ import org.thymeleaf.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringTextareaFieldTagProcessor
/*    */   extends AbstractSpringFieldTagProcessor
/*    */ {
/*    */   public SpringTextareaFieldTagProcessor(String dialectPrefix)
/*    */   {
/* 45 */     super(dialectPrefix, "textarea", null, null, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IThymeleafBindStatus bindStatus, IElementTagStructureHandler structureHandler)
/*    */   {
/* 56 */     String name = bindStatus.getExpression();
/* 57 */     name = name == null ? "" : name;
/*    */     
/* 59 */     String id = computeId(context, tag, name, false);
/*    */     
/* 61 */     String value = SpringValueFormatter.getDisplayString(bindStatus.getValue(), bindStatus.getEditor(), true);
/*    */     
/*    */ 
/* 64 */     String processedValue = RequestDataValueProcessorUtils.processFormFieldValue(context, name, value, "textarea");
/*    */     
/* 66 */     if (!StringUtils.isEmpty(processedValue)) {
/* 67 */       char c0 = processedValue.charAt(0);
/* 68 */       if (c0 == '\n') {
/* 69 */         processedValue = '\n' + processedValue;
/* 70 */       } else if ((c0 == '\r') && (processedValue.length() > 1) && (processedValue.charAt(1) == '\n')) {
/* 71 */         processedValue = "\r\n" + processedValue;
/* 72 */       } else if (c0 == '\r') {
/* 73 */         processedValue = '\r' + processedValue;
/*    */       }
/*    */     }
/*    */     
/* 77 */     StandardProcessorUtils.setAttribute(structureHandler, this.idAttributeDefinition, "id", id);
/* 78 */     StandardProcessorUtils.setAttribute(structureHandler, this.nameAttributeDefinition, "name", name);
/*    */     
/* 80 */     structureHandler.setBody(processedValue == null ? "" : processedValue, false);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringTextareaFieldTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */