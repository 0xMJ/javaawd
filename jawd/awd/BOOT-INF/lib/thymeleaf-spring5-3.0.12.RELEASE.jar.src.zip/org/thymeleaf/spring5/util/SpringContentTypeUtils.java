/*    */ package org.thymeleaf.spring5.util;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.web.servlet.View;
/*    */ import org.thymeleaf.util.ContentTypeUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringContentTypeUtils
/*    */ {
/*    */   public static String computeViewContentType(HttpServletRequest request, String defaultContentType, Charset defaultCharset)
/*    */   {
/* 50 */     if (request == null) {
/* 51 */       throw new IllegalArgumentException("Request cannot be null");
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 57 */     MediaType negotiatedMediaType = (MediaType)request.getAttribute(View.SELECTED_CONTENT_TYPE);
/* 58 */     if ((negotiatedMediaType != null) && (negotiatedMediaType.isConcrete())) {
/* 59 */       Charset negotiatedCharset = negotiatedMediaType.getCharset();
/* 60 */       if (negotiatedCharset != null) {
/* 61 */         return negotiatedMediaType.toString();
/*    */       }
/* 63 */       return ContentTypeUtils.combineContentTypeAndCharset(negotiatedMediaType.toString(), defaultCharset);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 71 */     String combinedContentType = ContentTypeUtils.combineContentTypeAndCharset(defaultContentType, defaultCharset);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 76 */     Charset combinedCharset = ContentTypeUtils.computeCharsetFromContentType(combinedContentType);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 81 */     String requestPathContentType = ContentTypeUtils.computeContentTypeForRequestPath(request.getRequestURI(), combinedCharset);
/* 82 */     if (requestPathContentType != null) {
/* 83 */       return requestPathContentType;
/*    */     }
/*    */     
/*    */ 
/* 87 */     return combinedContentType;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\util\SpringContentTypeUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */