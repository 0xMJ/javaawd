/*     */ package org.thymeleaf.spring5.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.springframework.beans.NotReadablePropertyException;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.FieldError;
/*     */ import org.springframework.validation.ObjectError;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*     */ import org.thymeleaf.spring5.context.IThymeleafRequestContext;
/*     */ import org.thymeleaf.spring5.context.SpringContextUtils;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.SelectionVariableExpression;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.standard.expression.VariableExpression;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FieldUtils
/*     */ {
/*     */   public static final String ALL_FIELDS = "*";
/*     */   public static final String GLOBAL_EXPRESSION = "global";
/*     */   public static final String ALL_EXPRESSION = "all";
/*     */   
/*     */   public static boolean hasErrors(IExpressionContext context, String field)
/*     */   {
/*  71 */     return checkErrors(context, convertToFieldExpression(field));
/*     */   }
/*     */   
/*     */   public static boolean hasAnyErrors(IExpressionContext context) {
/*  75 */     return checkErrors(context, "all");
/*     */   }
/*     */   
/*     */   public static boolean hasGlobalErrors(IExpressionContext context) {
/*  79 */     return checkErrors(context, "global");
/*     */   }
/*     */   
/*     */ 
/*     */   public static List<String> errors(IExpressionContext context, String field)
/*     */   {
/*  85 */     return computeErrors(context, convertToFieldExpression(field));
/*     */   }
/*     */   
/*     */   public static List<String> errors(IExpressionContext context) {
/*  89 */     return computeErrors(context, "all");
/*     */   }
/*     */   
/*     */   public static List<String> globalErrors(IExpressionContext context) {
/*  93 */     return computeErrors(context, "global");
/*     */   }
/*     */   
/*     */   private static List<String> computeErrors(IExpressionContext context, String fieldExpression)
/*     */   {
/*  98 */     IThymeleafBindStatus bindStatus = getBindStatus(context, fieldExpression);
/*  99 */     if (bindStatus == null) {
/* 100 */       return Collections.EMPTY_LIST;
/*     */     }
/*     */     
/* 103 */     String[] errorMessages = bindStatus.getErrorMessages();
/* 104 */     if ((errorMessages == null) || (errorMessages.length == 0))
/*     */     {
/* 106 */       return Collections.EMPTY_LIST;
/*     */     }
/* 108 */     return Arrays.asList(errorMessages);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<DetailedError> detailedErrors(IExpressionContext context)
/*     */   {
/* 116 */     return computeDetailedErrors(context, "all");
/*     */   }
/*     */   
/*     */   public static List<DetailedError> detailedErrors(IExpressionContext context, String field)
/*     */   {
/* 121 */     return computeDetailedErrors(context, convertToFieldExpression(field));
/*     */   }
/*     */   
/*     */   public static List<DetailedError> globalDetailedErrors(IExpressionContext context) {
/* 125 */     return computeDetailedErrors(context, "global");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static List<DetailedError> computeDetailedErrors(IExpressionContext context, String fieldExpression)
/*     */   {
/* 132 */     IThymeleafBindStatus bindStatus = getBindStatus(context, fieldExpression);
/* 133 */     if (bindStatus == null) {
/* 134 */       return Collections.EMPTY_LIST;
/*     */     }
/*     */     
/* 137 */     Errors errors = bindStatus.getErrors();
/* 138 */     if (errors == null) {
/* 139 */       return Collections.EMPTY_LIST;
/*     */     }
/*     */     
/* 142 */     IThymeleafRequestContext requestContext = SpringContextUtils.getRequestContext(context);
/* 143 */     if (requestContext == null) {
/* 144 */       return Collections.EMPTY_LIST;
/*     */     }
/*     */     
/*     */ 
/* 148 */     List<DetailedError> errorObjects = null;
/*     */     
/* 150 */     String bindExpression = bindStatus.getExpression();
/*     */     
/* 152 */     if ((bindExpression == null) || ("all".equals(bindExpression)) || ("*".equals(bindExpression))) {
/* 153 */       List<ObjectError> globalErrors = errors.getGlobalErrors();
/* 154 */       for (ObjectError globalError : globalErrors) {
/* 155 */         String message = requestContext.getMessage(globalError, false);
/*     */         
/* 157 */         DetailedError errorObject = new DetailedError(globalError.getCode(), globalError.getArguments(), message);
/* 158 */         if (errorObjects == null) {
/* 159 */           errorObjects = new ArrayList(errors.getErrorCount() + 2);
/*     */         }
/* 161 */         errorObjects.add(errorObject);
/*     */       }
/*     */     }
/*     */     
/* 165 */     if (bindExpression != null) {
/* 166 */       List<FieldError> fieldErrors = errors.getFieldErrors(bindStatus.getExpression());
/* 167 */       for (FieldError fieldError : fieldErrors) {
/* 168 */         String message = requestContext.getMessage(fieldError, false);
/*     */         
/* 170 */         DetailedError errorObject = new DetailedError(fieldError.getField(), fieldError.getCode(), fieldError.getArguments(), message);
/* 171 */         if (errorObjects == null) {
/* 172 */           errorObjects = new ArrayList(errors.getErrorCount() + 2);
/*     */         }
/* 174 */         errorObjects.add(errorObject);
/*     */       }
/*     */     }
/*     */     
/* 178 */     if (errorObjects == null) {
/* 179 */       return Collections.EMPTY_LIST;
/*     */     }
/* 181 */     return errorObjects;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String idFromName(String fieldName)
/*     */   {
/* 188 */     return StringUtils.deleteAny(fieldName, "[]");
/*     */   }
/*     */   
/*     */ 
/*     */   private static String convertToFieldExpression(String field)
/*     */   {
/* 194 */     if (field == null) {
/* 195 */       return null;
/*     */     }
/* 197 */     String trimmedField = field.trim();
/* 198 */     if (trimmedField.length() == 0) {
/* 199 */       return null;
/*     */     }
/* 201 */     char firstc = trimmedField.charAt(0);
/* 202 */     if ((firstc == '*') || (firstc == '$')) {
/* 203 */       return field;
/*     */     }
/* 205 */     return "*{" + field + "}";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static boolean checkErrors(IExpressionContext context, String expression)
/*     */   {
/* 212 */     IThymeleafBindStatus bindStatus = getBindStatus(context, expression);
/* 213 */     if (bindStatus == null) {
/* 214 */       throw new TemplateProcessingException("Could not bind form errors using expression \"" + expression + "\". Please check this expression is being executed inside the adequate context (e.g. a <form> with a th:object attribute)");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 219 */     return bindStatus.isError();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IThymeleafBindStatus getBindStatus(IExpressionContext context, String expression)
/*     */   {
/* 227 */     return getBindStatus(context, false, expression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IThymeleafBindStatus getBindStatus(IExpressionContext context, boolean optional, String expression)
/*     */   {
/* 235 */     Validate.notNull(expression, "Expression cannot be null");
/*     */     
/* 237 */     if (("global".equals(expression)) || ("all".equals(expression)) || ("*".equals(expression)))
/*     */     {
/* 239 */       String completeExpression = "*{" + expression + "}";
/* 240 */       return getBindStatus(context, optional, completeExpression);
/*     */     }
/*     */     
/* 243 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(context.getConfiguration());
/* 244 */     IStandardExpression expressionObj = expressionParser.parseExpression(context, expression);
/*     */     
/* 246 */     if (expressionObj == null) {
/* 247 */       throw new TemplateProcessingException("Expression \"" + expression + "\" is not valid: cannot perform Spring bind");
/*     */     }
/*     */     
/*     */ 
/* 251 */     if ((expressionObj instanceof SelectionVariableExpression)) {
/* 252 */       String bindExpression = ((SelectionVariableExpression)expressionObj).getExpression();
/* 253 */       return getBindStatusFromParsedExpression(context, optional, true, bindExpression);
/*     */     }
/*     */     
/* 256 */     if ((expressionObj instanceof VariableExpression)) {
/* 257 */       String bindExpression = ((VariableExpression)expressionObj).getExpression();
/* 258 */       return getBindStatusFromParsedExpression(context, optional, false, bindExpression);
/*     */     }
/*     */     
/* 261 */     throw new TemplateProcessingException("Expression \"" + expression + "\" is not valid: only variable expressions ${...} or selection expressions *{...} are allowed in Spring field bindings");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IThymeleafBindStatus getBindStatusFromParsedExpression(IExpressionContext context, boolean useSelectionAsRoot, String expression)
/*     */   {
/* 273 */     return getBindStatusFromParsedExpression(context, false, useSelectionAsRoot, expression);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IThymeleafBindStatus getBindStatusFromParsedExpression(IExpressionContext context, boolean optional, boolean useSelectionAsRoot, String expression)
/*     */   {
/* 292 */     IThymeleafRequestContext requestContext = SpringContextUtils.getRequestContext(context);
/* 293 */     if (requestContext == null) {
/* 294 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 298 */     String completeExpression = validateAndGetValueExpression(context, useSelectionAsRoot, expression);
/*     */     
/* 300 */     if (completeExpression == null) {
/* 301 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 305 */     if (!optional) {
/* 306 */       return requestContext.getBindStatus(completeExpression, false);
/*     */     }
/*     */     
/*     */ 
/* 310 */     if (isBound(requestContext, completeExpression))
/*     */     {
/*     */       try
/*     */       {
/* 314 */         return requestContext.getBindStatus(completeExpression, false);
/*     */       } catch (NotReadablePropertyException ignored) {
/* 316 */         return null;
/*     */       }
/*     */     }
/*     */     
/* 320 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String validateAndGetValueExpression(IExpressionContext context, boolean useSelectionAsRoot, String expression)
/*     */   {
/* 334 */     if (useSelectionAsRoot)
/*     */     {
/*     */ 
/* 337 */       VariableExpression boundObjectValue = (VariableExpression)context.getVariable("springBoundObjectExpression");
/*     */       
/*     */ 
/* 340 */       String boundObjectExpression = boundObjectValue == null ? null : boundObjectValue.getExpression();
/*     */       
/* 342 */       if ("global".equals(expression))
/*     */       {
/* 344 */         if (boundObjectExpression == null) {
/* 345 */           return null;
/*     */         }
/* 347 */         return boundObjectExpression;
/*     */       }
/* 349 */       if (("all".equals(expression)) || ("*".equals(expression)))
/*     */       {
/* 351 */         if (boundObjectExpression == null) {
/* 352 */           return null;
/*     */         }
/* 354 */         return boundObjectExpression + "." + "*";
/*     */       }
/*     */       
/* 357 */       if (boundObjectExpression == null) {
/* 358 */         return expression;
/*     */       }
/*     */       
/* 361 */       return boundObjectExpression + "." + expression;
/*     */     }
/*     */     
/*     */ 
/* 365 */     return expression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isBound(IThymeleafRequestContext requestContext, String completeExpression)
/*     */   {
/* 374 */     int dotPos = completeExpression.indexOf('.');
/* 375 */     if (dotPos == -1) {
/* 376 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 380 */     String beanName = completeExpression.substring(0, dotPos);
/*     */     
/*     */ 
/* 383 */     boolean beanValid = requestContext.getErrors(beanName, false).isPresent();
/* 384 */     if ((beanValid) && (completeExpression.length() > dotPos)) {
/* 385 */       String path = completeExpression.substring(dotPos + 1, completeExpression.length());
/*     */       
/* 387 */       return validateBeanPath(path);
/*     */     }
/* 389 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean validateBeanPath(CharSequence path)
/*     */   {
/* 399 */     int pathLen = path.length();
/* 400 */     boolean inKey = false;
/* 401 */     for (int charPos = 0; charPos < pathLen; charPos++) {
/* 402 */       char c = path.charAt(charPos);
/* 403 */       if ((!inKey) && (c == '[')) {
/* 404 */         inKey = true;
/*     */       }
/* 406 */       else if ((inKey) && (c == ']')) {
/* 407 */         inKey = false;
/*     */       }
/* 409 */       else if ((!inKey) && (!Character.isJavaIdentifierPart(c)) && (c != '.')) {
/* 410 */         return false;
/*     */       }
/*     */     }
/* 413 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\util\FieldUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */