/*    */ package org.thymeleaf.spring5.processor;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.standard.expression.IStandardExpression;
/*    */ import org.thymeleaf.standard.expression.VariableExpression;
/*    */ import org.thymeleaf.standard.processor.AbstractStandardTargetSelectionTagProcessor;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringObjectTagProcessor
/*    */   extends AbstractStandardTargetSelectionTagProcessor
/*    */ {
/*    */   public static final int ATTR_PRECEDENCE = 500;
/*    */   public static final String ATTR_NAME = "object";
/*    */   
/*    */   public SpringObjectTagProcessor(String dialectPrefix)
/*    */   {
/* 51 */     super(TemplateMode.HTML, dialectPrefix, "object", 500);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void validateSelectionValue(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IStandardExpression expression)
/*    */   {
/* 66 */     if ((expression == null) || (!(expression instanceof VariableExpression)))
/*    */     {
/* 68 */       throw new TemplateProcessingException("The expression used for object selection is " + expression + ", which is not valid: only variable expressions (${...}) are allowed in '" + attributeName + "' attributes in Spring-enabled environments.");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Map<String, Object> computeAdditionalLocalVariables(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IStandardExpression expression)
/*    */   {
/* 90 */     return Collections.singletonMap("springBoundObjectExpression", expression);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringObjectTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */