package org.thymeleaf.spring5.context;

import java.beans.PropertyEditor;
import org.springframework.validation.Errors;

public abstract interface IThymeleafBindStatus
{
  public abstract String getPath();
  
  public abstract String getExpression();
  
  public abstract Object getValue();
  
  public abstract Class<?> getValueType();
  
  public abstract Object getActualValue();
  
  public abstract String getDisplayValue();
  
  public abstract boolean isError();
  
  public abstract String[] getErrorCodes();
  
  public abstract String getErrorCode();
  
  public abstract String[] getErrorMessages();
  
  public abstract String getErrorMessage();
  
  public abstract String getErrorMessagesAsString(String paramString);
  
  public abstract Errors getErrors();
  
  public abstract PropertyEditor getEditor();
  
  public abstract PropertyEditor findEditor(Class<?> paramClass);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\IThymeleafBindStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */