/*    */ package org.thymeleaf.spring5.util;
/*    */ 
/*    */ import java.beans.PropertyEditor;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ import org.springframework.web.util.HtmlUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringValueFormatter
/*    */ {
/*    */   public static String getDisplayString(Object value, boolean htmlEscape)
/*    */   {
/* 51 */     String displayValue = ObjectUtils.getDisplayString(value);
/* 52 */     return htmlEscape ? HtmlUtils.htmlEscape(displayValue) : displayValue;
/*    */   }
/*    */   
/*    */   public static String getDisplayString(Object value, PropertyEditor propertyEditor, boolean htmlEscape)
/*    */   {
/* 57 */     if ((propertyEditor != null) && (!(value instanceof String))) {
/*    */       try {
/* 59 */         propertyEditor.setValue(value);
/* 60 */         String text = propertyEditor.getAsText();
/* 61 */         if (text != null) {
/* 62 */           return getDisplayString(text, htmlEscape);
/*    */         }
/*    */       }
/*    */       catch (Throwable localThrowable) {}
/*    */     }
/*    */     
/* 68 */     return getDisplayString(value, htmlEscape);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\util\SpringValueFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */