/*    */ package org.thymeleaf.spring5.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*    */ import org.thymeleaf.spring5.requestdata.RequestDataValueProcessorUtils;
/*    */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringInputPasswordFieldTagProcessor
/*    */   extends AbstractSpringFieldTagProcessor
/*    */ {
/*    */   public static final String PASSWORD_INPUT_TYPE_ATTR_VALUE = "password";
/*    */   
/*    */   public SpringInputPasswordFieldTagProcessor(String dialectPrefix)
/*    */   {
/* 49 */     super(dialectPrefix, "input", "type", new String[] { "password" }, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IThymeleafBindStatus bindStatus, IElementTagStructureHandler structureHandler)
/*    */   {
/* 61 */     String name = bindStatus.getExpression();
/* 62 */     name = name == null ? "" : name;
/*    */     
/* 64 */     String id = computeId(context, tag, name, false);
/*    */     
/* 66 */     StandardProcessorUtils.setAttribute(structureHandler, this.idAttributeDefinition, "id", id);
/* 67 */     StandardProcessorUtils.setAttribute(structureHandler, this.nameAttributeDefinition, "name", name);
/*    */     
/* 69 */     StandardProcessorUtils.setAttribute(structureHandler, this.valueAttributeDefinition, "value", 
/* 70 */       RequestDataValueProcessorUtils.processFormFieldValue(context, name, "", "password"));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringInputPasswordFieldTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */