/*    */ package org.thymeleaf.spring5.context.webflux;
/*    */ 
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.ReactiveAdapter;
/*    */ import org.springframework.core.ReactiveAdapterRegistry;
/*    */ import org.thymeleaf.spring5.view.reactive.ThymeleafReactiveView;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReactiveContextVariableUtils
/*    */ {
/*    */   static Publisher<Object> computePublisherValue(Object asyncObj, ReactiveAdapterRegistry reactiveAdapterRegistry)
/*    */   {
/* 66 */     if (((asyncObj instanceof Flux)) || ((asyncObj instanceof Mono)))
/*    */     {
/*    */ 
/*    */ 
/* 70 */       return (Publisher)asyncObj;
/*    */     }
/*    */     
/*    */ 
/* 74 */     if (reactiveAdapterRegistry == null)
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 83 */       throw new IllegalArgumentException("Could not initialize lazy reactive context variable (data driver or explicitly-set reactive wrapper):  Value is of class " + asyncObj.getClass().getName() + ", but no ReactiveAdapterRegistry has been set. This can happen if this context variable is used for rendering a template without going through a " + ThymeleafReactiveView.class.getSimpleName() + " or if there is no ReactiveAdapterRegistry bean registered at the application context. In such cases, it is required that the wrapped lazy variable values are instances of either " + Flux.class.getName() + " or " + Mono.class.getName() + ".");
/*    */     }
/*    */     
/* 86 */     ReactiveAdapter adapter = reactiveAdapterRegistry.getAdapter(null, asyncObj);
/* 87 */     if (adapter != null) {
/* 88 */       Publisher<Object> publisher = adapter.toPublisher(asyncObj);
/* 89 */       if (adapter.isMultiValue()) {
/* 90 */         return Flux.from(publisher);
/*    */       }
/* 92 */       return Mono.from(publisher);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 98 */     throw new IllegalArgumentException("Reactive context variable (data driver or explicitly-set reactive wrapper) is of class " + asyncObj.getClass().getName() + ", but the ReactiveAdapterRegistry does not contain a valid adapter able to convert it into a supported reactive data stream.");
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\webflux\ReactiveContextVariableUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */