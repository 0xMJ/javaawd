/*    */ package org.thymeleaf.spring5.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeDefinition;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*    */ import org.thymeleaf.spring5.requestdata.RequestDataValueProcessorUtils;
/*    */ import org.thymeleaf.spring5.util.SpringSelectedValueComparator;
/*    */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*    */ import org.unbescape.html.HtmlEscape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringOptionFieldTagProcessor
/*    */   extends AbstractSpringFieldTagProcessor
/*    */ {
/*    */   public SpringOptionFieldTagProcessor(String dialectPrefix)
/*    */   {
/* 47 */     super(dialectPrefix, "option", null, null, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IThymeleafBindStatus bindStatus, IElementTagStructureHandler structureHandler)
/*    */   {
/* 58 */     String name = bindStatus.getExpression();
/* 59 */     name = name == null ? "" : name;
/*    */     
/* 61 */     String value = tag.getAttributeValue(this.valueAttributeDefinition.getAttributeName());
/* 62 */     if (value == null) {
/* 63 */       throw new TemplateProcessingException("Attribute \"value\" is required in \"option\" tags");
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 68 */     boolean selected = SpringSelectedValueComparator.isSelected(bindStatus, HtmlEscape.unescapeHtml(value));
/*    */     
/* 70 */     StandardProcessorUtils.setAttribute(structureHandler, this.valueAttributeDefinition, "value", 
/*    */     
/*    */ 
/* 73 */       RequestDataValueProcessorUtils.processFormFieldValue(context, name, value, "option"));
/*    */     
/* 75 */     if (selected) {
/* 76 */       StandardProcessorUtils.setAttribute(structureHandler, this.selectedAttributeDefinition, "selected", "selected");
/*    */     } else {
/* 78 */       structureHandler.removeAttribute(this.selectedAttributeDefinition.getAttributeName());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringOptionFieldTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */