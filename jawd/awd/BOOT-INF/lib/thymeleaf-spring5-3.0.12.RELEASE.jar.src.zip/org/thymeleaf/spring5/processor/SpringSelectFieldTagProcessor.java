/*     */ package org.thymeleaf.spring5.processor;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeDefinition;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.model.IModelFactory;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*     */ import org.thymeleaf.spring5.requestdata.RequestDataValueProcessorUtils;
/*     */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringSelectFieldTagProcessor
/*     */   extends AbstractSpringFieldTagProcessor
/*     */ {
/*     */   static final String OPTION_IN_SELECT_ATTR_NAME = "%%OPTION_IN_SELECT_ATTR_NAME%%";
/*     */   static final String OPTION_IN_SELECT_ATTR_VALUE = "%%OPTION_IN_SELECT_ATTR_VALUE%%";
/*     */   
/*     */   public SpringSelectFieldTagProcessor(String dialectPrefix)
/*     */   {
/*  55 */     super(dialectPrefix, "select", null, null, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IThymeleafBindStatus bindStatus, IElementTagStructureHandler structureHandler)
/*     */   {
/*  66 */     String name = bindStatus.getExpression();
/*  67 */     name = name == null ? "" : name;
/*     */     
/*  69 */     String id = computeId(context, tag, name, false);
/*     */     
/*  71 */     boolean multiple = tag.hasAttribute(this.multipleAttributeDefinition.getAttributeName());
/*     */     
/*  73 */     StandardProcessorUtils.setAttribute(structureHandler, this.idAttributeDefinition, "id", id);
/*  74 */     StandardProcessorUtils.setAttribute(structureHandler, this.nameAttributeDefinition, "name", name);
/*     */     
/*  76 */     structureHandler.setLocalVariable("%%OPTION_IN_SELECT_ATTR_NAME%%", attributeName);
/*  77 */     structureHandler.setLocalVariable("%%OPTION_IN_SELECT_ATTR_VALUE%%", attributeValue);
/*     */     
/*  79 */     if ((multiple) && (!isDisabled(tag)))
/*     */     {
/*  81 */       IModelFactory modelFactory = context.getModelFactory();
/*     */       
/*  83 */       IModel hiddenMethodElementModel = modelFactory.createModel();
/*     */       
/*  85 */       String hiddenName = "_" + name;
/*  86 */       String type = "hidden";
/*     */       
/*  88 */       String value = RequestDataValueProcessorUtils.processFormFieldValue(context, hiddenName, "1", "hidden");
/*     */       
/*  90 */       Map<String, String> hiddenAttributes = new LinkedHashMap(4, 1.0F);
/*  91 */       hiddenAttributes.put("type", "hidden");
/*  92 */       hiddenAttributes.put("name", hiddenName);
/*  93 */       hiddenAttributes.put("value", value);
/*     */       
/*     */ 
/*  96 */       IStandaloneElementTag hiddenElementTag = modelFactory.createStandaloneElementTag("input", hiddenAttributes, AttributeValueQuotes.DOUBLE, false, true);
/*     */       
/*  98 */       hiddenMethodElementModel.add(hiddenElementTag);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 103 */       structureHandler.insertBefore(hiddenMethodElementModel);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean isDisabled(IProcessableElementTag tag)
/*     */   {
/* 113 */     return tag.hasAttribute(this.disabledAttributeDefinition.getAttributeName());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringSelectFieldTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */