/*     */ package org.thymeleaf.spring5.webflow.view;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.webflow.context.servlet.AjaxHandler;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ import org.thymeleaf.spring5.view.ThymeleafView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AjaxThymeleafView
/*     */   extends ThymeleafView
/*     */   implements AjaxEnabledView
/*     */ {
/*  61 */   private static final Logger vlogger = LoggerFactory.getLogger(AjaxThymeleafView.class);
/*     */   
/*     */ 
/*     */   private static final String FRAGMENTS_PARAM = "fragments";
/*     */   
/*  66 */   private AjaxHandler ajaxHandler = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AjaxHandler getAjaxHandler()
/*     */   {
/*  77 */     return this.ajaxHandler;
/*     */   }
/*     */   
/*     */   public void setAjaxHandler(AjaxHandler ajaxHandler)
/*     */   {
/*  82 */     this.ajaxHandler = ajaxHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void render(Map<String, ?> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*  93 */     AjaxHandler templateAjaxHandler = getAjaxHandler();
/*     */     
/*  95 */     if (templateAjaxHandler == null)
/*     */     {
/*     */ 
/*  98 */       throw new ConfigurationException("[THYMELEAF] AJAX Handler set into " + AjaxThymeleafView.class.getSimpleName() + " instance for template " + getTemplateName() + " is null.");
/*     */     }
/*     */     
/* 101 */     if (templateAjaxHandler.isAjaxRequest(request, response))
/*     */     {
/* 103 */       Set<String> fragmentsToRender = getRenderFragments(model, request, response);
/* 104 */       if ((fragmentsToRender == null) || (fragmentsToRender.size() == 0)) {
/* 105 */         vlogger.warn("[THYMELEAF] An Ajax request was detected, but no fragments were specified to be re-rendered.  Falling back to full page render.  This can cause unpredictable results when processing the ajax response on the client.");
/*     */         
/*     */ 
/* 108 */         super.render(model, request, response);
/* 109 */         return;
/*     */       }
/*     */       
/* 112 */       super.renderFragment(fragmentsToRender, model, request, response);
/*     */     }
/*     */     else
/*     */     {
/* 116 */       super.render(model, request, response);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Set<String> getRenderFragments(Map model, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 128 */     String fragmentsParam = request.getParameter("fragments");
/* 129 */     String[] renderFragments = StringUtils.commaDelimitedListToStringArray(fragmentsParam);
/* 130 */     if (renderFragments.length == 0) {
/* 131 */       return null;
/*     */     }
/* 133 */     if (renderFragments.length == 1) {
/* 134 */       return Collections.singleton(renderFragments[0]);
/*     */     }
/* 136 */     return new HashSet(Arrays.asList(renderFragments));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\webflow\view\AjaxThymeleafView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */