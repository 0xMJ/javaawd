/*    */ package org.thymeleaf.spring5.context.webflux;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.web.reactive.result.view.RequestDataValueProcessor;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ import org.thymeleaf.spring5.context.IThymeleafRequestDataValueProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpringWebFluxThymeleafRequestDataValueProcessor
/*    */   implements IThymeleafRequestDataValueProcessor
/*    */ {
/*    */   private final RequestDataValueProcessor requestDataValueProcessor;
/*    */   private final ServerWebExchange exchange;
/*    */   
/*    */   SpringWebFluxThymeleafRequestDataValueProcessor(RequestDataValueProcessor requestDataValueProcessor, ServerWebExchange exchange)
/*    */   {
/* 49 */     this.requestDataValueProcessor = requestDataValueProcessor;
/* 50 */     this.exchange = exchange;
/*    */   }
/*    */   
/*    */   public String processAction(String action, String httpMethod)
/*    */   {
/* 55 */     if (this.requestDataValueProcessor == null)
/*    */     {
/* 57 */       return action;
/*    */     }
/* 59 */     return this.requestDataValueProcessor.processAction(this.exchange, action, httpMethod);
/*    */   }
/*    */   
/*    */   public String processFormFieldValue(String name, String value, String type)
/*    */   {
/* 64 */     if (this.requestDataValueProcessor == null)
/*    */     {
/* 66 */       return value;
/*    */     }
/* 68 */     return this.requestDataValueProcessor.processFormFieldValue(this.exchange, name, value, type);
/*    */   }
/*    */   
/*    */   public Map<String, String> getExtraHiddenFields()
/*    */   {
/* 73 */     if (this.requestDataValueProcessor == null)
/*    */     {
/* 75 */       return null;
/*    */     }
/* 77 */     return this.requestDataValueProcessor.getExtraHiddenFields(this.exchange);
/*    */   }
/*    */   
/*    */   public String processUrl(String url)
/*    */   {
/* 82 */     if (this.requestDataValueProcessor == null)
/*    */     {
/* 84 */       return url;
/*    */     }
/* 86 */     return this.requestDataValueProcessor.processUrl(this.exchange, url);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\webflux\SpringWebFluxThymeleafRequestDataValueProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */