/*     */ package org.thymeleaf.spring5.util;
/*     */ 
/*     */ import org.springframework.core.SpringVersion;
/*     */ import org.thymeleaf.util.ClassLoaderUtils;
/*     */ import org.thymeleaf.util.VersionUtils;
/*     */ import org.thymeleaf.util.VersionUtils.VersionSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringVersionUtils
/*     */ {
/*     */   private static final VersionUtils.VersionSpec SPRING_VERSION_SPEC;
/*     */   private static final boolean SPRING_WEB_MVC_PRESENT;
/*     */   private static final boolean SPRING_WEB_REACTIVE_PRESENT;
/*     */   
/*     */   static
/*     */   {
/*  47 */     String springVersion = SpringVersion.getVersion();
/*     */     
/*     */ 
/*     */ 
/*  51 */     String corePackageName = SpringVersion.class.getPackage().getName();
/*  52 */     String springPackageName = corePackageName.substring(0, corePackageName.length() - 5);
/*     */     
/*     */ 
/*  55 */     if (springVersion != null)
/*     */     {
/*  57 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion(springVersion);
/*     */       
/*  59 */       if (SPRING_VERSION_SPEC.isUnknown()) {
/*  60 */         throw new ExceptionInInitializerError("Exception during initialization of Spring versioning utilities. Identified Spring version is '" + springVersion + "', which does not follow the {major}.{minor}.{patch}[.{...}] scheme");
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */     }
/*  68 */     else if (ClassLoaderUtils.isClassPresent(springPackageName + ".core.io.buffer.DataBuffer")) {
/*  69 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("5.0.0.RELEASE");
/*  70 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".context.annotation.ComponentScans")) {
/*  71 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("4.3.0.RELEASE");
/*  72 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".core.annotation.AliasFor")) {
/*  73 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("4.2.0.RELEASE");
/*  74 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".cache.annotation.CacheConfig")) {
/*  75 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("4.1.0.RELEASE");
/*  76 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".core.io.PathResource")) {
/*  77 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("4.0.0.RELEASE");
/*  78 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".web.context.request.async.DeferredResult")) {
/*  79 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("3.2.0.RELEASE");
/*  80 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".web.servlet.support.RequestDataValueProcessor")) {
/*  81 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("3.1.0.RELEASE");
/*  82 */     } else if (ClassLoaderUtils.isClassPresent(springPackageName + ".web.bind.annotation.RequestBody")) {
/*  83 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("3.0.0.RELEASE");
/*     */     }
/*     */     else {
/*  86 */       SPRING_VERSION_SPEC = VersionUtils.parseVersion("2.5.0.RELEASE");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  92 */     SPRING_WEB_MVC_PRESENT = ClassLoaderUtils.isClassPresent(springPackageName + ".web.servlet.View");
/*     */     
/*  94 */     SPRING_WEB_REACTIVE_PRESENT = (SPRING_VERSION_SPEC.isAtLeast(5)) && (ClassLoaderUtils.isClassPresent(springPackageName + ".web.reactive.result.view.View"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String getSpringVersion()
/*     */   {
/* 101 */     return SPRING_VERSION_SPEC.getVersion();
/*     */   }
/*     */   
/*     */   public static int getSpringVersionMajor() {
/* 105 */     return SPRING_VERSION_SPEC.getMajor();
/*     */   }
/*     */   
/*     */   public static int getSpringVersionMinor() {
/* 109 */     return SPRING_VERSION_SPEC.getMinor();
/*     */   }
/*     */   
/*     */   public static int getSpringVersionPatch() {
/* 113 */     return SPRING_VERSION_SPEC.getPatch();
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean isSpring30AtLeast()
/*     */   {
/* 119 */     return isSpringAtLeast(3, 0);
/*     */   }
/*     */   
/*     */   public static boolean isSpring31AtLeast()
/*     */   {
/* 124 */     return isSpringAtLeast(3, 1);
/*     */   }
/*     */   
/*     */   public static boolean isSpring32AtLeast()
/*     */   {
/* 129 */     return isSpringAtLeast(3, 2);
/*     */   }
/*     */   
/*     */   public static boolean isSpring40AtLeast()
/*     */   {
/* 134 */     return isSpringAtLeast(4, 0);
/*     */   }
/*     */   
/*     */   public static boolean isSpring41AtLeast()
/*     */   {
/* 139 */     return isSpringAtLeast(4, 1);
/*     */   }
/*     */   
/*     */   public static boolean isSpring42AtLeast()
/*     */   {
/* 144 */     return isSpringAtLeast(4, 2);
/*     */   }
/*     */   
/*     */   public static boolean isSpring43AtLeast()
/*     */   {
/* 149 */     return isSpringAtLeast(4, 3);
/*     */   }
/*     */   
/*     */   public static boolean isSpring50AtLeast()
/*     */   {
/* 154 */     return isSpringAtLeast(5, 0);
/*     */   }
/*     */   
/*     */   public static boolean isSpring51AtLeast()
/*     */   {
/* 159 */     return isSpringAtLeast(5, 1);
/*     */   }
/*     */   
/*     */   public static boolean isSpring52AtLeast()
/*     */   {
/* 164 */     return isSpringAtLeast(5, 2);
/*     */   }
/*     */   
/*     */   public static boolean isSpring53AtLeast()
/*     */   {
/* 169 */     return isSpringAtLeast(5, 3);
/*     */   }
/*     */   
/*     */   public static boolean isSpringAtLeast(int major, int minor)
/*     */   {
/* 174 */     return isSpringAtLeast(major, minor, 0);
/*     */   }
/*     */   
/*     */   public static boolean isSpringAtLeast(int major, int minor, int patch)
/*     */   {
/* 179 */     return SPRING_VERSION_SPEC.isAtLeast(major, minor, patch);
/*     */   }
/*     */   
/*     */   public static boolean isSpringWebMvcPresent()
/*     */   {
/* 184 */     return SPRING_WEB_MVC_PRESENT;
/*     */   }
/*     */   
/*     */   public static boolean isSpringWebFluxPresent()
/*     */   {
/* 189 */     return SPRING_WEB_REACTIVE_PRESENT;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\util\SpringVersionUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */