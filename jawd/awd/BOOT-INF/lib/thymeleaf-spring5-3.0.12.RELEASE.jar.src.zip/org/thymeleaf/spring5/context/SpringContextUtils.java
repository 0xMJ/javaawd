/*     */ package org.thymeleaf.spring5.context;
/*     */ 
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.spring5.expression.IThymeleafEvaluationContext;
/*     */ import org.thymeleaf.spring5.expression.ThymeleafEvaluationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringContextUtils
/*     */ {
/*     */   public static final String WEB_SESSION_ATTRIBUTE_NAME = "thymeleafWebSession";
/*     */   
/*     */   public static ApplicationContext getApplicationContext(ITemplateContext context)
/*     */   {
/*  79 */     if (context == null) {
/*  80 */       return null;
/*     */     }
/*     */     
/*     */ 
/*  84 */     IThymeleafEvaluationContext evaluationContext = (IThymeleafEvaluationContext)context.getVariable("thymeleaf::EvaluationContext");
/*  85 */     if ((evaluationContext == null) || (!(evaluationContext instanceof ThymeleafEvaluationContext))) {
/*  86 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     return ((ThymeleafEvaluationContext)evaluationContext).getApplicationContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IThymeleafRequestContext getRequestContext(IExpressionContext context)
/*     */   {
/* 115 */     if (context == null) {
/* 116 */       return null;
/*     */     }
/* 118 */     return (IThymeleafRequestContext)context.getVariable("thymeleafRequestContext");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\SpringContextUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */