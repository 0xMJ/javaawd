/*     */ package org.thymeleaf.spring5.expression;
/*     */ 
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.expression.BeanFactoryResolver;
/*     */ import org.springframework.context.expression.MapAccessor;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.expression.spel.support.StandardTypeConverter;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ import org.thymeleaf.standard.expression.RestrictedRequestAccessUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ThymeleafEvaluationContext
/*     */   extends StandardEvaluationContext
/*     */   implements IThymeleafEvaluationContext
/*     */ {
/*     */   public static final String THYMELEAF_EVALUATION_CONTEXT_CONTEXT_VARIABLE_NAME = "thymeleaf::EvaluationContext";
/*  68 */   private static final MapAccessor MAP_ACCESSOR_INSTANCE = new MapAccessor();
/*     */   
/*     */ 
/*     */   private final ApplicationContext applicationContext;
/*     */   
/*  73 */   private IExpressionObjects expressionObjects = null;
/*  74 */   private boolean variableAccessRestricted = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ThymeleafEvaluationContext(ApplicationContext applicationContext, ConversionService conversionService)
/*     */   {
/*  83 */     Validate.notNull(applicationContext, "Application Context cannot be null");
/*     */     
/*     */ 
/*  86 */     this.applicationContext = applicationContext;
/*  87 */     setBeanResolver(new BeanFactoryResolver(applicationContext));
/*  88 */     if (conversionService != null) {
/*  89 */       setTypeConverter(new StandardTypeConverter(conversionService));
/*     */     }
/*     */     
/*  92 */     addPropertyAccessor(SPELContextPropertyAccessor.INSTANCE);
/*  93 */     addPropertyAccessor(MAP_ACCESSOR_INSTANCE);
/*     */   }
/*     */   
/*     */ 
/*     */   public ApplicationContext getApplicationContext()
/*     */   {
/*  99 */     return this.applicationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object lookupVariable(String name)
/*     */   {
/* 106 */     if ((this.expressionObjects != null) && (this.expressionObjects.containsObject(name)))
/*     */     {
/* 108 */       Object result = this.expressionObjects.getObject(name);
/* 109 */       if (result != null)
/*     */       {
/*     */ 
/* 112 */         if ((this.variableAccessRestricted) && (
/* 113 */           ("request".equals(name)) || 
/* 114 */           ("httpServletRequest".equals(name)))) {
/* 115 */           return RestrictedRequestAccessUtils.wrapRequestObject(result);
/*     */         }
/*     */         
/* 118 */         return result;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 125 */     return super.lookupVariable(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isVariableAccessRestricted()
/*     */   {
/* 133 */     return this.variableAccessRestricted;
/*     */   }
/*     */   
/*     */   public void setVariableAccessRestricted(boolean restricted) {
/* 137 */     this.variableAccessRestricted = restricted;
/*     */   }
/*     */   
/*     */   public IExpressionObjects getExpressionObjects() {
/* 141 */     return this.expressionObjects;
/*     */   }
/*     */   
/*     */   public void setExpressionObjects(IExpressionObjects expressionObjects) {
/* 145 */     this.expressionObjects = expressionObjects;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\expression\ThymeleafEvaluationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */