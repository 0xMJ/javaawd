package org.thymeleaf.spring5.context;

import java.util.Map;

public abstract interface IThymeleafRequestDataValueProcessor
{
  public abstract String processAction(String paramString1, String paramString2);
  
  public abstract String processFormFieldValue(String paramString1, String paramString2, String paramString3);
  
  public abstract Map<String, String> getExtraHiddenFields();
  
  public abstract String processUrl(String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\IThymeleafRequestDataValueProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */