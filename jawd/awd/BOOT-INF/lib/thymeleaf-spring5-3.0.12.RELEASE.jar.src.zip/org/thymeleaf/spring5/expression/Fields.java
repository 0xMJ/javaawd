/*     */ package org.thymeleaf.spring5.expression;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.spring5.util.DetailedError;
/*     */ import org.thymeleaf.spring5.util.FieldUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Fields
/*     */ {
/*     */   private final IExpressionContext context;
/*     */   
/*     */   public boolean hasAnyErrors()
/*     */   {
/*  50 */     return FieldUtils.hasAnyErrors(this.context);
/*     */   }
/*     */   
/*     */   public boolean hasErrors() {
/*  54 */     return FieldUtils.hasAnyErrors(this.context);
/*     */   }
/*     */   
/*     */   public boolean hasErrors(String field) {
/*  58 */     return FieldUtils.hasErrors(this.context, field);
/*     */   }
/*     */   
/*     */   public boolean hasGlobalErrors() {
/*  62 */     return FieldUtils.hasGlobalErrors(this.context);
/*     */   }
/*     */   
/*     */   public List<String> allErrors() {
/*  66 */     return FieldUtils.errors(this.context);
/*     */   }
/*     */   
/*     */   public List<String> errors() {
/*  70 */     return FieldUtils.errors(this.context);
/*     */   }
/*     */   
/*     */   public List<String> errors(String field) {
/*  74 */     return FieldUtils.errors(this.context, field);
/*     */   }
/*     */   
/*     */   public List<String> globalErrors() {
/*  78 */     return FieldUtils.globalErrors(this.context);
/*     */   }
/*     */   
/*     */   public String idFromName(String fieldName)
/*     */   {
/*  83 */     return FieldUtils.idFromName(fieldName);
/*     */   }
/*     */   
/*     */ 
/*     */   public List<DetailedError> allDetailedErrors()
/*     */   {
/*  89 */     return FieldUtils.detailedErrors(this.context);
/*     */   }
/*     */   
/*     */   public List<DetailedError> detailedErrors() {
/*  93 */     return FieldUtils.detailedErrors(this.context);
/*     */   }
/*     */   
/*     */   public List<DetailedError> detailedErrors(String field) {
/*  97 */     return FieldUtils.detailedErrors(this.context, field);
/*     */   }
/*     */   
/*     */   public List<DetailedError> globalDetailedErrors() {
/* 101 */     return FieldUtils.globalDetailedErrors(this.context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Fields(IExpressionContext context)
/*     */   {
/* 108 */     this.context = context;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\expression\Fields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */