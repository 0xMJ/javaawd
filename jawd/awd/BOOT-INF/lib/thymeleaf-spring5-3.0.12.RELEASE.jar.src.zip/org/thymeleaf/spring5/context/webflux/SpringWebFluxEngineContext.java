/*     */ package org.thymeleaf.spring5.context.webflux;
/*     */ 
/*     */ import java.util.AbstractList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebSession;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.AbstractEngineContext;
/*     */ import org.thymeleaf.context.EngineContext;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.context.ILazyContextVariable;
/*     */ import org.thymeleaf.engine.TemplateData;
/*     */ import org.thymeleaf.inline.IInliner;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringWebFluxEngineContext
/*     */   extends AbstractEngineContext
/*     */   implements IEngineContext, ISpringWebFluxContext
/*     */ {
/*     */   private static final String PARAM_VARIABLE_NAME = "param";
/*     */   private static final String SESSION_VARIABLE_NAME = "session";
/*     */   private final ServerHttpRequest request;
/*     */   private final ServerHttpResponse response;
/*     */   private final ServerWebExchange exchange;
/*     */   private final WebExchangeAttributesVariablesMap webExchangeAttributesVariablesMap;
/*     */   private final Map<String, Object> requestParametersVariablesMap;
/*     */   private final Map<String, Object> sessionAttributesVariablesMap;
/*     */   
/*     */   public SpringWebFluxEngineContext(IEngineConfiguration configuration, TemplateData templateData, Map<String, Object> templateResolutionAttributes, ServerWebExchange exchange, Locale locale, Map<String, Object> variables)
/*     */   {
/* 113 */     super(configuration, templateResolutionAttributes, locale);
/*     */     
/* 115 */     Validate.notNull(exchange, "Server Web Exchange cannot be null in web variables map");
/*     */     
/* 117 */     this.exchange = exchange;
/* 118 */     this.request = this.exchange.getRequest();
/* 119 */     this.response = this.exchange.getResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     this.webExchangeAttributesVariablesMap = new WebExchangeAttributesVariablesMap(configuration, templateData, templateResolutionAttributes, this.exchange, locale, variables);
/*     */     
/* 127 */     this.requestParametersVariablesMap = new RequestParametersMap(this.request);
/* 128 */     this.sessionAttributesVariablesMap = new SessionAttributesMap(this.webExchangeAttributesVariablesMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ServerHttpRequest getRequest()
/*     */   {
/* 136 */     return this.request;
/*     */   }
/*     */   
/*     */ 
/*     */   public ServerHttpResponse getResponse()
/*     */   {
/* 142 */     return this.response;
/*     */   }
/*     */   
/*     */ 
/*     */   public Mono<WebSession> getSession()
/*     */   {
/* 148 */     return this.exchange.getSession();
/*     */   }
/*     */   
/*     */ 
/*     */   public ServerWebExchange getExchange()
/*     */   {
/* 154 */     return this.exchange;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean containsVariable(String name)
/*     */   {
/* 160 */     return ("session".equals(name)) || 
/* 161 */       ("param".equals(name)) || 
/* 162 */       (this.webExchangeAttributesVariablesMap.containsVariable(name));
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getVariable(String key)
/*     */   {
/* 168 */     if ("session".equals(key)) {
/* 169 */       return this.sessionAttributesVariablesMap;
/*     */     }
/* 171 */     if ("param".equals(key)) {
/* 172 */       return this.requestParametersVariablesMap;
/*     */     }
/* 174 */     return this.webExchangeAttributesVariablesMap.getVariable(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> getVariableNames()
/*     */   {
/* 182 */     return this.webExchangeAttributesVariablesMap.getVariableNames();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setVariable(String name, Object value)
/*     */   {
/* 188 */     if (("session".equals(name)) || ("param".equals(name))) {
/* 189 */       throw new IllegalArgumentException("Cannot set variable called '" + name + "' into web variables map: such name is a reserved word");
/*     */     }
/*     */     
/* 192 */     this.webExchangeAttributesVariablesMap.setVariable(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setVariables(Map<String, Object> variables)
/*     */   {
/* 198 */     if ((variables == null) || (variables.isEmpty())) {
/* 199 */       return;
/*     */     }
/*     */     
/* 202 */     for (String name : variables.keySet()) {
/* 203 */       if (("session".equals(name)) || ("param".equals(name))) {
/* 204 */         throw new IllegalArgumentException("Cannot set variable called '" + name + "' into web variables map: such name is a reserved word");
/*     */       }
/*     */     }
/*     */     
/* 208 */     this.webExchangeAttributesVariablesMap.setVariables(variables);
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeVariable(String name)
/*     */   {
/* 214 */     if (("session".equals(name)) || ("param".equals(name))) {
/* 215 */       throw new IllegalArgumentException("Cannot remove variable called '" + name + "' in web variables map: such name is a reserved word");
/*     */     }
/*     */     
/* 218 */     this.webExchangeAttributesVariablesMap.removeVariable(name);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isVariableLocal(String name)
/*     */   {
/* 224 */     return this.webExchangeAttributesVariablesMap.isVariableLocal(name);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasSelectionTarget()
/*     */   {
/* 230 */     return this.webExchangeAttributesVariablesMap.hasSelectionTarget();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getSelectionTarget()
/*     */   {
/* 236 */     return this.webExchangeAttributesVariablesMap.getSelectionTarget();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setSelectionTarget(Object selectionTarget)
/*     */   {
/* 242 */     this.webExchangeAttributesVariablesMap.setSelectionTarget(selectionTarget);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IInliner getInliner()
/*     */   {
/* 250 */     return this.webExchangeAttributesVariablesMap.getInliner();
/*     */   }
/*     */   
/*     */   public void setInliner(IInliner inliner)
/*     */   {
/* 255 */     this.webExchangeAttributesVariablesMap.setInliner(inliner);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateData getTemplateData()
/*     */   {
/* 263 */     return this.webExchangeAttributesVariablesMap.getTemplateData();
/*     */   }
/*     */   
/*     */   public void setTemplateData(TemplateData templateData)
/*     */   {
/* 268 */     this.webExchangeAttributesVariablesMap.setTemplateData(templateData);
/*     */   }
/*     */   
/*     */ 
/*     */   public List<TemplateData> getTemplateStack()
/*     */   {
/* 274 */     return this.webExchangeAttributesVariablesMap.getTemplateStack();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setElementTag(IProcessableElementTag elementTag)
/*     */   {
/* 282 */     this.webExchangeAttributesVariablesMap.setElementTag(elementTag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<IProcessableElementTag> getElementStack()
/*     */   {
/* 290 */     return this.webExchangeAttributesVariablesMap.getElementStack();
/*     */   }
/*     */   
/*     */ 
/*     */   public List<IProcessableElementTag> getElementStackAbove(int contextLevel)
/*     */   {
/* 296 */     return this.webExchangeAttributesVariablesMap.getElementStackAbove(contextLevel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int level()
/*     */   {
/* 304 */     return this.webExchangeAttributesVariablesMap.level();
/*     */   }
/*     */   
/*     */ 
/*     */   public void increaseLevel()
/*     */   {
/* 310 */     this.webExchangeAttributesVariablesMap.increaseLevel();
/*     */   }
/*     */   
/*     */ 
/*     */   public void decreaseLevel()
/*     */   {
/* 316 */     this.webExchangeAttributesVariablesMap.decreaseLevel();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStringRepresentationByLevel()
/*     */   {
/* 324 */     return this.webExchangeAttributesVariablesMap.getStringRepresentationByLevel();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 333 */     return this.webExchangeAttributesVariablesMap.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object resolveLazy(Object variable)
/*     */   {
/* 343 */     if ((variable != null) && ((variable instanceof ILazyContextVariable))) {
/* 344 */       return ((ILazyContextVariable)variable).getValue();
/*     */     }
/* 346 */     return variable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class SessionAttributesMap
/*     */     extends SpringWebFluxEngineContext.NoOpMapImpl
/*     */   {
/*     */     private final SpringWebFluxEngineContext.WebExchangeAttributesVariablesMap attrVars;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 363 */     private WebSession session = null;
/*     */     
/*     */ 
/*     */     SessionAttributesMap(SpringWebFluxEngineContext.WebExchangeAttributesVariablesMap attrVars)
/*     */     {
/* 368 */       this.attrVars = attrVars;
/*     */     }
/*     */     
/*     */     private WebSession getSession() {
/* 372 */       if (this.session == null) {
/* 373 */         this.session = ((WebSession)this.attrVars.getVariable("thymeleafWebSession"));
/*     */       }
/* 375 */       return this.session;
/*     */     }
/*     */     
/*     */     public int size()
/*     */     {
/* 380 */       WebSession webSession = getSession();
/* 381 */       if (webSession == null) {
/* 382 */         return 0;
/*     */       }
/* 384 */       return webSession.getAttributes().size();
/*     */     }
/*     */     
/*     */     public boolean isEmpty()
/*     */     {
/* 389 */       WebSession webSession = getSession();
/* 390 */       if (webSession == null) {
/* 391 */         return true;
/*     */       }
/* 393 */       return webSession.getAttributes().isEmpty();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean containsKey(Object key)
/*     */     {
/* 402 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean containsValue(Object value)
/*     */     {
/* 409 */       throw new UnsupportedOperationException("Map does not support #containsValue()");
/*     */     }
/*     */     
/*     */     public Object get(Object key)
/*     */     {
/* 414 */       WebSession webSession = getSession();
/* 415 */       if (webSession == null) {
/* 416 */         return null;
/*     */       }
/* 418 */       return SpringWebFluxEngineContext.resolveLazy(webSession.getAttributes().get(key != null ? key.toString() : null));
/*     */     }
/*     */     
/*     */     public Set<String> keySet()
/*     */     {
/* 423 */       WebSession webSession = getSession();
/* 424 */       if (webSession == null) {
/* 425 */         return Collections.emptySet();
/*     */       }
/* 427 */       return webSession.getAttributes().keySet();
/*     */     }
/*     */     
/*     */     public Collection<Object> values()
/*     */     {
/* 432 */       WebSession webSession = getSession();
/* 433 */       if (webSession == null) {
/* 434 */         return Collections.emptyList();
/*     */       }
/* 436 */       return webSession.getAttributes().values();
/*     */     }
/*     */     
/*     */     public Set<Map.Entry<String, Object>> entrySet()
/*     */     {
/* 441 */       WebSession webSession = getSession();
/* 442 */       if (webSession == null) {
/* 443 */         return Collections.emptySet();
/*     */       }
/* 445 */       return webSession.getAttributes().entrySet();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class RequestParametersMap
/*     */     extends SpringWebFluxEngineContext.NoOpMapImpl
/*     */   {
/*     */     private final ServerHttpRequest request;
/*     */     
/*     */ 
/*     */     RequestParametersMap(ServerHttpRequest request)
/*     */     {
/* 459 */       this.request = request;
/*     */     }
/*     */     
/*     */ 
/*     */     public int size()
/*     */     {
/* 465 */       return this.request.getQueryParams().size();
/*     */     }
/*     */     
/*     */     public boolean isEmpty()
/*     */     {
/* 470 */       return this.request.getQueryParams().isEmpty();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean containsKey(Object key)
/*     */     {
/* 479 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean containsValue(Object value)
/*     */     {
/* 486 */       throw new UnsupportedOperationException("Map does not support #containsValue()");
/*     */     }
/*     */     
/*     */     public Object get(Object key)
/*     */     {
/* 491 */       List<String> parameterValues = (List)this.request.getQueryParams().get(key != null ? key.toString() : null);
/* 492 */       if (parameterValues == null) {
/* 493 */         return null;
/*     */       }
/* 495 */       return new SpringWebFluxEngineContext.RequestParameterValues(parameterValues);
/*     */     }
/*     */     
/*     */     public Set<String> keySet()
/*     */     {
/* 500 */       return this.request.getQueryParams().keySet();
/*     */     }
/*     */     
/*     */     public Collection<Object> values()
/*     */     {
/* 505 */       return this.request.getQueryParams().values();
/*     */     }
/*     */     
/*     */     public Set<Map.Entry<String, Object>> entrySet()
/*     */     {
/* 510 */       return this.request.getQueryParams().entrySet();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class WebExchangeAttributesVariablesMap
/*     */     extends EngineContext
/*     */   {
/*     */     private final ServerWebExchange exchange;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     WebExchangeAttributesVariablesMap(IEngineConfiguration configuration, TemplateData templateData, Map<String, Object> templateResolutionAttributes, ServerWebExchange exchange, Locale locale, Map<String, Object> variables)
/*     */     {
/* 537 */       super(templateData, templateResolutionAttributes, locale, variables);
/* 538 */       this.exchange = exchange;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean containsVariable(String name)
/*     */     {
/* 545 */       if (super.containsVariable(name)) {
/* 546 */         return true;
/*     */       }
/* 548 */       return this.exchange.getAttributes().containsKey(name);
/*     */     }
/*     */     
/*     */ 
/*     */     public Object getVariable(String key)
/*     */     {
/* 554 */       Object value = super.getVariable(key);
/* 555 */       if (value != null) {
/* 556 */         return value;
/*     */       }
/* 558 */       return this.exchange.getAttributes().get(key);
/*     */     }
/*     */     
/*     */ 
/*     */     public Set<String> getVariableNames()
/*     */     {
/* 564 */       Set<String> variableNames = super.getVariableNames();
/* 565 */       variableNames.addAll(this.exchange.getAttributes().keySet());
/* 566 */       return variableNames;
/*     */     }
/*     */     
/*     */ 
/*     */     public String getStringRepresentationByLevel()
/*     */     {
/* 572 */       StringBuilder strBuilder = new StringBuilder(super.getStringRepresentationByLevel());
/* 573 */       strBuilder.append("[[EXCHANGE: " + this.exchange.getAttributes() + "]]");
/* 574 */       return strBuilder.toString();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 582 */       StringBuilder strBuilder = new StringBuilder(super.toString());
/* 583 */       strBuilder.append("[[EXCHANGE: " + this.exchange.getAttributes() + "]]");
/* 584 */       return strBuilder.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static abstract class NoOpMapImpl
/*     */     implements Map<String, Object>
/*     */   {
/*     */     public int size()
/*     */     {
/* 601 */       return 0;
/*     */     }
/*     */     
/*     */     public boolean isEmpty()
/*     */     {
/* 606 */       return true;
/*     */     }
/*     */     
/*     */     public boolean containsKey(Object key)
/*     */     {
/* 611 */       return false;
/*     */     }
/*     */     
/*     */     public boolean containsValue(Object value)
/*     */     {
/* 616 */       return false;
/*     */     }
/*     */     
/*     */     public Object get(Object key)
/*     */     {
/* 621 */       return null;
/*     */     }
/*     */     
/*     */     public Object put(String key, Object value)
/*     */     {
/* 626 */       throw new UnsupportedOperationException("Cannot add new entry: map is immutable");
/*     */     }
/*     */     
/*     */     public Object remove(Object key)
/*     */     {
/* 631 */       throw new UnsupportedOperationException("Cannot remove entry: map is immutable");
/*     */     }
/*     */     
/*     */     public void putAll(Map<? extends String, ? extends Object> m)
/*     */     {
/* 636 */       throw new UnsupportedOperationException("Cannot add new entry: map is immutable");
/*     */     }
/*     */     
/*     */     public void clear()
/*     */     {
/* 641 */       throw new UnsupportedOperationException("Cannot clear: map is immutable");
/*     */     }
/*     */     
/*     */     public Set<String> keySet()
/*     */     {
/* 646 */       return Collections.emptySet();
/*     */     }
/*     */     
/*     */     public Collection<Object> values()
/*     */     {
/* 651 */       return Collections.emptyList();
/*     */     }
/*     */     
/*     */     public Set<Map.Entry<String, Object>> entrySet()
/*     */     {
/* 656 */       return Collections.emptySet();
/*     */     }
/*     */     
/*     */     static final class MapEntry
/*     */       implements Map.Entry<String, Object>
/*     */     {
/*     */       private final String key;
/*     */       private final Object value;
/*     */       
/*     */       MapEntry(String key, Object value)
/*     */       {
/* 667 */         this.key = key;
/* 668 */         this.value = value;
/*     */       }
/*     */       
/*     */       public String getKey()
/*     */       {
/* 673 */         return this.key;
/*     */       }
/*     */       
/*     */       public Object getValue()
/*     */       {
/* 678 */         return this.value;
/*     */       }
/*     */       
/*     */       public Object setValue(Object value)
/*     */       {
/* 683 */         throw new UnsupportedOperationException("Cannot set value: map is immutable");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class RequestParameterValues
/*     */     extends AbstractList<String>
/*     */   {
/*     */     private final List<String> parameterValues;
/*     */     
/*     */ 
/*     */     RequestParameterValues(List<String> parameterValues)
/*     */     {
/* 698 */       this.parameterValues = parameterValues;
/*     */     }
/*     */     
/*     */     public int size()
/*     */     {
/* 703 */       return this.parameterValues.size();
/*     */     }
/*     */     
/*     */     public Object[] toArray()
/*     */     {
/* 708 */       return this.parameterValues.toArray();
/*     */     }
/*     */     
/*     */     public <T> T[] toArray(T[] arr)
/*     */     {
/* 713 */       return this.parameterValues.toArray(arr);
/*     */     }
/*     */     
/*     */     public String get(int index)
/*     */     {
/* 718 */       return (String)this.parameterValues.get(index);
/*     */     }
/*     */     
/*     */     public int indexOf(Object obj)
/*     */     {
/* 723 */       return this.parameterValues.indexOf(obj);
/*     */     }
/*     */     
/*     */     public boolean contains(Object obj)
/*     */     {
/* 728 */       return this.parameterValues.contains(obj);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 738 */       int size = this.parameterValues.size();
/* 739 */       if (size == 0) {
/* 740 */         return "";
/*     */       }
/* 742 */       if (size == 1) {
/* 743 */         return (String)this.parameterValues.get(0);
/*     */       }
/* 745 */       return this.parameterValues.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\webflux\SpringWebFluxEngineContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */