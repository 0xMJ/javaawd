/*     */ package org.thymeleaf.spring5.context.webflux;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebSession;
/*     */ import org.thymeleaf.context.AbstractContext;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringWebFluxContext
/*     */   extends AbstractContext
/*     */   implements ISpringWebFluxContext
/*     */ {
/*     */   private final ServerWebExchange exchange;
/*     */   private final ReactiveAdapterRegistry reactiveAdapterRegistry;
/*     */   
/*     */   public SpringWebFluxContext(ServerWebExchange exchange)
/*     */   {
/*  64 */     this(exchange, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringWebFluxContext(ServerWebExchange exchange, Locale locale)
/*     */   {
/*  76 */     this(exchange, null, locale, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringWebFluxContext(ServerWebExchange exchange, Locale locale, Map<String, Object> variables)
/*     */   {
/*  91 */     this(exchange, null, locale, variables);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringWebFluxContext(ServerWebExchange exchange, ReactiveAdapterRegistry reactiveAdapterRegistry, Locale locale, Map<String, Object> variables)
/*     */   {
/* 111 */     super(locale, variables);
/* 112 */     Validate.notNull(exchange, "ServerWebExchange cannot be null in Spring WebFlux contexts");
/*     */     
/* 114 */     this.exchange = exchange;
/* 115 */     this.reactiveAdapterRegistry = reactiveAdapterRegistry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ReactiveAdapterRegistry getReactiveAdapterRegistry()
/*     */   {
/* 122 */     return this.reactiveAdapterRegistry;
/*     */   }
/*     */   
/*     */   public ServerHttpRequest getRequest()
/*     */   {
/* 127 */     return this.exchange.getRequest();
/*     */   }
/*     */   
/*     */   public Mono<WebSession> getSession()
/*     */   {
/* 132 */     return this.exchange.getSession();
/*     */   }
/*     */   
/*     */   public ServerHttpResponse getResponse()
/*     */   {
/* 137 */     return this.exchange.getResponse();
/*     */   }
/*     */   
/*     */   public ServerWebExchange getExchange()
/*     */   {
/* 142 */     return this.exchange;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\webflux\SpringWebFluxContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */