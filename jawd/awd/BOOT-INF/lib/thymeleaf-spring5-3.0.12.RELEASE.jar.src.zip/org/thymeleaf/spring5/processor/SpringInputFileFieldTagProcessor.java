/*    */ package org.thymeleaf.spring5.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.spring5.context.IThymeleafBindStatus;
/*    */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringInputFileFieldTagProcessor
/*    */   extends AbstractSpringFieldTagProcessor
/*    */ {
/*    */   public static final String FILE_INPUT_TYPE_ATTR_VALUE = "file";
/*    */   
/*    */   public SpringInputFileFieldTagProcessor(String dialectPrefix)
/*    */   {
/* 46 */     super(dialectPrefix, "input", "type", new String[] { "file" }, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IThymeleafBindStatus bindStatus, IElementTagStructureHandler structureHandler)
/*    */   {
/* 58 */     String name = bindStatus.getExpression();
/* 59 */     name = name == null ? "" : name;
/*    */     
/* 61 */     String id = computeId(context, tag, name, false);
/*    */     
/* 63 */     StandardProcessorUtils.setAttribute(structureHandler, this.idAttributeDefinition, "id", id);
/* 64 */     StandardProcessorUtils.setAttribute(structureHandler, this.nameAttributeDefinition, "name", name);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\processor\SpringInputFileFieldTagProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */