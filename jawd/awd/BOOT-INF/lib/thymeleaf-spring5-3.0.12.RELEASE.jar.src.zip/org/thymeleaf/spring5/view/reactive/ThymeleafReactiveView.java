/*     */ package org.thymeleaf.spring5.view.reactive;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.web.reactive.HandlerMapping;
/*     */ import org.springframework.web.reactive.result.view.AbstractView;
/*     */ import org.springframework.web.reactive.result.view.RequestContext;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.spring5.ISpringWebFluxTemplateEngine;
/*     */ import org.thymeleaf.spring5.context.webflux.IReactiveDataDriverContextVariable;
/*     */ import org.thymeleaf.spring5.context.webflux.SpringWebFluxExpressionContext;
/*     */ import org.thymeleaf.spring5.context.webflux.SpringWebFluxThymeleafRequestContext;
/*     */ import org.thymeleaf.spring5.expression.ThymeleafEvaluationContext;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression.ExecutedFragmentExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThymeleafReactiveView
/*     */   extends AbstractView
/*     */   implements BeanNameAware
/*     */ {
/* 101 */   protected static final Logger logger = LoggerFactory.getLogger(ThymeleafReactiveView.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DEFAULT_RESPONSE_CHUNK_SIZE_BYTES = Integer.MAX_VALUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String REACTIVE_MODEL_ADDITIONS_EXECUTION_ATTRIBUTE_PREFIX = "ThymeleafReactiveModelAdditions:";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String WEBFLUX_CONVERSION_SERVICE_NAME = "webFluxConversionService";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */   private String beanName = null;
/* 144 */   private ISpringWebFluxTemplateEngine templateEngine = null;
/* 145 */   private String templateName = null;
/* 146 */   private Locale locale = null;
/* 147 */   private Map<String, Object> staticVariables = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 152 */   private boolean defaultCharsetSet = false;
/* 153 */   private boolean supportedMediaTypesSet = false;
/*     */   
/* 155 */   private Set<String> markupSelectors = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 164 */   private Integer responseMaxChunkSizeBytes = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMarkupSelector()
/*     */   {
/* 178 */     return (this.markupSelectors == null) || (this.markupSelectors.size() == 0) ? null : (String)this.markupSelectors.iterator().next();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setMarkupSelector(String markupSelector)
/*     */   {
/* 184 */     this.markupSelectors = ((markupSelector == null) || (markupSelector.trim().length() == 0) ? null : Collections.singleton(markupSelector.trim()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isDefaultCharsetSet()
/*     */   {
/* 192 */     return this.defaultCharsetSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDefaultCharset(Charset defaultCharset)
/*     */   {
/* 199 */     super.setDefaultCharset(defaultCharset);
/* 200 */     this.defaultCharsetSet = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isSupportedMediaTypesSet()
/*     */   {
/* 209 */     return this.supportedMediaTypesSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSupportedMediaTypes(List<MediaType> supportedMediaTypes)
/*     */   {
/* 216 */     super.setSupportedMediaTypes(supportedMediaTypes);
/* 217 */     this.supportedMediaTypesSet = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getBeanName()
/*     */   {
/* 224 */     return this.beanName;
/*     */   }
/*     */   
/*     */   public void setBeanName(String beanName)
/*     */   {
/* 229 */     this.beanName = beanName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTemplateName()
/*     */   {
/* 236 */     return this.templateName;
/*     */   }
/*     */   
/*     */   public void setTemplateName(String templateName)
/*     */   {
/* 241 */     this.templateName = templateName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Locale getLocale()
/*     */   {
/* 248 */     return this.locale;
/*     */   }
/*     */   
/*     */   protected void setLocale(Locale locale)
/*     */   {
/* 253 */     this.locale = locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getResponseMaxChunkSizeBytes()
/*     */   {
/* 264 */     return this.responseMaxChunkSizeBytes == null ? 
/* 265 */       Integer.MAX_VALUE : this.responseMaxChunkSizeBytes.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */   Integer getNullableResponseMaxChunkSize()
/*     */   {
/* 271 */     return this.responseMaxChunkSizeBytes;
/*     */   }
/*     */   
/*     */   public void setResponseMaxChunkSizeBytes(int responseMaxBufferSizeBytes)
/*     */   {
/* 276 */     this.responseMaxChunkSizeBytes = Integer.valueOf(responseMaxBufferSizeBytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected ISpringWebFluxTemplateEngine getTemplateEngine()
/*     */   {
/* 283 */     return this.templateEngine;
/*     */   }
/*     */   
/*     */   protected void setTemplateEngine(ISpringWebFluxTemplateEngine templateEngine)
/*     */   {
/* 288 */     this.templateEngine = templateEngine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getStaticVariables()
/*     */   {
/* 295 */     if (this.staticVariables == null) {
/* 296 */       return Collections.emptyMap();
/*     */     }
/* 298 */     return Collections.unmodifiableMap(this.staticVariables);
/*     */   }
/*     */   
/*     */   public void addStaticVariable(String name, Object value)
/*     */   {
/* 303 */     if (this.staticVariables == null) {
/* 304 */       this.staticVariables = new HashMap(3, 1.0F);
/*     */     }
/* 306 */     this.staticVariables.put(name, value);
/*     */   }
/*     */   
/*     */   public void setStaticVariables(Map<String, ?> variables)
/*     */   {
/* 311 */     if (variables != null) {
/* 312 */       if (this.staticVariables == null) {
/* 313 */         this.staticVariables = new HashMap(3, 1.0F);
/*     */       }
/* 315 */       this.staticVariables.putAll(variables);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Mono<Void> render(Map<String, ?> model, MediaType contentType, ServerWebExchange exchange)
/*     */   {
/* 328 */     ISpringWebFluxTemplateEngine viewTemplateEngine = getTemplateEngine();
/*     */     
/* 330 */     if (viewTemplateEngine == null) {
/* 331 */       return Mono.error(new IllegalArgumentException("Property 'thymeleafTemplateEngine' is required"));
/*     */     }
/*     */     
/* 334 */     IEngineConfiguration configuration = viewTemplateEngine.getConfiguration();
/* 335 */     Map<String, Object> executionAttributes = configuration.getExecutionAttributes();
/*     */     
/*     */ 
/*     */ 
/* 339 */     Map<String, Object> enrichedModel = null;
/* 340 */     for (String executionAttributeName : executionAttributes.keySet())
/*     */     {
/* 342 */       if ((executionAttributeName != null) && (executionAttributeName.startsWith("ThymeleafReactiveModelAdditions:")))
/*     */       {
/*     */ 
/*     */ 
/* 346 */         Object executionAttributeValue = executionAttributes.get(executionAttributeName);
/*     */         
/* 348 */         String modelAttributeName = executionAttributeName.substring("ThymeleafReactiveModelAdditions:".length());
/* 349 */         Publisher<?> modelAttributeValue = null;
/*     */         
/* 351 */         if (executionAttributeValue != null) {
/* 352 */           if ((executionAttributeValue instanceof Publisher)) {
/* 353 */             modelAttributeValue = (Publisher)executionAttributeValue;
/* 354 */           } else if ((executionAttributeValue instanceof Supplier)) {
/* 355 */             Supplier<Publisher<?>> supplier = (Supplier)executionAttributeValue;
/* 356 */             modelAttributeValue = (Publisher)supplier.get();
/* 357 */           } else if ((executionAttributeValue instanceof Function)) {
/* 358 */             Function<ServerWebExchange, Publisher<?>> function = (Function)executionAttributeValue;
/* 359 */             modelAttributeValue = (Publisher)function.apply(exchange);
/*     */           }
/*     */         }
/*     */         
/* 363 */         if (enrichedModel == null) {
/* 364 */           enrichedModel = new LinkedHashMap(model);
/*     */         }
/* 366 */         enrichedModel.put(modelAttributeName, modelAttributeValue);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 372 */     enrichedModel = enrichedModel != null ? enrichedModel : model;
/*     */     
/* 374 */     return super.render(enrichedModel, contentType, exchange);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Mono<Void> renderInternal(Map<String, Object> renderAttributes, MediaType contentType, ServerWebExchange exchange)
/*     */   {
/* 383 */     return renderFragmentInternal(this.markupSelectors, renderAttributes, contentType, exchange);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Mono<Void> renderFragmentInternal(Set<String> markupSelectorsToRender, Map<String, Object> renderAttributes, MediaType contentType, ServerWebExchange exchange)
/*     */   {
/* 391 */     String viewTemplateName = getTemplateName();
/* 392 */     ISpringWebFluxTemplateEngine viewTemplateEngine = getTemplateEngine();
/*     */     
/* 394 */     if (viewTemplateName == null) {
/* 395 */       return Mono.error(new IllegalArgumentException("Property 'templateName' is required"));
/*     */     }
/* 397 */     if (getLocale() == null) {
/* 398 */       return Mono.error(new IllegalArgumentException("Property 'locale' is required"));
/*     */     }
/* 400 */     if (viewTemplateEngine == null) {
/* 401 */       return Mono.error(new IllegalArgumentException("Property 'thymeleafTemplateEngine' is required"));
/*     */     }
/*     */     
/* 404 */     ServerHttpResponse response = exchange.getResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 417 */     Map<String, Object> mergedModel = new HashMap(30);
/*     */     
/* 419 */     Map<String, Object> templateStaticVariables = getStaticVariables();
/* 420 */     if (templateStaticVariables != null) {
/* 421 */       mergedModel.putAll(templateStaticVariables);
/*     */     }
/*     */     
/*     */ 
/* 425 */     Map<String, Object> pathVars = (Map)exchange.getAttributes().get(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
/* 426 */     if (pathVars != null) {
/* 427 */       mergedModel.putAll(pathVars);
/*     */     }
/*     */     
/* 430 */     if (renderAttributes != null) {
/* 431 */       mergedModel.putAll(renderAttributes);
/*     */     }
/*     */     
/* 434 */     ApplicationContext applicationContext = getApplicationContext();
/*     */     
/*     */ 
/*     */ 
/* 438 */     RequestContext requestContext = createRequestContext(exchange, mergedModel);
/* 439 */     SpringWebFluxThymeleafRequestContext thymeleafRequestContext = new SpringWebFluxThymeleafRequestContext(requestContext, exchange);
/*     */     
/*     */ 
/* 442 */     mergedModel.put("springRequestContext", requestContext);
/*     */     
/*     */ 
/* 445 */     mergedModel.put("thymeleafRequestContext", thymeleafRequestContext);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 455 */     ConversionService conversionService = applicationContext.containsBean("webFluxConversionService") ? (ConversionService)applicationContext.getBean("webFluxConversionService") : null;
/* 456 */     ThymeleafEvaluationContext evaluationContext = new ThymeleafEvaluationContext(applicationContext, conversionService);
/*     */     
/* 458 */     mergedModel.put("thymeleaf::EvaluationContext", evaluationContext);
/*     */     
/*     */ 
/*     */ 
/* 462 */     boolean dataDriven = isDataDriven(mergedModel);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 477 */     IEngineConfiguration configuration = viewTemplateEngine.getConfiguration();
/*     */     
/*     */ 
/* 480 */     SpringWebFluxExpressionContext context = new SpringWebFluxExpressionContext(configuration, exchange, getReactiveAdapterRegistry(), getLocale(), mergedModel);
/*     */     
/*     */ 
/*     */ 
/*     */     Set<String> markupSelectors;
/*     */     
/*     */ 
/*     */ 
/*     */     String templateName;
/*     */     
/*     */ 
/*     */     Set<String> markupSelectors;
/*     */     
/*     */ 
/* 494 */     if (!viewTemplateName.contains("::"))
/*     */     {
/*     */ 
/* 497 */       String templateName = viewTemplateName;
/* 498 */       markupSelectors = null;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 503 */       IStandardExpressionParser parser = StandardExpressions.getExpressionParser(configuration);
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 508 */         fragmentExpression = (FragmentExpression)parser.parseExpression(context, "~{" + viewTemplateName + "}");
/*     */       } catch (TemplateProcessingException e) { FragmentExpression fragmentExpression;
/* 510 */         return Mono.error(new IllegalArgumentException("Invalid template name specification: '" + viewTemplateName + "'"));
/*     */       }
/*     */       
/*     */       FragmentExpression fragmentExpression;
/*     */       
/* 515 */       FragmentExpression.ExecutedFragmentExpression fragment = FragmentExpression.createExecutedFragmentExpression(context, fragmentExpression);
/*     */       
/* 517 */       templateName = FragmentExpression.resolveTemplateName(fragment);
/* 518 */       markupSelectors = FragmentExpression.resolveFragments(fragment);
/* 519 */       Map<String, Object> nameFragmentParameters = fragment.getFragmentParameters();
/*     */       
/* 521 */       if (nameFragmentParameters != null)
/*     */       {
/* 523 */         if (fragment.hasSyntheticParameters())
/*     */         {
/*     */ 
/* 526 */           return Mono.error(new IllegalArgumentException("Parameters in a view specification must be named (non-synthetic): '" + viewTemplateName + "'"));
/*     */         }
/*     */         
/*     */ 
/* 530 */         context.setVariables(nameFragmentParameters);
/*     */       }
/*     */     }
/*     */     
/*     */     Set<String> processMarkupSelectors;
/*     */     
/*     */     Set<String> processMarkupSelectors;
/* 537 */     if ((markupSelectors != null) && (markupSelectors.size() > 0)) {
/* 538 */       if ((markupSelectorsToRender != null) && (markupSelectorsToRender.size() > 0)) {
/* 539 */         return Mono.error(new IllegalArgumentException("A markup selector has been specified (" + 
/* 540 */           Arrays.asList(new Set[] { markupSelectors }) + ") for a view that was already being executed as a fragment (" + 
/* 541 */           Arrays.asList(new Set[] { markupSelectorsToRender }) + "). Only one fragment selection is allowed."));
/*     */       }
/*     */       
/* 544 */       processMarkupSelectors = markupSelectors;
/*     */     } else { Set<String> processMarkupSelectors;
/* 546 */       if ((markupSelectorsToRender != null) && (markupSelectorsToRender.size() > 0)) {
/* 547 */         processMarkupSelectors = markupSelectorsToRender;
/*     */       } else {
/* 549 */         processMarkupSelectors = null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 563 */     int templateResponseMaxChunkSizeBytes = getResponseMaxChunkSizeBytes();
/*     */     
/* 565 */     HttpHeaders responseHeaders = exchange.getResponse().getHeaders();
/* 566 */     Locale templateLocale = getLocale();
/* 567 */     if (templateLocale != null) {
/* 568 */       responseHeaders.setContentLanguage(templateLocale);
/*     */     }
/*     */     
/*     */ 
/* 572 */     Charset charset = (Charset)getCharset(contentType).orElse(getDefaultCharset());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 615 */     Publisher<DataBuffer> stream = viewTemplateEngine.processStream(templateName, processMarkupSelectors, context, response
/* 616 */       .bufferFactory(), contentType, charset, templateResponseMaxChunkSizeBytes);
/*     */     
/*     */ 
/* 619 */     if ((templateResponseMaxChunkSizeBytes == Integer.MAX_VALUE) && (!dataDriven))
/*     */     {
/*     */ 
/*     */ 
/* 623 */       return response.writeWith(stream);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 629 */     return response.writeAndFlushWith(Flux.from(stream).window(1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Optional<Charset> getCharset(MediaType mediaType)
/*     */   {
/* 637 */     return mediaType != null ? Optional.ofNullable(mediaType.getCharset()) : Optional.empty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static boolean isDataDriven(Map<String, Object> mergedModel)
/*     */   {
/* 644 */     if ((mergedModel == null) || (mergedModel.size() == 0)) {
/* 645 */       return false;
/*     */     }
/* 647 */     for (Object value : mergedModel.values()) {
/* 648 */       if ((value instanceof IReactiveDataDriverContextVariable)) {
/* 649 */         return true;
/*     */       }
/*     */     }
/* 652 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ReactiveAdapterRegistry getReactiveAdapterRegistry()
/*     */   {
/* 660 */     ApplicationContext applicationContext = getApplicationContext();
/* 661 */     if (applicationContext == null) {
/* 662 */       return null;
/*     */     }
/*     */     
/* 665 */     if (applicationContext != null) {
/*     */       try {
/* 667 */         return (ReactiveAdapterRegistry)applicationContext.getBean(ReactiveAdapterRegistry.class);
/*     */       }
/*     */       catch (NoSuchBeanDefinitionException localNoSuchBeanDefinitionException) {}
/*     */     }
/*     */     
/* 672 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\view\reactive\ThymeleafReactiveView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */