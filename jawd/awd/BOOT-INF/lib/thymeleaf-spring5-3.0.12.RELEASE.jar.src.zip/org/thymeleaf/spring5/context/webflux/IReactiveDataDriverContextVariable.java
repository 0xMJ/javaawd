package org.thymeleaf.spring5.context.webflux;

import org.reactivestreams.Publisher;
import org.springframework.core.ReactiveAdapterRegistry;

public abstract interface IReactiveDataDriverContextVariable
{
  public abstract Publisher<Object> getDataStream(ReactiveAdapterRegistry paramReactiveAdapterRegistry);
  
  public abstract int getBufferSizeElements();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-spring5-3.0.12.RELEASE.jar!\org\thymeleaf\spring5\context\webflux\IReactiveDataDriverContextVariable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */