/*    */ package com.fasterxml.jackson.module.paramnames;
/*    */ 
/*    */ import java.lang.reflect.Executable;
/*    */ 
/*    */ class ParameterExtractor implements java.io.Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public java.lang.reflect.Parameter[] getParameters(Executable executable) {
/* 10 */     return executable.getParameters();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-module-parameter-names-2.12.5.jar!\com\fasterxml\jackson\module\paramnames\ParameterExtractor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */