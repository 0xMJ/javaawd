/*     */ package com.fasterxml.jackson.core.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.FormatFeature;
/*     */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum JsonWriteFeature
/*     */   implements FormatFeature
/*     */ {
/*  26 */   QUOTE_FIELD_NAMES(true, JsonGenerator.Feature.QUOTE_FIELD_NAMES), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  41 */   WRITE_NAN_AS_STRINGS(true, JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */   WRITE_NUMBERS_AS_STRINGS(false, JsonGenerator.Feature.WRITE_NUMBERS_AS_STRINGS), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   ESCAPE_NON_ASCII(false, JsonGenerator.Feature.ESCAPE_NON_ASCII);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean _defaultState;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int _mask;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final JsonGenerator.Feature _mappedFeature;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int collectDefaults()
/*     */   {
/* 116 */     int flags = 0;
/* 117 */     for (JsonWriteFeature f : values()) {
/* 118 */       if (f.enabledByDefault()) {
/* 119 */         flags |= f.getMask();
/*     */       }
/*     */     }
/* 122 */     return flags;
/*     */   }
/*     */   
/*     */   private JsonWriteFeature(boolean defaultState, JsonGenerator.Feature mapTo)
/*     */   {
/* 127 */     this._defaultState = defaultState;
/* 128 */     this._mask = (1 << ordinal());
/* 129 */     this._mappedFeature = mapTo;
/*     */   }
/*     */   
/*     */ 
/* 133 */   public boolean enabledByDefault() { return this._defaultState; }
/*     */   
/* 135 */   public int getMask() { return this._mask; }
/*     */   
/* 137 */   public boolean enabledIn(int flags) { return (flags & this._mask) != 0; }
/*     */   
/* 139 */   public JsonGenerator.Feature mappedFeature() { return this._mappedFeature; }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\json\JsonWriteFeature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */