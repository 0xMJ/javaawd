/*     */ package com.fasterxml.jackson.core.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParseException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JsonReadContext
/*     */   extends JsonStreamContext
/*     */ {
/*     */   protected final JsonReadContext _parent;
/*     */   protected DupDetector _dups;
/*     */   protected JsonReadContext _child;
/*     */   protected String _currentName;
/*     */   protected Object _currentValue;
/*     */   protected int _lineNr;
/*     */   protected int _columnNr;
/*     */   
/*     */   public JsonReadContext(JsonReadContext parent, DupDetector dups, int type, int lineNr, int colNr)
/*     */   {
/*  57 */     this._parent = parent;
/*  58 */     this._dups = dups;
/*  59 */     this._type = type;
/*  60 */     this._lineNr = lineNr;
/*  61 */     this._columnNr = colNr;
/*  62 */     this._index = -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset(int type, int lineNr, int colNr)
/*     */   {
/*  75 */     this._type = type;
/*  76 */     this._index = -1;
/*  77 */     this._lineNr = lineNr;
/*  78 */     this._columnNr = colNr;
/*  79 */     this._currentName = null;
/*  80 */     this._currentValue = null;
/*  81 */     if (this._dups != null) {
/*  82 */       this._dups.reset();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonReadContext withDupDetector(DupDetector dups)
/*     */   {
/*  93 */     this._dups = dups;
/*  94 */     return this;
/*     */   }
/*     */   
/*     */   public Object getCurrentValue()
/*     */   {
/*  99 */     return this._currentValue;
/*     */   }
/*     */   
/*     */   public void setCurrentValue(Object v)
/*     */   {
/* 104 */     this._currentValue = v;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonReadContext createRootContext(int lineNr, int colNr, DupDetector dups)
/*     */   {
/* 114 */     return new JsonReadContext(null, dups, 0, lineNr, colNr);
/*     */   }
/*     */   
/*     */   public static JsonReadContext createRootContext(DupDetector dups) {
/* 118 */     return new JsonReadContext(null, dups, 0, 1, 0);
/*     */   }
/*     */   
/*     */   public JsonReadContext createChildArrayContext(int lineNr, int colNr) {
/* 122 */     JsonReadContext ctxt = this._child;
/* 123 */     if (ctxt == null)
/*     */     {
/* 125 */       this._child = (ctxt = new JsonReadContext(this, this._dups == null ? null : this._dups.child(), 1, lineNr, colNr));
/*     */     } else {
/* 127 */       ctxt.reset(1, lineNr, colNr);
/*     */     }
/* 129 */     return ctxt;
/*     */   }
/*     */   
/*     */   public JsonReadContext createChildObjectContext(int lineNr, int colNr) {
/* 133 */     JsonReadContext ctxt = this._child;
/* 134 */     if (ctxt == null)
/*     */     {
/* 136 */       this._child = (ctxt = new JsonReadContext(this, this._dups == null ? null : this._dups.child(), 2, lineNr, colNr));
/* 137 */       return ctxt;
/*     */     }
/* 139 */     ctxt.reset(2, lineNr, colNr);
/* 140 */     return ctxt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCurrentName()
/*     */   {
/* 149 */     return this._currentName;
/*     */   }
/*     */   
/* 152 */   public boolean hasCurrentName() { return this._currentName != null; }
/*     */   
/* 154 */   public JsonReadContext getParent() { return this._parent; }
/*     */   
/*     */ 
/*     */   public JsonLocation getStartLocation(Object srcRef)
/*     */   {
/* 159 */     long totalChars = -1L;
/* 160 */     return new JsonLocation(srcRef, totalChars, this._lineNr, this._columnNr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonReadContext clearAndGetParent()
/*     */   {
/* 180 */     this._currentValue = null;
/*     */     
/* 182 */     return this._parent;
/*     */   }
/*     */   
/*     */   public DupDetector getDupDetector() {
/* 186 */     return this._dups;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean expectComma()
/*     */   {
/* 200 */     int ix = ++this._index;
/* 201 */     return (this._type != 0) && (ix > 0);
/*     */   }
/*     */   
/*     */   public void setCurrentName(String name) throws JsonProcessingException {
/* 205 */     this._currentName = name;
/* 206 */     if (this._dups != null) _checkDup(this._dups, name);
/*     */   }
/*     */   
/*     */   private void _checkDup(DupDetector dd, String name) throws JsonProcessingException {
/* 210 */     if (dd.isDup(name)) {
/* 211 */       Object src = dd.getSource();
/* 212 */       throw new JsonParseException((src instanceof JsonParser) ? (JsonParser)src : null, "Duplicate field '" + name + "'");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\json\JsonReadContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */