/*      */ package com.fasterxml.jackson.core.json.async;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.async.ByteArrayFeeder;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.json.JsonReadContext;
/*      */ import com.fasterxml.jackson.core.json.JsonReadFeature;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.TextBuffer;
/*      */ import com.fasterxml.jackson.core.util.VersionUtil;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NonBlockingJsonParser
/*      */   extends NonBlockingJsonParserBase
/*      */   implements ByteArrayFeeder
/*      */ {
/*   26 */   private static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*      */   
/*   28 */   private static final int FEAT_MASK_LEADING_ZEROS = JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS.getMask();
/*      */   
/*   30 */   private static final int FEAT_MASK_ALLOW_MISSING = JsonParser.Feature.ALLOW_MISSING_VALUES.getMask();
/*   31 */   private static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
/*   32 */   private static final int FEAT_MASK_ALLOW_UNQUOTED_NAMES = JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
/*   33 */   private static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = JsonParser.Feature.ALLOW_COMMENTS.getMask();
/*   34 */   private static final int FEAT_MASK_ALLOW_YAML_COMMENTS = JsonParser.Feature.ALLOW_YAML_COMMENTS.getMask();
/*      */   
/*      */ 
/*   37 */   private static final int[] _icUTF8 = CharTypes.getInputCodeUtf8();
/*      */   
/*      */ 
/*      */ 
/*   41 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   52 */   protected byte[] _inputBuffer = NO_BYTES;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _origBufferLen;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public NonBlockingJsonParser(IOContext ctxt, int parserFeatures, ByteQuadsCanonicalizer sym)
/*      */   {
/*   75 */     super(ctxt, parserFeatures, sym);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ByteArrayFeeder getNonBlockingInputFeeder()
/*      */   {
/*   86 */     return this;
/*      */   }
/*      */   
/*      */   public final boolean needMoreInput()
/*      */   {
/*   91 */     return (this._inputPtr >= this._inputEnd) && (!this._endOfInput);
/*      */   }
/*      */   
/*      */ 
/*      */   public void feedInput(byte[] buf, int start, int end)
/*      */     throws IOException
/*      */   {
/*   98 */     if (this._inputPtr < this._inputEnd) {
/*   99 */       _reportError("Still have %d undecoded bytes, should not call 'feedInput'", Integer.valueOf(this._inputEnd - this._inputPtr));
/*      */     }
/*  101 */     if (end < start) {
/*  102 */       _reportError("Input end (%d) may not be before start (%d)", Integer.valueOf(end), Integer.valueOf(start));
/*      */     }
/*      */     
/*  105 */     if (this._endOfInput) {
/*  106 */       _reportError("Already closed, can not feed more input");
/*      */     }
/*      */     
/*  109 */     this._currInputProcessed += this._origBufferLen;
/*      */     
/*      */ 
/*  112 */     this._currInputRowStart = (start - (this._inputEnd - this._currInputRowStart));
/*      */     
/*      */ 
/*  115 */     this._currBufferStart = start;
/*  116 */     this._inputBuffer = buf;
/*  117 */     this._inputPtr = start;
/*  118 */     this._inputEnd = end;
/*  119 */     this._origBufferLen = (end - start);
/*      */   }
/*      */   
/*      */   public void endOfInput()
/*      */   {
/*  124 */     this._endOfInput = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int releaseBuffered(OutputStream out)
/*      */     throws IOException
/*      */   {
/*  146 */     int avail = this._inputEnd - this._inputPtr;
/*  147 */     if (avail > 0) {
/*  148 */       out.write(this._inputBuffer, this._inputPtr, avail);
/*      */     }
/*  150 */     return avail;
/*      */   }
/*      */   
/*      */ 
/*      */   protected char _decodeEscaped()
/*      */     throws IOException
/*      */   {
/*  157 */     VersionUtil.throwInternal();
/*  158 */     return ' ';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonToken nextToken()
/*      */     throws IOException
/*      */   {
/*  172 */     if (this._inputPtr >= this._inputEnd) {
/*  173 */       if (this._closed) {
/*  174 */         return null;
/*      */       }
/*      */       
/*  177 */       if (this._endOfInput)
/*      */       {
/*      */ 
/*  180 */         if (this._currToken == JsonToken.NOT_AVAILABLE) {
/*  181 */           return _finishTokenWithEOF();
/*      */         }
/*  183 */         return _eofAsNextToken();
/*      */       }
/*  185 */       return JsonToken.NOT_AVAILABLE;
/*      */     }
/*      */     
/*  188 */     if (this._currToken == JsonToken.NOT_AVAILABLE) {
/*  189 */       return _finishToken();
/*      */     }
/*      */     
/*      */ 
/*  193 */     this._numTypesValid = 0;
/*  194 */     this._tokenInputTotal = (this._currInputProcessed + this._inputPtr);
/*      */     
/*  196 */     this._binaryValue = null;
/*  197 */     int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */     
/*  199 */     switch (this._majorState) {
/*      */     case 0: 
/*  201 */       return _startDocument(ch);
/*      */     
/*      */     case 1: 
/*  204 */       return _startValue(ch);
/*      */     
/*      */     case 2: 
/*  207 */       return _startFieldName(ch);
/*      */     case 3: 
/*  209 */       return _startFieldNameAfterComma(ch);
/*      */     
/*      */     case 4: 
/*  212 */       return _startValueExpectColon(ch);
/*      */     
/*      */     case 5: 
/*  215 */       return _startValue(ch);
/*      */     
/*      */     case 6: 
/*  218 */       return _startValueExpectComma(ch);
/*      */     }
/*      */     
/*      */     
/*  222 */     VersionUtil.throwInternal();
/*  223 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final JsonToken _finishToken()
/*      */     throws IOException
/*      */   {
/*  234 */     switch (this._minorState) {
/*      */     case 1: 
/*  236 */       return _finishBOM(this._pending32);
/*      */     case 4: 
/*  238 */       return _startFieldName(this._inputBuffer[(this._inputPtr++)] & 0xFF);
/*      */     case 5: 
/*  240 */       return _startFieldNameAfterComma(this._inputBuffer[(this._inputPtr++)] & 0xFF);
/*      */     
/*      */ 
/*      */     case 7: 
/*  244 */       return _parseEscapedName(this._quadLength, this._pending32, this._pendingBytes);
/*      */     case 8: 
/*  246 */       return _finishFieldWithEscape();
/*      */     case 9: 
/*  248 */       return _finishAposName(this._quadLength, this._pending32, this._pendingBytes);
/*      */     case 10: 
/*  250 */       return _finishUnquotedName(this._quadLength, this._pending32, this._pendingBytes);
/*      */     
/*      */ 
/*      */ 
/*      */     case 12: 
/*  255 */       return _startValue(this._inputBuffer[(this._inputPtr++)] & 0xFF);
/*      */     case 15: 
/*  257 */       return _startValueAfterComma(this._inputBuffer[(this._inputPtr++)] & 0xFF);
/*      */     case 13: 
/*  259 */       return _startValueExpectComma(this._inputBuffer[(this._inputPtr++)] & 0xFF);
/*      */     case 14: 
/*  261 */       return _startValueExpectColon(this._inputBuffer[(this._inputPtr++)] & 0xFF);
/*      */     
/*      */     case 16: 
/*  264 */       return _finishKeywordToken("null", this._pending32, JsonToken.VALUE_NULL);
/*      */     case 17: 
/*  266 */       return _finishKeywordToken("true", this._pending32, JsonToken.VALUE_TRUE);
/*      */     case 18: 
/*  268 */       return _finishKeywordToken("false", this._pending32, JsonToken.VALUE_FALSE);
/*      */     case 19: 
/*  270 */       return _finishNonStdToken(this._nonStdTokenType, this._pending32);
/*      */     
/*      */     case 23: 
/*  273 */       return _finishNumberMinus(this._inputBuffer[(this._inputPtr++)] & 0xFF);
/*      */     case 24: 
/*  275 */       return _finishNumberLeadingZeroes();
/*      */     case 25: 
/*  277 */       return _finishNumberLeadingNegZeroes();
/*      */     case 26: 
/*  279 */       return _finishNumberIntegralPart(this._textBuffer.getBufferWithoutReset(), this._textBuffer
/*  280 */         .getCurrentSegmentSize());
/*      */     case 30: 
/*  282 */       return _finishFloatFraction();
/*      */     case 31: 
/*  284 */       return _finishFloatExponent(true, this._inputBuffer[(this._inputPtr++)] & 0xFF);
/*      */     case 32: 
/*  286 */       return _finishFloatExponent(false, this._inputBuffer[(this._inputPtr++)] & 0xFF);
/*      */     
/*      */     case 40: 
/*  289 */       return _finishRegularString();
/*      */     case 42: 
/*  291 */       this._textBuffer.append((char)_decodeUTF8_2(this._pending32, this._inputBuffer[(this._inputPtr++)]));
/*  292 */       if (this._minorStateAfterSplit == 45) {
/*  293 */         return _finishAposString();
/*      */       }
/*  295 */       return _finishRegularString();
/*      */     case 43: 
/*  297 */       if (!_decodeSplitUTF8_3(this._pending32, this._pendingBytes, this._inputBuffer[(this._inputPtr++)])) {
/*  298 */         return JsonToken.NOT_AVAILABLE;
/*      */       }
/*  300 */       if (this._minorStateAfterSplit == 45) {
/*  301 */         return _finishAposString();
/*      */       }
/*  303 */       return _finishRegularString();
/*      */     case 44: 
/*  305 */       if (!_decodeSplitUTF8_4(this._pending32, this._pendingBytes, this._inputBuffer[(this._inputPtr++)])) {
/*  306 */         return JsonToken.NOT_AVAILABLE;
/*      */       }
/*  308 */       if (this._minorStateAfterSplit == 45) {
/*  309 */         return _finishAposString();
/*      */       }
/*  311 */       return _finishRegularString();
/*      */     
/*      */ 
/*      */     case 41: 
/*  315 */       int c = _decodeSplitEscaped(this._quoted32, this._quotedDigits);
/*  316 */       if (c < 0) {
/*  317 */         return JsonToken.NOT_AVAILABLE;
/*      */       }
/*  319 */       this._textBuffer.append((char)c);
/*      */       
/*  321 */       if (this._minorStateAfterSplit == 45) {
/*  322 */         return _finishAposString();
/*      */       }
/*  324 */       return _finishRegularString();
/*      */     
/*      */     case 45: 
/*  327 */       return _finishAposString();
/*      */     
/*      */     case 50: 
/*  330 */       return _finishErrorToken();
/*      */     
/*      */ 
/*      */ 
/*      */     case 51: 
/*  335 */       return _startSlashComment(this._pending32);
/*      */     case 52: 
/*  337 */       return _finishCComment(this._pending32, true);
/*      */     case 53: 
/*  339 */       return _finishCComment(this._pending32, false);
/*      */     case 54: 
/*  341 */       return _finishCppComment(this._pending32);
/*      */     case 55: 
/*  343 */       return _finishHashComment(this._pending32);
/*      */     }
/*  345 */     VersionUtil.throwInternal();
/*  346 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final JsonToken _finishTokenWithEOF()
/*      */     throws IOException
/*      */   {
/*  358 */     JsonToken t = this._currToken;
/*  359 */     switch (this._minorState) {
/*      */     case 3: 
/*  361 */       return _eofAsNextToken();
/*      */     case 12: 
/*  363 */       return _eofAsNextToken();
/*      */     
/*      */ 
/*      */     case 16: 
/*  367 */       return _finishKeywordTokenWithEOF("null", this._pending32, JsonToken.VALUE_NULL);
/*      */     case 17: 
/*  369 */       return _finishKeywordTokenWithEOF("true", this._pending32, JsonToken.VALUE_TRUE);
/*      */     case 18: 
/*  371 */       return _finishKeywordTokenWithEOF("false", this._pending32, JsonToken.VALUE_FALSE);
/*      */     case 19: 
/*  373 */       return _finishNonStdTokenWithEOF(this._nonStdTokenType, this._pending32);
/*      */     case 50: 
/*  375 */       return _finishErrorTokenWithEOF();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 24: 
/*      */     case 25: 
/*  382 */       return _valueCompleteInt(0, "0");
/*      */     
/*      */ 
/*      */     case 26: 
/*  386 */       int len = this._textBuffer.getCurrentSegmentSize();
/*  387 */       if (this._numberNegative) {
/*  388 */         len--;
/*      */       }
/*  390 */       this._intLength = len;
/*      */       
/*  392 */       return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */     
/*      */     case 30: 
/*  395 */       this._expLength = 0;
/*      */     
/*      */     case 32: 
/*  398 */       return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */     
/*      */     case 31: 
/*  401 */       _reportInvalidEOF(": was expecting fraction after exponent marker", JsonToken.VALUE_NUMBER_FLOAT);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 52: 
/*      */     case 53: 
/*  409 */       _reportInvalidEOF(": was expecting closing '*/' for comment", JsonToken.NOT_AVAILABLE);
/*      */     
/*      */ 
/*      */     case 54: 
/*      */     case 55: 
/*  414 */       return _eofAsNextToken();
/*      */     }
/*      */     
/*      */     
/*  418 */     _reportInvalidEOF(": was expecting rest of token (internal state: " + this._minorState + ")", this._currToken);
/*  419 */     return t;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final JsonToken _startDocument(int ch)
/*      */     throws IOException
/*      */   {
/*  430 */     ch &= 0xFF;
/*      */     
/*      */ 
/*  433 */     if ((ch == 239) && (this._minorState != 1)) {
/*  434 */       return _finishBOM(1);
/*      */     }
/*      */     
/*      */ 
/*  438 */     while (ch <= 32) {
/*  439 */       if (ch != 32) {
/*  440 */         if (ch == 10) {
/*  441 */           this._currInputRow += 1;
/*  442 */           this._currInputRowStart = this._inputPtr;
/*  443 */         } else if (ch == 13) {
/*  444 */           this._currInputRowAlt += 1;
/*  445 */           this._currInputRowStart = this._inputPtr;
/*  446 */         } else if (ch != 9) {
/*  447 */           _throwInvalidSpace(ch);
/*      */         }
/*      */       }
/*  450 */       if (this._inputPtr >= this._inputEnd) {
/*  451 */         this._minorState = 3;
/*  452 */         if (this._closed) {
/*  453 */           return null;
/*      */         }
/*      */         
/*  456 */         if (this._endOfInput) {
/*  457 */           return _eofAsNextToken();
/*      */         }
/*  459 */         return JsonToken.NOT_AVAILABLE;
/*      */       }
/*  461 */       ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */     }
/*  463 */     return _startValue(ch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final JsonToken _finishBOM(int bytesHandled)
/*      */     throws IOException
/*      */   {
/*  472 */     while (this._inputPtr < this._inputEnd) {
/*  473 */       int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*  474 */       switch (bytesHandled)
/*      */       {
/*      */ 
/*      */       case 3: 
/*  478 */         this._currInputProcessed -= 3L;
/*  479 */         return _startDocument(ch);
/*      */       case 2: 
/*  481 */         if (ch != 191) {
/*  482 */           _reportError("Unexpected byte 0x%02x following 0xEF 0xBB; should get 0xBF as third byte of UTF-8 BOM", Integer.valueOf(ch));
/*      */         }
/*      */         break;
/*      */       case 1: 
/*  486 */         if (ch != 187)
/*  487 */           _reportError("Unexpected byte 0x%02x following 0xEF; should get 0xBB as second byte UTF-8 BOM", Integer.valueOf(ch));
/*      */         break;
/*      */       }
/*      */       
/*  491 */       bytesHandled++;
/*      */     }
/*  493 */     this._pending32 = bytesHandled;
/*  494 */     this._minorState = 1;
/*  495 */     return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final JsonToken _startFieldName(int ch)
/*      */     throws IOException
/*      */   {
/*  511 */     if (ch <= 32) {
/*  512 */       ch = _skipWS(ch);
/*  513 */       if (ch <= 0) {
/*  514 */         this._minorState = 4;
/*  515 */         return this._currToken;
/*      */       }
/*      */     }
/*  518 */     _updateTokenLocation();
/*  519 */     if (ch != 34) {
/*  520 */       if (ch == 125) {
/*  521 */         return _closeObjectScope();
/*      */       }
/*  523 */       return _handleOddName(ch);
/*      */     }
/*      */     
/*  526 */     if (this._inputPtr + 13 <= this._inputEnd) {
/*  527 */       String n = _fastParseName();
/*  528 */       if (n != null) {
/*  529 */         return _fieldComplete(n);
/*      */       }
/*      */     }
/*  532 */     return _parseEscapedName(0, 0, 0);
/*      */   }
/*      */   
/*      */   private final JsonToken _startFieldNameAfterComma(int ch)
/*      */     throws IOException
/*      */   {
/*  538 */     if (ch <= 32) {
/*  539 */       ch = _skipWS(ch);
/*  540 */       if (ch <= 0) {
/*  541 */         this._minorState = 5;
/*  542 */         return this._currToken;
/*      */       }
/*      */     }
/*  545 */     if (ch != 44) {
/*  546 */       if (ch == 125) {
/*  547 */         return _closeObjectScope();
/*      */       }
/*  549 */       if (ch == 35) {
/*  550 */         return _finishHashComment(5);
/*      */       }
/*  552 */       if (ch == 47) {
/*  553 */         return _startSlashComment(5);
/*      */       }
/*  555 */       _reportUnexpectedChar(ch, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */     }
/*  557 */     int ptr = this._inputPtr;
/*  558 */     if (ptr >= this._inputEnd) {
/*  559 */       this._minorState = 4;
/*  560 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     }
/*  562 */     ch = this._inputBuffer[ptr];
/*  563 */     this._inputPtr = (ptr + 1);
/*  564 */     if (ch <= 32) {
/*  565 */       ch = _skipWS(ch);
/*  566 */       if (ch <= 0) {
/*  567 */         this._minorState = 4;
/*  568 */         return this._currToken;
/*      */       }
/*      */     }
/*  571 */     _updateTokenLocation();
/*  572 */     if (ch != 34) {
/*  573 */       if ((ch == 125) && 
/*  574 */         ((this._features & FEAT_MASK_TRAILING_COMMA) != 0)) {
/*  575 */         return _closeObjectScope();
/*      */       }
/*      */       
/*  578 */       return _handleOddName(ch);
/*      */     }
/*      */     
/*  581 */     if (this._inputPtr + 13 <= this._inputEnd) {
/*  582 */       String n = _fastParseName();
/*  583 */       if (n != null) {
/*  584 */         return _fieldComplete(n);
/*      */       }
/*      */     }
/*  587 */     return _parseEscapedName(0, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final JsonToken _startValue(int ch)
/*      */     throws IOException
/*      */   {
/*  604 */     if (ch <= 32) {
/*  605 */       ch = _skipWS(ch);
/*  606 */       if (ch <= 0) {
/*  607 */         this._minorState = 12;
/*  608 */         return this._currToken;
/*      */       }
/*      */     }
/*  611 */     _updateTokenLocation();
/*      */     
/*  613 */     this._parsingContext.expectComma();
/*      */     
/*  615 */     if (ch == 34) {
/*  616 */       return _startString();
/*      */     }
/*  618 */     switch (ch) {
/*      */     case 35: 
/*  620 */       return _finishHashComment(12);
/*      */     case 45: 
/*  622 */       return _startNegativeNumber();
/*      */     case 47: 
/*  624 */       return _startSlashComment(12);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 46: 
/*  631 */       if (isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/*  632 */         return _startFloatThatStartsWithPeriod();
/*      */       }
/*      */       
/*      */       break;
/*      */     case 48: 
/*  637 */       return _startNumberLeadingZero();
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*  647 */       return _startPositiveNumber(ch);
/*      */     case 102: 
/*  649 */       return _startFalseToken();
/*      */     case 110: 
/*  651 */       return _startNullToken();
/*      */     case 116: 
/*  653 */       return _startTrueToken();
/*      */     case 91: 
/*  655 */       return _startArrayScope();
/*      */     case 93: 
/*  657 */       return _closeArrayScope();
/*      */     case 123: 
/*  659 */       return _startObjectScope();
/*      */     case 125: 
/*  661 */       return _closeObjectScope();
/*      */     }
/*      */     
/*  664 */     return _startUnexpectedValue(false, ch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final JsonToken _startValueExpectComma(int ch)
/*      */     throws IOException
/*      */   {
/*  674 */     if (ch <= 32) {
/*  675 */       ch = _skipWS(ch);
/*  676 */       if (ch <= 0) {
/*  677 */         this._minorState = 13;
/*  678 */         return this._currToken;
/*      */       }
/*      */     }
/*  681 */     if (ch != 44) {
/*  682 */       if (ch == 93) {
/*  683 */         return _closeArrayScope();
/*      */       }
/*  685 */       if (ch == 125) {
/*  686 */         return _closeObjectScope();
/*      */       }
/*  688 */       if (ch == 47) {
/*  689 */         return _startSlashComment(13);
/*      */       }
/*  691 */       if (ch == 35) {
/*  692 */         return _finishHashComment(13);
/*      */       }
/*  694 */       _reportUnexpectedChar(ch, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */     }
/*      */     
/*      */ 
/*  698 */     this._parsingContext.expectComma();
/*      */     
/*  700 */     int ptr = this._inputPtr;
/*  701 */     if (ptr >= this._inputEnd) {
/*  702 */       this._minorState = 15;
/*  703 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     }
/*  705 */     ch = this._inputBuffer[ptr];
/*  706 */     this._inputPtr = (ptr + 1);
/*  707 */     if (ch <= 32) {
/*  708 */       ch = _skipWS(ch);
/*  709 */       if (ch <= 0) {
/*  710 */         this._minorState = 15;
/*  711 */         return this._currToken;
/*      */       }
/*      */     }
/*  714 */     _updateTokenLocation();
/*  715 */     if (ch == 34) {
/*  716 */       return _startString();
/*      */     }
/*  718 */     switch (ch) {
/*      */     case 35: 
/*  720 */       return _finishHashComment(15);
/*      */     case 45: 
/*  722 */       return _startNegativeNumber();
/*      */     case 47: 
/*  724 */       return _startSlashComment(15);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 48: 
/*  730 */       return _startNumberLeadingZero();
/*      */     case 49: case 50: 
/*      */     case 51: case 52: 
/*      */     case 53: case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*  737 */       return _startPositiveNumber(ch);
/*      */     case 102: 
/*  739 */       return _startFalseToken();
/*      */     case 110: 
/*  741 */       return _startNullToken();
/*      */     case 116: 
/*  743 */       return _startTrueToken();
/*      */     case 91: 
/*  745 */       return _startArrayScope();
/*      */     
/*      */     case 93: 
/*  748 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  749 */         return _closeArrayScope();
/*      */       }
/*      */       break;
/*      */     case 123: 
/*  753 */       return _startObjectScope();
/*      */     
/*      */     case 125: 
/*  756 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  757 */         return _closeObjectScope();
/*      */       }
/*      */       break;
/*      */     }
/*      */     
/*  762 */     return _startUnexpectedValue(true, ch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final JsonToken _startValueExpectColon(int ch)
/*      */     throws IOException
/*      */   {
/*  773 */     if (ch <= 32) {
/*  774 */       ch = _skipWS(ch);
/*  775 */       if (ch <= 0) {
/*  776 */         this._minorState = 14;
/*  777 */         return this._currToken;
/*      */       }
/*      */     }
/*  780 */     if (ch != 58) {
/*  781 */       if (ch == 47) {
/*  782 */         return _startSlashComment(14);
/*      */       }
/*  784 */       if (ch == 35) {
/*  785 */         return _finishHashComment(14);
/*      */       }
/*      */       
/*  788 */       _reportUnexpectedChar(ch, "was expecting a colon to separate field name and value");
/*      */     }
/*  790 */     int ptr = this._inputPtr;
/*  791 */     if (ptr >= this._inputEnd) {
/*  792 */       this._minorState = 12;
/*  793 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     }
/*  795 */     ch = this._inputBuffer[ptr];
/*  796 */     this._inputPtr = (ptr + 1);
/*  797 */     if (ch <= 32) {
/*  798 */       ch = _skipWS(ch);
/*  799 */       if (ch <= 0) {
/*  800 */         this._minorState = 12;
/*  801 */         return this._currToken;
/*      */       }
/*      */     }
/*  804 */     _updateTokenLocation();
/*  805 */     if (ch == 34) {
/*  806 */       return _startString();
/*      */     }
/*  808 */     switch (ch) {
/*      */     case 35: 
/*  810 */       return _finishHashComment(12);
/*      */     case 45: 
/*  812 */       return _startNegativeNumber();
/*      */     case 47: 
/*  814 */       return _startSlashComment(12);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 48: 
/*  820 */       return _startNumberLeadingZero();
/*      */     case 49: case 50: 
/*      */     case 51: case 52: 
/*      */     case 53: case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*  827 */       return _startPositiveNumber(ch);
/*      */     case 102: 
/*  829 */       return _startFalseToken();
/*      */     case 110: 
/*  831 */       return _startNullToken();
/*      */     case 116: 
/*  833 */       return _startTrueToken();
/*      */     case 91: 
/*  835 */       return _startArrayScope();
/*      */     case 123: 
/*  837 */       return _startObjectScope();
/*      */     }
/*      */     
/*  840 */     return _startUnexpectedValue(false, ch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private final JsonToken _startValueAfterComma(int ch)
/*      */     throws IOException
/*      */   {
/*  848 */     if (ch <= 32) {
/*  849 */       ch = _skipWS(ch);
/*  850 */       if (ch <= 0) {
/*  851 */         this._minorState = 15;
/*  852 */         return this._currToken;
/*      */       }
/*      */     }
/*  855 */     _updateTokenLocation();
/*  856 */     if (ch == 34) {
/*  857 */       return _startString();
/*      */     }
/*  859 */     switch (ch) {
/*      */     case 35: 
/*  861 */       return _finishHashComment(15);
/*      */     case 45: 
/*  863 */       return _startNegativeNumber();
/*      */     case 47: 
/*  865 */       return _startSlashComment(15);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 48: 
/*  871 */       return _startNumberLeadingZero();
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*  881 */       return _startPositiveNumber(ch);
/*      */     case 102: 
/*  883 */       return _startFalseToken();
/*      */     case 110: 
/*  885 */       return _startNullToken();
/*      */     case 116: 
/*  887 */       return _startTrueToken();
/*      */     case 91: 
/*  889 */       return _startArrayScope();
/*      */     
/*      */     case 93: 
/*  892 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  893 */         return _closeArrayScope();
/*      */       }
/*      */       break;
/*      */     case 123: 
/*  897 */       return _startObjectScope();
/*      */     
/*      */     case 125: 
/*  900 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  901 */         return _closeObjectScope();
/*      */       }
/*      */       break;
/*      */     }
/*      */     
/*  906 */     return _startUnexpectedValue(true, ch);
/*      */   }
/*      */   
/*      */   protected JsonToken _startUnexpectedValue(boolean leadingComma, int ch) throws IOException
/*      */   {
/*  911 */     switch (ch) {
/*      */     case 93: 
/*  913 */       if (!this._parsingContext.inArray()) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 44: 
/*  922 */       if ((!this._parsingContext.inRoot()) && 
/*  923 */         ((this._features & FEAT_MASK_ALLOW_MISSING) != 0)) {
/*  924 */         this._inputPtr -= 1;
/*  925 */         return _valueComplete(JsonToken.VALUE_NULL);
/*      */       }
/*      */     
/*      */ 
/*      */     case 125: 
/*      */       break;
/*      */     
/*      */ 
/*      */     case 39: 
/*  934 */       if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/*  935 */         return _startAposString();
/*      */       }
/*      */       break;
/*      */     case 43: 
/*  939 */       return _finishNonStdToken(2, 1);
/*      */     case 78: 
/*  941 */       return _finishNonStdToken(0, 1);
/*      */     case 73: 
/*  943 */       return _finishNonStdToken(1, 1);
/*      */     }
/*      */     
/*  946 */     _reportUnexpectedChar(ch, "expected a valid value " + _validJsonValueList());
/*  947 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int _skipWS(int ch)
/*      */     throws IOException
/*      */   {
/*      */     do
/*      */     {
/*  959 */       if (ch != 32) {
/*  960 */         if (ch == 10) {
/*  961 */           this._currInputRow += 1;
/*  962 */           this._currInputRowStart = this._inputPtr;
/*  963 */         } else if (ch == 13) {
/*  964 */           this._currInputRowAlt += 1;
/*  965 */           this._currInputRowStart = this._inputPtr;
/*  966 */         } else if (ch != 9) {
/*  967 */           _throwInvalidSpace(ch);
/*      */         }
/*      */       }
/*  970 */       if (this._inputPtr >= this._inputEnd) {
/*  971 */         this._currToken = JsonToken.NOT_AVAILABLE;
/*  972 */         return 0;
/*      */       }
/*  974 */       ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*  975 */     } while (ch <= 32);
/*  976 */     return ch;
/*      */   }
/*      */   
/*      */   private final JsonToken _startSlashComment(int fromMinorState) throws IOException
/*      */   {
/*  981 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/*  982 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     
/*      */ 
/*  986 */     if (this._inputPtr >= this._inputEnd) {
/*  987 */       this._pending32 = fromMinorState;
/*  988 */       this._minorState = 51;
/*  989 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     }
/*  991 */     int ch = this._inputBuffer[(this._inputPtr++)];
/*  992 */     if (ch == 42) {
/*  993 */       return _finishCComment(fromMinorState, false);
/*      */     }
/*  995 */     if (ch == 47) {
/*  996 */       return _finishCppComment(fromMinorState);
/*      */     }
/*  998 */     _reportUnexpectedChar(ch & 0xFF, "was expecting either '*' or '/' for a comment");
/*  999 */     return null;
/*      */   }
/*      */   
/*      */   private final JsonToken _finishHashComment(int fromMinorState)
/*      */     throws IOException
/*      */   {
/* 1005 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/* 1006 */       _reportUnexpectedChar(35, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_YAML_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     for (;;) {
/* 1009 */       if (this._inputPtr >= this._inputEnd) {
/* 1010 */         this._minorState = 55;
/* 1011 */         this._pending32 = fromMinorState;
/* 1012 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1014 */       int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1015 */       if (ch < 32) {
/* 1016 */         if (ch == 10) {
/* 1017 */           this._currInputRow += 1;
/* 1018 */           this._currInputRowStart = this._inputPtr;
/* 1019 */           break; }
/* 1020 */         if (ch == 13) {
/* 1021 */           this._currInputRowAlt += 1;
/* 1022 */           this._currInputRowStart = this._inputPtr;
/* 1023 */           break; }
/* 1024 */         if (ch != 9) {
/* 1025 */           _throwInvalidSpace(ch);
/*      */         }
/*      */       }
/*      */     }
/* 1029 */     return _startAfterComment(fromMinorState);
/*      */   }
/*      */   
/*      */   private final JsonToken _finishCppComment(int fromMinorState) throws IOException
/*      */   {
/*      */     for (;;) {
/* 1035 */       if (this._inputPtr >= this._inputEnd) {
/* 1036 */         this._minorState = 54;
/* 1037 */         this._pending32 = fromMinorState;
/* 1038 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1040 */       int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1041 */       if (ch < 32) {
/* 1042 */         if (ch == 10) {
/* 1043 */           this._currInputRow += 1;
/* 1044 */           this._currInputRowStart = this._inputPtr;
/* 1045 */           break; }
/* 1046 */         if (ch == 13) {
/* 1047 */           this._currInputRowAlt += 1;
/* 1048 */           this._currInputRowStart = this._inputPtr;
/* 1049 */           break; }
/* 1050 */         if (ch != 9) {
/* 1051 */           _throwInvalidSpace(ch);
/*      */         }
/*      */       }
/*      */     }
/* 1055 */     return _startAfterComment(fromMinorState);
/*      */   }
/*      */   
/*      */   private final JsonToken _finishCComment(int fromMinorState, boolean gotStar) throws IOException
/*      */   {
/*      */     for (;;) {
/* 1061 */       if (this._inputPtr >= this._inputEnd) {
/* 1062 */         this._minorState = (gotStar ? 52 : 53);
/* 1063 */         this._pending32 = fromMinorState;
/* 1064 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1066 */       int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1067 */       if (ch < 32) {
/* 1068 */         if (ch == 10) {
/* 1069 */           this._currInputRow += 1;
/* 1070 */           this._currInputRowStart = this._inputPtr;
/* 1071 */         } else if (ch == 13) {
/* 1072 */           this._currInputRowAlt += 1;
/* 1073 */           this._currInputRowStart = this._inputPtr;
/* 1074 */         } else if (ch != 9) {
/* 1075 */           _throwInvalidSpace(ch);
/*      */         }
/* 1077 */       } else { if (ch == 42) {
/* 1078 */           gotStar = true;
/* 1079 */           continue; }
/* 1080 */         if ((ch == 47) && 
/* 1081 */           (gotStar)) {
/*      */           break;
/*      */         }
/*      */       }
/* 1085 */       gotStar = false;
/*      */     }
/* 1087 */     return _startAfterComment(fromMinorState);
/*      */   }
/*      */   
/*      */   private final JsonToken _startAfterComment(int fromMinorState)
/*      */     throws IOException
/*      */   {
/* 1093 */     if (this._inputPtr >= this._inputEnd) {
/* 1094 */       this._minorState = fromMinorState;
/* 1095 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     }
/* 1097 */     int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1098 */     switch (fromMinorState) {
/*      */     case 4: 
/* 1100 */       return _startFieldName(ch);
/*      */     case 5: 
/* 1102 */       return _startFieldNameAfterComma(ch);
/*      */     case 12: 
/* 1104 */       return _startValue(ch);
/*      */     case 13: 
/* 1106 */       return _startValueExpectComma(ch);
/*      */     case 14: 
/* 1108 */       return _startValueExpectColon(ch);
/*      */     case 15: 
/* 1110 */       return _startValueAfterComma(ch);
/*      */     }
/*      */     
/* 1113 */     VersionUtil.throwInternal();
/* 1114 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonToken _startFalseToken()
/*      */     throws IOException
/*      */   {
/* 1125 */     int ptr = this._inputPtr;
/* 1126 */     if (ptr + 4 < this._inputEnd) {
/* 1127 */       byte[] buf = this._inputBuffer;
/* 1128 */       if ((buf[(ptr++)] == 97) && (buf[(ptr++)] == 108) && (buf[(ptr++)] == 115) && (buf[(ptr++)] == 101))
/*      */       {
/*      */ 
/*      */ 
/* 1132 */         int ch = buf[ptr] & 0xFF;
/* 1133 */         if ((ch < 48) || (ch == 93) || (ch == 125)) {
/* 1134 */           this._inputPtr = ptr;
/* 1135 */           return _valueComplete(JsonToken.VALUE_FALSE);
/*      */         }
/*      */       }
/*      */     }
/* 1139 */     this._minorState = 18;
/* 1140 */     return _finishKeywordToken("false", 1, JsonToken.VALUE_FALSE);
/*      */   }
/*      */   
/*      */   protected JsonToken _startTrueToken() throws IOException
/*      */   {
/* 1145 */     int ptr = this._inputPtr;
/* 1146 */     if (ptr + 3 < this._inputEnd) {
/* 1147 */       byte[] buf = this._inputBuffer;
/* 1148 */       if ((buf[(ptr++)] == 114) && (buf[(ptr++)] == 117) && (buf[(ptr++)] == 101))
/*      */       {
/*      */ 
/* 1151 */         int ch = buf[ptr] & 0xFF;
/* 1152 */         if ((ch < 48) || (ch == 93) || (ch == 125)) {
/* 1153 */           this._inputPtr = ptr;
/* 1154 */           return _valueComplete(JsonToken.VALUE_TRUE);
/*      */         }
/*      */       }
/*      */     }
/* 1158 */     this._minorState = 17;
/* 1159 */     return _finishKeywordToken("true", 1, JsonToken.VALUE_TRUE);
/*      */   }
/*      */   
/*      */   protected JsonToken _startNullToken() throws IOException
/*      */   {
/* 1164 */     int ptr = this._inputPtr;
/* 1165 */     if (ptr + 3 < this._inputEnd) {
/* 1166 */       byte[] buf = this._inputBuffer;
/* 1167 */       if ((buf[(ptr++)] == 117) && (buf[(ptr++)] == 108) && (buf[(ptr++)] == 108))
/*      */       {
/*      */ 
/* 1170 */         int ch = buf[ptr] & 0xFF;
/* 1171 */         if ((ch < 48) || (ch == 93) || (ch == 125)) {
/* 1172 */           this._inputPtr = ptr;
/* 1173 */           return _valueComplete(JsonToken.VALUE_NULL);
/*      */         }
/*      */       }
/*      */     }
/* 1177 */     this._minorState = 16;
/* 1178 */     return _finishKeywordToken("null", 1, JsonToken.VALUE_NULL);
/*      */   }
/*      */   
/*      */   protected JsonToken _finishKeywordToken(String expToken, int matched, JsonToken result)
/*      */     throws IOException
/*      */   {
/* 1184 */     int end = expToken.length();
/*      */     for (;;)
/*      */     {
/* 1187 */       if (this._inputPtr >= this._inputEnd) {
/* 1188 */         this._pending32 = matched;
/* 1189 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1191 */       int ch = this._inputBuffer[this._inputPtr];
/* 1192 */       if (matched == end) {
/* 1193 */         if ((ch >= 48) && (ch != 93) && (ch != 125)) break;
/* 1194 */         return _valueComplete(result);
/*      */       }
/*      */       
/*      */ 
/* 1198 */       if (ch != expToken.charAt(matched)) {
/*      */         break;
/*      */       }
/* 1201 */       matched++;
/* 1202 */       this._inputPtr += 1;
/*      */     }
/* 1204 */     this._minorState = 50;
/* 1205 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1206 */     return _finishErrorToken();
/*      */   }
/*      */   
/*      */   protected JsonToken _finishKeywordTokenWithEOF(String expToken, int matched, JsonToken result)
/*      */     throws IOException
/*      */   {
/* 1212 */     if (matched == expToken.length()) {
/* 1213 */       return this._currToken = result;
/*      */     }
/* 1215 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1216 */     return _finishErrorTokenWithEOF();
/*      */   }
/*      */   
/*      */   protected JsonToken _finishNonStdToken(int type, int matched) throws IOException
/*      */   {
/* 1221 */     String expToken = _nonStdToken(type);
/* 1222 */     int end = expToken.length();
/*      */     for (;;)
/*      */     {
/* 1225 */       if (this._inputPtr >= this._inputEnd) {
/* 1226 */         this._nonStdTokenType = type;
/* 1227 */         this._pending32 = matched;
/* 1228 */         this._minorState = 19;
/* 1229 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1231 */       int ch = this._inputBuffer[this._inputPtr];
/* 1232 */       if (matched == end) {
/* 1233 */         if ((ch >= 48) && (ch != 93) && (ch != 125)) break;
/* 1234 */         return _valueNonStdNumberComplete(type);
/*      */       }
/*      */       
/*      */ 
/* 1238 */       if (ch != expToken.charAt(matched)) {
/*      */         break;
/*      */       }
/* 1241 */       matched++;
/* 1242 */       this._inputPtr += 1;
/*      */     }
/* 1244 */     this._minorState = 50;
/* 1245 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1246 */     return _finishErrorToken();
/*      */   }
/*      */   
/*      */   protected JsonToken _finishNonStdTokenWithEOF(int type, int matched) throws IOException
/*      */   {
/* 1251 */     String expToken = _nonStdToken(type);
/* 1252 */     if (matched == expToken.length()) {
/* 1253 */       return _valueNonStdNumberComplete(type);
/*      */     }
/* 1255 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1256 */     return _finishErrorTokenWithEOF();
/*      */   }
/*      */   
/*      */   protected JsonToken _finishErrorToken() throws IOException
/*      */   {
/* 1261 */     while (this._inputPtr < this._inputEnd) {
/* 1262 */       int i = this._inputBuffer[(this._inputPtr++)];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1267 */       char ch = (char)i;
/* 1268 */       if (Character.isJavaIdentifierPart(ch))
/*      */       {
/*      */ 
/* 1271 */         this._textBuffer.append(ch);
/* 1272 */         if (this._textBuffer.size() < 256) {
/*      */           break;
/*      */         }
/*      */       } else {
/* 1276 */         return _reportErrorToken(this._textBuffer.contentsAsString());
/*      */       } }
/* 1278 */     return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */   }
/*      */   
/*      */   protected JsonToken _finishErrorTokenWithEOF() throws IOException
/*      */   {
/* 1283 */     return _reportErrorToken(this._textBuffer.contentsAsString());
/*      */   }
/*      */   
/*      */   protected JsonToken _reportErrorToken(String actualToken)
/*      */     throws IOException
/*      */   {
/* 1289 */     _reportError("Unrecognized token '%s': was expecting %s", this._textBuffer.contentsAsString(), 
/* 1290 */       _validJsonTokenList());
/* 1291 */     return JsonToken.NOT_AVAILABLE;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonToken _startFloatThatStartsWithPeriod()
/*      */     throws IOException
/*      */   {
/* 1303 */     this._numberNegative = false;
/* 1304 */     this._intLength = 0;
/* 1305 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1306 */     return _startFloat(outBuf, 0, 46);
/*      */   }
/*      */   
/*      */   protected JsonToken _startPositiveNumber(int ch) throws IOException
/*      */   {
/* 1311 */     this._numberNegative = false;
/* 1312 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1313 */     outBuf[0] = ((char)ch);
/*      */     
/* 1315 */     if (this._inputPtr >= this._inputEnd) {
/* 1316 */       this._minorState = 26;
/* 1317 */       this._textBuffer.setCurrentLength(1);
/* 1318 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     }
/*      */     
/* 1321 */     int outPtr = 1;
/*      */     
/* 1323 */     ch = this._inputBuffer[this._inputPtr] & 0xFF;
/*      */     for (;;) {
/* 1325 */       if (ch < 48) {
/* 1326 */         if (ch != 46) break;
/* 1327 */         this._intLength = outPtr;
/* 1328 */         this._inputPtr += 1;
/* 1329 */         return _startFloat(outBuf, outPtr, ch);
/*      */       }
/*      */       
/*      */ 
/* 1333 */       if (ch > 57) {
/* 1334 */         if ((ch != 101) && (ch != 69)) break;
/* 1335 */         this._intLength = outPtr;
/* 1336 */         this._inputPtr += 1;
/* 1337 */         return _startFloat(outBuf, outPtr, ch);
/*      */       }
/*      */       
/*      */ 
/* 1341 */       if (outPtr >= outBuf.length)
/*      */       {
/*      */ 
/* 1344 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1346 */       outBuf[(outPtr++)] = ((char)ch);
/* 1347 */       if (++this._inputPtr >= this._inputEnd) {
/* 1348 */         this._minorState = 26;
/* 1349 */         this._textBuffer.setCurrentLength(outPtr);
/* 1350 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1352 */       ch = this._inputBuffer[this._inputPtr] & 0xFF;
/*      */     }
/* 1354 */     this._intLength = outPtr;
/* 1355 */     this._textBuffer.setCurrentLength(outPtr);
/* 1356 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */   
/*      */   protected JsonToken _startNegativeNumber() throws IOException
/*      */   {
/* 1361 */     this._numberNegative = true;
/* 1362 */     if (this._inputPtr >= this._inputEnd) {
/* 1363 */       this._minorState = 23;
/* 1364 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     }
/* 1366 */     int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1367 */     if (ch <= 48) {
/* 1368 */       if (ch == 48) {
/* 1369 */         return _finishNumberLeadingNegZeroes();
/*      */       }
/*      */       
/* 1372 */       reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 1373 */     } else if (ch > 57) {
/* 1374 */       if (ch == 73) {
/* 1375 */         return _finishNonStdToken(3, 2);
/*      */       }
/* 1377 */       reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/*      */     }
/* 1379 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1380 */     outBuf[0] = '-';
/* 1381 */     outBuf[1] = ((char)ch);
/* 1382 */     if (this._inputPtr >= this._inputEnd) {
/* 1383 */       this._minorState = 26;
/* 1384 */       this._textBuffer.setCurrentLength(2);
/* 1385 */       this._intLength = 1;
/* 1386 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     }
/* 1388 */     ch = this._inputBuffer[this._inputPtr];
/* 1389 */     int outPtr = 2;
/*      */     for (;;)
/*      */     {
/* 1392 */       if (ch < 48) {
/* 1393 */         if (ch != 46) break;
/* 1394 */         this._intLength = (outPtr - 1);
/* 1395 */         this._inputPtr += 1;
/* 1396 */         return _startFloat(outBuf, outPtr, ch);
/*      */       }
/*      */       
/*      */ 
/* 1400 */       if (ch > 57) {
/* 1401 */         if ((ch != 101) && (ch != 69)) break;
/* 1402 */         this._intLength = (outPtr - 1);
/* 1403 */         this._inputPtr += 1;
/* 1404 */         return _startFloat(outBuf, outPtr, ch);
/*      */       }
/*      */       
/*      */ 
/* 1408 */       if (outPtr >= outBuf.length)
/*      */       {
/* 1410 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1412 */       outBuf[(outPtr++)] = ((char)ch);
/* 1413 */       if (++this._inputPtr >= this._inputEnd) {
/* 1414 */         this._minorState = 26;
/* 1415 */         this._textBuffer.setCurrentLength(outPtr);
/* 1416 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1418 */       ch = this._inputBuffer[this._inputPtr] & 0xFF;
/*      */     }
/* 1420 */     this._intLength = (outPtr - 1);
/* 1421 */     this._textBuffer.setCurrentLength(outPtr);
/* 1422 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */   
/*      */   protected JsonToken _startNumberLeadingZero() throws IOException
/*      */   {
/* 1427 */     int ptr = this._inputPtr;
/* 1428 */     if (ptr >= this._inputEnd) {
/* 1429 */       this._minorState = 24;
/* 1430 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1437 */     int ch = this._inputBuffer[(ptr++)] & 0xFF;
/*      */     
/* 1439 */     if (ch < 48) {
/* 1440 */       if (ch == 46) {
/* 1441 */         this._inputPtr = ptr;
/* 1442 */         this._intLength = 1;
/* 1443 */         char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1444 */         outBuf[0] = '0';
/* 1445 */         return _startFloat(outBuf, 1, ch);
/*      */       }
/* 1447 */     } else if (ch > 57) {
/* 1448 */       if ((ch == 101) || (ch == 69)) {
/* 1449 */         this._inputPtr = ptr;
/* 1450 */         this._intLength = 1;
/* 1451 */         char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1452 */         outBuf[0] = '0';
/* 1453 */         return _startFloat(outBuf, 1, ch);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1458 */       if ((ch != 93) && (ch != 125)) {
/* 1459 */         reportUnexpectedNumberChar(ch, "expected digit (0-9), decimal point (.) or exponent indicator (e/E) to follow '0'");
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1464 */       return _finishNumberLeadingZeroes();
/*      */     }
/*      */     
/* 1467 */     return _valueCompleteInt(0, "0");
/*      */   }
/*      */   
/*      */   protected JsonToken _finishNumberMinus(int ch) throws IOException
/*      */   {
/* 1472 */     if (ch <= 48) {
/* 1473 */       if (ch == 48) {
/* 1474 */         return _finishNumberLeadingNegZeroes();
/*      */       }
/* 1476 */       reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 1477 */     } else if (ch > 57) {
/* 1478 */       if (ch == 73) {
/* 1479 */         return _finishNonStdToken(3, 2);
/*      */       }
/* 1481 */       reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/*      */     }
/* 1483 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1484 */     outBuf[0] = '-';
/* 1485 */     outBuf[1] = ((char)ch);
/* 1486 */     this._intLength = 1;
/* 1487 */     return _finishNumberIntegralPart(outBuf, 2);
/*      */   }
/*      */   
/*      */   protected JsonToken _finishNumberLeadingZeroes() throws IOException
/*      */   {
/*      */     int ch;
/*      */     do
/*      */     {
/* 1495 */       if (this._inputPtr >= this._inputEnd) {
/* 1496 */         this._minorState = 24;
/* 1497 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1499 */       ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1500 */       if (ch < 48) {
/* 1501 */         if (ch != 46) break;
/* 1502 */         char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1503 */         outBuf[0] = '0';
/* 1504 */         this._intLength = 1;
/* 1505 */         return _startFloat(outBuf, 1, ch);
/*      */       }
/* 1507 */       if (ch > 57) {
/* 1508 */         if ((ch == 101) || (ch == 69)) {
/* 1509 */           char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1510 */           outBuf[0] = '0';
/* 1511 */           this._intLength = 1;
/* 1512 */           return _startFloat(outBuf, 1, ch);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1517 */         if ((ch == 93) || (ch == 125)) break;
/* 1518 */         reportUnexpectedNumberChar(ch, "expected digit (0-9), decimal point (.) or exponent indicator (e/E) to follow '0'"); break;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1524 */       if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1525 */         reportInvalidNumber("Leading zeroes not allowed");
/*      */       }
/* 1527 */     } while (ch == 48);
/*      */     
/*      */ 
/* 1530 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */     
/* 1532 */     outBuf[0] = ((char)ch);
/* 1533 */     this._intLength = 1;
/* 1534 */     return _finishNumberIntegralPart(outBuf, 1);
/*      */     
/* 1536 */     this._inputPtr -= 1;
/* 1537 */     return _valueCompleteInt(0, "0");
/*      */   }
/*      */   
/*      */   protected JsonToken _finishNumberLeadingNegZeroes()
/*      */     throws IOException
/*      */   {
/*      */     int ch;
/*      */     do
/*      */     {
/* 1546 */       if (this._inputPtr >= this._inputEnd) {
/* 1547 */         this._minorState = 25;
/* 1548 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1550 */       ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1551 */       if (ch < 48) {
/* 1552 */         if (ch != 46) break;
/* 1553 */         char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1554 */         outBuf[0] = '-';
/* 1555 */         outBuf[1] = '0';
/* 1556 */         this._intLength = 1;
/* 1557 */         return _startFloat(outBuf, 2, ch);
/*      */       }
/* 1559 */       if (ch > 57) {
/* 1560 */         if ((ch == 101) || (ch == 69)) {
/* 1561 */           char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1562 */           outBuf[0] = '-';
/* 1563 */           outBuf[1] = '0';
/* 1564 */           this._intLength = 1;
/* 1565 */           return _startFloat(outBuf, 2, ch);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1570 */         if ((ch == 93) || (ch == 125)) break;
/* 1571 */         reportUnexpectedNumberChar(ch, "expected digit (0-9), decimal point (.) or exponent indicator (e/E) to follow '0'"); break;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1577 */       if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1578 */         reportInvalidNumber("Leading zeroes not allowed");
/*      */       }
/* 1580 */     } while (ch == 48);
/*      */     
/*      */ 
/* 1583 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */     
/* 1585 */     outBuf[0] = '-';
/* 1586 */     outBuf[1] = ((char)ch);
/* 1587 */     this._intLength = 1;
/* 1588 */     return _finishNumberIntegralPart(outBuf, 2);
/*      */     
/* 1590 */     this._inputPtr -= 1;
/* 1591 */     return _valueCompleteInt(0, "0");
/*      */   }
/*      */   
/*      */   protected JsonToken _finishNumberIntegralPart(char[] outBuf, int outPtr)
/*      */     throws IOException
/*      */   {
/* 1597 */     int negMod = this._numberNegative ? -1 : 0;
/*      */     for (;;)
/*      */     {
/* 1600 */       if (this._inputPtr >= this._inputEnd) {
/* 1601 */         this._minorState = 26;
/* 1602 */         this._textBuffer.setCurrentLength(outPtr);
/* 1603 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1605 */       int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 1606 */       if (ch < 48) {
/* 1607 */         if (ch != 46) break;
/* 1608 */         this._intLength = (outPtr + negMod);
/* 1609 */         this._inputPtr += 1;
/* 1610 */         return _startFloat(outBuf, outPtr, ch);
/*      */       }
/*      */       
/*      */ 
/* 1614 */       if (ch > 57) {
/* 1615 */         if ((ch != 101) && (ch != 69)) break;
/* 1616 */         this._intLength = (outPtr + negMod);
/* 1617 */         this._inputPtr += 1;
/* 1618 */         return _startFloat(outBuf, outPtr, ch);
/*      */       }
/*      */       
/*      */ 
/* 1622 */       this._inputPtr += 1;
/* 1623 */       if (outPtr >= outBuf.length)
/*      */       {
/*      */ 
/* 1626 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1628 */       outBuf[(outPtr++)] = ((char)ch);
/*      */     }
/* 1630 */     this._intLength = (outPtr + negMod);
/* 1631 */     this._textBuffer.setCurrentLength(outPtr);
/* 1632 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */   
/*      */   protected JsonToken _startFloat(char[] outBuf, int outPtr, int ch) throws IOException
/*      */   {
/* 1637 */     int fractLen = 0;
/* 1638 */     if (ch == 46) {
/* 1639 */       if (outPtr >= outBuf.length) {
/* 1640 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1642 */       outBuf[(outPtr++)] = '.';
/*      */       for (;;) {
/* 1644 */         if (this._inputPtr >= this._inputEnd) {
/* 1645 */           this._textBuffer.setCurrentLength(outPtr);
/* 1646 */           this._minorState = 30;
/* 1647 */           this._fractLength = fractLen;
/* 1648 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         }
/* 1650 */         ch = this._inputBuffer[(this._inputPtr++)];
/* 1651 */         if ((ch < 48) || (ch > 57)) {
/* 1652 */           ch &= 0xFF;
/*      */           
/* 1654 */           if (fractLen != 0) break;
/* 1655 */           reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit"); break;
/*      */         }
/*      */         
/*      */ 
/* 1659 */         if (outPtr >= outBuf.length) {
/* 1660 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1662 */         outBuf[(outPtr++)] = ((char)ch);
/* 1663 */         fractLen++;
/*      */       }
/*      */     }
/* 1666 */     this._fractLength = fractLen;
/* 1667 */     int expLen = 0;
/* 1668 */     if ((ch == 101) || (ch == 69)) {
/* 1669 */       if (outPtr >= outBuf.length) {
/* 1670 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1672 */       outBuf[(outPtr++)] = ((char)ch);
/* 1673 */       if (this._inputPtr >= this._inputEnd) {
/* 1674 */         this._textBuffer.setCurrentLength(outPtr);
/* 1675 */         this._minorState = 31;
/* 1676 */         this._expLength = 0;
/* 1677 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1679 */       ch = this._inputBuffer[(this._inputPtr++)];
/* 1680 */       if ((ch == 45) || (ch == 43)) {
/* 1681 */         if (outPtr >= outBuf.length) {
/* 1682 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1684 */         outBuf[(outPtr++)] = ((char)ch);
/* 1685 */         if (this._inputPtr >= this._inputEnd) {
/* 1686 */           this._textBuffer.setCurrentLength(outPtr);
/* 1687 */           this._minorState = 32;
/* 1688 */           this._expLength = 0;
/* 1689 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         }
/* 1691 */         ch = this._inputBuffer[(this._inputPtr++)];
/*      */       }
/* 1693 */       while ((ch >= 48) && (ch <= 57)) {
/* 1694 */         expLen++;
/* 1695 */         if (outPtr >= outBuf.length) {
/* 1696 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1698 */         outBuf[(outPtr++)] = ((char)ch);
/* 1699 */         if (this._inputPtr >= this._inputEnd) {
/* 1700 */           this._textBuffer.setCurrentLength(outPtr);
/* 1701 */           this._minorState = 32;
/* 1702 */           this._expLength = expLen;
/* 1703 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         }
/* 1705 */         ch = this._inputBuffer[(this._inputPtr++)];
/*      */       }
/*      */       
/* 1708 */       ch &= 0xFF;
/* 1709 */       if (expLen == 0) {
/* 1710 */         reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     }
/*      */     
/* 1714 */     this._inputPtr -= 1;
/* 1715 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1717 */     this._expLength = expLen;
/* 1718 */     return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */   }
/*      */   
/*      */   protected JsonToken _finishFloatFraction() throws IOException
/*      */   {
/* 1723 */     int fractLen = this._fractLength;
/* 1724 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 1725 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     
/*      */     int ch;
/*      */     
/* 1729 */     while (((ch = this._inputBuffer[(this._inputPtr++)]) >= 48) && (ch <= 57)) {
/* 1730 */       fractLen++;
/* 1731 */       if (outPtr >= outBuf.length) {
/* 1732 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1734 */       outBuf[(outPtr++)] = ((char)ch);
/* 1735 */       if (this._inputPtr >= this._inputEnd) {
/* 1736 */         this._textBuffer.setCurrentLength(outPtr);
/* 1737 */         this._fractLength = fractLen;
/* 1738 */         return JsonToken.NOT_AVAILABLE;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1744 */     if (fractLen == 0) {
/* 1745 */       reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit");
/*      */     }
/* 1747 */     this._fractLength = fractLen;
/* 1748 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/*      */ 
/* 1751 */     if ((ch == 101) || (ch == 69)) {
/* 1752 */       this._textBuffer.append((char)ch);
/* 1753 */       this._expLength = 0;
/* 1754 */       if (this._inputPtr >= this._inputEnd) {
/* 1755 */         this._minorState = 31;
/* 1756 */         return JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1758 */       this._minorState = 32;
/* 1759 */       return _finishFloatExponent(true, this._inputBuffer[(this._inputPtr++)] & 0xFF);
/*      */     }
/*      */     
/*      */ 
/* 1763 */     this._inputPtr -= 1;
/* 1764 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1766 */     this._expLength = 0;
/* 1767 */     return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */   }
/*      */   
/*      */   protected JsonToken _finishFloatExponent(boolean checkSign, int ch) throws IOException
/*      */   {
/* 1772 */     if (checkSign) {
/* 1773 */       this._minorState = 32;
/* 1774 */       if ((ch == 45) || (ch == 43)) {
/* 1775 */         this._textBuffer.append((char)ch);
/* 1776 */         if (this._inputPtr >= this._inputEnd) {
/* 1777 */           this._minorState = 32;
/* 1778 */           this._expLength = 0;
/* 1779 */           return JsonToken.NOT_AVAILABLE;
/*      */         }
/* 1781 */         ch = this._inputBuffer[(this._inputPtr++)];
/*      */       }
/*      */     }
/*      */     
/* 1785 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 1786 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 1787 */     int expLen = this._expLength;
/*      */     
/* 1789 */     while ((ch >= 48) && (ch <= 57)) {
/* 1790 */       expLen++;
/* 1791 */       if (outPtr >= outBuf.length) {
/* 1792 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1794 */       outBuf[(outPtr++)] = ((char)ch);
/* 1795 */       if (this._inputPtr >= this._inputEnd) {
/* 1796 */         this._textBuffer.setCurrentLength(outPtr);
/* 1797 */         this._expLength = expLen;
/* 1798 */         return JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1800 */       ch = this._inputBuffer[(this._inputPtr++)];
/*      */     }
/*      */     
/* 1803 */     ch &= 0xFF;
/* 1804 */     if (expLen == 0) {
/* 1805 */       reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */     }
/*      */     
/* 1808 */     this._inputPtr -= 1;
/* 1809 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1811 */     this._expLength = expLen;
/* 1812 */     return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String _fastParseName()
/*      */     throws IOException
/*      */   {
/* 1828 */     byte[] input = this._inputBuffer;
/* 1829 */     int[] codes = _icLatin1;
/* 1830 */     int ptr = this._inputPtr;
/*      */     
/* 1832 */     int q0 = input[(ptr++)] & 0xFF;
/* 1833 */     if (codes[q0] == 0) {
/* 1834 */       int i = input[(ptr++)] & 0xFF;
/* 1835 */       if (codes[i] == 0) {
/* 1836 */         int q = q0 << 8 | i;
/* 1837 */         i = input[(ptr++)] & 0xFF;
/* 1838 */         if (codes[i] == 0) {
/* 1839 */           q = q << 8 | i;
/* 1840 */           i = input[(ptr++)] & 0xFF;
/* 1841 */           if (codes[i] == 0) {
/* 1842 */             q = q << 8 | i;
/* 1843 */             i = input[(ptr++)] & 0xFF;
/* 1844 */             if (codes[i] == 0) {
/* 1845 */               this._quad1 = q;
/* 1846 */               return _parseMediumName(ptr, i);
/*      */             }
/* 1848 */             if (i == 34) {
/* 1849 */               this._inputPtr = ptr;
/* 1850 */               return _findName(q, 4);
/*      */             }
/* 1852 */             return null;
/*      */           }
/* 1854 */           if (i == 34) {
/* 1855 */             this._inputPtr = ptr;
/* 1856 */             return _findName(q, 3);
/*      */           }
/* 1858 */           return null;
/*      */         }
/* 1860 */         if (i == 34) {
/* 1861 */           this._inputPtr = ptr;
/* 1862 */           return _findName(q, 2);
/*      */         }
/* 1864 */         return null;
/*      */       }
/* 1866 */       if (i == 34) {
/* 1867 */         this._inputPtr = ptr;
/* 1868 */         return _findName(q0, 1);
/*      */       }
/* 1870 */       return null;
/*      */     }
/* 1872 */     if (q0 == 34) {
/* 1873 */       this._inputPtr = ptr;
/* 1874 */       return "";
/*      */     }
/* 1876 */     return null;
/*      */   }
/*      */   
/*      */   private final String _parseMediumName(int ptr, int q2) throws IOException
/*      */   {
/* 1881 */     byte[] input = this._inputBuffer;
/* 1882 */     int[] codes = _icLatin1;
/*      */     
/*      */ 
/* 1885 */     int i = input[(ptr++)] & 0xFF;
/* 1886 */     if (codes[i] == 0) {
/* 1887 */       q2 = q2 << 8 | i;
/* 1888 */       i = input[(ptr++)] & 0xFF;
/* 1889 */       if (codes[i] == 0) {
/* 1890 */         q2 = q2 << 8 | i;
/* 1891 */         i = input[(ptr++)] & 0xFF;
/* 1892 */         if (codes[i] == 0) {
/* 1893 */           q2 = q2 << 8 | i;
/* 1894 */           i = input[(ptr++)] & 0xFF;
/* 1895 */           if (codes[i] == 0) {
/* 1896 */             return _parseMediumName2(ptr, i, q2);
/*      */           }
/* 1898 */           if (i == 34) {
/* 1899 */             this._inputPtr = ptr;
/* 1900 */             return _findName(this._quad1, q2, 4);
/*      */           }
/* 1902 */           return null;
/*      */         }
/* 1904 */         if (i == 34) {
/* 1905 */           this._inputPtr = ptr;
/* 1906 */           return _findName(this._quad1, q2, 3);
/*      */         }
/* 1908 */         return null;
/*      */       }
/* 1910 */       if (i == 34) {
/* 1911 */         this._inputPtr = ptr;
/* 1912 */         return _findName(this._quad1, q2, 2);
/*      */       }
/* 1914 */       return null;
/*      */     }
/* 1916 */     if (i == 34) {
/* 1917 */       this._inputPtr = ptr;
/* 1918 */       return _findName(this._quad1, q2, 1);
/*      */     }
/* 1920 */     return null;
/*      */   }
/*      */   
/*      */   private final String _parseMediumName2(int ptr, int q3, int q2) throws IOException
/*      */   {
/* 1925 */     byte[] input = this._inputBuffer;
/* 1926 */     int[] codes = _icLatin1;
/*      */     
/*      */ 
/* 1929 */     int i = input[(ptr++)] & 0xFF;
/* 1930 */     if (codes[i] != 0) {
/* 1931 */       if (i == 34) {
/* 1932 */         this._inputPtr = ptr;
/* 1933 */         return _findName(this._quad1, q2, q3, 1);
/*      */       }
/* 1935 */       return null;
/*      */     }
/* 1937 */     q3 = q3 << 8 | i;
/* 1938 */     i = input[(ptr++)] & 0xFF;
/* 1939 */     if (codes[i] != 0) {
/* 1940 */       if (i == 34) {
/* 1941 */         this._inputPtr = ptr;
/* 1942 */         return _findName(this._quad1, q2, q3, 2);
/*      */       }
/* 1944 */       return null;
/*      */     }
/* 1946 */     q3 = q3 << 8 | i;
/* 1947 */     i = input[(ptr++)] & 0xFF;
/* 1948 */     if (codes[i] != 0) {
/* 1949 */       if (i == 34) {
/* 1950 */         this._inputPtr = ptr;
/* 1951 */         return _findName(this._quad1, q2, q3, 3);
/*      */       }
/* 1953 */       return null;
/*      */     }
/* 1955 */     q3 = q3 << 8 | i;
/* 1956 */     i = input[(ptr++)] & 0xFF;
/* 1957 */     if (i == 34) {
/* 1958 */       this._inputPtr = ptr;
/* 1959 */       return _findName(this._quad1, q2, q3, 4);
/*      */     }
/*      */     
/* 1962 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final JsonToken _parseEscapedName(int qlen, int currQuad, int currQuadBytes)
/*      */     throws IOException
/*      */   {
/* 1978 */     int[] quads = this._quadBuffer;
/* 1979 */     int[] codes = _icLatin1;
/*      */     for (;;)
/*      */     {
/* 1982 */       if (this._inputPtr >= this._inputEnd) {
/* 1983 */         this._quadLength = qlen;
/* 1984 */         this._pending32 = currQuad;
/* 1985 */         this._pendingBytes = currQuadBytes;
/* 1986 */         this._minorState = 7;
/* 1987 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 1989 */       int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1990 */       if (codes[ch] == 0) {
/* 1991 */         if (currQuadBytes < 4) {
/* 1992 */           currQuadBytes++;
/* 1993 */           currQuad = currQuad << 8 | ch;
/*      */         }
/*      */         else {
/* 1996 */           if (qlen >= quads.length) {
/* 1997 */             this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */           }
/* 1999 */           quads[(qlen++)] = currQuad;
/* 2000 */           currQuad = ch;
/* 2001 */           currQuadBytes = 1;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 2006 */         if (ch == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 2010 */         if (ch != 92)
/*      */         {
/* 2012 */           _throwUnquotedSpace(ch, "name");
/*      */         }
/*      */         else {
/* 2015 */           ch = _decodeCharEscape();
/* 2016 */           if (ch < 0) {
/* 2017 */             this._minorState = 8;
/* 2018 */             this._minorStateAfterSplit = 7;
/* 2019 */             this._quadLength = qlen;
/* 2020 */             this._pending32 = currQuad;
/* 2021 */             this._pendingBytes = currQuadBytes;
/* 2022 */             return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2029 */         if (qlen >= quads.length) {
/* 2030 */           this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */         }
/* 2032 */         if (ch > 127)
/*      */         {
/* 2034 */           if (currQuadBytes >= 4) {
/* 2035 */             quads[(qlen++)] = currQuad;
/* 2036 */             currQuad = 0;
/* 2037 */             currQuadBytes = 0;
/*      */           }
/* 2039 */           if (ch < 2048) {
/* 2040 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2041 */             currQuadBytes++;
/*      */           }
/*      */           else {
/* 2044 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2045 */             currQuadBytes++;
/*      */             
/* 2047 */             if (currQuadBytes >= 4) {
/* 2048 */               quads[(qlen++)] = currQuad;
/* 2049 */               currQuad = 0;
/* 2050 */               currQuadBytes = 0;
/*      */             }
/* 2052 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2053 */             currQuadBytes++;
/*      */           }
/*      */           
/* 2056 */           ch = 0x80 | ch & 0x3F;
/*      */         }
/* 2058 */         if (currQuadBytes < 4) {
/* 2059 */           currQuadBytes++;
/* 2060 */           currQuad = currQuad << 8 | ch;
/*      */         }
/*      */         else {
/* 2063 */           quads[(qlen++)] = currQuad;
/* 2064 */           currQuad = ch;
/* 2065 */           currQuadBytes = 1;
/*      */         }
/*      */       } }
/* 2068 */     if (currQuadBytes > 0) {
/* 2069 */       if (qlen >= quads.length) {
/* 2070 */         this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */       }
/* 2072 */       quads[(qlen++)] = _padLastQuad(currQuad, currQuadBytes);
/* 2073 */     } else if (qlen == 0) {
/* 2074 */       return _fieldComplete("");
/*      */     }
/* 2076 */     String name = this._symbols.findName(quads, qlen);
/* 2077 */     if (name == null) {
/* 2078 */       name = _addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2080 */     return _fieldComplete(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private JsonToken _handleOddName(int ch)
/*      */     throws IOException
/*      */   {
/* 2092 */     switch (ch)
/*      */     {
/*      */ 
/*      */     case 35: 
/* 2096 */       if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) != 0) {
/* 2097 */         return _finishHashComment(4);
/*      */       }
/*      */       break;
/*      */     case 47: 
/* 2101 */       return _startSlashComment(4);
/*      */     case 39: 
/* 2103 */       if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2104 */         return _finishAposName(0, 0, 0);
/*      */       }
/*      */       break;
/*      */     case 93: 
/* 2108 */       return _closeArrayScope();
/*      */     }
/*      */     
/* 2111 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0)
/*      */     {
/*      */ 
/* 2114 */       char c = (char)ch;
/* 2115 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     }
/*      */     
/*      */ 
/* 2119 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 2121 */     if (codes[ch] != 0) {
/* 2122 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */     
/* 2125 */     return _finishUnquotedName(0, ch, 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private JsonToken _finishUnquotedName(int qlen, int currQuad, int currQuadBytes)
/*      */     throws IOException
/*      */   {
/* 2136 */     int[] quads = this._quadBuffer;
/* 2137 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/*      */ 
/*      */     for (;;)
/*      */     {
/* 2142 */       if (this._inputPtr >= this._inputEnd) {
/* 2143 */         this._quadLength = qlen;
/* 2144 */         this._pending32 = currQuad;
/* 2145 */         this._pendingBytes = currQuadBytes;
/* 2146 */         this._minorState = 10;
/* 2147 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 2149 */       int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2150 */       if (codes[ch] != 0) {
/*      */         break;
/*      */       }
/* 2153 */       this._inputPtr += 1;
/*      */       
/* 2155 */       if (currQuadBytes < 4) {
/* 2156 */         currQuadBytes++;
/* 2157 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2159 */         if (qlen >= quads.length) {
/* 2160 */           this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */         }
/* 2162 */         quads[(qlen++)] = currQuad;
/* 2163 */         currQuad = ch;
/* 2164 */         currQuadBytes = 1;
/*      */       }
/*      */     }
/*      */     
/* 2168 */     if (currQuadBytes > 0) {
/* 2169 */       if (qlen >= quads.length) {
/* 2170 */         this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */       }
/* 2172 */       quads[(qlen++)] = currQuad;
/*      */     }
/* 2174 */     String name = this._symbols.findName(quads, qlen);
/* 2175 */     if (name == null) {
/* 2176 */       name = _addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2178 */     return _fieldComplete(name);
/*      */   }
/*      */   
/*      */   private JsonToken _finishAposName(int qlen, int currQuad, int currQuadBytes)
/*      */     throws IOException
/*      */   {
/* 2184 */     int[] quads = this._quadBuffer;
/* 2185 */     int[] codes = _icLatin1;
/*      */     for (;;)
/*      */     {
/* 2188 */       if (this._inputPtr >= this._inputEnd) {
/* 2189 */         this._quadLength = qlen;
/* 2190 */         this._pending32 = currQuad;
/* 2191 */         this._pendingBytes = currQuadBytes;
/* 2192 */         this._minorState = 9;
/* 2193 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 2195 */       int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2196 */       if (ch == 39) {
/*      */         break;
/*      */       }
/*      */       
/* 2200 */       if ((ch != 34) && (codes[ch] != 0)) {
/* 2201 */         if (ch != 92)
/*      */         {
/* 2203 */           _throwUnquotedSpace(ch, "name");
/*      */         }
/*      */         else {
/* 2206 */           ch = _decodeCharEscape();
/* 2207 */           if (ch < 0) {
/* 2208 */             this._minorState = 8;
/* 2209 */             this._minorStateAfterSplit = 9;
/* 2210 */             this._quadLength = qlen;
/* 2211 */             this._pending32 = currQuad;
/* 2212 */             this._pendingBytes = currQuadBytes;
/* 2213 */             return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */           }
/*      */         }
/* 2216 */         if (ch > 127)
/*      */         {
/* 2218 */           if (currQuadBytes >= 4) {
/* 2219 */             if (qlen >= quads.length) {
/* 2220 */               this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */             }
/* 2222 */             quads[(qlen++)] = currQuad;
/* 2223 */             currQuad = 0;
/* 2224 */             currQuadBytes = 0;
/*      */           }
/* 2226 */           if (ch < 2048) {
/* 2227 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2228 */             currQuadBytes++;
/*      */           }
/*      */           else {
/* 2231 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2232 */             currQuadBytes++;
/*      */             
/* 2234 */             if (currQuadBytes >= 4) {
/* 2235 */               if (qlen >= quads.length) {
/* 2236 */                 this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */               }
/* 2238 */               quads[(qlen++)] = currQuad;
/* 2239 */               currQuad = 0;
/* 2240 */               currQuadBytes = 0;
/*      */             }
/* 2242 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2243 */             currQuadBytes++;
/*      */           }
/*      */           
/* 2246 */           ch = 0x80 | ch & 0x3F;
/*      */         }
/*      */       }
/*      */       
/* 2250 */       if (currQuadBytes < 4) {
/* 2251 */         currQuadBytes++;
/* 2252 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2254 */         if (qlen >= quads.length) {
/* 2255 */           this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */         }
/* 2257 */         quads[(qlen++)] = currQuad;
/* 2258 */         currQuad = ch;
/* 2259 */         currQuadBytes = 1;
/*      */       }
/*      */     }
/*      */     
/* 2263 */     if (currQuadBytes > 0) {
/* 2264 */       if (qlen >= quads.length) {
/* 2265 */         this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */       }
/* 2267 */       quads[(qlen++)] = _padLastQuad(currQuad, currQuadBytes);
/* 2268 */     } else if (qlen == 0) {
/* 2269 */       return _fieldComplete("");
/*      */     }
/* 2271 */     String name = this._symbols.findName(quads, qlen);
/* 2272 */     if (name == null) {
/* 2273 */       name = _addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2275 */     return _fieldComplete(name);
/*      */   }
/*      */   
/*      */   protected final JsonToken _finishFieldWithEscape()
/*      */     throws IOException
/*      */   {
/* 2281 */     int ch = _decodeSplitEscaped(this._quoted32, this._quotedDigits);
/* 2282 */     if (ch < 0) {
/* 2283 */       this._minorState = 8;
/* 2284 */       return JsonToken.NOT_AVAILABLE;
/*      */     }
/* 2286 */     if (this._quadLength >= this._quadBuffer.length) {
/* 2287 */       this._quadBuffer = growArrayBy(this._quadBuffer, 32);
/*      */     }
/* 2289 */     int currQuad = this._pending32;
/* 2290 */     int currQuadBytes = this._pendingBytes;
/* 2291 */     if (ch > 127)
/*      */     {
/* 2293 */       if (currQuadBytes >= 4) {
/* 2294 */         this._quadBuffer[(this._quadLength++)] = currQuad;
/* 2295 */         currQuad = 0;
/* 2296 */         currQuadBytes = 0;
/*      */       }
/* 2298 */       if (ch < 2048) {
/* 2299 */         currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2300 */         currQuadBytes++;
/*      */       }
/*      */       else {
/* 2303 */         currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/*      */         
/* 2305 */         currQuadBytes++; if (currQuadBytes >= 4) {
/* 2306 */           this._quadBuffer[(this._quadLength++)] = currQuad;
/* 2307 */           currQuad = 0;
/* 2308 */           currQuadBytes = 0;
/*      */         }
/* 2310 */         currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2311 */         currQuadBytes++;
/*      */       }
/*      */       
/* 2314 */       ch = 0x80 | ch & 0x3F;
/*      */     }
/* 2316 */     if (currQuadBytes < 4) {
/* 2317 */       currQuadBytes++;
/* 2318 */       currQuad = currQuad << 8 | ch;
/*      */     } else {
/* 2320 */       this._quadBuffer[(this._quadLength++)] = currQuad;
/* 2321 */       currQuad = ch;
/* 2322 */       currQuadBytes = 1;
/*      */     }
/* 2324 */     if (this._minorStateAfterSplit == 9) {
/* 2325 */       return _finishAposName(this._quadLength, currQuad, currQuadBytes);
/*      */     }
/* 2327 */     return _parseEscapedName(this._quadLength, currQuad, currQuadBytes);
/*      */   }
/*      */   
/*      */   private int _decodeSplitEscaped(int value, int bytesRead) throws IOException
/*      */   {
/* 2332 */     if (this._inputPtr >= this._inputEnd) {
/* 2333 */       this._quoted32 = value;
/* 2334 */       this._quotedDigits = bytesRead;
/* 2335 */       return -1;
/*      */     }
/* 2337 */     int c = this._inputBuffer[(this._inputPtr++)];
/* 2338 */     if (bytesRead == -1) {
/* 2339 */       switch (c)
/*      */       {
/*      */       case 98: 
/* 2342 */         return 8;
/*      */       case 116: 
/* 2344 */         return 9;
/*      */       case 110: 
/* 2346 */         return 10;
/*      */       case 102: 
/* 2348 */         return 12;
/*      */       case 114: 
/* 2350 */         return 13;
/*      */       
/*      */ 
/*      */       case 34: 
/*      */       case 47: 
/*      */       case 92: 
/* 2356 */         return c;
/*      */       
/*      */ 
/*      */       case 117: 
/*      */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       default: 
/* 2365 */         char ch = (char)c;
/* 2366 */         return _handleUnrecognizedCharacterEscape(ch);
/*      */       }
/*      */       
/* 2369 */       if (this._inputPtr >= this._inputEnd) {
/* 2370 */         this._quotedDigits = 0;
/* 2371 */         this._quoted32 = 0;
/* 2372 */         return -1;
/*      */       }
/* 2374 */       c = this._inputBuffer[(this._inputPtr++)];
/* 2375 */       bytesRead = 0;
/*      */     }
/* 2377 */     c &= 0xFF;
/*      */     for (;;) {
/* 2379 */       int digit = CharTypes.charToHex(c);
/* 2380 */       if (digit < 0) {
/* 2381 */         _reportUnexpectedChar(c & 0xFF, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2383 */       value = value << 4 | digit;
/* 2384 */       bytesRead++; if (bytesRead == 4) {
/* 2385 */         return value;
/*      */       }
/* 2387 */       if (this._inputPtr >= this._inputEnd) {
/* 2388 */         this._quotedDigits = bytesRead;
/* 2389 */         this._quoted32 = value;
/* 2390 */         return -1;
/*      */       }
/* 2392 */       c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonToken _startString()
/*      */     throws IOException
/*      */   {
/* 2404 */     int ptr = this._inputPtr;
/* 2405 */     int outPtr = 0;
/* 2406 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2407 */     int[] codes = _icUTF8;
/*      */     
/* 2409 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2410 */     byte[] inputBuffer = this._inputBuffer;
/* 2411 */     while (ptr < max) {
/* 2412 */       int c = inputBuffer[ptr] & 0xFF;
/* 2413 */       if (codes[c] != 0) {
/* 2414 */         if (c != 34) break;
/* 2415 */         this._inputPtr = (ptr + 1);
/* 2416 */         this._textBuffer.setCurrentLength(outPtr);
/* 2417 */         return _valueComplete(JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/*      */ 
/* 2421 */       ptr++;
/* 2422 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 2424 */     this._textBuffer.setCurrentLength(outPtr);
/* 2425 */     this._inputPtr = ptr;
/* 2426 */     return _finishRegularString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private final JsonToken _finishRegularString()
/*      */     throws IOException
/*      */   {
/* 2434 */     int[] codes = _icUTF8;
/* 2435 */     byte[] inputBuffer = this._inputBuffer;
/*      */     
/* 2437 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 2438 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2439 */     int ptr = this._inputPtr;
/* 2440 */     int safeEnd = this._inputEnd - 5;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 2447 */       if (ptr >= this._inputEnd) {
/* 2448 */         this._inputPtr = ptr;
/* 2449 */         this._minorState = 40;
/* 2450 */         this._textBuffer.setCurrentLength(outPtr);
/* 2451 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 2453 */       if (outPtr >= outBuf.length) {
/* 2454 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2455 */         outPtr = 0;
/*      */       }
/* 2457 */       int max = Math.min(this._inputEnd, ptr + (outBuf.length - outPtr));
/* 2458 */       while (ptr < max) {
/* 2459 */         int c = inputBuffer[(ptr++)] & 0xFF;
/* 2460 */         if (codes[c] != 0) {
/*      */           break label162;
/*      */         }
/* 2463 */         outBuf[(outPtr++)] = ((char)c);
/*      */       }
/* 2465 */       continue;
/*      */       label162:
/* 2467 */       int c; if (c == 34) {
/* 2468 */         this._inputPtr = ptr;
/* 2469 */         this._textBuffer.setCurrentLength(outPtr);
/* 2470 */         return _valueComplete(JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/* 2473 */       if (ptr >= safeEnd) {
/* 2474 */         this._inputPtr = ptr;
/* 2475 */         this._textBuffer.setCurrentLength(outPtr);
/* 2476 */         if (!_decodeSplitMultiByte(c, codes[c], ptr < this._inputEnd)) {
/* 2477 */           this._minorStateAfterSplit = 40;
/* 2478 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         }
/* 2480 */         outBuf = this._textBuffer.getBufferWithoutReset();
/* 2481 */         outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2482 */         ptr = this._inputPtr;
/*      */       }
/*      */       else
/*      */       {
/* 2486 */         switch (codes[c]) {
/*      */         case 1: 
/* 2488 */           this._inputPtr = ptr;
/* 2489 */           c = _decodeFastCharEscape();
/* 2490 */           ptr = this._inputPtr;
/* 2491 */           break;
/*      */         case 2: 
/* 2493 */           c = _decodeUTF8_2(c, this._inputBuffer[(ptr++)]);
/* 2494 */           break;
/*      */         case 3: 
/* 2496 */           c = _decodeUTF8_3(c, this._inputBuffer[(ptr++)], this._inputBuffer[(ptr++)]);
/* 2497 */           break;
/*      */         case 4: 
/* 2499 */           c = _decodeUTF8_4(c, this._inputBuffer[(ptr++)], this._inputBuffer[(ptr++)], this._inputBuffer[(ptr++)]);
/*      */           
/*      */ 
/* 2502 */           outBuf[(outPtr++)] = ((char)(0xD800 | c >> 10));
/* 2503 */           if (outPtr >= outBuf.length) {
/* 2504 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2505 */             outPtr = 0;
/*      */           }
/* 2507 */           c = 0xDC00 | c & 0x3FF;
/*      */           
/* 2509 */           break;
/*      */         default: 
/* 2511 */           if (c < 32)
/*      */           {
/* 2513 */             _throwUnquotedSpace(c, "string value");
/*      */           }
/*      */           else {
/* 2516 */             _reportInvalidChar(c);
/*      */           }
/*      */           break;
/*      */         }
/* 2520 */         if (outPtr >= outBuf.length) {
/* 2521 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 2522 */           outPtr = 0;
/*      */         }
/*      */         
/* 2525 */         outBuf[(outPtr++)] = ((char)c);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected JsonToken _startAposString() throws IOException {
/* 2531 */     int ptr = this._inputPtr;
/* 2532 */     int outPtr = 0;
/* 2533 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2534 */     int[] codes = _icUTF8;
/*      */     
/* 2536 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2537 */     byte[] inputBuffer = this._inputBuffer;
/* 2538 */     while (ptr < max) {
/* 2539 */       int c = inputBuffer[ptr] & 0xFF;
/* 2540 */       if (c == 39) {
/* 2541 */         this._inputPtr = (ptr + 1);
/* 2542 */         this._textBuffer.setCurrentLength(outPtr);
/* 2543 */         return _valueComplete(JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/* 2546 */       if (codes[c] != 0) {
/*      */         break;
/*      */       }
/* 2549 */       ptr++;
/* 2550 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 2552 */     this._textBuffer.setCurrentLength(outPtr);
/* 2553 */     this._inputPtr = ptr;
/* 2554 */     return _finishAposString();
/*      */   }
/*      */   
/*      */   private final JsonToken _finishAposString()
/*      */     throws IOException
/*      */   {
/* 2560 */     int[] codes = _icUTF8;
/* 2561 */     byte[] inputBuffer = this._inputBuffer;
/*      */     
/* 2563 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 2564 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2565 */     int ptr = this._inputPtr;
/* 2566 */     int safeEnd = this._inputEnd - 5;
/*      */     
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 2572 */       if (ptr >= this._inputEnd) {
/* 2573 */         this._inputPtr = ptr;
/* 2574 */         this._minorState = 45;
/* 2575 */         this._textBuffer.setCurrentLength(outPtr);
/* 2576 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       }
/* 2578 */       if (outPtr >= outBuf.length) {
/* 2579 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2580 */         outPtr = 0;
/*      */       }
/* 2582 */       int max = Math.min(this._inputEnd, ptr + (outBuf.length - outPtr));
/* 2583 */       while (ptr < max) {
/* 2584 */         int c = inputBuffer[(ptr++)] & 0xFF;
/* 2585 */         if ((codes[c] != 0) && (c != 34)) {
/*      */           break label197;
/*      */         }
/* 2588 */         if (c == 39) {
/* 2589 */           this._inputPtr = ptr;
/* 2590 */           this._textBuffer.setCurrentLength(outPtr);
/* 2591 */           return _valueComplete(JsonToken.VALUE_STRING);
/*      */         }
/* 2593 */         outBuf[(outPtr++)] = ((char)c);
/*      */       }
/* 2595 */       continue;
/*      */       label197:
/*      */       int c;
/* 2598 */       if (ptr >= safeEnd) {
/* 2599 */         this._inputPtr = ptr;
/* 2600 */         this._textBuffer.setCurrentLength(outPtr);
/* 2601 */         if (!_decodeSplitMultiByte(c, codes[c], ptr < this._inputEnd)) {
/* 2602 */           this._minorStateAfterSplit = 45;
/* 2603 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         }
/* 2605 */         outBuf = this._textBuffer.getBufferWithoutReset();
/* 2606 */         outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2607 */         ptr = this._inputPtr;
/*      */       }
/*      */       else
/*      */       {
/* 2611 */         switch (codes[c]) {
/*      */         case 1: 
/* 2613 */           this._inputPtr = ptr;
/* 2614 */           c = _decodeFastCharEscape();
/* 2615 */           ptr = this._inputPtr;
/* 2616 */           break;
/*      */         case 2: 
/* 2618 */           c = _decodeUTF8_2(c, this._inputBuffer[(ptr++)]);
/* 2619 */           break;
/*      */         case 3: 
/* 2621 */           c = _decodeUTF8_3(c, this._inputBuffer[(ptr++)], this._inputBuffer[(ptr++)]);
/* 2622 */           break;
/*      */         case 4: 
/* 2624 */           c = _decodeUTF8_4(c, this._inputBuffer[(ptr++)], this._inputBuffer[(ptr++)], this._inputBuffer[(ptr++)]);
/*      */           
/*      */ 
/* 2627 */           outBuf[(outPtr++)] = ((char)(0xD800 | c >> 10));
/* 2628 */           if (outPtr >= outBuf.length) {
/* 2629 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2630 */             outPtr = 0;
/*      */           }
/* 2632 */           c = 0xDC00 | c & 0x3FF;
/*      */           
/* 2634 */           break;
/*      */         default: 
/* 2636 */           if (c < 32)
/*      */           {
/* 2638 */             _throwUnquotedSpace(c, "string value");
/*      */           }
/*      */           else {
/* 2641 */             _reportInvalidChar(c);
/*      */           }
/*      */           break;
/*      */         }
/* 2645 */         if (outPtr >= outBuf.length) {
/* 2646 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 2647 */           outPtr = 0;
/*      */         }
/*      */         
/* 2650 */         outBuf[(outPtr++)] = ((char)c);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private final boolean _decodeSplitMultiByte(int c, int type, boolean gotNext) throws IOException
/*      */   {
/* 2657 */     switch (type) {
/*      */     case 1: 
/* 2659 */       c = _decodeSplitEscaped(0, -1);
/* 2660 */       if (c < 0) {
/* 2661 */         this._minorState = 41;
/* 2662 */         return false;
/*      */       }
/* 2664 */       this._textBuffer.append((char)c);
/* 2665 */       return true;
/*      */     case 2: 
/* 2667 */       if (gotNext)
/*      */       {
/* 2669 */         c = _decodeUTF8_2(c, this._inputBuffer[(this._inputPtr++)]);
/* 2670 */         this._textBuffer.append((char)c);
/* 2671 */         return true;
/*      */       }
/* 2673 */       this._minorState = 42;
/* 2674 */       this._pending32 = c;
/* 2675 */       return false;
/*      */     case 3: 
/* 2677 */       c &= 0xF;
/* 2678 */       if (gotNext) {
/* 2679 */         return _decodeSplitUTF8_3(c, 1, this._inputBuffer[(this._inputPtr++)]);
/*      */       }
/* 2681 */       this._minorState = 43;
/* 2682 */       this._pending32 = c;
/* 2683 */       this._pendingBytes = 1;
/* 2684 */       return false;
/*      */     case 4: 
/* 2686 */       c &= 0x7;
/* 2687 */       if (gotNext) {
/* 2688 */         return _decodeSplitUTF8_4(c, 1, this._inputBuffer[(this._inputPtr++)]);
/*      */       }
/* 2690 */       this._pending32 = c;
/* 2691 */       this._pendingBytes = 1;
/* 2692 */       this._minorState = 44;
/* 2693 */       return false;
/*      */     }
/* 2695 */     if (c < 32)
/*      */     {
/* 2697 */       _throwUnquotedSpace(c, "string value");
/*      */     }
/*      */     else {
/* 2700 */       _reportInvalidChar(c);
/*      */     }
/* 2702 */     this._textBuffer.append((char)c);
/* 2703 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   private final boolean _decodeSplitUTF8_3(int prev, int prevCount, int next)
/*      */     throws IOException
/*      */   {
/* 2710 */     if (prevCount == 1) {
/* 2711 */       if ((next & 0xC0) != 128) {
/* 2712 */         _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */       }
/* 2714 */       prev = prev << 6 | next & 0x3F;
/* 2715 */       if (this._inputPtr >= this._inputEnd) {
/* 2716 */         this._minorState = 43;
/* 2717 */         this._pending32 = prev;
/* 2718 */         this._pendingBytes = 2;
/* 2719 */         return false;
/*      */       }
/* 2721 */       next = this._inputBuffer[(this._inputPtr++)];
/*      */     }
/* 2723 */     if ((next & 0xC0) != 128) {
/* 2724 */       _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */     }
/* 2726 */     this._textBuffer.append((char)(prev << 6 | next & 0x3F));
/* 2727 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private final boolean _decodeSplitUTF8_4(int prev, int prevCount, int next)
/*      */     throws IOException
/*      */   {
/* 2735 */     if (prevCount == 1) {
/* 2736 */       if ((next & 0xC0) != 128) {
/* 2737 */         _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */       }
/* 2739 */       prev = prev << 6 | next & 0x3F;
/* 2740 */       if (this._inputPtr >= this._inputEnd) {
/* 2741 */         this._minorState = 44;
/* 2742 */         this._pending32 = prev;
/* 2743 */         this._pendingBytes = 2;
/* 2744 */         return false;
/*      */       }
/* 2746 */       prevCount = 2;
/* 2747 */       next = this._inputBuffer[(this._inputPtr++)];
/*      */     }
/* 2749 */     if (prevCount == 2) {
/* 2750 */       if ((next & 0xC0) != 128) {
/* 2751 */         _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */       }
/* 2753 */       prev = prev << 6 | next & 0x3F;
/* 2754 */       if (this._inputPtr >= this._inputEnd) {
/* 2755 */         this._minorState = 44;
/* 2756 */         this._pending32 = prev;
/* 2757 */         this._pendingBytes = 3;
/* 2758 */         return false;
/*      */       }
/* 2760 */       next = this._inputBuffer[(this._inputPtr++)];
/*      */     }
/* 2762 */     if ((next & 0xC0) != 128) {
/* 2763 */       _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */     }
/* 2765 */     int c = (prev << 6 | next & 0x3F) - 65536;
/*      */     
/* 2767 */     this._textBuffer.append((char)(0xD800 | c >> 10));
/* 2768 */     c = 0xDC00 | c & 0x3FF;
/*      */     
/* 2770 */     this._textBuffer.append((char)c);
/* 2771 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int _decodeCharEscape()
/*      */     throws IOException
/*      */   {
/* 2782 */     int left = this._inputEnd - this._inputPtr;
/* 2783 */     if (left < 5) {
/* 2784 */       return _decodeSplitEscaped(0, -1);
/*      */     }
/* 2786 */     return _decodeFastCharEscape();
/*      */   }
/*      */   
/*      */   private final int _decodeFastCharEscape() throws IOException
/*      */   {
/* 2791 */     int c = this._inputBuffer[(this._inputPtr++)];
/* 2792 */     switch (c)
/*      */     {
/*      */     case 98: 
/* 2795 */       return 8;
/*      */     case 116: 
/* 2797 */       return 9;
/*      */     case 110: 
/* 2799 */       return 10;
/*      */     case 102: 
/* 2801 */       return 12;
/*      */     case 114: 
/* 2803 */       return 13;
/*      */     
/*      */ 
/*      */     case 34: 
/*      */     case 47: 
/*      */     case 92: 
/* 2809 */       return (char)c;
/*      */     
/*      */ 
/*      */     case 117: 
/*      */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     default: 
/* 2818 */       char ch = (char)c;
/* 2819 */       return _handleUnrecognizedCharacterEscape(ch);
/*      */     }
/*      */     
/*      */     
/* 2823 */     int ch = this._inputBuffer[(this._inputPtr++)];
/* 2824 */     int digit = CharTypes.charToHex(ch);
/* 2825 */     int result = digit;
/*      */     
/* 2827 */     if (digit >= 0) {
/* 2828 */       ch = this._inputBuffer[(this._inputPtr++)];
/* 2829 */       digit = CharTypes.charToHex(ch);
/* 2830 */       if (digit >= 0) {
/* 2831 */         result = result << 4 | digit;
/* 2832 */         ch = this._inputBuffer[(this._inputPtr++)];
/* 2833 */         digit = CharTypes.charToHex(ch);
/* 2834 */         if (digit >= 0) {
/* 2835 */           result = result << 4 | digit;
/* 2836 */           ch = this._inputBuffer[(this._inputPtr++)];
/* 2837 */           digit = CharTypes.charToHex(ch);
/* 2838 */           if (digit >= 0) {
/* 2839 */             return result << 4 | digit;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2844 */     _reportUnexpectedChar(ch & 0xFF, "expected a hex-digit for character escape sequence");
/* 2845 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int _decodeUTF8_2(int c, int d)
/*      */     throws IOException
/*      */   {
/* 2856 */     if ((d & 0xC0) != 128) {
/* 2857 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2859 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */   
/*      */   private final int _decodeUTF8_3(int c, int d, int e) throws IOException
/*      */   {
/* 2864 */     c &= 0xF;
/* 2865 */     if ((d & 0xC0) != 128) {
/* 2866 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2868 */     c = c << 6 | d & 0x3F;
/* 2869 */     if ((e & 0xC0) != 128) {
/* 2870 */       _reportInvalidOther(e & 0xFF, this._inputPtr);
/*      */     }
/* 2872 */     return c << 6 | e & 0x3F;
/*      */   }
/*      */   
/*      */ 
/*      */   private final int _decodeUTF8_4(int c, int d, int e, int f)
/*      */     throws IOException
/*      */   {
/* 2879 */     if ((d & 0xC0) != 128) {
/* 2880 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2882 */     c = (c & 0x7) << 6 | d & 0x3F;
/* 2883 */     if ((e & 0xC0) != 128) {
/* 2884 */       _reportInvalidOther(e & 0xFF, this._inputPtr);
/*      */     }
/* 2886 */     c = c << 6 | e & 0x3F;
/* 2887 */     if ((f & 0xC0) != 128) {
/* 2888 */       _reportInvalidOther(f & 0xFF, this._inputPtr);
/*      */     }
/* 2890 */     return (c << 6 | f & 0x3F) - 65536;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\json\async\NonBlockingJsonParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */