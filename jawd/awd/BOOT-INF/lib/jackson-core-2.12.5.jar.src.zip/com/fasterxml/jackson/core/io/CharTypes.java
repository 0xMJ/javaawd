/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public final class CharTypes
/*     */ {
/*   7 */   protected static final char[] HC = "0123456789ABCDEF".toCharArray();
/*     */   protected static final byte[] HB;
/*     */   
/*  10 */   static { int len = HC.length;
/*  11 */     HB = new byte[len];
/*  12 */     for (int i = 0; i < len; i++) {
/*  13 */       HB[i] = ((byte)HC[i]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  27 */     int[] table = new int['Ā'];
/*     */     
/*  29 */     for (int i = 0; i < 32; i++) {
/*  30 */       table[i] = -1;
/*     */     }
/*     */     
/*  33 */     table[34] = 1;
/*  34 */     table[92] = 1;
/*  35 */     sInputCodes = table;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  44 */     int[] table = new int[sInputCodes.length];
/*  45 */     System.arraycopy(sInputCodes, 0, table, 0, table.length);
/*  46 */     for (int c = 128; c < 256; c++)
/*     */     {
/*     */       int code;
/*     */       int code;
/*  50 */       if ((c & 0xE0) == 192) {
/*  51 */         code = 2; } else { int code;
/*  52 */         if ((c & 0xF0) == 224) {
/*  53 */           code = 3; } else { int code;
/*  54 */           if ((c & 0xF8) == 240)
/*     */           {
/*  56 */             code = 4;
/*     */           }
/*     */           else
/*  59 */             code = -1;
/*     */         } }
/*  61 */       table[c] = code;
/*     */     }
/*  63 */     sInputCodesUTF8 = table;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */     int[] table = new int['Ā'];
/*     */     
/*  76 */     Arrays.fill(table, -1);
/*     */     
/*  78 */     for (int i = 33; i < 256; i++) {
/*  79 */       if (Character.isJavaIdentifierPart((char)i)) {
/*  80 */         table[i] = 0;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  86 */     table[64] = 0;
/*  87 */     table[35] = 0;
/*  88 */     table[42] = 0;
/*  89 */     table[45] = 0;
/*  90 */     table[43] = 0;
/*  91 */     sInputCodesJsNames = table;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     int[] table = new int['Ā'];
/*     */     
/* 103 */     System.arraycopy(sInputCodesJsNames, 0, table, 0, table.length);
/* 104 */     Arrays.fill(table, 128, 128, 0);
/* 105 */     sInputCodesUtf8JsNames = table;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */     int[] buf = new int['Ā'];
/*     */     
/* 116 */     System.arraycopy(sInputCodesUTF8, 128, buf, 128, 128);
/*     */     
/*     */ 
/* 119 */     Arrays.fill(buf, 0, 32, -1);
/* 120 */     buf[9] = 0;
/* 121 */     buf[10] = 10;
/* 122 */     buf[13] = 13;
/* 123 */     buf[42] = 42;
/* 124 */     sInputCodesComment = buf;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */     int[] buf = new int['Ā'];
/* 136 */     System.arraycopy(sInputCodesUTF8, 128, buf, 128, 128);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 141 */     Arrays.fill(buf, 0, 32, -1);
/* 142 */     buf[32] = 1;
/* 143 */     buf[9] = 1;
/* 144 */     buf[10] = 10;
/* 145 */     buf[13] = 13;
/* 146 */     buf[47] = 47;
/* 147 */     buf[35] = 35;
/* 148 */     sInputCodesWS = buf;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */     int[] table = new int[''];
/*     */     
/* 159 */     for (int i = 0; i < 32; i++)
/*     */     {
/* 161 */       table[i] = -1;
/*     */     }
/*     */     
/* 164 */     table[34] = 34;
/* 165 */     table[92] = 92;
/*     */     
/* 167 */     table[8] = 98;
/* 168 */     table[9] = 116;
/* 169 */     table[12] = 102;
/* 170 */     table[10] = 110;
/* 171 */     table[13] = 114;
/* 172 */     sOutputEscapes128 = table;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */     sHexValues = new int['Ā'];
/*     */     
/* 184 */     Arrays.fill(sHexValues, -1);
/* 185 */     for (int i = 0; i < 10; i++) {
/* 186 */       sHexValues[(48 + i)] = i;
/*     */     }
/* 188 */     for (int i = 0; i < 6; i++) {
/* 189 */       sHexValues[(97 + i)] = (10 + i);
/* 190 */       sHexValues[(65 + i)] = (10 + i);
/*     */     }
/*     */   }
/*     */   
/* 194 */   public static int[] getInputCodeLatin1() { return sInputCodes; }
/* 195 */   public static int[] getInputCodeUtf8() { return sInputCodesUTF8; }
/*     */   
/* 197 */   public static int[] getInputCodeLatin1JsNames() { return sInputCodesJsNames; }
/* 198 */   public static int[] getInputCodeUtf8JsNames() { return sInputCodesUtf8JsNames; }
/*     */   
/* 200 */   public static int[] getInputCodeComment() { return sInputCodesComment; }
/* 201 */   public static int[] getInputCodeWS() { return sInputCodesWS; }
/*     */   
/*     */ 
/*     */   protected static final int[] sInputCodes;
/*     */   
/*     */   protected static final int[] sInputCodesUTF8;
/*     */   
/*     */   protected static final int[] sInputCodesJsNames;
/*     */   
/*     */   public static int[] get7BitOutputEscapes()
/*     */   {
/* 212 */     return sOutputEscapes128;
/*     */   }
/*     */   
/*     */ 
/*     */   protected static final int[] sInputCodesUtf8JsNames;
/*     */   
/*     */   protected static final int[] sInputCodesComment;
/*     */   
/*     */   protected static final int[] sInputCodesWS;
/*     */   
/*     */   protected static final int[] sOutputEscapes128;
/*     */   protected static final int[] sHexValues;
/*     */   public static int[] get7BitOutputEscapes(int quoteChar)
/*     */   {
/* 226 */     if (quoteChar == 34) {
/* 227 */       return sOutputEscapes128;
/*     */     }
/* 229 */     return AltEscapes.instance.escapesFor(quoteChar);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int charToHex(int ch)
/*     */   {
/* 236 */     return sHexValues[(ch & 0xFF)];
/*     */   }
/*     */   
/*     */   public static void appendQuoted(StringBuilder sb, String content)
/*     */   {
/* 241 */     int[] escCodes = sOutputEscapes128;
/* 242 */     int escLen = escCodes.length;
/* 243 */     int i = 0; for (int len = content.length(); i < len; i++) {
/* 244 */       char c = content.charAt(i);
/* 245 */       if ((c >= escLen) || (escCodes[c] == 0)) {
/* 246 */         sb.append(c);
/*     */       }
/*     */       else {
/* 249 */         sb.append('\\');
/* 250 */         int escCode = escCodes[c];
/* 251 */         if (escCode < 0)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 260 */           sb.append('u');
/* 261 */           sb.append('0');
/* 262 */           sb.append('0');
/* 263 */           int value = c;
/* 264 */           sb.append(HC[(value >> 4)]);
/* 265 */           sb.append(HC[(value & 0xF)]);
/*     */         } else {
/* 267 */           sb.append((char)escCode);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 273 */   public static char[] copyHexChars() { return (char[])HC.clone(); }
/*     */   
/*     */   public static byte[] copyHexBytes()
/*     */   {
/* 277 */     return (byte[])HB.clone();
/*     */   }
/*     */   
/*     */   private static class AltEscapes
/*     */   {
/* 282 */     public static final AltEscapes instance = new AltEscapes();
/*     */     
/* 284 */     private int[][] _altEscapes = new int[''][];
/*     */     
/*     */     public int[] escapesFor(int quoteChar) {
/* 287 */       int[] esc = this._altEscapes[quoteChar];
/* 288 */       if (esc == null) {
/* 289 */         esc = Arrays.copyOf(CharTypes.sOutputEscapes128, 128);
/*     */         
/* 291 */         if (esc[quoteChar] == 0) {
/* 292 */           esc[quoteChar] = -1;
/*     */         }
/* 294 */         this._altEscapes[quoteChar] = esc;
/*     */       }
/* 296 */       return esc;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\io\CharTypes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */