/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.PrettyPrinter;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.io.SerializedString;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPrettyPrinter
/*     */   implements PrettyPrinter, Instantiatable<DefaultPrettyPrinter>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  28 */   public static final SerializedString DEFAULT_ROOT_VALUE_SEPARATOR = new SerializedString(" ");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */   protected Indenter _arrayIndenter = FixedSpaceIndenter.instance;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */   protected Indenter _objectIndenter = DefaultIndenter.SYSTEM_LINEFEED_INSTANCE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final SerializableString _rootSeparator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */   protected boolean _spacesInObjectEntries = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected transient int _nesting;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Separators _separators;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String _objectFieldValueSeparatorWithSpaces;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultPrettyPrinter()
/*     */   {
/* 101 */     this(DEFAULT_ROOT_VALUE_SEPARATOR);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultPrettyPrinter(String rootSeparator)
/*     */   {
/* 114 */     this(rootSeparator == null ? null : new SerializedString(rootSeparator));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultPrettyPrinter(SerializableString rootSeparator)
/*     */   {
/* 124 */     this._rootSeparator = rootSeparator;
/* 125 */     withSeparators(DEFAULT_SEPARATORS);
/*     */   }
/*     */   
/*     */   public DefaultPrettyPrinter(DefaultPrettyPrinter base) {
/* 129 */     this(base, base._rootSeparator);
/*     */   }
/*     */   
/*     */ 
/*     */   public DefaultPrettyPrinter(DefaultPrettyPrinter base, SerializableString rootSeparator)
/*     */   {
/* 135 */     this._arrayIndenter = base._arrayIndenter;
/* 136 */     this._objectIndenter = base._objectIndenter;
/* 137 */     this._spacesInObjectEntries = base._spacesInObjectEntries;
/* 138 */     this._nesting = base._nesting;
/*     */     
/* 140 */     this._separators = base._separators;
/* 141 */     this._objectFieldValueSeparatorWithSpaces = base._objectFieldValueSeparatorWithSpaces;
/*     */     
/* 143 */     this._rootSeparator = rootSeparator;
/*     */   }
/*     */   
/*     */   public DefaultPrettyPrinter withRootSeparator(SerializableString rootSeparator)
/*     */   {
/* 148 */     if ((this._rootSeparator == rootSeparator) || ((rootSeparator != null) && 
/* 149 */       (rootSeparator.equals(this._rootSeparator)))) {
/* 150 */       return this;
/*     */     }
/* 152 */     return new DefaultPrettyPrinter(this, rootSeparator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultPrettyPrinter withRootSeparator(String rootSeparator)
/*     */   {
/* 163 */     return withRootSeparator(rootSeparator == null ? null : new SerializedString(rootSeparator));
/*     */   }
/*     */   
/*     */   public void indentArraysWith(Indenter i) {
/* 167 */     this._arrayIndenter = (i == null ? NopIndenter.instance : i);
/*     */   }
/*     */   
/*     */   public void indentObjectsWith(Indenter i) {
/* 171 */     this._objectIndenter = (i == null ? NopIndenter.instance : i);
/*     */   }
/*     */   
/*     */   public DefaultPrettyPrinter withArrayIndenter(Indenter i)
/*     */   {
/* 176 */     if (i == null) {
/* 177 */       i = NopIndenter.instance;
/*     */     }
/* 179 */     if (this._arrayIndenter == i) {
/* 180 */       return this;
/*     */     }
/* 182 */     DefaultPrettyPrinter pp = new DefaultPrettyPrinter(this);
/* 183 */     pp._arrayIndenter = i;
/* 184 */     return pp;
/*     */   }
/*     */   
/*     */   public DefaultPrettyPrinter withObjectIndenter(Indenter i)
/*     */   {
/* 189 */     if (i == null) {
/* 190 */       i = NopIndenter.instance;
/*     */     }
/* 192 */     if (this._objectIndenter == i) {
/* 193 */       return this;
/*     */     }
/* 195 */     DefaultPrettyPrinter pp = new DefaultPrettyPrinter(this);
/* 196 */     pp._objectIndenter = i;
/* 197 */     return pp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultPrettyPrinter withSpacesInObjectEntries()
/*     */   {
/* 211 */     return _withSpaces(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultPrettyPrinter withoutSpacesInObjectEntries()
/*     */   {
/* 225 */     return _withSpaces(false);
/*     */   }
/*     */   
/*     */   protected DefaultPrettyPrinter _withSpaces(boolean state)
/*     */   {
/* 230 */     if (this._spacesInObjectEntries == state) {
/* 231 */       return this;
/*     */     }
/* 233 */     DefaultPrettyPrinter pp = new DefaultPrettyPrinter(this);
/* 234 */     pp._spacesInObjectEntries = state;
/* 235 */     return pp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultPrettyPrinter withSeparators(Separators separators)
/*     */   {
/* 248 */     this._separators = separators;
/* 249 */     this._objectFieldValueSeparatorWithSpaces = (" " + separators.getObjectFieldValueSeparator() + " ");
/* 250 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultPrettyPrinter createInstance()
/*     */   {
/* 261 */     if (getClass() != DefaultPrettyPrinter.class) {
/* 262 */       throw new IllegalStateException("Failed `createInstance()`: " + getClass().getName() + " does not override method; it has to");
/*     */     }
/*     */     
/* 265 */     return new DefaultPrettyPrinter(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeRootValueSeparator(JsonGenerator g)
/*     */     throws IOException
/*     */   {
/* 277 */     if (this._rootSeparator != null) {
/* 278 */       g.writeRaw(this._rootSeparator);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeStartObject(JsonGenerator g)
/*     */     throws IOException
/*     */   {
/* 285 */     g.writeRaw('{');
/* 286 */     if (!this._objectIndenter.isInline()) {
/* 287 */       this._nesting += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public void beforeObjectEntries(JsonGenerator g)
/*     */     throws IOException
/*     */   {
/* 294 */     this._objectIndenter.writeIndentation(g, this._nesting);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeObjectFieldValueSeparator(JsonGenerator g)
/*     */     throws IOException
/*     */   {
/* 309 */     if (this._spacesInObjectEntries) {
/* 310 */       g.writeRaw(this._objectFieldValueSeparatorWithSpaces);
/*     */     } else {
/* 312 */       g.writeRaw(this._separators.getObjectFieldValueSeparator());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeObjectEntrySeparator(JsonGenerator g)
/*     */     throws IOException
/*     */   {
/* 328 */     g.writeRaw(this._separators.getObjectEntrySeparator());
/* 329 */     this._objectIndenter.writeIndentation(g, this._nesting);
/*     */   }
/*     */   
/*     */   public void writeEndObject(JsonGenerator g, int nrOfEntries)
/*     */     throws IOException
/*     */   {
/* 335 */     if (!this._objectIndenter.isInline()) {
/* 336 */       this._nesting -= 1;
/*     */     }
/* 338 */     if (nrOfEntries > 0) {
/* 339 */       this._objectIndenter.writeIndentation(g, this._nesting);
/*     */     } else {
/* 341 */       g.writeRaw(' ');
/*     */     }
/* 343 */     g.writeRaw('}');
/*     */   }
/*     */   
/*     */   public void writeStartArray(JsonGenerator g)
/*     */     throws IOException
/*     */   {
/* 349 */     if (!this._arrayIndenter.isInline()) {
/* 350 */       this._nesting += 1;
/*     */     }
/* 352 */     g.writeRaw('[');
/*     */   }
/*     */   
/*     */   public void beforeArrayValues(JsonGenerator g) throws IOException
/*     */   {
/* 357 */     this._arrayIndenter.writeIndentation(g, this._nesting);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeArrayValueSeparator(JsonGenerator g)
/*     */     throws IOException
/*     */   {
/* 372 */     g.writeRaw(this._separators.getArrayValueSeparator());
/* 373 */     this._arrayIndenter.writeIndentation(g, this._nesting);
/*     */   }
/*     */   
/*     */   public void writeEndArray(JsonGenerator g, int nrOfValues)
/*     */     throws IOException
/*     */   {
/* 379 */     if (!this._arrayIndenter.isInline()) {
/* 380 */       this._nesting -= 1;
/*     */     }
/* 382 */     if (nrOfValues > 0) {
/* 383 */       this._arrayIndenter.writeIndentation(g, this._nesting);
/*     */     } else {
/* 385 */       g.writeRaw(' ');
/*     */     }
/* 387 */     g.writeRaw(']');
/*     */   }
/*     */   
/*     */ 
/*     */   public static abstract interface Indenter
/*     */   {
/*     */     public abstract void writeIndentation(JsonGenerator paramJsonGenerator, int paramInt)
/*     */       throws IOException;
/*     */     
/*     */     public abstract boolean isInline();
/*     */   }
/*     */   
/*     */   public static class NopIndenter
/*     */     implements DefaultPrettyPrinter.Indenter, Serializable
/*     */   {
/* 402 */     public static final NopIndenter instance = new NopIndenter();
/*     */     
/*     */     public void writeIndentation(JsonGenerator g, int level) throws IOException
/*     */     {}
/*     */     
/*     */     public boolean isInline() {
/* 408 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class FixedSpaceIndenter
/*     */     extends DefaultPrettyPrinter.NopIndenter
/*     */   {
/* 418 */     public static final FixedSpaceIndenter instance = new FixedSpaceIndenter();
/*     */     
/*     */     public void writeIndentation(JsonGenerator g, int level)
/*     */       throws IOException
/*     */     {
/* 423 */       g.writeRaw(' ');
/*     */     }
/*     */     
/*     */     public boolean isInline() {
/* 427 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\util\DefaultPrettyPrinter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */