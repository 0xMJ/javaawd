package com.fasterxml.jackson.core;

public abstract interface Versioned
{
  public abstract Version version();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\Versioned.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */