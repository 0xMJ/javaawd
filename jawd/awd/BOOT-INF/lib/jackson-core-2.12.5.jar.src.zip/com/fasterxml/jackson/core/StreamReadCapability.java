/*    */ package com.fasterxml.jackson.core;
/*    */ 
/*    */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum StreamReadCapability
/*    */   implements JacksonFeature
/*    */ {
/* 30 */   DUPLICATE_PROPERTIES(false), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 40 */   SCALARS_AS_OBJECTS(false), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 50 */   UNTYPED_SCALARS(false);
/*    */   
/*    */ 
/*    */ 
/*    */   private final boolean _defaultState;
/*    */   
/*    */   private final int _mask;
/*    */   
/*    */ 
/*    */   private StreamReadCapability(boolean defaultState)
/*    */   {
/* 61 */     this._defaultState = defaultState;
/* 62 */     this._mask = (1 << ordinal());
/*    */   }
/*    */   
/*    */ 
/* 66 */   public boolean enabledByDefault() { return this._defaultState; }
/*    */   
/* 68 */   public boolean enabledIn(int flags) { return (flags & this._mask) != 0; }
/*    */   
/* 70 */   public int getMask() { return this._mask; }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\StreamReadCapability.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */