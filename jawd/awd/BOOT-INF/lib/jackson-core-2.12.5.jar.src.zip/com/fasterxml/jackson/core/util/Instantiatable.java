package com.fasterxml.jackson.core.util;

public abstract interface Instantiatable<T>
{
  public abstract T createInstance();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\util\Instantiatable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */