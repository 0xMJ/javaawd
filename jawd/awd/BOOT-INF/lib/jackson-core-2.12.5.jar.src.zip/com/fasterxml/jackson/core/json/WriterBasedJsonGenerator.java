/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonGenerationException;
/*      */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.PrettyPrinter;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.NumberOutput;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ public class WriterBasedJsonGenerator extends JsonGeneratorImpl
/*      */ {
/*      */   protected static final int SHORT_WRITE = 32;
/*   22 */   protected static final char[] HEX_CHARS = ;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Writer _writer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char _quoteChar;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char[] _outputBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _outputHead;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _outputTail;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _outputEnd;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char[] _entityBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected SerializableString _currentEscape;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char[] _copyBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public WriterBasedJsonGenerator(IOContext ctxt, int features, ObjectCodec codec, Writer w)
/*      */   {
/*   96 */     this(ctxt, features, codec, w, '"');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WriterBasedJsonGenerator(IOContext ctxt, int features, ObjectCodec codec, Writer w, char quoteChar)
/*      */   {
/*  107 */     super(ctxt, features, codec);
/*  108 */     this._writer = w;
/*  109 */     this._outputBuffer = ctxt.allocConcatBuffer();
/*  110 */     this._outputEnd = this._outputBuffer.length;
/*  111 */     this._quoteChar = quoteChar;
/*  112 */     if (quoteChar != '"') {
/*  113 */       this._outputEscapes = com.fasterxml.jackson.core.io.CharTypes.get7BitOutputEscapes(quoteChar);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getOutputTarget()
/*      */   {
/*  125 */     return this._writer;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getOutputBuffered()
/*      */   {
/*  131 */     int len = this._outputTail - this._outputHead;
/*  132 */     return Math.max(0, len);
/*      */   }
/*      */   
/*      */   public boolean canWriteFormattedNumbers()
/*      */   {
/*  137 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeFieldName(String name)
/*      */     throws IOException
/*      */   {
/*  148 */     int status = this._writeContext.writeFieldName(name);
/*  149 */     if (status == 4) {
/*  150 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  152 */     _writeFieldName(name, status == 1);
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeFieldName(SerializableString name)
/*      */     throws IOException
/*      */   {
/*  159 */     int status = this._writeContext.writeFieldName(name.getValue());
/*  160 */     if (status == 4) {
/*  161 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  163 */     _writeFieldName(name, status == 1);
/*      */   }
/*      */   
/*      */   protected final void _writeFieldName(String name, boolean commaBefore) throws IOException
/*      */   {
/*  168 */     if (this._cfgPrettyPrinter != null) {
/*  169 */       _writePPFieldName(name, commaBefore);
/*  170 */       return;
/*      */     }
/*      */     
/*  173 */     if (this._outputTail + 1 >= this._outputEnd) {
/*  174 */       _flushBuffer();
/*      */     }
/*  176 */     if (commaBefore) {
/*  177 */       this._outputBuffer[(this._outputTail++)] = ',';
/*      */     }
/*      */     
/*  180 */     if (this._cfgUnqNames) {
/*  181 */       _writeString(name);
/*  182 */       return;
/*      */     }
/*      */     
/*  185 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     
/*  187 */     _writeString(name);
/*      */     
/*  189 */     if (this._outputTail >= this._outputEnd) {
/*  190 */       _flushBuffer();
/*      */     }
/*  192 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   protected final void _writeFieldName(SerializableString name, boolean commaBefore) throws IOException
/*      */   {
/*  197 */     if (this._cfgPrettyPrinter != null) {
/*  198 */       _writePPFieldName(name, commaBefore);
/*  199 */       return;
/*      */     }
/*      */     
/*  202 */     if (this._outputTail + 1 >= this._outputEnd) {
/*  203 */       _flushBuffer();
/*      */     }
/*  205 */     if (commaBefore) {
/*  206 */       this._outputBuffer[(this._outputTail++)] = ',';
/*      */     }
/*      */     
/*  209 */     if (this._cfgUnqNames) {
/*  210 */       char[] ch = name.asQuotedChars();
/*  211 */       writeRaw(ch, 0, ch.length);
/*  212 */       return;
/*      */     }
/*      */     
/*  215 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     
/*      */ 
/*  218 */     int len = name.appendQuoted(this._outputBuffer, this._outputTail);
/*  219 */     if (len < 0) {
/*  220 */       _writeFieldNameTail(name);
/*  221 */       return;
/*      */     }
/*  223 */     this._outputTail += len;
/*  224 */     if (this._outputTail >= this._outputEnd) {
/*  225 */       _flushBuffer();
/*      */     }
/*  227 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   private final void _writeFieldNameTail(SerializableString name) throws IOException
/*      */   {
/*  232 */     char[] quoted = name.asQuotedChars();
/*  233 */     writeRaw(quoted, 0, quoted.length);
/*  234 */     if (this._outputTail >= this._outputEnd) {
/*  235 */       _flushBuffer();
/*      */     }
/*  237 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeStartArray()
/*      */     throws IOException
/*      */   {
/*  249 */     _verifyValueWrite("start an array");
/*  250 */     this._writeContext = this._writeContext.createChildArrayContext();
/*  251 */     if (this._cfgPrettyPrinter != null) {
/*  252 */       this._cfgPrettyPrinter.writeStartArray(this);
/*      */     } else {
/*  254 */       if (this._outputTail >= this._outputEnd) {
/*  255 */         _flushBuffer();
/*      */       }
/*  257 */       this._outputBuffer[(this._outputTail++)] = '[';
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeStartArray(Object currentValue)
/*      */     throws IOException
/*      */   {
/*  264 */     _verifyValueWrite("start an array");
/*  265 */     this._writeContext = this._writeContext.createChildArrayContext(currentValue);
/*  266 */     if (this._cfgPrettyPrinter != null) {
/*  267 */       this._cfgPrettyPrinter.writeStartArray(this);
/*      */     } else {
/*  269 */       if (this._outputTail >= this._outputEnd) {
/*  270 */         _flushBuffer();
/*      */       }
/*  272 */       this._outputBuffer[(this._outputTail++)] = '[';
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeStartArray(Object currentValue, int size)
/*      */     throws IOException
/*      */   {
/*  279 */     _verifyValueWrite("start an array");
/*  280 */     this._writeContext = this._writeContext.createChildArrayContext(currentValue);
/*  281 */     if (this._cfgPrettyPrinter != null) {
/*  282 */       this._cfgPrettyPrinter.writeStartArray(this);
/*      */     } else {
/*  284 */       if (this._outputTail >= this._outputEnd) {
/*  285 */         _flushBuffer();
/*      */       }
/*  287 */       this._outputBuffer[(this._outputTail++)] = '[';
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeEndArray()
/*      */     throws IOException
/*      */   {
/*  294 */     if (!this._writeContext.inArray()) {
/*  295 */       _reportError("Current context not Array but " + this._writeContext.typeDesc());
/*      */     }
/*  297 */     if (this._cfgPrettyPrinter != null) {
/*  298 */       this._cfgPrettyPrinter.writeEndArray(this, this._writeContext.getEntryCount());
/*      */     } else {
/*  300 */       if (this._outputTail >= this._outputEnd) {
/*  301 */         _flushBuffer();
/*      */       }
/*  303 */       this._outputBuffer[(this._outputTail++)] = ']';
/*      */     }
/*  305 */     this._writeContext = this._writeContext.clearAndGetParent();
/*      */   }
/*      */   
/*      */   public void writeStartObject()
/*      */     throws IOException
/*      */   {
/*  311 */     _verifyValueWrite("start an object");
/*  312 */     this._writeContext = this._writeContext.createChildObjectContext();
/*  313 */     if (this._cfgPrettyPrinter != null) {
/*  314 */       this._cfgPrettyPrinter.writeStartObject(this);
/*      */     } else {
/*  316 */       if (this._outputTail >= this._outputEnd) {
/*  317 */         _flushBuffer();
/*      */       }
/*  319 */       this._outputBuffer[(this._outputTail++)] = '{';
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeStartObject(Object forValue)
/*      */     throws IOException
/*      */   {
/*  326 */     _verifyValueWrite("start an object");
/*  327 */     JsonWriteContext ctxt = this._writeContext.createChildObjectContext(forValue);
/*  328 */     this._writeContext = ctxt;
/*  329 */     if (this._cfgPrettyPrinter != null) {
/*  330 */       this._cfgPrettyPrinter.writeStartObject(this);
/*      */     } else {
/*  332 */       if (this._outputTail >= this._outputEnd) {
/*  333 */         _flushBuffer();
/*      */       }
/*  335 */       this._outputBuffer[(this._outputTail++)] = '{';
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeEndObject()
/*      */     throws IOException
/*      */   {
/*  342 */     if (!this._writeContext.inObject()) {
/*  343 */       _reportError("Current context not Object but " + this._writeContext.typeDesc());
/*      */     }
/*  345 */     if (this._cfgPrettyPrinter != null) {
/*  346 */       this._cfgPrettyPrinter.writeEndObject(this, this._writeContext.getEntryCount());
/*      */     } else {
/*  348 */       if (this._outputTail >= this._outputEnd) {
/*  349 */         _flushBuffer();
/*      */       }
/*  351 */       this._outputBuffer[(this._outputTail++)] = '}';
/*      */     }
/*  353 */     this._writeContext = this._writeContext.clearAndGetParent();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _writePPFieldName(String name, boolean commaBefore)
/*      */     throws IOException
/*      */   {
/*  362 */     if (commaBefore) {
/*  363 */       this._cfgPrettyPrinter.writeObjectEntrySeparator(this);
/*      */     } else {
/*  365 */       this._cfgPrettyPrinter.beforeObjectEntries(this);
/*      */     }
/*      */     
/*  368 */     if (this._cfgUnqNames) {
/*  369 */       _writeString(name);
/*      */     } else {
/*  371 */       if (this._outputTail >= this._outputEnd) {
/*  372 */         _flushBuffer();
/*      */       }
/*  374 */       this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  375 */       _writeString(name);
/*  376 */       if (this._outputTail >= this._outputEnd) {
/*  377 */         _flushBuffer();
/*      */       }
/*  379 */       this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     }
/*      */   }
/*      */   
/*      */   protected final void _writePPFieldName(SerializableString name, boolean commaBefore) throws IOException
/*      */   {
/*  385 */     if (commaBefore) {
/*  386 */       this._cfgPrettyPrinter.writeObjectEntrySeparator(this);
/*      */     } else {
/*  388 */       this._cfgPrettyPrinter.beforeObjectEntries(this);
/*      */     }
/*  390 */     char[] quoted = name.asQuotedChars();
/*  391 */     if (this._cfgUnqNames) {
/*  392 */       writeRaw(quoted, 0, quoted.length);
/*      */     } else {
/*  394 */       if (this._outputTail >= this._outputEnd) {
/*  395 */         _flushBuffer();
/*      */       }
/*  397 */       this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  398 */       writeRaw(quoted, 0, quoted.length);
/*  399 */       if (this._outputTail >= this._outputEnd) {
/*  400 */         _flushBuffer();
/*      */       }
/*  402 */       this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeString(String text)
/*      */     throws IOException
/*      */   {
/*  415 */     _verifyValueWrite("write a string");
/*  416 */     if (text == null) {
/*  417 */       _writeNull();
/*  418 */       return;
/*      */     }
/*  420 */     if (this._outputTail >= this._outputEnd) {
/*  421 */       _flushBuffer();
/*      */     }
/*  423 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  424 */     _writeString(text);
/*      */     
/*  426 */     if (this._outputTail >= this._outputEnd) {
/*  427 */       _flushBuffer();
/*      */     }
/*  429 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeString(Reader reader, int len)
/*      */     throws IOException
/*      */   {
/*  435 */     _verifyValueWrite("write a string");
/*  436 */     if (reader == null) {
/*  437 */       _reportError("null reader");
/*  438 */       return;
/*      */     }
/*  440 */     int toRead = len >= 0 ? len : Integer.MAX_VALUE;
/*      */     
/*  442 */     if (this._outputTail >= this._outputEnd) {
/*  443 */       _flushBuffer();
/*      */     }
/*  445 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     
/*  447 */     char[] buf = _allocateCopyBuffer();
/*  448 */     while (toRead > 0) {
/*  449 */       int toReadNow = Math.min(toRead, buf.length);
/*  450 */       int numRead = reader.read(buf, 0, toReadNow);
/*  451 */       if (numRead <= 0) {
/*      */         break;
/*      */       }
/*  454 */       _writeString(buf, 0, numRead);
/*  455 */       toRead -= numRead;
/*      */     }
/*      */     
/*  458 */     if (this._outputTail >= this._outputEnd) {
/*  459 */       _flushBuffer();
/*      */     }
/*  461 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     
/*  463 */     if ((toRead > 0) && (len >= 0)) {
/*  464 */       _reportError("Didn't read enough from reader");
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeString(char[] text, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  471 */     _verifyValueWrite("write a string");
/*  472 */     if (this._outputTail >= this._outputEnd) {
/*  473 */       _flushBuffer();
/*      */     }
/*  475 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  476 */     _writeString(text, offset, len);
/*      */     
/*  478 */     if (this._outputTail >= this._outputEnd) {
/*  479 */       _flushBuffer();
/*      */     }
/*  481 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeString(SerializableString sstr)
/*      */     throws IOException
/*      */   {
/*  487 */     _verifyValueWrite("write a string");
/*  488 */     if (this._outputTail >= this._outputEnd) {
/*  489 */       _flushBuffer();
/*      */     }
/*  491 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  492 */     int len = sstr.appendQuoted(this._outputBuffer, this._outputTail);
/*  493 */     if (len < 0) {
/*  494 */       _writeString2(sstr);
/*  495 */       return;
/*      */     }
/*  497 */     this._outputTail += len;
/*  498 */     if (this._outputTail >= this._outputEnd) {
/*  499 */       _flushBuffer();
/*      */     }
/*  501 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   private void _writeString2(SerializableString sstr)
/*      */     throws IOException
/*      */   {
/*  507 */     char[] text = sstr.asQuotedChars();
/*  508 */     int len = text.length;
/*  509 */     if (len < 32) {
/*  510 */       int room = this._outputEnd - this._outputTail;
/*  511 */       if (len > room) {
/*  512 */         _flushBuffer();
/*      */       }
/*  514 */       System.arraycopy(text, 0, this._outputBuffer, this._outputTail, len);
/*  515 */       this._outputTail += len;
/*      */     } else {
/*  517 */       _flushBuffer();
/*  518 */       this._writer.write(text, 0, len);
/*      */     }
/*  520 */     if (this._outputTail >= this._outputEnd) {
/*  521 */       _flushBuffer();
/*      */     }
/*  523 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeRawUTF8String(byte[] text, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  529 */     _reportUnsupportedOperation();
/*      */   }
/*      */   
/*      */   public void writeUTF8String(byte[] text, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  535 */     _reportUnsupportedOperation();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeRaw(String text)
/*      */     throws IOException
/*      */   {
/*  548 */     int len = text.length();
/*  549 */     int room = this._outputEnd - this._outputTail;
/*      */     
/*  551 */     if (room == 0) {
/*  552 */       _flushBuffer();
/*  553 */       room = this._outputEnd - this._outputTail;
/*      */     }
/*      */     
/*  556 */     if (room >= len) {
/*  557 */       text.getChars(0, len, this._outputBuffer, this._outputTail);
/*  558 */       this._outputTail += len;
/*      */     } else {
/*  560 */       writeRawLong(text);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeRaw(String text, int start, int len)
/*      */     throws IOException
/*      */   {
/*  568 */     int room = this._outputEnd - this._outputTail;
/*      */     
/*  570 */     if (room < len) {
/*  571 */       _flushBuffer();
/*  572 */       room = this._outputEnd - this._outputTail;
/*      */     }
/*      */     
/*  575 */     if (room >= len) {
/*  576 */       text.getChars(start, start + len, this._outputBuffer, this._outputTail);
/*  577 */       this._outputTail += len;
/*      */     } else {
/*  579 */       writeRawLong(text.substring(start, start + len));
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRaw(SerializableString text)
/*      */     throws IOException
/*      */   {
/*  586 */     int len = text.appendUnquoted(this._outputBuffer, this._outputTail);
/*  587 */     if (len < 0) {
/*  588 */       writeRaw(text.getValue());
/*  589 */       return;
/*      */     }
/*  591 */     this._outputTail += len;
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeRaw(char[] text, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  598 */     if (len < 32) {
/*  599 */       int room = this._outputEnd - this._outputTail;
/*  600 */       if (len > room) {
/*  601 */         _flushBuffer();
/*      */       }
/*  603 */       System.arraycopy(text, offset, this._outputBuffer, this._outputTail, len);
/*  604 */       this._outputTail += len;
/*  605 */       return;
/*      */     }
/*      */     
/*  608 */     _flushBuffer();
/*  609 */     this._writer.write(text, offset, len);
/*      */   }
/*      */   
/*      */   public void writeRaw(char c)
/*      */     throws IOException
/*      */   {
/*  615 */     if (this._outputTail >= this._outputEnd) {
/*  616 */       _flushBuffer();
/*      */     }
/*  618 */     this._outputBuffer[(this._outputTail++)] = c;
/*      */   }
/*      */   
/*      */   private void writeRawLong(String text) throws IOException
/*      */   {
/*  623 */     int room = this._outputEnd - this._outputTail;
/*      */     
/*  625 */     text.getChars(0, room, this._outputBuffer, this._outputTail);
/*  626 */     this._outputTail += room;
/*  627 */     _flushBuffer();
/*  628 */     int offset = room;
/*  629 */     int len = text.length() - room;
/*      */     
/*  631 */     while (len > this._outputEnd) {
/*  632 */       int amount = this._outputEnd;
/*  633 */       text.getChars(offset, offset + amount, this._outputBuffer, 0);
/*  634 */       this._outputHead = 0;
/*  635 */       this._outputTail = amount;
/*  636 */       _flushBuffer();
/*  637 */       offset += amount;
/*  638 */       len -= amount;
/*      */     }
/*      */     
/*  641 */     text.getChars(offset, offset + len, this._outputBuffer, 0);
/*  642 */     this._outputHead = 0;
/*  643 */     this._outputTail = len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  656 */     _verifyValueWrite("write a binary value");
/*      */     
/*  658 */     if (this._outputTail >= this._outputEnd) {
/*  659 */       _flushBuffer();
/*      */     }
/*  661 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  662 */     _writeBinary(b64variant, data, offset, offset + len);
/*      */     
/*  664 */     if (this._outputTail >= this._outputEnd) {
/*  665 */       _flushBuffer();
/*      */     }
/*  667 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  675 */     _verifyValueWrite("write a binary value");
/*      */     
/*  677 */     if (this._outputTail >= this._outputEnd) {
/*  678 */       _flushBuffer();
/*      */     }
/*  680 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  681 */     byte[] encodingBuffer = this._ioContext.allocBase64Buffer();
/*      */     try {
/*      */       int bytes;
/*  684 */       if (dataLength < 0) {
/*  685 */         bytes = _writeBinary(b64variant, data, encodingBuffer);
/*      */       } else {
/*  687 */         int missing = _writeBinary(b64variant, data, encodingBuffer, dataLength);
/*  688 */         if (missing > 0) {
/*  689 */           _reportError("Too few bytes available: missing " + missing + " bytes (out of " + dataLength + ")");
/*      */         }
/*  691 */         bytes = dataLength;
/*      */       }
/*      */     } finally { int bytes;
/*  694 */       this._ioContext.releaseBase64Buffer(encodingBuffer);
/*      */     }
/*      */     int bytes;
/*  697 */     if (this._outputTail >= this._outputEnd) {
/*  698 */       _flushBuffer();
/*      */     }
/*  700 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  701 */     return bytes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumber(short s)
/*      */     throws IOException
/*      */   {
/*  713 */     _verifyValueWrite("write a number");
/*  714 */     if (this._cfgNumbersAsStrings) {
/*  715 */       _writeQuotedShort(s);
/*  716 */       return;
/*      */     }
/*      */     
/*  719 */     if (this._outputTail + 6 >= this._outputEnd) {
/*  720 */       _flushBuffer();
/*      */     }
/*  722 */     this._outputTail = NumberOutput.outputInt(s, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private void _writeQuotedShort(short s) throws IOException {
/*  726 */     if (this._outputTail + 8 >= this._outputEnd) {
/*  727 */       _flushBuffer();
/*      */     }
/*  729 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  730 */     this._outputTail = NumberOutput.outputInt(s, this._outputBuffer, this._outputTail);
/*  731 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeNumber(int i)
/*      */     throws IOException
/*      */   {
/*  737 */     _verifyValueWrite("write a number");
/*  738 */     if (this._cfgNumbersAsStrings) {
/*  739 */       _writeQuotedInt(i);
/*  740 */       return;
/*      */     }
/*      */     
/*  743 */     if (this._outputTail + 11 >= this._outputEnd) {
/*  744 */       _flushBuffer();
/*      */     }
/*  746 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private void _writeQuotedInt(int i) throws IOException {
/*  750 */     if (this._outputTail + 13 >= this._outputEnd) {
/*  751 */       _flushBuffer();
/*      */     }
/*  753 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  754 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*  755 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeNumber(long l)
/*      */     throws IOException
/*      */   {
/*  761 */     _verifyValueWrite("write a number");
/*  762 */     if (this._cfgNumbersAsStrings) {
/*  763 */       _writeQuotedLong(l);
/*  764 */       return;
/*      */     }
/*  766 */     if (this._outputTail + 21 >= this._outputEnd)
/*      */     {
/*  768 */       _flushBuffer();
/*      */     }
/*  770 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private void _writeQuotedLong(long l) throws IOException {
/*  774 */     if (this._outputTail + 23 >= this._outputEnd) {
/*  775 */       _flushBuffer();
/*      */     }
/*  777 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  778 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/*  779 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void writeNumber(BigInteger value)
/*      */     throws IOException
/*      */   {
/*  787 */     _verifyValueWrite("write a number");
/*  788 */     if (value == null) {
/*  789 */       _writeNull();
/*  790 */     } else if (this._cfgNumbersAsStrings) {
/*  791 */       _writeQuotedRaw(value.toString());
/*      */     } else {
/*  793 */       writeRaw(value.toString());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeNumber(double d)
/*      */     throws IOException
/*      */   {
/*  801 */     if ((this._cfgNumbersAsStrings) || (
/*  802 */       (NumberOutput.notFinite(d)) && (isEnabled(JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS)))) {
/*  803 */       writeString(String.valueOf(d));
/*  804 */       return;
/*      */     }
/*      */     
/*  807 */     _verifyValueWrite("write a number");
/*  808 */     writeRaw(String.valueOf(d));
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeNumber(float f)
/*      */     throws IOException
/*      */   {
/*  815 */     if ((this._cfgNumbersAsStrings) || (
/*  816 */       (NumberOutput.notFinite(f)) && (isEnabled(JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS)))) {
/*  817 */       writeString(String.valueOf(f));
/*  818 */       return;
/*      */     }
/*      */     
/*  821 */     _verifyValueWrite("write a number");
/*  822 */     writeRaw(String.valueOf(f));
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeNumber(java.math.BigDecimal value)
/*      */     throws IOException
/*      */   {
/*  829 */     _verifyValueWrite("write a number");
/*  830 */     if (value == null) {
/*  831 */       _writeNull();
/*  832 */     } else if (this._cfgNumbersAsStrings) {
/*  833 */       _writeQuotedRaw(_asString(value));
/*      */     } else {
/*  835 */       writeRaw(_asString(value));
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeNumber(String encodedValue)
/*      */     throws IOException
/*      */   {
/*  842 */     _verifyValueWrite("write a number");
/*  843 */     if (encodedValue == null) {
/*  844 */       _writeNull();
/*  845 */     } else if (this._cfgNumbersAsStrings) {
/*  846 */       _writeQuotedRaw(encodedValue);
/*      */     } else {
/*  848 */       writeRaw(encodedValue);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeNumber(char[] encodedValueBuffer, int offset, int length) throws IOException
/*      */   {
/*  854 */     _verifyValueWrite("write a number");
/*  855 */     if (this._cfgNumbersAsStrings) {
/*  856 */       _writeQuotedRaw(encodedValueBuffer, offset, length);
/*      */     } else {
/*  858 */       writeRaw(encodedValueBuffer, offset, length);
/*      */     }
/*      */   }
/*      */   
/*      */   private void _writeQuotedRaw(String value) throws IOException
/*      */   {
/*  864 */     if (this._outputTail >= this._outputEnd) {
/*  865 */       _flushBuffer();
/*      */     }
/*  867 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  868 */     writeRaw(value);
/*  869 */     if (this._outputTail >= this._outputEnd) {
/*  870 */       _flushBuffer();
/*      */     }
/*  872 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   private void _writeQuotedRaw(char[] text, int offset, int length) throws IOException
/*      */   {
/*  877 */     if (this._outputTail >= this._outputEnd) {
/*  878 */       _flushBuffer();
/*      */     }
/*  880 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  881 */     writeRaw(text, offset, length);
/*  882 */     if (this._outputTail >= this._outputEnd) {
/*  883 */       _flushBuffer();
/*      */     }
/*  885 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeBoolean(boolean state)
/*      */     throws IOException
/*      */   {
/*  891 */     _verifyValueWrite("write a boolean value");
/*  892 */     if (this._outputTail + 5 >= this._outputEnd) {
/*  893 */       _flushBuffer();
/*      */     }
/*  895 */     int ptr = this._outputTail;
/*  896 */     char[] buf = this._outputBuffer;
/*  897 */     if (state) {
/*  898 */       buf[ptr] = 't';
/*  899 */       buf[(++ptr)] = 'r';
/*  900 */       buf[(++ptr)] = 'u';
/*  901 */       buf[(++ptr)] = 'e';
/*      */     } else {
/*  903 */       buf[ptr] = 'f';
/*  904 */       buf[(++ptr)] = 'a';
/*  905 */       buf[(++ptr)] = 'l';
/*  906 */       buf[(++ptr)] = 's';
/*  907 */       buf[(++ptr)] = 'e';
/*      */     }
/*  909 */     this._outputTail = (ptr + 1);
/*      */   }
/*      */   
/*      */   public void writeNull() throws IOException
/*      */   {
/*  914 */     _verifyValueWrite("write a null");
/*  915 */     _writeNull();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _verifyValueWrite(String typeMsg)
/*      */     throws IOException
/*      */   {
/*  927 */     int status = this._writeContext.writeValue();
/*  928 */     if (this._cfgPrettyPrinter != null)
/*      */     {
/*  930 */       _verifyPrettyValueWrite(typeMsg, status); return;
/*      */     }
/*      */     char c;
/*      */     char c;
/*  934 */     switch (status) {
/*      */     case 0: case 4: 
/*      */     default: 
/*  937 */       return;
/*      */     case 1: 
/*  939 */       c = ',';
/*  940 */       break;
/*      */     case 2: 
/*  942 */       c = ':';
/*  943 */       break;
/*      */     case 3: 
/*  945 */       if (this._rootValueSeparator != null) {
/*  946 */         writeRaw(this._rootValueSeparator.getValue());
/*      */       }
/*  948 */       return;
/*      */     case 5: 
/*  950 */       _reportCantWriteValueExpectName(typeMsg); return;
/*      */     }
/*      */     char c;
/*  953 */     if (this._outputTail >= this._outputEnd) {
/*  954 */       _flushBuffer();
/*      */     }
/*  956 */     this._outputBuffer[(this._outputTail++)] = c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void flush()
/*      */     throws IOException
/*      */   {
/*  968 */     _flushBuffer();
/*  969 */     if ((this._writer != null) && 
/*  970 */       (isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM))) {
/*  971 */       this._writer.flush();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/*  979 */     super.close();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  985 */     if ((this._outputBuffer != null) && 
/*  986 */       (isEnabled(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT))) {
/*      */       for (;;) {
/*  988 */         JsonStreamContext ctxt = getOutputContext();
/*  989 */         if (ctxt.inArray()) {
/*  990 */           writeEndArray();
/*  991 */         } else { if (!ctxt.inObject()) break;
/*  992 */           writeEndObject();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  998 */     _flushBuffer();
/*  999 */     this._outputHead = 0;
/* 1000 */     this._outputTail = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1008 */     if (this._writer != null) {
/* 1009 */       if ((this._ioContext.isResourceManaged()) || (isEnabled(JsonGenerator.Feature.AUTO_CLOSE_TARGET))) {
/* 1010 */         this._writer.close();
/* 1011 */       } else if (isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM))
/*      */       {
/* 1013 */         this._writer.flush();
/*      */       }
/*      */     }
/*      */     
/* 1017 */     _releaseBuffers();
/*      */   }
/*      */   
/*      */ 
/*      */   protected void _releaseBuffers()
/*      */   {
/* 1023 */     char[] buf = this._outputBuffer;
/* 1024 */     if (buf != null) {
/* 1025 */       this._outputBuffer = null;
/* 1026 */       this._ioContext.releaseConcatBuffer(buf);
/*      */     }
/* 1028 */     buf = this._copyBuffer;
/* 1029 */     if (buf != null) {
/* 1030 */       this._copyBuffer = null;
/* 1031 */       this._ioContext.releaseNameCopyBuffer(buf);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _writeString(String text)
/*      */     throws IOException
/*      */   {
/* 1048 */     int len = text.length();
/* 1049 */     if (len > this._outputEnd) {
/* 1050 */       _writeLongString(text);
/* 1051 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1056 */     if (this._outputTail + len > this._outputEnd) {
/* 1057 */       _flushBuffer();
/*      */     }
/* 1059 */     text.getChars(0, len, this._outputBuffer, this._outputTail);
/*      */     
/* 1061 */     if (this._characterEscapes != null) {
/* 1062 */       _writeStringCustom(len);
/* 1063 */     } else if (this._maximumNonEscapedChar != 0) {
/* 1064 */       _writeStringASCII(len, this._maximumNonEscapedChar);
/*      */     } else {
/* 1066 */       _writeString2(len);
/*      */     }
/*      */   }
/*      */   
/*      */   private void _writeString2(int len)
/*      */     throws IOException
/*      */   {
/* 1073 */     int end = this._outputTail + len;
/* 1074 */     int[] escCodes = this._outputEscapes;
/* 1075 */     int escLen = escCodes.length;
/*      */     
/*      */ 
/* 1078 */     while (this._outputTail < end)
/*      */     {
/*      */       for (;;)
/*      */       {
/* 1082 */         char c = this._outputBuffer[this._outputTail];
/* 1083 */         if ((c < escLen) && (escCodes[c] != 0)) {
/*      */           break;
/*      */         }
/* 1086 */         if (++this._outputTail >= end) {
/*      */           return;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1095 */       int flushLen = this._outputTail - this._outputHead;
/* 1096 */       if (flushLen > 0) {
/* 1097 */         this._writer.write(this._outputBuffer, this._outputHead, flushLen);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1102 */       char c = this._outputBuffer[(this._outputTail++)];
/* 1103 */       _prependOrWriteCharacterEscape(c, escCodes[c]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _writeLongString(String text)
/*      */     throws IOException
/*      */   {
/* 1114 */     _flushBuffer();
/*      */     
/*      */ 
/* 1117 */     int textLen = text.length();
/* 1118 */     int offset = 0;
/*      */     do {
/* 1120 */       int max = this._outputEnd;
/* 1121 */       int segmentLen = offset + max > textLen ? textLen - offset : max;
/*      */       
/* 1123 */       text.getChars(offset, offset + segmentLen, this._outputBuffer, 0);
/* 1124 */       if (this._characterEscapes != null) {
/* 1125 */         _writeSegmentCustom(segmentLen);
/* 1126 */       } else if (this._maximumNonEscapedChar != 0) {
/* 1127 */         _writeSegmentASCII(segmentLen, this._maximumNonEscapedChar);
/*      */       } else {
/* 1129 */         _writeSegment(segmentLen);
/*      */       }
/* 1131 */       offset += segmentLen;
/* 1132 */     } while (offset < textLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _writeSegment(int end)
/*      */     throws IOException
/*      */   {
/* 1146 */     int[] escCodes = this._outputEscapes;
/* 1147 */     int escLen = escCodes.length;
/*      */     
/* 1149 */     int ptr = 0;
/* 1150 */     int start = ptr;
/*      */     
/*      */ 
/* 1153 */     while (ptr < end)
/*      */     {
/*      */       char c;
/*      */       for (;;) {
/* 1157 */         c = this._outputBuffer[ptr];
/* 1158 */         if ((c >= escLen) || (escCodes[c] == 0))
/*      */         {
/*      */ 
/* 1161 */           ptr++; if (ptr >= end) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1170 */       int flushLen = ptr - start;
/* 1171 */       if (flushLen > 0) {
/* 1172 */         this._writer.write(this._outputBuffer, start, flushLen);
/* 1173 */         if (ptr >= end) {
/*      */           break;
/*      */         }
/*      */       }
/* 1177 */       ptr++;
/*      */       
/* 1179 */       start = _prependOrWriteCharacterEscape(this._outputBuffer, ptr, end, c, escCodes[c]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _writeString(char[] text, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 1189 */     if (this._characterEscapes != null) {
/* 1190 */       _writeStringCustom(text, offset, len);
/* 1191 */       return;
/*      */     }
/* 1193 */     if (this._maximumNonEscapedChar != 0) {
/* 1194 */       _writeStringASCII(text, offset, len, this._maximumNonEscapedChar);
/* 1195 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1201 */     len += offset;
/* 1202 */     int[] escCodes = this._outputEscapes;
/* 1203 */     int escLen = escCodes.length;
/* 1204 */     while (offset < len) {
/* 1205 */       int start = offset;
/*      */       for (;;)
/*      */       {
/* 1208 */         char c = text[offset];
/* 1209 */         if ((c < escLen) && (escCodes[c] != 0)) {
/*      */           break;
/*      */         }
/* 1212 */         offset++; if (offset >= len) {
/*      */           break;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1218 */       int newAmount = offset - start;
/* 1219 */       if (newAmount < 32)
/*      */       {
/* 1221 */         if (this._outputTail + newAmount > this._outputEnd) {
/* 1222 */           _flushBuffer();
/*      */         }
/* 1224 */         if (newAmount > 0) {
/* 1225 */           System.arraycopy(text, start, this._outputBuffer, this._outputTail, newAmount);
/* 1226 */           this._outputTail += newAmount;
/*      */         }
/*      */       } else {
/* 1229 */         _flushBuffer();
/* 1230 */         this._writer.write(text, start, newAmount);
/*      */       }
/*      */       
/* 1233 */       if (offset >= len) {
/*      */         break;
/*      */       }
/*      */       
/* 1237 */       char c = text[(offset++)];
/* 1238 */       _appendCharacterEscape(c, escCodes[c]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _writeStringASCII(int len, int maxNonEscaped)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1256 */     int end = this._outputTail + len;
/* 1257 */     int[] escCodes = this._outputEscapes;
/* 1258 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/* 1259 */     int escCode = 0;
/*      */     
/*      */ 
/* 1262 */     while (this._outputTail < end)
/*      */     {
/*      */       char c;
/*      */       do
/*      */       {
/* 1267 */         c = this._outputBuffer[this._outputTail];
/* 1268 */         if (c < escLimit) {
/* 1269 */           escCode = escCodes[c];
/* 1270 */           if (escCode != 0) {
/*      */             break;
/*      */           }
/* 1273 */         } else if (c > maxNonEscaped) {
/* 1274 */           escCode = -1;
/* 1275 */           break;
/*      */         }
/* 1277 */       } while (++this._outputTail < end);
/* 1278 */       break;
/*      */       
/*      */ 
/* 1281 */       int flushLen = this._outputTail - this._outputHead;
/* 1282 */       if (flushLen > 0) {
/* 1283 */         this._writer.write(this._outputBuffer, this._outputHead, flushLen);
/*      */       }
/* 1285 */       this._outputTail += 1;
/* 1286 */       _prependOrWriteCharacterEscape(c, escCode);
/*      */     }
/*      */   }
/*      */   
/*      */   private void _writeSegmentASCII(int end, int maxNonEscaped)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1293 */     int[] escCodes = this._outputEscapes;
/* 1294 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/*      */     
/* 1296 */     int ptr = 0;
/* 1297 */     int escCode = 0;
/* 1298 */     int start = ptr;
/*      */     
/*      */ 
/* 1301 */     while (ptr < end)
/*      */     {
/*      */       char c;
/*      */       for (;;) {
/* 1305 */         c = this._outputBuffer[ptr];
/* 1306 */         if (c < escLimit) {
/* 1307 */           escCode = escCodes[c];
/* 1308 */           if (escCode != 0) {
/*      */             break;
/*      */           }
/* 1311 */         } else if (c > maxNonEscaped) {
/* 1312 */           escCode = -1;
/* 1313 */           break;
/*      */         }
/* 1315 */         ptr++; if (ptr >= end) {
/*      */           break;
/*      */         }
/*      */       }
/* 1319 */       int flushLen = ptr - start;
/* 1320 */       if (flushLen > 0) {
/* 1321 */         this._writer.write(this._outputBuffer, start, flushLen);
/* 1322 */         if (ptr >= end) {
/*      */           break;
/*      */         }
/*      */       }
/* 1326 */       ptr++;
/* 1327 */       start = _prependOrWriteCharacterEscape(this._outputBuffer, ptr, end, c, escCode);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void _writeStringASCII(char[] text, int offset, int len, int maxNonEscaped)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1335 */     len += offset;
/* 1336 */     int[] escCodes = this._outputEscapes;
/* 1337 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/*      */     
/* 1339 */     int escCode = 0;
/*      */     
/* 1341 */     while (offset < len) {
/* 1342 */       int start = offset;
/*      */       char c;
/*      */       for (;;)
/*      */       {
/* 1346 */         c = text[offset];
/* 1347 */         if (c < escLimit) {
/* 1348 */           escCode = escCodes[c];
/* 1349 */           if (escCode != 0) {
/*      */             break;
/*      */           }
/* 1352 */         } else if (c > maxNonEscaped) {
/* 1353 */           escCode = -1;
/* 1354 */           break;
/*      */         }
/* 1356 */         offset++; if (offset >= len) {
/*      */           break;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1362 */       int newAmount = offset - start;
/* 1363 */       if (newAmount < 32)
/*      */       {
/* 1365 */         if (this._outputTail + newAmount > this._outputEnd) {
/* 1366 */           _flushBuffer();
/*      */         }
/* 1368 */         if (newAmount > 0) {
/* 1369 */           System.arraycopy(text, start, this._outputBuffer, this._outputTail, newAmount);
/* 1370 */           this._outputTail += newAmount;
/*      */         }
/*      */       } else {
/* 1373 */         _flushBuffer();
/* 1374 */         this._writer.write(text, start, newAmount);
/*      */       }
/*      */       
/* 1377 */       if (offset >= len) {
/*      */         break;
/*      */       }
/*      */       
/* 1381 */       offset++;
/* 1382 */       _appendCharacterEscape(c, escCode);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _writeStringCustom(int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1400 */     int end = this._outputTail + len;
/* 1401 */     int[] escCodes = this._outputEscapes;
/* 1402 */     int maxNonEscaped = this._maximumNonEscapedChar < 1 ? 65535 : this._maximumNonEscapedChar;
/* 1403 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/* 1404 */     int escCode = 0;
/* 1405 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/*      */ 
/* 1408 */     while (this._outputTail < end)
/*      */     {
/*      */       char c;
/*      */       do
/*      */       {
/* 1413 */         c = this._outputBuffer[this._outputTail];
/* 1414 */         if (c < escLimit) {
/* 1415 */           escCode = escCodes[c];
/* 1416 */           if (escCode != 0)
/*      */             break;
/*      */         } else {
/* 1419 */           if (c > maxNonEscaped) {
/* 1420 */             escCode = -1;
/* 1421 */             break;
/*      */           }
/* 1423 */           if ((this._currentEscape = customEscapes.getEscapeSequence(c)) != null) {
/* 1424 */             escCode = -2;
/* 1425 */             break;
/*      */           }
/*      */         }
/* 1428 */       } while (++this._outputTail < end);
/* 1429 */       break;
/*      */       
/*      */ 
/* 1432 */       int flushLen = this._outputTail - this._outputHead;
/* 1433 */       if (flushLen > 0) {
/* 1434 */         this._writer.write(this._outputBuffer, this._outputHead, flushLen);
/*      */       }
/* 1436 */       this._outputTail += 1;
/* 1437 */       _prependOrWriteCharacterEscape(c, escCode);
/*      */     }
/*      */   }
/*      */   
/*      */   private void _writeSegmentCustom(int end)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1444 */     int[] escCodes = this._outputEscapes;
/* 1445 */     int maxNonEscaped = this._maximumNonEscapedChar < 1 ? 65535 : this._maximumNonEscapedChar;
/* 1446 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/* 1447 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/* 1449 */     int ptr = 0;
/* 1450 */     int escCode = 0;
/* 1451 */     int start = ptr;
/*      */     
/*      */ 
/* 1454 */     while (ptr < end)
/*      */     {
/*      */       char c;
/*      */       for (;;) {
/* 1458 */         c = this._outputBuffer[ptr];
/* 1459 */         if (c < escLimit) {
/* 1460 */           escCode = escCodes[c];
/* 1461 */           if (escCode != 0)
/*      */             break;
/*      */         } else {
/* 1464 */           if (c > maxNonEscaped) {
/* 1465 */             escCode = -1;
/* 1466 */             break;
/*      */           }
/* 1468 */           if ((this._currentEscape = customEscapes.getEscapeSequence(c)) != null) {
/* 1469 */             escCode = -2;
/* 1470 */             break;
/*      */           }
/*      */         }
/* 1473 */         ptr++; if (ptr >= end) {
/*      */           break;
/*      */         }
/*      */       }
/* 1477 */       int flushLen = ptr - start;
/* 1478 */       if (flushLen > 0) {
/* 1479 */         this._writer.write(this._outputBuffer, start, flushLen);
/* 1480 */         if (ptr >= end) {
/*      */           break;
/*      */         }
/*      */       }
/* 1484 */       ptr++;
/* 1485 */       start = _prependOrWriteCharacterEscape(this._outputBuffer, ptr, end, c, escCode);
/*      */     }
/*      */   }
/*      */   
/*      */   private void _writeStringCustom(char[] text, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1492 */     len += offset;
/* 1493 */     int[] escCodes = this._outputEscapes;
/* 1494 */     int maxNonEscaped = this._maximumNonEscapedChar < 1 ? 65535 : this._maximumNonEscapedChar;
/* 1495 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/* 1496 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/* 1498 */     int escCode = 0;
/*      */     
/* 1500 */     while (offset < len) {
/* 1501 */       int start = offset;
/*      */       char c;
/*      */       for (;;)
/*      */       {
/* 1505 */         c = text[offset];
/* 1506 */         if (c < escLimit) {
/* 1507 */           escCode = escCodes[c];
/* 1508 */           if (escCode != 0)
/*      */             break;
/*      */         } else {
/* 1511 */           if (c > maxNonEscaped) {
/* 1512 */             escCode = -1;
/* 1513 */             break;
/*      */           }
/* 1515 */           if ((this._currentEscape = customEscapes.getEscapeSequence(c)) != null) {
/* 1516 */             escCode = -2;
/* 1517 */             break;
/*      */           }
/*      */         }
/* 1520 */         offset++; if (offset >= len) {
/*      */           break;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1526 */       int newAmount = offset - start;
/* 1527 */       if (newAmount < 32)
/*      */       {
/* 1529 */         if (this._outputTail + newAmount > this._outputEnd) {
/* 1530 */           _flushBuffer();
/*      */         }
/* 1532 */         if (newAmount > 0) {
/* 1533 */           System.arraycopy(text, start, this._outputBuffer, this._outputTail, newAmount);
/* 1534 */           this._outputTail += newAmount;
/*      */         }
/*      */       } else {
/* 1537 */         _flushBuffer();
/* 1538 */         this._writer.write(text, start, newAmount);
/*      */       }
/*      */       
/* 1541 */       if (offset >= len) {
/*      */         break;
/*      */       }
/*      */       
/* 1545 */       offset++;
/* 1546 */       _appendCharacterEscape(c, escCode);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _writeBinary(Base64Variant b64variant, byte[] input, int inputPtr, int inputEnd)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1560 */     int safeInputEnd = inputEnd - 3;
/*      */     
/* 1562 */     int safeOutputEnd = this._outputEnd - 6;
/* 1563 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */     
/*      */ 
/* 1566 */     while (inputPtr <= safeInputEnd) {
/* 1567 */       if (this._outputTail > safeOutputEnd) {
/* 1568 */         _flushBuffer();
/*      */       }
/*      */       
/* 1571 */       int b24 = input[(inputPtr++)] << 8;
/* 1572 */       b24 |= input[(inputPtr++)] & 0xFF;
/* 1573 */       b24 = b24 << 8 | input[(inputPtr++)] & 0xFF;
/* 1574 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1575 */       chunksBeforeLF--; if (chunksBeforeLF <= 0)
/*      */       {
/* 1577 */         this._outputBuffer[(this._outputTail++)] = '\\';
/* 1578 */         this._outputBuffer[(this._outputTail++)] = 'n';
/* 1579 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1584 */     int inputLeft = inputEnd - inputPtr;
/* 1585 */     if (inputLeft > 0) {
/* 1586 */       if (this._outputTail > safeOutputEnd) {
/* 1587 */         _flushBuffer();
/*      */       }
/* 1589 */       int b24 = input[(inputPtr++)] << 16;
/* 1590 */       if (inputLeft == 2) {
/* 1591 */         b24 |= (input[(inputPtr++)] & 0xFF) << 8;
/*      */       }
/* 1593 */       this._outputTail = b64variant.encodeBase64Partial(b24, inputLeft, this._outputBuffer, this._outputTail);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final int _writeBinary(Base64Variant b64variant, InputStream data, byte[] readBuffer, int bytesLeft)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1602 */     int inputPtr = 0;
/* 1603 */     int inputEnd = 0;
/* 1604 */     int lastFullOffset = -3;
/*      */     
/*      */ 
/* 1607 */     int safeOutputEnd = this._outputEnd - 6;
/* 1608 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */     
/* 1610 */     while (bytesLeft > 2) {
/* 1611 */       if (inputPtr > lastFullOffset) {
/* 1612 */         inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, bytesLeft);
/* 1613 */         inputPtr = 0;
/* 1614 */         if (inputEnd < 3) {
/*      */           break;
/*      */         }
/* 1617 */         lastFullOffset = inputEnd - 3;
/*      */       }
/* 1619 */       if (this._outputTail > safeOutputEnd) {
/* 1620 */         _flushBuffer();
/*      */       }
/* 1622 */       int b24 = readBuffer[(inputPtr++)] << 8;
/* 1623 */       b24 |= readBuffer[(inputPtr++)] & 0xFF;
/* 1624 */       b24 = b24 << 8 | readBuffer[(inputPtr++)] & 0xFF;
/* 1625 */       bytesLeft -= 3;
/* 1626 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1627 */       chunksBeforeLF--; if (chunksBeforeLF <= 0) {
/* 1628 */         this._outputBuffer[(this._outputTail++)] = '\\';
/* 1629 */         this._outputBuffer[(this._outputTail++)] = 'n';
/* 1630 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1635 */     if (bytesLeft > 0) {
/* 1636 */       inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, bytesLeft);
/* 1637 */       inputPtr = 0;
/* 1638 */       if (inputEnd > 0) {
/* 1639 */         if (this._outputTail > safeOutputEnd) {
/* 1640 */           _flushBuffer();
/*      */         }
/* 1642 */         int b24 = readBuffer[(inputPtr++)] << 16;
/*      */         int amount;
/* 1644 */         int amount; if (inputPtr < inputEnd) {
/* 1645 */           b24 |= (readBuffer[inputPtr] & 0xFF) << 8;
/* 1646 */           amount = 2;
/*      */         } else {
/* 1648 */           amount = 1;
/*      */         }
/* 1650 */         this._outputTail = b64variant.encodeBase64Partial(b24, amount, this._outputBuffer, this._outputTail);
/* 1651 */         bytesLeft -= amount;
/*      */       }
/*      */     }
/* 1654 */     return bytesLeft;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final int _writeBinary(Base64Variant b64variant, InputStream data, byte[] readBuffer)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1662 */     int inputPtr = 0;
/* 1663 */     int inputEnd = 0;
/* 1664 */     int lastFullOffset = -3;
/* 1665 */     int bytesDone = 0;
/*      */     
/*      */ 
/* 1668 */     int safeOutputEnd = this._outputEnd - 6;
/* 1669 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */     
/*      */     for (;;)
/*      */     {
/* 1673 */       if (inputPtr > lastFullOffset) {
/* 1674 */         inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, readBuffer.length);
/* 1675 */         inputPtr = 0;
/* 1676 */         if (inputEnd < 3) {
/*      */           break;
/*      */         }
/* 1679 */         lastFullOffset = inputEnd - 3;
/*      */       }
/* 1681 */       if (this._outputTail > safeOutputEnd) {
/* 1682 */         _flushBuffer();
/*      */       }
/*      */       
/* 1685 */       int b24 = readBuffer[(inputPtr++)] << 8;
/* 1686 */       b24 |= readBuffer[(inputPtr++)] & 0xFF;
/* 1687 */       b24 = b24 << 8 | readBuffer[(inputPtr++)] & 0xFF;
/* 1688 */       bytesDone += 3;
/* 1689 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1690 */       chunksBeforeLF--; if (chunksBeforeLF <= 0) {
/* 1691 */         this._outputBuffer[(this._outputTail++)] = '\\';
/* 1692 */         this._outputBuffer[(this._outputTail++)] = 'n';
/* 1693 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1698 */     if (inputPtr < inputEnd) {
/* 1699 */       if (this._outputTail > safeOutputEnd) {
/* 1700 */         _flushBuffer();
/*      */       }
/* 1702 */       int b24 = readBuffer[(inputPtr++)] << 16;
/* 1703 */       int amount = 1;
/* 1704 */       if (inputPtr < inputEnd) {
/* 1705 */         b24 |= (readBuffer[inputPtr] & 0xFF) << 8;
/* 1706 */         amount = 2;
/*      */       }
/* 1708 */       bytesDone += amount;
/* 1709 */       this._outputTail = b64variant.encodeBase64Partial(b24, amount, this._outputBuffer, this._outputTail);
/*      */     }
/* 1711 */     return bytesDone;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int _readMore(InputStream in, byte[] readBuffer, int inputPtr, int inputEnd, int maxRead)
/*      */     throws IOException
/*      */   {
/* 1719 */     int i = 0;
/* 1720 */     while (inputPtr < inputEnd) {
/* 1721 */       readBuffer[(i++)] = readBuffer[(inputPtr++)];
/*      */     }
/* 1723 */     inputPtr = 0;
/* 1724 */     inputEnd = i;
/* 1725 */     maxRead = Math.min(maxRead, readBuffer.length);
/*      */     do
/*      */     {
/* 1728 */       int length = maxRead - inputEnd;
/* 1729 */       if (length == 0) {
/*      */         break;
/*      */       }
/* 1732 */       int count = in.read(readBuffer, inputEnd, length);
/* 1733 */       if (count < 0) {
/* 1734 */         return inputEnd;
/*      */       }
/* 1736 */       inputEnd += count;
/* 1737 */     } while (inputEnd < 3);
/* 1738 */     return inputEnd;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeNull()
/*      */     throws IOException
/*      */   {
/* 1749 */     if (this._outputTail + 4 >= this._outputEnd) {
/* 1750 */       _flushBuffer();
/*      */     }
/* 1752 */     int ptr = this._outputTail;
/* 1753 */     char[] buf = this._outputBuffer;
/* 1754 */     buf[ptr] = 'n';
/* 1755 */     buf[(++ptr)] = 'u';
/* 1756 */     buf[(++ptr)] = 'l';
/* 1757 */     buf[(++ptr)] = 'l';
/* 1758 */     this._outputTail = (ptr + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _prependOrWriteCharacterEscape(char ch, int escCode)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1775 */     if (escCode >= 0) {
/* 1776 */       if (this._outputTail >= 2) {
/* 1777 */         int ptr = this._outputTail - 2;
/* 1778 */         this._outputHead = ptr;
/* 1779 */         this._outputBuffer[(ptr++)] = '\\';
/* 1780 */         this._outputBuffer[ptr] = ((char)escCode);
/* 1781 */         return;
/*      */       }
/*      */       
/* 1784 */       char[] buf = this._entityBuffer;
/* 1785 */       if (buf == null) {
/* 1786 */         buf = _allocateEntityBuffer();
/*      */       }
/* 1788 */       this._outputHead = this._outputTail;
/* 1789 */       buf[1] = ((char)escCode);
/* 1790 */       this._writer.write(buf, 0, 2);
/* 1791 */       return;
/*      */     }
/* 1793 */     if (escCode != -2) {
/* 1794 */       if (this._outputTail >= 6) {
/* 1795 */         char[] buf = this._outputBuffer;
/* 1796 */         int ptr = this._outputTail - 6;
/* 1797 */         this._outputHead = ptr;
/* 1798 */         buf[ptr] = '\\';
/* 1799 */         buf[(++ptr)] = 'u';
/*      */         
/* 1801 */         if (ch > 'ÿ') {
/* 1802 */           int hi = ch >> '\b' & 0xFF;
/* 1803 */           buf[(++ptr)] = HEX_CHARS[(hi >> 4)];
/* 1804 */           buf[(++ptr)] = HEX_CHARS[(hi & 0xF)];
/* 1805 */           ch = (char)(ch & 0xFF);
/*      */         } else {
/* 1807 */           buf[(++ptr)] = '0';
/* 1808 */           buf[(++ptr)] = '0';
/*      */         }
/* 1810 */         buf[(++ptr)] = HEX_CHARS[(ch >> '\004')];
/* 1811 */         buf[(++ptr)] = HEX_CHARS[(ch & 0xF)];
/* 1812 */         return;
/*      */       }
/*      */       
/* 1815 */       char[] buf = this._entityBuffer;
/* 1816 */       if (buf == null) {
/* 1817 */         buf = _allocateEntityBuffer();
/*      */       }
/* 1819 */       this._outputHead = this._outputTail;
/* 1820 */       if (ch > 'ÿ') {
/* 1821 */         int hi = ch >> '\b' & 0xFF;
/* 1822 */         int lo = ch & 0xFF;
/* 1823 */         buf[10] = HEX_CHARS[(hi >> 4)];
/* 1824 */         buf[11] = HEX_CHARS[(hi & 0xF)];
/* 1825 */         buf[12] = HEX_CHARS[(lo >> 4)];
/* 1826 */         buf[13] = HEX_CHARS[(lo & 0xF)];
/* 1827 */         this._writer.write(buf, 8, 6);
/*      */       } else {
/* 1829 */         buf[6] = HEX_CHARS[(ch >> '\004')];
/* 1830 */         buf[7] = HEX_CHARS[(ch & 0xF)];
/* 1831 */         this._writer.write(buf, 2, 6);
/*      */       }
/*      */       return;
/*      */     }
/*      */     String escape;
/*      */     String escape;
/* 1837 */     if (this._currentEscape == null) {
/* 1838 */       escape = this._characterEscapes.getEscapeSequence(ch).getValue();
/*      */     } else {
/* 1840 */       escape = this._currentEscape.getValue();
/* 1841 */       this._currentEscape = null;
/*      */     }
/* 1843 */     int len = escape.length();
/* 1844 */     if (this._outputTail >= len) {
/* 1845 */       int ptr = this._outputTail - len;
/* 1846 */       this._outputHead = ptr;
/* 1847 */       escape.getChars(0, len, this._outputBuffer, ptr);
/* 1848 */       return;
/*      */     }
/*      */     
/* 1851 */     this._outputHead = this._outputTail;
/* 1852 */     this._writer.write(escape);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int _prependOrWriteCharacterEscape(char[] buffer, int ptr, int end, char ch, int escCode)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1866 */     if (escCode >= 0) {
/* 1867 */       if ((ptr > 1) && (ptr < end)) {
/* 1868 */         ptr -= 2;
/* 1869 */         buffer[ptr] = '\\';
/* 1870 */         buffer[(ptr + 1)] = ((char)escCode);
/*      */       } else {
/* 1872 */         char[] ent = this._entityBuffer;
/* 1873 */         if (ent == null) {
/* 1874 */           ent = _allocateEntityBuffer();
/*      */         }
/* 1876 */         ent[1] = ((char)escCode);
/* 1877 */         this._writer.write(ent, 0, 2);
/*      */       }
/* 1879 */       return ptr;
/*      */     }
/* 1881 */     if (escCode != -2) {
/* 1882 */       if ((ptr > 5) && (ptr < end)) {
/* 1883 */         ptr -= 6;
/* 1884 */         buffer[(ptr++)] = '\\';
/* 1885 */         buffer[(ptr++)] = 'u';
/*      */         
/* 1887 */         if (ch > 'ÿ') {
/* 1888 */           int hi = ch >> '\b' & 0xFF;
/* 1889 */           buffer[(ptr++)] = HEX_CHARS[(hi >> 4)];
/* 1890 */           buffer[(ptr++)] = HEX_CHARS[(hi & 0xF)];
/* 1891 */           ch = (char)(ch & 0xFF);
/*      */         } else {
/* 1893 */           buffer[(ptr++)] = '0';
/* 1894 */           buffer[(ptr++)] = '0';
/*      */         }
/* 1896 */         buffer[(ptr++)] = HEX_CHARS[(ch >> '\004')];
/* 1897 */         buffer[ptr] = HEX_CHARS[(ch & 0xF)];
/* 1898 */         ptr -= 5;
/*      */       }
/*      */       else {
/* 1901 */         char[] ent = this._entityBuffer;
/* 1902 */         if (ent == null) {
/* 1903 */           ent = _allocateEntityBuffer();
/*      */         }
/* 1905 */         this._outputHead = this._outputTail;
/* 1906 */         if (ch > 'ÿ') {
/* 1907 */           int hi = ch >> '\b' & 0xFF;
/* 1908 */           int lo = ch & 0xFF;
/* 1909 */           ent[10] = HEX_CHARS[(hi >> 4)];
/* 1910 */           ent[11] = HEX_CHARS[(hi & 0xF)];
/* 1911 */           ent[12] = HEX_CHARS[(lo >> 4)];
/* 1912 */           ent[13] = HEX_CHARS[(lo & 0xF)];
/* 1913 */           this._writer.write(ent, 8, 6);
/*      */         } else {
/* 1915 */           ent[6] = HEX_CHARS[(ch >> '\004')];
/* 1916 */           ent[7] = HEX_CHARS[(ch & 0xF)];
/* 1917 */           this._writer.write(ent, 2, 6);
/*      */         }
/*      */       }
/* 1920 */       return ptr; }
/*      */     String escape;
/*      */     String escape;
/* 1923 */     if (this._currentEscape == null) {
/* 1924 */       escape = this._characterEscapes.getEscapeSequence(ch).getValue();
/*      */     } else {
/* 1926 */       escape = this._currentEscape.getValue();
/* 1927 */       this._currentEscape = null;
/*      */     }
/* 1929 */     int len = escape.length();
/* 1930 */     if ((ptr >= len) && (ptr < end)) {
/* 1931 */       ptr -= len;
/* 1932 */       escape.getChars(0, len, buffer, ptr);
/*      */     } else {
/* 1934 */       this._writer.write(escape);
/*      */     }
/* 1936 */     return ptr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _appendCharacterEscape(char ch, int escCode)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1946 */     if (escCode >= 0) {
/* 1947 */       if (this._outputTail + 2 > this._outputEnd) {
/* 1948 */         _flushBuffer();
/*      */       }
/* 1950 */       this._outputBuffer[(this._outputTail++)] = '\\';
/* 1951 */       this._outputBuffer[(this._outputTail++)] = ((char)escCode);
/* 1952 */       return;
/*      */     }
/* 1954 */     if (escCode != -2) {
/* 1955 */       if (this._outputTail + 5 >= this._outputEnd) {
/* 1956 */         _flushBuffer();
/*      */       }
/* 1958 */       int ptr = this._outputTail;
/* 1959 */       char[] buf = this._outputBuffer;
/* 1960 */       buf[(ptr++)] = '\\';
/* 1961 */       buf[(ptr++)] = 'u';
/*      */       
/* 1963 */       if (ch > 'ÿ') {
/* 1964 */         int hi = ch >> '\b' & 0xFF;
/* 1965 */         buf[(ptr++)] = HEX_CHARS[(hi >> 4)];
/* 1966 */         buf[(ptr++)] = HEX_CHARS[(hi & 0xF)];
/* 1967 */         ch = (char)(ch & 0xFF);
/*      */       } else {
/* 1969 */         buf[(ptr++)] = '0';
/* 1970 */         buf[(ptr++)] = '0';
/*      */       }
/* 1972 */       buf[(ptr++)] = HEX_CHARS[(ch >> '\004')];
/* 1973 */       buf[(ptr++)] = HEX_CHARS[(ch & 0xF)];
/* 1974 */       this._outputTail = ptr; return;
/*      */     }
/*      */     String escape;
/*      */     String escape;
/* 1978 */     if (this._currentEscape == null) {
/* 1979 */       escape = this._characterEscapes.getEscapeSequence(ch).getValue();
/*      */     } else {
/* 1981 */       escape = this._currentEscape.getValue();
/* 1982 */       this._currentEscape = null;
/*      */     }
/* 1984 */     int len = escape.length();
/* 1985 */     if (this._outputTail + len > this._outputEnd) {
/* 1986 */       _flushBuffer();
/* 1987 */       if (len > this._outputEnd) {
/* 1988 */         this._writer.write(escape);
/* 1989 */         return;
/*      */       }
/*      */     }
/* 1992 */     escape.getChars(0, len, this._outputBuffer, this._outputTail);
/* 1993 */     this._outputTail += len;
/*      */   }
/*      */   
/*      */   private char[] _allocateEntityBuffer()
/*      */   {
/* 1998 */     char[] buf = new char[14];
/*      */     
/* 2000 */     buf[0] = '\\';
/*      */     
/* 2002 */     buf[2] = '\\';
/* 2003 */     buf[3] = 'u';
/* 2004 */     buf[4] = '0';
/* 2005 */     buf[5] = '0';
/*      */     
/* 2007 */     buf[8] = '\\';
/* 2008 */     buf[9] = 'u';
/* 2009 */     this._entityBuffer = buf;
/* 2010 */     return buf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private char[] _allocateCopyBuffer()
/*      */   {
/* 2017 */     if (this._copyBuffer == null) {
/* 2018 */       this._copyBuffer = this._ioContext.allocNameCopyBuffer(2000);
/*      */     }
/* 2020 */     return this._copyBuffer;
/*      */   }
/*      */   
/*      */   protected void _flushBuffer() throws IOException
/*      */   {
/* 2025 */     int len = this._outputTail - this._outputHead;
/* 2026 */     if (len > 0) {
/* 2027 */       int offset = this._outputHead;
/* 2028 */       this._outputTail = (this._outputHead = 0);
/* 2029 */       this._writer.write(this._outputBuffer, offset, len);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\json\WriterBasedJsonGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */