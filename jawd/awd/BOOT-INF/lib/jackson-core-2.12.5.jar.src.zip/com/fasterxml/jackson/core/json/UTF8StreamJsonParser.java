/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.base.ParserBase;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.TextBuffer;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ 
/*      */ public class UTF8StreamJsonParser extends ParserBase
/*      */ {
/*      */   static final byte BYTE_LF = 10;
/*   24 */   private static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*      */   
/*   26 */   private static final int FEAT_MASK_LEADING_ZEROS = JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS.getMask();
/*      */   
/*   28 */   private static final int FEAT_MASK_NON_NUM_NUMBERS = JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS.getMask();
/*      */   
/*   30 */   private static final int FEAT_MASK_ALLOW_MISSING = JsonParser.Feature.ALLOW_MISSING_VALUES.getMask();
/*   31 */   private static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
/*   32 */   private static final int FEAT_MASK_ALLOW_UNQUOTED_NAMES = JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
/*   33 */   private static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = JsonParser.Feature.ALLOW_COMMENTS.getMask();
/*   34 */   private static final int FEAT_MASK_ALLOW_YAML_COMMENTS = JsonParser.Feature.ALLOW_YAML_COMMENTS.getMask();
/*      */   
/*      */ 
/*   37 */   private static final int[] _icUTF8 = CharTypes.getInputCodeUtf8();
/*      */   
/*      */ 
/*      */ 
/*   41 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectCodec _objectCodec;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final ByteQuadsCanonicalizer _symbols;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   70 */   protected int[] _quadBuffer = new int[16];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _tokenIncomplete;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int _quad1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _nameStartOffset;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _nameStartRow;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _nameStartCol;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputStream _inputStream;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] _inputBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _bufferRecyclable;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public UTF8StreamJsonParser(IOContext ctxt, int features, InputStream in, ObjectCodec codec, ByteQuadsCanonicalizer sym, byte[] inputBuffer, int start, int end, boolean bufferRecyclable)
/*      */   {
/*  149 */     this(ctxt, features, in, codec, sym, inputBuffer, start, end, 0, bufferRecyclable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UTF8StreamJsonParser(IOContext ctxt, int features, InputStream in, ObjectCodec codec, ByteQuadsCanonicalizer sym, byte[] inputBuffer, int start, int end, int bytesPreProcessed, boolean bufferRecyclable)
/*      */   {
/*  158 */     super(ctxt, features);
/*  159 */     this._inputStream = in;
/*  160 */     this._objectCodec = codec;
/*  161 */     this._symbols = sym;
/*  162 */     this._inputBuffer = inputBuffer;
/*  163 */     this._inputPtr = start;
/*  164 */     this._inputEnd = end;
/*  165 */     this._currInputRowStart = (start - bytesPreProcessed);
/*      */     
/*  167 */     this._currInputProcessed = (-start + bytesPreProcessed);
/*  168 */     this._bufferRecyclable = bufferRecyclable;
/*      */   }
/*      */   
/*      */   public ObjectCodec getCodec()
/*      */   {
/*  173 */     return this._objectCodec;
/*      */   }
/*      */   
/*      */   public void setCodec(ObjectCodec c)
/*      */   {
/*  178 */     this._objectCodec = c;
/*      */   }
/*      */   
/*      */   public com.fasterxml.jackson.core.util.JacksonFeatureSet<com.fasterxml.jackson.core.StreamReadCapability> getReadCapabilities()
/*      */   {
/*  183 */     return JSON_READ_CAPABILITIES;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int releaseBuffered(OutputStream out)
/*      */     throws IOException
/*      */   {
/*  195 */     int count = this._inputEnd - this._inputPtr;
/*  196 */     if (count < 1) {
/*  197 */       return 0;
/*      */     }
/*      */     
/*  200 */     int origPtr = this._inputPtr;
/*  201 */     this._inputPtr += count;
/*  202 */     out.write(this._inputBuffer, origPtr, count);
/*  203 */     return count;
/*      */   }
/*      */   
/*      */   public Object getInputSource()
/*      */   {
/*  208 */     return this._inputStream;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean _loadMore()
/*      */     throws IOException
/*      */   {
/*  219 */     if (this._inputStream != null) {
/*  220 */       int space = this._inputBuffer.length;
/*  221 */       if (space == 0) {
/*  222 */         return false;
/*      */       }
/*      */       
/*  225 */       int count = this._inputStream.read(this._inputBuffer, 0, space);
/*  226 */       if (count > 0) {
/*  227 */         int bufSize = this._inputEnd;
/*      */         
/*  229 */         this._currInputProcessed += bufSize;
/*  230 */         this._currInputRowStart -= bufSize;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  235 */         this._nameStartOffset -= bufSize;
/*      */         
/*  237 */         this._inputPtr = 0;
/*  238 */         this._inputEnd = count;
/*      */         
/*  240 */         return true;
/*      */       }
/*      */       
/*  243 */       _closeInput();
/*      */       
/*  245 */       if (count == 0) {
/*  246 */         throw new IOException("InputStream.read() returned 0 characters when trying to read " + this._inputBuffer.length + " bytes");
/*      */       }
/*      */     }
/*  249 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void _closeInput()
/*      */     throws IOException
/*      */   {
/*  257 */     if (this._inputStream != null) {
/*  258 */       if ((this._ioContext.isResourceManaged()) || (isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE))) {
/*  259 */         this._inputStream.close();
/*      */       }
/*  261 */       this._inputStream = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _releaseBuffers()
/*      */     throws IOException
/*      */   {
/*  274 */     super._releaseBuffers();
/*      */     
/*  276 */     this._symbols.release();
/*  277 */     if (this._bufferRecyclable) {
/*  278 */       byte[] buf = this._inputBuffer;
/*  279 */       if (buf != null)
/*      */       {
/*      */ 
/*  282 */         if (buf != NO_BYTES) {
/*  283 */           this._inputBuffer = NO_BYTES;
/*  284 */           this._ioContext.releaseReadIOBuffer(buf);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getText()
/*      */     throws IOException
/*      */   {
/*  299 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  300 */       if (this._tokenIncomplete) {
/*  301 */         this._tokenIncomplete = false;
/*  302 */         return _finishAndReturnString();
/*      */       }
/*  304 */       return this._textBuffer.contentsAsString();
/*      */     }
/*  306 */     return _getText2(this._currToken);
/*      */   }
/*      */   
/*      */   public int getText(Writer writer)
/*      */     throws IOException
/*      */   {
/*  312 */     JsonToken t = this._currToken;
/*  313 */     if (t == JsonToken.VALUE_STRING) {
/*  314 */       if (this._tokenIncomplete) {
/*  315 */         this._tokenIncomplete = false;
/*  316 */         _finishString();
/*      */       }
/*  318 */       return this._textBuffer.contentsToWriter(writer);
/*      */     }
/*  320 */     if (t == JsonToken.FIELD_NAME) {
/*  321 */       String n = this._parsingContext.getCurrentName();
/*  322 */       writer.write(n);
/*  323 */       return n.length();
/*      */     }
/*  325 */     if (t != null) {
/*  326 */       if (t.isNumeric()) {
/*  327 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  329 */       char[] ch = t.asCharArray();
/*  330 */       writer.write(ch);
/*  331 */       return ch.length;
/*      */     }
/*  333 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getValueAsString()
/*      */     throws IOException
/*      */   {
/*  342 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  343 */       if (this._tokenIncomplete) {
/*  344 */         this._tokenIncomplete = false;
/*  345 */         return _finishAndReturnString();
/*      */       }
/*  347 */       return this._textBuffer.contentsAsString();
/*      */     }
/*  349 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  350 */       return getCurrentName();
/*      */     }
/*  352 */     return super.getValueAsString(null);
/*      */   }
/*      */   
/*      */ 
/*      */   public String getValueAsString(String defValue)
/*      */     throws IOException
/*      */   {
/*  359 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  360 */       if (this._tokenIncomplete) {
/*  361 */         this._tokenIncomplete = false;
/*  362 */         return _finishAndReturnString();
/*      */       }
/*  364 */       return this._textBuffer.contentsAsString();
/*      */     }
/*  366 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  367 */       return getCurrentName();
/*      */     }
/*  369 */     return super.getValueAsString(defValue);
/*      */   }
/*      */   
/*      */ 
/*      */   public int getValueAsInt()
/*      */     throws IOException
/*      */   {
/*  376 */     JsonToken t = this._currToken;
/*  377 */     if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT))
/*      */     {
/*  379 */       if ((this._numTypesValid & 0x1) == 0) {
/*  380 */         if (this._numTypesValid == 0) {
/*  381 */           return _parseIntValue();
/*      */         }
/*  383 */         if ((this._numTypesValid & 0x1) == 0) {
/*  384 */           convertNumberToInt();
/*      */         }
/*      */       }
/*  387 */       return this._numberInt;
/*      */     }
/*  389 */     return super.getValueAsInt(0);
/*      */   }
/*      */   
/*      */ 
/*      */   public int getValueAsInt(int defValue)
/*      */     throws IOException
/*      */   {
/*  396 */     JsonToken t = this._currToken;
/*  397 */     if ((t == JsonToken.VALUE_NUMBER_INT) || (t == JsonToken.VALUE_NUMBER_FLOAT))
/*      */     {
/*  399 */       if ((this._numTypesValid & 0x1) == 0) {
/*  400 */         if (this._numTypesValid == 0) {
/*  401 */           return _parseIntValue();
/*      */         }
/*  403 */         if ((this._numTypesValid & 0x1) == 0) {
/*  404 */           convertNumberToInt();
/*      */         }
/*      */       }
/*  407 */       return this._numberInt;
/*      */     }
/*  409 */     return super.getValueAsInt(defValue);
/*      */   }
/*      */   
/*      */   protected final String _getText2(JsonToken t)
/*      */   {
/*  414 */     if (t == null) {
/*  415 */       return null;
/*      */     }
/*  417 */     switch (t.id()) {
/*      */     case 5: 
/*  419 */       return this._parsingContext.getCurrentName();
/*      */     
/*      */ 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/*  425 */       return this._textBuffer.contentsAsString();
/*      */     }
/*  427 */     return t.asString();
/*      */   }
/*      */   
/*      */ 
/*      */   public char[] getTextCharacters()
/*      */     throws IOException
/*      */   {
/*  434 */     if (this._currToken != null) {
/*  435 */       switch (this._currToken.id())
/*      */       {
/*      */       case 5: 
/*  438 */         if (!this._nameCopied) {
/*  439 */           String name = this._parsingContext.getCurrentName();
/*  440 */           int nameLen = name.length();
/*  441 */           if (this._nameCopyBuffer == null) {
/*  442 */             this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  443 */           } else if (this._nameCopyBuffer.length < nameLen) {
/*  444 */             this._nameCopyBuffer = new char[nameLen];
/*      */           }
/*  446 */           name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  447 */           this._nameCopied = true;
/*      */         }
/*  449 */         return this._nameCopyBuffer;
/*      */       
/*      */       case 6: 
/*  452 */         if (this._tokenIncomplete) {
/*  453 */           this._tokenIncomplete = false;
/*  454 */           _finishString();
/*      */         }
/*      */       
/*      */       case 7: 
/*      */       case 8: 
/*  459 */         return this._textBuffer.getTextBuffer();
/*      */       }
/*      */       
/*  462 */       return this._currToken.asCharArray();
/*      */     }
/*      */     
/*  465 */     return null;
/*      */   }
/*      */   
/*      */   public int getTextLength()
/*      */     throws IOException
/*      */   {
/*  471 */     if (this._currToken != null) {
/*  472 */       switch (this._currToken.id())
/*      */       {
/*      */       case 5: 
/*  475 */         return this._parsingContext.getCurrentName().length();
/*      */       case 6: 
/*  477 */         if (this._tokenIncomplete) {
/*  478 */           this._tokenIncomplete = false;
/*  479 */           _finishString();
/*      */         }
/*      */       
/*      */       case 7: 
/*      */       case 8: 
/*  484 */         return this._textBuffer.size();
/*      */       }
/*      */       
/*  487 */       return this._currToken.asCharArray().length;
/*      */     }
/*      */     
/*  490 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getTextOffset()
/*      */     throws IOException
/*      */   {
/*  497 */     if (this._currToken != null) {
/*  498 */       switch (this._currToken.id()) {
/*      */       case 5: 
/*  500 */         return 0;
/*      */       case 6: 
/*  502 */         if (this._tokenIncomplete) {
/*  503 */           this._tokenIncomplete = false;
/*  504 */           _finishString();
/*      */         }
/*      */       
/*      */       case 7: 
/*      */       case 8: 
/*  509 */         return this._textBuffer.getTextOffset();
/*      */       }
/*      */       
/*      */     }
/*  513 */     return 0;
/*      */   }
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant)
/*      */     throws IOException
/*      */   {
/*  519 */     if ((this._currToken != JsonToken.VALUE_STRING) && ((this._currToken != JsonToken.VALUE_EMBEDDED_OBJECT) || (this._binaryValue == null)))
/*      */     {
/*  521 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */     
/*  524 */     if (this._tokenIncomplete) {
/*      */       try {
/*  526 */         this._binaryValue = _decodeBase64(b64variant);
/*      */       } catch (IllegalArgumentException iae) {
/*  528 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       }
/*      */       
/*  531 */       this._tokenIncomplete = false;
/*      */     }
/*  533 */     else if (this._binaryValue == null)
/*      */     {
/*  535 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  536 */       _decodeBase64(getText(), builder, b64variant);
/*  537 */       this._binaryValue = builder.toByteArray();
/*      */     }
/*      */     
/*  540 */     return this._binaryValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out)
/*      */     throws IOException
/*      */   {
/*  547 */     if ((!this._tokenIncomplete) || (this._currToken != JsonToken.VALUE_STRING)) {
/*  548 */       byte[] b = getBinaryValue(b64variant);
/*  549 */       out.write(b);
/*  550 */       return b.length;
/*      */     }
/*      */     
/*  553 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  555 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  557 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     }
/*      */   }
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer)
/*      */     throws IOException
/*      */   {
/*  564 */     int outputPtr = 0;
/*  565 */     int outputEnd = buffer.length - 3;
/*  566 */     int outputCount = 0;
/*      */     
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/*  572 */       if (this._inputPtr >= this._inputEnd) {
/*  573 */         _loadMoreGuaranteed();
/*      */       }
/*  575 */       int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*  576 */       if (ch > 32) {
/*  577 */         int bits = b64variant.decodeBase64Char(ch);
/*  578 */         if (bits < 0) {
/*  579 */           if (ch == 34) {
/*      */             break;
/*      */           }
/*  582 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  583 */           if (bits < 0) {}
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*  589 */           if (outputPtr > outputEnd) {
/*  590 */             outputCount += outputPtr;
/*  591 */             out.write(buffer, 0, outputPtr);
/*  592 */             outputPtr = 0;
/*      */           }
/*      */           
/*  595 */           int decodedData = bits;
/*      */           
/*      */ 
/*      */ 
/*  599 */           if (this._inputPtr >= this._inputEnd) {
/*  600 */             _loadMoreGuaranteed();
/*      */           }
/*  602 */           ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*  603 */           bits = b64variant.decodeBase64Char(ch);
/*  604 */           if (bits < 0) {
/*  605 */             bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */           }
/*  607 */           decodedData = decodedData << 6 | bits;
/*      */           
/*      */ 
/*  610 */           if (this._inputPtr >= this._inputEnd) {
/*  611 */             _loadMoreGuaranteed();
/*      */           }
/*  613 */           ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*  614 */           bits = b64variant.decodeBase64Char(ch);
/*      */           
/*      */ 
/*  617 */           if (bits < 0) {
/*  618 */             if (bits != -2)
/*      */             {
/*  620 */               if (ch == 34) {
/*  621 */                 decodedData >>= 4;
/*  622 */                 buffer[(outputPtr++)] = ((byte)decodedData);
/*  623 */                 if (!b64variant.usesPadding()) break;
/*  624 */                 this._inputPtr -= 1;
/*  625 */                 _handleBase64MissingPadding(b64variant); break;
/*      */               }
/*      */               
/*      */ 
/*  629 */               bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */             }
/*  631 */             if (bits == -2)
/*      */             {
/*  633 */               if (this._inputPtr >= this._inputEnd) {
/*  634 */                 _loadMoreGuaranteed();
/*      */               }
/*  636 */               ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*  637 */               if ((!b64variant.usesPaddingChar(ch)) && 
/*  638 */                 (_decodeBase64Escape(b64variant, ch, 3) != -2)) {
/*  639 */                 throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */               }
/*      */               
/*      */ 
/*  643 */               decodedData >>= 4;
/*  644 */               buffer[(outputPtr++)] = ((byte)decodedData);
/*  645 */               continue;
/*      */             }
/*      */           }
/*      */           
/*  649 */           decodedData = decodedData << 6 | bits;
/*      */           
/*  651 */           if (this._inputPtr >= this._inputEnd) {
/*  652 */             _loadMoreGuaranteed();
/*      */           }
/*  654 */           ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*  655 */           bits = b64variant.decodeBase64Char(ch);
/*  656 */           if (bits < 0) {
/*  657 */             if (bits != -2)
/*      */             {
/*  659 */               if (ch == 34) {
/*  660 */                 decodedData >>= 2;
/*  661 */                 buffer[(outputPtr++)] = ((byte)(decodedData >> 8));
/*  662 */                 buffer[(outputPtr++)] = ((byte)decodedData);
/*  663 */                 if (!b64variant.usesPadding()) break;
/*  664 */                 this._inputPtr -= 1;
/*  665 */                 _handleBase64MissingPadding(b64variant); break;
/*      */               }
/*      */               
/*      */ 
/*  669 */               bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */             }
/*  671 */             if (bits == -2)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  678 */               decodedData >>= 2;
/*  679 */               buffer[(outputPtr++)] = ((byte)(decodedData >> 8));
/*  680 */               buffer[(outputPtr++)] = ((byte)decodedData);
/*  681 */               continue;
/*      */             }
/*      */           }
/*      */           
/*  685 */           decodedData = decodedData << 6 | bits;
/*  686 */           buffer[(outputPtr++)] = ((byte)(decodedData >> 16));
/*  687 */           buffer[(outputPtr++)] = ((byte)(decodedData >> 8));
/*  688 */           buffer[(outputPtr++)] = ((byte)decodedData);
/*      */         } } }
/*  690 */     this._tokenIncomplete = false;
/*  691 */     if (outputPtr > 0) {
/*  692 */       outputCount += outputPtr;
/*  693 */       out.write(buffer, 0, outputPtr);
/*      */     }
/*  695 */     return outputCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonToken nextToken()
/*      */     throws IOException
/*      */   {
/*  715 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  716 */       return _nextAfterName();
/*      */     }
/*      */     
/*      */ 
/*  720 */     this._numTypesValid = 0;
/*  721 */     if (this._tokenIncomplete) {
/*  722 */       _skipString();
/*      */     }
/*  724 */     int i = _skipWSOrEnd();
/*  725 */     if (i < 0)
/*      */     {
/*  727 */       close();
/*  728 */       return this._currToken = null;
/*      */     }
/*      */     
/*  731 */     this._binaryValue = null;
/*      */     
/*      */ 
/*  734 */     if (i == 93) {
/*  735 */       _closeArrayScope();
/*  736 */       return this._currToken = JsonToken.END_ARRAY;
/*      */     }
/*  738 */     if (i == 125) {
/*  739 */       _closeObjectScope();
/*  740 */       return this._currToken = JsonToken.END_OBJECT;
/*      */     }
/*      */     
/*      */ 
/*  744 */     if (this._parsingContext.expectComma()) {
/*  745 */       if (i != 44) {
/*  746 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  748 */       i = _skipWS();
/*      */       
/*  750 */       if (((this._features & FEAT_MASK_TRAILING_COMMA) != 0) && (
/*  751 */         (i == 93) || (i == 125))) {
/*  752 */         return _closeScope(i);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  760 */     if (!this._parsingContext.inObject()) {
/*  761 */       _updateLocation();
/*  762 */       return _nextTokenNotInObject(i);
/*      */     }
/*      */     
/*  765 */     _updateNameLocation();
/*  766 */     String n = _parseName(i);
/*  767 */     this._parsingContext.setCurrentName(n);
/*  768 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/*  770 */     i = _skipColon();
/*  771 */     _updateLocation();
/*      */     
/*      */ 
/*  774 */     if (i == 34) {
/*  775 */       this._tokenIncomplete = true;
/*  776 */       this._nextToken = JsonToken.VALUE_STRING;
/*  777 */       return this._currToken; }
/*      */     JsonToken t;
/*      */     JsonToken t;
/*      */     JsonToken t;
/*  781 */     JsonToken t; JsonToken t; JsonToken t; JsonToken t; JsonToken t; JsonToken t; switch (i) {
/*      */     case 45: 
/*  783 */       t = _parseNegNumber();
/*  784 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 46: 
/*  789 */       t = _parseFloatThatStartsWithPeriod();
/*  790 */       break;
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*  801 */       t = _parsePosNumber(i);
/*  802 */       break;
/*      */     case 102: 
/*  804 */       _matchFalse();
/*  805 */       t = JsonToken.VALUE_FALSE;
/*  806 */       break;
/*      */     case 110: 
/*  808 */       _matchNull();
/*  809 */       t = JsonToken.VALUE_NULL;
/*  810 */       break;
/*      */     case 116: 
/*  812 */       _matchTrue();
/*  813 */       t = JsonToken.VALUE_TRUE;
/*  814 */       break;
/*      */     case 91: 
/*  816 */       t = JsonToken.START_ARRAY;
/*  817 */       break;
/*      */     case 123: 
/*  819 */       t = JsonToken.START_OBJECT;
/*  820 */       break;
/*      */     
/*      */     default: 
/*  823 */       t = _handleUnexpectedValue(i);
/*      */     }
/*  825 */     this._nextToken = t;
/*  826 */     return this._currToken;
/*      */   }
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException
/*      */   {
/*  831 */     if (i == 34) {
/*  832 */       this._tokenIncomplete = true;
/*  833 */       return this._currToken = JsonToken.VALUE_STRING;
/*      */     }
/*  835 */     switch (i) {
/*      */     case 91: 
/*  837 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  838 */       return this._currToken = JsonToken.START_ARRAY;
/*      */     case 123: 
/*  840 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*  841 */       return this._currToken = JsonToken.START_OBJECT;
/*      */     case 116: 
/*  843 */       _matchTrue();
/*  844 */       return this._currToken = JsonToken.VALUE_TRUE;
/*      */     case 102: 
/*  846 */       _matchFalse();
/*  847 */       return this._currToken = JsonToken.VALUE_FALSE;
/*      */     case 110: 
/*  849 */       _matchNull();
/*  850 */       return this._currToken = JsonToken.VALUE_NULL;
/*      */     case 45: 
/*  852 */       return this._currToken = _parseNegNumber();
/*      */     
/*      */ 
/*      */ 
/*      */     case 46: 
/*  857 */       return this._currToken = _parseFloatThatStartsWithPeriod();
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*  868 */       return this._currToken = _parsePosNumber(i);
/*      */     }
/*  870 */     return this._currToken = _handleUnexpectedValue(i);
/*      */   }
/*      */   
/*      */   private final JsonToken _nextAfterName()
/*      */   {
/*  875 */     this._nameCopied = false;
/*  876 */     JsonToken t = this._nextToken;
/*  877 */     this._nextToken = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  882 */     if (t == JsonToken.START_ARRAY) {
/*  883 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  884 */     } else if (t == JsonToken.START_OBJECT) {
/*  885 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     }
/*  887 */     return this._currToken = t;
/*      */   }
/*      */   
/*      */   public void finishToken() throws IOException
/*      */   {
/*  892 */     if (this._tokenIncomplete) {
/*  893 */       this._tokenIncomplete = false;
/*  894 */       _finishString();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nextFieldName(SerializableString str)
/*      */     throws IOException
/*      */   {
/*  908 */     this._numTypesValid = 0;
/*  909 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  910 */       _nextAfterName();
/*  911 */       return false;
/*      */     }
/*  913 */     if (this._tokenIncomplete) {
/*  914 */       _skipString();
/*      */     }
/*  916 */     int i = _skipWSOrEnd();
/*  917 */     if (i < 0) {
/*  918 */       close();
/*  919 */       this._currToken = null;
/*  920 */       return false;
/*      */     }
/*  922 */     this._binaryValue = null;
/*      */     
/*      */ 
/*  925 */     if (i == 93) {
/*  926 */       _closeArrayScope();
/*  927 */       this._currToken = JsonToken.END_ARRAY;
/*  928 */       return false;
/*      */     }
/*  930 */     if (i == 125) {
/*  931 */       _closeObjectScope();
/*  932 */       this._currToken = JsonToken.END_OBJECT;
/*  933 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  937 */     if (this._parsingContext.expectComma()) {
/*  938 */       if (i != 44) {
/*  939 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  941 */       i = _skipWS();
/*      */       
/*      */ 
/*  944 */       if (((this._features & FEAT_MASK_TRAILING_COMMA) != 0) && (
/*  945 */         (i == 93) || (i == 125))) {
/*  946 */         _closeScope(i);
/*  947 */         return false;
/*      */       }
/*      */     }
/*      */     
/*  951 */     if (!this._parsingContext.inObject()) {
/*  952 */       _updateLocation();
/*  953 */       _nextTokenNotInObject(i);
/*  954 */       return false;
/*      */     }
/*      */     
/*      */ 
/*  958 */     _updateNameLocation();
/*  959 */     if (i == 34)
/*      */     {
/*  961 */       byte[] nameBytes = str.asQuotedUTF8();
/*  962 */       int len = nameBytes.length;
/*      */       
/*      */ 
/*  965 */       if (this._inputPtr + len + 4 < this._inputEnd)
/*      */       {
/*  967 */         int end = this._inputPtr + len;
/*  968 */         if (this._inputBuffer[end] == 34) {
/*  969 */           int offset = 0;
/*  970 */           int ptr = this._inputPtr;
/*      */           for (;;) {
/*  972 */             if (ptr == end) {
/*  973 */               this._parsingContext.setCurrentName(str.getValue());
/*  974 */               i = _skipColonFast(ptr + 1);
/*  975 */               _isNextTokenNameYes(i);
/*  976 */               return true;
/*      */             }
/*  978 */             if (nameBytes[offset] != this._inputBuffer[ptr]) {
/*      */               break;
/*      */             }
/*  981 */             offset++;
/*  982 */             ptr++;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  987 */     return _isNextTokenNameMaybe(i, str);
/*      */   }
/*      */   
/*      */ 
/*      */   public String nextFieldName()
/*      */     throws IOException
/*      */   {
/*  994 */     this._numTypesValid = 0;
/*  995 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  996 */       _nextAfterName();
/*  997 */       return null;
/*      */     }
/*  999 */     if (this._tokenIncomplete) {
/* 1000 */       _skipString();
/*      */     }
/* 1002 */     int i = _skipWSOrEnd();
/* 1003 */     if (i < 0) {
/* 1004 */       close();
/* 1005 */       this._currToken = null;
/* 1006 */       return null;
/*      */     }
/* 1008 */     this._binaryValue = null;
/*      */     
/* 1010 */     if (i == 93) {
/* 1011 */       _closeArrayScope();
/* 1012 */       this._currToken = JsonToken.END_ARRAY;
/* 1013 */       return null;
/*      */     }
/* 1015 */     if (i == 125) {
/* 1016 */       _closeObjectScope();
/* 1017 */       this._currToken = JsonToken.END_OBJECT;
/* 1018 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1022 */     if (this._parsingContext.expectComma()) {
/* 1023 */       if (i != 44) {
/* 1024 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/* 1026 */       i = _skipWS();
/*      */       
/* 1028 */       if (((this._features & FEAT_MASK_TRAILING_COMMA) != 0) && (
/* 1029 */         (i == 93) || (i == 125))) {
/* 1030 */         _closeScope(i);
/* 1031 */         return null;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1036 */     if (!this._parsingContext.inObject()) {
/* 1037 */       _updateLocation();
/* 1038 */       _nextTokenNotInObject(i);
/* 1039 */       return null;
/*      */     }
/*      */     
/* 1042 */     _updateNameLocation();
/* 1043 */     String nameStr = _parseName(i);
/* 1044 */     this._parsingContext.setCurrentName(nameStr);
/* 1045 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/* 1047 */     i = _skipColon();
/* 1048 */     _updateLocation();
/* 1049 */     if (i == 34) {
/* 1050 */       this._tokenIncomplete = true;
/* 1051 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1052 */       return nameStr; }
/*      */     JsonToken t;
/*      */     JsonToken t;
/* 1055 */     JsonToken t; JsonToken t; JsonToken t; JsonToken t; JsonToken t; JsonToken t; JsonToken t; switch (i) {
/*      */     case 45: 
/* 1057 */       t = _parseNegNumber();
/* 1058 */       break;
/*      */     case 46: 
/* 1060 */       t = _parseFloatThatStartsWithPeriod();
/* 1061 */       break;
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/* 1072 */       t = _parsePosNumber(i);
/* 1073 */       break;
/*      */     case 102: 
/* 1075 */       _matchFalse();
/* 1076 */       t = JsonToken.VALUE_FALSE;
/* 1077 */       break;
/*      */     case 110: 
/* 1079 */       _matchNull();
/* 1080 */       t = JsonToken.VALUE_NULL;
/* 1081 */       break;
/*      */     case 116: 
/* 1083 */       _matchTrue();
/* 1084 */       t = JsonToken.VALUE_TRUE;
/* 1085 */       break;
/*      */     case 91: 
/* 1087 */       t = JsonToken.START_ARRAY;
/* 1088 */       break;
/*      */     case 123: 
/* 1090 */       t = JsonToken.START_OBJECT;
/* 1091 */       break;
/*      */     
/*      */     default: 
/* 1094 */       t = _handleUnexpectedValue(i);
/*      */     }
/* 1096 */     this._nextToken = t;
/* 1097 */     return nameStr;
/*      */   }
/*      */   
/*      */   private final int _skipColonFast(int ptr)
/*      */     throws IOException
/*      */   {
/* 1103 */     int i = this._inputBuffer[(ptr++)];
/* 1104 */     if (i == 58) {
/* 1105 */       i = this._inputBuffer[(ptr++)];
/* 1106 */       if (i > 32) {
/* 1107 */         if ((i != 47) && (i != 35)) {
/* 1108 */           this._inputPtr = ptr;
/* 1109 */           return i;
/*      */         }
/* 1111 */       } else if ((i == 32) || (i == 9)) {
/* 1112 */         i = this._inputBuffer[(ptr++)];
/* 1113 */         if ((i > 32) && 
/* 1114 */           (i != 47) && (i != 35)) {
/* 1115 */           this._inputPtr = ptr;
/* 1116 */           return i;
/*      */         }
/*      */       }
/*      */       
/* 1120 */       this._inputPtr = (ptr - 1);
/* 1121 */       return _skipColon2(true);
/*      */     }
/* 1123 */     if ((i == 32) || (i == 9)) {
/* 1124 */       i = this._inputBuffer[(ptr++)];
/*      */     }
/* 1126 */     if (i == 58) {
/* 1127 */       i = this._inputBuffer[(ptr++)];
/* 1128 */       if (i > 32) {
/* 1129 */         if ((i != 47) && (i != 35)) {
/* 1130 */           this._inputPtr = ptr;
/* 1131 */           return i;
/*      */         }
/* 1133 */       } else if ((i == 32) || (i == 9)) {
/* 1134 */         i = this._inputBuffer[(ptr++)];
/* 1135 */         if ((i > 32) && 
/* 1136 */           (i != 47) && (i != 35)) {
/* 1137 */           this._inputPtr = ptr;
/* 1138 */           return i;
/*      */         }
/*      */       }
/*      */       
/* 1142 */       this._inputPtr = (ptr - 1);
/* 1143 */       return _skipColon2(true);
/*      */     }
/* 1145 */     this._inputPtr = (ptr - 1);
/* 1146 */     return _skipColon2(false);
/*      */   }
/*      */   
/*      */   private final void _isNextTokenNameYes(int i) throws IOException
/*      */   {
/* 1151 */     this._currToken = JsonToken.FIELD_NAME;
/* 1152 */     _updateLocation();
/*      */     
/* 1154 */     switch (i) {
/*      */     case 34: 
/* 1156 */       this._tokenIncomplete = true;
/* 1157 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1158 */       return;
/*      */     case 91: 
/* 1160 */       this._nextToken = JsonToken.START_ARRAY;
/* 1161 */       return;
/*      */     case 123: 
/* 1163 */       this._nextToken = JsonToken.START_OBJECT;
/* 1164 */       return;
/*      */     case 116: 
/* 1166 */       _matchTrue();
/* 1167 */       this._nextToken = JsonToken.VALUE_TRUE;
/* 1168 */       return;
/*      */     case 102: 
/* 1170 */       _matchFalse();
/* 1171 */       this._nextToken = JsonToken.VALUE_FALSE;
/* 1172 */       return;
/*      */     case 110: 
/* 1174 */       _matchNull();
/* 1175 */       this._nextToken = JsonToken.VALUE_NULL;
/* 1176 */       return;
/*      */     case 45: 
/* 1178 */       this._nextToken = _parseNegNumber();
/* 1179 */       return;
/*      */     case 46: 
/* 1181 */       this._nextToken = _parseFloatThatStartsWithPeriod();
/* 1182 */       return;
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/* 1193 */       this._nextToken = _parsePosNumber(i);
/* 1194 */       return;
/*      */     }
/* 1196 */     this._nextToken = _handleUnexpectedValue(i);
/*      */   }
/*      */   
/*      */ 
/*      */   private final boolean _isNextTokenNameMaybe(int i, SerializableString str)
/*      */     throws IOException
/*      */   {
/* 1203 */     String n = _parseName(i);
/* 1204 */     this._parsingContext.setCurrentName(n);
/* 1205 */     boolean match = n.equals(str.getValue());
/* 1206 */     this._currToken = JsonToken.FIELD_NAME;
/* 1207 */     i = _skipColon();
/* 1208 */     _updateLocation();
/*      */     
/*      */ 
/* 1211 */     if (i == 34) {
/* 1212 */       this._tokenIncomplete = true;
/* 1213 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1214 */       return match; }
/*      */     JsonToken t;
/*      */     JsonToken t;
/*      */     JsonToken t;
/* 1218 */     JsonToken t; JsonToken t; JsonToken t; JsonToken t; JsonToken t; JsonToken t; switch (i) {
/*      */     case 91: 
/* 1220 */       t = JsonToken.START_ARRAY;
/* 1221 */       break;
/*      */     case 123: 
/* 1223 */       t = JsonToken.START_OBJECT;
/* 1224 */       break;
/*      */     case 116: 
/* 1226 */       _matchTrue();
/* 1227 */       t = JsonToken.VALUE_TRUE;
/* 1228 */       break;
/*      */     case 102: 
/* 1230 */       _matchFalse();
/* 1231 */       t = JsonToken.VALUE_FALSE;
/* 1232 */       break;
/*      */     case 110: 
/* 1234 */       _matchNull();
/* 1235 */       t = JsonToken.VALUE_NULL;
/* 1236 */       break;
/*      */     case 45: 
/* 1238 */       t = _parseNegNumber();
/* 1239 */       break;
/*      */     case 46: 
/* 1241 */       t = _parseFloatThatStartsWithPeriod();
/* 1242 */       break;
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/* 1253 */       t = _parsePosNumber(i);
/* 1254 */       break;
/*      */     default: 
/* 1256 */       t = _handleUnexpectedValue(i);
/*      */     }
/* 1258 */     this._nextToken = t;
/* 1259 */     return match;
/*      */   }
/*      */   
/*      */ 
/*      */   public String nextTextValue()
/*      */     throws IOException
/*      */   {
/* 1266 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1267 */       this._nameCopied = false;
/* 1268 */       JsonToken t = this._nextToken;
/* 1269 */       this._nextToken = null;
/* 1270 */       this._currToken = t;
/* 1271 */       if (t == JsonToken.VALUE_STRING) {
/* 1272 */         if (this._tokenIncomplete) {
/* 1273 */           this._tokenIncomplete = false;
/* 1274 */           return _finishAndReturnString();
/*      */         }
/* 1276 */         return this._textBuffer.contentsAsString();
/*      */       }
/* 1278 */       if (t == JsonToken.START_ARRAY) {
/* 1279 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1280 */       } else if (t == JsonToken.START_OBJECT) {
/* 1281 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/* 1283 */       return null;
/*      */     }
/*      */     
/* 1286 */     return nextToken() == JsonToken.VALUE_STRING ? getText() : null;
/*      */   }
/*      */   
/*      */ 
/*      */   public int nextIntValue(int defaultValue)
/*      */     throws IOException
/*      */   {
/* 1293 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1294 */       this._nameCopied = false;
/* 1295 */       JsonToken t = this._nextToken;
/* 1296 */       this._nextToken = null;
/* 1297 */       this._currToken = t;
/* 1298 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1299 */         return getIntValue();
/*      */       }
/* 1301 */       if (t == JsonToken.START_ARRAY) {
/* 1302 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1303 */       } else if (t == JsonToken.START_OBJECT) {
/* 1304 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/* 1306 */       return defaultValue;
/*      */     }
/*      */     
/* 1309 */     return nextToken() == JsonToken.VALUE_NUMBER_INT ? getIntValue() : defaultValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public long nextLongValue(long defaultValue)
/*      */     throws IOException
/*      */   {
/* 1316 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1317 */       this._nameCopied = false;
/* 1318 */       JsonToken t = this._nextToken;
/* 1319 */       this._nextToken = null;
/* 1320 */       this._currToken = t;
/* 1321 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1322 */         return getLongValue();
/*      */       }
/* 1324 */       if (t == JsonToken.START_ARRAY) {
/* 1325 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1326 */       } else if (t == JsonToken.START_OBJECT) {
/* 1327 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/* 1329 */       return defaultValue;
/*      */     }
/*      */     
/* 1332 */     return nextToken() == JsonToken.VALUE_NUMBER_INT ? getLongValue() : defaultValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public Boolean nextBooleanValue()
/*      */     throws IOException
/*      */   {
/* 1339 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1340 */       this._nameCopied = false;
/* 1341 */       JsonToken t = this._nextToken;
/* 1342 */       this._nextToken = null;
/* 1343 */       this._currToken = t;
/* 1344 */       if (t == JsonToken.VALUE_TRUE) {
/* 1345 */         return Boolean.TRUE;
/*      */       }
/* 1347 */       if (t == JsonToken.VALUE_FALSE) {
/* 1348 */         return Boolean.FALSE;
/*      */       }
/* 1350 */       if (t == JsonToken.START_ARRAY) {
/* 1351 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1352 */       } else if (t == JsonToken.START_OBJECT) {
/* 1353 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/* 1355 */       return null;
/*      */     }
/*      */     
/* 1358 */     JsonToken t = nextToken();
/* 1359 */     if (t == JsonToken.VALUE_TRUE) {
/* 1360 */       return Boolean.TRUE;
/*      */     }
/* 1362 */     if (t == JsonToken.VALUE_FALSE) {
/* 1363 */       return Boolean.FALSE;
/*      */     }
/* 1365 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod()
/*      */     throws IOException
/*      */   {
/* 1378 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1379 */       return _handleUnexpectedValue(46);
/*      */     }
/* 1381 */     return _parseFloat(this._textBuffer.emptyAndGetCurrentSegment(), 0, 46, false, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonToken _parsePosNumber(int c)
/*      */     throws IOException
/*      */   {
/* 1402 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */     
/* 1404 */     if (c == 48) {
/* 1405 */       c = _verifyNoLeadingZeroes();
/*      */     }
/*      */     
/* 1408 */     outBuf[0] = ((char)c);
/* 1409 */     int intLen = 1;
/* 1410 */     int outPtr = 1;
/*      */     
/*      */ 
/* 1413 */     int end = Math.min(this._inputEnd, this._inputPtr + outBuf.length - 1);
/*      */     for (;;)
/*      */     {
/* 1416 */       if (this._inputPtr >= end) {
/* 1417 */         return _parseNumber2(outBuf, outPtr, false, intLen);
/*      */       }
/* 1419 */       c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1420 */       if ((c < 48) || (c > 57)) {
/*      */         break;
/*      */       }
/* 1423 */       intLen++;
/* 1424 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 1426 */     if ((c == 46) || (c == 101) || (c == 69)) {
/* 1427 */       return _parseFloat(outBuf, outPtr, c, false, intLen);
/*      */     }
/* 1429 */     this._inputPtr -= 1;
/* 1430 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1432 */     if (this._parsingContext.inRoot()) {
/* 1433 */       _verifyRootSpace(c);
/*      */     }
/*      */     
/* 1436 */     return resetInt(false, intLen);
/*      */   }
/*      */   
/*      */   protected JsonToken _parseNegNumber() throws IOException
/*      */   {
/* 1441 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1442 */     int outPtr = 0;
/*      */     
/*      */ 
/* 1445 */     outBuf[(outPtr++)] = '-';
/*      */     
/* 1447 */     if (this._inputPtr >= this._inputEnd) {
/* 1448 */       _loadMoreGuaranteed();
/*      */     }
/* 1450 */     int c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */     
/* 1452 */     if (c <= 48)
/*      */     {
/* 1454 */       if (c != 48) {
/* 1455 */         return _handleInvalidNumberStart(c, true);
/*      */       }
/* 1457 */       c = _verifyNoLeadingZeroes();
/* 1458 */     } else if (c > 57) {
/* 1459 */       return _handleInvalidNumberStart(c, true);
/*      */     }
/*      */     
/*      */ 
/* 1463 */     outBuf[(outPtr++)] = ((char)c);
/* 1464 */     int intLen = 1;
/*      */     
/*      */ 
/*      */ 
/* 1468 */     int end = Math.min(this._inputEnd, this._inputPtr + outBuf.length - outPtr);
/*      */     for (;;)
/*      */     {
/* 1471 */       if (this._inputPtr >= end)
/*      */       {
/* 1473 */         return _parseNumber2(outBuf, outPtr, true, intLen);
/*      */       }
/* 1475 */       c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1476 */       if ((c < 48) || (c > 57)) {
/*      */         break;
/*      */       }
/* 1479 */       intLen++;
/* 1480 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 1482 */     if ((c == 46) || (c == 101) || (c == 69)) {
/* 1483 */       return _parseFloat(outBuf, outPtr, c, true, intLen);
/*      */     }
/*      */     
/* 1486 */     this._inputPtr -= 1;
/* 1487 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1489 */     if (this._parsingContext.inRoot()) {
/* 1490 */       _verifyRootSpace(c);
/*      */     }
/*      */     
/*      */ 
/* 1494 */     return resetInt(true, intLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final JsonToken _parseNumber2(char[] outBuf, int outPtr, boolean negative, int intPartLength)
/*      */     throws IOException
/*      */   {
/*      */     for (;;)
/*      */     {
/* 1506 */       if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/* 1507 */         this._textBuffer.setCurrentLength(outPtr);
/* 1508 */         return resetInt(negative, intPartLength);
/*      */       }
/* 1510 */       int c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1511 */       if ((c > 57) || (c < 48)) {
/* 1512 */         if ((c != 46) && (c != 101) && (c != 69)) break;
/* 1513 */         return _parseFloat(outBuf, outPtr, c, negative, intPartLength);
/*      */       }
/*      */       
/*      */ 
/* 1517 */       if (outPtr >= outBuf.length) {
/* 1518 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1519 */         outPtr = 0;
/*      */       }
/* 1521 */       outBuf[(outPtr++)] = ((char)c);
/* 1522 */       intPartLength++;
/*      */     }
/* 1524 */     this._inputPtr -= 1;
/* 1525 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1527 */     if (this._parsingContext.inRoot()) {
/* 1528 */       _verifyRootSpace(this._inputBuffer[this._inputPtr] & 0xFF);
/*      */     }
/*      */     
/*      */ 
/* 1532 */     return resetInt(negative, intPartLength);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int _verifyNoLeadingZeroes()
/*      */     throws IOException
/*      */   {
/* 1543 */     if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/* 1544 */       return 48;
/*      */     }
/* 1546 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/*      */     
/* 1548 */     if ((ch < 48) || (ch > 57)) {
/* 1549 */       return 48;
/*      */     }
/*      */     
/* 1552 */     if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1553 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1556 */     this._inputPtr += 1;
/* 1557 */     if (ch == 48) {
/* 1558 */       while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 1559 */         ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 1560 */         if ((ch < 48) || (ch > 57)) {
/* 1561 */           return 48;
/*      */         }
/* 1563 */         this._inputPtr += 1;
/* 1564 */         if (ch != 48) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1569 */     return ch;
/*      */   }
/*      */   
/*      */   private final JsonToken _parseFloat(char[] outBuf, int outPtr, int c, boolean negative, int integerPartLength)
/*      */     throws IOException
/*      */   {
/* 1575 */     int fractLen = 0;
/* 1576 */     boolean eof = false;
/*      */     
/*      */ 
/* 1579 */     if (c == 46) {
/* 1580 */       if (outPtr >= outBuf.length) {
/* 1581 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1582 */         outPtr = 0;
/*      */       }
/* 1584 */       outBuf[(outPtr++)] = ((char)c);
/*      */       
/*      */       for (;;)
/*      */       {
/* 1588 */         if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/* 1589 */           eof = true;
/* 1590 */           break;
/*      */         }
/* 1592 */         c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1593 */         if ((c < 48) || (c > 57)) {
/*      */           break;
/*      */         }
/* 1596 */         fractLen++;
/* 1597 */         if (outPtr >= outBuf.length) {
/* 1598 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1599 */           outPtr = 0;
/*      */         }
/* 1601 */         outBuf[(outPtr++)] = ((char)c);
/*      */       }
/*      */       
/* 1604 */       if (fractLen == 0) {
/* 1605 */         reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     }
/*      */     
/* 1609 */     int expLen = 0;
/* 1610 */     if ((c == 101) || (c == 69)) {
/* 1611 */       if (outPtr >= outBuf.length) {
/* 1612 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1613 */         outPtr = 0;
/*      */       }
/* 1615 */       outBuf[(outPtr++)] = ((char)c);
/*      */       
/* 1617 */       if (this._inputPtr >= this._inputEnd) {
/* 1618 */         _loadMoreGuaranteed();
/*      */       }
/* 1620 */       c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */       
/* 1622 */       if ((c == 45) || (c == 43)) {
/* 1623 */         if (outPtr >= outBuf.length) {
/* 1624 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1625 */           outPtr = 0;
/*      */         }
/* 1627 */         outBuf[(outPtr++)] = ((char)c);
/*      */         
/* 1629 */         if (this._inputPtr >= this._inputEnd) {
/* 1630 */           _loadMoreGuaranteed();
/*      */         }
/* 1632 */         c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */       }
/*      */       
/*      */ 
/* 1636 */       while ((c >= 48) && (c <= 57)) {
/* 1637 */         expLen++;
/* 1638 */         if (outPtr >= outBuf.length) {
/* 1639 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1640 */           outPtr = 0;
/*      */         }
/* 1642 */         outBuf[(outPtr++)] = ((char)c);
/* 1643 */         if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/* 1644 */           eof = true;
/* 1645 */           break;
/*      */         }
/* 1647 */         c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */       }
/*      */       
/* 1650 */       if (expLen == 0) {
/* 1651 */         reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1656 */     if (!eof) {
/* 1657 */       this._inputPtr -= 1;
/*      */       
/* 1659 */       if (this._parsingContext.inRoot()) {
/* 1660 */         _verifyRootSpace(c);
/*      */       }
/*      */     }
/* 1663 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/*      */ 
/* 1666 */     return resetFloat(negative, integerPartLength, fractLen, expLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _verifyRootSpace(int ch)
/*      */     throws IOException
/*      */   {
/* 1679 */     this._inputPtr += 1;
/*      */     
/* 1681 */     switch (ch) {
/*      */     case 9: 
/*      */     case 32: 
/* 1684 */       return;
/*      */     case 13: 
/* 1686 */       _skipCR();
/* 1687 */       return;
/*      */     case 10: 
/* 1689 */       this._currInputRow += 1;
/* 1690 */       this._currInputRowStart = this._inputPtr;
/* 1691 */       return;
/*      */     }
/* 1693 */     _reportMissingRootWS(ch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final String _parseName(int i)
/*      */     throws IOException
/*      */   {
/* 1704 */     if (i != 34) {
/* 1705 */       return _handleOddName(i);
/*      */     }
/*      */     
/* 1708 */     if (this._inputPtr + 13 > this._inputEnd) {
/* 1709 */       return slowParseName();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1718 */     byte[] input = this._inputBuffer;
/* 1719 */     int[] codes = _icLatin1;
/*      */     
/* 1721 */     int q = input[(this._inputPtr++)] & 0xFF;
/*      */     
/* 1723 */     if (codes[q] == 0) {
/* 1724 */       i = input[(this._inputPtr++)] & 0xFF;
/* 1725 */       if (codes[i] == 0) {
/* 1726 */         q = q << 8 | i;
/* 1727 */         i = input[(this._inputPtr++)] & 0xFF;
/* 1728 */         if (codes[i] == 0) {
/* 1729 */           q = q << 8 | i;
/* 1730 */           i = input[(this._inputPtr++)] & 0xFF;
/* 1731 */           if (codes[i] == 0) {
/* 1732 */             q = q << 8 | i;
/* 1733 */             i = input[(this._inputPtr++)] & 0xFF;
/* 1734 */             if (codes[i] == 0) {
/* 1735 */               this._quad1 = q;
/* 1736 */               return parseMediumName(i);
/*      */             }
/* 1738 */             if (i == 34) {
/* 1739 */               return findName(q, 4);
/*      */             }
/* 1741 */             return parseName(q, i, 4);
/*      */           }
/* 1743 */           if (i == 34) {
/* 1744 */             return findName(q, 3);
/*      */           }
/* 1746 */           return parseName(q, i, 3);
/*      */         }
/* 1748 */         if (i == 34) {
/* 1749 */           return findName(q, 2);
/*      */         }
/* 1751 */         return parseName(q, i, 2);
/*      */       }
/* 1753 */       if (i == 34) {
/* 1754 */         return findName(q, 1);
/*      */       }
/* 1756 */       return parseName(q, i, 1);
/*      */     }
/* 1758 */     if (q == 34) {
/* 1759 */       return "";
/*      */     }
/* 1761 */     return parseName(0, q, 0);
/*      */   }
/*      */   
/*      */   protected final String parseMediumName(int q2) throws IOException
/*      */   {
/* 1766 */     byte[] input = this._inputBuffer;
/* 1767 */     int[] codes = _icLatin1;
/*      */     
/*      */ 
/* 1770 */     int i = input[(this._inputPtr++)] & 0xFF;
/* 1771 */     if (codes[i] != 0) {
/* 1772 */       if (i == 34) {
/* 1773 */         return findName(this._quad1, q2, 1);
/*      */       }
/* 1775 */       return parseName(this._quad1, q2, i, 1);
/*      */     }
/* 1777 */     q2 = q2 << 8 | i;
/* 1778 */     i = input[(this._inputPtr++)] & 0xFF;
/* 1779 */     if (codes[i] != 0) {
/* 1780 */       if (i == 34) {
/* 1781 */         return findName(this._quad1, q2, 2);
/*      */       }
/* 1783 */       return parseName(this._quad1, q2, i, 2);
/*      */     }
/* 1785 */     q2 = q2 << 8 | i;
/* 1786 */     i = input[(this._inputPtr++)] & 0xFF;
/* 1787 */     if (codes[i] != 0) {
/* 1788 */       if (i == 34) {
/* 1789 */         return findName(this._quad1, q2, 3);
/*      */       }
/* 1791 */       return parseName(this._quad1, q2, i, 3);
/*      */     }
/* 1793 */     q2 = q2 << 8 | i;
/* 1794 */     i = input[(this._inputPtr++)] & 0xFF;
/* 1795 */     if (codes[i] != 0) {
/* 1796 */       if (i == 34) {
/* 1797 */         return findName(this._quad1, q2, 4);
/*      */       }
/* 1799 */       return parseName(this._quad1, q2, i, 4);
/*      */     }
/* 1801 */     return parseMediumName2(i, q2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final String parseMediumName2(int q3, int q2)
/*      */     throws IOException
/*      */   {
/* 1809 */     byte[] input = this._inputBuffer;
/* 1810 */     int[] codes = _icLatin1;
/*      */     
/*      */ 
/* 1813 */     int i = input[(this._inputPtr++)] & 0xFF;
/* 1814 */     if (codes[i] != 0) {
/* 1815 */       if (i == 34) {
/* 1816 */         return findName(this._quad1, q2, q3, 1);
/*      */       }
/* 1818 */       return parseName(this._quad1, q2, q3, i, 1);
/*      */     }
/* 1820 */     q3 = q3 << 8 | i;
/* 1821 */     i = input[(this._inputPtr++)] & 0xFF;
/* 1822 */     if (codes[i] != 0) {
/* 1823 */       if (i == 34) {
/* 1824 */         return findName(this._quad1, q2, q3, 2);
/*      */       }
/* 1826 */       return parseName(this._quad1, q2, q3, i, 2);
/*      */     }
/* 1828 */     q3 = q3 << 8 | i;
/* 1829 */     i = input[(this._inputPtr++)] & 0xFF;
/* 1830 */     if (codes[i] != 0) {
/* 1831 */       if (i == 34) {
/* 1832 */         return findName(this._quad1, q2, q3, 3);
/*      */       }
/* 1834 */       return parseName(this._quad1, q2, q3, i, 3);
/*      */     }
/* 1836 */     q3 = q3 << 8 | i;
/* 1837 */     i = input[(this._inputPtr++)] & 0xFF;
/* 1838 */     if (codes[i] != 0) {
/* 1839 */       if (i == 34) {
/* 1840 */         return findName(this._quad1, q2, q3, 4);
/*      */       }
/* 1842 */       return parseName(this._quad1, q2, q3, i, 4);
/*      */     }
/* 1844 */     return parseLongName(i, q2, q3);
/*      */   }
/*      */   
/*      */   protected final String parseLongName(int q, int q2, int q3) throws IOException
/*      */   {
/* 1849 */     this._quadBuffer[0] = this._quad1;
/* 1850 */     this._quadBuffer[1] = q2;
/* 1851 */     this._quadBuffer[2] = q3;
/*      */     
/*      */ 
/* 1854 */     byte[] input = this._inputBuffer;
/* 1855 */     int[] codes = _icLatin1;
/* 1856 */     int qlen = 3;
/*      */     
/* 1858 */     while (this._inputPtr + 4 <= this._inputEnd) {
/* 1859 */       int i = input[(this._inputPtr++)] & 0xFF;
/* 1860 */       if (codes[i] != 0) {
/* 1861 */         if (i == 34) {
/* 1862 */           return findName(this._quadBuffer, qlen, q, 1);
/*      */         }
/* 1864 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 1);
/*      */       }
/*      */       
/* 1867 */       q = q << 8 | i;
/* 1868 */       i = input[(this._inputPtr++)] & 0xFF;
/* 1869 */       if (codes[i] != 0) {
/* 1870 */         if (i == 34) {
/* 1871 */           return findName(this._quadBuffer, qlen, q, 2);
/*      */         }
/* 1873 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 2);
/*      */       }
/*      */       
/* 1876 */       q = q << 8 | i;
/* 1877 */       i = input[(this._inputPtr++)] & 0xFF;
/* 1878 */       if (codes[i] != 0) {
/* 1879 */         if (i == 34) {
/* 1880 */           return findName(this._quadBuffer, qlen, q, 3);
/*      */         }
/* 1882 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 3);
/*      */       }
/*      */       
/* 1885 */       q = q << 8 | i;
/* 1886 */       i = input[(this._inputPtr++)] & 0xFF;
/* 1887 */       if (codes[i] != 0) {
/* 1888 */         if (i == 34) {
/* 1889 */           return findName(this._quadBuffer, qlen, q, 4);
/*      */         }
/* 1891 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 4);
/*      */       }
/*      */       
/*      */ 
/* 1895 */       if (qlen >= this._quadBuffer.length) {
/* 1896 */         this._quadBuffer = growArrayBy(this._quadBuffer, qlen);
/*      */       }
/* 1898 */       this._quadBuffer[(qlen++)] = q;
/* 1899 */       q = i;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1906 */     return parseEscapedName(this._quadBuffer, qlen, 0, q, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String slowParseName()
/*      */     throws IOException
/*      */   {
/* 1916 */     if ((this._inputPtr >= this._inputEnd) && 
/* 1917 */       (!_loadMore())) {
/* 1918 */       _reportInvalidEOF(": was expecting closing '\"' for name", JsonToken.FIELD_NAME);
/*      */     }
/*      */     
/* 1921 */     int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 1922 */     if (i == 34) {
/* 1923 */       return "";
/*      */     }
/* 1925 */     return parseEscapedName(this._quadBuffer, 0, 0, i, 0);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int ch, int lastQuadBytes) throws IOException {
/* 1929 */     return parseEscapedName(this._quadBuffer, 0, q1, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int ch, int lastQuadBytes) throws IOException {
/* 1933 */     this._quadBuffer[0] = q1;
/* 1934 */     return parseEscapedName(this._quadBuffer, 1, q2, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int q3, int ch, int lastQuadBytes) throws IOException {
/* 1938 */     this._quadBuffer[0] = q1;
/* 1939 */     this._quadBuffer[1] = q2;
/* 1940 */     return parseEscapedName(this._quadBuffer, 2, q3, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final String parseEscapedName(int[] quads, int qlen, int currQuad, int ch, int currQuadBytes)
/*      */     throws IOException
/*      */   {
/* 1955 */     int[] codes = _icLatin1;
/*      */     for (;;)
/*      */     {
/* 1958 */       if (codes[ch] != 0) {
/* 1959 */         if (ch == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 1963 */         if (ch != 92)
/*      */         {
/* 1965 */           _throwUnquotedSpace(ch, "name");
/*      */         }
/*      */         else {
/* 1968 */           ch = _decodeEscaped();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1973 */         if (ch > 127)
/*      */         {
/* 1975 */           if (currQuadBytes >= 4) {
/* 1976 */             if (qlen >= quads.length) {
/* 1977 */               this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */             }
/* 1979 */             quads[(qlen++)] = currQuad;
/* 1980 */             currQuad = 0;
/* 1981 */             currQuadBytes = 0;
/*      */           }
/* 1983 */           if (ch < 2048) {
/* 1984 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 1985 */             currQuadBytes++;
/*      */           }
/*      */           else {
/* 1988 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 1989 */             currQuadBytes++;
/*      */             
/* 1991 */             if (currQuadBytes >= 4) {
/* 1992 */               if (qlen >= quads.length) {
/* 1993 */                 this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */               }
/* 1995 */               quads[(qlen++)] = currQuad;
/* 1996 */               currQuad = 0;
/* 1997 */               currQuadBytes = 0;
/*      */             }
/* 1999 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2000 */             currQuadBytes++;
/*      */           }
/*      */           
/* 2003 */           ch = 0x80 | ch & 0x3F;
/*      */         }
/*      */       }
/*      */       
/* 2007 */       if (currQuadBytes < 4) {
/* 2008 */         currQuadBytes++;
/* 2009 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2011 */         if (qlen >= quads.length) {
/* 2012 */           this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */         }
/* 2014 */         quads[(qlen++)] = currQuad;
/* 2015 */         currQuad = ch;
/* 2016 */         currQuadBytes = 1;
/*      */       }
/* 2018 */       if ((this._inputPtr >= this._inputEnd) && 
/* 2019 */         (!_loadMore())) {
/* 2020 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2023 */       ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */     }
/*      */     
/* 2026 */     if (currQuadBytes > 0) {
/* 2027 */       if (qlen >= quads.length) {
/* 2028 */         this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */       }
/* 2030 */       quads[(qlen++)] = _padLastQuad(currQuad, currQuadBytes);
/*      */     }
/* 2032 */     String name = this._symbols.findName(quads, qlen);
/* 2033 */     if (name == null) {
/* 2034 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2036 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String _handleOddName(int ch)
/*      */     throws IOException
/*      */   {
/* 2048 */     if ((ch == 39) && ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0)) {
/* 2049 */       return _parseAposName();
/*      */     }
/*      */     
/* 2052 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/* 2053 */       char c = (char)_decodeCharForError(ch);
/* 2054 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2060 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 2062 */     if (codes[ch] != 0) {
/* 2063 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2069 */     int[] quads = this._quadBuffer;
/* 2070 */     int qlen = 0;
/* 2071 */     int currQuad = 0;
/* 2072 */     int currQuadBytes = 0;
/*      */     
/*      */     for (;;)
/*      */     {
/* 2076 */       if (currQuadBytes < 4) {
/* 2077 */         currQuadBytes++;
/* 2078 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2080 */         if (qlen >= quads.length) {
/* 2081 */           this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */         }
/* 2083 */         quads[(qlen++)] = currQuad;
/* 2084 */         currQuad = ch;
/* 2085 */         currQuadBytes = 1;
/*      */       }
/* 2087 */       if ((this._inputPtr >= this._inputEnd) && 
/* 2088 */         (!_loadMore())) {
/* 2089 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2092 */       ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2093 */       if (codes[ch] != 0) {
/*      */         break;
/*      */       }
/* 2096 */       this._inputPtr += 1;
/*      */     }
/*      */     
/* 2099 */     if (currQuadBytes > 0) {
/* 2100 */       if (qlen >= quads.length) {
/* 2101 */         this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */       }
/* 2103 */       quads[(qlen++)] = currQuad;
/*      */     }
/* 2105 */     String name = this._symbols.findName(quads, qlen);
/* 2106 */     if (name == null) {
/* 2107 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2109 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String _parseAposName()
/*      */     throws IOException
/*      */   {
/* 2119 */     if ((this._inputPtr >= this._inputEnd) && 
/* 2120 */       (!_loadMore())) {
/* 2121 */       _reportInvalidEOF(": was expecting closing ''' for field name", JsonToken.FIELD_NAME);
/*      */     }
/*      */     
/* 2124 */     int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2125 */     if (ch == 39) {
/* 2126 */       return "";
/*      */     }
/* 2128 */     int[] quads = this._quadBuffer;
/* 2129 */     int qlen = 0;
/* 2130 */     int currQuad = 0;
/* 2131 */     int currQuadBytes = 0;
/*      */     
/*      */ 
/*      */ 
/* 2135 */     int[] codes = _icLatin1;
/*      */     
/*      */ 
/* 2138 */     while (ch != 39)
/*      */     {
/*      */ 
/*      */ 
/* 2142 */       if ((codes[ch] != 0) && (ch != 34)) {
/* 2143 */         if (ch != 92)
/*      */         {
/*      */ 
/* 2146 */           _throwUnquotedSpace(ch, "name");
/*      */         }
/*      */         else {
/* 2149 */           ch = _decodeEscaped();
/*      */         }
/*      */         
/* 2152 */         if (ch > 127)
/*      */         {
/* 2154 */           if (currQuadBytes >= 4) {
/* 2155 */             if (qlen >= quads.length) {
/* 2156 */               this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */             }
/* 2158 */             quads[(qlen++)] = currQuad;
/* 2159 */             currQuad = 0;
/* 2160 */             currQuadBytes = 0;
/*      */           }
/* 2162 */           if (ch < 2048) {
/* 2163 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2164 */             currQuadBytes++;
/*      */           }
/*      */           else {
/* 2167 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2168 */             currQuadBytes++;
/*      */             
/* 2170 */             if (currQuadBytes >= 4) {
/* 2171 */               if (qlen >= quads.length) {
/* 2172 */                 this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */               }
/* 2174 */               quads[(qlen++)] = currQuad;
/* 2175 */               currQuad = 0;
/* 2176 */               currQuadBytes = 0;
/*      */             }
/* 2178 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2179 */             currQuadBytes++;
/*      */           }
/*      */           
/* 2182 */           ch = 0x80 | ch & 0x3F;
/*      */         }
/*      */       }
/*      */       
/* 2186 */       if (currQuadBytes < 4) {
/* 2187 */         currQuadBytes++;
/* 2188 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2190 */         if (qlen >= quads.length) {
/* 2191 */           this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */         }
/* 2193 */         quads[(qlen++)] = currQuad;
/* 2194 */         currQuad = ch;
/* 2195 */         currQuadBytes = 1;
/*      */       }
/* 2197 */       if ((this._inputPtr >= this._inputEnd) && 
/* 2198 */         (!_loadMore())) {
/* 2199 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2202 */       ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */     }
/*      */     
/* 2205 */     if (currQuadBytes > 0) {
/* 2206 */       if (qlen >= quads.length) {
/* 2207 */         this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */       }
/* 2209 */       quads[(qlen++)] = _padLastQuad(currQuad, currQuadBytes);
/*      */     }
/* 2211 */     String name = this._symbols.findName(quads, qlen);
/* 2212 */     if (name == null) {
/* 2213 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2215 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String findName(int q1, int lastQuadBytes)
/*      */     throws JsonParseException
/*      */   {
/* 2226 */     q1 = _padLastQuad(q1, lastQuadBytes);
/*      */     
/* 2228 */     String name = this._symbols.findName(q1);
/* 2229 */     if (name != null) {
/* 2230 */       return name;
/*      */     }
/*      */     
/* 2233 */     this._quadBuffer[0] = q1;
/* 2234 */     return addName(this._quadBuffer, 1, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String findName(int q1, int q2, int lastQuadBytes) throws JsonParseException
/*      */   {
/* 2239 */     q2 = _padLastQuad(q2, lastQuadBytes);
/*      */     
/* 2241 */     String name = this._symbols.findName(q1, q2);
/* 2242 */     if (name != null) {
/* 2243 */       return name;
/*      */     }
/*      */     
/* 2246 */     this._quadBuffer[0] = q1;
/* 2247 */     this._quadBuffer[1] = q2;
/* 2248 */     return addName(this._quadBuffer, 2, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String findName(int q1, int q2, int q3, int lastQuadBytes) throws JsonParseException
/*      */   {
/* 2253 */     q3 = _padLastQuad(q3, lastQuadBytes);
/* 2254 */     String name = this._symbols.findName(q1, q2, q3);
/* 2255 */     if (name != null) {
/* 2256 */       return name;
/*      */     }
/* 2258 */     int[] quads = this._quadBuffer;
/* 2259 */     quads[0] = q1;
/* 2260 */     quads[1] = q2;
/* 2261 */     quads[2] = _padLastQuad(q3, lastQuadBytes);
/* 2262 */     return addName(quads, 3, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String findName(int[] quads, int qlen, int lastQuad, int lastQuadBytes) throws JsonParseException
/*      */   {
/* 2267 */     if (qlen >= quads.length) {
/* 2268 */       this._quadBuffer = (quads = growArrayBy(quads, quads.length));
/*      */     }
/* 2270 */     quads[(qlen++)] = _padLastQuad(lastQuad, lastQuadBytes);
/* 2271 */     String name = this._symbols.findName(quads, qlen);
/* 2272 */     if (name == null) {
/* 2273 */       return addName(quads, qlen, lastQuadBytes);
/*      */     }
/* 2275 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String addName(int[] quads, int qlen, int lastQuadBytes)
/*      */     throws JsonParseException
/*      */   {
/* 2291 */     int byteLen = (qlen << 2) - 4 + lastQuadBytes;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     int lastQuad;
/*      */     
/*      */ 
/*      */ 
/* 2300 */     if (lastQuadBytes < 4) {
/* 2301 */       int lastQuad = quads[(qlen - 1)];
/*      */       
/* 2303 */       quads[(qlen - 1)] = (lastQuad << (4 - lastQuadBytes << 3));
/*      */     } else {
/* 2305 */       lastQuad = 0;
/*      */     }
/*      */     
/*      */ 
/* 2309 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2310 */     int cix = 0;
/*      */     
/* 2312 */     for (int ix = 0; ix < byteLen;) {
/* 2313 */       int ch = quads[(ix >> 2)];
/* 2314 */       int byteIx = ix & 0x3;
/* 2315 */       ch = ch >> (3 - byteIx << 3) & 0xFF;
/* 2316 */       ix++;
/*      */       
/* 2318 */       if (ch > 127) { int needed;
/*      */         int needed;
/* 2320 */         if ((ch & 0xE0) == 192) {
/* 2321 */           ch &= 0x1F;
/* 2322 */           needed = 1; } else { int needed;
/* 2323 */           if ((ch & 0xF0) == 224) {
/* 2324 */             ch &= 0xF;
/* 2325 */             needed = 2; } else { int needed;
/* 2326 */             if ((ch & 0xF8) == 240) {
/* 2327 */               ch &= 0x7;
/* 2328 */               needed = 3;
/*      */             } else {
/* 2330 */               _reportInvalidInitial(ch);
/* 2331 */               needed = ch = 1;
/*      */             } } }
/* 2333 */         if (ix + needed > byteLen) {
/* 2334 */           _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */         }
/*      */         
/*      */ 
/* 2338 */         int ch2 = quads[(ix >> 2)];
/* 2339 */         byteIx = ix & 0x3;
/* 2340 */         ch2 >>= 3 - byteIx << 3;
/* 2341 */         ix++;
/*      */         
/* 2343 */         if ((ch2 & 0xC0) != 128) {
/* 2344 */           _reportInvalidOther(ch2);
/*      */         }
/* 2346 */         ch = ch << 6 | ch2 & 0x3F;
/* 2347 */         if (needed > 1) {
/* 2348 */           ch2 = quads[(ix >> 2)];
/* 2349 */           byteIx = ix & 0x3;
/* 2350 */           ch2 >>= 3 - byteIx << 3;
/* 2351 */           ix++;
/*      */           
/* 2353 */           if ((ch2 & 0xC0) != 128) {
/* 2354 */             _reportInvalidOther(ch2);
/*      */           }
/* 2356 */           ch = ch << 6 | ch2 & 0x3F;
/* 2357 */           if (needed > 2) {
/* 2358 */             ch2 = quads[(ix >> 2)];
/* 2359 */             byteIx = ix & 0x3;
/* 2360 */             ch2 >>= 3 - byteIx << 3;
/* 2361 */             ix++;
/* 2362 */             if ((ch2 & 0xC0) != 128) {
/* 2363 */               _reportInvalidOther(ch2 & 0xFF);
/*      */             }
/* 2365 */             ch = ch << 6 | ch2 & 0x3F;
/*      */           }
/*      */         }
/* 2368 */         if (needed > 2) {
/* 2369 */           ch -= 65536;
/* 2370 */           if (cix >= cbuf.length) {
/* 2371 */             cbuf = this._textBuffer.expandCurrentSegment();
/*      */           }
/* 2373 */           cbuf[(cix++)] = ((char)(55296 + (ch >> 10)));
/* 2374 */           ch = 0xDC00 | ch & 0x3FF;
/*      */         }
/*      */       }
/* 2377 */       if (cix >= cbuf.length) {
/* 2378 */         cbuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 2380 */       cbuf[(cix++)] = ((char)ch);
/*      */     }
/*      */     
/*      */ 
/* 2384 */     String baseName = new String(cbuf, 0, cix);
/*      */     
/* 2386 */     if (lastQuadBytes < 4) {
/* 2387 */       quads[(qlen - 1)] = lastQuad;
/*      */     }
/* 2389 */     return this._symbols.addName(baseName, quads, qlen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static final int _padLastQuad(int q, int bytes)
/*      */   {
/* 2396 */     return bytes == 4 ? q : q | -1 << (bytes << 3);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _loadMoreGuaranteed()
/*      */     throws IOException
/*      */   {
/* 2406 */     if (!_loadMore()) { _reportInvalidEOF();
/*      */     }
/*      */   }
/*      */   
/*      */   protected void _finishString()
/*      */     throws IOException
/*      */   {
/* 2413 */     int ptr = this._inputPtr;
/* 2414 */     if (ptr >= this._inputEnd) {
/* 2415 */       _loadMoreGuaranteed();
/* 2416 */       ptr = this._inputPtr;
/*      */     }
/* 2418 */     int outPtr = 0;
/* 2419 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2420 */     int[] codes = _icUTF8;
/*      */     
/* 2422 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2423 */     byte[] inputBuffer = this._inputBuffer;
/* 2424 */     while (ptr < max) {
/* 2425 */       int c = inputBuffer[ptr] & 0xFF;
/* 2426 */       if (codes[c] != 0) {
/* 2427 */         if (c != 34) break;
/* 2428 */         this._inputPtr = (ptr + 1);
/* 2429 */         this._textBuffer.setCurrentLength(outPtr);
/* 2430 */         return;
/*      */       }
/*      */       
/*      */ 
/* 2434 */       ptr++;
/* 2435 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 2437 */     this._inputPtr = ptr;
/* 2438 */     _finishString2(outBuf, outPtr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String _finishAndReturnString()
/*      */     throws IOException
/*      */   {
/* 2447 */     int ptr = this._inputPtr;
/* 2448 */     if (ptr >= this._inputEnd) {
/* 2449 */       _loadMoreGuaranteed();
/* 2450 */       ptr = this._inputPtr;
/*      */     }
/* 2452 */     int outPtr = 0;
/* 2453 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2454 */     int[] codes = _icUTF8;
/*      */     
/* 2456 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2457 */     byte[] inputBuffer = this._inputBuffer;
/* 2458 */     while (ptr < max) {
/* 2459 */       int c = inputBuffer[ptr] & 0xFF;
/* 2460 */       if (codes[c] != 0) {
/* 2461 */         if (c != 34) break;
/* 2462 */         this._inputPtr = (ptr + 1);
/* 2463 */         return this._textBuffer.setCurrentAndReturn(outPtr);
/*      */       }
/*      */       
/*      */ 
/* 2467 */       ptr++;
/* 2468 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 2470 */     this._inputPtr = ptr;
/* 2471 */     _finishString2(outBuf, outPtr);
/* 2472 */     return this._textBuffer.contentsAsString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _finishString2(char[] outBuf, int outPtr)
/*      */     throws IOException
/*      */   {
/* 2481 */     int[] codes = _icUTF8;
/* 2482 */     byte[] inputBuffer = this._inputBuffer;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 2489 */       int ptr = this._inputPtr;
/* 2490 */       if (ptr >= this._inputEnd) {
/* 2491 */         _loadMoreGuaranteed();
/* 2492 */         ptr = this._inputPtr;
/*      */       }
/* 2494 */       if (outPtr >= outBuf.length) {
/* 2495 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2496 */         outPtr = 0;
/*      */       }
/* 2498 */       int max = Math.min(this._inputEnd, ptr + (outBuf.length - outPtr));
/* 2499 */       while (ptr < max) {
/* 2500 */         int c = inputBuffer[(ptr++)] & 0xFF;
/* 2501 */         if (codes[c] != 0) {
/* 2502 */           this._inputPtr = ptr;
/*      */           break label124;
/*      */         }
/* 2505 */         outBuf[(outPtr++)] = ((char)c);
/*      */       }
/* 2507 */       this._inputPtr = ptr;
/* 2508 */       continue;
/*      */       label124:
/* 2510 */       int c; if (c == 34) {
/*      */         break;
/*      */       }
/*      */       
/* 2514 */       switch (codes[c]) {
/*      */       case 1: 
/* 2516 */         c = _decodeEscaped();
/* 2517 */         break;
/*      */       case 2: 
/* 2519 */         c = _decodeUtf8_2(c);
/* 2520 */         break;
/*      */       case 3: 
/* 2522 */         if (this._inputEnd - this._inputPtr >= 2) {
/* 2523 */           c = _decodeUtf8_3fast(c);
/*      */         } else {
/* 2525 */           c = _decodeUtf8_3(c);
/*      */         }
/* 2527 */         break;
/*      */       case 4: 
/* 2529 */         c = _decodeUtf8_4(c);
/*      */         
/* 2531 */         outBuf[(outPtr++)] = ((char)(0xD800 | c >> 10));
/* 2532 */         if (outPtr >= outBuf.length) {
/* 2533 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 2534 */           outPtr = 0;
/*      */         }
/* 2536 */         c = 0xDC00 | c & 0x3FF;
/*      */         
/* 2538 */         break;
/*      */       default: 
/* 2540 */         if (c < 32)
/*      */         {
/* 2542 */           _throwUnquotedSpace(c, "string value");
/*      */         }
/*      */         else {
/* 2545 */           _reportInvalidChar(c);
/*      */         }
/*      */         break;
/*      */       }
/* 2549 */       if (outPtr >= outBuf.length) {
/* 2550 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2551 */         outPtr = 0;
/*      */       }
/*      */       
/* 2554 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 2556 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _skipString()
/*      */     throws IOException
/*      */   {
/* 2566 */     this._tokenIncomplete = false;
/*      */     
/*      */ 
/* 2569 */     int[] codes = _icUTF8;
/* 2570 */     byte[] inputBuffer = this._inputBuffer;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 2578 */       int ptr = this._inputPtr;
/* 2579 */       int max = this._inputEnd;
/* 2580 */       if (ptr >= max) {
/* 2581 */         _loadMoreGuaranteed();
/* 2582 */         ptr = this._inputPtr;
/* 2583 */         max = this._inputEnd;
/*      */       }
/* 2585 */       while (ptr < max) {
/* 2586 */         int c = inputBuffer[(ptr++)] & 0xFF;
/* 2587 */         if (codes[c] != 0) {
/* 2588 */           this._inputPtr = ptr;
/*      */           break label92;
/*      */         }
/*      */       }
/* 2592 */       this._inputPtr = ptr;
/* 2593 */       continue;
/*      */       label92:
/* 2595 */       int c; if (c == 34) {
/*      */         break;
/*      */       }
/*      */       
/* 2599 */       switch (codes[c]) {
/*      */       case 1: 
/* 2601 */         _decodeEscaped();
/* 2602 */         break;
/*      */       case 2: 
/* 2604 */         _skipUtf8_2();
/* 2605 */         break;
/*      */       case 3: 
/* 2607 */         _skipUtf8_3();
/* 2608 */         break;
/*      */       case 4: 
/* 2610 */         _skipUtf8_4(c);
/* 2611 */         break;
/*      */       default: 
/* 2613 */         if (c < 32) {
/* 2614 */           _throwUnquotedSpace(c, "string value");
/*      */         }
/*      */         else {
/* 2617 */           _reportInvalidChar(c);
/*      */         }
/*      */         
/*      */         break;
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected JsonToken _handleUnexpectedValue(int c)
/*      */     throws IOException
/*      */   {
/* 2630 */     switch (c)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 93: 
/* 2639 */       if (!this._parsingContext.inArray()) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 44: 
/* 2648 */       if ((!this._parsingContext.inRoot()) && 
/* 2649 */         ((this._features & FEAT_MASK_ALLOW_MISSING) != 0)) {
/* 2650 */         this._inputPtr -= 1;
/* 2651 */         return JsonToken.VALUE_NULL;
/*      */       }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 125: 
/* 2658 */       _reportUnexpectedChar(c, "expected a value");
/*      */     case 39: 
/* 2660 */       if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2661 */         return _handleApos();
/*      */       }
/*      */       break;
/*      */     case 78: 
/* 2665 */       _matchToken("NaN", 1);
/* 2666 */       if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2667 */         return resetAsNaN("NaN", NaN.0D);
/*      */       }
/* 2669 */       _reportError("Non-standard token 'NaN': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/* 2670 */       break;
/*      */     case 73: 
/* 2672 */       _matchToken("Infinity", 1);
/* 2673 */       if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2674 */         return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */       }
/* 2676 */       _reportError("Non-standard token 'Infinity': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/* 2677 */       break;
/*      */     case 43: 
/* 2679 */       if ((this._inputPtr >= this._inputEnd) && 
/* 2680 */         (!_loadMore())) {
/* 2681 */         _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */       }
/*      */       
/* 2684 */       return _handleInvalidNumberStart(this._inputBuffer[(this._inputPtr++)] & 0xFF, false);
/*      */     }
/*      */     
/* 2687 */     if (Character.isJavaIdentifierStart(c)) {
/* 2688 */       _reportInvalidToken("" + (char)c, _validJsonTokenList());
/*      */     }
/*      */     
/* 2691 */     _reportUnexpectedChar(c, "expected a valid value " + _validJsonValueList());
/* 2692 */     return null;
/*      */   }
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException
/*      */   {
/* 2697 */     int c = 0;
/*      */     
/* 2699 */     int outPtr = 0;
/* 2700 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */     
/*      */ 
/* 2703 */     int[] codes = _icUTF8;
/* 2704 */     byte[] inputBuffer = this._inputBuffer;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 2711 */       if (this._inputPtr >= this._inputEnd) {
/* 2712 */         _loadMoreGuaranteed();
/*      */       }
/* 2714 */       if (outPtr >= outBuf.length) {
/* 2715 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2716 */         outPtr = 0;
/*      */       }
/* 2718 */       int max = this._inputEnd;
/*      */       
/* 2720 */       int max2 = this._inputPtr + (outBuf.length - outPtr);
/* 2721 */       if (max2 < max) {
/* 2722 */         max = max2;
/*      */       }
/*      */       
/* 2725 */       while (this._inputPtr < max) {
/* 2726 */         c = inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2727 */         if ((c == 39) || (codes[c] != 0)) {
/*      */           break label140;
/*      */         }
/* 2730 */         outBuf[(outPtr++)] = ((char)c);
/*      */       }
/* 2732 */       continue;
/*      */       
/*      */       label140:
/* 2735 */       if (c == 39) {
/*      */         break;
/*      */       }
/*      */       
/* 2739 */       switch (codes[c]) {
/*      */       case 1: 
/* 2741 */         c = _decodeEscaped();
/* 2742 */         break;
/*      */       case 2: 
/* 2744 */         c = _decodeUtf8_2(c);
/* 2745 */         break;
/*      */       case 3: 
/* 2747 */         if (this._inputEnd - this._inputPtr >= 2) {
/* 2748 */           c = _decodeUtf8_3fast(c);
/*      */         } else {
/* 2750 */           c = _decodeUtf8_3(c);
/*      */         }
/* 2752 */         break;
/*      */       case 4: 
/* 2754 */         c = _decodeUtf8_4(c);
/*      */         
/* 2756 */         outBuf[(outPtr++)] = ((char)(0xD800 | c >> 10));
/* 2757 */         if (outPtr >= outBuf.length) {
/* 2758 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 2759 */           outPtr = 0;
/*      */         }
/* 2761 */         c = 0xDC00 | c & 0x3FF;
/*      */         
/* 2763 */         break;
/*      */       default: 
/* 2765 */         if (c < 32) {
/* 2766 */           _throwUnquotedSpace(c, "string value");
/*      */         }
/*      */         
/* 2769 */         _reportInvalidChar(c);
/*      */       }
/*      */       
/* 2772 */       if (outPtr >= outBuf.length) {
/* 2773 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2774 */         outPtr = 0;
/*      */       }
/*      */       
/* 2777 */       outBuf[(outPtr++)] = ((char)c);
/*      */     }
/* 2779 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 2781 */     return JsonToken.VALUE_STRING;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg)
/*      */     throws IOException
/*      */   {
/* 2796 */     while (ch == 73) {
/* 2797 */       if ((this._inputPtr >= this._inputEnd) && 
/* 2798 */         (!_loadMore())) {
/* 2799 */         _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_FLOAT);
/*      */       }
/*      */       
/* 2802 */       ch = this._inputBuffer[(this._inputPtr++)];
/*      */       String match;
/* 2804 */       String match; if (ch == 78) {
/* 2805 */         match = neg ? "-INF" : "+INF";
/* 2806 */       } else { if (ch != 110) break;
/* 2807 */         match = neg ? "-Infinity" : "+Infinity";
/*      */       }
/*      */       
/*      */ 
/* 2811 */       _matchToken(match, 3);
/* 2812 */       if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2813 */         return resetAsNaN(match, neg ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */       }
/* 2815 */       _reportError("Non-standard token '%s': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow", match);
/*      */     }
/*      */     
/* 2818 */     reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 2819 */     return null;
/*      */   }
/*      */   
/*      */   protected final void _matchTrue()
/*      */     throws IOException
/*      */   {
/* 2825 */     int ptr = this._inputPtr;
/* 2826 */     if (ptr + 3 < this._inputEnd) {
/* 2827 */       byte[] buf = this._inputBuffer;
/* 2828 */       if ((buf[(ptr++)] == 114) && (buf[(ptr++)] == 117) && (buf[(ptr++)] == 101))
/*      */       {
/*      */ 
/* 2831 */         int ch = buf[ptr] & 0xFF;
/* 2832 */         if ((ch < 48) || (ch == 93) || (ch == 125)) {
/* 2833 */           this._inputPtr = ptr;
/* 2834 */           return;
/*      */         }
/*      */       }
/*      */     }
/* 2838 */     _matchToken2("true", 1);
/*      */   }
/*      */   
/*      */   protected final void _matchFalse() throws IOException
/*      */   {
/* 2843 */     int ptr = this._inputPtr;
/* 2844 */     if (ptr + 4 < this._inputEnd) {
/* 2845 */       byte[] buf = this._inputBuffer;
/* 2846 */       if ((buf[(ptr++)] == 97) && (buf[(ptr++)] == 108) && (buf[(ptr++)] == 115) && (buf[(ptr++)] == 101))
/*      */       {
/*      */ 
/*      */ 
/* 2850 */         int ch = buf[ptr] & 0xFF;
/* 2851 */         if ((ch < 48) || (ch == 93) || (ch == 125)) {
/* 2852 */           this._inputPtr = ptr;
/* 2853 */           return;
/*      */         }
/*      */       }
/*      */     }
/* 2857 */     _matchToken2("false", 1);
/*      */   }
/*      */   
/*      */   protected final void _matchNull() throws IOException
/*      */   {
/* 2862 */     int ptr = this._inputPtr;
/* 2863 */     if (ptr + 3 < this._inputEnd) {
/* 2864 */       byte[] buf = this._inputBuffer;
/* 2865 */       if ((buf[(ptr++)] == 117) && (buf[(ptr++)] == 108) && (buf[(ptr++)] == 108))
/*      */       {
/*      */ 
/* 2868 */         int ch = buf[ptr] & 0xFF;
/* 2869 */         if ((ch < 48) || (ch == 93) || (ch == 125)) {
/* 2870 */           this._inputPtr = ptr;
/* 2871 */           return;
/*      */         }
/*      */       }
/*      */     }
/* 2875 */     _matchToken2("null", 1);
/*      */   }
/*      */   
/*      */   protected final void _matchToken(String matchStr, int i) throws IOException
/*      */   {
/* 2880 */     int len = matchStr.length();
/* 2881 */     if (this._inputPtr + len >= this._inputEnd) {
/* 2882 */       _matchToken2(matchStr, i);
/*      */     }
/*      */     else {
/*      */       do {
/* 2886 */         if (this._inputBuffer[this._inputPtr] != matchStr.charAt(i)) {
/* 2887 */           _reportInvalidToken(matchStr.substring(0, i));
/*      */         }
/* 2889 */         this._inputPtr += 1;
/* 2890 */         i++; } while (i < len);
/*      */       
/* 2892 */       int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2893 */       if ((ch >= 48) && (ch != 93) && (ch != 125)) {
/* 2894 */         _checkMatchEnd(matchStr, i, ch);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private final void _matchToken2(String matchStr, int i) throws IOException {
/* 2900 */     int len = matchStr.length();
/*      */     do {
/* 2902 */       if (((this._inputPtr >= this._inputEnd) && (!_loadMore())) || 
/* 2903 */         (this._inputBuffer[this._inputPtr] != matchStr.charAt(i))) {
/* 2904 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2906 */       this._inputPtr += 1;
/* 2907 */       i++; } while (i < len);
/*      */     
/*      */ 
/* 2910 */     if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/* 2911 */       return;
/*      */     }
/* 2913 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2914 */     if ((ch >= 48) && (ch != 93) && (ch != 125)) {
/* 2915 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int ch) throws IOException
/*      */   {
/* 2921 */     char c = (char)_decodeCharForError(ch);
/* 2922 */     if (Character.isJavaIdentifierPart(c)) {
/* 2923 */       _reportInvalidToken(matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int _skipWS()
/*      */     throws IOException
/*      */   {
/* 2935 */     while (this._inputPtr < this._inputEnd) {
/* 2936 */       int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2937 */       if (i > 32) {
/* 2938 */         if ((i == 47) || (i == 35)) {
/* 2939 */           this._inputPtr -= 1;
/* 2940 */           return _skipWS2();
/*      */         }
/* 2942 */         return i;
/*      */       }
/* 2944 */       if (i != 32) {
/* 2945 */         if (i == 10) {
/* 2946 */           this._currInputRow += 1;
/* 2947 */           this._currInputRowStart = this._inputPtr;
/* 2948 */         } else if (i == 13) {
/* 2949 */           _skipCR();
/* 2950 */         } else if (i != 9) {
/* 2951 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/* 2955 */     return _skipWS2();
/*      */   }
/*      */   
/*      */   private final int _skipWS2() throws IOException
/*      */   {
/* 2960 */     while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 2961 */       int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2962 */       if (i > 32) {
/* 2963 */         if (i == 47) {
/* 2964 */           _skipComment();
/*      */ 
/*      */         }
/* 2967 */         else if ((i != 35) || 
/* 2968 */           (!_skipYAMLComment()))
/*      */         {
/*      */ 
/*      */ 
/* 2972 */           return i;
/*      */         }
/* 2974 */       } else if (i != 32) {
/* 2975 */         if (i == 10) {
/* 2976 */           this._currInputRow += 1;
/* 2977 */           this._currInputRowStart = this._inputPtr;
/* 2978 */         } else if (i == 13) {
/* 2979 */           _skipCR();
/* 2980 */         } else if (i != 9) {
/* 2981 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/* 2985 */     throw _constructError("Unexpected end-of-input within/between " + this._parsingContext.typeDesc() + " entries");
/*      */   }
/*      */   
/*      */ 
/*      */   private final int _skipWSOrEnd()
/*      */     throws IOException
/*      */   {
/* 2992 */     if ((this._inputPtr >= this._inputEnd) && 
/* 2993 */       (!_loadMore())) {
/* 2994 */       return _eofAsNextChar();
/*      */     }
/*      */     
/* 2997 */     int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 2998 */     if (i > 32) {
/* 2999 */       if ((i == 47) || (i == 35)) {
/* 3000 */         this._inputPtr -= 1;
/* 3001 */         return _skipWSOrEnd2();
/*      */       }
/* 3003 */       return i;
/*      */     }
/* 3005 */     if (i != 32) {
/* 3006 */       if (i == 10) {
/* 3007 */         this._currInputRow += 1;
/* 3008 */         this._currInputRowStart = this._inputPtr;
/* 3009 */       } else if (i == 13) {
/* 3010 */         _skipCR();
/* 3011 */       } else if (i != 9) {
/* 3012 */         _throwInvalidSpace(i);
/*      */       }
/*      */     }
/*      */     
/* 3016 */     while (this._inputPtr < this._inputEnd) {
/* 3017 */       i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 3018 */       if (i > 32) {
/* 3019 */         if ((i == 47) || (i == 35)) {
/* 3020 */           this._inputPtr -= 1;
/* 3021 */           return _skipWSOrEnd2();
/*      */         }
/* 3023 */         return i;
/*      */       }
/* 3025 */       if (i != 32) {
/* 3026 */         if (i == 10) {
/* 3027 */           this._currInputRow += 1;
/* 3028 */           this._currInputRowStart = this._inputPtr;
/* 3029 */         } else if (i == 13) {
/* 3030 */           _skipCR();
/* 3031 */         } else if (i != 9) {
/* 3032 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/* 3036 */     return _skipWSOrEnd2();
/*      */   }
/*      */   
/*      */   private final int _skipWSOrEnd2() throws IOException
/*      */   {
/* 3041 */     while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 3042 */       int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 3043 */       if (i > 32) {
/* 3044 */         if (i == 47) {
/* 3045 */           _skipComment();
/*      */ 
/*      */         }
/* 3048 */         else if ((i != 35) || 
/* 3049 */           (!_skipYAMLComment()))
/*      */         {
/*      */ 
/*      */ 
/* 3053 */           return i; }
/* 3054 */       } else if (i != 32) {
/* 3055 */         if (i == 10) {
/* 3056 */           this._currInputRow += 1;
/* 3057 */           this._currInputRowStart = this._inputPtr;
/* 3058 */         } else if (i == 13) {
/* 3059 */           _skipCR();
/* 3060 */         } else if (i != 9) {
/* 3061 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 3066 */     return _eofAsNextChar();
/*      */   }
/*      */   
/*      */   private final int _skipColon() throws IOException
/*      */   {
/* 3071 */     if (this._inputPtr + 4 >= this._inputEnd) {
/* 3072 */       return _skipColon2(false);
/*      */     }
/*      */     
/* 3075 */     int i = this._inputBuffer[this._inputPtr];
/* 3076 */     if (i == 58) {
/* 3077 */       i = this._inputBuffer[(++this._inputPtr)];
/* 3078 */       if (i > 32) {
/* 3079 */         if ((i == 47) || (i == 35)) {
/* 3080 */           return _skipColon2(true);
/*      */         }
/* 3082 */         this._inputPtr += 1;
/* 3083 */         return i;
/*      */       }
/* 3085 */       if ((i == 32) || (i == 9)) {
/* 3086 */         i = this._inputBuffer[(++this._inputPtr)];
/* 3087 */         if (i > 32) {
/* 3088 */           if ((i == 47) || (i == 35)) {
/* 3089 */             return _skipColon2(true);
/*      */           }
/* 3091 */           this._inputPtr += 1;
/* 3092 */           return i;
/*      */         }
/*      */       }
/* 3095 */       return _skipColon2(true);
/*      */     }
/* 3097 */     if ((i == 32) || (i == 9)) {
/* 3098 */       i = this._inputBuffer[(++this._inputPtr)];
/*      */     }
/* 3100 */     if (i == 58) {
/* 3101 */       i = this._inputBuffer[(++this._inputPtr)];
/* 3102 */       if (i > 32) {
/* 3103 */         if ((i == 47) || (i == 35)) {
/* 3104 */           return _skipColon2(true);
/*      */         }
/* 3106 */         this._inputPtr += 1;
/* 3107 */         return i;
/*      */       }
/* 3109 */       if ((i == 32) || (i == 9)) {
/* 3110 */         i = this._inputBuffer[(++this._inputPtr)];
/* 3111 */         if (i > 32) {
/* 3112 */           if ((i == 47) || (i == 35)) {
/* 3113 */             return _skipColon2(true);
/*      */           }
/* 3115 */           this._inputPtr += 1;
/* 3116 */           return i;
/*      */         }
/*      */       }
/* 3119 */       return _skipColon2(true);
/*      */     }
/* 3121 */     return _skipColon2(false);
/*      */   }
/*      */   
/*      */   private final int _skipColon2(boolean gotColon) throws IOException
/*      */   {
/* 3126 */     while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 3127 */       int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */       
/* 3129 */       if (i > 32) {
/* 3130 */         if (i == 47) {
/* 3131 */           _skipComment();
/*      */ 
/*      */         }
/* 3134 */         else if ((i != 35) || 
/* 3135 */           (!_skipYAMLComment()))
/*      */         {
/*      */ 
/*      */ 
/* 3139 */           if (gotColon) {
/* 3140 */             return i;
/*      */           }
/* 3142 */           if (i != 58) {
/* 3143 */             _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */           }
/* 3145 */           gotColon = true;
/* 3146 */         } } else if (i != 32) {
/* 3147 */         if (i == 10) {
/* 3148 */           this._currInputRow += 1;
/* 3149 */           this._currInputRowStart = this._inputPtr;
/* 3150 */         } else if (i == 13) {
/* 3151 */           _skipCR();
/* 3152 */         } else if (i != 9) {
/* 3153 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/* 3157 */     _reportInvalidEOF(" within/between " + this._parsingContext.typeDesc() + " entries", null);
/*      */     
/* 3159 */     return -1;
/*      */   }
/*      */   
/*      */   private final void _skipComment() throws IOException
/*      */   {
/* 3164 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/* 3165 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     
/* 3168 */     if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/* 3169 */       _reportInvalidEOF(" in a comment", null);
/*      */     }
/* 3171 */     int c = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 3172 */     if (c == 47) {
/* 3173 */       _skipLine();
/* 3174 */     } else if (c == 42) {
/* 3175 */       _skipCComment();
/*      */     } else {
/* 3177 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     }
/*      */   }
/*      */   
/*      */   private final void _skipCComment()
/*      */     throws IOException
/*      */   {
/* 3184 */     int[] codes = CharTypes.getInputCodeComment();
/*      */     
/*      */ 
/*      */ 
/* 3188 */     while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 3189 */       int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 3190 */       int code = codes[i];
/* 3191 */       if (code != 0)
/* 3192 */         switch (code) {
/*      */         case 42: 
/* 3194 */           if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/*      */             break label216;
/*      */           }
/* 3197 */           if (this._inputBuffer[this._inputPtr] == 47) {
/* 3198 */             this._inputPtr += 1; return;
/*      */           }
/*      */           
/*      */           break;
/*      */         case 10: 
/* 3203 */           this._currInputRow += 1;
/* 3204 */           this._currInputRowStart = this._inputPtr;
/* 3205 */           break;
/*      */         case 13: 
/* 3207 */           _skipCR();
/* 3208 */           break;
/*      */         case 2: 
/* 3210 */           _skipUtf8_2();
/* 3211 */           break;
/*      */         case 3: 
/* 3213 */           _skipUtf8_3();
/* 3214 */           break;
/*      */         case 4: 
/* 3216 */           _skipUtf8_4(i);
/* 3217 */           break;
/*      */         
/*      */         default: 
/* 3220 */           _reportInvalidChar(i);
/*      */         }
/*      */     }
/*      */     label216:
/* 3224 */     _reportInvalidEOF(" in a comment", null);
/*      */   }
/*      */   
/*      */   private final boolean _skipYAMLComment() throws IOException
/*      */   {
/* 3229 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/* 3230 */       return false;
/*      */     }
/* 3232 */     _skipLine();
/* 3233 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _skipLine()
/*      */     throws IOException
/*      */   {
/* 3243 */     int[] codes = CharTypes.getInputCodeComment();
/* 3244 */     while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 3245 */       int i = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 3246 */       int code = codes[i];
/* 3247 */       if (code != 0) {
/* 3248 */         switch (code) {
/*      */         case 10: 
/* 3250 */           this._currInputRow += 1;
/* 3251 */           this._currInputRowStart = this._inputPtr;
/* 3252 */           return;
/*      */         case 13: 
/* 3254 */           _skipCR(); return;
/*      */         case 42: 
/*      */           break;
/*      */         
/*      */         case 2: 
/* 3259 */           _skipUtf8_2();
/* 3260 */           break;
/*      */         case 3: 
/* 3262 */           _skipUtf8_3();
/* 3263 */           break;
/*      */         case 4: 
/* 3265 */           _skipUtf8_4(i);
/* 3266 */           break;
/*      */         default: 
/* 3268 */           if (code < 0)
/*      */           {
/* 3270 */             _reportInvalidChar(i);
/*      */           }
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected char _decodeEscaped() throws IOException
/*      */   {
/* 3280 */     if ((this._inputPtr >= this._inputEnd) && 
/* 3281 */       (!_loadMore())) {
/* 3282 */       _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */     }
/*      */     
/* 3285 */     int c = this._inputBuffer[(this._inputPtr++)];
/*      */     
/* 3287 */     switch (c)
/*      */     {
/*      */     case 98: 
/* 3290 */       return '\b';
/*      */     case 116: 
/* 3292 */       return '\t';
/*      */     case 110: 
/* 3294 */       return '\n';
/*      */     case 102: 
/* 3296 */       return '\f';
/*      */     case 114: 
/* 3298 */       return '\r';
/*      */     
/*      */ 
/*      */     case 34: 
/*      */     case 47: 
/*      */     case 92: 
/* 3304 */       return (char)c;
/*      */     
/*      */     case 117: 
/*      */       break;
/*      */     
/*      */     default: 
/* 3310 */       return _handleUnrecognizedCharacterEscape((char)_decodeCharForError(c));
/*      */     }
/*      */     
/*      */     
/* 3314 */     int value = 0;
/* 3315 */     for (int i = 0; i < 4; i++) {
/* 3316 */       if ((this._inputPtr >= this._inputEnd) && 
/* 3317 */         (!_loadMore())) {
/* 3318 */         _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/* 3321 */       int ch = this._inputBuffer[(this._inputPtr++)];
/* 3322 */       int digit = CharTypes.charToHex(ch);
/* 3323 */       if (digit < 0) {
/* 3324 */         _reportUnexpectedChar(ch & 0xFF, "expected a hex-digit for character escape sequence");
/*      */       }
/* 3326 */       value = value << 4 | digit;
/*      */     }
/* 3328 */     return (char)value;
/*      */   }
/*      */   
/*      */   protected int _decodeCharForError(int firstByte) throws IOException
/*      */   {
/* 3333 */     int c = firstByte & 0xFF;
/* 3334 */     if (c > 127)
/*      */     {
/*      */       int needed;
/*      */       int needed;
/* 3338 */       if ((c & 0xE0) == 192) {
/* 3339 */         c &= 0x1F;
/* 3340 */         needed = 1; } else { int needed;
/* 3341 */         if ((c & 0xF0) == 224) {
/* 3342 */           c &= 0xF;
/* 3343 */           needed = 2; } else { int needed;
/* 3344 */           if ((c & 0xF8) == 240)
/*      */           {
/* 3346 */             c &= 0x7;
/* 3347 */             needed = 3;
/*      */           } else {
/* 3349 */             _reportInvalidInitial(c & 0xFF);
/* 3350 */             needed = 1;
/*      */           }
/*      */         } }
/* 3353 */       int d = nextByte();
/* 3354 */       if ((d & 0xC0) != 128) {
/* 3355 */         _reportInvalidOther(d & 0xFF);
/*      */       }
/* 3357 */       c = c << 6 | d & 0x3F;
/*      */       
/* 3359 */       if (needed > 1) {
/* 3360 */         d = nextByte();
/* 3361 */         if ((d & 0xC0) != 128) {
/* 3362 */           _reportInvalidOther(d & 0xFF);
/*      */         }
/* 3364 */         c = c << 6 | d & 0x3F;
/* 3365 */         if (needed > 2) {
/* 3366 */           d = nextByte();
/* 3367 */           if ((d & 0xC0) != 128) {
/* 3368 */             _reportInvalidOther(d & 0xFF);
/*      */           }
/* 3370 */           c = c << 6 | d & 0x3F;
/*      */         }
/*      */       }
/*      */     }
/* 3374 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int _decodeUtf8_2(int c)
/*      */     throws IOException
/*      */   {
/* 3385 */     if (this._inputPtr >= this._inputEnd) {
/* 3386 */       _loadMoreGuaranteed();
/*      */     }
/* 3388 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 3389 */     if ((d & 0xC0) != 128) {
/* 3390 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3392 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */   
/*      */   private final int _decodeUtf8_3(int c1) throws IOException
/*      */   {
/* 3397 */     if (this._inputPtr >= this._inputEnd) {
/* 3398 */       _loadMoreGuaranteed();
/*      */     }
/* 3400 */     c1 &= 0xF;
/* 3401 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 3402 */     if ((d & 0xC0) != 128) {
/* 3403 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3405 */     int c = c1 << 6 | d & 0x3F;
/* 3406 */     if (this._inputPtr >= this._inputEnd) {
/* 3407 */       _loadMoreGuaranteed();
/*      */     }
/* 3409 */     d = this._inputBuffer[(this._inputPtr++)];
/* 3410 */     if ((d & 0xC0) != 128) {
/* 3411 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3413 */     c = c << 6 | d & 0x3F;
/* 3414 */     return c;
/*      */   }
/*      */   
/*      */   private final int _decodeUtf8_3fast(int c1) throws IOException
/*      */   {
/* 3419 */     c1 &= 0xF;
/* 3420 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 3421 */     if ((d & 0xC0) != 128) {
/* 3422 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3424 */     int c = c1 << 6 | d & 0x3F;
/* 3425 */     d = this._inputBuffer[(this._inputPtr++)];
/* 3426 */     if ((d & 0xC0) != 128) {
/* 3427 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3429 */     c = c << 6 | d & 0x3F;
/* 3430 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int _decodeUtf8_4(int c)
/*      */     throws IOException
/*      */   {
/* 3439 */     if (this._inputPtr >= this._inputEnd) {
/* 3440 */       _loadMoreGuaranteed();
/*      */     }
/* 3442 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 3443 */     if ((d & 0xC0) != 128) {
/* 3444 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3446 */     c = (c & 0x7) << 6 | d & 0x3F;
/*      */     
/* 3448 */     if (this._inputPtr >= this._inputEnd) {
/* 3449 */       _loadMoreGuaranteed();
/*      */     }
/* 3451 */     d = this._inputBuffer[(this._inputPtr++)];
/* 3452 */     if ((d & 0xC0) != 128) {
/* 3453 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3455 */     c = c << 6 | d & 0x3F;
/* 3456 */     if (this._inputPtr >= this._inputEnd) {
/* 3457 */       _loadMoreGuaranteed();
/*      */     }
/* 3459 */     d = this._inputBuffer[(this._inputPtr++)];
/* 3460 */     if ((d & 0xC0) != 128) {
/* 3461 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3467 */     return (c << 6 | d & 0x3F) - 65536;
/*      */   }
/*      */   
/*      */   private final void _skipUtf8_2() throws IOException
/*      */   {
/* 3472 */     if (this._inputPtr >= this._inputEnd) {
/* 3473 */       _loadMoreGuaranteed();
/*      */     }
/* 3475 */     int c = this._inputBuffer[(this._inputPtr++)];
/* 3476 */     if ((c & 0xC0) != 128) {
/* 3477 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private final void _skipUtf8_3()
/*      */     throws IOException
/*      */   {
/* 3486 */     if (this._inputPtr >= this._inputEnd) {
/* 3487 */       _loadMoreGuaranteed();
/*      */     }
/*      */     
/* 3490 */     int c = this._inputBuffer[(this._inputPtr++)];
/* 3491 */     if ((c & 0xC0) != 128) {
/* 3492 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/* 3494 */     if (this._inputPtr >= this._inputEnd) {
/* 3495 */       _loadMoreGuaranteed();
/*      */     }
/* 3497 */     c = this._inputBuffer[(this._inputPtr++)];
/* 3498 */     if ((c & 0xC0) != 128) {
/* 3499 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void _skipUtf8_4(int c) throws IOException
/*      */   {
/* 3505 */     if (this._inputPtr >= this._inputEnd) {
/* 3506 */       _loadMoreGuaranteed();
/*      */     }
/* 3508 */     int d = this._inputBuffer[(this._inputPtr++)];
/* 3509 */     if ((d & 0xC0) != 128) {
/* 3510 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3512 */     if (this._inputPtr >= this._inputEnd) {
/* 3513 */       _loadMoreGuaranteed();
/*      */     }
/* 3515 */     d = this._inputBuffer[(this._inputPtr++)];
/* 3516 */     if ((d & 0xC0) != 128) {
/* 3517 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3519 */     if (this._inputPtr >= this._inputEnd) {
/* 3520 */       _loadMoreGuaranteed();
/*      */     }
/* 3522 */     d = this._inputBuffer[(this._inputPtr++)];
/* 3523 */     if ((d & 0xC0) != 128) {
/* 3524 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _skipCR()
/*      */     throws IOException
/*      */   {
/* 3540 */     if (((this._inputPtr < this._inputEnd) || (_loadMore())) && 
/* 3541 */       (this._inputBuffer[this._inputPtr] == 10)) {
/* 3542 */       this._inputPtr += 1;
/*      */     }
/*      */     
/* 3545 */     this._currInputRow += 1;
/* 3546 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */   
/*      */   private int nextByte() throws IOException
/*      */   {
/* 3551 */     if (this._inputPtr >= this._inputEnd) {
/* 3552 */       _loadMoreGuaranteed();
/*      */     }
/* 3554 */     return this._inputBuffer[(this._inputPtr++)] & 0xFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _reportInvalidToken(String matchedPart, int ptr)
/*      */     throws IOException
/*      */   {
/* 3564 */     this._inputPtr = ptr;
/* 3565 */     _reportInvalidToken(matchedPart, _validJsonTokenList());
/*      */   }
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart) throws IOException {
/* 3569 */     _reportInvalidToken(matchedPart, _validJsonTokenList());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _reportInvalidToken(String matchedPart, String msg)
/*      */     throws IOException
/*      */   {
/* 3578 */     StringBuilder sb = new StringBuilder(matchedPart);
/* 3579 */     while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 3580 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 3581 */       char c = (char)_decodeCharForError(i);
/* 3582 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/* 3587 */       sb.append(c);
/* 3588 */       if (sb.length() >= 256) {
/* 3589 */         sb.append("...");
/* 3590 */         break;
/*      */       }
/*      */     }
/* 3593 */     _reportError("Unrecognized token '%s': was expecting %s", sb, msg);
/*      */   }
/*      */   
/*      */   protected void _reportInvalidChar(int c)
/*      */     throws JsonParseException
/*      */   {
/* 3599 */     if (c < 32) {
/* 3600 */       _throwInvalidSpace(c);
/*      */     }
/* 3602 */     _reportInvalidInitial(c);
/*      */   }
/*      */   
/*      */   protected void _reportInvalidInitial(int mask) throws JsonParseException {
/* 3606 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */   
/*      */   protected void _reportInvalidOther(int mask) throws JsonParseException {
/* 3610 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */   
/*      */   protected void _reportInvalidOther(int mask, int ptr)
/*      */     throws JsonParseException
/*      */   {
/* 3616 */     this._inputPtr = ptr;
/* 3617 */     _reportInvalidOther(mask);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final byte[] _decodeBase64(Base64Variant b64variant)
/*      */     throws IOException
/*      */   {
/* 3633 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */     
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 3639 */       if (this._inputPtr >= this._inputEnd) {
/* 3640 */         _loadMoreGuaranteed();
/*      */       }
/* 3642 */       int ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 3643 */       if (ch > 32) {
/* 3644 */         int bits = b64variant.decodeBase64Char(ch);
/* 3645 */         if (bits < 0) {
/* 3646 */           if (ch == 34) {
/* 3647 */             return builder.toByteArray();
/*      */           }
/* 3649 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 3650 */           if (bits < 0) {}
/*      */         }
/*      */         else
/*      */         {
/* 3654 */           int decodedData = bits;
/*      */           
/*      */ 
/*      */ 
/* 3658 */           if (this._inputPtr >= this._inputEnd) {
/* 3659 */             _loadMoreGuaranteed();
/*      */           }
/* 3661 */           ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 3662 */           bits = b64variant.decodeBase64Char(ch);
/* 3663 */           if (bits < 0) {
/* 3664 */             bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */           }
/* 3666 */           decodedData = decodedData << 6 | bits;
/*      */           
/*      */ 
/* 3669 */           if (this._inputPtr >= this._inputEnd) {
/* 3670 */             _loadMoreGuaranteed();
/*      */           }
/* 3672 */           ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 3673 */           bits = b64variant.decodeBase64Char(ch);
/*      */           
/*      */ 
/* 3676 */           if (bits < 0) {
/* 3677 */             if (bits != -2)
/*      */             {
/* 3679 */               if (ch == 34) {
/* 3680 */                 decodedData >>= 4;
/* 3681 */                 builder.append(decodedData);
/* 3682 */                 if (b64variant.usesPadding()) {
/* 3683 */                   this._inputPtr -= 1;
/* 3684 */                   _handleBase64MissingPadding(b64variant);
/*      */                 }
/* 3686 */                 return builder.toByteArray();
/*      */               }
/* 3688 */               bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */             }
/* 3690 */             if (bits == -2)
/*      */             {
/* 3692 */               if (this._inputPtr >= this._inputEnd) {
/* 3693 */                 _loadMoreGuaranteed();
/*      */               }
/* 3695 */               ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 3696 */               if ((!b64variant.usesPaddingChar(ch)) && 
/* 3697 */                 (_decodeBase64Escape(b64variant, ch, 3) != -2)) {
/* 3698 */                 throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */               }
/*      */               
/*      */ 
/* 3702 */               decodedData >>= 4;
/* 3703 */               builder.append(decodedData);
/* 3704 */               continue;
/*      */             }
/*      */           }
/*      */           
/* 3708 */           decodedData = decodedData << 6 | bits;
/*      */           
/* 3710 */           if (this._inputPtr >= this._inputEnd) {
/* 3711 */             _loadMoreGuaranteed();
/*      */           }
/* 3713 */           ch = this._inputBuffer[(this._inputPtr++)] & 0xFF;
/* 3714 */           bits = b64variant.decodeBase64Char(ch);
/* 3715 */           if (bits < 0) {
/* 3716 */             if (bits != -2)
/*      */             {
/* 3718 */               if (ch == 34) {
/* 3719 */                 decodedData >>= 2;
/* 3720 */                 builder.appendTwoBytes(decodedData);
/* 3721 */                 if (b64variant.usesPadding()) {
/* 3722 */                   this._inputPtr -= 1;
/* 3723 */                   _handleBase64MissingPadding(b64variant);
/*      */                 }
/* 3725 */                 return builder.toByteArray();
/*      */               }
/* 3727 */               bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */             }
/* 3729 */             if (bits == -2)
/*      */             {
/*      */ 
/*      */ 
/* 3733 */               decodedData >>= 2;
/* 3734 */               builder.appendTwoBytes(decodedData);
/* 3735 */               continue;
/*      */             }
/*      */           }
/*      */           
/* 3739 */           decodedData = decodedData << 6 | bits;
/* 3740 */           builder.appendThreeBytes(decodedData);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonLocation getTokenLocation()
/*      */   {
/* 3754 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 3755 */       long total = this._currInputProcessed + (this._nameStartOffset - 1);
/* 3756 */       return new JsonLocation(_getSourceReference(), total, -1L, this._nameStartRow, this._nameStartCol);
/*      */     }
/*      */     
/* 3759 */     return new JsonLocation(_getSourceReference(), this._tokenInputTotal - 1L, -1L, this._tokenInputRow, this._tokenInputCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonLocation getCurrentLocation()
/*      */   {
/* 3767 */     int col = this._inputPtr - this._currInputRowStart + 1;
/* 3768 */     return new JsonLocation(_getSourceReference(), this._currInputProcessed + this._inputPtr, -1L, this._currInputRow, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _updateLocation()
/*      */   {
/* 3776 */     this._tokenInputRow = this._currInputRow;
/* 3777 */     int ptr = this._inputPtr;
/* 3778 */     this._tokenInputTotal = (this._currInputProcessed + ptr);
/* 3779 */     this._tokenInputCol = (ptr - this._currInputRowStart);
/*      */   }
/*      */   
/*      */ 
/*      */   private final void _updateNameLocation()
/*      */   {
/* 3785 */     this._nameStartRow = this._currInputRow;
/* 3786 */     int ptr = this._inputPtr;
/* 3787 */     this._nameStartOffset = ptr;
/* 3788 */     this._nameStartCol = (ptr - this._currInputRowStart);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final JsonToken _closeScope(int i)
/*      */     throws JsonParseException
/*      */   {
/* 3798 */     if (i == 125) {
/* 3799 */       _closeObjectScope();
/* 3800 */       return this._currToken = JsonToken.END_OBJECT;
/*      */     }
/* 3802 */     _closeArrayScope();
/* 3803 */     return this._currToken = JsonToken.END_ARRAY;
/*      */   }
/*      */   
/*      */   private final void _closeArrayScope() throws JsonParseException {
/* 3807 */     _updateLocation();
/* 3808 */     if (!this._parsingContext.inArray()) {
/* 3809 */       _reportMismatchedEndMarker(93, '}');
/*      */     }
/* 3811 */     this._parsingContext = this._parsingContext.clearAndGetParent();
/*      */   }
/*      */   
/*      */   private final void _closeObjectScope() throws JsonParseException {
/* 3815 */     _updateLocation();
/* 3816 */     if (!this._parsingContext.inObject()) {
/* 3817 */       _reportMismatchedEndMarker(125, ']');
/*      */     }
/* 3819 */     this._parsingContext = this._parsingContext.clearAndGetParent();
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\json\UTF8StreamJsonParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */