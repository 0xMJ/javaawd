/*     */ package com.fasterxml.jackson.core.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerationException;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonWriteContext
/*     */   extends JsonStreamContext
/*     */ {
/*     */   public static final int STATUS_OK_AS_IS = 0;
/*     */   public static final int STATUS_OK_AFTER_COMMA = 1;
/*     */   public static final int STATUS_OK_AFTER_COLON = 2;
/*     */   public static final int STATUS_OK_AFTER_SPACE = 3;
/*     */   public static final int STATUS_EXPECT_VALUE = 4;
/*     */   public static final int STATUS_EXPECT_NAME = 5;
/*     */   protected final JsonWriteContext _parent;
/*     */   protected DupDetector _dups;
/*     */   protected JsonWriteContext _child;
/*     */   protected String _currentName;
/*     */   protected Object _currentValue;
/*     */   protected boolean _gotName;
/*     */   
/*     */   protected JsonWriteContext(int type, JsonWriteContext parent, DupDetector dups)
/*     */   {
/*  70 */     this._type = type;
/*  71 */     this._parent = parent;
/*  72 */     this._dups = dups;
/*  73 */     this._index = -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected JsonWriteContext(int type, JsonWriteContext parent, DupDetector dups, Object currValue)
/*     */   {
/*  80 */     this._type = type;
/*  81 */     this._parent = parent;
/*  82 */     this._dups = dups;
/*  83 */     this._index = -1;
/*  84 */     this._currentValue = currValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriteContext reset(int type)
/*     */   {
/*  97 */     this._type = type;
/*  98 */     this._index = -1;
/*  99 */     this._currentName = null;
/* 100 */     this._gotName = false;
/* 101 */     this._currentValue = null;
/* 102 */     if (this._dups != null) this._dups.reset();
/* 103 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriteContext reset(int type, Object currValue)
/*     */   {
/* 118 */     this._type = type;
/* 119 */     this._index = -1;
/* 120 */     this._currentName = null;
/* 121 */     this._gotName = false;
/* 122 */     this._currentValue = currValue;
/* 123 */     if (this._dups != null) this._dups.reset();
/* 124 */     return this;
/*     */   }
/*     */   
/*     */   public JsonWriteContext withDupDetector(DupDetector dups) {
/* 128 */     this._dups = dups;
/* 129 */     return this;
/*     */   }
/*     */   
/*     */   public Object getCurrentValue()
/*     */   {
/* 134 */     return this._currentValue;
/*     */   }
/*     */   
/*     */   public void setCurrentValue(Object v)
/*     */   {
/* 139 */     this._currentValue = v;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static JsonWriteContext createRootContext()
/*     */   {
/* 152 */     return createRootContext(null);
/*     */   }
/*     */   
/* 155 */   public static JsonWriteContext createRootContext(DupDetector dd) { return new JsonWriteContext(0, null, dd); }
/*     */   
/*     */   public JsonWriteContext createChildArrayContext()
/*     */   {
/* 159 */     JsonWriteContext ctxt = this._child;
/* 160 */     if (ctxt == null)
/*     */     {
/* 162 */       this._child = (ctxt = new JsonWriteContext(1, this, this._dups == null ? null : this._dups.child()));
/* 163 */       return ctxt;
/*     */     }
/* 165 */     return ctxt.reset(1);
/*     */   }
/*     */   
/*     */   public JsonWriteContext createChildArrayContext(Object currValue)
/*     */   {
/* 170 */     JsonWriteContext ctxt = this._child;
/* 171 */     if (ctxt == null)
/*     */     {
/* 173 */       this._child = (ctxt = new JsonWriteContext(1, this, this._dups == null ? null : this._dups.child(), currValue));
/* 174 */       return ctxt;
/*     */     }
/* 176 */     return ctxt.reset(1, currValue);
/*     */   }
/*     */   
/*     */   public JsonWriteContext createChildObjectContext() {
/* 180 */     JsonWriteContext ctxt = this._child;
/* 181 */     if (ctxt == null)
/*     */     {
/* 183 */       this._child = (ctxt = new JsonWriteContext(2, this, this._dups == null ? null : this._dups.child()));
/* 184 */       return ctxt;
/*     */     }
/* 186 */     return ctxt.reset(2);
/*     */   }
/*     */   
/*     */   public JsonWriteContext createChildObjectContext(Object currValue)
/*     */   {
/* 191 */     JsonWriteContext ctxt = this._child;
/* 192 */     if (ctxt == null)
/*     */     {
/* 194 */       this._child = (ctxt = new JsonWriteContext(2, this, this._dups == null ? null : this._dups.child(), currValue));
/* 195 */       return ctxt;
/*     */     }
/* 197 */     return ctxt.reset(2, currValue);
/*     */   }
/*     */   
/* 200 */   public final JsonWriteContext getParent() { return this._parent; }
/* 201 */   public final String getCurrentName() { return this._currentName; }
/*     */   
/* 203 */   public boolean hasCurrentName() { return this._currentName != null; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriteContext clearAndGetParent()
/*     */   {
/* 216 */     this._currentValue = null;
/*     */     
/* 218 */     return this._parent;
/*     */   }
/*     */   
/*     */   public DupDetector getDupDetector() {
/* 222 */     return this._dups;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int writeFieldName(String name)
/*     */     throws JsonProcessingException
/*     */   {
/* 231 */     if ((this._type != 2) || (this._gotName)) {
/* 232 */       return 4;
/*     */     }
/* 234 */     this._gotName = true;
/* 235 */     this._currentName = name;
/* 236 */     if (this._dups != null) _checkDup(this._dups, name);
/* 237 */     return this._index < 0 ? 0 : 1;
/*     */   }
/*     */   
/*     */   private final void _checkDup(DupDetector dd, String name) throws JsonProcessingException {
/* 241 */     if (dd.isDup(name)) {
/* 242 */       Object src = dd.getSource();
/* 243 */       throw new JsonGenerationException("Duplicate field '" + name + "'", (src instanceof JsonGenerator) ? (JsonGenerator)src : null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int writeValue()
/*     */   {
/* 250 */     if (this._type == 2) {
/* 251 */       if (!this._gotName) {
/* 252 */         return 5;
/*     */       }
/* 254 */       this._gotName = false;
/* 255 */       this._index += 1;
/* 256 */       return 2;
/*     */     }
/*     */     
/*     */ 
/* 260 */     if (this._type == 1) {
/* 261 */       int ix = this._index;
/* 262 */       this._index += 1;
/* 263 */       return ix < 0 ? 0 : 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 268 */     this._index += 1;
/* 269 */     return this._index == 0 ? 0 : 3;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\json\JsonWriteContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */