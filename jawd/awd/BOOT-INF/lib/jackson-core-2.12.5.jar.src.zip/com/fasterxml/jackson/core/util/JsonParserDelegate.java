/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.FormatSchema;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*     */ import com.fasterxml.jackson.core.JsonParser.NumberType;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ public class JsonParserDelegate extends JsonParser
/*     */ {
/*     */   protected JsonParser delegate;
/*     */   
/*     */   public JsonParserDelegate(JsonParser d)
/*     */   {
/*  26 */     this.delegate = d;
/*     */   }
/*     */   
/*     */   public Object getCurrentValue()
/*     */   {
/*  31 */     return this.delegate.getCurrentValue();
/*     */   }
/*     */   
/*     */   public void setCurrentValue(Object v)
/*     */   {
/*  36 */     this.delegate.setCurrentValue(v);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  45 */   public void setCodec(ObjectCodec c) { this.delegate.setCodec(c); }
/*  46 */   public ObjectCodec getCodec() { return this.delegate.getCodec(); }
/*     */   
/*     */   public JsonParser enable(JsonParser.Feature f)
/*     */   {
/*  50 */     this.delegate.enable(f);
/*  51 */     return this;
/*     */   }
/*     */   
/*     */   public JsonParser disable(JsonParser.Feature f)
/*     */   {
/*  56 */     this.delegate.disable(f);
/*  57 */     return this;
/*     */   }
/*     */   
/*  60 */   public boolean isEnabled(JsonParser.Feature f) { return this.delegate.isEnabled(f); }
/*  61 */   public int getFeatureMask() { return this.delegate.getFeatureMask(); }
/*     */   
/*     */   @Deprecated
/*     */   public JsonParser setFeatureMask(int mask)
/*     */   {
/*  66 */     this.delegate.setFeatureMask(mask);
/*  67 */     return this;
/*     */   }
/*     */   
/*     */   public JsonParser overrideStdFeatures(int values, int mask)
/*     */   {
/*  72 */     this.delegate.overrideStdFeatures(values, mask);
/*  73 */     return this;
/*     */   }
/*     */   
/*     */   public JsonParser overrideFormatFeatures(int values, int mask)
/*     */   {
/*  78 */     this.delegate.overrideFormatFeatures(values, mask);
/*  79 */     return this;
/*     */   }
/*     */   
/*  82 */   public FormatSchema getSchema() { return this.delegate.getSchema(); }
/*  83 */   public void setSchema(FormatSchema schema) { this.delegate.setSchema(schema); }
/*  84 */   public boolean canUseSchema(FormatSchema schema) { return this.delegate.canUseSchema(schema); }
/*  85 */   public Version version() { return this.delegate.version(); }
/*  86 */   public Object getInputSource() { return this.delegate.getInputSource(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */   public boolean requiresCustomCodec() { return this.delegate.requiresCustomCodec(); }
/*     */   
/*  96 */   public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() { return this.delegate.getReadCapabilities(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */   public void close()
/* 104 */     throws IOException { this.delegate.close(); }
/* 105 */   public boolean isClosed() { return this.delegate.isClosed(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */   public JsonToken currentToken() { return this.delegate.currentToken(); }
/* 114 */   public int currentTokenId() { return this.delegate.currentTokenId(); }
/*     */   
/* 116 */   public JsonToken getCurrentToken() { return this.delegate.getCurrentToken(); }
/*     */   
/*     */   @Deprecated
/* 119 */   public int getCurrentTokenId() { return this.delegate.getCurrentTokenId(); }
/*     */   
/* 121 */   public boolean hasCurrentToken() { return this.delegate.hasCurrentToken(); }
/* 122 */   public boolean hasTokenId(int id) { return this.delegate.hasTokenId(id); }
/* 123 */   public boolean hasToken(JsonToken t) { return this.delegate.hasToken(t); }
/*     */   
/* 125 */   public String getCurrentName() throws IOException { return this.delegate.getCurrentName(); }
/* 126 */   public JsonLocation getCurrentLocation() { return this.delegate.getCurrentLocation(); }
/* 127 */   public JsonStreamContext getParsingContext() { return this.delegate.getParsingContext(); }
/* 128 */   public boolean isExpectedStartArrayToken() { return this.delegate.isExpectedStartArrayToken(); }
/* 129 */   public boolean isExpectedStartObjectToken() { return this.delegate.isExpectedStartObjectToken(); }
/* 130 */   public boolean isExpectedNumberIntToken() { return this.delegate.isExpectedNumberIntToken(); }
/*     */   
/* 132 */   public boolean isNaN() throws IOException { return this.delegate.isNaN(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 140 */   public void clearCurrentToken() { this.delegate.clearCurrentToken(); }
/* 141 */   public JsonToken getLastClearedToken() { return this.delegate.getLastClearedToken(); }
/* 142 */   public void overrideCurrentName(String name) { this.delegate.overrideCurrentName(name); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 150 */   public String getText()
/* 150 */     throws IOException { return this.delegate.getText(); }
/* 151 */   public boolean hasTextCharacters() { return this.delegate.hasTextCharacters(); }
/* 152 */   public char[] getTextCharacters() throws IOException { return this.delegate.getTextCharacters(); }
/* 153 */   public int getTextLength() throws IOException { return this.delegate.getTextLength(); }
/* 154 */   public int getTextOffset() throws IOException { return this.delegate.getTextOffset(); }
/* 155 */   public int getText(Writer writer) throws IOException, UnsupportedOperationException { return this.delegate.getText(writer); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BigInteger getBigIntegerValue()
/*     */     throws IOException
/*     */   {
/* 164 */     return this.delegate.getBigIntegerValue();
/*     */   }
/*     */   
/* 167 */   public boolean getBooleanValue() throws IOException { return this.delegate.getBooleanValue(); }
/*     */   
/*     */   public byte getByteValue() throws IOException {
/* 170 */     return this.delegate.getByteValue();
/*     */   }
/*     */   
/* 173 */   public short getShortValue() throws IOException { return this.delegate.getShortValue(); }
/*     */   
/*     */   public BigDecimal getDecimalValue() throws IOException {
/* 176 */     return this.delegate.getDecimalValue();
/*     */   }
/*     */   
/* 179 */   public double getDoubleValue() throws IOException { return this.delegate.getDoubleValue(); }
/*     */   
/*     */   public float getFloatValue() throws IOException {
/* 182 */     return this.delegate.getFloatValue();
/*     */   }
/*     */   
/* 185 */   public int getIntValue() throws IOException { return this.delegate.getIntValue(); }
/*     */   
/*     */   public long getLongValue() throws IOException {
/* 188 */     return this.delegate.getLongValue();
/*     */   }
/*     */   
/* 191 */   public JsonParser.NumberType getNumberType() throws IOException { return this.delegate.getNumberType(); }
/*     */   
/*     */   public Number getNumberValue() throws IOException {
/* 194 */     return this.delegate.getNumberValue();
/*     */   }
/*     */   
/* 197 */   public Number getNumberValueExact() throws IOException { return this.delegate.getNumberValueExact(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 205 */   public int getValueAsInt()
/* 205 */     throws IOException { return this.delegate.getValueAsInt(); }
/* 206 */   public int getValueAsInt(int defaultValue) throws IOException { return this.delegate.getValueAsInt(defaultValue); }
/* 207 */   public long getValueAsLong() throws IOException { return this.delegate.getValueAsLong(); }
/* 208 */   public long getValueAsLong(long defaultValue) throws IOException { return this.delegate.getValueAsLong(defaultValue); }
/* 209 */   public double getValueAsDouble() throws IOException { return this.delegate.getValueAsDouble(); }
/* 210 */   public double getValueAsDouble(double defaultValue) throws IOException { return this.delegate.getValueAsDouble(defaultValue); }
/* 211 */   public boolean getValueAsBoolean() throws IOException { return this.delegate.getValueAsBoolean(); }
/* 212 */   public boolean getValueAsBoolean(boolean defaultValue) throws IOException { return this.delegate.getValueAsBoolean(defaultValue); }
/* 213 */   public String getValueAsString() throws IOException { return this.delegate.getValueAsString(); }
/* 214 */   public String getValueAsString(String defaultValue) throws IOException { return this.delegate.getValueAsString(defaultValue); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 222 */   public Object getEmbeddedObject()
/* 222 */     throws IOException { return this.delegate.getEmbeddedObject(); }
/* 223 */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException { return this.delegate.getBinaryValue(b64variant); }
/* 224 */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException { return this.delegate.readBinaryValue(b64variant, out); }
/* 225 */   public JsonLocation getTokenLocation() { return this.delegate.getTokenLocation(); }
/*     */   
/* 227 */   public JsonToken nextToken() throws IOException { return this.delegate.nextToken(); }
/*     */   
/* 229 */   public JsonToken nextValue() throws IOException { return this.delegate.nextValue(); }
/*     */   
/* 231 */   public void finishToken() throws IOException { this.delegate.finishToken(); }
/*     */   
/*     */   public JsonParser skipChildren() throws IOException
/*     */   {
/* 235 */     this.delegate.skipChildren();
/*     */     
/* 237 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 246 */   public boolean canReadObjectId() { return this.delegate.canReadObjectId(); }
/* 247 */   public boolean canReadTypeId() { return this.delegate.canReadTypeId(); }
/* 248 */   public Object getObjectId() throws IOException { return this.delegate.getObjectId(); }
/* 249 */   public Object getTypeId() throws IOException { return this.delegate.getTypeId(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonParser delegate()
/*     */   {
/* 264 */     return this.delegate;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\util\JsonParserDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */