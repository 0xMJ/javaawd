/*     */ package com.fasterxml.jackson.core.json.async;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParseException;
/*     */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.core.base.ParserBase;
/*     */ import com.fasterxml.jackson.core.io.IOContext;
/*     */ import com.fasterxml.jackson.core.json.JsonReadContext;
/*     */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*     */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*     */ import com.fasterxml.jackson.core.util.TextBuffer;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NonBlockingJsonParserBase
/*     */   extends ParserBase
/*     */ {
/*     */   protected static final int MAJOR_INITIAL = 0;
/*     */   protected static final int MAJOR_ROOT = 1;
/*     */   protected static final int MAJOR_OBJECT_FIELD_FIRST = 2;
/*     */   protected static final int MAJOR_OBJECT_FIELD_NEXT = 3;
/*     */   protected static final int MAJOR_OBJECT_VALUE = 4;
/*     */   protected static final int MAJOR_ARRAY_ELEMENT_FIRST = 5;
/*     */   protected static final int MAJOR_ARRAY_ELEMENT_NEXT = 6;
/*     */   protected static final int MAJOR_CLOSED = 7;
/*     */   protected static final int MINOR_ROOT_BOM = 1;
/*     */   protected static final int MINOR_ROOT_NEED_SEPARATOR = 2;
/*     */   protected static final int MINOR_ROOT_GOT_SEPARATOR = 3;
/*     */   protected static final int MINOR_FIELD_LEADING_WS = 4;
/*     */   protected static final int MINOR_FIELD_LEADING_COMMA = 5;
/*     */   protected static final int MINOR_FIELD_NAME = 7;
/*     */   protected static final int MINOR_FIELD_NAME_ESCAPE = 8;
/*     */   protected static final int MINOR_FIELD_APOS_NAME = 9;
/*     */   protected static final int MINOR_FIELD_UNQUOTED_NAME = 10;
/*     */   protected static final int MINOR_VALUE_LEADING_WS = 12;
/*     */   protected static final int MINOR_VALUE_EXPECTING_COMMA = 13;
/*     */   protected static final int MINOR_VALUE_EXPECTING_COLON = 14;
/*     */   protected static final int MINOR_VALUE_WS_AFTER_COMMA = 15;
/*     */   protected static final int MINOR_VALUE_TOKEN_NULL = 16;
/*     */   protected static final int MINOR_VALUE_TOKEN_TRUE = 17;
/*     */   protected static final int MINOR_VALUE_TOKEN_FALSE = 18;
/*     */   protected static final int MINOR_VALUE_TOKEN_NON_STD = 19;
/*     */   protected static final int MINOR_NUMBER_MINUS = 23;
/*     */   protected static final int MINOR_NUMBER_ZERO = 24;
/*     */   protected static final int MINOR_NUMBER_MINUSZERO = 25;
/*     */   protected static final int MINOR_NUMBER_INTEGER_DIGITS = 26;
/*     */   protected static final int MINOR_NUMBER_FRACTION_DIGITS = 30;
/*     */   protected static final int MINOR_NUMBER_EXPONENT_MARKER = 31;
/*     */   protected static final int MINOR_NUMBER_EXPONENT_DIGITS = 32;
/*     */   protected static final int MINOR_VALUE_STRING = 40;
/*     */   protected static final int MINOR_VALUE_STRING_ESCAPE = 41;
/*     */   protected static final int MINOR_VALUE_STRING_UTF8_2 = 42;
/*     */   protected static final int MINOR_VALUE_STRING_UTF8_3 = 43;
/*     */   protected static final int MINOR_VALUE_STRING_UTF8_4 = 44;
/*     */   protected static final int MINOR_VALUE_APOS_STRING = 45;
/*     */   protected static final int MINOR_VALUE_TOKEN_ERROR = 50;
/*     */   protected static final int MINOR_COMMENT_LEADING_SLASH = 51;
/*     */   protected static final int MINOR_COMMENT_CLOSING_ASTERISK = 52;
/*     */   protected static final int MINOR_COMMENT_C = 53;
/*     */   protected static final int MINOR_COMMENT_CPP = 54;
/*     */   protected static final int MINOR_COMMENT_YAML = 55;
/*     */   protected final ByteQuadsCanonicalizer _symbols;
/* 147 */   protected int[] _quadBuffer = new int[8];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int _quadLength;
/*     */   
/*     */ 
/*     */ 
/*     */   protected int _quad1;
/*     */   
/*     */ 
/*     */ 
/*     */   protected int _pending32;
/*     */   
/*     */ 
/*     */ 
/*     */   protected int _pendingBytes;
/*     */   
/*     */ 
/*     */ 
/*     */   protected int _quoted32;
/*     */   
/*     */ 
/*     */ 
/*     */   protected int _quotedDigits;
/*     */   
/*     */ 
/*     */ 
/*     */   protected int _majorState;
/*     */   
/*     */ 
/*     */ 
/*     */   protected int _majorStateAfterValue;
/*     */   
/*     */ 
/*     */ 
/*     */   protected int _minorState;
/*     */   
/*     */ 
/*     */ 
/*     */   protected int _minorStateAfterSplit;
/*     */   
/*     */ 
/*     */ 
/* 192 */   protected boolean _endOfInput = false;
/*     */   
/*     */ 
/*     */   protected static final int NON_STD_TOKEN_NAN = 0;
/*     */   
/*     */ 
/*     */   protected static final int NON_STD_TOKEN_INFINITY = 1;
/*     */   
/*     */ 
/*     */   protected static final int NON_STD_TOKEN_PLUS_INFINITY = 2;
/*     */   
/*     */ 
/*     */   protected static final int NON_STD_TOKEN_MINUS_INFINITY = 3;
/*     */   
/* 206 */   protected static final String[] NON_STD_TOKENS = { "NaN", "Infinity", "+Infinity", "-Infinity" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 211 */   protected static final double[] NON_STD_TOKEN_VALUES = { NaN.0D, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int _nonStdTokenType;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */   protected int _currBufferStart = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 242 */   protected int _currInputRowAlt = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NonBlockingJsonParserBase(IOContext ctxt, int parserFeatures, ByteQuadsCanonicalizer sym)
/*     */   {
/* 253 */     super(ctxt, parserFeatures);
/* 254 */     this._symbols = sym;
/* 255 */     this._currToken = null;
/* 256 */     this._majorState = 0;
/* 257 */     this._majorStateAfterValue = 1;
/*     */   }
/*     */   
/*     */   public ObjectCodec getCodec()
/*     */   {
/* 262 */     return null;
/*     */   }
/*     */   
/*     */   public void setCodec(ObjectCodec c)
/*     */   {
/* 267 */     throw new UnsupportedOperationException("Can not use ObjectMapper with non-blocking parser");
/*     */   }
/*     */   
/*     */   public boolean canParseAsync() {
/* 271 */     return true;
/*     */   }
/*     */   
/*     */   public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/* 275 */     return JSON_READ_CAPABILITIES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ByteQuadsCanonicalizer symbolTableForTests()
/*     */   {
/* 285 */     return this._symbols;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int releaseBuffered(OutputStream paramOutputStream)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void _releaseBuffers()
/*     */     throws IOException
/*     */   {
/* 300 */     super._releaseBuffers();
/*     */     
/* 302 */     this._symbols.release();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getInputSource()
/*     */   {
/* 309 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void _closeInput()
/*     */     throws IOException
/*     */   {
/* 317 */     this._currBufferStart = 0;
/* 318 */     this._inputEnd = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasTextCharacters()
/*     */   {
/* 330 */     if (this._currToken == JsonToken.VALUE_STRING)
/*     */     {
/* 332 */       return this._textBuffer.hasTextAsCharacters();
/*     */     }
/* 334 */     if (this._currToken == JsonToken.FIELD_NAME)
/*     */     {
/* 336 */       return this._nameCopied;
/*     */     }
/*     */     
/* 339 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public JsonLocation getCurrentLocation()
/*     */   {
/* 345 */     int col = this._inputPtr - this._currInputRowStart + 1;
/*     */     
/* 347 */     int row = Math.max(this._currInputRow, this._currInputRowAlt);
/* 348 */     return new JsonLocation(_getSourceReference(), this._currInputProcessed + (this._inputPtr - this._currBufferStart), -1L, row, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonLocation getTokenLocation()
/*     */   {
/* 356 */     return new JsonLocation(_getSourceReference(), this._tokenInputTotal, -1L, this._tokenInputRow, this._tokenInputCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */     throws IOException
/*     */   {
/* 375 */     if (this._currToken == JsonToken.VALUE_STRING) {
/* 376 */       return this._textBuffer.contentsAsString();
/*     */     }
/* 378 */     return _getText2(this._currToken);
/*     */   }
/*     */   
/*     */   protected final String _getText2(JsonToken t)
/*     */   {
/* 383 */     if (t == null) {
/* 384 */       return null;
/*     */     }
/* 386 */     switch (t.id()) {
/*     */     case -1: 
/* 388 */       return null;
/*     */     case 5: 
/* 390 */       return this._parsingContext.getCurrentName();
/*     */     
/*     */     case 6: 
/*     */     case 7: 
/*     */     case 8: 
/* 395 */       return this._textBuffer.contentsAsString();
/*     */     }
/* 397 */     return t.asString();
/*     */   }
/*     */   
/*     */ 
/*     */   public int getText(Writer writer)
/*     */     throws IOException
/*     */   {
/* 404 */     JsonToken t = this._currToken;
/* 405 */     if (t == JsonToken.VALUE_STRING) {
/* 406 */       return this._textBuffer.contentsToWriter(writer);
/*     */     }
/* 408 */     if (t == JsonToken.FIELD_NAME) {
/* 409 */       String n = this._parsingContext.getCurrentName();
/* 410 */       writer.write(n);
/* 411 */       return n.length();
/*     */     }
/* 413 */     if (t != null) {
/* 414 */       if (t.isNumeric()) {
/* 415 */         return this._textBuffer.contentsToWriter(writer);
/*     */       }
/* 417 */       if (t == JsonToken.NOT_AVAILABLE) {
/* 418 */         _reportError("Current token not available: can not call this method");
/*     */       }
/* 420 */       char[] ch = t.asCharArray();
/* 421 */       writer.write(ch);
/* 422 */       return ch.length;
/*     */     }
/* 424 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValueAsString()
/*     */     throws IOException
/*     */   {
/* 433 */     if (this._currToken == JsonToken.VALUE_STRING) {
/* 434 */       return this._textBuffer.contentsAsString();
/*     */     }
/* 436 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 437 */       return getCurrentName();
/*     */     }
/* 439 */     return super.getValueAsString(null);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getValueAsString(String defValue)
/*     */     throws IOException
/*     */   {
/* 446 */     if (this._currToken == JsonToken.VALUE_STRING) {
/* 447 */       return this._textBuffer.contentsAsString();
/*     */     }
/* 449 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 450 */       return getCurrentName();
/*     */     }
/* 452 */     return super.getValueAsString(defValue);
/*     */   }
/*     */   
/*     */   public char[] getTextCharacters()
/*     */     throws IOException
/*     */   {
/* 458 */     if (this._currToken != null) {
/* 459 */       switch (this._currToken.id())
/*     */       {
/*     */       case 5: 
/* 462 */         if (!this._nameCopied) {
/* 463 */           String name = this._parsingContext.getCurrentName();
/* 464 */           int nameLen = name.length();
/* 465 */           if (this._nameCopyBuffer == null) {
/* 466 */             this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/* 467 */           } else if (this._nameCopyBuffer.length < nameLen) {
/* 468 */             this._nameCopyBuffer = new char[nameLen];
/*     */           }
/* 470 */           name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/* 471 */           this._nameCopied = true;
/*     */         }
/* 473 */         return this._nameCopyBuffer;
/*     */       
/*     */ 
/*     */       case 6: 
/*     */       case 7: 
/*     */       case 8: 
/* 479 */         return this._textBuffer.getTextBuffer();
/*     */       }
/*     */       
/* 482 */       return this._currToken.asCharArray();
/*     */     }
/*     */     
/* 485 */     return null;
/*     */   }
/*     */   
/*     */   public int getTextLength()
/*     */     throws IOException
/*     */   {
/* 491 */     if (this._currToken != null) {
/* 492 */       switch (this._currToken.id())
/*     */       {
/*     */       case 5: 
/* 495 */         return this._parsingContext.getCurrentName().length();
/*     */       
/*     */       case 6: 
/*     */       case 7: 
/*     */       case 8: 
/* 500 */         return this._textBuffer.size();
/*     */       }
/*     */       
/* 503 */       return this._currToken.asCharArray().length;
/*     */     }
/*     */     
/* 506 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getTextOffset()
/*     */     throws IOException
/*     */   {
/* 513 */     if (this._currToken != null) {
/* 514 */       switch (this._currToken.id()) {
/*     */       case 5: 
/* 516 */         return 0;
/*     */       
/*     */       case 6: 
/*     */       case 7: 
/*     */       case 8: 
/* 521 */         return this._textBuffer.getTextOffset();
/*     */       }
/*     */       
/*     */     }
/* 525 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBinaryValue(Base64Variant b64variant)
/*     */     throws IOException
/*     */   {
/* 537 */     if (this._currToken != JsonToken.VALUE_STRING) {
/* 538 */       _reportError("Current token (%s) not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary", this._currToken);
/*     */     }
/*     */     
/* 541 */     if (this._binaryValue == null)
/*     */     {
/* 543 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/* 544 */       _decodeBase64(getText(), builder, b64variant);
/* 545 */       this._binaryValue = builder.toByteArray();
/*     */     }
/* 547 */     return this._binaryValue;
/*     */   }
/*     */   
/*     */   public int readBinaryValue(Base64Variant b64variant, OutputStream out)
/*     */     throws IOException
/*     */   {
/* 553 */     byte[] b = getBinaryValue(b64variant);
/* 554 */     out.write(b);
/* 555 */     return b.length;
/*     */   }
/*     */   
/*     */   public Object getEmbeddedObject()
/*     */     throws IOException
/*     */   {
/* 561 */     if (this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT) {
/* 562 */       return this._binaryValue;
/*     */     }
/* 564 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final JsonToken _startArrayScope()
/*     */     throws IOException
/*     */   {
/* 575 */     this._parsingContext = this._parsingContext.createChildArrayContext(-1, -1);
/* 576 */     this._majorState = 5;
/* 577 */     this._majorStateAfterValue = 6;
/* 578 */     return this._currToken = JsonToken.START_ARRAY;
/*     */   }
/*     */   
/*     */   protected final JsonToken _startObjectScope() throws IOException
/*     */   {
/* 583 */     this._parsingContext = this._parsingContext.createChildObjectContext(-1, -1);
/* 584 */     this._majorState = 2;
/* 585 */     this._majorStateAfterValue = 3;
/* 586 */     return this._currToken = JsonToken.START_OBJECT;
/*     */   }
/*     */   
/*     */   protected final JsonToken _closeArrayScope() throws IOException
/*     */   {
/* 591 */     if (!this._parsingContext.inArray()) {
/* 592 */       _reportMismatchedEndMarker(93, '}');
/*     */     }
/* 594 */     JsonReadContext ctxt = this._parsingContext.getParent();
/* 595 */     this._parsingContext = ctxt;
/*     */     int st;
/* 597 */     int st; if (ctxt.inObject()) {
/* 598 */       st = 3; } else { int st;
/* 599 */       if (ctxt.inArray()) {
/* 600 */         st = 6;
/*     */       } else
/* 602 */         st = 1;
/*     */     }
/* 604 */     this._majorState = st;
/* 605 */     this._majorStateAfterValue = st;
/* 606 */     return this._currToken = JsonToken.END_ARRAY;
/*     */   }
/*     */   
/*     */   protected final JsonToken _closeObjectScope() throws IOException
/*     */   {
/* 611 */     if (!this._parsingContext.inObject()) {
/* 612 */       _reportMismatchedEndMarker(125, ']');
/*     */     }
/* 614 */     JsonReadContext ctxt = this._parsingContext.getParent();
/* 615 */     this._parsingContext = ctxt;
/*     */     int st;
/* 617 */     int st; if (ctxt.inObject()) {
/* 618 */       st = 3; } else { int st;
/* 619 */       if (ctxt.inArray()) {
/* 620 */         st = 6;
/*     */       } else
/* 622 */         st = 1;
/*     */     }
/* 624 */     this._majorState = st;
/* 625 */     this._majorStateAfterValue = st;
/* 626 */     return this._currToken = JsonToken.END_OBJECT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String _findName(int q1, int lastQuadBytes)
/*     */     throws JsonParseException
/*     */   {
/* 637 */     q1 = _padLastQuad(q1, lastQuadBytes);
/*     */     
/* 639 */     String name = this._symbols.findName(q1);
/* 640 */     if (name != null) {
/* 641 */       return name;
/*     */     }
/*     */     
/* 644 */     this._quadBuffer[0] = q1;
/* 645 */     return _addName(this._quadBuffer, 1, lastQuadBytes);
/*     */   }
/*     */   
/*     */   protected final String _findName(int q1, int q2, int lastQuadBytes) throws JsonParseException
/*     */   {
/* 650 */     q2 = _padLastQuad(q2, lastQuadBytes);
/*     */     
/* 652 */     String name = this._symbols.findName(q1, q2);
/* 653 */     if (name != null) {
/* 654 */       return name;
/*     */     }
/*     */     
/* 657 */     this._quadBuffer[0] = q1;
/* 658 */     this._quadBuffer[1] = q2;
/* 659 */     return _addName(this._quadBuffer, 2, lastQuadBytes);
/*     */   }
/*     */   
/*     */   protected final String _findName(int q1, int q2, int q3, int lastQuadBytes) throws JsonParseException
/*     */   {
/* 664 */     q3 = _padLastQuad(q3, lastQuadBytes);
/* 665 */     String name = this._symbols.findName(q1, q2, q3);
/* 666 */     if (name != null) {
/* 667 */       return name;
/*     */     }
/* 669 */     int[] quads = this._quadBuffer;
/* 670 */     quads[0] = q1;
/* 671 */     quads[1] = q2;
/* 672 */     quads[2] = _padLastQuad(q3, lastQuadBytes);
/* 673 */     return _addName(quads, 3, lastQuadBytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String _addName(int[] quads, int qlen, int lastQuadBytes)
/*     */     throws JsonParseException
/*     */   {
/* 689 */     int byteLen = (qlen << 2) - 4 + lastQuadBytes;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     int lastQuad;
/*     */     
/*     */ 
/*     */ 
/* 698 */     if (lastQuadBytes < 4) {
/* 699 */       int lastQuad = quads[(qlen - 1)];
/*     */       
/* 701 */       quads[(qlen - 1)] = (lastQuad << (4 - lastQuadBytes << 3));
/*     */     } else {
/* 703 */       lastQuad = 0;
/*     */     }
/*     */     
/*     */ 
/* 707 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 708 */     int cix = 0;
/*     */     
/* 710 */     for (int ix = 0; ix < byteLen;) {
/* 711 */       int ch = quads[(ix >> 2)];
/* 712 */       int byteIx = ix & 0x3;
/* 713 */       ch = ch >> (3 - byteIx << 3) & 0xFF;
/* 714 */       ix++;
/*     */       
/* 716 */       if (ch > 127) { int needed;
/*     */         int needed;
/* 718 */         if ((ch & 0xE0) == 192) {
/* 719 */           ch &= 0x1F;
/* 720 */           needed = 1; } else { int needed;
/* 721 */           if ((ch & 0xF0) == 224) {
/* 722 */             ch &= 0xF;
/* 723 */             needed = 2; } else { int needed;
/* 724 */             if ((ch & 0xF8) == 240) {
/* 725 */               ch &= 0x7;
/* 726 */               needed = 3;
/*     */             } else {
/* 728 */               _reportInvalidInitial(ch);
/* 729 */               needed = ch = 1;
/*     */             } } }
/* 731 */         if (ix + needed > byteLen) {
/* 732 */           _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*     */         }
/*     */         
/*     */ 
/* 736 */         int ch2 = quads[(ix >> 2)];
/* 737 */         byteIx = ix & 0x3;
/* 738 */         ch2 >>= 3 - byteIx << 3;
/* 739 */         ix++;
/*     */         
/* 741 */         if ((ch2 & 0xC0) != 128) {
/* 742 */           _reportInvalidOther(ch2);
/*     */         }
/* 744 */         ch = ch << 6 | ch2 & 0x3F;
/* 745 */         if (needed > 1) {
/* 746 */           ch2 = quads[(ix >> 2)];
/* 747 */           byteIx = ix & 0x3;
/* 748 */           ch2 >>= 3 - byteIx << 3;
/* 749 */           ix++;
/*     */           
/* 751 */           if ((ch2 & 0xC0) != 128) {
/* 752 */             _reportInvalidOther(ch2);
/*     */           }
/* 754 */           ch = ch << 6 | ch2 & 0x3F;
/* 755 */           if (needed > 2) {
/* 756 */             ch2 = quads[(ix >> 2)];
/* 757 */             byteIx = ix & 0x3;
/* 758 */             ch2 >>= 3 - byteIx << 3;
/* 759 */             ix++;
/* 760 */             if ((ch2 & 0xC0) != 128) {
/* 761 */               _reportInvalidOther(ch2 & 0xFF);
/*     */             }
/* 763 */             ch = ch << 6 | ch2 & 0x3F;
/*     */           }
/*     */         }
/* 766 */         if (needed > 2) {
/* 767 */           ch -= 65536;
/* 768 */           if (cix >= cbuf.length) {
/* 769 */             cbuf = this._textBuffer.expandCurrentSegment();
/*     */           }
/* 771 */           cbuf[(cix++)] = ((char)(55296 + (ch >> 10)));
/* 772 */           ch = 0xDC00 | ch & 0x3FF;
/*     */         }
/*     */       }
/* 775 */       if (cix >= cbuf.length) {
/* 776 */         cbuf = this._textBuffer.expandCurrentSegment();
/*     */       }
/* 778 */       cbuf[(cix++)] = ((char)ch);
/*     */     }
/*     */     
/*     */ 
/* 782 */     String baseName = new String(cbuf, 0, cix);
/*     */     
/* 784 */     if (lastQuadBytes < 4) {
/* 785 */       quads[(qlen - 1)] = lastQuad;
/*     */     }
/* 787 */     return this._symbols.addName(baseName, quads, qlen);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected static final int _padLastQuad(int q, int bytes)
/*     */   {
/* 794 */     return bytes == 4 ? q : q | -1 << (bytes << 3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final JsonToken _eofAsNextToken()
/*     */     throws IOException
/*     */   {
/* 808 */     this._majorState = 7;
/* 809 */     if (!this._parsingContext.inRoot()) {
/* 810 */       _handleEOF();
/*     */     }
/* 812 */     close();
/* 813 */     return this._currToken = null;
/*     */   }
/*     */   
/*     */   protected final JsonToken _fieldComplete(String name) throws IOException
/*     */   {
/* 818 */     this._majorState = 4;
/* 819 */     this._parsingContext.setCurrentName(name);
/* 820 */     return this._currToken = JsonToken.FIELD_NAME;
/*     */   }
/*     */   
/*     */   protected final JsonToken _valueComplete(JsonToken t) throws IOException
/*     */   {
/* 825 */     this._majorState = this._majorStateAfterValue;
/* 826 */     this._currToken = t;
/* 827 */     return t;
/*     */   }
/*     */   
/*     */   protected final JsonToken _valueCompleteInt(int value, String asText) throws IOException
/*     */   {
/* 832 */     this._textBuffer.resetWithString(asText);
/* 833 */     this._intLength = asText.length();
/* 834 */     this._numTypesValid = 1;
/* 835 */     this._numberInt = value;
/* 836 */     this._majorState = this._majorStateAfterValue;
/* 837 */     JsonToken t = JsonToken.VALUE_NUMBER_INT;
/* 838 */     this._currToken = t;
/* 839 */     return t;
/*     */   }
/*     */   
/*     */   protected final JsonToken _valueNonStdNumberComplete(int type)
/*     */     throws IOException
/*     */   {
/* 845 */     String tokenStr = NON_STD_TOKENS[type];
/* 846 */     this._textBuffer.resetWithString(tokenStr);
/* 847 */     if (!isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 848 */       _reportError("Non-standard token '%s': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow", tokenStr);
/*     */     }
/*     */     
/* 851 */     this._intLength = 0;
/* 852 */     this._numTypesValid = 8;
/* 853 */     this._numberDouble = NON_STD_TOKEN_VALUES[type];
/* 854 */     this._majorState = this._majorStateAfterValue;
/* 855 */     return this._currToken = JsonToken.VALUE_NUMBER_FLOAT;
/*     */   }
/*     */   
/*     */   protected final String _nonStdToken(int type) {
/* 859 */     return NON_STD_TOKENS[type];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void _updateTokenLocation()
/*     */   {
/* 870 */     this._tokenInputRow = Math.max(this._currInputRow, this._currInputRowAlt);
/* 871 */     int ptr = this._inputPtr;
/* 872 */     this._tokenInputCol = (ptr - this._currInputRowStart);
/* 873 */     this._tokenInputTotal = (this._currInputProcessed + (ptr - this._currBufferStart));
/*     */   }
/*     */   
/*     */   protected void _reportInvalidChar(int c) throws JsonParseException
/*     */   {
/* 878 */     if (c < 32) {
/* 879 */       _throwInvalidSpace(c);
/*     */     }
/* 881 */     _reportInvalidInitial(c);
/*     */   }
/*     */   
/*     */   protected void _reportInvalidInitial(int mask) throws JsonParseException {
/* 885 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*     */   }
/*     */   
/*     */   protected void _reportInvalidOther(int mask, int ptr) throws JsonParseException {
/* 889 */     this._inputPtr = ptr;
/* 890 */     _reportInvalidOther(mask);
/*     */   }
/*     */   
/*     */   protected void _reportInvalidOther(int mask) throws JsonParseException {
/* 894 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\json\async\NonBlockingJsonParserBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */