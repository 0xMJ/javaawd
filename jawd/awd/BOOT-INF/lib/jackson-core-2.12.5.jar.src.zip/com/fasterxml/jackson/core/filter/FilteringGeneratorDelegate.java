/*      */ package com.fasterxml.jackson.core.filter;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.util.JsonGeneratorDelegate;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FilteringGeneratorDelegate
/*      */   extends JsonGeneratorDelegate
/*      */ {
/*      */   protected TokenFilter rootFilter;
/*      */   protected boolean _allowMultipleMatches;
/*      */   protected TokenFilter.Inclusion _inclusion;
/*      */   protected TokenFilterContext _filterContext;
/*      */   protected TokenFilter _itemFilter;
/*      */   protected int _matchCount;
/*      */   
/*      */   @Deprecated
/*      */   public FilteringGeneratorDelegate(JsonGenerator d, TokenFilter f, boolean includePath, boolean allowMultipleMatches)
/*      */   {
/*   92 */     this(d, f, includePath ? TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH : TokenFilter.Inclusion.ONLY_INCLUDE_ALL, allowMultipleMatches);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FilteringGeneratorDelegate(JsonGenerator d, TokenFilter f, TokenFilter.Inclusion inclusion, boolean allowMultipleMatches)
/*      */   {
/*  102 */     super(d, false);
/*  103 */     this.rootFilter = f;
/*      */     
/*  105 */     this._itemFilter = f;
/*  106 */     this._filterContext = TokenFilterContext.createRootContext(f);
/*  107 */     this._inclusion = inclusion;
/*  108 */     this._allowMultipleMatches = allowMultipleMatches;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TokenFilter getFilter()
/*      */   {
/*  117 */     return this.rootFilter;
/*      */   }
/*      */   
/*  120 */   public JsonStreamContext getFilterContext() { return this._filterContext; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMatchCount()
/*      */   {
/*  128 */     return this._matchCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonStreamContext getOutputContext()
/*      */   {
/*  143 */     return this._filterContext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeStartArray()
/*      */     throws IOException
/*      */   {
/*  156 */     if (this._itemFilter == null) {
/*  157 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*  158 */       return;
/*      */     }
/*  160 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  161 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  162 */       this.delegate.writeStartArray();
/*  163 */       return;
/*      */     }
/*      */     
/*  166 */     this._itemFilter = this._filterContext.checkValue(this._itemFilter);
/*  167 */     if (this._itemFilter == null) {
/*  168 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*  169 */       return;
/*      */     }
/*  171 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  172 */       this._itemFilter = this._itemFilter.filterStartArray();
/*      */     }
/*  174 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  175 */       _checkParentPath();
/*  176 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  177 */       this.delegate.writeStartArray();
/*  178 */     } else if ((this._itemFilter != null) && (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL)) {
/*  179 */       _checkParentPath(false);
/*  180 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  181 */       this.delegate.writeStartArray();
/*      */     } else {
/*  183 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeStartArray(int size)
/*      */     throws IOException
/*      */   {
/*  191 */     if (this._itemFilter == null) {
/*  192 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*  193 */       return;
/*      */     }
/*  195 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  196 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  197 */       this.delegate.writeStartArray(size);
/*  198 */       return;
/*      */     }
/*  200 */     this._itemFilter = this._filterContext.checkValue(this._itemFilter);
/*  201 */     if (this._itemFilter == null) {
/*  202 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*  203 */       return;
/*      */     }
/*  205 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  206 */       this._itemFilter = this._itemFilter.filterStartArray();
/*      */     }
/*  208 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  209 */       _checkParentPath();
/*  210 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  211 */       this.delegate.writeStartArray(size);
/*  212 */     } else if ((this._itemFilter != null) && (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL)) {
/*  213 */       _checkParentPath(false);
/*  214 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  215 */       this.delegate.writeStartArray(size);
/*      */     } else {
/*  217 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, false);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeStartArray(Object forValue)
/*      */     throws IOException
/*      */   {
/*  224 */     if (this._itemFilter == null) {
/*  225 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*  226 */       return;
/*      */     }
/*  228 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  229 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  230 */       this.delegate.writeStartArray(forValue);
/*  231 */       return;
/*      */     }
/*  233 */     this._itemFilter = this._filterContext.checkValue(this._itemFilter);
/*  234 */     if (this._itemFilter == null) {
/*  235 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*  236 */       return;
/*      */     }
/*  238 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  239 */       this._itemFilter = this._itemFilter.filterStartArray();
/*      */     }
/*  241 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  242 */       _checkParentPath();
/*  243 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  244 */       this.delegate.writeStartArray(forValue);
/*      */     } else {
/*  246 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, false);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeStartArray(Object forValue, int size)
/*      */     throws IOException
/*      */   {
/*  253 */     if (this._itemFilter == null) {
/*  254 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*  255 */       return;
/*      */     }
/*  257 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  258 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  259 */       this.delegate.writeStartArray(forValue, size);
/*  260 */       return;
/*      */     }
/*  262 */     this._itemFilter = this._filterContext.checkValue(this._itemFilter);
/*  263 */     if (this._itemFilter == null) {
/*  264 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*  265 */       return;
/*      */     }
/*  267 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  268 */       this._itemFilter = this._itemFilter.filterStartArray();
/*      */     }
/*  270 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  271 */       _checkParentPath();
/*  272 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  273 */       this.delegate.writeStartArray(forValue, size);
/*      */     } else {
/*  275 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, false);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeEndArray()
/*      */     throws IOException
/*      */   {
/*  282 */     this._filterContext = this._filterContext.closeArray(this.delegate);
/*      */     
/*  284 */     if (this._filterContext != null) {
/*  285 */       this._itemFilter = this._filterContext.getFilter();
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeStartObject()
/*      */     throws IOException
/*      */   {
/*  292 */     if (this._itemFilter == null) {
/*  293 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, false);
/*  294 */       return;
/*      */     }
/*  296 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  297 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, true);
/*  298 */       this.delegate.writeStartObject();
/*  299 */       return;
/*      */     }
/*      */     
/*  302 */     TokenFilter f = this._filterContext.checkValue(this._itemFilter);
/*  303 */     if (f == null) {
/*  304 */       return;
/*      */     }
/*      */     
/*  307 */     if (f != TokenFilter.INCLUDE_ALL) {
/*  308 */       f = f.filterStartObject();
/*      */     }
/*  310 */     if (f == TokenFilter.INCLUDE_ALL) {
/*  311 */       _checkParentPath();
/*  312 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  313 */       this.delegate.writeStartObject();
/*  314 */     } else if ((f != null) && (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL)) {
/*  315 */       _checkParentPath(false);
/*  316 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  317 */       this.delegate.writeStartObject();
/*      */     } else {
/*  319 */       this._filterContext = this._filterContext.createChildObjectContext(f, false);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeStartObject(Object forValue)
/*      */     throws IOException
/*      */   {
/*  326 */     if (this._itemFilter == null) {
/*  327 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, false);
/*  328 */       return;
/*      */     }
/*  330 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  331 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, true);
/*  332 */       this.delegate.writeStartObject(forValue);
/*  333 */       return;
/*      */     }
/*      */     
/*  336 */     TokenFilter f = this._filterContext.checkValue(this._itemFilter);
/*  337 */     if (f == null) {
/*  338 */       return;
/*      */     }
/*      */     
/*  341 */     if (f != TokenFilter.INCLUDE_ALL) {
/*  342 */       f = f.filterStartObject();
/*      */     }
/*  344 */     if (f == TokenFilter.INCLUDE_ALL) {
/*  345 */       _checkParentPath();
/*  346 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  347 */       this.delegate.writeStartObject(forValue);
/*  348 */     } else if ((f != null) && (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL)) {
/*  349 */       _checkParentPath(false);
/*  350 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  351 */       this.delegate.writeStartObject(forValue);
/*      */     } else {
/*  353 */       this._filterContext = this._filterContext.createChildObjectContext(f, false);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeStartObject(Object forValue, int size)
/*      */     throws IOException
/*      */   {
/*  360 */     if (this._itemFilter == null) {
/*  361 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, false);
/*  362 */       return;
/*      */     }
/*  364 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  365 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, true);
/*  366 */       this.delegate.writeStartObject(forValue, size);
/*  367 */       return;
/*      */     }
/*      */     
/*  370 */     TokenFilter f = this._filterContext.checkValue(this._itemFilter);
/*  371 */     if (f == null) {
/*  372 */       return;
/*      */     }
/*      */     
/*  375 */     if (f != TokenFilter.INCLUDE_ALL) {
/*  376 */       f = f.filterStartObject();
/*      */     }
/*  378 */     if (f == TokenFilter.INCLUDE_ALL) {
/*  379 */       _checkParentPath();
/*  380 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  381 */       this.delegate.writeStartObject(forValue, size);
/*      */     } else {
/*  383 */       this._filterContext = this._filterContext.createChildObjectContext(f, false);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeEndObject()
/*      */     throws IOException
/*      */   {
/*  390 */     this._filterContext = this._filterContext.closeObject(this.delegate);
/*  391 */     if (this._filterContext != null) {
/*  392 */       this._itemFilter = this._filterContext.getFilter();
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeFieldName(String name)
/*      */     throws IOException
/*      */   {
/*  399 */     TokenFilter state = this._filterContext.setFieldName(name);
/*  400 */     if (state == null) {
/*  401 */       this._itemFilter = null;
/*  402 */       return;
/*      */     }
/*  404 */     if (state == TokenFilter.INCLUDE_ALL) {
/*  405 */       this._itemFilter = state;
/*  406 */       this.delegate.writeFieldName(name);
/*  407 */       return;
/*      */     }
/*  409 */     state = state.includeProperty(name);
/*  410 */     this._itemFilter = state;
/*  411 */     if (state == TokenFilter.INCLUDE_ALL) {
/*  412 */       _checkPropertyParentPath();
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeFieldName(SerializableString name)
/*      */     throws IOException
/*      */   {
/*  419 */     TokenFilter state = this._filterContext.setFieldName(name.getValue());
/*  420 */     if (state == null) {
/*  421 */       this._itemFilter = null;
/*  422 */       return;
/*      */     }
/*  424 */     if (state == TokenFilter.INCLUDE_ALL) {
/*  425 */       this._itemFilter = state;
/*  426 */       this.delegate.writeFieldName(name);
/*  427 */       return;
/*      */     }
/*  429 */     state = state.includeProperty(name.getValue());
/*  430 */     this._itemFilter = state;
/*  431 */     if (state == TokenFilter.INCLUDE_ALL) {
/*  432 */       _checkPropertyParentPath();
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeFieldId(long id)
/*      */     throws IOException
/*      */   {
/*  439 */     writeFieldName(Long.toString(id));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeString(String value)
/*      */     throws IOException
/*      */   {
/*  451 */     if (this._itemFilter == null) {
/*  452 */       return;
/*      */     }
/*  454 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  455 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  456 */       if (state == null) {
/*  457 */         return;
/*      */       }
/*  459 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  460 */         (!state.includeString(value))) {
/*  461 */         return;
/*      */       }
/*      */       
/*  464 */       _checkParentPath();
/*      */     }
/*  466 */     this.delegate.writeString(value);
/*      */   }
/*      */   
/*      */   public void writeString(char[] text, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  472 */     if (this._itemFilter == null) {
/*  473 */       return;
/*      */     }
/*  475 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  476 */       String value = new String(text, offset, len);
/*  477 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  478 */       if (state == null) {
/*  479 */         return;
/*      */       }
/*  481 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  482 */         (!state.includeString(value))) {
/*  483 */         return;
/*      */       }
/*      */       
/*  486 */       _checkParentPath();
/*      */     }
/*  488 */     this.delegate.writeString(text, offset, len);
/*      */   }
/*      */   
/*      */   public void writeString(SerializableString value)
/*      */     throws IOException
/*      */   {
/*  494 */     if (this._itemFilter == null) {
/*  495 */       return;
/*      */     }
/*  497 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  498 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  499 */       if (state == null) {
/*  500 */         return;
/*      */       }
/*  502 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  503 */         (!state.includeString(value.getValue()))) {
/*  504 */         return;
/*      */       }
/*      */       
/*  507 */       _checkParentPath();
/*      */     }
/*  509 */     this.delegate.writeString(value);
/*      */   }
/*      */   
/*      */   public void writeString(Reader reader, int len) throws IOException
/*      */   {
/*  514 */     if (this._itemFilter == null) {
/*  515 */       return;
/*      */     }
/*  517 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  518 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  519 */       if (state == null) {
/*  520 */         return;
/*      */       }
/*  522 */       if (state != TokenFilter.INCLUDE_ALL)
/*      */       {
/*      */ 
/*  525 */         if (!state.includeString(reader, len)) {
/*  526 */           return;
/*      */         }
/*      */       }
/*  529 */       _checkParentPath();
/*      */     }
/*  531 */     this.delegate.writeString(reader, len);
/*      */   }
/*      */   
/*      */   public void writeRawUTF8String(byte[] text, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  537 */     if (_checkRawValueWrite()) {
/*  538 */       this.delegate.writeRawUTF8String(text, offset, length);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeUTF8String(byte[] text, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  546 */     if (_checkRawValueWrite()) {
/*  547 */       this.delegate.writeUTF8String(text, offset, length);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeRaw(String text)
/*      */     throws IOException
/*      */   {
/*  560 */     if (_checkRawValueWrite()) {
/*  561 */       this.delegate.writeRaw(text);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRaw(String text, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  568 */     if (_checkRawValueWrite()) {
/*  569 */       this.delegate.writeRaw(text, offset, len);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRaw(SerializableString text)
/*      */     throws IOException
/*      */   {
/*  576 */     if (_checkRawValueWrite()) {
/*  577 */       this.delegate.writeRaw(text);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRaw(char[] text, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  584 */     if (_checkRawValueWrite()) {
/*  585 */       this.delegate.writeRaw(text, offset, len);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRaw(char c)
/*      */     throws IOException
/*      */   {
/*  592 */     if (_checkRawValueWrite()) {
/*  593 */       this.delegate.writeRaw(c);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRawValue(String text)
/*      */     throws IOException
/*      */   {
/*  600 */     if (_checkRawValueWrite()) {
/*  601 */       this.delegate.writeRawValue(text);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRawValue(String text, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  608 */     if (_checkRawValueWrite()) {
/*  609 */       this.delegate.writeRawValue(text, offset, len);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRawValue(char[] text, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  616 */     if (_checkRawValueWrite()) {
/*  617 */       this.delegate.writeRawValue(text, offset, len);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  624 */     if (_checkBinaryWrite()) {
/*  625 */       this.delegate.writeBinary(b64variant, data, offset, len);
/*      */     }
/*      */   }
/*      */   
/*      */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength)
/*      */     throws IOException
/*      */   {
/*  632 */     if (_checkBinaryWrite()) {
/*  633 */       return this.delegate.writeBinary(b64variant, data, dataLength);
/*      */     }
/*  635 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumber(short v)
/*      */     throws IOException
/*      */   {
/*  647 */     if (this._itemFilter == null) {
/*  648 */       return;
/*      */     }
/*  650 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  651 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  652 */       if (state == null) {
/*  653 */         return;
/*      */       }
/*  655 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  656 */         (!state.includeNumber(v))) {
/*  657 */         return;
/*      */       }
/*      */       
/*  660 */       _checkParentPath();
/*      */     }
/*  662 */     this.delegate.writeNumber(v);
/*      */   }
/*      */   
/*      */   public void writeNumber(int v)
/*      */     throws IOException
/*      */   {
/*  668 */     if (this._itemFilter == null) {
/*  669 */       return;
/*      */     }
/*  671 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  672 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  673 */       if (state == null) {
/*  674 */         return;
/*      */       }
/*  676 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  677 */         (!state.includeNumber(v))) {
/*  678 */         return;
/*      */       }
/*      */       
/*  681 */       _checkParentPath();
/*      */     }
/*  683 */     this.delegate.writeNumber(v);
/*      */   }
/*      */   
/*      */   public void writeNumber(long v)
/*      */     throws IOException
/*      */   {
/*  689 */     if (this._itemFilter == null) {
/*  690 */       return;
/*      */     }
/*  692 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  693 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  694 */       if (state == null) {
/*  695 */         return;
/*      */       }
/*  697 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  698 */         (!state.includeNumber(v))) {
/*  699 */         return;
/*      */       }
/*      */       
/*  702 */       _checkParentPath();
/*      */     }
/*  704 */     this.delegate.writeNumber(v);
/*      */   }
/*      */   
/*      */   public void writeNumber(BigInteger v)
/*      */     throws IOException
/*      */   {
/*  710 */     if (this._itemFilter == null) {
/*  711 */       return;
/*      */     }
/*  713 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  714 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  715 */       if (state == null) {
/*  716 */         return;
/*      */       }
/*  718 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  719 */         (!state.includeNumber(v))) {
/*  720 */         return;
/*      */       }
/*      */       
/*  723 */       _checkParentPath();
/*      */     }
/*  725 */     this.delegate.writeNumber(v);
/*      */   }
/*      */   
/*      */   public void writeNumber(double v)
/*      */     throws IOException
/*      */   {
/*  731 */     if (this._itemFilter == null) {
/*  732 */       return;
/*      */     }
/*  734 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  735 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  736 */       if (state == null) {
/*  737 */         return;
/*      */       }
/*  739 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  740 */         (!state.includeNumber(v))) {
/*  741 */         return;
/*      */       }
/*      */       
/*  744 */       _checkParentPath();
/*      */     }
/*  746 */     this.delegate.writeNumber(v);
/*      */   }
/*      */   
/*      */   public void writeNumber(float v)
/*      */     throws IOException
/*      */   {
/*  752 */     if (this._itemFilter == null) {
/*  753 */       return;
/*      */     }
/*  755 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  756 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  757 */       if (state == null) {
/*  758 */         return;
/*      */       }
/*  760 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  761 */         (!state.includeNumber(v))) {
/*  762 */         return;
/*      */       }
/*      */       
/*  765 */       _checkParentPath();
/*      */     }
/*  767 */     this.delegate.writeNumber(v);
/*      */   }
/*      */   
/*      */   public void writeNumber(BigDecimal v)
/*      */     throws IOException
/*      */   {
/*  773 */     if (this._itemFilter == null) {
/*  774 */       return;
/*      */     }
/*  776 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  777 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  778 */       if (state == null) {
/*  779 */         return;
/*      */       }
/*  781 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  782 */         (!state.includeNumber(v))) {
/*  783 */         return;
/*      */       }
/*      */       
/*  786 */       _checkParentPath();
/*      */     }
/*  788 */     this.delegate.writeNumber(v);
/*      */   }
/*      */   
/*      */   public void writeNumber(String encodedValue)
/*      */     throws IOException, UnsupportedOperationException
/*      */   {
/*  794 */     if (this._itemFilter == null) {
/*  795 */       return;
/*      */     }
/*  797 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  798 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  799 */       if (state == null) {
/*  800 */         return;
/*      */       }
/*  802 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  803 */         (!state.includeRawValue())) {
/*  804 */         return;
/*      */       }
/*      */       
/*  807 */       _checkParentPath();
/*      */     }
/*  809 */     this.delegate.writeNumber(encodedValue);
/*      */   }
/*      */   
/*      */   public void writeNumber(char[] encodedValueBuffer, int offset, int length)
/*      */     throws IOException, UnsupportedOperationException
/*      */   {
/*  815 */     if (this._itemFilter == null) {
/*  816 */       return;
/*      */     }
/*  818 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  819 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  820 */       if (state == null) {
/*  821 */         return;
/*      */       }
/*  823 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  824 */         (!state.includeRawValue())) {
/*  825 */         return;
/*      */       }
/*      */       
/*  828 */       _checkParentPath();
/*      */     }
/*  830 */     this.delegate.writeNumber(encodedValueBuffer, offset, length);
/*      */   }
/*      */   
/*      */   public void writeBoolean(boolean v)
/*      */     throws IOException
/*      */   {
/*  836 */     if (this._itemFilter == null) {
/*  837 */       return;
/*      */     }
/*  839 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  840 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  841 */       if (state == null) {
/*  842 */         return;
/*      */       }
/*  844 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  845 */         (!state.includeBoolean(v))) {
/*  846 */         return;
/*      */       }
/*      */       
/*  849 */       _checkParentPath();
/*      */     }
/*  851 */     this.delegate.writeBoolean(v);
/*      */   }
/*      */   
/*      */   public void writeNull()
/*      */     throws IOException
/*      */   {
/*  857 */     if (this._itemFilter == null) {
/*  858 */       return;
/*      */     }
/*  860 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  861 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  862 */       if (state == null) {
/*  863 */         return;
/*      */       }
/*  865 */       if ((state != TokenFilter.INCLUDE_ALL) && 
/*  866 */         (!state.includeNull())) {
/*  867 */         return;
/*      */       }
/*      */       
/*  870 */       _checkParentPath();
/*      */     }
/*  872 */     this.delegate.writeNull();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeOmittedField(String fieldName)
/*      */     throws IOException
/*      */   {
/*  884 */     if (this._itemFilter != null) {
/*  885 */       this.delegate.writeOmittedField(fieldName);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeObjectId(Object id)
/*      */     throws IOException
/*      */   {
/*  900 */     if (this._itemFilter != null) {
/*  901 */       this.delegate.writeObjectId(id);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeObjectRef(Object id) throws IOException
/*      */   {
/*  907 */     if (this._itemFilter != null) {
/*  908 */       this.delegate.writeObjectRef(id);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeTypeId(Object id) throws IOException
/*      */   {
/*  914 */     if (this._itemFilter != null) {
/*  915 */       this.delegate.writeTypeId(id);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _checkParentPath()
/*      */     throws IOException
/*      */   {
/*  994 */     _checkParentPath(true);
/*      */   }
/*      */   
/*      */   protected void _checkParentPath(boolean isMatch) throws IOException
/*      */   {
/*  999 */     if (isMatch) {
/* 1000 */       this._matchCount += 1;
/*      */     }
/*      */     
/* 1003 */     if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 1004 */       this._filterContext.writePath(this.delegate);
/* 1005 */     } else if (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL)
/*      */     {
/* 1007 */       this._filterContext.ensureFieldNameWritten(this.delegate);
/*      */     }
/*      */     
/* 1010 */     if ((isMatch) && (!this._allowMultipleMatches))
/*      */     {
/* 1012 */       this._filterContext.skipParentChecks();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _checkPropertyParentPath()
/*      */     throws IOException
/*      */   {
/* 1023 */     this._matchCount += 1;
/* 1024 */     if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 1025 */       this._filterContext.writePath(this.delegate);
/* 1026 */     } else if (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL)
/*      */     {
/* 1028 */       this._filterContext.ensureFieldNameWritten(this.delegate);
/*      */     }
/*      */     
/*      */ 
/* 1032 */     if (!this._allowMultipleMatches)
/*      */     {
/* 1034 */       this._filterContext.skipParentChecks();
/*      */     }
/*      */   }
/*      */   
/*      */   protected boolean _checkBinaryWrite() throws IOException
/*      */   {
/* 1040 */     if (this._itemFilter == null) {
/* 1041 */       return false;
/*      */     }
/* 1043 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/* 1044 */       return true;
/*      */     }
/* 1046 */     if (this._itemFilter.includeBinary()) {
/* 1047 */       _checkParentPath();
/* 1048 */       return true;
/*      */     }
/* 1050 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean _checkRawValueWrite() throws IOException
/*      */   {
/* 1055 */     if (this._itemFilter == null) {
/* 1056 */       return false;
/*      */     }
/* 1058 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/* 1059 */       return true;
/*      */     }
/* 1061 */     if (this._itemFilter.includeRawValue()) {
/* 1062 */       _checkParentPath();
/* 1063 */       return true;
/*      */     }
/* 1065 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\filter\FilteringGeneratorDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */