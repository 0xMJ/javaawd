/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.JsonStringEncoder;
/*     */ import java.lang.ref.SoftReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferRecyclers
/*     */ {
/*     */   public static final String SYSTEM_PROPERTY_TRACK_REUSABLE_BUFFERS = "com.fasterxml.jackson.core.util.BufferRecyclers.trackReusableBuffers";
/*     */   
/*     */   static
/*     */   {
/*  38 */     boolean trackReusableBuffers = false;
/*     */     try {
/*  40 */       trackReusableBuffers = "true".equals(System.getProperty("com.fasterxml.jackson.core.util.BufferRecyclers.trackReusableBuffers"));
/*     */     } catch (SecurityException localSecurityException) {} }
/*     */   
/*  43 */   private static final ThreadLocalBufferManager _bufferRecyclerTracker = trackReusableBuffers ? ThreadLocalBufferManager.instance() : null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  57 */   protected static final ThreadLocal<SoftReference<BufferRecycler>> _recyclerRef = new ThreadLocal();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BufferRecycler getBufferRecycler()
/*     */   {
/*  67 */     SoftReference<BufferRecycler> ref = (SoftReference)_recyclerRef.get();
/*  68 */     BufferRecycler br = ref == null ? null : (BufferRecycler)ref.get();
/*     */     
/*  70 */     if (br == null) {
/*  71 */       br = new BufferRecycler();
/*  72 */       if (_bufferRecyclerTracker != null) {
/*  73 */         ref = _bufferRecyclerTracker.wrapAndTrack(br);
/*     */       } else {
/*  75 */         ref = new SoftReference(br);
/*     */       }
/*  77 */       _recyclerRef.set(ref);
/*     */     }
/*  79 */     return br;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int releaseBuffers()
/*     */   {
/*  96 */     if (_bufferRecyclerTracker != null) {
/*  97 */       return _bufferRecyclerTracker.releaseBuffers();
/*     */     }
/*  99 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static JsonStringEncoder getJsonStringEncoder()
/*     */   {
/* 117 */     return JsonStringEncoder.getInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static byte[] encodeAsUTF8(String text)
/*     */   {
/* 129 */     return JsonStringEncoder.getInstance().encodeAsUTF8(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static char[] quoteAsJsonText(String rawText)
/*     */   {
/* 141 */     return JsonStringEncoder.getInstance().quoteAsString(rawText);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static void quoteAsJsonText(CharSequence input, StringBuilder output)
/*     */   {
/* 153 */     JsonStringEncoder.getInstance().quoteAsString(input, output);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static byte[] quoteAsJsonUTF8(String rawText)
/*     */   {
/* 165 */     return JsonStringEncoder.getInstance().quoteAsUTF8(rawText);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\util\BufferRecyclers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */