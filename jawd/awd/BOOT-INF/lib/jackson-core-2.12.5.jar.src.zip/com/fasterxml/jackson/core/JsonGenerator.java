/*      */ package com.fasterxml.jackson.core;
/*      */ 
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*      */ import com.fasterxml.jackson.core.type.WritableTypeId.Inclusion;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.core.util.VersionUtil;
/*      */ import java.io.Closeable;
/*      */ import java.io.Flushable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class JsonGenerator
/*      */   implements Closeable, Flushable, Versioned
/*      */ {
/*   41 */   protected static final JacksonFeatureSet<StreamWriteCapability> DEFAULT_WRITE_CAPABILITIES = JacksonFeatureSet.fromDefaults(StreamWriteCapability.values());
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   49 */   protected static final JacksonFeatureSet<StreamWriteCapability> DEFAULT_TEXTUAL_WRITE_CAPABILITIES = DEFAULT_WRITE_CAPABILITIES
/*   50 */     .with(StreamWriteCapability.CAN_WRITE_FORMATTED_NUMBERS);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   58 */   protected static final JacksonFeatureSet<StreamWriteCapability> DEFAULT_BINARY_WRITE_CAPABILITIES = DEFAULT_WRITE_CAPABILITIES
/*   59 */     .with(StreamWriteCapability.CAN_WRITE_BINARY_NATIVELY);
/*      */   
/*      */ 
/*      */   protected PrettyPrinter _cfgPrettyPrinter;
/*      */   
/*      */ 
/*      */   public abstract JsonGenerator setCodec(ObjectCodec paramObjectCodec);
/*      */   
/*      */ 
/*      */ 
/*      */   public abstract ObjectCodec getCodec();
/*      */   
/*      */ 
/*      */   public abstract Version version();
/*      */   
/*      */ 
/*      */   public abstract JsonStreamContext getOutputContext();
/*      */   
/*      */ 
/*      */   public static enum Feature
/*      */   {
/*   80 */     AUTO_CLOSE_TARGET(true), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   92 */     AUTO_CLOSE_JSON_CONTENT(true), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  105 */     FLUSH_PASSED_TO_STREAM(true), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  120 */     QUOTE_FIELD_NAMES(true), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  137 */     QUOTE_NON_NUMERIC_NUMBERS(true), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  159 */     ESCAPE_NON_ASCII(false), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  184 */     WRITE_NUMBERS_AS_STRINGS(false), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  201 */     WRITE_BIGDECIMAL_AS_PLAIN(false), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  220 */     STRICT_DUPLICATE_DETECTION(false), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  242 */     IGNORE_UNKNOWN(false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private final boolean _defaultState;
/*      */     
/*      */ 
/*      */     private final int _mask;
/*      */     
/*      */ 
/*      */ 
/*      */     public static int collectDefaults()
/*      */     {
/*  256 */       int flags = 0;
/*  257 */       for (Feature f : values()) {
/*  258 */         if (f.enabledByDefault()) {
/*  259 */           flags |= f.getMask();
/*      */         }
/*      */       }
/*  262 */       return flags;
/*      */     }
/*      */     
/*      */     private Feature(boolean defaultState) {
/*  266 */       this._defaultState = defaultState;
/*  267 */       this._mask = (1 << ordinal());
/*      */     }
/*      */     
/*  270 */     public boolean enabledByDefault() { return this._defaultState; }
/*      */     
/*      */ 
/*  273 */     public boolean enabledIn(int flags) { return (flags & this._mask) != 0; }
/*      */     
/*  275 */     public int getMask() { return this._mask; }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getOutputTarget()
/*      */   {
/*  360 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getCurrentValue()
/*      */   {
/*  379 */     JsonStreamContext ctxt = getOutputContext();
/*  380 */     return ctxt == null ? null : ctxt.getCurrentValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCurrentValue(Object v)
/*      */   {
/*  394 */     JsonStreamContext ctxt = getOutputContext();
/*  395 */     if (ctxt != null) {
/*  396 */       ctxt.setCurrentValue(v);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract JsonGenerator enable(Feature paramFeature);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract JsonGenerator disable(Feature paramFeature);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final JsonGenerator configure(Feature f, boolean state)
/*      */   {
/*  436 */     if (state) enable(f); else disable(f);
/*  437 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract boolean isEnabled(Feature paramFeature);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(StreamWriteFeature f)
/*      */   {
/*  461 */     return isEnabled(f.mappedFeature());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract int getFeatureMask();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public abstract JsonGenerator setFeatureMask(int paramInt);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator overrideStdFeatures(int values, int mask)
/*      */   {
/*  507 */     int oldState = getFeatureMask();
/*  508 */     int newState = oldState & (mask ^ 0xFFFFFFFF) | values & mask;
/*  509 */     return setFeatureMask(newState);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFormatFeatures()
/*      */   {
/*  521 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator overrideFormatFeatures(int values, int mask)
/*      */   {
/*  543 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSchema(FormatSchema schema)
/*      */   {
/*  568 */     throw new UnsupportedOperationException(String.format("Generator of type %s does not support schema of type '%s'", new Object[] {
/*      */     
/*  570 */       getClass().getName(), schema.getSchemaType() }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FormatSchema getSchema()
/*      */   {
/*  579 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator setPrettyPrinter(PrettyPrinter pp)
/*      */   {
/*  601 */     this._cfgPrettyPrinter = pp;
/*  602 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PrettyPrinter getPrettyPrinter()
/*      */   {
/*  612 */     return this._cfgPrettyPrinter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract JsonGenerator useDefaultPrettyPrinter();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator setHighestNonEscapedChar(int charCode)
/*      */   {
/*  647 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getHighestEscapedChar()
/*      */   {
/*  661 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public CharacterEscapes getCharacterEscapes()
/*      */   {
/*  669 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator setCharacterEscapes(CharacterEscapes esc)
/*      */   {
/*  681 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator setRootValueSeparator(SerializableString sep)
/*      */   {
/*  695 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getOutputBuffered()
/*      */   {
/*  723 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canUseSchema(FormatSchema schema)
/*      */   {
/*  740 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canWriteObjectId()
/*      */   {
/*  760 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canWriteTypeId()
/*      */   {
/*  780 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canWriteBinaryNatively()
/*      */   {
/*  797 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canOmitFields()
/*      */   {
/*  810 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canWriteFormattedNumbers()
/*      */   {
/*  829 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JacksonFeatureSet<StreamWriteCapability> getWriteCapabilities()
/*      */   {
/*  840 */     return DEFAULT_WRITE_CAPABILITIES;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeStartArray()
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void writeStartArray(int size)
/*      */     throws IOException
/*      */   {
/*  886 */     writeStartArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeStartArray(Object forValue)
/*      */     throws IOException
/*      */   {
/*  903 */     writeStartArray();
/*  904 */     setCurrentValue(forValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeStartArray(Object forValue, int size)
/*      */     throws IOException
/*      */   {
/*  926 */     writeStartArray(size);
/*  927 */     setCurrentValue(forValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeEndArray()
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeStartObject()
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeStartObject(Object forValue)
/*      */     throws IOException
/*      */   {
/*  977 */     writeStartObject();
/*  978 */     setCurrentValue(forValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeStartObject(Object forValue, int size)
/*      */     throws IOException
/*      */   {
/* 1008 */     writeStartObject();
/* 1009 */     setCurrentValue(forValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeEndObject()
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeFieldName(String paramString)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeFieldName(SerializableString paramSerializableString)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeFieldId(long id)
/*      */     throws IOException
/*      */   {
/* 1077 */     writeFieldName(Long.toString(id));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeArray(int[] array, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1102 */     if (array == null) {
/* 1103 */       throw new IllegalArgumentException("null array");
/*      */     }
/* 1105 */     _verifyOffsets(array.length, offset, length);
/* 1106 */     writeStartArray(array, length);
/* 1107 */     int i = offset; for (int end = offset + length; i < end; i++) {
/* 1108 */       writeNumber(array[i]);
/*      */     }
/* 1110 */     writeEndArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeArray(long[] array, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1129 */     if (array == null) {
/* 1130 */       throw new IllegalArgumentException("null array");
/*      */     }
/* 1132 */     _verifyOffsets(array.length, offset, length);
/* 1133 */     writeStartArray(array, length);
/* 1134 */     int i = offset; for (int end = offset + length; i < end; i++) {
/* 1135 */       writeNumber(array[i]);
/*      */     }
/* 1137 */     writeEndArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeArray(double[] array, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1156 */     if (array == null) {
/* 1157 */       throw new IllegalArgumentException("null array");
/*      */     }
/* 1159 */     _verifyOffsets(array.length, offset, length);
/* 1160 */     writeStartArray(array, length);
/* 1161 */     int i = offset; for (int end = offset + length; i < end; i++) {
/* 1162 */       writeNumber(array[i]);
/*      */     }
/* 1164 */     writeEndArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeArray(String[] array, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1183 */     if (array == null) {
/* 1184 */       throw new IllegalArgumentException("null array");
/*      */     }
/* 1186 */     _verifyOffsets(array.length, offset, length);
/* 1187 */     writeStartArray(array, length);
/* 1188 */     int i = offset; for (int end = offset + length; i < end; i++) {
/* 1189 */       writeString(array[i]);
/*      */     }
/* 1191 */     writeEndArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeString(String paramString)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeString(Reader reader, int len)
/*      */     throws IOException
/*      */   {
/* 1239 */     _reportUnsupportedOperation();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeString(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeString(SerializableString paramSerializableString)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeRawUTF8String(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeUTF8String(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeRaw(String paramString)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeRaw(String paramString, int paramInt1, int paramInt2)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeRaw(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeRaw(char paramChar)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeRaw(SerializableString raw)
/*      */     throws IOException
/*      */   {
/* 1437 */     writeRaw(raw.getValue());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeRawValue(String paramString)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeRawValue(String paramString, int paramInt1, int paramInt2)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeRawValue(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeRawValue(SerializableString raw)
/*      */     throws IOException
/*      */   {
/* 1472 */     writeRawValue(raw.getValue());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeBinary(Base64Variant paramBase64Variant, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeBinary(byte[] data, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 1518 */     writeBinary(Base64Variants.getDefaultVariant(), data, offset, len);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeBinary(byte[] data)
/*      */     throws IOException
/*      */   {
/* 1533 */     writeBinary(Base64Variants.getDefaultVariant(), data, 0, data.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int writeBinary(InputStream data, int dataLength)
/*      */     throws IOException
/*      */   {
/* 1556 */     return writeBinary(Base64Variants.getDefaultVariant(), data, dataLength);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract int writeBinary(Base64Variant paramBase64Variant, InputStream paramInputStream, int paramInt)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumber(short v)
/*      */     throws IOException
/*      */   {
/* 1604 */     writeNumber(v);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeNumber(int paramInt)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeNumber(long paramLong)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeNumber(BigInteger paramBigInteger)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeNumber(double paramDouble)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeNumber(float paramFloat)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeNumber(BigDecimal paramBigDecimal)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeNumber(String paramString)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumber(char[] encodedValueBuffer, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 1731 */     writeNumber(new String(encodedValueBuffer, offset, len));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeBoolean(boolean paramBoolean)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeNull()
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeEmbeddedObject(Object object)
/*      */     throws IOException
/*      */   {
/* 1784 */     if (object == null) {
/* 1785 */       writeNull();
/* 1786 */       return;
/*      */     }
/* 1788 */     if ((object instanceof byte[])) {
/* 1789 */       writeBinary((byte[])object);
/* 1790 */       return;
/*      */     }
/*      */     
/* 1793 */     throw new JsonGenerationException("No native support for writing embedded objects of type " + object.getClass().getName(), this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeObjectId(Object id)
/*      */     throws IOException
/*      */   {
/* 1822 */     throw new JsonGenerationException("No native support for writing Object Ids", this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeObjectRef(Object referenced)
/*      */     throws IOException
/*      */   {
/* 1842 */     throw new JsonGenerationException("No native support for writing Object Ids", this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeTypeId(Object id)
/*      */     throws IOException
/*      */   {
/* 1864 */     throw new JsonGenerationException("No native support for writing Type Ids", this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableTypeId writeTypePrefix(WritableTypeId typeIdDef)
/*      */     throws IOException
/*      */   {
/* 1893 */     Object id = typeIdDef.id;
/*      */     
/* 1895 */     JsonToken valueShape = typeIdDef.valueShape;
/* 1896 */     if (canWriteTypeId()) {
/* 1897 */       typeIdDef.wrapperWritten = false;
/*      */       
/* 1899 */       writeTypeId(id);
/*      */     }
/*      */     else
/*      */     {
/* 1903 */       String idStr = (id instanceof String) ? (String)id : String.valueOf(id);
/* 1904 */       typeIdDef.wrapperWritten = true;
/*      */       
/* 1906 */       WritableTypeId.Inclusion incl = typeIdDef.include;
/*      */       
/* 1908 */       if ((valueShape != JsonToken.START_OBJECT) && 
/* 1909 */         (incl.requiresObjectContext())) {
/* 1910 */         typeIdDef.include = (incl = WritableTypeId.Inclusion.WRAPPER_ARRAY);
/*      */       }
/*      */       
/* 1913 */       switch (incl)
/*      */       {
/*      */       case PARENT_PROPERTY: 
/*      */         break;
/*      */       
/*      */ 
/*      */       case PAYLOAD_PROPERTY: 
/*      */         break;
/*      */       
/*      */ 
/*      */ 
/*      */       case METADATA_PROPERTY: 
/* 1925 */         writeStartObject(typeIdDef.forValue);
/* 1926 */         writeStringField(typeIdDef.asProperty, idStr);
/* 1927 */         return typeIdDef;
/*      */       
/*      */ 
/*      */       case WRAPPER_OBJECT: 
/* 1931 */         writeStartObject();
/* 1932 */         writeFieldName(idStr);
/* 1933 */         break;
/*      */       case WRAPPER_ARRAY: 
/*      */       default: 
/* 1936 */         writeStartArray();
/* 1937 */         writeString(idStr);
/*      */       }
/*      */       
/*      */     }
/* 1941 */     if (valueShape == JsonToken.START_OBJECT) {
/* 1942 */       writeStartObject(typeIdDef.forValue);
/* 1943 */     } else if (valueShape == JsonToken.START_ARRAY)
/*      */     {
/* 1945 */       writeStartArray();
/*      */     }
/* 1947 */     return typeIdDef;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WritableTypeId writeTypeSuffix(WritableTypeId typeIdDef)
/*      */     throws IOException
/*      */   {
/* 1969 */     JsonToken valueShape = typeIdDef.valueShape;
/*      */     
/* 1971 */     if (valueShape == JsonToken.START_OBJECT) {
/* 1972 */       writeEndObject();
/* 1973 */     } else if (valueShape == JsonToken.START_ARRAY) {
/* 1974 */       writeEndArray();
/*      */     }
/*      */     
/* 1977 */     if (typeIdDef.wrapperWritten) {
/* 1978 */       switch (typeIdDef.include) {
/*      */       case WRAPPER_ARRAY: 
/* 1980 */         writeEndArray();
/* 1981 */         break;
/*      */       
/*      */ 
/*      */       case PARENT_PROPERTY: 
/* 1985 */         Object id = typeIdDef.id;
/* 1986 */         String idStr = (id instanceof String) ? (String)id : String.valueOf(id);
/* 1987 */         writeStringField(typeIdDef.asProperty, idStr);
/*      */         
/* 1989 */         break;
/*      */       case PAYLOAD_PROPERTY: 
/*      */       case METADATA_PROPERTY: 
/*      */         break;
/*      */       
/*      */       case WRAPPER_OBJECT: 
/*      */       default: 
/* 1996 */         writeEndObject();
/*      */       }
/*      */       
/*      */     }
/* 2000 */     return typeIdDef;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeObject(Object paramObject)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void writeTree(TreeNode paramTreeNode)
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeBinaryField(String fieldName, byte[] data)
/*      */     throws IOException
/*      */   {
/* 2068 */     writeFieldName(fieldName);
/* 2069 */     writeBinary(data);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeBooleanField(String fieldName, boolean value)
/*      */     throws IOException
/*      */   {
/* 2087 */     writeFieldName(fieldName);
/* 2088 */     writeBoolean(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNullField(String fieldName)
/*      */     throws IOException
/*      */   {
/* 2105 */     writeFieldName(fieldName);
/* 2106 */     writeNull();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeStringField(String fieldName, String value)
/*      */     throws IOException
/*      */   {
/* 2124 */     writeFieldName(fieldName);
/* 2125 */     writeString(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumberField(String fieldName, short value)
/*      */     throws IOException
/*      */   {
/* 2145 */     writeFieldName(fieldName);
/* 2146 */     writeNumber(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumberField(String fieldName, int value)
/*      */     throws IOException
/*      */   {
/* 2164 */     writeFieldName(fieldName);
/* 2165 */     writeNumber(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumberField(String fieldName, long value)
/*      */     throws IOException
/*      */   {
/* 2183 */     writeFieldName(fieldName);
/* 2184 */     writeNumber(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumberField(String fieldName, BigInteger value)
/*      */     throws IOException
/*      */   {
/* 2204 */     writeFieldName(fieldName);
/* 2205 */     writeNumber(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumberField(String fieldName, float value)
/*      */     throws IOException
/*      */   {
/* 2223 */     writeFieldName(fieldName);
/* 2224 */     writeNumber(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumberField(String fieldName, double value)
/*      */     throws IOException
/*      */   {
/* 2242 */     writeFieldName(fieldName);
/* 2243 */     writeNumber(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumberField(String fieldName, BigDecimal value)
/*      */     throws IOException
/*      */   {
/* 2262 */     writeFieldName(fieldName);
/* 2263 */     writeNumber(value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeArrayFieldStart(String fieldName)
/*      */     throws IOException
/*      */   {
/* 2285 */     writeFieldName(fieldName);
/* 2286 */     writeStartArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeObjectFieldStart(String fieldName)
/*      */     throws IOException
/*      */   {
/* 2308 */     writeFieldName(fieldName);
/* 2309 */     writeStartObject();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeObjectField(String fieldName, Object pojo)
/*      */     throws IOException
/*      */   {
/* 2331 */     writeFieldName(fieldName);
/* 2332 */     writeObject(pojo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeOmittedField(String fieldName)
/*      */     throws IOException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copyCurrentEvent(JsonParser p)
/*      */     throws IOException
/*      */   {
/* 2376 */     JsonToken t = p.currentToken();
/* 2377 */     int token = t == null ? -1 : t.id();
/* 2378 */     switch (token) {
/*      */     case -1: 
/* 2380 */       _reportError("No current event to copy");
/* 2381 */       break;
/*      */     case 1: 
/* 2383 */       writeStartObject();
/* 2384 */       break;
/*      */     case 2: 
/* 2386 */       writeEndObject();
/* 2387 */       break;
/*      */     case 3: 
/* 2389 */       writeStartArray();
/* 2390 */       break;
/*      */     case 4: 
/* 2392 */       writeEndArray();
/* 2393 */       break;
/*      */     case 5: 
/* 2395 */       writeFieldName(p.getCurrentName());
/* 2396 */       break;
/*      */     case 6: 
/* 2398 */       if (p.hasTextCharacters()) {
/* 2399 */         writeString(p.getTextCharacters(), p.getTextOffset(), p.getTextLength());
/*      */       } else {
/* 2401 */         writeString(p.getText());
/*      */       }
/* 2403 */       break;
/*      */     
/*      */     case 7: 
/* 2406 */       JsonParser.NumberType n = p.getNumberType();
/* 2407 */       if (n == JsonParser.NumberType.INT) {
/* 2408 */         writeNumber(p.getIntValue());
/* 2409 */       } else if (n == JsonParser.NumberType.BIG_INTEGER) {
/* 2410 */         writeNumber(p.getBigIntegerValue());
/*      */       } else {
/* 2412 */         writeNumber(p.getLongValue());
/*      */       }
/* 2414 */       break;
/*      */     
/*      */ 
/*      */     case 8: 
/* 2418 */       JsonParser.NumberType n = p.getNumberType();
/* 2419 */       if (n == JsonParser.NumberType.BIG_DECIMAL) {
/* 2420 */         writeNumber(p.getDecimalValue());
/* 2421 */       } else if (n == JsonParser.NumberType.FLOAT) {
/* 2422 */         writeNumber(p.getFloatValue());
/*      */       } else {
/* 2424 */         writeNumber(p.getDoubleValue());
/*      */       }
/* 2426 */       break;
/*      */     
/*      */     case 9: 
/* 2429 */       writeBoolean(true);
/* 2430 */       break;
/*      */     case 10: 
/* 2432 */       writeBoolean(false);
/* 2433 */       break;
/*      */     case 11: 
/* 2435 */       writeNull();
/* 2436 */       break;
/*      */     case 12: 
/* 2438 */       writeObject(p.getEmbeddedObject());
/* 2439 */       break;
/*      */     case 0: default: 
/* 2441 */       throw new IllegalStateException("Internal error: unknown current token, " + t);
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copyCurrentStructure(JsonParser p)
/*      */     throws IOException
/*      */   {
/* 2482 */     JsonToken t = p.currentToken();
/*      */     
/* 2484 */     int id = t == null ? -1 : t.id();
/* 2485 */     if (id == 5) {
/* 2486 */       writeFieldName(p.getCurrentName());
/* 2487 */       t = p.nextToken();
/* 2488 */       id = t == null ? -1 : t.id();
/*      */     }
/*      */     
/* 2491 */     switch (id) {
/*      */     case 1: 
/* 2493 */       writeStartObject();
/* 2494 */       _copyCurrentContents(p);
/* 2495 */       return;
/*      */     case 3: 
/* 2497 */       writeStartArray();
/* 2498 */       _copyCurrentContents(p);
/* 2499 */       return;
/*      */     }
/*      */     
/* 2502 */     copyCurrentEvent(p);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void _copyCurrentContents(JsonParser p)
/*      */     throws IOException
/*      */   {
/* 2509 */     int depth = 1;
/*      */     
/*      */     JsonToken t;
/*      */     
/* 2513 */     while ((t = p.nextToken()) != null) {
/* 2514 */       switch (t.id()) {
/*      */       case 5: 
/* 2516 */         writeFieldName(p.getCurrentName());
/* 2517 */         break;
/*      */       
/*      */       case 3: 
/* 2520 */         writeStartArray();
/* 2521 */         depth++;
/* 2522 */         break;
/*      */       
/*      */       case 1: 
/* 2525 */         writeStartObject();
/* 2526 */         depth++;
/* 2527 */         break;
/*      */       
/*      */       case 4: 
/* 2530 */         writeEndArray();
/* 2531 */         depth--; if (depth == 0) {}
/*      */         
/*      */ 
/*      */         break;
/*      */       case 2: 
/* 2536 */         writeEndObject();
/* 2537 */         depth--; if (depth == 0) {}
/*      */         
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 6: 
/* 2543 */         if (p.hasTextCharacters()) {
/* 2544 */           writeString(p.getTextCharacters(), p.getTextOffset(), p.getTextLength());
/*      */         } else {
/* 2546 */           writeString(p.getText());
/*      */         }
/* 2548 */         break;
/*      */       
/*      */       case 7: 
/* 2551 */         JsonParser.NumberType n = p.getNumberType();
/* 2552 */         if (n == JsonParser.NumberType.INT) {
/* 2553 */           writeNumber(p.getIntValue());
/* 2554 */         } else if (n == JsonParser.NumberType.BIG_INTEGER) {
/* 2555 */           writeNumber(p.getBigIntegerValue());
/*      */         } else {
/* 2557 */           writeNumber(p.getLongValue());
/*      */         }
/* 2559 */         break;
/*      */       
/*      */ 
/*      */       case 8: 
/* 2563 */         JsonParser.NumberType n = p.getNumberType();
/* 2564 */         if (n == JsonParser.NumberType.BIG_DECIMAL) {
/* 2565 */           writeNumber(p.getDecimalValue());
/* 2566 */         } else if (n == JsonParser.NumberType.FLOAT) {
/* 2567 */           writeNumber(p.getFloatValue());
/*      */         } else {
/* 2569 */           writeNumber(p.getDoubleValue());
/*      */         }
/* 2571 */         break;
/*      */       
/*      */       case 9: 
/* 2574 */         writeBoolean(true);
/* 2575 */         break;
/*      */       case 10: 
/* 2577 */         writeBoolean(false);
/* 2578 */         break;
/*      */       case 11: 
/* 2580 */         writeNull();
/* 2581 */         break;
/*      */       case 12: 
/* 2583 */         writeObject(p.getEmbeddedObject());
/* 2584 */         break;
/*      */       default: 
/* 2586 */         throw new IllegalStateException("Internal error: unknown current token, " + t);
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void flush()
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract boolean isClosed();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void close()
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _reportError(String msg)
/*      */     throws JsonGenerationException
/*      */   {
/* 2657 */     throw new JsonGenerationException(msg, this);
/*      */   }
/*      */   
/*      */   protected final void _throwInternal() {}
/*      */   
/*      */   protected void _reportUnsupportedOperation() {
/* 2663 */     throw new UnsupportedOperationException("Operation not supported by generator of type " + getClass().getName());
/*      */   }
/*      */   
/*      */ 
/*      */   protected final void _verifyOffsets(int arrayLength, int offset, int length)
/*      */   {
/* 2669 */     if ((offset < 0) || (offset + length > arrayLength)) {
/* 2670 */       throw new IllegalArgumentException(String.format("invalid argument(s) (offset=%d, length=%d) for input array of %d element", new Object[] {
/*      */       
/* 2672 */         Integer.valueOf(offset), Integer.valueOf(length), Integer.valueOf(arrayLength) }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _writeSimpleObject(Object value)
/*      */     throws IOException
/*      */   {
/* 2691 */     if (value == null) {
/* 2692 */       writeNull();
/* 2693 */       return;
/*      */     }
/* 2695 */     if ((value instanceof String)) {
/* 2696 */       writeString((String)value);
/* 2697 */       return;
/*      */     }
/* 2699 */     if ((value instanceof Number)) {
/* 2700 */       Number n = (Number)value;
/* 2701 */       if ((n instanceof Integer)) {
/* 2702 */         writeNumber(n.intValue());
/* 2703 */         return; }
/* 2704 */       if ((n instanceof Long)) {
/* 2705 */         writeNumber(n.longValue());
/* 2706 */         return; }
/* 2707 */       if ((n instanceof Double)) {
/* 2708 */         writeNumber(n.doubleValue());
/* 2709 */         return; }
/* 2710 */       if ((n instanceof Float)) {
/* 2711 */         writeNumber(n.floatValue());
/* 2712 */         return; }
/* 2713 */       if ((n instanceof Short)) {
/* 2714 */         writeNumber(n.shortValue());
/* 2715 */         return; }
/* 2716 */       if ((n instanceof Byte)) {
/* 2717 */         writeNumber((short)n.byteValue());
/* 2718 */         return; }
/* 2719 */       if ((n instanceof BigInteger)) {
/* 2720 */         writeNumber((BigInteger)n);
/* 2721 */         return; }
/* 2722 */       if ((n instanceof BigDecimal)) {
/* 2723 */         writeNumber((BigDecimal)n);
/* 2724 */         return;
/*      */       }
/*      */       
/* 2727 */       if ((n instanceof AtomicInteger)) {
/* 2728 */         writeNumber(((AtomicInteger)n).get());
/* 2729 */         return; }
/* 2730 */       if ((n instanceof AtomicLong)) {
/* 2731 */         writeNumber(((AtomicLong)n).get());
/* 2732 */         return;
/*      */       }
/* 2734 */     } else { if ((value instanceof byte[])) {
/* 2735 */         writeBinary((byte[])value);
/* 2736 */         return; }
/* 2737 */       if ((value instanceof Boolean)) {
/* 2738 */         writeBoolean(((Boolean)value).booleanValue());
/* 2739 */         return; }
/* 2740 */       if ((value instanceof AtomicBoolean)) {
/* 2741 */         writeBoolean(((AtomicBoolean)value).get());
/* 2742 */         return;
/*      */       }
/*      */     }
/* 2745 */     throw new IllegalStateException("No ObjectCodec defined for the generator, can only serialize simple wrapper types (type passed " + value.getClass().getName() + ")");
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\JsonGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */