/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonGenerationException;
/*      */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.PrettyPrinter;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.NumberOutput;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ public class UTF8JsonGenerator extends JsonGeneratorImpl
/*      */ {
/*      */   private static final byte BYTE_u = 117;
/*      */   private static final byte BYTE_0 = 48;
/*      */   private static final byte BYTE_LBRACKET = 91;
/*      */   private static final byte BYTE_RBRACKET = 93;
/*      */   private static final byte BYTE_LCURLY = 123;
/*      */   private static final byte BYTE_RCURLY = 125;
/*      */   private static final byte BYTE_BACKSLASH = 92;
/*      */   private static final byte BYTE_COMMA = 44;
/*      */   private static final byte BYTE_COLON = 58;
/*      */   private static final int MAX_BYTES_TO_BUFFER = 512;
/*   32 */   private static final byte[] HEX_CHARS = ;
/*      */   
/*   34 */   private static final byte[] NULL_BYTES = { 110, 117, 108, 108 };
/*   35 */   private static final byte[] TRUE_BYTES = { 116, 114, 117, 101 };
/*   36 */   private static final byte[] FALSE_BYTES = { 102, 97, 108, 115, 101 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final OutputStream _outputStream;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte _quoteChar;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] _outputBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _outputTail;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final int _outputEnd;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final int _outputMaxContiguous;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char[] _charBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final int _charBufferLength;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] _entityBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _bufferRecyclable;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UTF8JsonGenerator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out, char quoteChar)
/*      */   {
/*  123 */     super(ctxt, features, codec);
/*  124 */     this._outputStream = out;
/*  125 */     this._quoteChar = ((byte)quoteChar);
/*  126 */     if (quoteChar != '"') {
/*  127 */       this._outputEscapes = CharTypes.get7BitOutputEscapes(quoteChar);
/*      */     }
/*      */     
/*  130 */     this._bufferRecyclable = true;
/*  131 */     this._outputBuffer = ctxt.allocWriteEncodingBuffer();
/*  132 */     this._outputEnd = this._outputBuffer.length;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  138 */     this._outputMaxContiguous = (this._outputEnd >> 3);
/*  139 */     this._charBuffer = ctxt.allocConcatBuffer();
/*  140 */     this._charBufferLength = this._charBuffer.length;
/*      */     
/*      */ 
/*  143 */     if (isEnabled(JsonGenerator.Feature.ESCAPE_NON_ASCII)) {
/*  144 */       setHighestNonEscapedChar(127);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UTF8JsonGenerator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out, char quoteChar, byte[] outputBuffer, int outputOffset, boolean bufferRecyclable)
/*      */   {
/*  156 */     super(ctxt, features, codec);
/*  157 */     this._outputStream = out;
/*  158 */     this._quoteChar = ((byte)quoteChar);
/*  159 */     if (quoteChar != '"') {
/*  160 */       this._outputEscapes = CharTypes.get7BitOutputEscapes(quoteChar);
/*      */     }
/*      */     
/*  163 */     this._bufferRecyclable = bufferRecyclable;
/*  164 */     this._outputTail = outputOffset;
/*  165 */     this._outputBuffer = outputBuffer;
/*  166 */     this._outputEnd = this._outputBuffer.length;
/*      */     
/*  168 */     this._outputMaxContiguous = (this._outputEnd >> 3);
/*  169 */     this._charBuffer = ctxt.allocConcatBuffer();
/*  170 */     this._charBufferLength = this._charBuffer.length;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public UTF8JsonGenerator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out)
/*      */   {
/*  176 */     this(ctxt, features, codec, out, '"');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public UTF8JsonGenerator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out, byte[] outputBuffer, int outputOffset, boolean bufferRecyclable)
/*      */   {
/*  184 */     this(ctxt, features, codec, out, '"', outputBuffer, outputOffset, bufferRecyclable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getOutputTarget()
/*      */   {
/*  196 */     return this._outputStream;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getOutputBuffered()
/*      */   {
/*  202 */     return this._outputTail;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeFieldName(String name)
/*      */     throws IOException
/*      */   {
/*  214 */     if (this._cfgPrettyPrinter != null) {
/*  215 */       _writePPFieldName(name);
/*  216 */       return;
/*      */     }
/*  218 */     int status = this._writeContext.writeFieldName(name);
/*  219 */     if (status == 4) {
/*  220 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  222 */     if (status == 1) {
/*  223 */       if (this._outputTail >= this._outputEnd) {
/*  224 */         _flushBuffer();
/*      */       }
/*  226 */       this._outputBuffer[(this._outputTail++)] = 44;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  231 */     if (this._cfgUnqNames) {
/*  232 */       _writeStringSegments(name, false);
/*  233 */       return;
/*      */     }
/*  235 */     int len = name.length();
/*      */     
/*  237 */     if (len > this._charBufferLength) {
/*  238 */       _writeStringSegments(name, true);
/*  239 */       return;
/*      */     }
/*  241 */     if (this._outputTail >= this._outputEnd) {
/*  242 */       _flushBuffer();
/*      */     }
/*  244 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     
/*  246 */     if (len <= this._outputMaxContiguous) {
/*  247 */       if (this._outputTail + len > this._outputEnd) {
/*  248 */         _flushBuffer();
/*      */       }
/*  250 */       _writeStringSegment(name, 0, len);
/*      */     } else {
/*  252 */       _writeStringSegments(name, 0, len);
/*      */     }
/*      */     
/*  255 */     if (this._outputTail >= this._outputEnd) {
/*  256 */       _flushBuffer();
/*      */     }
/*  258 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeFieldName(SerializableString name)
/*      */     throws IOException
/*      */   {
/*  264 */     if (this._cfgPrettyPrinter != null) {
/*  265 */       _writePPFieldName(name);
/*  266 */       return;
/*      */     }
/*  268 */     int status = this._writeContext.writeFieldName(name.getValue());
/*  269 */     if (status == 4) {
/*  270 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  272 */     if (status == 1) {
/*  273 */       if (this._outputTail >= this._outputEnd) {
/*  274 */         _flushBuffer();
/*      */       }
/*  276 */       this._outputBuffer[(this._outputTail++)] = 44;
/*      */     }
/*  278 */     if (this._cfgUnqNames) {
/*  279 */       _writeUnq(name);
/*  280 */       return;
/*      */     }
/*  282 */     if (this._outputTail >= this._outputEnd) {
/*  283 */       _flushBuffer();
/*      */     }
/*  285 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  286 */     int len = name.appendQuotedUTF8(this._outputBuffer, this._outputTail);
/*  287 */     if (len < 0) {
/*  288 */       _writeBytes(name.asQuotedUTF8());
/*      */     } else {
/*  290 */       this._outputTail += len;
/*      */     }
/*  292 */     if (this._outputTail >= this._outputEnd) {
/*  293 */       _flushBuffer();
/*      */     }
/*  295 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   private final void _writeUnq(SerializableString name) throws IOException {
/*  299 */     int len = name.appendQuotedUTF8(this._outputBuffer, this._outputTail);
/*  300 */     if (len < 0) {
/*  301 */       _writeBytes(name.asQuotedUTF8());
/*      */     } else {
/*  303 */       this._outputTail += len;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void writeStartArray()
/*      */     throws IOException
/*      */   {
/*  316 */     _verifyValueWrite("start an array");
/*  317 */     this._writeContext = this._writeContext.createChildArrayContext();
/*  318 */     if (this._cfgPrettyPrinter != null) {
/*  319 */       this._cfgPrettyPrinter.writeStartArray(this);
/*      */     } else {
/*  321 */       if (this._outputTail >= this._outputEnd) {
/*  322 */         _flushBuffer();
/*      */       }
/*  324 */       this._outputBuffer[(this._outputTail++)] = 91;
/*      */     }
/*      */   }
/*      */   
/*      */   public final void writeStartArray(Object currentValue)
/*      */     throws IOException
/*      */   {
/*  331 */     _verifyValueWrite("start an array");
/*  332 */     this._writeContext = this._writeContext.createChildArrayContext(currentValue);
/*  333 */     if (this._cfgPrettyPrinter != null) {
/*  334 */       this._cfgPrettyPrinter.writeStartArray(this);
/*      */     } else {
/*  336 */       if (this._outputTail >= this._outputEnd) {
/*  337 */         _flushBuffer();
/*      */       }
/*  339 */       this._outputBuffer[(this._outputTail++)] = 91;
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeStartArray(Object currentValue, int size)
/*      */     throws IOException
/*      */   {
/*  346 */     _verifyValueWrite("start an array");
/*  347 */     this._writeContext = this._writeContext.createChildArrayContext(currentValue);
/*  348 */     if (this._cfgPrettyPrinter != null) {
/*  349 */       this._cfgPrettyPrinter.writeStartArray(this);
/*      */     } else {
/*  351 */       if (this._outputTail >= this._outputEnd) {
/*  352 */         _flushBuffer();
/*      */       }
/*  354 */       this._outputBuffer[(this._outputTail++)] = 91;
/*      */     }
/*      */   }
/*      */   
/*      */   public final void writeEndArray()
/*      */     throws IOException
/*      */   {
/*  361 */     if (!this._writeContext.inArray()) {
/*  362 */       _reportError("Current context not Array but " + this._writeContext.typeDesc());
/*      */     }
/*  364 */     if (this._cfgPrettyPrinter != null) {
/*  365 */       this._cfgPrettyPrinter.writeEndArray(this, this._writeContext.getEntryCount());
/*      */     } else {
/*  367 */       if (this._outputTail >= this._outputEnd) {
/*  368 */         _flushBuffer();
/*      */       }
/*  370 */       this._outputBuffer[(this._outputTail++)] = 93;
/*      */     }
/*  372 */     this._writeContext = this._writeContext.clearAndGetParent();
/*      */   }
/*      */   
/*      */   public final void writeStartObject()
/*      */     throws IOException
/*      */   {
/*  378 */     _verifyValueWrite("start an object");
/*  379 */     this._writeContext = this._writeContext.createChildObjectContext();
/*  380 */     if (this._cfgPrettyPrinter != null) {
/*  381 */       this._cfgPrettyPrinter.writeStartObject(this);
/*      */     } else {
/*  383 */       if (this._outputTail >= this._outputEnd) {
/*  384 */         _flushBuffer();
/*      */       }
/*  386 */       this._outputBuffer[(this._outputTail++)] = 123;
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeStartObject(Object forValue)
/*      */     throws IOException
/*      */   {
/*  393 */     _verifyValueWrite("start an object");
/*  394 */     JsonWriteContext ctxt = this._writeContext.createChildObjectContext(forValue);
/*  395 */     this._writeContext = ctxt;
/*  396 */     if (this._cfgPrettyPrinter != null) {
/*  397 */       this._cfgPrettyPrinter.writeStartObject(this);
/*      */     } else {
/*  399 */       if (this._outputTail >= this._outputEnd) {
/*  400 */         _flushBuffer();
/*      */       }
/*  402 */       this._outputBuffer[(this._outputTail++)] = 123;
/*      */     }
/*      */   }
/*      */   
/*      */   public final void writeEndObject()
/*      */     throws IOException
/*      */   {
/*  409 */     if (!this._writeContext.inObject()) {
/*  410 */       _reportError("Current context not Object but " + this._writeContext.typeDesc());
/*      */     }
/*  412 */     if (this._cfgPrettyPrinter != null) {
/*  413 */       this._cfgPrettyPrinter.writeEndObject(this, this._writeContext.getEntryCount());
/*      */     } else {
/*  415 */       if (this._outputTail >= this._outputEnd) {
/*  416 */         _flushBuffer();
/*      */       }
/*  418 */       this._outputBuffer[(this._outputTail++)] = 125;
/*      */     }
/*  420 */     this._writeContext = this._writeContext.clearAndGetParent();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _writePPFieldName(String name)
/*      */     throws IOException
/*      */   {
/*  429 */     int status = this._writeContext.writeFieldName(name);
/*  430 */     if (status == 4) {
/*  431 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  433 */     if (status == 1) {
/*  434 */       this._cfgPrettyPrinter.writeObjectEntrySeparator(this);
/*      */     } else {
/*  436 */       this._cfgPrettyPrinter.beforeObjectEntries(this);
/*      */     }
/*  438 */     if (this._cfgUnqNames) {
/*  439 */       _writeStringSegments(name, false);
/*  440 */       return;
/*      */     }
/*  442 */     int len = name.length();
/*  443 */     if (len > this._charBufferLength) {
/*  444 */       _writeStringSegments(name, true);
/*  445 */       return;
/*      */     }
/*  447 */     if (this._outputTail >= this._outputEnd) {
/*  448 */       _flushBuffer();
/*      */     }
/*  450 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  451 */     name.getChars(0, len, this._charBuffer, 0);
/*      */     
/*  453 */     if (len <= this._outputMaxContiguous) {
/*  454 */       if (this._outputTail + len > this._outputEnd) {
/*  455 */         _flushBuffer();
/*      */       }
/*  457 */       _writeStringSegment(this._charBuffer, 0, len);
/*      */     } else {
/*  459 */       _writeStringSegments(this._charBuffer, 0, len);
/*      */     }
/*  461 */     if (this._outputTail >= this._outputEnd) {
/*  462 */       _flushBuffer();
/*      */     }
/*  464 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   protected final void _writePPFieldName(SerializableString name) throws IOException
/*      */   {
/*  469 */     int status = this._writeContext.writeFieldName(name.getValue());
/*  470 */     if (status == 4) {
/*  471 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  473 */     if (status == 1) {
/*  474 */       this._cfgPrettyPrinter.writeObjectEntrySeparator(this);
/*      */     } else {
/*  476 */       this._cfgPrettyPrinter.beforeObjectEntries(this);
/*      */     }
/*      */     
/*  479 */     boolean addQuotes = !this._cfgUnqNames;
/*  480 */     if (addQuotes) {
/*  481 */       if (this._outputTail >= this._outputEnd) {
/*  482 */         _flushBuffer();
/*      */       }
/*  484 */       this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     }
/*  486 */     int len = name.appendQuotedUTF8(this._outputBuffer, this._outputTail);
/*  487 */     if (len < 0) {
/*  488 */       _writeBytes(name.asQuotedUTF8());
/*      */     } else {
/*  490 */       this._outputTail += len;
/*      */     }
/*  492 */     if (addQuotes) {
/*  493 */       if (this._outputTail >= this._outputEnd) {
/*  494 */         _flushBuffer();
/*      */       }
/*  496 */       this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeString(String text)
/*      */     throws IOException
/*      */   {
/*  509 */     _verifyValueWrite("write a string");
/*  510 */     if (text == null) {
/*  511 */       _writeNull();
/*  512 */       return;
/*      */     }
/*      */     
/*  515 */     int len = text.length();
/*  516 */     if (len > this._outputMaxContiguous) {
/*  517 */       _writeStringSegments(text, true);
/*  518 */       return;
/*      */     }
/*  520 */     if (this._outputTail + len >= this._outputEnd) {
/*  521 */       _flushBuffer();
/*      */     }
/*  523 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  524 */     _writeStringSegment(text, 0, len);
/*  525 */     if (this._outputTail >= this._outputEnd) {
/*  526 */       _flushBuffer();
/*      */     }
/*  528 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeString(Reader reader, int len) throws IOException
/*      */   {
/*  533 */     _verifyValueWrite("write a string");
/*  534 */     if (reader == null) {
/*  535 */       _reportError("null reader");
/*  536 */       return;
/*      */     }
/*      */     
/*  539 */     int toRead = len >= 0 ? len : Integer.MAX_VALUE;
/*  540 */     char[] buf = this._charBuffer;
/*      */     
/*      */ 
/*  543 */     if (this._outputTail >= this._outputEnd) {
/*  544 */       _flushBuffer();
/*      */     }
/*  546 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     
/*      */ 
/*  549 */     while (toRead > 0) {
/*  550 */       int toReadNow = Math.min(toRead, buf.length);
/*  551 */       int numRead = reader.read(buf, 0, toReadNow);
/*  552 */       if (numRead <= 0) {
/*      */         break;
/*      */       }
/*  555 */       if (this._outputTail + len >= this._outputEnd) {
/*  556 */         _flushBuffer();
/*      */       }
/*  558 */       _writeStringSegments(buf, 0, numRead);
/*      */       
/*  560 */       toRead -= numRead;
/*      */     }
/*      */     
/*      */ 
/*  564 */     if (this._outputTail >= this._outputEnd) {
/*  565 */       _flushBuffer();
/*      */     }
/*  567 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     
/*  569 */     if ((toRead > 0) && (len >= 0)) {
/*  570 */       _reportError("Didn't read enough from reader");
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeString(char[] text, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  577 */     _verifyValueWrite("write a string");
/*  578 */     if (this._outputTail >= this._outputEnd) {
/*  579 */       _flushBuffer();
/*      */     }
/*  581 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     
/*  583 */     if (len <= this._outputMaxContiguous) {
/*  584 */       if (this._outputTail + len > this._outputEnd) {
/*  585 */         _flushBuffer();
/*      */       }
/*  587 */       _writeStringSegment(text, offset, len);
/*      */     } else {
/*  589 */       _writeStringSegments(text, offset, len);
/*      */     }
/*      */     
/*  592 */     if (this._outputTail >= this._outputEnd) {
/*  593 */       _flushBuffer();
/*      */     }
/*  595 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public final void writeString(SerializableString text)
/*      */     throws IOException
/*      */   {
/*  601 */     _verifyValueWrite("write a string");
/*  602 */     if (this._outputTail >= this._outputEnd) {
/*  603 */       _flushBuffer();
/*      */     }
/*  605 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  606 */     int len = text.appendQuotedUTF8(this._outputBuffer, this._outputTail);
/*  607 */     if (len < 0) {
/*  608 */       _writeBytes(text.asQuotedUTF8());
/*      */     } else {
/*  610 */       this._outputTail += len;
/*      */     }
/*  612 */     if (this._outputTail >= this._outputEnd) {
/*  613 */       _flushBuffer();
/*      */     }
/*  615 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeRawUTF8String(byte[] text, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  621 */     _verifyValueWrite("write a string");
/*  622 */     if (this._outputTail >= this._outputEnd) {
/*  623 */       _flushBuffer();
/*      */     }
/*  625 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  626 */     _writeBytes(text, offset, length);
/*  627 */     if (this._outputTail >= this._outputEnd) {
/*  628 */       _flushBuffer();
/*      */     }
/*  630 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeUTF8String(byte[] text, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  636 */     _verifyValueWrite("write a string");
/*  637 */     if (this._outputTail >= this._outputEnd) {
/*  638 */       _flushBuffer();
/*      */     }
/*  640 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     
/*  642 */     if (len <= this._outputMaxContiguous) {
/*  643 */       _writeUTF8Segment(text, offset, len);
/*      */     } else {
/*  645 */       _writeUTF8Segments(text, offset, len);
/*      */     }
/*  647 */     if (this._outputTail >= this._outputEnd) {
/*  648 */       _flushBuffer();
/*      */     }
/*  650 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeRaw(String text)
/*      */     throws IOException
/*      */   {
/*  661 */     int len = text.length();
/*  662 */     char[] buf = this._charBuffer;
/*  663 */     if (len <= buf.length) {
/*  664 */       text.getChars(0, len, buf, 0);
/*  665 */       writeRaw(buf, 0, len);
/*      */     } else {
/*  667 */       writeRaw(text, 0, len);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRaw(String text, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  674 */     char[] buf = this._charBuffer;
/*  675 */     int cbufLen = buf.length;
/*      */     
/*      */ 
/*  678 */     if (len <= cbufLen) {
/*  679 */       text.getChars(offset, offset + len, buf, 0);
/*  680 */       writeRaw(buf, 0, len);
/*  681 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  687 */     int maxChunk = Math.min(cbufLen, (this._outputEnd >> 2) + (this._outputEnd >> 4));
/*      */     
/*  689 */     int maxBytes = maxChunk * 3;
/*      */     
/*  691 */     while (len > 0) {
/*  692 */       int len2 = Math.min(maxChunk, len);
/*  693 */       text.getChars(offset, offset + len2, buf, 0);
/*  694 */       if (this._outputTail + maxBytes > this._outputEnd) {
/*  695 */         _flushBuffer();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  703 */       if (len2 > 1) {
/*  704 */         char ch = buf[(len2 - 1)];
/*  705 */         if ((ch >= 55296) && (ch <= 56319)) {
/*  706 */           len2--;
/*      */         }
/*      */       }
/*  709 */       _writeRawSegment(buf, 0, len2);
/*  710 */       offset += len2;
/*  711 */       len -= len2;
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRaw(SerializableString text)
/*      */     throws IOException
/*      */   {
/*  718 */     int len = text.appendUnquotedUTF8(this._outputBuffer, this._outputTail);
/*  719 */     if (len < 0) {
/*  720 */       _writeBytes(text.asUnquotedUTF8());
/*      */     } else {
/*  722 */       this._outputTail += len;
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRawValue(SerializableString text)
/*      */     throws IOException
/*      */   {
/*  729 */     _verifyValueWrite("write a raw (unencoded) value");
/*  730 */     int len = text.appendUnquotedUTF8(this._outputBuffer, this._outputTail);
/*  731 */     if (len < 0) {
/*  732 */       _writeBytes(text.asUnquotedUTF8());
/*      */     } else {
/*  734 */       this._outputTail += len;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void writeRaw(char[] cbuf, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  744 */     int len3 = len + len + len;
/*  745 */     if (this._outputTail + len3 > this._outputEnd)
/*      */     {
/*  747 */       if (this._outputEnd < len3) {
/*  748 */         _writeSegmentedRaw(cbuf, offset, len);
/*  749 */         return;
/*      */       }
/*      */       
/*  752 */       _flushBuffer();
/*      */     }
/*      */     
/*  755 */     len += offset;
/*      */     
/*      */ 
/*      */ 
/*  759 */     while (offset < len)
/*      */     {
/*      */       for (;;) {
/*  762 */         int ch = cbuf[offset];
/*  763 */         if (ch > 127) {
/*      */           break;
/*      */         }
/*  766 */         this._outputBuffer[(this._outputTail++)] = ((byte)ch);
/*  767 */         offset++; if (offset >= len) {
/*      */           return;
/*      */         }
/*      */       }
/*  771 */       char ch = cbuf[(offset++)];
/*  772 */       if (ch < 'ࠀ') {
/*  773 */         this._outputBuffer[(this._outputTail++)] = ((byte)(0xC0 | ch >> '\006'));
/*  774 */         this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | ch & 0x3F));
/*      */       } else {
/*  776 */         offset = _outputRawMultiByteChar(ch, cbuf, offset, len);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeRaw(char ch)
/*      */     throws IOException
/*      */   {
/*  784 */     if (this._outputTail + 3 >= this._outputEnd) {
/*  785 */       _flushBuffer();
/*      */     }
/*  787 */     byte[] bbuf = this._outputBuffer;
/*  788 */     if (ch <= '') {
/*  789 */       bbuf[(this._outputTail++)] = ((byte)ch);
/*  790 */     } else if (ch < 'ࠀ') {
/*  791 */       bbuf[(this._outputTail++)] = ((byte)(0xC0 | ch >> '\006'));
/*  792 */       bbuf[(this._outputTail++)] = ((byte)(0x80 | ch & 0x3F));
/*      */     } else {
/*  794 */       _outputRawMultiByteChar(ch, null, 0, 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeSegmentedRaw(char[] cbuf, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  804 */     int end = this._outputEnd;
/*  805 */     byte[] bbuf = this._outputBuffer;
/*  806 */     int inputEnd = offset + len;
/*      */     
/*      */ 
/*  809 */     while (offset < inputEnd)
/*      */     {
/*      */       for (;;) {
/*  812 */         int ch = cbuf[offset];
/*  813 */         if (ch >= 128) {
/*      */           break;
/*      */         }
/*      */         
/*  817 */         if (this._outputTail >= end) {
/*  818 */           _flushBuffer();
/*      */         }
/*  820 */         bbuf[(this._outputTail++)] = ((byte)ch);
/*  821 */         offset++; if (offset >= inputEnd) {
/*      */           return;
/*      */         }
/*      */       }
/*  825 */       if (this._outputTail + 3 >= this._outputEnd) {
/*  826 */         _flushBuffer();
/*      */       }
/*  828 */       char ch = cbuf[(offset++)];
/*  829 */       if (ch < 'ࠀ') {
/*  830 */         bbuf[(this._outputTail++)] = ((byte)(0xC0 | ch >> '\006'));
/*  831 */         bbuf[(this._outputTail++)] = ((byte)(0x80 | ch & 0x3F));
/*      */       } else {
/*  833 */         offset = _outputRawMultiByteChar(ch, cbuf, offset, inputEnd);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _writeRawSegment(char[] cbuf, int offset, int end)
/*      */     throws IOException
/*      */   {
/*  850 */     while (offset < end)
/*      */     {
/*      */       for (;;) {
/*  853 */         int ch = cbuf[offset];
/*  854 */         if (ch > 127) {
/*      */           break;
/*      */         }
/*  857 */         this._outputBuffer[(this._outputTail++)] = ((byte)ch);
/*  858 */         offset++; if (offset >= end) {
/*      */           return;
/*      */         }
/*      */       }
/*  862 */       char ch = cbuf[(offset++)];
/*  863 */       if (ch < 'ࠀ') {
/*  864 */         this._outputBuffer[(this._outputTail++)] = ((byte)(0xC0 | ch >> '\006'));
/*  865 */         this._outputBuffer[(this._outputTail++)] = ((byte)(0x80 | ch & 0x3F));
/*      */       } else {
/*  867 */         offset = _outputRawMultiByteChar(ch, cbuf, offset, end);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  883 */     _verifyValueWrite("write a binary value");
/*      */     
/*  885 */     if (this._outputTail >= this._outputEnd) {
/*  886 */       _flushBuffer();
/*      */     }
/*  888 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  889 */     _writeBinary(b64variant, data, offset, offset + len);
/*      */     
/*  891 */     if (this._outputTail >= this._outputEnd) {
/*  892 */       _flushBuffer();
/*      */     }
/*  894 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*  902 */     _verifyValueWrite("write a binary value");
/*      */     
/*  904 */     if (this._outputTail >= this._outputEnd) {
/*  905 */       _flushBuffer();
/*      */     }
/*  907 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  908 */     byte[] encodingBuffer = this._ioContext.allocBase64Buffer();
/*      */     try {
/*      */       int bytes;
/*  911 */       if (dataLength < 0) {
/*  912 */         bytes = _writeBinary(b64variant, data, encodingBuffer);
/*      */       } else {
/*  914 */         int missing = _writeBinary(b64variant, data, encodingBuffer, dataLength);
/*  915 */         if (missing > 0) {
/*  916 */           _reportError("Too few bytes available: missing " + missing + " bytes (out of " + dataLength + ")");
/*      */         }
/*  918 */         bytes = dataLength;
/*      */       }
/*      */     } finally { int bytes;
/*  921 */       this._ioContext.releaseBase64Buffer(encodingBuffer);
/*      */     }
/*      */     int bytes;
/*  924 */     if (this._outputTail >= this._outputEnd) {
/*  925 */       _flushBuffer();
/*      */     }
/*  927 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  928 */     return bytes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumber(short s)
/*      */     throws IOException
/*      */   {
/*  940 */     _verifyValueWrite("write a number");
/*      */     
/*  942 */     if (this._outputTail + 6 >= this._outputEnd) {
/*  943 */       _flushBuffer();
/*      */     }
/*  945 */     if (this._cfgNumbersAsStrings) {
/*  946 */       _writeQuotedShort(s);
/*  947 */       return;
/*      */     }
/*  949 */     this._outputTail = NumberOutput.outputInt(s, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private final void _writeQuotedShort(short s) throws IOException {
/*  953 */     if (this._outputTail + 8 >= this._outputEnd) {
/*  954 */       _flushBuffer();
/*      */     }
/*  956 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  957 */     this._outputTail = NumberOutput.outputInt(s, this._outputBuffer, this._outputTail);
/*  958 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeNumber(int i)
/*      */     throws IOException
/*      */   {
/*  964 */     _verifyValueWrite("write a number");
/*      */     
/*  966 */     if (this._outputTail + 11 >= this._outputEnd) {
/*  967 */       _flushBuffer();
/*      */     }
/*  969 */     if (this._cfgNumbersAsStrings) {
/*  970 */       _writeQuotedInt(i);
/*  971 */       return;
/*      */     }
/*  973 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private final void _writeQuotedInt(int i) throws IOException
/*      */   {
/*  978 */     if (this._outputTail + 13 >= this._outputEnd) {
/*  979 */       _flushBuffer();
/*      */     }
/*  981 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*  982 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*  983 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeNumber(long l)
/*      */     throws IOException
/*      */   {
/*  989 */     _verifyValueWrite("write a number");
/*  990 */     if (this._cfgNumbersAsStrings) {
/*  991 */       _writeQuotedLong(l);
/*  992 */       return;
/*      */     }
/*  994 */     if (this._outputTail + 21 >= this._outputEnd)
/*      */     {
/*  996 */       _flushBuffer();
/*      */     }
/*  998 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private final void _writeQuotedLong(long l) throws IOException
/*      */   {
/* 1003 */     if (this._outputTail + 23 >= this._outputEnd) {
/* 1004 */       _flushBuffer();
/*      */     }
/* 1006 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/* 1007 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/* 1008 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeNumber(BigInteger value)
/*      */     throws IOException
/*      */   {
/* 1014 */     _verifyValueWrite("write a number");
/* 1015 */     if (value == null) {
/* 1016 */       _writeNull();
/* 1017 */     } else if (this._cfgNumbersAsStrings) {
/* 1018 */       _writeQuotedRaw(value.toString());
/*      */     } else {
/* 1020 */       writeRaw(value.toString());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeNumber(double d)
/*      */     throws IOException
/*      */   {
/* 1028 */     if ((this._cfgNumbersAsStrings) || (
/* 1029 */       (NumberOutput.notFinite(d)) && 
/* 1030 */       (JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS.enabledIn(this._features)))) {
/* 1031 */       writeString(String.valueOf(d));
/* 1032 */       return;
/*      */     }
/*      */     
/* 1035 */     _verifyValueWrite("write a number");
/* 1036 */     writeRaw(String.valueOf(d));
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeNumber(float f)
/*      */     throws IOException
/*      */   {
/* 1043 */     if ((this._cfgNumbersAsStrings) || (
/* 1044 */       (NumberOutput.notFinite(f)) && 
/* 1045 */       (JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS.enabledIn(this._features)))) {
/* 1046 */       writeString(String.valueOf(f));
/* 1047 */       return;
/*      */     }
/*      */     
/* 1050 */     _verifyValueWrite("write a number");
/* 1051 */     writeRaw(String.valueOf(f));
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeNumber(java.math.BigDecimal value)
/*      */     throws IOException
/*      */   {
/* 1058 */     _verifyValueWrite("write a number");
/* 1059 */     if (value == null) {
/* 1060 */       _writeNull();
/* 1061 */     } else if (this._cfgNumbersAsStrings) {
/* 1062 */       _writeQuotedRaw(_asString(value));
/*      */     } else {
/* 1064 */       writeRaw(_asString(value));
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeNumber(String encodedValue)
/*      */     throws IOException
/*      */   {
/* 1071 */     _verifyValueWrite("write a number");
/* 1072 */     if (encodedValue == null) {
/* 1073 */       _writeNull();
/* 1074 */     } else if (this._cfgNumbersAsStrings) {
/* 1075 */       _writeQuotedRaw(encodedValue);
/*      */     } else {
/* 1077 */       writeRaw(encodedValue);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeNumber(char[] encodedValueBuffer, int offset, int length) throws IOException
/*      */   {
/* 1083 */     _verifyValueWrite("write a number");
/* 1084 */     if (this._cfgNumbersAsStrings) {
/* 1085 */       _writeQuotedRaw(encodedValueBuffer, offset, length);
/*      */     } else {
/* 1087 */       writeRaw(encodedValueBuffer, offset, length);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void _writeQuotedRaw(String value) throws IOException
/*      */   {
/* 1093 */     if (this._outputTail >= this._outputEnd) {
/* 1094 */       _flushBuffer();
/*      */     }
/* 1096 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/* 1097 */     writeRaw(value);
/* 1098 */     if (this._outputTail >= this._outputEnd) {
/* 1099 */       _flushBuffer();
/*      */     }
/* 1101 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   private void _writeQuotedRaw(char[] text, int offset, int length) throws IOException
/*      */   {
/* 1106 */     if (this._outputTail >= this._outputEnd) {
/* 1107 */       _flushBuffer();
/*      */     }
/* 1109 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/* 1110 */     writeRaw(text, offset, length);
/* 1111 */     if (this._outputTail >= this._outputEnd) {
/* 1112 */       _flushBuffer();
/*      */     }
/* 1114 */     this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */   }
/*      */   
/*      */   public void writeBoolean(boolean state)
/*      */     throws IOException
/*      */   {
/* 1120 */     _verifyValueWrite("write a boolean value");
/* 1121 */     if (this._outputTail + 5 >= this._outputEnd) {
/* 1122 */       _flushBuffer();
/*      */     }
/* 1124 */     byte[] keyword = state ? TRUE_BYTES : FALSE_BYTES;
/* 1125 */     int len = keyword.length;
/* 1126 */     System.arraycopy(keyword, 0, this._outputBuffer, this._outputTail, len);
/* 1127 */     this._outputTail += len;
/*      */   }
/*      */   
/*      */   public void writeNull()
/*      */     throws IOException
/*      */   {
/* 1133 */     _verifyValueWrite("write a null");
/* 1134 */     _writeNull();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _verifyValueWrite(String typeMsg)
/*      */     throws IOException
/*      */   {
/* 1146 */     int status = this._writeContext.writeValue();
/* 1147 */     if (this._cfgPrettyPrinter != null)
/*      */     {
/* 1149 */       _verifyPrettyValueWrite(typeMsg, status); return;
/*      */     }
/*      */     byte b;
/*      */     byte b;
/* 1153 */     switch (status) {
/*      */     case 0: case 4: 
/*      */     default: 
/* 1156 */       return;
/*      */     case 1: 
/* 1158 */       b = 44;
/* 1159 */       break;
/*      */     case 2: 
/* 1161 */       b = 58;
/* 1162 */       break;
/*      */     case 3: 
/* 1164 */       if (this._rootValueSeparator != null) {
/* 1165 */         byte[] raw = this._rootValueSeparator.asUnquotedUTF8();
/* 1166 */         if (raw.length > 0) {
/* 1167 */           _writeBytes(raw);
/*      */         }
/*      */       }
/* 1170 */       return;
/*      */     case 5: 
/* 1172 */       _reportCantWriteValueExpectName(typeMsg); return;
/*      */     }
/*      */     byte b;
/* 1175 */     if (this._outputTail >= this._outputEnd) {
/* 1176 */       _flushBuffer();
/*      */     }
/* 1178 */     this._outputBuffer[(this._outputTail++)] = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void flush()
/*      */     throws IOException
/*      */   {
/* 1190 */     _flushBuffer();
/* 1191 */     if ((this._outputStream != null) && 
/* 1192 */       (isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM))) {
/* 1193 */       this._outputStream.flush();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/* 1201 */     super.close();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1207 */     if ((this._outputBuffer != null) && 
/* 1208 */       (isEnabled(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT))) {
/*      */       for (;;) {
/* 1210 */         JsonStreamContext ctxt = getOutputContext();
/* 1211 */         if (ctxt.inArray()) {
/* 1212 */           writeEndArray();
/* 1213 */         } else { if (!ctxt.inObject()) break;
/* 1214 */           writeEndObject();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1220 */     _flushBuffer();
/* 1221 */     this._outputTail = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1229 */     if (this._outputStream != null) {
/* 1230 */       if ((this._ioContext.isResourceManaged()) || (isEnabled(JsonGenerator.Feature.AUTO_CLOSE_TARGET))) {
/* 1231 */         this._outputStream.close();
/* 1232 */       } else if (isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM))
/*      */       {
/* 1234 */         this._outputStream.flush();
/*      */       }
/*      */     }
/*      */     
/* 1238 */     _releaseBuffers();
/*      */   }
/*      */   
/*      */ 
/*      */   protected void _releaseBuffers()
/*      */   {
/* 1244 */     byte[] buf = this._outputBuffer;
/* 1245 */     if ((buf != null) && (this._bufferRecyclable)) {
/* 1246 */       this._outputBuffer = null;
/* 1247 */       this._ioContext.releaseWriteEncodingBuffer(buf);
/*      */     }
/* 1249 */     char[] cbuf = this._charBuffer;
/* 1250 */     if (cbuf != null) {
/* 1251 */       this._charBuffer = null;
/* 1252 */       this._ioContext.releaseConcatBuffer(cbuf);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeBytes(byte[] bytes)
/*      */     throws IOException
/*      */   {
/* 1264 */     int len = bytes.length;
/* 1265 */     if (this._outputTail + len > this._outputEnd) {
/* 1266 */       _flushBuffer();
/*      */       
/* 1268 */       if (len > 512) {
/* 1269 */         this._outputStream.write(bytes, 0, len);
/* 1270 */         return;
/*      */       }
/*      */     }
/* 1273 */     System.arraycopy(bytes, 0, this._outputBuffer, this._outputTail, len);
/* 1274 */     this._outputTail += len;
/*      */   }
/*      */   
/*      */   private final void _writeBytes(byte[] bytes, int offset, int len) throws IOException
/*      */   {
/* 1279 */     if (this._outputTail + len > this._outputEnd) {
/* 1280 */       _flushBuffer();
/*      */       
/* 1282 */       if (len > 512) {
/* 1283 */         this._outputStream.write(bytes, offset, len);
/* 1284 */         return;
/*      */       }
/*      */     }
/* 1287 */     System.arraycopy(bytes, offset, this._outputBuffer, this._outputTail, len);
/* 1288 */     this._outputTail += len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeStringSegments(String text, boolean addQuotes)
/*      */     throws IOException
/*      */   {
/* 1306 */     if (addQuotes) {
/* 1307 */       if (this._outputTail >= this._outputEnd) {
/* 1308 */         _flushBuffer();
/*      */       }
/* 1310 */       this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     }
/*      */     
/* 1313 */     int left = text.length();
/* 1314 */     int offset = 0;
/*      */     
/* 1316 */     while (left > 0) {
/* 1317 */       int len = Math.min(this._outputMaxContiguous, left);
/* 1318 */       if (this._outputTail + len > this._outputEnd) {
/* 1319 */         _flushBuffer();
/*      */       }
/* 1321 */       _writeStringSegment(text, offset, len);
/* 1322 */       offset += len;
/* 1323 */       left -= len;
/*      */     }
/*      */     
/* 1326 */     if (addQuotes) {
/* 1327 */       if (this._outputTail >= this._outputEnd) {
/* 1328 */         _flushBuffer();
/*      */       }
/* 1330 */       this._outputBuffer[(this._outputTail++)] = this._quoteChar;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeStringSegments(char[] cbuf, int offset, int totalLen)
/*      */     throws IOException
/*      */   {
/*      */     do
/*      */     {
/* 1343 */       int len = Math.min(this._outputMaxContiguous, totalLen);
/* 1344 */       if (this._outputTail + len > this._outputEnd) {
/* 1345 */         _flushBuffer();
/*      */       }
/* 1347 */       _writeStringSegment(cbuf, offset, len);
/* 1348 */       offset += len;
/* 1349 */       totalLen -= len;
/* 1350 */     } while (totalLen > 0);
/*      */   }
/*      */   
/*      */   private final void _writeStringSegments(String text, int offset, int totalLen) throws IOException
/*      */   {
/*      */     do {
/* 1356 */       int len = Math.min(this._outputMaxContiguous, totalLen);
/* 1357 */       if (this._outputTail + len > this._outputEnd) {
/* 1358 */         _flushBuffer();
/*      */       }
/* 1360 */       _writeStringSegment(text, offset, len);
/* 1361 */       offset += len;
/* 1362 */       totalLen -= len;
/* 1363 */     } while (totalLen > 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeStringSegment(char[] cbuf, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 1386 */     len += offset;
/*      */     
/* 1388 */     int outputPtr = this._outputTail;
/* 1389 */     byte[] outputBuffer = this._outputBuffer;
/* 1390 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1392 */     while (offset < len) {
/* 1393 */       int ch = cbuf[offset];
/*      */       
/* 1395 */       if ((ch > 127) || (escCodes[ch] != 0)) {
/*      */         break;
/*      */       }
/* 1398 */       outputBuffer[(outputPtr++)] = ((byte)ch);
/* 1399 */       offset++;
/*      */     }
/* 1401 */     this._outputTail = outputPtr;
/* 1402 */     if (offset < len) {
/* 1403 */       if (this._characterEscapes != null) {
/* 1404 */         _writeCustomStringSegment2(cbuf, offset, len);
/* 1405 */       } else if (this._maximumNonEscapedChar == 0) {
/* 1406 */         _writeStringSegment2(cbuf, offset, len);
/*      */       } else {
/* 1408 */         _writeStringSegmentASCII2(cbuf, offset, len);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private final void _writeStringSegment(String text, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 1418 */     len += offset;
/*      */     
/* 1420 */     int outputPtr = this._outputTail;
/* 1421 */     byte[] outputBuffer = this._outputBuffer;
/* 1422 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1424 */     while (offset < len) {
/* 1425 */       int ch = text.charAt(offset);
/*      */       
/* 1427 */       if ((ch > 127) || (escCodes[ch] != 0)) {
/*      */         break;
/*      */       }
/* 1430 */       outputBuffer[(outputPtr++)] = ((byte)ch);
/* 1431 */       offset++;
/*      */     }
/* 1433 */     this._outputTail = outputPtr;
/* 1434 */     if (offset < len) {
/* 1435 */       if (this._characterEscapes != null) {
/* 1436 */         _writeCustomStringSegment2(text, offset, len);
/* 1437 */       } else if (this._maximumNonEscapedChar == 0) {
/* 1438 */         _writeStringSegment2(text, offset, len);
/*      */       } else {
/* 1440 */         _writeStringSegmentASCII2(text, offset, len);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeStringSegment2(char[] cbuf, int offset, int end)
/*      */     throws IOException
/*      */   {
/* 1452 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1453 */       _flushBuffer();
/*      */     }
/*      */     
/* 1456 */     int outputPtr = this._outputTail;
/*      */     
/* 1458 */     byte[] outputBuffer = this._outputBuffer;
/* 1459 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1461 */     while (offset < end) {
/* 1462 */       int ch = cbuf[(offset++)];
/* 1463 */       if (ch <= 127) {
/* 1464 */         if (escCodes[ch] == 0) {
/* 1465 */           outputBuffer[(outputPtr++)] = ((byte)ch);
/*      */         }
/*      */         else {
/* 1468 */           int escape = escCodes[ch];
/* 1469 */           if (escape > 0) {
/* 1470 */             outputBuffer[(outputPtr++)] = 92;
/* 1471 */             outputBuffer[(outputPtr++)] = ((byte)escape);
/*      */           }
/*      */           else {
/* 1474 */             outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */           }
/*      */         }
/*      */       }
/* 1478 */       else if (ch <= 2047) {
/* 1479 */         outputBuffer[(outputPtr++)] = ((byte)(0xC0 | ch >> 6));
/* 1480 */         outputBuffer[(outputPtr++)] = ((byte)(0x80 | ch & 0x3F));
/*      */       } else {
/* 1482 */         outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */       }
/*      */     }
/* 1485 */     this._outputTail = outputPtr;
/*      */   }
/*      */   
/*      */   private final void _writeStringSegment2(String text, int offset, int end) throws IOException
/*      */   {
/* 1490 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1491 */       _flushBuffer();
/*      */     }
/*      */     
/* 1494 */     int outputPtr = this._outputTail;
/*      */     
/* 1496 */     byte[] outputBuffer = this._outputBuffer;
/* 1497 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1499 */     while (offset < end) {
/* 1500 */       int ch = text.charAt(offset++);
/* 1501 */       if (ch <= 127) {
/* 1502 */         if (escCodes[ch] == 0) {
/* 1503 */           outputBuffer[(outputPtr++)] = ((byte)ch);
/*      */         }
/*      */         else {
/* 1506 */           int escape = escCodes[ch];
/* 1507 */           if (escape > 0) {
/* 1508 */             outputBuffer[(outputPtr++)] = 92;
/* 1509 */             outputBuffer[(outputPtr++)] = ((byte)escape);
/*      */           }
/*      */           else {
/* 1512 */             outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */           }
/*      */         }
/*      */       }
/* 1516 */       else if (ch <= 2047) {
/* 1517 */         outputBuffer[(outputPtr++)] = ((byte)(0xC0 | ch >> 6));
/* 1518 */         outputBuffer[(outputPtr++)] = ((byte)(0x80 | ch & 0x3F));
/*      */       } else {
/* 1520 */         outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */       }
/*      */     }
/* 1523 */     this._outputTail = outputPtr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeStringSegmentASCII2(char[] cbuf, int offset, int end)
/*      */     throws IOException
/*      */   {
/* 1540 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1541 */       _flushBuffer();
/*      */     }
/* 1543 */     int outputPtr = this._outputTail;
/*      */     
/* 1545 */     byte[] outputBuffer = this._outputBuffer;
/* 1546 */     int[] escCodes = this._outputEscapes;
/* 1547 */     int maxUnescaped = this._maximumNonEscapedChar;
/*      */     
/* 1549 */     while (offset < end) {
/* 1550 */       int ch = cbuf[(offset++)];
/* 1551 */       if (ch <= 127) {
/* 1552 */         if (escCodes[ch] == 0) {
/* 1553 */           outputBuffer[(outputPtr++)] = ((byte)ch);
/*      */         }
/*      */         else {
/* 1556 */           int escape = escCodes[ch];
/* 1557 */           if (escape > 0) {
/* 1558 */             outputBuffer[(outputPtr++)] = 92;
/* 1559 */             outputBuffer[(outputPtr++)] = ((byte)escape);
/*      */           }
/*      */           else {
/* 1562 */             outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */           }
/*      */         }
/*      */       }
/* 1566 */       else if (ch > maxUnescaped) {
/* 1567 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */ 
/*      */       }
/* 1570 */       else if (ch <= 2047) {
/* 1571 */         outputBuffer[(outputPtr++)] = ((byte)(0xC0 | ch >> 6));
/* 1572 */         outputBuffer[(outputPtr++)] = ((byte)(0x80 | ch & 0x3F));
/*      */       } else {
/* 1574 */         outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */       }
/*      */     }
/* 1577 */     this._outputTail = outputPtr;
/*      */   }
/*      */   
/*      */   private final void _writeStringSegmentASCII2(String text, int offset, int end)
/*      */     throws IOException
/*      */   {
/* 1583 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1584 */       _flushBuffer();
/*      */     }
/*      */     
/* 1587 */     int outputPtr = this._outputTail;
/*      */     
/* 1589 */     byte[] outputBuffer = this._outputBuffer;
/* 1590 */     int[] escCodes = this._outputEscapes;
/* 1591 */     int maxUnescaped = this._maximumNonEscapedChar;
/*      */     
/* 1593 */     while (offset < end) {
/* 1594 */       int ch = text.charAt(offset++);
/* 1595 */       if (ch <= 127) {
/* 1596 */         if (escCodes[ch] == 0) {
/* 1597 */           outputBuffer[(outputPtr++)] = ((byte)ch);
/*      */         }
/*      */         else {
/* 1600 */           int escape = escCodes[ch];
/* 1601 */           if (escape > 0) {
/* 1602 */             outputBuffer[(outputPtr++)] = 92;
/* 1603 */             outputBuffer[(outputPtr++)] = ((byte)escape);
/*      */           }
/*      */           else {
/* 1606 */             outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */           }
/*      */         }
/*      */       }
/* 1610 */       else if (ch > maxUnescaped) {
/* 1611 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */ 
/*      */       }
/* 1614 */       else if (ch <= 2047) {
/* 1615 */         outputBuffer[(outputPtr++)] = ((byte)(0xC0 | ch >> 6));
/* 1616 */         outputBuffer[(outputPtr++)] = ((byte)(0x80 | ch & 0x3F));
/*      */       } else {
/* 1618 */         outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */       }
/*      */     }
/* 1621 */     this._outputTail = outputPtr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeCustomStringSegment2(char[] cbuf, int offset, int end)
/*      */     throws IOException
/*      */   {
/* 1638 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1639 */       _flushBuffer();
/*      */     }
/* 1641 */     int outputPtr = this._outputTail;
/*      */     
/* 1643 */     byte[] outputBuffer = this._outputBuffer;
/* 1644 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1646 */     int maxUnescaped = this._maximumNonEscapedChar <= 0 ? 65535 : this._maximumNonEscapedChar;
/* 1647 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/* 1649 */     while (offset < end) {
/* 1650 */       int ch = cbuf[(offset++)];
/* 1651 */       if (ch <= 127) {
/* 1652 */         if (escCodes[ch] == 0) {
/* 1653 */           outputBuffer[(outputPtr++)] = ((byte)ch);
/*      */         }
/*      */         else {
/* 1656 */           int escape = escCodes[ch];
/* 1657 */           if (escape > 0) {
/* 1658 */             outputBuffer[(outputPtr++)] = 92;
/* 1659 */             outputBuffer[(outputPtr++)] = ((byte)escape);
/* 1660 */           } else if (escape == -2) {
/* 1661 */             SerializableString esc = customEscapes.getEscapeSequence(ch);
/* 1662 */             if (esc == null) {
/* 1663 */               _reportError("Invalid custom escape definitions; custom escape not found for character code 0x" + 
/* 1664 */                 Integer.toHexString(ch) + ", although was supposed to have one");
/*      */             }
/* 1666 */             outputPtr = _writeCustomEscape(outputBuffer, outputPtr, esc, end - offset);
/*      */           }
/*      */           else {
/* 1669 */             outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */           }
/*      */         }
/*      */       }
/* 1673 */       else if (ch > maxUnescaped) {
/* 1674 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */       }
/*      */       else {
/* 1677 */         SerializableString esc = customEscapes.getEscapeSequence(ch);
/* 1678 */         if (esc != null) {
/* 1679 */           outputPtr = _writeCustomEscape(outputBuffer, outputPtr, esc, end - offset);
/*      */ 
/*      */         }
/* 1682 */         else if (ch <= 2047) {
/* 1683 */           outputBuffer[(outputPtr++)] = ((byte)(0xC0 | ch >> 6));
/* 1684 */           outputBuffer[(outputPtr++)] = ((byte)(0x80 | ch & 0x3F));
/*      */         } else {
/* 1686 */           outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */         }
/*      */       } }
/* 1689 */     this._outputTail = outputPtr;
/*      */   }
/*      */   
/*      */   private final void _writeCustomStringSegment2(String text, int offset, int end)
/*      */     throws IOException
/*      */   {
/* 1695 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1696 */       _flushBuffer();
/*      */     }
/* 1698 */     int outputPtr = this._outputTail;
/*      */     
/* 1700 */     byte[] outputBuffer = this._outputBuffer;
/* 1701 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1703 */     int maxUnescaped = this._maximumNonEscapedChar <= 0 ? 65535 : this._maximumNonEscapedChar;
/* 1704 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/* 1706 */     while (offset < end) {
/* 1707 */       int ch = text.charAt(offset++);
/* 1708 */       if (ch <= 127) {
/* 1709 */         if (escCodes[ch] == 0) {
/* 1710 */           outputBuffer[(outputPtr++)] = ((byte)ch);
/*      */         }
/*      */         else {
/* 1713 */           int escape = escCodes[ch];
/* 1714 */           if (escape > 0) {
/* 1715 */             outputBuffer[(outputPtr++)] = 92;
/* 1716 */             outputBuffer[(outputPtr++)] = ((byte)escape);
/* 1717 */           } else if (escape == -2) {
/* 1718 */             SerializableString esc = customEscapes.getEscapeSequence(ch);
/* 1719 */             if (esc == null) {
/* 1720 */               _reportError("Invalid custom escape definitions; custom escape not found for character code 0x" + 
/* 1721 */                 Integer.toHexString(ch) + ", although was supposed to have one");
/*      */             }
/* 1723 */             outputPtr = _writeCustomEscape(outputBuffer, outputPtr, esc, end - offset);
/*      */           }
/*      */           else {
/* 1726 */             outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */           }
/*      */         }
/*      */       }
/* 1730 */       else if (ch > maxUnescaped) {
/* 1731 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */       }
/*      */       else {
/* 1734 */         SerializableString esc = customEscapes.getEscapeSequence(ch);
/* 1735 */         if (esc != null) {
/* 1736 */           outputPtr = _writeCustomEscape(outputBuffer, outputPtr, esc, end - offset);
/*      */ 
/*      */         }
/* 1739 */         else if (ch <= 2047) {
/* 1740 */           outputBuffer[(outputPtr++)] = ((byte)(0xC0 | ch >> 6));
/* 1741 */           outputBuffer[(outputPtr++)] = ((byte)(0x80 | ch & 0x3F));
/*      */         } else {
/* 1743 */           outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */         }
/*      */       } }
/* 1746 */     this._outputTail = outputPtr;
/*      */   }
/*      */   
/*      */   private final int _writeCustomEscape(byte[] outputBuffer, int outputPtr, SerializableString esc, int remainingChars)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1752 */     byte[] raw = esc.asUnquotedUTF8();
/* 1753 */     int len = raw.length;
/* 1754 */     if (len > 6) {
/* 1755 */       return _handleLongCustomEscape(outputBuffer, outputPtr, this._outputEnd, raw, remainingChars);
/*      */     }
/*      */     
/* 1758 */     System.arraycopy(raw, 0, outputBuffer, outputPtr, len);
/* 1759 */     return outputPtr + len;
/*      */   }
/*      */   
/*      */ 
/*      */   private final int _handleLongCustomEscape(byte[] outputBuffer, int outputPtr, int outputEnd, byte[] raw, int remainingChars)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1766 */     int len = raw.length;
/* 1767 */     if (outputPtr + len > outputEnd) {
/* 1768 */       this._outputTail = outputPtr;
/* 1769 */       _flushBuffer();
/* 1770 */       outputPtr = this._outputTail;
/* 1771 */       if (len > outputBuffer.length) {
/* 1772 */         this._outputStream.write(raw, 0, len);
/* 1773 */         return outputPtr;
/*      */       }
/*      */     }
/* 1776 */     System.arraycopy(raw, 0, outputBuffer, outputPtr, len);
/* 1777 */     outputPtr += len;
/*      */     
/* 1779 */     if (outputPtr + 6 * remainingChars > outputEnd) {
/* 1780 */       this._outputTail = outputPtr;
/* 1781 */       _flushBuffer();
/* 1782 */       return this._outputTail;
/*      */     }
/* 1784 */     return outputPtr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeUTF8Segments(byte[] utf8, int offset, int totalLen)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/*      */     do
/*      */     {
/* 1802 */       int len = Math.min(this._outputMaxContiguous, totalLen);
/* 1803 */       _writeUTF8Segment(utf8, offset, len);
/* 1804 */       offset += len;
/* 1805 */       totalLen -= len;
/* 1806 */     } while (totalLen > 0);
/*      */   }
/*      */   
/*      */ 
/*      */   private final void _writeUTF8Segment(byte[] utf8, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1813 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1815 */     int ptr = offset; for (int end = offset + len; ptr < end;)
/*      */     {
/* 1817 */       int ch = utf8[(ptr++)];
/* 1818 */       if ((ch >= 0) && (escCodes[ch] != 0)) {
/* 1819 */         _writeUTF8Segment2(utf8, offset, len);
/* 1820 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1825 */     if (this._outputTail + len > this._outputEnd) {
/* 1826 */       _flushBuffer();
/*      */     }
/* 1828 */     System.arraycopy(utf8, offset, this._outputBuffer, this._outputTail, len);
/* 1829 */     this._outputTail += len;
/*      */   }
/*      */   
/*      */   private final void _writeUTF8Segment2(byte[] utf8, int offset, int len)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1835 */     int outputPtr = this._outputTail;
/*      */     
/*      */ 
/* 1838 */     if (outputPtr + len * 6 > this._outputEnd) {
/* 1839 */       _flushBuffer();
/* 1840 */       outputPtr = this._outputTail;
/*      */     }
/*      */     
/* 1843 */     byte[] outputBuffer = this._outputBuffer;
/* 1844 */     int[] escCodes = this._outputEscapes;
/* 1845 */     len += offset;
/*      */     
/* 1847 */     while (offset < len) {
/* 1848 */       byte b = utf8[(offset++)];
/* 1849 */       int ch = b;
/* 1850 */       if ((ch < 0) || (escCodes[ch] == 0)) {
/* 1851 */         outputBuffer[(outputPtr++)] = b;
/*      */       }
/*      */       else {
/* 1854 */         int escape = escCodes[ch];
/* 1855 */         if (escape > 0) {
/* 1856 */           outputBuffer[(outputPtr++)] = 92;
/* 1857 */           outputBuffer[(outputPtr++)] = ((byte)escape);
/*      */         }
/*      */         else {
/* 1860 */           outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         }
/*      */       } }
/* 1863 */     this._outputTail = outputPtr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _writeBinary(Base64Variant b64variant, byte[] input, int inputPtr, int inputEnd)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1877 */     int safeInputEnd = inputEnd - 3;
/*      */     
/* 1879 */     int safeOutputEnd = this._outputEnd - 6;
/* 1880 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */     
/*      */ 
/* 1883 */     while (inputPtr <= safeInputEnd) {
/* 1884 */       if (this._outputTail > safeOutputEnd) {
/* 1885 */         _flushBuffer();
/*      */       }
/*      */       
/* 1888 */       int b24 = input[(inputPtr++)] << 8;
/* 1889 */       b24 |= input[(inputPtr++)] & 0xFF;
/* 1890 */       b24 = b24 << 8 | input[(inputPtr++)] & 0xFF;
/* 1891 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1892 */       chunksBeforeLF--; if (chunksBeforeLF <= 0)
/*      */       {
/* 1894 */         this._outputBuffer[(this._outputTail++)] = 92;
/* 1895 */         this._outputBuffer[(this._outputTail++)] = 110;
/* 1896 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1901 */     int inputLeft = inputEnd - inputPtr;
/* 1902 */     if (inputLeft > 0) {
/* 1903 */       if (this._outputTail > safeOutputEnd) {
/* 1904 */         _flushBuffer();
/*      */       }
/* 1906 */       int b24 = input[(inputPtr++)] << 16;
/* 1907 */       if (inputLeft == 2) {
/* 1908 */         b24 |= (input[(inputPtr++)] & 0xFF) << 8;
/*      */       }
/* 1910 */       this._outputTail = b64variant.encodeBase64Partial(b24, inputLeft, this._outputBuffer, this._outputTail);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final int _writeBinary(Base64Variant b64variant, InputStream data, byte[] readBuffer, int bytesLeft)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1919 */     int inputPtr = 0;
/* 1920 */     int inputEnd = 0;
/* 1921 */     int lastFullOffset = -3;
/*      */     
/*      */ 
/* 1924 */     int safeOutputEnd = this._outputEnd - 6;
/* 1925 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */     
/* 1927 */     while (bytesLeft > 2) {
/* 1928 */       if (inputPtr > lastFullOffset) {
/* 1929 */         inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, bytesLeft);
/* 1930 */         inputPtr = 0;
/* 1931 */         if (inputEnd < 3) {
/*      */           break;
/*      */         }
/* 1934 */         lastFullOffset = inputEnd - 3;
/*      */       }
/* 1936 */       if (this._outputTail > safeOutputEnd) {
/* 1937 */         _flushBuffer();
/*      */       }
/* 1939 */       int b24 = readBuffer[(inputPtr++)] << 8;
/* 1940 */       b24 |= readBuffer[(inputPtr++)] & 0xFF;
/* 1941 */       b24 = b24 << 8 | readBuffer[(inputPtr++)] & 0xFF;
/* 1942 */       bytesLeft -= 3;
/* 1943 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1944 */       chunksBeforeLF--; if (chunksBeforeLF <= 0) {
/* 1945 */         this._outputBuffer[(this._outputTail++)] = 92;
/* 1946 */         this._outputBuffer[(this._outputTail++)] = 110;
/* 1947 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1952 */     if (bytesLeft > 0) {
/* 1953 */       inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, bytesLeft);
/* 1954 */       inputPtr = 0;
/* 1955 */       if (inputEnd > 0) {
/* 1956 */         if (this._outputTail > safeOutputEnd) {
/* 1957 */           _flushBuffer();
/*      */         }
/* 1959 */         int b24 = readBuffer[(inputPtr++)] << 16;
/*      */         int amount;
/* 1961 */         int amount; if (inputPtr < inputEnd) {
/* 1962 */           b24 |= (readBuffer[inputPtr] & 0xFF) << 8;
/* 1963 */           amount = 2;
/*      */         } else {
/* 1965 */           amount = 1;
/*      */         }
/* 1967 */         this._outputTail = b64variant.encodeBase64Partial(b24, amount, this._outputBuffer, this._outputTail);
/* 1968 */         bytesLeft -= amount;
/*      */       }
/*      */     }
/* 1971 */     return bytesLeft;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final int _writeBinary(Base64Variant b64variant, InputStream data, byte[] readBuffer)
/*      */     throws IOException, JsonGenerationException
/*      */   {
/* 1979 */     int inputPtr = 0;
/* 1980 */     int inputEnd = 0;
/* 1981 */     int lastFullOffset = -3;
/* 1982 */     int bytesDone = 0;
/*      */     
/*      */ 
/* 1985 */     int safeOutputEnd = this._outputEnd - 6;
/* 1986 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */     
/*      */     for (;;)
/*      */     {
/* 1990 */       if (inputPtr > lastFullOffset) {
/* 1991 */         inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, readBuffer.length);
/* 1992 */         inputPtr = 0;
/* 1993 */         if (inputEnd < 3) {
/*      */           break;
/*      */         }
/* 1996 */         lastFullOffset = inputEnd - 3;
/*      */       }
/* 1998 */       if (this._outputTail > safeOutputEnd) {
/* 1999 */         _flushBuffer();
/*      */       }
/*      */       
/* 2002 */       int b24 = readBuffer[(inputPtr++)] << 8;
/* 2003 */       b24 |= readBuffer[(inputPtr++)] & 0xFF;
/* 2004 */       b24 = b24 << 8 | readBuffer[(inputPtr++)] & 0xFF;
/* 2005 */       bytesDone += 3;
/* 2006 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 2007 */       chunksBeforeLF--; if (chunksBeforeLF <= 0) {
/* 2008 */         this._outputBuffer[(this._outputTail++)] = 92;
/* 2009 */         this._outputBuffer[(this._outputTail++)] = 110;
/* 2010 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2015 */     if (inputPtr < inputEnd) {
/* 2016 */       if (this._outputTail > safeOutputEnd) {
/* 2017 */         _flushBuffer();
/*      */       }
/* 2019 */       int b24 = readBuffer[(inputPtr++)] << 16;
/* 2020 */       int amount = 1;
/* 2021 */       if (inputPtr < inputEnd) {
/* 2022 */         b24 |= (readBuffer[inputPtr] & 0xFF) << 8;
/* 2023 */         amount = 2;
/*      */       }
/* 2025 */       bytesDone += amount;
/* 2026 */       this._outputTail = b64variant.encodeBase64Partial(b24, amount, this._outputBuffer, this._outputTail);
/*      */     }
/* 2028 */     return bytesDone;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private final int _readMore(InputStream in, byte[] readBuffer, int inputPtr, int inputEnd, int maxRead)
/*      */     throws IOException
/*      */   {
/* 2036 */     int i = 0;
/* 2037 */     while (inputPtr < inputEnd) {
/* 2038 */       readBuffer[(i++)] = readBuffer[(inputPtr++)];
/*      */     }
/* 2040 */     inputPtr = 0;
/* 2041 */     inputEnd = i;
/* 2042 */     maxRead = Math.min(maxRead, readBuffer.length);
/*      */     do
/*      */     {
/* 2045 */       int length = maxRead - inputEnd;
/* 2046 */       if (length == 0) {
/*      */         break;
/*      */       }
/* 2049 */       int count = in.read(readBuffer, inputEnd, length);
/* 2050 */       if (count < 0) {
/* 2051 */         return inputEnd;
/*      */       }
/* 2053 */       inputEnd += count;
/* 2054 */     } while (inputEnd < 3);
/* 2055 */     return inputEnd;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int _outputRawMultiByteChar(int ch, char[] cbuf, int inputOffset, int inputEnd)
/*      */     throws IOException
/*      */   {
/* 2073 */     if ((ch >= 55296) && 
/* 2074 */       (ch <= 57343))
/*      */     {
/* 2076 */       if ((inputOffset >= inputEnd) || (cbuf == null)) {
/* 2077 */         _reportError(String.format("Split surrogate on writeRaw() input (last character): first character 0x%4x", new Object[] {
/* 2078 */           Integer.valueOf(ch) }));
/*      */       } else {
/* 2080 */         _outputSurrogates(ch, cbuf[inputOffset]);
/*      */       }
/* 2082 */       return inputOffset + 1;
/*      */     }
/*      */     
/* 2085 */     byte[] bbuf = this._outputBuffer;
/* 2086 */     bbuf[(this._outputTail++)] = ((byte)(0xE0 | ch >> 12));
/* 2087 */     bbuf[(this._outputTail++)] = ((byte)(0x80 | ch >> 6 & 0x3F));
/* 2088 */     bbuf[(this._outputTail++)] = ((byte)(0x80 | ch & 0x3F));
/* 2089 */     return inputOffset;
/*      */   }
/*      */   
/*      */   protected final void _outputSurrogates(int surr1, int surr2) throws IOException
/*      */   {
/* 2094 */     int c = _decodeSurrogate(surr1, surr2);
/* 2095 */     if (this._outputTail + 4 > this._outputEnd) {
/* 2096 */       _flushBuffer();
/*      */     }
/* 2098 */     byte[] bbuf = this._outputBuffer;
/* 2099 */     bbuf[(this._outputTail++)] = ((byte)(0xF0 | c >> 18));
/* 2100 */     bbuf[(this._outputTail++)] = ((byte)(0x80 | c >> 12 & 0x3F));
/* 2101 */     bbuf[(this._outputTail++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/* 2102 */     bbuf[(this._outputTail++)] = ((byte)(0x80 | c & 0x3F));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int _outputMultiByteChar(int ch, int outputPtr)
/*      */     throws IOException
/*      */   {
/* 2116 */     byte[] bbuf = this._outputBuffer;
/* 2117 */     if ((ch >= 55296) && (ch <= 57343))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2122 */       bbuf[(outputPtr++)] = 92;
/* 2123 */       bbuf[(outputPtr++)] = 117;
/*      */       
/* 2125 */       bbuf[(outputPtr++)] = HEX_CHARS[(ch >> 12 & 0xF)];
/* 2126 */       bbuf[(outputPtr++)] = HEX_CHARS[(ch >> 8 & 0xF)];
/* 2127 */       bbuf[(outputPtr++)] = HEX_CHARS[(ch >> 4 & 0xF)];
/* 2128 */       bbuf[(outputPtr++)] = HEX_CHARS[(ch & 0xF)];
/*      */     }
/*      */     else {
/* 2131 */       bbuf[(outputPtr++)] = ((byte)(0xE0 | ch >> 12));
/* 2132 */       bbuf[(outputPtr++)] = ((byte)(0x80 | ch >> 6 & 0x3F));
/* 2133 */       bbuf[(outputPtr++)] = ((byte)(0x80 | ch & 0x3F));
/*      */     }
/* 2135 */     return outputPtr;
/*      */   }
/*      */   
/*      */   private final void _writeNull() throws IOException
/*      */   {
/* 2140 */     if (this._outputTail + 4 >= this._outputEnd) {
/* 2141 */       _flushBuffer();
/*      */     }
/* 2143 */     System.arraycopy(NULL_BYTES, 0, this._outputBuffer, this._outputTail, 4);
/* 2144 */     this._outputTail += 4;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int _writeGenericEscape(int charToEscape, int outputPtr)
/*      */     throws IOException
/*      */   {
/* 2154 */     byte[] bbuf = this._outputBuffer;
/* 2155 */     bbuf[(outputPtr++)] = 92;
/* 2156 */     bbuf[(outputPtr++)] = 117;
/* 2157 */     if (charToEscape > 255) {
/* 2158 */       int hi = charToEscape >> 8 & 0xFF;
/* 2159 */       bbuf[(outputPtr++)] = HEX_CHARS[(hi >> 4)];
/* 2160 */       bbuf[(outputPtr++)] = HEX_CHARS[(hi & 0xF)];
/* 2161 */       charToEscape &= 0xFF;
/*      */     } else {
/* 2163 */       bbuf[(outputPtr++)] = 48;
/* 2164 */       bbuf[(outputPtr++)] = 48;
/*      */     }
/*      */     
/* 2167 */     bbuf[(outputPtr++)] = HEX_CHARS[(charToEscape >> 4)];
/* 2168 */     bbuf[(outputPtr++)] = HEX_CHARS[(charToEscape & 0xF)];
/* 2169 */     return outputPtr;
/*      */   }
/*      */   
/*      */   protected final void _flushBuffer() throws IOException
/*      */   {
/* 2174 */     int len = this._outputTail;
/* 2175 */     if (len > 0) {
/* 2176 */       this._outputTail = 0;
/* 2177 */       this._outputStream.write(this._outputBuffer, 0, len);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\json\UTF8JsonGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */