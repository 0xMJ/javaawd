/*    */ package com.fasterxml.jackson.core;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TreeCodec
/*    */ {
/*    */   public abstract <T extends TreeNode> T readTree(JsonParser paramJsonParser)
/*    */     throws IOException, JsonProcessingException;
/*    */   
/*    */   public abstract void writeTree(JsonGenerator paramJsonGenerator, TreeNode paramTreeNode)
/*    */     throws IOException, JsonProcessingException;
/*    */   
/*    */   public TreeNode missingNode()
/*    */   {
/* 23 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TreeNode nullNode()
/*    */   {
/* 32 */     return null;
/*    */   }
/*    */   
/*    */   public abstract TreeNode createArrayNode();
/*    */   
/*    */   public abstract TreeNode createObjectNode();
/*    */   
/*    */   public abstract JsonParser treeAsTokens(TreeNode paramTreeNode);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\TreeCodec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */