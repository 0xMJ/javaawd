/*     */ package com.fasterxml.jackson.core.filter;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonParser.NumberType;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.util.JsonParserDelegate;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilteringParserDelegate
/*     */   extends JsonParserDelegate
/*     */ {
/*     */   protected TokenFilter rootFilter;
/*     */   protected boolean _allowMultipleMatches;
/*     */   protected TokenFilter.Inclusion _inclusion;
/*     */   protected JsonToken _currToken;
/*     */   protected JsonToken _lastClearedToken;
/*     */   protected TokenFilterContext _headContext;
/*     */   protected TokenFilterContext _exposedContext;
/*     */   protected TokenFilter _itemFilter;
/*     */   protected int _matchCount;
/*     */   
/*     */   @Deprecated
/*     */   public FilteringParserDelegate(JsonParser p, TokenFilter f, boolean includePath, boolean allowMultipleMatches)
/*     */   {
/* 108 */     this(p, f, includePath ? TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH : TokenFilter.Inclusion.ONLY_INCLUDE_ALL, allowMultipleMatches);
/*     */   }
/*     */   
/*     */ 
/*     */   public FilteringParserDelegate(JsonParser p, TokenFilter f, TokenFilter.Inclusion inclusion, boolean allowMultipleMatches)
/*     */   {
/* 114 */     super(p);
/* 115 */     this.rootFilter = f;
/*     */     
/* 117 */     this._itemFilter = f;
/* 118 */     this._headContext = TokenFilterContext.createRootContext(f);
/* 119 */     this._inclusion = inclusion;
/* 120 */     this._allowMultipleMatches = allowMultipleMatches;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TokenFilter getFilter()
/*     */   {
/* 129 */     return this.rootFilter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMatchCount()
/*     */   {
/* 136 */     return this._matchCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 145 */   public JsonToken getCurrentToken() { return this._currToken; }
/* 146 */   public JsonToken currentToken() { return this._currToken; }
/*     */   
/*     */ 
/*     */   @Deprecated
/* 150 */   public final int getCurrentTokenId() { return currentTokenId(); }
/*     */   
/*     */   public final int currentTokenId() {
/* 153 */     JsonToken t = this._currToken;
/* 154 */     return t == null ? 0 : t.id();
/*     */   }
/*     */   
/* 157 */   public boolean hasCurrentToken() { return this._currToken != null; }
/*     */   
/* 159 */   public boolean hasTokenId(int id) { JsonToken t = this._currToken;
/* 160 */     if (t == null) {
/* 161 */       return 0 == id;
/*     */     }
/* 163 */     return t.id() == id;
/*     */   }
/*     */   
/*     */   public final boolean hasToken(JsonToken t) {
/* 167 */     return this._currToken == t;
/*     */   }
/*     */   
/* 170 */   public boolean isExpectedStartArrayToken() { return this._currToken == JsonToken.START_ARRAY; }
/* 171 */   public boolean isExpectedStartObjectToken() { return this._currToken == JsonToken.START_OBJECT; }
/*     */   
/* 173 */   public JsonLocation getCurrentLocation() { return this.delegate.getCurrentLocation(); }
/*     */   
/*     */   public JsonStreamContext getParsingContext()
/*     */   {
/* 177 */     return _filterContext();
/*     */   }
/*     */   
/*     */   public String getCurrentName()
/*     */     throws IOException
/*     */   {
/* 183 */     JsonStreamContext ctxt = _filterContext();
/* 184 */     if ((this._currToken == JsonToken.START_OBJECT) || (this._currToken == JsonToken.START_ARRAY)) {
/* 185 */       JsonStreamContext parent = ctxt.getParent();
/* 186 */       return parent == null ? null : parent.getCurrentName();
/*     */     }
/* 188 */     return ctxt.getCurrentName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearCurrentToken()
/*     */   {
/* 199 */     if (this._currToken != null) {
/* 200 */       this._lastClearedToken = this._currToken;
/* 201 */       this._currToken = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public JsonToken getLastClearedToken() {
/* 206 */     return this._lastClearedToken;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void overrideCurrentName(String name)
/*     */   {
/* 214 */     throw new UnsupportedOperationException("Can not currently override name during filtering read");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonToken nextToken()
/*     */     throws IOException
/*     */   {
/* 234 */     if ((!this._allowMultipleMatches) && (this._currToken != null) && (this._exposedContext == null))
/*     */     {
/*     */ 
/* 237 */       if ((this._currToken.isScalarValue()) && (!this._headContext.isStartHandled()) && (this._inclusion == TokenFilter.Inclusion.ONLY_INCLUDE_ALL) && (this._itemFilter == TokenFilter.INCLUDE_ALL))
/*     */       {
/*     */ 
/* 240 */         return this._currToken = null;
/*     */       }
/*     */     }
/*     */     
/* 244 */     TokenFilterContext ctxt = this._exposedContext;
/*     */     
/* 246 */     if (ctxt != null) {
/*     */       for (;;) {
/* 248 */         JsonToken t = ctxt.nextTokenToRead();
/* 249 */         if (t != null) {
/* 250 */           this._currToken = t;
/* 251 */           return t;
/*     */         }
/*     */         
/* 254 */         if (ctxt == this._headContext) {
/* 255 */           this._exposedContext = null;
/* 256 */           if (!ctxt.inArray()) break;
/* 257 */           t = this.delegate.getCurrentToken();
/*     */           
/*     */ 
/* 260 */           this._currToken = t;
/* 261 */           return t;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 276 */         ctxt = this._headContext.findChildOf(ctxt);
/* 277 */         this._exposedContext = ctxt;
/* 278 */         if (ctxt == null) {
/* 279 */           throw _constructError("Unexpected problem: chain of filtered context broken");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 285 */     JsonToken t = this.delegate.nextToken();
/* 286 */     if (t == null)
/*     */     {
/* 288 */       this._currToken = t;
/* 289 */       return t;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 295 */     switch (t.id()) {
/*     */     case 3: 
/* 297 */       TokenFilter f = this._itemFilter;
/* 298 */       if (f == TokenFilter.INCLUDE_ALL) {
/* 299 */         this._headContext = this._headContext.createChildArrayContext(f, true);
/* 300 */         return this._currToken = t;
/*     */       }
/* 302 */       if (f == null) {
/* 303 */         this.delegate.skipChildren();
/*     */       }
/*     */       else
/*     */       {
/* 307 */         f = this._headContext.checkValue(f);
/* 308 */         if (f == null) {
/* 309 */           this.delegate.skipChildren();
/*     */         }
/*     */         else {
/* 312 */           if (f != TokenFilter.INCLUDE_ALL) {
/* 313 */             f = f.filterStartArray();
/*     */           }
/* 315 */           this._itemFilter = f;
/* 316 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 317 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/* 318 */             return this._currToken = t; }
/* 319 */           if ((f != null) && (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL))
/*     */           {
/* 321 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/* 322 */             return this._currToken = t;
/*     */           }
/* 324 */           this._headContext = this._headContext.createChildArrayContext(f, false);
/*     */           
/*     */ 
/* 327 */           if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 328 */             t = _nextTokenWithBuffering(this._headContext);
/* 329 */             if (t != null) {
/* 330 */               this._currToken = t;
/* 331 */               return t;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       break;
/* 337 */     case 1:  TokenFilter f = this._itemFilter;
/* 338 */       if (f == TokenFilter.INCLUDE_ALL) {
/* 339 */         this._headContext = this._headContext.createChildObjectContext(f, true);
/* 340 */         return this._currToken = t;
/*     */       }
/* 342 */       if (f == null) {
/* 343 */         this.delegate.skipChildren();
/*     */       }
/*     */       else
/*     */       {
/* 347 */         f = this._headContext.checkValue(f);
/* 348 */         if (f == null) {
/* 349 */           this.delegate.skipChildren();
/*     */         }
/*     */         else {
/* 352 */           if (f != TokenFilter.INCLUDE_ALL) {
/* 353 */             f = f.filterStartObject();
/*     */           }
/* 355 */           this._itemFilter = f;
/* 356 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 357 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/* 358 */             return this._currToken = t; }
/* 359 */           if ((f != null) && (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL))
/*     */           {
/* 361 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/* 362 */             return this._currToken = t;
/*     */           }
/* 364 */           this._headContext = this._headContext.createChildObjectContext(f, false);
/*     */           
/* 366 */           if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 367 */             t = _nextTokenWithBuffering(this._headContext);
/* 368 */             if (t != null) {
/* 369 */               this._currToken = t;
/* 370 */               return t;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */       break;
/*     */     case 2: 
/*     */     case 4: 
/* 380 */       boolean returnEnd = this._headContext.isStartHandled();
/* 381 */       TokenFilter f = this._headContext.getFilter();
/* 382 */       if ((f != null) && (f != TokenFilter.INCLUDE_ALL)) {
/* 383 */         f.filterFinishArray();
/*     */       }
/* 385 */       this._headContext = this._headContext.getParent();
/* 386 */       this._itemFilter = this._headContext.getFilter();
/* 387 */       if (returnEnd) {
/* 388 */         return this._currToken = t;
/*     */       }
/*     */       
/* 391 */       break;
/*     */     
/*     */ 
/*     */     case 5: 
/* 395 */       String name = this.delegate.getCurrentName();
/*     */       
/* 397 */       TokenFilter f = this._headContext.setFieldName(name);
/* 398 */       if (f == TokenFilter.INCLUDE_ALL) {
/* 399 */         this._itemFilter = f;
/* 400 */         return this._currToken = t;
/*     */       }
/* 402 */       if (f == null) {
/* 403 */         this.delegate.nextToken();
/* 404 */         this.delegate.skipChildren();
/*     */       }
/*     */       else {
/* 407 */         f = f.includeProperty(name);
/* 408 */         if (f == null) {
/* 409 */           this.delegate.nextToken();
/* 410 */           this.delegate.skipChildren();
/*     */         }
/*     */         else {
/* 413 */           this._itemFilter = f;
/* 414 */           if (f == TokenFilter.INCLUDE_ALL) {
/* 415 */             if (_verifyAllowedMatches()) {
/* 416 */               if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 417 */                 return this._currToken = t;
/*     */               }
/*     */             } else {
/* 420 */               this.delegate.nextToken();
/* 421 */               this.delegate.skipChildren();
/*     */             }
/*     */           }
/* 424 */           if (this._inclusion != TokenFilter.Inclusion.ONLY_INCLUDE_ALL) {
/* 425 */             t = _nextTokenWithBuffering(this._headContext);
/* 426 */             if (t != null) {
/* 427 */               this._currToken = t;
/* 428 */               return t;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       break;
/*     */     default: 
/* 435 */       TokenFilter f = this._itemFilter;
/* 436 */       if (f == TokenFilter.INCLUDE_ALL) {
/* 437 */         return this._currToken = t;
/*     */       }
/* 439 */       if (f != null) {
/* 440 */         f = this._headContext.checkValue(f);
/* 441 */         if (((f == TokenFilter.INCLUDE_ALL) || ((f != null) && 
/* 442 */           (f.includeValue(this.delegate)))) && 
/* 443 */           (_verifyAllowedMatches())) {
/* 444 */           return this._currToken = t;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */       break;
/*     */     }
/*     */     
/*     */     
/* 453 */     return _nextToken2();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final JsonToken _nextToken2()
/*     */     throws IOException
/*     */   {
/*     */     for (;;)
/*     */     {
/* 466 */       JsonToken t = this.delegate.nextToken();
/* 467 */       if (t == null) {
/* 468 */         this._currToken = t;
/* 469 */         return t;
/*     */       }
/*     */       
/*     */ 
/* 473 */       switch (t.id()) {
/*     */       case 3: 
/* 475 */         TokenFilter f = this._itemFilter;
/* 476 */         if (f == TokenFilter.INCLUDE_ALL) {
/* 477 */           this._headContext = this._headContext.createChildArrayContext(f, true);
/* 478 */           return this._currToken = t;
/*     */         }
/* 480 */         if (f == null) {
/* 481 */           this.delegate.skipChildren();
/*     */         }
/*     */         else
/*     */         {
/* 485 */           f = this._headContext.checkValue(f);
/* 486 */           if (f == null) {
/* 487 */             this.delegate.skipChildren();
/*     */           }
/*     */           else {
/* 490 */             if (f != TokenFilter.INCLUDE_ALL) {
/* 491 */               f = f.filterStartArray();
/*     */             }
/* 493 */             this._itemFilter = f;
/* 494 */             if (f == TokenFilter.INCLUDE_ALL) {
/* 495 */               this._headContext = this._headContext.createChildArrayContext(f, true);
/* 496 */               return this._currToken = t; }
/* 497 */             if ((f != null) && (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL)) {
/* 498 */               this._headContext = this._headContext.createChildArrayContext(f, true);
/* 499 */               return this._currToken = t;
/*     */             }
/* 501 */             this._headContext = this._headContext.createChildArrayContext(f, false);
/*     */             
/* 503 */             if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 504 */               t = _nextTokenWithBuffering(this._headContext);
/* 505 */               if (t != null) {
/* 506 */                 this._currToken = t;
/* 507 */                 return t;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         break;
/* 513 */       case 1:  TokenFilter f = this._itemFilter;
/* 514 */         if (f == TokenFilter.INCLUDE_ALL) {
/* 515 */           this._headContext = this._headContext.createChildObjectContext(f, true);
/* 516 */           return this._currToken = t;
/*     */         }
/* 518 */         if (f == null) {
/* 519 */           this.delegate.skipChildren();
/*     */         }
/*     */         else
/*     */         {
/* 523 */           f = this._headContext.checkValue(f);
/* 524 */           if (f == null) {
/* 525 */             this.delegate.skipChildren();
/*     */           }
/*     */           else {
/* 528 */             if (f != TokenFilter.INCLUDE_ALL) {
/* 529 */               f = f.filterStartObject();
/*     */             }
/* 531 */             this._itemFilter = f;
/* 532 */             if (f == TokenFilter.INCLUDE_ALL) {
/* 533 */               this._headContext = this._headContext.createChildObjectContext(f, true);
/* 534 */               return this._currToken = t; }
/* 535 */             if ((f != null) && (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL)) {
/* 536 */               this._headContext = this._headContext.createChildObjectContext(f, true);
/* 537 */               return this._currToken = t;
/*     */             }
/* 539 */             this._headContext = this._headContext.createChildObjectContext(f, false);
/* 540 */             if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 541 */               t = _nextTokenWithBuffering(this._headContext);
/* 542 */               if (t != null) {
/* 543 */                 this._currToken = t;
/* 544 */                 return t;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         break;
/*     */       case 2: 
/*     */       case 4: 
/* 552 */         boolean returnEnd = this._headContext.isStartHandled();
/* 553 */         TokenFilter f = this._headContext.getFilter();
/* 554 */         if ((f != null) && (f != TokenFilter.INCLUDE_ALL)) {
/* 555 */           f.filterFinishArray();
/*     */         }
/* 557 */         this._headContext = this._headContext.getParent();
/* 558 */         this._itemFilter = this._headContext.getFilter();
/* 559 */         if (returnEnd) {
/* 560 */           return this._currToken = t;
/*     */         }
/*     */         
/* 563 */         break;
/*     */       
/*     */ 
/*     */       case 5: 
/* 567 */         String name = this.delegate.getCurrentName();
/* 568 */         TokenFilter f = this._headContext.setFieldName(name);
/* 569 */         if (f == TokenFilter.INCLUDE_ALL) {
/* 570 */           this._itemFilter = f;
/* 571 */           return this._currToken = t;
/*     */         }
/* 573 */         if (f == null) {
/* 574 */           this.delegate.nextToken();
/* 575 */           this.delegate.skipChildren();
/*     */         }
/*     */         else {
/* 578 */           f = f.includeProperty(name);
/* 579 */           if (f == null) {
/* 580 */             this.delegate.nextToken();
/* 581 */             this.delegate.skipChildren();
/*     */           }
/*     */           else {
/* 584 */             this._itemFilter = f;
/* 585 */             if (f == TokenFilter.INCLUDE_ALL) {
/* 586 */               if ((_verifyAllowedMatches()) && (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH)) {
/* 587 */                 return this._currToken = t;
/*     */               }
/*     */               
/*     */             }
/* 591 */             else if (this._inclusion != TokenFilter.Inclusion.ONLY_INCLUDE_ALL) {
/* 592 */               t = _nextTokenWithBuffering(this._headContext);
/* 593 */               if (t != null) {
/* 594 */                 this._currToken = t;
/* 595 */                 return t;
/*     */               }
/*     */             }
/*     */           } }
/* 599 */         break;
/*     */       
/*     */       default: 
/* 602 */         TokenFilter f = this._itemFilter;
/* 603 */         if (f == TokenFilter.INCLUDE_ALL) {
/* 604 */           return this._currToken = t;
/*     */         }
/* 606 */         if (f != null) {
/* 607 */           f = this._headContext.checkValue(f);
/* 608 */           if (((f == TokenFilter.INCLUDE_ALL) || ((f != null) && 
/* 609 */             (f.includeValue(this.delegate)))) && 
/* 610 */             (_verifyAllowedMatches())) {
/* 611 */             return this._currToken = t;
/*     */           }
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected final JsonToken _nextTokenWithBuffering(TokenFilterContext buffRoot)
/*     */     throws IOException
/*     */   {
/*     */     TokenFilter f;
/*     */     do
/*     */     {
/*     */       do
/*     */       {
/*     */         for (;;)
/*     */         {
/* 629 */           JsonToken t = this.delegate.nextToken();
/* 630 */           if (t == null) {
/* 631 */             return t;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 639 */           switch (t.id()) {
/*     */           case 3: 
/* 641 */             TokenFilter f = this._headContext.checkValue(this._itemFilter);
/* 642 */             if (f == null) {
/* 643 */               this.delegate.skipChildren();
/*     */             }
/*     */             else {
/* 646 */               if (f != TokenFilter.INCLUDE_ALL) {
/* 647 */                 f = f.filterStartArray();
/*     */               }
/* 649 */               this._itemFilter = f;
/* 650 */               if (f == TokenFilter.INCLUDE_ALL) {
/* 651 */                 this._headContext = this._headContext.createChildArrayContext(f, true);
/* 652 */                 return _nextBuffered(buffRoot); }
/* 653 */               if ((f != null) && (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL))
/*     */               {
/* 655 */                 this._headContext = this._headContext.createChildArrayContext(f, true);
/* 656 */                 return _nextBuffered(buffRoot);
/*     */               }
/* 658 */               this._headContext = this._headContext.createChildArrayContext(f, false); }
/* 659 */             break;
/*     */           
/*     */           case 1: 
/* 662 */             TokenFilter f = this._itemFilter;
/* 663 */             if (f == TokenFilter.INCLUDE_ALL) {
/* 664 */               this._headContext = this._headContext.createChildObjectContext(f, true);
/* 665 */               return t;
/*     */             }
/* 667 */             if (f == null) {
/* 668 */               this.delegate.skipChildren();
/*     */             }
/*     */             else
/*     */             {
/* 672 */               f = this._headContext.checkValue(f);
/* 673 */               if (f == null) {
/* 674 */                 this.delegate.skipChildren();
/*     */               }
/*     */               else {
/* 677 */                 if (f != TokenFilter.INCLUDE_ALL) {
/* 678 */                   f = f.filterStartObject();
/*     */                 }
/* 680 */                 this._itemFilter = f;
/* 681 */                 if (f == TokenFilter.INCLUDE_ALL) {
/* 682 */                   this._headContext = this._headContext.createChildObjectContext(f, true);
/* 683 */                   return _nextBuffered(buffRoot); }
/* 684 */                 if ((f != null) && (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL))
/*     */                 {
/* 686 */                   this._headContext = this._headContext.createChildArrayContext(f, true);
/* 687 */                   return _nextBuffered(buffRoot);
/*     */                 }
/* 689 */                 this._headContext = this._headContext.createChildObjectContext(f, false); } }
/* 690 */             break;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */           case 2: 
/*     */           case 4: 
/* 697 */             TokenFilter f = this._headContext.getFilter();
/* 698 */             if ((f != null) && (f != TokenFilter.INCLUDE_ALL)) {
/* 699 */               f.filterFinishArray();
/*     */             }
/* 701 */             boolean gotEnd = this._headContext == buffRoot;
/* 702 */             boolean returnEnd = (gotEnd) && (this._headContext.isStartHandled());
/*     */             
/* 704 */             this._headContext = this._headContext.getParent();
/* 705 */             this._itemFilter = this._headContext.getFilter();
/*     */             
/* 707 */             if (returnEnd) {
/* 708 */               return t;
/*     */             }
/*     */             
/* 711 */             break;
/*     */           
/*     */ 
/*     */           case 5: 
/* 715 */             String name = this.delegate.getCurrentName();
/* 716 */             TokenFilter f = this._headContext.setFieldName(name);
/* 717 */             if (f == TokenFilter.INCLUDE_ALL) {
/* 718 */               this._itemFilter = f;
/* 719 */               return _nextBuffered(buffRoot);
/*     */             }
/* 721 */             if (f == null) {
/* 722 */               this.delegate.nextToken();
/* 723 */               this.delegate.skipChildren();
/*     */             }
/*     */             else {
/* 726 */               f = f.includeProperty(name);
/* 727 */               if (f == null) {
/* 728 */                 this.delegate.nextToken();
/* 729 */                 this.delegate.skipChildren();
/*     */               }
/*     */               else {
/* 732 */                 this._itemFilter = f;
/* 733 */                 if (f == TokenFilter.INCLUDE_ALL) {
/* 734 */                   if (_verifyAllowedMatches()) {
/* 735 */                     return _nextBuffered(buffRoot);
/*     */                   }
/*     */                   
/*     */ 
/* 739 */                   this._itemFilter = this._headContext.setFieldName(name);
/*     */                 }
/*     */               }
/*     */             }
/*     */             break;
/*     */           }
/*     */         }
/* 746 */         f = this._itemFilter;
/* 747 */         if (f == TokenFilter.INCLUDE_ALL) {
/* 748 */           return _nextBuffered(buffRoot);
/*     */         }
/* 750 */       } while (f == null);
/* 751 */       f = this._headContext.checkValue(f);
/* 752 */     } while (((f != TokenFilter.INCLUDE_ALL) && ((f == null) || 
/* 753 */       (!f.includeValue(this.delegate)))) || 
/* 754 */       (!_verifyAllowedMatches()));
/* 755 */     return _nextBuffered(buffRoot);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JsonToken _nextBuffered(TokenFilterContext buffRoot)
/*     */     throws IOException
/*     */   {
/* 767 */     this._exposedContext = buffRoot;
/* 768 */     TokenFilterContext ctxt = buffRoot;
/* 769 */     JsonToken t = ctxt.nextTokenToRead();
/* 770 */     if (t != null) {
/* 771 */       return t;
/*     */     }
/*     */     do
/*     */     {
/* 775 */       if (ctxt == this._headContext) {
/* 776 */         throw _constructError("Internal error: failed to locate expected buffered tokens");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 783 */       ctxt = this._exposedContext.findChildOf(ctxt);
/* 784 */       this._exposedContext = ctxt;
/* 785 */       if (ctxt == null) {
/* 786 */         throw _constructError("Unexpected problem: chain of filtered context broken");
/*     */       }
/* 788 */       t = this._exposedContext.nextTokenToRead();
/* 789 */     } while (t == null);
/* 790 */     return t;
/*     */   }
/*     */   
/*     */   private final boolean _verifyAllowedMatches()
/*     */     throws IOException
/*     */   {
/* 796 */     if ((this._matchCount == 0) || (this._allowMultipleMatches)) {
/* 797 */       this._matchCount += 1;
/* 798 */       return true;
/*     */     }
/* 800 */     return false;
/*     */   }
/*     */   
/*     */   public JsonToken nextValue()
/*     */     throws IOException
/*     */   {
/* 806 */     JsonToken t = nextToken();
/* 807 */     if (t == JsonToken.FIELD_NAME) {
/* 808 */       t = nextToken();
/*     */     }
/* 810 */     return t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonParser skipChildren()
/*     */     throws IOException
/*     */   {
/* 821 */     if ((this._currToken != JsonToken.START_OBJECT) && (this._currToken != JsonToken.START_ARRAY))
/*     */     {
/* 823 */       return this;
/*     */     }
/* 825 */     int open = 1;
/*     */     
/*     */ 
/*     */     for (;;)
/*     */     {
/* 830 */       JsonToken t = nextToken();
/* 831 */       if (t == null) {
/* 832 */         return this;
/*     */       }
/* 834 */       if (t.isStructStart()) {
/* 835 */         open++;
/* 836 */       } else if (t.isStructEnd()) {
/* 837 */         open--; if (open == 0) {
/* 838 */           return this;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 850 */   public String getText()
/* 850 */     throws IOException { return this.delegate.getText(); }
/* 851 */   public boolean hasTextCharacters() { return this.delegate.hasTextCharacters(); }
/* 852 */   public char[] getTextCharacters() throws IOException { return this.delegate.getTextCharacters(); }
/* 853 */   public int getTextLength() throws IOException { return this.delegate.getTextLength(); }
/* 854 */   public int getTextOffset() throws IOException { return this.delegate.getTextOffset(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BigInteger getBigIntegerValue()
/*     */     throws IOException
/*     */   {
/* 863 */     return this.delegate.getBigIntegerValue();
/*     */   }
/*     */   
/* 866 */   public boolean getBooleanValue() throws IOException { return this.delegate.getBooleanValue(); }
/*     */   
/*     */   public byte getByteValue() throws IOException {
/* 869 */     return this.delegate.getByteValue();
/*     */   }
/*     */   
/* 872 */   public short getShortValue() throws IOException { return this.delegate.getShortValue(); }
/*     */   
/*     */   public BigDecimal getDecimalValue() throws IOException {
/* 875 */     return this.delegate.getDecimalValue();
/*     */   }
/*     */   
/* 878 */   public double getDoubleValue() throws IOException { return this.delegate.getDoubleValue(); }
/*     */   
/*     */   public float getFloatValue() throws IOException {
/* 881 */     return this.delegate.getFloatValue();
/*     */   }
/*     */   
/* 884 */   public int getIntValue() throws IOException { return this.delegate.getIntValue(); }
/*     */   
/*     */   public long getLongValue() throws IOException {
/* 887 */     return this.delegate.getLongValue();
/*     */   }
/*     */   
/* 890 */   public JsonParser.NumberType getNumberType() throws IOException { return this.delegate.getNumberType(); }
/*     */   
/*     */   public Number getNumberValue() throws IOException {
/* 893 */     return this.delegate.getNumberValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 901 */   public int getValueAsInt()
/* 901 */     throws IOException { return this.delegate.getValueAsInt(); }
/* 902 */   public int getValueAsInt(int defaultValue) throws IOException { return this.delegate.getValueAsInt(defaultValue); }
/* 903 */   public long getValueAsLong() throws IOException { return this.delegate.getValueAsLong(); }
/* 904 */   public long getValueAsLong(long defaultValue) throws IOException { return this.delegate.getValueAsLong(defaultValue); }
/* 905 */   public double getValueAsDouble() throws IOException { return this.delegate.getValueAsDouble(); }
/* 906 */   public double getValueAsDouble(double defaultValue) throws IOException { return this.delegate.getValueAsDouble(defaultValue); }
/* 907 */   public boolean getValueAsBoolean() throws IOException { return this.delegate.getValueAsBoolean(); }
/* 908 */   public boolean getValueAsBoolean(boolean defaultValue) throws IOException { return this.delegate.getValueAsBoolean(defaultValue); }
/* 909 */   public String getValueAsString() throws IOException { return this.delegate.getValueAsString(); }
/* 910 */   public String getValueAsString(String defaultValue) throws IOException { return this.delegate.getValueAsString(defaultValue); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 918 */   public Object getEmbeddedObject()
/* 918 */     throws IOException { return this.delegate.getEmbeddedObject(); }
/* 919 */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException { return this.delegate.getBinaryValue(b64variant); }
/* 920 */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException { return this.delegate.readBinaryValue(b64variant, out); }
/* 921 */   public JsonLocation getTokenLocation() { return this.delegate.getTokenLocation(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonStreamContext _filterContext()
/*     */   {
/* 930 */     if (this._exposedContext != null) {
/* 931 */       return this._exposedContext;
/*     */     }
/* 933 */     return this._headContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\filter\FilteringParserDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */