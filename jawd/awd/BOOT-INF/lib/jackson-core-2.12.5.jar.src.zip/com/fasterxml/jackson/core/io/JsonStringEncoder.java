/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*     */ import com.fasterxml.jackson.core.util.TextBuffer;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JsonStringEncoder
/*     */ {
/*  24 */   private static final char[] HC = ;
/*     */   
/*  26 */   private static final byte[] HB = CharTypes.copyHexBytes();
/*     */   
/*     */ 
/*     */   private static final int SURR1_FIRST = 55296;
/*     */   
/*     */ 
/*     */   private static final int SURR1_LAST = 56319;
/*     */   
/*     */ 
/*     */   private static final int SURR2_FIRST = 56320;
/*     */   
/*     */ 
/*     */   private static final int SURR2_LAST = 57343;
/*     */   
/*     */   private static final int INITIAL_CHAR_BUFFER_SIZE = 30;
/*     */   
/*     */   private static final int INITIAL_BYTE_BUFFER_SIZE = 60;
/*     */   
/*  44 */   private static final JsonStringEncoder instance = new JsonStringEncoder();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonStringEncoder getInstance()
/*     */   {
/*  55 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] quoteAsString(String input)
/*     */   {
/*  74 */     char[] outputBuffer = new char[30];
/*  75 */     int[] escCodes = CharTypes.get7BitOutputEscapes();
/*  76 */     int escCodeCount = escCodes.length;
/*  77 */     int inPtr = 0;
/*  78 */     int inputLen = input.length();
/*  79 */     TextBuffer textBuffer = null;
/*  80 */     int outPtr = 0;
/*  81 */     char[] qbuf = null;
/*     */     
/*     */ 
/*  84 */     while (inPtr < inputLen)
/*     */     {
/*     */       for (;;) {
/*  87 */         char c = input.charAt(inPtr);
/*  88 */         if ((c < escCodeCount) && (escCodes[c] != 0)) {
/*     */           break;
/*     */         }
/*  91 */         if (outPtr >= outputBuffer.length) {
/*  92 */           if (textBuffer == null) {
/*  93 */             textBuffer = TextBuffer.fromInitial(outputBuffer);
/*     */           }
/*  95 */           outputBuffer = textBuffer.finishCurrentSegment();
/*  96 */           outPtr = 0;
/*     */         }
/*  98 */         outputBuffer[(outPtr++)] = c;
/*  99 */         inPtr++; if (inPtr >= inputLen) {
/*     */           break label265;
/*     */         }
/*     */       }
/*     */       
/* 104 */       if (qbuf == null) {
/* 105 */         qbuf = _qbuf();
/*     */       }
/* 107 */       char d = input.charAt(inPtr++);
/* 108 */       int escCode = escCodes[d];
/*     */       
/*     */ 
/* 111 */       int length = escCode < 0 ? _appendNumeric(d, qbuf) : _appendNamed(escCode, qbuf);
/*     */       
/* 113 */       if (outPtr + length > outputBuffer.length) {
/* 114 */         int first = outputBuffer.length - outPtr;
/* 115 */         if (first > 0) {
/* 116 */           System.arraycopy(qbuf, 0, outputBuffer, outPtr, first);
/*     */         }
/* 118 */         if (textBuffer == null) {
/* 119 */           textBuffer = TextBuffer.fromInitial(outputBuffer);
/*     */         }
/* 121 */         outputBuffer = textBuffer.finishCurrentSegment();
/* 122 */         int second = length - first;
/* 123 */         System.arraycopy(qbuf, first, outputBuffer, 0, second);
/* 124 */         outPtr = second;
/*     */       } else {
/* 126 */         System.arraycopy(qbuf, 0, outputBuffer, outPtr, length);
/* 127 */         outPtr += length;
/*     */       }
/*     */     }
/*     */     label265:
/* 131 */     if (textBuffer == null) {
/* 132 */       return Arrays.copyOfRange(outputBuffer, 0, outPtr);
/*     */     }
/* 134 */     textBuffer.setCurrentLength(outPtr);
/* 135 */     return textBuffer.contentsAsArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char[] quoteAsString(CharSequence input)
/*     */   {
/* 150 */     if ((input instanceof String)) {
/* 151 */       return quoteAsString((String)input);
/*     */     }
/*     */     
/* 154 */     TextBuffer textBuffer = null;
/*     */     
/* 156 */     char[] outputBuffer = new char[30];
/* 157 */     int[] escCodes = CharTypes.get7BitOutputEscapes();
/* 158 */     int escCodeCount = escCodes.length;
/* 159 */     int inPtr = 0;
/* 160 */     int inputLen = input.length();
/* 161 */     int outPtr = 0;
/* 162 */     char[] qbuf = null;
/*     */     
/*     */ 
/* 165 */     while (inPtr < inputLen)
/*     */     {
/*     */       for (;;) {
/* 168 */         char c = input.charAt(inPtr);
/* 169 */         if ((c < escCodeCount) && (escCodes[c] != 0)) {
/*     */           break;
/*     */         }
/* 172 */         if (outPtr >= outputBuffer.length) {
/* 173 */           if (textBuffer == null) {
/* 174 */             textBuffer = TextBuffer.fromInitial(outputBuffer);
/*     */           }
/* 176 */           outputBuffer = textBuffer.finishCurrentSegment();
/* 177 */           outPtr = 0;
/*     */         }
/* 179 */         outputBuffer[(outPtr++)] = c;
/* 180 */         inPtr++; if (inPtr >= inputLen) {
/*     */           break label284;
/*     */         }
/*     */       }
/*     */       
/* 185 */       if (qbuf == null) {
/* 186 */         qbuf = _qbuf();
/*     */       }
/* 188 */       char d = input.charAt(inPtr++);
/* 189 */       int escCode = escCodes[d];
/*     */       
/*     */ 
/* 192 */       int length = escCode < 0 ? _appendNumeric(d, qbuf) : _appendNamed(escCode, qbuf);
/*     */       
/* 194 */       if (outPtr + length > outputBuffer.length) {
/* 195 */         int first = outputBuffer.length - outPtr;
/* 196 */         if (first > 0) {
/* 197 */           System.arraycopy(qbuf, 0, outputBuffer, outPtr, first);
/*     */         }
/* 199 */         if (textBuffer == null) {
/* 200 */           textBuffer = TextBuffer.fromInitial(outputBuffer);
/*     */         }
/* 202 */         outputBuffer = textBuffer.finishCurrentSegment();
/* 203 */         int second = length - first;
/* 204 */         System.arraycopy(qbuf, first, outputBuffer, 0, second);
/* 205 */         outPtr = second;
/*     */       } else {
/* 207 */         System.arraycopy(qbuf, 0, outputBuffer, outPtr, length);
/* 208 */         outPtr += length;
/*     */       }
/*     */     }
/*     */     label284:
/* 212 */     if (textBuffer == null) {
/* 213 */       return Arrays.copyOfRange(outputBuffer, 0, outPtr);
/*     */     }
/* 215 */     textBuffer.setCurrentLength(outPtr);
/* 216 */     return textBuffer.contentsAsArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void quoteAsString(CharSequence input, StringBuilder output)
/*     */   {
/* 231 */     int[] escCodes = CharTypes.get7BitOutputEscapes();
/* 232 */     int escCodeCount = escCodes.length;
/* 233 */     int inPtr = 0;
/* 234 */     int inputLen = input.length();
/* 235 */     char[] qbuf = null;
/*     */     
/*     */ 
/* 238 */     while (inPtr < inputLen)
/*     */     {
/*     */       for (;;) {
/* 241 */         char c = input.charAt(inPtr);
/* 242 */         if ((c < escCodeCount) && (escCodes[c] != 0)) {
/*     */           break;
/*     */         }
/* 245 */         output.append(c);
/* 246 */         inPtr++; if (inPtr >= inputLen) {
/*     */           return;
/*     */         }
/*     */       }
/*     */       
/* 251 */       if (qbuf == null) {
/* 252 */         qbuf = _qbuf();
/*     */       }
/* 254 */       char d = input.charAt(inPtr++);
/* 255 */       int escCode = escCodes[d];
/*     */       
/*     */ 
/* 258 */       int length = escCode < 0 ? _appendNumeric(d, qbuf) : _appendNamed(escCode, qbuf);
/* 259 */       output.append(qbuf, 0, length);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] quoteAsUTF8(String text)
/*     */   {
/* 275 */     int inputPtr = 0;
/* 276 */     int inputEnd = text.length();
/* 277 */     int outputPtr = 0;
/* 278 */     byte[] outputBuffer = new byte[60];
/* 279 */     ByteArrayBuilder bb = null;
/*     */     
/*     */ 
/* 282 */     while (inputPtr < inputEnd) {
/* 283 */       int[] escCodes = CharTypes.get7BitOutputEscapes();
/*     */       
/*     */       for (;;)
/*     */       {
/* 287 */         int ch = text.charAt(inputPtr);
/* 288 */         if ((ch > 127) || (escCodes[ch] != 0)) {
/*     */           break;
/*     */         }
/* 291 */         if (outputPtr >= outputBuffer.length) {
/* 292 */           if (bb == null) {
/* 293 */             bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */           }
/* 295 */           outputBuffer = bb.finishCurrentSegment();
/* 296 */           outputPtr = 0;
/*     */         }
/* 298 */         outputBuffer[(outputPtr++)] = ((byte)ch);
/* 299 */         inputPtr++; if (inputPtr >= inputEnd) {
/*     */           break label504;
/*     */         }
/*     */       }
/* 303 */       if (bb == null) {
/* 304 */         bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */       }
/* 306 */       if (outputPtr >= outputBuffer.length) {
/* 307 */         outputBuffer = bb.finishCurrentSegment();
/* 308 */         outputPtr = 0;
/*     */       }
/*     */       
/* 311 */       int ch = text.charAt(inputPtr++);
/* 312 */       if (ch <= 127) {
/* 313 */         int escape = escCodes[ch];
/*     */         
/* 315 */         outputPtr = _appendByte(ch, escape, bb, outputPtr);
/* 316 */         outputBuffer = bb.getCurrentSegment();
/*     */       }
/*     */       else {
/* 319 */         if (ch <= 2047) {
/* 320 */           outputBuffer[(outputPtr++)] = ((byte)(0xC0 | ch >> 6));
/* 321 */           ch = 0x80 | ch & 0x3F;
/*     */ 
/*     */         }
/* 324 */         else if ((ch < 55296) || (ch > 57343)) {
/* 325 */           outputBuffer[(outputPtr++)] = ((byte)(0xE0 | ch >> 12));
/* 326 */           if (outputPtr >= outputBuffer.length) {
/* 327 */             outputBuffer = bb.finishCurrentSegment();
/* 328 */             outputPtr = 0;
/*     */           }
/* 330 */           outputBuffer[(outputPtr++)] = ((byte)(0x80 | ch >> 6 & 0x3F));
/* 331 */           ch = 0x80 | ch & 0x3F;
/*     */         } else {
/* 333 */           if (ch > 56319) {
/* 334 */             _illegal(ch);
/*     */           }
/*     */           
/* 337 */           if (inputPtr >= inputEnd) {
/* 338 */             _illegal(ch);
/*     */           }
/* 340 */           ch = _convert(ch, text.charAt(inputPtr++));
/* 341 */           if (ch > 1114111) {
/* 342 */             _illegal(ch);
/*     */           }
/* 344 */           outputBuffer[(outputPtr++)] = ((byte)(0xF0 | ch >> 18));
/* 345 */           if (outputPtr >= outputBuffer.length) {
/* 346 */             outputBuffer = bb.finishCurrentSegment();
/* 347 */             outputPtr = 0;
/*     */           }
/* 349 */           outputBuffer[(outputPtr++)] = ((byte)(0x80 | ch >> 12 & 0x3F));
/* 350 */           if (outputPtr >= outputBuffer.length) {
/* 351 */             outputBuffer = bb.finishCurrentSegment();
/* 352 */             outputPtr = 0;
/*     */           }
/* 354 */           outputBuffer[(outputPtr++)] = ((byte)(0x80 | ch >> 6 & 0x3F));
/* 355 */           ch = 0x80 | ch & 0x3F;
/*     */         }
/*     */         
/* 358 */         if (outputPtr >= outputBuffer.length) {
/* 359 */           outputBuffer = bb.finishCurrentSegment();
/* 360 */           outputPtr = 0;
/*     */         }
/* 362 */         outputBuffer[(outputPtr++)] = ((byte)ch); } }
/*     */     label504:
/* 364 */     if (bb == null) {
/* 365 */       return Arrays.copyOfRange(outputBuffer, 0, outputPtr);
/*     */     }
/* 367 */     return bb.completeAndCoalesce(outputPtr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] encodeAsUTF8(String text)
/*     */   {
/* 381 */     int inputPtr = 0;
/* 382 */     int inputEnd = text.length();
/* 383 */     int outputPtr = 0;
/* 384 */     byte[] outputBuffer = new byte[60];
/* 385 */     int outputEnd = outputBuffer.length;
/* 386 */     ByteArrayBuilder bb = null;
/*     */     
/*     */ 
/* 389 */     while (inputPtr < inputEnd) {
/* 390 */       int c = text.charAt(inputPtr++);
/*     */       
/*     */ 
/* 393 */       while (c <= 127) {
/* 394 */         if (outputPtr >= outputEnd) {
/* 395 */           if (bb == null) {
/* 396 */             bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */           }
/* 398 */           outputBuffer = bb.finishCurrentSegment();
/* 399 */           outputEnd = outputBuffer.length;
/* 400 */           outputPtr = 0;
/*     */         }
/* 402 */         outputBuffer[(outputPtr++)] = ((byte)c);
/* 403 */         if (inputPtr >= inputEnd) {
/*     */           break label453;
/*     */         }
/* 406 */         c = text.charAt(inputPtr++);
/*     */       }
/*     */       
/*     */ 
/* 410 */       if (bb == null) {
/* 411 */         bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */       }
/* 413 */       if (outputPtr >= outputEnd) {
/* 414 */         outputBuffer = bb.finishCurrentSegment();
/* 415 */         outputEnd = outputBuffer.length;
/* 416 */         outputPtr = 0;
/*     */       }
/* 418 */       if (c < 2048) {
/* 419 */         outputBuffer[(outputPtr++)] = ((byte)(0xC0 | c >> 6));
/*     */ 
/*     */       }
/* 422 */       else if ((c < 55296) || (c > 57343)) {
/* 423 */         outputBuffer[(outputPtr++)] = ((byte)(0xE0 | c >> 12));
/* 424 */         if (outputPtr >= outputEnd) {
/* 425 */           outputBuffer = bb.finishCurrentSegment();
/* 426 */           outputEnd = outputBuffer.length;
/* 427 */           outputPtr = 0;
/*     */         }
/* 429 */         outputBuffer[(outputPtr++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/*     */       } else {
/* 431 */         if (c > 56319) {
/* 432 */           _illegal(c);
/*     */         }
/*     */         
/* 435 */         if (inputPtr >= inputEnd) {
/* 436 */           _illegal(c);
/*     */         }
/* 438 */         c = _convert(c, text.charAt(inputPtr++));
/* 439 */         if (c > 1114111) {
/* 440 */           _illegal(c);
/*     */         }
/* 442 */         outputBuffer[(outputPtr++)] = ((byte)(0xF0 | c >> 18));
/* 443 */         if (outputPtr >= outputEnd) {
/* 444 */           outputBuffer = bb.finishCurrentSegment();
/* 445 */           outputEnd = outputBuffer.length;
/* 446 */           outputPtr = 0;
/*     */         }
/* 448 */         outputBuffer[(outputPtr++)] = ((byte)(0x80 | c >> 12 & 0x3F));
/* 449 */         if (outputPtr >= outputEnd) {
/* 450 */           outputBuffer = bb.finishCurrentSegment();
/* 451 */           outputEnd = outputBuffer.length;
/* 452 */           outputPtr = 0;
/*     */         }
/* 454 */         outputBuffer[(outputPtr++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/*     */       }
/*     */       
/* 457 */       if (outputPtr >= outputEnd) {
/* 458 */         outputBuffer = bb.finishCurrentSegment();
/* 459 */         outputEnd = outputBuffer.length;
/* 460 */         outputPtr = 0;
/*     */       }
/* 462 */       outputBuffer[(outputPtr++)] = ((byte)(0x80 | c & 0x3F)); }
/*     */     label453:
/* 464 */     if (bb == null) {
/* 465 */       return Arrays.copyOfRange(outputBuffer, 0, outputPtr);
/*     */     }
/* 467 */     return bb.completeAndCoalesce(outputPtr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] encodeAsUTF8(CharSequence text)
/*     */   {
/* 482 */     int inputPtr = 0;
/* 483 */     int inputEnd = text.length();
/* 484 */     int outputPtr = 0;
/* 485 */     byte[] outputBuffer = new byte[60];
/* 486 */     int outputEnd = outputBuffer.length;
/* 487 */     ByteArrayBuilder bb = null;
/*     */     
/*     */ 
/* 490 */     while (inputPtr < inputEnd) {
/* 491 */       int c = text.charAt(inputPtr++);
/*     */       
/*     */ 
/* 494 */       while (c <= 127) {
/* 495 */         if (outputPtr >= outputEnd) {
/* 496 */           if (bb == null) {
/* 497 */             bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */           }
/* 499 */           outputBuffer = bb.finishCurrentSegment();
/* 500 */           outputEnd = outputBuffer.length;
/* 501 */           outputPtr = 0;
/*     */         }
/* 503 */         outputBuffer[(outputPtr++)] = ((byte)c);
/* 504 */         if (inputPtr >= inputEnd) {
/*     */           break label461;
/*     */         }
/* 507 */         c = text.charAt(inputPtr++);
/*     */       }
/*     */       
/*     */ 
/* 511 */       if (bb == null) {
/* 512 */         bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */       }
/* 514 */       if (outputPtr >= outputEnd) {
/* 515 */         outputBuffer = bb.finishCurrentSegment();
/* 516 */         outputEnd = outputBuffer.length;
/* 517 */         outputPtr = 0;
/*     */       }
/* 519 */       if (c < 2048) {
/* 520 */         outputBuffer[(outputPtr++)] = ((byte)(0xC0 | c >> 6));
/*     */ 
/*     */       }
/* 523 */       else if ((c < 55296) || (c > 57343)) {
/* 524 */         outputBuffer[(outputPtr++)] = ((byte)(0xE0 | c >> 12));
/* 525 */         if (outputPtr >= outputEnd) {
/* 526 */           outputBuffer = bb.finishCurrentSegment();
/* 527 */           outputEnd = outputBuffer.length;
/* 528 */           outputPtr = 0;
/*     */         }
/* 530 */         outputBuffer[(outputPtr++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/*     */       } else {
/* 532 */         if (c > 56319) {
/* 533 */           _illegal(c);
/*     */         }
/*     */         
/* 536 */         if (inputPtr >= inputEnd) {
/* 537 */           _illegal(c);
/*     */         }
/* 539 */         c = _convert(c, text.charAt(inputPtr++));
/* 540 */         if (c > 1114111) {
/* 541 */           _illegal(c);
/*     */         }
/* 543 */         outputBuffer[(outputPtr++)] = ((byte)(0xF0 | c >> 18));
/* 544 */         if (outputPtr >= outputEnd) {
/* 545 */           outputBuffer = bb.finishCurrentSegment();
/* 546 */           outputEnd = outputBuffer.length;
/* 547 */           outputPtr = 0;
/*     */         }
/* 549 */         outputBuffer[(outputPtr++)] = ((byte)(0x80 | c >> 12 & 0x3F));
/* 550 */         if (outputPtr >= outputEnd) {
/* 551 */           outputBuffer = bb.finishCurrentSegment();
/* 552 */           outputEnd = outputBuffer.length;
/* 553 */           outputPtr = 0;
/*     */         }
/* 555 */         outputBuffer[(outputPtr++)] = ((byte)(0x80 | c >> 6 & 0x3F));
/*     */       }
/*     */       
/* 558 */       if (outputPtr >= outputEnd) {
/* 559 */         outputBuffer = bb.finishCurrentSegment();
/* 560 */         outputEnd = outputBuffer.length;
/* 561 */         outputPtr = 0;
/*     */       }
/* 563 */       outputBuffer[(outputPtr++)] = ((byte)(0x80 | c & 0x3F)); }
/*     */     label461:
/* 565 */     if (bb == null) {
/* 566 */       return Arrays.copyOfRange(outputBuffer, 0, outputPtr);
/*     */     }
/* 568 */     return bb.completeAndCoalesce(outputPtr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private char[] _qbuf()
/*     */   {
/* 578 */     char[] qbuf = new char[6];
/* 579 */     qbuf[0] = '\\';
/* 580 */     qbuf[2] = '0';
/* 581 */     qbuf[3] = '0';
/* 582 */     return qbuf;
/*     */   }
/*     */   
/*     */   private int _appendNumeric(int value, char[] qbuf) {
/* 586 */     qbuf[1] = 'u';
/*     */     
/* 588 */     qbuf[4] = HC[(value >> 4)];
/* 589 */     qbuf[5] = HC[(value & 0xF)];
/* 590 */     return 6;
/*     */   }
/*     */   
/*     */   private int _appendNamed(int esc, char[] qbuf) {
/* 594 */     qbuf[1] = ((char)esc);
/* 595 */     return 2;
/*     */   }
/*     */   
/*     */   private int _appendByte(int ch, int esc, ByteArrayBuilder bb, int ptr)
/*     */   {
/* 600 */     bb.setCurrentSegmentLength(ptr);
/* 601 */     bb.append(92);
/* 602 */     if (esc < 0) {
/* 603 */       bb.append(117);
/* 604 */       if (ch > 255) {
/* 605 */         int hi = ch >> 8;
/* 606 */         bb.append(HB[(hi >> 4)]);
/* 607 */         bb.append(HB[(hi & 0xF)]);
/* 608 */         ch &= 0xFF;
/*     */       } else {
/* 610 */         bb.append(48);
/* 611 */         bb.append(48);
/*     */       }
/* 613 */       bb.append(HB[(ch >> 4)]);
/* 614 */       bb.append(HB[(ch & 0xF)]);
/*     */     } else {
/* 616 */       bb.append((byte)esc);
/*     */     }
/* 618 */     return bb.getCurrentSegmentLength();
/*     */   }
/*     */   
/*     */   private static int _convert(int p1, int p2)
/*     */   {
/* 623 */     if ((p2 < 56320) || (p2 > 57343)) {
/* 624 */       throw new IllegalArgumentException("Broken surrogate pair: first char 0x" + Integer.toHexString(p1) + ", second 0x" + Integer.toHexString(p2) + "; illegal combination");
/*     */     }
/* 626 */     return 65536 + (p1 - 55296 << 10) + (p2 - 56320);
/*     */   }
/*     */   
/*     */   private static void _illegal(int c) {
/* 630 */     throw new IllegalArgumentException(UTF8Writer.illegalSurrogateDesc(c));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\io\JsonStringEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */