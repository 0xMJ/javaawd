/*      */ package com.fasterxml.jackson.core.base;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*      */ import com.fasterxml.jackson.core.JsonParser.NumberType;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import com.fasterxml.jackson.core.json.DupDetector;
/*      */ import com.fasterxml.jackson.core.json.JsonReadContext;
/*      */ import com.fasterxml.jackson.core.json.PackageVersion;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.core.util.TextBuffer;
/*      */ import java.io.IOException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ public abstract class ParserBase extends ParserMinimalBase
/*      */ {
/*   27 */   protected static final JacksonFeatureSet<StreamReadCapability> JSON_READ_CAPABILITIES = DEFAULT_READ_CAPABILITIES;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final IOContext _ioContext;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _closed;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _inputPtr;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _inputEnd;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long _currInputProcessed;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   83 */   protected int _currInputRow = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _currInputRowStart;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long _tokenInputTotal;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  112 */   protected int _tokenInputRow = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _tokenInputCol;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonReadContext _parsingContext;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonToken _nextToken;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final TextBuffer _textBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char[] _nameCopyBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _nameCopied;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ByteArrayBuilder _byteArrayBuilder;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] _binaryValue;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  187 */   protected int _numTypesValid = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _numberInt;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long _numberLong;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected double _numberDouble;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BigInteger _numberBigInt;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BigDecimal _numberBigDecimal;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _numberNegative;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _intLength;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _fractLength;
/*      */   
/*      */ 
/*      */ 
/*      */   protected int _expLength;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ParserBase(IOContext ctxt, int features)
/*      */   {
/*  238 */     super(features);
/*  239 */     this._ioContext = ctxt;
/*  240 */     this._textBuffer = ctxt.constructTextBuffer();
/*      */     
/*  242 */     DupDetector dups = JsonParser.Feature.STRICT_DUPLICATE_DETECTION.enabledIn(features) ? DupDetector.rootDetector(this) : null;
/*  243 */     this._parsingContext = JsonReadContext.createRootContext(dups);
/*      */   }
/*      */   
/*  246 */   public Version version() { return PackageVersion.VERSION; }
/*      */   
/*      */   public Object getCurrentValue()
/*      */   {
/*  250 */     return this._parsingContext.getCurrentValue();
/*      */   }
/*      */   
/*      */   public void setCurrentValue(Object v)
/*      */   {
/*  255 */     this._parsingContext.setCurrentValue(v);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser enable(JsonParser.Feature f)
/*      */   {
/*  266 */     this._features |= f.getMask();
/*  267 */     if ((f == JsonParser.Feature.STRICT_DUPLICATE_DETECTION) && 
/*  268 */       (this._parsingContext.getDupDetector() == null)) {
/*  269 */       this._parsingContext = this._parsingContext.withDupDetector(DupDetector.rootDetector(this));
/*      */     }
/*      */     
/*  272 */     return this;
/*      */   }
/*      */   
/*      */   public JsonParser disable(JsonParser.Feature f)
/*      */   {
/*  277 */     this._features &= (f.getMask() ^ 0xFFFFFFFF);
/*  278 */     if (f == JsonParser.Feature.STRICT_DUPLICATE_DETECTION) {
/*  279 */       this._parsingContext = this._parsingContext.withDupDetector(null);
/*      */     }
/*  281 */     return this;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser setFeatureMask(int newMask)
/*      */   {
/*  287 */     int changes = this._features ^ newMask;
/*  288 */     if (changes != 0) {
/*  289 */       this._features = newMask;
/*  290 */       _checkStdFeatureChanges(newMask, changes);
/*      */     }
/*  292 */     return this;
/*      */   }
/*      */   
/*      */   public JsonParser overrideStdFeatures(int values, int mask)
/*      */   {
/*  297 */     int oldState = this._features;
/*  298 */     int newState = oldState & (mask ^ 0xFFFFFFFF) | values & mask;
/*  299 */     int changed = oldState ^ newState;
/*  300 */     if (changed != 0) {
/*  301 */       this._features = newState;
/*  302 */       _checkStdFeatureChanges(newState, changed);
/*      */     }
/*  304 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _checkStdFeatureChanges(int newFeatureFlags, int changedFeatures)
/*      */   {
/*  318 */     int f = JsonParser.Feature.STRICT_DUPLICATE_DETECTION.getMask();
/*      */     
/*  320 */     if (((changedFeatures & f) != 0) && 
/*  321 */       ((newFeatureFlags & f) != 0)) {
/*  322 */       if (this._parsingContext.getDupDetector() == null) {
/*  323 */         this._parsingContext = this._parsingContext.withDupDetector(DupDetector.rootDetector(this));
/*      */       } else {
/*  325 */         this._parsingContext = this._parsingContext.withDupDetector(null);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getCurrentName()
/*      */     throws IOException
/*      */   {
/*  343 */     if ((this._currToken == JsonToken.START_OBJECT) || (this._currToken == JsonToken.START_ARRAY)) {
/*  344 */       JsonReadContext parent = this._parsingContext.getParent();
/*  345 */       if (parent != null) {
/*  346 */         return parent.getCurrentName();
/*      */       }
/*      */     }
/*  349 */     return this._parsingContext.getCurrentName();
/*      */   }
/*      */   
/*      */   public void overrideCurrentName(String name)
/*      */   {
/*  354 */     JsonReadContext ctxt = this._parsingContext;
/*  355 */     if ((this._currToken == JsonToken.START_OBJECT) || (this._currToken == JsonToken.START_ARRAY)) {
/*  356 */       ctxt = ctxt.getParent();
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  361 */       ctxt.setCurrentName(name);
/*      */     } catch (IOException e) {
/*  363 */       throw new IllegalStateException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 31	com/fasterxml/jackson/core/base/ParserBase:_closed	Z
/*      */     //   4: ifne +41 -> 45
/*      */     //   7: aload_0
/*      */     //   8: aload_0
/*      */     //   9: getfield 32	com/fasterxml/jackson/core/base/ParserBase:_inputPtr	I
/*      */     //   12: aload_0
/*      */     //   13: getfield 33	com/fasterxml/jackson/core/base/ParserBase:_inputEnd	I
/*      */     //   16: invokestatic 34	java/lang/Math:max	(II)I
/*      */     //   19: putfield 32	com/fasterxml/jackson/core/base/ParserBase:_inputPtr	I
/*      */     //   22: aload_0
/*      */     //   23: iconst_1
/*      */     //   24: putfield 31	com/fasterxml/jackson/core/base/ParserBase:_closed	Z
/*      */     //   27: aload_0
/*      */     //   28: invokevirtual 35	com/fasterxml/jackson/core/base/ParserBase:_closeInput	()V
/*      */     //   31: aload_0
/*      */     //   32: invokevirtual 36	com/fasterxml/jackson/core/base/ParserBase:_releaseBuffers	()V
/*      */     //   35: goto +10 -> 45
/*      */     //   38: astore_1
/*      */     //   39: aload_0
/*      */     //   40: invokevirtual 36	com/fasterxml/jackson/core/base/ParserBase:_releaseBuffers	()V
/*      */     //   43: aload_1
/*      */     //   44: athrow
/*      */     //   45: return
/*      */     // Line number table:
/*      */     //   Java source line #368	-> byte code offset #0
/*      */     //   Java source line #370	-> byte code offset #7
/*      */     //   Java source line #371	-> byte code offset #22
/*      */     //   Java source line #373	-> byte code offset #27
/*      */     //   Java source line #377	-> byte code offset #31
/*      */     //   Java source line #378	-> byte code offset #35
/*      */     //   Java source line #377	-> byte code offset #38
/*      */     //   Java source line #378	-> byte code offset #43
/*      */     //   Java source line #380	-> byte code offset #45
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	46	0	this	ParserBase
/*      */     //   38	6	1	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   27	31	38	finally
/*      */   }
/*      */   
/*  382 */   public boolean isClosed() { return this._closed; }
/*  383 */   public JsonReadContext getParsingContext() { return this._parsingContext; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonLocation getTokenLocation()
/*      */   {
/*  392 */     return new JsonLocation(_getSourceReference(), -1L, 
/*  393 */       getTokenCharacterOffset(), 
/*  394 */       getTokenLineNr(), 
/*  395 */       getTokenColumnNr());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonLocation getCurrentLocation()
/*      */   {
/*  404 */     int col = this._inputPtr - this._currInputRowStart + 1;
/*  405 */     return new JsonLocation(_getSourceReference(), -1L, this._currInputProcessed + this._inputPtr, this._currInputRow, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasTextCharacters()
/*      */   {
/*  418 */     if (this._currToken == JsonToken.VALUE_STRING) return true;
/*  419 */     if (this._currToken == JsonToken.FIELD_NAME) return this._nameCopied;
/*  420 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public byte[] getBinaryValue(Base64Variant variant)
/*      */     throws IOException
/*      */   {
/*  427 */     if (this._binaryValue == null) {
/*  428 */       if (this._currToken != JsonToken.VALUE_STRING) {
/*  429 */         _reportError("Current token (" + this._currToken + ") not VALUE_STRING, can not access as binary");
/*      */       }
/*  431 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  432 */       _decodeBase64(getText(), builder, variant);
/*  433 */       this._binaryValue = builder.toByteArray();
/*      */     }
/*  435 */     return this._binaryValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  444 */   public long getTokenCharacterOffset() { return this._tokenInputTotal; }
/*  445 */   public int getTokenLineNr() { return this._tokenInputRow; }
/*      */   
/*      */   public int getTokenColumnNr() {
/*  448 */     int col = this._tokenInputCol;
/*  449 */     return col < 0 ? col : col + 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected abstract void _closeInput()
/*      */     throws IOException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _releaseBuffers()
/*      */     throws IOException
/*      */   {
/*  473 */     this._textBuffer.releaseBuffers();
/*  474 */     char[] buf = this._nameCopyBuffer;
/*  475 */     if (buf != null) {
/*  476 */       this._nameCopyBuffer = null;
/*  477 */       this._ioContext.releaseNameCopyBuffer(buf);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _handleEOF()
/*      */     throws JsonParseException
/*      */   {
/*  488 */     if (!this._parsingContext.inRoot()) {
/*  489 */       String marker = this._parsingContext.inArray() ? "Array" : "Object";
/*  490 */       _reportInvalidEOF(String.format(": expected close marker for %s (start marker at %s)", new Object[] { marker, this._parsingContext
/*      */       
/*      */ 
/*  493 */         .getStartLocation(_getSourceReference()) }), null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final int _eofAsNextChar()
/*      */     throws JsonParseException
/*      */   {
/*  502 */     _handleEOF();
/*  503 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ByteArrayBuilder _getByteArrayBuilder()
/*      */   {
/*  514 */     if (this._byteArrayBuilder == null) {
/*  515 */       this._byteArrayBuilder = new ByteArrayBuilder();
/*      */     } else {
/*  517 */       this._byteArrayBuilder.reset();
/*      */     }
/*  519 */     return this._byteArrayBuilder;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final JsonToken reset(boolean negative, int intLen, int fractLen, int expLen)
/*      */   {
/*  532 */     if ((fractLen < 1) && (expLen < 1)) {
/*  533 */       return resetInt(negative, intLen);
/*      */     }
/*  535 */     return resetFloat(negative, intLen, fractLen, expLen);
/*      */   }
/*      */   
/*      */   protected final JsonToken resetInt(boolean negative, int intLen)
/*      */   {
/*  540 */     this._numberNegative = negative;
/*  541 */     this._intLength = intLen;
/*  542 */     this._fractLength = 0;
/*  543 */     this._expLength = 0;
/*  544 */     this._numTypesValid = 0;
/*  545 */     return JsonToken.VALUE_NUMBER_INT;
/*      */   }
/*      */   
/*      */   protected final JsonToken resetFloat(boolean negative, int intLen, int fractLen, int expLen)
/*      */   {
/*  550 */     this._numberNegative = negative;
/*  551 */     this._intLength = intLen;
/*  552 */     this._fractLength = fractLen;
/*  553 */     this._expLength = expLen;
/*  554 */     this._numTypesValid = 0;
/*  555 */     return JsonToken.VALUE_NUMBER_FLOAT;
/*      */   }
/*      */   
/*      */   protected final JsonToken resetAsNaN(String valueStr, double value)
/*      */   {
/*  560 */     this._textBuffer.resetWithString(valueStr);
/*  561 */     this._numberDouble = value;
/*  562 */     this._numTypesValid = 8;
/*  563 */     return JsonToken.VALUE_NUMBER_FLOAT;
/*      */   }
/*      */   
/*      */   public boolean isNaN()
/*      */   {
/*  568 */     if ((this._currToken == JsonToken.VALUE_NUMBER_FLOAT) && 
/*  569 */       ((this._numTypesValid & 0x8) != 0))
/*      */     {
/*  571 */       double d = this._numberDouble;
/*  572 */       return (Double.isNaN(d)) || (Double.isInfinite(d));
/*      */     }
/*      */     
/*  575 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Number getNumberValue()
/*      */     throws IOException
/*      */   {
/*  587 */     if (this._numTypesValid == 0) {
/*  588 */       _parseNumericValue(0);
/*      */     }
/*      */     
/*  591 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  592 */       if ((this._numTypesValid & 0x1) != 0) {
/*  593 */         return Integer.valueOf(this._numberInt);
/*      */       }
/*  595 */       if ((this._numTypesValid & 0x2) != 0) {
/*  596 */         return Long.valueOf(this._numberLong);
/*      */       }
/*  598 */       if ((this._numTypesValid & 0x4) != 0) {
/*  599 */         return this._numberBigInt;
/*      */       }
/*  601 */       _throwInternal();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  606 */     if ((this._numTypesValid & 0x10) != 0) {
/*  607 */       return this._numberBigDecimal;
/*      */     }
/*  609 */     if ((this._numTypesValid & 0x8) == 0) {
/*  610 */       _throwInternal();
/*      */     }
/*  612 */     return Double.valueOf(this._numberDouble);
/*      */   }
/*      */   
/*      */ 
/*      */   public Number getNumberValueExact()
/*      */     throws IOException
/*      */   {
/*  619 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  620 */       if (this._numTypesValid == 0) {
/*  621 */         _parseNumericValue(0);
/*      */       }
/*  623 */       if ((this._numTypesValid & 0x1) != 0) {
/*  624 */         return Integer.valueOf(this._numberInt);
/*      */       }
/*  626 */       if ((this._numTypesValid & 0x2) != 0) {
/*  627 */         return Long.valueOf(this._numberLong);
/*      */       }
/*  629 */       if ((this._numTypesValid & 0x4) != 0) {
/*  630 */         return this._numberBigInt;
/*      */       }
/*  632 */       _throwInternal();
/*      */     }
/*      */     
/*  635 */     if (this._numTypesValid == 0) {
/*  636 */       _parseNumericValue(16);
/*      */     }
/*  638 */     if ((this._numTypesValid & 0x10) != 0) {
/*  639 */       return this._numberBigDecimal;
/*      */     }
/*  641 */     if ((this._numTypesValid & 0x8) == 0) {
/*  642 */       _throwInternal();
/*      */     }
/*  644 */     return Double.valueOf(this._numberDouble);
/*      */   }
/*      */   
/*      */   public JsonParser.NumberType getNumberType()
/*      */     throws IOException
/*      */   {
/*  650 */     if (this._numTypesValid == 0) {
/*  651 */       _parseNumericValue(0);
/*      */     }
/*  653 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  654 */       if ((this._numTypesValid & 0x1) != 0) {
/*  655 */         return JsonParser.NumberType.INT;
/*      */       }
/*  657 */       if ((this._numTypesValid & 0x2) != 0) {
/*  658 */         return JsonParser.NumberType.LONG;
/*      */       }
/*  660 */       return JsonParser.NumberType.BIG_INTEGER;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  669 */     if ((this._numTypesValid & 0x10) != 0) {
/*  670 */       return JsonParser.NumberType.BIG_DECIMAL;
/*      */     }
/*  672 */     return JsonParser.NumberType.DOUBLE;
/*      */   }
/*      */   
/*      */   public int getIntValue()
/*      */     throws IOException
/*      */   {
/*  678 */     if ((this._numTypesValid & 0x1) == 0) {
/*  679 */       if (this._numTypesValid == 0) {
/*  680 */         return _parseIntValue();
/*      */       }
/*  682 */       if ((this._numTypesValid & 0x1) == 0) {
/*  683 */         convertNumberToInt();
/*      */       }
/*      */     }
/*  686 */     return this._numberInt;
/*      */   }
/*      */   
/*      */   public long getLongValue()
/*      */     throws IOException
/*      */   {
/*  692 */     if ((this._numTypesValid & 0x2) == 0) {
/*  693 */       if (this._numTypesValid == 0) {
/*  694 */         _parseNumericValue(2);
/*      */       }
/*  696 */       if ((this._numTypesValid & 0x2) == 0) {
/*  697 */         convertNumberToLong();
/*      */       }
/*      */     }
/*  700 */     return this._numberLong;
/*      */   }
/*      */   
/*      */   public BigInteger getBigIntegerValue()
/*      */     throws IOException
/*      */   {
/*  706 */     if ((this._numTypesValid & 0x4) == 0) {
/*  707 */       if (this._numTypesValid == 0) {
/*  708 */         _parseNumericValue(4);
/*      */       }
/*  710 */       if ((this._numTypesValid & 0x4) == 0) {
/*  711 */         convertNumberToBigInteger();
/*      */       }
/*      */     }
/*  714 */     return this._numberBigInt;
/*      */   }
/*      */   
/*      */   public float getFloatValue()
/*      */     throws IOException
/*      */   {
/*  720 */     double value = getDoubleValue();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  729 */     return (float)value;
/*      */   }
/*      */   
/*      */   public double getDoubleValue()
/*      */     throws IOException
/*      */   {
/*  735 */     if ((this._numTypesValid & 0x8) == 0) {
/*  736 */       if (this._numTypesValid == 0) {
/*  737 */         _parseNumericValue(8);
/*      */       }
/*  739 */       if ((this._numTypesValid & 0x8) == 0) {
/*  740 */         convertNumberToDouble();
/*      */       }
/*      */     }
/*  743 */     return this._numberDouble;
/*      */   }
/*      */   
/*      */   public BigDecimal getDecimalValue()
/*      */     throws IOException
/*      */   {
/*  749 */     if ((this._numTypesValid & 0x10) == 0) {
/*  750 */       if (this._numTypesValid == 0) {
/*  751 */         _parseNumericValue(16);
/*      */       }
/*  753 */       if ((this._numTypesValid & 0x10) == 0) {
/*  754 */         convertNumberToBigDecimal();
/*      */       }
/*      */     }
/*  757 */     return this._numberBigDecimal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _parseNumericValue(int expType)
/*      */     throws IOException
/*      */   {
/*  780 */     if (this._closed) {
/*  781 */       _reportError("Internal error: _parseNumericValue called when parser instance closed");
/*      */     }
/*      */     
/*      */ 
/*  785 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  786 */       int len = this._intLength;
/*      */       
/*  788 */       if (len <= 9) {
/*  789 */         int i = this._textBuffer.contentsAsInt(this._numberNegative);
/*  790 */         this._numberInt = i;
/*  791 */         this._numTypesValid = 1;
/*  792 */         return;
/*      */       }
/*  794 */       if (len <= 18) {
/*  795 */         long l = this._textBuffer.contentsAsLong(this._numberNegative);
/*      */         
/*  797 */         if (len == 10) {
/*  798 */           if (this._numberNegative) {
/*  799 */             if (l >= -2147483648L) {
/*  800 */               this._numberInt = ((int)l);
/*  801 */               this._numTypesValid = 1;
/*      */             }
/*      */             
/*      */           }
/*  805 */           else if (l <= 2147483647L) {
/*  806 */             this._numberInt = ((int)l);
/*  807 */             this._numTypesValid = 1;
/*  808 */             return;
/*      */           }
/*      */         }
/*      */         
/*  812 */         this._numberLong = l;
/*  813 */         this._numTypesValid = 2;
/*  814 */         return;
/*      */       }
/*  816 */       _parseSlowInt(expType);
/*  817 */       return;
/*      */     }
/*  819 */     if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT) {
/*  820 */       _parseSlowFloat(expType);
/*  821 */       return;
/*      */     }
/*  823 */     _reportError("Current token (%s) not numeric, can not use numeric value accessors", this._currToken);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _parseIntValue()
/*      */     throws IOException
/*      */   {
/*  834 */     if (this._closed) {
/*  835 */       _reportError("Internal error: _parseNumericValue called when parser instance closed");
/*      */     }
/*      */     
/*  838 */     if ((this._currToken == JsonToken.VALUE_NUMBER_INT) && 
/*  839 */       (this._intLength <= 9)) {
/*  840 */       int i = this._textBuffer.contentsAsInt(this._numberNegative);
/*  841 */       this._numberInt = i;
/*  842 */       this._numTypesValid = 1;
/*  843 */       return i;
/*      */     }
/*      */     
/*      */ 
/*  847 */     _parseNumericValue(1);
/*  848 */     if ((this._numTypesValid & 0x1) == 0) {
/*  849 */       convertNumberToInt();
/*      */     }
/*  851 */     return this._numberInt;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _parseSlowFloat(int expType)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  864 */       if (expType == 16) {
/*  865 */         this._numberBigDecimal = this._textBuffer.contentsAsDecimal();
/*  866 */         this._numTypesValid = 16;
/*      */       }
/*      */       else {
/*  869 */         this._numberDouble = this._textBuffer.contentsAsDouble();
/*  870 */         this._numTypesValid = 8;
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException nex) {
/*  874 */       _wrapError("Malformed numeric value (" + _longNumberDesc(this._textBuffer.contentsAsString()) + ")", nex);
/*      */     }
/*      */   }
/*      */   
/*      */   private void _parseSlowInt(int expType) throws IOException
/*      */   {
/*  880 */     String numStr = this._textBuffer.contentsAsString();
/*      */     try {
/*  882 */       int len = this._intLength;
/*  883 */       char[] buf = this._textBuffer.getTextBuffer();
/*  884 */       int offset = this._textBuffer.getTextOffset();
/*  885 */       if (this._numberNegative) {
/*  886 */         offset++;
/*      */       }
/*      */       
/*  889 */       if (NumberInput.inLongRange(buf, offset, len, this._numberNegative))
/*      */       {
/*  891 */         this._numberLong = Long.parseLong(numStr);
/*  892 */         this._numTypesValid = 2;
/*      */       }
/*      */       else {
/*  895 */         if ((expType == 1) || (expType == 2)) {
/*  896 */           _reportTooLongIntegral(expType, numStr);
/*      */         }
/*  898 */         if ((expType == 8) || (expType == 32)) {
/*  899 */           this._numberDouble = NumberInput.parseDouble(numStr);
/*  900 */           this._numTypesValid = 8;
/*      */         }
/*      */         else {
/*  903 */           this._numberBigInt = new BigInteger(numStr);
/*  904 */           this._numTypesValid = 4;
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException nex) {
/*  909 */       _wrapError("Malformed numeric value (" + _longNumberDesc(numStr) + ")", nex);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void _reportTooLongIntegral(int expType, String rawNum)
/*      */     throws IOException
/*      */   {
/*  916 */     if (expType == 1) {
/*  917 */       reportOverflowInt(rawNum);
/*      */     } else {
/*  919 */       reportOverflowLong(rawNum);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void convertNumberToInt()
/*      */     throws IOException
/*      */   {
/*  932 */     if ((this._numTypesValid & 0x2) != 0)
/*      */     {
/*  934 */       int result = (int)this._numberLong;
/*  935 */       if (result != this._numberLong) {
/*  936 */         reportOverflowInt(getText(), currentToken());
/*      */       }
/*  938 */       this._numberInt = result;
/*  939 */     } else if ((this._numTypesValid & 0x4) != 0) {
/*  940 */       if ((BI_MIN_INT.compareTo(this._numberBigInt) > 0) || 
/*  941 */         (BI_MAX_INT.compareTo(this._numberBigInt) < 0)) {
/*  942 */         reportOverflowInt();
/*      */       }
/*  944 */       this._numberInt = this._numberBigInt.intValue();
/*  945 */     } else if ((this._numTypesValid & 0x8) != 0)
/*      */     {
/*  947 */       if ((this._numberDouble < -2.147483648E9D) || (this._numberDouble > 2.147483647E9D)) {
/*  948 */         reportOverflowInt();
/*      */       }
/*  950 */       this._numberInt = ((int)this._numberDouble);
/*  951 */     } else if ((this._numTypesValid & 0x10) != 0) {
/*  952 */       if ((BD_MIN_INT.compareTo(this._numberBigDecimal) > 0) || 
/*  953 */         (BD_MAX_INT.compareTo(this._numberBigDecimal) < 0)) {
/*  954 */         reportOverflowInt();
/*      */       }
/*  956 */       this._numberInt = this._numberBigDecimal.intValue();
/*      */     } else {
/*  958 */       _throwInternal();
/*      */     }
/*  960 */     this._numTypesValid |= 0x1;
/*      */   }
/*      */   
/*      */   protected void convertNumberToLong() throws IOException
/*      */   {
/*  965 */     if ((this._numTypesValid & 0x1) != 0) {
/*  966 */       this._numberLong = this._numberInt;
/*  967 */     } else if ((this._numTypesValid & 0x4) != 0) {
/*  968 */       if ((BI_MIN_LONG.compareTo(this._numberBigInt) > 0) || 
/*  969 */         (BI_MAX_LONG.compareTo(this._numberBigInt) < 0)) {
/*  970 */         reportOverflowLong();
/*      */       }
/*  972 */       this._numberLong = this._numberBigInt.longValue();
/*  973 */     } else if ((this._numTypesValid & 0x8) != 0)
/*      */     {
/*  975 */       if ((this._numberDouble < -9.223372036854776E18D) || (this._numberDouble > 9.223372036854776E18D)) {
/*  976 */         reportOverflowLong();
/*      */       }
/*  978 */       this._numberLong = (this._numberDouble);
/*  979 */     } else if ((this._numTypesValid & 0x10) != 0) {
/*  980 */       if ((BD_MIN_LONG.compareTo(this._numberBigDecimal) > 0) || 
/*  981 */         (BD_MAX_LONG.compareTo(this._numberBigDecimal) < 0)) {
/*  982 */         reportOverflowLong();
/*      */       }
/*  984 */       this._numberLong = this._numberBigDecimal.longValue();
/*      */     } else {
/*  986 */       _throwInternal();
/*      */     }
/*  988 */     this._numTypesValid |= 0x2;
/*      */   }
/*      */   
/*      */   protected void convertNumberToBigInteger() throws IOException
/*      */   {
/*  993 */     if ((this._numTypesValid & 0x10) != 0)
/*      */     {
/*  995 */       this._numberBigInt = this._numberBigDecimal.toBigInteger();
/*  996 */     } else if ((this._numTypesValid & 0x2) != 0) {
/*  997 */       this._numberBigInt = BigInteger.valueOf(this._numberLong);
/*  998 */     } else if ((this._numTypesValid & 0x1) != 0) {
/*  999 */       this._numberBigInt = BigInteger.valueOf(this._numberInt);
/* 1000 */     } else if ((this._numTypesValid & 0x8) != 0) {
/* 1001 */       this._numberBigInt = BigDecimal.valueOf(this._numberDouble).toBigInteger();
/*      */     } else {
/* 1003 */       _throwInternal();
/*      */     }
/* 1005 */     this._numTypesValid |= 0x4;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void convertNumberToDouble()
/*      */     throws IOException
/*      */   {
/* 1016 */     if ((this._numTypesValid & 0x10) != 0) {
/* 1017 */       this._numberDouble = this._numberBigDecimal.doubleValue();
/* 1018 */     } else if ((this._numTypesValid & 0x4) != 0) {
/* 1019 */       this._numberDouble = this._numberBigInt.doubleValue();
/* 1020 */     } else if ((this._numTypesValid & 0x2) != 0) {
/* 1021 */       this._numberDouble = this._numberLong;
/* 1022 */     } else if ((this._numTypesValid & 0x1) != 0) {
/* 1023 */       this._numberDouble = this._numberInt;
/*      */     } else {
/* 1025 */       _throwInternal();
/*      */     }
/* 1027 */     this._numTypesValid |= 0x8;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void convertNumberToBigDecimal()
/*      */     throws IOException
/*      */   {
/* 1038 */     if ((this._numTypesValid & 0x8) != 0)
/*      */     {
/*      */ 
/*      */ 
/* 1042 */       this._numberBigDecimal = NumberInput.parseBigDecimal(getText());
/* 1043 */     } else if ((this._numTypesValid & 0x4) != 0) {
/* 1044 */       this._numberBigDecimal = new BigDecimal(this._numberBigInt);
/* 1045 */     } else if ((this._numTypesValid & 0x2) != 0) {
/* 1046 */       this._numberBigDecimal = BigDecimal.valueOf(this._numberLong);
/* 1047 */     } else if ((this._numTypesValid & 0x1) != 0) {
/* 1048 */       this._numberBigDecimal = BigDecimal.valueOf(this._numberInt);
/*      */     } else {
/* 1050 */       _throwInternal();
/*      */     }
/* 1052 */     this._numTypesValid |= 0x10;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _reportMismatchedEndMarker(int actCh, char expCh)
/*      */     throws JsonParseException
/*      */   {
/* 1062 */     JsonReadContext ctxt = getParsingContext();
/* 1063 */     _reportError(String.format("Unexpected close marker '%s': expected '%c' (for %s starting at %s)", new Object[] {
/*      */     
/* 1065 */       Character.valueOf((char)actCh), Character.valueOf(expCh), ctxt.typeDesc(), ctxt.getStartLocation(_getSourceReference()) }));
/*      */   }
/*      */   
/*      */   protected char _handleUnrecognizedCharacterEscape(char ch)
/*      */     throws com.fasterxml.jackson.core.JsonProcessingException
/*      */   {
/* 1071 */     if (isEnabled(JsonParser.Feature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER)) {
/* 1072 */       return ch;
/*      */     }
/*      */     
/* 1075 */     if ((ch == '\'') && (isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES))) {
/* 1076 */       return ch;
/*      */     }
/* 1078 */     _reportError("Unrecognized character escape " + _getCharDesc(ch));
/* 1079 */     return ch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _throwUnquotedSpace(int i, String ctxtDesc)
/*      */     throws JsonParseException
/*      */   {
/* 1091 */     if ((!isEnabled(JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS)) || (i > 32)) {
/* 1092 */       char c = (char)i;
/* 1093 */       String msg = "Illegal unquoted character (" + _getCharDesc(c) + "): has to be escaped using backslash to be included in " + ctxtDesc;
/* 1094 */       _reportError(msg);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String _validJsonTokenList()
/*      */     throws IOException
/*      */   {
/* 1106 */     return _validJsonValueList();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String _validJsonValueList()
/*      */     throws IOException
/*      */   {
/* 1118 */     if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 1119 */       return "(JSON String, Number (or 'NaN'/'INF'/'+INF'), Array, Object or token 'null', 'true' or 'false')";
/*      */     }
/* 1121 */     return "(JSON String, Number, Array, Object or token 'null', 'true' or 'false')";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char _decodeEscaped()
/*      */     throws IOException
/*      */   {
/* 1136 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   protected final int _decodeBase64Escape(Base64Variant b64variant, int ch, int index)
/*      */     throws IOException
/*      */   {
/* 1142 */     if (ch != 92) {
/* 1143 */       throw reportInvalidBase64Char(b64variant, ch, index);
/*      */     }
/* 1145 */     int unescaped = _decodeEscaped();
/*      */     
/* 1147 */     if ((unescaped <= 32) && 
/* 1148 */       (index == 0)) {
/* 1149 */       return -1;
/*      */     }
/*      */     
/*      */ 
/* 1153 */     int bits = b64variant.decodeBase64Char(unescaped);
/* 1154 */     if ((bits < 0) && 
/* 1155 */       (bits != -2)) {
/* 1156 */       throw reportInvalidBase64Char(b64variant, unescaped, index);
/*      */     }
/*      */     
/* 1159 */     return bits;
/*      */   }
/*      */   
/*      */   protected final int _decodeBase64Escape(Base64Variant b64variant, char ch, int index) throws IOException
/*      */   {
/* 1164 */     if (ch != '\\') {
/* 1165 */       throw reportInvalidBase64Char(b64variant, ch, index);
/*      */     }
/* 1167 */     char unescaped = _decodeEscaped();
/*      */     
/* 1169 */     if ((unescaped <= ' ') && 
/* 1170 */       (index == 0)) {
/* 1171 */       return -1;
/*      */     }
/*      */     
/*      */ 
/* 1175 */     int bits = b64variant.decodeBase64Char(unescaped);
/* 1176 */     if (bits < 0)
/*      */     {
/* 1178 */       if ((bits != -2) || (index < 2)) {
/* 1179 */         throw reportInvalidBase64Char(b64variant, unescaped, index);
/*      */       }
/*      */     }
/* 1182 */     return bits;
/*      */   }
/*      */   
/*      */   protected IllegalArgumentException reportInvalidBase64Char(Base64Variant b64variant, int ch, int bindex) throws IllegalArgumentException {
/* 1186 */     return reportInvalidBase64Char(b64variant, ch, bindex, null);
/*      */   }
/*      */   
/*      */ 
/*      */   protected IllegalArgumentException reportInvalidBase64Char(Base64Variant b64variant, int ch, int bindex, String msg)
/*      */     throws IllegalArgumentException
/*      */   {
/*      */     String base;
/*      */     String base;
/* 1195 */     if (ch <= 32) {
/* 1196 */       base = String.format("Illegal white space character (code 0x%s) as character #%d of 4-char base64 unit: can only used between units", new Object[] {
/* 1197 */         Integer.toHexString(ch), Integer.valueOf(bindex + 1) }); } else { String base;
/* 1198 */       if (b64variant.usesPaddingChar(ch)) {
/* 1199 */         base = "Unexpected padding character ('" + b64variant.getPaddingChar() + "') as character #" + (bindex + 1) + " of 4-char base64 unit: padding only legal as 3rd or 4th character"; } else { String base;
/* 1200 */         if ((!Character.isDefined(ch)) || (Character.isISOControl(ch)))
/*      */         {
/* 1202 */           base = "Illegal character (code 0x" + Integer.toHexString(ch) + ") in base64 content";
/*      */         } else
/* 1204 */           base = "Illegal character '" + (char)ch + "' (code 0x" + Integer.toHexString(ch) + ") in base64 content";
/*      */       } }
/* 1206 */     if (msg != null) {
/* 1207 */       base = base + ": " + msg;
/*      */     }
/* 1209 */     return new IllegalArgumentException(base);
/*      */   }
/*      */   
/*      */   protected void _handleBase64MissingPadding(Base64Variant b64variant)
/*      */     throws IOException
/*      */   {
/* 1215 */     _reportError(b64variant.missingPaddingMessage());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object _getSourceReference()
/*      */   {
/* 1231 */     if (JsonParser.Feature.INCLUDE_SOURCE_IN_LOCATION.enabledIn(this._features)) {
/* 1232 */       return this._ioContext.getSourceReference();
/*      */     }
/* 1234 */     return null;
/*      */   }
/*      */   
/*      */   protected static int[] growArrayBy(int[] arr, int more)
/*      */   {
/* 1239 */     if (arr == null) {
/* 1240 */       return new int[more];
/*      */     }
/* 1242 */     return Arrays.copyOf(arr, arr.length + more);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected void loadMoreGuaranteed()
/*      */     throws IOException
/*      */   {
/* 1254 */     if (!loadMore()) _reportInvalidEOF();
/*      */   }
/*      */   
/*      */   @Deprecated
/* 1258 */   protected boolean loadMore() throws IOException { return false; }
/*      */   
/*      */   protected void _finishString()
/*      */     throws IOException
/*      */   {}
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\base\ParserBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */