/*     */ package com.fasterxml.jackson.core.sym;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonFactory.Feature;
/*     */ import com.fasterxml.jackson.core.util.InternCache;
/*     */ import java.util.Arrays;
/*     */ import java.util.BitSet;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharsToNameCanonicalizer
/*     */ {
/*     */   public static final int HASH_MULT = 33;
/*     */   private static final int DEFAULT_T_SIZE = 64;
/*     */   private static final int MAX_T_SIZE = 65536;
/*     */   static final int MAX_ENTRIES_FOR_REUSE = 12000;
/*     */   static final int MAX_COLL_CHAIN_LENGTH = 100;
/*     */   protected final CharsToNameCanonicalizer _parent;
/*     */   protected final AtomicReference<TableInfo> _tableInfo;
/*     */   protected final int _seed;
/*     */   protected final int _flags;
/*     */   protected boolean _canonicalize;
/*     */   protected String[] _symbols;
/*     */   protected Bucket[] _buckets;
/*     */   protected int _size;
/*     */   protected int _sizeThreshold;
/*     */   protected int _indexMask;
/*     */   protected int _longestCollisionList;
/*     */   protected boolean _hashShared;
/*     */   protected BitSet _overflows;
/*     */   
/*     */   private CharsToNameCanonicalizer(int seed)
/*     */   {
/* 231 */     this._parent = null;
/* 232 */     this._seed = seed;
/*     */     
/*     */ 
/* 235 */     this._canonicalize = true;
/* 236 */     this._flags = -1;
/*     */     
/* 238 */     this._hashShared = false;
/* 239 */     this._longestCollisionList = 0;
/*     */     
/* 241 */     this._tableInfo = new AtomicReference(TableInfo.createInitial(64));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CharsToNameCanonicalizer(CharsToNameCanonicalizer parent, int flags, int seed, TableInfo parentState)
/*     */   {
/* 252 */     this._parent = parent;
/* 253 */     this._seed = seed;
/* 254 */     this._tableInfo = null;
/* 255 */     this._flags = flags;
/* 256 */     this._canonicalize = JsonFactory.Feature.CANONICALIZE_FIELD_NAMES.enabledIn(flags);
/*     */     
/*     */ 
/* 259 */     this._symbols = parentState.symbols;
/* 260 */     this._buckets = parentState.buckets;
/*     */     
/* 262 */     this._size = parentState.size;
/* 263 */     this._longestCollisionList = parentState.longestCollisionList;
/*     */     
/*     */ 
/* 266 */     int arrayLen = this._symbols.length;
/* 267 */     this._sizeThreshold = _thresholdSize(arrayLen);
/* 268 */     this._indexMask = (arrayLen - 1);
/*     */     
/*     */ 
/* 271 */     this._hashShared = true;
/*     */   }
/*     */   
/* 274 */   private static int _thresholdSize(int hashAreaSize) { return hashAreaSize - (hashAreaSize >> 2); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CharsToNameCanonicalizer createRoot()
/*     */   {
/* 293 */     long now = System.currentTimeMillis();
/*     */     
/* 295 */     int seed = (int)now + (int)(now >>> 32) | 0x1;
/* 296 */     return createRoot(seed);
/*     */   }
/*     */   
/*     */   protected static CharsToNameCanonicalizer createRoot(int seed) {
/* 300 */     return new CharsToNameCanonicalizer(seed);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CharsToNameCanonicalizer makeChild(int flags)
/*     */   {
/* 319 */     return new CharsToNameCanonicalizer(this, flags, this._seed, (TableInfo)this._tableInfo.get());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void release()
/*     */   {
/* 330 */     if (!maybeDirty()) { return;
/*     */     }
/*     */     
/* 333 */     if ((this._parent != null) && (this._canonicalize)) {
/* 334 */       this._parent.mergeChild(new TableInfo(this));
/*     */       
/*     */ 
/* 337 */       this._hashShared = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void mergeChild(TableInfo childState)
/*     */   {
/* 350 */     int childCount = childState.size;
/* 351 */     TableInfo currState = (TableInfo)this._tableInfo.get();
/*     */     
/*     */ 
/*     */ 
/* 355 */     if (childCount == currState.size) {
/* 356 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 362 */     if (childCount > 12000)
/*     */     {
/* 364 */       childState = TableInfo.createInitial(64);
/*     */     }
/* 366 */     this._tableInfo.compareAndSet(currState, childState);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 379 */     if (this._tableInfo != null) {
/* 380 */       return ((TableInfo)this._tableInfo.get()).size;
/*     */     }
/*     */     
/* 383 */     return this._size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 392 */   public int bucketCount() { return this._symbols.length; }
/* 393 */   public boolean maybeDirty() { return !this._hashShared; }
/* 394 */   public int hashSeed() { return this._seed; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int collisionCount()
/*     */   {
/* 406 */     int count = 0;
/*     */     
/* 408 */     for (Bucket bucket : this._buckets) {
/* 409 */       if (bucket != null) {
/* 410 */         count += bucket.length;
/*     */       }
/*     */     }
/* 413 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int maxCollisionLength()
/*     */   {
/* 425 */     return this._longestCollisionList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String findSymbol(char[] buffer, int start, int len, int h)
/*     */   {
/* 435 */     if (len < 1) {
/* 436 */       return "";
/*     */     }
/* 438 */     if (!this._canonicalize) {
/* 439 */       return new String(buffer, start, len);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 447 */     int index = _hashToIndex(h);
/* 448 */     String sym = this._symbols[index];
/*     */     
/*     */ 
/* 451 */     if (sym != null)
/*     */     {
/* 453 */       if (sym.length() == len) {
/* 454 */         int i = 0;
/* 455 */         while (sym.charAt(i) == buffer[(start + i)])
/*     */         {
/* 457 */           i++; if (i == len) {
/* 458 */             return sym;
/*     */           }
/*     */         }
/*     */       }
/* 462 */       Bucket b = this._buckets[(index >> 1)];
/* 463 */       if (b != null) {
/* 464 */         sym = b.has(buffer, start, len);
/* 465 */         if (sym != null) {
/* 466 */           return sym;
/*     */         }
/* 468 */         sym = _findSymbol2(buffer, start, len, b.next);
/* 469 */         if (sym != null) {
/* 470 */           return sym;
/*     */         }
/*     */       }
/*     */     }
/* 474 */     return _addSymbol(buffer, start, len, h, index);
/*     */   }
/*     */   
/*     */   private String _findSymbol2(char[] buffer, int start, int len, Bucket b) {
/* 478 */     while (b != null) {
/* 479 */       String sym = b.has(buffer, start, len);
/* 480 */       if (sym != null) {
/* 481 */         return sym;
/*     */       }
/* 483 */       b = b.next;
/*     */     }
/* 485 */     return null;
/*     */   }
/*     */   
/*     */   private String _addSymbol(char[] buffer, int start, int len, int h, int index)
/*     */   {
/* 490 */     if (this._hashShared) {
/* 491 */       copyArrays();
/* 492 */       this._hashShared = false;
/* 493 */     } else if (this._size >= this._sizeThreshold) {
/* 494 */       rehash();
/*     */       
/*     */ 
/* 497 */       index = _hashToIndex(calcHash(buffer, start, len));
/*     */     }
/*     */     
/* 500 */     String newSymbol = new String(buffer, start, len);
/* 501 */     if (JsonFactory.Feature.INTERN_FIELD_NAMES.enabledIn(this._flags)) {
/* 502 */       newSymbol = InternCache.instance.intern(newSymbol);
/*     */     }
/* 504 */     this._size += 1;
/*     */     
/* 506 */     if (this._symbols[index] == null) {
/* 507 */       this._symbols[index] = newSymbol;
/*     */     } else {
/* 509 */       int bix = index >> 1;
/* 510 */       Bucket newB = new Bucket(newSymbol, this._buckets[bix]);
/* 511 */       int collLen = newB.length;
/* 512 */       if (collLen > 100)
/*     */       {
/*     */ 
/* 515 */         _handleSpillOverflow(bix, newB, index);
/*     */       } else {
/* 517 */         this._buckets[bix] = newB;
/* 518 */         this._longestCollisionList = Math.max(collLen, this._longestCollisionList);
/*     */       }
/*     */     }
/* 521 */     return newSymbol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void _handleSpillOverflow(int bucketIndex, Bucket newBucket, int mainIndex)
/*     */   {
/* 533 */     if (this._overflows == null) {
/* 534 */       this._overflows = new BitSet();
/* 535 */       this._overflows.set(bucketIndex);
/*     */     }
/* 537 */     else if (this._overflows.get(bucketIndex))
/*     */     {
/* 539 */       if (JsonFactory.Feature.FAIL_ON_SYMBOL_HASH_OVERFLOW.enabledIn(this._flags)) {
/* 540 */         reportTooManyCollisions(100);
/*     */       }
/*     */       
/*     */ 
/* 544 */       this._canonicalize = false;
/*     */     } else {
/* 546 */       this._overflows.set(bucketIndex);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 551 */     this._symbols[mainIndex] = newBucket.symbol;
/* 552 */     this._buckets[bucketIndex] = null;
/*     */     
/* 554 */     this._size -= newBucket.length;
/*     */     
/* 556 */     this._longestCollisionList = -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int _hashToIndex(int rawHash)
/*     */   {
/* 569 */     rawHash += (rawHash >>> 15);
/* 570 */     rawHash ^= rawHash << 7;
/* 571 */     rawHash += (rawHash >>> 3);
/* 572 */     return rawHash & this._indexMask;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int calcHash(char[] buffer, int start, int len)
/*     */   {
/* 588 */     int hash = this._seed;
/* 589 */     int i = start; for (int end = start + len; i < end; i++) {
/* 590 */       hash = hash * 33 + buffer[i];
/*     */     }
/*     */     
/* 593 */     return hash == 0 ? 1 : hash;
/*     */   }
/*     */   
/*     */   public int calcHash(String key)
/*     */   {
/* 598 */     int len = key.length();
/*     */     
/* 600 */     int hash = this._seed;
/* 601 */     for (int i = 0; i < len; i++) {
/* 602 */       hash = hash * 33 + key.charAt(i);
/*     */     }
/*     */     
/* 605 */     return hash == 0 ? 1 : hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void copyArrays()
/*     */   {
/* 619 */     String[] oldSyms = this._symbols;
/* 620 */     this._symbols = ((String[])Arrays.copyOf(oldSyms, oldSyms.length));
/* 621 */     Bucket[] oldBuckets = this._buckets;
/* 622 */     this._buckets = ((Bucket[])Arrays.copyOf(oldBuckets, oldBuckets.length));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void rehash()
/*     */   {
/* 633 */     int size = this._symbols.length;
/* 634 */     int newSize = size + size;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 640 */     if (newSize > 65536)
/*     */     {
/*     */ 
/* 643 */       this._size = 0;
/* 644 */       this._canonicalize = false;
/*     */       
/* 646 */       this._symbols = new String[64];
/* 647 */       this._buckets = new Bucket[32];
/* 648 */       this._indexMask = 63;
/* 649 */       this._hashShared = false;
/* 650 */       return;
/*     */     }
/*     */     
/* 653 */     String[] oldSyms = this._symbols;
/* 654 */     Bucket[] oldBuckets = this._buckets;
/* 655 */     this._symbols = new String[newSize];
/* 656 */     this._buckets = new Bucket[newSize >> 1];
/*     */     
/* 658 */     this._indexMask = (newSize - 1);
/* 659 */     this._sizeThreshold = _thresholdSize(newSize);
/*     */     
/* 661 */     int count = 0;
/*     */     
/*     */ 
/*     */ 
/* 665 */     int maxColl = 0;
/* 666 */     for (int i = 0; i < size; i++) {
/* 667 */       String symbol = oldSyms[i];
/* 668 */       if (symbol != null) {
/* 669 */         count++;
/* 670 */         int index = _hashToIndex(calcHash(symbol));
/* 671 */         if (this._symbols[index] == null) {
/* 672 */           this._symbols[index] = symbol;
/*     */         } else {
/* 674 */           int bix = index >> 1;
/* 675 */           Bucket newB = new Bucket(symbol, this._buckets[bix]);
/* 676 */           this._buckets[bix] = newB;
/* 677 */           maxColl = Math.max(maxColl, newB.length);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 682 */     int bucketSize = size >> 1;
/* 683 */     for (int i = 0; i < bucketSize; i++) {
/* 684 */       Bucket b = oldBuckets[i];
/* 685 */       while (b != null) {
/* 686 */         count++;
/* 687 */         String symbol = b.symbol;
/* 688 */         int index = _hashToIndex(calcHash(symbol));
/* 689 */         if (this._symbols[index] == null) {
/* 690 */           this._symbols[index] = symbol;
/*     */         } else {
/* 692 */           int bix = index >> 1;
/* 693 */           Bucket newB = new Bucket(symbol, this._buckets[bix]);
/* 694 */           this._buckets[bix] = newB;
/* 695 */           maxColl = Math.max(maxColl, newB.length);
/*     */         }
/* 697 */         b = b.next;
/*     */       }
/*     */     }
/* 700 */     this._longestCollisionList = maxColl;
/* 701 */     this._overflows = null;
/*     */     
/* 703 */     if (count != this._size) {
/* 704 */       throw new IllegalStateException(String.format("Internal error on SymbolTable.rehash(): had %d entries; now have %d", new Object[] {
/*     */       
/* 706 */         Integer.valueOf(this._size), Integer.valueOf(count) }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void reportTooManyCollisions(int maxLen)
/*     */   {
/* 716 */     throw new IllegalStateException("Longest collision chain in symbol table (of size " + this._size + ") now exceeds maximum, " + maxLen + " -- suspect a DoS attack based on hash collisions");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void verifyInternalConsistency()
/*     */   {
/* 728 */     int count = 0;
/* 729 */     int size = this._symbols.length;
/*     */     
/* 731 */     for (int i = 0; i < size; i++) {
/* 732 */       String symbol = this._symbols[i];
/* 733 */       if (symbol != null) {
/* 734 */         count++;
/*     */       }
/*     */     }
/*     */     
/* 738 */     int bucketSize = size >> 1;
/* 739 */     for (int i = 0; i < bucketSize; i++) {
/* 740 */       for (Bucket b = this._buckets[i]; b != null; b = b.next) {
/* 741 */         count++;
/*     */       }
/*     */     }
/* 744 */     if (count != this._size) {
/* 745 */       throw new IllegalStateException(String.format("Internal error: expected internal size %d vs calculated count %d", new Object[] {
/* 746 */         Integer.valueOf(this._size), Integer.valueOf(count) }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class Bucket
/*     */   {
/*     */     public final String symbol;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public final Bucket next;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public final int length;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Bucket(String s, Bucket n)
/*     */     {
/* 816 */       this.symbol = s;
/* 817 */       this.next = n;
/* 818 */       this.length = (n == null ? 1 : n.length + 1);
/*     */     }
/*     */     
/*     */     public String has(char[] buf, int start, int len) {
/* 822 */       if (this.symbol.length() != len) {
/* 823 */         return null;
/*     */       }
/* 825 */       int i = 0;
/*     */       do {
/* 827 */         if (this.symbol.charAt(i) != buf[(start + i)]) {
/* 828 */           return null;
/*     */         }
/* 830 */         i++; } while (i < len);
/* 831 */       return this.symbol;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class TableInfo
/*     */   {
/*     */     final int size;
/*     */     
/*     */ 
/*     */     final int longestCollisionList;
/*     */     
/*     */ 
/*     */     final String[] symbols;
/*     */     
/*     */     final CharsToNameCanonicalizer.Bucket[] buckets;
/*     */     
/*     */ 
/*     */     public TableInfo(int size, int longestCollisionList, String[] symbols, CharsToNameCanonicalizer.Bucket[] buckets)
/*     */     {
/* 852 */       this.size = size;
/* 853 */       this.longestCollisionList = longestCollisionList;
/* 854 */       this.symbols = symbols;
/* 855 */       this.buckets = buckets;
/*     */     }
/*     */     
/*     */     public TableInfo(CharsToNameCanonicalizer src)
/*     */     {
/* 860 */       this.size = src._size;
/* 861 */       this.longestCollisionList = src._longestCollisionList;
/* 862 */       this.symbols = src._symbols;
/* 863 */       this.buckets = src._buckets;
/*     */     }
/*     */     
/*     */     public static TableInfo createInitial(int sz) {
/* 867 */       return new TableInfo(0, 0, new String[sz], new CharsToNameCanonicalizer.Bucket[sz >> 1]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\sym\CharsToNameCanonicalizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */