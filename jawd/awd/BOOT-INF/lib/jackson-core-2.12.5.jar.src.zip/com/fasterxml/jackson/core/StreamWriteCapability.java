/*    */ package com.fasterxml.jackson.core;
/*    */ 
/*    */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum StreamWriteCapability
/*    */   implements JacksonFeature
/*    */ {
/* 24 */   CAN_WRITE_BINARY_NATIVELY(false), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 34 */   CAN_WRITE_FORMATTED_NUMBERS(false);
/*    */   
/*    */ 
/*    */ 
/*    */   private final boolean _defaultState;
/*    */   
/*    */   private final int _mask;
/*    */   
/*    */ 
/*    */   private StreamWriteCapability(boolean defaultState)
/*    */   {
/* 45 */     this._defaultState = defaultState;
/* 46 */     this._mask = (1 << ordinal());
/*    */   }
/*    */   
/*    */ 
/* 50 */   public boolean enabledByDefault() { return this._defaultState; }
/*    */   
/* 52 */   public boolean enabledIn(int flags) { return (flags & this._mask) != 0; }
/*    */   
/* 54 */   public int getMask() { return this._mask; }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\StreamWriteCapability.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */