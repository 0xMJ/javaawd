/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.CharTypes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsonStreamContext
/*     */ {
/*     */   public static final int TYPE_ROOT = 0;
/*     */   public static final int TYPE_ARRAY = 1;
/*     */   public static final int TYPE_OBJECT = 2;
/*     */   protected int _type;
/*     */   protected int _index;
/*     */   
/*     */   protected JsonStreamContext() {}
/*     */   
/*     */   protected JsonStreamContext(JsonStreamContext base)
/*     */   {
/*  71 */     this._type = base._type;
/*  72 */     this._index = base._index;
/*     */   }
/*     */   
/*     */   protected JsonStreamContext(int type, int index)
/*     */   {
/*  77 */     this._type = type;
/*  78 */     this._index = index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JsonStreamContext getParent();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean inArray()
/*     */   {
/* 101 */     return this._type == 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean inRoot()
/*     */   {
/* 110 */     return this._type == 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean inObject()
/*     */   {
/* 118 */     return this._type == 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final String getTypeDesc()
/*     */   {
/* 127 */     switch (this._type) {
/* 128 */     case 0:  return "ROOT";
/* 129 */     case 1:  return "ARRAY";
/* 130 */     case 2:  return "OBJECT";
/*     */     }
/* 132 */     return "?";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String typeDesc()
/*     */   {
/* 145 */     switch (this._type) {
/* 146 */     case 0:  return "root";
/* 147 */     case 1:  return "Array";
/* 148 */     case 2:  return "Object";
/*     */     }
/* 150 */     return "?";
/*     */   }
/*     */   
/*     */ 
/*     */   public final int getEntryCount()
/*     */   {
/* 156 */     return this._index + 1;
/*     */   }
/*     */   
/*     */   public final int getCurrentIndex()
/*     */   {
/* 161 */     return this._index < 0 ? 0 : this._index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasCurrentIndex()
/*     */   {
/* 172 */     return this._index >= 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasPathSegment()
/*     */   {
/* 194 */     if (this._type == 2)
/* 195 */       return hasCurrentName();
/* 196 */     if (this._type == 1) {
/* 197 */       return hasCurrentIndex();
/*     */     }
/* 199 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getCurrentName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasCurrentName()
/*     */   {
/* 217 */     return getCurrentName() != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getCurrentValue()
/*     */   {
/* 234 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrentValue(Object v) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonPointer pathAsPointer()
/*     */   {
/* 258 */     return JsonPointer.forPath(this, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonPointer pathAsPointer(boolean includeRoot)
/*     */   {
/* 273 */     return JsonPointer.forPath(this, includeRoot);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonLocation getStartLocation(Object srcRef)
/*     */   {
/* 294 */     return JsonLocation.NA;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 308 */     StringBuilder sb = new StringBuilder(64);
/* 309 */     switch (this._type) {
/*     */     case 0: 
/* 311 */       sb.append("/");
/* 312 */       break;
/*     */     case 1: 
/* 314 */       sb.append('[');
/* 315 */       sb.append(getCurrentIndex());
/* 316 */       sb.append(']');
/* 317 */       break;
/*     */     case 2: 
/*     */     default: 
/* 320 */       sb.append('{');
/* 321 */       String currentName = getCurrentName();
/* 322 */       if (currentName != null) {
/* 323 */         sb.append('"');
/* 324 */         CharTypes.appendQuoted(sb, currentName);
/* 325 */         sb.append('"');
/*     */       } else {
/* 327 */         sb.append('?');
/*     */       }
/* 329 */       sb.append('}');
/*     */     }
/*     */     
/* 332 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\JsonStreamContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */