package com.fasterxml.jackson.core.async;

import java.io.IOException;

public abstract interface ByteArrayFeeder
  extends NonBlockingInputFeeder
{
  public abstract void feedInput(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\async\ByteArrayFeeder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */