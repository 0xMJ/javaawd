/*    */ package com.fasterxml.jackson.core;
/*    */ 
/*    */ import com.fasterxml.jackson.core.io.SerializedString;
/*    */ import com.fasterxml.jackson.core.util.Separators;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface PrettyPrinter
/*    */ {
/* 31 */   public static final Separators DEFAULT_SEPARATORS = ;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 38 */   public static final SerializedString DEFAULT_ROOT_VALUE_SEPARATOR = new SerializedString(" ");
/*    */   
/*    */   public abstract void writeRootValueSeparator(JsonGenerator paramJsonGenerator)
/*    */     throws IOException;
/*    */   
/*    */   public abstract void writeStartObject(JsonGenerator paramJsonGenerator)
/*    */     throws IOException;
/*    */   
/*    */   public abstract void writeEndObject(JsonGenerator paramJsonGenerator, int paramInt)
/*    */     throws IOException;
/*    */   
/*    */   public abstract void writeObjectEntrySeparator(JsonGenerator paramJsonGenerator)
/*    */     throws IOException;
/*    */   
/*    */   public abstract void writeObjectFieldValueSeparator(JsonGenerator paramJsonGenerator)
/*    */     throws IOException;
/*    */   
/*    */   public abstract void writeStartArray(JsonGenerator paramJsonGenerator)
/*    */     throws IOException;
/*    */   
/*    */   public abstract void writeEndArray(JsonGenerator paramJsonGenerator, int paramInt)
/*    */     throws IOException;
/*    */   
/*    */   public abstract void writeArrayValueSeparator(JsonGenerator paramJsonGenerator)
/*    */     throws IOException;
/*    */   
/*    */   public abstract void beforeArrayValues(JsonGenerator paramJsonGenerator)
/*    */     throws IOException;
/*    */   
/*    */   public abstract void beforeObjectEntries(JsonGenerator paramJsonGenerator)
/*    */     throws IOException;
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\PrettyPrinter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */