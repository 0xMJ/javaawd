/*     */ package com.fasterxml.jackson.core.filter;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenFilterContext
/*     */   extends JsonStreamContext
/*     */ {
/*     */   protected final TokenFilterContext _parent;
/*     */   protected TokenFilterContext _child;
/*     */   protected String _currentName;
/*     */   protected TokenFilter _filter;
/*     */   protected boolean _startHandled;
/*     */   protected boolean _needToHandleName;
/*     */   
/*     */   protected TokenFilterContext(int type, TokenFilterContext parent, TokenFilter filter, boolean startHandled)
/*     */   {
/*  72 */     this._type = type;
/*  73 */     this._parent = parent;
/*  74 */     this._filter = filter;
/*  75 */     this._index = -1;
/*  76 */     this._startHandled = startHandled;
/*  77 */     this._needToHandleName = false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected TokenFilterContext reset(int type, TokenFilter filter, boolean startWritten)
/*     */   {
/*  83 */     this._type = type;
/*  84 */     this._filter = filter;
/*  85 */     this._index = -1;
/*  86 */     this._currentName = null;
/*  87 */     this._startHandled = startWritten;
/*  88 */     this._needToHandleName = false;
/*  89 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TokenFilterContext createRootContext(TokenFilter filter)
/*     */   {
/* 100 */     return new TokenFilterContext(0, null, filter, true);
/*     */   }
/*     */   
/*     */   public TokenFilterContext createChildArrayContext(TokenFilter filter, boolean writeStart) {
/* 104 */     TokenFilterContext ctxt = this._child;
/* 105 */     if (ctxt == null) {
/* 106 */       this._child = (ctxt = new TokenFilterContext(1, this, filter, writeStart));
/* 107 */       return ctxt;
/*     */     }
/* 109 */     return ctxt.reset(1, filter, writeStart);
/*     */   }
/*     */   
/*     */   public TokenFilterContext createChildObjectContext(TokenFilter filter, boolean writeStart) {
/* 113 */     TokenFilterContext ctxt = this._child;
/* 114 */     if (ctxt == null) {
/* 115 */       this._child = (ctxt = new TokenFilterContext(2, this, filter, writeStart));
/* 116 */       return ctxt;
/*     */     }
/* 118 */     return ctxt.reset(2, filter, writeStart);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TokenFilter setFieldName(String name)
/*     */     throws JsonProcessingException
/*     */   {
/* 128 */     this._currentName = name;
/* 129 */     this._needToHandleName = true;
/* 130 */     return this._filter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TokenFilter checkValue(TokenFilter filter)
/*     */   {
/* 139 */     if (this._type == 2) {
/* 140 */       return filter;
/*     */     }
/*     */     
/* 143 */     int ix = ++this._index;
/* 144 */     if (this._type == 1) {
/* 145 */       return filter.includeElement(ix);
/*     */     }
/* 147 */     return filter.includeRootValue(ix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void ensureFieldNameWritten(JsonGenerator gen)
/*     */     throws IOException
/*     */   {
/* 155 */     if (this._needToHandleName) {
/* 156 */       this._needToHandleName = false;
/* 157 */       gen.writeFieldName(this._currentName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writePath(JsonGenerator gen)
/*     */     throws IOException
/*     */   {
/* 167 */     if ((this._filter == null) || (this._filter == TokenFilter.INCLUDE_ALL)) {
/* 168 */       return;
/*     */     }
/* 170 */     if (this._parent != null) {
/* 171 */       this._parent._writePath(gen);
/*     */     }
/* 173 */     if (this._startHandled)
/*     */     {
/* 175 */       if (this._needToHandleName) {
/* 176 */         gen.writeFieldName(this._currentName);
/*     */       }
/*     */     } else {
/* 179 */       this._startHandled = true;
/* 180 */       if (this._type == 2) {
/* 181 */         gen.writeStartObject();
/* 182 */         gen.writeFieldName(this._currentName);
/* 183 */       } else if (this._type == 1) {
/* 184 */         gen.writeStartArray();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void _writePath(JsonGenerator gen) throws IOException
/*     */   {
/* 191 */     if ((this._filter == null) || (this._filter == TokenFilter.INCLUDE_ALL)) {
/* 192 */       return;
/*     */     }
/* 194 */     if (this._parent != null) {
/* 195 */       this._parent._writePath(gen);
/*     */     }
/* 197 */     if (this._startHandled)
/*     */     {
/* 199 */       if (this._needToHandleName) {
/* 200 */         this._needToHandleName = false;
/* 201 */         gen.writeFieldName(this._currentName);
/*     */       }
/*     */     } else {
/* 204 */       this._startHandled = true;
/* 205 */       if (this._type == 2) {
/* 206 */         gen.writeStartObject();
/* 207 */         if (this._needToHandleName) {
/* 208 */           this._needToHandleName = false;
/* 209 */           gen.writeFieldName(this._currentName);
/*     */         }
/* 211 */       } else if (this._type == 1) {
/* 212 */         gen.writeStartArray();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public TokenFilterContext closeArray(JsonGenerator gen) throws IOException
/*     */   {
/* 219 */     if (this._startHandled) {
/* 220 */       gen.writeEndArray();
/*     */     }
/* 222 */     if ((this._filter != null) && (this._filter != TokenFilter.INCLUDE_ALL)) {
/* 223 */       this._filter.filterFinishArray();
/*     */     }
/* 225 */     return this._parent;
/*     */   }
/*     */   
/*     */   public TokenFilterContext closeObject(JsonGenerator gen) throws IOException
/*     */   {
/* 230 */     if (this._startHandled) {
/* 231 */       gen.writeEndObject();
/*     */     }
/* 233 */     if ((this._filter != null) && (this._filter != TokenFilter.INCLUDE_ALL)) {
/* 234 */       this._filter.filterFinishObject();
/*     */     }
/* 236 */     return this._parent;
/*     */   }
/*     */   
/*     */   public void skipParentChecks() {
/* 240 */     this._filter = null;
/* 241 */     for (TokenFilterContext ctxt = this._parent; ctxt != null; ctxt = ctxt._parent) {
/* 242 */       this._parent._filter = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getCurrentValue()
/*     */   {
/* 253 */     return null;
/*     */   }
/*     */   
/*     */   public void setCurrentValue(Object v) {}
/*     */   
/* 258 */   public final TokenFilterContext getParent() { return this._parent; }
/* 259 */   public final String getCurrentName() { return this._currentName; }
/*     */   
/* 261 */   public boolean hasCurrentName() { return this._currentName != null; }
/*     */   
/* 263 */   public TokenFilter getFilter() { return this._filter; }
/* 264 */   public boolean isStartHandled() { return this._startHandled; }
/*     */   
/*     */   public JsonToken nextTokenToRead() {
/* 267 */     if (!this._startHandled) {
/* 268 */       this._startHandled = true;
/* 269 */       if (this._type == 2) {
/* 270 */         return JsonToken.START_OBJECT;
/*     */       }
/*     */       
/* 273 */       return JsonToken.START_ARRAY;
/*     */     }
/*     */     
/* 276 */     if ((this._needToHandleName) && (this._type == 2)) {
/* 277 */       this._needToHandleName = false;
/* 278 */       return JsonToken.FIELD_NAME;
/*     */     }
/* 280 */     return null;
/*     */   }
/*     */   
/*     */   public TokenFilterContext findChildOf(TokenFilterContext parent) {
/* 284 */     if (this._parent == parent) {
/* 285 */       return this;
/*     */     }
/* 287 */     TokenFilterContext curr = this._parent;
/* 288 */     while (curr != null) {
/* 289 */       TokenFilterContext p = curr._parent;
/* 290 */       if (p == parent) {
/* 291 */         return curr;
/*     */       }
/* 293 */       curr = p;
/*     */     }
/*     */     
/* 296 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void appendDesc(StringBuilder sb)
/*     */   {
/* 302 */     if (this._parent != null) {
/* 303 */       this._parent.appendDesc(sb);
/*     */     }
/* 305 */     if (this._type == 2) {
/* 306 */       sb.append('{');
/* 307 */       if (this._currentName != null) {
/* 308 */         sb.append('"');
/*     */         
/* 310 */         sb.append(this._currentName);
/* 311 */         sb.append('"');
/*     */       } else {
/* 313 */         sb.append('?');
/*     */       }
/* 315 */       sb.append('}');
/* 316 */     } else if (this._type == 1) {
/* 317 */       sb.append('[');
/* 318 */       sb.append(getCurrentIndex());
/* 319 */       sb.append(']');
/*     */     }
/*     */     else {
/* 322 */       sb.append("/");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 333 */     StringBuilder sb = new StringBuilder(64);
/* 334 */     appendDesc(sb);
/* 335 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\filter\TokenFilterContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */