/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.base.ParserBase;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.TextBuffer;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ 
/*      */ public class ReaderBasedJsonParser extends ParserBase
/*      */ {
/*   23 */   private static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*      */   
/*      */ 
/*   26 */   private static final int FEAT_MASK_LEADING_ZEROS = JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS.getMask();
/*      */   
/*      */ 
/*   29 */   private static final int FEAT_MASK_NON_NUM_NUMBERS = JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS.getMask();
/*      */   
/*      */ 
/*   32 */   private static final int FEAT_MASK_ALLOW_MISSING = JsonParser.Feature.ALLOW_MISSING_VALUES.getMask();
/*   33 */   private static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
/*   34 */   private static final int FEAT_MASK_ALLOW_UNQUOTED_NAMES = JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
/*      */   
/*   36 */   private static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = JsonParser.Feature.ALLOW_COMMENTS.getMask();
/*   37 */   private static final int FEAT_MASK_ALLOW_YAML_COMMENTS = JsonParser.Feature.ALLOW_YAML_COMMENTS.getMask();
/*      */   
/*      */ 
/*      */ 
/*   41 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Reader _reader;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected char[] _inputBuffer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _bufferRecyclable;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectCodec _objectCodec;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final CharsToNameCanonicalizer _symbols;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final int _hashSeed;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _tokenIncomplete;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected long _nameStartOffset;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _nameStartRow;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _nameStartCol;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ReaderBasedJsonParser(IOContext ctxt, int features, Reader r, ObjectCodec codec, CharsToNameCanonicalizer st, char[] inputBuffer, int start, int end, boolean bufferRecyclable)
/*      */   {
/*  133 */     super(ctxt, features);
/*  134 */     this._reader = r;
/*  135 */     this._inputBuffer = inputBuffer;
/*  136 */     this._inputPtr = start;
/*  137 */     this._inputEnd = end;
/*  138 */     this._objectCodec = codec;
/*  139 */     this._symbols = st;
/*  140 */     this._hashSeed = st.hashSeed();
/*  141 */     this._bufferRecyclable = bufferRecyclable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ReaderBasedJsonParser(IOContext ctxt, int features, Reader r, ObjectCodec codec, CharsToNameCanonicalizer st)
/*      */   {
/*  151 */     super(ctxt, features);
/*  152 */     this._reader = r;
/*  153 */     this._inputBuffer = ctxt.allocTokenBuffer();
/*  154 */     this._inputPtr = 0;
/*  155 */     this._inputEnd = 0;
/*  156 */     this._objectCodec = codec;
/*  157 */     this._symbols = st;
/*  158 */     this._hashSeed = st.hashSeed();
/*  159 */     this._bufferRecyclable = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  168 */   public ObjectCodec getCodec() { return this._objectCodec; }
/*  169 */   public void setCodec(ObjectCodec c) { this._objectCodec = c; }
/*      */   
/*      */   public com.fasterxml.jackson.core.util.JacksonFeatureSet<StreamReadCapability> getReadCapabilities()
/*      */   {
/*  173 */     return JSON_READ_CAPABILITIES;
/*      */   }
/*      */   
/*      */   public int releaseBuffered(Writer w) throws IOException
/*      */   {
/*  178 */     int count = this._inputEnd - this._inputPtr;
/*  179 */     if (count < 1) { return 0;
/*      */     }
/*  181 */     int origPtr = this._inputPtr;
/*  182 */     this._inputPtr += count;
/*  183 */     w.write(this._inputBuffer, origPtr, count);
/*  184 */     return count;
/*      */   }
/*      */   
/*  187 */   public Object getInputSource() { return this._reader; }
/*      */   
/*      */   @Deprecated
/*      */   protected char getNextChar(String eofMsg) throws IOException {
/*  191 */     return getNextChar(eofMsg, null);
/*      */   }
/*      */   
/*      */   protected char getNextChar(String eofMsg, JsonToken forToken) throws IOException {
/*  195 */     if ((this._inputPtr >= this._inputEnd) && 
/*  196 */       (!_loadMore())) {
/*  197 */       _reportInvalidEOF(eofMsg, forToken);
/*      */     }
/*      */     
/*  200 */     return this._inputBuffer[(this._inputPtr++)];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _closeInput()
/*      */     throws IOException
/*      */   {
/*  212 */     if (this._reader != null) {
/*  213 */       if ((this._ioContext.isResourceManaged()) || (isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE))) {
/*  214 */         this._reader.close();
/*      */       }
/*  216 */       this._reader = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _releaseBuffers()
/*      */     throws IOException
/*      */   {
/*  229 */     super._releaseBuffers();
/*      */     
/*  231 */     this._symbols.release();
/*      */     
/*  233 */     if (this._bufferRecyclable) {
/*  234 */       char[] buf = this._inputBuffer;
/*  235 */       if (buf != null) {
/*  236 */         this._inputBuffer = null;
/*  237 */         this._ioContext.releaseTokenBuffer(buf);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _loadMoreGuaranteed()
/*      */     throws IOException
/*      */   {
/*  249 */     if (!_loadMore()) _reportInvalidEOF();
/*      */   }
/*      */   
/*      */   protected boolean _loadMore() throws IOException
/*      */   {
/*  254 */     if (this._reader != null) {
/*  255 */       int count = this._reader.read(this._inputBuffer, 0, this._inputBuffer.length);
/*  256 */       if (count > 0) {
/*  257 */         int bufSize = this._inputEnd;
/*  258 */         this._currInputProcessed += bufSize;
/*  259 */         this._currInputRowStart -= bufSize;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  264 */         this._nameStartOffset -= bufSize;
/*      */         
/*  266 */         this._inputPtr = 0;
/*  267 */         this._inputEnd = count;
/*      */         
/*  269 */         return true;
/*      */       }
/*      */       
/*  272 */       _closeInput();
/*      */       
/*  274 */       if (count == 0) {
/*  275 */         throw new IOException("Reader returned 0 characters when trying to read " + this._inputEnd);
/*      */       }
/*      */     }
/*  278 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final String getText()
/*      */     throws IOException
/*      */   {
/*  296 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  297 */       if (this._tokenIncomplete) {
/*  298 */         this._tokenIncomplete = false;
/*  299 */         _finishString();
/*      */       }
/*  301 */       return this._textBuffer.contentsAsString();
/*      */     }
/*  303 */     return _getText2(this._currToken);
/*      */   }
/*      */   
/*      */   public int getText(Writer writer)
/*      */     throws IOException
/*      */   {
/*  309 */     JsonToken t = this._currToken;
/*  310 */     if (t == JsonToken.VALUE_STRING) {
/*  311 */       if (this._tokenIncomplete) {
/*  312 */         this._tokenIncomplete = false;
/*  313 */         _finishString();
/*      */       }
/*  315 */       return this._textBuffer.contentsToWriter(writer);
/*      */     }
/*  317 */     if (t == JsonToken.FIELD_NAME) {
/*  318 */       String n = this._parsingContext.getCurrentName();
/*  319 */       writer.write(n);
/*  320 */       return n.length();
/*      */     }
/*  322 */     if (t != null) {
/*  323 */       if (t.isNumeric()) {
/*  324 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  326 */       char[] ch = t.asCharArray();
/*  327 */       writer.write(ch);
/*  328 */       return ch.length;
/*      */     }
/*  330 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final String getValueAsString()
/*      */     throws IOException
/*      */   {
/*  339 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  340 */       if (this._tokenIncomplete) {
/*  341 */         this._tokenIncomplete = false;
/*  342 */         _finishString();
/*      */       }
/*  344 */       return this._textBuffer.contentsAsString();
/*      */     }
/*  346 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  347 */       return getCurrentName();
/*      */     }
/*  349 */     return super.getValueAsString(null);
/*      */   }
/*      */   
/*      */   public final String getValueAsString(String defValue)
/*      */     throws IOException
/*      */   {
/*  355 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  356 */       if (this._tokenIncomplete) {
/*  357 */         this._tokenIncomplete = false;
/*  358 */         _finishString();
/*      */       }
/*  360 */       return this._textBuffer.contentsAsString();
/*      */     }
/*  362 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  363 */       return getCurrentName();
/*      */     }
/*  365 */     return super.getValueAsString(defValue);
/*      */   }
/*      */   
/*      */   protected final String _getText2(JsonToken t) {
/*  369 */     if (t == null) {
/*  370 */       return null;
/*      */     }
/*  372 */     switch (t.id()) {
/*      */     case 5: 
/*  374 */       return this._parsingContext.getCurrentName();
/*      */     
/*      */ 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/*  380 */       return this._textBuffer.contentsAsString();
/*      */     }
/*  382 */     return t.asString();
/*      */   }
/*      */   
/*      */ 
/*      */   public final char[] getTextCharacters()
/*      */     throws IOException
/*      */   {
/*  389 */     if (this._currToken != null) {
/*  390 */       switch (this._currToken.id()) {
/*      */       case 5: 
/*  392 */         if (!this._nameCopied) {
/*  393 */           String name = this._parsingContext.getCurrentName();
/*  394 */           int nameLen = name.length();
/*  395 */           if (this._nameCopyBuffer == null) {
/*  396 */             this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  397 */           } else if (this._nameCopyBuffer.length < nameLen) {
/*  398 */             this._nameCopyBuffer = new char[nameLen];
/*      */           }
/*  400 */           name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  401 */           this._nameCopied = true;
/*      */         }
/*  403 */         return this._nameCopyBuffer;
/*      */       case 6: 
/*  405 */         if (this._tokenIncomplete) {
/*  406 */           this._tokenIncomplete = false;
/*  407 */           _finishString();
/*      */         }
/*      */       
/*      */       case 7: 
/*      */       case 8: 
/*  412 */         return this._textBuffer.getTextBuffer();
/*      */       }
/*  414 */       return this._currToken.asCharArray();
/*      */     }
/*      */     
/*  417 */     return null;
/*      */   }
/*      */   
/*      */   public final int getTextLength()
/*      */     throws IOException
/*      */   {
/*  423 */     if (this._currToken != null) {
/*  424 */       switch (this._currToken.id()) {
/*      */       case 5: 
/*  426 */         return this._parsingContext.getCurrentName().length();
/*      */       case 6: 
/*  428 */         if (this._tokenIncomplete) {
/*  429 */           this._tokenIncomplete = false;
/*  430 */           _finishString();
/*      */         }
/*      */       
/*      */       case 7: 
/*      */       case 8: 
/*  435 */         return this._textBuffer.size();
/*      */       }
/*  437 */       return this._currToken.asCharArray().length;
/*      */     }
/*      */     
/*  440 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */   public final int getTextOffset()
/*      */     throws IOException
/*      */   {
/*  447 */     if (this._currToken != null) {
/*  448 */       switch (this._currToken.id()) {
/*      */       case 5: 
/*  450 */         return 0;
/*      */       case 6: 
/*  452 */         if (this._tokenIncomplete) {
/*  453 */           this._tokenIncomplete = false;
/*  454 */           _finishString();
/*      */         }
/*      */       
/*      */       case 7: 
/*      */       case 8: 
/*  459 */         return this._textBuffer.getTextOffset();
/*      */       }
/*      */       
/*      */     }
/*  463 */     return 0;
/*      */   }
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant)
/*      */     throws IOException
/*      */   {
/*  469 */     if ((this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT) && (this._binaryValue != null)) {
/*  470 */       return this._binaryValue;
/*      */     }
/*  472 */     if (this._currToken != JsonToken.VALUE_STRING) {
/*  473 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */     
/*  476 */     if (this._tokenIncomplete) {
/*      */       try {
/*  478 */         this._binaryValue = _decodeBase64(b64variant);
/*      */       } catch (IllegalArgumentException iae) {
/*  480 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  485 */       this._tokenIncomplete = false;
/*      */     }
/*  487 */     else if (this._binaryValue == null)
/*      */     {
/*  489 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  490 */       _decodeBase64(getText(), builder, b64variant);
/*  491 */       this._binaryValue = builder.toByteArray();
/*      */     }
/*      */     
/*  494 */     return this._binaryValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out)
/*      */     throws IOException
/*      */   {
/*  501 */     if ((!this._tokenIncomplete) || (this._currToken != JsonToken.VALUE_STRING)) {
/*  502 */       byte[] b = getBinaryValue(b64variant);
/*  503 */       out.write(b);
/*  504 */       return b.length;
/*      */     }
/*      */     
/*  507 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  509 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  511 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     }
/*      */   }
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer) throws IOException
/*      */   {
/*  517 */     int outputPtr = 0;
/*  518 */     int outputEnd = buffer.length - 3;
/*  519 */     int outputCount = 0;
/*      */     
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/*  525 */       if (this._inputPtr >= this._inputEnd) {
/*  526 */         _loadMoreGuaranteed();
/*      */       }
/*  528 */       char ch = this._inputBuffer[(this._inputPtr++)];
/*  529 */       if (ch > ' ') {
/*  530 */         int bits = b64variant.decodeBase64Char(ch);
/*  531 */         if (bits < 0) {
/*  532 */           if (ch == '"') {
/*      */             break;
/*      */           }
/*  535 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  536 */           if (bits < 0) {}
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*  542 */           if (outputPtr > outputEnd) {
/*  543 */             outputCount += outputPtr;
/*  544 */             out.write(buffer, 0, outputPtr);
/*  545 */             outputPtr = 0;
/*      */           }
/*      */           
/*  548 */           int decodedData = bits;
/*      */           
/*      */ 
/*      */ 
/*  552 */           if (this._inputPtr >= this._inputEnd) {
/*  553 */             _loadMoreGuaranteed();
/*      */           }
/*  555 */           ch = this._inputBuffer[(this._inputPtr++)];
/*  556 */           bits = b64variant.decodeBase64Char(ch);
/*  557 */           if (bits < 0) {
/*  558 */             bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */           }
/*  560 */           decodedData = decodedData << 6 | bits;
/*      */           
/*      */ 
/*  563 */           if (this._inputPtr >= this._inputEnd) {
/*  564 */             _loadMoreGuaranteed();
/*      */           }
/*  566 */           ch = this._inputBuffer[(this._inputPtr++)];
/*  567 */           bits = b64variant.decodeBase64Char(ch);
/*      */           
/*      */ 
/*  570 */           if (bits < 0) {
/*  571 */             if (bits != -2)
/*      */             {
/*  573 */               if (ch == '"') {
/*  574 */                 decodedData >>= 4;
/*  575 */                 buffer[(outputPtr++)] = ((byte)decodedData);
/*  576 */                 if (!b64variant.usesPadding()) break;
/*  577 */                 this._inputPtr -= 1;
/*  578 */                 _handleBase64MissingPadding(b64variant); break;
/*      */               }
/*      */               
/*      */ 
/*  582 */               bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */             }
/*  584 */             if (bits == -2)
/*      */             {
/*  586 */               if (this._inputPtr >= this._inputEnd) {
/*  587 */                 _loadMoreGuaranteed();
/*      */               }
/*  589 */               ch = this._inputBuffer[(this._inputPtr++)];
/*  590 */               if ((!b64variant.usesPaddingChar(ch)) && 
/*  591 */                 (_decodeBase64Escape(b64variant, ch, 3) != -2)) {
/*  592 */                 throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */               }
/*      */               
/*      */ 
/*  596 */               decodedData >>= 4;
/*  597 */               buffer[(outputPtr++)] = ((byte)decodedData);
/*  598 */               continue;
/*      */             }
/*      */           }
/*      */           
/*  602 */           decodedData = decodedData << 6 | bits;
/*      */           
/*  604 */           if (this._inputPtr >= this._inputEnd) {
/*  605 */             _loadMoreGuaranteed();
/*      */           }
/*  607 */           ch = this._inputBuffer[(this._inputPtr++)];
/*  608 */           bits = b64variant.decodeBase64Char(ch);
/*  609 */           if (bits < 0) {
/*  610 */             if (bits != -2)
/*      */             {
/*  612 */               if (ch == '"') {
/*  613 */                 decodedData >>= 2;
/*  614 */                 buffer[(outputPtr++)] = ((byte)(decodedData >> 8));
/*  615 */                 buffer[(outputPtr++)] = ((byte)decodedData);
/*  616 */                 if (!b64variant.usesPadding()) break;
/*  617 */                 this._inputPtr -= 1;
/*  618 */                 _handleBase64MissingPadding(b64variant); break;
/*      */               }
/*      */               
/*      */ 
/*  622 */               bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */             }
/*  624 */             if (bits == -2)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  631 */               decodedData >>= 2;
/*  632 */               buffer[(outputPtr++)] = ((byte)(decodedData >> 8));
/*  633 */               buffer[(outputPtr++)] = ((byte)decodedData);
/*  634 */               continue;
/*      */             }
/*      */           }
/*      */           
/*  638 */           decodedData = decodedData << 6 | bits;
/*  639 */           buffer[(outputPtr++)] = ((byte)(decodedData >> 16));
/*  640 */           buffer[(outputPtr++)] = ((byte)(decodedData >> 8));
/*  641 */           buffer[(outputPtr++)] = ((byte)decodedData);
/*      */         } } }
/*  643 */     this._tokenIncomplete = false;
/*  644 */     if (outputPtr > 0) {
/*  645 */       outputCount += outputPtr;
/*  646 */       out.write(buffer, 0, outputPtr);
/*      */     }
/*  648 */     return outputCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final JsonToken nextToken()
/*      */     throws IOException
/*      */   {
/*  668 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  669 */       return _nextAfterName();
/*      */     }
/*      */     
/*      */ 
/*  673 */     this._numTypesValid = 0;
/*  674 */     if (this._tokenIncomplete) {
/*  675 */       _skipString();
/*      */     }
/*  677 */     int i = _skipWSOrEnd();
/*  678 */     if (i < 0)
/*      */     {
/*      */ 
/*  681 */       close();
/*  682 */       return this._currToken = null;
/*      */     }
/*      */     
/*  685 */     this._binaryValue = null;
/*      */     
/*      */ 
/*  688 */     if ((i == 93) || (i == 125)) {
/*  689 */       _closeScope(i);
/*  690 */       return this._currToken;
/*      */     }
/*      */     
/*      */ 
/*  694 */     if (this._parsingContext.expectComma()) {
/*  695 */       i = _skipComma(i);
/*      */       
/*      */ 
/*  698 */       if (((this._features & FEAT_MASK_TRAILING_COMMA) != 0) && (
/*  699 */         (i == 93) || (i == 125))) {
/*  700 */         _closeScope(i);
/*  701 */         return this._currToken;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  709 */     boolean inObject = this._parsingContext.inObject();
/*  710 */     if (inObject)
/*      */     {
/*  712 */       _updateNameLocation();
/*  713 */       String name = i == 34 ? _parseName() : _handleOddName(i);
/*  714 */       this._parsingContext.setCurrentName(name);
/*  715 */       this._currToken = JsonToken.FIELD_NAME;
/*  716 */       i = _skipColon();
/*      */     }
/*  718 */     _updateLocation();
/*      */     JsonToken t;
/*      */     JsonToken t;
/*      */     JsonToken t;
/*      */     JsonToken t;
/*      */     JsonToken t;
/*  724 */     JsonToken t; JsonToken t; JsonToken t; JsonToken t; JsonToken t; switch (i) {
/*      */     case 34: 
/*  726 */       this._tokenIncomplete = true;
/*  727 */       t = JsonToken.VALUE_STRING;
/*  728 */       break;
/*      */     case 91: 
/*  730 */       if (!inObject) {
/*  731 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/*  733 */       t = JsonToken.START_ARRAY;
/*  734 */       break;
/*      */     case 123: 
/*  736 */       if (!inObject) {
/*  737 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/*  739 */       t = JsonToken.START_OBJECT;
/*  740 */       break;
/*      */     
/*      */ 
/*      */     case 125: 
/*  744 */       _reportUnexpectedChar(i, "expected a value");
/*      */     case 116: 
/*  746 */       _matchTrue();
/*  747 */       t = JsonToken.VALUE_TRUE;
/*  748 */       break;
/*      */     case 102: 
/*  750 */       _matchFalse();
/*  751 */       t = JsonToken.VALUE_FALSE;
/*  752 */       break;
/*      */     case 110: 
/*  754 */       _matchNull();
/*  755 */       t = JsonToken.VALUE_NULL;
/*  756 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 45: 
/*  763 */       t = _parseNegNumber();
/*  764 */       break;
/*      */     case 46: 
/*  766 */       t = _parseFloatThatStartsWithPeriod();
/*  767 */       break;
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*  778 */       t = _parsePosNumber(i);
/*  779 */       break;
/*      */     default: 
/*  781 */       t = _handleOddValue(i);
/*      */     }
/*      */     
/*      */     
/*  785 */     if (inObject) {
/*  786 */       this._nextToken = t;
/*  787 */       return this._currToken;
/*      */     }
/*  789 */     this._currToken = t;
/*  790 */     return t;
/*      */   }
/*      */   
/*      */   private final JsonToken _nextAfterName()
/*      */   {
/*  795 */     this._nameCopied = false;
/*  796 */     JsonToken t = this._nextToken;
/*  797 */     this._nextToken = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  802 */     if (t == JsonToken.START_ARRAY) {
/*  803 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  804 */     } else if (t == JsonToken.START_OBJECT) {
/*  805 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     }
/*  807 */     return this._currToken = t;
/*      */   }
/*      */   
/*      */   public void finishToken() throws IOException
/*      */   {
/*  812 */     if (this._tokenIncomplete) {
/*  813 */       this._tokenIncomplete = false;
/*  814 */       _finishString();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean nextFieldName(SerializableString sstr)
/*      */     throws IOException
/*      */   {
/*  830 */     this._numTypesValid = 0;
/*  831 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  832 */       _nextAfterName();
/*  833 */       return false;
/*      */     }
/*  835 */     if (this._tokenIncomplete) {
/*  836 */       _skipString();
/*      */     }
/*  838 */     int i = _skipWSOrEnd();
/*  839 */     if (i < 0) {
/*  840 */       close();
/*  841 */       this._currToken = null;
/*  842 */       return false;
/*      */     }
/*  844 */     this._binaryValue = null;
/*      */     
/*      */ 
/*  847 */     if ((i == 93) || (i == 125)) {
/*  848 */       _closeScope(i);
/*  849 */       return false;
/*      */     }
/*      */     
/*  852 */     if (this._parsingContext.expectComma()) {
/*  853 */       i = _skipComma(i);
/*      */       
/*      */ 
/*  856 */       if (((this._features & FEAT_MASK_TRAILING_COMMA) != 0) && (
/*  857 */         (i == 93) || (i == 125))) {
/*  858 */         _closeScope(i);
/*  859 */         return false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  864 */     if (!this._parsingContext.inObject()) {
/*  865 */       _updateLocation();
/*  866 */       _nextTokenNotInObject(i);
/*  867 */       return false;
/*      */     }
/*      */     
/*  870 */     _updateNameLocation();
/*  871 */     if (i == 34)
/*      */     {
/*  873 */       char[] nameChars = sstr.asQuotedChars();
/*  874 */       int len = nameChars.length;
/*      */       
/*      */ 
/*  877 */       if (this._inputPtr + len + 4 < this._inputEnd)
/*      */       {
/*  879 */         int end = this._inputPtr + len;
/*  880 */         if (this._inputBuffer[end] == '"') {
/*  881 */           int offset = 0;
/*  882 */           int ptr = this._inputPtr;
/*      */           for (;;) {
/*  884 */             if (ptr == end) {
/*  885 */               this._parsingContext.setCurrentName(sstr.getValue());
/*  886 */               _isNextTokenNameYes(_skipColonFast(ptr + 1));
/*  887 */               return true;
/*      */             }
/*  889 */             if (nameChars[offset] != this._inputBuffer[ptr]) {
/*      */               break;
/*      */             }
/*  892 */             offset++;
/*  893 */             ptr++;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  898 */     return _isNextTokenNameMaybe(i, sstr.getValue());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String nextFieldName()
/*      */     throws IOException
/*      */   {
/*  906 */     this._numTypesValid = 0;
/*  907 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  908 */       _nextAfterName();
/*  909 */       return null;
/*      */     }
/*  911 */     if (this._tokenIncomplete) {
/*  912 */       _skipString();
/*      */     }
/*  914 */     int i = _skipWSOrEnd();
/*  915 */     if (i < 0) {
/*  916 */       close();
/*  917 */       this._currToken = null;
/*  918 */       return null;
/*      */     }
/*  920 */     this._binaryValue = null;
/*  921 */     if ((i == 93) || (i == 125)) {
/*  922 */       _closeScope(i);
/*  923 */       return null;
/*      */     }
/*  925 */     if (this._parsingContext.expectComma()) {
/*  926 */       i = _skipComma(i);
/*  927 */       if (((this._features & FEAT_MASK_TRAILING_COMMA) != 0) && (
/*  928 */         (i == 93) || (i == 125))) {
/*  929 */         _closeScope(i);
/*  930 */         return null;
/*      */       }
/*      */     }
/*      */     
/*  934 */     if (!this._parsingContext.inObject()) {
/*  935 */       _updateLocation();
/*  936 */       _nextTokenNotInObject(i);
/*  937 */       return null;
/*      */     }
/*      */     
/*  940 */     _updateNameLocation();
/*  941 */     String name = i == 34 ? _parseName() : _handleOddName(i);
/*  942 */     this._parsingContext.setCurrentName(name);
/*  943 */     this._currToken = JsonToken.FIELD_NAME;
/*  944 */     i = _skipColon();
/*      */     
/*  946 */     _updateLocation();
/*  947 */     if (i == 34) {
/*  948 */       this._tokenIncomplete = true;
/*  949 */       this._nextToken = JsonToken.VALUE_STRING;
/*  950 */       return name; }
/*      */     JsonToken t;
/*      */     JsonToken t;
/*      */     JsonToken t;
/*      */     JsonToken t;
/*      */     JsonToken t;
/*      */     JsonToken t;
/*  957 */     JsonToken t; JsonToken t; JsonToken t; switch (i) {
/*      */     case 45: 
/*  959 */       t = _parseNegNumber();
/*  960 */       break;
/*      */     case 46: 
/*  962 */       t = _parseFloatThatStartsWithPeriod();
/*  963 */       break;
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*  974 */       t = _parsePosNumber(i);
/*  975 */       break;
/*      */     case 102: 
/*  977 */       _matchFalse();
/*  978 */       t = JsonToken.VALUE_FALSE;
/*  979 */       break;
/*      */     case 110: 
/*  981 */       _matchNull();
/*  982 */       t = JsonToken.VALUE_NULL;
/*  983 */       break;
/*      */     case 116: 
/*  985 */       _matchTrue();
/*  986 */       t = JsonToken.VALUE_TRUE;
/*  987 */       break;
/*      */     case 91: 
/*  989 */       t = JsonToken.START_ARRAY;
/*  990 */       break;
/*      */     case 123: 
/*  992 */       t = JsonToken.START_OBJECT;
/*  993 */       break;
/*      */     default: 
/*  995 */       t = _handleOddValue(i);
/*      */     }
/*      */     
/*  998 */     this._nextToken = t;
/*  999 */     return name;
/*      */   }
/*      */   
/*      */   private final void _isNextTokenNameYes(int i) throws IOException
/*      */   {
/* 1004 */     this._currToken = JsonToken.FIELD_NAME;
/* 1005 */     _updateLocation();
/*      */     
/* 1007 */     switch (i) {
/*      */     case 34: 
/* 1009 */       this._tokenIncomplete = true;
/* 1010 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1011 */       return;
/*      */     case 91: 
/* 1013 */       this._nextToken = JsonToken.START_ARRAY;
/* 1014 */       return;
/*      */     case 123: 
/* 1016 */       this._nextToken = JsonToken.START_OBJECT;
/* 1017 */       return;
/*      */     case 116: 
/* 1019 */       _matchToken("true", 1);
/* 1020 */       this._nextToken = JsonToken.VALUE_TRUE;
/* 1021 */       return;
/*      */     case 102: 
/* 1023 */       _matchToken("false", 1);
/* 1024 */       this._nextToken = JsonToken.VALUE_FALSE;
/* 1025 */       return;
/*      */     case 110: 
/* 1027 */       _matchToken("null", 1);
/* 1028 */       this._nextToken = JsonToken.VALUE_NULL;
/* 1029 */       return;
/*      */     case 45: 
/* 1031 */       this._nextToken = _parseNegNumber();
/* 1032 */       return;
/*      */     case 46: 
/* 1034 */       this._nextToken = _parseFloatThatStartsWithPeriod();
/* 1035 */       return;
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/* 1046 */       this._nextToken = _parsePosNumber(i);
/* 1047 */       return;
/*      */     }
/* 1049 */     this._nextToken = _handleOddValue(i);
/*      */   }
/*      */   
/*      */   protected boolean _isNextTokenNameMaybe(int i, String nameToMatch)
/*      */     throws IOException
/*      */   {
/* 1055 */     String name = i == 34 ? _parseName() : _handleOddName(i);
/* 1056 */     this._parsingContext.setCurrentName(name);
/* 1057 */     this._currToken = JsonToken.FIELD_NAME;
/* 1058 */     i = _skipColon();
/* 1059 */     _updateLocation();
/* 1060 */     if (i == 34) {
/* 1061 */       this._tokenIncomplete = true;
/* 1062 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1063 */       return nameToMatch.equals(name); }
/*      */     JsonToken t;
/*      */     JsonToken t;
/*      */     JsonToken t;
/* 1067 */     JsonToken t; JsonToken t; JsonToken t; JsonToken t; JsonToken t; JsonToken t; switch (i) {
/*      */     case 45: 
/* 1069 */       t = _parseNegNumber();
/* 1070 */       break;
/*      */     case 46: 
/* 1072 */       t = _parseFloatThatStartsWithPeriod();
/* 1073 */       break;
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/* 1084 */       t = _parsePosNumber(i);
/* 1085 */       break;
/*      */     case 102: 
/* 1087 */       _matchFalse();
/* 1088 */       t = JsonToken.VALUE_FALSE;
/* 1089 */       break;
/*      */     case 110: 
/* 1091 */       _matchNull();
/* 1092 */       t = JsonToken.VALUE_NULL;
/* 1093 */       break;
/*      */     case 116: 
/* 1095 */       _matchTrue();
/* 1096 */       t = JsonToken.VALUE_TRUE;
/* 1097 */       break;
/*      */     case 91: 
/* 1099 */       t = JsonToken.START_ARRAY;
/* 1100 */       break;
/*      */     case 123: 
/* 1102 */       t = JsonToken.START_OBJECT;
/* 1103 */       break;
/*      */     default: 
/* 1105 */       t = _handleOddValue(i);
/*      */     }
/*      */     
/* 1108 */     this._nextToken = t;
/* 1109 */     return nameToMatch.equals(name);
/*      */   }
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException
/*      */   {
/* 1114 */     if (i == 34) {
/* 1115 */       this._tokenIncomplete = true;
/* 1116 */       return this._currToken = JsonToken.VALUE_STRING;
/*      */     }
/* 1118 */     switch (i) {
/*      */     case 91: 
/* 1120 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1121 */       return this._currToken = JsonToken.START_ARRAY;
/*      */     case 123: 
/* 1123 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/* 1124 */       return this._currToken = JsonToken.START_OBJECT;
/*      */     case 116: 
/* 1126 */       _matchToken("true", 1);
/* 1127 */       return this._currToken = JsonToken.VALUE_TRUE;
/*      */     case 102: 
/* 1129 */       _matchToken("false", 1);
/* 1130 */       return this._currToken = JsonToken.VALUE_FALSE;
/*      */     case 110: 
/* 1132 */       _matchToken("null", 1);
/* 1133 */       return this._currToken = JsonToken.VALUE_NULL;
/*      */     case 45: 
/* 1135 */       return this._currToken = _parseNegNumber();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 46: 
/* 1141 */       return this._currToken = _parseFloatThatStartsWithPeriod();
/*      */     case 48: 
/*      */     case 49: 
/*      */     case 50: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/* 1152 */       return this._currToken = _parsePosNumber(i);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 44: 
/* 1164 */       if ((!this._parsingContext.inRoot()) && 
/* 1165 */         ((this._features & FEAT_MASK_ALLOW_MISSING) != 0)) {
/* 1166 */         this._inputPtr -= 1;
/* 1167 */         return this._currToken = JsonToken.VALUE_NULL;
/*      */       }
/*      */       break;
/*      */     }
/* 1171 */     return this._currToken = _handleOddValue(i);
/*      */   }
/*      */   
/*      */   public final String nextTextValue()
/*      */     throws IOException
/*      */   {
/* 1177 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1178 */       this._nameCopied = false;
/* 1179 */       JsonToken t = this._nextToken;
/* 1180 */       this._nextToken = null;
/* 1181 */       this._currToken = t;
/* 1182 */       if (t == JsonToken.VALUE_STRING) {
/* 1183 */         if (this._tokenIncomplete) {
/* 1184 */           this._tokenIncomplete = false;
/* 1185 */           _finishString();
/*      */         }
/* 1187 */         return this._textBuffer.contentsAsString();
/*      */       }
/* 1189 */       if (t == JsonToken.START_ARRAY) {
/* 1190 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1191 */       } else if (t == JsonToken.START_OBJECT) {
/* 1192 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/* 1194 */       return null;
/*      */     }
/*      */     
/* 1197 */     return nextToken() == JsonToken.VALUE_STRING ? getText() : null;
/*      */   }
/*      */   
/*      */ 
/*      */   public final int nextIntValue(int defaultValue)
/*      */     throws IOException
/*      */   {
/* 1204 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1205 */       this._nameCopied = false;
/* 1206 */       JsonToken t = this._nextToken;
/* 1207 */       this._nextToken = null;
/* 1208 */       this._currToken = t;
/* 1209 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1210 */         return getIntValue();
/*      */       }
/* 1212 */       if (t == JsonToken.START_ARRAY) {
/* 1213 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1214 */       } else if (t == JsonToken.START_OBJECT) {
/* 1215 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/* 1217 */       return defaultValue;
/*      */     }
/*      */     
/* 1220 */     return nextToken() == JsonToken.VALUE_NUMBER_INT ? getIntValue() : defaultValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public final long nextLongValue(long defaultValue)
/*      */     throws IOException
/*      */   {
/* 1227 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1228 */       this._nameCopied = false;
/* 1229 */       JsonToken t = this._nextToken;
/* 1230 */       this._nextToken = null;
/* 1231 */       this._currToken = t;
/* 1232 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1233 */         return getLongValue();
/*      */       }
/* 1235 */       if (t == JsonToken.START_ARRAY) {
/* 1236 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1237 */       } else if (t == JsonToken.START_OBJECT) {
/* 1238 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/* 1240 */       return defaultValue;
/*      */     }
/*      */     
/* 1243 */     return nextToken() == JsonToken.VALUE_NUMBER_INT ? getLongValue() : defaultValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public final Boolean nextBooleanValue()
/*      */     throws IOException
/*      */   {
/* 1250 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1251 */       this._nameCopied = false;
/* 1252 */       JsonToken t = this._nextToken;
/* 1253 */       this._nextToken = null;
/* 1254 */       this._currToken = t;
/* 1255 */       if (t == JsonToken.VALUE_TRUE) {
/* 1256 */         return Boolean.TRUE;
/*      */       }
/* 1258 */       if (t == JsonToken.VALUE_FALSE) {
/* 1259 */         return Boolean.FALSE;
/*      */       }
/* 1261 */       if (t == JsonToken.START_ARRAY) {
/* 1262 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1263 */       } else if (t == JsonToken.START_OBJECT) {
/* 1264 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       }
/* 1266 */       return null;
/*      */     }
/* 1268 */     JsonToken t = nextToken();
/* 1269 */     if (t != null) {
/* 1270 */       int id = t.id();
/* 1271 */       if (id == 9) return Boolean.TRUE;
/* 1272 */       if (id == 10) return Boolean.FALSE;
/*      */     }
/* 1274 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod()
/*      */     throws IOException
/*      */   {
/* 1287 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1288 */       return _handleOddValue(46);
/*      */     }
/* 1290 */     return _parseFloat(46, this._inputPtr - 1, this._inputPtr, false, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final JsonToken _parsePosNumber(int ch)
/*      */     throws IOException
/*      */   {
/* 1315 */     int ptr = this._inputPtr;
/* 1316 */     int startPtr = ptr - 1;
/* 1317 */     int inputLen = this._inputEnd;
/*      */     
/*      */ 
/* 1320 */     if (ch == 48) {
/* 1321 */       return _parseNumber2(false, startPtr);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1330 */     int intLen = 1;
/*      */     
/*      */ 
/*      */     for (;;)
/*      */     {
/* 1335 */       if (ptr >= inputLen) {
/* 1336 */         this._inputPtr = startPtr;
/* 1337 */         return _parseNumber2(false, startPtr);
/*      */       }
/* 1339 */       ch = this._inputBuffer[(ptr++)];
/* 1340 */       if ((ch < 48) || (ch > 57)) {
/*      */         break;
/*      */       }
/* 1343 */       intLen++;
/*      */     }
/* 1345 */     if ((ch == 46) || (ch == 101) || (ch == 69)) {
/* 1346 */       this._inputPtr = ptr;
/* 1347 */       return _parseFloat(ch, startPtr, ptr, false, intLen);
/*      */     }
/*      */     
/* 1350 */     ptr--;
/* 1351 */     this._inputPtr = ptr;
/*      */     
/* 1353 */     if (this._parsingContext.inRoot()) {
/* 1354 */       _verifyRootSpace(ch);
/*      */     }
/* 1356 */     int len = ptr - startPtr;
/* 1357 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/* 1358 */     return resetInt(false, intLen);
/*      */   }
/*      */   
/*      */   private final JsonToken _parseFloat(int ch, int startPtr, int ptr, boolean neg, int intLen)
/*      */     throws IOException
/*      */   {
/* 1364 */     int inputLen = this._inputEnd;
/* 1365 */     int fractLen = 0;
/*      */     
/*      */ 
/* 1368 */     if (ch == 46)
/*      */     {
/*      */       for (;;) {
/* 1371 */         if (ptr >= inputLen) {
/* 1372 */           return _parseNumber2(neg, startPtr);
/*      */         }
/* 1374 */         ch = this._inputBuffer[(ptr++)];
/* 1375 */         if ((ch < 48) || (ch > 57)) {
/*      */           break;
/*      */         }
/* 1378 */         fractLen++;
/*      */       }
/*      */       
/* 1381 */       if (fractLen == 0) {
/* 1382 */         reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit");
/*      */       }
/*      */     }
/* 1385 */     int expLen = 0;
/* 1386 */     if ((ch == 101) || (ch == 69)) {
/* 1387 */       if (ptr >= inputLen) {
/* 1388 */         this._inputPtr = startPtr;
/* 1389 */         return _parseNumber2(neg, startPtr);
/*      */       }
/*      */       
/* 1392 */       ch = this._inputBuffer[(ptr++)];
/* 1393 */       if ((ch == 45) || (ch == 43)) {
/* 1394 */         if (ptr >= inputLen) {
/* 1395 */           this._inputPtr = startPtr;
/* 1396 */           return _parseNumber2(neg, startPtr);
/*      */         }
/* 1398 */         ch = this._inputBuffer[(ptr++)];
/*      */       }
/* 1400 */       while ((ch <= 57) && (ch >= 48)) {
/* 1401 */         expLen++;
/* 1402 */         if (ptr >= inputLen) {
/* 1403 */           this._inputPtr = startPtr;
/* 1404 */           return _parseNumber2(neg, startPtr);
/*      */         }
/* 1406 */         ch = this._inputBuffer[(ptr++)];
/*      */       }
/*      */       
/* 1409 */       if (expLen == 0) {
/* 1410 */         reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     }
/* 1413 */     ptr--;
/* 1414 */     this._inputPtr = ptr;
/*      */     
/* 1416 */     if (this._parsingContext.inRoot()) {
/* 1417 */       _verifyRootSpace(ch);
/*      */     }
/* 1419 */     int len = ptr - startPtr;
/* 1420 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/*      */     
/* 1422 */     return resetFloat(neg, intLen, fractLen, expLen);
/*      */   }
/*      */   
/*      */   protected final JsonToken _parseNegNumber() throws IOException
/*      */   {
/* 1427 */     int ptr = this._inputPtr;
/* 1428 */     int startPtr = ptr - 1;
/* 1429 */     int inputLen = this._inputEnd;
/*      */     
/* 1431 */     if (ptr >= inputLen) {
/* 1432 */       return _parseNumber2(true, startPtr);
/*      */     }
/* 1434 */     int ch = this._inputBuffer[(ptr++)];
/*      */     
/* 1436 */     if ((ch > 57) || (ch < 48)) {
/* 1437 */       this._inputPtr = ptr;
/* 1438 */       return _handleInvalidNumberStart(ch, true);
/*      */     }
/*      */     
/* 1441 */     if (ch == 48) {
/* 1442 */       return _parseNumber2(true, startPtr);
/*      */     }
/* 1444 */     int intLen = 1;
/*      */     
/*      */ 
/*      */     for (;;)
/*      */     {
/* 1449 */       if (ptr >= inputLen) {
/* 1450 */         return _parseNumber2(true, startPtr);
/*      */       }
/* 1452 */       ch = this._inputBuffer[(ptr++)];
/* 1453 */       if ((ch < 48) || (ch > 57)) {
/*      */         break;
/*      */       }
/* 1456 */       intLen++;
/*      */     }
/*      */     
/* 1459 */     if ((ch == 46) || (ch == 101) || (ch == 69)) {
/* 1460 */       this._inputPtr = ptr;
/* 1461 */       return _parseFloat(ch, startPtr, ptr, true, intLen);
/*      */     }
/* 1463 */     ptr--;
/* 1464 */     this._inputPtr = ptr;
/* 1465 */     if (this._parsingContext.inRoot()) {
/* 1466 */       _verifyRootSpace(ch);
/*      */     }
/* 1468 */     int len = ptr - startPtr;
/* 1469 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/* 1470 */     return resetInt(true, intLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final JsonToken _parseNumber2(boolean neg, int startPtr)
/*      */     throws IOException
/*      */   {
/* 1482 */     this._inputPtr = (neg ? startPtr + 1 : startPtr);
/* 1483 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1484 */     int outPtr = 0;
/*      */     
/*      */ 
/* 1487 */     if (neg) {
/* 1488 */       outBuf[(outPtr++)] = '-';
/*      */     }
/*      */     
/*      */ 
/* 1492 */     int intLen = 0;
/*      */     
/* 1494 */     char c = this._inputPtr < this._inputEnd ? this._inputBuffer[(this._inputPtr++)] : getNextChar("No digit following minus sign", JsonToken.VALUE_NUMBER_INT);
/* 1495 */     if (c == '0') {
/* 1496 */       c = _verifyNoLeadingZeroes();
/*      */     }
/* 1498 */     boolean eof = false;
/*      */     
/*      */ 
/*      */ 
/* 1502 */     while ((c >= '0') && (c <= '9')) {
/* 1503 */       intLen++;
/* 1504 */       if (outPtr >= outBuf.length) {
/* 1505 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1506 */         outPtr = 0;
/*      */       }
/* 1508 */       outBuf[(outPtr++)] = c;
/* 1509 */       if ((this._inputPtr >= this._inputEnd) && (!_loadMore()))
/*      */       {
/* 1511 */         c = '\000';
/* 1512 */         eof = true;
/* 1513 */         break;
/*      */       }
/* 1515 */       c = this._inputBuffer[(this._inputPtr++)];
/*      */     }
/*      */     
/* 1518 */     if (intLen == 0) {
/* 1519 */       return _handleInvalidNumberStart(c, neg);
/*      */     }
/*      */     
/* 1522 */     int fractLen = 0;
/*      */     
/* 1524 */     if (c == '.') {
/* 1525 */       if (outPtr >= outBuf.length) {
/* 1526 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1527 */         outPtr = 0;
/*      */       }
/* 1529 */       outBuf[(outPtr++)] = c;
/*      */       
/*      */       for (;;)
/*      */       {
/* 1533 */         if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/* 1534 */           eof = true;
/* 1535 */           break;
/*      */         }
/* 1537 */         c = this._inputBuffer[(this._inputPtr++)];
/* 1538 */         if ((c < '0') || (c > '9')) {
/*      */           break;
/*      */         }
/* 1541 */         fractLen++;
/* 1542 */         if (outPtr >= outBuf.length) {
/* 1543 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1544 */           outPtr = 0;
/*      */         }
/* 1546 */         outBuf[(outPtr++)] = c;
/*      */       }
/*      */       
/* 1549 */       if (fractLen == 0) {
/* 1550 */         reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     }
/*      */     
/* 1554 */     int expLen = 0;
/* 1555 */     if ((c == 'e') || (c == 'E')) {
/* 1556 */       if (outPtr >= outBuf.length) {
/* 1557 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1558 */         outPtr = 0;
/*      */       }
/* 1560 */       outBuf[(outPtr++)] = c;
/*      */       
/*      */ 
/* 1563 */       c = this._inputPtr < this._inputEnd ? this._inputBuffer[(this._inputPtr++)] : getNextChar("expected a digit for number exponent");
/*      */       
/* 1565 */       if ((c == '-') || (c == '+')) {
/* 1566 */         if (outPtr >= outBuf.length) {
/* 1567 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1568 */           outPtr = 0;
/*      */         }
/* 1570 */         outBuf[(outPtr++)] = c;
/*      */         
/*      */ 
/* 1573 */         c = this._inputPtr < this._inputEnd ? this._inputBuffer[(this._inputPtr++)] : getNextChar("expected a digit for number exponent");
/*      */       }
/*      */       
/*      */ 
/* 1577 */       while ((c <= '9') && (c >= '0')) {
/* 1578 */         expLen++;
/* 1579 */         if (outPtr >= outBuf.length) {
/* 1580 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1581 */           outPtr = 0;
/*      */         }
/* 1583 */         outBuf[(outPtr++)] = c;
/* 1584 */         if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/* 1585 */           eof = true;
/* 1586 */           break;
/*      */         }
/* 1588 */         c = this._inputBuffer[(this._inputPtr++)];
/*      */       }
/*      */       
/* 1591 */       if (expLen == 0) {
/* 1592 */         reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1597 */     if (!eof) {
/* 1598 */       this._inputPtr -= 1;
/* 1599 */       if (this._parsingContext.inRoot()) {
/* 1600 */         _verifyRootSpace(c);
/*      */       }
/*      */     }
/* 1603 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1605 */     return reset(neg, intLen, fractLen, expLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final char _verifyNoLeadingZeroes()
/*      */     throws IOException
/*      */   {
/* 1615 */     if (this._inputPtr < this._inputEnd) {
/* 1616 */       char ch = this._inputBuffer[this._inputPtr];
/*      */       
/* 1618 */       if ((ch < '0') || (ch > '9')) {
/* 1619 */         return '0';
/*      */       }
/*      */     }
/*      */     
/* 1623 */     return _verifyNLZ2();
/*      */   }
/*      */   
/*      */   private char _verifyNLZ2() throws IOException
/*      */   {
/* 1628 */     if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/* 1629 */       return '0';
/*      */     }
/* 1631 */     char ch = this._inputBuffer[this._inputPtr];
/* 1632 */     if ((ch < '0') || (ch > '9')) {
/* 1633 */       return '0';
/*      */     }
/* 1635 */     if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1636 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1639 */     this._inputPtr += 1;
/* 1640 */     if (ch == '0') {
/* 1641 */       while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 1642 */         ch = this._inputBuffer[this._inputPtr];
/* 1643 */         if ((ch < '0') || (ch > '9')) {
/* 1644 */           return '0';
/*      */         }
/* 1646 */         this._inputPtr += 1;
/* 1647 */         if (ch != '0') {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1652 */     return ch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean negative)
/*      */     throws IOException
/*      */   {
/* 1661 */     if (ch == 73) {
/* 1662 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1663 */         (!_loadMore())) {
/* 1664 */         _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */       }
/*      */       
/* 1667 */       ch = this._inputBuffer[(this._inputPtr++)];
/* 1668 */       if (ch == 78) {
/* 1669 */         String match = negative ? "-INF" : "+INF";
/* 1670 */         _matchToken(match, 3);
/* 1671 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 1672 */           return resetAsNaN(match, negative ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */         }
/* 1674 */         _reportError("Non-standard token '" + match + "': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/* 1675 */       } else if (ch == 110) {
/* 1676 */         String match = negative ? "-Infinity" : "+Infinity";
/* 1677 */         _matchToken(match, 3);
/* 1678 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 1679 */           return resetAsNaN(match, negative ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */         }
/* 1681 */         _reportError("Non-standard token '" + match + "': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */       }
/*      */     }
/* 1684 */     reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 1685 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _verifyRootSpace(int ch)
/*      */     throws IOException
/*      */   {
/* 1698 */     this._inputPtr += 1;
/* 1699 */     switch (ch) {
/*      */     case 9: 
/*      */     case 32: 
/* 1702 */       return;
/*      */     case 13: 
/* 1704 */       _skipCR();
/* 1705 */       return;
/*      */     case 10: 
/* 1707 */       this._currInputRow += 1;
/* 1708 */       this._currInputRowStart = this._inputPtr;
/* 1709 */       return;
/*      */     }
/* 1711 */     _reportMissingRootWS(ch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final String _parseName()
/*      */     throws IOException
/*      */   {
/* 1724 */     int ptr = this._inputPtr;
/* 1725 */     int hash = this._hashSeed;
/* 1726 */     int[] codes = _icLatin1;
/*      */     
/* 1728 */     while (ptr < this._inputEnd) {
/* 1729 */       int ch = this._inputBuffer[ptr];
/* 1730 */       if ((ch < codes.length) && (codes[ch] != 0)) {
/* 1731 */         if (ch != 34) break;
/* 1732 */         int start = this._inputPtr;
/* 1733 */         this._inputPtr = (ptr + 1);
/* 1734 */         return this._symbols.findSymbol(this._inputBuffer, start, ptr - start, hash);
/*      */       }
/*      */       
/*      */ 
/* 1738 */       hash = hash * 33 + ch;
/* 1739 */       ptr++;
/*      */     }
/* 1741 */     int start = this._inputPtr;
/* 1742 */     this._inputPtr = ptr;
/* 1743 */     return _parseName2(start, hash, 34);
/*      */   }
/*      */   
/*      */   private String _parseName2(int startPtr, int hash, int endChar) throws IOException
/*      */   {
/* 1748 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, this._inputPtr - startPtr);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1753 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 1754 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     for (;;)
/*      */     {
/* 1757 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1758 */         (!_loadMore())) {
/* 1759 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 1762 */       char c = this._inputBuffer[(this._inputPtr++)];
/* 1763 */       int i = c;
/* 1764 */       if (i <= 92) {
/* 1765 */         if (i == 92)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1770 */           c = _decodeEscaped();
/* 1771 */         } else if (i <= endChar) {
/* 1772 */           if (i == endChar) {
/*      */             break;
/*      */           }
/* 1775 */           if (i < 32) {
/* 1776 */             _throwUnquotedSpace(i, "name");
/*      */           }
/*      */         }
/*      */       }
/* 1780 */       hash = hash * 33 + c;
/*      */       
/* 1782 */       outBuf[(outPtr++)] = c;
/*      */       
/*      */ 
/* 1785 */       if (outPtr >= outBuf.length) {
/* 1786 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1787 */         outPtr = 0;
/*      */       }
/*      */     }
/* 1790 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1792 */     TextBuffer tb = this._textBuffer;
/* 1793 */     char[] buf = tb.getTextBuffer();
/* 1794 */     int start = tb.getTextOffset();
/* 1795 */     int len = tb.size();
/* 1796 */     return this._symbols.findSymbol(buf, start, len, hash);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String _handleOddName(int i)
/*      */     throws IOException
/*      */   {
/* 1809 */     if ((i == 39) && ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0)) {
/* 1810 */       return _parseAposName();
/*      */     }
/*      */     
/* 1813 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/* 1814 */       _reportUnexpectedChar(i, "was expecting double-quote to start field name");
/*      */     }
/* 1816 */     int[] codes = CharTypes.getInputCodeLatin1JsNames();
/* 1817 */     int maxCode = codes.length;
/*      */     
/*      */     boolean firstOk;
/*      */     
/*      */     boolean firstOk;
/* 1822 */     if (i < maxCode) {
/* 1823 */       firstOk = codes[i] == 0;
/*      */     } else {
/* 1825 */       firstOk = Character.isJavaIdentifierPart((char)i);
/*      */     }
/* 1827 */     if (!firstOk) {
/* 1828 */       _reportUnexpectedChar(i, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/* 1830 */     int ptr = this._inputPtr;
/* 1831 */     int hash = this._hashSeed;
/* 1832 */     int inputLen = this._inputEnd;
/*      */     
/* 1834 */     if (ptr < inputLen) {
/*      */       do {
/* 1836 */         int ch = this._inputBuffer[ptr];
/* 1837 */         if (ch < maxCode) {
/* 1838 */           if (codes[ch] != 0) {
/* 1839 */             int start = this._inputPtr - 1;
/* 1840 */             this._inputPtr = ptr;
/* 1841 */             return this._symbols.findSymbol(this._inputBuffer, start, ptr - start, hash);
/*      */           }
/* 1843 */         } else if (!Character.isJavaIdentifierPart((char)ch)) {
/* 1844 */           int start = this._inputPtr - 1;
/* 1845 */           this._inputPtr = ptr;
/* 1846 */           return this._symbols.findSymbol(this._inputBuffer, start, ptr - start, hash);
/*      */         }
/* 1848 */         hash = hash * 33 + ch;
/* 1849 */         ptr++;
/* 1850 */       } while (ptr < inputLen);
/*      */     }
/* 1852 */     int start = this._inputPtr - 1;
/* 1853 */     this._inputPtr = ptr;
/* 1854 */     return _handleOddName2(start, hash, codes);
/*      */   }
/*      */   
/*      */   protected String _parseAposName()
/*      */     throws IOException
/*      */   {
/* 1860 */     int ptr = this._inputPtr;
/* 1861 */     int hash = this._hashSeed;
/* 1862 */     int inputLen = this._inputEnd;
/*      */     
/* 1864 */     if (ptr < inputLen) {
/* 1865 */       int[] codes = _icLatin1;
/* 1866 */       int maxCode = codes.length;
/*      */       do
/*      */       {
/* 1869 */         int ch = this._inputBuffer[ptr];
/* 1870 */         if (ch == 39) {
/* 1871 */           int start = this._inputPtr;
/* 1872 */           this._inputPtr = (ptr + 1);
/* 1873 */           return this._symbols.findSymbol(this._inputBuffer, start, ptr - start, hash);
/*      */         }
/* 1875 */         if ((ch < maxCode) && (codes[ch] != 0)) {
/*      */           break;
/*      */         }
/* 1878 */         hash = hash * 33 + ch;
/* 1879 */         ptr++;
/* 1880 */       } while (ptr < inputLen);
/*      */     }
/*      */     
/* 1883 */     int start = this._inputPtr;
/* 1884 */     this._inputPtr = ptr;
/*      */     
/* 1886 */     return _parseName2(start, hash, 39);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonToken _handleOddValue(int i)
/*      */     throws IOException
/*      */   {
/* 1896 */     switch (i)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 39: 
/* 1903 */       if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 1904 */         return _handleApos();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 93: 
/* 1912 */       if (!this._parsingContext.inArray()) {
/*      */         break;
/*      */       }
/*      */     
/*      */ 
/*      */     case 44: 
/* 1918 */       if ((!this._parsingContext.inRoot()) && 
/* 1919 */         ((this._features & FEAT_MASK_ALLOW_MISSING) != 0)) {
/* 1920 */         this._inputPtr -= 1;
/* 1921 */         return JsonToken.VALUE_NULL;
/*      */       }
/*      */       
/*      */       break;
/*      */     case 78: 
/* 1926 */       _matchToken("NaN", 1);
/* 1927 */       if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 1928 */         return resetAsNaN("NaN", NaN.0D);
/*      */       }
/* 1930 */       _reportError("Non-standard token 'NaN': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/* 1931 */       break;
/*      */     case 73: 
/* 1933 */       _matchToken("Infinity", 1);
/* 1934 */       if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 1935 */         return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */       }
/* 1937 */       _reportError("Non-standard token 'Infinity': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/* 1938 */       break;
/*      */     case 43: 
/* 1940 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1941 */         (!_loadMore())) {
/* 1942 */         _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */       }
/*      */       
/* 1945 */       return _handleInvalidNumberStart(this._inputBuffer[(this._inputPtr++)], false);
/*      */     }
/*      */     
/* 1948 */     if (Character.isJavaIdentifierStart(i)) {
/* 1949 */       _reportInvalidToken("" + (char)i, _validJsonTokenList());
/*      */     }
/*      */     
/* 1952 */     _reportUnexpectedChar(i, "expected a valid value " + _validJsonValueList());
/* 1953 */     return null;
/*      */   }
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException
/*      */   {
/* 1958 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1959 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     for (;;)
/*      */     {
/* 1962 */       if ((this._inputPtr >= this._inputEnd) && 
/* 1963 */         (!_loadMore())) {
/* 1964 */         _reportInvalidEOF(": was expecting closing quote for a string value", JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/*      */ 
/* 1968 */       char c = this._inputBuffer[(this._inputPtr++)];
/* 1969 */       int i = c;
/* 1970 */       if (i <= 92) {
/* 1971 */         if (i == 92)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1976 */           c = _decodeEscaped();
/* 1977 */         } else if (i <= 39) {
/* 1978 */           if (i == 39) {
/*      */             break;
/*      */           }
/* 1981 */           if (i < 32) {
/* 1982 */             _throwUnquotedSpace(i, "string value");
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1987 */       if (outPtr >= outBuf.length) {
/* 1988 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1989 */         outPtr = 0;
/*      */       }
/*      */       
/* 1992 */       outBuf[(outPtr++)] = c;
/*      */     }
/* 1994 */     this._textBuffer.setCurrentLength(outPtr);
/* 1995 */     return JsonToken.VALUE_STRING;
/*      */   }
/*      */   
/*      */   private String _handleOddName2(int startPtr, int hash, int[] codes) throws IOException
/*      */   {
/* 2000 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, this._inputPtr - startPtr);
/* 2001 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 2002 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2003 */     int maxCode = codes.length;
/*      */     
/*      */ 
/* 2006 */     while ((this._inputPtr < this._inputEnd) || 
/* 2007 */       (_loadMore()))
/*      */     {
/*      */ 
/*      */ 
/* 2011 */       char c = this._inputBuffer[this._inputPtr];
/* 2012 */       int i = c;
/* 2013 */       if (i < maxCode ? 
/* 2014 */         codes[i] != 0 : 
/*      */         
/*      */ 
/* 2017 */         !Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 2020 */       this._inputPtr += 1;
/* 2021 */       hash = hash * 33 + i;
/*      */       
/* 2023 */       outBuf[(outPtr++)] = c;
/*      */       
/*      */ 
/* 2026 */       if (outPtr >= outBuf.length) {
/* 2027 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2028 */         outPtr = 0;
/*      */       }
/*      */     }
/* 2031 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 2033 */     TextBuffer tb = this._textBuffer;
/* 2034 */     char[] buf = tb.getTextBuffer();
/* 2035 */     int start = tb.getTextOffset();
/* 2036 */     int len = tb.size();
/*      */     
/* 2038 */     return this._symbols.findSymbol(buf, start, len, hash);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _finishString()
/*      */     throws IOException
/*      */   {
/* 2049 */     int ptr = this._inputPtr;
/* 2050 */     int inputLen = this._inputEnd;
/*      */     
/* 2052 */     if (ptr < inputLen) {
/* 2053 */       int[] codes = _icLatin1;
/* 2054 */       int maxCode = codes.length;
/*      */       do
/*      */       {
/* 2057 */         int ch = this._inputBuffer[ptr];
/* 2058 */         if ((ch < maxCode) && (codes[ch] != 0)) {
/* 2059 */           if (ch != 34) break;
/* 2060 */           this._textBuffer.resetWithShared(this._inputBuffer, this._inputPtr, ptr - this._inputPtr);
/* 2061 */           this._inputPtr = (ptr + 1);
/*      */           
/* 2063 */           return;
/*      */         }
/*      */         
/*      */ 
/* 2067 */         ptr++;
/* 2068 */       } while (ptr < inputLen);
/*      */     }
/*      */     
/*      */ 
/* 2072 */     this._textBuffer.resetWithCopy(this._inputBuffer, this._inputPtr, ptr - this._inputPtr);
/* 2073 */     this._inputPtr = ptr;
/* 2074 */     _finishString2();
/*      */   }
/*      */   
/*      */   protected void _finishString2() throws IOException
/*      */   {
/* 2079 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 2080 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2081 */     int[] codes = _icLatin1;
/* 2082 */     int maxCode = codes.length;
/*      */     for (;;)
/*      */     {
/* 2085 */       if ((this._inputPtr >= this._inputEnd) && 
/* 2086 */         (!_loadMore())) {
/* 2087 */         _reportInvalidEOF(": was expecting closing quote for a string value", JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/*      */ 
/* 2091 */       char c = this._inputBuffer[(this._inputPtr++)];
/* 2092 */       int i = c;
/* 2093 */       if ((i < maxCode) && (codes[i] != 0)) {
/* 2094 */         if (i == 34)
/*      */           break;
/* 2096 */         if (i == 92)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 2101 */           c = _decodeEscaped();
/* 2102 */         } else if (i < 32) {
/* 2103 */           _throwUnquotedSpace(i, "string value");
/*      */         }
/*      */       }
/*      */       
/* 2107 */       if (outPtr >= outBuf.length) {
/* 2108 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2109 */         outPtr = 0;
/*      */       }
/*      */       
/* 2112 */       outBuf[(outPtr++)] = c;
/*      */     }
/* 2114 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _skipString()
/*      */     throws IOException
/*      */   {
/* 2124 */     this._tokenIncomplete = false;
/*      */     
/* 2126 */     int inPtr = this._inputPtr;
/* 2127 */     int inLen = this._inputEnd;
/* 2128 */     char[] inBuf = this._inputBuffer;
/*      */     for (;;)
/*      */     {
/* 2131 */       if (inPtr >= inLen) {
/* 2132 */         this._inputPtr = inPtr;
/* 2133 */         if (!_loadMore()) {
/* 2134 */           _reportInvalidEOF(": was expecting closing quote for a string value", JsonToken.VALUE_STRING);
/*      */         }
/*      */         
/* 2137 */         inPtr = this._inputPtr;
/* 2138 */         inLen = this._inputEnd;
/*      */       }
/* 2140 */       char c = inBuf[(inPtr++)];
/* 2141 */       int i = c;
/* 2142 */       if (i <= 92) {
/* 2143 */         if (i == 92)
/*      */         {
/*      */ 
/* 2146 */           this._inputPtr = inPtr;
/* 2147 */           _decodeEscaped();
/* 2148 */           inPtr = this._inputPtr;
/* 2149 */           inLen = this._inputEnd;
/* 2150 */         } else if (i <= 34) {
/* 2151 */           if (i == 34) {
/* 2152 */             this._inputPtr = inPtr;
/* 2153 */             break;
/*      */           }
/* 2155 */           if (i < 32) {
/* 2156 */             this._inputPtr = inPtr;
/* 2157 */             _throwUnquotedSpace(i, "string value");
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _skipCR()
/*      */     throws IOException
/*      */   {
/* 2175 */     if (((this._inputPtr < this._inputEnd) || (_loadMore())) && 
/* 2176 */       (this._inputBuffer[this._inputPtr] == '\n')) {
/* 2177 */       this._inputPtr += 1;
/*      */     }
/*      */     
/* 2180 */     this._currInputRow += 1;
/* 2181 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */   
/*      */   private final int _skipColon() throws IOException
/*      */   {
/* 2186 */     if (this._inputPtr + 4 >= this._inputEnd) {
/* 2187 */       return _skipColon2(false);
/*      */     }
/* 2189 */     char c = this._inputBuffer[this._inputPtr];
/* 2190 */     if (c == ':') {
/* 2191 */       int i = this._inputBuffer[(++this._inputPtr)];
/* 2192 */       if (i > 32) {
/* 2193 */         if ((i == 47) || (i == 35)) {
/* 2194 */           return _skipColon2(true);
/*      */         }
/* 2196 */         this._inputPtr += 1;
/* 2197 */         return i;
/*      */       }
/* 2199 */       if ((i == 32) || (i == 9)) {
/* 2200 */         i = this._inputBuffer[(++this._inputPtr)];
/* 2201 */         if (i > 32) {
/* 2202 */           if ((i == 47) || (i == 35)) {
/* 2203 */             return _skipColon2(true);
/*      */           }
/* 2205 */           this._inputPtr += 1;
/* 2206 */           return i;
/*      */         }
/*      */       }
/* 2209 */       return _skipColon2(true);
/*      */     }
/* 2211 */     if ((c == ' ') || (c == '\t')) {
/* 2212 */       c = this._inputBuffer[(++this._inputPtr)];
/*      */     }
/* 2214 */     if (c == ':') {
/* 2215 */       int i = this._inputBuffer[(++this._inputPtr)];
/* 2216 */       if (i > 32) {
/* 2217 */         if ((i == 47) || (i == 35)) {
/* 2218 */           return _skipColon2(true);
/*      */         }
/* 2220 */         this._inputPtr += 1;
/* 2221 */         return i;
/*      */       }
/* 2223 */       if ((i == 32) || (i == 9)) {
/* 2224 */         i = this._inputBuffer[(++this._inputPtr)];
/* 2225 */         if (i > 32) {
/* 2226 */           if ((i == 47) || (i == 35)) {
/* 2227 */             return _skipColon2(true);
/*      */           }
/* 2229 */           this._inputPtr += 1;
/* 2230 */           return i;
/*      */         }
/*      */       }
/* 2233 */       return _skipColon2(true);
/*      */     }
/* 2235 */     return _skipColon2(false);
/*      */   }
/*      */   
/*      */   private final int _skipColon2(boolean gotColon) throws IOException
/*      */   {
/* 2240 */     while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 2241 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 2242 */       if (i > 32) {
/* 2243 */         if (i == 47) {
/* 2244 */           _skipComment();
/*      */ 
/*      */         }
/* 2247 */         else if ((i != 35) || 
/* 2248 */           (!_skipYAMLComment()))
/*      */         {
/*      */ 
/*      */ 
/* 2252 */           if (gotColon) {
/* 2253 */             return i;
/*      */           }
/* 2255 */           if (i != 58) {
/* 2256 */             _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */           }
/* 2258 */           gotColon = true;
/*      */         }
/*      */       }
/* 2261 */       else if (i < 32) {
/* 2262 */         if (i == 10) {
/* 2263 */           this._currInputRow += 1;
/* 2264 */           this._currInputRowStart = this._inputPtr;
/* 2265 */         } else if (i == 13) {
/* 2266 */           _skipCR();
/* 2267 */         } else if (i != 9) {
/* 2268 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/* 2272 */     _reportInvalidEOF(" within/between " + this._parsingContext.typeDesc() + " entries", null);
/*      */     
/* 2274 */     return -1;
/*      */   }
/*      */   
/*      */   private final int _skipColonFast(int ptr)
/*      */     throws IOException
/*      */   {
/* 2280 */     int i = this._inputBuffer[(ptr++)];
/* 2281 */     if (i == 58) {
/* 2282 */       i = this._inputBuffer[(ptr++)];
/* 2283 */       if (i > 32) {
/* 2284 */         if ((i != 47) && (i != 35)) {
/* 2285 */           this._inputPtr = ptr;
/* 2286 */           return i;
/*      */         }
/* 2288 */       } else if ((i == 32) || (i == 9)) {
/* 2289 */         i = this._inputBuffer[(ptr++)];
/* 2290 */         if ((i > 32) && 
/* 2291 */           (i != 47) && (i != 35)) {
/* 2292 */           this._inputPtr = ptr;
/* 2293 */           return i;
/*      */         }
/*      */       }
/*      */       
/* 2297 */       this._inputPtr = (ptr - 1);
/* 2298 */       return _skipColon2(true);
/*      */     }
/* 2300 */     if ((i == 32) || (i == 9)) {
/* 2301 */       i = this._inputBuffer[(ptr++)];
/*      */     }
/* 2303 */     boolean gotColon = i == 58;
/* 2304 */     if (gotColon) {
/* 2305 */       i = this._inputBuffer[(ptr++)];
/* 2306 */       if (i > 32) {
/* 2307 */         if ((i != 47) && (i != 35)) {
/* 2308 */           this._inputPtr = ptr;
/* 2309 */           return i;
/*      */         }
/* 2311 */       } else if ((i == 32) || (i == 9)) {
/* 2312 */         i = this._inputBuffer[(ptr++)];
/* 2313 */         if ((i > 32) && 
/* 2314 */           (i != 47) && (i != 35)) {
/* 2315 */           this._inputPtr = ptr;
/* 2316 */           return i;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2321 */     this._inputPtr = (ptr - 1);
/* 2322 */     return _skipColon2(gotColon);
/*      */   }
/*      */   
/*      */   private final int _skipComma(int i)
/*      */     throws IOException
/*      */   {
/* 2328 */     if (i != 44) {
/* 2329 */       _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */     }
/* 2331 */     while (this._inputPtr < this._inputEnd) {
/* 2332 */       i = this._inputBuffer[(this._inputPtr++)];
/* 2333 */       if (i > 32) {
/* 2334 */         if ((i == 47) || (i == 35)) {
/* 2335 */           this._inputPtr -= 1;
/* 2336 */           return _skipAfterComma2();
/*      */         }
/* 2338 */         return i;
/*      */       }
/* 2340 */       if (i < 32) {
/* 2341 */         if (i == 10) {
/* 2342 */           this._currInputRow += 1;
/* 2343 */           this._currInputRowStart = this._inputPtr;
/* 2344 */         } else if (i == 13) {
/* 2345 */           _skipCR();
/* 2346 */         } else if (i != 9) {
/* 2347 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/* 2351 */     return _skipAfterComma2();
/*      */   }
/*      */   
/*      */   private final int _skipAfterComma2() throws IOException
/*      */   {
/* 2356 */     while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 2357 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 2358 */       if (i > 32) {
/* 2359 */         if (i == 47) {
/* 2360 */           _skipComment();
/*      */ 
/*      */         }
/* 2363 */         else if ((i != 35) || 
/* 2364 */           (!_skipYAMLComment()))
/*      */         {
/*      */ 
/*      */ 
/* 2368 */           return i;
/*      */         }
/* 2370 */       } else if (i < 32) {
/* 2371 */         if (i == 10) {
/* 2372 */           this._currInputRow += 1;
/* 2373 */           this._currInputRowStart = this._inputPtr;
/* 2374 */         } else if (i == 13) {
/* 2375 */           _skipCR();
/* 2376 */         } else if (i != 9) {
/* 2377 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/* 2381 */     throw _constructError("Unexpected end-of-input within/between " + this._parsingContext.typeDesc() + " entries");
/*      */   }
/*      */   
/*      */ 
/*      */   private final int _skipWSOrEnd()
/*      */     throws IOException
/*      */   {
/* 2388 */     if ((this._inputPtr >= this._inputEnd) && 
/* 2389 */       (!_loadMore())) {
/* 2390 */       return _eofAsNextChar();
/*      */     }
/*      */     
/* 2393 */     int i = this._inputBuffer[(this._inputPtr++)];
/* 2394 */     if (i > 32) {
/* 2395 */       if ((i == 47) || (i == 35)) {
/* 2396 */         this._inputPtr -= 1;
/* 2397 */         return _skipWSOrEnd2();
/*      */       }
/* 2399 */       return i;
/*      */     }
/* 2401 */     if (i != 32) {
/* 2402 */       if (i == 10) {
/* 2403 */         this._currInputRow += 1;
/* 2404 */         this._currInputRowStart = this._inputPtr;
/* 2405 */       } else if (i == 13) {
/* 2406 */         _skipCR();
/* 2407 */       } else if (i != 9) {
/* 2408 */         _throwInvalidSpace(i);
/*      */       }
/*      */     }
/*      */     
/* 2412 */     while (this._inputPtr < this._inputEnd) {
/* 2413 */       i = this._inputBuffer[(this._inputPtr++)];
/* 2414 */       if (i > 32) {
/* 2415 */         if ((i == 47) || (i == 35)) {
/* 2416 */           this._inputPtr -= 1;
/* 2417 */           return _skipWSOrEnd2();
/*      */         }
/* 2419 */         return i;
/*      */       }
/* 2421 */       if (i != 32) {
/* 2422 */         if (i == 10) {
/* 2423 */           this._currInputRow += 1;
/* 2424 */           this._currInputRowStart = this._inputPtr;
/* 2425 */         } else if (i == 13) {
/* 2426 */           _skipCR();
/* 2427 */         } else if (i != 9) {
/* 2428 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/* 2432 */     return _skipWSOrEnd2();
/*      */   }
/*      */   
/*      */   private int _skipWSOrEnd2() throws IOException
/*      */   {
/*      */     for (;;) {
/* 2438 */       if ((this._inputPtr >= this._inputEnd) && 
/* 2439 */         (!_loadMore())) {
/* 2440 */         return _eofAsNextChar();
/*      */       }
/*      */       
/* 2443 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 2444 */       if (i > 32) {
/* 2445 */         if (i == 47) {
/* 2446 */           _skipComment();
/*      */ 
/*      */         }
/* 2449 */         else if ((i != 35) || 
/* 2450 */           (!_skipYAMLComment()))
/*      */         {
/*      */ 
/*      */ 
/* 2454 */           return i; }
/* 2455 */       } else if (i != 32) {
/* 2456 */         if (i == 10) {
/* 2457 */           this._currInputRow += 1;
/* 2458 */           this._currInputRowStart = this._inputPtr;
/* 2459 */         } else if (i == 13) {
/* 2460 */           _skipCR();
/* 2461 */         } else if (i != 9) {
/* 2462 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void _skipComment() throws IOException
/*      */   {
/* 2470 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/* 2471 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     
/* 2474 */     if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/* 2475 */       _reportInvalidEOF(" in a comment", null);
/*      */     }
/* 2477 */     char c = this._inputBuffer[(this._inputPtr++)];
/* 2478 */     if (c == '/') {
/* 2479 */       _skipLine();
/* 2480 */     } else if (c == '*') {
/* 2481 */       _skipCComment();
/*      */     } else {
/* 2483 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     }
/*      */   }
/*      */   
/*      */   private void _skipCComment()
/*      */     throws IOException
/*      */   {
/* 2490 */     while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 2491 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 2492 */       if (i <= 42) {
/* 2493 */         if (i == 42) {
/* 2494 */           if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/*      */             break;
/*      */           }
/* 2497 */           if (this._inputBuffer[this._inputPtr] == '/') {
/* 2498 */             this._inputPtr += 1;
/*      */           }
/*      */           
/*      */ 
/*      */         }
/* 2503 */         else if (i < 32) {
/* 2504 */           if (i == 10) {
/* 2505 */             this._currInputRow += 1;
/* 2506 */             this._currInputRowStart = this._inputPtr;
/* 2507 */           } else if (i == 13) {
/* 2508 */             _skipCR();
/* 2509 */           } else if (i != 9) {
/* 2510 */             _throwInvalidSpace(i);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2515 */     _reportInvalidEOF(" in a comment", null);
/*      */   }
/*      */   
/*      */   private boolean _skipYAMLComment() throws IOException
/*      */   {
/* 2520 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/* 2521 */       return false;
/*      */     }
/* 2523 */     _skipLine();
/* 2524 */     return true;
/*      */   }
/*      */   
/*      */   private void _skipLine()
/*      */     throws IOException
/*      */   {
/* 2530 */     while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 2531 */       int i = this._inputBuffer[(this._inputPtr++)];
/* 2532 */       if (i < 32) {
/* 2533 */         if (i == 10) {
/* 2534 */           this._currInputRow += 1;
/* 2535 */           this._currInputRowStart = this._inputPtr;
/* 2536 */           break; }
/* 2537 */         if (i == 13) {
/* 2538 */           _skipCR();
/* 2539 */           break; }
/* 2540 */         if (i != 9) {
/* 2541 */           _throwInvalidSpace(i);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected char _decodeEscaped()
/*      */     throws IOException
/*      */   {
/* 2550 */     if ((this._inputPtr >= this._inputEnd) && 
/* 2551 */       (!_loadMore())) {
/* 2552 */       _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */     }
/*      */     
/* 2555 */     char c = this._inputBuffer[(this._inputPtr++)];
/*      */     
/* 2557 */     switch (c)
/*      */     {
/*      */     case 'b': 
/* 2560 */       return '\b';
/*      */     case 't': 
/* 2562 */       return '\t';
/*      */     case 'n': 
/* 2564 */       return '\n';
/*      */     case 'f': 
/* 2566 */       return '\f';
/*      */     case 'r': 
/* 2568 */       return '\r';
/*      */     
/*      */ 
/*      */     case '"': 
/*      */     case '/': 
/*      */     case '\\': 
/* 2574 */       return c;
/*      */     
/*      */     case 'u': 
/*      */       break;
/*      */     
/*      */     default: 
/* 2580 */       return _handleUnrecognizedCharacterEscape(c);
/*      */     }
/*      */     
/*      */     
/* 2584 */     int value = 0;
/* 2585 */     for (int i = 0; i < 4; i++) {
/* 2586 */       if ((this._inputPtr >= this._inputEnd) && 
/* 2587 */         (!_loadMore())) {
/* 2588 */         _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/* 2591 */       int ch = this._inputBuffer[(this._inputPtr++)];
/* 2592 */       int digit = CharTypes.charToHex(ch);
/* 2593 */       if (digit < 0) {
/* 2594 */         _reportUnexpectedChar(ch, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2596 */       value = value << 4 | digit;
/*      */     }
/* 2598 */     return (char)value;
/*      */   }
/*      */   
/*      */   private final void _matchTrue() throws IOException {
/* 2602 */     int ptr = this._inputPtr;
/* 2603 */     if (ptr + 3 < this._inputEnd) {
/* 2604 */       char[] b = this._inputBuffer;
/* 2605 */       if ((b[ptr] == 'r') && (b[(++ptr)] == 'u') && (b[(++ptr)] == 'e')) {
/* 2606 */         char c = b[(++ptr)];
/* 2607 */         if ((c < '0') || (c == ']') || (c == '}')) {
/* 2608 */           this._inputPtr = ptr;
/* 2609 */           return;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2614 */     _matchToken("true", 1);
/*      */   }
/*      */   
/*      */   private final void _matchFalse() throws IOException {
/* 2618 */     int ptr = this._inputPtr;
/* 2619 */     if (ptr + 4 < this._inputEnd) {
/* 2620 */       char[] b = this._inputBuffer;
/* 2621 */       if ((b[ptr] == 'a') && (b[(++ptr)] == 'l') && (b[(++ptr)] == 's') && (b[(++ptr)] == 'e')) {
/* 2622 */         char c = b[(++ptr)];
/* 2623 */         if ((c < '0') || (c == ']') || (c == '}')) {
/* 2624 */           this._inputPtr = ptr;
/* 2625 */           return;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2630 */     _matchToken("false", 1);
/*      */   }
/*      */   
/*      */   private final void _matchNull() throws IOException {
/* 2634 */     int ptr = this._inputPtr;
/* 2635 */     if (ptr + 3 < this._inputEnd) {
/* 2636 */       char[] b = this._inputBuffer;
/* 2637 */       if ((b[ptr] == 'u') && (b[(++ptr)] == 'l') && (b[(++ptr)] == 'l')) {
/* 2638 */         char c = b[(++ptr)];
/* 2639 */         if ((c < '0') || (c == ']') || (c == '}')) {
/* 2640 */           this._inputPtr = ptr;
/* 2641 */           return;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2646 */     _matchToken("null", 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final void _matchToken(String matchStr, int i)
/*      */     throws IOException
/*      */   {
/* 2654 */     int len = matchStr.length();
/* 2655 */     if (this._inputPtr + len >= this._inputEnd) {
/* 2656 */       _matchToken2(matchStr, i);
/*      */     }
/*      */     else
/*      */     {
/*      */       do {
/* 2661 */         if (this._inputBuffer[this._inputPtr] != matchStr.charAt(i)) {
/* 2662 */           _reportInvalidToken(matchStr.substring(0, i));
/*      */         }
/* 2664 */         this._inputPtr += 1;
/* 2665 */         i++; } while (i < len);
/* 2666 */       int ch = this._inputBuffer[this._inputPtr];
/* 2667 */       if ((ch >= 48) && (ch != 93) && (ch != 125)) {
/* 2668 */         _checkMatchEnd(matchStr, i, ch);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private final void _matchToken2(String matchStr, int i) throws IOException {
/* 2674 */     int len = matchStr.length();
/*      */     do {
/* 2676 */       if (((this._inputPtr >= this._inputEnd) && (!_loadMore())) || 
/* 2677 */         (this._inputBuffer[this._inputPtr] != matchStr.charAt(i))) {
/* 2678 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2680 */       this._inputPtr += 1;
/* 2681 */       i++; } while (i < len);
/*      */     
/*      */ 
/* 2684 */     if ((this._inputPtr >= this._inputEnd) && (!_loadMore())) {
/* 2685 */       return;
/*      */     }
/* 2687 */     int ch = this._inputBuffer[this._inputPtr];
/* 2688 */     if ((ch >= 48) && (ch != 93) && (ch != 125)) {
/* 2689 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int c) throws IOException
/*      */   {
/* 2695 */     char ch = (char)c;
/* 2696 */     if (Character.isJavaIdentifierPart(ch)) {
/* 2697 */       _reportInvalidToken(matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected byte[] _decodeBase64(Base64Variant b64variant)
/*      */     throws IOException
/*      */   {
/* 2714 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 2721 */       if (this._inputPtr >= this._inputEnd) {
/* 2722 */         _loadMoreGuaranteed();
/*      */       }
/* 2724 */       char ch = this._inputBuffer[(this._inputPtr++)];
/* 2725 */       if (ch > ' ') {
/* 2726 */         int bits = b64variant.decodeBase64Char(ch);
/* 2727 */         if (bits < 0) {
/* 2728 */           if (ch == '"') {
/* 2729 */             return builder.toByteArray();
/*      */           }
/* 2731 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 2732 */           if (bits < 0) {}
/*      */         }
/*      */         else
/*      */         {
/* 2736 */           int decodedData = bits;
/*      */           
/*      */ 
/*      */ 
/* 2740 */           if (this._inputPtr >= this._inputEnd) {
/* 2741 */             _loadMoreGuaranteed();
/*      */           }
/* 2743 */           ch = this._inputBuffer[(this._inputPtr++)];
/* 2744 */           bits = b64variant.decodeBase64Char(ch);
/* 2745 */           if (bits < 0) {
/* 2746 */             bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */           }
/* 2748 */           decodedData = decodedData << 6 | bits;
/*      */           
/*      */ 
/* 2751 */           if (this._inputPtr >= this._inputEnd) {
/* 2752 */             _loadMoreGuaranteed();
/*      */           }
/* 2754 */           ch = this._inputBuffer[(this._inputPtr++)];
/* 2755 */           bits = b64variant.decodeBase64Char(ch);
/*      */           
/*      */ 
/* 2758 */           if (bits < 0) {
/* 2759 */             if (bits != -2)
/*      */             {
/* 2761 */               if (ch == '"') {
/* 2762 */                 decodedData >>= 4;
/* 2763 */                 builder.append(decodedData);
/* 2764 */                 if (b64variant.usesPadding()) {
/* 2765 */                   this._inputPtr -= 1;
/* 2766 */                   _handleBase64MissingPadding(b64variant);
/*      */                 }
/* 2768 */                 return builder.toByteArray();
/*      */               }
/* 2770 */               bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */             }
/* 2772 */             if (bits == -2)
/*      */             {
/* 2774 */               if (this._inputPtr >= this._inputEnd) {
/* 2775 */                 _loadMoreGuaranteed();
/*      */               }
/* 2777 */               ch = this._inputBuffer[(this._inputPtr++)];
/* 2778 */               if ((!b64variant.usesPaddingChar(ch)) && 
/* 2779 */                 (_decodeBase64Escape(b64variant, ch, 3) != -2)) {
/* 2780 */                 throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */               }
/*      */               
/*      */ 
/* 2784 */               decodedData >>= 4;
/* 2785 */               builder.append(decodedData);
/* 2786 */               continue;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 2791 */           decodedData = decodedData << 6 | bits;
/*      */           
/* 2793 */           if (this._inputPtr >= this._inputEnd) {
/* 2794 */             _loadMoreGuaranteed();
/*      */           }
/* 2796 */           ch = this._inputBuffer[(this._inputPtr++)];
/* 2797 */           bits = b64variant.decodeBase64Char(ch);
/* 2798 */           if (bits < 0) {
/* 2799 */             if (bits != -2)
/*      */             {
/* 2801 */               if (ch == '"') {
/* 2802 */                 decodedData >>= 2;
/* 2803 */                 builder.appendTwoBytes(decodedData);
/* 2804 */                 if (b64variant.usesPadding()) {
/* 2805 */                   this._inputPtr -= 1;
/* 2806 */                   _handleBase64MissingPadding(b64variant);
/*      */                 }
/* 2808 */                 return builder.toByteArray();
/*      */               }
/* 2810 */               bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */             }
/* 2812 */             if (bits == -2)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2818 */               decodedData >>= 2;
/* 2819 */               builder.appendTwoBytes(decodedData);
/* 2820 */               continue;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 2825 */           decodedData = decodedData << 6 | bits;
/* 2826 */           builder.appendThreeBytes(decodedData);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonLocation getTokenLocation()
/*      */   {
/* 2839 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 2840 */       long total = this._currInputProcessed + (this._nameStartOffset - 1L);
/* 2841 */       return new JsonLocation(_getSourceReference(), -1L, total, this._nameStartRow, this._nameStartCol);
/*      */     }
/*      */     
/* 2844 */     return new JsonLocation(_getSourceReference(), -1L, this._tokenInputTotal - 1L, this._tokenInputRow, this._tokenInputCol);
/*      */   }
/*      */   
/*      */ 
/*      */   public JsonLocation getCurrentLocation()
/*      */   {
/* 2850 */     int col = this._inputPtr - this._currInputRowStart + 1;
/* 2851 */     return new JsonLocation(_getSourceReference(), -1L, this._currInputProcessed + this._inputPtr, this._currInputRow, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _updateLocation()
/*      */   {
/* 2859 */     int ptr = this._inputPtr;
/* 2860 */     this._tokenInputTotal = (this._currInputProcessed + ptr);
/* 2861 */     this._tokenInputRow = this._currInputRow;
/* 2862 */     this._tokenInputCol = (ptr - this._currInputRowStart);
/*      */   }
/*      */   
/*      */ 
/*      */   private final void _updateNameLocation()
/*      */   {
/* 2868 */     int ptr = this._inputPtr;
/* 2869 */     this._nameStartOffset = ptr;
/* 2870 */     this._nameStartRow = this._currInputRow;
/* 2871 */     this._nameStartCol = (ptr - this._currInputRowStart);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _reportInvalidToken(String matchedPart)
/*      */     throws IOException
/*      */   {
/* 2881 */     _reportInvalidToken(matchedPart, _validJsonTokenList());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _reportInvalidToken(String matchedPart, String msg)
/*      */     throws IOException
/*      */   {
/* 2890 */     StringBuilder sb = new StringBuilder(matchedPart);
/* 2891 */     while ((this._inputPtr < this._inputEnd) || (_loadMore())) {
/* 2892 */       char c = this._inputBuffer[this._inputPtr];
/* 2893 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 2896 */       this._inputPtr += 1;
/* 2897 */       sb.append(c);
/* 2898 */       if (sb.length() >= 256) {
/* 2899 */         sb.append("...");
/* 2900 */         break;
/*      */       }
/*      */     }
/* 2903 */     _reportError("Unrecognized token '%s': was expecting %s", sb, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _closeScope(int i)
/*      */     throws com.fasterxml.jackson.core.JsonParseException
/*      */   {
/* 2913 */     if (i == 93) {
/* 2914 */       _updateLocation();
/* 2915 */       if (!this._parsingContext.inArray()) {
/* 2916 */         _reportMismatchedEndMarker(i, '}');
/*      */       }
/* 2918 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 2919 */       this._currToken = JsonToken.END_ARRAY;
/*      */     }
/* 2921 */     if (i == 125) {
/* 2922 */       _updateLocation();
/* 2923 */       if (!this._parsingContext.inObject()) {
/* 2924 */         _reportMismatchedEndMarker(i, ']');
/*      */       }
/* 2926 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 2927 */       this._currToken = JsonToken.END_OBJECT;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\json\ReaderBasedJsonParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */