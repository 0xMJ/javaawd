package com.fasterxml.jackson.core.async;

public abstract interface NonBlockingInputFeeder
{
  public abstract boolean needMoreInput();
  
  public abstract void endOfInput();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\async\NonBlockingInputFeeder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */