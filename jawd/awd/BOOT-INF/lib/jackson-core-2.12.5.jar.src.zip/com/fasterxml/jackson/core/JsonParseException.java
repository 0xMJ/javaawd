/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.exc.StreamReadException;
/*     */ import com.fasterxml.jackson.core.util.RequestPayload;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonParseException
/*     */   extends StreamReadException
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   
/*     */   @Deprecated
/*     */   public JsonParseException(String msg, JsonLocation loc)
/*     */   {
/*  22 */     super(msg, loc, null);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public JsonParseException(String msg, JsonLocation loc, Throwable root) {
/*  27 */     super(msg, loc, root);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonParseException(JsonParser p, String msg)
/*     */   {
/*  41 */     super(p, msg);
/*     */   }
/*     */   
/*     */   public JsonParseException(JsonParser p, String msg, Throwable root)
/*     */   {
/*  46 */     super(p, msg, root);
/*     */   }
/*     */   
/*     */   public JsonParseException(JsonParser p, String msg, JsonLocation loc)
/*     */   {
/*  51 */     super(p, msg, loc);
/*     */   }
/*     */   
/*     */   public JsonParseException(JsonParser p, String msg, JsonLocation loc, Throwable root)
/*     */   {
/*  56 */     super(msg, loc, root);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonParseException withParser(JsonParser p)
/*     */   {
/*  73 */     this._processor = p;
/*  74 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonParseException withRequestPayload(RequestPayload payload)
/*     */   {
/*  91 */     this._requestPayload = payload;
/*  92 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public JsonParser getProcessor()
/*     */   {
/*  98 */     return super.getProcessor();
/*     */   }
/*     */   
/*     */ 
/*     */   public RequestPayload getRequestPayload()
/*     */   {
/* 104 */     return super.getRequestPayload();
/*     */   }
/*     */   
/*     */ 
/*     */   public String getRequestPayloadAsString()
/*     */   {
/* 110 */     return super.getRequestPayloadAsString();
/*     */   }
/*     */   
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 116 */     return super.getMessage();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\JsonParseException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */