/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum StreamReadFeature
/*     */   implements JacksonFeature
/*     */ {
/*  31 */   AUTO_CLOSE_SOURCE(JsonParser.Feature.AUTO_CLOSE_SOURCE), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */   STRICT_DUPLICATE_DETECTION(JsonParser.Feature.STRICT_DUPLICATE_DETECTION), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */   IGNORE_UNDEFINED(JsonParser.Feature.IGNORE_UNDEFINED), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */   INCLUDE_SOURCE_IN_LOCATION(JsonParser.Feature.INCLUDE_SOURCE_IN_LOCATION);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean _defaultState;
/*     */   
/*     */ 
/*     */ 
/*     */   private final int _mask;
/*     */   
/*     */ 
/*     */ 
/*     */   private final JsonParser.Feature _mappedFeature;
/*     */   
/*     */ 
/*     */ 
/*     */   private StreamReadFeature(JsonParser.Feature mapTo)
/*     */   {
/* 111 */     this._mappedFeature = mapTo;
/* 112 */     this._mask = mapTo.getMask();
/* 113 */     this._defaultState = mapTo.enabledByDefault();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int collectDefaults()
/*     */   {
/* 124 */     int flags = 0;
/* 125 */     for (StreamReadFeature f : values()) {
/* 126 */       if (f.enabledByDefault()) {
/* 127 */         flags |= f.getMask();
/*     */       }
/*     */     }
/* 130 */     return flags;
/*     */   }
/*     */   
/*     */ 
/* 134 */   public boolean enabledByDefault() { return this._defaultState; }
/*     */   
/* 136 */   public boolean enabledIn(int flags) { return (flags & this._mask) != 0; }
/*     */   
/* 138 */   public int getMask() { return this._mask; }
/*     */   
/* 140 */   public JsonParser.Feature mappedFeature() { return this._mappedFeature; }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\StreamReadFeature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */