package com.fasterxml.jackson.core.format;

public enum MatchStrength
{
  NO_MATCH,  INCONCLUSIVE,  WEAK_MATCH,  SOLID_MATCH,  FULL_MATCH;
  
  private MatchStrength() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\format\MatchStrength.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */