/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonPointer
/*     */ {
/*     */   public static final char SEPARATOR = '/';
/*  34 */   protected static final JsonPointer EMPTY = new JsonPointer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final JsonPointer _nextSegment;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected volatile JsonPointer _head;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String _asString;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String _matchingPropertyName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final int _matchingElementIndex;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonPointer()
/*     */   {
/*  78 */     this._nextSegment = null;
/*  79 */     this._matchingPropertyName = "";
/*  80 */     this._matchingElementIndex = -1;
/*  81 */     this._asString = "";
/*     */   }
/*     */   
/*     */   protected JsonPointer(String fullString, String segment, JsonPointer next)
/*     */   {
/*  86 */     this._asString = fullString;
/*  87 */     this._nextSegment = next;
/*     */     
/*  89 */     this._matchingPropertyName = segment;
/*     */     
/*  91 */     this._matchingElementIndex = _parseIndex(segment);
/*     */   }
/*     */   
/*     */   protected JsonPointer(String fullString, String segment, int matchIndex, JsonPointer next)
/*     */   {
/*  96 */     this._asString = fullString;
/*  97 */     this._nextSegment = next;
/*  98 */     this._matchingPropertyName = segment;
/*  99 */     this._matchingElementIndex = matchIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonPointer compile(String expr)
/*     */     throws IllegalArgumentException
/*     */   {
/* 124 */     if ((expr == null) || (expr.length() == 0)) {
/* 125 */       return EMPTY;
/*     */     }
/*     */     
/* 128 */     if (expr.charAt(0) != '/') {
/* 129 */       throw new IllegalArgumentException("Invalid input: JSON Pointer expression must start with '/': \"" + expr + "\"");
/*     */     }
/* 131 */     return _parseTail(expr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonPointer valueOf(String expr)
/*     */   {
/* 142 */     return compile(expr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonPointer empty()
/*     */   {
/* 155 */     return EMPTY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonPointer forPath(JsonStreamContext context, boolean includeRoot)
/*     */   {
/* 174 */     if (context == null) {
/* 175 */       return EMPTY;
/*     */     }
/* 177 */     if (!context.hasPathSegment())
/*     */     {
/* 179 */       if ((!includeRoot) || (!context.inRoot()) || (!context.hasCurrentIndex())) {
/* 180 */         context = context.getParent();
/*     */       }
/*     */     }
/* 183 */     JsonPointer tail = null;
/* 185 */     for (; 
/* 185 */         context != null; context = context.getParent()) {
/* 186 */       if (context.inObject()) {
/* 187 */         String seg = context.getCurrentName();
/* 188 */         if (seg == null) {
/* 189 */           seg = "";
/*     */         }
/* 191 */         tail = new JsonPointer(_fullPath(tail, seg), seg, tail);
/* 192 */       } else if ((context.inArray()) || (includeRoot)) {
/* 193 */         int ix = context.getCurrentIndex();
/* 194 */         String ixStr = String.valueOf(ix);
/* 195 */         tail = new JsonPointer(_fullPath(tail, ixStr), ixStr, ix, tail);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 201 */     if (tail == null) {
/* 202 */       return EMPTY;
/*     */     }
/* 204 */     return tail;
/*     */   }
/*     */   
/*     */   private static String _fullPath(JsonPointer tail, String segment)
/*     */   {
/* 209 */     if (tail == null) {
/* 210 */       StringBuilder sb = new StringBuilder(segment.length() + 1);
/* 211 */       sb.append('/');
/* 212 */       _appendEscaped(sb, segment);
/* 213 */       return sb.toString();
/*     */     }
/* 215 */     String tailDesc = tail._asString;
/* 216 */     StringBuilder sb = new StringBuilder(segment.length() + 1 + tailDesc.length());
/* 217 */     sb.append('/');
/* 218 */     _appendEscaped(sb, segment);
/* 219 */     sb.append(tailDesc);
/* 220 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static void _appendEscaped(StringBuilder sb, String segment)
/*     */   {
/* 225 */     int i = 0; for (int end = segment.length(); i < end; i++) {
/* 226 */       char c = segment.charAt(i);
/* 227 */       if (c == '/') {
/* 228 */         sb.append("~1");
/*     */ 
/*     */       }
/* 231 */       else if (c == '~') {
/* 232 */         sb.append("~0");
/*     */       }
/*     */       else {
/* 235 */         sb.append(c);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 267 */   public boolean matches() { return this._nextSegment == null; }
/* 268 */   public String getMatchingProperty() { return this._matchingPropertyName; }
/* 269 */   public int getMatchingIndex() { return this._matchingElementIndex; }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean mayMatchProperty()
/*     */   {
/* 275 */     return this._matchingPropertyName != null;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean mayMatchElement()
/*     */   {
/* 281 */     return this._matchingElementIndex >= 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonPointer last()
/*     */   {
/* 290 */     JsonPointer current = this;
/* 291 */     if (current == EMPTY) {
/* 292 */       return null;
/*     */     }
/*     */     JsonPointer next;
/* 295 */     while ((next = current._nextSegment) != EMPTY) {
/* 296 */       current = next;
/*     */     }
/* 298 */     return current;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonPointer append(JsonPointer tail)
/*     */   {
/* 318 */     if (this == EMPTY) {
/* 319 */       return tail;
/*     */     }
/* 321 */     if (tail == EMPTY) {
/* 322 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 327 */     String currentJsonPointer = this._asString;
/* 328 */     if (currentJsonPointer.endsWith("/"))
/*     */     {
/* 330 */       currentJsonPointer = currentJsonPointer.substring(0, currentJsonPointer.length() - 1);
/*     */     }
/* 332 */     return compile(currentJsonPointer + tail._asString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matchesProperty(String name)
/*     */   {
/* 346 */     return (this._nextSegment != null) && (this._matchingPropertyName.equals(name));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonPointer matchProperty(String name)
/*     */   {
/* 361 */     if ((this._nextSegment != null) && (this._matchingPropertyName.equals(name))) {
/* 362 */       return this._nextSegment;
/*     */     }
/* 364 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matchesElement(int index)
/*     */   {
/* 378 */     return (index == this._matchingElementIndex) && (index >= 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonPointer matchElement(int index)
/*     */   {
/* 395 */     if ((index != this._matchingElementIndex) || (index < 0)) {
/* 396 */       return null;
/*     */     }
/* 398 */     return this._nextSegment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonPointer tail()
/*     */   {
/* 415 */     return this._nextSegment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonPointer head()
/*     */   {
/* 435 */     JsonPointer h = this._head;
/* 436 */     if (h == null) {
/* 437 */       if (this != EMPTY) {
/* 438 */         h = _constructHead();
/*     */       }
/* 440 */       this._head = h;
/*     */     }
/* 442 */     return h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 451 */   public String toString() { return this._asString; }
/* 452 */   public int hashCode() { return this._asString.hashCode(); }
/*     */   
/*     */   public boolean equals(Object o) {
/* 455 */     if (o == this) return true;
/* 456 */     if (o == null) return false;
/* 457 */     if (!(o instanceof JsonPointer)) return false;
/* 458 */     return this._asString.equals(((JsonPointer)o)._asString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int _parseIndex(String str)
/*     */   {
/* 468 */     int len = str.length();
/*     */     
/*     */ 
/* 471 */     if ((len == 0) || (len > 10)) {
/* 472 */       return -1;
/*     */     }
/*     */     
/* 475 */     char c = str.charAt(0);
/* 476 */     if (c <= '0') {
/* 477 */       return (len == 1) && (c == '0') ? 0 : -1;
/*     */     }
/* 479 */     if (c > '9') {
/* 480 */       return -1;
/*     */     }
/* 482 */     for (int i = 1; i < len; i++) {
/* 483 */       c = str.charAt(i);
/* 484 */       if ((c > '9') || (c < '0')) {
/* 485 */         return -1;
/*     */       }
/*     */     }
/* 488 */     if (len == 10) {
/* 489 */       long l = NumberInput.parseLong(str);
/* 490 */       if (l > 2147483647L) {
/* 491 */         return -1;
/*     */       }
/*     */     }
/* 494 */     return NumberInput.parseInt(str);
/*     */   }
/*     */   
/*     */   protected static JsonPointer _parseTail(String input) {
/* 498 */     int end = input.length();
/*     */     
/*     */ 
/* 501 */     for (int i = 1; i < end;) {
/* 502 */       char c = input.charAt(i);
/* 503 */       if (c == '/') {
/* 504 */         return new JsonPointer(input, input.substring(1, i), 
/* 505 */           _parseTail(input.substring(i)));
/*     */       }
/* 507 */       i++;
/*     */       
/* 509 */       if ((c == '~') && (i < end)) {
/* 510 */         return _parseQuotedTail(input, i);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 515 */     return new JsonPointer(input, input.substring(1), EMPTY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static JsonPointer _parseQuotedTail(String input, int i)
/*     */   {
/* 528 */     int end = input.length();
/* 529 */     StringBuilder sb = new StringBuilder(Math.max(16, end));
/* 530 */     if (i > 2) {
/* 531 */       sb.append(input, 1, i - 1);
/*     */     }
/* 533 */     _appendEscape(sb, input.charAt(i++));
/* 534 */     while (i < end) {
/* 535 */       char c = input.charAt(i);
/* 536 */       if (c == '/') {
/* 537 */         return new JsonPointer(input, sb.toString(), 
/* 538 */           _parseTail(input.substring(i)));
/*     */       }
/* 540 */       i++;
/* 541 */       if ((c == '~') && (i < end)) {
/* 542 */         _appendEscape(sb, input.charAt(i++));
/*     */       }
/*     */       else {
/* 545 */         sb.append(c);
/*     */       }
/*     */     }
/* 548 */     return new JsonPointer(input, sb.toString(), EMPTY);
/*     */   }
/*     */   
/*     */ 
/*     */   protected JsonPointer _constructHead()
/*     */   {
/* 554 */     JsonPointer last = last();
/* 555 */     if (last == this) {
/* 556 */       return EMPTY;
/*     */     }
/*     */     
/* 559 */     int suffixLength = last._asString.length();
/* 560 */     JsonPointer next = this._nextSegment;
/* 561 */     return new JsonPointer(this._asString.substring(0, this._asString.length() - suffixLength), this._matchingPropertyName, this._matchingElementIndex, next
/* 562 */       ._constructHead(suffixLength, last));
/*     */   }
/*     */   
/*     */   protected JsonPointer _constructHead(int suffixLength, JsonPointer last)
/*     */   {
/* 567 */     if (this == last) {
/* 568 */       return EMPTY;
/*     */     }
/* 570 */     JsonPointer next = this._nextSegment;
/* 571 */     String str = this._asString;
/* 572 */     return new JsonPointer(str.substring(0, str.length() - suffixLength), this._matchingPropertyName, this._matchingElementIndex, next
/* 573 */       ._constructHead(suffixLength, last));
/*     */   }
/*     */   
/*     */   private static void _appendEscape(StringBuilder sb, char c) {
/* 577 */     if (c == '0') {
/* 578 */       c = '~';
/* 579 */     } else if (c == '1') {
/* 580 */       c = '/';
/*     */     } else {
/* 582 */       sb.append('~');
/*     */     }
/* 584 */     sb.append(c);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\JsonPointer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */