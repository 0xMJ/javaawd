/*      */ package com.fasterxml.jackson.core.sym;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonFactory.Feature;
/*      */ import com.fasterxml.jackson.core.util.InternCache;
/*      */ import java.util.Arrays;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ByteQuadsCanonicalizer
/*      */ {
/*      */   private static final int DEFAULT_T_SIZE = 64;
/*      */   private static final int MAX_T_SIZE = 65536;
/*      */   private static final int MIN_HASH_SIZE = 16;
/*      */   static final int MAX_ENTRIES_FOR_REUSE = 6000;
/*      */   protected final ByteQuadsCanonicalizer _parent;
/*      */   protected final AtomicReference<TableInfo> _tableInfo;
/*      */   protected final int _seed;
/*      */   protected boolean _intern;
/*      */   protected final boolean _failOnDoS;
/*      */   protected int[] _hashArea;
/*      */   protected int _hashSize;
/*      */   protected int _secondaryStart;
/*      */   protected int _tertiaryStart;
/*      */   protected int _tertiaryShift;
/*      */   protected int _count;
/*      */   protected String[] _names;
/*      */   protected int _spilloverEnd;
/*      */   protected int _longNameOffset;
/*      */   protected boolean _hashShared;
/*      */   private static final int MULT = 33;
/*      */   private static final int MULT2 = 65599;
/*      */   private static final int MULT3 = 31;
/*      */   
/*      */   private ByteQuadsCanonicalizer(int sz, boolean intern, int seed, boolean failOnDoS)
/*      */   {
/*  228 */     this._parent = null;
/*  229 */     this._seed = seed;
/*  230 */     this._intern = intern;
/*  231 */     this._failOnDoS = failOnDoS;
/*      */     
/*  233 */     if (sz < 16) {
/*  234 */       sz = 16;
/*      */ 
/*      */ 
/*      */     }
/*  238 */     else if ((sz & sz - 1) != 0) {
/*  239 */       int curr = 16;
/*  240 */       while (curr < sz) {
/*  241 */         curr += curr;
/*      */       }
/*  243 */       sz = curr;
/*      */     }
/*      */     
/*  246 */     this._tableInfo = new AtomicReference(TableInfo.createInitial(sz));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteQuadsCanonicalizer(ByteQuadsCanonicalizer parent, boolean intern, int seed, boolean failOnDoS, TableInfo state)
/*      */   {
/*  255 */     this._parent = parent;
/*  256 */     this._seed = seed;
/*  257 */     this._intern = intern;
/*  258 */     this._failOnDoS = failOnDoS;
/*  259 */     this._tableInfo = null;
/*      */     
/*      */ 
/*  262 */     this._count = state.count;
/*  263 */     this._hashSize = state.size;
/*  264 */     this._secondaryStart = (this._hashSize << 2);
/*  265 */     this._tertiaryStart = (this._secondaryStart + (this._secondaryStart >> 1));
/*  266 */     this._tertiaryShift = state.tertiaryShift;
/*      */     
/*  268 */     this._hashArea = state.mainHash;
/*  269 */     this._names = state.names;
/*      */     
/*  271 */     this._spilloverEnd = state.spilloverEnd;
/*  272 */     this._longNameOffset = state.longNameOffset;
/*      */     
/*      */ 
/*  275 */     this._hashShared = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ByteQuadsCanonicalizer createRoot()
/*      */   {
/*  293 */     long now = System.currentTimeMillis();
/*      */     
/*  295 */     int seed = (int)now + (int)(now >>> 32) | 0x1;
/*  296 */     return createRoot(seed);
/*      */   }
/*      */   
/*      */ 
/*      */   protected static ByteQuadsCanonicalizer createRoot(int seed)
/*      */   {
/*  302 */     return new ByteQuadsCanonicalizer(64, true, seed, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ByteQuadsCanonicalizer makeChild(int flags)
/*      */   {
/*  314 */     return new ByteQuadsCanonicalizer(this, JsonFactory.Feature.INTERN_FIELD_NAMES
/*  315 */       .enabledIn(flags), this._seed, JsonFactory.Feature.FAIL_ON_SYMBOL_HASH_OVERFLOW
/*      */       
/*  317 */       .enabledIn(flags), 
/*  318 */       (TableInfo)this._tableInfo.get());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void release()
/*      */   {
/*  331 */     if ((this._parent != null) && (maybeDirty())) {
/*  332 */       this._parent.mergeChild(new TableInfo(this));
/*      */       
/*      */ 
/*  335 */       this._hashShared = true;
/*      */     }
/*      */   }
/*      */   
/*      */   private void mergeChild(TableInfo childState)
/*      */   {
/*  341 */     int childCount = childState.count;
/*  342 */     TableInfo currState = (TableInfo)this._tableInfo.get();
/*      */     
/*      */ 
/*      */ 
/*  346 */     if (childCount == currState.count) {
/*  347 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  354 */     if (childCount > 6000)
/*      */     {
/*  356 */       childState = TableInfo.createInitial(64);
/*      */     }
/*  358 */     this._tableInfo.compareAndSet(currState, childState);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int size()
/*      */   {
/*  372 */     if (this._tableInfo != null) {
/*  373 */       return ((TableInfo)this._tableInfo.get()).count;
/*      */     }
/*      */     
/*  376 */     return this._count;
/*      */   }
/*      */   
/*      */ 
/*      */   public int bucketCount()
/*      */   {
/*  382 */     return this._hashSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  391 */   public boolean maybeDirty() { return !this._hashShared; }
/*      */   
/*  393 */   public int hashSeed() { return this._seed; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int primaryCount()
/*      */   {
/*  404 */     int count = 0;
/*  405 */     int offset = 3; for (int end = this._secondaryStart; offset < end; offset += 4) {
/*  406 */       if (this._hashArea[offset] != 0) {
/*  407 */         count++;
/*      */       }
/*      */     }
/*  410 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int secondaryCount()
/*      */   {
/*  420 */     int count = 0;
/*  421 */     int offset = this._secondaryStart + 3;
/*  422 */     for (int end = this._tertiaryStart; offset < end; offset += 4) {
/*  423 */       if (this._hashArea[offset] != 0) {
/*  424 */         count++;
/*      */       }
/*      */     }
/*  427 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int tertiaryCount()
/*      */   {
/*  437 */     int count = 0;
/*  438 */     int offset = this._tertiaryStart + 3;
/*  439 */     for (int end = offset + this._hashSize; offset < end; offset += 4) {
/*  440 */       if (this._hashArea[offset] != 0) {
/*  441 */         count++;
/*      */       }
/*      */     }
/*  444 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int spilloverCount()
/*      */   {
/*  455 */     return this._spilloverEnd - _spilloverStart() >> 2;
/*      */   }
/*      */   
/*      */   public int totalCount()
/*      */   {
/*  460 */     int count = 0;
/*  461 */     int offset = 3; for (int end = this._hashSize << 3; offset < end; offset += 4) {
/*  462 */       if (this._hashArea[offset] != 0) {
/*  463 */         count++;
/*      */       }
/*      */     }
/*  466 */     return count;
/*      */   }
/*      */   
/*      */   public String toString()
/*      */   {
/*  471 */     int pri = primaryCount();
/*  472 */     int sec = secondaryCount();
/*  473 */     int tert = tertiaryCount();
/*  474 */     int spill = spilloverCount();
/*  475 */     int total = totalCount();
/*  476 */     return String.format("[%s: size=%d, hashSize=%d, %d/%d/%d/%d pri/sec/ter/spill (=%s), total:%d]", new Object[] {
/*  477 */       getClass().getName(), Integer.valueOf(this._count), Integer.valueOf(this._hashSize), 
/*  478 */       Integer.valueOf(pri), Integer.valueOf(sec), Integer.valueOf(tert), Integer.valueOf(spill), Integer.valueOf(pri + sec + tert + spill), Integer.valueOf(total) });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findName(int q1)
/*      */   {
/*  489 */     int offset = _calcOffset(calcHash(q1));
/*      */     
/*  491 */     int[] hashArea = this._hashArea;
/*      */     
/*  493 */     int len = hashArea[(offset + 3)];
/*      */     
/*  495 */     if (len == 1) {
/*  496 */       if (hashArea[offset] == q1) {
/*  497 */         return this._names[(offset >> 2)];
/*      */       }
/*  499 */     } else if (len == 0) {
/*  500 */       return null;
/*      */     }
/*      */     
/*  503 */     int offset2 = this._secondaryStart + (offset >> 3 << 2);
/*      */     
/*  505 */     len = hashArea[(offset2 + 3)];
/*      */     
/*  507 */     if (len == 1) {
/*  508 */       if (hashArea[offset2] == q1) {
/*  509 */         return this._names[(offset2 >> 2)];
/*      */       }
/*  511 */     } else if (len == 0) {
/*  512 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  516 */     return _findSecondary(offset, q1);
/*      */   }
/*      */   
/*      */   public String findName(int q1, int q2)
/*      */   {
/*  521 */     int offset = _calcOffset(calcHash(q1, q2));
/*      */     
/*  523 */     int[] hashArea = this._hashArea;
/*      */     
/*  525 */     int len = hashArea[(offset + 3)];
/*      */     
/*  527 */     if (len == 2) {
/*  528 */       if ((q1 == hashArea[offset]) && (q2 == hashArea[(offset + 1)])) {
/*  529 */         return this._names[(offset >> 2)];
/*      */       }
/*  531 */     } else if (len == 0) {
/*  532 */       return null;
/*      */     }
/*      */     
/*  535 */     int offset2 = this._secondaryStart + (offset >> 3 << 2);
/*      */     
/*  537 */     len = hashArea[(offset2 + 3)];
/*      */     
/*  539 */     if (len == 2) {
/*  540 */       if ((q1 == hashArea[offset2]) && (q2 == hashArea[(offset2 + 1)])) {
/*  541 */         return this._names[(offset2 >> 2)];
/*      */       }
/*  543 */     } else if (len == 0) {
/*  544 */       return null;
/*      */     }
/*  546 */     return _findSecondary(offset, q1, q2);
/*      */   }
/*      */   
/*      */   public String findName(int q1, int q2, int q3)
/*      */   {
/*  551 */     int offset = _calcOffset(calcHash(q1, q2, q3));
/*  552 */     int[] hashArea = this._hashArea;
/*  553 */     int len = hashArea[(offset + 3)];
/*      */     
/*  555 */     if (len == 3) {
/*  556 */       if ((q1 == hashArea[offset]) && (hashArea[(offset + 1)] == q2) && (hashArea[(offset + 2)] == q3)) {
/*  557 */         return this._names[(offset >> 2)];
/*      */       }
/*  559 */     } else if (len == 0) {
/*  560 */       return null;
/*      */     }
/*      */     
/*  563 */     int offset2 = this._secondaryStart + (offset >> 3 << 2);
/*      */     
/*  565 */     len = hashArea[(offset2 + 3)];
/*      */     
/*  567 */     if (len == 3) {
/*  568 */       if ((q1 == hashArea[offset2]) && (hashArea[(offset2 + 1)] == q2) && (hashArea[(offset2 + 2)] == q3)) {
/*  569 */         return this._names[(offset2 >> 2)];
/*      */       }
/*  571 */     } else if (len == 0) {
/*  572 */       return null;
/*      */     }
/*  574 */     return _findSecondary(offset, q1, q2, q3);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findName(int[] q, int qlen)
/*      */   {
/*  583 */     if (qlen < 4) {
/*  584 */       switch (qlen) {
/*      */       case 3: 
/*  586 */         return findName(q[0], q[1], q[2]);
/*      */       case 2: 
/*  588 */         return findName(q[0], q[1]);
/*      */       case 1: 
/*  590 */         return findName(q[0]);
/*      */       }
/*  592 */       return "";
/*      */     }
/*      */     
/*  595 */     int hash = calcHash(q, qlen);
/*  596 */     int offset = _calcOffset(hash);
/*      */     
/*  598 */     int[] hashArea = this._hashArea;
/*      */     
/*  600 */     int len = hashArea[(offset + 3)];
/*      */     
/*  602 */     if ((hash == hashArea[offset]) && (len == qlen))
/*      */     {
/*  604 */       if (_verifyLongName(q, qlen, hashArea[(offset + 1)])) {
/*  605 */         return this._names[(offset >> 2)];
/*      */       }
/*      */     }
/*  608 */     if (len == 0) {
/*  609 */       return null;
/*      */     }
/*      */     
/*  612 */     int offset2 = this._secondaryStart + (offset >> 3 << 2);
/*      */     
/*  614 */     int len2 = hashArea[(offset2 + 3)];
/*  615 */     if ((hash == hashArea[offset2]) && (len2 == qlen) && 
/*  616 */       (_verifyLongName(q, qlen, hashArea[(offset2 + 1)]))) {
/*  617 */       return this._names[(offset2 >> 2)];
/*      */     }
/*      */     
/*  620 */     return _findSecondary(offset, hash, q, qlen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int _calcOffset(int hash)
/*      */   {
/*  628 */     int ix = hash & this._hashSize - 1;
/*      */     
/*  630 */     return ix << 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String _findSecondary(int origOffset, int q1)
/*      */   {
/*  645 */     int offset = this._tertiaryStart + (origOffset >> this._tertiaryShift + 2 << this._tertiaryShift);
/*  646 */     int[] hashArea = this._hashArea;
/*  647 */     int bucketSize = 1 << this._tertiaryShift;
/*  648 */     for (int end = offset + bucketSize; offset < end; offset += 4) {
/*  649 */       int len = hashArea[(offset + 3)];
/*  650 */       if ((q1 == hashArea[offset]) && (1 == len)) {
/*  651 */         return this._names[(offset >> 2)];
/*      */       }
/*  653 */       if (len == 0) {
/*  654 */         return null;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  660 */     for (offset = _spilloverStart(); offset < this._spilloverEnd; offset += 4) {
/*  661 */       if ((q1 == hashArea[offset]) && (1 == hashArea[(offset + 3)])) {
/*  662 */         return this._names[(offset >> 2)];
/*      */       }
/*      */     }
/*  665 */     return null;
/*      */   }
/*      */   
/*      */   private String _findSecondary(int origOffset, int q1, int q2)
/*      */   {
/*  670 */     int offset = this._tertiaryStart + (origOffset >> this._tertiaryShift + 2 << this._tertiaryShift);
/*  671 */     int[] hashArea = this._hashArea;
/*      */     
/*  673 */     int bucketSize = 1 << this._tertiaryShift;
/*  674 */     for (int end = offset + bucketSize; offset < end; offset += 4) {
/*  675 */       int len = hashArea[(offset + 3)];
/*  676 */       if ((q1 == hashArea[offset]) && (q2 == hashArea[(offset + 1)]) && (2 == len)) {
/*  677 */         return this._names[(offset >> 2)];
/*      */       }
/*  679 */       if (len == 0) {
/*  680 */         return null;
/*      */       }
/*      */     }
/*  683 */     for (offset = _spilloverStart(); offset < this._spilloverEnd; offset += 4) {
/*  684 */       if ((q1 == hashArea[offset]) && (q2 == hashArea[(offset + 1)]) && (2 == hashArea[(offset + 3)])) {
/*  685 */         return this._names[(offset >> 2)];
/*      */       }
/*      */     }
/*  688 */     return null;
/*      */   }
/*      */   
/*      */   private String _findSecondary(int origOffset, int q1, int q2, int q3)
/*      */   {
/*  693 */     int offset = this._tertiaryStart + (origOffset >> this._tertiaryShift + 2 << this._tertiaryShift);
/*  694 */     int[] hashArea = this._hashArea;
/*      */     
/*  696 */     int bucketSize = 1 << this._tertiaryShift;
/*  697 */     for (int end = offset + bucketSize; offset < end; offset += 4) {
/*  698 */       int len = hashArea[(offset + 3)];
/*  699 */       if ((q1 == hashArea[offset]) && (q2 == hashArea[(offset + 1)]) && (q3 == hashArea[(offset + 2)]) && (3 == len)) {
/*  700 */         return this._names[(offset >> 2)];
/*      */       }
/*  702 */       if (len == 0) {
/*  703 */         return null;
/*      */       }
/*      */     }
/*  706 */     for (offset = _spilloverStart(); offset < this._spilloverEnd; offset += 4) {
/*  707 */       if ((q1 == hashArea[offset]) && (q2 == hashArea[(offset + 1)]) && (q3 == hashArea[(offset + 2)]) && (3 == hashArea[(offset + 3)]))
/*      */       {
/*  709 */         return this._names[(offset >> 2)];
/*      */       }
/*      */     }
/*  712 */     return null;
/*      */   }
/*      */   
/*      */   private String _findSecondary(int origOffset, int hash, int[] q, int qlen)
/*      */   {
/*  717 */     int offset = this._tertiaryStart + (origOffset >> this._tertiaryShift + 2 << this._tertiaryShift);
/*  718 */     int[] hashArea = this._hashArea;
/*      */     
/*  720 */     int bucketSize = 1 << this._tertiaryShift;
/*  721 */     for (int end = offset + bucketSize; offset < end; offset += 4) {
/*  722 */       int len = hashArea[(offset + 3)];
/*  723 */       if ((hash == hashArea[offset]) && (qlen == len) && 
/*  724 */         (_verifyLongName(q, qlen, hashArea[(offset + 1)]))) {
/*  725 */         return this._names[(offset >> 2)];
/*      */       }
/*      */       
/*  728 */       if (len == 0) {
/*  729 */         return null;
/*      */       }
/*      */     }
/*  732 */     for (offset = _spilloverStart(); offset < this._spilloverEnd; offset += 4) {
/*  733 */       if ((hash == hashArea[offset]) && (qlen == hashArea[(offset + 3)]) && 
/*  734 */         (_verifyLongName(q, qlen, hashArea[(offset + 1)]))) {
/*  735 */         return this._names[(offset >> 2)];
/*      */       }
/*      */     }
/*      */     
/*  739 */     return null;
/*      */   }
/*      */   
/*      */   private boolean _verifyLongName(int[] q, int qlen, int spillOffset)
/*      */   {
/*  744 */     int[] hashArea = this._hashArea;
/*      */     
/*  746 */     int ix = 0;
/*      */     
/*  748 */     switch (qlen) {
/*      */     default: 
/*  750 */       return _verifyLongName2(q, qlen, spillOffset);
/*      */     case 8: 
/*  752 */       if (q[(ix++)] != hashArea[(spillOffset++)]) return false;
/*      */     case 7: 
/*  754 */       if (q[(ix++)] != hashArea[(spillOffset++)]) return false;
/*      */     case 6: 
/*  756 */       if (q[(ix++)] != hashArea[(spillOffset++)]) return false;
/*      */     case 5: 
/*  758 */       if (q[(ix++)] != hashArea[(spillOffset++)]) return false;
/*      */       break; }
/*  760 */     if (q[(ix++)] != hashArea[(spillOffset++)]) return false;
/*  761 */     if (q[(ix++)] != hashArea[(spillOffset++)]) return false;
/*  762 */     if (q[(ix++)] != hashArea[(spillOffset++)]) return false;
/*  763 */     if (q[(ix++)] != hashArea[(spillOffset++)]) { return false;
/*      */     }
/*  765 */     return true;
/*      */   }
/*      */   
/*      */   private boolean _verifyLongName2(int[] q, int qlen, int spillOffset)
/*      */   {
/*  770 */     int ix = 0;
/*      */     do {
/*  772 */       if (q[(ix++)] != this._hashArea[(spillOffset++)]) {
/*  773 */         return false;
/*      */       }
/*  775 */     } while (ix < qlen);
/*  776 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String addName(String name, int q1)
/*      */   {
/*  786 */     _verifySharing();
/*  787 */     if (this._intern) {
/*  788 */       name = InternCache.instance.intern(name);
/*      */     }
/*  790 */     int offset = _findOffsetForAdd(calcHash(q1));
/*  791 */     this._hashArea[offset] = q1;
/*  792 */     this._hashArea[(offset + 3)] = 1;
/*  793 */     this._names[(offset >> 2)] = name;
/*  794 */     this._count += 1;
/*  795 */     return name;
/*      */   }
/*      */   
/*      */   public String addName(String name, int q1, int q2) {
/*  799 */     _verifySharing();
/*  800 */     if (this._intern) {
/*  801 */       name = InternCache.instance.intern(name);
/*      */     }
/*  803 */     int hash = q2 == 0 ? calcHash(q1) : calcHash(q1, q2);
/*  804 */     int offset = _findOffsetForAdd(hash);
/*  805 */     this._hashArea[offset] = q1;
/*  806 */     this._hashArea[(offset + 1)] = q2;
/*  807 */     this._hashArea[(offset + 3)] = 2;
/*  808 */     this._names[(offset >> 2)] = name;
/*  809 */     this._count += 1;
/*  810 */     return name;
/*      */   }
/*      */   
/*      */   public String addName(String name, int q1, int q2, int q3) {
/*  814 */     _verifySharing();
/*  815 */     if (this._intern) {
/*  816 */       name = InternCache.instance.intern(name);
/*      */     }
/*  818 */     int offset = _findOffsetForAdd(calcHash(q1, q2, q3));
/*  819 */     this._hashArea[offset] = q1;
/*  820 */     this._hashArea[(offset + 1)] = q2;
/*  821 */     this._hashArea[(offset + 2)] = q3;
/*  822 */     this._hashArea[(offset + 3)] = 3;
/*  823 */     this._names[(offset >> 2)] = name;
/*  824 */     this._count += 1;
/*  825 */     return name;
/*      */   }
/*      */   
/*      */   public String addName(String name, int[] q, int qlen)
/*      */   {
/*  830 */     _verifySharing();
/*  831 */     if (this._intern) {
/*  832 */       name = InternCache.instance.intern(name);
/*      */     }
/*      */     
/*      */     int offset;
/*  836 */     switch (qlen)
/*      */     {
/*      */     case 1: 
/*  839 */       int offset = _findOffsetForAdd(calcHash(q[0]));
/*  840 */       this._hashArea[offset] = q[0];
/*  841 */       this._hashArea[(offset + 3)] = 1;
/*      */       
/*  843 */       break;
/*      */     
/*      */     case 2: 
/*  846 */       int offset = _findOffsetForAdd(calcHash(q[0], q[1]));
/*  847 */       this._hashArea[offset] = q[0];
/*  848 */       this._hashArea[(offset + 1)] = q[1];
/*  849 */       this._hashArea[(offset + 3)] = 2;
/*      */       
/*  851 */       break;
/*      */     
/*      */     case 3: 
/*  854 */       int offset = _findOffsetForAdd(calcHash(q[0], q[1], q[2]));
/*  855 */       this._hashArea[offset] = q[0];
/*  856 */       this._hashArea[(offset + 1)] = q[1];
/*  857 */       this._hashArea[(offset + 2)] = q[2];
/*  858 */       this._hashArea[(offset + 3)] = 3;
/*      */       
/*  860 */       break;
/*      */     default: 
/*  862 */       int hash = calcHash(q, qlen);
/*  863 */       offset = _findOffsetForAdd(hash);
/*      */       
/*  865 */       this._hashArea[offset] = hash;
/*  866 */       int longStart = _appendLongName(q, qlen);
/*  867 */       this._hashArea[(offset + 1)] = longStart;
/*  868 */       this._hashArea[(offset + 3)] = qlen;
/*      */     }
/*      */     
/*  871 */     this._names[(offset >> 2)] = name;
/*      */     
/*      */ 
/*  874 */     this._count += 1;
/*  875 */     return name;
/*      */   }
/*      */   
/*      */   private void _verifySharing()
/*      */   {
/*  880 */     if (this._hashShared) {
/*  881 */       this._hashArea = Arrays.copyOf(this._hashArea, this._hashArea.length);
/*  882 */       this._names = ((String[])Arrays.copyOf(this._names, this._names.length));
/*  883 */       this._hashShared = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int _findOffsetForAdd(int hash)
/*      */   {
/*  893 */     int offset = _calcOffset(hash);
/*  894 */     int[] hashArea = this._hashArea;
/*  895 */     if (hashArea[(offset + 3)] == 0)
/*      */     {
/*  897 */       return offset;
/*      */     }
/*      */     
/*      */ 
/*  901 */     if (_checkNeedForRehash()) {
/*  902 */       return _resizeAndFindOffsetForAdd(hash);
/*      */     }
/*      */     
/*      */ 
/*  906 */     int offset2 = this._secondaryStart + (offset >> 3 << 2);
/*  907 */     if (hashArea[(offset2 + 3)] == 0)
/*      */     {
/*  909 */       return offset2;
/*      */     }
/*      */     
/*      */ 
/*  913 */     offset2 = this._tertiaryStart + (offset >> this._tertiaryShift + 2 << this._tertiaryShift);
/*  914 */     int bucketSize = 1 << this._tertiaryShift;
/*  915 */     for (int end = offset2 + bucketSize; offset2 < end; offset2 += 4) {
/*  916 */       if (hashArea[(offset2 + 3)] == 0)
/*      */       {
/*  918 */         return offset2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  923 */     offset = this._spilloverEnd;
/*  924 */     this._spilloverEnd += 4;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  934 */     int end = this._hashSize << 3;
/*  935 */     if (this._spilloverEnd >= end) {
/*  936 */       if (this._failOnDoS) {
/*  937 */         _reportTooManyCollisions();
/*      */       }
/*  939 */       return _resizeAndFindOffsetForAdd(hash);
/*      */     }
/*  941 */     return offset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int _resizeAndFindOffsetForAdd(int hash)
/*      */   {
/*  948 */     rehash();
/*      */     
/*      */ 
/*  951 */     int offset = _calcOffset(hash);
/*  952 */     int[] hashArea = this._hashArea;
/*  953 */     if (hashArea[(offset + 3)] == 0) {
/*  954 */       return offset;
/*      */     }
/*  956 */     int offset2 = this._secondaryStart + (offset >> 3 << 2);
/*  957 */     if (hashArea[(offset2 + 3)] == 0) {
/*  958 */       return offset2;
/*      */     }
/*  960 */     offset2 = this._tertiaryStart + (offset >> this._tertiaryShift + 2 << this._tertiaryShift);
/*  961 */     int bucketSize = 1 << this._tertiaryShift;
/*  962 */     for (int end = offset2 + bucketSize; offset2 < end; offset2 += 4) {
/*  963 */       if (hashArea[(offset2 + 3)] == 0) {
/*  964 */         return offset2;
/*      */       }
/*      */     }
/*  967 */     offset = this._spilloverEnd;
/*  968 */     this._spilloverEnd += 4;
/*  969 */     return offset;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean _checkNeedForRehash()
/*      */   {
/*  975 */     if (this._count > this._hashSize >> 1) {
/*  976 */       int spillCount = this._spilloverEnd - _spilloverStart() >> 2;
/*  977 */       if ((spillCount > 1 + this._count >> 7) || (this._count > this._hashSize * 0.8D))
/*      */       {
/*  979 */         return true;
/*      */       }
/*      */     }
/*  982 */     return false;
/*      */   }
/*      */   
/*      */   private int _appendLongName(int[] quads, int qlen)
/*      */   {
/*  987 */     int start = this._longNameOffset;
/*      */     
/*      */ 
/*  990 */     if (start + qlen > this._hashArea.length)
/*      */     {
/*  992 */       int toAdd = start + qlen - this._hashArea.length;
/*      */       
/*  994 */       int minAdd = Math.min(4096, this._hashSize);
/*      */       
/*  996 */       int newSize = this._hashArea.length + Math.max(toAdd, minAdd);
/*  997 */       this._hashArea = Arrays.copyOf(this._hashArea, newSize);
/*      */     }
/*  999 */     System.arraycopy(quads, 0, this._hashArea, start, qlen);
/* 1000 */     this._longNameOffset += qlen;
/* 1001 */     return start;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int calcHash(int q1)
/*      */   {
/* 1026 */     int hash = q1 ^ this._seed;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1032 */     hash += (hash >>> 16);
/* 1033 */     hash ^= hash << 3;
/* 1034 */     hash += (hash >>> 12);
/* 1035 */     return hash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int calcHash(int q1, int q2)
/*      */   {
/* 1042 */     int hash = q1;
/*      */     
/* 1044 */     hash += (hash >>> 15);
/* 1045 */     hash ^= hash >>> 9;
/* 1046 */     hash += q2 * 33;
/* 1047 */     hash ^= this._seed;
/* 1048 */     hash += (hash >>> 16);
/* 1049 */     hash ^= hash >>> 4;
/* 1050 */     hash += (hash << 3);
/*      */     
/* 1052 */     return hash;
/*      */   }
/*      */   
/*      */   public int calcHash(int q1, int q2, int q3)
/*      */   {
/* 1057 */     int hash = q1 ^ this._seed;
/* 1058 */     hash += (hash >>> 9);
/* 1059 */     hash *= 31;
/* 1060 */     hash += q2;
/* 1061 */     hash *= 33;
/* 1062 */     hash += (hash >>> 15);
/* 1063 */     hash ^= q3;
/*      */     
/* 1065 */     hash += (hash >>> 4);
/*      */     
/* 1067 */     hash += (hash >>> 15);
/* 1068 */     hash ^= hash << 9;
/*      */     
/* 1070 */     return hash;
/*      */   }
/*      */   
/*      */   public int calcHash(int[] q, int qlen)
/*      */   {
/* 1075 */     if (qlen < 4) {
/* 1076 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1083 */     int hash = q[0] ^ this._seed;
/* 1084 */     hash += (hash >>> 9);
/* 1085 */     hash += q[1];
/* 1086 */     hash += (hash >>> 15);
/* 1087 */     hash *= 33;
/* 1088 */     hash ^= q[2];
/* 1089 */     hash += (hash >>> 4);
/*      */     
/* 1091 */     for (int i = 3; i < qlen; i++) {
/* 1092 */       int next = q[i];
/* 1093 */       next ^= next >> 21;
/* 1094 */       hash += next;
/*      */     }
/* 1096 */     hash *= 65599;
/*      */     
/*      */ 
/* 1099 */     hash += (hash >>> 19);
/* 1100 */     hash ^= hash << 5;
/* 1101 */     return hash;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void rehash()
/*      */   {
/* 1113 */     this._hashShared = false;
/*      */     
/*      */ 
/*      */ 
/* 1117 */     int[] oldHashArea = this._hashArea;
/* 1118 */     String[] oldNames = this._names;
/* 1119 */     int oldSize = this._hashSize;
/* 1120 */     int oldCount = this._count;
/* 1121 */     int newSize = oldSize + oldSize;
/* 1122 */     int oldEnd = this._spilloverEnd;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1127 */     if (newSize > 65536) {
/* 1128 */       nukeSymbols(true);
/* 1129 */       return;
/*      */     }
/*      */     
/* 1132 */     this._hashArea = new int[oldHashArea.length + (oldSize << 3)];
/* 1133 */     this._hashSize = newSize;
/* 1134 */     this._secondaryStart = (newSize << 2);
/* 1135 */     this._tertiaryStart = (this._secondaryStart + (this._secondaryStart >> 1));
/* 1136 */     this._tertiaryShift = _calcTertiaryShift(newSize);
/*      */     
/*      */ 
/* 1139 */     this._names = new String[oldNames.length << 1];
/* 1140 */     nukeSymbols(false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1147 */     int copyCount = 0;
/* 1148 */     int[] q = new int[16];
/* 1149 */     int offset = 0; for (int end = oldEnd; offset < end; offset += 4) {
/* 1150 */       int len = oldHashArea[(offset + 3)];
/* 1151 */       if (len != 0)
/*      */       {
/*      */ 
/* 1154 */         copyCount++;
/* 1155 */         String name = oldNames[(offset >> 2)];
/* 1156 */         switch (len) {
/*      */         case 1: 
/* 1158 */           q[0] = oldHashArea[offset];
/* 1159 */           addName(name, q, 1);
/* 1160 */           break;
/*      */         case 2: 
/* 1162 */           q[0] = oldHashArea[offset];
/* 1163 */           q[1] = oldHashArea[(offset + 1)];
/* 1164 */           addName(name, q, 2);
/* 1165 */           break;
/*      */         case 3: 
/* 1167 */           q[0] = oldHashArea[offset];
/* 1168 */           q[1] = oldHashArea[(offset + 1)];
/* 1169 */           q[2] = oldHashArea[(offset + 2)];
/* 1170 */           addName(name, q, 3);
/* 1171 */           break;
/*      */         default: 
/* 1173 */           if (len > q.length) {
/* 1174 */             q = new int[len];
/*      */           }
/*      */           
/* 1177 */           int qoff = oldHashArea[(offset + 1)];
/* 1178 */           System.arraycopy(oldHashArea, qoff, q, 0, len);
/* 1179 */           addName(name, q, len);
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1186 */     if (copyCount != oldCount) {
/* 1187 */       throw new IllegalStateException("Failed rehash(): old count=" + oldCount + ", copyCount=" + copyCount);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void nukeSymbols(boolean fill)
/*      */   {
/* 1196 */     this._count = 0;
/*      */     
/* 1198 */     this._spilloverEnd = _spilloverStart();
/*      */     
/* 1200 */     this._longNameOffset = (this._hashSize << 3);
/* 1201 */     if (fill) {
/* 1202 */       Arrays.fill(this._hashArea, 0);
/* 1203 */       Arrays.fill(this._names, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int _spilloverStart()
/*      */   {
/* 1219 */     int offset = this._hashSize;
/* 1220 */     return (offset << 3) - offset;
/*      */   }
/*      */   
/*      */ 
/*      */   protected void _reportTooManyCollisions()
/*      */   {
/* 1226 */     if (this._hashSize <= 1024) {
/* 1227 */       return;
/*      */     }
/* 1229 */     throw new IllegalStateException("Spill-over slots in symbol table with " + this._count + " entries, hash area of " + this._hashSize + " slots is now full (all " + (this._hashSize >> 3) + " slots -- suspect a DoS attack based on hash collisions. You can disable the check via `JsonFactory.Feature.FAIL_ON_SYMBOL_HASH_OVERFLOW`");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int _calcTertiaryShift(int primarySlots)
/*      */   {
/* 1238 */     int tertSlots = primarySlots >> 2;
/*      */     
/*      */ 
/* 1241 */     if (tertSlots < 64) {
/* 1242 */       return 4;
/*      */     }
/* 1244 */     if (tertSlots <= 256) {
/* 1245 */       return 5;
/*      */     }
/* 1247 */     if (tertSlots <= 1024) {
/* 1248 */       return 6;
/*      */     }
/*      */     
/* 1251 */     return 7;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static final class TableInfo
/*      */   {
/*      */     public final int size;
/*      */     
/*      */ 
/*      */     public final int count;
/*      */     
/*      */ 
/*      */     public final int tertiaryShift;
/*      */     
/*      */ 
/*      */     public final int[] mainHash;
/*      */     
/*      */ 
/*      */     public final String[] names;
/*      */     
/*      */ 
/*      */     public final int spilloverEnd;
/*      */     
/*      */     public final int longNameOffset;
/*      */     
/*      */ 
/*      */     public TableInfo(int size, int count, int tertiaryShift, int[] mainHash, String[] names, int spilloverEnd, int longNameOffset)
/*      */     {
/* 1280 */       this.size = size;
/* 1281 */       this.count = count;
/* 1282 */       this.tertiaryShift = tertiaryShift;
/* 1283 */       this.mainHash = mainHash;
/* 1284 */       this.names = names;
/* 1285 */       this.spilloverEnd = spilloverEnd;
/* 1286 */       this.longNameOffset = longNameOffset;
/*      */     }
/*      */     
/*      */     public TableInfo(ByteQuadsCanonicalizer src)
/*      */     {
/* 1291 */       this.size = src._hashSize;
/* 1292 */       this.count = src._count;
/* 1293 */       this.tertiaryShift = src._tertiaryShift;
/* 1294 */       this.mainHash = src._hashArea;
/* 1295 */       this.names = src._names;
/* 1296 */       this.spilloverEnd = src._spilloverEnd;
/* 1297 */       this.longNameOffset = src._longNameOffset;
/*      */     }
/*      */     
/*      */     public static TableInfo createInitial(int sz) {
/* 1301 */       int hashAreaSize = sz << 3;
/* 1302 */       int tertShift = ByteQuadsCanonicalizer._calcTertiaryShift(sz);
/*      */       
/* 1304 */       return new TableInfo(sz, 0, tertShift, new int[hashAreaSize], new String[sz << 1], hashAreaSize - sz, hashAreaSize);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\sym\ByteQuadsCanonicalizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */