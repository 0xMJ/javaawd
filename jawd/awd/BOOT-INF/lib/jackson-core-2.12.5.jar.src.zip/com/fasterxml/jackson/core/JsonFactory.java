/*      */ package com.fasterxml.jackson.core;
/*      */ 
/*      */ import com.fasterxml.jackson.core.format.InputAccessor;
/*      */ import com.fasterxml.jackson.core.format.MatchStrength;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.InputDecorator;
/*      */ import com.fasterxml.jackson.core.io.OutputDecorator;
/*      */ import com.fasterxml.jackson.core.io.SerializedString;
/*      */ import com.fasterxml.jackson.core.io.UTF8Writer;
/*      */ import com.fasterxml.jackson.core.json.ByteSourceJsonBootstrapper;
/*      */ import com.fasterxml.jackson.core.json.PackageVersion;
/*      */ import com.fasterxml.jackson.core.json.ReaderBasedJsonParser;
/*      */ import com.fasterxml.jackson.core.json.UTF8DataInputJsonParser;
/*      */ import com.fasterxml.jackson.core.json.UTF8JsonGenerator;
/*      */ import com.fasterxml.jackson.core.json.WriterBasedJsonGenerator;
/*      */ import com.fasterxml.jackson.core.json.async.NonBlockingJsonParser;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.BufferRecycler;
/*      */ import com.fasterxml.jackson.core.util.BufferRecyclers;
/*      */ import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*      */ import java.io.CharArrayReader;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringReader;
/*      */ import java.io.Writer;
/*      */ import java.net.URL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JsonFactory
/*      */   extends TokenStreamFactory
/*      */   implements Versioned, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 2L;
/*      */   public static final String FORMAT_NAME_JSON = "JSON";
/*      */   
/*      */   public static enum Feature
/*      */     implements JacksonFeature
/*      */   {
/*   81 */     INTERN_FIELD_NAMES(true), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   91 */     CANONICALIZE_FIELD_NAMES(true), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  107 */     FAIL_ON_SYMBOL_HASH_OVERFLOW(true), 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  124 */     USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING(true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final boolean _defaultState;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static int collectDefaults()
/*      */     {
/*  140 */       int flags = 0;
/*  141 */       for (Feature f : values()) {
/*  142 */         if (f.enabledByDefault()) flags |= f.getMask();
/*      */       }
/*  144 */       return flags;
/*      */     }
/*      */     
/*  147 */     private Feature(boolean defaultState) { this._defaultState = defaultState; }
/*      */     
/*      */ 
/*  150 */     public boolean enabledByDefault() { return this._defaultState; }
/*      */     
/*  152 */     public boolean enabledIn(int flags) { return (flags & getMask()) != 0; }
/*      */     
/*  154 */     public int getMask() { return 1 << ordinal(); }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  172 */   protected static final int DEFAULT_FACTORY_FEATURE_FLAGS = ;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  178 */   protected static final int DEFAULT_PARSER_FEATURE_FLAGS = JsonParser.Feature.collectDefaults();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  184 */   protected static final int DEFAULT_GENERATOR_FEATURE_FLAGS = JsonGenerator.Feature.collectDefaults();
/*      */   
/*  186 */   public static final SerializableString DEFAULT_ROOT_VALUE_SEPARATOR = DefaultPrettyPrinter.DEFAULT_ROOT_VALUE_SEPARATOR;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final char DEFAULT_QUOTE_CHAR = '"';
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  204 */   protected final transient CharsToNameCanonicalizer _rootCharSymbols = CharsToNameCanonicalizer.createRoot();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  215 */   protected final transient ByteQuadsCanonicalizer _byteSymbolCanonicalizer = ByteQuadsCanonicalizer.createRoot();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  226 */   protected int _factoryFeatures = DEFAULT_FACTORY_FEATURE_FLAGS;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  231 */   protected int _parserFeatures = DEFAULT_PARSER_FEATURE_FLAGS;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  236 */   protected int _generatorFeatures = DEFAULT_GENERATOR_FEATURE_FLAGS;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectCodec _objectCodec;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected CharacterEscapes _characterEscapes;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InputDecorator _inputDecorator;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected OutputDecorator _outputDecorator;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  279 */   protected SerializableString _rootValueSeparator = DEFAULT_ROOT_VALUE_SEPARATOR;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _maximumNonEscapedChar;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final char _quoteChar;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  314 */   public JsonFactory() { this((ObjectCodec)null); }
/*      */   
/*      */   public JsonFactory(ObjectCodec oc) {
/*  317 */     this._objectCodec = oc;
/*  318 */     this._quoteChar = '"';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonFactory(JsonFactory src, ObjectCodec codec)
/*      */   {
/*  331 */     this._objectCodec = codec;
/*      */     
/*      */ 
/*  334 */     this._factoryFeatures = src._factoryFeatures;
/*  335 */     this._parserFeatures = src._parserFeatures;
/*  336 */     this._generatorFeatures = src._generatorFeatures;
/*  337 */     this._inputDecorator = src._inputDecorator;
/*  338 */     this._outputDecorator = src._outputDecorator;
/*      */     
/*      */ 
/*  341 */     this._characterEscapes = src._characterEscapes;
/*  342 */     this._rootValueSeparator = src._rootValueSeparator;
/*  343 */     this._maximumNonEscapedChar = src._maximumNonEscapedChar;
/*  344 */     this._quoteChar = src._quoteChar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonFactory(JsonFactoryBuilder b)
/*      */   {
/*  355 */     this._objectCodec = null;
/*      */     
/*      */ 
/*  358 */     this._factoryFeatures = b._factoryFeatures;
/*  359 */     this._parserFeatures = b._streamReadFeatures;
/*  360 */     this._generatorFeatures = b._streamWriteFeatures;
/*  361 */     this._inputDecorator = b._inputDecorator;
/*  362 */     this._outputDecorator = b._outputDecorator;
/*      */     
/*      */ 
/*  365 */     this._characterEscapes = b._characterEscapes;
/*  366 */     this._rootValueSeparator = b._rootValueSeparator;
/*  367 */     this._maximumNonEscapedChar = b._maximumNonEscapedChar;
/*  368 */     this._quoteChar = b._quoteChar;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonFactory(TSFBuilder<?, ?> b, boolean bogus)
/*      */   {
/*  380 */     this._objectCodec = null;
/*      */     
/*  382 */     this._factoryFeatures = b._factoryFeatures;
/*  383 */     this._parserFeatures = b._streamReadFeatures;
/*  384 */     this._generatorFeatures = b._streamWriteFeatures;
/*  385 */     this._inputDecorator = b._inputDecorator;
/*  386 */     this._outputDecorator = b._outputDecorator;
/*      */     
/*      */ 
/*  389 */     this._characterEscapes = null;
/*  390 */     this._rootValueSeparator = null;
/*  391 */     this._maximumNonEscapedChar = 0;
/*  392 */     this._quoteChar = '"';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TSFBuilder<?, ?> rebuild()
/*      */   {
/*  405 */     _requireJSONFactory("Factory implementation for format (%s) MUST override `rebuild()` method");
/*  406 */     return new JsonFactoryBuilder(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static TSFBuilder<?, ?> builder()
/*      */   {
/*  421 */     return new JsonFactoryBuilder();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonFactory copy()
/*      */   {
/*  442 */     _checkInvalidCopy(JsonFactory.class);
/*      */     
/*  444 */     return new JsonFactory(this, null);
/*      */   }
/*      */   
/*      */   protected void _checkInvalidCopy(Class<?> exp)
/*      */   {
/*  449 */     if (getClass() != exp)
/*      */     {
/*  451 */       throw new IllegalStateException("Failed copy(): " + getClass().getName() + " (version: " + version() + ") does not override copy(); it has to");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object readResolve()
/*      */   {
/*  471 */     return new JsonFactory(this, this._objectCodec);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean requiresPropertyOrdering()
/*      */   {
/*  499 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canHandleBinaryNatively()
/*      */   {
/*  517 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canUseCharArrays()
/*      */   {
/*  534 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canParseAsync()
/*      */   {
/*  551 */     return _isJSONFactory();
/*      */   }
/*      */   
/*      */   public Class<? extends FormatFeature> getFormatReadFeatureType()
/*      */   {
/*  556 */     return null;
/*      */   }
/*      */   
/*      */   public Class<? extends FormatFeature> getFormatWriteFeatureType()
/*      */   {
/*  561 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canUseSchema(FormatSchema schema)
/*      */   {
/*  585 */     if (schema == null) {
/*  586 */       return false;
/*      */     }
/*  588 */     String ourFormat = getFormatName();
/*  589 */     return (ourFormat != null) && (ourFormat.equals(schema.getSchemaType()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFormatName()
/*      */   {
/*  608 */     if (getClass() == JsonFactory.class) {
/*  609 */       return "JSON";
/*      */     }
/*  611 */     return null;
/*      */   }
/*      */   
/*      */   public MatchStrength hasFormat(InputAccessor acc)
/*      */     throws IOException
/*      */   {
/*  617 */     if (getClass() == JsonFactory.class) {
/*  618 */       return hasJSONFormat(acc);
/*      */     }
/*  620 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean requiresCustomCodec()
/*      */   {
/*  637 */     return false;
/*      */   }
/*      */   
/*      */   protected MatchStrength hasJSONFormat(InputAccessor acc) throws IOException {
/*  641 */     return ByteSourceJsonBootstrapper.hasJSONFormat(acc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Version version()
/*      */   {
/*  652 */     return PackageVersion.VERSION;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final JsonFactory configure(Feature f, boolean state)
/*      */   {
/*  674 */     return state ? enable(f) : disable(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonFactory enable(Feature f)
/*      */   {
/*  689 */     this._factoryFeatures |= f.getMask();
/*  690 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonFactory disable(Feature f)
/*      */   {
/*  705 */     this._factoryFeatures &= (f.getMask() ^ 0xFFFFFFFF);
/*  706 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isEnabled(Feature f)
/*      */   {
/*  717 */     return (this._factoryFeatures & f.getMask()) != 0;
/*      */   }
/*      */   
/*      */   public final int getParserFeatures()
/*      */   {
/*  722 */     return this._parserFeatures;
/*      */   }
/*      */   
/*      */   public final int getGeneratorFeatures()
/*      */   {
/*  727 */     return this._generatorFeatures;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getFormatParserFeatures()
/*      */   {
/*  733 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getFormatGeneratorFeatures()
/*      */   {
/*  739 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final JsonFactory configure(JsonParser.Feature f, boolean state)
/*      */   {
/*  758 */     return state ? enable(f) : disable(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonFactory enable(JsonParser.Feature f)
/*      */   {
/*  770 */     this._parserFeatures |= f.getMask();
/*  771 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonFactory disable(JsonParser.Feature f)
/*      */   {
/*  783 */     this._parserFeatures &= (f.getMask() ^ 0xFFFFFFFF);
/*  784 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isEnabled(JsonParser.Feature f)
/*      */   {
/*  796 */     return (this._parserFeatures & f.getMask()) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isEnabled(StreamReadFeature f)
/*      */   {
/*  809 */     return (this._parserFeatures & f.mappedFeature().getMask()) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputDecorator getInputDecorator()
/*      */   {
/*  819 */     return this._inputDecorator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonFactory setInputDecorator(InputDecorator d)
/*      */   {
/*  833 */     this._inputDecorator = d;
/*  834 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final JsonFactory configure(JsonGenerator.Feature f, boolean state)
/*      */   {
/*  853 */     return state ? enable(f) : disable(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonFactory enable(JsonGenerator.Feature f)
/*      */   {
/*  865 */     this._generatorFeatures |= f.getMask();
/*  866 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonFactory disable(JsonGenerator.Feature f)
/*      */   {
/*  878 */     this._generatorFeatures &= (f.getMask() ^ 0xFFFFFFFF);
/*  879 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isEnabled(JsonGenerator.Feature f)
/*      */   {
/*  891 */     return (this._generatorFeatures & f.getMask()) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isEnabled(StreamWriteFeature f)
/*      */   {
/*  904 */     return (this._generatorFeatures & f.mappedFeature().getMask()) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CharacterEscapes getCharacterEscapes()
/*      */   {
/*  913 */     return this._characterEscapes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonFactory setCharacterEscapes(CharacterEscapes esc)
/*      */   {
/*  924 */     this._characterEscapes = esc;
/*  925 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public OutputDecorator getOutputDecorator()
/*      */   {
/*  936 */     return this._outputDecorator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonFactory setOutputDecorator(OutputDecorator d)
/*      */   {
/*  950 */     this._outputDecorator = d;
/*  951 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonFactory setRootValueSeparator(String sep)
/*      */   {
/*  964 */     this._rootValueSeparator = (sep == null ? null : new SerializedString(sep));
/*  965 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getRootValueSeparator()
/*      */   {
/*  972 */     return this._rootValueSeparator == null ? null : this._rootValueSeparator.getValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonFactory setCodec(ObjectCodec oc)
/*      */   {
/*  993 */     this._objectCodec = oc;
/*  994 */     return this;
/*      */   }
/*      */   
/*  997 */   public ObjectCodec getCodec() { return this._objectCodec; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(File f)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1028 */     IOContext ctxt = _createContext(f, true);
/* 1029 */     InputStream in = new FileInputStream(f);
/* 1030 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(URL url)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1056 */     IOContext ctxt = _createContext(url, true);
/* 1057 */     InputStream in = _optimizedStreamFromURL(url);
/* 1058 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(InputStream in)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1084 */     IOContext ctxt = _createContext(in, false);
/* 1085 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(Reader r)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1105 */     IOContext ctxt = _createContext(r, false);
/* 1106 */     return _createParser(_decorate(r, ctxt), ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(byte[] data)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1117 */     IOContext ctxt = _createContext(data, true);
/* 1118 */     if (this._inputDecorator != null) {
/* 1119 */       InputStream in = this._inputDecorator.decorate(ctxt, data, 0, data.length);
/* 1120 */       if (in != null) {
/* 1121 */         return _createParser(in, ctxt);
/*      */       }
/*      */     }
/* 1124 */     return _createParser(data, 0, data.length, ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(byte[] data, int offset, int len)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1139 */     IOContext ctxt = _createContext(data, true);
/*      */     
/* 1141 */     if (this._inputDecorator != null) {
/* 1142 */       InputStream in = this._inputDecorator.decorate(ctxt, data, offset, len);
/* 1143 */       if (in != null) {
/* 1144 */         return _createParser(in, ctxt);
/*      */       }
/*      */     }
/* 1147 */     return _createParser(data, offset, len, ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(String content)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1158 */     int strLen = content.length();
/*      */     
/* 1160 */     if ((this._inputDecorator != null) || (strLen > 32768) || (!canUseCharArrays()))
/*      */     {
/*      */ 
/* 1163 */       return createParser(new StringReader(content));
/*      */     }
/* 1165 */     IOContext ctxt = _createContext(content, true);
/* 1166 */     char[] buf = ctxt.allocTokenBuffer(strLen);
/* 1167 */     content.getChars(0, strLen, buf, 0);
/* 1168 */     return _createParser(buf, 0, strLen, ctxt, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(char[] content)
/*      */     throws IOException
/*      */   {
/* 1179 */     return createParser(content, 0, content.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(char[] content, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 1189 */     if (this._inputDecorator != null) {
/* 1190 */       return createParser(new CharArrayReader(content, offset, len));
/*      */     }
/* 1192 */     return _createParser(content, offset, len, _createContext(content, true), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(DataInput in)
/*      */     throws IOException
/*      */   {
/* 1208 */     IOContext ctxt = _createContext(in, false);
/* 1209 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createNonBlockingByteArrayParser()
/*      */     throws IOException
/*      */   {
/* 1239 */     _requireJSONFactory("Non-blocking source not (yet?) supported for this format (%s)");
/* 1240 */     IOContext ctxt = _createNonBlockingContext(null);
/* 1241 */     ByteQuadsCanonicalizer can = this._byteSymbolCanonicalizer.makeChild(this._factoryFeatures);
/* 1242 */     return new NonBlockingJsonParser(ctxt, this._parserFeatures, can);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(OutputStream out, JsonEncoding enc)
/*      */     throws IOException
/*      */   {
/* 1278 */     IOContext ctxt = _createContext(out, false);
/* 1279 */     ctxt.setEncoding(enc);
/* 1280 */     if (enc == JsonEncoding.UTF8) {
/* 1281 */       return _createUTF8Generator(_decorate(out, ctxt), ctxt);
/*      */     }
/* 1283 */     Writer w = _createWriter(out, enc, ctxt);
/* 1284 */     return _createGenerator(_decorate(w, ctxt), ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(OutputStream out)
/*      */     throws IOException
/*      */   {
/* 1297 */     return createGenerator(out, JsonEncoding.UTF8);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(Writer w)
/*      */     throws IOException
/*      */   {
/* 1317 */     IOContext ctxt = _createContext(w, false);
/* 1318 */     return _createGenerator(_decorate(w, ctxt), ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(File f, JsonEncoding enc)
/*      */     throws IOException
/*      */   {
/* 1340 */     OutputStream out = new FileOutputStream(f);
/*      */     
/* 1342 */     IOContext ctxt = _createContext(out, true);
/* 1343 */     ctxt.setEncoding(enc);
/* 1344 */     if (enc == JsonEncoding.UTF8) {
/* 1345 */       return _createUTF8Generator(_decorate(out, ctxt), ctxt);
/*      */     }
/* 1347 */     Writer w = _createWriter(out, enc, ctxt);
/* 1348 */     return _createGenerator(_decorate(w, ctxt), ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(DataOutput out, JsonEncoding enc)
/*      */     throws IOException
/*      */   {
/* 1359 */     return createGenerator(_createDataOutputWrapper(out), enc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(DataOutput out)
/*      */     throws IOException
/*      */   {
/* 1372 */     return createGenerator(_createDataOutputWrapper(out), JsonEncoding.UTF8);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(File f)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1407 */     return createParser(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(URL url)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1435 */     return createParser(url);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(InputStream in)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1466 */     return createParser(in);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(Reader r)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1490 */     return createParser(r);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(byte[] data)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1507 */     return createParser(data);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(byte[] data, int offset, int len)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1527 */     return createParser(data, offset, len);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(String content)
/*      */     throws IOException, JsonParseException
/*      */   {
/* 1545 */     return createParser(content);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonGenerator createJsonGenerator(OutputStream out, JsonEncoding enc)
/*      */     throws IOException
/*      */   {
/* 1582 */     return createGenerator(out, enc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonGenerator createJsonGenerator(Writer out)
/*      */     throws IOException
/*      */   {
/* 1606 */     return createGenerator(out);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonGenerator createJsonGenerator(OutputStream out)
/*      */     throws IOException
/*      */   {
/* 1625 */     return createGenerator(out, JsonEncoding.UTF8);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonParser _createParser(InputStream in, IOContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1656 */     return new ByteSourceJsonBootstrapper(ctxt, in).constructParser(this._parserFeatures, this._objectCodec, this._byteSymbolCanonicalizer, this._rootCharSymbols, this._factoryFeatures);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonParser _createParser(Reader r, IOContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1680 */     return new ReaderBasedJsonParser(ctxt, this._parserFeatures, r, this._objectCodec, this._rootCharSymbols
/* 1681 */       .makeChild(this._factoryFeatures));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonParser _createParser(char[] data, int offset, int len, IOContext ctxt, boolean recyclable)
/*      */     throws IOException
/*      */   {
/* 1702 */     return new ReaderBasedJsonParser(ctxt, this._parserFeatures, null, this._objectCodec, this._rootCharSymbols
/* 1703 */       .makeChild(this._factoryFeatures), data, offset, offset + len, recyclable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonParser _createParser(byte[] data, int offset, int len, IOContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1729 */     return new ByteSourceJsonBootstrapper(ctxt, data, offset, len).constructParser(this._parserFeatures, this._objectCodec, this._byteSymbolCanonicalizer, this._rootCharSymbols, this._factoryFeatures);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonParser _createParser(DataInput input, IOContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1749 */     _requireJSONFactory("InputData source not (yet?) supported for this format (%s)");
/*      */     
/*      */ 
/* 1752 */     int firstByte = ByteSourceJsonBootstrapper.skipUTF8BOM(input);
/* 1753 */     ByteQuadsCanonicalizer can = this._byteSymbolCanonicalizer.makeChild(this._factoryFeatures);
/* 1754 */     return new UTF8DataInputJsonParser(ctxt, this._parserFeatures, input, this._objectCodec, can, firstByte);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonGenerator _createGenerator(Writer out, IOContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1784 */     WriterBasedJsonGenerator gen = new WriterBasedJsonGenerator(ctxt, this._generatorFeatures, this._objectCodec, out, this._quoteChar);
/*      */     
/* 1786 */     if (this._maximumNonEscapedChar > 0) {
/* 1787 */       gen.setHighestNonEscapedChar(this._maximumNonEscapedChar);
/*      */     }
/* 1789 */     if (this._characterEscapes != null) {
/* 1790 */       gen.setCharacterEscapes(this._characterEscapes);
/*      */     }
/* 1792 */     SerializableString rootSep = this._rootValueSeparator;
/* 1793 */     if (rootSep != DEFAULT_ROOT_VALUE_SEPARATOR) {
/* 1794 */       gen.setRootValueSeparator(rootSep);
/*      */     }
/* 1796 */     return gen;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonGenerator _createUTF8Generator(OutputStream out, IOContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1817 */     UTF8JsonGenerator gen = new UTF8JsonGenerator(ctxt, this._generatorFeatures, this._objectCodec, out, this._quoteChar);
/*      */     
/* 1819 */     if (this._maximumNonEscapedChar > 0) {
/* 1820 */       gen.setHighestNonEscapedChar(this._maximumNonEscapedChar);
/*      */     }
/* 1822 */     if (this._characterEscapes != null) {
/* 1823 */       gen.setCharacterEscapes(this._characterEscapes);
/*      */     }
/* 1825 */     SerializableString rootSep = this._rootValueSeparator;
/* 1826 */     if (rootSep != DEFAULT_ROOT_VALUE_SEPARATOR) {
/* 1827 */       gen.setRootValueSeparator(rootSep);
/*      */     }
/* 1829 */     return gen;
/*      */   }
/*      */   
/*      */   protected Writer _createWriter(OutputStream out, JsonEncoding enc, IOContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1835 */     if (enc == JsonEncoding.UTF8) {
/* 1836 */       return new UTF8Writer(ctxt, out);
/*      */     }
/*      */     
/* 1839 */     return new OutputStreamWriter(out, enc.getJavaName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final InputStream _decorate(InputStream in, IOContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1849 */     if (this._inputDecorator != null) {
/* 1850 */       InputStream in2 = this._inputDecorator.decorate(ctxt, in);
/* 1851 */       if (in2 != null) {
/* 1852 */         return in2;
/*      */       }
/*      */     }
/* 1855 */     return in;
/*      */   }
/*      */   
/*      */   protected final Reader _decorate(Reader in, IOContext ctxt) throws IOException {
/* 1859 */     if (this._inputDecorator != null) {
/* 1860 */       Reader in2 = this._inputDecorator.decorate(ctxt, in);
/* 1861 */       if (in2 != null) {
/* 1862 */         return in2;
/*      */       }
/*      */     }
/* 1865 */     return in;
/*      */   }
/*      */   
/*      */   protected final DataInput _decorate(DataInput in, IOContext ctxt) throws IOException
/*      */   {
/* 1870 */     if (this._inputDecorator != null) {
/* 1871 */       DataInput in2 = this._inputDecorator.decorate(ctxt, in);
/* 1872 */       if (in2 != null) {
/* 1873 */         return in2;
/*      */       }
/*      */     }
/* 1876 */     return in;
/*      */   }
/*      */   
/*      */   protected final OutputStream _decorate(OutputStream out, IOContext ctxt) throws IOException {
/* 1880 */     if (this._outputDecorator != null) {
/* 1881 */       OutputStream out2 = this._outputDecorator.decorate(ctxt, out);
/* 1882 */       if (out2 != null) {
/* 1883 */         return out2;
/*      */       }
/*      */     }
/* 1886 */     return out;
/*      */   }
/*      */   
/*      */   protected final Writer _decorate(Writer out, IOContext ctxt) throws IOException {
/* 1890 */     if (this._outputDecorator != null) {
/* 1891 */       Writer out2 = this._outputDecorator.decorate(ctxt, out);
/* 1892 */       if (out2 != null) {
/* 1893 */         return out2;
/*      */       }
/*      */     }
/* 1896 */     return out;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BufferRecycler _getBufferRecycler()
/*      */   {
/* 1919 */     if (Feature.USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING.enabledIn(this._factoryFeatures)) {
/* 1920 */       return BufferRecyclers.getBufferRecycler();
/*      */     }
/* 1922 */     return new BufferRecycler();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected IOContext _createContext(Object srcRef, boolean resourceManaged)
/*      */   {
/* 1935 */     return new IOContext(_getBufferRecycler(), srcRef, resourceManaged);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected IOContext _createNonBlockingContext(Object srcRef)
/*      */   {
/* 1951 */     return new IOContext(_getBufferRecycler(), srcRef, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _requireJSONFactory(String msg)
/*      */   {
/* 1975 */     if (!_isJSONFactory()) {
/* 1976 */       throw new UnsupportedOperationException(String.format(msg, new Object[] { getFormatName() }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private final boolean _isJSONFactory()
/*      */   {
/* 1983 */     return getFormatName() == "JSON";
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\JsonFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */