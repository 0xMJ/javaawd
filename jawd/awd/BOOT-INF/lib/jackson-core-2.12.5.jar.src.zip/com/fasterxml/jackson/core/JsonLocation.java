/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonLocation
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final int MAX_CONTENT_SNIPPET = 500;
/*  36 */   public static final JsonLocation NA = new JsonLocation(null, -1L, -1L, -1, -1);
/*     */   
/*     */ 
/*     */ 
/*     */   protected final long _totalBytes;
/*     */   
/*     */ 
/*     */   protected final long _totalChars;
/*     */   
/*     */ 
/*     */   protected final int _lineNr;
/*     */   
/*     */ 
/*     */   protected final int _columnNr;
/*     */   
/*     */ 
/*     */   final transient Object _sourceRef;
/*     */   
/*     */ 
/*     */ 
/*     */   public JsonLocation(Object srcRef, long totalChars, int lineNr, int colNr)
/*     */   {
/*  58 */     this(srcRef, -1L, totalChars, lineNr, colNr);
/*     */   }
/*     */   
/*     */ 
/*     */   public JsonLocation(Object sourceRef, long totalBytes, long totalChars, int lineNr, int columnNr)
/*     */   {
/*  64 */     this._sourceRef = sourceRef;
/*  65 */     this._totalBytes = totalBytes;
/*  66 */     this._totalChars = totalChars;
/*  67 */     this._lineNr = lineNr;
/*  68 */     this._columnNr = columnNr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getSourceRef()
/*     */   {
/*  81 */     return this._sourceRef;
/*     */   }
/*     */   
/*     */   public int getLineNr()
/*     */   {
/*  86 */     return this._lineNr;
/*     */   }
/*     */   
/*     */   public int getColumnNr()
/*     */   {
/*  91 */     return this._columnNr;
/*     */   }
/*     */   
/*     */ 
/*     */   public long getCharOffset()
/*     */   {
/*  97 */     return this._totalChars;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getByteOffset()
/*     */   {
/* 105 */     return this._totalBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String sourceDescription()
/*     */   {
/* 120 */     return _appendSourceDesc(new StringBuilder(100)).toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 132 */     int hash = this._sourceRef == null ? 1 : this._sourceRef.hashCode();
/* 133 */     hash ^= this._lineNr;
/* 134 */     hash += this._columnNr;
/* 135 */     hash ^= (int)this._totalChars;
/* 136 */     hash += (int)this._totalBytes;
/* 137 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 143 */     if (other == this) return true;
/* 144 */     if (other == null) return false;
/* 145 */     if (!(other instanceof JsonLocation)) return false;
/* 146 */     JsonLocation otherLoc = (JsonLocation)other;
/*     */     
/* 148 */     if (this._sourceRef == null) {
/* 149 */       if (otherLoc._sourceRef != null) return false;
/* 150 */     } else if (!this._sourceRef.equals(otherLoc._sourceRef)) { return false;
/*     */     }
/* 152 */     if ((this._lineNr == otherLoc._lineNr) && (this._columnNr == otherLoc._columnNr) && (this._totalChars == otherLoc._totalChars)) {} return 
/*     */     
/*     */ 
/* 155 */       getByteOffset() == otherLoc.getByteOffset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 162 */     StringBuilder sb = new StringBuilder(80);
/* 163 */     sb.append("[Source: ");
/* 164 */     _appendSourceDesc(sb);
/* 165 */     sb.append("; line: ");
/* 166 */     sb.append(this._lineNr);
/* 167 */     sb.append(", column: ");
/* 168 */     sb.append(this._columnNr);
/* 169 */     sb.append(']');
/* 170 */     return sb.toString();
/*     */   }
/*     */   
/*     */   protected StringBuilder _appendSourceDesc(StringBuilder sb)
/*     */   {
/* 175 */     Object srcRef = this._sourceRef;
/*     */     
/* 177 */     if (srcRef == null) {
/* 178 */       sb.append("UNKNOWN");
/* 179 */       return sb;
/*     */     }
/*     */     
/*     */ 
/* 183 */     Class<?> srcType = (srcRef instanceof Class) ? (Class)srcRef : srcRef.getClass();
/* 184 */     String tn = srcType.getName();
/*     */     
/* 186 */     if (tn.startsWith("java.")) {
/* 187 */       tn = srcType.getSimpleName();
/* 188 */     } else if ((srcRef instanceof byte[])) {
/* 189 */       tn = "byte[]";
/* 190 */     } else if ((srcRef instanceof char[])) {
/* 191 */       tn = "char[]";
/*     */     }
/* 193 */     sb.append('(').append(tn).append(')');
/*     */     
/*     */ 
/* 196 */     String charStr = " chars";
/*     */     int len;
/* 198 */     if ((srcRef instanceof CharSequence)) {
/* 199 */       CharSequence cs = (CharSequence)srcRef;
/* 200 */       int len = cs.length();
/* 201 */       len -= _append(sb, cs.subSequence(0, Math.min(len, 500)).toString());
/* 202 */     } else if ((srcRef instanceof char[])) {
/* 203 */       char[] ch = (char[])srcRef;
/* 204 */       int len = ch.length;
/* 205 */       len -= _append(sb, new String(ch, 0, Math.min(len, 500)));
/* 206 */     } else if ((srcRef instanceof byte[])) {
/* 207 */       byte[] b = (byte[])srcRef;
/* 208 */       int maxLen = Math.min(b.length, 500);
/* 209 */       _append(sb, new String(b, 0, maxLen, Charset.forName("UTF-8")));
/* 210 */       int len = b.length - maxLen;
/* 211 */       charStr = " bytes";
/*     */     } else {
/* 213 */       len = 0;
/*     */     }
/* 215 */     if (len > 0) {
/* 216 */       sb.append("[truncated ").append(len).append(charStr).append(']');
/*     */     }
/* 218 */     return sb;
/*     */   }
/*     */   
/*     */   private int _append(StringBuilder sb, String content) {
/* 222 */     sb.append('"').append(content).append('"');
/* 223 */     return content.length();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-core-2.12.5.jar!\com\fasterxml\jackson\core\JsonLocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */