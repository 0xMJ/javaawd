/*    */ package javax.websocket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final Session session;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SessionException(String message, Throwable cause, Session session)
/*    */   {
/* 27 */     super(message, cause);
/* 28 */     this.session = session;
/*    */   }
/*    */   
/*    */   public Session getSession()
/*    */   {
/* 33 */     return this.session;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\javax\websocket\SessionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */