/*    */ package javax.websocket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeploymentException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DeploymentException(String message)
/*    */   {
/* 24 */     super(message);
/*    */   }
/*    */   
/*    */   public DeploymentException(String message, Throwable cause) {
/* 28 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\javax\websocket\DeploymentException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */