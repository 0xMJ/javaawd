package javax.websocket;

import java.util.List;
import java.util.Map;

public abstract interface EndpointConfig
{
  public abstract List<Class<? extends Encoder>> getEncoders();
  
  public abstract List<Class<? extends Decoder>> getDecoders();
  
  public abstract Map<String, Object> getUserProperties();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\javax\websocket\EndpointConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */