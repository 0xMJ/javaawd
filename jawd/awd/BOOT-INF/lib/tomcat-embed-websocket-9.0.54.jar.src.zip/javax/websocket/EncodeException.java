/*    */ package javax.websocket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EncodeException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private Object object;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EncodeException(Object object, String message)
/*    */   {
/* 26 */     super(message);
/* 27 */     this.object = object;
/*    */   }
/*    */   
/*    */   public EncodeException(Object object, String message, Throwable cause) {
/* 31 */     super(message, cause);
/* 32 */     this.object = object;
/*    */   }
/*    */   
/*    */   public Object getObject() {
/* 36 */     return this.object;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\javax\websocket\EncodeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */