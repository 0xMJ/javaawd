/*    */ package javax.websocket;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.Iterator;
/*    */ import java.util.ServiceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ContainerProvider
/*    */ {
/*    */   private static final String DEFAULT_PROVIDER_CLASS_NAME = "org.apache.tomcat.websocket.WsWebSocketContainer";
/*    */   
/*    */   public static WebSocketContainer getWebSocketContainer()
/*    */   {
/* 37 */     WebSocketContainer result = null;
/*    */     
/*    */ 
/* 40 */     ServiceLoader<ContainerProvider> serviceLoader = ServiceLoader.load(ContainerProvider.class);
/* 41 */     Iterator<ContainerProvider> iter = serviceLoader.iterator();
/* 42 */     while ((result == null) && (iter.hasNext())) {
/* 43 */       result = ((ContainerProvider)iter.next()).getContainer();
/*    */     }
/*    */     
/*    */ 
/* 47 */     if (result == null)
/*    */     {
/*    */       try
/*    */       {
/* 51 */         Class<WebSocketContainer> clazz = Class.forName("org.apache.tomcat.websocket.WsWebSocketContainer");
/*    */         
/* 53 */         result = (WebSocketContainer)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*    */       }
/*    */       catch (ReflectiveOperationException|IllegalArgumentException|SecurityException localReflectiveOperationException) {}
/*    */     }
/*    */     
/*    */ 
/* 59 */     return result;
/*    */   }
/*    */   
/*    */   protected abstract WebSocketContainer getContainer();
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\javax\websocket\ContainerProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */