package javax.websocket.server;

import java.util.Set;
import javax.websocket.Endpoint;

public abstract interface ServerApplicationConfig
{
  public abstract Set<ServerEndpointConfig> getEndpointConfigs(Set<Class<? extends Endpoint>> paramSet);
  
  public abstract Set<Class<?>> getAnnotatedEndpointClasses(Set<Class<?>> paramSet);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\javax\websocket\server\ServerApplicationConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */