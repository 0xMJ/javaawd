package javax.websocket.server;

import javax.websocket.DeploymentException;
import javax.websocket.WebSocketContainer;

public abstract interface ServerContainer
  extends WebSocketContainer
{
  public abstract void addEndpoint(Class<?> paramClass)
    throws DeploymentException;
  
  public abstract void addEndpoint(ServerEndpointConfig paramServerEndpointConfig)
    throws DeploymentException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\javax\websocket\server\ServerContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */