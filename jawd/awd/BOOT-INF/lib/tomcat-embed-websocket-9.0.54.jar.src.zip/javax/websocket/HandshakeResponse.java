package javax.websocket;

import java.util.List;
import java.util.Map;

public abstract interface HandshakeResponse
{
  public static final String SEC_WEBSOCKET_ACCEPT = "Sec-WebSocket-Accept";
  
  public abstract Map<String, List<String>> getHeaders();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\javax\websocket\HandshakeResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */