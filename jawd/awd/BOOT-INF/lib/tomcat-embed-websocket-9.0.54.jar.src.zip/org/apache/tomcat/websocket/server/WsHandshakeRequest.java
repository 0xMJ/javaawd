/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.security.Principal;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.websocket.server.HandshakeRequest;
/*     */ import org.apache.tomcat.util.collections.CaseInsensitiveKeyMap;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsHandshakeRequest
/*     */   implements HandshakeRequest
/*     */ {
/*  41 */   private static final StringManager sm = StringManager.getManager(WsHandshakeRequest.class);
/*     */   
/*     */   private final URI requestUri;
/*     */   
/*     */   private final Map<String, List<String>> parameterMap;
/*     */   
/*     */   private final String queryString;
/*     */   private final Principal userPrincipal;
/*     */   private final Map<String, List<String>> headers;
/*     */   private final Object httpSession;
/*     */   private volatile HttpServletRequest request;
/*     */   
/*     */   public WsHandshakeRequest(HttpServletRequest request, Map<String, String> pathParams)
/*     */   {
/*  55 */     this.request = request;
/*     */     
/*  57 */     this.queryString = request.getQueryString();
/*  58 */     this.userPrincipal = request.getUserPrincipal();
/*  59 */     this.httpSession = request.getSession(false);
/*  60 */     this.requestUri = buildRequestUri(request);
/*     */     
/*     */ 
/*  63 */     Map<String, String[]> originalParameters = request.getParameterMap();
/*     */     
/*  65 */     Map<String, List<String>> newParameters = new HashMap(originalParameters.size());
/*  66 */     for (Map.Entry<String, String[]> entry : originalParameters.entrySet()) {
/*  67 */       newParameters.put(entry.getKey(), 
/*  68 */         Collections.unmodifiableList(
/*  69 */         Arrays.asList((Object[])entry.getValue())));
/*     */     }
/*  71 */     for (Map.Entry<String, String> entry : pathParams.entrySet()) {
/*  72 */       newParameters.put(entry.getKey(), Collections.singletonList(entry.getValue()));
/*     */     }
/*  74 */     this.parameterMap = Collections.unmodifiableMap(newParameters);
/*     */     
/*     */ 
/*  77 */     Object newHeaders = new CaseInsensitiveKeyMap();
/*     */     
/*  79 */     Enumeration<String> headerNames = request.getHeaderNames();
/*  80 */     while (headerNames.hasMoreElements()) {
/*  81 */       String headerName = (String)headerNames.nextElement();
/*     */       
/*  83 */       ((Map)newHeaders).put(headerName, Collections.unmodifiableList(
/*  84 */         Collections.list(request.getHeaders(headerName))));
/*     */     }
/*     */     
/*  87 */     this.headers = Collections.unmodifiableMap((Map)newHeaders);
/*     */   }
/*     */   
/*     */   public URI getRequestURI()
/*     */   {
/*  92 */     return this.requestUri;
/*     */   }
/*     */   
/*     */   public Map<String, List<String>> getParameterMap()
/*     */   {
/*  97 */     return this.parameterMap;
/*     */   }
/*     */   
/*     */   public String getQueryString()
/*     */   {
/* 102 */     return this.queryString;
/*     */   }
/*     */   
/*     */   public Principal getUserPrincipal()
/*     */   {
/* 107 */     return this.userPrincipal;
/*     */   }
/*     */   
/*     */   public Map<String, List<String>> getHeaders()
/*     */   {
/* 112 */     return this.headers;
/*     */   }
/*     */   
/*     */   public boolean isUserInRole(String role)
/*     */   {
/* 117 */     if (this.request == null) {
/* 118 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 121 */     return this.request.isUserInRole(role);
/*     */   }
/*     */   
/*     */   public Object getHttpSession()
/*     */   {
/* 126 */     return this.httpSession;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void finished()
/*     */   {
/* 138 */     this.request = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static URI buildRequestUri(HttpServletRequest req)
/*     */   {
/* 147 */     StringBuilder uri = new StringBuilder();
/* 148 */     String scheme = req.getScheme();
/* 149 */     int port = req.getServerPort();
/* 150 */     if (port < 0)
/*     */     {
/* 152 */       port = 80;
/*     */     }
/*     */     
/* 155 */     if ("http".equals(scheme)) {
/* 156 */       uri.append("ws");
/* 157 */     } else if ("https".equals(scheme)) {
/* 158 */       uri.append("wss");
/* 159 */     } else if (("wss".equals(scheme)) || ("ws".equals(scheme))) {
/* 160 */       uri.append(scheme);
/*     */     }
/*     */     else
/*     */     {
/* 164 */       throw new IllegalArgumentException(sm.getString("wsHandshakeRequest.unknownScheme", new Object[] { scheme }));
/*     */     }
/*     */     
/* 167 */     uri.append("://");
/* 168 */     uri.append(req.getServerName());
/*     */     
/* 170 */     if (((scheme.equals("http")) && (port != 80)) || 
/* 171 */       ((scheme.equals("ws")) && (port != 80)) || 
/* 172 */       ((scheme.equals("wss")) && (port != 443)) || (
/* 173 */       (scheme.equals("https")) && (port != 443))) {
/* 174 */       uri.append(':');
/* 175 */       uri.append(port);
/*     */     }
/*     */     
/* 178 */     uri.append(req.getRequestURI());
/*     */     
/* 180 */     if (req.getQueryString() != null) {
/* 181 */       uri.append('?');
/* 182 */       uri.append(req.getQueryString());
/*     */     }
/*     */     try
/*     */     {
/* 186 */       return new URI(uri.toString());
/*     */     }
/*     */     catch (URISyntaxException e)
/*     */     {
/* 190 */       throw new IllegalArgumentException(sm.getString("wsHandshakeRequest.invalidUri", new Object[] {uri.toString() }), e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\server\WsHandshakeRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */