/*    */ package org.apache.tomcat.websocket.server;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.GenericFilter;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsFilter
/*    */   extends GenericFilter
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private transient WsServerContainer sc;
/*    */   
/*    */   public void init()
/*    */     throws ServletException
/*    */   {
/* 41 */     this.sc = ((WsServerContainer)getServletContext().getAttribute("javax.websocket.server.ServerContainer"));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*    */     throws IOException, ServletException
/*    */   {
/* 51 */     if ((!this.sc.areEndpointsRegistered()) || 
/* 52 */       (!UpgradeUtil.isWebSocketUpgradeRequest(request, response))) {
/* 53 */       chain.doFilter(request, response);
/* 54 */       return;
/*    */     }
/*    */     
/*    */ 
/* 58 */     HttpServletRequest req = (HttpServletRequest)request;
/* 59 */     HttpServletResponse resp = (HttpServletResponse)response;
/*    */     
/*    */ 
/*    */ 
/* 63 */     String pathInfo = req.getPathInfo();
/* 64 */     String path; String path; if (pathInfo == null) {
/* 65 */       path = req.getServletPath();
/*    */     } else {
/* 67 */       path = req.getServletPath() + pathInfo;
/*    */     }
/* 69 */     WsMappingResult mappingResult = this.sc.findMapping(path);
/*    */     
/* 71 */     if (mappingResult == null)
/*    */     {
/*    */ 
/* 74 */       chain.doFilter(request, response);
/* 75 */       return;
/*    */     }
/*    */     
/* 78 */     UpgradeUtil.doUpgrade(this.sc, req, resp, mappingResult.getConfig(), mappingResult
/* 79 */       .getPathParams());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\server\WsFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */