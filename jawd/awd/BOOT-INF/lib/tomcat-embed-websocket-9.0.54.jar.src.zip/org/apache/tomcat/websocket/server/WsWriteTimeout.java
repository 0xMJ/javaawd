/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentSkipListSet;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.tomcat.websocket.BackgroundProcess;
/*     */ import org.apache.tomcat.websocket.BackgroundProcessManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsWriteTimeout
/*     */   implements BackgroundProcess
/*     */ {
/*  35 */   private final Set<WsRemoteEndpointImplServer> endpoints = new ConcurrentSkipListSet(new EndpointComparator(null));
/*     */   
/*  37 */   private final AtomicInteger count = new AtomicInteger(0);
/*  38 */   private int backgroundProcessCount = 0;
/*  39 */   private volatile int processPeriod = 1;
/*     */   
/*     */ 
/*     */   public void backgroundProcess()
/*     */   {
/*  44 */     this.backgroundProcessCount += 1;
/*     */     long now;
/*  46 */     if (this.backgroundProcessCount >= this.processPeriod) {
/*  47 */       this.backgroundProcessCount = 0;
/*     */       
/*  49 */       now = System.currentTimeMillis();
/*  50 */       for (WsRemoteEndpointImplServer endpoint : this.endpoints) {
/*  51 */         if (endpoint.getTimeoutExpiry() >= now) {
/*     */           break;
/*     */         }
/*  54 */         endpoint.onTimeout(false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProcessPeriod(int period)
/*     */   {
/*  68 */     this.processPeriod = period;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getProcessPeriod()
/*     */   {
/*  80 */     return this.processPeriod;
/*     */   }
/*     */   
/*     */   public void register(WsRemoteEndpointImplServer endpoint)
/*     */   {
/*  85 */     boolean result = this.endpoints.add(endpoint);
/*  86 */     if (result) {
/*  87 */       int newCount = this.count.incrementAndGet();
/*  88 */       if (newCount == 1) {
/*  89 */         BackgroundProcessManager.getInstance().register(this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void unregister(WsRemoteEndpointImplServer endpoint)
/*     */   {
/*  96 */     boolean result = this.endpoints.remove(endpoint);
/*  97 */     if (result) {
/*  98 */       int newCount = this.count.decrementAndGet();
/*  99 */       if (newCount == 0) {
/* 100 */         BackgroundProcessManager.getInstance().unregister(this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class EndpointComparator
/*     */     implements Comparator<WsRemoteEndpointImplServer>
/*     */   {
/*     */     public int compare(WsRemoteEndpointImplServer o1, WsRemoteEndpointImplServer o2)
/*     */     {
/* 116 */       long t1 = o1.getTimeoutExpiry();
/* 117 */       long t2 = o2.getTimeoutExpiry();
/*     */       
/* 119 */       if (t1 < t2)
/* 120 */         return -1;
/* 121 */       if (t1 == t2) {
/* 122 */         return 0;
/*     */       }
/* 124 */       return 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\server\WsWriteTimeout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */