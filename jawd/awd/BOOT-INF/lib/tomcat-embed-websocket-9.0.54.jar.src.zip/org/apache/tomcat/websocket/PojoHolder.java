/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import javax.naming.NamingException;
/*    */ import javax.websocket.ClientEndpointConfig;
/*    */ import javax.websocket.DeploymentException;
/*    */ import javax.websocket.Endpoint;
/*    */ import org.apache.tomcat.InstanceManager;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ import org.apache.tomcat.websocket.pojo.PojoEndpointClient;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PojoHolder
/*    */   implements ClientEndpointHolder
/*    */ {
/* 30 */   private static final StringManager sm = StringManager.getManager(PojoHolder.class);
/*    */   
/*    */   private final Object pojo;
/*    */   private final ClientEndpointConfig clientEndpointConfig;
/*    */   
/*    */   public PojoHolder(Object pojo, ClientEndpointConfig clientEndpointConfig)
/*    */   {
/* 37 */     this.pojo = pojo;
/* 38 */     this.clientEndpointConfig = clientEndpointConfig;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getClassName()
/*    */   {
/* 44 */     return this.pojo.getClass().getName();
/*    */   }
/*    */   
/*    */   public Endpoint getInstance(InstanceManager instanceManager)
/*    */     throws DeploymentException
/*    */   {
/* 50 */     if (instanceManager != null) {
/*    */       try {
/* 52 */         instanceManager.newInstance(this.pojo);
/*    */       } catch (ReflectiveOperationException|NamingException e) {
/* 54 */         throw new DeploymentException(sm.getString("clientEndpointHolder.instanceRegistrationFailed"), e);
/*    */       }
/*    */     }
/* 57 */     return new PojoEndpointClient(this.pojo, this.clientEndpointConfig.getDecoders(), instanceManager);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\PojoHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */