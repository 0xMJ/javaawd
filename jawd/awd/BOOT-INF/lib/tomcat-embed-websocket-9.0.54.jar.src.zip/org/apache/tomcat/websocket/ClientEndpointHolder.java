package org.apache.tomcat.websocket;

import javax.websocket.DeploymentException;
import javax.websocket.Endpoint;
import org.apache.tomcat.InstanceManager;

public abstract interface ClientEndpointHolder
{
  public abstract String getClassName();
  
  public abstract Endpoint getInstance(InstanceManager paramInstanceManager)
    throws DeploymentException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\ClientEndpointHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */