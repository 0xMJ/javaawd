/*    */ package org.apache.tomcat.websocket.server;
/*    */ 
/*    */ import aQute.bnd.annotation.spi.ServiceProvider;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import javax.websocket.Extension;
/*    */ import javax.websocket.HandshakeResponse;
/*    */ import javax.websocket.server.HandshakeRequest;
/*    */ import javax.websocket.server.ServerEndpointConfig;
/*    */ import javax.websocket.server.ServerEndpointConfig.Configurator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ServiceProvider(ServerEndpointConfig.Configurator.class)
/*    */ public class DefaultServerEndpointConfigurator
/*    */   extends ServerEndpointConfig.Configurator
/*    */ {
/*    */   public <T> T getEndpointInstance(Class<T> clazz)
/*    */     throws InstantiationException
/*    */   {
/*    */     try
/*    */     {
/* 37 */       return (T)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*    */     } catch (InstantiationException e) {
/* 39 */       throw e;
/*    */     } catch (ReflectiveOperationException e) {
/* 41 */       InstantiationException ie = new InstantiationException();
/* 42 */       ie.initCause(e);
/* 43 */       throw ie;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getNegotiatedSubprotocol(List<String> supported, List<String> requested)
/*    */   {
/* 52 */     for (String request : requested) {
/* 53 */       if (supported.contains(request)) {
/* 54 */         return request;
/*    */       }
/*    */     }
/* 57 */     return "";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public List<Extension> getNegotiatedExtensions(List<Extension> installed, List<Extension> requested)
/*    */   {
/* 64 */     Set<String> installedNames = new HashSet();
/* 65 */     for (Iterator localIterator = installed.iterator(); localIterator.hasNext();) { e = (Extension)localIterator.next();
/* 66 */       installedNames.add(e.getName()); }
/*    */     Extension e;
/* 68 */     Object result = new ArrayList();
/* 69 */     for (Extension request : requested) {
/* 70 */       if (installedNames.contains(request.getName())) {
/* 71 */         ((List)result).add(request);
/*    */       }
/*    */     }
/* 74 */     return (List<Extension>)result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean checkOrigin(String originHeaderValue)
/*    */   {
/* 80 */     return true;
/*    */   }
/*    */   
/*    */   public void modifyHandshake(ServerEndpointConfig sec, HandshakeRequest request, HandshakeResponse response) {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\server\DefaultServerEndpointConfigurator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */