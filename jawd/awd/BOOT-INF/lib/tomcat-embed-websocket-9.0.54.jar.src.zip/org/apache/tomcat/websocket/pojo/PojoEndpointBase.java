/*     */ package org.apache.tomcat.websocket.pojo;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.websocket.CloseReason;
/*     */ import javax.websocket.Endpoint;
/*     */ import javax.websocket.EndpointConfig;
/*     */ import javax.websocket.MessageHandler;
/*     */ import javax.websocket.Session;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.ExceptionUtils;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PojoEndpointBase
/*     */   extends Endpoint
/*     */ {
/*  42 */   private final Log log = LogFactory.getLog(PojoEndpointBase.class);
/*  43 */   private static final StringManager sm = StringManager.getManager(PojoEndpointBase.class);
/*     */   
/*     */   private Object pojo;
/*     */   private final Map<String, String> pathParameters;
/*     */   private PojoMethodMapping methodMapping;
/*     */   
/*     */   protected PojoEndpointBase(Map<String, String> pathParameters)
/*     */   {
/*  51 */     this.pathParameters = pathParameters;
/*     */   }
/*     */   
/*     */   protected final void doOnOpen(Session session, EndpointConfig config)
/*     */   {
/*  56 */     PojoMethodMapping methodMapping = getMethodMapping();
/*  57 */     Object pojo = getPojo();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  62 */     for (MessageHandler mh : methodMapping.getMessageHandlers(pojo, this.pathParameters, session, config))
/*     */     {
/*  64 */       session.addMessageHandler(mh);
/*     */     }
/*     */     
/*  67 */     if (methodMapping.getOnOpen() != null) {
/*     */       try {
/*  69 */         methodMapping.getOnOpen().invoke(pojo, methodMapping
/*  70 */           .getOnOpenArgs(this.pathParameters, session, config));
/*     */ 
/*     */       }
/*     */       catch (IllegalAccessException e)
/*     */       {
/*  75 */         this.log.error(sm.getString("pojoEndpointBase.onOpenFail", new Object[] {pojo
/*     */         
/*  77 */           .getClass().getName() }), e);
/*  78 */         handleOnOpenOrCloseError(session, e);
/*     */       } catch (InvocationTargetException e) {
/*  80 */         Throwable cause = e.getCause();
/*  81 */         handleOnOpenOrCloseError(session, cause);
/*     */       } catch (Throwable t) {
/*  83 */         handleOnOpenOrCloseError(session, t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void handleOnOpenOrCloseError(Session session, Throwable t)
/*     */   {
/*  91 */     ExceptionUtils.handleThrowable(t);
/*     */     
/*     */ 
/*  94 */     onError(session, t);
/*     */     try {
/*  96 */       session.close();
/*     */     } catch (IOException ioe) {
/*  98 */       this.log.warn(sm.getString("pojoEndpointBase.closeSessionFail"), ioe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public final void onClose(Session session, CloseReason closeReason)
/*     */   {
/* 105 */     if (this.methodMapping.getOnClose() != null) {
/*     */       try {
/* 107 */         this.methodMapping.getOnClose().invoke(this.pojo, this.methodMapping
/* 108 */           .getOnCloseArgs(this.pathParameters, session, closeReason));
/*     */       } catch (Throwable t) {
/* 110 */         this.log.error(sm.getString("pojoEndpointBase.onCloseFail", new Object[] {this.pojo
/* 111 */           .getClass().getName() }), t);
/* 112 */         handleOnOpenOrCloseError(session, t);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 117 */     Set<MessageHandler> messageHandlers = session.getMessageHandlers();
/* 118 */     for (MessageHandler messageHandler : messageHandlers) {
/* 119 */       if ((messageHandler instanceof PojoMessageHandlerWholeBase)) {
/* 120 */         ((PojoMessageHandlerWholeBase)messageHandler).onClose();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void onError(Session session, Throwable throwable)
/*     */   {
/* 129 */     if (this.methodMapping.getOnError() == null) {
/* 130 */       this.log.error(sm.getString("pojoEndpointBase.onError", new Object[] {this.pojo
/* 131 */         .getClass().getName() }), throwable);
/*     */     } else {
/*     */       try {
/* 134 */         this.methodMapping.getOnError().invoke(this.pojo, this.methodMapping
/*     */         
/* 136 */           .getOnErrorArgs(this.pathParameters, session, throwable));
/*     */       }
/*     */       catch (Throwable t) {
/* 139 */         ExceptionUtils.handleThrowable(t);
/* 140 */         this.log.error(sm.getString("pojoEndpointBase.onErrorFail", new Object[] {this.pojo
/* 141 */           .getClass().getName() }), t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 146 */   protected Object getPojo() { return this.pojo; }
/* 147 */   protected void setPojo(Object pojo) { this.pojo = pojo; }
/*     */   
/*     */ 
/* 150 */   protected PojoMethodMapping getMethodMapping() { return this.methodMapping; }
/*     */   
/* 152 */   protected void setMethodMapping(PojoMethodMapping methodMapping) { this.methodMapping = methodMapping; }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\pojo\PojoEndpointBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */