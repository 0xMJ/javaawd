/*     */ package org.apache.tomcat.websocket.pojo;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import javax.naming.NamingException;
/*     */ import javax.websocket.DecodeException;
/*     */ import javax.websocket.Decoder;
/*     */ import javax.websocket.Decoder.Text;
/*     */ import javax.websocket.Decoder.TextStream;
/*     */ import javax.websocket.EndpointConfig;
/*     */ import javax.websocket.Session;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PojoMessageHandlerWholeText
/*     */   extends PojoMessageHandlerWholeBase<String>
/*     */ {
/*  43 */   private static final StringManager sm = StringManager.getManager(PojoMessageHandlerWholeText.class);
/*     */   
/*     */ 
/*     */   private final Class<?> primitiveType;
/*     */   
/*     */ 
/*     */ 
/*     */   public PojoMessageHandlerWholeText(Object pojo, Method method, Session session, EndpointConfig config, List<Class<? extends Decoder>> decoderClazzes, Object[] params, int indexPayload, boolean convert, int indexSession, long maxMessageSize)
/*     */   {
/*  52 */     super(pojo, method, session, params, indexPayload, convert, indexSession, maxMessageSize);
/*     */     
/*     */ 
/*     */ 
/*  56 */     if ((maxMessageSize > -1L) && (maxMessageSize > session.getMaxTextMessageBufferSize())) {
/*  57 */       if (maxMessageSize > 2147483647L) {
/*  58 */         throw new IllegalArgumentException(sm.getString("pojoMessageHandlerWhole.maxBufferSize"));
/*     */       }
/*     */       
/*  61 */       session.setMaxTextMessageBufferSize((int)maxMessageSize);
/*     */     }
/*     */     
/*     */ 
/*  65 */     Class<?> type = method.getParameterTypes()[indexPayload];
/*  66 */     if (Util.isPrimitive(type)) {
/*  67 */       this.primitiveType = type;
/*  68 */       return;
/*     */     }
/*  70 */     this.primitiveType = null;
/*     */     
/*     */     try
/*     */     {
/*  74 */       if (decoderClazzes != null) {
/*  75 */         for (Class<? extends Decoder> decoderClazz : decoderClazzes) {
/*  76 */           if (Decoder.Text.class.isAssignableFrom(decoderClazz)) {
/*  77 */             Decoder.Text<?> decoder = (Decoder.Text)createDecoderInstance(decoderClazz);
/*  78 */             decoder.init(config);
/*  79 */             this.decoders.add(decoder);
/*  80 */           } else if (Decoder.TextStream.class.isAssignableFrom(decoderClazz)) {
/*  81 */             Decoder.TextStream<?> decoder = (Decoder.TextStream)createDecoderInstance(decoderClazz);
/*  82 */             decoder.init(config);
/*  83 */             this.decoders.add(decoder);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (ReflectiveOperationException|NamingException e)
/*     */     {
/*  90 */       throw new IllegalArgumentException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object decode(String message)
/*     */     throws DecodeException
/*     */   {
/*  98 */     if (this.primitiveType != null) {
/*  99 */       return Util.coerceToType(this.primitiveType, message);
/*     */     }
/*     */     
/* 102 */     for (Decoder decoder : this.decoders) {
/* 103 */       if ((decoder instanceof Decoder.Text)) {
/* 104 */         if (((Decoder.Text)decoder).willDecode(message)) {
/* 105 */           return ((Decoder.Text)decoder).decode(message);
/*     */         }
/*     */       } else {
/* 108 */         StringReader r = new StringReader(message);
/*     */         try {
/* 110 */           return ((Decoder.TextStream)decoder).decode(r);
/*     */         } catch (IOException ioe) {
/* 112 */           throw new DecodeException(message, sm.getString("pojoMessageHandlerWhole.decodeIoFail"), ioe);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 117 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object convert(String message)
/*     */   {
/* 123 */     return new StringReader(message);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\pojo\PojoMessageHandlerWholeText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */