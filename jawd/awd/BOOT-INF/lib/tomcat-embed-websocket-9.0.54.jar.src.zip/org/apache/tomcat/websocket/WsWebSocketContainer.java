/*      */ package org.apache.tomcat.websocket;
/*      */ 
/*      */ import java.io.EOFException;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.Proxy;
/*      */ import java.net.Proxy.Type;
/*      */ import java.net.ProxySelector;
/*      */ import java.net.SocketAddress;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.channels.AsynchronousChannelGroup;
/*      */ import java.nio.channels.AsynchronousSocketChannel;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.security.KeyStore;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.TimeoutException;
/*      */ import javax.net.ssl.SSLContext;
/*      */ import javax.net.ssl.SSLEngine;
/*      */ import javax.net.ssl.SSLException;
/*      */ import javax.net.ssl.SSLParameters;
/*      */ import javax.net.ssl.TrustManagerFactory;
/*      */ import javax.websocket.ClientEndpoint;
/*      */ import javax.websocket.ClientEndpointConfig;
/*      */ import javax.websocket.ClientEndpointConfig.Builder;
/*      */ import javax.websocket.ClientEndpointConfig.Configurator;
/*      */ import javax.websocket.CloseReason;
/*      */ import javax.websocket.CloseReason.CloseCodes;
/*      */ import javax.websocket.DeploymentException;
/*      */ import javax.websocket.Endpoint;
/*      */ import javax.websocket.Extension;
/*      */ import javax.websocket.Extension.Parameter;
/*      */ import javax.websocket.HandshakeResponse;
/*      */ import javax.websocket.Session;
/*      */ import javax.websocket.WebSocketContainer;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.InstanceManagerBindings;
/*      */ import org.apache.tomcat.util.buf.StringUtils;
/*      */ import org.apache.tomcat.util.codec.binary.Base64;
/*      */ import org.apache.tomcat.util.collections.CaseInsensitiveKeyMap;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.util.security.KeyStoreUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WsWebSocketContainer
/*      */   implements WebSocketContainer, BackgroundProcess
/*      */ {
/*   80 */   private static final StringManager sm = StringManager.getManager(WsWebSocketContainer.class);
/*   81 */   private static final Random RANDOM = new Random();
/*   82 */   private static final byte[] CRLF = { 13, 10 };
/*      */   
/*   84 */   private static final byte[] GET_BYTES = "GET ".getBytes(StandardCharsets.ISO_8859_1);
/*   85 */   private static final byte[] ROOT_URI_BYTES = "/".getBytes(StandardCharsets.ISO_8859_1);
/*   86 */   private static final byte[] HTTP_VERSION_BYTES = " HTTP/1.1\r\n"
/*   87 */     .getBytes(StandardCharsets.ISO_8859_1);
/*      */   
/*   89 */   private volatile AsynchronousChannelGroup asynchronousChannelGroup = null;
/*   90 */   private final Object asynchronousChannelGroupLock = new Object();
/*      */   
/*   92 */   private final Log log = LogFactory.getLog(WsWebSocketContainer.class);
/*      */   
/*      */ 
/*   95 */   private final Map<Object, Set<WsSession>> endpointSessionMap = new HashMap();
/*   96 */   private final Map<WsSession, WsSession> sessions = new ConcurrentHashMap();
/*   97 */   private final Object endPointSessionMapLock = new Object();
/*      */   
/*   99 */   private long defaultAsyncTimeout = -1L;
/*  100 */   private int maxBinaryMessageBufferSize = Constants.DEFAULT_BUFFER_SIZE;
/*  101 */   private int maxTextMessageBufferSize = Constants.DEFAULT_BUFFER_SIZE;
/*  102 */   private volatile long defaultMaxSessionIdleTimeout = 0L;
/*  103 */   private int backgroundProcessCount = 0;
/*  104 */   private int processPeriod = Constants.DEFAULT_PROCESS_PERIOD;
/*      */   private InstanceManager instanceManager;
/*      */   
/*      */   protected InstanceManager getInstanceManager(ClassLoader classLoader)
/*      */   {
/*  109 */     if (this.instanceManager != null) {
/*  110 */       return this.instanceManager;
/*      */     }
/*  112 */     return InstanceManagerBindings.get(classLoader);
/*      */   }
/*      */   
/*      */   protected void setInstanceManager(InstanceManager instanceManager) {
/*  116 */     this.instanceManager = instanceManager;
/*      */   }
/*      */   
/*      */   public Session connectToServer(Object pojo, URI path) throws DeploymentException
/*      */   {
/*  121 */     ClientEndpointConfig config = createClientEndpointConfig(pojo.getClass());
/*  122 */     ClientEndpointHolder holder = new PojoHolder(pojo, config);
/*  123 */     return connectToServerRecursive(holder, config, path, new HashSet());
/*      */   }
/*      */   
/*      */   public Session connectToServer(Class<?> annotatedEndpointClass, URI path)
/*      */     throws DeploymentException
/*      */   {
/*  129 */     ClientEndpointConfig config = createClientEndpointConfig(annotatedEndpointClass);
/*  130 */     ClientEndpointHolder holder = new PojoClassHolder(annotatedEndpointClass, config);
/*  131 */     return connectToServerRecursive(holder, config, path, new HashSet());
/*      */   }
/*      */   
/*      */   private ClientEndpointConfig createClientEndpointConfig(Class<?> annotatedEndpointClass)
/*      */     throws DeploymentException
/*      */   {
/*  137 */     ClientEndpoint annotation = (ClientEndpoint)annotatedEndpointClass.getAnnotation(ClientEndpoint.class);
/*  138 */     if (annotation == null)
/*      */     {
/*  140 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.missingAnnotation", new Object[] {annotatedEndpointClass
/*  141 */         .getName() }));
/*      */     }
/*      */     
/*      */ 
/*  145 */     Class<? extends ClientEndpointConfig.Configurator> configuratorClazz = annotation.configurator();
/*      */     
/*  147 */     ClientEndpointConfig.Configurator configurator = null;
/*  148 */     if (!ClientEndpointConfig.Configurator.class.equals(configuratorClazz)) {
/*      */       try
/*      */       {
/*  151 */         configurator = (ClientEndpointConfig.Configurator)configuratorClazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */       } catch (ReflectiveOperationException e) {
/*  153 */         throw new DeploymentException(sm.getString("wsWebSocketContainer.defaultConfiguratorFail"), e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  158 */     ClientEndpointConfig.Builder builder = ClientEndpointConfig.Builder.create();
/*      */     
/*  160 */     if (configurator != null) {
/*  161 */       builder.configurator(configurator);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  167 */     ClientEndpointConfig config = builder.decoders(Arrays.asList(annotation.decoders())).encoders(Arrays.asList(annotation.encoders())).preferredSubprotocols(Arrays.asList(annotation.subprotocols())).build();
/*      */     
/*  169 */     return config;
/*      */   }
/*      */   
/*      */ 
/*      */   public Session connectToServer(Class<? extends Endpoint> clazz, ClientEndpointConfig clientEndpointConfiguration, URI path)
/*      */     throws DeploymentException
/*      */   {
/*  176 */     ClientEndpointHolder holder = new EndpointClassHolder(clazz);
/*  177 */     return connectToServerRecursive(holder, clientEndpointConfiguration, path, new HashSet());
/*      */   }
/*      */   
/*      */ 
/*      */   public Session connectToServer(Endpoint endpoint, ClientEndpointConfig clientEndpointConfiguration, URI path)
/*      */     throws DeploymentException
/*      */   {
/*  184 */     ClientEndpointHolder holder = new EndpointHolder(endpoint);
/*  185 */     return connectToServerRecursive(holder, clientEndpointConfiguration, path, new HashSet());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private Session connectToServerRecursive(ClientEndpointHolder clientEndpointHolder, ClientEndpointConfig clientEndpointConfiguration, URI path, Set<URI> redirectSet)
/*      */     throws DeploymentException
/*      */   {
/*  193 */     if (this.log.isDebugEnabled()) {
/*  194 */       this.log.debug(sm.getString("wsWebSocketContainer.connect.entry", new Object[] { clientEndpointHolder.getClassName(), path }));
/*      */     }
/*      */     
/*  197 */     boolean secure = false;
/*  198 */     ByteBuffer proxyConnect = null;
/*      */     
/*      */ 
/*      */ 
/*  202 */     String scheme = path.getScheme();
/*  203 */     URI proxyPath; if ("ws".equalsIgnoreCase(scheme)) {
/*  204 */       proxyPath = URI.create("http" + path.toString().substring(2));
/*  205 */     } else if ("wss".equalsIgnoreCase(scheme)) {
/*  206 */       URI proxyPath = URI.create("https" + path.toString().substring(3));
/*  207 */       secure = true;
/*      */     } else {
/*  209 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.pathWrongScheme", new Object[] { scheme }));
/*      */     }
/*      */     
/*      */     URI proxyPath;
/*      */     
/*  214 */     String host = path.getHost();
/*  215 */     if (host == null)
/*      */     {
/*  217 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.pathNoHost"));
/*      */     }
/*  219 */     int port = path.getPort();
/*      */     
/*  221 */     SocketAddress sa = null;
/*      */     
/*      */ 
/*      */ 
/*  225 */     List<Proxy> proxies = ProxySelector.getDefault().select(proxyPath);
/*  226 */     Proxy selectedProxy = null;
/*  227 */     for (Proxy proxy : proxies) {
/*  228 */       if (proxy.type().equals(Proxy.Type.HTTP)) {
/*  229 */         sa = proxy.address();
/*  230 */         if ((sa instanceof InetSocketAddress)) {
/*  231 */           InetSocketAddress inet = (InetSocketAddress)sa;
/*  232 */           if (inet.isUnresolved()) {
/*  233 */             sa = new InetSocketAddress(inet.getHostName(), inet.getPort());
/*      */           }
/*      */         }
/*  236 */         selectedProxy = proxy;
/*  237 */         break;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  243 */     if (port == -1) {
/*  244 */       if ("ws".equalsIgnoreCase(scheme)) {
/*  245 */         port = 80;
/*      */       }
/*      */       else {
/*  248 */         port = 443;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  253 */     if (sa == null) {
/*  254 */       sa = new InetSocketAddress(host, port);
/*      */     } else {
/*  256 */       proxyConnect = createProxyRequest(host, port);
/*      */     }
/*      */     
/*      */ 
/*  260 */     Object reqHeaders = createRequestHeaders(host, port, secure, clientEndpointConfiguration);
/*      */     
/*  262 */     clientEndpointConfiguration.getConfigurator().beforeRequest((Map)reqHeaders);
/*  263 */     if ((Constants.DEFAULT_ORIGIN_HEADER_VALUE != null) && 
/*  264 */       (!((Map)reqHeaders).containsKey("Origin"))) {
/*  265 */       List<String> originValues = new ArrayList(1);
/*  266 */       originValues.add(Constants.DEFAULT_ORIGIN_HEADER_VALUE);
/*  267 */       ((Map)reqHeaders).put("Origin", originValues);
/*      */     }
/*  269 */     ByteBuffer request = createRequest(path, (Map)reqHeaders);
/*      */     
/*      */     try
/*      */     {
/*  273 */       socketChannel = AsynchronousSocketChannel.open(getAsynchronousChannelGroup());
/*      */     } catch (IOException ioe) { AsynchronousSocketChannel socketChannel;
/*  275 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.asynchronousSocketChannelFail"), ioe);
/*      */     }
/*      */     
/*      */     AsynchronousSocketChannel socketChannel;
/*  279 */     Map<String, Object> userProperties = clientEndpointConfiguration.getUserProperties();
/*      */     
/*      */ 
/*  282 */     long timeout = 5000L;
/*  283 */     String timeoutValue = (String)userProperties.get("org.apache.tomcat.websocket.IO_TIMEOUT_MS");
/*  284 */     if (timeoutValue != null) {
/*  285 */       timeout = Long.valueOf(timeoutValue).intValue();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  290 */     ByteBuffer response = ByteBuffer.allocate(getDefaultMaxBinaryMessageBufferSize());
/*      */     
/*  292 */     boolean success = false;
/*  293 */     List<Extension> extensionsAgreed = new ArrayList();
/*  294 */     Transformation transformation = null;
/*  295 */     AsyncChannelWrapper channel = null;
/*      */     
/*      */     try
/*      */     {
/*  299 */       Future<Void> fConnect = socketChannel.connect(sa);
/*      */       
/*  301 */       if (proxyConnect != null) {
/*  302 */         fConnect.get(timeout, TimeUnit.MILLISECONDS);
/*      */         
/*  304 */         channel = new AsyncChannelWrapperNonSecure(socketChannel);
/*  305 */         writeRequest(channel, proxyConnect, timeout);
/*  306 */         HttpResponse httpResponse = processResponse(response, channel, timeout);
/*  307 */         if (httpResponse.getStatus() != 200) {
/*  308 */           throw new DeploymentException(sm.getString("wsWebSocketContainer.proxyConnectFail", new Object[] { selectedProxy, 
/*      */           
/*  310 */             Integer.toString(httpResponse.getStatus()) }));
/*      */         }
/*      */       }
/*      */       
/*  314 */       if (secure)
/*      */       {
/*      */ 
/*      */ 
/*  318 */         SSLEngine sslEngine = createSSLEngine(userProperties, host, port);
/*  319 */         channel = new AsyncChannelWrapperSecure(socketChannel, sslEngine);
/*  320 */       } else if (channel == null)
/*      */       {
/*      */ 
/*  323 */         channel = new AsyncChannelWrapperNonSecure(socketChannel);
/*      */       }
/*      */       
/*  326 */       fConnect.get(timeout, TimeUnit.MILLISECONDS);
/*      */       
/*  328 */       Future<Void> fHandshake = channel.handshake();
/*  329 */       fHandshake.get(timeout, TimeUnit.MILLISECONDS);
/*      */       
/*  331 */       if (this.log.isDebugEnabled()) {
/*  332 */         SocketAddress localAddress = null;
/*      */         try {
/*  334 */           localAddress = channel.getLocalAddress();
/*      */         }
/*      */         catch (IOException localIOException1) {}
/*      */         
/*  338 */         this.log.debug(sm.getString("wsWebSocketContainer.connect.write", new Object[] {
/*  339 */           Integer.valueOf(request.position()), Integer.valueOf(request.limit()), localAddress }));
/*      */       }
/*  341 */       writeRequest(channel, request, timeout);
/*      */       
/*  343 */       HttpResponse httpResponse = processResponse(response, channel, timeout);
/*      */       
/*      */ 
/*  346 */       int maxRedirects = 20;
/*      */       
/*  348 */       String maxRedirectsValue = (String)userProperties.get("org.apache.tomcat.websocket.MAX_REDIRECTIONS");
/*  349 */       if (maxRedirectsValue != null) {
/*  350 */         maxRedirects = Integer.parseInt(maxRedirectsValue);
/*      */       }
/*      */       Object auth;
/*  353 */       if (httpResponse.status != 101) {
/*  354 */         if (isRedirectStatus(httpResponse.status))
/*      */         {
/*  356 */           List<String> locationHeader = (List)httpResponse.getHandshakeResponse().getHeaders().get("Location");
/*      */           
/*      */ 
/*  359 */           if ((locationHeader == null) || (locationHeader.isEmpty()) || 
/*  360 */             (locationHeader.get(0) == null) || (((String)locationHeader.get(0)).isEmpty())) {
/*  361 */             throw new DeploymentException(sm.getString("wsWebSocketContainer.missingLocationHeader", new Object[] {
/*      */             
/*  363 */               Integer.toString(httpResponse.status) }));
/*      */           }
/*      */           
/*  366 */           URI redirectLocation = URI.create((String)locationHeader.get(0)).normalize();
/*      */           
/*  368 */           if (!redirectLocation.isAbsolute()) {
/*  369 */             redirectLocation = path.resolve(redirectLocation);
/*      */           }
/*      */           
/*  372 */           String redirectScheme = redirectLocation.getScheme().toLowerCase();
/*      */           
/*  374 */           if (redirectScheme.startsWith("http"))
/*      */           {
/*      */ 
/*      */ 
/*  378 */             redirectLocation = new URI(redirectScheme.replace("http", "ws"), redirectLocation.getUserInfo(), redirectLocation.getHost(), redirectLocation.getPort(), redirectLocation.getPath(), redirectLocation.getQuery(), redirectLocation.getFragment());
/*      */           }
/*      */           
/*  381 */           if ((!redirectSet.add(redirectLocation)) || (redirectSet.size() > maxRedirects)) {
/*  382 */             throw new DeploymentException(sm.getString("wsWebSocketContainer.redirectThreshold", new Object[] { redirectLocation, 
/*      */             
/*  384 */               Integer.toString(redirectSet.size()), 
/*  385 */               Integer.toString(maxRedirects) }));
/*      */           }
/*      */           
/*  388 */           return connectToServerRecursive(clientEndpointHolder, clientEndpointConfiguration, redirectLocation, redirectSet);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  393 */         if (httpResponse.status == 401)
/*      */         {
/*  395 */           if (userProperties.get("Authorization") != null) {
/*  396 */             throw new DeploymentException(sm.getString("wsWebSocketContainer.failedAuthentication", new Object[] {
/*      */             
/*  398 */               Integer.valueOf(httpResponse.status) }));
/*      */           }
/*      */           
/*      */ 
/*  402 */           List<String> wwwAuthenticateHeaders = (List)httpResponse.getHandshakeResponse().getHeaders().get("WWW-Authenticate");
/*      */           
/*  404 */           if ((wwwAuthenticateHeaders == null) || (wwwAuthenticateHeaders.isEmpty()) || 
/*  405 */             (wwwAuthenticateHeaders.get(0) == null) || (((String)wwwAuthenticateHeaders.get(0)).isEmpty())) {
/*  406 */             throw new DeploymentException(sm.getString("wsWebSocketContainer.missingWWWAuthenticateHeader", new Object[] {
/*      */             
/*  408 */               Integer.toString(httpResponse.status) }));
/*      */           }
/*      */           
/*  411 */           String authScheme = ((String)wwwAuthenticateHeaders.get(0)).split("\\s+", 2)[0];
/*      */           
/*  413 */           String requestUri = new String(request.array(), StandardCharsets.ISO_8859_1).split("\\s", 3)[1];
/*      */           
/*  415 */           auth = AuthenticatorFactory.getAuthenticator(authScheme);
/*      */           
/*  417 */           if (auth == null)
/*      */           {
/*  419 */             throw new DeploymentException(sm.getString("wsWebSocketContainer.unsupportedAuthScheme", new Object[] {
/*  420 */               Integer.valueOf(httpResponse.status), authScheme }));
/*      */           }
/*      */           
/*  423 */           userProperties.put("Authorization", ((Authenticator)auth).getAuthorization(requestUri, 
/*  424 */             (String)wwwAuthenticateHeaders.get(0), userProperties));
/*      */           
/*  426 */           return connectToServerRecursive(clientEndpointHolder, clientEndpointConfiguration, path, redirectSet);
/*      */         }
/*      */         
/*      */ 
/*  430 */         throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidStatus", new Object[] {
/*  431 */           Integer.toString(httpResponse.status) }));
/*      */       }
/*      */       
/*  434 */       HandshakeResponse handshakeResponse = httpResponse.getHandshakeResponse();
/*  435 */       clientEndpointConfiguration.getConfigurator().afterResponse(handshakeResponse);
/*      */       
/*      */ 
/*  438 */       List<String> protocolHeaders = (List)handshakeResponse.getHeaders().get("Sec-WebSocket-Protocol");
/*      */       String subProtocol;
/*  440 */       if ((protocolHeaders == null) || (protocolHeaders.size() == 0)) {
/*  441 */         subProtocol = null; } else { String subProtocol;
/*  442 */         if (protocolHeaders.size() == 1) {
/*  443 */           subProtocol = (String)protocolHeaders.get(0);
/*      */         }
/*      */         else {
/*  446 */           throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidSubProtocol"));
/*      */         }
/*      */       }
/*      */       
/*      */       String subProtocol;
/*      */       
/*  452 */       List<String> extHeaders = (List)handshakeResponse.getHeaders().get("Sec-WebSocket-Extensions");
/*      */       
/*  454 */       if (extHeaders != null) {
/*  455 */         for (auth = extHeaders.iterator(); ((Iterator)auth).hasNext();) { extHeader = (String)((Iterator)auth).next();
/*  456 */           Util.parseExtensionHeader(extensionsAgreed, extHeader);
/*      */         }
/*      */       }
/*      */       
/*      */       String extHeader;
/*  461 */       TransformationFactory factory = TransformationFactory.getInstance();
/*  462 */       for (Extension extension : extensionsAgreed) {
/*  463 */         List<List<Extension.Parameter>> wrapper = new ArrayList(1);
/*  464 */         wrapper.add(extension.getParameters());
/*  465 */         Transformation t = factory.create(extension.getName(), wrapper, false);
/*  466 */         if (t == null) {
/*  467 */           throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidExtensionParameters"));
/*      */         }
/*      */         
/*  470 */         if (transformation == null) {
/*  471 */           transformation = t;
/*      */         } else {
/*  473 */           transformation.setNext(t);
/*      */         }
/*      */       }
/*      */       
/*  477 */       success = true;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  482 */       if (!success) {
/*  483 */         if (channel != null) {
/*  484 */           channel.close();
/*      */         } else {
/*      */           try {
/*  487 */             socketChannel.close();
/*      */           }
/*      */           catch (IOException localIOException4) {}
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  496 */       wsRemoteEndpointClient = new WsRemoteEndpointImplClient(channel);
/*      */     }
/*      */     catch (ExecutionException|InterruptedException|SSLException|EOFException|TimeoutException|URISyntaxException|AuthenticationException e)
/*      */     {
/*  480 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.httpRequestFailed", new Object[] { path }), e);
/*      */     } finally {
/*  482 */       if (!success) {
/*  483 */         if (channel != null) {
/*  484 */           channel.close();
/*      */         } else {
/*      */           try {
/*  487 */             socketChannel.close();
/*      */           }
/*      */           catch (IOException localIOException5) {}
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     String subProtocol;
/*      */     
/*      */     WsRemoteEndpointImplClient wsRemoteEndpointClient;
/*      */     
/*  499 */     WsSession wsSession = new WsSession(clientEndpointHolder, wsRemoteEndpointClient, this, extensionsAgreed, subProtocol, Collections.emptyMap(), secure, clientEndpointConfiguration);
/*      */     
/*  501 */     WsFrameClient wsFrameClient = new WsFrameClient(response, channel, wsSession, transformation);
/*      */     
/*      */ 
/*      */ 
/*  505 */     wsRemoteEndpointClient.setTransformation(wsFrameClient.getTransformation());
/*      */     
/*  507 */     wsSession.getLocal().onOpen(wsSession, clientEndpointConfiguration);
/*  508 */     registerSession(wsSession.getLocal(), wsSession);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  520 */     wsFrameClient.startInputProcessing();
/*      */     
/*  522 */     return wsSession;
/*      */   }
/*      */   
/*      */   private static void writeRequest(AsyncChannelWrapper channel, ByteBuffer request, long timeout)
/*      */     throws TimeoutException, InterruptedException, ExecutionException
/*      */   {
/*  528 */     int toWrite = request.limit();
/*      */     
/*  530 */     Future<Integer> fWrite = channel.write(request);
/*  531 */     Integer thisWrite = (Integer)fWrite.get(timeout, TimeUnit.MILLISECONDS);
/*  532 */     toWrite -= thisWrite.intValue();
/*      */     
/*  534 */     while (toWrite > 0) {
/*  535 */       fWrite = channel.write(request);
/*  536 */       thisWrite = (Integer)fWrite.get(timeout, TimeUnit.MILLISECONDS);
/*  537 */       toWrite -= thisWrite.intValue();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static boolean isRedirectStatus(int httpResponseCode)
/*      */   {
/*  544 */     boolean isRedirect = false;
/*      */     
/*  546 */     switch (httpResponseCode) {
/*      */     case 300: 
/*      */     case 301: 
/*      */     case 302: 
/*      */     case 303: 
/*      */     case 305: 
/*      */     case 307: 
/*  553 */       isRedirect = true;
/*  554 */       break;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  559 */     return isRedirect;
/*      */   }
/*      */   
/*      */   private static ByteBuffer createProxyRequest(String host, int port)
/*      */   {
/*  564 */     StringBuilder request = new StringBuilder();
/*  565 */     request.append("CONNECT ");
/*  566 */     request.append(host);
/*  567 */     request.append(':');
/*  568 */     request.append(port);
/*      */     
/*  570 */     request.append(" HTTP/1.1\r\nProxy-Connection: keep-alive\r\nConnection: keepalive\r\nHost: ");
/*  571 */     request.append(host);
/*  572 */     request.append(':');
/*  573 */     request.append(port);
/*      */     
/*  575 */     request.append("\r\n\r\n");
/*      */     
/*  577 */     byte[] bytes = request.toString().getBytes(StandardCharsets.ISO_8859_1);
/*  578 */     return ByteBuffer.wrap(bytes);
/*      */   }
/*      */   
/*      */   protected void registerSession(Object key, WsSession wsSession)
/*      */   {
/*  583 */     if (!wsSession.isOpen())
/*      */     {
/*  585 */       return;
/*      */     }
/*  587 */     synchronized (this.endPointSessionMapLock) {
/*  588 */       if (this.endpointSessionMap.size() == 0) {
/*  589 */         BackgroundProcessManager.getInstance().register(this);
/*      */       }
/*  591 */       Set<WsSession> wsSessions = (Set)this.endpointSessionMap.get(key);
/*  592 */       if (wsSessions == null) {
/*  593 */         wsSessions = new HashSet();
/*  594 */         this.endpointSessionMap.put(key, wsSessions);
/*      */       }
/*  596 */       wsSessions.add(wsSession);
/*      */     }
/*  598 */     this.sessions.put(wsSession, wsSession);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void unregisterSession(Object key, WsSession wsSession)
/*      */   {
/*  604 */     synchronized (this.endPointSessionMapLock) {
/*  605 */       Set<WsSession> wsSessions = (Set)this.endpointSessionMap.get(key);
/*  606 */       if (wsSessions != null) {
/*  607 */         wsSessions.remove(wsSession);
/*  608 */         if (wsSessions.size() == 0) {
/*  609 */           this.endpointSessionMap.remove(key);
/*      */         }
/*      */       }
/*  612 */       if (this.endpointSessionMap.size() == 0) {
/*  613 */         BackgroundProcessManager.getInstance().unregister(this);
/*      */       }
/*      */     }
/*  616 */     this.sessions.remove(wsSession);
/*      */   }
/*      */   
/*      */   Set<Session> getOpenSessions(Object key)
/*      */   {
/*  621 */     HashSet<Session> result = new HashSet();
/*  622 */     synchronized (this.endPointSessionMapLock) {
/*  623 */       Set<WsSession> sessions = (Set)this.endpointSessionMap.get(key);
/*  624 */       if (sessions != null) {
/*  625 */         result.addAll(sessions);
/*      */       }
/*      */     }
/*  628 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   private static Map<String, List<String>> createRequestHeaders(String host, int port, boolean secure, ClientEndpointConfig clientEndpointConfiguration)
/*      */   {
/*  634 */     Map<String, List<String>> headers = new HashMap();
/*  635 */     List<Extension> extensions = clientEndpointConfiguration.getExtensions();
/*  636 */     List<String> subProtocols = clientEndpointConfiguration.getPreferredSubprotocols();
/*  637 */     Map<String, Object> userProperties = clientEndpointConfiguration.getUserProperties();
/*      */     
/*  639 */     if (userProperties.get("Authorization") != null) {
/*  640 */       List<String> authValues = new ArrayList(1);
/*  641 */       authValues.add((String)userProperties.get("Authorization"));
/*  642 */       headers.put("Authorization", authValues);
/*      */     }
/*      */     
/*      */ 
/*  646 */     List<String> hostValues = new ArrayList(1);
/*  647 */     if (((port == 80) && (!secure)) || ((port == 443) && (secure)))
/*      */     {
/*  649 */       hostValues.add(host);
/*      */     } else {
/*  651 */       hostValues.add(host + ':' + port);
/*      */     }
/*      */     
/*  654 */     headers.put("Host", hostValues);
/*      */     
/*      */ 
/*  657 */     List<String> upgradeValues = new ArrayList(1);
/*  658 */     upgradeValues.add("websocket");
/*  659 */     headers.put("Upgrade", upgradeValues);
/*      */     
/*      */ 
/*  662 */     List<String> connectionValues = new ArrayList(1);
/*  663 */     connectionValues.add("upgrade");
/*  664 */     headers.put("Connection", connectionValues);
/*      */     
/*      */ 
/*  667 */     List<String> wsVersionValues = new ArrayList(1);
/*  668 */     wsVersionValues.add("13");
/*  669 */     headers.put("Sec-WebSocket-Version", wsVersionValues);
/*      */     
/*      */ 
/*  672 */     List<String> wsKeyValues = new ArrayList(1);
/*  673 */     wsKeyValues.add(generateWsKeyValue());
/*  674 */     headers.put("Sec-WebSocket-Key", wsKeyValues);
/*      */     
/*      */ 
/*  677 */     if ((subProtocols != null) && (subProtocols.size() > 0)) {
/*  678 */       headers.put("Sec-WebSocket-Protocol", subProtocols);
/*      */     }
/*      */     
/*      */ 
/*  682 */     if ((extensions != null) && (extensions.size() > 0)) {
/*  683 */       headers.put("Sec-WebSocket-Extensions", 
/*  684 */         generateExtensionHeaders(extensions));
/*      */     }
/*      */     
/*  687 */     return headers;
/*      */   }
/*      */   
/*      */   private static List<String> generateExtensionHeaders(List<Extension> extensions)
/*      */   {
/*  692 */     List<String> result = new ArrayList(extensions.size());
/*  693 */     for (Extension extension : extensions) {
/*  694 */       StringBuilder header = new StringBuilder();
/*  695 */       header.append(extension.getName());
/*  696 */       for (Extension.Parameter param : extension.getParameters()) {
/*  697 */         header.append(';');
/*  698 */         header.append(param.getName());
/*  699 */         String value = param.getValue();
/*  700 */         if ((value != null) && (value.length() > 0)) {
/*  701 */           header.append('=');
/*  702 */           header.append(value);
/*      */         }
/*      */       }
/*  705 */       result.add(header.toString());
/*      */     }
/*  707 */     return result;
/*      */   }
/*      */   
/*      */   private static String generateWsKeyValue()
/*      */   {
/*  712 */     byte[] keyBytes = new byte[16];
/*  713 */     RANDOM.nextBytes(keyBytes);
/*  714 */     return Base64.encodeBase64String(keyBytes);
/*      */   }
/*      */   
/*      */   private static ByteBuffer createRequest(URI uri, Map<String, List<String>> reqHeaders)
/*      */   {
/*  719 */     ByteBuffer result = ByteBuffer.allocate(4096);
/*      */     
/*      */ 
/*  722 */     result.put(GET_BYTES);
/*  723 */     String path = uri.getPath();
/*  724 */     if ((null == path) || (path.isEmpty())) {
/*  725 */       result.put(ROOT_URI_BYTES);
/*      */     } else {
/*  727 */       result.put(uri.getRawPath().getBytes(StandardCharsets.ISO_8859_1));
/*      */     }
/*  729 */     String query = uri.getRawQuery();
/*  730 */     if (query != null) {
/*  731 */       result.put((byte)63);
/*  732 */       result.put(query.getBytes(StandardCharsets.ISO_8859_1));
/*      */     }
/*  734 */     result.put(HTTP_VERSION_BYTES);
/*      */     
/*      */ 
/*  737 */     for (Map.Entry<String, List<String>> entry : reqHeaders.entrySet()) {
/*  738 */       result = addHeader(result, (String)entry.getKey(), (List)entry.getValue());
/*      */     }
/*      */     
/*      */ 
/*  742 */     result.put(CRLF);
/*      */     
/*  744 */     result.flip();
/*      */     
/*  746 */     return result;
/*      */   }
/*      */   
/*      */   private static ByteBuffer addHeader(ByteBuffer result, String key, List<String> values)
/*      */   {
/*  751 */     if (values.isEmpty()) {
/*  752 */       return result;
/*      */     }
/*      */     
/*  755 */     result = putWithExpand(result, key.getBytes(StandardCharsets.ISO_8859_1));
/*  756 */     result = putWithExpand(result, ": ".getBytes(StandardCharsets.ISO_8859_1));
/*  757 */     result = putWithExpand(result, StringUtils.join(values).getBytes(StandardCharsets.ISO_8859_1));
/*  758 */     result = putWithExpand(result, CRLF);
/*      */     
/*  760 */     return result;
/*      */   }
/*      */   
/*      */   private static ByteBuffer putWithExpand(ByteBuffer input, byte[] bytes)
/*      */   {
/*  765 */     if (bytes.length > input.remaining()) { int newSize;
/*      */       int newSize;
/*  767 */       if (bytes.length > input.capacity()) {
/*  768 */         newSize = 2 * bytes.length;
/*      */       } else {
/*  770 */         newSize = input.capacity() * 2;
/*      */       }
/*  772 */       ByteBuffer expanded = ByteBuffer.allocate(newSize);
/*  773 */       input.flip();
/*  774 */       expanded.put(input);
/*  775 */       input = expanded;
/*      */     }
/*  777 */     return input.put(bytes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private HttpResponse processResponse(ByteBuffer response, AsyncChannelWrapper channel, long timeout)
/*      */     throws InterruptedException, ExecutionException, DeploymentException, EOFException, TimeoutException
/*      */   {
/*  793 */     Map<String, List<String>> headers = new CaseInsensitiveKeyMap();
/*      */     
/*  795 */     int status = 0;
/*  796 */     boolean readStatus = false;
/*  797 */     boolean readHeaders = false;
/*  798 */     String line = null;
/*  799 */     for (; !readHeaders; 
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  833 */         goto 155)
/*      */     {
/*  802 */       response.clear();
/*      */       
/*  804 */       Future<Integer> read = channel.read(response);
/*      */       try
/*      */       {
/*  807 */         bytesRead = (Integer)read.get(timeout, TimeUnit.MILLISECONDS);
/*      */       } catch (TimeoutException e) {
/*      */         Integer bytesRead;
/*  810 */         TimeoutException te = new TimeoutException(sm.getString("wsWebSocketContainer.responseFail", new Object[] { Integer.toString(status), headers }));
/*  811 */         te.initCause(e);
/*  812 */         throw te; }
/*      */       Integer bytesRead;
/*  814 */       if (bytesRead.intValue() == -1) {
/*  815 */         throw new EOFException(sm.getString("wsWebSocketContainer.responseFail", new Object[] { Integer.toString(status), headers }));
/*      */       }
/*  817 */       response.flip();
/*  818 */       while ((response.hasRemaining()) && (!readHeaders)) {
/*  819 */         if (line == null) {
/*  820 */           line = readLine(response);
/*      */         } else {
/*  822 */           line = line + readLine(response);
/*      */         }
/*  824 */         if ("\r\n".equals(line)) {
/*  825 */           readHeaders = true;
/*  826 */         } else if (line.endsWith("\r\n")) {
/*  827 */           if (readStatus) {
/*  828 */             parseHeaders(line, headers);
/*      */           } else {
/*  830 */             status = parseStatus(line);
/*  831 */             readStatus = true;
/*      */           }
/*  833 */           line = null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  838 */     return new HttpResponse(status, new WsHandshakeResponse(headers));
/*      */   }
/*      */   
/*      */ 
/*      */   private int parseStatus(String line)
/*      */     throws DeploymentException
/*      */   {
/*  845 */     String[] parts = line.trim().split(" ");
/*      */     
/*  847 */     if ((parts.length < 2) || ((!"HTTP/1.0".equals(parts[0])) && (!"HTTP/1.1".equals(parts[0])))) {
/*  848 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidStatus", new Object[] { line }));
/*      */     }
/*      */     try
/*      */     {
/*  852 */       return Integer.parseInt(parts[1]);
/*      */     } catch (NumberFormatException nfe) {
/*  854 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.invalidStatus", new Object[] { line }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseHeaders(String line, Map<String, List<String>> headers)
/*      */   {
/*  863 */     int index = line.indexOf(':');
/*  864 */     if (index == -1) {
/*  865 */       this.log.warn(sm.getString("wsWebSocketContainer.invalidHeader", new Object[] { line }));
/*  866 */       return;
/*      */     }
/*      */     
/*  869 */     String headerName = line.substring(0, index).trim().toLowerCase(Locale.ENGLISH);
/*      */     
/*      */ 
/*  872 */     String headerValue = line.substring(index + 1).trim();
/*      */     
/*  874 */     List<String> values = (List)headers.get(headerName);
/*  875 */     if (values == null) {
/*  876 */       values = new ArrayList(1);
/*  877 */       headers.put(headerName, values);
/*      */     }
/*  879 */     values.add(headerValue);
/*      */   }
/*      */   
/*      */   private String readLine(ByteBuffer response)
/*      */   {
/*  884 */     StringBuilder sb = new StringBuilder();
/*      */     
/*  886 */     char c = '\000';
/*  887 */     while (response.hasRemaining()) {
/*  888 */       c = (char)response.get();
/*  889 */       sb.append(c);
/*  890 */       if (c == '\n') {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/*  895 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private SSLEngine createSSLEngine(Map<String, Object> userProperties, String host, int port)
/*      */     throws DeploymentException
/*      */   {
/*      */     try
/*      */     {
/*  905 */       SSLContext sslContext = (SSLContext)userProperties.get("org.apache.tomcat.websocket.SSL_CONTEXT");
/*      */       
/*  907 */       if (sslContext == null)
/*      */       {
/*  909 */         sslContext = SSLContext.getInstance("TLS");
/*      */         
/*      */ 
/*      */ 
/*  913 */         String sslTrustStoreValue = (String)userProperties.get("org.apache.tomcat.websocket.SSL_TRUSTSTORE");
/*  914 */         if (sslTrustStoreValue != null) {
/*  915 */           String sslTrustStorePwdValue = (String)userProperties.get("org.apache.tomcat.websocket.SSL_TRUSTSTORE_PWD");
/*      */           
/*  917 */           if (sslTrustStorePwdValue == null) {
/*  918 */             sslTrustStorePwdValue = "changeit";
/*      */           }
/*      */           
/*  921 */           File keyStoreFile = new File(sslTrustStoreValue);
/*  922 */           KeyStore ks = KeyStore.getInstance("JKS");
/*  923 */           InputStream is = new FileInputStream(keyStoreFile);Throwable localThrowable3 = null;
/*  924 */           try { KeyStoreUtil.load(ks, is, sslTrustStorePwdValue.toCharArray());
/*      */           }
/*      */           catch (Throwable localThrowable1)
/*      */           {
/*  923 */             localThrowable3 = localThrowable1;throw localThrowable1;
/*      */           } finally {
/*  925 */             if (is != null) if (localThrowable3 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else is.close();
/*      */           }
/*  927 */           TrustManagerFactory tmf = TrustManagerFactory.getInstance(
/*  928 */             TrustManagerFactory.getDefaultAlgorithm());
/*  929 */           tmf.init(ks);
/*      */           
/*  931 */           sslContext.init(null, tmf.getTrustManagers(), null);
/*      */         } else {
/*  933 */           sslContext.init(null, null, null);
/*      */         }
/*      */       }
/*      */       
/*  937 */       SSLEngine engine = sslContext.createSSLEngine(host, port);
/*      */       
/*      */ 
/*  940 */       String sslProtocolsValue = (String)userProperties.get("org.apache.tomcat.websocket.SSL_PROTOCOLS");
/*  941 */       if (sslProtocolsValue != null) {
/*  942 */         engine.setEnabledProtocols(sslProtocolsValue.split(","));
/*      */       }
/*      */       
/*  945 */       engine.setUseClientMode(true);
/*      */       
/*      */ 
/*      */ 
/*  949 */       SSLParameters sslParams = engine.getSSLParameters();
/*      */       
/*  951 */       sslParams.setEndpointIdentificationAlgorithm("HTTPS");
/*      */       
/*  953 */       engine.setSSLParameters(sslParams);
/*      */       
/*  955 */       return engine;
/*      */     } catch (Exception e) {
/*  957 */       throw new DeploymentException(sm.getString("wsWebSocketContainer.sslEngineFail"), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public long getDefaultMaxSessionIdleTimeout()
/*      */   {
/*  965 */     return this.defaultMaxSessionIdleTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDefaultMaxSessionIdleTimeout(long timeout)
/*      */   {
/*  971 */     this.defaultMaxSessionIdleTimeout = timeout;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getDefaultMaxBinaryMessageBufferSize()
/*      */   {
/*  977 */     return this.maxBinaryMessageBufferSize;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDefaultMaxBinaryMessageBufferSize(int max)
/*      */   {
/*  983 */     this.maxBinaryMessageBufferSize = max;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getDefaultMaxTextMessageBufferSize()
/*      */   {
/*  989 */     return this.maxTextMessageBufferSize;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDefaultMaxTextMessageBufferSize(int max)
/*      */   {
/*  995 */     this.maxTextMessageBufferSize = max;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<Extension> getInstalledExtensions()
/*      */   {
/* 1006 */     return Collections.emptySet();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getDefaultAsyncSendTimeout()
/*      */   {
/* 1017 */     return this.defaultAsyncTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAsyncSendTimeout(long timeout)
/*      */   {
/* 1028 */     this.defaultAsyncTimeout = timeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void destroy()
/*      */   {
/* 1039 */     CloseReason cr = new CloseReason(CloseReason.CloseCodes.GOING_AWAY, sm.getString("wsWebSocketContainer.shutdown"));
/*      */     
/* 1041 */     for (WsSession session : this.sessions.keySet()) {
/*      */       try {
/* 1043 */         session.close(cr);
/*      */       } catch (IOException ioe) {
/* 1045 */         this.log.debug(sm.getString("wsWebSocketContainer.sessionCloseFail", new Object[] {session
/* 1046 */           .getId() }), ioe);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1052 */     if (this.asynchronousChannelGroup != null) {
/* 1053 */       synchronized (this.asynchronousChannelGroupLock) {
/* 1054 */         if (this.asynchronousChannelGroup != null) {
/* 1055 */           AsyncChannelGroupUtil.unregister();
/* 1056 */           this.asynchronousChannelGroup = null;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private AsynchronousChannelGroup getAsynchronousChannelGroup()
/*      */   {
/* 1066 */     AsynchronousChannelGroup result = this.asynchronousChannelGroup;
/* 1067 */     if (result == null) {
/* 1068 */       synchronized (this.asynchronousChannelGroupLock) {
/* 1069 */         if (this.asynchronousChannelGroup == null) {
/* 1070 */           this.asynchronousChannelGroup = AsyncChannelGroupUtil.register();
/*      */         }
/* 1072 */         result = this.asynchronousChannelGroup;
/*      */       }
/*      */     }
/* 1075 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void backgroundProcess()
/*      */   {
/* 1084 */     this.backgroundProcessCount += 1;
/* 1085 */     if (this.backgroundProcessCount >= this.processPeriod) {
/* 1086 */       this.backgroundProcessCount = 0;
/*      */       
/* 1088 */       for (WsSession wsSession : this.sessions.keySet()) {
/* 1089 */         wsSession.checkExpiration();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setProcessPeriod(int period)
/*      */   {
/* 1098 */     this.processPeriod = period;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getProcessPeriod()
/*      */   {
/* 1110 */     return this.processPeriod;
/*      */   }
/*      */   
/*      */   private static class HttpResponse
/*      */   {
/*      */     private final int status;
/*      */     private final HandshakeResponse handshakeResponse;
/*      */     
/*      */     public HttpResponse(int status, HandshakeResponse handshakeResponse) {
/* 1119 */       this.status = status;
/* 1120 */       this.handshakeResponse = handshakeResponse;
/*      */     }
/*      */     
/*      */     public int getStatus()
/*      */     {
/* 1125 */       return this.status;
/*      */     }
/*      */     
/*      */     public HandshakeResponse getHandshakeResponse()
/*      */     {
/* 1130 */       return this.handshakeResponse;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\WsWebSocketContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */