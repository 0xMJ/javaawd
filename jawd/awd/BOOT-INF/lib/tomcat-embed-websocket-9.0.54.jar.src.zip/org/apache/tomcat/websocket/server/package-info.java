package org.apache.tomcat.websocket.server;

interface package-info {}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\server\package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */