/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContainerInitializer;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.annotation.HandlesTypes;
/*     */ import javax.websocket.ContainerProvider;
/*     */ import javax.websocket.DeploymentException;
/*     */ import javax.websocket.Endpoint;
/*     */ import javax.websocket.server.ServerApplicationConfig;
/*     */ import javax.websocket.server.ServerEndpoint;
/*     */ import javax.websocket.server.ServerEndpointConfig;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @HandlesTypes({ServerEndpoint.class, ServerApplicationConfig.class, Endpoint.class})
/*     */ public class WsSci
/*     */   implements ServletContainerInitializer
/*     */ {
/*     */   public void onStartup(Set<Class<?>> clazzes, ServletContext ctx)
/*     */     throws ServletException
/*     */   {
/*  49 */     WsServerContainer sc = init(ctx, true);
/*     */     
/*  51 */     if ((clazzes == null) || (clazzes.size() == 0)) {
/*  52 */       return;
/*     */     }
/*     */     
/*     */ 
/*  56 */     Set<ServerApplicationConfig> serverApplicationConfigs = new HashSet();
/*  57 */     Set<Class<? extends Endpoint>> scannedEndpointClazzes = new HashSet();
/*  58 */     Set<Class<?>> scannedPojoEndpoints = new HashSet();
/*     */     Class<?> clazz;
/*     */     try
/*     */     {
/*  62 */       wsPackage = ContainerProvider.class.getName();
/*  63 */       wsPackage = wsPackage.substring(0, wsPackage.lastIndexOf('.') + 1);
/*  64 */       for (localIterator = clazzes.iterator(); localIterator.hasNext();) { clazz = (Class)localIterator.next();
/*  65 */         JreCompat jreCompat = JreCompat.getInstance();
/*  66 */         int modifiers = clazz.getModifiers();
/*  67 */         if ((Modifier.isPublic(modifiers)) && 
/*  68 */           (!Modifier.isAbstract(modifiers)) && 
/*  69 */           (!Modifier.isInterface(modifiers)) && 
/*  70 */           (jreCompat.isExported(clazz)) && 
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */           (!clazz.getName().startsWith(wsPackage)))
/*     */         {
/*     */ 
/*  79 */           if (ServerApplicationConfig.class.isAssignableFrom(clazz)) {
/*  80 */             serverApplicationConfigs.add(
/*  81 */               (ServerApplicationConfig)clazz.getConstructor(new Class[0]).newInstance(new Object[0]));
/*     */           }
/*  83 */           if (Endpoint.class.isAssignableFrom(clazz))
/*     */           {
/*  85 */             Class<? extends Endpoint> endpoint = clazz;
/*     */             
/*  87 */             scannedEndpointClazzes.add(endpoint);
/*     */           }
/*  89 */           if (clazz.isAnnotationPresent(ServerEndpoint.class))
/*  90 */             scannedPojoEndpoints.add(clazz);
/*     */         }
/*     */       } } catch (ReflectiveOperationException e) { String wsPackage;
/*     */       Iterator localIterator;
/*  94 */       throw new ServletException(e);
/*     */     }
/*     */     
/*     */ 
/*  98 */     Set<ServerEndpointConfig> filteredEndpointConfigs = new HashSet();
/*  99 */     Object filteredPojoEndpoints = new HashSet();
/*     */     
/* 101 */     if (serverApplicationConfigs.isEmpty()) {
/* 102 */       ((Set)filteredPojoEndpoints).addAll(scannedPojoEndpoints);
/*     */     } else {
/* 104 */       for (ServerApplicationConfig config : serverApplicationConfigs)
/*     */       {
/* 106 */         Set<ServerEndpointConfig> configFilteredEndpoints = config.getEndpointConfigs(scannedEndpointClazzes);
/* 107 */         if (configFilteredEndpoints != null) {
/* 108 */           filteredEndpointConfigs.addAll(configFilteredEndpoints);
/*     */         }
/*     */         
/* 111 */         Set<Class<?>> configFilteredPojos = config.getAnnotatedEndpointClasses(scannedPojoEndpoints);
/*     */         
/* 113 */         if (configFilteredPojos != null) {
/* 114 */           ((Set)filteredPojoEndpoints).addAll(configFilteredPojos);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 121 */       for (ServerEndpointConfig config : filteredEndpointConfigs) {
/* 122 */         sc.addEndpoint(config);
/*     */       }
/*     */       
/* 125 */       for (Class<?> clazz : (Set)filteredPojoEndpoints) {
/* 126 */         sc.addEndpoint(clazz, true);
/*     */       }
/*     */     } catch (DeploymentException e) {
/* 129 */       throw new ServletException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static WsServerContainer init(ServletContext servletContext, boolean initBySciMechanism)
/*     */   {
/* 137 */     WsServerContainer sc = new WsServerContainer(servletContext);
/*     */     
/* 139 */     servletContext.setAttribute("javax.websocket.server.ServerContainer", sc);
/*     */     
/*     */ 
/* 142 */     servletContext.addListener(new WsSessionListener(sc));
/*     */     
/*     */ 
/* 145 */     if (initBySciMechanism) {
/* 146 */       servletContext.addListener(new WsContextListener());
/*     */     }
/*     */     
/* 149 */     return sc;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\server\WsSci.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */