/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import javax.naming.NamingException;
/*    */ import javax.websocket.DeploymentException;
/*    */ import javax.websocket.Endpoint;
/*    */ import org.apache.tomcat.InstanceManager;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndpointHolder
/*    */   implements ClientEndpointHolder
/*    */ {
/* 28 */   private static final StringManager sm = StringManager.getManager(EndpointHolder.class);
/*    */   
/*    */   private final Endpoint endpoint;
/*    */   
/*    */   public EndpointHolder(Endpoint endpoint)
/*    */   {
/* 34 */     this.endpoint = endpoint;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getClassName()
/*    */   {
/* 40 */     return this.endpoint.getClass().getName();
/*    */   }
/*    */   
/*    */   public Endpoint getInstance(InstanceManager instanceManager)
/*    */     throws DeploymentException
/*    */   {
/* 46 */     if (instanceManager != null) {
/*    */       try {
/* 48 */         instanceManager.newInstance(this.endpoint);
/*    */       } catch (ReflectiveOperationException|NamingException e) {
/* 50 */         throw new DeploymentException(sm.getString("clientEndpointHolder.instanceRegistrationFailed"), e);
/*    */       }
/*    */     }
/* 53 */     return this.endpoint;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\EndpointHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */