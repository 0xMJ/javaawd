/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.CompletionHandler;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.websocket.SendHandler;
/*     */ import javax.websocket.SendResult;
/*     */ import org.apache.coyote.http11.upgrade.UpgradeInfo;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.net.SocketWrapperBase;
/*     */ import org.apache.tomcat.util.net.SocketWrapperBase.BlockingMode;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.Transformation;
/*     */ import org.apache.tomcat.websocket.WsRemoteEndpointImplBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsRemoteEndpointImplServer
/*     */   extends WsRemoteEndpointImplBase
/*     */ {
/*  46 */   private static final StringManager sm = StringManager.getManager(WsRemoteEndpointImplServer.class);
/*  47 */   private final Log log = LogFactory.getLog(WsRemoteEndpointImplServer.class);
/*     */   
/*     */   private final SocketWrapperBase<?> socketWrapper;
/*     */   private final UpgradeInfo upgradeInfo;
/*     */   private final WsWriteTimeout wsWriteTimeout;
/*  52 */   private volatile SendHandler handler = null;
/*  53 */   private volatile ByteBuffer[] buffers = null;
/*     */   
/*  55 */   private volatile long timeoutExpiry = -1L;
/*     */   
/*     */   public WsRemoteEndpointImplServer(SocketWrapperBase<?> socketWrapper, UpgradeInfo upgradeInfo, WsServerContainer serverContainer)
/*     */   {
/*  59 */     this.socketWrapper = socketWrapper;
/*  60 */     this.upgradeInfo = upgradeInfo;
/*  61 */     this.wsWriteTimeout = serverContainer.getTimeout();
/*     */   }
/*     */   
/*     */ 
/*     */   protected final boolean isMasked()
/*     */   {
/*  67 */     return false;
/*     */   }
/*     */   
/*     */   protected void doWrite(SendHandler handler, final long blockingWriteTimeoutExpiry, ByteBuffer... buffers)
/*     */   {
/*     */     final boolean block;
/*     */     long timeout;
/*  74 */     if (this.socketWrapper.hasAsyncIO()) {
/*  75 */       block = blockingWriteTimeoutExpiry != -1L;
/*  76 */       timeout = -1L;
/*  77 */       if (block) {
/*  78 */         timeout = blockingWriteTimeoutExpiry - System.currentTimeMillis();
/*  79 */         if (timeout <= 0L) {
/*  80 */           SendResult sr = new SendResult(new SocketTimeoutException());
/*  81 */           handler.onResult(sr);
/*     */         }
/*     */       }
/*     */       else {
/*  85 */         this.handler = handler;
/*  86 */         timeout = getSendTimeout();
/*  87 */         if (timeout > 0L)
/*     */         {
/*  89 */           this.timeoutExpiry = (timeout + System.currentTimeMillis());
/*  90 */           this.wsWriteTimeout.register(this);
/*     */         }
/*     */       }
/*  93 */       this.socketWrapper.write(block ? SocketWrapperBase.BlockingMode.BLOCK : SocketWrapperBase.BlockingMode.SEMI_BLOCK, timeout, TimeUnit.MILLISECONDS, null, SocketWrapperBase.COMPLETE_WRITE_WITH_COMPLETION, new CompletionHandler()
/*     */       {
/*     */ 
/*     */         public void completed(Long result, Void attachment)
/*     */         {
/*  98 */           if (block) {
/*  99 */             long timeout = blockingWriteTimeoutExpiry - System.currentTimeMillis();
/* 100 */             if (timeout <= 0L) {
/* 101 */               failed(new SocketTimeoutException(), null);
/*     */             } else {
/* 103 */               this.val$handler.onResult(WsRemoteEndpointImplServer.SENDRESULT_OK);
/*     */             }
/*     */           } else {
/* 106 */             WsRemoteEndpointImplServer.this.wsWriteTimeout.unregister(WsRemoteEndpointImplServer.this);
/* 107 */             WsRemoteEndpointImplServer.this.clearHandler(null, true);
/*     */           }
/*     */         }
/*     */         
/*     */         public void failed(Throwable exc, Void attachment) {
/* 112 */           if (block) {
/* 113 */             SendResult sr = new SendResult(exc);
/* 114 */             this.val$handler.onResult(sr);
/*     */           } else {
/* 116 */             WsRemoteEndpointImplServer.this.wsWriteTimeout.unregister(WsRemoteEndpointImplServer.this);
/* 117 */             WsRemoteEndpointImplServer.this.clearHandler(exc, true);
/* 118 */             WsRemoteEndpointImplServer.this.close(); } } }, buffers);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 123 */     else if (blockingWriteTimeoutExpiry == -1L) {
/* 124 */       this.handler = handler;
/* 125 */       this.buffers = buffers;
/*     */       
/*     */ 
/* 128 */       onWritePossible(true);
/*     */     }
/*     */     else {
/*     */       try {
/* 132 */         block = buffers;timeout = block.length; for (long l1 = 0; l1 < timeout; l1++) { ByteBuffer buffer = block[l1];
/* 133 */           long timeout = blockingWriteTimeoutExpiry - System.currentTimeMillis();
/* 134 */           if (timeout <= 0L) {
/* 135 */             SendResult sr = new SendResult(new SocketTimeoutException());
/* 136 */             handler.onResult(sr);
/* 137 */             return;
/*     */           }
/* 139 */           this.socketWrapper.setWriteTimeout(timeout);
/* 140 */           this.socketWrapper.write(true, buffer);
/*     */         }
/* 142 */         long timeout = blockingWriteTimeoutExpiry - System.currentTimeMillis();
/* 143 */         if (timeout <= 0L) {
/* 144 */           SendResult sr = new SendResult(new SocketTimeoutException());
/* 145 */           handler.onResult(sr);
/* 146 */           return;
/*     */         }
/* 148 */         this.socketWrapper.setWriteTimeout(timeout);
/* 149 */         this.socketWrapper.flush(true);
/* 150 */         handler.onResult(SENDRESULT_OK);
/*     */       } catch (IOException e) {
/* 152 */         SendResult sr = new SendResult(e);
/* 153 */         handler.onResult(sr);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void updateStats(long payloadLength)
/*     */   {
/* 162 */     this.upgradeInfo.addMsgsSent(1L);
/* 163 */     this.upgradeInfo.addBytesSent(payloadLength);
/*     */   }
/*     */   
/*     */ 
/*     */   public void onWritePossible(boolean useDispatch)
/*     */   {
/* 169 */     ByteBuffer[] buffers = this.buffers;
/* 170 */     if (buffers == null)
/*     */     {
/*     */ 
/* 173 */       return;
/*     */     }
/* 175 */     boolean complete = false;
/*     */     try {
/* 177 */       this.socketWrapper.flush(false);
/*     */       
/* 179 */       while (this.socketWrapper.isReadyForWrite()) {
/* 180 */         complete = true;
/* 181 */         for (ByteBuffer buffer : buffers) {
/* 182 */           if (buffer.hasRemaining()) {
/* 183 */             complete = false;
/* 184 */             this.socketWrapper.write(false, buffer);
/* 185 */             break;
/*     */           }
/*     */         }
/* 188 */         if (complete) {
/* 189 */           this.socketWrapper.flush(false);
/* 190 */           complete = this.socketWrapper.isReadyForWrite();
/* 191 */           if (complete) {
/* 192 */             this.wsWriteTimeout.unregister(this);
/* 193 */             clearHandler(null, useDispatch);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IOException|IllegalStateException e) {
/* 199 */       this.wsWriteTimeout.unregister(this);
/* 200 */       clearHandler(e, useDispatch);
/* 201 */       close();
/*     */     }
/*     */     
/* 204 */     if (!complete)
/*     */     {
/* 206 */       long timeout = getSendTimeout();
/* 207 */       if (timeout > 0L)
/*     */       {
/* 209 */         this.timeoutExpiry = (timeout + System.currentTimeMillis());
/* 210 */         this.wsWriteTimeout.register(this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void doClose()
/*     */   {
/* 218 */     if (this.handler != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 223 */       clearHandler(new EOFException(), true);
/*     */     }
/*     */     try {
/* 226 */       this.socketWrapper.close();
/*     */     } catch (Exception e) {
/* 228 */       if (this.log.isInfoEnabled()) {
/* 229 */         this.log.info(sm.getString("wsRemoteEndpointServer.closeFailed"), e);
/*     */       }
/*     */     }
/* 232 */     this.wsWriteTimeout.unregister(this);
/*     */   }
/*     */   
/*     */   protected long getTimeoutExpiry()
/*     */   {
/* 237 */     return this.timeoutExpiry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void onTimeout(boolean useDispatch)
/*     */   {
/* 249 */     if (this.handler != null) {
/* 250 */       clearHandler(new SocketTimeoutException(), useDispatch);
/*     */     }
/* 252 */     close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void setTransformation(Transformation transformation)
/*     */   {
/* 259 */     super.setTransformation(transformation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void clearHandler(Throwable t, boolean useDispatch)
/*     */   {
/* 278 */     SendHandler sh = this.handler;
/* 279 */     this.handler = null;
/* 280 */     this.buffers = null;
/* 281 */     if (sh != null) {
/* 282 */       if (useDispatch) {
/* 283 */         OnResultRunnable r = new OnResultRunnable(sh, t, null);
/*     */         try {
/* 285 */           this.socketWrapper.execute(r);
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         catch (RejectedExecutionException ree)
/*     */         {
/*     */ 
/*     */ 
/* 294 */           r.run();
/*     */         }
/*     */       }
/* 297 */       else if (t == null) {
/* 298 */         sh.onResult(new SendResult());
/*     */       } else {
/* 300 */         sh.onResult(new SendResult(t));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class OnResultRunnable
/*     */     implements Runnable
/*     */   {
/*     */     private final SendHandler sh;
/*     */     private final Throwable t;
/*     */     
/*     */     private OnResultRunnable(SendHandler sh, Throwable t)
/*     */     {
/* 313 */       this.sh = sh;
/* 314 */       this.t = t;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 319 */       if (this.t == null) {
/* 320 */         this.sh.onResult(new SendResult());
/*     */       } else {
/* 322 */         this.sh.onResult(new SendResult(this.t));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\server\WsRemoteEndpointImplServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */