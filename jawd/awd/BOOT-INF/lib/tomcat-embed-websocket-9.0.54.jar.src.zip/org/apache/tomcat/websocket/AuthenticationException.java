/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 5709887412240096441L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AuthenticationException(String message)
/*    */   {
/* 32 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\AuthenticationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */