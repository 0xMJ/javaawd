/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Deflater;
/*     */ import java.util.zip.Inflater;
/*     */ import javax.websocket.Extension;
/*     */ import javax.websocket.Extension.Parameter;
/*     */ import javax.websocket.SendHandler;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PerMessageDeflate
/*     */   implements Transformation
/*     */ {
/*  35 */   private static final StringManager sm = StringManager.getManager(PerMessageDeflate.class);
/*     */   
/*     */   private static final String SERVER_NO_CONTEXT_TAKEOVER = "server_no_context_takeover";
/*     */   
/*     */   private static final String CLIENT_NO_CONTEXT_TAKEOVER = "client_no_context_takeover";
/*     */   private static final String SERVER_MAX_WINDOW_BITS = "server_max_window_bits";
/*     */   private static final String CLIENT_MAX_WINDOW_BITS = "client_max_window_bits";
/*     */   private static final int RSV_BITMASK = 4;
/*  43 */   private static final byte[] EOM_BYTES = { 0, 0, -1, -1 };
/*     */   
/*     */   public static final String NAME = "permessage-deflate";
/*     */   
/*     */   private final boolean serverContextTakeover;
/*     */   private final int serverMaxWindowBits;
/*     */   private final boolean clientContextTakeover;
/*     */   private final int clientMaxWindowBits;
/*     */   private final boolean isServer;
/*  52 */   private final Inflater inflater = new Inflater(true);
/*  53 */   private final ByteBuffer readBuffer = ByteBuffer.allocate(Constants.DEFAULT_BUFFER_SIZE);
/*  54 */   private final Deflater deflater = new Deflater(-1, true);
/*  55 */   private final byte[] EOM_BUFFER = new byte[EOM_BYTES.length + 1];
/*     */   
/*     */   private volatile Transformation next;
/*  58 */   private volatile boolean skipDecompression = false;
/*  59 */   private volatile ByteBuffer writeBuffer = ByteBuffer.allocate(Constants.DEFAULT_BUFFER_SIZE);
/*  60 */   private volatile boolean firstCompressedFrameWritten = false;
/*     */   
/*  62 */   private volatile boolean emptyMessage = true;
/*     */   
/*     */   static PerMessageDeflate negotiate(List<List<Extension.Parameter>> preferences, boolean isServer)
/*     */   {
/*  66 */     for (List<Extension.Parameter> preference : preferences) {
/*  67 */       boolean ok = true;
/*  68 */       boolean serverContextTakeover = true;
/*  69 */       int serverMaxWindowBits = -1;
/*  70 */       boolean clientContextTakeover = true;
/*  71 */       int clientMaxWindowBits = -1;
/*     */       
/*  73 */       for (Extension.Parameter param : preference) {
/*  74 */         if ("server_no_context_takeover".equals(param.getName())) {
/*  75 */           if (serverContextTakeover) {
/*  76 */             serverContextTakeover = false;
/*     */           }
/*     */           else {
/*  79 */             throw new IllegalArgumentException(sm.getString("perMessageDeflate.duplicateParameter", new Object[] { "server_no_context_takeover" }));
/*     */           }
/*     */           
/*     */         }
/*  83 */         else if ("client_no_context_takeover".equals(param.getName())) {
/*  84 */           if (clientContextTakeover) {
/*  85 */             clientContextTakeover = false;
/*     */           }
/*     */           else {
/*  88 */             throw new IllegalArgumentException(sm.getString("perMessageDeflate.duplicateParameter", new Object[] { "client_no_context_takeover" }));
/*     */           }
/*     */           
/*     */         }
/*  92 */         else if ("server_max_window_bits".equals(param.getName())) {
/*  93 */           if (serverMaxWindowBits == -1) {
/*  94 */             serverMaxWindowBits = Integer.parseInt(param.getValue());
/*  95 */             if ((serverMaxWindowBits < 8) || (serverMaxWindowBits > 15)) {
/*  96 */               throw new IllegalArgumentException(sm.getString("perMessageDeflate.invalidWindowSize", new Object[] { "server_max_window_bits", 
/*     */               
/*     */ 
/*  99 */                 Integer.valueOf(serverMaxWindowBits) }));
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 104 */             if ((isServer) && (serverMaxWindowBits != 15)) {
/* 105 */               ok = false;
/* 106 */               break;
/*     */             }
/*     */             
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 114 */             throw new IllegalArgumentException(sm.getString("perMessageDeflate.duplicateParameter", new Object[] { "server_max_window_bits" }));
/*     */           }
/*     */           
/*     */         }
/* 118 */         else if ("client_max_window_bits".equals(param.getName())) {
/* 119 */           if (clientMaxWindowBits == -1) {
/* 120 */             if (param.getValue() == null)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 125 */               clientMaxWindowBits = 15;
/*     */             } else {
/* 127 */               clientMaxWindowBits = Integer.parseInt(param.getValue());
/* 128 */               if ((clientMaxWindowBits < 8) || (clientMaxWindowBits > 15)) {
/* 129 */                 throw new IllegalArgumentException(sm.getString("perMessageDeflate.invalidWindowSize", new Object[] { "client_max_window_bits", 
/*     */                 
/*     */ 
/* 132 */                   Integer.valueOf(clientMaxWindowBits) }));
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 138 */             if ((!isServer) && (clientMaxWindowBits != 15)) {
/* 139 */               ok = false;
/* 140 */               break;
/*     */             }
/*     */             
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 148 */             throw new IllegalArgumentException(sm.getString("perMessageDeflate.duplicateParameter", new Object[] { "client_max_window_bits" }));
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         else {
/* 154 */           throw new IllegalArgumentException(sm.getString("perMessageDeflate.unknownParameter", new Object[] {param
/* 155 */             .getName() }));
/*     */         }
/*     */       }
/* 158 */       if (ok) {
/* 159 */         return new PerMessageDeflate(serverContextTakeover, serverMaxWindowBits, clientContextTakeover, clientMaxWindowBits, isServer);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 164 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private PerMessageDeflate(boolean serverContextTakeover, int serverMaxWindowBits, boolean clientContextTakeover, int clientMaxWindowBits, boolean isServer)
/*     */   {
/* 170 */     this.serverContextTakeover = serverContextTakeover;
/* 171 */     this.serverMaxWindowBits = serverMaxWindowBits;
/* 172 */     this.clientContextTakeover = clientContextTakeover;
/* 173 */     this.clientMaxWindowBits = clientMaxWindowBits;
/* 174 */     this.isServer = isServer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TransformationResult getMoreData(byte opCode, boolean fin, int rsv, ByteBuffer dest)
/*     */     throws IOException
/*     */   {
/* 183 */     if (Util.isControl(opCode)) {
/* 184 */       return this.next.getMoreData(opCode, fin, rsv, dest);
/*     */     }
/*     */     
/* 187 */     if (!Util.isContinuation(opCode))
/*     */     {
/* 189 */       this.skipDecompression = ((rsv & 0x4) == 0);
/*     */     }
/*     */     
/*     */ 
/* 193 */     if (this.skipDecompression) {
/* 194 */       return this.next.getMoreData(opCode, fin, rsv, dest);
/*     */     }
/*     */     
/*     */ 
/* 198 */     boolean usedEomBytes = false;
/*     */     
/* 200 */     while ((dest.remaining() > 0) || (usedEomBytes))
/*     */     {
/*     */       try {
/* 203 */         written = this.inflater.inflate(dest
/* 204 */           .array(), dest.arrayOffset() + dest.position(), dest.remaining());
/*     */       } catch (DataFormatException e) { int written;
/* 206 */         throw new IOException(sm.getString("perMessageDeflate.deflateFailed"), e);
/*     */       } catch (NullPointerException e) {
/* 208 */         throw new IOException(sm.getString("perMessageDeflate.alreadyClosed"), e); }
/*     */       int written;
/* 210 */       dest.position(dest.position() + written);
/*     */       
/* 212 */       if ((this.inflater.needsInput()) && (!usedEomBytes)) {
/* 213 */         this.readBuffer.clear();
/* 214 */         TransformationResult nextResult = this.next.getMoreData(opCode, fin, rsv ^ 0x4, this.readBuffer);
/* 215 */         this.inflater.setInput(this.readBuffer.array(), this.readBuffer.arrayOffset(), this.readBuffer.position());
/* 216 */         if (dest.hasRemaining()) {
/* 217 */           if (TransformationResult.UNDERFLOW.equals(nextResult))
/* 218 */             return nextResult;
/* 219 */           if ((TransformationResult.END_OF_FRAME.equals(nextResult)) && 
/* 220 */             (this.readBuffer.position() == 0))
/* 221 */             if (fin) {
/* 222 */               this.inflater.setInput(EOM_BYTES);
/* 223 */               usedEomBytes = true;
/*     */             } else {
/* 225 */               return TransformationResult.END_OF_FRAME;
/*     */             }
/*     */         } else {
/* 228 */           if (this.readBuffer.position() > 0)
/* 229 */             return TransformationResult.OVERFLOW;
/* 230 */           if (fin) {
/* 231 */             this.inflater.setInput(EOM_BYTES);
/* 232 */             usedEomBytes = true;
/*     */           }
/* 234 */         } } else if (written == 0) {
/* 235 */         if ((fin) && (((this.isServer) && (!this.clientContextTakeover)) || ((!this.isServer) && (!this.serverContextTakeover)))) {
/*     */           try
/*     */           {
/* 238 */             this.inflater.reset();
/*     */           } catch (NullPointerException e) {
/* 240 */             throw new IOException(sm.getString("perMessageDeflate.alreadyClosed"), e);
/*     */           }
/*     */         }
/* 243 */         return TransformationResult.END_OF_FRAME;
/*     */       }
/*     */     }
/*     */     
/* 247 */     return TransformationResult.OVERFLOW;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean validateRsv(int rsv, byte opCode)
/*     */   {
/* 253 */     if (Util.isControl(opCode)) {
/* 254 */       if ((rsv & 0x4) != 0) {
/* 255 */         return false;
/*     */       }
/* 257 */       if (this.next == null) {
/* 258 */         return true;
/*     */       }
/* 260 */       return this.next.validateRsv(rsv, opCode);
/*     */     }
/*     */     
/*     */ 
/* 264 */     int rsvNext = rsv;
/* 265 */     if ((rsv & 0x4) != 0) {
/* 266 */       rsvNext = rsv ^ 0x4;
/*     */     }
/* 268 */     if (this.next == null) {
/* 269 */       return true;
/*     */     }
/* 271 */     return this.next.validateRsv(rsvNext, opCode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Extension getExtensionResponse()
/*     */   {
/* 279 */     Extension result = new WsExtension("permessage-deflate");
/*     */     
/* 281 */     List<Extension.Parameter> params = result.getParameters();
/*     */     
/* 283 */     if (!this.serverContextTakeover) {
/* 284 */       params.add(new WsExtensionParameter("server_no_context_takeover", null));
/*     */     }
/* 286 */     if (this.serverMaxWindowBits != -1) {
/* 287 */       params.add(new WsExtensionParameter("server_max_window_bits", 
/* 288 */         Integer.toString(this.serverMaxWindowBits)));
/*     */     }
/* 290 */     if (!this.clientContextTakeover) {
/* 291 */       params.add(new WsExtensionParameter("client_no_context_takeover", null));
/*     */     }
/* 293 */     if (this.clientMaxWindowBits != -1) {
/* 294 */       params.add(new WsExtensionParameter("client_max_window_bits", 
/* 295 */         Integer.toString(this.clientMaxWindowBits)));
/*     */     }
/*     */     
/* 298 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setNext(Transformation t)
/*     */   {
/* 304 */     if (this.next == null) {
/* 305 */       this.next = t;
/*     */     } else {
/* 307 */       this.next.setNext(t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean validateRsvBits(int i)
/*     */   {
/* 314 */     if ((i & 0x4) != 0) {
/* 315 */       return false;
/*     */     }
/* 317 */     if (this.next == null) {
/* 318 */       return true;
/*     */     }
/* 320 */     return this.next.validateRsvBits(i | 0x4);
/*     */   }
/*     */   
/*     */ 
/*     */   public List<MessagePart> sendMessagePart(List<MessagePart> uncompressedParts)
/*     */     throws IOException
/*     */   {
/* 327 */     List<MessagePart> allCompressedParts = new ArrayList();
/*     */     
/* 329 */     for (MessagePart uncompressedPart : uncompressedParts) {
/* 330 */       byte opCode = uncompressedPart.getOpCode();
/* 331 */       boolean emptyPart = uncompressedPart.getPayload().limit() == 0;
/* 332 */       this.emptyMessage = ((this.emptyMessage) && (emptyPart));
/* 333 */       if (Util.isControl(opCode))
/*     */       {
/*     */ 
/* 336 */         allCompressedParts.add(uncompressedPart);
/* 337 */       } else if ((this.emptyMessage) && (uncompressedPart.isFin()))
/*     */       {
/*     */ 
/* 340 */         allCompressedParts.add(uncompressedPart);
/*     */       } else {
/* 342 */         List<MessagePart> compressedParts = new ArrayList();
/* 343 */         ByteBuffer uncompressedPayload = uncompressedPart.getPayload();
/*     */         
/* 345 */         SendHandler uncompressedIntermediateHandler = uncompressedPart.getIntermediateHandler();
/*     */         
/* 347 */         this.deflater.setInput(uncompressedPayload.array(), uncompressedPayload
/* 348 */           .arrayOffset() + uncompressedPayload.position(), uncompressedPayload
/* 349 */           .remaining());
/*     */         
/* 351 */         int flush = uncompressedPart.isFin() ? 2 : 0;
/* 352 */         boolean deflateRequired = true;
/*     */         
/* 354 */         while (deflateRequired) {
/* 355 */           ByteBuffer compressedPayload = this.writeBuffer;
/*     */           try
/*     */           {
/* 358 */             int written = this.deflater.deflate(compressedPayload.array(), compressedPayload
/* 359 */               .arrayOffset() + compressedPayload.position(), compressedPayload
/* 360 */               .remaining(), flush);
/* 361 */             compressedPayload.position(compressedPayload.position() + written);
/*     */           } catch (NullPointerException e) {
/* 363 */             throw new IOException(sm.getString("perMessageDeflate.alreadyClosed"), e);
/*     */           }
/*     */           
/* 366 */           if ((!uncompressedPart.isFin()) && (compressedPayload.hasRemaining()) && (this.deflater.needsInput())) {
/*     */             break;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 378 */           this.writeBuffer = ByteBuffer.allocate(Constants.DEFAULT_BUFFER_SIZE);
/*     */           
/*     */ 
/* 381 */           compressedPayload.flip();
/*     */           
/* 383 */           boolean fin = uncompressedPart.isFin();
/* 384 */           boolean full = compressedPayload.limit() == compressedPayload.capacity();
/* 385 */           boolean needsInput = this.deflater.needsInput();
/* 386 */           long blockingWriteTimeoutExpiry = uncompressedPart.getBlockingWriteTimeoutExpiry();
/*     */           
/* 388 */           if ((fin) && (!full) && (needsInput))
/*     */           {
/* 390 */             compressedPayload.limit(compressedPayload.limit() - EOM_BYTES.length);
/* 391 */             MessagePart compressedPart = new MessagePart(true, getRsv(uncompressedPart), opCode, compressedPayload, uncompressedIntermediateHandler, uncompressedIntermediateHandler, blockingWriteTimeoutExpiry);
/*     */             
/*     */ 
/* 394 */             deflateRequired = false;
/* 395 */             startNewMessage(); } else { MessagePart compressedPart;
/* 396 */             if ((full) && (!needsInput))
/*     */             {
/*     */ 
/* 399 */               compressedPart = new MessagePart(false, getRsv(uncompressedPart), opCode, compressedPayload, uncompressedIntermediateHandler, uncompressedIntermediateHandler, blockingWriteTimeoutExpiry);
/*     */ 
/*     */             }
/* 402 */             else if ((!fin) && (full) && (needsInput))
/*     */             {
/*     */ 
/* 405 */               MessagePart compressedPart = new MessagePart(false, getRsv(uncompressedPart), opCode, compressedPayload, uncompressedIntermediateHandler, uncompressedIntermediateHandler, blockingWriteTimeoutExpiry);
/*     */               
/*     */ 
/* 408 */               deflateRequired = false; } else { MessagePart compressedPart;
/* 409 */               if ((fin) && (full) && (needsInput))
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */                 try
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/* 419 */                   eomBufferWritten = this.deflater.deflate(this.EOM_BUFFER, 0, this.EOM_BUFFER.length, 2);
/*     */                 } catch (NullPointerException e) { int eomBufferWritten;
/* 421 */                   throw new IOException(sm.getString("perMessageDeflate.alreadyClosed"), e); }
/*     */                 int eomBufferWritten;
/* 423 */                 if (eomBufferWritten < this.EOM_BUFFER.length)
/*     */                 {
/* 425 */                   compressedPayload.limit(compressedPayload.limit() - EOM_BYTES.length + eomBufferWritten);
/*     */                   
/* 427 */                   MessagePart compressedPart = new MessagePart(true, getRsv(uncompressedPart), opCode, compressedPayload, uncompressedIntermediateHandler, uncompressedIntermediateHandler, blockingWriteTimeoutExpiry);
/*     */                   
/*     */ 
/* 430 */                   deflateRequired = false;
/* 431 */                   startNewMessage();
/*     */                 }
/*     */                 else
/*     */                 {
/* 435 */                   this.writeBuffer.put(this.EOM_BUFFER, 0, eomBufferWritten);
/*     */                   
/* 437 */                   compressedPart = new MessagePart(false, getRsv(uncompressedPart), opCode, compressedPayload, uncompressedIntermediateHandler, uncompressedIntermediateHandler, blockingWriteTimeoutExpiry);
/*     */                 }
/*     */               }
/*     */               else
/*     */               {
/* 442 */                 throw new IllegalStateException(sm.getString("perMessageDeflate.invalidState"));
/*     */               }
/*     */             }
/*     */           }
/*     */           MessagePart compressedPart;
/* 447 */           compressedParts.add(compressedPart);
/*     */         }
/*     */         
/* 450 */         SendHandler uncompressedEndHandler = uncompressedPart.getEndHandler();
/* 451 */         int size = compressedParts.size();
/* 452 */         if (size > 0) {
/* 453 */           ((MessagePart)compressedParts.get(size - 1)).setEndHandler(uncompressedEndHandler);
/*     */         }
/*     */         
/* 456 */         allCompressedParts.addAll(compressedParts);
/*     */       }
/*     */     }
/*     */     
/* 460 */     if (this.next == null) {
/* 461 */       return allCompressedParts;
/*     */     }
/* 463 */     return this.next.sendMessagePart(allCompressedParts);
/*     */   }
/*     */   
/*     */   private void startNewMessage()
/*     */     throws IOException
/*     */   {
/* 469 */     this.firstCompressedFrameWritten = false;
/* 470 */     this.emptyMessage = true;
/* 471 */     if (((this.isServer) && (!this.serverContextTakeover)) || ((!this.isServer) && (!this.clientContextTakeover))) {
/*     */       try {
/* 473 */         this.deflater.reset();
/*     */       } catch (NullPointerException e) {
/* 475 */         throw new IOException(sm.getString("perMessageDeflate.alreadyClosed"), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private int getRsv(MessagePart uncompressedMessagePart)
/*     */   {
/* 482 */     int result = uncompressedMessagePart.getRsv();
/* 483 */     if (!this.firstCompressedFrameWritten) {
/* 484 */       result += 4;
/* 485 */       this.firstCompressedFrameWritten = true;
/*     */     }
/* 487 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 494 */     this.next.close();
/* 495 */     this.inflater.end();
/* 496 */     this.deflater.end();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\PerMessageDeflate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */