package org.apache.tomcat.websocket;

public enum MessageHandlerResultType
{
  BINARY,  TEXT,  PONG;
  
  private MessageHandlerResultType() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\MessageHandlerResultType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */