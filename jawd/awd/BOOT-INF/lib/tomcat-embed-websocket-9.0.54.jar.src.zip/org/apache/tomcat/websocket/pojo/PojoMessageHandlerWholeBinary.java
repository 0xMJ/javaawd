/*     */ package org.apache.tomcat.websocket.pojo;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.List;
/*     */ import javax.naming.NamingException;
/*     */ import javax.websocket.DecodeException;
/*     */ import javax.websocket.Decoder;
/*     */ import javax.websocket.Decoder.Binary;
/*     */ import javax.websocket.Decoder.BinaryStream;
/*     */ import javax.websocket.EndpointConfig;
/*     */ import javax.websocket.Session;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PojoMessageHandlerWholeBinary
/*     */   extends PojoMessageHandlerWholeBase<ByteBuffer>
/*     */ {
/*  42 */   private static final StringManager sm = StringManager.getManager(PojoMessageHandlerWholeBinary.class);
/*     */   
/*     */ 
/*     */   private final boolean isForInputStream;
/*     */   
/*     */ 
/*     */ 
/*     */   public PojoMessageHandlerWholeBinary(Object pojo, Method method, Session session, EndpointConfig config, List<Class<? extends Decoder>> decoderClazzes, Object[] params, int indexPayload, boolean convert, int indexSession, boolean isForInputStream, long maxMessageSize)
/*     */   {
/*  51 */     super(pojo, method, session, params, indexPayload, convert, indexSession, maxMessageSize);
/*     */     
/*     */ 
/*     */ 
/*  55 */     if ((maxMessageSize > -1L) && (maxMessageSize > session.getMaxBinaryMessageBufferSize())) {
/*  56 */       if (maxMessageSize > 2147483647L) {
/*  57 */         throw new IllegalArgumentException(sm.getString("pojoMessageHandlerWhole.maxBufferSize"));
/*     */       }
/*     */       
/*  60 */       session.setMaxBinaryMessageBufferSize((int)maxMessageSize);
/*     */     }
/*     */     try
/*     */     {
/*  64 */       if (decoderClazzes != null) {
/*  65 */         for (Class<? extends Decoder> decoderClazz : decoderClazzes) {
/*  66 */           if (Decoder.Binary.class.isAssignableFrom(decoderClazz)) {
/*  67 */             Decoder.Binary<?> decoder = (Decoder.Binary)createDecoderInstance(decoderClazz);
/*  68 */             decoder.init(config);
/*  69 */             this.decoders.add(decoder);
/*  70 */           } else if (Decoder.BinaryStream.class.isAssignableFrom(decoderClazz)) {
/*  71 */             Decoder.BinaryStream<?> decoder = (Decoder.BinaryStream)createDecoderInstance(decoderClazz);
/*  72 */             decoder.init(config);
/*  73 */             this.decoders.add(decoder);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (ReflectiveOperationException|NamingException e)
/*     */     {
/*  80 */       throw new IllegalArgumentException(e);
/*     */     }
/*  82 */     this.isForInputStream = isForInputStream;
/*     */   }
/*     */   
/*     */   protected Object decode(ByteBuffer message)
/*     */     throws DecodeException
/*     */   {
/*  88 */     for (Decoder decoder : this.decoders) {
/*  89 */       if ((decoder instanceof Decoder.Binary)) {
/*  90 */         if (((Decoder.Binary)decoder).willDecode(message)) {
/*  91 */           return ((Decoder.Binary)decoder).decode(message);
/*     */         }
/*     */       } else {
/*  94 */         byte[] array = new byte[message.limit() - message.position()];
/*  95 */         message.get(array);
/*  96 */         ByteArrayInputStream bais = new ByteArrayInputStream(array);
/*     */         try {
/*  98 */           return ((Decoder.BinaryStream)decoder).decode(bais);
/*     */         } catch (IOException ioe) {
/* 100 */           throw new DecodeException(message, sm.getString("pojoMessageHandlerWhole.decodeIoFail"), ioe);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 105 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object convert(ByteBuffer message)
/*     */   {
/* 111 */     byte[] array = new byte[message.remaining()];
/* 112 */     message.get(array);
/* 113 */     if (this.isForInputStream) {
/* 114 */       return new ByteArrayInputStream(array);
/*     */     }
/* 116 */     return array;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\pojo\PojoMessageHandlerWholeBinary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */