/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import java.util.ServiceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticatorFactory
/*    */ {
/*    */   public static Authenticator getAuthenticator(String authScheme)
/*    */   {
/* 34 */     Authenticator auth = null;
/* 35 */     switch (authScheme.toLowerCase())
/*    */     {
/*    */     case "basic": 
/* 38 */       auth = new BasicAuthenticator();
/* 39 */       break;
/*    */     
/*    */     case "digest": 
/* 42 */       auth = new DigestAuthenticator();
/* 43 */       break;
/*    */     
/*    */     default: 
/* 46 */       auth = loadAuthenticators(authScheme);
/*    */     }
/*    */     
/*    */     
/* 50 */     return auth;
/*    */   }
/*    */   
/*    */   private static Authenticator loadAuthenticators(String authScheme)
/*    */   {
/* 55 */     ServiceLoader<Authenticator> serviceLoader = ServiceLoader.load(Authenticator.class);
/*    */     
/* 57 */     for (Authenticator auth : serviceLoader) {
/* 58 */       if (auth.getSchemeName().equalsIgnoreCase(authScheme)) {
/* 59 */         return auth;
/*    */       }
/*    */     }
/*    */     
/* 63 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\AuthenticatorFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */