/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import javax.naming.NamingException;
/*    */ import javax.websocket.ClientEndpointConfig;
/*    */ import javax.websocket.DeploymentException;
/*    */ import javax.websocket.Endpoint;
/*    */ import org.apache.tomcat.InstanceManager;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ import org.apache.tomcat.websocket.pojo.PojoEndpointClient;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PojoClassHolder
/*    */   implements ClientEndpointHolder
/*    */ {
/* 30 */   private static final StringManager sm = StringManager.getManager(PojoClassHolder.class);
/*    */   
/*    */   private final Class<?> pojoClazz;
/*    */   private final ClientEndpointConfig clientEndpointConfig;
/*    */   
/*    */   public PojoClassHolder(Class<?> pojoClazz, ClientEndpointConfig clientEndpointConfig)
/*    */   {
/* 37 */     this.pojoClazz = pojoClazz;
/* 38 */     this.clientEndpointConfig = clientEndpointConfig;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getClassName()
/*    */   {
/* 44 */     return this.pojoClazz.getName();
/*    */   }
/*    */   
/*    */   public Endpoint getInstance(InstanceManager instanceManager) throws DeploymentException {
/*    */     try {
/*    */       Object pojo;
/*    */       Object pojo;
/* 51 */       if (instanceManager == null) {
/* 52 */         pojo = this.pojoClazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*    */       } else {
/* 54 */         pojo = instanceManager.newInstance(this.pojoClazz);
/*    */       }
/* 56 */       return new PojoEndpointClient(pojo, this.clientEndpointConfig.getDecoders(), instanceManager);
/*    */     } catch (ReflectiveOperationException|SecurityException|NamingException e) {
/* 58 */       throw new DeploymentException(sm.getString("clientEndpointHolder.instanceCreationFailed"), e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\PojoClassHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */