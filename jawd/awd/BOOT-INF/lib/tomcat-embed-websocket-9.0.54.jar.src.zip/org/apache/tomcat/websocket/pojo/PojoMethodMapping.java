/*     */ package org.apache.tomcat.websocket.pojo;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.websocket.CloseReason;
/*     */ import javax.websocket.DecodeException;
/*     */ import javax.websocket.Decoder;
/*     */ import javax.websocket.DeploymentException;
/*     */ import javax.websocket.EndpointConfig;
/*     */ import javax.websocket.MessageHandler;
/*     */ import javax.websocket.OnClose;
/*     */ import javax.websocket.OnError;
/*     */ import javax.websocket.OnMessage;
/*     */ import javax.websocket.OnOpen;
/*     */ import javax.websocket.PongMessage;
/*     */ import javax.websocket.Session;
/*     */ import javax.websocket.server.PathParam;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.DecoderEntry;
/*     */ import org.apache.tomcat.websocket.Util;
/*     */ import org.apache.tomcat.websocket.Util.DecoderMatch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PojoMethodMapping
/*     */ {
/*  62 */   private static final StringManager sm = StringManager.getManager(PojoMethodMapping.class);
/*     */   
/*     */   private final Method onOpen;
/*     */   private final Method onClose;
/*     */   private final Method onError;
/*     */   private final PojoPathParam[] onOpenParams;
/*     */   private final PojoPathParam[] onCloseParams;
/*     */   private final PojoPathParam[] onErrorParams;
/*  70 */   private final List<MessageHandlerInfo> onMessage = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String wsPath;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public PojoMethodMapping(Class<?> clazzPojo, List<Class<? extends Decoder>> decoderClazzes, String wsPath)
/*     */     throws DeploymentException
/*     */   {
/*  89 */     this(clazzPojo, decoderClazzes, wsPath, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PojoMethodMapping(Class<?> clazzPojo, List<Class<? extends Decoder>> decoderClazzes, String wsPath, InstanceManager instanceManager)
/*     */     throws DeploymentException
/*     */   {
/* 106 */     this.wsPath = wsPath;
/*     */     
/* 108 */     List<DecoderEntry> decoders = Util.getDecoders(decoderClazzes, instanceManager);
/* 109 */     Method open = null;
/* 110 */     Method close = null;
/* 111 */     Method error = null;
/* 112 */     Method[] clazzPojoMethods = null;
/* 113 */     Class<?> currentClazz = clazzPojo;
/* 114 */     while (!currentClazz.equals(Object.class)) {
/* 115 */       Method[] currentClazzMethods = currentClazz.getDeclaredMethods();
/* 116 */       if (currentClazz == clazzPojo) {
/* 117 */         clazzPojoMethods = currentClazzMethods;
/*     */       }
/* 119 */       for (Method method : currentClazzMethods) {
/* 120 */         if (!method.isSynthetic())
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */           if (method.getAnnotation(OnOpen.class) != null) {
/* 128 */             checkPublic(method);
/* 129 */             if (open == null) {
/* 130 */               open = method;
/*     */             }
/* 132 */             else if ((currentClazz == clazzPojo) || 
/* 133 */               (!isMethodOverride(open, method)))
/*     */             {
/* 135 */               throw new DeploymentException(sm.getString("pojoMethodMapping.duplicateAnnotation", new Object[] { OnOpen.class, currentClazz }));
/*     */             }
/*     */             
/*     */ 
/*     */           }
/* 140 */           else if (method.getAnnotation(OnClose.class) != null) {
/* 141 */             checkPublic(method);
/* 142 */             if (close == null) {
/* 143 */               close = method;
/*     */             }
/* 145 */             else if ((currentClazz == clazzPojo) || 
/* 146 */               (!isMethodOverride(close, method)))
/*     */             {
/* 148 */               throw new DeploymentException(sm.getString("pojoMethodMapping.duplicateAnnotation", new Object[] { OnClose.class, currentClazz }));
/*     */             }
/*     */             
/*     */ 
/*     */           }
/* 153 */           else if (method.getAnnotation(OnError.class) != null) {
/* 154 */             checkPublic(method);
/* 155 */             if (error == null) {
/* 156 */               error = method;
/*     */             }
/* 158 */             else if ((currentClazz == clazzPojo) || 
/* 159 */               (!isMethodOverride(error, method)))
/*     */             {
/* 161 */               throw new DeploymentException(sm.getString("pojoMethodMapping.duplicateAnnotation", new Object[] { OnError.class, currentClazz }));
/*     */             }
/*     */             
/*     */ 
/*     */           }
/* 166 */           else if (method.getAnnotation(OnMessage.class) != null) {
/* 167 */             checkPublic(method);
/* 168 */             MessageHandlerInfo messageHandler = new MessageHandlerInfo(method, decoders);
/* 169 */             boolean found = false;
/* 170 */             for (MessageHandlerInfo otherMessageHandler : this.onMessage) {
/* 171 */               if (messageHandler.targetsSameWebSocketMessageType(otherMessageHandler)) {
/* 172 */                 found = true;
/* 173 */                 if ((currentClazz == clazzPojo) || 
/* 174 */                   (!isMethodOverride(messageHandler.m, otherMessageHandler.m)))
/*     */                 {
/* 176 */                   throw new DeploymentException(sm.getString("pojoMethodMapping.duplicateAnnotation", new Object[] { OnMessage.class, currentClazz }));
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/*     */ 
/* 182 */             if (!found) {
/* 183 */               this.onMessage.add(messageHandler);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 189 */       currentClazz = currentClazz.getSuperclass();
/*     */     }
/*     */     
/*     */ 
/* 193 */     if ((open != null) && (open.getDeclaringClass() != clazzPojo) && 
/* 194 */       (isOverridenWithoutAnnotation(clazzPojoMethods, open, OnOpen.class))) {
/* 195 */       open = null;
/*     */     }
/*     */     
/* 198 */     if ((close != null) && (close.getDeclaringClass() != clazzPojo) && 
/* 199 */       (isOverridenWithoutAnnotation(clazzPojoMethods, close, OnClose.class))) {
/* 200 */       close = null;
/*     */     }
/*     */     
/* 203 */     if ((error != null) && (error.getDeclaringClass() != clazzPojo) && 
/* 204 */       (isOverridenWithoutAnnotation(clazzPojoMethods, error, OnError.class))) {
/* 205 */       error = null;
/*     */     }
/*     */     
/* 208 */     List<MessageHandlerInfo> overriddenOnMessage = new ArrayList();
/* 209 */     for (??? = this.onMessage.iterator(); ((Iterator)???).hasNext();) { MessageHandlerInfo messageHandler = (MessageHandlerInfo)((Iterator)???).next();
/* 210 */       if ((messageHandler.m.getDeclaringClass() != clazzPojo) && 
/* 211 */         (isOverridenWithoutAnnotation(clazzPojoMethods, messageHandler.m, OnMessage.class))) {
/* 212 */         overriddenOnMessage.add(messageHandler);
/*     */       }
/*     */     }
/* 215 */     for (??? = overriddenOnMessage.iterator(); ((Iterator)???).hasNext();) { MessageHandlerInfo messageHandler = (MessageHandlerInfo)((Iterator)???).next();
/* 216 */       this.onMessage.remove(messageHandler);
/*     */     }
/* 218 */     this.onOpen = open;
/* 219 */     this.onClose = close;
/* 220 */     this.onError = error;
/* 221 */     this.onOpenParams = getPathParams(this.onOpen, MethodType.ON_OPEN);
/* 222 */     this.onCloseParams = getPathParams(this.onClose, MethodType.ON_CLOSE);
/* 223 */     this.onErrorParams = getPathParams(this.onError, MethodType.ON_ERROR);
/*     */   }
/*     */   
/*     */   private void checkPublic(Method m) throws DeploymentException
/*     */   {
/* 228 */     if (!Modifier.isPublic(m.getModifiers())) {
/* 229 */       throw new DeploymentException(sm.getString("pojoMethodMapping.methodNotPublic", new Object[] {m
/* 230 */         .getName() }));
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isMethodOverride(Method method1, Method method2)
/*     */   {
/* 236 */     return (method1.getName().equals(method2.getName())) && 
/* 237 */       (method1.getReturnType().equals(method2.getReturnType())) && 
/* 238 */       (Arrays.equals(method1.getParameterTypes(), method2.getParameterTypes()));
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isOverridenWithoutAnnotation(Method[] methods, Method superclazzMethod, Class<? extends Annotation> annotation)
/*     */   {
/* 244 */     for (Method method : methods) {
/* 245 */       if ((isMethodOverride(method, superclazzMethod)) && 
/* 246 */         (method.getAnnotation(annotation) == null)) {
/* 247 */         return true;
/*     */       }
/*     */     }
/* 250 */     return false;
/*     */   }
/*     */   
/*     */   public String getWsPath()
/*     */   {
/* 255 */     return this.wsPath;
/*     */   }
/*     */   
/*     */   public Method getOnOpen()
/*     */   {
/* 260 */     return this.onOpen;
/*     */   }
/*     */   
/*     */   public Object[] getOnOpenArgs(Map<String, String> pathParameters, Session session, EndpointConfig config)
/*     */     throws DecodeException
/*     */   {
/* 266 */     return buildArgs(this.onOpenParams, pathParameters, session, config, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public Method getOnClose()
/*     */   {
/* 272 */     return this.onClose;
/*     */   }
/*     */   
/*     */   public Object[] getOnCloseArgs(Map<String, String> pathParameters, Session session, CloseReason closeReason)
/*     */     throws DecodeException
/*     */   {
/* 278 */     return buildArgs(this.onCloseParams, pathParameters, session, null, null, closeReason);
/*     */   }
/*     */   
/*     */ 
/*     */   public Method getOnError()
/*     */   {
/* 284 */     return this.onError;
/*     */   }
/*     */   
/*     */   public Object[] getOnErrorArgs(Map<String, String> pathParameters, Session session, Throwable throwable)
/*     */     throws DecodeException
/*     */   {
/* 290 */     return buildArgs(this.onErrorParams, pathParameters, session, null, throwable, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasMessageHandlers()
/*     */   {
/* 296 */     return !this.onMessage.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<MessageHandler> getMessageHandlers(Object pojo, Map<String, String> pathParameters, Session session, EndpointConfig config)
/*     */   {
/* 303 */     Set<MessageHandler> result = new HashSet();
/* 304 */     for (MessageHandlerInfo messageMethod : this.onMessage) {
/* 305 */       result.addAll(messageMethod.getMessageHandlers(pojo, pathParameters, session, config));
/*     */     }
/*     */     
/* 308 */     return result;
/*     */   }
/*     */   
/*     */   private static PojoPathParam[] getPathParams(Method m, MethodType methodType)
/*     */     throws DeploymentException
/*     */   {
/* 314 */     if (m == null) {
/* 315 */       return new PojoPathParam[0];
/*     */     }
/* 317 */     boolean foundThrowable = false;
/* 318 */     Class<?>[] types = m.getParameterTypes();
/* 319 */     Annotation[][] paramsAnnotations = m.getParameterAnnotations();
/* 320 */     PojoPathParam[] result = new PojoPathParam[types.length];
/* 321 */     for (int i = 0; i < types.length; i++) {
/* 322 */       Class<?> type = types[i];
/* 323 */       if (type.equals(Session.class)) {
/* 324 */         result[i] = new PojoPathParam(type, null);
/* 325 */       } else if ((methodType == MethodType.ON_OPEN) && 
/* 326 */         (type.equals(EndpointConfig.class))) {
/* 327 */         result[i] = new PojoPathParam(type, null);
/* 328 */       } else if ((methodType == MethodType.ON_ERROR) && 
/* 329 */         (type.equals(Throwable.class))) {
/* 330 */         foundThrowable = true;
/* 331 */         result[i] = new PojoPathParam(type, null);
/* 332 */       } else if ((methodType == MethodType.ON_CLOSE) && 
/* 333 */         (type.equals(CloseReason.class))) {
/* 334 */         result[i] = new PojoPathParam(type, null);
/*     */       } else {
/* 336 */         Annotation[] paramAnnotations = paramsAnnotations[i];
/* 337 */         for (Annotation paramAnnotation : paramAnnotations) {
/* 338 */           if (paramAnnotation.annotationType().equals(PathParam.class))
/*     */           {
/*     */ 
/* 341 */             result[i] = new PojoPathParam(type, ((PathParam)paramAnnotation).value());
/* 342 */             break;
/*     */           }
/*     */         }
/*     */         
/* 346 */         if (result[i] == null) {
/* 347 */           throw new DeploymentException(sm.getString("pojoMethodMapping.paramWithoutAnnotation", new Object[] { type, m
/*     */           
/* 349 */             .getName(), m.getClass().getName() }));
/*     */         }
/*     */       }
/*     */     }
/* 353 */     if ((methodType == MethodType.ON_ERROR) && (!foundThrowable)) {
/* 354 */       throw new DeploymentException(sm.getString("pojoMethodMapping.onErrorNoThrowable", new Object[] {m
/*     */       
/* 356 */         .getName(), m.getDeclaringClass().getName() }));
/*     */     }
/* 358 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static Object[] buildArgs(PojoPathParam[] pathParams, Map<String, String> pathParameters, Session session, EndpointConfig config, Throwable throwable, CloseReason closeReason)
/*     */     throws DecodeException
/*     */   {
/* 366 */     Object[] result = new Object[pathParams.length];
/* 367 */     for (int i = 0; i < pathParams.length; i++) {
/* 368 */       Class<?> type = pathParams[i].getType();
/* 369 */       if (type.equals(Session.class)) {
/* 370 */         result[i] = session;
/* 371 */       } else if (type.equals(EndpointConfig.class)) {
/* 372 */         result[i] = config;
/* 373 */       } else if (type.equals(Throwable.class)) {
/* 374 */         result[i] = throwable;
/* 375 */       } else if (type.equals(CloseReason.class)) {
/* 376 */         result[i] = closeReason;
/*     */       } else {
/* 378 */         String name = pathParams[i].getName();
/* 379 */         String value = (String)pathParameters.get(name);
/*     */         try {
/* 381 */           result[i] = Util.coerceToType(type, value);
/*     */         } catch (Exception e) {
/* 383 */           throw new DecodeException(value, sm.getString("pojoMethodMapping.decodePathParamFail", new Object[] { value, type }), e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 389 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class MessageHandlerInfo
/*     */   {
/*     */     private final Method m;
/* 396 */     private int indexString = -1;
/* 397 */     private int indexByteArray = -1;
/* 398 */     private int indexByteBuffer = -1;
/* 399 */     private int indexPong = -1;
/* 400 */     private int indexBoolean = -1;
/* 401 */     private int indexSession = -1;
/* 402 */     private int indexInputStream = -1;
/* 403 */     private int indexReader = -1;
/* 404 */     private int indexPrimitive = -1;
/* 405 */     private Map<Integer, PojoPathParam> indexPathParams = new HashMap();
/* 406 */     private int indexPayload = -1;
/* 407 */     private Util.DecoderMatch decoderMatch = null;
/* 408 */     private long maxMessageSize = -1L;
/*     */     
/*     */     public MessageHandlerInfo(Method m, List<DecoderEntry> decoderEntries)
/*     */       throws DeploymentException
/*     */     {
/* 413 */       this.m = m;
/*     */       
/* 415 */       Class<?>[] types = m.getParameterTypes();
/* 416 */       Annotation[][] paramsAnnotations = m.getParameterAnnotations();
/*     */       
/* 418 */       for (int i = 0; i < types.length; i++) {
/* 419 */         boolean paramFound = false;
/* 420 */         Annotation[] paramAnnotations = paramsAnnotations[i];
/* 421 */         for (Annotation paramAnnotation : paramAnnotations) {
/* 422 */           if (paramAnnotation.annotationType().equals(PathParam.class))
/*     */           {
/* 424 */             this.indexPathParams.put(
/* 425 */               Integer.valueOf(i), new PojoPathParam(types[i], ((PathParam)paramAnnotation)
/* 426 */               .value()));
/* 427 */             paramFound = true;
/* 428 */             break;
/*     */           }
/*     */         }
/* 431 */         if (!paramFound)
/*     */         {
/*     */ 
/* 434 */           if (String.class.isAssignableFrom(types[i])) {
/* 435 */             if (this.indexString == -1) {
/* 436 */               this.indexString = i;
/*     */             } else {
/* 438 */               throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */               
/* 440 */                 .getName(), m.getDeclaringClass().getName() }));
/*     */             }
/* 442 */           } else if (Reader.class.isAssignableFrom(types[i])) {
/* 443 */             if (this.indexReader == -1) {
/* 444 */               this.indexReader = i;
/*     */             } else {
/* 446 */               throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */               
/* 448 */                 .getName(), m.getDeclaringClass().getName() }));
/*     */             }
/* 450 */           } else if (Boolean.TYPE == types[i]) {
/* 451 */             if (this.indexBoolean == -1) {
/* 452 */               this.indexBoolean = i;
/*     */             } else {
/* 454 */               throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateLastParam", new Object[] {m
/*     */               
/* 456 */                 .getName(), m.getDeclaringClass().getName() }));
/*     */             }
/* 458 */           } else if (ByteBuffer.class.isAssignableFrom(types[i])) {
/* 459 */             if (this.indexByteBuffer == -1) {
/* 460 */               this.indexByteBuffer = i;
/*     */             } else {
/* 462 */               throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */               
/* 464 */                 .getName(), m.getDeclaringClass().getName() }));
/*     */             }
/* 466 */           } else if (byte[].class == types[i]) {
/* 467 */             if (this.indexByteArray == -1) {
/* 468 */               this.indexByteArray = i;
/*     */             } else {
/* 470 */               throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */               
/* 472 */                 .getName(), m.getDeclaringClass().getName() }));
/*     */             }
/* 474 */           } else if (InputStream.class.isAssignableFrom(types[i])) {
/* 475 */             if (this.indexInputStream == -1) {
/* 476 */               this.indexInputStream = i;
/*     */             } else {
/* 478 */               throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */               
/* 480 */                 .getName(), m.getDeclaringClass().getName() }));
/*     */             }
/* 482 */           } else if (Util.isPrimitive(types[i])) {
/* 483 */             if (this.indexPrimitive == -1) {
/* 484 */               this.indexPrimitive = i;
/*     */             } else {
/* 486 */               throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */               
/* 488 */                 .getName(), m.getDeclaringClass().getName() }));
/*     */             }
/* 490 */           } else if (Session.class.isAssignableFrom(types[i])) {
/* 491 */             if (this.indexSession == -1) {
/* 492 */               this.indexSession = i;
/*     */             } else {
/* 494 */               throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateSessionParam", new Object[] {m
/*     */               
/* 496 */                 .getName(), m.getDeclaringClass().getName() }));
/*     */             }
/* 498 */           } else if (PongMessage.class.isAssignableFrom(types[i])) {
/* 499 */             if (this.indexPong == -1) {
/* 500 */               this.indexPong = i;
/*     */             } else {
/* 502 */               throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicatePongMessageParam", new Object[] {m
/*     */               
/* 504 */                 .getName(), m.getDeclaringClass().getName() }));
/*     */             }
/*     */           } else {
/* 507 */             if ((this.decoderMatch != null) && (this.decoderMatch.hasMatches())) {
/* 508 */               throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */               
/* 510 */                 .getName(), m.getDeclaringClass().getName() }));
/*     */             }
/* 512 */             this.decoderMatch = new Util.DecoderMatch(types[i], decoderEntries);
/*     */             
/* 514 */             if (this.decoderMatch.hasMatches()) {
/* 515 */               this.indexPayload = i;
/*     */             } else {
/* 517 */               throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.noDecoder", new Object[] {m
/*     */               
/* 519 */                 .getName(), m.getDeclaringClass().getName() }));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 525 */       if (this.indexString != -1) {
/* 526 */         if (this.indexPayload != -1) {
/* 527 */           throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */           
/* 529 */             .getName(), m.getDeclaringClass().getName() }));
/*     */         }
/* 531 */         this.indexPayload = this.indexString;
/*     */       }
/*     */       
/* 534 */       if (this.indexReader != -1) {
/* 535 */         if (this.indexPayload != -1) {
/* 536 */           throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */           
/* 538 */             .getName(), m.getDeclaringClass().getName() }));
/*     */         }
/* 540 */         this.indexPayload = this.indexReader;
/*     */       }
/*     */       
/* 543 */       if (this.indexByteArray != -1) {
/* 544 */         if (this.indexPayload != -1) {
/* 545 */           throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */           
/* 547 */             .getName(), m.getDeclaringClass().getName() }));
/*     */         }
/* 549 */         this.indexPayload = this.indexByteArray;
/*     */       }
/*     */       
/* 552 */       if (this.indexByteBuffer != -1) {
/* 553 */         if (this.indexPayload != -1) {
/* 554 */           throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */           
/* 556 */             .getName(), m.getDeclaringClass().getName() }));
/*     */         }
/* 558 */         this.indexPayload = this.indexByteBuffer;
/*     */       }
/*     */       
/* 561 */       if (this.indexInputStream != -1) {
/* 562 */         if (this.indexPayload != -1) {
/* 563 */           throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */           
/* 565 */             .getName(), m.getDeclaringClass().getName() }));
/*     */         }
/* 567 */         this.indexPayload = this.indexInputStream;
/*     */       }
/*     */       
/* 570 */       if (this.indexPrimitive != -1) {
/* 571 */         if (this.indexPayload != -1) {
/* 572 */           throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.duplicateMessageParam", new Object[] {m
/*     */           
/* 574 */             .getName(), m.getDeclaringClass().getName() }));
/*     */         }
/* 576 */         this.indexPayload = this.indexPrimitive;
/*     */       }
/*     */       
/* 579 */       if (this.indexPong != -1) {
/* 580 */         if (this.indexPayload != -1) {
/* 581 */           throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.pongWithPayload", new Object[] {m
/*     */           
/* 583 */             .getName(), m.getDeclaringClass().getName() }));
/*     */         }
/* 585 */         this.indexPayload = this.indexPong;
/*     */       }
/*     */       
/* 588 */       if ((this.indexPayload == -1) && (this.indexPrimitive == -1) && (this.indexBoolean != -1))
/*     */       {
/*     */ 
/* 591 */         this.indexPayload = this.indexBoolean;
/* 592 */         this.indexPrimitive = this.indexBoolean;
/* 593 */         this.indexBoolean = -1;
/*     */       }
/* 595 */       if (this.indexPayload == -1) {
/* 596 */         throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.noPayload", new Object[] {m
/*     */         
/* 598 */           .getName(), m.getDeclaringClass().getName() }));
/*     */       }
/* 600 */       if ((this.indexPong != -1) && (this.indexBoolean != -1)) {
/* 601 */         throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.partialPong", new Object[] {m
/*     */         
/* 603 */           .getName(), m.getDeclaringClass().getName() }));
/*     */       }
/* 605 */       if ((this.indexReader != -1) && (this.indexBoolean != -1)) {
/* 606 */         throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.partialReader", new Object[] {m
/*     */         
/* 608 */           .getName(), m.getDeclaringClass().getName() }));
/*     */       }
/* 610 */       if ((this.indexInputStream != -1) && (this.indexBoolean != -1)) {
/* 611 */         throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.partialInputStream", new Object[] {m
/*     */         
/* 613 */           .getName(), m.getDeclaringClass().getName() }));
/*     */       }
/* 615 */       if ((this.decoderMatch != null) && (this.decoderMatch.hasMatches()) && (this.indexBoolean != -1))
/*     */       {
/* 617 */         throw new DeploymentException(PojoMethodMapping.sm.getString("pojoMethodMapping.partialObject", new Object[] {m
/*     */         
/* 619 */           .getName(), m.getDeclaringClass().getName() }));
/*     */       }
/*     */       
/* 622 */       this.maxMessageSize = ((OnMessage)m.getAnnotation(OnMessage.class)).maxMessageSize();
/*     */     }
/*     */     
/*     */     public boolean targetsSameWebSocketMessageType(MessageHandlerInfo otherHandler)
/*     */     {
/* 627 */       if (otherHandler == null) {
/* 628 */         return false;
/*     */       }
/*     */       
/* 631 */       return ((isPong()) && (otherHandler.isPong())) || ((isBinary()) && (otherHandler.isBinary())) || (
/* 632 */         (isText()) && (otherHandler.isText()));
/*     */     }
/*     */     
/*     */     private boolean isPong()
/*     */     {
/* 637 */       return this.indexPong >= 0;
/*     */     }
/*     */     
/*     */     private boolean isText()
/*     */     {
/* 642 */       return (this.indexString >= 0) || (this.indexPrimitive >= 0) || (this.indexReader >= 0) || ((this.decoderMatch != null) && 
/* 643 */         (this.decoderMatch.getTextDecoders().size() > 0));
/*     */     }
/*     */     
/*     */     private boolean isBinary()
/*     */     {
/* 648 */       return (this.indexByteArray >= 0) || (this.indexByteBuffer >= 0) || (this.indexInputStream >= 0) || ((this.decoderMatch != null) && 
/* 649 */         (this.decoderMatch.getBinaryDecoders().size() > 0));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Set<MessageHandler> getMessageHandlers(Object pojo, Map<String, String> pathParameters, Session session, EndpointConfig config)
/*     */     {
/* 656 */       Object[] params = new Object[this.m.getParameterTypes().length];
/*     */       
/*     */ 
/* 659 */       for (Map.Entry<Integer, PojoPathParam> entry : this.indexPathParams.entrySet()) {
/* 660 */         PojoPathParam pathParam = (PojoPathParam)entry.getValue();
/* 661 */         String valueString = (String)pathParameters.get(pathParam.getName());
/* 662 */         Object value = null;
/*     */         try {
/* 664 */           value = Util.coerceToType(pathParam.getType(), valueString);
/*     */         }
/*     */         catch (Exception e) {
/* 667 */           DecodeException de = new DecodeException(valueString, PojoMethodMapping.sm.getString("pojoMethodMapping.decodePathParamFail", new Object[] { valueString, pathParam
/*     */           
/* 669 */             .getType() }), e);
/* 670 */           params = new Object[] { de };
/* 671 */           break;
/*     */         }
/* 673 */         params[((Integer)entry.getKey()).intValue()] = value;
/*     */       }
/*     */       
/* 676 */       Object results = new HashSet(2);
/* 677 */       if (this.indexBoolean == -1)
/*     */       {
/* 679 */         if ((this.indexString != -1) || (this.indexPrimitive != -1)) {
/* 680 */           MessageHandler mh = new PojoMessageHandlerWholeText(pojo, this.m, session, config, null, params, this.indexPayload, false, this.indexSession, this.maxMessageSize);
/*     */           
/*     */ 
/* 683 */           ((Set)results).add(mh);
/* 684 */         } else if (this.indexReader != -1) {
/* 685 */           MessageHandler mh = new PojoMessageHandlerWholeText(pojo, this.m, session, config, null, params, this.indexReader, true, this.indexSession, this.maxMessageSize);
/*     */           
/*     */ 
/* 688 */           ((Set)results).add(mh);
/* 689 */         } else if (this.indexByteArray != -1) {
/* 690 */           MessageHandler mh = new PojoMessageHandlerWholeBinary(pojo, this.m, session, config, null, params, this.indexByteArray, true, this.indexSession, false, this.maxMessageSize);
/*     */           
/*     */ 
/* 693 */           ((Set)results).add(mh);
/* 694 */         } else if (this.indexByteBuffer != -1) {
/* 695 */           MessageHandler mh = new PojoMessageHandlerWholeBinary(pojo, this.m, session, config, null, params, this.indexByteBuffer, false, this.indexSession, false, this.maxMessageSize);
/*     */           
/*     */ 
/* 698 */           ((Set)results).add(mh);
/* 699 */         } else if (this.indexInputStream != -1) {
/* 700 */           MessageHandler mh = new PojoMessageHandlerWholeBinary(pojo, this.m, session, config, null, params, this.indexInputStream, true, this.indexSession, true, this.maxMessageSize);
/*     */           
/*     */ 
/* 703 */           ((Set)results).add(mh);
/* 704 */         } else if ((this.decoderMatch != null) && (this.decoderMatch.hasMatches())) {
/* 705 */           if (this.decoderMatch.getBinaryDecoders().size() > 0)
/*     */           {
/*     */ 
/* 708 */             MessageHandler mh = new PojoMessageHandlerWholeBinary(pojo, this.m, session, config, this.decoderMatch.getBinaryDecoders(), params, this.indexPayload, true, this.indexSession, true, this.maxMessageSize);
/*     */             
/*     */ 
/* 711 */             ((Set)results).add(mh);
/*     */           }
/* 713 */           if (this.decoderMatch.getTextDecoders().size() > 0)
/*     */           {
/*     */ 
/* 716 */             MessageHandler mh = new PojoMessageHandlerWholeText(pojo, this.m, session, config, this.decoderMatch.getTextDecoders(), params, this.indexPayload, true, this.indexSession, this.maxMessageSize);
/*     */             
/* 718 */             ((Set)results).add(mh);
/*     */           }
/*     */         } else {
/* 721 */           MessageHandler mh = new PojoMessageHandlerWholePong(pojo, this.m, session, params, this.indexPong, false, this.indexSession);
/*     */           
/* 723 */           ((Set)results).add(mh);
/*     */         }
/*     */         
/*     */       }
/* 727 */       else if (this.indexString != -1) {
/* 728 */         MessageHandler mh = new PojoMessageHandlerPartialText(pojo, this.m, session, params, this.indexString, false, this.indexBoolean, this.indexSession, this.maxMessageSize);
/*     */         
/*     */ 
/* 731 */         ((Set)results).add(mh);
/* 732 */       } else if (this.indexByteArray != -1) {
/* 733 */         MessageHandler mh = new PojoMessageHandlerPartialBinary(pojo, this.m, session, params, this.indexByteArray, true, this.indexBoolean, this.indexSession, this.maxMessageSize);
/*     */         
/*     */ 
/* 736 */         ((Set)results).add(mh);
/*     */       } else {
/* 738 */         MessageHandler mh = new PojoMessageHandlerPartialBinary(pojo, this.m, session, params, this.indexByteBuffer, false, this.indexBoolean, this.indexSession, this.maxMessageSize);
/*     */         
/*     */ 
/* 741 */         ((Set)results).add(mh);
/*     */       }
/*     */       
/* 744 */       return (Set<MessageHandler>)results;
/*     */     }
/*     */   }
/*     */   
/*     */   private static enum MethodType
/*     */   {
/* 750 */     ON_OPEN, 
/* 751 */     ON_CLOSE, 
/* 752 */     ON_ERROR;
/*     */     
/*     */     private MethodType() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\pojo\PojoMethodMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */