/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Base64;
/*    */ import java.util.Base64.Encoder;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasicAuthenticator
/*    */   extends Authenticator
/*    */ {
/*    */   public static final String schemeName = "basic";
/*    */   public static final String charsetparam = "charset";
/*    */   
/*    */   public String getAuthorization(String requestUri, String WWWAuthenticate, Map<String, Object> userProperties)
/*    */     throws AuthenticationException
/*    */   {
/* 36 */     String userName = (String)userProperties.get("org.apache.tomcat.websocket.WS_AUTHENTICATION_USER_NAME");
/* 37 */     String password = (String)userProperties.get("org.apache.tomcat.websocket.WS_AUTHENTICATION_PASSWORD");
/*    */     
/* 39 */     if ((userName == null) || (password == null)) {
/* 40 */       throw new AuthenticationException("Failed to perform Basic authentication due to  missing user/password");
/*    */     }
/*    */     
/*    */ 
/* 44 */     Map<String, String> wwwAuthenticate = parseWWWAuthenticateHeader(WWWAuthenticate);
/*    */     
/* 46 */     String userPass = userName + ":" + password;
/*    */     Charset charset;
/*    */     Charset charset;
/* 49 */     if ((wwwAuthenticate.get("charset") != null) && 
/* 50 */       (((String)wwwAuthenticate.get("charset")).equalsIgnoreCase("UTF-8"))) {
/* 51 */       charset = StandardCharsets.UTF_8;
/*    */     } else {
/* 53 */       charset = StandardCharsets.ISO_8859_1;
/*    */     }
/*    */     
/* 56 */     String base64 = Base64.getEncoder().encodeToString(userPass.getBytes(charset));
/*    */     
/* 58 */     return " Basic " + base64;
/*    */   }
/*    */   
/*    */   public String getSchemeName()
/*    */   {
/* 63 */     return "basic";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\BasicAuthenticator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */