package org.apache.tomcat.websocket;

public abstract interface BackgroundProcess
{
  public abstract void backgroundProcess();
  
  public abstract void setProcessPeriod(int paramInt);
  
  public abstract int getProcessPeriod();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\BackgroundProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */