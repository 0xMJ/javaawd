/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.AsynchronousSocketChannel;
/*     */ import java.nio.channels.CompletionHandler;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import javax.net.ssl.SSLEngine;
/*     */ import javax.net.ssl.SSLEngineResult;
/*     */ import javax.net.ssl.SSLEngineResult.HandshakeStatus;
/*     */ import javax.net.ssl.SSLEngineResult.Status;
/*     */ import javax.net.ssl.SSLException;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncChannelWrapperSecure
/*     */   implements AsyncChannelWrapper
/*     */ {
/*  53 */   private final Log log = LogFactory.getLog(AsyncChannelWrapperSecure.class);
/*     */   
/*  55 */   private static final StringManager sm = StringManager.getManager(AsyncChannelWrapperSecure.class);
/*     */   
/*  57 */   private static final ByteBuffer DUMMY = ByteBuffer.allocate(16921);
/*     */   
/*     */   private final AsynchronousSocketChannel socketChannel;
/*     */   
/*     */   private final SSLEngine sslEngine;
/*     */   private final ByteBuffer socketReadBuffer;
/*     */   private final ByteBuffer socketWriteBuffer;
/*  64 */   private final ExecutorService executor = Executors.newFixedThreadPool(2, new SecureIOThreadFactory(null));
/*  65 */   private AtomicBoolean writing = new AtomicBoolean(false);
/*  66 */   private AtomicBoolean reading = new AtomicBoolean(false);
/*     */   
/*     */   public AsyncChannelWrapperSecure(AsynchronousSocketChannel socketChannel, SSLEngine sslEngine)
/*     */   {
/*  70 */     this.socketChannel = socketChannel;
/*  71 */     this.sslEngine = sslEngine;
/*     */     
/*  73 */     int socketBufferSize = sslEngine.getSession().getPacketBufferSize();
/*  74 */     this.socketReadBuffer = ByteBuffer.allocateDirect(socketBufferSize);
/*  75 */     this.socketWriteBuffer = ByteBuffer.allocateDirect(socketBufferSize);
/*     */   }
/*     */   
/*     */   public Future<Integer> read(ByteBuffer dst)
/*     */   {
/*  80 */     WrapperFuture<Integer, Void> future = new WrapperFuture();
/*     */     
/*  82 */     if (!this.reading.compareAndSet(false, true)) {
/*  83 */       throw new IllegalStateException(sm.getString("asyncChannelWrapperSecure.concurrentRead"));
/*     */     }
/*     */     
/*     */ 
/*  87 */     ReadTask readTask = new ReadTask(dst, future);
/*     */     
/*  89 */     this.executor.execute(readTask);
/*     */     
/*  91 */     return future;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public <B, A extends B> void read(ByteBuffer dst, A attachment, CompletionHandler<Integer, B> handler)
/*     */   {
/*  98 */     WrapperFuture<Integer, B> future = new WrapperFuture(handler, attachment);
/*     */     
/*     */ 
/* 101 */     if (!this.reading.compareAndSet(false, true)) {
/* 102 */       throw new IllegalStateException(sm.getString("asyncChannelWrapperSecure.concurrentRead"));
/*     */     }
/*     */     
/*     */ 
/* 106 */     ReadTask readTask = new ReadTask(dst, future);
/*     */     
/* 108 */     this.executor.execute(readTask);
/*     */   }
/*     */   
/*     */ 
/*     */   public Future<Integer> write(ByteBuffer src)
/*     */   {
/* 114 */     WrapperFuture<Long, Void> inner = new WrapperFuture();
/*     */     
/* 116 */     if (!this.writing.compareAndSet(false, true)) {
/* 117 */       throw new IllegalStateException(sm.getString("asyncChannelWrapperSecure.concurrentWrite"));
/*     */     }
/*     */     
/*     */ 
/* 121 */     WriteTask writeTask = new WriteTask(new ByteBuffer[] { src }, 0, 1, inner);
/*     */     
/*     */ 
/* 124 */     this.executor.execute(writeTask);
/*     */     
/* 126 */     Future<Integer> future = new LongToIntegerFuture(inner);
/* 127 */     return future;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public <B, A extends B> void write(ByteBuffer[] srcs, int offset, int length, long timeout, TimeUnit unit, A attachment, CompletionHandler<Long, B> handler)
/*     */   {
/* 135 */     WrapperFuture<Long, B> future = new WrapperFuture(handler, attachment);
/*     */     
/*     */ 
/* 138 */     if (!this.writing.compareAndSet(false, true)) {
/* 139 */       throw new IllegalStateException(sm.getString("asyncChannelWrapperSecure.concurrentWrite"));
/*     */     }
/*     */     
/*     */ 
/* 143 */     WriteTask writeTask = new WriteTask(srcs, offset, length, future);
/*     */     
/* 145 */     this.executor.execute(writeTask);
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/*     */     try {
/* 151 */       this.socketChannel.close();
/*     */     } catch (IOException e) {
/* 153 */       this.log.info(sm.getString("asyncChannelWrapperSecure.closeFail"));
/*     */     }
/* 155 */     this.executor.shutdownNow();
/*     */   }
/*     */   
/*     */   public Future<Void> handshake()
/*     */     throws SSLException
/*     */   {
/* 161 */     WrapperFuture<Void, Void> wFuture = new WrapperFuture();
/*     */     
/* 163 */     Thread t = new WebSocketSslHandshakeThread(wFuture);
/* 164 */     t.start();
/*     */     
/* 166 */     return wFuture;
/*     */   }
/*     */   
/*     */   public SocketAddress getLocalAddress()
/*     */     throws IOException
/*     */   {
/* 172 */     return this.socketChannel.getLocalAddress();
/*     */   }
/*     */   
/*     */   private class WriteTask
/*     */     implements Runnable
/*     */   {
/*     */     private final ByteBuffer[] srcs;
/*     */     private final int offset;
/*     */     private final int length;
/*     */     private final AsyncChannelWrapperSecure.WrapperFuture<Long, ?> future;
/*     */     
/*     */     public WriteTask(int srcs, int offset, AsyncChannelWrapperSecure.WrapperFuture<Long, ?> length)
/*     */     {
/* 185 */       this.srcs = srcs;
/* 186 */       this.future = future;
/* 187 */       this.offset = offset;
/* 188 */       this.length = length;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 193 */       long written = 0L;
/*     */       try
/*     */       {
/* 196 */         for (int i = this.offset; i < this.offset + this.length; i++) {
/* 197 */           ByteBuffer src = this.srcs[i];
/* 198 */           while (src.hasRemaining()) {
/* 199 */             AsyncChannelWrapperSecure.this.socketWriteBuffer.clear();
/*     */             
/*     */ 
/* 202 */             SSLEngineResult r = AsyncChannelWrapperSecure.this.sslEngine.wrap(src, AsyncChannelWrapperSecure.this.socketWriteBuffer);
/* 203 */             written += r.bytesConsumed();
/* 204 */             SSLEngineResult.Status s = r.getStatus();
/*     */             
/* 206 */             if ((s != SSLEngineResult.Status.OK) && (s != SSLEngineResult.Status.BUFFER_OVERFLOW))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 212 */               throw new IllegalStateException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.statusWrap"));
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 217 */             if (r.getHandshakeStatus() == SSLEngineResult.HandshakeStatus.NEED_TASK) {
/* 218 */               Runnable runnable = AsyncChannelWrapperSecure.this.sslEngine.getDelegatedTask();
/* 219 */               while (runnable != null) {
/* 220 */                 runnable.run();
/* 221 */                 runnable = AsyncChannelWrapperSecure.this.sslEngine.getDelegatedTask();
/*     */               }
/*     */             }
/*     */             
/* 225 */             AsyncChannelWrapperSecure.this.socketWriteBuffer.flip();
/*     */             
/*     */ 
/* 228 */             int toWrite = r.bytesProduced();
/* 229 */             while (toWrite > 0)
/*     */             {
/* 231 */               Future<Integer> f = AsyncChannelWrapperSecure.this.socketChannel.write(AsyncChannelWrapperSecure.this.socketWriteBuffer);
/* 232 */               Integer socketWrite = (Integer)f.get();
/* 233 */               toWrite -= socketWrite.intValue();
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 239 */         if (AsyncChannelWrapperSecure.this.writing.compareAndSet(true, false)) {
/* 240 */           this.future.complete(Long.valueOf(written));
/*     */         } else {
/* 242 */           this.future.fail(new IllegalStateException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.wrongStateWrite")));
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 246 */         AsyncChannelWrapperSecure.this.writing.set(false);
/* 247 */         this.future.fail(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class ReadTask implements Runnable
/*     */   {
/*     */     private final ByteBuffer dest;
/*     */     private final AsyncChannelWrapperSecure.WrapperFuture<Integer, ?> future;
/*     */     
/*     */     public ReadTask(AsyncChannelWrapperSecure.WrapperFuture<Integer, ?> dest)
/*     */     {
/* 259 */       this.dest = dest;
/* 260 */       this.future = future;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 265 */       int read = 0;
/*     */       
/* 267 */       boolean forceRead = false;
/*     */       try
/*     */       {
/* 270 */         while (read == 0) {
/* 271 */           AsyncChannelWrapperSecure.this.socketReadBuffer.compact();
/*     */           
/* 273 */           if (forceRead) {
/* 274 */             forceRead = false;
/* 275 */             Future<Integer> f = AsyncChannelWrapperSecure.this.socketChannel.read(AsyncChannelWrapperSecure.this.socketReadBuffer);
/* 276 */             Integer socketRead = (Integer)f.get();
/* 277 */             if (socketRead.intValue() == -1) {
/* 278 */               throw new EOFException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.eof"));
/*     */             }
/*     */           }
/*     */           
/* 282 */           AsyncChannelWrapperSecure.this.socketReadBuffer.flip();
/*     */           
/* 284 */           if (AsyncChannelWrapperSecure.this.socketReadBuffer.hasRemaining())
/*     */           {
/* 286 */             SSLEngineResult r = AsyncChannelWrapperSecure.this.sslEngine.unwrap(AsyncChannelWrapperSecure.this.socketReadBuffer, this.dest);
/* 287 */             read += r.bytesProduced();
/* 288 */             SSLEngineResult.Status s = r.getStatus();
/*     */             
/* 290 */             if (s != SSLEngineResult.Status.OK)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 295 */               if (s == SSLEngineResult.Status.BUFFER_UNDERFLOW)
/*     */               {
/* 297 */                 if (read == 0)
/*     */                 {
/*     */ 
/* 300 */                   forceRead = true;
/*     */                 }
/*     */                 
/*     */               }
/* 304 */               else if (s == SSLEngineResult.Status.BUFFER_OVERFLOW)
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 310 */                 if (AsyncChannelWrapperSecure.this.reading.compareAndSet(true, false))
/*     */                 {
/* 312 */                   throw new ReadBufferOverflowException(AsyncChannelWrapperSecure.this.sslEngine.getSession().getApplicationBufferSize());
/*     */                 }
/* 314 */                 this.future.fail(new IllegalStateException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.wrongStateRead")));
/*     */ 
/*     */               }
/*     */               else
/*     */               {
/* 319 */                 throw new IllegalStateException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.statusUnwrap"));
/*     */               }
/*     */             }
/*     */             
/*     */ 
/* 324 */             if (r.getHandshakeStatus() == SSLEngineResult.HandshakeStatus.NEED_TASK) {
/* 325 */               Runnable runnable = AsyncChannelWrapperSecure.this.sslEngine.getDelegatedTask();
/* 326 */               while (runnable != null) {
/* 327 */                 runnable.run();
/* 328 */                 runnable = AsyncChannelWrapperSecure.this.sslEngine.getDelegatedTask();
/*     */               }
/*     */             }
/*     */           } else {
/* 332 */             forceRead = true;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 337 */         if (AsyncChannelWrapperSecure.this.reading.compareAndSet(true, false)) {
/* 338 */           this.future.complete(Integer.valueOf(read));
/*     */         } else {
/* 340 */           this.future.fail(new IllegalStateException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.wrongStateRead")));
/*     */         }
/*     */       }
/*     */       catch (RuntimeException|ReadBufferOverflowException|SSLException|EOFException|ExecutionException|InterruptedException e)
/*     */       {
/* 345 */         AsyncChannelWrapperSecure.this.reading.set(false);
/* 346 */         this.future.fail(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class WebSocketSslHandshakeThread
/*     */     extends Thread
/*     */   {
/*     */     private final AsyncChannelWrapperSecure.WrapperFuture<Void, Void> hFuture;
/*     */     private SSLEngineResult.HandshakeStatus handshakeStatus;
/*     */     private SSLEngineResult.Status resultStatus;
/*     */     
/*     */     public WebSocketSslHandshakeThread()
/*     */     {
/* 360 */       this.hFuture = hFuture;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/*     */       try {
/* 366 */         AsyncChannelWrapperSecure.this.sslEngine.beginHandshake();
/*     */         
/* 368 */         AsyncChannelWrapperSecure.this.socketReadBuffer.position(AsyncChannelWrapperSecure.this.socketReadBuffer.limit());
/*     */         
/* 370 */         this.handshakeStatus = AsyncChannelWrapperSecure.this.sslEngine.getHandshakeStatus();
/* 371 */         this.resultStatus = SSLEngineResult.Status.OK;
/*     */         
/* 373 */         boolean handshaking = true;
/*     */         
/* 375 */         while (handshaking) {
/* 376 */           switch (AsyncChannelWrapperSecure.1.$SwitchMap$javax$net$ssl$SSLEngineResult$HandshakeStatus[this.handshakeStatus.ordinal()]) {
/*     */           case 1: 
/* 378 */             AsyncChannelWrapperSecure.this.socketWriteBuffer.clear();
/*     */             
/* 380 */             SSLEngineResult r = AsyncChannelWrapperSecure.this.sslEngine.wrap(AsyncChannelWrapperSecure.DUMMY, AsyncChannelWrapperSecure.this.socketWriteBuffer);
/* 381 */             checkResult(r, true);
/* 382 */             AsyncChannelWrapperSecure.this.socketWriteBuffer.flip();
/*     */             
/* 384 */             Future<Integer> fWrite = AsyncChannelWrapperSecure.this.socketChannel.write(AsyncChannelWrapperSecure.this.socketWriteBuffer);
/* 385 */             fWrite.get();
/* 386 */             break;
/*     */           
/*     */           case 2: 
/* 389 */             AsyncChannelWrapperSecure.this.socketReadBuffer.compact();
/* 390 */             if ((AsyncChannelWrapperSecure.this.socketReadBuffer.position() == 0) || (this.resultStatus == SSLEngineResult.Status.BUFFER_UNDERFLOW))
/*     */             {
/*     */ 
/* 393 */               Future<Integer> fRead = AsyncChannelWrapperSecure.this.socketChannel.read(AsyncChannelWrapperSecure.this.socketReadBuffer);
/* 394 */               fRead.get();
/*     */             }
/* 396 */             AsyncChannelWrapperSecure.this.socketReadBuffer.flip();
/*     */             
/* 398 */             SSLEngineResult r = AsyncChannelWrapperSecure.this.sslEngine.unwrap(AsyncChannelWrapperSecure.this.socketReadBuffer, AsyncChannelWrapperSecure.DUMMY);
/* 399 */             checkResult(r, false);
/* 400 */             break;
/*     */           
/*     */           case 3: 
/* 403 */             Runnable r = null;
/* 404 */             while ((r = AsyncChannelWrapperSecure.this.sslEngine.getDelegatedTask()) != null) {
/* 405 */               r.run();
/*     */             }
/* 407 */             this.handshakeStatus = AsyncChannelWrapperSecure.this.sslEngine.getHandshakeStatus();
/* 408 */             break;
/*     */           
/*     */           case 4: 
/* 411 */             handshaking = false;
/* 412 */             break;
/*     */           
/*     */ 
/*     */           case 5: 
/* 416 */             throw new SSLException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.notHandshaking"));
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 421 */         this.hFuture.fail(e);
/* 422 */         return;
/*     */       }
/*     */       
/* 425 */       this.hFuture.complete(null);
/*     */     }
/*     */     
/*     */     private void checkResult(SSLEngineResult result, boolean wrap)
/*     */       throws SSLException
/*     */     {
/* 431 */       this.handshakeStatus = result.getHandshakeStatus();
/* 432 */       this.resultStatus = result.getStatus();
/*     */       
/* 434 */       if ((this.resultStatus != SSLEngineResult.Status.OK) && ((wrap) || (this.resultStatus != SSLEngineResult.Status.BUFFER_UNDERFLOW)))
/*     */       {
/*     */ 
/* 437 */         throw new SSLException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.check.notOk", new Object[] { this.resultStatus }));
/*     */       }
/* 439 */       if ((wrap) && (result.bytesConsumed() != 0)) {
/* 440 */         throw new SSLException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.check.wrap"));
/*     */       }
/* 442 */       if ((!wrap) && (result.bytesProduced() != 0)) {
/* 443 */         throw new SSLException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.check.unwrap"));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class WrapperFuture<T, A>
/*     */     implements Future<T>
/*     */   {
/*     */     private final CompletionHandler<T, A> handler;
/*     */     private final A attachment;
/* 454 */     private volatile T result = null;
/* 455 */     private volatile Throwable throwable = null;
/* 456 */     private CountDownLatch completionLatch = new CountDownLatch(1);
/*     */     
/*     */     public WrapperFuture() {
/* 459 */       this(null, null);
/*     */     }
/*     */     
/*     */     public WrapperFuture(CompletionHandler<T, A> handler, A attachment) {
/* 463 */       this.handler = handler;
/* 464 */       this.attachment = attachment;
/*     */     }
/*     */     
/*     */     public void complete(T result) {
/* 468 */       this.result = result;
/* 469 */       this.completionLatch.countDown();
/* 470 */       if (this.handler != null) {
/* 471 */         this.handler.completed(result, this.attachment);
/*     */       }
/*     */     }
/*     */     
/*     */     public void fail(Throwable t) {
/* 476 */       this.throwable = t;
/* 477 */       this.completionLatch.countDown();
/* 478 */       if (this.handler != null) {
/* 479 */         this.handler.failed(this.throwable, this.attachment);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public final boolean cancel(boolean mayInterruptIfRunning)
/*     */     {
/* 486 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */     public final boolean isCancelled()
/*     */     {
/* 492 */       return false;
/*     */     }
/*     */     
/*     */     public final boolean isDone()
/*     */     {
/* 497 */       return this.completionLatch.getCount() > 0L;
/*     */     }
/*     */     
/*     */     public T get() throws InterruptedException, ExecutionException
/*     */     {
/* 502 */       this.completionLatch.await();
/* 503 */       if (this.throwable != null) {
/* 504 */         throw new ExecutionException(this.throwable);
/*     */       }
/* 506 */       return (T)this.result;
/*     */     }
/*     */     
/*     */ 
/*     */     public T get(long timeout, TimeUnit unit)
/*     */       throws InterruptedException, ExecutionException, TimeoutException
/*     */     {
/* 513 */       boolean latchResult = this.completionLatch.await(timeout, unit);
/* 514 */       if (!latchResult) {
/* 515 */         throw new TimeoutException();
/*     */       }
/* 517 */       if (this.throwable != null) {
/* 518 */         throw new ExecutionException(this.throwable);
/*     */       }
/* 520 */       return (T)this.result;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class LongToIntegerFuture implements Future<Integer>
/*     */   {
/*     */     private final Future<Long> wrapped;
/*     */     
/*     */     public LongToIntegerFuture(Future<Long> wrapped) {
/* 529 */       this.wrapped = wrapped;
/*     */     }
/*     */     
/*     */     public boolean cancel(boolean mayInterruptIfRunning)
/*     */     {
/* 534 */       return this.wrapped.cancel(mayInterruptIfRunning);
/*     */     }
/*     */     
/*     */     public boolean isCancelled()
/*     */     {
/* 539 */       return this.wrapped.isCancelled();
/*     */     }
/*     */     
/*     */     public boolean isDone()
/*     */     {
/* 544 */       return this.wrapped.isDone();
/*     */     }
/*     */     
/*     */     public Integer get() throws InterruptedException, ExecutionException
/*     */     {
/* 549 */       Long result = (Long)this.wrapped.get();
/* 550 */       if (result.longValue() > 2147483647L) {
/* 551 */         throw new ExecutionException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.tooBig", new Object[] { result }), null);
/*     */       }
/*     */       
/* 554 */       return Integer.valueOf(result.intValue());
/*     */     }
/*     */     
/*     */ 
/*     */     public Integer get(long timeout, TimeUnit unit)
/*     */       throws InterruptedException, ExecutionException, TimeoutException
/*     */     {
/* 561 */       Long result = (Long)this.wrapped.get(timeout, unit);
/* 562 */       if (result.longValue() > 2147483647L) {
/* 563 */         throw new ExecutionException(AsyncChannelWrapperSecure.sm.getString("asyncChannelWrapperSecure.tooBig", new Object[] { result }), null);
/*     */       }
/*     */       
/* 566 */       return Integer.valueOf(result.intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SecureIOThreadFactory
/*     */     implements ThreadFactory
/*     */   {
/* 573 */     private AtomicInteger count = new AtomicInteger(0);
/*     */     
/*     */     public Thread newThread(Runnable r)
/*     */     {
/* 577 */       Thread t = new Thread(r);
/* 578 */       t.setName("WebSocketClient-SecureIO-" + this.count.incrementAndGet());
/*     */       
/*     */ 
/* 581 */       t.setDaemon(true);
/* 582 */       return t;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\AsyncChannelWrapperSecure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */