/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.websocket.DeploymentException;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UriTemplate
/*     */ {
/*  37 */   private static final StringManager sm = StringManager.getManager(UriTemplate.class);
/*     */   
/*     */   private final String normalized;
/*  40 */   private final List<Segment> segments = new ArrayList();
/*     */   private final boolean hasParameters;
/*     */   
/*     */   public UriTemplate(String path)
/*     */     throws DeploymentException
/*     */   {
/*  46 */     if ((path == null) || (path.length() == 0) || (!path.startsWith("/")) || (path.contains("/../")) || 
/*  47 */       (path.contains("/./")) || (path.contains("//")))
/*     */     {
/*  49 */       throw new DeploymentException(sm.getString("uriTemplate.invalidPath", new Object[] { path }));
/*     */     }
/*     */     
/*  52 */     StringBuilder normalized = new StringBuilder(path.length());
/*  53 */     Set<String> paramNames = new HashSet();
/*     */     
/*     */ 
/*  56 */     String[] segments = path.split("/", -1);
/*  57 */     int paramCount = 0;
/*  58 */     int segmentCount = 0;
/*     */     
/*  60 */     for (int i = 0; i < segments.length; i++) {
/*  61 */       String segment = segments[i];
/*  62 */       if (segment.length() == 0) {
/*  63 */         if ((i != 0) && ((i != segments.length - 1) || (paramCount != 0)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */           throw new DeploymentException(sm.getString("uriTemplate.emptySegment", new Object[] { path }));
/*     */         }
/*     */       }
/*     */       else {
/*  76 */         normalized.append('/');
/*  77 */         int index = -1;
/*  78 */         if ((segment.startsWith("{")) && (segment.endsWith("}"))) {
/*  79 */           index = segmentCount;
/*  80 */           segment = segment.substring(1, segment.length() - 1);
/*  81 */           normalized.append('{');
/*  82 */           normalized.append(paramCount++);
/*  83 */           normalized.append('}');
/*  84 */           if (!paramNames.add(segment)) {
/*  85 */             throw new DeploymentException(sm.getString("uriTemplate.duplicateParameter", new Object[] { segment }));
/*     */           }
/*     */         }
/*     */         else {
/*  89 */           if ((segment.contains("{")) || (segment.contains("}"))) {
/*  90 */             throw new DeploymentException(sm.getString("uriTemplate.invalidSegment", new Object[] { segment, path }));
/*     */           }
/*     */           
/*  93 */           normalized.append(segment);
/*     */         }
/*  95 */         this.segments.add(new Segment(index, segment));
/*  96 */         segmentCount++;
/*     */       }
/*     */     }
/*  99 */     this.normalized = normalized.toString();
/* 100 */     this.hasParameters = (paramCount > 0);
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<String, String> match(UriTemplate candidate)
/*     */   {
/* 106 */     Map<String, String> result = new HashMap();
/*     */     
/*     */ 
/* 109 */     if (candidate.getSegmentCount() != getSegmentCount()) {
/* 110 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 114 */     Iterator<Segment> candidateSegments = candidate.getSegments().iterator();
/* 115 */     Iterator<Segment> targetSegments = this.segments.iterator();
/*     */     
/* 117 */     while (candidateSegments.hasNext()) {
/* 118 */       Segment candidateSegment = (Segment)candidateSegments.next();
/* 119 */       Segment targetSegment = (Segment)targetSegments.next();
/*     */       
/* 121 */       if (targetSegment.getParameterIndex() == -1)
/*     */       {
/* 123 */         if (!targetSegment.getValue().equals(candidateSegment
/* 124 */           .getValue()))
/*     */         {
/* 126 */           return null;
/*     */         }
/*     */       }
/*     */       else {
/* 130 */         result.put(targetSegment.getValue(), candidateSegment
/* 131 */           .getValue());
/*     */       }
/*     */     }
/*     */     
/* 135 */     return result;
/*     */   }
/*     */   
/*     */   public boolean hasParameters()
/*     */   {
/* 140 */     return this.hasParameters;
/*     */   }
/*     */   
/*     */   public int getSegmentCount()
/*     */   {
/* 145 */     return this.segments.size();
/*     */   }
/*     */   
/*     */   public String getNormalizedPath()
/*     */   {
/* 150 */     return this.normalized;
/*     */   }
/*     */   
/*     */   private List<Segment> getSegments()
/*     */   {
/* 155 */     return this.segments;
/*     */   }
/*     */   
/*     */   private static class Segment
/*     */   {
/*     */     private final int parameterIndex;
/*     */     private final String value;
/*     */     
/*     */     public Segment(int parameterIndex, String value) {
/* 164 */       this.parameterIndex = parameterIndex;
/* 165 */       this.value = value;
/*     */     }
/*     */     
/*     */     public int getParameterIndex()
/*     */     {
/* 170 */       return this.parameterIndex;
/*     */     }
/*     */     
/*     */     public String getValue()
/*     */     {
/* 175 */       return this.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\server\UriTemplate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */