/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.websocket.Extension;
/*     */ import javax.websocket.Extension.Parameter;
/*     */ import javax.websocket.server.ServerEndpointConfig;
/*     */ import javax.websocket.server.ServerEndpointConfig.Configurator;
/*     */ import org.apache.tomcat.util.codec.binary.Base64;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.util.security.ConcurrentMessageDigest;
/*     */ import org.apache.tomcat.websocket.Constants;
/*     */ import org.apache.tomcat.websocket.Transformation;
/*     */ import org.apache.tomcat.websocket.TransformationFactory;
/*     */ import org.apache.tomcat.websocket.Util;
/*     */ import org.apache.tomcat.websocket.WsHandshakeResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpgradeUtil
/*     */ {
/*  50 */   private static final StringManager sm = StringManager.getManager(UpgradeUtil.class.getPackage().getName());
/*  51 */   private static final byte[] WS_ACCEPT = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
/*  52 */     .getBytes(StandardCharsets.ISO_8859_1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isWebSocketUpgradeRequest(ServletRequest request, ServletResponse response)
/*     */   {
/*  75 */     if (((request instanceof HttpServletRequest)) && ((response instanceof HttpServletResponse)))
/*     */     {
/*  77 */       if (!headerContainsToken((HttpServletRequest)request, "Upgrade", "websocket")) {}
/*     */     }
/*  75 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  80 */       "GET".equals(((HttpServletRequest)request).getMethod());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void doUpgrade(WsServerContainer sc, HttpServletRequest req, HttpServletResponse resp, ServerEndpointConfig sec, Map<String, String> pathParams)
/*     */     throws ServletException, IOException
/*     */   {
/*  92 */     String subProtocol = null;
/*  93 */     if (!headerContainsToken(req, "Connection", "upgrade"))
/*     */     {
/*  95 */       resp.sendError(400);
/*  96 */       return;
/*     */     }
/*  98 */     if (!headerContainsToken(req, "Sec-WebSocket-Version", "13"))
/*     */     {
/* 100 */       resp.setStatus(426);
/* 101 */       resp.setHeader("Sec-WebSocket-Version", "13");
/*     */       
/* 103 */       return;
/*     */     }
/* 105 */     String key = req.getHeader("Sec-WebSocket-Key");
/* 106 */     if (key == null) {
/* 107 */       resp.sendError(400);
/* 108 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 113 */     String origin = req.getHeader("Origin");
/* 114 */     if (!sec.getConfigurator().checkOrigin(origin)) {
/* 115 */       resp.sendError(403);
/* 116 */       return;
/*     */     }
/*     */     
/* 119 */     List<String> subProtocols = getTokensFromHeader(req, "Sec-WebSocket-Protocol");
/*     */     
/* 121 */     subProtocol = sec.getConfigurator().getNegotiatedSubprotocol(sec
/* 122 */       .getSubprotocols(), subProtocols);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 127 */     List<Extension> extensionsRequested = new ArrayList();
/* 128 */     Enumeration<String> extHeaders = req.getHeaders("Sec-WebSocket-Extensions");
/* 129 */     while (extHeaders.hasMoreElements()) {
/* 130 */       Util.parseExtensionHeader(extensionsRequested, (String)extHeaders.nextElement());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 135 */     List<Extension> installedExtensions = null;
/* 136 */     if (sec.getExtensions().size() == 0) {
/* 137 */       installedExtensions = Constants.INSTALLED_EXTENSIONS;
/*     */     } else {
/* 139 */       installedExtensions = new ArrayList();
/* 140 */       installedExtensions.addAll(sec.getExtensions());
/* 141 */       installedExtensions.addAll(Constants.INSTALLED_EXTENSIONS);
/*     */     }
/* 143 */     List<Extension> negotiatedExtensionsPhase1 = sec.getConfigurator().getNegotiatedExtensions(installedExtensions, extensionsRequested);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 150 */     List<Transformation> transformations = createTransformations(negotiatedExtensionsPhase1);
/*     */     List<Extension> negotiatedExtensionsPhase2;
/*     */     List<Extension> negotiatedExtensionsPhase2;
/* 153 */     if (transformations.isEmpty()) {
/* 154 */       negotiatedExtensionsPhase2 = Collections.emptyList();
/*     */     } else {
/* 156 */       negotiatedExtensionsPhase2 = new ArrayList(transformations.size());
/* 157 */       for (Transformation t : transformations) {
/* 158 */         negotiatedExtensionsPhase2.add(t.getExtensionResponse());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 163 */     Transformation transformation = null;
/* 164 */     StringBuilder responseHeaderExtensions = new StringBuilder();
/* 165 */     boolean first = true;
/* 166 */     for (Transformation t : transformations) {
/* 167 */       if (first) {
/* 168 */         first = false;
/*     */       } else {
/* 170 */         responseHeaderExtensions.append(',');
/*     */       }
/* 172 */       append(responseHeaderExtensions, t.getExtensionResponse());
/* 173 */       if (transformation == null) {
/* 174 */         transformation = t;
/*     */       } else {
/* 176 */         transformation.setNext(t);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 181 */     if ((transformation != null) && (!transformation.validateRsvBits(0))) {
/* 182 */       throw new ServletException(sm.getString("upgradeUtil.incompatibleRsv"));
/*     */     }
/*     */     
/*     */ 
/* 186 */     resp.setHeader("Upgrade", "websocket");
/*     */     
/* 188 */     resp.setHeader("Connection", "upgrade");
/*     */     
/* 190 */     resp.setHeader("Sec-WebSocket-Accept", 
/* 191 */       getWebSocketAccept(key));
/* 192 */     if ((subProtocol != null) && (subProtocol.length() > 0))
/*     */     {
/* 194 */       resp.setHeader("Sec-WebSocket-Protocol", subProtocol);
/*     */     }
/* 196 */     if (!transformations.isEmpty()) {
/* 197 */       resp.setHeader("Sec-WebSocket-Extensions", responseHeaderExtensions.toString());
/*     */     }
/*     */     
/* 200 */     WsHandshakeRequest wsRequest = new WsHandshakeRequest(req, pathParams);
/* 201 */     WsHandshakeResponse wsResponse = new WsHandshakeResponse();
/* 202 */     WsPerSessionServerEndpointConfig perSessionServerEndpointConfig = new WsPerSessionServerEndpointConfig(sec);
/*     */     
/* 204 */     sec.getConfigurator().modifyHandshake(perSessionServerEndpointConfig, wsRequest, wsResponse);
/*     */     
/* 206 */     wsRequest.finished();
/*     */     
/*     */ 
/*     */ 
/* 210 */     for (Iterator localIterator3 = wsResponse.getHeaders().entrySet().iterator(); localIterator3.hasNext();) { entry = (Map.Entry)localIterator3.next();
/* 211 */       for (String headerValue : (List)entry.getValue()) {
/* 212 */         resp.addHeader((String)entry.getKey(), headerValue);
/*     */       }
/*     */     }
/*     */     
/*     */     Map.Entry<String, List<String>> entry;
/* 217 */     WsHttpUpgradeHandler wsHandler = (WsHttpUpgradeHandler)req.upgrade(WsHttpUpgradeHandler.class);
/* 218 */     wsHandler.preInit(perSessionServerEndpointConfig, sc, wsRequest, negotiatedExtensionsPhase2, subProtocol, transformation, pathParams, req
/*     */     
/* 220 */       .isSecure());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static List<Transformation> createTransformations(List<Extension> negotiatedExtensions)
/*     */   {
/* 228 */     TransformationFactory factory = TransformationFactory.getInstance();
/*     */     
/* 230 */     LinkedHashMap<String, List<List<Extension.Parameter>>> extensionPreferences = new LinkedHashMap();
/*     */     
/*     */ 
/*     */ 
/* 234 */     List<Transformation> result = new ArrayList(negotiatedExtensions.size());
/*     */     
/* 236 */     for (Extension extension : negotiatedExtensions)
/*     */     {
/* 238 */       List<List<Extension.Parameter>> preferences = (List)extensionPreferences.get(extension.getName());
/*     */       
/* 240 */       if (preferences == null) {
/* 241 */         preferences = new ArrayList();
/* 242 */         extensionPreferences.put(extension.getName(), preferences);
/*     */       }
/*     */       
/* 245 */       preferences.add(extension.getParameters());
/*     */     }
/*     */     
/*     */ 
/* 249 */     for (Map.Entry<String, List<List<Extension.Parameter>>> entry : extensionPreferences.entrySet()) {
/* 250 */       Transformation transformation = factory.create((String)entry.getKey(), (List)entry.getValue(), true);
/* 251 */       if (transformation != null) {
/* 252 */         result.add(transformation);
/*     */       }
/*     */     }
/* 255 */     return result;
/*     */   }
/*     */   
/*     */   private static void append(StringBuilder sb, Extension extension)
/*     */   {
/* 260 */     if ((extension == null) || (extension.getName() == null) || (extension.getName().length() == 0)) {
/* 261 */       return;
/*     */     }
/*     */     
/* 264 */     sb.append(extension.getName());
/*     */     
/* 266 */     for (Extension.Parameter p : extension.getParameters()) {
/* 267 */       sb.append(';');
/* 268 */       sb.append(p.getName());
/* 269 */       if (p.getValue() != null) {
/* 270 */         sb.append('=');
/* 271 */         sb.append(p.getValue());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean headerContainsToken(HttpServletRequest req, String headerName, String target)
/*     */   {
/* 283 */     Enumeration<String> headers = req.getHeaders(headerName);
/* 284 */     while (headers.hasMoreElements()) {
/* 285 */       String header = (String)headers.nextElement();
/* 286 */       String[] tokens = header.split(",");
/* 287 */       for (String token : tokens) {
/* 288 */         if (target.equalsIgnoreCase(token.trim())) {
/* 289 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 293 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static List<String> getTokensFromHeader(HttpServletRequest req, String headerName)
/*     */   {
/* 303 */     List<String> result = new ArrayList();
/* 304 */     Enumeration<String> headers = req.getHeaders(headerName);
/* 305 */     while (headers.hasMoreElements()) {
/* 306 */       String header = (String)headers.nextElement();
/* 307 */       String[] tokens = header.split(",");
/* 308 */       for (String token : tokens) {
/* 309 */         result.add(token.trim());
/*     */       }
/*     */     }
/* 312 */     return result;
/*     */   }
/*     */   
/*     */   private static String getWebSocketAccept(String key)
/*     */   {
/* 317 */     byte[] digest = ConcurrentMessageDigest.digestSHA1(new byte[][] {key
/* 318 */       .getBytes(StandardCharsets.ISO_8859_1), WS_ACCEPT });
/* 319 */     return Base64.encodeBase64String(digest);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\server\UpgradeUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */