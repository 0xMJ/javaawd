/*      */ package org.apache.tomcat.websocket;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.URI;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.channels.WritePendingException;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.security.Principal;
/*      */ import java.util.Collections;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import javax.naming.NamingException;
/*      */ import javax.websocket.ClientEndpointConfig;
/*      */ import javax.websocket.CloseReason;
/*      */ import javax.websocket.CloseReason.CloseCode;
/*      */ import javax.websocket.CloseReason.CloseCodes;
/*      */ import javax.websocket.DeploymentException;
/*      */ import javax.websocket.Endpoint;
/*      */ import javax.websocket.EndpointConfig;
/*      */ import javax.websocket.Extension;
/*      */ import javax.websocket.MessageHandler;
/*      */ import javax.websocket.MessageHandler.Partial;
/*      */ import javax.websocket.MessageHandler.Whole;
/*      */ import javax.websocket.PongMessage;
/*      */ import javax.websocket.RemoteEndpoint.Async;
/*      */ import javax.websocket.RemoteEndpoint.Basic;
/*      */ import javax.websocket.SendResult;
/*      */ import javax.websocket.Session;
/*      */ import javax.websocket.WebSocketContainer;
/*      */ import javax.websocket.server.ServerEndpointConfig;
/*      */ import javax.websocket.server.ServerEndpointConfig.Builder;
/*      */ import javax.websocket.server.ServerEndpointConfig.Configurator;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ import org.apache.tomcat.websocket.pojo.PojoEndpointServer;
/*      */ import org.apache.tomcat.websocket.server.DefaultServerEndpointConfigurator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WsSession
/*      */   implements Session
/*      */ {
/*   63 */   private final Log log = LogFactory.getLog(WsSession.class);
/*   64 */   private static final StringManager sm = StringManager.getManager(WsSession.class);
/*      */   
/*      */ 
/*      */ 
/*   68 */   private static final byte[] ELLIPSIS_BYTES = "…".getBytes(StandardCharsets.UTF_8);
/*      */   
/*   70 */   private static final int ELLIPSIS_BYTES_LEN = ELLIPSIS_BYTES.length;
/*      */   
/*      */   private static final boolean SEC_CONFIGURATOR_USES_IMPL_DEFAULT;
/*      */   
/*   74 */   private static AtomicLong ids = new AtomicLong(0L);
/*      */   private final Endpoint localEndpoint;
/*      */   private final WsRemoteEndpointImplBase wsRemoteEndpoint;
/*      */   
/*      */   static {
/*   79 */     ServerEndpointConfig.Builder builder = ServerEndpointConfig.Builder.create(Object.class, "/");
/*   80 */     ServerEndpointConfig sec = builder.build();
/*      */     
/*   82 */     SEC_CONFIGURATOR_USES_IMPL_DEFAULT = sec.getConfigurator().getClass().equals(DefaultServerEndpointConfigurator.class);
/*      */   }
/*      */   
/*      */ 
/*      */   private final RemoteEndpoint.Async remoteEndpointAsync;
/*      */   
/*      */   private final RemoteEndpoint.Basic remoteEndpointBasic;
/*      */   
/*      */   private final ClassLoader applicationClassLoader;
/*      */   
/*      */   private final WsWebSocketContainer webSocketContainer;
/*      */   
/*      */   private final URI requestUri;
/*      */   private final Map<String, List<String>> requestParameterMap;
/*      */   private final String queryString;
/*      */   private final Principal userPrincipal;
/*      */   private final EndpointConfig endpointConfig;
/*      */   private final List<Extension> negotiatedExtensions;
/*      */   private final String subProtocol;
/*      */   private final Map<String, String> pathParameters;
/*      */   private final boolean secure;
/*      */   private final String httpSessionId;
/*      */   private final String id;
/*  105 */   private volatile MessageHandler textMessageHandler = null;
/*      */   
/*  107 */   private volatile MessageHandler binaryMessageHandler = null;
/*  108 */   private volatile MessageHandler.Whole<PongMessage> pongMessageHandler = null;
/*  109 */   private volatile State state = State.OPEN;
/*  110 */   private final Object stateLock = new Object();
/*  111 */   private final Map<String, Object> userProperties = new ConcurrentHashMap();
/*  112 */   private volatile int maxBinaryMessageBufferSize = Constants.DEFAULT_BUFFER_SIZE;
/*  113 */   private volatile int maxTextMessageBufferSize = Constants.DEFAULT_BUFFER_SIZE;
/*  114 */   private volatile long maxIdleTimeout = 0L;
/*  115 */   private volatile long lastActiveRead = System.currentTimeMillis();
/*  116 */   private volatile long lastActiveWrite = System.currentTimeMillis();
/*  117 */   private Map<FutureToSendHandler, FutureToSendHandler> futures = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private WsFrameBase wsFrame;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WsSession(ClientEndpointHolder clientEndpointHolder, WsRemoteEndpointImplBase wsRemoteEndpoint, WsWebSocketContainer wsWebSocketContainer, List<Extension> negotiatedExtensions, String subProtocol, Map<String, String> pathParameters, boolean secure, ClientEndpointConfig clientEndpointConfig)
/*      */     throws DeploymentException
/*      */   {
/*  147 */     this.wsRemoteEndpoint = wsRemoteEndpoint;
/*  148 */     this.wsRemoteEndpoint.setSession(this);
/*  149 */     this.remoteEndpointAsync = new WsRemoteEndpointAsync(wsRemoteEndpoint);
/*  150 */     this.remoteEndpointBasic = new WsRemoteEndpointBasic(wsRemoteEndpoint);
/*  151 */     this.webSocketContainer = wsWebSocketContainer;
/*  152 */     this.applicationClassLoader = Thread.currentThread().getContextClassLoader();
/*  153 */     wsRemoteEndpoint.setSendTimeout(wsWebSocketContainer.getDefaultAsyncSendTimeout());
/*  154 */     this.maxBinaryMessageBufferSize = this.webSocketContainer.getDefaultMaxBinaryMessageBufferSize();
/*  155 */     this.maxTextMessageBufferSize = this.webSocketContainer.getDefaultMaxTextMessageBufferSize();
/*  156 */     this.maxIdleTimeout = this.webSocketContainer.getDefaultMaxSessionIdleTimeout();
/*  157 */     this.requestUri = null;
/*  158 */     this.requestParameterMap = Collections.emptyMap();
/*  159 */     this.queryString = null;
/*  160 */     this.userPrincipal = null;
/*  161 */     this.httpSessionId = null;
/*  162 */     this.negotiatedExtensions = negotiatedExtensions;
/*  163 */     if (subProtocol == null) {
/*  164 */       this.subProtocol = "";
/*      */     } else {
/*  166 */       this.subProtocol = subProtocol;
/*      */     }
/*  168 */     this.pathParameters = pathParameters;
/*  169 */     this.secure = secure;
/*  170 */     this.wsRemoteEndpoint.setEncoders(clientEndpointConfig);
/*  171 */     this.endpointConfig = clientEndpointConfig;
/*      */     
/*  173 */     this.userProperties.putAll(this.endpointConfig.getUserProperties());
/*  174 */     this.id = Long.toHexString(ids.getAndIncrement());
/*      */     
/*  176 */     this.localEndpoint = clientEndpointHolder.getInstance(getInstanceManager());
/*      */     
/*  178 */     if (this.log.isDebugEnabled()) {
/*  179 */       this.log.debug(sm.getString("wsSession.created", new Object[] { this.id }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public WsSession(WsRemoteEndpointImplBase wsRemoteEndpoint, WsWebSocketContainer wsWebSocketContainer, URI requestUri, Map<String, List<String>> requestParameterMap, String queryString, Principal userPrincipal, String httpSessionId, List<Extension> negotiatedExtensions, String subProtocol, Map<String, String> pathParameters, boolean secure, ServerEndpointConfig serverEndpointConfig)
/*      */     throws DeploymentException
/*      */   {
/*  226 */     this.wsRemoteEndpoint = wsRemoteEndpoint;
/*  227 */     this.wsRemoteEndpoint.setSession(this);
/*  228 */     this.remoteEndpointAsync = new WsRemoteEndpointAsync(wsRemoteEndpoint);
/*  229 */     this.remoteEndpointBasic = new WsRemoteEndpointBasic(wsRemoteEndpoint);
/*  230 */     this.webSocketContainer = wsWebSocketContainer;
/*  231 */     this.applicationClassLoader = Thread.currentThread().getContextClassLoader();
/*  232 */     wsRemoteEndpoint.setSendTimeout(wsWebSocketContainer.getDefaultAsyncSendTimeout());
/*  233 */     this.maxBinaryMessageBufferSize = this.webSocketContainer.getDefaultMaxBinaryMessageBufferSize();
/*  234 */     this.maxTextMessageBufferSize = this.webSocketContainer.getDefaultMaxTextMessageBufferSize();
/*  235 */     this.maxIdleTimeout = this.webSocketContainer.getDefaultMaxSessionIdleTimeout();
/*  236 */     this.requestUri = requestUri;
/*  237 */     if (requestParameterMap == null) {
/*  238 */       this.requestParameterMap = Collections.emptyMap();
/*      */     } else {
/*  240 */       this.requestParameterMap = requestParameterMap;
/*      */     }
/*  242 */     this.queryString = queryString;
/*  243 */     this.userPrincipal = userPrincipal;
/*  244 */     this.httpSessionId = httpSessionId;
/*  245 */     this.negotiatedExtensions = negotiatedExtensions;
/*  246 */     if (subProtocol == null) {
/*  247 */       this.subProtocol = "";
/*      */     } else {
/*  249 */       this.subProtocol = subProtocol;
/*      */     }
/*  251 */     this.pathParameters = pathParameters;
/*  252 */     this.secure = secure;
/*  253 */     this.wsRemoteEndpoint.setEncoders(serverEndpointConfig);
/*  254 */     this.endpointConfig = serverEndpointConfig;
/*      */     
/*  256 */     this.userProperties.putAll(this.endpointConfig.getUserProperties());
/*  257 */     this.id = Long.toHexString(ids.getAndIncrement());
/*      */     
/*  259 */     InstanceManager instanceManager = getInstanceManager();
/*  260 */     ServerEndpointConfig.Configurator configurator = serverEndpointConfig.getConfigurator();
/*  261 */     Class<?> clazz = serverEndpointConfig.getEndpointClass();
/*      */     
/*      */     try
/*      */     {
/*  265 */       if ((instanceManager == null) || (!isDefaultConfigurator(configurator))) {
/*  266 */         Object endpointInstance = configurator.getEndpointInstance(clazz);
/*  267 */         if (instanceManager != null) {
/*      */           try {
/*  269 */             instanceManager.newInstance(endpointInstance);
/*      */           } catch (ReflectiveOperationException|NamingException e) {
/*  271 */             throw new DeploymentException(sm.getString("wsSession.instanceNew"), e);
/*      */           }
/*      */         }
/*      */       } else {
/*  275 */         endpointInstance = instanceManager.newInstance(clazz);
/*      */       }
/*      */     } catch (ReflectiveOperationException|NamingException e) { Object endpointInstance;
/*  278 */       throw new DeploymentException(sm.getString("wsSession.instanceCreateFailed"), e);
/*      */     }
/*      */     Object endpointInstance;
/*  281 */     if ((endpointInstance instanceof Endpoint)) {
/*  282 */       this.localEndpoint = ((Endpoint)endpointInstance);
/*      */     } else {
/*  284 */       this.localEndpoint = new PojoEndpointServer(pathParameters, endpointInstance);
/*      */     }
/*      */     
/*  287 */     if (this.log.isDebugEnabled()) {
/*  288 */       this.log.debug(sm.getString("wsSession.created", new Object[] { this.id }));
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isDefaultConfigurator(ServerEndpointConfig.Configurator configurator)
/*      */   {
/*  294 */     if (configurator.getClass().equals(DefaultServerEndpointConfigurator.class)) {
/*  295 */       return true;
/*      */     }
/*  297 */     if ((SEC_CONFIGURATOR_USES_IMPL_DEFAULT) && 
/*  298 */       (configurator.getClass().equals(ServerEndpointConfig.Configurator.class))) {
/*  299 */       return true;
/*      */     }
/*  301 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public WsSession(Endpoint localEndpoint, WsRemoteEndpointImplBase wsRemoteEndpoint, WsWebSocketContainer wsWebSocketContainer, URI requestUri, Map<String, List<String>> requestParameterMap, String queryString, Principal userPrincipal, String httpSessionId, List<Extension> negotiatedExtensions, String subProtocol, Map<String, String> pathParameters, boolean secure, EndpointConfig endpointConfig)
/*      */     throws DeploymentException
/*      */   {
/*  350 */     this.localEndpoint = localEndpoint;
/*  351 */     this.wsRemoteEndpoint = wsRemoteEndpoint;
/*  352 */     this.wsRemoteEndpoint.setSession(this);
/*  353 */     this.remoteEndpointAsync = new WsRemoteEndpointAsync(wsRemoteEndpoint);
/*  354 */     this.remoteEndpointBasic = new WsRemoteEndpointBasic(wsRemoteEndpoint);
/*  355 */     this.webSocketContainer = wsWebSocketContainer;
/*  356 */     this.applicationClassLoader = Thread.currentThread().getContextClassLoader();
/*  357 */     wsRemoteEndpoint.setSendTimeout(wsWebSocketContainer.getDefaultAsyncSendTimeout());
/*  358 */     this.maxBinaryMessageBufferSize = this.webSocketContainer.getDefaultMaxBinaryMessageBufferSize();
/*  359 */     this.maxTextMessageBufferSize = this.webSocketContainer.getDefaultMaxTextMessageBufferSize();
/*  360 */     this.maxIdleTimeout = this.webSocketContainer.getDefaultMaxSessionIdleTimeout();
/*  361 */     this.requestUri = requestUri;
/*  362 */     if (requestParameterMap == null) {
/*  363 */       this.requestParameterMap = Collections.emptyMap();
/*      */     } else {
/*  365 */       this.requestParameterMap = requestParameterMap;
/*      */     }
/*  367 */     this.queryString = queryString;
/*  368 */     this.userPrincipal = userPrincipal;
/*  369 */     this.httpSessionId = httpSessionId;
/*  370 */     this.negotiatedExtensions = negotiatedExtensions;
/*  371 */     if (subProtocol == null) {
/*  372 */       this.subProtocol = "";
/*      */     } else {
/*  374 */       this.subProtocol = subProtocol;
/*      */     }
/*  376 */     this.pathParameters = pathParameters;
/*  377 */     this.secure = secure;
/*  378 */     this.wsRemoteEndpoint.setEncoders(endpointConfig);
/*  379 */     this.endpointConfig = endpointConfig;
/*      */     
/*  381 */     this.userProperties.putAll(endpointConfig.getUserProperties());
/*  382 */     this.id = Long.toHexString(ids.getAndIncrement());
/*      */     
/*  384 */     InstanceManager instanceManager = getInstanceManager();
/*  385 */     if (instanceManager != null) {
/*      */       try {
/*  387 */         instanceManager.newInstance(localEndpoint);
/*      */       } catch (Exception e) {
/*  389 */         throw new DeploymentException(sm.getString("wsSession.instanceNew"), e);
/*      */       }
/*      */     }
/*      */     
/*  393 */     if (this.log.isDebugEnabled()) {
/*  394 */       this.log.debug(sm.getString("wsSession.created", new Object[] { this.id }));
/*      */     }
/*      */   }
/*      */   
/*      */   public InstanceManager getInstanceManager()
/*      */   {
/*  400 */     return this.webSocketContainer.getInstanceManager(this.applicationClassLoader);
/*      */   }
/*      */   
/*      */ 
/*      */   public WebSocketContainer getContainer()
/*      */   {
/*  406 */     checkState();
/*  407 */     return this.webSocketContainer;
/*      */   }
/*      */   
/*      */ 
/*      */   public void addMessageHandler(MessageHandler listener)
/*      */   {
/*  413 */     Class<?> target = Util.getMessageType(listener);
/*  414 */     doAddMessageHandler(target, listener);
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> void addMessageHandler(Class<T> clazz, MessageHandler.Partial<T> handler)
/*      */     throws IllegalStateException
/*      */   {
/*  421 */     doAddMessageHandler(clazz, handler);
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> void addMessageHandler(Class<T> clazz, MessageHandler.Whole<T> handler)
/*      */     throws IllegalStateException
/*      */   {
/*  428 */     doAddMessageHandler(clazz, handler);
/*      */   }
/*      */   
/*      */ 
/*      */   private void doAddMessageHandler(Class<?> target, MessageHandler listener)
/*      */   {
/*  434 */     checkState();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  446 */     Set<MessageHandlerResult> mhResults = Util.getMessageHandlers(target, listener, this.endpointConfig, this);
/*      */     
/*      */ 
/*  449 */     for (MessageHandlerResult mhResult : mhResults) {
/*  450 */       switch (mhResult.getType()) {
/*      */       case TEXT: 
/*  452 */         if (this.textMessageHandler != null) {
/*  453 */           throw new IllegalStateException(sm.getString("wsSession.duplicateHandlerText"));
/*      */         }
/*  455 */         this.textMessageHandler = mhResult.getHandler();
/*  456 */         break;
/*      */       
/*      */       case BINARY: 
/*  459 */         if (this.binaryMessageHandler != null)
/*      */         {
/*  461 */           throw new IllegalStateException(sm.getString("wsSession.duplicateHandlerBinary"));
/*      */         }
/*  463 */         this.binaryMessageHandler = mhResult.getHandler();
/*  464 */         break;
/*      */       
/*      */       case PONG: 
/*  467 */         if (this.pongMessageHandler != null) {
/*  468 */           throw new IllegalStateException(sm.getString("wsSession.duplicateHandlerPong"));
/*      */         }
/*  470 */         MessageHandler handler = mhResult.getHandler();
/*  471 */         if ((handler instanceof MessageHandler.Whole)) {
/*  472 */           this.pongMessageHandler = ((MessageHandler.Whole)handler);
/*      */         }
/*      */         else {
/*  475 */           throw new IllegalStateException(sm.getString("wsSession.invalidHandlerTypePong"));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         break;
/*      */       default: 
/*  482 */         throw new IllegalArgumentException(sm.getString("wsSession.unknownHandlerType", new Object[] { listener, mhResult.getType() }));
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Set<MessageHandler> getMessageHandlers()
/*      */   {
/*  491 */     checkState();
/*  492 */     Set<MessageHandler> result = new HashSet();
/*  493 */     if (this.binaryMessageHandler != null) {
/*  494 */       result.add(this.binaryMessageHandler);
/*      */     }
/*  496 */     if (this.textMessageHandler != null) {
/*  497 */       result.add(this.textMessageHandler);
/*      */     }
/*  499 */     if (this.pongMessageHandler != null) {
/*  500 */       result.add(this.pongMessageHandler);
/*      */     }
/*  502 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   public void removeMessageHandler(MessageHandler listener)
/*      */   {
/*  508 */     checkState();
/*  509 */     if (listener == null) {
/*  510 */       return;
/*      */     }
/*      */     
/*  513 */     MessageHandler wrapped = null;
/*      */     
/*  515 */     if ((listener instanceof WrappedMessageHandler)) {
/*  516 */       wrapped = ((WrappedMessageHandler)listener).getWrappedHandler();
/*      */     }
/*      */     
/*  519 */     if (wrapped == null) {
/*  520 */       wrapped = listener;
/*      */     }
/*      */     
/*  523 */     boolean removed = false;
/*  524 */     if ((wrapped.equals(this.textMessageHandler)) || (listener.equals(this.textMessageHandler))) {
/*  525 */       this.textMessageHandler = null;
/*  526 */       removed = true;
/*      */     }
/*      */     
/*  529 */     if ((wrapped.equals(this.binaryMessageHandler)) || (listener.equals(this.binaryMessageHandler))) {
/*  530 */       this.binaryMessageHandler = null;
/*  531 */       removed = true;
/*      */     }
/*      */     
/*  534 */     if ((wrapped.equals(this.pongMessageHandler)) || (listener.equals(this.pongMessageHandler))) {
/*  535 */       this.pongMessageHandler = null;
/*  536 */       removed = true;
/*      */     }
/*      */     
/*  539 */     if (!removed)
/*      */     {
/*      */ 
/*      */ 
/*  543 */       throw new IllegalStateException(sm.getString("wsSession.removeHandlerFailed", new Object[] { listener }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public String getProtocolVersion()
/*      */   {
/*  550 */     checkState();
/*  551 */     return "13";
/*      */   }
/*      */   
/*      */ 
/*      */   public String getNegotiatedSubprotocol()
/*      */   {
/*  557 */     checkState();
/*  558 */     return this.subProtocol;
/*      */   }
/*      */   
/*      */ 
/*      */   public List<Extension> getNegotiatedExtensions()
/*      */   {
/*  564 */     checkState();
/*  565 */     return this.negotiatedExtensions;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isSecure()
/*      */   {
/*  571 */     checkState();
/*  572 */     return this.secure;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isOpen()
/*      */   {
/*  578 */     return this.state == State.OPEN;
/*      */   }
/*      */   
/*      */ 
/*      */   public long getMaxIdleTimeout()
/*      */   {
/*  584 */     checkState();
/*  585 */     return this.maxIdleTimeout;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setMaxIdleTimeout(long timeout)
/*      */   {
/*  591 */     checkState();
/*  592 */     this.maxIdleTimeout = timeout;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setMaxBinaryMessageBufferSize(int max)
/*      */   {
/*  598 */     checkState();
/*  599 */     this.maxBinaryMessageBufferSize = max;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getMaxBinaryMessageBufferSize()
/*      */   {
/*  605 */     checkState();
/*  606 */     return this.maxBinaryMessageBufferSize;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setMaxTextMessageBufferSize(int max)
/*      */   {
/*  612 */     checkState();
/*  613 */     this.maxTextMessageBufferSize = max;
/*      */   }
/*      */   
/*      */ 
/*      */   public int getMaxTextMessageBufferSize()
/*      */   {
/*  619 */     checkState();
/*  620 */     return this.maxTextMessageBufferSize;
/*      */   }
/*      */   
/*      */ 
/*      */   public Set<Session> getOpenSessions()
/*      */   {
/*  626 */     checkState();
/*  627 */     return this.webSocketContainer.getOpenSessions(getSessionMapKey());
/*      */   }
/*      */   
/*      */ 
/*      */   public RemoteEndpoint.Async getAsyncRemote()
/*      */   {
/*  633 */     checkState();
/*  634 */     return this.remoteEndpointAsync;
/*      */   }
/*      */   
/*      */ 
/*      */   public RemoteEndpoint.Basic getBasicRemote()
/*      */   {
/*  640 */     checkState();
/*  641 */     return this.remoteEndpointBasic;
/*      */   }
/*      */   
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/*  647 */     close(new CloseReason(CloseReason.CloseCodes.NORMAL_CLOSURE, ""));
/*      */   }
/*      */   
/*      */   public void close(CloseReason closeReason)
/*      */     throws IOException
/*      */   {
/*  653 */     doClose(closeReason, closeReason);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doClose(CloseReason closeReasonMessage, CloseReason closeReasonLocal)
/*      */   {
/*  666 */     doClose(closeReasonMessage, closeReasonLocal, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void doClose(CloseReason closeReasonMessage, CloseReason closeReasonLocal, boolean closeSocket)
/*      */   {
/*  683 */     if (this.state != State.OPEN) {
/*  684 */       return;
/*      */     }
/*      */     
/*  687 */     synchronized (this.stateLock) {
/*  688 */       if (this.state != State.OPEN) {
/*  689 */         return;
/*      */       }
/*      */       
/*  692 */       if (this.log.isDebugEnabled()) {
/*  693 */         this.log.debug(sm.getString("wsSession.doClose", new Object[] { this.id }));
/*      */       }
/*      */       try {
/*  696 */         this.wsRemoteEndpoint.setBatchingAllowed(false);
/*      */       } catch (IOException e) {
/*  698 */         this.log.warn(sm.getString("wsSession.flushFailOnClose"), e);
/*  699 */         fireEndpointOnError(e);
/*      */       }
/*      */       
/*  702 */       this.state = State.OUTPUT_CLOSED;
/*      */       
/*  704 */       sendCloseMessage(closeReasonMessage);
/*  705 */       if (closeSocket) {
/*  706 */         this.wsRemoteEndpoint.close();
/*      */       }
/*  708 */       fireEndpointOnClose(closeReasonLocal);
/*      */     }
/*      */     
/*  711 */     IOException ioe = new IOException(sm.getString("wsSession.messageFailed"));
/*  712 */     SendResult sr = new SendResult(ioe);
/*  713 */     for (FutureToSendHandler f2sh : this.futures.keySet()) {
/*  714 */       f2sh.onResult(sr);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void onClose(CloseReason closeReason)
/*      */   {
/*  729 */     synchronized (this.stateLock) {
/*  730 */       if (this.state != State.CLOSED) {
/*      */         try {
/*  732 */           this.wsRemoteEndpoint.setBatchingAllowed(false);
/*      */         } catch (IOException e) {
/*  734 */           this.log.warn(sm.getString("wsSession.flushFailOnClose"), e);
/*  735 */           fireEndpointOnError(e);
/*      */         }
/*  737 */         if (this.state == State.OPEN) {
/*  738 */           this.state = State.OUTPUT_CLOSED;
/*  739 */           sendCloseMessage(closeReason);
/*  740 */           fireEndpointOnClose(closeReason);
/*      */         }
/*  742 */         this.state = State.CLOSED;
/*      */         
/*      */ 
/*  745 */         this.wsRemoteEndpoint.close();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void fireEndpointOnClose(CloseReason closeReason)
/*      */   {
/*  753 */     Throwable throwable = null;
/*  754 */     InstanceManager instanceManager = getInstanceManager();
/*  755 */     Thread t = Thread.currentThread();
/*  756 */     ClassLoader cl = t.getContextClassLoader();
/*  757 */     t.setContextClassLoader(this.applicationClassLoader);
/*      */     try {
/*  759 */       this.localEndpoint.onClose(this, closeReason);
/*      */     } catch (Throwable t1) {
/*  761 */       ExceptionUtils.handleThrowable(t1);
/*  762 */       throwable = t1;
/*      */     } finally {
/*  764 */       if (instanceManager != null) {
/*      */         try {
/*  766 */           instanceManager.destroyInstance(this.localEndpoint);
/*      */         } catch (Throwable t2) {
/*  768 */           ExceptionUtils.handleThrowable(t2);
/*  769 */           if (throwable == null) {
/*  770 */             throwable = t2;
/*      */           }
/*      */         }
/*      */       }
/*  774 */       t.setContextClassLoader(cl);
/*      */     }
/*      */     
/*  777 */     if (throwable != null) {
/*  778 */       fireEndpointOnError(throwable);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void fireEndpointOnError(Throwable throwable)
/*      */   {
/*  787 */     Thread t = Thread.currentThread();
/*  788 */     ClassLoader cl = t.getContextClassLoader();
/*  789 */     t.setContextClassLoader(this.applicationClassLoader);
/*      */     try {
/*  791 */       this.localEndpoint.onError(this, throwable);
/*      */     } finally {
/*  793 */       t.setContextClassLoader(cl);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void sendCloseMessage(CloseReason closeReason)
/*      */   {
/*  800 */     ByteBuffer msg = ByteBuffer.allocate(125);
/*  801 */     CloseReason.CloseCode closeCode = closeReason.getCloseCode();
/*      */     
/*  803 */     if (closeCode == CloseReason.CloseCodes.CLOSED_ABNORMALLY)
/*      */     {
/*  805 */       msg.putShort((short)CloseReason.CloseCodes.PROTOCOL_ERROR.getCode());
/*      */     } else {
/*  807 */       msg.putShort((short)closeCode.getCode());
/*      */     }
/*      */     
/*  810 */     String reason = closeReason.getReasonPhrase();
/*  811 */     if ((reason != null) && (reason.length() > 0)) {
/*  812 */       appendCloseReasonWithTruncation(msg, reason);
/*      */     }
/*  814 */     msg.flip();
/*      */     try {
/*  816 */       this.wsRemoteEndpoint.sendMessageBlock((byte)8, msg, true);
/*      */     }
/*      */     catch (IOException|WritePendingException e)
/*      */     {
/*  820 */       if (this.log.isDebugEnabled()) {
/*  821 */         this.log.debug(sm.getString("wsSession.sendCloseFail", new Object[] { this.id }), e);
/*      */       }
/*  823 */       this.wsRemoteEndpoint.close();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  828 */       if (closeCode != CloseReason.CloseCodes.CLOSED_ABNORMALLY) {
/*  829 */         this.localEndpoint.onError(this, e);
/*      */       }
/*      */     } finally {
/*  832 */       this.webSocketContainer.unregisterSession(getSessionMapKey(), this);
/*      */     }
/*      */   }
/*      */   
/*      */   private Object getSessionMapKey()
/*      */   {
/*  838 */     if ((this.endpointConfig instanceof ServerEndpointConfig))
/*      */     {
/*  840 */       return ((ServerEndpointConfig)this.endpointConfig).getPath();
/*      */     }
/*      */     
/*  843 */     return this.localEndpoint;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static void appendCloseReasonWithTruncation(ByteBuffer msg, String reason)
/*      */   {
/*  857 */     byte[] reasonBytes = reason.getBytes(StandardCharsets.UTF_8);
/*      */     
/*  859 */     if (reasonBytes.length <= 123)
/*      */     {
/*  861 */       msg.put(reasonBytes);
/*      */     }
/*      */     else {
/*  864 */       int remaining = 123 - ELLIPSIS_BYTES_LEN;
/*  865 */       int pos = 0;
/*  866 */       byte[] bytesNext = reason.substring(pos, pos + 1).getBytes(StandardCharsets.UTF_8);
/*  867 */       while (remaining >= bytesNext.length) {
/*  868 */         msg.put(bytesNext);
/*  869 */         remaining -= bytesNext.length;
/*  870 */         pos++;
/*  871 */         bytesNext = reason.substring(pos, pos + 1).getBytes(StandardCharsets.UTF_8);
/*      */       }
/*  873 */       msg.put(ELLIPSIS_BYTES);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void registerFuture(FutureToSendHandler f2sh)
/*      */   {
/*  892 */     this.futures.put(f2sh, f2sh);
/*      */     
/*  894 */     if (this.state == State.OPEN)
/*      */     {
/*      */ 
/*  897 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  903 */     if (f2sh.isDone())
/*      */     {
/*      */ 
/*      */ 
/*  907 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  924 */     IOException ioe = new IOException(sm.getString("wsSession.messageFailed"));
/*  925 */     SendResult sr = new SendResult(ioe);
/*  926 */     f2sh.onResult(sr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void unregisterFuture(FutureToSendHandler f2sh)
/*      */   {
/*  935 */     this.futures.remove(f2sh);
/*      */   }
/*      */   
/*      */ 
/*      */   public URI getRequestURI()
/*      */   {
/*  941 */     checkState();
/*  942 */     return this.requestUri;
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, List<String>> getRequestParameterMap()
/*      */   {
/*  948 */     checkState();
/*  949 */     return this.requestParameterMap;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getQueryString()
/*      */   {
/*  955 */     checkState();
/*  956 */     return this.queryString;
/*      */   }
/*      */   
/*      */ 
/*      */   public Principal getUserPrincipal()
/*      */   {
/*  962 */     checkState();
/*  963 */     return this.userPrincipal;
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, String> getPathParameters()
/*      */   {
/*  969 */     checkState();
/*  970 */     return this.pathParameters;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getId()
/*      */   {
/*  976 */     return this.id;
/*      */   }
/*      */   
/*      */ 
/*      */   public Map<String, Object> getUserProperties()
/*      */   {
/*  982 */     checkState();
/*  983 */     return this.userProperties;
/*      */   }
/*      */   
/*      */   public Endpoint getLocal()
/*      */   {
/*  988 */     return this.localEndpoint;
/*      */   }
/*      */   
/*      */   public String getHttpSessionId()
/*      */   {
/*  993 */     return this.httpSessionId;
/*      */   }
/*      */   
/*      */   protected MessageHandler getTextMessageHandler()
/*      */   {
/*  998 */     return this.textMessageHandler;
/*      */   }
/*      */   
/*      */   protected MessageHandler getBinaryMessageHandler()
/*      */   {
/* 1003 */     return this.binaryMessageHandler;
/*      */   }
/*      */   
/*      */   protected MessageHandler.Whole<PongMessage> getPongMessageHandler()
/*      */   {
/* 1008 */     return this.pongMessageHandler;
/*      */   }
/*      */   
/*      */   protected void updateLastActiveRead()
/*      */   {
/* 1013 */     this.lastActiveRead = System.currentTimeMillis();
/*      */   }
/*      */   
/*      */   protected void updateLastActiveWrite()
/*      */   {
/* 1018 */     this.lastActiveWrite = System.currentTimeMillis();
/*      */   }
/*      */   
/*      */ 
/*      */   protected void checkExpiration()
/*      */   {
/* 1024 */     long timeout = this.maxIdleTimeout;
/* 1025 */     long timeoutRead = getMaxIdleTimeoutRead();
/* 1026 */     long timeoutWrite = getMaxIdleTimeoutWrite();
/*      */     
/* 1028 */     long currentTime = System.currentTimeMillis();
/* 1029 */     String key = null;
/*      */     
/* 1031 */     if ((timeoutRead > 0L) && (currentTime - this.lastActiveRead > timeoutRead)) {
/* 1032 */       key = "wsSession.timeoutRead";
/* 1033 */     } else if ((timeoutWrite > 0L) && (currentTime - this.lastActiveWrite > timeoutWrite)) {
/* 1034 */       key = "wsSession.timeoutWrite";
/* 1035 */     } else if ((timeout > 0L) && (currentTime - this.lastActiveRead > timeout) && (currentTime - this.lastActiveWrite > timeout))
/*      */     {
/* 1037 */       key = "wsSession.timeout";
/*      */     }
/*      */     
/* 1040 */     if (key != null) {
/* 1041 */       String msg = sm.getString(key, new Object[] { getId() });
/* 1042 */       if (this.log.isDebugEnabled()) {
/* 1043 */         this.log.debug(msg);
/*      */       }
/* 1045 */       doClose(new CloseReason(CloseReason.CloseCodes.GOING_AWAY, msg), new CloseReason(CloseReason.CloseCodes.CLOSED_ABNORMALLY, msg));
/*      */     }
/*      */   }
/*      */   
/*      */   private long getMaxIdleTimeoutRead()
/*      */   {
/* 1051 */     Object timeout = this.userProperties.get("org.apache.tomcat.websocket.READ_IDLE_TIMEOUT_MS");
/* 1052 */     if ((timeout instanceof Long)) {
/* 1053 */       return ((Long)timeout).longValue();
/*      */     }
/* 1055 */     return 0L;
/*      */   }
/*      */   
/*      */   private long getMaxIdleTimeoutWrite()
/*      */   {
/* 1060 */     Object timeout = this.userProperties.get("org.apache.tomcat.websocket.WRITE_IDLE_TIMEOUT_MS");
/* 1061 */     if ((timeout instanceof Long)) {
/* 1062 */       return ((Long)timeout).longValue();
/*      */     }
/* 1064 */     return 0L;
/*      */   }
/*      */   
/*      */   private void checkState()
/*      */   {
/* 1069 */     if (this.state == State.CLOSED)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1074 */       throw new IllegalStateException(sm.getString("wsSession.closed", new Object[] { this.id }));
/*      */     }
/*      */   }
/*      */   
/*      */   private static enum State {
/* 1079 */     OPEN, 
/* 1080 */     OUTPUT_CLOSED, 
/* 1081 */     CLOSED;
/*      */     
/*      */     private State() {}
/*      */   }
/*      */   
/*      */   void setWsFrame(WsFrameBase wsFrame) {
/* 1087 */     this.wsFrame = wsFrame;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void suspend()
/*      */   {
/* 1095 */     this.wsFrame.suspend();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resume()
/*      */   {
/* 1103 */     this.wsFrame.resume();
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\WsSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */