/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.WebConnection;
/*     */ import javax.websocket.CloseReason;
/*     */ import javax.websocket.CloseReason.CloseCodes;
/*     */ import javax.websocket.DeploymentException;
/*     */ import javax.websocket.Endpoint;
/*     */ import javax.websocket.Extension;
/*     */ import javax.websocket.server.ServerEndpointConfig;
/*     */ import org.apache.coyote.http11.upgrade.InternalHttpUpgradeHandler;
/*     */ import org.apache.coyote.http11.upgrade.UpgradeInfo;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.net.AbstractEndpoint.Handler.SocketState;
/*     */ import org.apache.tomcat.util.net.SSLSupport;
/*     */ import org.apache.tomcat.util.net.SocketEvent;
/*     */ import org.apache.tomcat.util.net.SocketWrapperBase;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.Transformation;
/*     */ import org.apache.tomcat.websocket.WsIOException;
/*     */ import org.apache.tomcat.websocket.WsSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsHttpUpgradeHandler
/*     */   implements InternalHttpUpgradeHandler
/*     */ {
/*  50 */   private final Log log = LogFactory.getLog(WsHttpUpgradeHandler.class);
/*  51 */   private static final StringManager sm = StringManager.getManager(WsHttpUpgradeHandler.class);
/*     */   
/*     */   private final ClassLoader applicationClassLoader;
/*     */   
/*     */   private SocketWrapperBase<?> socketWrapper;
/*  56 */   private UpgradeInfo upgradeInfo = new UpgradeInfo();
/*     */   
/*     */   private Endpoint ep;
/*     */   
/*     */   private ServerEndpointConfig serverEndpointConfig;
/*     */   private WsServerContainer webSocketContainer;
/*     */   private WsHandshakeRequest handshakeRequest;
/*     */   private List<Extension> negotiatedExtensions;
/*     */   private String subProtocol;
/*     */   private Transformation transformation;
/*     */   private Map<String, String> pathParameters;
/*     */   private boolean secure;
/*     */   private WebConnection connection;
/*     */   private WsRemoteEndpointImplServer wsRemoteEndpointServer;
/*     */   private WsFrameServer wsFrame;
/*     */   private WsSession wsSession;
/*     */   
/*     */   public WsHttpUpgradeHandler()
/*     */   {
/*  75 */     this.applicationClassLoader = Thread.currentThread().getContextClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setSocketWrapper(SocketWrapperBase<?> socketWrapper)
/*     */   {
/*  81 */     this.socketWrapper = socketWrapper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void preInit(ServerEndpointConfig serverEndpointConfig, WsServerContainer wsc, WsHandshakeRequest handshakeRequest, List<Extension> negotiatedExtensionsPhase2, String subProtocol, Transformation transformation, Map<String, String> pathParameters, boolean secure)
/*     */   {
/*  90 */     this.serverEndpointConfig = serverEndpointConfig;
/*  91 */     this.webSocketContainer = wsc;
/*  92 */     this.handshakeRequest = handshakeRequest;
/*  93 */     this.negotiatedExtensions = negotiatedExtensionsPhase2;
/*  94 */     this.subProtocol = subProtocol;
/*  95 */     this.transformation = transformation;
/*  96 */     this.pathParameters = pathParameters;
/*  97 */     this.secure = secure;
/*     */   }
/*     */   
/*     */ 
/*     */   public void init(WebConnection connection)
/*     */   {
/* 103 */     this.connection = connection;
/* 104 */     if (this.serverEndpointConfig == null)
/*     */     {
/* 106 */       throw new IllegalStateException(sm.getString("wsHttpUpgradeHandler.noPreInit"));
/*     */     }
/*     */     
/* 109 */     String httpSessionId = null;
/* 110 */     Object session = this.handshakeRequest.getHttpSession();
/* 111 */     if (session != null) {
/* 112 */       httpSessionId = ((HttpSession)session).getId();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 118 */     Thread t = Thread.currentThread();
/* 119 */     ClassLoader cl = t.getContextClassLoader();
/* 120 */     t.setContextClassLoader(this.applicationClassLoader);
/*     */     try {
/* 122 */       this.wsRemoteEndpointServer = new WsRemoteEndpointImplServer(this.socketWrapper, this.upgradeInfo, this.webSocketContainer);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 127 */       this.wsSession = new WsSession(this.wsRemoteEndpointServer, this.webSocketContainer, this.handshakeRequest.getRequestURI(), this.handshakeRequest.getParameterMap(), this.handshakeRequest.getQueryString(), this.handshakeRequest.getUserPrincipal(), httpSessionId, this.negotiatedExtensions, this.subProtocol, this.pathParameters, this.secure, this.serverEndpointConfig);
/*     */       
/*     */ 
/* 130 */       this.ep = this.wsSession.getLocal();
/* 131 */       this.wsFrame = new WsFrameServer(this.socketWrapper, this.upgradeInfo, this.wsSession, this.transformation, this.applicationClassLoader);
/*     */       
/*     */ 
/*     */ 
/* 135 */       this.wsRemoteEndpointServer.setTransformation(this.wsFrame.getTransformation());
/* 136 */       this.ep.onOpen(this.wsSession, this.serverEndpointConfig);
/* 137 */       this.webSocketContainer.registerSession(this.serverEndpointConfig.getPath(), this.wsSession);
/*     */     } catch (DeploymentException e) {
/* 139 */       throw new IllegalArgumentException(e);
/*     */     } finally {
/* 141 */       t.setContextClassLoader(cl);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public UpgradeInfo getUpgradeInfo()
/*     */   {
/* 148 */     return this.upgradeInfo;
/*     */   }
/*     */   
/*     */ 
/*     */   public AbstractEndpoint.Handler.SocketState upgradeDispatch(SocketEvent status)
/*     */   {
/* 154 */     switch (status) {
/*     */     case OPEN_READ: 
/*     */       try {
/* 157 */         return this.wsFrame.notifyDataAvailable();
/*     */       } catch (WsIOException ws) {
/* 159 */         close(ws.getCloseReason());
/*     */       } catch (IOException ioe) {
/* 161 */         onError(ioe);
/*     */         
/* 163 */         CloseReason cr = new CloseReason(CloseReason.CloseCodes.CLOSED_ABNORMALLY, ioe.getMessage());
/* 164 */         close(cr);
/*     */       }
/* 166 */       return AbstractEndpoint.Handler.SocketState.CLOSED;
/*     */     case OPEN_WRITE: 
/* 168 */       this.wsRemoteEndpointServer.onWritePossible(false);
/* 169 */       break;
/*     */     
/*     */     case STOP: 
/* 172 */       CloseReason cr = new CloseReason(CloseReason.CloseCodes.GOING_AWAY, sm.getString("wsHttpUpgradeHandler.serverStop"));
/*     */       try {
/* 174 */         this.wsSession.close(cr);
/*     */       } catch (IOException ioe) {
/* 176 */         onError(ioe);
/*     */         
/* 178 */         cr = new CloseReason(CloseReason.CloseCodes.CLOSED_ABNORMALLY, ioe.getMessage());
/* 179 */         close(cr);
/* 180 */         return AbstractEndpoint.Handler.SocketState.CLOSED;
/*     */       }
/*     */     
/*     */     case ERROR: 
/* 184 */       String msg = sm.getString("wsHttpUpgradeHandler.closeOnError");
/* 185 */       this.wsSession.doClose(new CloseReason(CloseReason.CloseCodes.GOING_AWAY, msg), new CloseReason(CloseReason.CloseCodes.CLOSED_ABNORMALLY, msg));
/*     */     
/*     */ 
/*     */     case DISCONNECT: 
/*     */     case TIMEOUT: 
/*     */     case CONNECT_FAIL: 
/* 191 */       return AbstractEndpoint.Handler.SocketState.CLOSED;
/*     */     }
/*     */     
/* 194 */     if (this.wsFrame.isOpen()) {
/* 195 */       return AbstractEndpoint.Handler.SocketState.UPGRADED;
/*     */     }
/* 197 */     return AbstractEndpoint.Handler.SocketState.CLOSED;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void timeoutAsync(long now) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void pause() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 216 */     WebConnection connection = this.connection;
/* 217 */     if (connection != null) {
/* 218 */       this.connection = null;
/*     */       try {
/* 220 */         connection.close();
/*     */       } catch (Exception e) {
/* 222 */         this.log.error(sm.getString("wsHttpUpgradeHandler.destroyFailed"), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void onError(Throwable throwable)
/*     */   {
/* 230 */     Thread t = Thread.currentThread();
/* 231 */     ClassLoader cl = t.getContextClassLoader();
/* 232 */     t.setContextClassLoader(this.applicationClassLoader);
/*     */     try {
/* 234 */       this.ep.onError(this.wsSession, throwable);
/*     */     } finally {
/* 236 */       t.setContextClassLoader(cl);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void close(CloseReason cr)
/*     */   {
/* 250 */     this.wsSession.onClose(cr);
/*     */   }
/*     */   
/*     */   public void setSslSupport(SSLSupport sslSupport) {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\server\WsHttpUpgradeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */