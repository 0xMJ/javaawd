/*     */ package org.apache.tomcat.websocket.pojo;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.naming.NamingException;
/*     */ import javax.websocket.DecodeException;
/*     */ import javax.websocket.Decoder;
/*     */ import javax.websocket.Endpoint;
/*     */ import javax.websocket.MessageHandler.Whole;
/*     */ import javax.websocket.Session;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.WsSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PojoMessageHandlerWholeBase<T>
/*     */   extends PojoMessageHandlerBase<T>
/*     */   implements MessageHandler.Whole<T>
/*     */ {
/*  45 */   private final Log log = LogFactory.getLog(PojoMessageHandlerWholeBase.class);
/*  46 */   private static final StringManager sm = StringManager.getManager(PojoMessageHandlerWholeBase.class);
/*     */   
/*  48 */   protected final List<Decoder> decoders = new ArrayList();
/*     */   
/*     */ 
/*     */   public PojoMessageHandlerWholeBase(Object pojo, Method method, Session session, Object[] params, int indexPayload, boolean convert, int indexSession, long maxMessageSize)
/*     */   {
/*  53 */     super(pojo, method, session, params, indexPayload, convert, indexSession, maxMessageSize);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Decoder createDecoderInstance(Class<? extends Decoder> clazz)
/*     */     throws ReflectiveOperationException, NamingException
/*     */   {
/*  60 */     InstanceManager instanceManager = ((WsSession)this.session).getInstanceManager();
/*  61 */     if (instanceManager == null) {
/*  62 */       return (Decoder)clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */     }
/*  64 */     return (Decoder)instanceManager.newInstance(clazz);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void onMessage(T message)
/*     */   {
/*  72 */     if ((this.params.length == 1) && ((this.params[0] instanceof DecodeException))) {
/*  73 */       ((WsSession)this.session).getLocal().onError(this.session, (DecodeException)this.params[0]);
/*     */       
/*  75 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  81 */       payload = decode(message);
/*     */     } catch (DecodeException de) { Object payload;
/*  83 */       ((WsSession)this.session).getLocal().onError(this.session, de); return;
/*     */     }
/*     */     
/*     */     Object payload;
/*  87 */     if (payload == null)
/*     */     {
/*  89 */       if (this.convert) {
/*  90 */         payload = convert(message);
/*     */       } else {
/*  92 */         payload = message;
/*     */       }
/*     */     }
/*     */     
/*  96 */     Object[] parameters = (Object[])this.params.clone();
/*  97 */     if (this.indexSession != -1) {
/*  98 */       parameters[this.indexSession] = this.session;
/*     */     }
/* 100 */     parameters[this.indexPayload] = payload;
/*     */     
/* 102 */     Object result = null;
/*     */     try {
/* 104 */       result = this.method.invoke(this.pojo, parameters);
/*     */     } catch (IllegalAccessException|InvocationTargetException e) {
/* 106 */       handlePojoMethodException(e);
/*     */     }
/* 108 */     processResult(result);
/*     */   }
/*     */   
/*     */   protected void onClose()
/*     */   {
/* 113 */     InstanceManager instanceManager = ((WsSession)this.session).getInstanceManager();
/*     */     
/* 115 */     for (Decoder decoder : this.decoders) {
/* 116 */       decoder.destroy();
/* 117 */       if (instanceManager != null) {
/*     */         try {
/* 119 */           instanceManager.destroyInstance(decoder);
/*     */         } catch (IllegalAccessException|InvocationTargetException e) {
/* 121 */           this.log.warn(sm.getString("pojoMessageHandlerWholeBase.decodeDestoryFailed", new Object[] { decoder.getClass() }), e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object convert(T message)
/*     */   {
/* 129 */     return message;
/*     */   }
/*     */   
/*     */   protected abstract Object decode(T paramT)
/*     */     throws DecodeException;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\pojo\PojoMessageHandlerWholeBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */