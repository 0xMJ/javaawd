/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import javax.naming.NamingException;
/*    */ import javax.websocket.DeploymentException;
/*    */ import javax.websocket.Endpoint;
/*    */ import org.apache.tomcat.InstanceManager;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndpointClassHolder
/*    */   implements ClientEndpointHolder
/*    */ {
/* 28 */   private static final StringManager sm = StringManager.getManager(EndpointClassHolder.class);
/*    */   
/*    */   private final Class<? extends Endpoint> clazz;
/*    */   
/*    */   public EndpointClassHolder(Class<? extends Endpoint> clazz)
/*    */   {
/* 34 */     this.clazz = clazz;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getClassName()
/*    */   {
/* 40 */     return this.clazz.getName();
/*    */   }
/*    */   
/*    */   public Endpoint getInstance(InstanceManager instanceManager) throws DeploymentException
/*    */   {
/*    */     try
/*    */     {
/* 47 */       if (instanceManager == null) {
/* 48 */         return (Endpoint)this.clazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*    */       }
/* 50 */       return (Endpoint)instanceManager.newInstance(this.clazz);
/*    */     }
/*    */     catch (ReflectiveOperationException|NamingException e) {
/* 53 */       throw new DeploymentException(sm.getString("clientEndpointHolder.instanceCreationFailed"), e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\EndpointClassHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */