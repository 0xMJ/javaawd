/*      */ package org.apache.tomcat.websocket;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.net.SocketTimeoutException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.nio.charset.CoderResult;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Queue;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.Semaphore;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import javax.naming.NamingException;
/*      */ import javax.websocket.CloseReason;
/*      */ import javax.websocket.CloseReason.CloseCodes;
/*      */ import javax.websocket.DeploymentException;
/*      */ import javax.websocket.EncodeException;
/*      */ import javax.websocket.Encoder;
/*      */ import javax.websocket.Encoder.Binary;
/*      */ import javax.websocket.Encoder.BinaryStream;
/*      */ import javax.websocket.Encoder.Text;
/*      */ import javax.websocket.Encoder.TextStream;
/*      */ import javax.websocket.EndpointConfig;
/*      */ import javax.websocket.RemoteEndpoint;
/*      */ import javax.websocket.SendHandler;
/*      */ import javax.websocket.SendResult;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.juli.logging.LogFactory;
/*      */ import org.apache.tomcat.InstanceManager;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.Utf8Encoder;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class WsRemoteEndpointImplBase
/*      */   implements RemoteEndpoint
/*      */ {
/*   58 */   protected static final StringManager sm = StringManager.getManager(WsRemoteEndpointImplBase.class);
/*      */   
/*   60 */   protected static final SendResult SENDRESULT_OK = new SendResult();
/*      */   
/*   62 */   private final Log log = LogFactory.getLog(WsRemoteEndpointImplBase.class);
/*      */   
/*   64 */   private final StateMachine stateMachine = new StateMachine(null);
/*      */   
/*   66 */   private final IntermediateMessageHandler intermediateMessageHandler = new IntermediateMessageHandler(this);
/*      */   
/*      */ 
/*   69 */   private Transformation transformation = null;
/*   70 */   private final Semaphore messagePartInProgress = new Semaphore(1);
/*   71 */   private final Queue<MessagePart> messagePartQueue = new ArrayDeque();
/*   72 */   private final Object messagePartLock = new Object();
/*      */   
/*      */ 
/*   75 */   private volatile boolean closed = false;
/*   76 */   private boolean fragmented = false;
/*   77 */   private boolean nextFragmented = false;
/*   78 */   private boolean text = false;
/*   79 */   private boolean nextText = false;
/*      */   
/*      */ 
/*   82 */   private final ByteBuffer headerBuffer = ByteBuffer.allocate(14);
/*   83 */   private final ByteBuffer outputBuffer = ByteBuffer.allocate(Constants.DEFAULT_BUFFER_SIZE);
/*   84 */   private final CharsetEncoder encoder = new Utf8Encoder();
/*   85 */   private final ByteBuffer encoderBuffer = ByteBuffer.allocate(Constants.DEFAULT_BUFFER_SIZE);
/*   86 */   private final AtomicBoolean batchingAllowed = new AtomicBoolean(false);
/*   87 */   private volatile long sendTimeout = -1L;
/*      */   private WsSession wsSession;
/*   89 */   private List<EncoderEntry> encoderEntries = new ArrayList();
/*      */   
/*      */   protected void setTransformation(Transformation transformation)
/*      */   {
/*   93 */     this.transformation = transformation;
/*      */   }
/*      */   
/*      */   public long getSendTimeout()
/*      */   {
/*   98 */     return this.sendTimeout;
/*      */   }
/*      */   
/*      */   public void setSendTimeout(long timeout)
/*      */   {
/*  103 */     this.sendTimeout = timeout;
/*      */   }
/*      */   
/*      */   public void setBatchingAllowed(boolean batchingAllowed)
/*      */     throws IOException
/*      */   {
/*  109 */     boolean oldValue = this.batchingAllowed.getAndSet(batchingAllowed);
/*      */     
/*  111 */     if ((oldValue) && (!batchingAllowed)) {
/*  112 */       flushBatch();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean getBatchingAllowed()
/*      */   {
/*  119 */     return this.batchingAllowed.get();
/*      */   }
/*      */   
/*      */   public void flushBatch()
/*      */     throws IOException
/*      */   {
/*  125 */     sendMessageBlock((byte)24, null, true);
/*      */   }
/*      */   
/*      */   public void sendBytes(ByteBuffer data) throws IOException
/*      */   {
/*  130 */     if (data == null) {
/*  131 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.nullData"));
/*      */     }
/*  133 */     this.stateMachine.binaryStart();
/*  134 */     sendMessageBlock((byte)2, data, true);
/*  135 */     this.stateMachine.complete(true);
/*      */   }
/*      */   
/*      */   public Future<Void> sendBytesByFuture(ByteBuffer data)
/*      */   {
/*  140 */     FutureToSendHandler f2sh = new FutureToSendHandler(this.wsSession);
/*  141 */     sendBytesByCompletion(data, f2sh);
/*  142 */     return f2sh;
/*      */   }
/*      */   
/*      */   public void sendBytesByCompletion(ByteBuffer data, SendHandler handler)
/*      */   {
/*  147 */     if (data == null) {
/*  148 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.nullData"));
/*      */     }
/*  150 */     if (handler == null) {
/*  151 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.nullHandler"));
/*      */     }
/*  153 */     StateUpdateSendHandler sush = new StateUpdateSendHandler(handler, this.stateMachine);
/*  154 */     this.stateMachine.binaryStart();
/*  155 */     startMessage((byte)2, data, true, sush);
/*      */   }
/*      */   
/*      */   public void sendPartialBytes(ByteBuffer partialByte, boolean last)
/*      */     throws IOException
/*      */   {
/*  161 */     if (partialByte == null) {
/*  162 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.nullData"));
/*      */     }
/*  164 */     this.stateMachine.binaryPartialStart();
/*  165 */     sendMessageBlock((byte)2, partialByte, last);
/*  166 */     this.stateMachine.complete(last);
/*      */   }
/*      */   
/*      */ 
/*      */   public void sendPing(ByteBuffer applicationData)
/*      */     throws IOException, IllegalArgumentException
/*      */   {
/*  173 */     if (applicationData.remaining() > 125) {
/*  174 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.tooMuchData"));
/*      */     }
/*  176 */     sendMessageBlock((byte)9, applicationData, true);
/*      */   }
/*      */   
/*      */ 
/*      */   public void sendPong(ByteBuffer applicationData)
/*      */     throws IOException, IllegalArgumentException
/*      */   {
/*  183 */     if (applicationData.remaining() > 125) {
/*  184 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.tooMuchData"));
/*      */     }
/*  186 */     sendMessageBlock((byte)10, applicationData, true);
/*      */   }
/*      */   
/*      */   public void sendString(String text) throws IOException
/*      */   {
/*  191 */     if (text == null) {
/*  192 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.nullData"));
/*      */     }
/*  194 */     this.stateMachine.textStart();
/*  195 */     sendMessageBlock(CharBuffer.wrap(text), true);
/*      */   }
/*      */   
/*      */   public Future<Void> sendStringByFuture(String text)
/*      */   {
/*  200 */     FutureToSendHandler f2sh = new FutureToSendHandler(this.wsSession);
/*  201 */     sendStringByCompletion(text, f2sh);
/*  202 */     return f2sh;
/*      */   }
/*      */   
/*      */   public void sendStringByCompletion(String text, SendHandler handler)
/*      */   {
/*  207 */     if (text == null) {
/*  208 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.nullData"));
/*      */     }
/*  210 */     if (handler == null) {
/*  211 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.nullHandler"));
/*      */     }
/*  213 */     this.stateMachine.textStart();
/*      */     
/*  215 */     TextMessageSendHandler tmsh = new TextMessageSendHandler(handler, CharBuffer.wrap(text), true, this.encoder, this.encoderBuffer, this);
/*  216 */     tmsh.write();
/*      */   }
/*      */   
/*      */ 
/*      */   public void sendPartialString(String fragment, boolean isLast)
/*      */     throws IOException
/*      */   {
/*  223 */     if (fragment == null) {
/*  224 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.nullData"));
/*      */     }
/*  226 */     this.stateMachine.textPartialStart();
/*  227 */     sendMessageBlock(CharBuffer.wrap(fragment), isLast);
/*      */   }
/*      */   
/*      */   public OutputStream getSendStream()
/*      */   {
/*  232 */     this.stateMachine.streamStart();
/*  233 */     return new WsOutputStream(this);
/*      */   }
/*      */   
/*      */   public Writer getSendWriter()
/*      */   {
/*  238 */     this.stateMachine.writeStart();
/*  239 */     return new WsWriter(this);
/*      */   }
/*      */   
/*      */   void sendMessageBlock(CharBuffer part, boolean last) throws IOException
/*      */   {
/*  244 */     long timeoutExpiry = getTimeoutExpiry();
/*  245 */     boolean isDone = false;
/*  246 */     while (!isDone) {
/*  247 */       this.encoderBuffer.clear();
/*  248 */       CoderResult cr = this.encoder.encode(part, this.encoderBuffer, true);
/*  249 */       if (cr.isError()) {
/*  250 */         throw new IllegalArgumentException(cr.toString());
/*      */       }
/*  252 */       isDone = !cr.isOverflow();
/*  253 */       this.encoderBuffer.flip();
/*  254 */       sendMessageBlock((byte)1, this.encoderBuffer, (last) && (isDone), timeoutExpiry);
/*      */     }
/*  256 */     this.stateMachine.complete(last);
/*      */   }
/*      */   
/*      */   void sendMessageBlock(byte opCode, ByteBuffer payload, boolean last)
/*      */     throws IOException
/*      */   {
/*  262 */     sendMessageBlock(opCode, payload, last, getTimeoutExpiry());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private long getTimeoutExpiry()
/*      */   {
/*  270 */     long timeout = getBlockingSendTimeout();
/*  271 */     if (timeout < 0L) {
/*  272 */       return Long.MAX_VALUE;
/*      */     }
/*  274 */     return System.currentTimeMillis() + timeout;
/*      */   }
/*      */   
/*      */ 
/*      */   private void sendMessageBlock(byte opCode, ByteBuffer payload, boolean last, long timeoutExpiry)
/*      */     throws IOException
/*      */   {
/*  281 */     this.wsSession.updateLastActiveWrite();
/*      */     
/*  283 */     BlockingSendHandler bsh = new BlockingSendHandler(null);
/*      */     
/*  285 */     List<MessagePart> messageParts = new ArrayList();
/*  286 */     messageParts.add(new MessagePart(last, 0, opCode, payload, bsh, bsh, timeoutExpiry));
/*      */     
/*  288 */     messageParts = this.transformation.sendMessagePart(messageParts);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  293 */     if (messageParts.size() == 0) {
/*  294 */       return;
/*      */     }
/*      */     
/*  297 */     long timeout = timeoutExpiry - System.currentTimeMillis();
/*      */     try {
/*  299 */       if (!this.messagePartInProgress.tryAcquire(timeout, TimeUnit.MILLISECONDS)) {
/*  300 */         String msg = sm.getString("wsRemoteEndpoint.acquireTimeout");
/*  301 */         this.wsSession.doClose(new CloseReason(CloseReason.CloseCodes.GOING_AWAY, msg), new CloseReason(CloseReason.CloseCodes.CLOSED_ABNORMALLY, msg), true);
/*      */         
/*  303 */         throw new SocketTimeoutException(msg);
/*      */       }
/*      */     } catch (InterruptedException e) {
/*  306 */       String msg = sm.getString("wsRemoteEndpoint.sendInterrupt");
/*  307 */       this.wsSession.doClose(new CloseReason(CloseReason.CloseCodes.GOING_AWAY, msg), new CloseReason(CloseReason.CloseCodes.CLOSED_ABNORMALLY, msg), true);
/*      */       
/*  309 */       throw new IOException(msg, e);
/*      */     }
/*      */     
/*  312 */     for (MessagePart mp : messageParts) {
/*      */       try {
/*  314 */         writeMessagePart(mp);
/*      */       } catch (Throwable t) {
/*  316 */         ExceptionUtils.handleThrowable(t);
/*  317 */         this.messagePartInProgress.release();
/*  318 */         this.wsSession.doClose(new CloseReason(CloseReason.CloseCodes.GOING_AWAY, t.getMessage()), new CloseReason(CloseReason.CloseCodes.CLOSED_ABNORMALLY, t
/*  319 */           .getMessage()), true);
/*  320 */         throw t;
/*      */       }
/*  322 */       if (!bsh.getSendResult().isOK()) {
/*  323 */         this.messagePartInProgress.release();
/*  324 */         Throwable t = bsh.getSendResult().getException();
/*  325 */         this.wsSession.doClose(new CloseReason(CloseReason.CloseCodes.GOING_AWAY, t.getMessage()), new CloseReason(CloseReason.CloseCodes.CLOSED_ABNORMALLY, t
/*  326 */           .getMessage()), true);
/*  327 */         throw new IOException(t);
/*      */       }
/*      */       
/*      */ 
/*  331 */       this.fragmented = this.nextFragmented;
/*  332 */       this.text = this.nextText;
/*      */     }
/*      */     
/*  335 */     if (payload != null) {
/*  336 */       payload.clear();
/*      */     }
/*      */     
/*  339 */     endMessage(null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void startMessage(byte opCode, ByteBuffer payload, boolean last, SendHandler handler)
/*      */   {
/*  346 */     this.wsSession.updateLastActiveWrite();
/*      */     
/*  348 */     List<MessagePart> messageParts = new ArrayList();
/*  349 */     messageParts.add(new MessagePart(last, 0, opCode, payload, this.intermediateMessageHandler, new EndMessageHandler(this, handler), -1L));
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  354 */       messageParts = this.transformation.sendMessagePart(messageParts);
/*      */     } catch (IOException ioe) {
/*  356 */       handler.onResult(new SendResult(ioe));
/*  357 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  363 */     if (messageParts.size() == 0) {
/*  364 */       handler.onResult(new SendResult());
/*  365 */       return;
/*      */     }
/*      */     
/*  368 */     MessagePart mp = (MessagePart)messageParts.remove(0);
/*      */     
/*  370 */     boolean doWrite = false;
/*  371 */     synchronized (this.messagePartLock) {
/*  372 */       if ((8 == mp.getOpCode()) && (getBatchingAllowed()))
/*      */       {
/*      */ 
/*  375 */         this.log.warn(sm.getString("wsRemoteEndpoint.flushOnCloseFailed"));
/*      */       }
/*  377 */       if (this.messagePartInProgress.tryAcquire()) {
/*  378 */         doWrite = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  389 */         this.messagePartQueue.add(mp);
/*      */       }
/*      */       
/*  392 */       this.messagePartQueue.addAll(messageParts);
/*      */     }
/*  394 */     if (doWrite)
/*      */     {
/*      */ 
/*      */ 
/*  398 */       writeMessagePart(mp);
/*      */     }
/*      */   }
/*      */   
/*      */   void endMessage(SendHandler handler, SendResult result)
/*      */   {
/*  404 */     boolean doWrite = false;
/*  405 */     MessagePart mpNext = null;
/*  406 */     synchronized (this.messagePartLock)
/*      */     {
/*  408 */       this.fragmented = this.nextFragmented;
/*  409 */       this.text = this.nextText;
/*      */       
/*  411 */       mpNext = (MessagePart)this.messagePartQueue.poll();
/*  412 */       if (mpNext == null) {
/*  413 */         this.messagePartInProgress.release();
/*  414 */       } else if (!this.closed)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  419 */         doWrite = true;
/*      */       }
/*      */     }
/*  422 */     if (doWrite)
/*      */     {
/*      */ 
/*      */ 
/*  426 */       writeMessagePart(mpNext);
/*      */     }
/*      */     
/*  429 */     this.wsSession.updateLastActiveWrite();
/*      */     
/*      */ 
/*      */ 
/*  433 */     if (handler != null) {
/*  434 */       handler.onResult(result);
/*      */     }
/*      */   }
/*      */   
/*      */   void writeMessagePart(MessagePart mp)
/*      */   {
/*  440 */     if (this.closed)
/*      */     {
/*  442 */       throw new IllegalStateException(sm.getString("wsRemoteEndpoint.closed"));
/*      */     }
/*      */     
/*  445 */     if (24 == mp.getOpCode()) {
/*  446 */       this.nextFragmented = this.fragmented;
/*  447 */       this.nextText = this.text;
/*  448 */       this.outputBuffer.flip();
/*      */       
/*  450 */       SendHandler flushHandler = new OutputBufferFlushSendHandler(this.outputBuffer, mp.getEndHandler());
/*  451 */       doWrite(flushHandler, mp.getBlockingWriteTimeoutExpiry(), new ByteBuffer[] { this.outputBuffer }); return;
/*      */     }
/*      */     
/*      */     boolean first;
/*      */     
/*      */     boolean first;
/*      */     
/*  458 */     if (Util.isControl(mp.getOpCode())) {
/*  459 */       this.nextFragmented = this.fragmented;
/*  460 */       this.nextText = this.text;
/*  461 */       if (mp.getOpCode() == 8) {
/*  462 */         this.closed = true;
/*      */       }
/*  464 */       first = true;
/*      */     } else {
/*  466 */       boolean isText = Util.isText(mp.getOpCode());
/*      */       boolean first;
/*  468 */       if (this.fragmented)
/*      */       {
/*  470 */         if (this.text != isText)
/*      */         {
/*  472 */           throw new IllegalStateException(sm.getString("wsRemoteEndpoint.changeType"));
/*      */         }
/*  474 */         this.nextText = this.text;
/*  475 */         this.nextFragmented = (!mp.isFin());
/*  476 */         first = false;
/*      */       }
/*      */       else {
/*  479 */         if (mp.isFin()) {
/*  480 */           this.nextFragmented = false;
/*      */         } else {
/*  482 */           this.nextFragmented = true;
/*  483 */           this.nextText = isText;
/*      */         }
/*  485 */         first = true;
/*      */       }
/*      */     }
/*      */     
/*      */     byte[] mask;
/*      */     byte[] mask;
/*  491 */     if (isMasked()) {
/*  492 */       mask = Util.generateMask();
/*      */     } else {
/*  494 */       mask = null;
/*      */     }
/*      */     
/*  497 */     int payloadSize = mp.getPayload().remaining();
/*  498 */     this.headerBuffer.clear();
/*  499 */     writeHeader(this.headerBuffer, mp.isFin(), mp.getRsv(), mp.getOpCode(), 
/*  500 */       isMasked(), mp.getPayload(), mask, first);
/*  501 */     this.headerBuffer.flip();
/*      */     
/*  503 */     if ((getBatchingAllowed()) || (isMasked()))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  508 */       OutputBufferSendHandler obsh = new OutputBufferSendHandler(mp.getEndHandler(), mp.getBlockingWriteTimeoutExpiry(), this.headerBuffer, mp.getPayload(), mask, this.outputBuffer, !getBatchingAllowed(), this);
/*  509 */       obsh.write();
/*      */     }
/*      */     else {
/*  512 */       doWrite(mp.getEndHandler(), mp.getBlockingWriteTimeoutExpiry(), new ByteBuffer[] { this.headerBuffer, mp
/*  513 */         .getPayload() });
/*      */     }
/*      */     
/*  516 */     updateStats(payloadSize);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void updateStats(long payloadLength) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private long getBlockingSendTimeout()
/*      */   {
/*  533 */     Object obj = this.wsSession.getUserProperties().get("org.apache.tomcat.websocket.BLOCKING_SEND_TIMEOUT");
/*  534 */     Long userTimeout = null;
/*  535 */     if ((obj instanceof Long)) {
/*  536 */       userTimeout = (Long)obj;
/*      */     }
/*  538 */     if (userTimeout == null) {
/*  539 */       return 20000L;
/*      */     }
/*  541 */     return userTimeout.longValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class EndMessageHandler
/*      */     implements SendHandler
/*      */   {
/*      */     private final WsRemoteEndpointImplBase endpoint;
/*      */     
/*      */ 
/*      */     private final SendHandler handler;
/*      */     
/*      */ 
/*      */     public EndMessageHandler(WsRemoteEndpointImplBase endpoint, SendHandler handler)
/*      */     {
/*  557 */       this.endpoint = endpoint;
/*  558 */       this.handler = handler;
/*      */     }
/*      */     
/*      */ 
/*      */     public void onResult(SendResult result)
/*      */     {
/*  564 */       this.endpoint.endMessage(this.handler, result);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class IntermediateMessageHandler
/*      */     implements SendHandler
/*      */   {
/*      */     private final WsRemoteEndpointImplBase endpoint;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public IntermediateMessageHandler(WsRemoteEndpointImplBase endpoint)
/*      */     {
/*  583 */       this.endpoint = endpoint;
/*      */     }
/*      */     
/*      */ 
/*      */     public void onResult(SendResult result)
/*      */     {
/*  589 */       this.endpoint.endMessage(null, result);
/*      */     }
/*      */   }
/*      */   
/*      */   public void sendObject(Object obj)
/*      */     throws IOException, EncodeException
/*      */   {
/*  596 */     if (obj == null) {
/*  597 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.nullData"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  604 */     Encoder encoder = findEncoder(obj);
/*  605 */     if ((encoder == null) && (Util.isPrimitive(obj.getClass()))) {
/*  606 */       String msg = obj.toString();
/*  607 */       sendString(msg);
/*  608 */       return;
/*      */     }
/*  610 */     if ((encoder == null) && (byte[].class.isAssignableFrom(obj.getClass()))) {
/*  611 */       ByteBuffer msg = ByteBuffer.wrap((byte[])obj);
/*  612 */       sendBytes(msg);
/*  613 */       return;
/*      */     }
/*      */     
/*  616 */     if ((encoder instanceof Encoder.Text)) {
/*  617 */       String msg = ((Encoder.Text)encoder).encode(obj);
/*  618 */       sendString(msg); } else { Throwable localThrowable6;
/*  619 */       if ((encoder instanceof Encoder.TextStream)) {
/*  620 */         Writer w = getSendWriter();localThrowable6 = null;
/*  621 */         try { ((Encoder.TextStream)encoder).encode(obj, w);
/*      */         }
/*      */         catch (Throwable localThrowable1)
/*      */         {
/*  620 */           localThrowable6 = localThrowable1;throw localThrowable1;
/*      */         } finally {
/*  622 */           if (w != null) if (localThrowable6 != null) try { w.close(); } catch (Throwable localThrowable2) { localThrowable6.addSuppressed(localThrowable2); } else w.close();
/*  623 */         } } else if ((encoder instanceof Encoder.Binary)) {
/*  624 */         ByteBuffer msg = ((Encoder.Binary)encoder).encode(obj);
/*  625 */         sendBytes(msg);
/*  626 */       } else if ((encoder instanceof Encoder.BinaryStream)) {
/*  627 */         OutputStream os = getSendStream();localThrowable6 = null;
/*  628 */         try { ((Encoder.BinaryStream)encoder).encode(obj, os);
/*      */         }
/*      */         catch (Throwable localThrowable4)
/*      */         {
/*  627 */           localThrowable6 = localThrowable4;throw localThrowable4;
/*      */         } finally {
/*  629 */           if (os != null) if (localThrowable6 != null) try { os.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else os.close();
/*      */         }
/*  631 */       } else { throw new EncodeException(obj, sm.getString("wsRemoteEndpoint.noEncoder", new Object[] {obj
/*  632 */           .getClass() }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public Future<Void> sendObjectByFuture(Object obj) {
/*  638 */     FutureToSendHandler f2sh = new FutureToSendHandler(this.wsSession);
/*  639 */     sendObjectByCompletion(obj, f2sh);
/*  640 */     return f2sh;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void sendObjectByCompletion(Object obj, SendHandler completion)
/*      */   {
/*  647 */     if (obj == null) {
/*  648 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.nullData"));
/*      */     }
/*  650 */     if (completion == null) {
/*  651 */       throw new IllegalArgumentException(sm.getString("wsRemoteEndpoint.nullHandler"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  659 */     Encoder encoder = findEncoder(obj);
/*  660 */     if ((encoder == null) && (Util.isPrimitive(obj.getClass()))) {
/*  661 */       String msg = obj.toString();
/*  662 */       sendStringByCompletion(msg, completion);
/*  663 */       return;
/*      */     }
/*  665 */     if ((encoder == null) && (byte[].class.isAssignableFrom(obj.getClass()))) {
/*  666 */       ByteBuffer msg = ByteBuffer.wrap((byte[])obj);
/*  667 */       sendBytesByCompletion(msg, completion);
/*  668 */       return;
/*      */     }
/*      */     try
/*      */     {
/*  672 */       if ((encoder instanceof Encoder.Text)) {
/*  673 */         String msg = ((Encoder.Text)encoder).encode(obj);
/*  674 */         sendStringByCompletion(msg, completion); } else { Throwable localThrowable6;
/*  675 */         if ((encoder instanceof Encoder.TextStream)) {
/*  676 */           Writer w = getSendWriter();localThrowable6 = null;
/*  677 */           try { ((Encoder.TextStream)encoder).encode(obj, w);
/*      */           }
/*      */           catch (Throwable localThrowable1)
/*      */           {
/*  676 */             localThrowable6 = localThrowable1;throw localThrowable1;
/*      */           } finally {
/*  678 */             if (w != null) if (localThrowable6 != null) try { w.close(); } catch (Throwable localThrowable2) { localThrowable6.addSuppressed(localThrowable2); } else w.close(); }
/*  679 */           completion.onResult(new SendResult());
/*  680 */         } else if ((encoder instanceof Encoder.Binary)) {
/*  681 */           ByteBuffer msg = ((Encoder.Binary)encoder).encode(obj);
/*  682 */           sendBytesByCompletion(msg, completion);
/*  683 */         } else if ((encoder instanceof Encoder.BinaryStream)) {
/*  684 */           OutputStream os = getSendStream();localThrowable6 = null;
/*  685 */           try { ((Encoder.BinaryStream)encoder).encode(obj, os);
/*      */           }
/*      */           catch (Throwable localThrowable4)
/*      */           {
/*  684 */             localThrowable6 = localThrowable4;throw localThrowable4;
/*      */           } finally {
/*  686 */             if (os != null) if (localThrowable6 != null) try { os.close(); } catch (Throwable localThrowable5) { localThrowable6.addSuppressed(localThrowable5); } else os.close(); }
/*  687 */           completion.onResult(new SendResult());
/*      */         } else {
/*  689 */           throw new EncodeException(obj, sm.getString("wsRemoteEndpoint.noEncoder", new Object[] {obj
/*  690 */             .getClass() }));
/*      */         }
/*      */       }
/*  693 */     } catch (Exception e) { SendResult sr = new SendResult(e);
/*  694 */       completion.onResult(sr);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setSession(WsSession wsSession)
/*      */   {
/*  700 */     this.wsSession = wsSession;
/*      */   }
/*      */   
/*      */   protected void setEncoders(EndpointConfig endpointConfig)
/*      */     throws DeploymentException
/*      */   {
/*  706 */     this.encoderEntries.clear();
/*      */     
/*  708 */     for (Class<? extends Encoder> encoderClazz : endpointConfig.getEncoders())
/*      */     {
/*  710 */       InstanceManager instanceManager = this.wsSession.getInstanceManager();
/*      */       try { Encoder instance;
/*  712 */         Encoder instance; if (instanceManager == null) {
/*  713 */           instance = (Encoder)encoderClazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */         } else {
/*  715 */           instance = (Encoder)instanceManager.newInstance(encoderClazz);
/*      */         }
/*  717 */         instance.init(endpointConfig);
/*      */       }
/*      */       catch (ReflectiveOperationException|NamingException e) {
/*  720 */         throw new DeploymentException(sm.getString("wsRemoteEndpoint.invalidEncoder", new Object[] {encoderClazz
/*  721 */           .getName() }), e);
/*      */       }
/*      */       Encoder instance;
/*  724 */       EncoderEntry entry = new EncoderEntry(Util.getEncoderType(encoderClazz), instance);
/*  725 */       this.encoderEntries.add(entry);
/*      */     }
/*      */   }
/*      */   
/*      */   private Encoder findEncoder(Object obj)
/*      */   {
/*  731 */     for (EncoderEntry entry : this.encoderEntries) {
/*  732 */       if (entry.getClazz().isAssignableFrom(obj.getClass())) {
/*  733 */         return entry.getEncoder();
/*      */       }
/*      */     }
/*  736 */     return null;
/*      */   }
/*      */   
/*      */   public final void close()
/*      */   {
/*  741 */     InstanceManager instanceManager = this.wsSession.getInstanceManager();
/*  742 */     for (EncoderEntry entry : this.encoderEntries) {
/*  743 */       entry.getEncoder().destroy();
/*  744 */       if (instanceManager != null) {
/*      */         try {
/*  746 */           instanceManager.destroyInstance(entry);
/*      */         } catch (IllegalAccessException|InvocationTargetException e) {
/*  748 */           this.log.warn(sm.getString("wsRemoteEndpoint.encoderDestoryFailed", new Object[] { this.encoder.getClass() }), e);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  754 */     this.transformation.close();
/*  755 */     doClose();
/*      */   }
/*      */   
/*      */ 
/*      */   protected abstract void doWrite(SendHandler paramSendHandler, long paramLong, ByteBuffer... paramVarArgs);
/*      */   
/*      */ 
/*      */   protected abstract boolean isMasked();
/*      */   
/*      */   protected abstract void doClose();
/*      */   
/*      */   private static void writeHeader(ByteBuffer headerBuffer, boolean fin, int rsv, byte opCode, boolean masked, ByteBuffer payload, byte[] mask, boolean first)
/*      */   {
/*  768 */     byte b = 0;
/*      */     
/*  770 */     if (fin)
/*      */     {
/*  772 */       b = (byte)(b - 128);
/*      */     }
/*      */     
/*  775 */     b = (byte)(b + (rsv << 4));
/*      */     
/*  777 */     if (first)
/*      */     {
/*  779 */       b = (byte)(b + opCode);
/*      */     }
/*      */     
/*      */ 
/*  783 */     headerBuffer.put(b);
/*      */     
/*  785 */     if (masked) {
/*  786 */       b = Byte.MIN_VALUE;
/*      */     } else {
/*  788 */       b = 0;
/*      */     }
/*      */     
/*      */ 
/*  792 */     if (payload.remaining() < 126) {
/*  793 */       headerBuffer.put((byte)(payload.remaining() | b));
/*  794 */     } else if (payload.remaining() < 65536) {
/*  795 */       headerBuffer.put((byte)(0x7E | b));
/*  796 */       headerBuffer.put((byte)(payload.remaining() >>> 8));
/*  797 */       headerBuffer.put((byte)(payload.remaining() & 0xFF));
/*      */     }
/*      */     else {
/*  800 */       headerBuffer.put((byte)(0x7F | b));
/*  801 */       headerBuffer.put((byte)0);
/*  802 */       headerBuffer.put((byte)0);
/*  803 */       headerBuffer.put((byte)0);
/*  804 */       headerBuffer.put((byte)0);
/*  805 */       headerBuffer.put((byte)(payload.remaining() >>> 24));
/*  806 */       headerBuffer.put((byte)(payload.remaining() >>> 16));
/*  807 */       headerBuffer.put((byte)(payload.remaining() >>> 8));
/*  808 */       headerBuffer.put((byte)(payload.remaining() & 0xFF));
/*      */     }
/*  810 */     if (masked) {
/*  811 */       headerBuffer.put(mask[0]);
/*  812 */       headerBuffer.put(mask[1]);
/*  813 */       headerBuffer.put(mask[2]);
/*  814 */       headerBuffer.put(mask[3]);
/*      */     }
/*      */   }
/*      */   
/*      */   private class TextMessageSendHandler
/*      */     implements SendHandler
/*      */   {
/*      */     private final SendHandler handler;
/*      */     private final CharBuffer message;
/*      */     private final boolean isLast;
/*      */     private final CharsetEncoder encoder;
/*      */     private final ByteBuffer buffer;
/*      */     private final WsRemoteEndpointImplBase endpoint;
/*  827 */     private volatile boolean isDone = false;
/*      */     
/*      */ 
/*      */     public TextMessageSendHandler(SendHandler handler, CharBuffer message, boolean isLast, CharsetEncoder encoder, ByteBuffer encoderBuffer, WsRemoteEndpointImplBase endpoint)
/*      */     {
/*  832 */       this.handler = handler;
/*  833 */       this.message = message;
/*  834 */       this.isLast = isLast;
/*  835 */       this.encoder = encoder.reset();
/*  836 */       this.buffer = encoderBuffer;
/*  837 */       this.endpoint = endpoint;
/*      */     }
/*      */     
/*      */     public void write() {
/*  841 */       this.buffer.clear();
/*  842 */       CoderResult cr = this.encoder.encode(this.message, this.buffer, true);
/*  843 */       if (cr.isError()) {
/*  844 */         throw new IllegalArgumentException(cr.toString());
/*      */       }
/*  846 */       this.isDone = (!cr.isOverflow());
/*  847 */       this.buffer.flip();
/*  848 */       this.endpoint.startMessage((byte)1, this.buffer, (this.isDone) && (this.isLast), this);
/*      */     }
/*      */     
/*      */ 
/*      */     public void onResult(SendResult result)
/*      */     {
/*  854 */       if (this.isDone) {
/*  855 */         this.endpoint.stateMachine.complete(this.isLast);
/*  856 */         this.handler.onResult(result);
/*  857 */       } else if (!result.isOK()) {
/*  858 */         this.handler.onResult(result);
/*  859 */       } else if (WsRemoteEndpointImplBase.this.closed)
/*      */       {
/*  861 */         SendResult sr = new SendResult(new IOException(WsRemoteEndpointImplBase.sm.getString("wsRemoteEndpoint.closedDuringMessage")));
/*  862 */         this.handler.onResult(sr);
/*      */       } else {
/*  864 */         write();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class OutputBufferSendHandler
/*      */     implements SendHandler
/*      */   {
/*      */     private final SendHandler handler;
/*      */     
/*      */     private final long blockingWriteTimeoutExpiry;
/*      */     
/*      */     private final ByteBuffer headerBuffer;
/*      */     
/*      */     private final ByteBuffer payload;
/*      */     private final byte[] mask;
/*      */     private final ByteBuffer outputBuffer;
/*      */     private final boolean flushRequired;
/*      */     private final WsRemoteEndpointImplBase endpoint;
/*  884 */     private volatile int maskIndex = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public OutputBufferSendHandler(SendHandler completion, long blockingWriteTimeoutExpiry, ByteBuffer headerBuffer, ByteBuffer payload, byte[] mask, ByteBuffer outputBuffer, boolean flushRequired, WsRemoteEndpointImplBase endpoint)
/*      */     {
/*  891 */       this.blockingWriteTimeoutExpiry = blockingWriteTimeoutExpiry;
/*  892 */       this.handler = completion;
/*  893 */       this.headerBuffer = headerBuffer;
/*  894 */       this.payload = payload;
/*  895 */       this.mask = mask;
/*  896 */       this.outputBuffer = outputBuffer;
/*  897 */       this.flushRequired = flushRequired;
/*  898 */       this.endpoint = endpoint;
/*      */     }
/*      */     
/*      */     public void write()
/*      */     {
/*  903 */       while ((this.headerBuffer.hasRemaining()) && (this.outputBuffer.hasRemaining())) {
/*  904 */         this.outputBuffer.put(this.headerBuffer.get());
/*      */       }
/*  906 */       if (this.headerBuffer.hasRemaining())
/*      */       {
/*  908 */         this.outputBuffer.flip();
/*  909 */         this.endpoint.doWrite(this, this.blockingWriteTimeoutExpiry, new ByteBuffer[] { this.outputBuffer });
/*  910 */         return;
/*      */       }
/*      */       
/*      */ 
/*  914 */       int payloadLeft = this.payload.remaining();
/*  915 */       int payloadLimit = this.payload.limit();
/*  916 */       int outputSpace = this.outputBuffer.remaining();
/*  917 */       int toWrite = payloadLeft;
/*      */       
/*  919 */       if (payloadLeft > outputSpace) {
/*  920 */         toWrite = outputSpace;
/*      */         
/*  922 */         this.payload.limit(this.payload.position() + toWrite);
/*      */       }
/*      */       
/*  925 */       if (this.mask == null)
/*      */       {
/*  927 */         this.outputBuffer.put(this.payload);
/*      */       } else {
/*  929 */         for (int i = 0; i < toWrite; i++) {
/*  930 */           this.outputBuffer.put(
/*  931 */             (byte)(this.payload.get() ^ this.mask[(this.maskIndex++)] & 0xFF));
/*  932 */           if (this.maskIndex > 3) {
/*  933 */             this.maskIndex = 0;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  938 */       if (payloadLeft > outputSpace)
/*      */       {
/*  940 */         this.payload.limit(payloadLimit);
/*      */         
/*  942 */         this.outputBuffer.flip();
/*  943 */         this.endpoint.doWrite(this, this.blockingWriteTimeoutExpiry, new ByteBuffer[] { this.outputBuffer });
/*  944 */         return;
/*      */       }
/*      */       
/*  947 */       if (this.flushRequired) {
/*  948 */         this.outputBuffer.flip();
/*  949 */         if (this.outputBuffer.remaining() == 0) {
/*  950 */           this.handler.onResult(WsRemoteEndpointImplBase.SENDRESULT_OK);
/*      */         } else {
/*  952 */           this.endpoint.doWrite(this, this.blockingWriteTimeoutExpiry, new ByteBuffer[] { this.outputBuffer });
/*      */         }
/*      */       } else {
/*  955 */         this.handler.onResult(WsRemoteEndpointImplBase.SENDRESULT_OK);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void onResult(SendResult result)
/*      */     {
/*  962 */       if (result.isOK()) {
/*  963 */         if (this.outputBuffer.hasRemaining()) {
/*  964 */           this.endpoint.doWrite(this, this.blockingWriteTimeoutExpiry, new ByteBuffer[] { this.outputBuffer });
/*      */         } else {
/*  966 */           this.outputBuffer.clear();
/*  967 */           write();
/*      */         }
/*      */       } else {
/*  970 */         this.handler.onResult(result);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class OutputBufferFlushSendHandler
/*      */     implements SendHandler
/*      */   {
/*      */     private final ByteBuffer outputBuffer;
/*      */     
/*      */     private final SendHandler handler;
/*      */     
/*      */     public OutputBufferFlushSendHandler(ByteBuffer outputBuffer, SendHandler handler)
/*      */     {
/*  985 */       this.outputBuffer = outputBuffer;
/*  986 */       this.handler = handler;
/*      */     }
/*      */     
/*      */     public void onResult(SendResult result)
/*      */     {
/*  991 */       if (result.isOK()) {
/*  992 */         this.outputBuffer.clear();
/*      */       }
/*  994 */       this.handler.onResult(result);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class WsOutputStream
/*      */     extends OutputStream
/*      */   {
/*      */     private final WsRemoteEndpointImplBase endpoint;
/* 1002 */     private final ByteBuffer buffer = ByteBuffer.allocate(Constants.DEFAULT_BUFFER_SIZE);
/* 1003 */     private final Object closeLock = new Object();
/* 1004 */     private volatile boolean closed = false;
/* 1005 */     private volatile boolean used = false;
/*      */     
/*      */     public WsOutputStream(WsRemoteEndpointImplBase endpoint) {
/* 1008 */       this.endpoint = endpoint;
/*      */     }
/*      */     
/*      */     public void write(int b) throws IOException
/*      */     {
/* 1013 */       if (this.closed)
/*      */       {
/* 1015 */         throw new IllegalStateException(WsRemoteEndpointImplBase.sm.getString("wsRemoteEndpoint.closedOutputStream"));
/*      */       }
/*      */       
/* 1018 */       this.used = true;
/* 1019 */       if (this.buffer.remaining() == 0) {
/* 1020 */         flush();
/*      */       }
/* 1022 */       this.buffer.put((byte)b);
/*      */     }
/*      */     
/*      */     public void write(byte[] b, int off, int len) throws IOException
/*      */     {
/* 1027 */       if (this.closed)
/*      */       {
/* 1029 */         throw new IllegalStateException(WsRemoteEndpointImplBase.sm.getString("wsRemoteEndpoint.closedOutputStream"));
/*      */       }
/* 1031 */       if ((off < 0) || (off > b.length) || (len < 0) || (off + len > b.length) || (off + len < 0))
/*      */       {
/* 1033 */         throw new IndexOutOfBoundsException();
/*      */       }
/*      */       
/* 1036 */       this.used = true;
/*      */       
/* 1038 */       if (len == 0) {
/* 1039 */         return;
/*      */       }
/*      */       
/* 1042 */       if (this.buffer.remaining() == 0) {
/* 1043 */         flush();
/*      */       }
/* 1045 */       int remaining = this.buffer.remaining();
/* 1046 */       int written = 0;
/*      */       
/* 1048 */       while (remaining < len - written) {
/* 1049 */         this.buffer.put(b, off + written, remaining);
/* 1050 */         written += remaining;
/* 1051 */         flush();
/* 1052 */         remaining = this.buffer.remaining();
/*      */       }
/* 1054 */       this.buffer.put(b, off + written, len - written);
/*      */     }
/*      */     
/*      */     public void flush() throws IOException
/*      */     {
/* 1059 */       if (this.closed)
/*      */       {
/* 1061 */         throw new IllegalStateException(WsRemoteEndpointImplBase.sm.getString("wsRemoteEndpoint.closedOutputStream"));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1066 */       if (this.buffer.position() > 0) {
/* 1067 */         doWrite(false);
/*      */       }
/*      */     }
/*      */     
/*      */     public void close() throws IOException
/*      */     {
/* 1073 */       synchronized (this.closeLock) {
/* 1074 */         if (this.closed) {
/* 1075 */           return;
/*      */         }
/* 1077 */         this.closed = true;
/*      */       }
/*      */       
/* 1080 */       doWrite(true);
/*      */     }
/*      */     
/*      */     private void doWrite(boolean last) throws IOException {
/* 1084 */       if (this.used) {
/* 1085 */         this.buffer.flip();
/* 1086 */         this.endpoint.sendMessageBlock((byte)2, this.buffer, last);
/*      */       }
/* 1088 */       this.endpoint.stateMachine.complete(last);
/* 1089 */       this.buffer.clear();
/*      */     }
/*      */   }
/*      */   
/*      */   private static class WsWriter
/*      */     extends Writer
/*      */   {
/*      */     private final WsRemoteEndpointImplBase endpoint;
/* 1097 */     private final CharBuffer buffer = CharBuffer.allocate(Constants.DEFAULT_BUFFER_SIZE);
/* 1098 */     private final Object closeLock = new Object();
/* 1099 */     private volatile boolean closed = false;
/* 1100 */     private volatile boolean used = false;
/*      */     
/*      */     public WsWriter(WsRemoteEndpointImplBase endpoint) {
/* 1103 */       this.endpoint = endpoint;
/*      */     }
/*      */     
/*      */     public void write(char[] cbuf, int off, int len) throws IOException
/*      */     {
/* 1108 */       if (this.closed)
/*      */       {
/* 1110 */         throw new IllegalStateException(WsRemoteEndpointImplBase.sm.getString("wsRemoteEndpoint.closedWriter"));
/*      */       }
/* 1112 */       if ((off < 0) || (off > cbuf.length) || (len < 0) || (off + len > cbuf.length) || (off + len < 0))
/*      */       {
/* 1114 */         throw new IndexOutOfBoundsException();
/*      */       }
/*      */       
/* 1117 */       this.used = true;
/*      */       
/* 1119 */       if (len == 0) {
/* 1120 */         return;
/*      */       }
/*      */       
/* 1123 */       if (this.buffer.remaining() == 0) {
/* 1124 */         flush();
/*      */       }
/* 1126 */       int remaining = this.buffer.remaining();
/* 1127 */       int written = 0;
/*      */       
/* 1129 */       while (remaining < len - written) {
/* 1130 */         this.buffer.put(cbuf, off + written, remaining);
/* 1131 */         written += remaining;
/* 1132 */         flush();
/* 1133 */         remaining = this.buffer.remaining();
/*      */       }
/* 1135 */       this.buffer.put(cbuf, off + written, len - written);
/*      */     }
/*      */     
/*      */     public void flush() throws IOException
/*      */     {
/* 1140 */       if (this.closed)
/*      */       {
/* 1142 */         throw new IllegalStateException(WsRemoteEndpointImplBase.sm.getString("wsRemoteEndpoint.closedWriter"));
/*      */       }
/*      */       
/* 1145 */       if (this.buffer.position() > 0) {
/* 1146 */         doWrite(false);
/*      */       }
/*      */     }
/*      */     
/*      */     public void close() throws IOException
/*      */     {
/* 1152 */       synchronized (this.closeLock) {
/* 1153 */         if (this.closed) {
/* 1154 */           return;
/*      */         }
/* 1156 */         this.closed = true;
/*      */       }
/*      */       
/* 1159 */       doWrite(true);
/*      */     }
/*      */     
/*      */     private void doWrite(boolean last) throws IOException {
/* 1163 */       if (this.used) {
/* 1164 */         this.buffer.flip();
/* 1165 */         this.endpoint.sendMessageBlock(this.buffer, last);
/* 1166 */         this.buffer.clear();
/*      */       } else {
/* 1168 */         this.endpoint.stateMachine.complete(last);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static class EncoderEntry
/*      */   {
/*      */     private final Class<?> clazz;
/*      */     private final Encoder encoder;
/*      */     
/*      */     public EncoderEntry(Class<?> clazz, Encoder encoder)
/*      */     {
/* 1180 */       this.clazz = clazz;
/* 1181 */       this.encoder = encoder;
/*      */     }
/*      */     
/*      */     public Class<?> getClazz() {
/* 1185 */       return this.clazz;
/*      */     }
/*      */     
/*      */     public Encoder getEncoder() {
/* 1189 */       return this.encoder;
/*      */     }
/*      */   }
/*      */   
/*      */   private static enum State
/*      */   {
/* 1195 */     OPEN, 
/* 1196 */     STREAM_WRITING, 
/* 1197 */     WRITER_WRITING, 
/* 1198 */     BINARY_PARTIAL_WRITING, 
/* 1199 */     BINARY_PARTIAL_READY, 
/* 1200 */     BINARY_FULL_WRITING, 
/* 1201 */     TEXT_PARTIAL_WRITING, 
/* 1202 */     TEXT_PARTIAL_READY, 
/* 1203 */     TEXT_FULL_WRITING;
/*      */     
/*      */     private State() {}
/*      */   }
/*      */   
/* 1208 */   private static class StateMachine { private WsRemoteEndpointImplBase.State state = WsRemoteEndpointImplBase.State.OPEN;
/*      */     
/*      */     public synchronized void streamStart() {
/* 1211 */       checkState(new WsRemoteEndpointImplBase.State[] { WsRemoteEndpointImplBase.State.OPEN });
/* 1212 */       this.state = WsRemoteEndpointImplBase.State.STREAM_WRITING;
/*      */     }
/*      */     
/*      */     public synchronized void writeStart() {
/* 1216 */       checkState(new WsRemoteEndpointImplBase.State[] { WsRemoteEndpointImplBase.State.OPEN });
/* 1217 */       this.state = WsRemoteEndpointImplBase.State.WRITER_WRITING;
/*      */     }
/*      */     
/*      */     public synchronized void binaryPartialStart() {
/* 1221 */       checkState(new WsRemoteEndpointImplBase.State[] { WsRemoteEndpointImplBase.State.OPEN, WsRemoteEndpointImplBase.State.BINARY_PARTIAL_READY });
/* 1222 */       this.state = WsRemoteEndpointImplBase.State.BINARY_PARTIAL_WRITING;
/*      */     }
/*      */     
/*      */     public synchronized void binaryStart() {
/* 1226 */       checkState(new WsRemoteEndpointImplBase.State[] { WsRemoteEndpointImplBase.State.OPEN });
/* 1227 */       this.state = WsRemoteEndpointImplBase.State.BINARY_FULL_WRITING;
/*      */     }
/*      */     
/*      */     public synchronized void textPartialStart() {
/* 1231 */       checkState(new WsRemoteEndpointImplBase.State[] { WsRemoteEndpointImplBase.State.OPEN, WsRemoteEndpointImplBase.State.TEXT_PARTIAL_READY });
/* 1232 */       this.state = WsRemoteEndpointImplBase.State.TEXT_PARTIAL_WRITING;
/*      */     }
/*      */     
/*      */     public synchronized void textStart() {
/* 1236 */       checkState(new WsRemoteEndpointImplBase.State[] { WsRemoteEndpointImplBase.State.OPEN });
/* 1237 */       this.state = WsRemoteEndpointImplBase.State.TEXT_FULL_WRITING;
/*      */     }
/*      */     
/*      */     public synchronized void complete(boolean last) {
/* 1241 */       if (last) {
/* 1242 */         checkState(new WsRemoteEndpointImplBase.State[] { WsRemoteEndpointImplBase.State.TEXT_PARTIAL_WRITING, WsRemoteEndpointImplBase.State.TEXT_FULL_WRITING, WsRemoteEndpointImplBase.State.BINARY_PARTIAL_WRITING, WsRemoteEndpointImplBase.State.BINARY_FULL_WRITING, WsRemoteEndpointImplBase.State.STREAM_WRITING, WsRemoteEndpointImplBase.State.WRITER_WRITING });
/*      */         
/*      */ 
/* 1245 */         this.state = WsRemoteEndpointImplBase.State.OPEN;
/*      */       } else {
/* 1247 */         checkState(new WsRemoteEndpointImplBase.State[] { WsRemoteEndpointImplBase.State.TEXT_PARTIAL_WRITING, WsRemoteEndpointImplBase.State.BINARY_PARTIAL_WRITING, WsRemoteEndpointImplBase.State.STREAM_WRITING, WsRemoteEndpointImplBase.State.WRITER_WRITING });
/*      */         
/* 1249 */         if (this.state == WsRemoteEndpointImplBase.State.TEXT_PARTIAL_WRITING) {
/* 1250 */           this.state = WsRemoteEndpointImplBase.State.TEXT_PARTIAL_READY;
/* 1251 */         } else if (this.state == WsRemoteEndpointImplBase.State.BINARY_PARTIAL_WRITING) {
/* 1252 */           this.state = WsRemoteEndpointImplBase.State.BINARY_PARTIAL_READY;
/* 1253 */         } else if (this.state != WsRemoteEndpointImplBase.State.WRITER_WRITING)
/*      */         {
/* 1255 */           if (this.state != WsRemoteEndpointImplBase.State.STREAM_WRITING)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1261 */             throw new IllegalStateException("BUG: This code should never be called");
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     private void checkState(WsRemoteEndpointImplBase.State... required) {
/* 1268 */       for (WsRemoteEndpointImplBase.State state : required) {
/* 1269 */         if (this.state == state) {
/* 1270 */           return;
/*      */         }
/*      */       }
/*      */       
/* 1274 */       throw new IllegalStateException(WsRemoteEndpointImplBase.sm.getString("wsRemoteEndpoint.wrongState", new Object[] { this.state }));
/*      */     }
/*      */   }
/*      */   
/*      */   private static class StateUpdateSendHandler implements SendHandler
/*      */   {
/*      */     private final SendHandler handler;
/*      */     private final WsRemoteEndpointImplBase.StateMachine stateMachine;
/*      */     
/*      */     public StateUpdateSendHandler(SendHandler handler, WsRemoteEndpointImplBase.StateMachine stateMachine)
/*      */     {
/* 1285 */       this.handler = handler;
/* 1286 */       this.stateMachine = stateMachine;
/*      */     }
/*      */     
/*      */     public void onResult(SendResult result)
/*      */     {
/* 1291 */       if (result.isOK()) {
/* 1292 */         this.stateMachine.complete(true);
/*      */       }
/* 1294 */       this.handler.onResult(result);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class BlockingSendHandler
/*      */     implements SendHandler
/*      */   {
/* 1301 */     private volatile SendResult sendResult = null;
/*      */     
/*      */     public void onResult(SendResult result)
/*      */     {
/* 1305 */       this.sendResult = result;
/*      */     }
/*      */     
/*      */     public SendResult getSendResult() {
/* 1309 */       return this.sendResult;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\WsRemoteEndpointImplBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */