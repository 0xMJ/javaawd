/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentSkipListMap;
/*     */ import javax.naming.NamingException;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.FilterRegistration.Dynamic;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.websocket.CloseReason;
/*     */ import javax.websocket.CloseReason.CloseCodes;
/*     */ import javax.websocket.DeploymentException;
/*     */ import javax.websocket.Encoder;
/*     */ import javax.websocket.server.ServerContainer;
/*     */ import javax.websocket.server.ServerEndpoint;
/*     */ import javax.websocket.server.ServerEndpointConfig;
/*     */ import javax.websocket.server.ServerEndpointConfig.Builder;
/*     */ import javax.websocket.server.ServerEndpointConfig.Configurator;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.Constants;
/*     */ import org.apache.tomcat.websocket.WsSession;
/*     */ import org.apache.tomcat.websocket.WsWebSocketContainer;
/*     */ import org.apache.tomcat.websocket.pojo.PojoMethodMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsServerContainer
/*     */   extends WsWebSocketContainer
/*     */   implements ServerContainer
/*     */ {
/*  63 */   private static final StringManager sm = StringManager.getManager(WsServerContainer.class);
/*     */   
/*  65 */   private static final CloseReason AUTHENTICATED_HTTP_SESSION_CLOSED = new CloseReason(CloseReason.CloseCodes.VIOLATED_POLICY, "This connection was established under an authenticated HTTP session that has ended.");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  70 */   private final WsWriteTimeout wsWriteTimeout = new WsWriteTimeout();
/*     */   
/*     */   private final ServletContext servletContext;
/*  73 */   private final Map<String, ExactPathMatch> configExactMatchMap = new ConcurrentHashMap();
/*  74 */   private final Map<Integer, ConcurrentSkipListMap<String, TemplatePathMatch>> configTemplateMatchMap = new ConcurrentHashMap();
/*     */   
/*  76 */   private volatile boolean enforceNoAddAfterHandshake = Constants.STRICT_SPEC_COMPLIANCE;
/*     */   
/*  78 */   private volatile boolean addAllowed = true;
/*  79 */   private final Map<String, Set<WsSession>> authenticatedSessions = new ConcurrentHashMap();
/*  80 */   private volatile boolean endpointsRegistered = false;
/*  81 */   private volatile boolean deploymentFailed = false;
/*     */   
/*     */   WsServerContainer(ServletContext servletContext)
/*     */   {
/*  85 */     this.servletContext = servletContext;
/*  86 */     setInstanceManager((InstanceManager)servletContext.getAttribute(InstanceManager.class.getName()));
/*     */     
/*     */ 
/*  89 */     String value = servletContext.getInitParameter("org.apache.tomcat.websocket.binaryBufferSize");
/*     */     
/*  91 */     if (value != null) {
/*  92 */       setDefaultMaxBinaryMessageBufferSize(Integer.parseInt(value));
/*     */     }
/*     */     
/*  95 */     value = servletContext.getInitParameter("org.apache.tomcat.websocket.textBufferSize");
/*     */     
/*  97 */     if (value != null) {
/*  98 */       setDefaultMaxTextMessageBufferSize(Integer.parseInt(value));
/*     */     }
/*     */     
/* 101 */     value = servletContext.getInitParameter("org.apache.tomcat.websocket.noAddAfterHandshake");
/*     */     
/* 103 */     if (value != null) {
/* 104 */       setEnforceNoAddAfterHandshake(Boolean.parseBoolean(value));
/*     */     }
/*     */     
/* 107 */     FilterRegistration.Dynamic fr = servletContext.addFilter("Tomcat WebSocket (JSR356) Filter", new WsFilter());
/*     */     
/* 109 */     fr.setAsyncSupported(true);
/*     */     
/* 111 */     EnumSet<DispatcherType> types = EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD);
/*     */     
/*     */ 
/* 114 */     fr.addMappingForUrlPatterns(types, true, new String[] { "/*" });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addEndpoint(ServerEndpointConfig sec)
/*     */     throws DeploymentException
/*     */   {
/* 129 */     addEndpoint(sec, false);
/*     */   }
/*     */   
/*     */   void addEndpoint(ServerEndpointConfig sec, boolean fromAnnotatedPojo)
/*     */     throws DeploymentException
/*     */   {
/* 135 */     if ((this.enforceNoAddAfterHandshake) && (!this.addAllowed))
/*     */     {
/* 137 */       throw new DeploymentException(sm.getString("serverContainer.addNotAllowed"));
/*     */     }
/*     */     
/* 140 */     if (this.servletContext == null)
/*     */     {
/* 142 */       throw new DeploymentException(sm.getString("serverContainer.servletContextMissing"));
/*     */     }
/*     */     
/* 145 */     if (this.deploymentFailed) {
/* 146 */       throw new DeploymentException(sm.getString("serverContainer.failedDeployment", new Object[] {this.servletContext
/* 147 */         .getContextPath(), this.servletContext.getVirtualServerName() }));
/*     */     }
/*     */     try
/*     */     {
/* 151 */       String path = sec.getPath();
/*     */       
/*     */ 
/*     */ 
/* 155 */       PojoMethodMapping methodMapping = new PojoMethodMapping(sec.getEndpointClass(), sec.getDecoders(), path, getInstanceManager(Thread.currentThread().getContextClassLoader()));
/* 156 */       if ((methodMapping.getOnClose() != null) || (methodMapping.getOnOpen() != null) || 
/* 157 */         (methodMapping.getOnError() != null) || (methodMapping.hasMessageHandlers())) {
/* 158 */         sec.getUserProperties().put("org.apache.tomcat.websocket.pojo.PojoEndpoint.methodMapping", methodMapping);
/*     */       }
/*     */       
/*     */ 
/* 162 */       UriTemplate uriTemplate = new UriTemplate(path);
/* 163 */       if (uriTemplate.hasParameters()) {
/* 164 */         Integer key = Integer.valueOf(uriTemplate.getSegmentCount());
/*     */         
/* 166 */         ConcurrentSkipListMap<String, TemplatePathMatch> templateMatches = (ConcurrentSkipListMap)this.configTemplateMatchMap.get(key);
/* 167 */         if (templateMatches == null)
/*     */         {
/*     */ 
/* 170 */           templateMatches = new ConcurrentSkipListMap();
/* 171 */           this.configTemplateMatchMap.putIfAbsent(key, templateMatches);
/* 172 */           templateMatches = (ConcurrentSkipListMap)this.configTemplateMatchMap.get(key);
/*     */         }
/* 174 */         TemplatePathMatch newMatch = new TemplatePathMatch(sec, uriTemplate, fromAnnotatedPojo);
/* 175 */         TemplatePathMatch oldMatch = (TemplatePathMatch)templateMatches.putIfAbsent(uriTemplate.getNormalizedPath(), newMatch);
/* 176 */         if (oldMatch != null)
/*     */         {
/*     */ 
/* 179 */           if ((oldMatch.isFromAnnotatedPojo()) && (!newMatch.isFromAnnotatedPojo()) && 
/* 180 */             (oldMatch.getConfig().getEndpointClass() == newMatch.getConfig().getEndpointClass()))
/*     */           {
/* 182 */             templateMatches.put(path, oldMatch);
/*     */           }
/*     */           else
/*     */           {
/* 186 */             throw new DeploymentException(sm.getString("serverContainer.duplicatePaths", new Object[] { path, sec
/* 187 */               .getEndpointClass(), sec
/* 188 */               .getEndpointClass() }));
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 193 */         ExactPathMatch newMatch = new ExactPathMatch(sec, fromAnnotatedPojo);
/* 194 */         ExactPathMatch oldMatch = (ExactPathMatch)this.configExactMatchMap.put(path, newMatch);
/* 195 */         if (oldMatch != null)
/*     */         {
/*     */ 
/* 198 */           if ((oldMatch.isFromAnnotatedPojo()) && (!newMatch.isFromAnnotatedPojo()) && 
/* 199 */             (oldMatch.getConfig().getEndpointClass() == newMatch.getConfig().getEndpointClass()))
/*     */           {
/* 201 */             this.configExactMatchMap.put(path, oldMatch);
/*     */           }
/*     */           else
/*     */           {
/* 205 */             throw new DeploymentException(sm.getString("serverContainer.duplicatePaths", new Object[] { path, oldMatch
/* 206 */               .getConfig().getEndpointClass(), sec
/* 207 */               .getEndpointClass() }));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 212 */       this.endpointsRegistered = true;
/*     */     } catch (DeploymentException de) {
/* 214 */       failDeployment();
/* 215 */       throw de;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addEndpoint(Class<?> pojo)
/*     */     throws DeploymentException
/*     */   {
/* 229 */     addEndpoint(pojo, false);
/*     */   }
/*     */   
/*     */   void addEndpoint(Class<?> pojo, boolean fromAnnotatedPojo)
/*     */     throws DeploymentException
/*     */   {
/* 235 */     if (this.deploymentFailed) {
/* 236 */       throw new DeploymentException(sm.getString("serverContainer.failedDeployment", new Object[] {this.servletContext
/* 237 */         .getContextPath(), this.servletContext.getVirtualServerName() }));
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 243 */       ServerEndpoint annotation = (ServerEndpoint)pojo.getAnnotation(ServerEndpoint.class);
/* 244 */       if (annotation == null)
/*     */       {
/* 246 */         throw new DeploymentException(sm.getString("serverContainer.missingAnnotation", new Object[] {pojo
/* 247 */           .getName() }));
/*     */       }
/* 249 */       String path = annotation.value();
/*     */       
/*     */ 
/* 252 */       validateEncoders(annotation.encoders(), getInstanceManager(Thread.currentThread().getContextClassLoader()));
/*     */       
/*     */ 
/*     */ 
/* 256 */       Class<? extends ServerEndpointConfig.Configurator> configuratorClazz = annotation.configurator();
/* 257 */       ServerEndpointConfig.Configurator configurator = null;
/* 258 */       if (!configuratorClazz.equals(ServerEndpointConfig.Configurator.class)) {
/*     */         try {
/* 260 */           configurator = (ServerEndpointConfig.Configurator)annotation.configurator().getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */         } catch (ReflectiveOperationException e) {
/* 262 */           throw new DeploymentException(sm.getString("serverContainer.configuratorFail", new Object[] {annotation
/*     */           
/* 264 */             .configurator().getName(), pojo
/* 265 */             .getClass().getName() }), e);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 273 */       sec = ServerEndpointConfig.Builder.create(pojo, path).decoders(Arrays.asList(annotation.decoders())).encoders(Arrays.asList(annotation.encoders())).subprotocols(Arrays.asList(annotation.subprotocols())).configurator(configurator).build();
/*     */     } catch (DeploymentException de) { ServerEndpointConfig sec;
/* 275 */       failDeployment();
/* 276 */       throw de;
/*     */     }
/*     */     ServerEndpointConfig sec;
/* 279 */     addEndpoint(sec, fromAnnotatedPojo);
/*     */   }
/*     */   
/*     */   void failDeployment()
/*     */   {
/* 284 */     this.deploymentFailed = true;
/*     */     
/*     */ 
/* 287 */     this.endpointsRegistered = false;
/* 288 */     this.configExactMatchMap.clear();
/* 289 */     this.configTemplateMatchMap.clear();
/*     */   }
/*     */   
/*     */   boolean areEndpointsRegistered()
/*     */   {
/* 294 */     return this.endpointsRegistered;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doUpgrade(HttpServletRequest request, HttpServletResponse response, ServerEndpointConfig sec, Map<String, String> pathParams)
/*     */     throws ServletException, IOException
/*     */   {
/* 320 */     UpgradeUtil.doUpgrade(this, request, response, sec, pathParams);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public WsMappingResult findMapping(String path)
/*     */   {
/* 328 */     if (this.addAllowed) {
/* 329 */       this.addAllowed = false;
/*     */     }
/*     */     
/*     */ 
/* 333 */     ExactPathMatch match = (ExactPathMatch)this.configExactMatchMap.get(path);
/* 334 */     if (match != null) {
/* 335 */       return new WsMappingResult(match.getConfig(), Collections.emptyMap());
/*     */     }
/*     */     
/*     */ 
/* 339 */     UriTemplate pathUriTemplate = null;
/*     */     try {
/* 341 */       pathUriTemplate = new UriTemplate(path);
/*     */     }
/*     */     catch (DeploymentException e) {
/* 344 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 348 */     Integer key = Integer.valueOf(pathUriTemplate.getSegmentCount());
/* 349 */     ConcurrentSkipListMap<String, TemplatePathMatch> templateMatches = (ConcurrentSkipListMap)this.configTemplateMatchMap.get(key);
/*     */     
/* 351 */     if (templateMatches == null)
/*     */     {
/*     */ 
/* 354 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 359 */     ServerEndpointConfig sec = null;
/* 360 */     Map<String, String> pathParams = null;
/* 361 */     for (TemplatePathMatch templateMatch : templateMatches.values()) {
/* 362 */       pathParams = templateMatch.getUriTemplate().match(pathUriTemplate);
/* 363 */       if (pathParams != null) {
/* 364 */         sec = templateMatch.getConfig();
/* 365 */         break;
/*     */       }
/*     */     }
/*     */     
/* 369 */     if (sec == null)
/*     */     {
/* 371 */       return null;
/*     */     }
/*     */     
/* 374 */     return new WsMappingResult(sec, pathParams);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isEnforceNoAddAfterHandshake()
/*     */   {
/* 380 */     return this.enforceNoAddAfterHandshake;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setEnforceNoAddAfterHandshake(boolean enforceNoAddAfterHandshake)
/*     */   {
/* 386 */     this.enforceNoAddAfterHandshake = enforceNoAddAfterHandshake;
/*     */   }
/*     */   
/*     */   protected WsWriteTimeout getTimeout()
/*     */   {
/* 391 */     return this.wsWriteTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerSession(Object key, WsSession wsSession)
/*     */   {
/* 402 */     super.registerSession(key, wsSession);
/* 403 */     if ((wsSession.isOpen()) && 
/* 404 */       (wsSession.getUserPrincipal() != null) && 
/* 405 */       (wsSession.getHttpSessionId() != null)) {
/* 406 */       registerAuthenticatedSession(wsSession, wsSession
/* 407 */         .getHttpSessionId());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void unregisterSession(Object key, WsSession wsSession)
/*     */   {
/* 419 */     if ((wsSession.getUserPrincipal() != null) && 
/* 420 */       (wsSession.getHttpSessionId() != null)) {
/* 421 */       unregisterAuthenticatedSession(wsSession, wsSession
/* 422 */         .getHttpSessionId());
/*     */     }
/* 424 */     super.unregisterSession(key, wsSession);
/*     */   }
/*     */   
/*     */ 
/*     */   private void registerAuthenticatedSession(WsSession wsSession, String httpSessionId)
/*     */   {
/* 430 */     Set<WsSession> wsSessions = (Set)this.authenticatedSessions.get(httpSessionId);
/* 431 */     if (wsSessions == null) {
/* 432 */       wsSessions = Collections.newSetFromMap(new ConcurrentHashMap());
/*     */       
/* 434 */       this.authenticatedSessions.putIfAbsent(httpSessionId, wsSessions);
/* 435 */       wsSessions = (Set)this.authenticatedSessions.get(httpSessionId);
/*     */     }
/* 437 */     wsSessions.add(wsSession);
/*     */   }
/*     */   
/*     */ 
/*     */   private void unregisterAuthenticatedSession(WsSession wsSession, String httpSessionId)
/*     */   {
/* 443 */     Set<WsSession> wsSessions = (Set)this.authenticatedSessions.get(httpSessionId);
/*     */     
/* 445 */     if (wsSessions != null) {
/* 446 */       wsSessions.remove(wsSession);
/*     */     }
/*     */   }
/*     */   
/*     */   public void closeAuthenticatedSession(String httpSessionId)
/*     */   {
/* 452 */     Set<WsSession> wsSessions = (Set)this.authenticatedSessions.remove(httpSessionId);
/*     */     
/* 454 */     if ((wsSessions != null) && (!wsSessions.isEmpty())) {
/* 455 */       for (WsSession wsSession : wsSessions) {
/*     */         try {
/* 457 */           wsSession.close(AUTHENTICATED_HTTP_SESSION_CLOSED);
/*     */         }
/*     */         catch (IOException localIOException) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void validateEncoders(Class<? extends Encoder>[] encoders, InstanceManager instanceManager)
/*     */     throws DeploymentException
/*     */   {
/* 470 */     for (Class<? extends Encoder> encoder : encoders) {
/*     */       try
/*     */       {
/*     */         Encoder instance;
/*     */         
/*     */ 
/* 476 */         if (instanceManager == null) {
/* 477 */           instance = (Encoder)encoder.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */         } else {
/* 479 */           Encoder instance = (Encoder)instanceManager.newInstance(encoder);
/* 480 */           instanceManager.destroyInstance(instance);
/*     */         }
/*     */       } catch (ReflectiveOperationException|NamingException e) {
/* 483 */         throw new DeploymentException(sm.getString("serverContainer.encoderFail", new Object[] {encoder
/* 484 */           .getName() }), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class TemplatePathMatch
/*     */   {
/*     */     private final ServerEndpointConfig config;
/*     */     private final UriTemplate uriTemplate;
/*     */     private final boolean fromAnnotatedPojo;
/*     */     
/*     */     public TemplatePathMatch(ServerEndpointConfig config, UriTemplate uriTemplate, boolean fromAnnotatedPojo)
/*     */     {
/* 497 */       this.config = config;
/* 498 */       this.uriTemplate = uriTemplate;
/* 499 */       this.fromAnnotatedPojo = fromAnnotatedPojo;
/*     */     }
/*     */     
/*     */     public ServerEndpointConfig getConfig()
/*     */     {
/* 504 */       return this.config;
/*     */     }
/*     */     
/*     */     public UriTemplate getUriTemplate()
/*     */     {
/* 509 */       return this.uriTemplate;
/*     */     }
/*     */     
/*     */     public boolean isFromAnnotatedPojo()
/*     */     {
/* 514 */       return this.fromAnnotatedPojo;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ExactPathMatch
/*     */   {
/*     */     private final ServerEndpointConfig config;
/*     */     private final boolean fromAnnotatedPojo;
/*     */     
/*     */     public ExactPathMatch(ServerEndpointConfig config, boolean fromAnnotatedPojo) {
/* 524 */       this.config = config;
/* 525 */       this.fromAnnotatedPojo = fromAnnotatedPojo;
/*     */     }
/*     */     
/*     */     public ServerEndpointConfig getConfig()
/*     */     {
/* 530 */       return this.config;
/*     */     }
/*     */     
/*     */     public boolean isFromAnnotatedPojo()
/*     */     {
/* 535 */       return this.fromAnnotatedPojo;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\server\WsServerContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */