/*    */ package org.apache.tomcat.websocket.pojo;
/*    */ 
/*    */ import javax.websocket.DeploymentException;
/*    */ import org.apache.tomcat.util.res.StringManager;
/*    */ import org.apache.tomcat.websocket.Util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PojoPathParam
/*    */ {
/* 34 */   private static final StringManager sm = StringManager.getManager(PojoPathParam.class);
/*    */   private final Class<?> type;
/*    */   private final String name;
/*    */   
/*    */   public PojoPathParam(Class<?> type, String name)
/*    */     throws DeploymentException
/*    */   {
/* 41 */     if (name != null)
/*    */     {
/* 43 */       validateType(type);
/*    */     }
/* 45 */     this.type = type;
/* 46 */     this.name = name;
/*    */   }
/*    */   
/*    */   public Class<?> getType()
/*    */   {
/* 51 */     return this.type;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 56 */     return this.name;
/*    */   }
/*    */   
/*    */   private static void validateType(Class<?> type) throws DeploymentException
/*    */   {
/* 61 */     if (String.class == type) {
/* 62 */       return;
/*    */     }
/* 64 */     if (Util.isPrimitive(type)) {
/* 65 */       return;
/*    */     }
/* 67 */     throw new DeploymentException(sm.getString("pojoPathParam.wrongType", new Object[] { type.getName() }));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\pojo\PojoPathParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */