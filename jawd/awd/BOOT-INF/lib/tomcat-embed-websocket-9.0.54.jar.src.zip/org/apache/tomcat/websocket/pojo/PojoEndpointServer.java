/*    */ package org.apache.tomcat.websocket.pojo;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.websocket.EndpointConfig;
/*    */ import javax.websocket.Session;
/*    */ import javax.websocket.server.ServerEndpointConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PojoEndpointServer
/*    */   extends PojoEndpointBase
/*    */ {
/*    */   public PojoEndpointServer(Map<String, String> pathParameters, Object pojo)
/*    */   {
/* 33 */     super(pathParameters);
/* 34 */     setPojo(pojo);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void onOpen(Session session, EndpointConfig endpointConfig)
/*    */   {
/* 41 */     ServerEndpointConfig sec = (ServerEndpointConfig)endpointConfig;
/*    */     
/*    */ 
/* 44 */     PojoMethodMapping methodMapping = (PojoMethodMapping)sec.getUserProperties().get("org.apache.tomcat.websocket.pojo.PojoEndpoint.methodMapping");
/*    */     
/* 46 */     setMethodMapping(methodMapping);
/*    */     
/* 48 */     doOnOpen(session, endpointConfig);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\pojo\PojoEndpointServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */