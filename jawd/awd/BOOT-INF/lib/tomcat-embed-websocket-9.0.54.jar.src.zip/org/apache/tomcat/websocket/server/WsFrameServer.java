/*     */ package org.apache.tomcat.websocket.server;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.coyote.http11.upgrade.UpgradeInfo;
/*     */ import org.apache.juli.logging.Log;
/*     */ import org.apache.juli.logging.LogFactory;
/*     */ import org.apache.tomcat.util.net.AbstractEndpoint.Handler.SocketState;
/*     */ import org.apache.tomcat.util.net.SocketEvent;
/*     */ import org.apache.tomcat.util.net.SocketWrapperBase;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.Transformation;
/*     */ import org.apache.tomcat.websocket.WsFrameBase;
/*     */ import org.apache.tomcat.websocket.WsFrameBase.ReadState;
/*     */ import org.apache.tomcat.websocket.WsIOException;
/*     */ import org.apache.tomcat.websocket.WsSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsFrameServer
/*     */   extends WsFrameBase
/*     */ {
/*  37 */   private final Log log = LogFactory.getLog(WsFrameServer.class);
/*  38 */   private static final StringManager sm = StringManager.getManager(WsFrameServer.class);
/*     */   
/*     */   private final SocketWrapperBase<?> socketWrapper;
/*     */   
/*     */   private final UpgradeInfo upgradeInfo;
/*     */   private final ClassLoader applicationClassLoader;
/*     */   
/*     */   public WsFrameServer(SocketWrapperBase<?> socketWrapper, UpgradeInfo upgradeInfo, WsSession wsSession, Transformation transformation, ClassLoader applicationClassLoader)
/*     */   {
/*  47 */     super(wsSession, transformation);
/*  48 */     this.socketWrapper = socketWrapper;
/*  49 */     this.upgradeInfo = upgradeInfo;
/*  50 */     this.applicationClassLoader = applicationClassLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void onDataAvailable()
/*     */     throws IOException
/*     */   {
/*  61 */     if (this.log.isDebugEnabled()) {
/*  62 */       this.log.debug("wsFrameServer.onDataAvailable");
/*     */     }
/*  64 */     if ((isOpen()) && (this.inputBuffer.hasRemaining()) && (!isSuspended()))
/*     */     {
/*     */ 
/*     */ 
/*  68 */       processInputBuffer();
/*     */     }
/*     */     
/*  71 */     while ((isOpen()) && (!isSuspended()))
/*     */     {
/*  73 */       this.inputBuffer.mark();
/*  74 */       this.inputBuffer.position(this.inputBuffer.limit()).limit(this.inputBuffer.capacity());
/*  75 */       int read = this.socketWrapper.read(false, this.inputBuffer);
/*  76 */       this.inputBuffer.limit(this.inputBuffer.position()).reset();
/*  77 */       if (read < 0)
/*  78 */         throw new EOFException();
/*  79 */       if (read == 0) {
/*  80 */         return;
/*     */       }
/*  82 */       if (this.log.isDebugEnabled()) {
/*  83 */         this.log.debug(sm.getString("wsFrameServer.bytesRead", new Object[] { Integer.toString(read) }));
/*     */       }
/*  85 */       processInputBuffer();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void updateStats(long payloadLength)
/*     */   {
/*  92 */     this.upgradeInfo.addMsgsReceived(1L);
/*  93 */     this.upgradeInfo.addBytesReceived(payloadLength);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isMasked()
/*     */   {
/* 100 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Transformation getTransformation()
/*     */   {
/* 107 */     return super.getTransformation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isOpen()
/*     */   {
/* 114 */     return super.isOpen();
/*     */   }
/*     */   
/*     */ 
/*     */   protected Log getLog()
/*     */   {
/* 120 */     return this.log;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected void sendMessageText(boolean last)
/*     */     throws WsIOException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: invokestatic 36	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   3: invokevirtual 37	java/lang/Thread:getContextClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   6: astore_2
/*     */     //   7: invokestatic 36	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   10: aload_0
/*     */     //   11: getfield 7	org/apache/tomcat/websocket/server/WsFrameServer:applicationClassLoader	Ljava/lang/ClassLoader;
/*     */     //   14: invokevirtual 38	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   17: aload_0
/*     */     //   18: iload_1
/*     */     //   19: invokespecial 39	org/apache/tomcat/websocket/WsFrameBase:sendMessageText	(Z)V
/*     */     //   22: invokestatic 36	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   25: aload_2
/*     */     //   26: invokevirtual 38	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   29: goto +13 -> 42
/*     */     //   32: astore_3
/*     */     //   33: invokestatic 36	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   36: aload_2
/*     */     //   37: invokevirtual 38	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   40: aload_3
/*     */     //   41: athrow
/*     */     //   42: return
/*     */     // Line number table:
/*     */     //   Java source line #126	-> byte code offset #0
/*     */     //   Java source line #128	-> byte code offset #7
/*     */     //   Java source line #129	-> byte code offset #17
/*     */     //   Java source line #131	-> byte code offset #22
/*     */     //   Java source line #132	-> byte code offset #29
/*     */     //   Java source line #131	-> byte code offset #32
/*     */     //   Java source line #132	-> byte code offset #40
/*     */     //   Java source line #133	-> byte code offset #42
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	43	0	this	WsFrameServer
/*     */     //   0	43	1	last	boolean
/*     */     //   6	31	2	cl	ClassLoader
/*     */     //   32	9	3	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	22	32	finally
/*     */   }
/*     */   
/*     */   protected void sendMessageBinary(ByteBuffer msg, boolean last)
/*     */     throws WsIOException
/*     */   {
/* 138 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*     */     try {
/* 140 */       Thread.currentThread().setContextClassLoader(this.applicationClassLoader);
/* 141 */       super.sendMessageBinary(msg, last);
/*     */     } finally {
/* 143 */       Thread.currentThread().setContextClassLoader(cl);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void resumeProcessing()
/*     */   {
/* 150 */     this.socketWrapper.processSocket(SocketEvent.OPEN_READ, true);
/*     */   }
/*     */   
/*     */   AbstractEndpoint.Handler.SocketState notifyDataAvailable() throws IOException
/*     */   {
/* 155 */     while (isOpen()) {
/* 156 */       switch (getReadState()) {
/*     */       case WAITING: 
/* 158 */         if (changeReadState(WsFrameBase.ReadState.WAITING, WsFrameBase.ReadState.PROCESSING))
/*     */         {
/*     */           try
/*     */           {
/* 162 */             return doOnDataAvailable();
/*     */           } catch (IOException e) {
/* 164 */             changeReadState(WsFrameBase.ReadState.CLOSING);
/* 165 */             throw e;
/*     */           } }
/*     */         break;
/* 168 */       case SUSPENDING_WAIT:  if (changeReadState(WsFrameBase.ReadState.SUSPENDING_WAIT, WsFrameBase.ReadState.SUSPENDED))
/*     */         {
/*     */ 
/* 171 */           return AbstractEndpoint.Handler.SocketState.SUSPENDED; }
/*     */         break;
/*     */       default: 
/* 174 */         throw new IllegalStateException(sm.getString("wsFrameServer.illegalReadState", new Object[] {getReadState() }));
/*     */       }
/*     */       
/*     */     }
/* 178 */     return AbstractEndpoint.Handler.SocketState.CLOSED;
/*     */   }
/*     */   
/*     */   private AbstractEndpoint.Handler.SocketState doOnDataAvailable() throws IOException
/*     */   {
/* 183 */     onDataAvailable();
/* 184 */     while (isOpen()) {
/* 185 */       switch (getReadState()) {
/*     */       case PROCESSING: 
/* 187 */         if (changeReadState(WsFrameBase.ReadState.PROCESSING, WsFrameBase.ReadState.WAITING))
/*     */         {
/*     */ 
/* 190 */           return AbstractEndpoint.Handler.SocketState.UPGRADED; }
/*     */         break;
/* 192 */       case SUSPENDING_PROCESS:  if (changeReadState(WsFrameBase.ReadState.SUSPENDING_PROCESS, WsFrameBase.ReadState.SUSPENDED))
/*     */         {
/*     */ 
/* 195 */           return AbstractEndpoint.Handler.SocketState.SUSPENDED; }
/*     */         break;
/*     */       default: 
/* 198 */         throw new IllegalStateException(sm.getString("wsFrameServer.illegalReadState", new Object[] {getReadState() }));
/*     */       }
/*     */       
/*     */     }
/* 202 */     return AbstractEndpoint.Handler.SocketState.CLOSED;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\server\WsFrameServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */