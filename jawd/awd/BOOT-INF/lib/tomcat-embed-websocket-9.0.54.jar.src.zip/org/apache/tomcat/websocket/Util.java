/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import javax.naming.NamingException;
/*     */ import javax.websocket.CloseReason.CloseCode;
/*     */ import javax.websocket.CloseReason.CloseCodes;
/*     */ import javax.websocket.Decoder;
/*     */ import javax.websocket.Decoder.Binary;
/*     */ import javax.websocket.Decoder.BinaryStream;
/*     */ import javax.websocket.Decoder.Text;
/*     */ import javax.websocket.Decoder.TextStream;
/*     */ import javax.websocket.DeploymentException;
/*     */ import javax.websocket.Encoder;
/*     */ import javax.websocket.EndpointConfig;
/*     */ import javax.websocket.Extension;
/*     */ import javax.websocket.MessageHandler;
/*     */ import javax.websocket.MessageHandler.Whole;
/*     */ import javax.websocket.PongMessage;
/*     */ import javax.websocket.Session;
/*     */ import org.apache.tomcat.InstanceManager;
/*     */ import org.apache.tomcat.util.res.StringManager;
/*     */ import org.apache.tomcat.websocket.pojo.PojoMessageHandlerPartialBinary;
/*     */ import org.apache.tomcat.websocket.pojo.PojoMessageHandlerWholeBinary;
/*     */ import org.apache.tomcat.websocket.pojo.PojoMessageHandlerWholeText;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*  64 */   private static final StringManager sm = StringManager.getManager(Util.class);
/*  65 */   private static final Queue<SecureRandom> randoms = new ConcurrentLinkedQueue();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean isControl(byte opCode)
/*     */   {
/*  74 */     return (opCode & 0x8) != 0;
/*     */   }
/*     */   
/*     */   static boolean isText(byte opCode)
/*     */   {
/*  79 */     return opCode == 1;
/*     */   }
/*     */   
/*     */   static boolean isContinuation(byte opCode)
/*     */   {
/*  84 */     return opCode == 0;
/*     */   }
/*     */   
/*     */   static CloseReason.CloseCode getCloseCode(int code)
/*     */   {
/*  89 */     if ((code > 2999) && (code < 5000)) {
/*  90 */       return CloseReason.CloseCodes.getCloseCode(code);
/*     */     }
/*  92 */     switch (code) {
/*     */     case 1000: 
/*  94 */       return CloseReason.CloseCodes.NORMAL_CLOSURE;
/*     */     case 1001: 
/*  96 */       return CloseReason.CloseCodes.GOING_AWAY;
/*     */     case 1002: 
/*  98 */       return CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */     case 1003: 
/* 100 */       return CloseReason.CloseCodes.CANNOT_ACCEPT;
/*     */     
/*     */ 
/*     */     case 1004: 
/* 104 */       return CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */     
/*     */ 
/*     */     case 1005: 
/* 108 */       return CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */     
/*     */ 
/*     */     case 1006: 
/* 112 */       return CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */     case 1007: 
/* 114 */       return CloseReason.CloseCodes.NOT_CONSISTENT;
/*     */     case 1008: 
/* 116 */       return CloseReason.CloseCodes.VIOLATED_POLICY;
/*     */     case 1009: 
/* 118 */       return CloseReason.CloseCodes.TOO_BIG;
/*     */     case 1010: 
/* 120 */       return CloseReason.CloseCodes.NO_EXTENSION;
/*     */     case 1011: 
/* 122 */       return CloseReason.CloseCodes.UNEXPECTED_CONDITION;
/*     */     
/*     */ 
/*     */     case 1012: 
/* 126 */       return CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */     
/*     */ 
/*     */     case 1013: 
/* 130 */       return CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */     
/*     */ 
/*     */     case 1015: 
/* 134 */       return CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */     }
/* 136 */     return CloseReason.CloseCodes.PROTOCOL_ERROR;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static byte[] generateMask()
/*     */   {
/* 148 */     SecureRandom sr = (SecureRandom)randoms.poll();
/*     */     
/*     */ 
/* 151 */     if (sr == null) {
/*     */       try {
/* 153 */         sr = SecureRandom.getInstance("SHA1PRNG");
/*     */       }
/*     */       catch (NoSuchAlgorithmException e) {
/* 156 */         sr = new SecureRandom();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 161 */     byte[] result = new byte[4];
/* 162 */     sr.nextBytes(result);
/*     */     
/*     */ 
/* 165 */     randoms.add(sr);
/*     */     
/* 167 */     return result;
/*     */   }
/*     */   
/*     */   static Class<?> getMessageType(MessageHandler listener)
/*     */   {
/* 172 */     return 
/* 173 */       getGenericType(MessageHandler.class, listener.getClass()).getClazz();
/*     */   }
/*     */   
/*     */   private static Class<?> getDecoderType(Class<? extends Decoder> decoder)
/*     */   {
/* 178 */     return getGenericType(Decoder.class, decoder).getClazz();
/*     */   }
/*     */   
/*     */   static Class<?> getEncoderType(Class<? extends Encoder> encoder)
/*     */   {
/* 183 */     return getGenericType(Encoder.class, encoder).getClazz();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static <T> TypeResult getGenericType(Class<T> type, Class<? extends T> clazz)
/*     */   {
/* 193 */     Type[] interfaces = clazz.getGenericInterfaces();
/* 194 */     for (Type iface : interfaces)
/*     */     {
/* 196 */       if ((iface instanceof ParameterizedType)) {
/* 197 */         ParameterizedType pi = (ParameterizedType)iface;
/*     */         
/* 199 */         if (((pi.getRawType() instanceof Class)) && 
/* 200 */           (type.isAssignableFrom((Class)pi.getRawType()))) {
/* 201 */           return getTypeParameter(clazz, pi
/* 202 */             .getActualTypeArguments()[0]);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 211 */     Object superClazz = clazz.getSuperclass();
/* 212 */     if (superClazz == null)
/*     */     {
/* 214 */       return null;
/*     */     }
/*     */     
/* 217 */     TypeResult superClassTypeResult = getGenericType(type, (Class)superClazz);
/* 218 */     int dimension = superClassTypeResult.getDimension();
/* 219 */     if ((superClassTypeResult.getIndex() == -1) && (dimension == 0))
/*     */     {
/*     */ 
/* 222 */       return superClassTypeResult;
/*     */     }
/*     */     
/* 225 */     if (superClassTypeResult.getIndex() > -1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 230 */       ParameterizedType superClassType = (ParameterizedType)clazz.getGenericSuperclass();
/* 231 */       TypeResult result = getTypeParameter(clazz, superClassType
/* 232 */         .getActualTypeArguments()[superClassTypeResult
/* 233 */         .getIndex()]);
/* 234 */       result.incrementDimension(superClassTypeResult.getDimension());
/* 235 */       if ((result.getClazz() != null) && (result.getDimension() > 0)) {
/* 236 */         superClassTypeResult = result;
/*     */       } else {
/* 238 */         return result;
/*     */       }
/*     */     }
/*     */     
/* 242 */     if (superClassTypeResult.getDimension() > 0) {
/* 243 */       StringBuilder className = new StringBuilder();
/* 244 */       for (int i = 0; i < dimension; i++) {
/* 245 */         className.append('[');
/*     */       }
/* 247 */       className.append('L');
/* 248 */       className.append(superClassTypeResult.getClazz().getCanonicalName());
/* 249 */       className.append(';');
/*     */       
/*     */       try
/*     */       {
/* 253 */         arrayClazz = Class.forName(className.toString());
/*     */       } catch (ClassNotFoundException e) { Class<?> arrayClazz;
/* 255 */         throw new IllegalArgumentException(e);
/*     */       }
/*     */       Class<?> arrayClazz;
/* 258 */       return new TypeResult(arrayClazz, -1, 0);
/*     */     }
/*     */     
/*     */ 
/* 262 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static TypeResult getTypeParameter(Class<?> clazz, Type argType)
/*     */   {
/* 271 */     if ((argType instanceof Class))
/* 272 */       return new TypeResult((Class)argType, -1, 0);
/* 273 */     if ((argType instanceof ParameterizedType))
/* 274 */       return new TypeResult((Class)((ParameterizedType)argType).getRawType(), -1, 0);
/* 275 */     if ((argType instanceof GenericArrayType)) {
/* 276 */       Type arrayElementType = ((GenericArrayType)argType).getGenericComponentType();
/* 277 */       TypeResult result = getTypeParameter(clazz, arrayElementType);
/* 278 */       result.incrementDimension(1);
/* 279 */       return result;
/*     */     }
/* 281 */     TypeVariable<?>[] tvs = clazz.getTypeParameters();
/* 282 */     for (int i = 0; i < tvs.length; i++) {
/* 283 */       if (tvs[i].equals(argType)) {
/* 284 */         return new TypeResult(null, i, 0);
/*     */       }
/*     */     }
/* 287 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean isPrimitive(Class<?> clazz)
/*     */   {
/* 293 */     if (clazz.isPrimitive())
/* 294 */       return true;
/* 295 */     if ((clazz.equals(Boolean.class)) || 
/* 296 */       (clazz.equals(Byte.class)) || 
/* 297 */       (clazz.equals(Character.class)) || 
/* 298 */       (clazz.equals(Double.class)) || 
/* 299 */       (clazz.equals(Float.class)) || 
/* 300 */       (clazz.equals(Integer.class)) || 
/* 301 */       (clazz.equals(Long.class)) || 
/* 302 */       (clazz.equals(Short.class))) {
/* 303 */       return true;
/*     */     }
/* 305 */     return false;
/*     */   }
/*     */   
/*     */   public static Object coerceToType(Class<?> type, String value)
/*     */   {
/* 310 */     if (type.equals(String.class))
/* 311 */       return value;
/* 312 */     if ((type.equals(Boolean.TYPE)) || (type.equals(Boolean.class)))
/* 313 */       return Boolean.valueOf(value);
/* 314 */     if ((type.equals(Byte.TYPE)) || (type.equals(Byte.class)))
/* 315 */       return Byte.valueOf(value);
/* 316 */     if ((type.equals(Character.TYPE)) || (type.equals(Character.class)))
/* 317 */       return Character.valueOf(value.charAt(0));
/* 318 */     if ((type.equals(Double.TYPE)) || (type.equals(Double.class)))
/* 319 */       return Double.valueOf(value);
/* 320 */     if ((type.equals(Float.TYPE)) || (type.equals(Float.class)))
/* 321 */       return Float.valueOf(value);
/* 322 */     if ((type.equals(Integer.TYPE)) || (type.equals(Integer.class)))
/* 323 */       return Integer.valueOf(value);
/* 324 */     if ((type.equals(Long.TYPE)) || (type.equals(Long.class)))
/* 325 */       return Long.valueOf(value);
/* 326 */     if ((type.equals(Short.TYPE)) || (type.equals(Short.class))) {
/* 327 */       return Short.valueOf(value);
/*     */     }
/* 329 */     throw new IllegalArgumentException(sm.getString("util.invalidType", new Object[] { value, type
/* 330 */       .getName() }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static List<DecoderEntry> getDecoders(List<Class<? extends Decoder>> decoderClazzes)
/*     */     throws DeploymentException
/*     */   {
/* 350 */     return getDecoders(decoderClazzes, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<DecoderEntry> getDecoders(List<Class<? extends Decoder>> decoderClazzes, InstanceManager instanceManager)
/*     */     throws DeploymentException
/*     */   {
/* 368 */     List<DecoderEntry> result = new ArrayList();
/* 369 */     if (decoderClazzes != null) {
/* 370 */       for (Class<? extends Decoder> decoderClazz : decoderClazzes)
/*     */       {
/*     */         try
/*     */         {
/*     */           Decoder instance;
/* 375 */           if (instanceManager == null) {
/* 376 */             instance = (Decoder)decoderClazz.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */           } else {
/* 378 */             Decoder instance = (Decoder)instanceManager.newInstance(decoderClazz);
/*     */             
/* 380 */             instanceManager.destroyInstance(instance);
/*     */           }
/*     */         }
/*     */         catch (ReflectiveOperationException|IllegalArgumentException|SecurityException|NamingException e)
/*     */         {
/* 385 */           throw new DeploymentException(sm.getString("pojoMethodMapping.invalidDecoder", new Object[] {decoderClazz.getName() }), e); }
/*     */         Decoder instance;
/* 387 */         DecoderEntry entry = new DecoderEntry(getDecoderType(decoderClazz), decoderClazz);
/* 388 */         result.add(entry);
/*     */       }
/*     */     }
/*     */     
/* 392 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Set<MessageHandlerResult> getMessageHandlers(Class<?> target, MessageHandler listener, EndpointConfig endpointConfig, Session session)
/*     */   {
/* 401 */     Set<MessageHandlerResult> results = new HashSet(2);
/*     */     
/*     */ 
/*     */ 
/* 405 */     if (String.class.isAssignableFrom(target)) {
/* 406 */       MessageHandlerResult result = new MessageHandlerResult(listener, MessageHandlerResultType.TEXT);
/*     */       
/*     */ 
/* 409 */       results.add(result);
/* 410 */     } else if (ByteBuffer.class.isAssignableFrom(target)) {
/* 411 */       MessageHandlerResult result = new MessageHandlerResult(listener, MessageHandlerResultType.BINARY);
/*     */       
/*     */ 
/* 414 */       results.add(result);
/* 415 */     } else if (PongMessage.class.isAssignableFrom(target)) {
/* 416 */       MessageHandlerResult result = new MessageHandlerResult(listener, MessageHandlerResultType.PONG);
/*     */       
/*     */ 
/* 419 */       results.add(result);
/*     */ 
/*     */     }
/* 422 */     else if (byte[].class.isAssignableFrom(target)) {
/* 423 */       boolean whole = MessageHandler.Whole.class.isAssignableFrom(listener.getClass());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 431 */       MessageHandlerResult result = new MessageHandlerResult(whole ? new PojoMessageHandlerWholeBinary(listener, getOnMessageMethod(listener), session, endpointConfig, matchDecoders(target, endpointConfig, true, ((WsSession)session).getInstanceManager()), new Object[1], 0, true, -1, false, -1L) : new PojoMessageHandlerPartialBinary(listener, getOnMessagePartialMethod(listener), session, new Object[2], 0, true, 1, -1, -1L), MessageHandlerResultType.BINARY);
/*     */       
/*     */ 
/* 434 */       results.add(result);
/* 435 */     } else if (InputStream.class.isAssignableFrom(target))
/*     */     {
/*     */ 
/*     */ 
/* 439 */       MessageHandlerResult result = new MessageHandlerResult(new PojoMessageHandlerWholeBinary(listener, getOnMessageMethod(listener), session, endpointConfig, matchDecoders(target, endpointConfig, true, ((WsSession)session).getInstanceManager()), new Object[1], 0, true, -1, true, -1L), MessageHandlerResultType.BINARY);
/*     */       
/*     */ 
/* 442 */       results.add(result);
/* 443 */     } else if (Reader.class.isAssignableFrom(target))
/*     */     {
/*     */ 
/*     */ 
/* 447 */       MessageHandlerResult result = new MessageHandlerResult(new PojoMessageHandlerWholeText(listener, getOnMessageMethod(listener), session, endpointConfig, matchDecoders(target, endpointConfig, false, ((WsSession)session).getInstanceManager()), new Object[1], 0, true, -1, -1L), MessageHandlerResultType.TEXT);
/*     */       
/*     */ 
/* 450 */       results.add(result);
/*     */     }
/*     */     else
/*     */     {
/* 454 */       DecoderMatch decoderMatch = matchDecoders(target, endpointConfig, ((WsSession)session)
/* 455 */         .getInstanceManager());
/* 456 */       Method m = getOnMessageMethod(listener);
/* 457 */       if (decoderMatch.getBinaryDecoders().size() > 0)
/*     */       {
/*     */ 
/*     */ 
/* 461 */         MessageHandlerResult result = new MessageHandlerResult(new PojoMessageHandlerWholeBinary(listener, m, session, endpointConfig, decoderMatch.getBinaryDecoders(), new Object[1], 0, false, -1, false, -1L), MessageHandlerResultType.BINARY);
/*     */         
/*     */ 
/* 464 */         results.add(result);
/*     */       }
/* 466 */       if (decoderMatch.getTextDecoders().size() > 0)
/*     */       {
/*     */ 
/*     */ 
/* 470 */         MessageHandlerResult result = new MessageHandlerResult(new PojoMessageHandlerWholeText(listener, m, session, endpointConfig, decoderMatch.getTextDecoders(), new Object[1], 0, false, -1, -1L), MessageHandlerResultType.TEXT);
/*     */         
/*     */ 
/* 473 */         results.add(result);
/*     */       }
/*     */     }
/*     */     
/* 477 */     if (results.size() == 0)
/*     */     {
/* 479 */       throw new IllegalArgumentException(sm.getString("wsSession.unknownHandler", new Object[] { listener, target }));
/*     */     }
/*     */     
/* 482 */     return results;
/*     */   }
/*     */   
/*     */   private static List<Class<? extends Decoder>> matchDecoders(Class<?> target, EndpointConfig endpointConfig, boolean binary, InstanceManager instanceManager)
/*     */   {
/* 487 */     DecoderMatch decoderMatch = matchDecoders(target, endpointConfig, instanceManager);
/* 488 */     if (binary) {
/* 489 */       if (decoderMatch.getBinaryDecoders().size() > 0) {
/* 490 */         return decoderMatch.getBinaryDecoders();
/*     */       }
/* 492 */     } else if (decoderMatch.getTextDecoders().size() > 0) {
/* 493 */       return decoderMatch.getTextDecoders();
/*     */     }
/* 495 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private static DecoderMatch matchDecoders(Class<?> target, EndpointConfig endpointConfig, InstanceManager instanceManager)
/*     */   {
/*     */     try
/*     */     {
/* 503 */       List<Class<? extends Decoder>> decoders = endpointConfig.getDecoders();
/* 504 */       List<DecoderEntry> decoderEntries = getDecoders(decoders, instanceManager);
/* 505 */       decoderMatch = new DecoderMatch(target, decoderEntries);
/*     */     } catch (DeploymentException e) { DecoderMatch decoderMatch;
/* 507 */       throw new IllegalArgumentException(e); }
/*     */     DecoderMatch decoderMatch;
/* 509 */     return decoderMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void parseExtensionHeader(List<Extension> extensions, String header)
/*     */   {
/* 530 */     String[] unparsedExtensions = header.split(",");
/* 531 */     for (String unparsedExtension : unparsedExtensions)
/*     */     {
/*     */ 
/* 534 */       String[] unparsedParameters = unparsedExtension.split(";");
/* 535 */       WsExtension extension = new WsExtension(unparsedParameters[0].trim());
/*     */       
/* 537 */       for (int i = 1; i < unparsedParameters.length; i++) {
/* 538 */         int equalsPos = unparsedParameters[i].indexOf('=');
/*     */         String value;
/*     */         String name;
/* 541 */         String value; if (equalsPos == -1) {
/* 542 */           String name = unparsedParameters[i].trim();
/* 543 */           value = null;
/*     */         } else {
/* 545 */           name = unparsedParameters[i].substring(0, equalsPos).trim();
/* 546 */           value = unparsedParameters[i].substring(equalsPos + 1).trim();
/* 547 */           int len = value.length();
/* 548 */           if ((len > 1) && 
/* 549 */             (value.charAt(0) == '"') && (value.charAt(len - 1) == '"')) {
/* 550 */             value = value.substring(1, value.length() - 1);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 556 */         if ((containsDelims(name)) || (containsDelims(value))) {
/* 557 */           throw new IllegalArgumentException(sm.getString("util.notToken", new Object[] { name, value }));
/*     */         }
/*     */         
/* 560 */         if ((value != null) && (
/* 561 */           (value.indexOf(',') > -1) || (value.indexOf(';') > -1) || 
/* 562 */           (value.indexOf('"') > -1) || (value.indexOf('=') > -1))) {
/* 563 */           throw new IllegalArgumentException(sm.getString("", new Object[] { value }));
/*     */         }
/* 565 */         extension.addParameter(new WsExtensionParameter(name, value));
/*     */       }
/* 567 */       extensions.add(extension);
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean containsDelims(String input)
/*     */   {
/* 573 */     if ((input == null) || (input.length() == 0)) {
/* 574 */       return false;
/*     */     }
/* 576 */     for (char c : input.toCharArray()) {
/* 577 */       switch (c) {
/*     */       case '"': 
/*     */       case ',': 
/*     */       case ';': 
/*     */       case '=': 
/* 582 */         return true;
/*     */       }
/*     */       
/*     */     }
/*     */     
/*     */ 
/* 588 */     return false;
/*     */   }
/*     */   
/*     */   private static Method getOnMessageMethod(MessageHandler listener) {
/*     */     try {
/* 593 */       return listener.getClass().getMethod("onMessage", new Class[] { Object.class });
/*     */     }
/*     */     catch (NoSuchMethodException|SecurityException e) {
/* 596 */       throw new IllegalArgumentException(sm.getString("util.invalidMessageHandler"), e);
/*     */     }
/*     */   }
/*     */   
/*     */   private static Method getOnMessagePartialMethod(MessageHandler listener) {
/*     */     try {
/* 602 */       return listener.getClass().getMethod("onMessage", new Class[] { Object.class, Boolean.TYPE });
/*     */     }
/*     */     catch (NoSuchMethodException|SecurityException e) {
/* 605 */       throw new IllegalArgumentException(sm.getString("util.invalidMessageHandler"), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class DecoderMatch
/*     */   {
/* 612 */     private final List<Class<? extends Decoder>> textDecoders = new ArrayList();
/*     */     
/* 614 */     private final List<Class<? extends Decoder>> binaryDecoders = new ArrayList();
/*     */     private final Class<?> target;
/*     */     
/*     */     public DecoderMatch(Class<?> target, List<DecoderEntry> decoderEntries)
/*     */     {
/* 619 */       this.target = target;
/* 620 */       for (DecoderEntry decoderEntry : decoderEntries) {
/* 621 */         if (decoderEntry.getClazz().isAssignableFrom(target)) {
/* 622 */           if (Decoder.Binary.class.isAssignableFrom(decoderEntry
/* 623 */             .getDecoderClazz())) {
/* 624 */             this.binaryDecoders.add(decoderEntry.getDecoderClazz());
/*     */           }
/*     */           else
/*     */           {
/* 628 */             if (Decoder.BinaryStream.class.isAssignableFrom(decoderEntry
/* 629 */               .getDecoderClazz())) {
/* 630 */               this.binaryDecoders.add(decoderEntry.getDecoderClazz());
/*     */               
/*     */ 
/* 633 */               break; }
/* 634 */             if (Decoder.Text.class.isAssignableFrom(decoderEntry
/* 635 */               .getDecoderClazz())) {
/* 636 */               this.textDecoders.add(decoderEntry.getDecoderClazz());
/*     */             }
/*     */             else
/*     */             {
/* 640 */               if (Decoder.TextStream.class.isAssignableFrom(decoderEntry
/* 641 */                 .getDecoderClazz())) {
/* 642 */                 this.textDecoders.add(decoderEntry.getDecoderClazz());
/*     */                 
/*     */ 
/* 645 */                 break;
/*     */               }
/*     */               
/* 648 */               throw new IllegalArgumentException(Util.sm.getString("util.unknownDecoderType"));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public List<Class<? extends Decoder>> getTextDecoders() {
/* 656 */       return this.textDecoders;
/*     */     }
/*     */     
/*     */     public List<Class<? extends Decoder>> getBinaryDecoders()
/*     */     {
/* 661 */       return this.binaryDecoders;
/*     */     }
/*     */     
/*     */     public Class<?> getTarget()
/*     */     {
/* 666 */       return this.target;
/*     */     }
/*     */     
/*     */     public boolean hasMatches()
/*     */     {
/* 671 */       return (this.textDecoders.size() > 0) || (this.binaryDecoders.size() > 0);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class TypeResult
/*     */   {
/*     */     private final Class<?> clazz;
/*     */     private final int index;
/*     */     private int dimension;
/*     */     
/*     */     public TypeResult(Class<?> clazz, int index, int dimension) {
/* 682 */       this.clazz = clazz;
/* 683 */       this.index = index;
/* 684 */       this.dimension = dimension;
/*     */     }
/*     */     
/*     */     public Class<?> getClazz() {
/* 688 */       return this.clazz;
/*     */     }
/*     */     
/*     */     public int getIndex() {
/* 692 */       return this.index;
/*     */     }
/*     */     
/*     */     public int getDimension() {
/* 696 */       return this.dimension;
/*     */     }
/*     */     
/*     */     public void incrementDimension(int inc) {
/* 700 */       this.dimension += inc;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */