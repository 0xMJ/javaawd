/*     */ package org.apache.tomcat.websocket;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Map;
/*     */ import org.apache.tomcat.util.security.MD5Encoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DigestAuthenticator
/*     */   extends Authenticator
/*     */ {
/*     */   public static final String schemeName = "digest";
/*  33 */   private static final Object cnonceGeneratorLock = new Object();
/*     */   private static volatile SecureRandom cnonceGenerator;
/*  35 */   private int nonceCount = 0;
/*     */   
/*     */   private long cNonce;
/*     */   
/*     */   public String getAuthorization(String requestUri, String WWWAuthenticate, Map<String, Object> userProperties)
/*     */     throws AuthenticationException
/*     */   {
/*  42 */     String userName = (String)userProperties.get("org.apache.tomcat.websocket.WS_AUTHENTICATION_USER_NAME");
/*  43 */     String password = (String)userProperties.get("org.apache.tomcat.websocket.WS_AUTHENTICATION_PASSWORD");
/*     */     
/*  45 */     if ((userName == null) || (password == null)) {
/*  46 */       throw new AuthenticationException("Failed to perform Digest authentication due to  missing user/password");
/*     */     }
/*     */     
/*     */ 
/*  50 */     Map<String, String> wwwAuthenticate = parseWWWAuthenticateHeader(WWWAuthenticate);
/*     */     
/*  52 */     String realm = (String)wwwAuthenticate.get("realm");
/*  53 */     String nonce = (String)wwwAuthenticate.get("nonce");
/*  54 */     String messageQop = (String)wwwAuthenticate.get("qop");
/*     */     
/*  56 */     String algorithm = wwwAuthenticate.get("algorithm") == null ? "MD5" : (String)wwwAuthenticate.get("algorithm");
/*  57 */     String opaque = (String)wwwAuthenticate.get("opaque");
/*     */     
/*  59 */     StringBuilder challenge = new StringBuilder();
/*     */     
/*  61 */     if (!messageQop.isEmpty()) {
/*  62 */       if (cnonceGenerator == null) {
/*  63 */         synchronized (cnonceGeneratorLock) {
/*  64 */           if (cnonceGenerator == null) {
/*  65 */             cnonceGenerator = new SecureRandom();
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*  70 */       this.cNonce = cnonceGenerator.nextLong();
/*  71 */       this.nonceCount += 1;
/*     */     }
/*     */     
/*  74 */     challenge.append("Digest ");
/*  75 */     challenge.append("username =\"" + userName + "\",");
/*  76 */     challenge.append("realm=\"" + realm + "\",");
/*  77 */     challenge.append("nonce=\"" + nonce + "\",");
/*  78 */     challenge.append("uri=\"" + requestUri + "\",");
/*     */     try
/*     */     {
/*  81 */       challenge.append("response=\"" + calculateRequestDigest(requestUri, userName, password, realm, nonce, messageQop, algorithm) + "\",");
/*     */ 
/*     */     }
/*     */     catch (NoSuchAlgorithmException e)
/*     */     {
/*     */ 
/*  87 */       throw new AuthenticationException("Unable to generate request digest " + e.getMessage());
/*     */     }
/*     */     
/*  90 */     challenge.append("algorithm=" + algorithm + ",");
/*  91 */     challenge.append("opaque=\"" + opaque + "\",");
/*     */     
/*  93 */     if (!messageQop.isEmpty()) {
/*  94 */       challenge.append("qop=\"" + messageQop + "\"");
/*  95 */       challenge.append(",cnonce=\"" + this.cNonce + "\",");
/*  96 */       challenge.append("nc=" + String.format("%08X", new Object[] { Integer.valueOf(this.nonceCount) }));
/*     */     }
/*     */     
/*  99 */     return challenge.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String calculateRequestDigest(String requestUri, String userName, String password, String realm, String nonce, String qop, String algorithm)
/*     */     throws NoSuchAlgorithmException
/*     */   {
/* 107 */     StringBuilder preDigest = new StringBuilder();
/*     */     String A1;
/*     */     String A1;
/* 110 */     if (algorithm.equalsIgnoreCase("MD5")) {
/* 111 */       A1 = userName + ":" + realm + ":" + password;
/*     */     } else {
/* 113 */       A1 = encodeMD5(new StringBuilder().append(userName).append(":").append(realm).append(":").append(password).toString()) + ":" + nonce + ":" + this.cNonce;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */     String A2 = "GET:" + requestUri;
/*     */     
/* 123 */     preDigest.append(encodeMD5(A1));
/* 124 */     preDigest.append(':');
/* 125 */     preDigest.append(nonce);
/*     */     
/* 127 */     if (qop.toLowerCase().contains("auth")) {
/* 128 */       preDigest.append(':');
/* 129 */       preDigest.append(String.format("%08X", new Object[] { Integer.valueOf(this.nonceCount) }));
/* 130 */       preDigest.append(':');
/* 131 */       preDigest.append(String.valueOf(this.cNonce));
/* 132 */       preDigest.append(':');
/* 133 */       preDigest.append(qop);
/*     */     }
/*     */     
/* 136 */     preDigest.append(':');
/* 137 */     preDigest.append(encodeMD5(A2));
/*     */     
/* 139 */     return encodeMD5(preDigest.toString());
/*     */   }
/*     */   
/*     */   private String encodeMD5(String value) throws NoSuchAlgorithmException
/*     */   {
/* 144 */     byte[] bytesOfMessage = value.getBytes(StandardCharsets.ISO_8859_1);
/* 145 */     MessageDigest md = MessageDigest.getInstance("MD5");
/* 146 */     byte[] thedigest = md.digest(bytesOfMessage);
/*     */     
/* 148 */     return MD5Encoder.encode(thedigest);
/*     */   }
/*     */   
/*     */   public String getSchemeName()
/*     */   {
/* 153 */     return "digest";
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\DigestAuthenticator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */