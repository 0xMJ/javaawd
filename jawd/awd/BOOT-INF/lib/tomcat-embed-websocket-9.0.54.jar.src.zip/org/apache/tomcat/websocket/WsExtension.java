/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.websocket.Extension;
/*    */ import javax.websocket.Extension.Parameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsExtension
/*    */   implements Extension
/*    */ {
/*    */   private final String name;
/* 27 */   private final List<Extension.Parameter> parameters = new ArrayList();
/*    */   
/*    */   WsExtension(String name) {
/* 30 */     this.name = name;
/*    */   }
/*    */   
/*    */   void addParameter(Extension.Parameter parameter) {
/* 34 */     this.parameters.add(parameter);
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 39 */     return this.name;
/*    */   }
/*    */   
/*    */   public List<Extension.Parameter> getParameters()
/*    */   {
/* 44 */     return this.parameters;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\WsExtension.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */