/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import aQute.bnd.annotation.spi.ServiceProvider;
/*    */ import javax.websocket.ContainerProvider;
/*    */ import javax.websocket.WebSocketContainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ServiceProvider(ContainerProvider.class)
/*    */ public class WsContainerProvider
/*    */   extends ContainerProvider
/*    */ {
/*    */   protected WebSocketContainer getContainer()
/*    */   {
/* 27 */     return new WsWebSocketContainer();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\WsContainerProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */