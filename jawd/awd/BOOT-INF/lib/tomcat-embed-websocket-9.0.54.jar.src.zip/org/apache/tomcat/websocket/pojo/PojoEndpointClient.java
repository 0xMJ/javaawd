/*    */ package org.apache.tomcat.websocket.pojo;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import javax.websocket.Decoder;
/*    */ import javax.websocket.DeploymentException;
/*    */ import javax.websocket.EndpointConfig;
/*    */ import javax.websocket.Session;
/*    */ import org.apache.tomcat.InstanceManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PojoEndpointClient
/*    */   extends PojoEndpointBase
/*    */ {
/*    */   @Deprecated
/*    */   public PojoEndpointClient(Object pojo, List<Class<? extends Decoder>> decoders)
/*    */     throws DeploymentException
/*    */   {
/* 39 */     super(Collections.emptyMap());
/* 40 */     setPojo(pojo);
/* 41 */     setMethodMapping(new PojoMethodMapping(pojo.getClass(), decoders, null));
/*    */   }
/*    */   
/*    */   public PojoEndpointClient(Object pojo, List<Class<? extends Decoder>> decoders, InstanceManager instanceManager) throws DeploymentException {
/* 45 */     super(Collections.emptyMap());
/* 46 */     setPojo(pojo);
/* 47 */     setMethodMapping(new PojoMethodMapping(pojo.getClass(), decoders, null, instanceManager));
/*    */   }
/*    */   
/*    */   public void onOpen(Session session, EndpointConfig config)
/*    */   {
/* 52 */     doOnOpen(session, config);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\pojo\PojoEndpointClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */