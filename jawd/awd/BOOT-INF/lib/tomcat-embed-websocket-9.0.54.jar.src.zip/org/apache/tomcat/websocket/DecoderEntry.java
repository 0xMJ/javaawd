/*    */ package org.apache.tomcat.websocket;
/*    */ 
/*    */ import javax.websocket.Decoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecoderEntry
/*    */ {
/*    */   private final Class<?> clazz;
/*    */   private final Class<? extends Decoder> decoderClazz;
/*    */   
/*    */   public DecoderEntry(Class<?> clazz, Class<? extends Decoder> decoderClazz)
/*    */   {
/* 28 */     this.clazz = clazz;
/* 29 */     this.decoderClazz = decoderClazz;
/*    */   }
/*    */   
/*    */   public Class<?> getClazz() {
/* 33 */     return this.clazz;
/*    */   }
/*    */   
/*    */   public Class<? extends Decoder> getDecoderClazz() {
/* 37 */     return this.decoderClazz;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\DecoderEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */