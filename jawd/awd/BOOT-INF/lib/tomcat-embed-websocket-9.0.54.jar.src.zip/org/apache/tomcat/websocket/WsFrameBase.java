/*      */ package org.apache.tomcat.websocket;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.nio.Buffer;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.CharsetDecoder;
/*      */ import java.nio.charset.CoderResult;
/*      */ import java.nio.charset.CodingErrorAction;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import javax.websocket.CloseReason;
/*      */ import javax.websocket.CloseReason.CloseCodes;
/*      */ import javax.websocket.Endpoint;
/*      */ import javax.websocket.Extension;
/*      */ import javax.websocket.MessageHandler;
/*      */ import javax.websocket.MessageHandler.Partial;
/*      */ import javax.websocket.MessageHandler.Whole;
/*      */ import javax.websocket.PongMessage;
/*      */ import javax.websocket.RemoteEndpoint.Basic;
/*      */ import org.apache.juli.logging.Log;
/*      */ import org.apache.tomcat.util.ExceptionUtils;
/*      */ import org.apache.tomcat.util.buf.Utf8Decoder;
/*      */ import org.apache.tomcat.util.res.StringManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class WsFrameBase
/*      */ {
/*   46 */   private static final StringManager sm = StringManager.getManager(WsFrameBase.class);
/*      */   
/*      */ 
/*      */   protected final WsSession wsSession;
/*      */   
/*      */ 
/*      */   protected final ByteBuffer inputBuffer;
/*      */   
/*      */   private final Transformation transformation;
/*      */   
/*   56 */   private final ByteBuffer controlBufferBinary = ByteBuffer.allocate(125);
/*   57 */   private final CharBuffer controlBufferText = CharBuffer.allocate(125);
/*      */   
/*      */ 
/*   60 */   private final CharsetDecoder utf8DecoderControl = new Utf8Decoder()
/*   61 */     .onMalformedInput(CodingErrorAction.REPORT)
/*   62 */     .onUnmappableCharacter(CodingErrorAction.REPORT);
/*   63 */   private final CharsetDecoder utf8DecoderMessage = new Utf8Decoder()
/*   64 */     .onMalformedInput(CodingErrorAction.REPORT)
/*   65 */     .onUnmappableCharacter(CodingErrorAction.REPORT);
/*   66 */   private boolean continuationExpected = false;
/*   67 */   private boolean textMessage = false;
/*      */   
/*      */   private ByteBuffer messageBufferBinary;
/*      */   
/*      */   private CharBuffer messageBufferText;
/*   72 */   private MessageHandler binaryMsgHandler = null;
/*   73 */   private MessageHandler textMsgHandler = null;
/*      */   
/*      */ 
/*   76 */   private boolean fin = false;
/*   77 */   private int rsv = 0;
/*   78 */   private byte opCode = 0;
/*   79 */   private final byte[] mask = new byte[4];
/*   80 */   private int maskIndex = 0;
/*   81 */   private long payloadLength = 0L;
/*   82 */   private volatile long payloadWritten = 0L;
/*      */   
/*      */ 
/*   85 */   private volatile State state = State.NEW_FRAME;
/*   86 */   private volatile boolean open = true;
/*      */   
/*      */ 
/*   89 */   private static final AtomicReferenceFieldUpdater<WsFrameBase, ReadState> READ_STATE_UPDATER = AtomicReferenceFieldUpdater.newUpdater(WsFrameBase.class, ReadState.class, "readState");
/*   90 */   private volatile ReadState readState = ReadState.WAITING;
/*      */   
/*      */   public WsFrameBase(WsSession wsSession, Transformation transformation) {
/*   93 */     this.inputBuffer = ByteBuffer.allocate(Constants.DEFAULT_BUFFER_SIZE);
/*   94 */     this.inputBuffer.position(0).limit(0);
/*   95 */     this.messageBufferBinary = ByteBuffer.allocate(wsSession.getMaxBinaryMessageBufferSize());
/*   96 */     this.messageBufferText = CharBuffer.allocate(wsSession.getMaxTextMessageBufferSize());
/*   97 */     wsSession.setWsFrame(this);
/*   98 */     this.wsSession = wsSession;
/*      */     Transformation finalTransformation;
/*  100 */     Transformation finalTransformation; if (isMasked()) {
/*  101 */       finalTransformation = new UnmaskTransformation(null);
/*      */     } else {
/*  103 */       finalTransformation = new NoopTransformation(null);
/*      */     }
/*  105 */     if (transformation == null) {
/*  106 */       this.transformation = finalTransformation;
/*      */     } else {
/*  108 */       transformation.setNext(finalTransformation);
/*  109 */       this.transformation = transformation;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void processInputBuffer() throws IOException
/*      */   {
/*  115 */     while (!isSuspended()) {
/*  116 */       this.wsSession.updateLastActiveRead();
/*  117 */       if (this.state == State.NEW_FRAME) {
/*  118 */         if (!processInitialHeader()) {
/*      */           break;
/*      */         }
/*      */         
/*      */ 
/*  123 */         if (!this.open) {
/*  124 */           throw new IOException(sm.getString("wsFrame.closed"));
/*      */         }
/*      */       }
/*  127 */       if ((this.state != State.PARTIAL_HEADER) || 
/*  128 */         (processRemainingHeader()))
/*      */       {
/*      */ 
/*      */ 
/*  132 */         if ((this.state == State.DATA) && 
/*  133 */           (!processData())) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean processInitialHeader()
/*      */     throws IOException
/*      */   {
/*  147 */     if (this.inputBuffer.remaining() < 2) {
/*  148 */       return false;
/*      */     }
/*  150 */     int b = this.inputBuffer.get();
/*  151 */     this.fin = ((b & 0x80) != 0);
/*  152 */     this.rsv = ((b & 0x70) >>> 4);
/*  153 */     this.opCode = ((byte)(b & 0xF));
/*  154 */     if (!this.transformation.validateRsv(this.rsv, this.opCode))
/*      */     {
/*      */ 
/*  157 */       throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.wrongRsv", new Object[] {Integer.valueOf(this.rsv), Integer.valueOf(this.opCode) })));
/*      */     }
/*      */     
/*  160 */     if (Util.isControl(this.opCode)) {
/*  161 */       if (!this.fin)
/*      */       {
/*      */ 
/*  164 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.controlFragmented")));
/*      */       }
/*  166 */       if ((this.opCode != 9) && (this.opCode != 10) && (this.opCode != 8))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  171 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.invalidOpCode", new Object[] {Integer.valueOf(this.opCode) })));
/*      */       }
/*      */     } else {
/*  174 */       if (this.continuationExpected) {
/*  175 */         if (!Util.isContinuation(this.opCode))
/*      */         {
/*      */ 
/*  178 */           throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.noContinuation")));
/*      */         }
/*      */       } else {
/*      */         try {
/*  182 */           if (this.opCode == 2)
/*      */           {
/*  184 */             this.textMessage = false;
/*  185 */             int size = this.wsSession.getMaxBinaryMessageBufferSize();
/*  186 */             if (size != this.messageBufferBinary.capacity()) {
/*  187 */               this.messageBufferBinary = ByteBuffer.allocate(size);
/*      */             }
/*  189 */             this.binaryMsgHandler = this.wsSession.getBinaryMessageHandler();
/*  190 */             this.textMsgHandler = null;
/*  191 */           } else if (this.opCode == 1)
/*      */           {
/*  193 */             this.textMessage = true;
/*  194 */             int size = this.wsSession.getMaxTextMessageBufferSize();
/*  195 */             if (size != this.messageBufferText.capacity()) {
/*  196 */               this.messageBufferText = CharBuffer.allocate(size);
/*      */             }
/*  198 */             this.binaryMsgHandler = null;
/*  199 */             this.textMsgHandler = this.wsSession.getTextMessageHandler();
/*      */           }
/*      */           else
/*      */           {
/*  203 */             throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.invalidOpCode", new Object[] {Integer.valueOf(this.opCode) })));
/*      */           }
/*      */           
/*      */         }
/*      */         catch (IllegalStateException ise)
/*      */         {
/*  209 */           throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.sessionClosed")));
/*      */         }
/*      */       }
/*  212 */       this.continuationExpected = (!this.fin);
/*      */     }
/*  214 */     b = this.inputBuffer.get();
/*      */     
/*  216 */     if (((b & 0x80) == 0) && (isMasked()))
/*      */     {
/*      */ 
/*  219 */       throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.notMasked")));
/*      */     }
/*  221 */     this.payloadLength = (b & 0x7F);
/*  222 */     this.state = State.PARTIAL_HEADER;
/*  223 */     if (getLog().isDebugEnabled()) {
/*  224 */       getLog().debug(sm.getString("wsFrame.partialHeaderComplete", new Object[] { Boolean.toString(this.fin), 
/*  225 */         Integer.toString(this.rsv), Integer.toString(this.opCode), Long.toString(this.payloadLength) }));
/*      */     }
/*  227 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   protected abstract boolean isMasked();
/*      */   
/*      */ 
/*      */   protected abstract Log getLog();
/*      */   
/*      */ 
/*      */   private boolean processRemainingHeader()
/*      */     throws IOException
/*      */   {
/*      */     int headerLength;
/*      */     int headerLength;
/*  242 */     if (isMasked()) {
/*  243 */       headerLength = 4;
/*      */     } else {
/*  245 */       headerLength = 0;
/*      */     }
/*      */     
/*  248 */     if (this.payloadLength == 126L) {
/*  249 */       headerLength += 2;
/*  250 */     } else if (this.payloadLength == 127L) {
/*  251 */       headerLength += 8;
/*      */     }
/*  253 */     if (this.inputBuffer.remaining() < headerLength) {
/*  254 */       return false;
/*      */     }
/*      */     
/*  257 */     if (this.payloadLength == 126L) {
/*  258 */       this.payloadLength = byteArrayToLong(this.inputBuffer.array(), this.inputBuffer
/*  259 */         .arrayOffset() + this.inputBuffer.position(), 2);
/*  260 */       this.inputBuffer.position(this.inputBuffer.position() + 2);
/*  261 */     } else if (this.payloadLength == 127L) {
/*  262 */       this.payloadLength = byteArrayToLong(this.inputBuffer.array(), this.inputBuffer
/*  263 */         .arrayOffset() + this.inputBuffer.position(), 8);
/*      */       
/*      */ 
/*      */ 
/*  267 */       if (this.payloadLength < 0L)
/*      */       {
/*  269 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.payloadMsbInvalid")));
/*      */       }
/*  271 */       this.inputBuffer.position(this.inputBuffer.position() + 8);
/*      */     }
/*  273 */     if (Util.isControl(this.opCode)) {
/*  274 */       if (this.payloadLength > 125L)
/*      */       {
/*      */ 
/*  277 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.controlPayloadTooBig", new Object[] {Long.valueOf(this.payloadLength) })));
/*      */       }
/*  279 */       if (!this.fin)
/*      */       {
/*      */ 
/*  282 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.controlNoFin")));
/*      */       }
/*      */     }
/*  285 */     if (isMasked()) {
/*  286 */       this.inputBuffer.get(this.mask, 0, 4);
/*      */     }
/*  288 */     this.state = State.DATA;
/*  289 */     return true;
/*      */   }
/*      */   
/*      */   private boolean processData() throws IOException {
/*      */     boolean result;
/*      */     boolean result;
/*  295 */     if (Util.isControl(this.opCode)) {
/*  296 */       result = processDataControl(); } else { boolean result;
/*  297 */       if (this.textMessage) { boolean result;
/*  298 */         if (this.textMsgHandler == null) {
/*  299 */           result = swallowInput();
/*      */         } else
/*  301 */           result = processDataText();
/*      */       } else {
/*      */         boolean result;
/*  304 */         if (this.binaryMsgHandler == null) {
/*  305 */           result = swallowInput();
/*      */         } else
/*  307 */           result = processDataBinary();
/*      */       }
/*      */     }
/*  310 */     if (result) {
/*  311 */       updateStats(this.payloadLength);
/*      */     }
/*  313 */     checkRoomPayload();
/*  314 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void updateStats(long payloadLength) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean processDataControl()
/*      */     throws IOException
/*      */   {
/*  329 */     TransformationResult tr = this.transformation.getMoreData(this.opCode, this.fin, this.rsv, this.controlBufferBinary);
/*  330 */     if (TransformationResult.UNDERFLOW.equals(tr)) {
/*  331 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  336 */     this.controlBufferBinary.flip();
/*  337 */     if (this.opCode == 8) {
/*  338 */       this.open = false;
/*  339 */       String reason = null;
/*  340 */       int code = CloseReason.CloseCodes.NORMAL_CLOSURE.getCode();
/*  341 */       if (this.controlBufferBinary.remaining() == 1) {
/*  342 */         this.controlBufferBinary.clear();
/*      */         
/*      */ 
/*      */ 
/*  346 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.oneByteCloseCode")));
/*      */       }
/*  348 */       if (this.controlBufferBinary.remaining() > 1) {
/*  349 */         code = this.controlBufferBinary.getShort();
/*  350 */         if (this.controlBufferBinary.remaining() > 0) {
/*  351 */           CoderResult cr = this.utf8DecoderControl.decode(this.controlBufferBinary, this.controlBufferText, true);
/*      */           
/*  353 */           if (cr.isError()) {
/*  354 */             this.controlBufferBinary.clear();
/*  355 */             this.controlBufferText.clear();
/*      */             
/*      */ 
/*  358 */             throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.invalidUtf8Close")));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  363 */           this.controlBufferText.flip();
/*  364 */           reason = this.controlBufferText.toString();
/*      */         }
/*      */       }
/*  367 */       this.wsSession.onClose(new CloseReason(Util.getCloseCode(code), reason));
/*  368 */     } else if (this.opCode == 9) {
/*  369 */       if (this.wsSession.isOpen()) {
/*  370 */         this.wsSession.getBasicRemote().sendPong(this.controlBufferBinary);
/*      */       }
/*  372 */     } else if (this.opCode == 10) {
/*  373 */       MessageHandler.Whole<PongMessage> mhPong = this.wsSession.getPongMessageHandler();
/*  374 */       if (mhPong != null) {
/*      */         try {
/*  376 */           mhPong.onMessage(new WsPongMessage(this.controlBufferBinary));
/*      */         } catch (Throwable t) {
/*  378 */           handleThrowableOnSend(t);
/*      */         } finally {
/*  380 */           this.controlBufferBinary.clear();
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/*  385 */       this.controlBufferBinary.clear();
/*      */       
/*      */ 
/*  388 */       throw new WsIOException(new CloseReason(CloseReason.CloseCodes.PROTOCOL_ERROR, sm.getString("wsFrame.invalidOpCode", new Object[] {Integer.valueOf(this.opCode) })));
/*      */     }
/*  390 */     this.controlBufferBinary.clear();
/*  391 */     newFrame();
/*  392 */     return true;
/*      */   }
/*      */   
/*      */   protected void sendMessageText(boolean last)
/*      */     throws WsIOException
/*      */   {
/*  398 */     if ((this.textMsgHandler instanceof WrappedMessageHandler)) {
/*  399 */       long maxMessageSize = ((WrappedMessageHandler)this.textMsgHandler).getMaxMessageSize();
/*  400 */       if ((maxMessageSize > -1L) && (this.messageBufferText.remaining() > maxMessageSize))
/*      */       {
/*  402 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.TOO_BIG, sm.getString("wsFrame.messageTooBig", new Object[] {
/*  403 */           Long.valueOf(this.messageBufferText.remaining()), 
/*  404 */           Long.valueOf(maxMessageSize) })));
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/*  409 */       if ((this.textMsgHandler instanceof MessageHandler.Partial))
/*      */       {
/*  411 */         ((MessageHandler.Partial)this.textMsgHandler).onMessage(this.messageBufferText.toString(), last);
/*      */       }
/*      */       else
/*      */       {
/*  415 */         ((MessageHandler.Whole)this.textMsgHandler).onMessage(this.messageBufferText.toString());
/*      */       }
/*      */     } catch (Throwable t) {
/*  418 */       handleThrowableOnSend(t);
/*      */     } finally {
/*  420 */       this.messageBufferText.clear();
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean processDataText()
/*      */     throws IOException
/*      */   {
/*  427 */     TransformationResult tr = this.transformation.getMoreData(this.opCode, this.fin, this.rsv, this.messageBufferBinary);
/*  428 */     while (!TransformationResult.END_OF_FRAME.equals(tr))
/*      */     {
/*      */ 
/*  431 */       this.messageBufferBinary.flip();
/*      */       for (;;) {
/*  433 */         CoderResult cr = this.utf8DecoderMessage.decode(this.messageBufferBinary, this.messageBufferText, false);
/*      */         
/*  435 */         if (cr.isError())
/*      */         {
/*      */ 
/*  438 */           throw new WsIOException(new CloseReason(CloseReason.CloseCodes.NOT_CONSISTENT, sm.getString("wsFrame.invalidUtf8"))); }
/*  439 */         if (cr.isOverflow())
/*      */         {
/*  441 */           if (usePartial()) {
/*  442 */             this.messageBufferText.flip();
/*  443 */             sendMessageText(false);
/*  444 */             this.messageBufferText.clear();
/*      */           }
/*      */           else
/*      */           {
/*  448 */             throw new WsIOException(new CloseReason(CloseReason.CloseCodes.TOO_BIG, sm.getString("wsFrame.textMessageTooBig")));
/*      */           }
/*  450 */         } else if (cr.isUnderflow())
/*      */         {
/*  452 */           this.messageBufferBinary.compact();
/*      */           
/*      */ 
/*      */ 
/*  456 */           if (TransformationResult.OVERFLOW.equals(tr)) {
/*      */             break;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  463 */           return false;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  468 */       tr = this.transformation.getMoreData(this.opCode, this.fin, this.rsv, this.messageBufferBinary);
/*      */     }
/*      */     
/*  471 */     this.messageBufferBinary.flip();
/*  472 */     boolean last = false;
/*      */     
/*      */     for (;;)
/*      */     {
/*  476 */       CoderResult cr = this.utf8DecoderMessage.decode(this.messageBufferBinary, this.messageBufferText, last);
/*      */       
/*  478 */       if (cr.isError())
/*      */       {
/*      */ 
/*  481 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.NOT_CONSISTENT, sm.getString("wsFrame.invalidUtf8"))); }
/*  482 */       if (cr.isOverflow())
/*      */       {
/*  484 */         if (usePartial()) {
/*  485 */           this.messageBufferText.flip();
/*  486 */           sendMessageText(false);
/*  487 */           this.messageBufferText.clear();
/*      */         }
/*      */         else
/*      */         {
/*  491 */           throw new WsIOException(new CloseReason(CloseReason.CloseCodes.TOO_BIG, sm.getString("wsFrame.textMessageTooBig")));
/*      */         }
/*  493 */       } else if ((cr.isUnderflow()) && (!last))
/*      */       {
/*      */ 
/*  496 */         if (this.continuationExpected)
/*      */         {
/*      */ 
/*  499 */           if (usePartial()) {
/*  500 */             this.messageBufferText.flip();
/*  501 */             sendMessageText(false);
/*  502 */             this.messageBufferText.clear();
/*      */           }
/*  504 */           this.messageBufferBinary.compact();
/*  505 */           newFrame();
/*      */           
/*  507 */           return true;
/*      */         }
/*      */         
/*  510 */         last = true;
/*      */       }
/*      */       else
/*      */       {
/*  514 */         this.messageBufferText.flip();
/*  515 */         sendMessageText(true);
/*      */         
/*  517 */         newMessage();
/*  518 */         return true;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean processDataBinary()
/*      */     throws IOException
/*      */   {
/*  526 */     TransformationResult tr = this.transformation.getMoreData(this.opCode, this.fin, this.rsv, this.messageBufferBinary);
/*  527 */     while (!TransformationResult.END_OF_FRAME.equals(tr))
/*      */     {
/*  529 */       if (TransformationResult.UNDERFLOW.equals(tr))
/*      */       {
/*  531 */         return false;
/*      */       }
/*      */       
/*      */ 
/*  535 */       if (!usePartial())
/*      */       {
/*  537 */         CloseReason cr = new CloseReason(CloseReason.CloseCodes.TOO_BIG, sm.getString("wsFrame.bufferTooSmall", new Object[] {
/*  538 */           Integer.valueOf(this.messageBufferBinary.capacity()), 
/*  539 */           Long.valueOf(this.payloadLength) }));
/*  540 */         throw new WsIOException(cr);
/*      */       }
/*  542 */       this.messageBufferBinary.flip();
/*  543 */       ByteBuffer copy = ByteBuffer.allocate(this.messageBufferBinary.limit());
/*  544 */       copy.put(this.messageBufferBinary);
/*  545 */       copy.flip();
/*  546 */       sendMessageBinary(copy, false);
/*  547 */       this.messageBufferBinary.clear();
/*      */       
/*  549 */       tr = this.transformation.getMoreData(this.opCode, this.fin, this.rsv, this.messageBufferBinary);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  556 */     if ((usePartial()) || (!this.continuationExpected)) {
/*  557 */       this.messageBufferBinary.flip();
/*  558 */       ByteBuffer copy = ByteBuffer.allocate(this.messageBufferBinary.limit());
/*  559 */       copy.put(this.messageBufferBinary);
/*  560 */       copy.flip();
/*  561 */       sendMessageBinary(copy, !this.continuationExpected);
/*  562 */       this.messageBufferBinary.clear();
/*      */     }
/*      */     
/*  565 */     if (this.continuationExpected)
/*      */     {
/*  567 */       newFrame();
/*      */     }
/*      */     else {
/*  570 */       newMessage();
/*      */     }
/*      */     
/*  573 */     return true;
/*      */   }
/*      */   
/*      */   private void handleThrowableOnSend(Throwable t) throws WsIOException
/*      */   {
/*  578 */     ExceptionUtils.handleThrowable(t);
/*  579 */     this.wsSession.getLocal().onError(this.wsSession, t);
/*      */     
/*  581 */     CloseReason cr = new CloseReason(CloseReason.CloseCodes.CLOSED_ABNORMALLY, sm.getString("wsFrame.ioeTriggeredClose"));
/*  582 */     throw new WsIOException(cr);
/*      */   }
/*      */   
/*      */   protected void sendMessageBinary(ByteBuffer msg, boolean last)
/*      */     throws WsIOException
/*      */   {
/*  588 */     if ((this.binaryMsgHandler instanceof WrappedMessageHandler)) {
/*  589 */       long maxMessageSize = ((WrappedMessageHandler)this.binaryMsgHandler).getMaxMessageSize();
/*  590 */       if ((maxMessageSize > -1L) && (msg.remaining() > maxMessageSize))
/*      */       {
/*  592 */         throw new WsIOException(new CloseReason(CloseReason.CloseCodes.TOO_BIG, sm.getString("wsFrame.messageTooBig", new Object[] {
/*  593 */           Long.valueOf(msg.remaining()), 
/*  594 */           Long.valueOf(maxMessageSize) })));
/*      */       }
/*      */     }
/*      */     try {
/*  598 */       if ((this.binaryMsgHandler instanceof MessageHandler.Partial)) {
/*  599 */         ((MessageHandler.Partial)this.binaryMsgHandler).onMessage(msg, last);
/*      */       }
/*      */       else {
/*  602 */         ((MessageHandler.Whole)this.binaryMsgHandler).onMessage(msg);
/*      */       }
/*      */     } catch (Throwable t) {
/*  605 */       handleThrowableOnSend(t);
/*      */     }
/*      */   }
/*      */   
/*      */   private void newMessage()
/*      */   {
/*  611 */     this.messageBufferBinary.clear();
/*  612 */     this.messageBufferText.clear();
/*  613 */     this.utf8DecoderMessage.reset();
/*  614 */     this.continuationExpected = false;
/*  615 */     newFrame();
/*      */   }
/*      */   
/*      */   private void newFrame()
/*      */   {
/*  620 */     if (this.inputBuffer.remaining() == 0) {
/*  621 */       this.inputBuffer.position(0).limit(0);
/*      */     }
/*      */     
/*  624 */     this.maskIndex = 0;
/*  625 */     this.payloadWritten = 0L;
/*  626 */     this.state = State.NEW_FRAME;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  631 */     checkRoomHeaders();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void checkRoomHeaders()
/*      */   {
/*  638 */     if (this.inputBuffer.capacity() - this.inputBuffer.position() < 131)
/*      */     {
/*  640 */       makeRoom();
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkRoomPayload()
/*      */   {
/*  646 */     if (this.inputBuffer.capacity() - this.inputBuffer.position() - this.payloadLength + this.payloadWritten < 0L) {
/*  647 */       makeRoom();
/*      */     }
/*      */   }
/*      */   
/*      */   private void makeRoom()
/*      */   {
/*  653 */     this.inputBuffer.compact();
/*  654 */     this.inputBuffer.flip();
/*      */   }
/*      */   
/*      */   private boolean usePartial()
/*      */   {
/*  659 */     if (Util.isControl(this.opCode))
/*  660 */       return false;
/*  661 */     if (this.textMessage) {
/*  662 */       return this.textMsgHandler instanceof MessageHandler.Partial;
/*      */     }
/*      */     
/*  665 */     return this.binaryMsgHandler instanceof MessageHandler.Partial;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean swallowInput()
/*      */   {
/*  671 */     long toSkip = Math.min(this.payloadLength - this.payloadWritten, this.inputBuffer.remaining());
/*  672 */     this.inputBuffer.position(this.inputBuffer.position() + (int)toSkip);
/*  673 */     this.payloadWritten += toSkip;
/*  674 */     if (this.payloadWritten == this.payloadLength) {
/*  675 */       if (this.continuationExpected) {
/*  676 */         newFrame();
/*      */       } else {
/*  678 */         newMessage();
/*      */       }
/*  680 */       return true;
/*      */     }
/*  682 */     return false;
/*      */   }
/*      */   
/*      */   protected static long byteArrayToLong(byte[] b, int start, int len)
/*      */     throws IOException
/*      */   {
/*  688 */     if (len > 8) {
/*  689 */       throw new IOException(sm.getString("wsFrame.byteToLongFail", new Object[] { Long.valueOf(len) }));
/*      */     }
/*  691 */     int shift = 0;
/*  692 */     long result = 0L;
/*  693 */     for (int i = start + len - 1; i >= start; i--) {
/*  694 */       result += ((b[i] & 0xFF) << shift);
/*  695 */       shift += 8;
/*      */     }
/*  697 */     return result;
/*      */   }
/*      */   
/*      */   protected boolean isOpen()
/*      */   {
/*  702 */     return this.open;
/*      */   }
/*      */   
/*      */   protected Transformation getTransformation()
/*      */   {
/*  707 */     return this.transformation;
/*      */   }
/*      */   
/*      */   private static enum State
/*      */   {
/*  712 */     NEW_FRAME,  PARTIAL_HEADER,  DATA;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private State() {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static enum ReadState
/*      */   {
/*  773 */     WAITING(false), 
/*  774 */     PROCESSING(false), 
/*  775 */     SUSPENDING_WAIT(true), 
/*  776 */     SUSPENDING_PROCESS(true), 
/*  777 */     SUSPENDED(true), 
/*  778 */     CLOSING(false);
/*      */     
/*      */     private final boolean isSuspended;
/*      */     
/*      */     private ReadState(boolean isSuspended) {
/*  783 */       this.isSuspended = isSuspended;
/*      */     }
/*      */     
/*      */ 
/*  787 */     public boolean isSuspended() { return this.isSuspended; }
/*      */   }
/*      */   
/*      */   public void suspend() {
/*      */     do {
/*      */       do {
/*  793 */         do { do { do { switch (this.readState) {
/*      */               }
/*  795 */             } while (!READ_STATE_UPDATER.compareAndSet(this, ReadState.WAITING, ReadState.SUSPENDING_WAIT));
/*      */             
/*      */ 
/*      */ 
/*  799 */             return;
/*      */           }
/*  801 */           while (!READ_STATE_UPDATER.compareAndSet(this, ReadState.PROCESSING, ReadState.SUSPENDING_PROCESS));
/*      */           
/*      */ 
/*      */ 
/*  805 */           return;
/*      */         }
/*  807 */         while (this.readState != ReadState.SUSPENDING_WAIT);
/*      */         
/*      */ 
/*  810 */         if (getLog().isWarnEnabled()) {
/*  811 */           getLog().warn(sm.getString("wsFrame.suspendRequested"));
/*      */         }
/*      */         
/*  814 */         return;
/*      */       }
/*  816 */       while (this.readState != ReadState.SUSPENDING_PROCESS);
/*      */       
/*      */ 
/*  819 */       if (getLog().isWarnEnabled()) {
/*  820 */         getLog().warn(sm.getString("wsFrame.suspendRequested"));
/*      */       }
/*      */       
/*  823 */       return;
/*      */     }
/*  825 */     while (this.readState != ReadState.SUSPENDED);
/*      */     
/*      */ 
/*  828 */     if (getLog().isWarnEnabled()) {
/*  829 */       getLog().warn(sm.getString("wsFrame.alreadySuspended"));
/*      */     }
/*      */     
/*  832 */     return;
/*      */     
/*  834 */     return;
/*      */     
/*  836 */     throw new IllegalStateException(sm.getString("wsFrame.illegalReadState", new Object[] { this.state }));
/*      */   }
/*      */   
/*      */   public void resume() {
/*      */     do {
/*      */       do {
/*      */         do {
/*  843 */           do { do { switch (this.readState) {
/*      */               }
/*  845 */             } while (this.readState != ReadState.WAITING);
/*      */             
/*      */ 
/*  848 */             if (getLog().isWarnEnabled()) {
/*  849 */               getLog().warn(sm.getString("wsFrame.alreadyResumed"));
/*      */             }
/*      */             
/*  852 */             return;
/*      */           }
/*  854 */           while (this.readState != ReadState.PROCESSING);
/*      */           
/*      */ 
/*  857 */           if (getLog().isWarnEnabled()) {
/*  858 */             getLog().warn(sm.getString("wsFrame.alreadyResumed"));
/*      */           }
/*      */           
/*  861 */           return;
/*      */         }
/*  863 */         while (!READ_STATE_UPDATER.compareAndSet(this, ReadState.SUSPENDING_WAIT, ReadState.WAITING));
/*      */         
/*      */ 
/*      */ 
/*  867 */         return;
/*      */       }
/*  869 */       while (!READ_STATE_UPDATER.compareAndSet(this, ReadState.SUSPENDING_PROCESS, ReadState.PROCESSING));
/*      */       
/*      */ 
/*      */ 
/*  873 */       return;
/*      */     }
/*  875 */     while (!READ_STATE_UPDATER.compareAndSet(this, ReadState.SUSPENDED, ReadState.WAITING));
/*      */     
/*      */ 
/*      */ 
/*  879 */     resumeProcessing();
/*  880 */     return;
/*      */     
/*  882 */     return;
/*      */     
/*  884 */     throw new IllegalStateException(sm.getString("wsFrame.illegalReadState", new Object[] { this.state }));
/*      */   }
/*      */   
/*      */ 
/*      */   protected boolean isSuspended()
/*      */   {
/*  890 */     return this.readState.isSuspended();
/*      */   }
/*      */   
/*      */   protected ReadState getReadState() {
/*  894 */     return this.readState;
/*      */   }
/*      */   
/*      */   protected void changeReadState(ReadState newState) {
/*  898 */     READ_STATE_UPDATER.set(this, newState);
/*      */   }
/*      */   
/*      */   protected boolean changeReadState(ReadState oldState, ReadState newState) {
/*  902 */     return READ_STATE_UPDATER.compareAndSet(this, oldState, newState);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected abstract void resumeProcessing();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static abstract class TerminalTransformation
/*      */     implements Transformation
/*      */   {
/*      */     public boolean validateRsvBits(int i)
/*      */     {
/*  921 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */     public Extension getExtensionResponse()
/*      */     {
/*  927 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setNext(Transformation t) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean validateRsv(int rsv, byte opCode)
/*      */     {
/*  942 */       return rsv == 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void close() {}
/*      */   }
/*      */   
/*      */ 
/*      */   private final class NoopTransformation
/*      */     extends WsFrameBase.TerminalTransformation
/*      */   {
/*      */     private NoopTransformation()
/*      */     {
/*  956 */       super();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public TransformationResult getMoreData(byte opCode, boolean fin, int rsv, ByteBuffer dest)
/*      */     {
/*  964 */       long toWrite = Math.min(WsFrameBase.this.payloadLength - WsFrameBase.this.payloadWritten, WsFrameBase.this.inputBuffer.remaining());
/*  965 */       toWrite = Math.min(toWrite, dest.remaining());
/*      */       
/*  967 */       int orgLimit = WsFrameBase.this.inputBuffer.limit();
/*  968 */       WsFrameBase.this.inputBuffer.limit(WsFrameBase.this.inputBuffer.position() + (int)toWrite);
/*  969 */       dest.put(WsFrameBase.this.inputBuffer);
/*  970 */       WsFrameBase.this.inputBuffer.limit(orgLimit);
/*  971 */       WsFrameBase.this.payloadWritten = (WsFrameBase.this.payloadWritten + toWrite);
/*      */       
/*  973 */       if (WsFrameBase.this.payloadWritten == WsFrameBase.this.payloadLength)
/*  974 */         return TransformationResult.END_OF_FRAME;
/*  975 */       if (WsFrameBase.this.inputBuffer.remaining() == 0) {
/*  976 */         return TransformationResult.UNDERFLOW;
/*      */       }
/*      */       
/*  979 */       return TransformationResult.OVERFLOW;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public List<MessagePart> sendMessagePart(List<MessagePart> messageParts)
/*      */     {
/*  988 */       return messageParts;
/*      */     }
/*      */   }
/*      */   
/*      */   private final class UnmaskTransformation
/*      */     extends WsFrameBase.TerminalTransformation
/*      */   {
/*      */     private UnmaskTransformation()
/*      */     {
/*  997 */       super();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public TransformationResult getMoreData(byte opCode, boolean fin, int rsv, ByteBuffer dest)
/*      */     {
/* 1005 */       while ((WsFrameBase.this.payloadWritten < WsFrameBase.this.payloadLength) && (WsFrameBase.this.inputBuffer.remaining() > 0) && 
/* 1006 */         (dest.hasRemaining())) {
/* 1007 */         byte b = (byte)((WsFrameBase.this.inputBuffer.get() ^ WsFrameBase.this.mask[WsFrameBase.this.maskIndex]) & 0xFF);
/* 1008 */         WsFrameBase.access$608(WsFrameBase.this);
/* 1009 */         if (WsFrameBase.this.maskIndex == 4) {
/* 1010 */           WsFrameBase.this.maskIndex = 0;
/*      */         }
/* 1012 */         WsFrameBase.access$408(WsFrameBase.this);
/* 1013 */         dest.put(b);
/*      */       }
/* 1015 */       if (WsFrameBase.this.payloadWritten == WsFrameBase.this.payloadLength)
/* 1016 */         return TransformationResult.END_OF_FRAME;
/* 1017 */       if (WsFrameBase.this.inputBuffer.remaining() == 0) {
/* 1018 */         return TransformationResult.UNDERFLOW;
/*      */       }
/*      */       
/* 1021 */       return TransformationResult.OVERFLOW;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public List<MessagePart> sendMessagePart(List<MessagePart> messageParts)
/*      */     {
/* 1028 */       return messageParts;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-websocket-9.0.54.jar!\org\apache\tomcat\websocket\WsFrameBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */