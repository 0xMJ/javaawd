/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.FormatFeature;
/*      */ import com.fasterxml.jackson.core.FormatSchema;
/*      */ import com.fasterxml.jackson.core.JsonFactory;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*      */ import com.fasterxml.jackson.core.JsonPointer;
/*      */ import com.fasterxml.jackson.core.JsonProcessingException;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.StreamReadFeature;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.Versioned;
/*      */ import com.fasterxml.jackson.core.filter.FilteringParserDelegate;
/*      */ import com.fasterxml.jackson.core.filter.JsonPointerBasedFilter;
/*      */ import com.fasterxml.jackson.core.filter.TokenFilter;
/*      */ import com.fasterxml.jackson.core.filter.TokenFilter.Inclusion;
/*      */ import com.fasterxml.jackson.core.type.ResolvedType;
/*      */ import com.fasterxml.jackson.core.type.TypeReference;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.PackageVersion;
/*      */ import com.fasterxml.jackson.databind.deser.DataFormatReaders;
/*      */ import com.fasterxml.jackson.databind.deser.DataFormatReaders.Match;
/*      */ import com.fasterxml.jackson.databind.deser.DefaultDeserializationContext;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*      */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*      */ import com.fasterxml.jackson.databind.node.TreeTraversingParser;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.io.DataInput;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Type;
/*      */ import java.net.URL;
/*      */ import java.util.Iterator;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ObjectReader
/*      */   extends ObjectCodec
/*      */   implements Versioned, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 2L;
/*      */   protected final DeserializationConfig _config;
/*      */   protected final DefaultDeserializationContext _context;
/*      */   protected final JsonFactory _parserFactory;
/*      */   protected final boolean _unwrapRoot;
/*      */   private final TokenFilter _filter;
/*      */   protected final JavaType _valueType;
/*      */   protected final JsonDeserializer<Object> _rootDeserializer;
/*      */   protected final Object _valueToUpdate;
/*      */   protected final FormatSchema _schema;
/*      */   protected final InjectableValues _injectableValues;
/*      */   protected final DataFormatReaders _dataFormatReaders;
/*      */   protected final ConcurrentHashMap<JavaType, JsonDeserializer<Object>> _rootDeserializers;
/*      */   protected transient JavaType _jsonNodeType;
/*      */   
/*      */   protected ObjectReader(ObjectMapper mapper, DeserializationConfig config)
/*      */   {
/*  171 */     this(mapper, config, null, null, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectReader(ObjectMapper mapper, DeserializationConfig config, JavaType valueType, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues)
/*      */   {
/*  182 */     this._config = config;
/*  183 */     this._context = mapper._deserializationContext;
/*  184 */     this._rootDeserializers = mapper._rootDeserializers;
/*  185 */     this._parserFactory = mapper._jsonFactory;
/*  186 */     this._valueType = valueType;
/*  187 */     this._valueToUpdate = valueToUpdate;
/*  188 */     this._schema = schema;
/*  189 */     this._injectableValues = injectableValues;
/*  190 */     this._unwrapRoot = config.useRootWrapping();
/*      */     
/*  192 */     this._rootDeserializer = _prefetchRootDeserializer(valueType);
/*  193 */     this._dataFormatReaders = null;
/*  194 */     this._filter = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectReader(ObjectReader base, DeserializationConfig config, JavaType valueType, JsonDeserializer<Object> rootDeser, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues, DataFormatReaders dataFormatReaders)
/*      */   {
/*  205 */     this._config = config;
/*  206 */     this._context = base._context;
/*      */     
/*  208 */     this._rootDeserializers = base._rootDeserializers;
/*  209 */     this._parserFactory = base._parserFactory;
/*      */     
/*  211 */     this._valueType = valueType;
/*  212 */     this._rootDeserializer = rootDeser;
/*  213 */     this._valueToUpdate = valueToUpdate;
/*  214 */     this._schema = schema;
/*  215 */     this._injectableValues = injectableValues;
/*  216 */     this._unwrapRoot = config.useRootWrapping();
/*  217 */     this._dataFormatReaders = dataFormatReaders;
/*  218 */     this._filter = base._filter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectReader(ObjectReader base, DeserializationConfig config)
/*      */   {
/*  226 */     this._config = config;
/*  227 */     this._context = base._context;
/*      */     
/*  229 */     this._rootDeserializers = base._rootDeserializers;
/*  230 */     this._parserFactory = base._parserFactory;
/*      */     
/*  232 */     this._valueType = base._valueType;
/*  233 */     this._rootDeserializer = base._rootDeserializer;
/*  234 */     this._valueToUpdate = base._valueToUpdate;
/*  235 */     this._schema = base._schema;
/*  236 */     this._injectableValues = base._injectableValues;
/*  237 */     this._unwrapRoot = config.useRootWrapping();
/*  238 */     this._dataFormatReaders = base._dataFormatReaders;
/*  239 */     this._filter = base._filter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected ObjectReader(ObjectReader base, JsonFactory f)
/*      */   {
/*  246 */     this._config = ((DeserializationConfig)base._config.with(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, f.requiresPropertyOrdering()));
/*  247 */     this._context = base._context;
/*      */     
/*  249 */     this._rootDeserializers = base._rootDeserializers;
/*  250 */     this._parserFactory = f;
/*      */     
/*  252 */     this._valueType = base._valueType;
/*  253 */     this._rootDeserializer = base._rootDeserializer;
/*  254 */     this._valueToUpdate = base._valueToUpdate;
/*  255 */     this._schema = base._schema;
/*  256 */     this._injectableValues = base._injectableValues;
/*  257 */     this._unwrapRoot = base._unwrapRoot;
/*  258 */     this._dataFormatReaders = base._dataFormatReaders;
/*  259 */     this._filter = base._filter;
/*      */   }
/*      */   
/*      */   protected ObjectReader(ObjectReader base, TokenFilter filter) {
/*  263 */     this._config = base._config;
/*  264 */     this._context = base._context;
/*  265 */     this._rootDeserializers = base._rootDeserializers;
/*  266 */     this._parserFactory = base._parserFactory;
/*  267 */     this._valueType = base._valueType;
/*  268 */     this._rootDeserializer = base._rootDeserializer;
/*  269 */     this._valueToUpdate = base._valueToUpdate;
/*  270 */     this._schema = base._schema;
/*  271 */     this._injectableValues = base._injectableValues;
/*  272 */     this._unwrapRoot = base._unwrapRoot;
/*  273 */     this._dataFormatReaders = base._dataFormatReaders;
/*  274 */     this._filter = filter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Version version()
/*      */   {
/*  283 */     return PackageVersion.VERSION;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectReader _new(ObjectReader base, JsonFactory f)
/*      */   {
/*  300 */     return new ObjectReader(base, f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectReader _new(ObjectReader base, DeserializationConfig config)
/*      */   {
/*  309 */     return new ObjectReader(base, config);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectReader _new(ObjectReader base, DeserializationConfig config, JavaType valueType, JsonDeserializer<Object> rootDeser, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues, DataFormatReaders dataFormatReaders)
/*      */   {
/*  321 */     return new ObjectReader(base, config, valueType, rootDeser, valueToUpdate, schema, injectableValues, dataFormatReaders);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected <T> MappingIterator<T> _newIterator(JsonParser p, DeserializationContext ctxt, JsonDeserializer<?> deser, boolean parserManaged)
/*      */   {
/*  334 */     return new MappingIterator(this._valueType, p, ctxt, deser, parserManaged, this._valueToUpdate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonToken _initForReading(DeserializationContext ctxt, JsonParser p)
/*      */     throws IOException
/*      */   {
/*  347 */     this._config.initialize(p, this._schema);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  353 */     JsonToken t = p.currentToken();
/*  354 */     if (t == null) {
/*  355 */       t = p.nextToken();
/*  356 */       if (t == null)
/*      */       {
/*  358 */         ctxt.reportInputMismatch(this._valueType, "No content to map due to end-of-input", new Object[0]);
/*      */       }
/*      */     }
/*      */     
/*  362 */     return t;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _initForMultiRead(DeserializationContext ctxt, JsonParser p)
/*      */     throws IOException
/*      */   {
/*  377 */     this._config.initialize(p, this._schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader with(DeserializationFeature feature)
/*      */   {
/*  391 */     return _with(this._config.with(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader with(DeserializationFeature first, DeserializationFeature... other)
/*      */   {
/*  401 */     return _with(this._config.with(first, other));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader withFeatures(DeserializationFeature... features)
/*      */   {
/*  409 */     return _with(this._config.withFeatures(features));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader without(DeserializationFeature feature)
/*      */   {
/*  417 */     return _with(this._config.without(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader without(DeserializationFeature first, DeserializationFeature... other)
/*      */   {
/*  426 */     return _with(this._config.without(first, other));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader withoutFeatures(DeserializationFeature... features)
/*      */   {
/*  434 */     return _with(this._config.withoutFeatures(features));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader with(JsonParser.Feature feature)
/*      */   {
/*  453 */     return _with(this._config.with(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader withFeatures(JsonParser.Feature... features)
/*      */   {
/*  465 */     return _with(this._config.withFeatures(features));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader without(JsonParser.Feature feature)
/*      */   {
/*  477 */     return _with(this._config.without(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader withoutFeatures(JsonParser.Feature... features)
/*      */   {
/*  489 */     return _with(this._config.withoutFeatures(features));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader with(StreamReadFeature feature)
/*      */   {
/*  507 */     return _with(this._config.with(feature.mappedFeature()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader without(StreamReadFeature feature)
/*      */   {
/*  519 */     return _with(this._config.without(feature.mappedFeature()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader with(FormatFeature feature)
/*      */   {
/*  535 */     return _with(this._config.with(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader withFeatures(FormatFeature... features)
/*      */   {
/*  545 */     return _with(this._config.withFeatures(features));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader without(FormatFeature feature)
/*      */   {
/*  555 */     return _with(this._config.without(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader withoutFeatures(FormatFeature... features)
/*      */   {
/*  565 */     return _with(this._config.withoutFeatures(features));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader at(String pointerExpr)
/*      */   {
/*  580 */     _assertNotNull("pointerExpr", pointerExpr);
/*  581 */     return new ObjectReader(this, new JsonPointerBasedFilter(pointerExpr));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader at(JsonPointer pointer)
/*      */   {
/*  590 */     _assertNotNull("pointer", pointer);
/*  591 */     return new ObjectReader(this, new JsonPointerBasedFilter(pointer));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader with(DeserializationConfig config)
/*      */   {
/*  602 */     return _with(config);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader with(InjectableValues injectableValues)
/*      */   {
/*  614 */     if (this._injectableValues == injectableValues) {
/*  615 */       return this;
/*      */     }
/*  617 */     return _new(this, this._config, this._valueType, this._rootDeserializer, this._valueToUpdate, this._schema, injectableValues, this._dataFormatReaders);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader with(JsonNodeFactory f)
/*      */   {
/*  631 */     return _with(this._config.with(f));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader with(JsonFactory f)
/*      */   {
/*  646 */     if (f == this._parserFactory) {
/*  647 */       return this;
/*      */     }
/*  649 */     ObjectReader r = _new(this, f);
/*      */     
/*  651 */     if (f.getCodec() == null) {
/*  652 */       f.setCodec(r);
/*      */     }
/*  654 */     return r;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader withRootName(String rootName)
/*      */   {
/*  667 */     return _with((DeserializationConfig)this._config.withRootName(rootName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectReader withRootName(PropertyName rootName)
/*      */   {
/*  674 */     return _with(this._config.withRootName(rootName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader withoutRootName()
/*      */   {
/*  688 */     return _with(this._config.withRootName(PropertyName.NO_NAME));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader with(FormatSchema schema)
/*      */   {
/*  701 */     if (this._schema == schema) {
/*  702 */       return this;
/*      */     }
/*  704 */     _verifySchemaType(schema);
/*  705 */     return _new(this, this._config, this._valueType, this._rootDeserializer, this._valueToUpdate, schema, this._injectableValues, this._dataFormatReaders);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader forType(JavaType valueType)
/*      */   {
/*  720 */     if ((valueType != null) && (valueType.equals(this._valueType))) {
/*  721 */       return this;
/*      */     }
/*  723 */     JsonDeserializer<Object> rootDeser = _prefetchRootDeserializer(valueType);
/*      */     
/*  725 */     DataFormatReaders det = this._dataFormatReaders;
/*  726 */     if (det != null) {
/*  727 */       det = det.withType(valueType);
/*      */     }
/*  729 */     return _new(this, this._config, valueType, rootDeser, this._valueToUpdate, this._schema, this._injectableValues, det);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader forType(Class<?> valueType)
/*      */   {
/*  743 */     return forType(this._config.constructType(valueType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader forType(TypeReference<?> valueTypeRef)
/*      */   {
/*  756 */     return forType(this._config.getTypeFactory().constructType(valueTypeRef.getType()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectReader withType(JavaType valueType)
/*      */   {
/*  764 */     return forType(valueType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectReader withType(Class<?> valueType)
/*      */   {
/*  772 */     return forType(this._config.constructType(valueType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectReader withType(Type valueType)
/*      */   {
/*  780 */     return forType(this._config.getTypeFactory().constructType(valueType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectReader withType(TypeReference<?> valueTypeRef)
/*      */   {
/*  788 */     return forType(this._config.getTypeFactory().constructType(valueTypeRef.getType()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader withValueToUpdate(Object value)
/*      */   {
/*  801 */     if (value == this._valueToUpdate) return this;
/*  802 */     if (value == null)
/*      */     {
/*      */ 
/*  805 */       return _new(this, this._config, this._valueType, this._rootDeserializer, null, this._schema, this._injectableValues, this._dataFormatReaders);
/*      */     }
/*      */     
/*      */ 
/*      */     JavaType t;
/*      */     
/*      */ 
/*      */     JavaType t;
/*      */     
/*  814 */     if (this._valueType == null) {
/*  815 */       t = this._config.constructType(value.getClass());
/*      */     } else {
/*  817 */       t = this._valueType;
/*      */     }
/*  819 */     return _new(this, this._config, t, this._rootDeserializer, value, this._schema, this._injectableValues, this._dataFormatReaders);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader withView(Class<?> activeView)
/*      */   {
/*  831 */     return _with(this._config.withView(activeView));
/*      */   }
/*      */   
/*      */   public ObjectReader with(Locale l) {
/*  835 */     return _with((DeserializationConfig)this._config.with(l));
/*      */   }
/*      */   
/*      */   public ObjectReader with(TimeZone tz) {
/*  839 */     return _with((DeserializationConfig)this._config.with(tz));
/*      */   }
/*      */   
/*      */   public ObjectReader withHandler(DeserializationProblemHandler h) {
/*  843 */     return _with(this._config.withHandler(h));
/*      */   }
/*      */   
/*      */   public ObjectReader with(Base64Variant defaultBase64) {
/*  847 */     return _with((DeserializationConfig)this._config.with(defaultBase64));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader withFormatDetection(ObjectReader... readers)
/*      */   {
/*  873 */     return withFormatDetection(new DataFormatReaders(readers));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader withFormatDetection(DataFormatReaders readers)
/*      */   {
/*  892 */     return _new(this, this._config, this._valueType, this._rootDeserializer, this._valueToUpdate, this._schema, this._injectableValues, readers);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader with(ContextAttributes attrs)
/*      */   {
/*  900 */     return _with(this._config.with(attrs));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectReader withAttributes(Map<?, ?> attrs)
/*      */   {
/*  907 */     return _with((DeserializationConfig)this._config.withAttributes(attrs));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectReader withAttribute(Object key, Object value)
/*      */   {
/*  914 */     return _with((DeserializationConfig)this._config.withAttribute(key, value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectReader withoutAttribute(Object key)
/*      */   {
/*  921 */     return _with((DeserializationConfig)this._config.withoutAttribute(key));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectReader _with(DeserializationConfig newConfig)
/*      */   {
/*  931 */     if (newConfig == this._config) {
/*  932 */       return this;
/*      */     }
/*  934 */     ObjectReader r = _new(this, newConfig);
/*  935 */     if (this._dataFormatReaders != null) {
/*  936 */       r = r.withFormatDetection(this._dataFormatReaders.with(newConfig));
/*      */     }
/*  938 */     return r;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(DeserializationFeature f)
/*      */   {
/*  948 */     return this._config.isEnabled(f);
/*      */   }
/*      */   
/*      */   public boolean isEnabled(MapperFeature f) {
/*  952 */     return this._config.isEnabled(f);
/*      */   }
/*      */   
/*      */   public boolean isEnabled(JsonParser.Feature f) {
/*  956 */     return this._config.isEnabled(f, this._parserFactory);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(StreamReadFeature f)
/*      */   {
/*  963 */     return this._config.isEnabled(f.mappedFeature(), this._parserFactory);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public DeserializationConfig getConfig()
/*      */   {
/*  970 */     return this._config;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonFactory getFactory()
/*      */   {
/*  978 */     return this._parserFactory;
/*      */   }
/*      */   
/*      */   public TypeFactory getTypeFactory() {
/*  982 */     return this._config.getTypeFactory();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ContextAttributes getAttributes()
/*      */   {
/*  989 */     return this._config.getAttributes();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public InjectableValues getInjectableValues()
/*      */   {
/*  996 */     return this._injectableValues;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JavaType getValueType()
/*      */   {
/* 1003 */     return this._valueType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(File src)
/*      */     throws IOException
/*      */   {
/* 1021 */     _assertNotNull("src", src);
/* 1022 */     return this._config.initialize(this._parserFactory.createParser(src), this._schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(URL src)
/*      */     throws IOException
/*      */   {
/* 1034 */     _assertNotNull("src", src);
/* 1035 */     return this._config.initialize(this._parserFactory.createParser(src), this._schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(InputStream in)
/*      */     throws IOException
/*      */   {
/* 1047 */     _assertNotNull("in", in);
/* 1048 */     return this._config.initialize(this._parserFactory.createParser(in), this._schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(Reader r)
/*      */     throws IOException
/*      */   {
/* 1060 */     _assertNotNull("r", r);
/* 1061 */     return this._config.initialize(this._parserFactory.createParser(r), this._schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(byte[] content)
/*      */     throws IOException
/*      */   {
/* 1073 */     _assertNotNull("content", content);
/* 1074 */     return this._config.initialize(this._parserFactory.createParser(content), this._schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(byte[] content, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 1086 */     _assertNotNull("content", content);
/* 1087 */     return this._config.initialize(this._parserFactory.createParser(content, offset, len), this._schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(String content)
/*      */     throws IOException
/*      */   {
/* 1099 */     _assertNotNull("content", content);
/* 1100 */     return this._config.initialize(this._parserFactory.createParser(content), this._schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(char[] content)
/*      */     throws IOException
/*      */   {
/* 1112 */     _assertNotNull("content", content);
/* 1113 */     return this._config.initialize(this._parserFactory.createParser(content), this._schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(char[] content, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 1125 */     _assertNotNull("content", content);
/* 1126 */     return this._config.initialize(this._parserFactory.createParser(content, offset, len), this._schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(DataInput content)
/*      */     throws IOException
/*      */   {
/* 1138 */     _assertNotNull("content", content);
/* 1139 */     return this._config.initialize(this._parserFactory.createParser(content), this._schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createNonBlockingByteArrayParser()
/*      */     throws IOException
/*      */   {
/* 1151 */     return this._config.initialize(this._parserFactory.createNonBlockingByteArrayParser(), this._schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(JsonParser p)
/*      */     throws IOException
/*      */   {
/* 1173 */     _assertNotNull("p", p);
/* 1174 */     return (T)_bind(p, this._valueToUpdate);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(JsonParser p, Class<T> valueType)
/*      */     throws IOException
/*      */   {
/* 1191 */     _assertNotNull("p", p);
/* 1192 */     return (T)forType(valueType).readValue(p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(JsonParser p, TypeReference<T> valueTypeRef)
/*      */     throws IOException
/*      */   {
/* 1209 */     _assertNotNull("p", p);
/* 1210 */     return (T)forType(valueTypeRef).readValue(p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(JsonParser p, ResolvedType valueType)
/*      */     throws IOException
/*      */   {
/* 1226 */     _assertNotNull("p", p);
/* 1227 */     return (T)forType((JavaType)valueType).readValue(p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(JsonParser p, JavaType valueType)
/*      */     throws IOException
/*      */   {
/* 1238 */     _assertNotNull("p", p);
/* 1239 */     return (T)forType(valueType).readValue(p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> Iterator<T> readValues(JsonParser p, Class<T> valueType)
/*      */     throws IOException
/*      */   {
/* 1263 */     _assertNotNull("p", p);
/* 1264 */     return forType(valueType).readValues(p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> Iterator<T> readValues(JsonParser p, TypeReference<T> valueTypeRef)
/*      */     throws IOException
/*      */   {
/* 1288 */     _assertNotNull("p", p);
/* 1289 */     return forType(valueTypeRef).readValues(p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> Iterator<T> readValues(JsonParser p, ResolvedType valueType)
/*      */     throws IOException
/*      */   {
/* 1313 */     _assertNotNull("p", p);
/* 1314 */     return readValues(p, (JavaType)valueType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> Iterator<T> readValues(JsonParser p, JavaType valueType)
/*      */     throws IOException
/*      */   {
/* 1337 */     _assertNotNull("p", p);
/* 1338 */     return forType(valueType).readValues(p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonNode createArrayNode()
/*      */   {
/* 1349 */     return this._config.getNodeFactory().arrayNode();
/*      */   }
/*      */   
/*      */   public JsonNode createObjectNode()
/*      */   {
/* 1354 */     return this._config.getNodeFactory().objectNode();
/*      */   }
/*      */   
/*      */   public JsonNode missingNode()
/*      */   {
/* 1359 */     return this._config.getNodeFactory().missingNode();
/*      */   }
/*      */   
/*      */   public JsonNode nullNode()
/*      */   {
/* 1364 */     return this._config.getNodeFactory().nullNode();
/*      */   }
/*      */   
/*      */   public JsonParser treeAsTokens(TreeNode n)
/*      */   {
/* 1369 */     _assertNotNull("n", n);
/*      */     
/*      */ 
/* 1372 */     ObjectReader codec = withValueToUpdate(null);
/* 1373 */     return new TreeTraversingParser((JsonNode)n, codec);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T extends TreeNode> T readTree(JsonParser p)
/*      */     throws IOException
/*      */   {
/* 1397 */     _assertNotNull("p", p);
/* 1398 */     return _bindAsTreeOrNull(p);
/*      */   }
/*      */   
/*      */   public void writeTree(JsonGenerator g, TreeNode rootNode)
/*      */   {
/* 1403 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(InputStream src)
/*      */     throws IOException
/*      */   {
/* 1423 */     if (this._dataFormatReaders != null) {
/* 1424 */       return (T)_detectBindAndClose(this._dataFormatReaders.findFormat(src), false);
/*      */     }
/* 1426 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(InputStream src, Class<T> valueType)
/*      */     throws IOException
/*      */   {
/* 1441 */     return (T)forType(valueType).readValue(src);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(Reader src)
/*      */     throws IOException
/*      */   {
/* 1455 */     if (this._dataFormatReaders != null) {
/* 1456 */       _reportUndetectableSource(src);
/*      */     }
/* 1458 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(Reader src, Class<T> valueType)
/*      */     throws IOException
/*      */   {
/* 1473 */     return (T)forType(valueType).readValue(src);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(String src)
/*      */     throws JsonProcessingException, JsonMappingException
/*      */   {
/* 1487 */     if (this._dataFormatReaders != null) {
/* 1488 */       _reportUndetectableSource(src);
/*      */     }
/*      */     try {
/* 1491 */       return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */     } catch (JsonProcessingException e) {
/* 1493 */       throw e;
/*      */     } catch (IOException e) {
/* 1495 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(String src, Class<T> valueType)
/*      */     throws IOException
/*      */   {
/* 1511 */     return (T)forType(valueType).readValue(src);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(byte[] content)
/*      */     throws IOException
/*      */   {
/* 1525 */     if (this._dataFormatReaders != null) {
/* 1526 */       return (T)_detectBindAndClose(content, 0, content.length);
/*      */     }
/* 1528 */     return (T)_bindAndClose(_considerFilter(createParser(content), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(byte[] content, Class<T> valueType)
/*      */     throws IOException
/*      */   {
/* 1543 */     return (T)forType(valueType).readValue(content);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(byte[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1559 */     if (this._dataFormatReaders != null) {
/* 1560 */       return (T)_detectBindAndClose(buffer, offset, length);
/*      */     }
/* 1562 */     return (T)_bindAndClose(_considerFilter(createParser(buffer, offset, length), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(byte[] buffer, int offset, int length, Class<T> valueType)
/*      */     throws IOException
/*      */   {
/* 1580 */     return (T)forType(valueType).readValue(buffer, offset, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(File src)
/*      */     throws IOException
/*      */   {
/* 1594 */     if (this._dataFormatReaders != null) {
/* 1595 */       return (T)_detectBindAndClose(this._dataFormatReaders.findFormat(_inputStream(src)), true);
/*      */     }
/*      */     
/* 1598 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(File src, Class<T> valueType)
/*      */     throws IOException
/*      */   {
/* 1613 */     return (T)forType(valueType).readValue(src);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(URL src)
/*      */     throws IOException
/*      */   {
/* 1632 */     if (this._dataFormatReaders != null) {
/* 1633 */       return (T)_detectBindAndClose(this._dataFormatReaders.findFormat(_inputStream(src)), true);
/*      */     }
/* 1635 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(URL src, Class<T> valueType)
/*      */     throws IOException
/*      */   {
/* 1650 */     return (T)forType(valueType).readValue(src);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(JsonNode content)
/*      */     throws IOException
/*      */   {
/* 1665 */     _assertNotNull("content", content);
/* 1666 */     if (this._dataFormatReaders != null) {
/* 1667 */       _reportUndetectableSource(content);
/*      */     }
/* 1669 */     return (T)_bindAndClose(_considerFilter(treeAsTokens(content), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(JsonNode content, Class<T> valueType)
/*      */     throws IOException
/*      */   {
/* 1684 */     return (T)forType(valueType).readValue(content);
/*      */   }
/*      */   
/*      */   public <T> T readValue(DataInput src)
/*      */     throws IOException
/*      */   {
/* 1690 */     if (this._dataFormatReaders != null) {
/* 1691 */       _reportUndetectableSource(src);
/*      */     }
/* 1693 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(DataInput content, Class<T> valueType)
/*      */     throws IOException
/*      */   {
/* 1708 */     return (T)forType(valueType).readValue(content);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(InputStream src)
/*      */     throws IOException
/*      */   {
/* 1736 */     if (this._dataFormatReaders != null) {
/* 1737 */       return _detectBindAndCloseAsTree(src);
/*      */     }
/* 1739 */     return _bindAndCloseAsTree(_considerFilter(createParser(src), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(Reader src)
/*      */     throws IOException
/*      */   {
/* 1748 */     if (this._dataFormatReaders != null) {
/* 1749 */       _reportUndetectableSource(src);
/*      */     }
/* 1751 */     return _bindAndCloseAsTree(_considerFilter(createParser(src), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(String json)
/*      */     throws JsonProcessingException, JsonMappingException
/*      */   {
/* 1760 */     if (this._dataFormatReaders != null) {
/* 1761 */       _reportUndetectableSource(json);
/*      */     }
/*      */     try {
/* 1764 */       return _bindAndCloseAsTree(_considerFilter(createParser(json), false));
/*      */     } catch (JsonProcessingException e) {
/* 1766 */       throw e;
/*      */     } catch (IOException e) {
/* 1768 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(byte[] json)
/*      */     throws IOException
/*      */   {
/* 1778 */     _assertNotNull("json", json);
/* 1779 */     if (this._dataFormatReaders != null) {
/* 1780 */       _reportUndetectableSource(json);
/*      */     }
/* 1782 */     return _bindAndCloseAsTree(_considerFilter(createParser(json), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(byte[] json, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 1791 */     if (this._dataFormatReaders != null) {
/* 1792 */       _reportUndetectableSource(json);
/*      */     }
/* 1794 */     return _bindAndCloseAsTree(_considerFilter(createParser(json, offset, len), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(DataInput src)
/*      */     throws IOException
/*      */   {
/* 1803 */     if (this._dataFormatReaders != null) {
/* 1804 */       _reportUndetectableSource(src);
/*      */     }
/* 1806 */     return _bindAndCloseAsTree(_considerFilter(createParser(src), false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(JsonParser p)
/*      */     throws IOException
/*      */   {
/* 1828 */     _assertNotNull("p", p);
/* 1829 */     DeserializationContext ctxt = createDeserializationContext(p);
/*      */     
/* 1831 */     return _newIterator(p, ctxt, _findRootDeserializer(ctxt), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(InputStream src)
/*      */     throws IOException
/*      */   {
/* 1856 */     if (this._dataFormatReaders != null) {
/* 1857 */       return _detectBindAndReadValues(this._dataFormatReaders.findFormat(src), false);
/*      */     }
/*      */     
/* 1860 */     return _bindAndReadValues(_considerFilter(createParser(src), true));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(Reader src)
/*      */     throws IOException
/*      */   {
/* 1868 */     if (this._dataFormatReaders != null) {
/* 1869 */       _reportUndetectableSource(src);
/*      */     }
/* 1871 */     JsonParser p = _considerFilter(createParser(src), true);
/* 1872 */     DeserializationContext ctxt = createDeserializationContext(p);
/* 1873 */     _initForMultiRead(ctxt, p);
/* 1874 */     p.nextToken();
/* 1875 */     return _newIterator(p, ctxt, _findRootDeserializer(ctxt), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(String json)
/*      */     throws IOException
/*      */   {
/* 1885 */     if (this._dataFormatReaders != null) {
/* 1886 */       _reportUndetectableSource(json);
/*      */     }
/* 1888 */     JsonParser p = _considerFilter(createParser(json), true);
/* 1889 */     DeserializationContext ctxt = createDeserializationContext(p);
/* 1890 */     _initForMultiRead(ctxt, p);
/* 1891 */     p.nextToken();
/* 1892 */     return _newIterator(p, ctxt, _findRootDeserializer(ctxt), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(byte[] src, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1900 */     if (this._dataFormatReaders != null) {
/* 1901 */       return _detectBindAndReadValues(this._dataFormatReaders.findFormat(src, offset, length), false);
/*      */     }
/* 1903 */     return _bindAndReadValues(_considerFilter(createParser(src, offset, length), true));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final <T> MappingIterator<T> readValues(byte[] src)
/*      */     throws IOException
/*      */   {
/* 1911 */     _assertNotNull("src", src);
/* 1912 */     return readValues(src, 0, src.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(File src)
/*      */     throws IOException
/*      */   {
/* 1920 */     if (this._dataFormatReaders != null) {
/* 1921 */       return _detectBindAndReadValues(this._dataFormatReaders
/* 1922 */         .findFormat(_inputStream(src)), false);
/*      */     }
/* 1924 */     return _bindAndReadValues(_considerFilter(createParser(src), true));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(URL src)
/*      */     throws IOException
/*      */   {
/* 1940 */     if (this._dataFormatReaders != null) {
/* 1941 */       return _detectBindAndReadValues(this._dataFormatReaders
/* 1942 */         .findFormat(_inputStream(src)), true);
/*      */     }
/* 1944 */     return _bindAndReadValues(_considerFilter(createParser(src), true));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(DataInput src)
/*      */     throws IOException
/*      */   {
/* 1952 */     if (this._dataFormatReaders != null) {
/* 1953 */       _reportUndetectableSource(src);
/*      */     }
/* 1955 */     return _bindAndReadValues(_considerFilter(createParser(src), true));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T treeToValue(TreeNode n, Class<T> valueType)
/*      */     throws JsonProcessingException
/*      */   {
/* 1967 */     _assertNotNull("n", n);
/*      */     try {
/* 1969 */       return (T)readValue(treeAsTokens(n), valueType);
/*      */     } catch (JsonProcessingException e) {
/* 1971 */       throw e;
/*      */     } catch (IOException e) {
/* 1973 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeValue(JsonGenerator gen, Object value) throws IOException
/*      */   {
/* 1979 */     throw new UnsupportedOperationException("Not implemented for ObjectReader");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object _bind(JsonParser p, Object valueToUpdate)
/*      */     throws IOException
/*      */   {
/* 1996 */     DefaultDeserializationContext ctxt = createDeserializationContext(p);
/* 1997 */     JsonToken t = _initForReading(ctxt, p);
/* 1998 */     Object result; Object result; if (t == JsonToken.VALUE_NULL) { Object result;
/* 1999 */       if (valueToUpdate == null) {
/* 2000 */         result = _findRootDeserializer(ctxt).getNullValue(ctxt);
/*      */       } else
/* 2002 */         result = valueToUpdate;
/*      */     } else { Object result;
/* 2004 */       if ((t == JsonToken.END_ARRAY) || (t == JsonToken.END_OBJECT)) {
/* 2005 */         result = valueToUpdate;
/*      */       } else {
/* 2007 */         result = ctxt.readRootValue(p, this._valueType, _findRootDeserializer(ctxt), this._valueToUpdate);
/*      */       }
/*      */     }
/* 2010 */     p.clearCurrentToken();
/* 2011 */     if (this._config.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 2012 */       _verifyNoTrailingTokens(p, ctxt, this._valueType);
/*      */     }
/* 2014 */     return result;
/*      */   }
/*      */   
/*      */   protected Object _bindAndClose(JsonParser p0) throws IOException
/*      */   {
/* 2019 */     JsonParser p = p0;Throwable localThrowable3 = null;
/*      */     try
/*      */     {
/* 2022 */       DefaultDeserializationContext ctxt = createDeserializationContext(p);
/* 2023 */       JsonToken t = _initForReading(ctxt, p);
/* 2024 */       Object result; Object result; if (t == JsonToken.VALUE_NULL) { Object result;
/* 2025 */         if (this._valueToUpdate == null) {
/* 2026 */           result = _findRootDeserializer(ctxt).getNullValue(ctxt);
/*      */         } else
/* 2028 */           result = this._valueToUpdate;
/*      */       } else { Object result;
/* 2030 */         if ((t == JsonToken.END_ARRAY) || (t == JsonToken.END_OBJECT)) {
/* 2031 */           result = this._valueToUpdate;
/*      */         } else
/* 2033 */           result = ctxt.readRootValue(p, this._valueType, _findRootDeserializer(ctxt), this._valueToUpdate);
/*      */       }
/* 2035 */       if (this._config.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 2036 */         _verifyNoTrailingTokens(p, ctxt, this._valueType);
/*      */       }
/* 2038 */       return result;
/*      */     }
/*      */     catch (Throwable localThrowable1)
/*      */     {
/* 2019 */       localThrowable3 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2039 */       if (p != null) if (localThrowable3 != null) try { p.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else p.close();
/*      */     }
/*      */   }
/*      */   
/* 2043 */   protected final JsonNode _bindAndCloseAsTree(JsonParser p0) throws IOException { JsonParser p = p0;Throwable localThrowable3 = null;
/* 2044 */     try { return _bindAsTree(p);
/*      */     }
/*      */     catch (Throwable localThrowable4)
/*      */     {
/* 2043 */       localThrowable3 = localThrowable4;throw localThrowable4;
/*      */     } finally {
/* 2045 */       if (p != null) if (localThrowable3 != null) try { p.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else p.close();
/*      */     }
/*      */   }
/*      */   
/*      */   protected final JsonNode _bindAsTree(JsonParser p) throws IOException
/*      */   {
/* 2051 */     this._config.initialize(p);
/* 2052 */     if (this._schema != null) {
/* 2053 */       p.setSchema(this._schema);
/*      */     }
/*      */     
/* 2056 */     JsonToken t = p.currentToken();
/* 2057 */     if (t == null) {
/* 2058 */       t = p.nextToken();
/* 2059 */       if (t == null) {
/* 2060 */         return this._config.getNodeFactory().missingNode();
/*      */       }
/*      */     }
/* 2063 */     DefaultDeserializationContext ctxt = createDeserializationContext(p);
/*      */     JsonNode resultNode;
/*      */     JsonNode resultNode;
/* 2066 */     if (t == JsonToken.VALUE_NULL) {
/* 2067 */       resultNode = this._config.getNodeFactory().nullNode();
/*      */     }
/*      */     else {
/* 2070 */       resultNode = (JsonNode)ctxt.readRootValue(p, _jsonNodeType(), _findTreeDeserializer(ctxt), null);
/*      */     }
/* 2072 */     if (this._config.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 2073 */       _verifyNoTrailingTokens(p, ctxt, _jsonNodeType());
/*      */     }
/* 2075 */     return resultNode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final JsonNode _bindAsTreeOrNull(JsonParser p)
/*      */     throws IOException
/*      */   {
/* 2084 */     this._config.initialize(p);
/* 2085 */     if (this._schema != null) {
/* 2086 */       p.setSchema(this._schema);
/*      */     }
/* 2088 */     JsonToken t = p.currentToken();
/* 2089 */     if (t == null) {
/* 2090 */       t = p.nextToken();
/* 2091 */       if (t == null) {
/* 2092 */         return null;
/*      */       }
/*      */     }
/* 2095 */     DefaultDeserializationContext ctxt = createDeserializationContext(p);
/*      */     JsonNode resultNode;
/* 2097 */     JsonNode resultNode; if (t == JsonToken.VALUE_NULL) {
/* 2098 */       resultNode = this._config.getNodeFactory().nullNode();
/*      */     }
/*      */     else {
/* 2101 */       resultNode = (JsonNode)ctxt.readRootValue(p, _jsonNodeType(), _findTreeDeserializer(ctxt), null);
/*      */     }
/* 2103 */     if (this._config.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 2104 */       _verifyNoTrailingTokens(p, ctxt, _jsonNodeType());
/*      */     }
/* 2106 */     return resultNode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected <T> MappingIterator<T> _bindAndReadValues(JsonParser p)
/*      */     throws IOException
/*      */   {
/* 2114 */     DeserializationContext ctxt = createDeserializationContext(p);
/* 2115 */     _initForMultiRead(ctxt, p);
/* 2116 */     p.nextToken();
/* 2117 */     return _newIterator(p, ctxt, _findRootDeserializer(ctxt), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonParser _considerFilter(JsonParser p, boolean multiValue)
/*      */   {
/* 2126 */     return (this._filter == null) || (FilteringParserDelegate.class.isInstance(p)) ? p : new FilteringParserDelegate(p, this._filter, TokenFilter.Inclusion.ONLY_INCLUDE_ALL, multiValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _verifyNoTrailingTokens(JsonParser p, DeserializationContext ctxt, JavaType bindType)
/*      */     throws IOException
/*      */   {
/* 2137 */     JsonToken t = p.nextToken();
/* 2138 */     if (t != null) {
/* 2139 */       Class<?> bt = ClassUtil.rawClass(bindType);
/* 2140 */       if ((bt == null) && 
/* 2141 */         (this._valueToUpdate != null)) {
/* 2142 */         bt = this._valueToUpdate.getClass();
/*      */       }
/*      */       
/* 2145 */       ctxt.reportTrailingTokens(bt, p, t);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object _detectBindAndClose(byte[] src, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 2157 */     DataFormatReaders.Match match = this._dataFormatReaders.findFormat(src, offset, length);
/* 2158 */     if (!match.hasMatch()) {
/* 2159 */       _reportUnkownFormat(this._dataFormatReaders, match);
/*      */     }
/* 2161 */     JsonParser p = match.createParserWithMatch();
/* 2162 */     return match.getReader()._bindAndClose(p);
/*      */   }
/*      */   
/*      */   protected Object _detectBindAndClose(DataFormatReaders.Match match, boolean forceClosing)
/*      */     throws IOException
/*      */   {
/* 2168 */     if (!match.hasMatch()) {
/* 2169 */       _reportUnkownFormat(this._dataFormatReaders, match);
/*      */     }
/* 2171 */     JsonParser p = match.createParserWithMatch();
/*      */     
/*      */ 
/* 2174 */     if (forceClosing) {
/* 2175 */       p.enable(JsonParser.Feature.AUTO_CLOSE_SOURCE);
/*      */     }
/*      */     
/* 2178 */     return match.getReader()._bindAndClose(p);
/*      */   }
/*      */   
/*      */   protected <T> MappingIterator<T> _detectBindAndReadValues(DataFormatReaders.Match match, boolean forceClosing)
/*      */     throws IOException
/*      */   {
/* 2184 */     if (!match.hasMatch()) {
/* 2185 */       _reportUnkownFormat(this._dataFormatReaders, match);
/*      */     }
/* 2187 */     JsonParser p = match.createParserWithMatch();
/*      */     
/*      */ 
/* 2190 */     if (forceClosing) {
/* 2191 */       p.enable(JsonParser.Feature.AUTO_CLOSE_SOURCE);
/*      */     }
/*      */     
/* 2194 */     return match.getReader()._bindAndReadValues(p);
/*      */   }
/*      */   
/*      */   protected JsonNode _detectBindAndCloseAsTree(InputStream in) throws IOException
/*      */   {
/* 2199 */     DataFormatReaders.Match match = this._dataFormatReaders.findFormat(in);
/* 2200 */     if (!match.hasMatch()) {
/* 2201 */       _reportUnkownFormat(this._dataFormatReaders, match);
/*      */     }
/* 2203 */     JsonParser p = match.createParserWithMatch();
/* 2204 */     p.enable(JsonParser.Feature.AUTO_CLOSE_SOURCE);
/* 2205 */     return match.getReader()._bindAndCloseAsTree(p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _reportUnkownFormat(DataFormatReaders detector, DataFormatReaders.Match match)
/*      */     throws JsonProcessingException
/*      */   {
/* 2217 */     throw new JsonParseException(null, "Cannot detect format from input, does not look like any of detectable formats " + detector.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _verifySchemaType(FormatSchema schema)
/*      */   {
/* 2231 */     if ((schema != null) && 
/* 2232 */       (!this._parserFactory.canUseSchema(schema)))
/*      */     {
/* 2234 */       throw new IllegalArgumentException("Cannot use FormatSchema of type " + schema.getClass().getName() + " for format " + this._parserFactory.getFormatName());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DefaultDeserializationContext createDeserializationContext(JsonParser p)
/*      */   {
/* 2245 */     return this._context.createInstance(this._config, p, this._injectableValues);
/*      */   }
/*      */   
/*      */   protected DefaultDeserializationContext createDummyDeserializationContext()
/*      */   {
/* 2250 */     return this._context.createDummyInstance(this._config);
/*      */   }
/*      */   
/*      */   protected InputStream _inputStream(URL src) throws IOException {
/* 2254 */     return src.openStream();
/*      */   }
/*      */   
/*      */   protected InputStream _inputStream(File f) throws IOException {
/* 2258 */     return new FileInputStream(f);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void _reportUndetectableSource(Object src)
/*      */     throws JsonParseException
/*      */   {
/* 2265 */     throw new JsonParseException(null, "Cannot use source of type " + src.getClass().getName() + " with format auto-detection: must be byte- not char-based");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> _findRootDeserializer(DeserializationContext ctxt)
/*      */     throws JsonMappingException
/*      */   {
/* 2280 */     if (this._rootDeserializer != null) {
/* 2281 */       return this._rootDeserializer;
/*      */     }
/*      */     
/*      */ 
/* 2285 */     JavaType t = this._valueType;
/* 2286 */     if (t == null) {
/* 2287 */       ctxt.reportBadDefinition((JavaType)null, "No value type configured for ObjectReader");
/*      */     }
/*      */     
/*      */ 
/* 2291 */     JsonDeserializer<Object> deser = (JsonDeserializer)this._rootDeserializers.get(t);
/* 2292 */     if (deser != null) {
/* 2293 */       return deser;
/*      */     }
/*      */     
/* 2296 */     deser = ctxt.findRootValueDeserializer(t);
/* 2297 */     if (deser == null) {
/* 2298 */       ctxt.reportBadDefinition(t, "Cannot find a deserializer for type " + t);
/*      */     }
/* 2300 */     this._rootDeserializers.put(t, deser);
/* 2301 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> _findTreeDeserializer(DeserializationContext ctxt)
/*      */     throws JsonMappingException
/*      */   {
/* 2310 */     JavaType nodeType = _jsonNodeType();
/* 2311 */     JsonDeserializer<Object> deser = (JsonDeserializer)this._rootDeserializers.get(nodeType);
/* 2312 */     if (deser == null)
/*      */     {
/* 2314 */       deser = ctxt.findRootValueDeserializer(nodeType);
/* 2315 */       if (deser == null) {
/* 2316 */         ctxt.reportBadDefinition(nodeType, "Cannot find a deserializer for type " + nodeType);
/*      */       }
/*      */       
/* 2319 */       this._rootDeserializers.put(nodeType, deser);
/*      */     }
/* 2321 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> _prefetchRootDeserializer(JavaType valueType)
/*      */   {
/* 2331 */     if ((valueType == null) || (!this._config.isEnabled(DeserializationFeature.EAGER_DESERIALIZER_FETCH))) {
/* 2332 */       return null;
/*      */     }
/*      */     
/* 2335 */     JsonDeserializer<Object> deser = (JsonDeserializer)this._rootDeserializers.get(valueType);
/* 2336 */     if (deser == null) {
/*      */       try
/*      */       {
/* 2339 */         DeserializationContext ctxt = createDummyDeserializationContext();
/* 2340 */         deser = ctxt.findRootValueDeserializer(valueType);
/* 2341 */         if (deser != null) {
/* 2342 */           this._rootDeserializers.put(valueType, deser);
/*      */         }
/* 2344 */         return deser;
/*      */       }
/*      */       catch (JsonProcessingException localJsonProcessingException) {}
/*      */     }
/*      */     
/* 2349 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final JavaType _jsonNodeType()
/*      */   {
/* 2356 */     JavaType t = this._jsonNodeType;
/* 2357 */     if (t == null) {
/* 2358 */       t = getTypeFactory().constructType(JsonNode.class);
/* 2359 */       this._jsonNodeType = t;
/*      */     }
/* 2361 */     return t;
/*      */   }
/*      */   
/*      */   protected final void _assertNotNull(String paramName, Object src) {
/* 2365 */     if (src == null) {
/* 2366 */       throw new IllegalArgumentException(String.format("argument \"%s\" is null", new Object[] { paramName }));
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\ObjectReader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */