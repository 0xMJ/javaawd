/*    */ package com.fasterxml.jackson.databind.cfg;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoercionConfig
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 13 */   private static final int INPUT_SHAPE_COUNT = CoercionInputShape.values().length;
/*    */   
/*    */ 
/*    */   protected Boolean _acceptBlankAsEmpty;
/*    */   
/*    */ 
/*    */   protected final CoercionAction[] _coercionsByShape;
/*    */   
/*    */ 
/*    */   public CoercionConfig()
/*    */   {
/* 24 */     this._coercionsByShape = new CoercionAction[INPUT_SHAPE_COUNT];
/* 25 */     this._acceptBlankAsEmpty = Boolean.valueOf(false);
/*    */   }
/*    */   
/*    */   protected CoercionConfig(CoercionConfig src) {
/* 29 */     this._acceptBlankAsEmpty = src._acceptBlankAsEmpty;
/* 30 */     this._coercionsByShape = ((CoercionAction[])Arrays.copyOf(src._coercionsByShape, src._coercionsByShape.length));
/*    */   }
/*    */   
/*    */   public CoercionAction findAction(CoercionInputShape shape)
/*    */   {
/* 35 */     return this._coercionsByShape[shape.ordinal()];
/*    */   }
/*    */   
/*    */   public Boolean getAcceptBlankAsEmpty() {
/* 39 */     return this._acceptBlankAsEmpty;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\cfg\CoercionConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */