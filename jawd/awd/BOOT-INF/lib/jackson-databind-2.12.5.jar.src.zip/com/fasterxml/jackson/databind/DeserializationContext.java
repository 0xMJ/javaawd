/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*      */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*      */ import com.fasterxml.jackson.annotation.ObjectIdResolver;
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.ContextualKeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializerCache;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializerFactory;
/*      */ import com.fasterxml.jackson.databind.deser.UnresolvedForwardReference;
/*      */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*      */ import com.fasterxml.jackson.databind.deser.impl.TypeWrappedDeserializer;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidDefinitionException;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidFormatException;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidTypeIdException;
/*      */ import com.fasterxml.jackson.databind.exc.MismatchedInputException;
/*      */ import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
/*      */ import com.fasterxml.jackson.databind.exc.ValueInstantiationException;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*      */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.LinkedNode;
/*      */ import com.fasterxml.jackson.databind.util.ObjectBuffer;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.text.DateFormat;
/*      */ import java.text.ParseException;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class DeserializationContext
/*      */   extends DatabindContext
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   protected final DeserializerCache _cache;
/*      */   protected final DeserializerFactory _factory;
/*      */   protected final DeserializationConfig _config;
/*      */   protected final int _featureFlags;
/*      */   protected final JacksonFeatureSet<StreamReadCapability> _readCapabilities;
/*      */   protected final Class<?> _view;
/*      */   protected transient JsonParser _parser;
/*      */   protected final InjectableValues _injectableValues;
/*      */   protected transient ArrayBuilders _arrayBuilders;
/*      */   protected transient ObjectBuffer _objectBuffer;
/*      */   protected transient DateFormat _dateFormat;
/*      */   protected transient ContextAttributes _attributes;
/*      */   protected LinkedNode<JavaType> _currentType;
/*      */   
/*      */   protected DeserializationContext(DeserializerFactory df)
/*      */   {
/*  162 */     this(df, null);
/*      */   }
/*      */   
/*      */ 
/*      */   protected DeserializationContext(DeserializerFactory df, DeserializerCache cache)
/*      */   {
/*  168 */     if (df == null) {
/*  169 */       throw new NullPointerException("Cannot pass null DeserializerFactory");
/*      */     }
/*  171 */     this._factory = df;
/*  172 */     if (cache == null) {
/*  173 */       cache = new DeserializerCache();
/*      */     }
/*  175 */     this._cache = cache;
/*  176 */     this._featureFlags = 0;
/*  177 */     this._readCapabilities = null;
/*  178 */     this._config = null;
/*  179 */     this._injectableValues = null;
/*  180 */     this._view = null;
/*  181 */     this._attributes = null;
/*      */   }
/*      */   
/*      */ 
/*      */   protected DeserializationContext(DeserializationContext src, DeserializerFactory factory)
/*      */   {
/*  187 */     this._cache = src._cache;
/*  188 */     this._factory = factory;
/*      */     
/*  190 */     this._config = src._config;
/*  191 */     this._featureFlags = src._featureFlags;
/*  192 */     this._readCapabilities = src._readCapabilities;
/*  193 */     this._view = src._view;
/*  194 */     this._parser = src._parser;
/*  195 */     this._injectableValues = src._injectableValues;
/*  196 */     this._attributes = src._attributes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DeserializationContext(DeserializationContext src, DeserializationConfig config, JsonParser p, InjectableValues injectableValues)
/*      */   {
/*  206 */     this._cache = src._cache;
/*  207 */     this._factory = src._factory;
/*      */     
/*      */ 
/*      */ 
/*  211 */     this._readCapabilities = (p == null ? null : p.getReadCapabilities());
/*      */     
/*  213 */     this._config = config;
/*  214 */     this._featureFlags = config.getDeserializationFeatures();
/*  215 */     this._view = config.getActiveView();
/*  216 */     this._parser = p;
/*  217 */     this._injectableValues = injectableValues;
/*  218 */     this._attributes = config.getAttributes();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DeserializationContext(DeserializationContext src, DeserializationConfig config)
/*      */   {
/*  230 */     this._cache = src._cache;
/*  231 */     this._factory = src._factory;
/*  232 */     this._readCapabilities = null;
/*      */     
/*  234 */     this._config = config;
/*  235 */     this._featureFlags = config.getDeserializationFeatures();
/*  236 */     this._view = null;
/*  237 */     this._parser = null;
/*  238 */     this._injectableValues = null;
/*  239 */     this._attributes = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected DeserializationContext(DeserializationContext src)
/*      */   {
/*  246 */     this._cache = new DeserializerCache();
/*  247 */     this._factory = src._factory;
/*      */     
/*  249 */     this._config = src._config;
/*  250 */     this._featureFlags = src._featureFlags;
/*  251 */     this._readCapabilities = src._readCapabilities;
/*  252 */     this._view = src._view;
/*  253 */     this._injectableValues = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DeserializationConfig getConfig()
/*      */   {
/*  263 */     return this._config;
/*      */   }
/*      */   
/*  266 */   public final Class<?> getActiveView() { return this._view; }
/*      */   
/*      */   public final boolean canOverrideAccessModifiers()
/*      */   {
/*  270 */     return this._config.canOverrideAccessModifiers();
/*      */   }
/*      */   
/*      */   public final boolean isEnabled(MapperFeature feature)
/*      */   {
/*  275 */     return this._config.isEnabled(feature);
/*      */   }
/*      */   
/*      */   public final JsonFormat.Value getDefaultPropertyFormat(Class<?> baseType)
/*      */   {
/*  280 */     return this._config.getDefaultPropertyFormat(baseType);
/*      */   }
/*      */   
/*      */   public final AnnotationIntrospector getAnnotationIntrospector()
/*      */   {
/*  285 */     return this._config.getAnnotationIntrospector();
/*      */   }
/*      */   
/*      */   public final TypeFactory getTypeFactory()
/*      */   {
/*  290 */     return this._config.getTypeFactory();
/*      */   }
/*      */   
/*      */ 
/*      */   public JavaType constructSpecializedType(JavaType baseType, Class<?> subclass)
/*      */     throws IllegalArgumentException
/*      */   {
/*  297 */     if (baseType.hasRawClass(subclass)) {
/*  298 */       return baseType;
/*      */     }
/*      */     
/*      */ 
/*  302 */     return getConfig().getTypeFactory().constructSpecializedType(baseType, subclass, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Locale getLocale()
/*      */   {
/*  313 */     return this._config.getLocale();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TimeZone getTimeZone()
/*      */   {
/*  324 */     return this._config.getTimeZone();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getAttribute(Object key)
/*      */   {
/*  335 */     return this._attributes.getAttribute(key);
/*      */   }
/*      */   
/*      */ 
/*      */   public DeserializationContext setAttribute(Object key, Object value)
/*      */   {
/*  341 */     this._attributes = this._attributes.withPerCallAttribute(key, value);
/*  342 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JavaType getContextualType()
/*      */   {
/*  359 */     return this._currentType == null ? null : (JavaType)this._currentType.value();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DeserializerFactory getFactory()
/*      */   {
/*  372 */     return this._factory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isEnabled(DeserializationFeature feat)
/*      */   {
/*  383 */     return (this._featureFlags & feat.getMask()) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isEnabled(StreamReadCapability cap)
/*      */   {
/*  395 */     return this._readCapabilities.isEnabled(cap);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int getDeserializationFeatures()
/*      */   {
/*  405 */     return this._featureFlags;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean hasDeserializationFeatures(int featureMask)
/*      */   {
/*  415 */     return (this._featureFlags & featureMask) == featureMask;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean hasSomeOfFeatures(int featureMask)
/*      */   {
/*  425 */     return (this._featureFlags & featureMask) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final JsonParser getParser()
/*      */   {
/*  436 */     return this._parser;
/*      */   }
/*      */   
/*      */   public final Object findInjectableValue(Object valueId, BeanProperty forProperty, Object beanInstance)
/*      */     throws JsonMappingException
/*      */   {
/*  442 */     if (this._injectableValues == null) {
/*  443 */       reportBadDefinition(ClassUtil.classOf(valueId), String.format("No 'injectableValues' configured, cannot inject value with id [%s]", new Object[] { valueId }));
/*      */     }
/*      */     
/*  446 */     return this._injectableValues.findInjectableValue(valueId, this, forProperty, beanInstance);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Base64Variant getBase64Variant()
/*      */   {
/*  458 */     return this._config.getBase64Variant();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final JsonNodeFactory getNodeFactory()
/*      */   {
/*  468 */     return this._config.getNodeFactory();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CoercionAction findCoercionAction(LogicalType targetType, Class<?> targetClass, CoercionInputShape inputShape)
/*      */   {
/*  492 */     return this._config.findCoercionAction(targetType, targetClass, inputShape);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public CoercionAction findCoercionFromBlankString(LogicalType targetType, Class<?> targetClass, CoercionAction actionIfBlankNotAllowed)
/*      */   {
/*  515 */     return this._config.findCoercionFromBlankString(targetType, targetClass, actionIfBlankNotAllowed);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasValueDeserializerFor(JavaType type, AtomicReference<Throwable> cause)
/*      */   {
/*      */     try
/*      */     {
/*  536 */       return this._cache.hasValueDeserializerFor(this, this._factory, type);
/*      */     } catch (JsonMappingException e) {
/*  538 */       if (cause != null) {
/*  539 */         cause.set(e);
/*      */       }
/*      */     } catch (RuntimeException e) {
/*  542 */       if (cause == null) {
/*  543 */         throw e;
/*      */       }
/*  545 */       cause.set(e);
/*      */     }
/*  547 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final JsonDeserializer<Object> findContextualValueDeserializer(JavaType type, BeanProperty prop)
/*      */     throws JsonMappingException
/*      */   {
/*  558 */     JsonDeserializer<Object> deser = this._cache.findValueDeserializer(this, this._factory, type);
/*  559 */     if (deser != null) {
/*  560 */       deser = handleSecondaryContextualization(deser, prop, type);
/*      */     }
/*  562 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final JsonDeserializer<Object> findNonContextualValueDeserializer(JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/*  581 */     return this._cache.findValueDeserializer(this, this._factory, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final JsonDeserializer<Object> findRootValueDeserializer(JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/*  591 */     JsonDeserializer<Object> deser = this._cache.findValueDeserializer(this, this._factory, type);
/*      */     
/*  593 */     if (deser == null) {
/*  594 */       return null;
/*      */     }
/*  596 */     deser = handleSecondaryContextualization(deser, null, type);
/*  597 */     TypeDeserializer typeDeser = this._factory.findTypeDeserializer(this._config, type);
/*  598 */     if (typeDeser != null)
/*      */     {
/*  600 */       typeDeser = typeDeser.forProperty(null);
/*  601 */       return new TypeWrappedDeserializer(typeDeser, deser);
/*      */     }
/*  603 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final KeyDeserializer findKeyDeserializer(JavaType keyType, BeanProperty prop)
/*      */     throws JsonMappingException
/*      */   {
/*  614 */     KeyDeserializer kd = this._cache.findKeyDeserializer(this, this._factory, keyType);
/*      */     
/*      */ 
/*  617 */     if ((kd instanceof ContextualKeyDeserializer)) {
/*  618 */       kd = ((ContextualKeyDeserializer)kd).createContextual(this, prop);
/*      */     }
/*  620 */     return kd;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract ReadableObjectId findObjectId(Object paramObject, ObjectIdGenerator<?> paramObjectIdGenerator, ObjectIdResolver paramObjectIdResolver);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void checkUnresolvedObjectId()
/*      */     throws UnresolvedForwardReference;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final JavaType constructType(Class<?> cls)
/*      */   {
/*  657 */     return cls == null ? null : this._config.constructType(cls);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Class<?> findClass(String className)
/*      */     throws ClassNotFoundException
/*      */   {
/*  671 */     return getTypeFactory().findClass(className);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final ObjectBuffer leaseObjectBuffer()
/*      */   {
/*  688 */     ObjectBuffer buf = this._objectBuffer;
/*  689 */     if (buf == null) {
/*  690 */       buf = new ObjectBuffer();
/*      */     } else {
/*  692 */       this._objectBuffer = null;
/*      */     }
/*  694 */     return buf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void returnObjectBuffer(ObjectBuffer buf)
/*      */   {
/*  708 */     if ((this._objectBuffer == null) || 
/*  709 */       (buf.initialCapacity() >= this._objectBuffer.initialCapacity())) {
/*  710 */       this._objectBuffer = buf;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final ArrayBuilders getArrayBuilders()
/*      */   {
/*  720 */     if (this._arrayBuilders == null) {
/*  721 */       this._arrayBuilders = new ArrayBuilders();
/*      */     }
/*  723 */     return this._arrayBuilders;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract JsonDeserializer<Object> deserializerInstance(Annotated paramAnnotated, Object paramObject)
/*      */     throws JsonMappingException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract KeyDeserializer keyDeserializerInstance(Annotated paramAnnotated, Object paramObject)
/*      */     throws JsonMappingException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<?> handlePrimaryContextualization(JsonDeserializer<?> deser, BeanProperty prop, JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/*  762 */     if ((deser instanceof ContextualDeserializer)) {
/*  763 */       this._currentType = new LinkedNode(type, this._currentType);
/*      */       try {
/*  765 */         deser = ((ContextualDeserializer)deser).createContextual(this, prop);
/*      */       } finally {
/*  767 */         this._currentType = this._currentType.next();
/*      */       }
/*      */     }
/*  770 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<?> handleSecondaryContextualization(JsonDeserializer<?> deser, BeanProperty prop, JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/*  793 */     if ((deser instanceof ContextualDeserializer)) {
/*  794 */       this._currentType = new LinkedNode(type, this._currentType);
/*      */       try {
/*  796 */         deser = ((ContextualDeserializer)deser).createContextual(this, prop);
/*      */       } finally {
/*  798 */         this._currentType = this._currentType.next();
/*      */       }
/*      */     }
/*  801 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date parseDate(String dateStr)
/*      */     throws IllegalArgumentException
/*      */   {
/*      */     try
/*      */     {
/*  823 */       DateFormat df = _getDateFormat();
/*  824 */       return df.parse(dateStr);
/*      */     } catch (ParseException e) {
/*  826 */       throw new IllegalArgumentException(String.format("Failed to parse Date value '%s': %s", new Object[] { dateStr, 
/*      */       
/*  828 */         ClassUtil.exceptionMessage(e) }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Calendar constructCalendar(Date d)
/*      */   {
/*  838 */     Calendar c = Calendar.getInstance(getTimeZone());
/*  839 */     c.setTime(d);
/*  840 */     return c;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String extractScalarFromObject(JsonParser p, JsonDeserializer<?> deser, Class<?> scalarType)
/*      */     throws IOException
/*      */   {
/*  872 */     return (String)handleUnexpectedToken(scalarType, p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(JsonParser p, Class<T> type)
/*      */     throws IOException
/*      */   {
/*  893 */     return (T)readValue(p, getTypeFactory().constructType(type));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> T readValue(JsonParser p, JavaType type)
/*      */     throws IOException
/*      */   {
/*  901 */     JsonDeserializer<Object> deser = findRootValueDeserializer(type);
/*  902 */     if (deser == null) {
/*  903 */       reportBadDefinition(type, "Could not find JsonDeserializer for type " + 
/*  904 */         ClassUtil.getTypeDescription(type));
/*      */     }
/*  906 */     return (T)deser.deserialize(p, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readPropertyValue(JsonParser p, BeanProperty prop, Class<T> type)
/*      */     throws IOException
/*      */   {
/*  918 */     return (T)readPropertyValue(p, prop, getTypeFactory().constructType(type));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> T readPropertyValue(JsonParser p, BeanProperty prop, JavaType type)
/*      */     throws IOException
/*      */   {
/*  926 */     JsonDeserializer<Object> deser = findContextualValueDeserializer(type, prop);
/*  927 */     if (deser == null) {
/*  928 */       return (T)reportBadDefinition(type, String.format("Could not find JsonDeserializer for type %s (via property %s)", new Object[] {
/*      */       
/*  930 */         ClassUtil.getTypeDescription(type), ClassUtil.nameOf(prop) }));
/*      */     }
/*  932 */     return (T)deser.deserialize(p, this);
/*      */   }
/*      */   
/*      */ 
/*      */   public JsonNode readTree(JsonParser p)
/*      */     throws IOException
/*      */   {
/*  939 */     JsonToken t = p.currentToken();
/*  940 */     if (t == null) {
/*  941 */       t = p.nextToken();
/*  942 */       if (t == null) {
/*  943 */         return getNodeFactory().missingNode();
/*      */       }
/*      */     }
/*  946 */     if (t == JsonToken.VALUE_NULL) {
/*  947 */       return getNodeFactory().nullNode();
/*      */     }
/*  949 */     return 
/*  950 */       (JsonNode)findRootValueDeserializer(this._config.constructType(JsonNode.class)).deserialize(p, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean handleUnknownProperty(JsonParser p, JsonDeserializer<?> deser, Object instanceOrClass, String propName)
/*      */     throws IOException
/*      */   {
/*  972 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/*  973 */     while (h != null)
/*      */     {
/*  975 */       if (((DeserializationProblemHandler)h.value()).handleUnknownProperty(this, p, deser, instanceOrClass, propName)) {
/*  976 */         return true;
/*      */       }
/*  978 */       h = h.next();
/*      */     }
/*      */     
/*  981 */     if (!isEnabled(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)) {
/*  982 */       p.skipChildren();
/*  983 */       return true;
/*      */     }
/*      */     
/*  986 */     Collection<Object> propIds = deser == null ? null : deser.getKnownPropertyNames();
/*  987 */     throw UnrecognizedPropertyException.from(this._parser, instanceOrClass, propName, propIds);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object handleWeirdKey(Class<?> keyClass, String keyValue, String msg, Object... msgArgs)
/*      */     throws IOException
/*      */   {
/* 1015 */     msg = _format(msg, msgArgs);
/* 1016 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1017 */     while (h != null)
/*      */     {
/* 1019 */       Object key = ((DeserializationProblemHandler)h.value()).handleWeirdKey(this, keyClass, keyValue, msg);
/* 1020 */       if (key != DeserializationProblemHandler.NOT_HANDLED)
/*      */       {
/* 1022 */         if ((key == null) || (keyClass.isInstance(key))) {
/* 1023 */           return key;
/*      */         }
/* 1025 */         throw weirdStringException(keyValue, keyClass, String.format("DeserializationProblemHandler.handleWeirdStringValue() for type %s returned value of type %s", new Object[] {
/*      */         
/* 1027 */           ClassUtil.getClassDescription(keyClass), 
/* 1028 */           ClassUtil.getClassDescription(key) }));
/*      */       }
/*      */       
/* 1031 */       h = h.next();
/*      */     }
/* 1033 */     throw weirdKeyException(keyClass, keyValue, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object handleWeirdStringValue(Class<?> targetClass, String value, String msg, Object... msgArgs)
/*      */     throws IOException
/*      */   {
/* 1061 */     msg = _format(msg, msgArgs);
/* 1062 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1063 */     while (h != null)
/*      */     {
/* 1065 */       Object instance = ((DeserializationProblemHandler)h.value()).handleWeirdStringValue(this, targetClass, value, msg);
/* 1066 */       if (instance != DeserializationProblemHandler.NOT_HANDLED)
/*      */       {
/* 1068 */         if (_isCompatible(targetClass, instance)) {
/* 1069 */           return instance;
/*      */         }
/* 1071 */         throw weirdStringException(value, targetClass, String.format("DeserializationProblemHandler.handleWeirdStringValue() for type %s returned value of type %s", new Object[] {
/*      */         
/* 1073 */           ClassUtil.getClassDescription(targetClass), 
/* 1074 */           ClassUtil.getClassDescription(instance) }));
/*      */       }
/*      */       
/* 1077 */       h = h.next();
/*      */     }
/* 1079 */     throw weirdStringException(value, targetClass, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object handleWeirdNumberValue(Class<?> targetClass, Number value, String msg, Object... msgArgs)
/*      */     throws IOException
/*      */   {
/* 1106 */     msg = _format(msg, msgArgs);
/* 1107 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1108 */     while (h != null)
/*      */     {
/* 1110 */       Object key = ((DeserializationProblemHandler)h.value()).handleWeirdNumberValue(this, targetClass, value, msg);
/* 1111 */       if (key != DeserializationProblemHandler.NOT_HANDLED)
/*      */       {
/* 1113 */         if (_isCompatible(targetClass, key)) {
/* 1114 */           return key;
/*      */         }
/* 1116 */         throw weirdNumberException(value, targetClass, _format("DeserializationProblemHandler.handleWeirdNumberValue() for type %s returned value of type %s", new Object[] {
/*      */         
/* 1118 */           ClassUtil.getClassDescription(targetClass), 
/* 1119 */           ClassUtil.getClassDescription(key) }));
/*      */       }
/*      */       
/* 1122 */       h = h.next();
/*      */     }
/* 1124 */     throw weirdNumberException(value, targetClass, msg);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object handleWeirdNativeValue(JavaType targetType, Object badValue, JsonParser p)
/*      */     throws IOException
/*      */   {
/* 1131 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1132 */     Class<?> raw = targetType.getRawClass();
/* 1133 */     for (; h != null; h = h.next())
/*      */     {
/* 1135 */       Object goodValue = ((DeserializationProblemHandler)h.value()).handleWeirdNativeValue(this, targetType, badValue, p);
/* 1136 */       if (goodValue != DeserializationProblemHandler.NOT_HANDLED)
/*      */       {
/* 1138 */         if ((goodValue == null) || (raw.isInstance(goodValue))) {
/* 1139 */           return goodValue;
/*      */         }
/* 1141 */         throw JsonMappingException.from(p, _format("DeserializationProblemHandler.handleWeirdNativeValue() for type %s returned value of type %s", new Object[] {
/*      */         
/* 1143 */           ClassUtil.getClassDescription(targetType), 
/* 1144 */           ClassUtil.getClassDescription(goodValue) }));
/*      */       }
/*      */     }
/*      */     
/* 1148 */     throw weirdNativeValueException(badValue, raw);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object handleMissingInstantiator(Class<?> instClass, ValueInstantiator valueInst, JsonParser p, String msg, Object... msgArgs)
/*      */     throws IOException
/*      */   {
/* 1173 */     if (p == null) {
/* 1174 */       p = getParser();
/*      */     }
/* 1176 */     msg = _format(msg, msgArgs);
/* 1177 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1178 */     while (h != null)
/*      */     {
/* 1180 */       Object instance = ((DeserializationProblemHandler)h.value()).handleMissingInstantiator(this, instClass, valueInst, p, msg);
/*      */       
/* 1182 */       if (instance != DeserializationProblemHandler.NOT_HANDLED)
/*      */       {
/* 1184 */         if (_isCompatible(instClass, instance)) {
/* 1185 */           return instance;
/*      */         }
/* 1187 */         reportBadDefinition(constructType(instClass), String.format("DeserializationProblemHandler.handleMissingInstantiator() for type %s returned value of type %s", new Object[] {
/*      */         
/* 1189 */           ClassUtil.getClassDescription(instClass), 
/* 1190 */           ClassUtil.getClassDescription(instance) }));
/*      */       }
/*      */       
/* 1193 */       h = h.next();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1201 */     if (valueInst == null) {
/* 1202 */       msg = String.format("Cannot construct instance of %s: %s", new Object[] {
/* 1203 */         ClassUtil.nameOf(instClass), msg });
/* 1204 */       return reportBadDefinition(instClass, msg);
/*      */     }
/* 1206 */     if (!valueInst.canInstantiate()) {
/* 1207 */       msg = String.format("Cannot construct instance of %s (no Creators, like default constructor, exist): %s", new Object[] {
/* 1208 */         ClassUtil.nameOf(instClass), msg });
/* 1209 */       return reportBadDefinition(instClass, msg);
/*      */     }
/* 1211 */     msg = String.format("Cannot construct instance of %s (although at least one Creator exists): %s", new Object[] {
/* 1212 */       ClassUtil.nameOf(instClass), msg });
/* 1213 */     return reportInputMismatch(instClass, msg, new Object[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object handleInstantiationProblem(Class<?> instClass, Object argument, Throwable t)
/*      */     throws IOException
/*      */   {
/* 1237 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1238 */     while (h != null)
/*      */     {
/* 1240 */       Object instance = ((DeserializationProblemHandler)h.value()).handleInstantiationProblem(this, instClass, argument, t);
/* 1241 */       if (instance != DeserializationProblemHandler.NOT_HANDLED)
/*      */       {
/* 1243 */         if (_isCompatible(instClass, instance)) {
/* 1244 */           return instance;
/*      */         }
/* 1246 */         reportBadDefinition(constructType(instClass), String.format("DeserializationProblemHandler.handleInstantiationProblem() for type %s returned value of type %s", new Object[] {
/*      */         
/* 1248 */           ClassUtil.getClassDescription(instClass), 
/* 1249 */           ClassUtil.classNameOf(instance) }));
/*      */       }
/*      */       
/* 1252 */       h = h.next();
/*      */     }
/*      */     
/* 1255 */     ClassUtil.throwIfIOE(t);
/*      */     
/* 1257 */     if (!isEnabled(DeserializationFeature.WRAP_EXCEPTIONS)) {
/* 1258 */       ClassUtil.throwIfRTE(t);
/*      */     }
/* 1260 */     throw instantiationException(instClass, t);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object handleUnexpectedToken(Class<?> instClass, JsonParser p)
/*      */     throws IOException
/*      */   {
/* 1280 */     return handleUnexpectedToken(constructType(instClass), p.currentToken(), p, null, new Object[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object handleUnexpectedToken(Class<?> instClass, JsonToken t, JsonParser p, String msg, Object... msgArgs)
/*      */     throws IOException
/*      */   {
/* 1302 */     return handleUnexpectedToken(constructType(instClass), t, p, msg, msgArgs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object handleUnexpectedToken(JavaType targetType, JsonParser p)
/*      */     throws IOException
/*      */   {
/* 1322 */     return handleUnexpectedToken(targetType, p.currentToken(), p, null, new Object[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object handleUnexpectedToken(JavaType targetType, JsonToken t, JsonParser p, String msg, Object... msgArgs)
/*      */     throws IOException
/*      */   {
/* 1344 */     msg = _format(msg, msgArgs);
/* 1345 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1346 */     while (h != null) {
/* 1347 */       Object instance = ((DeserializationProblemHandler)h.value()).handleUnexpectedToken(this, targetType, t, p, msg);
/*      */       
/* 1349 */       if (instance != DeserializationProblemHandler.NOT_HANDLED) {
/* 1350 */         if (_isCompatible(targetType.getRawClass(), instance)) {
/* 1351 */           return instance;
/*      */         }
/* 1353 */         reportBadDefinition(targetType, String.format("DeserializationProblemHandler.handleUnexpectedToken() for type %s returned value of type %s", new Object[] {
/*      */         
/* 1355 */           ClassUtil.getTypeDescription(targetType), 
/* 1356 */           ClassUtil.classNameOf(instance) }));
/*      */       }
/*      */       
/* 1359 */       h = h.next();
/*      */     }
/* 1361 */     if (msg == null) {
/* 1362 */       String targetDesc = ClassUtil.getTypeDescription(targetType);
/* 1363 */       if (t == null) {
/* 1364 */         msg = String.format("Unexpected end-of-input when trying read value of type %s", new Object[] { targetDesc });
/*      */       }
/*      */       else {
/* 1367 */         msg = String.format("Cannot deserialize value of type %s from %s (token `JsonToken.%s`)", new Object[] { targetDesc, 
/* 1368 */           _shapeForToken(t), t });
/*      */       }
/*      */     }
/*      */     
/* 1372 */     if ((t != null) && (t.isScalarValue())) {
/* 1373 */       p.getText();
/*      */     }
/* 1375 */     reportInputMismatch(targetType, msg, new Object[0]);
/* 1376 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JavaType handleUnknownTypeId(JavaType baseType, String id, TypeIdResolver idResolver, String extraDesc)
/*      */     throws IOException
/*      */   {
/* 1402 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1403 */     while (h != null)
/*      */     {
/* 1405 */       JavaType type = ((DeserializationProblemHandler)h.value()).handleUnknownTypeId(this, baseType, id, idResolver, extraDesc);
/* 1406 */       if (type != null) {
/* 1407 */         if (type.hasRawClass(Void.class)) {
/* 1408 */           return null;
/*      */         }
/*      */         
/* 1411 */         if (type.isTypeOrSubTypeOf(baseType.getRawClass())) {
/* 1412 */           return type;
/*      */         }
/* 1414 */         throw invalidTypeIdException(baseType, id, "problem handler tried to resolve into non-subtype: " + 
/*      */         
/* 1416 */           ClassUtil.getTypeDescription(type));
/*      */       }
/* 1418 */       h = h.next();
/*      */     }
/*      */     
/* 1421 */     if (!isEnabled(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE)) {
/* 1422 */       return null;
/*      */     }
/* 1424 */     throw invalidTypeIdException(baseType, id, extraDesc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JavaType handleMissingTypeId(JavaType baseType, TypeIdResolver idResolver, String extraDesc)
/*      */     throws IOException
/*      */   {
/* 1433 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1434 */     while (h != null)
/*      */     {
/* 1436 */       JavaType type = ((DeserializationProblemHandler)h.value()).handleMissingTypeId(this, baseType, idResolver, extraDesc);
/* 1437 */       if (type != null) {
/* 1438 */         if (type.hasRawClass(Void.class)) {
/* 1439 */           return null;
/*      */         }
/*      */         
/* 1442 */         if (type.isTypeOrSubTypeOf(baseType.getRawClass())) {
/* 1443 */           return type;
/*      */         }
/* 1445 */         throw invalidTypeIdException(baseType, null, "problem handler tried to resolve into non-subtype: " + 
/*      */         
/* 1447 */           ClassUtil.getTypeDescription(type));
/*      */       }
/* 1449 */       h = h.next();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1456 */     throw missingTypeIdException(baseType, extraDesc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleBadMerge(JsonDeserializer<?> deser)
/*      */     throws JsonMappingException
/*      */   {
/* 1472 */     if (!isEnabled(MapperFeature.IGNORE_MERGE_FOR_UNMERGEABLE)) {
/* 1473 */       JavaType type = constructType(deser.handledType());
/* 1474 */       String msg = String.format("Invalid configuration: values of type %s cannot be merged", new Object[] {
/* 1475 */         ClassUtil.getTypeDescription(type) });
/* 1476 */       throw InvalidDefinitionException.from(getParser(), msg, type);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _isCompatible(Class<?> target, Object value)
/*      */   {
/* 1485 */     if ((value == null) || (target.isInstance(value))) {
/* 1486 */       return true;
/*      */     }
/*      */     
/* 1489 */     return (target.isPrimitive()) && 
/* 1490 */       (ClassUtil.wrapperType(target).isInstance(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reportWrongTokenException(JsonDeserializer<?> deser, JsonToken expToken, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1514 */     msg = _format(msg, msgArgs);
/* 1515 */     throw wrongTokenException(getParser(), deser.handledType(), expToken, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reportWrongTokenException(JavaType targetType, JsonToken expToken, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1532 */     msg = _format(msg, msgArgs);
/* 1533 */     throw wrongTokenException(getParser(), targetType, expToken, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reportWrongTokenException(Class<?> targetType, JsonToken expToken, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1550 */     msg = _format(msg, msgArgs);
/* 1551 */     throw wrongTokenException(getParser(), targetType, expToken, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T reportUnresolvedObjectId(ObjectIdReader oidReader, Object bean)
/*      */     throws JsonMappingException
/*      */   {
/* 1560 */     String msg = String.format("No Object Id found for an instance of %s, to assign to property '%s'", new Object[] {
/* 1561 */       ClassUtil.classNameOf(bean), oidReader.propertyName });
/* 1562 */     return (T)reportInputMismatch(oidReader.idProperty, msg, new Object[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T reportInputMismatch(JsonDeserializer<?> src, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1574 */     msg = _format(msg, msgArgs);
/* 1575 */     throw MismatchedInputException.from(getParser(), src.handledType(), msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T reportInputMismatch(Class<?> targetType, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1587 */     msg = _format(msg, msgArgs);
/* 1588 */     throw MismatchedInputException.from(getParser(), targetType, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T reportInputMismatch(JavaType targetType, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1600 */     msg = _format(msg, msgArgs);
/* 1601 */     throw MismatchedInputException.from(getParser(), targetType, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T reportInputMismatch(BeanProperty prop, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1613 */     msg = _format(msg, msgArgs);
/* 1614 */     JavaType type = prop == null ? null : prop.getType();
/* 1615 */     MismatchedInputException e = MismatchedInputException.from(getParser(), type, msg);
/*      */     
/* 1617 */     if (prop != null) {
/* 1618 */       AnnotatedMember member = prop.getMember();
/* 1619 */       if (member != null) {
/* 1620 */         e.prependPath(member.getDeclaringClass(), prop.getName());
/*      */       }
/*      */     }
/* 1623 */     throw e;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T reportPropertyInputMismatch(Class<?> targetType, String propertyName, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1635 */     msg = _format(msg, msgArgs);
/* 1636 */     MismatchedInputException e = MismatchedInputException.from(getParser(), targetType, msg);
/* 1637 */     if (propertyName != null) {
/* 1638 */       e.prependPath(targetType, propertyName);
/*      */     }
/* 1640 */     throw e;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T reportPropertyInputMismatch(JavaType targetType, String propertyName, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1652 */     return (T)reportPropertyInputMismatch(targetType.getRawClass(), propertyName, msg, msgArgs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T reportBadCoercion(JsonDeserializer<?> src, Class<?> targetType, Object inputValue, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1665 */     msg = _format(msg, msgArgs);
/* 1666 */     InvalidFormatException e = InvalidFormatException.from(getParser(), msg, inputValue, targetType);
/*      */     
/* 1668 */     throw e;
/*      */   }
/*      */   
/*      */   public <T> T reportTrailingTokens(Class<?> targetType, JsonParser p, JsonToken trailingToken)
/*      */     throws JsonMappingException
/*      */   {
/* 1674 */     throw MismatchedInputException.from(p, targetType, String.format("Trailing token (of type %s) found after value (bound as %s): not allowed as per `DeserializationFeature.FAIL_ON_TRAILING_TOKENS`", new Object[] { trailingToken, 
/*      */     
/* 1676 */       ClassUtil.nameOf(targetType) }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void reportWrongTokenException(JsonParser p, JsonToken expToken, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1685 */     msg = _format(msg, msgArgs);
/* 1686 */     throw wrongTokenException(p, expToken, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void reportUnknownProperty(Object instanceOrClass, String fieldName, JsonDeserializer<?> deser)
/*      */     throws JsonMappingException
/*      */   {
/* 1705 */     if (isEnabled(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES))
/*      */     {
/* 1707 */       Collection<Object> propIds = deser == null ? null : deser.getKnownPropertyNames();
/* 1708 */       throw UnrecognizedPropertyException.from(this._parser, instanceOrClass, fieldName, propIds);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void reportMissingContent(String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1720 */     throw MismatchedInputException.from(getParser(), (JavaType)null, "No content to map due to end-of-input");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T reportBadTypeDefinition(BeanDescription bean, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1739 */     msg = _format(msg, msgArgs);
/* 1740 */     String beanDesc = ClassUtil.nameOf(bean.getBeanClass());
/* 1741 */     msg = String.format("Invalid type definition for type %s: %s", new Object[] { beanDesc, msg });
/* 1742 */     throw InvalidDefinitionException.from(this._parser, msg, bean, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T reportBadPropertyDefinition(BeanDescription bean, BeanPropertyDefinition prop, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1754 */     msg = _format(msg, msgArgs);
/* 1755 */     String propName = ClassUtil.nameOf(prop);
/* 1756 */     String beanDesc = ClassUtil.nameOf(bean.getBeanClass());
/* 1757 */     msg = String.format("Invalid definition for property %s (of type %s): %s", new Object[] { propName, beanDesc, msg });
/*      */     
/* 1759 */     throw InvalidDefinitionException.from(this._parser, msg, bean, prop);
/*      */   }
/*      */   
/*      */   public <T> T reportBadDefinition(JavaType type, String msg) throws JsonMappingException
/*      */   {
/* 1764 */     throw InvalidDefinitionException.from(this._parser, msg, type);
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public <T> T reportBadMerge(JsonDeserializer<?> deser)
/*      */     throws JsonMappingException
/*      */   {
/* 1772 */     handleBadMerge(deser);
/* 1773 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonMappingException wrongTokenException(JsonParser p, JavaType targetType, JsonToken expToken, String extra)
/*      */   {
/* 1796 */     String msg = String.format("Unexpected token (%s), expected %s", new Object[] {p
/* 1797 */       .currentToken(), expToken });
/* 1798 */     msg = _colonConcat(msg, extra);
/* 1799 */     return MismatchedInputException.from(p, targetType, msg);
/*      */   }
/*      */   
/*      */ 
/*      */   public JsonMappingException wrongTokenException(JsonParser p, Class<?> targetType, JsonToken expToken, String extra)
/*      */   {
/* 1805 */     String msg = String.format("Unexpected token (%s), expected %s", new Object[] {p
/* 1806 */       .currentToken(), expToken });
/* 1807 */     msg = _colonConcat(msg, extra);
/* 1808 */     return MismatchedInputException.from(p, targetType, msg);
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public JsonMappingException wrongTokenException(JsonParser p, JsonToken expToken, String msg)
/*      */   {
/* 1815 */     return wrongTokenException(p, (JavaType)null, expToken, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonMappingException weirdKeyException(Class<?> keyClass, String keyValue, String msg)
/*      */   {
/* 1828 */     return InvalidFormatException.from(this._parser, 
/* 1829 */       String.format("Cannot deserialize Map key of type %s from String %s: %s", new Object[] {
/* 1830 */       ClassUtil.nameOf(keyClass), _quotedString(keyValue), msg }), keyValue, keyClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonMappingException weirdStringException(String value, Class<?> instClass, String msgBase)
/*      */   {
/* 1849 */     String msg = String.format("Cannot deserialize value of type %s from String %s: %s", new Object[] {
/* 1850 */       ClassUtil.nameOf(instClass), _quotedString(value), msgBase });
/* 1851 */     return InvalidFormatException.from(this._parser, msg, value, instClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonMappingException weirdNumberException(Number value, Class<?> instClass, String msg)
/*      */   {
/* 1863 */     return InvalidFormatException.from(this._parser, 
/* 1864 */       String.format("Cannot deserialize value of type %s from number %s: %s", new Object[] {
/* 1865 */       ClassUtil.nameOf(instClass), String.valueOf(value), msg }), value, instClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonMappingException weirdNativeValueException(Object value, Class<?> instClass)
/*      */   {
/* 1881 */     return InvalidFormatException.from(this._parser, String.format("Cannot deserialize value of type %s from native value (`JsonToken.VALUE_EMBEDDED_OBJECT`) of type %s: incompatible types", new Object[] {
/*      */     
/* 1883 */       ClassUtil.nameOf(instClass), ClassUtil.classNameOf(value) }), value, instClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonMappingException instantiationException(Class<?> instClass, Throwable cause)
/*      */   {
/*      */     String excMsg;
/*      */     
/*      */ 
/*      */ 
/*      */     String excMsg;
/*      */     
/*      */ 
/* 1898 */     if (cause == null) {
/* 1899 */       excMsg = "N/A";
/* 1900 */     } else if ((excMsg = ClassUtil.exceptionMessage(cause)) == null) {
/* 1901 */       excMsg = ClassUtil.nameOf(cause.getClass());
/*      */     }
/* 1903 */     String msg = String.format("Cannot construct instance of %s, problem: %s", new Object[] {
/* 1904 */       ClassUtil.nameOf(instClass), excMsg });
/*      */     
/*      */ 
/* 1907 */     return ValueInstantiationException.from(this._parser, msg, constructType(instClass), cause);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonMappingException instantiationException(Class<?> instClass, String msg0)
/*      */   {
/* 1922 */     return ValueInstantiationException.from(this._parser, 
/* 1923 */       String.format("Cannot construct instance of %s: %s", new Object[] {
/* 1924 */       ClassUtil.nameOf(instClass), msg0 }), 
/* 1925 */       constructType(instClass));
/*      */   }
/*      */   
/*      */ 
/*      */   public JsonMappingException invalidTypeIdException(JavaType baseType, String typeId, String extraDesc)
/*      */   {
/* 1931 */     String msg = String.format("Could not resolve type id '%s' as a subtype of %s", new Object[] { typeId, 
/* 1932 */       ClassUtil.getTypeDescription(baseType) });
/* 1933 */     return InvalidTypeIdException.from(this._parser, _colonConcat(msg, extraDesc), baseType, typeId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonMappingException missingTypeIdException(JavaType baseType, String extraDesc)
/*      */   {
/* 1941 */     String msg = String.format("Could not resolve subtype of %s", new Object[] { baseType });
/*      */     
/* 1943 */     return InvalidTypeIdException.from(this._parser, _colonConcat(msg, extraDesc), baseType, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonMappingException unknownTypeException(JavaType type, String id, String extraDesc)
/*      */   {
/* 1961 */     String msg = String.format("Could not resolve type id '%s' into a subtype of %s", new Object[] { id, 
/* 1962 */       ClassUtil.getTypeDescription(type) });
/* 1963 */     msg = _colonConcat(msg, extraDesc);
/* 1964 */     return MismatchedInputException.from(this._parser, type, msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonMappingException endOfInputException(Class<?> instClass)
/*      */   {
/* 1975 */     return MismatchedInputException.from(this._parser, instClass, "Unexpected end-of-input when trying to deserialize a " + instClass
/* 1976 */       .getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void reportMappingException(String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 2000 */     throw JsonMappingException.from(getParser(), _format(msg, msgArgs));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonMappingException mappingException(String message)
/*      */   {
/* 2016 */     return JsonMappingException.from(getParser(), message);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonMappingException mappingException(String msg, Object... msgArgs)
/*      */   {
/* 2032 */     return JsonMappingException.from(getParser(), _format(msg, msgArgs));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonMappingException mappingException(Class<?> targetClass)
/*      */   {
/* 2042 */     return mappingException(targetClass, this._parser.currentToken());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonMappingException mappingException(Class<?> targetClass, JsonToken token)
/*      */   {
/* 2050 */     return JsonMappingException.from(this._parser, 
/* 2051 */       String.format("Cannot deserialize instance of %s out of %s token", new Object[] {
/* 2052 */       ClassUtil.nameOf(targetClass), token }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected DateFormat getDateFormat()
/*      */   {
/* 2063 */     return _getDateFormat();
/*      */   }
/*      */   
/*      */   protected DateFormat _getDateFormat() {
/* 2067 */     if (this._dateFormat != null) {
/* 2068 */       return this._dateFormat;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2075 */     DateFormat df = this._config.getDateFormat();
/* 2076 */     this._dateFormat = (df = (DateFormat)df.clone());
/* 2077 */     return df;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String _shapeForToken(JsonToken t)
/*      */   {
/* 2086 */     if (t != null) {
/* 2087 */       switch (t)
/*      */       {
/*      */       case START_OBJECT: 
/*      */       case END_OBJECT: 
/*      */       case FIELD_NAME: 
/* 2092 */         return "Object value";
/*      */       
/*      */ 
/*      */       case START_ARRAY: 
/*      */       case END_ARRAY: 
/* 2097 */         return "Array value";
/*      */       
/*      */       case VALUE_FALSE: 
/*      */       case VALUE_TRUE: 
/* 2101 */         return "Boolean value";
/*      */       
/*      */       case VALUE_EMBEDDED_OBJECT: 
/* 2104 */         return "Embedded Object";
/*      */       
/*      */       case VALUE_NUMBER_FLOAT: 
/* 2107 */         return "Floating-point value";
/*      */       case VALUE_NUMBER_INT: 
/* 2109 */         return "Integer value";
/*      */       case VALUE_STRING: 
/* 2111 */         return "String value";
/*      */       
/*      */       case VALUE_NULL: 
/* 2114 */         return "Null value";
/*      */       }
/*      */       
/*      */       
/* 2118 */       return "[Unavailable value]";
/*      */     }
/*      */     
/* 2121 */     return "<end of input>";
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\DeserializationContext.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */