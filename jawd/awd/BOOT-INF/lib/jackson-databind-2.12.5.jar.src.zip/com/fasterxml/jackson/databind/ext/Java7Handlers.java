/*    */ package com.fasterxml.jackson.databind.ext;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Java7Handlers
/*    */ {
/*    */   private static final Java7Handlers IMPL;
/*    */   
/*    */   static
/*    */   {
/* 21 */     Java7Handlers impl = null;
/*    */     try {
/* 23 */       Class<?> cls = Class.forName("com.fasterxml.jackson.databind.ext.Java7HandlersImpl");
/* 24 */       impl = (Java7Handlers)ClassUtil.createInstance(cls, false);
/*    */     }
/*    */     catch (Throwable localThrowable) {}
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 32 */     IMPL = impl; }
/*    */   public abstract JsonSerializer<?> getSerializerForJavaNioFilePath(Class<?> paramClass);
/*    */   public abstract JsonDeserializer<?> getDeserializerForJavaNioFilePath(Class<?> paramClass);
/*    */   public abstract Class<?> getClassJavaNioFilePath();
/* 36 */   public static Java7Handlers instance() { return IMPL; }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\ext\Java7Handlers.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */