/*     */ package com.fasterxml.jackson.databind.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import java.text.DateFormat;
/*     */ import java.text.FieldPosition;
/*     */ import java.text.ParseException;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdDateFormat
/*     */   extends DateFormat
/*     */ {
/*     */   protected static final String PATTERN_PLAIN_STR = "\\d\\d\\d\\d[-]\\d\\d[-]\\d\\d";
/*  40 */   protected static final Pattern PATTERN_PLAIN = Pattern.compile("\\d\\d\\d\\d[-]\\d\\d[-]\\d\\d");
/*     */   protected static final Pattern PATTERN_ISO8601;
/*     */   public static final String DATE_FORMAT_STR_ISO8601 = "yyyy-MM-dd'T'HH:mm:ss.SSSX";
/*     */   protected static final String DATE_FORMAT_STR_PLAIN = "yyyy-MM-dd"; protected static final String DATE_FORMAT_STR_RFC1123 = "EEE, dd MMM yyyy HH:mm:ss zzz"; protected static final String[] ALL_FORMATS;
/*  44 */   static { Pattern p = null;
/*     */     try {
/*  46 */       p = Pattern.compile("\\d\\d\\d\\d[-]\\d\\d[-]\\d\\d[T]\\d\\d[:]\\d\\d(?:[:]\\d\\d)?(\\.\\d+)?(Z|[+-]\\d\\d(?:[:]?\\d\\d)?)?");
/*     */ 
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*     */ 
/*  52 */       throw new RuntimeException(t);
/*     */     }
/*  54 */     PATTERN_ISO8601 = p;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */     ALL_FORMATS = new String[] { "yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ss.SSS", "EEE, dd MMM yyyy HH:mm:ss zzz", "yyyy-MM-dd" };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */     DEFAULT_TIMEZONE = TimeZone.getTimeZone("UTC");
/*     */     
/*     */ 
/*  95 */     DEFAULT_LOCALE = Locale.US;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 106 */     DATE_FORMAT_RFC1123 = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", DEFAULT_LOCALE);
/* 107 */     DATE_FORMAT_RFC1123.setTimeZone(DEFAULT_TIMEZONE);
/*     */   }
/*     */   
/*     */   protected static final TimeZone DEFAULT_TIMEZONE;
/*     */   protected static final Locale DEFAULT_LOCALE;
/*     */   protected static final DateFormat DATE_FORMAT_RFC1123;
/* 113 */   public static final StdDateFormat instance = new StdDateFormat();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */   protected static final Calendar CALENDAR = new GregorianCalendar(DEFAULT_TIMEZONE, DEFAULT_LOCALE);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected transient TimeZone _timezone;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Locale _locale;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Boolean _lenient;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private transient Calendar _calendar;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private transient DateFormat _formatRFC1123;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 159 */   private boolean _tzSerializedWithColon = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StdDateFormat()
/*     */   {
/* 168 */     this._locale = DEFAULT_LOCALE;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public StdDateFormat(TimeZone tz, Locale loc) {
/* 173 */     this._timezone = tz;
/* 174 */     this._locale = loc;
/*     */   }
/*     */   
/*     */   protected StdDateFormat(TimeZone tz, Locale loc, Boolean lenient) {
/* 178 */     this(tz, loc, lenient, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected StdDateFormat(TimeZone tz, Locale loc, Boolean lenient, boolean formatTzOffsetWithColon)
/*     */   {
/* 186 */     this._timezone = tz;
/* 187 */     this._locale = loc;
/* 188 */     this._lenient = lenient;
/* 189 */     this._tzSerializedWithColon = formatTzOffsetWithColon;
/*     */   }
/*     */   
/*     */   public static TimeZone getDefaultTimeZone() {
/* 193 */     return DEFAULT_TIMEZONE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public StdDateFormat withTimeZone(TimeZone tz)
/*     */   {
/* 201 */     if (tz == null) {
/* 202 */       tz = DEFAULT_TIMEZONE;
/*     */     }
/* 204 */     if ((tz == this._timezone) || (tz.equals(this._timezone))) {
/* 205 */       return this;
/*     */     }
/* 207 */     return new StdDateFormat(tz, this._locale, this._lenient, this._tzSerializedWithColon);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StdDateFormat withLocale(Locale loc)
/*     */   {
/* 217 */     if (loc.equals(this._locale)) {
/* 218 */       return this;
/*     */     }
/* 220 */     return new StdDateFormat(this._timezone, loc, this._lenient, this._tzSerializedWithColon);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StdDateFormat withLenient(Boolean b)
/*     */   {
/* 231 */     if (_equals(b, this._lenient)) {
/* 232 */       return this;
/*     */     }
/* 234 */     return new StdDateFormat(this._timezone, this._locale, b, this._tzSerializedWithColon);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StdDateFormat withColonInTimeZone(boolean b)
/*     */   {
/* 251 */     if (this._tzSerializedWithColon == b) {
/* 252 */       return this;
/*     */     }
/* 254 */     return new StdDateFormat(this._timezone, this._locale, this._lenient, b);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public StdDateFormat clone()
/*     */   {
/* 261 */     return new StdDateFormat(this._timezone, this._locale, this._lenient, this._tzSerializedWithColon);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static DateFormat getISO8601Format(TimeZone tz, Locale loc)
/*     */   {
/* 275 */     DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX", loc);
/* 276 */     df.setTimeZone(DEFAULT_TIMEZONE);
/* 277 */     return df;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static DateFormat getRFC1123Format(TimeZone tz, Locale loc)
/*     */   {
/* 291 */     return _cloneFormat(DATE_FORMAT_RFC1123, "EEE, dd MMM yyyy HH:mm:ss zzz", tz, loc, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TimeZone getTimeZone()
/*     */   {
/* 303 */     return this._timezone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeZone(TimeZone tz)
/*     */   {
/* 311 */     if (!tz.equals(this._timezone)) {
/* 312 */       _clearFormats();
/* 313 */       this._timezone = tz;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLenient(boolean enabled)
/*     */   {
/* 324 */     Boolean newValue = Boolean.valueOf(enabled);
/* 325 */     if (!_equals(newValue, this._lenient)) {
/* 326 */       this._lenient = newValue;
/*     */       
/* 328 */       _clearFormats();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isLenient()
/*     */   {
/* 335 */     return (this._lenient == null) || (this._lenient.booleanValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isColonIncludedInTimeZone()
/*     */   {
/* 353 */     return this._tzSerializedWithColon;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date parse(String dateStr)
/*     */     throws ParseException
/*     */   {
/* 365 */     dateStr = dateStr.trim();
/* 366 */     ParsePosition pos = new ParsePosition(0);
/* 367 */     Date dt = _parseDate(dateStr, pos);
/* 368 */     if (dt != null) {
/* 369 */       return dt;
/*     */     }
/* 371 */     StringBuilder sb = new StringBuilder();
/* 372 */     for (String f : ALL_FORMATS) {
/* 373 */       if (sb.length() > 0) {
/* 374 */         sb.append("\", \"");
/*     */       } else {
/* 376 */         sb.append('"');
/*     */       }
/* 378 */       sb.append(f);
/*     */     }
/* 380 */     sb.append('"');
/*     */     
/*     */ 
/* 383 */     throw new ParseException(String.format("Cannot parse date \"%s\": not compatible with any of standard forms (%s)", new Object[] { dateStr, sb.toString() }), pos.getErrorIndex());
/*     */   }
/*     */   
/*     */ 
/*     */   public Date parse(String dateStr, ParsePosition pos)
/*     */   {
/*     */     try
/*     */     {
/* 391 */       return _parseDate(dateStr, pos);
/*     */     }
/*     */     catch (ParseException localParseException) {}
/*     */     
/* 395 */     return null;
/*     */   }
/*     */   
/*     */   protected Date _parseDate(String dateStr, ParsePosition pos) throws ParseException
/*     */   {
/* 400 */     if (looksLikeISO8601(dateStr)) {
/* 401 */       return parseAsISO8601(dateStr, pos);
/*     */     }
/*     */     
/* 404 */     int i = dateStr.length();
/* 405 */     for (;;) { i--; if (i < 0) break;
/* 406 */       char ch = dateStr.charAt(i);
/* 407 */       if (((ch < '0') || (ch > '9')) && (
/*     */       
/* 409 */         (i > 0) || (ch != '-'))) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/* 414 */     if (i < 0)
/*     */     {
/* 416 */       if ((dateStr.charAt(0) == '-') || (NumberInput.inLongRange(dateStr, false))) {
/* 417 */         return _parseDateFromLong(dateStr, pos);
/*     */       }
/*     */     }
/* 420 */     return parseAsRFC1123(dateStr, pos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringBuffer format(Date date, StringBuffer toAppendTo, FieldPosition fieldPosition)
/*     */   {
/* 433 */     TimeZone tz = this._timezone;
/* 434 */     if (tz == null) {
/* 435 */       tz = DEFAULT_TIMEZONE;
/*     */     }
/* 437 */     _format(tz, this._locale, date, toAppendTo);
/* 438 */     return toAppendTo;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void _format(TimeZone tz, Locale loc, Date date, StringBuffer buffer)
/*     */   {
/* 444 */     Calendar cal = _getCalendar(tz);
/* 445 */     cal.setTime(date);
/*     */     
/* 447 */     int year = cal.get(1);
/*     */     
/*     */ 
/* 450 */     if (cal.get(0) == 0) {
/* 451 */       _formatBCEYear(buffer, year);
/*     */     } else {
/* 453 */       if (year > 9999)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 459 */         buffer.append('+');
/*     */       }
/* 461 */       pad4(buffer, year);
/*     */     }
/* 463 */     buffer.append('-');
/* 464 */     pad2(buffer, cal.get(2) + 1);
/* 465 */     buffer.append('-');
/* 466 */     pad2(buffer, cal.get(5));
/* 467 */     buffer.append('T');
/* 468 */     pad2(buffer, cal.get(11));
/* 469 */     buffer.append(':');
/* 470 */     pad2(buffer, cal.get(12));
/* 471 */     buffer.append(':');
/* 472 */     pad2(buffer, cal.get(13));
/* 473 */     buffer.append('.');
/* 474 */     pad3(buffer, cal.get(14));
/*     */     
/* 476 */     int offset = tz.getOffset(cal.getTimeInMillis());
/* 477 */     if (offset != 0) {
/* 478 */       int hours = Math.abs(offset / 60000 / 60);
/* 479 */       int minutes = Math.abs(offset / 60000 % 60);
/* 480 */       buffer.append(offset < 0 ? '-' : '+');
/* 481 */       pad2(buffer, hours);
/* 482 */       if (this._tzSerializedWithColon) {
/* 483 */         buffer.append(':');
/*     */       }
/* 485 */       pad2(buffer, minutes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 492 */     else if (this._tzSerializedWithColon) {
/* 493 */       buffer.append("+00:00");
/*     */     } else {
/* 495 */       buffer.append("+0000");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void _formatBCEYear(StringBuffer buffer, int bceYearNoSign)
/*     */   {
/* 503 */     if (bceYearNoSign == 1) {
/* 504 */       buffer.append("+0000");
/* 505 */       return;
/*     */     }
/* 507 */     int isoYear = bceYearNoSign - 1;
/* 508 */     buffer.append('-');
/*     */     
/*     */ 
/*     */ 
/* 512 */     pad4(buffer, isoYear);
/*     */   }
/*     */   
/*     */   private static void pad2(StringBuffer buffer, int value) {
/* 516 */     int tens = value / 10;
/* 517 */     if (tens == 0) {
/* 518 */       buffer.append('0');
/*     */     } else {
/* 520 */       buffer.append((char)(48 + tens));
/* 521 */       value -= 10 * tens;
/*     */     }
/* 523 */     buffer.append((char)(48 + value));
/*     */   }
/*     */   
/*     */   private static void pad3(StringBuffer buffer, int value) {
/* 527 */     int h = value / 100;
/* 528 */     if (h == 0) {
/* 529 */       buffer.append('0');
/*     */     } else {
/* 531 */       buffer.append((char)(48 + h));
/* 532 */       value -= h * 100;
/*     */     }
/* 534 */     pad2(buffer, value);
/*     */   }
/*     */   
/*     */   private static void pad4(StringBuffer buffer, int value) {
/* 538 */     int h = value / 100;
/* 539 */     if (h == 0) {
/* 540 */       buffer.append('0').append('0');
/*     */     } else {
/* 542 */       if (h > 99) {
/* 543 */         buffer.append(h);
/*     */       } else {
/* 545 */         pad2(buffer, h);
/*     */       }
/* 547 */       value -= 100 * h;
/*     */     }
/* 549 */     pad2(buffer, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 560 */     return String.format("DateFormat %s: (timezone: %s, locale: %s, lenient: %s)", new Object[] {
/* 561 */       getClass().getName(), this._timezone, this._locale, this._lenient });
/*     */   }
/*     */   
/*     */   public String toPattern() {
/* 565 */     StringBuilder sb = new StringBuilder(100);
/* 566 */     sb.append("[one of: '")
/* 567 */       .append("yyyy-MM-dd'T'HH:mm:ss.SSSX")
/* 568 */       .append("', '")
/* 569 */       .append("EEE, dd MMM yyyy HH:mm:ss zzz")
/* 570 */       .append("' (");
/*     */     
/* 572 */     sb.append(Boolean.FALSE.equals(this._lenient) ? "strict" : "lenient")
/*     */     
/* 574 */       .append(")]");
/* 575 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 580 */     return o == this;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 585 */     return System.identityHashCode(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean looksLikeISO8601(String dateStr)
/*     */   {
/* 600 */     if ((dateStr.length() >= 7) && 
/* 601 */       (Character.isDigit(dateStr.charAt(0))) && 
/* 602 */       (Character.isDigit(dateStr.charAt(3))) && 
/* 603 */       (dateStr.charAt(4) == '-') && 
/* 604 */       (Character.isDigit(dateStr.charAt(5))))
/*     */     {
/* 606 */       return true;
/*     */     }
/* 608 */     return false;
/*     */   }
/*     */   
/*     */   private Date _parseDateFromLong(String longStr, ParsePosition pos) throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 615 */       ts = NumberInput.parseLong(longStr);
/*     */     }
/*     */     catch (NumberFormatException e) {
/*     */       long ts;
/* 619 */       throw new ParseException(String.format("Timestamp value %s out of 64-bit value range", new Object[] { longStr }), pos.getErrorIndex()); }
/*     */     long ts;
/* 621 */     return new Date(ts);
/*     */   }
/*     */   
/*     */   protected Date parseAsISO8601(String dateStr, ParsePosition pos) throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 628 */       return _parseAsISO8601(dateStr, pos);
/*     */     }
/*     */     catch (IllegalArgumentException e)
/*     */     {
/* 632 */       throw new ParseException(String.format("Cannot parse date \"%s\", problem: %s", new Object[] { dateStr, e.getMessage() }), pos.getErrorIndex());
/*     */     }
/*     */   }
/*     */   
/*     */   protected Date _parseAsISO8601(String dateStr, ParsePosition bogus)
/*     */     throws IllegalArgumentException, ParseException
/*     */   {
/* 639 */     int totalLen = dateStr.length();
/*     */     
/* 641 */     TimeZone tz = DEFAULT_TIMEZONE;
/* 642 */     if ((this._timezone != null) && ('Z' != dateStr.charAt(totalLen - 1))) {
/* 643 */       tz = this._timezone;
/*     */     }
/* 645 */     Calendar cal = _getCalendar(tz);
/* 646 */     cal.clear();
/*     */     String formatStr;
/* 648 */     String formatStr; if (totalLen <= 10) {
/* 649 */       Matcher m = PATTERN_PLAIN.matcher(dateStr);
/* 650 */       if (m.matches()) {
/* 651 */         int year = _parse4D(dateStr, 0);
/* 652 */         int month = _parse2D(dateStr, 5) - 1;
/* 653 */         int day = _parse2D(dateStr, 8);
/*     */         
/* 655 */         cal.set(year, month, day, 0, 0, 0);
/* 656 */         cal.set(14, 0);
/* 657 */         return cal.getTime();
/*     */       }
/* 659 */       formatStr = "yyyy-MM-dd";
/*     */     } else {
/* 661 */       Matcher m = PATTERN_ISO8601.matcher(dateStr);
/* 662 */       if (m.matches())
/*     */       {
/*     */ 
/* 665 */         int start = m.start(2);
/* 666 */         int end = m.end(2);
/* 667 */         int len = end - start;
/* 668 */         if (len > 1)
/*     */         {
/* 670 */           int offsetSecs = _parse2D(dateStr, start + 1) * 3600;
/* 671 */           if (len >= 5) {
/* 672 */             offsetSecs += _parse2D(dateStr, end - 2) * 60;
/*     */           }
/* 674 */           if (dateStr.charAt(start) == '-') {
/* 675 */             offsetSecs *= 64536;
/*     */           } else {
/* 677 */             offsetSecs *= 1000;
/*     */           }
/* 679 */           cal.set(15, offsetSecs);
/*     */           
/* 681 */           cal.set(16, 0);
/*     */         }
/*     */         
/* 684 */         int year = _parse4D(dateStr, 0);
/* 685 */         int month = _parse2D(dateStr, 5) - 1;
/* 686 */         int day = _parse2D(dateStr, 8);
/*     */         
/*     */ 
/* 689 */         int hour = _parse2D(dateStr, 11);
/* 690 */         int minute = _parse2D(dateStr, 14);
/*     */         
/*     */         int seconds;
/*     */         int seconds;
/* 694 */         if ((totalLen > 16) && (dateStr.charAt(16) == ':')) {
/* 695 */           seconds = _parse2D(dateStr, 17);
/*     */         } else {
/* 697 */           seconds = 0;
/*     */         }
/* 699 */         cal.set(year, month, day, hour, minute, seconds);
/*     */         
/*     */ 
/* 702 */         start = m.start(1) + 1;
/* 703 */         end = m.end(1);
/* 704 */         int msecs = 0;
/* 705 */         if (start >= end) {
/* 706 */           cal.set(14, 0);
/*     */         }
/*     */         else {
/* 709 */           msecs = 0;
/* 710 */           int fractLen = end - start;
/* 711 */           switch (fractLen)
/*     */           {
/*     */           default: 
/* 714 */             if (fractLen > 9) {
/* 715 */               throw new ParseException(String.format("Cannot parse date \"%s\": invalid fractional seconds '%s'; can use at most 9 digits", new Object[] { dateStr, m
/*     */               
/* 717 */                 .group(1).substring(1) }), start);
/*     */             }
/*     */           
/*     */ 
/*     */           case 3: 
/* 722 */             msecs += dateStr.charAt(start + 2) - '0';
/*     */           case 2: 
/* 724 */             msecs += 10 * (dateStr.charAt(start + 1) - '0');
/*     */           case 1: 
/* 726 */             msecs += 100 * (dateStr.charAt(start) - '0');
/* 727 */             break;
/*     */           }
/*     */           
/*     */           
/* 731 */           cal.set(14, msecs);
/*     */         }
/* 733 */         return cal.getTime();
/*     */       }
/* 735 */       formatStr = "yyyy-MM-dd'T'HH:mm:ss.SSSX";
/*     */     }
/*     */     
/*     */ 
/* 739 */     throw new ParseException(String.format("Cannot parse date \"%s\": while it seems to fit format '%s', parsing fails (leniency? %s)", new Object[] { dateStr, formatStr, this._lenient }), 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int _parse4D(String str, int index)
/*     */   {
/* 747 */     return 
/*     */     
/*     */ 
/* 750 */       1000 * (str.charAt(index) - '0') + 100 * (str.charAt(index + 1) - '0') + 10 * (str.charAt(index + 2) - '0') + (str.charAt(index + 3) - '0');
/*     */   }
/*     */   
/*     */   private static int _parse2D(String str, int index) {
/* 754 */     return 
/* 755 */       10 * (str.charAt(index) - '0') + (str.charAt(index + 1) - '0');
/*     */   }
/*     */   
/*     */   protected Date parseAsRFC1123(String dateStr, ParsePosition pos)
/*     */   {
/* 760 */     if (this._formatRFC1123 == null) {
/* 761 */       this._formatRFC1123 = _cloneFormat(DATE_FORMAT_RFC1123, "EEE, dd MMM yyyy HH:mm:ss zzz", this._timezone, this._locale, this._lenient);
/*     */     }
/*     */     
/* 764 */     return this._formatRFC1123.parse(dateStr, pos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final DateFormat _cloneFormat(DateFormat df, String format, TimeZone tz, Locale loc, Boolean lenient)
/*     */   {
/* 776 */     if (!loc.equals(DEFAULT_LOCALE)) {
/* 777 */       df = new SimpleDateFormat(format, loc);
/* 778 */       df.setTimeZone(tz == null ? DEFAULT_TIMEZONE : tz);
/*     */     } else {
/* 780 */       df = (DateFormat)df.clone();
/* 781 */       if (tz != null) {
/* 782 */         df.setTimeZone(tz);
/*     */       }
/*     */     }
/* 785 */     if (lenient != null) {
/* 786 */       df.setLenient(lenient.booleanValue());
/*     */     }
/* 788 */     return df;
/*     */   }
/*     */   
/*     */   protected void _clearFormats() {
/* 792 */     this._formatRFC1123 = null;
/*     */   }
/*     */   
/*     */   protected Calendar _getCalendar(TimeZone tz) {
/* 796 */     Calendar cal = this._calendar;
/* 797 */     if (cal == null) {
/* 798 */       this._calendar = (cal = (Calendar)CALENDAR.clone());
/*     */     }
/* 800 */     if (!cal.getTimeZone().equals(tz)) {
/* 801 */       cal.setTimeZone(tz);
/*     */     }
/* 803 */     cal.setLenient(isLenient());
/* 804 */     return cal;
/*     */   }
/*     */   
/*     */   protected static <T> boolean _equals(T value1, T value2) {
/* 808 */     if (value1 == value2) {
/* 809 */       return true;
/*     */     }
/* 811 */     return (value1 != null) && (value1.equals(value2));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\util\StdDateFormat.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */