/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReferenceTypeDeserializer<T>
/*     */   extends StdDeserializer<T>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   protected final JavaType _fullType;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected final TypeDeserializer _valueTypeDeserializer;
/*     */   protected final JsonDeserializer<Object> _valueDeserializer;
/*     */   
/*     */   public ReferenceTypeDeserializer(JavaType fullType, ValueInstantiator vi, TypeDeserializer typeDeser, JsonDeserializer<?> deser)
/*     */   {
/*  50 */     super(fullType);
/*  51 */     this._valueInstantiator = vi;
/*  52 */     this._fullType = fullType;
/*  53 */     this._valueDeserializer = deser;
/*  54 */     this._valueTypeDeserializer = typeDeser;
/*     */   }
/*     */   
/*     */ 
/*     */   @Deprecated
/*     */   public ReferenceTypeDeserializer(JavaType fullType, TypeDeserializer typeDeser, JsonDeserializer<?> deser)
/*     */   {
/*  61 */     this(fullType, null, typeDeser, deser);
/*     */   }
/*     */   
/*     */ 
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/*  68 */     JsonDeserializer<?> deser = this._valueDeserializer;
/*  69 */     if (deser == null) {
/*  70 */       deser = ctxt.findContextualValueDeserializer(this._fullType.getReferencedType(), property);
/*     */     } else {
/*  72 */       deser = ctxt.handleSecondaryContextualization(deser, property, this._fullType.getReferencedType());
/*     */     }
/*  74 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/*  75 */     if (typeDeser != null) {
/*  76 */       typeDeser = typeDeser.forProperty(property);
/*     */     }
/*     */     
/*  79 */     if ((deser == this._valueDeserializer) && (typeDeser == this._valueTypeDeserializer)) {
/*  80 */       return this;
/*     */     }
/*  82 */     return withResolved(typeDeser, deser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AccessPattern getNullAccessPattern()
/*     */   {
/*  97 */     return AccessPattern.DYNAMIC;
/*     */   }
/*     */   
/*     */   public AccessPattern getEmptyAccessPattern()
/*     */   {
/* 102 */     return AccessPattern.DYNAMIC;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract ReferenceTypeDeserializer<T> withResolved(TypeDeserializer paramTypeDeserializer, JsonDeserializer<?> paramJsonDeserializer);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract T getNullValue(DeserializationContext paramDeserializationContext)
/*     */     throws JsonMappingException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getEmptyValue(DeserializationContext ctxt)
/*     */     throws JsonMappingException
/*     */   {
/* 126 */     return getNullValue(ctxt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract T referenceValue(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract T updateReference(T paramT, Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Object getReferenced(T paramT);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValueInstantiator getValueInstantiator()
/*     */   {
/* 157 */     return this._valueInstantiator;
/*     */   }
/*     */   
/* 160 */   public JavaType getValueType() { return this._fullType; }
/*     */   
/*     */   public LogicalType logicalType()
/*     */   {
/* 164 */     if (this._valueDeserializer != null) {
/* 165 */       return this._valueDeserializer.logicalType();
/*     */     }
/* 167 */     return super.logicalType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean supportsUpdate(DeserializationConfig config)
/*     */   {
/* 177 */     return this._valueDeserializer == null ? null : this._valueDeserializer
/* 178 */       .supportsUpdate(config);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T deserialize(JsonParser p, DeserializationContext ctxt)
/*     */     throws IOException
/*     */   {
/* 191 */     if (this._valueInstantiator != null)
/*     */     {
/* 193 */       T value = this._valueInstantiator.createUsingDefault(ctxt);
/* 194 */       return (T)deserialize(p, ctxt, value);
/*     */     }
/*     */     
/*     */ 
/* 198 */     Object contents = this._valueTypeDeserializer == null ? this._valueDeserializer.deserialize(p, ctxt) : this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/* 199 */     return (T)referenceValue(contents);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public T deserialize(JsonParser p, DeserializationContext ctxt, T reference)
/*     */     throws IOException
/*     */   {
/* 207 */     Boolean B = this._valueDeserializer.supportsUpdate(ctxt.getConfig());
/*     */     Object contents;
/* 209 */     Object contents; if ((B.equals(Boolean.FALSE)) || (this._valueTypeDeserializer != null))
/*     */     {
/*     */ 
/* 212 */       contents = this._valueTypeDeserializer == null ? this._valueDeserializer.deserialize(p, ctxt) : this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/*     */     }
/*     */     else {
/* 215 */       contents = getReferenced(reference);
/*     */       
/* 217 */       if (contents == null)
/*     */       {
/*     */ 
/* 220 */         contents = this._valueTypeDeserializer == null ? this._valueDeserializer.deserialize(p, ctxt) : this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/* 221 */         return (T)referenceValue(contents);
/*     */       }
/* 223 */       contents = this._valueDeserializer.deserialize(p, ctxt, contents);
/*     */     }
/*     */     
/* 226 */     return (T)updateReference(reference, contents);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*     */     throws IOException
/*     */   {
/* 233 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/* 234 */       return getNullValue(ctxt);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 248 */     if (this._valueTypeDeserializer == null) {
/* 249 */       return deserialize(p, ctxt);
/*     */     }
/* 251 */     return referenceValue(this._valueTypeDeserializer.deserializeTypedFromAny(p, ctxt));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\std\ReferenceTypeDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */