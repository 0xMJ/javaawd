/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnnotatedField
/*     */   extends AnnotatedMember
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final transient Field _field;
/*     */   protected Serialization _serialization;
/*     */   
/*     */   public AnnotatedField(TypeResolutionContext contextClass, Field field, AnnotationMap annMap)
/*     */   {
/*  39 */     super(contextClass, annMap);
/*  40 */     this._field = field;
/*     */   }
/*     */   
/*     */   public AnnotatedField withAnnotations(AnnotationMap ann)
/*     */   {
/*  45 */     return new AnnotatedField(this._typeContext, this._field, ann);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AnnotatedField(Serialization ser)
/*     */   {
/*  53 */     super(null, null);
/*  54 */     this._field = null;
/*  55 */     this._serialization = ser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Field getAnnotated()
/*     */   {
/*  65 */     return this._field;
/*     */   }
/*     */   
/*  68 */   public int getModifiers() { return this._field.getModifiers(); }
/*     */   
/*     */   public String getName() {
/*  71 */     return this._field.getName();
/*     */   }
/*     */   
/*     */   public Class<?> getRawType() {
/*  75 */     return this._field.getType();
/*     */   }
/*     */   
/*     */   public JavaType getType()
/*     */   {
/*  80 */     return this._typeContext.resolveType(this._field.getGenericType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getDeclaringClass()
/*     */   {
/*  90 */     return this._field.getDeclaringClass();
/*     */   }
/*     */   
/*  93 */   public Member getMember() { return this._field; }
/*     */   
/*     */   public void setValue(Object pojo, Object value) throws IllegalArgumentException
/*     */   {
/*     */     try
/*     */     {
/*  99 */       this._field.set(pojo, value);
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 102 */       throw new IllegalArgumentException("Failed to setValue() for field " + getFullName() + ": " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getValue(Object pojo) throws IllegalArgumentException
/*     */   {
/*     */     try
/*     */     {
/* 110 */       return this._field.get(pojo);
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 113 */       throw new IllegalArgumentException("Failed to getValue() for field " + getFullName() + ": " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAnnotationCount()
/*     */   {
/* 123 */     return this._annotations.size();
/*     */   }
/*     */   
/*     */   public boolean isTransient()
/*     */   {
/* 128 */     return Modifier.isTransient(getModifiers());
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 132 */     return this._field.getName().hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 137 */     if (o == this) return true;
/* 138 */     return (ClassUtil.hasClass(o, getClass())) && (((AnnotatedField)o)._field == this._field);
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 144 */     return "[field " + getFullName() + "]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object writeReplace()
/*     */   {
/* 154 */     return new AnnotatedField(new Serialization(this._field));
/*     */   }
/*     */   
/*     */   Object readResolve() {
/* 158 */     Class<?> clazz = this._serialization.clazz;
/*     */     try {
/* 160 */       Field f = clazz.getDeclaredField(this._serialization.name);
/*     */       
/* 162 */       if (!f.isAccessible()) {
/* 163 */         ClassUtil.checkAndFixAccess(f, false);
/*     */       }
/* 165 */       return new AnnotatedField(null, f, null);
/*     */     }
/*     */     catch (Exception e) {
/* 168 */       throw new IllegalArgumentException("Could not find method '" + this._serialization.name + "' from Class '" + clazz.getName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class Serialization
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     protected Class<?> clazz;
/*     */     
/*     */     protected String name;
/*     */     
/*     */ 
/*     */     public Serialization(Field f)
/*     */     {
/* 185 */       this.clazz = f.getDeclaringClass();
/* 186 */       this.name = f.getName();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\introspect\AnnotatedField.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */