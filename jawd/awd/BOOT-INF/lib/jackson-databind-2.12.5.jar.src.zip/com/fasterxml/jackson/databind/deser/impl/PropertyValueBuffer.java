/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.deser.SettableAnyProperty;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import java.io.IOException;
/*     */ import java.util.BitSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyValueBuffer
/*     */ {
/*     */   protected final JsonParser _parser;
/*     */   protected final DeserializationContext _context;
/*     */   protected final ObjectIdReader _objectIdReader;
/*     */   protected final Object[] _creatorParameters;
/*     */   protected int _paramsNeeded;
/*     */   protected int _paramsSeen;
/*     */   protected final BitSet _paramsSeenBig;
/*     */   protected PropertyValue _buffered;
/*     */   protected Object _idValue;
/*     */   
/*     */   public PropertyValueBuffer(JsonParser p, DeserializationContext ctxt, int paramCount, ObjectIdReader oir)
/*     */   {
/*  89 */     this._parser = p;
/*  90 */     this._context = ctxt;
/*  91 */     this._paramsNeeded = paramCount;
/*  92 */     this._objectIdReader = oir;
/*  93 */     this._creatorParameters = new Object[paramCount];
/*  94 */     if (paramCount < 32) {
/*  95 */       this._paramsSeenBig = null;
/*     */     } else {
/*  97 */       this._paramsSeenBig = new BitSet();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean hasParameter(SettableBeanProperty prop)
/*     */   {
/* 109 */     if (this._paramsSeenBig == null) {
/* 110 */       return (this._paramsSeen >> prop.getCreatorIndex() & 0x1) == 1;
/*     */     }
/* 112 */     return this._paramsSeenBig.get(prop.getCreatorIndex());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getParameter(SettableBeanProperty prop)
/*     */     throws JsonMappingException
/*     */   {
/*     */     Object value;
/*     */     
/*     */ 
/*     */ 
/*     */     Object value;
/*     */     
/*     */ 
/*     */ 
/* 129 */     if (hasParameter(prop)) {
/* 130 */       value = this._creatorParameters[prop.getCreatorIndex()];
/*     */     } else {
/* 132 */       value = this._creatorParameters[prop.getCreatorIndex()] = _findMissing(prop);
/*     */     }
/* 134 */     if ((value == null) && (this._context.isEnabled(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES))) {
/* 135 */       return this._context.reportInputMismatch(prop, "Null value for creator property '%s' (index %d); `DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES` enabled", new Object[] {prop
/*     */       
/* 137 */         .getName(), Integer.valueOf(prop.getCreatorIndex()) });
/*     */     }
/* 139 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object[] getParameters(SettableBeanProperty[] props)
/*     */     throws JsonMappingException
/*     */   {
/* 153 */     if (this._paramsNeeded > 0) {
/* 154 */       if (this._paramsSeenBig == null) {
/* 155 */         int mask = this._paramsSeen;
/*     */         
/*     */ 
/* 158 */         int ix = 0; for (int len = this._creatorParameters.length; ix < len; mask >>= 1) {
/* 159 */           if ((mask & 0x1) == 0) {
/* 160 */             this._creatorParameters[ix] = _findMissing(props[ix]);
/*     */           }
/* 158 */           ix++;
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 164 */         int len = this._creatorParameters.length;
/* 165 */         for (int ix = 0; (ix = this._paramsSeenBig.nextClearBit(ix)) < len; ix++) {
/* 166 */           this._creatorParameters[ix] = _findMissing(props[ix]);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 171 */     if (this._context.isEnabled(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES)) {
/* 172 */       for (int ix = 0; ix < props.length; ix++) {
/* 173 */         if (this._creatorParameters[ix] == null) {
/* 174 */           SettableBeanProperty prop = props[ix];
/* 175 */           this._context.reportInputMismatch(prop, "Null value for creator property '%s' (index %d); `DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES` enabled", new Object[] {prop
/*     */           
/* 177 */             .getName(), Integer.valueOf(props[ix].getCreatorIndex()) });
/*     */         }
/*     */       }
/*     */     }
/* 181 */     return this._creatorParameters;
/*     */   }
/*     */   
/*     */   protected Object _findMissing(SettableBeanProperty prop)
/*     */     throws JsonMappingException
/*     */   {
/* 187 */     Object injectableValueId = prop.getInjectableValueId();
/* 188 */     if (injectableValueId != null) {
/* 189 */       return this._context.findInjectableValue(prop.getInjectableValueId(), prop, null);
/*     */     }
/*     */     
/*     */ 
/* 193 */     if (prop.isRequired()) {
/* 194 */       this._context.reportInputMismatch(prop, "Missing required creator property '%s' (index %d)", new Object[] {prop
/* 195 */         .getName(), Integer.valueOf(prop.getCreatorIndex()) });
/*     */     }
/* 197 */     if (this._context.isEnabled(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES)) {
/* 198 */       this._context.reportInputMismatch(prop, "Missing creator property '%s' (index %d); `DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES` enabled", new Object[] {prop
/*     */       
/* 200 */         .getName(), Integer.valueOf(prop.getCreatorIndex()) });
/*     */     }
/*     */     try
/*     */     {
/* 204 */       Object nullValue = prop.getNullValueProvider().getNullValue(this._context);
/* 205 */       if (nullValue != null) {
/* 206 */         return nullValue;
/*     */       }
/*     */       
/*     */ 
/* 210 */       JsonDeserializer<Object> deser = prop.getValueDeserializer();
/* 211 */       return deser.getNullValue(this._context);
/*     */     }
/*     */     catch (JsonMappingException e) {
/* 214 */       AnnotatedMember member = prop.getMember();
/* 215 */       if (member != null) {
/* 216 */         e.prependPath(member.getDeclaringClass(), prop.getName());
/*     */       }
/* 218 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean readIdProperty(String propName)
/*     */     throws IOException
/*     */   {
/* 236 */     if ((this._objectIdReader != null) && (propName.equals(this._objectIdReader.propertyName.getSimpleName()))) {
/* 237 */       this._idValue = this._objectIdReader.readObjectReference(this._parser, this._context);
/* 238 */       return true;
/*     */     }
/* 240 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object handleIdValue(DeserializationContext ctxt, Object bean)
/*     */     throws IOException
/*     */   {
/* 248 */     if (this._objectIdReader != null) {
/* 249 */       if (this._idValue != null) {
/* 250 */         ReadableObjectId roid = ctxt.findObjectId(this._idValue, this._objectIdReader.generator, this._objectIdReader.resolver);
/* 251 */         roid.bindItem(bean);
/*     */         
/* 253 */         SettableBeanProperty idProp = this._objectIdReader.idProperty;
/* 254 */         if (idProp != null) {
/* 255 */           return idProp.setAndReturn(bean, this._idValue);
/*     */         }
/*     */       }
/*     */       else {
/* 259 */         ctxt.reportUnresolvedObjectId(this._objectIdReader, bean);
/*     */       }
/*     */     }
/* 262 */     return bean;
/*     */   }
/*     */   
/* 265 */   protected PropertyValue buffered() { return this._buffered; }
/*     */   
/* 267 */   public boolean isComplete() { return this._paramsNeeded <= 0; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean assignParameter(SettableBeanProperty prop, Object value)
/*     */   {
/* 279 */     int ix = prop.getCreatorIndex();
/* 280 */     this._creatorParameters[ix] = value;
/* 281 */     if (this._paramsSeenBig == null) {
/* 282 */       int old = this._paramsSeen;
/* 283 */       int newValue = old | 1 << ix;
/* 284 */       if (old != newValue) {
/* 285 */         this._paramsSeen = newValue;
/* 286 */         if (--this._paramsNeeded <= 0)
/*     */         {
/* 288 */           return (this._objectIdReader == null) || (this._idValue != null);
/*     */         }
/*     */       }
/*     */     }
/* 292 */     else if (!this._paramsSeenBig.get(ix)) {
/* 293 */       this._paramsSeenBig.set(ix);
/* 294 */       if (--this._paramsNeeded > 0) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 299 */     return false;
/*     */   }
/*     */   
/*     */   public void bufferProperty(SettableBeanProperty prop, Object value) {
/* 303 */     this._buffered = new PropertyValue.Regular(this._buffered, value, prop);
/*     */   }
/*     */   
/*     */   public void bufferAnyProperty(SettableAnyProperty prop, String propName, Object value) {
/* 307 */     this._buffered = new PropertyValue.Any(this._buffered, value, prop, propName);
/*     */   }
/*     */   
/*     */   public void bufferMapProperty(Object key, Object value) {
/* 311 */     this._buffered = new PropertyValue.Map(this._buffered, value, key);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\impl\PropertyValueBuffer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */