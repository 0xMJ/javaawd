/*      */ package com.fasterxml.jackson.databind.util;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import java.io.IOException;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.Collection;
/*      */ import java.util.EnumMap;
/*      */ import java.util.EnumSet;
/*      */ import java.util.List;
/*      */ 
/*      */ public final class ClassUtil
/*      */ {
/*   19 */   private static final Class<?> CLS_OBJECT = Object.class;
/*      */   
/*   21 */   private static final Annotation[] NO_ANNOTATIONS = new Annotation[0];
/*   22 */   private static final Ctor[] NO_CTORS = new Ctor[0];
/*      */   
/*   24 */   private static final java.util.Iterator<?> EMPTY_ITERATOR = java.util.Collections.emptyIterator();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <T> java.util.Iterator<T> emptyIterator()
/*      */   {
/*   37 */     return EMPTY_ITERATOR;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List<JavaType> findSuperTypes(JavaType type, Class<?> endBefore, boolean addClassItself)
/*      */   {
/*   62 */     if ((type == null) || (type.hasRawClass(endBefore)) || (type.hasRawClass(Object.class))) {
/*   63 */       return java.util.Collections.emptyList();
/*      */     }
/*   65 */     List<JavaType> result = new java.util.ArrayList(8);
/*   66 */     _addSuperTypes(type, endBefore, result, addClassItself);
/*   67 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static List<Class<?>> findRawSuperTypes(Class<?> cls, Class<?> endBefore, boolean addClassItself)
/*      */   {
/*   74 */     if ((cls == null) || (cls == endBefore) || (cls == Object.class)) {
/*   75 */       return java.util.Collections.emptyList();
/*      */     }
/*   77 */     List<Class<?>> result = new java.util.ArrayList(8);
/*   78 */     _addRawSuperTypes(cls, endBefore, result, addClassItself);
/*   79 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List<Class<?>> findSuperClasses(Class<?> cls, Class<?> endBefore, boolean addClassItself)
/*      */   {
/*   94 */     List<Class<?>> result = new java.util.ArrayList(8);
/*   95 */     if ((cls != null) && (cls != endBefore)) {
/*   96 */       if (addClassItself) {
/*   97 */         result.add(cls);
/*      */       }
/*   99 */       while (((cls = cls.getSuperclass()) != null) && 
/*  100 */         (cls != endBefore))
/*      */       {
/*      */ 
/*  103 */         result.add(cls);
/*      */       }
/*      */     }
/*  106 */     return result;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static List<Class<?>> findSuperTypes(Class<?> cls, Class<?> endBefore) {
/*  111 */     return findSuperTypes(cls, endBefore, new java.util.ArrayList(8));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static List<Class<?>> findSuperTypes(Class<?> cls, Class<?> endBefore, List<Class<?>> result) {
/*  116 */     _addRawSuperTypes(cls, endBefore, result, false);
/*  117 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   private static void _addSuperTypes(JavaType type, Class<?> endBefore, Collection<JavaType> result, boolean addClassItself)
/*      */   {
/*  123 */     if (type == null) {
/*  124 */       return;
/*      */     }
/*  126 */     Class<?> cls = type.getRawClass();
/*  127 */     if ((cls == endBefore) || (cls == Object.class)) return;
/*  128 */     if (addClassItself) {
/*  129 */       if (result.contains(type)) {
/*  130 */         return;
/*      */       }
/*  132 */       result.add(type);
/*      */     }
/*  134 */     for (JavaType intCls : type.getInterfaces()) {
/*  135 */       _addSuperTypes(intCls, endBefore, result, true);
/*      */     }
/*  137 */     _addSuperTypes(type.getSuperClass(), endBefore, result, true);
/*      */   }
/*      */   
/*      */   private static void _addRawSuperTypes(Class<?> cls, Class<?> endBefore, Collection<Class<?>> result, boolean addClassItself) {
/*  141 */     if ((cls == endBefore) || (cls == null) || (cls == Object.class)) return;
/*  142 */     if (addClassItself) {
/*  143 */       if (result.contains(cls)) {
/*  144 */         return;
/*      */       }
/*  146 */       result.add(cls);
/*      */     }
/*  148 */     for (Class<?> intCls : _interfaces(cls)) {
/*  149 */       _addRawSuperTypes(intCls, endBefore, result, true);
/*      */     }
/*  151 */     _addRawSuperTypes(cls.getSuperclass(), endBefore, result, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String canBeABeanType(Class<?> type)
/*      */   {
/*  167 */     if (type.isAnnotation()) {
/*  168 */       return "annotation";
/*      */     }
/*  170 */     if (type.isArray()) {
/*  171 */       return "array";
/*      */     }
/*  173 */     if (Enum.class.isAssignableFrom(type)) {
/*  174 */       return "enum";
/*      */     }
/*  176 */     if (type.isPrimitive()) {
/*  177 */       return "primitive";
/*      */     }
/*      */     
/*      */ 
/*  181 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String isLocalType(Class<?> type, boolean allowNonStatic)
/*      */   {
/*      */     try
/*      */     {
/*  191 */       boolean isStatic = Modifier.isStatic(type.getModifiers());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  196 */       if ((!isStatic) && (hasEnclosingMethod(type))) {
/*  197 */         return "local/anonymous";
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  203 */       if ((!allowNonStatic) && 
/*  204 */         (!isStatic) && (getEnclosingClass(type) != null)) {
/*  205 */         return "non-static member class";
/*      */       }
/*      */     }
/*      */     catch (SecurityException localSecurityException) {}catch (NullPointerException localNullPointerException) {}
/*      */     
/*      */ 
/*  211 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> getOuterClass(Class<?> type)
/*      */   {
/*  220 */     if (!Modifier.isStatic(type.getModifiers())) {
/*      */       try
/*      */       {
/*  223 */         if (hasEnclosingMethod(type)) {
/*  224 */           return null;
/*      */         }
/*  226 */         return getEnclosingClass(type);
/*      */       } catch (SecurityException localSecurityException) {}
/*      */     }
/*  229 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isProxyType(Class<?> type)
/*      */   {
/*  246 */     String name = type.getName();
/*      */     
/*  248 */     if ((name.startsWith("net.sf.cglib.proxy.")) || 
/*  249 */       (name.startsWith("org.hibernate.proxy."))) {
/*  250 */       return true;
/*      */     }
/*      */     
/*  253 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isConcrete(Class<?> type)
/*      */   {
/*  262 */     int mod = type.getModifiers();
/*  263 */     return (mod & 0x600) == 0;
/*      */   }
/*      */   
/*      */   public static boolean isConcrete(Member member)
/*      */   {
/*  268 */     int mod = member.getModifiers();
/*  269 */     return (mod & 0x600) == 0;
/*      */   }
/*      */   
/*      */   public static boolean isCollectionMapOrArray(Class<?> type)
/*      */   {
/*  274 */     if (type.isArray()) return true;
/*  275 */     if (Collection.class.isAssignableFrom(type)) return true;
/*  276 */     if (java.util.Map.class.isAssignableFrom(type)) return true;
/*  277 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean isBogusClass(Class<?> cls) {
/*  281 */     return (cls == Void.class) || (cls == Void.TYPE) || (cls == com.fasterxml.jackson.databind.annotation.NoClass.class);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isRecordType(Class<?> cls)
/*      */   {
/*  291 */     Class<?> parent = cls.getSuperclass();
/*  292 */     return (parent != null) && ("java.lang.Record".equals(parent.getName()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static boolean isObjectOrPrimitive(Class<?> cls)
/*      */   {
/*  299 */     return (cls == CLS_OBJECT) || (cls.isPrimitive());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean hasClass(Object inst, Class<?> raw)
/*      */   {
/*  308 */     return (inst != null) && (inst.getClass() == raw);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void verifyMustOverride(Class<?> expType, Object instance, String method)
/*      */   {
/*  317 */     if (instance.getClass() != expType) {
/*  318 */       throw new IllegalStateException(String.format("Sub-class %s (of class %s) must override method '%s'", new Object[] {instance
/*      */       
/*  320 */         .getClass().getName(), expType.getName(), method }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static boolean hasGetterSignature(Method m)
/*      */   {
/*  337 */     if (Modifier.isStatic(m.getModifiers())) {
/*  338 */       return false;
/*      */     }
/*      */     
/*  341 */     Class<?>[] pts = m.getParameterTypes();
/*  342 */     if ((pts != null) && (pts.length != 0)) {
/*  343 */       return false;
/*      */     }
/*      */     
/*  346 */     if (Void.TYPE == m.getReturnType()) {
/*  347 */       return false;
/*      */     }
/*      */     
/*  350 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Throwable throwIfError(Throwable t)
/*      */   {
/*  366 */     if ((t instanceof Error)) {
/*  367 */       throw ((Error)t);
/*      */     }
/*  369 */     return t;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Throwable throwIfRTE(Throwable t)
/*      */   {
/*  379 */     if ((t instanceof RuntimeException)) {
/*  380 */       throw ((RuntimeException)t);
/*      */     }
/*  382 */     return t;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Throwable throwIfIOE(Throwable t)
/*      */     throws IOException
/*      */   {
/*  392 */     if ((t instanceof IOException)) {
/*  393 */       throw ((IOException)t);
/*      */     }
/*  395 */     return t;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Throwable getRootCause(Throwable t)
/*      */   {
/*  410 */     while (t.getCause() != null) {
/*  411 */       t = t.getCause();
/*      */     }
/*  413 */     return t;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Throwable throwRootCauseIfIOE(Throwable t)
/*      */     throws IOException
/*      */   {
/*  424 */     return throwIfIOE(getRootCause(t));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void throwAsIAE(Throwable t)
/*      */   {
/*  432 */     throwAsIAE(t, t.getMessage());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void throwAsIAE(Throwable t, String msg)
/*      */   {
/*  442 */     throwIfRTE(t);
/*  443 */     throwIfError(t);
/*  444 */     throw new IllegalArgumentException(msg, t);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static <T> T throwAsMappingException(com.fasterxml.jackson.databind.DeserializationContext ctxt, IOException e0)
/*      */     throws com.fasterxml.jackson.databind.JsonMappingException
/*      */   {
/*  452 */     if ((e0 instanceof com.fasterxml.jackson.databind.JsonMappingException)) {
/*  453 */       throw ((com.fasterxml.jackson.databind.JsonMappingException)e0);
/*      */     }
/*  455 */     com.fasterxml.jackson.databind.JsonMappingException e = com.fasterxml.jackson.databind.JsonMappingException.from(ctxt, e0.getMessage());
/*  456 */     e.initCause(e0);
/*  457 */     throw e;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void unwrapAndThrowAsIAE(Throwable t)
/*      */   {
/*  467 */     throwAsIAE(getRootCause(t));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void unwrapAndThrowAsIAE(Throwable t, String msg)
/*      */   {
/*  477 */     throwAsIAE(getRootCause(t), msg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void closeOnFailAndThrowAsIOE(JsonGenerator g, Exception fail)
/*      */     throws IOException
/*      */   {
/*  495 */     g.disable(com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT);
/*      */     try {
/*  497 */       g.close();
/*      */     } catch (Exception e) {
/*  499 */       fail.addSuppressed(e);
/*      */     }
/*  501 */     throwIfIOE(fail);
/*  502 */     throwIfRTE(fail);
/*  503 */     throw new RuntimeException(fail);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void closeOnFailAndThrowAsIOE(JsonGenerator g, java.io.Closeable toClose, Exception fail)
/*      */     throws IOException
/*      */   {
/*  519 */     if (g != null) {
/*  520 */       g.disable(com.fasterxml.jackson.core.JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT);
/*      */       try {
/*  522 */         g.close();
/*      */       } catch (Exception e) {
/*  524 */         fail.addSuppressed(e);
/*      */       }
/*      */     }
/*  527 */     if (toClose != null) {
/*      */       try {
/*  529 */         toClose.close();
/*      */       } catch (Exception e) {
/*  531 */         fail.addSuppressed(e);
/*      */       }
/*      */     }
/*  534 */     throwIfIOE(fail);
/*  535 */     throwIfRTE(fail);
/*  536 */     throw new RuntimeException(fail);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <T> T createInstance(Class<T> cls, boolean canFixAccess)
/*      */     throws IllegalArgumentException
/*      */   {
/*  561 */     Constructor<T> ctor = findConstructor(cls, canFixAccess);
/*  562 */     if (ctor == null) {
/*  563 */       throw new IllegalArgumentException("Class " + cls.getName() + " has no default (no arg) constructor");
/*      */     }
/*      */     try {
/*  566 */       return (T)ctor.newInstance(new Object[0]);
/*      */     } catch (Exception e) {
/*  568 */       unwrapAndThrowAsIAE(e, "Failed to instantiate class " + cls.getName() + ", problem: " + e.getMessage()); }
/*  569 */     return null;
/*      */   }
/*      */   
/*      */   public static <T> Constructor<T> findConstructor(Class<T> cls, boolean forceAccess)
/*      */     throws IllegalArgumentException
/*      */   {
/*      */     try
/*      */     {
/*  577 */       Constructor<T> ctor = cls.getDeclaredConstructor(new Class[0]);
/*  578 */       if (forceAccess) {
/*  579 */         checkAndFixAccess(ctor, forceAccess);
/*      */ 
/*      */       }
/*  582 */       else if (!Modifier.isPublic(ctor.getModifiers())) {
/*  583 */         throw new IllegalArgumentException("Default constructor for " + cls.getName() + " is not accessible (non-public?): not allowed to try modify access via Reflection: cannot instantiate type");
/*      */       }
/*      */       
/*  586 */       return ctor;
/*      */     }
/*      */     catch (NoSuchMethodException localNoSuchMethodException) {}catch (Exception e)
/*      */     {
/*  590 */       unwrapAndThrowAsIAE(e, "Failed to find default constructor of class " + cls.getName() + ", problem: " + e.getMessage());
/*      */     }
/*  592 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> classOf(Object inst)
/*      */   {
/*  605 */     if (inst == null) {
/*  606 */       return null;
/*      */     }
/*  608 */     return inst.getClass();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static Class<?> rawClass(JavaType t)
/*      */   {
/*  615 */     if (t == null) {
/*  616 */       return null;
/*      */     }
/*  618 */     return t.getRawClass();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static <T> T nonNull(T valueOrNull, T defaultValue)
/*      */   {
/*  625 */     return valueOrNull == null ? defaultValue : valueOrNull;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static String nullOrToString(Object value)
/*      */   {
/*  632 */     if (value == null) {
/*  633 */       return null;
/*      */     }
/*  635 */     return value.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static String nonNullString(String str)
/*      */   {
/*  642 */     if (str == null) {
/*  643 */       return "";
/*      */     }
/*  645 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String quotedOr(Object str, String forNull)
/*      */   {
/*  655 */     if (str == null) {
/*  656 */       return forNull;
/*      */     }
/*  658 */     return String.format("\"%s\"", new Object[] { str });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getClassDescription(Object classOrInstance)
/*      */   {
/*  674 */     if (classOrInstance == null) {
/*  675 */       return "unknown";
/*      */     }
/*      */     
/*  678 */     Class<?> cls = (classOrInstance instanceof Class) ? (Class)classOrInstance : classOrInstance.getClass();
/*  679 */     return nameOf(cls);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getTypeDescription(JavaType fullType)
/*      */   {
/*  695 */     if (fullType == null) {
/*  696 */       return "[null]";
/*      */     }
/*  698 */     StringBuilder sb = new StringBuilder(80).append('`');
/*  699 */     sb.append(fullType.toCanonical());
/*  700 */     return '`';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String classNameOf(Object inst)
/*      */   {
/*  711 */     if (inst == null) {
/*  712 */       return "[null]";
/*      */     }
/*  714 */     Class<?> raw = (inst instanceof Class) ? (Class)inst : inst.getClass();
/*  715 */     return nameOf(raw);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String nameOf(Class<?> cls)
/*      */   {
/*  725 */     if (cls == null) {
/*  726 */       return "[null]";
/*      */     }
/*  728 */     int index = 0;
/*  729 */     while (cls.isArray()) {
/*  730 */       index++;
/*  731 */       cls = cls.getComponentType();
/*      */     }
/*  733 */     String base = cls.isPrimitive() ? cls.getSimpleName() : cls.getName();
/*  734 */     if (index > 0) {
/*  735 */       StringBuilder sb = new StringBuilder(base);
/*      */       do {
/*  737 */         sb.append("[]");
/*  738 */         index--; } while (index > 0);
/*  739 */       base = sb.toString();
/*      */     }
/*  741 */     return backticked(base);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String nameOf(Named named)
/*      */   {
/*  754 */     if (named == null) {
/*  755 */       return "[null]";
/*      */     }
/*  757 */     return apostrophed(named.getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String name(String name)
/*      */   {
/*  767 */     if (name == null) {
/*  768 */       return "[null]";
/*      */     }
/*  770 */     return apostrophed(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String name(com.fasterxml.jackson.databind.PropertyName name)
/*      */   {
/*  780 */     if (name == null) {
/*  781 */       return "[null]";
/*      */     }
/*      */     
/*  784 */     return apostrophed(name.getSimpleName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String backticked(String text)
/*      */   {
/*  799 */     if (text == null) {
/*  800 */       return "[null]";
/*      */     }
/*  802 */     return text.length() + 2 + '`' + text + '`';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String apostrophed(String text)
/*      */   {
/*  811 */     if (text == null) {
/*  812 */       return "[null]";
/*      */     }
/*  814 */     return text.length() + 2 + '\'' + text + '\'';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String exceptionMessage(Throwable t)
/*      */   {
/*  827 */     if ((t instanceof com.fasterxml.jackson.core.JsonProcessingException)) {
/*  828 */       return ((com.fasterxml.jackson.core.JsonProcessingException)t).getOriginalMessage();
/*      */     }
/*  830 */     return t.getMessage();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object defaultValue(Class<?> cls)
/*      */   {
/*  845 */     if (cls == Integer.TYPE) {
/*  846 */       return Integer.valueOf(0);
/*      */     }
/*  848 */     if (cls == Long.TYPE) {
/*  849 */       return Long.valueOf(0L);
/*      */     }
/*  851 */     if (cls == Boolean.TYPE) {
/*  852 */       return Boolean.FALSE;
/*      */     }
/*  854 */     if (cls == Double.TYPE) {
/*  855 */       return Double.valueOf(0.0D);
/*      */     }
/*  857 */     if (cls == Float.TYPE) {
/*  858 */       return Float.valueOf(0.0F);
/*      */     }
/*  860 */     if (cls == Byte.TYPE) {
/*  861 */       return Byte.valueOf((byte)0);
/*      */     }
/*  863 */     if (cls == Short.TYPE) {
/*  864 */       return Short.valueOf((short)0);
/*      */     }
/*  866 */     if (cls == Character.TYPE) {
/*  867 */       return Character.valueOf('\000');
/*      */     }
/*  869 */     throw new IllegalArgumentException("Class " + cls.getName() + " is not a primitive type");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> wrapperType(Class<?> primitiveType)
/*      */   {
/*  878 */     if (primitiveType == Integer.TYPE) {
/*  879 */       return Integer.class;
/*      */     }
/*  881 */     if (primitiveType == Long.TYPE) {
/*  882 */       return Long.class;
/*      */     }
/*  884 */     if (primitiveType == Boolean.TYPE) {
/*  885 */       return Boolean.class;
/*      */     }
/*  887 */     if (primitiveType == Double.TYPE) {
/*  888 */       return Double.class;
/*      */     }
/*  890 */     if (primitiveType == Float.TYPE) {
/*  891 */       return Float.class;
/*      */     }
/*  893 */     if (primitiveType == Byte.TYPE) {
/*  894 */       return Byte.class;
/*      */     }
/*  896 */     if (primitiveType == Short.TYPE) {
/*  897 */       return Short.class;
/*      */     }
/*  899 */     if (primitiveType == Character.TYPE) {
/*  900 */       return Character.class;
/*      */     }
/*  902 */     throw new IllegalArgumentException("Class " + primitiveType.getName() + " is not a primitive type");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> primitiveType(Class<?> type)
/*      */   {
/*  913 */     if (type.isPrimitive()) {
/*  914 */       return type;
/*      */     }
/*      */     
/*  917 */     if (type == Integer.class) {
/*  918 */       return Integer.TYPE;
/*      */     }
/*  920 */     if (type == Long.class) {
/*  921 */       return Long.TYPE;
/*      */     }
/*  923 */     if (type == Boolean.class) {
/*  924 */       return Boolean.TYPE;
/*      */     }
/*  926 */     if (type == Double.class) {
/*  927 */       return Double.TYPE;
/*      */     }
/*  929 */     if (type == Float.class) {
/*  930 */       return Float.TYPE;
/*      */     }
/*  932 */     if (type == Byte.class) {
/*  933 */       return Byte.TYPE;
/*      */     }
/*  935 */     if (type == Short.class) {
/*  936 */       return Short.TYPE;
/*      */     }
/*  938 */     if (type == Character.class) {
/*  939 */       return Character.TYPE;
/*      */     }
/*  941 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static void checkAndFixAccess(Member member)
/*      */   {
/*  960 */     checkAndFixAccess(member, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void checkAndFixAccess(Member member, boolean force)
/*      */   {
/*  977 */     java.lang.reflect.AccessibleObject ao = (java.lang.reflect.AccessibleObject)member;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  984 */       if ((force) || 
/*  985 */         (!Modifier.isPublic(member.getModifiers())) || 
/*  986 */         (!Modifier.isPublic(member.getDeclaringClass().getModifiers()))) {
/*  987 */         ao.setAccessible(true);
/*      */       }
/*      */     }
/*      */     catch (SecurityException se)
/*      */     {
/*  992 */       if (!ao.isAccessible()) {
/*  993 */         Class<?> declClass = member.getDeclaringClass();
/*  994 */         throw new IllegalArgumentException("Cannot access " + member + " (from class " + declClass.getName() + "; failed to set access: " + se.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isEnumType(Class<?> rawType)
/*      */   {
/* 1012 */     return Enum.class.isAssignableFrom(rawType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<? extends Enum<?>> findEnumType(EnumSet<?> s)
/*      */   {
/* 1024 */     if (!s.isEmpty()) {
/* 1025 */       return findEnumType((Enum)s.iterator().next());
/*      */     }
/*      */     
/* 1028 */     return EnumTypeLocator.instance.enumTypeFor(s);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<? extends Enum<?>> findEnumType(EnumMap<?, ?> m)
/*      */   {
/* 1039 */     if (!m.isEmpty()) {
/* 1040 */       return findEnumType((Enum)m.keySet().iterator().next());
/*      */     }
/*      */     
/* 1043 */     return EnumTypeLocator.instance.enumTypeFor(m);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<? extends Enum<?>> findEnumType(Enum<?> en)
/*      */   {
/* 1055 */     return en.getDeclaringClass();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<? extends Enum<?>> findEnumType(Class<?> cls)
/*      */   {
/* 1068 */     if (cls.getSuperclass() != Enum.class) {
/* 1069 */       cls = cls.getSuperclass();
/*      */     }
/* 1071 */     return cls;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <T extends Annotation> Enum<?> findFirstAnnotatedEnumValue(Class<Enum<?>> enumClass, Class<T> annotationClass)
/*      */   {
/* 1087 */     Field[] fields = enumClass.getDeclaredFields();
/* 1088 */     for (Field field : fields) {
/* 1089 */       if (field.isEnumConstant()) {
/* 1090 */         Annotation defaultValueAnnotation = field.getAnnotation(annotationClass);
/* 1091 */         if (defaultValueAnnotation != null) {
/* 1092 */           String name = field.getName();
/* 1093 */           for (Enum<?> enumValue : (Enum[])enumClass.getEnumConstants()) {
/* 1094 */             if (name.equals(enumValue.name())) {
/* 1095 */               return enumValue;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1101 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isJacksonStdImpl(Object impl)
/*      */   {
/* 1121 */     return (impl == null) || (isJacksonStdImpl(impl.getClass()));
/*      */   }
/*      */   
/*      */   public static boolean isJacksonStdImpl(Class<?> implClass) {
/* 1125 */     return implClass.getAnnotation(com.fasterxml.jackson.databind.annotation.JacksonStdImpl.class) != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isJDKClass(Class<?> rawType)
/*      */   {
/* 1142 */     String clsName = rawType.getName();
/* 1143 */     return (clsName.startsWith("java.")) || (clsName.startsWith("javax."));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isNonStaticInnerClass(Class<?> cls)
/*      */   {
/* 1156 */     return (!Modifier.isStatic(cls.getModifiers())) && 
/* 1157 */       (getEnclosingClass(cls) != null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static String getPackageName(Class<?> cls)
/*      */   {
/* 1167 */     Package pkg = cls.getPackage();
/* 1168 */     return pkg == null ? null : pkg.getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static boolean hasEnclosingMethod(Class<?> cls)
/*      */   {
/* 1175 */     return (!isObjectOrPrimitive(cls)) && (cls.getEnclosingMethod() != null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static Field[] getDeclaredFields(Class<?> cls)
/*      */   {
/* 1183 */     return cls.getDeclaredFields();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static Method[] getDeclaredMethods(Class<?> cls)
/*      */   {
/* 1191 */     return cls.getDeclaredMethods();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static Annotation[] findClassAnnotations(Class<?> cls)
/*      */   {
/* 1198 */     if (isObjectOrPrimitive(cls)) {
/* 1199 */       return NO_ANNOTATIONS;
/*      */     }
/* 1201 */     return cls.getDeclaredAnnotations();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Method[] getClassMethods(Class<?> cls)
/*      */   {
/*      */     try
/*      */     {
/* 1214 */       return cls.getDeclaredMethods();
/*      */     }
/*      */     catch (NoClassDefFoundError ex)
/*      */     {
/* 1218 */       ClassLoader loader = Thread.currentThread().getContextClassLoader();
/* 1219 */       if (loader == null)
/*      */       {
/* 1221 */         return _failGetClassMethods(cls, ex);
/*      */       }
/*      */       try
/*      */       {
/* 1225 */         contextClass = loader.loadClass(cls.getName());
/*      */       } catch (ClassNotFoundException e) { Class<?> contextClass;
/* 1227 */         ex.addSuppressed(e);
/* 1228 */         return _failGetClassMethods(cls, ex);
/*      */       }
/*      */       try { Class<?> contextClass;
/* 1231 */         return contextClass.getDeclaredMethods();
/*      */       } catch (Throwable t) {
/* 1233 */         return _failGetClassMethods(cls, t);
/*      */       }
/*      */     } catch (Throwable t) {
/* 1236 */       return _failGetClassMethods(cls, t);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static Method[] _failGetClassMethods(Class<?> cls, Throwable rootCause)
/*      */     throws IllegalArgumentException
/*      */   {
/* 1244 */     throw new IllegalArgumentException(String.format("Failed on call to `getDeclaredMethods()` on class `%s`, problem: (%s) %s", new Object[] {cls
/*      */     
/* 1246 */       .getName(), rootCause.getClass().getName(), rootCause.getMessage() }), rootCause);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Ctor[] getConstructors(Class<?> cls)
/*      */   {
/* 1256 */     if ((cls.isInterface()) || (isObjectOrPrimitive(cls))) {
/* 1257 */       return NO_CTORS;
/*      */     }
/* 1259 */     Constructor<?>[] rawCtors = cls.getDeclaredConstructors();
/* 1260 */     int len = rawCtors.length;
/* 1261 */     Ctor[] result = new Ctor[len];
/* 1262 */     for (int i = 0; i < len; i++) {
/* 1263 */       result[i] = new Ctor(rawCtors[i]);
/*      */     }
/* 1265 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> getDeclaringClass(Class<?> cls)
/*      */   {
/* 1275 */     return isObjectOrPrimitive(cls) ? null : cls.getDeclaringClass();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static java.lang.reflect.Type getGenericSuperclass(Class<?> cls)
/*      */   {
/* 1282 */     return cls.getGenericSuperclass();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static java.lang.reflect.Type[] getGenericInterfaces(Class<?> cls)
/*      */   {
/* 1289 */     return cls.getGenericInterfaces();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Class<?> getEnclosingClass(Class<?> cls)
/*      */   {
/* 1297 */     return isObjectOrPrimitive(cls) ? null : cls.getEnclosingClass();
/*      */   }
/*      */   
/*      */   private static Class<?>[] _interfaces(Class<?> cls) {
/* 1301 */     return cls.getInterfaces();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class EnumTypeLocator
/*      */   {
/* 1316 */     static final EnumTypeLocator instance = new EnumTypeLocator();
/*      */     
/*      */     private final Field enumSetTypeField;
/*      */     
/*      */     private final Field enumMapTypeField;
/*      */     
/*      */     private EnumTypeLocator()
/*      */     {
/* 1324 */       this.enumSetTypeField = locateField(EnumSet.class, "elementType", Class.class);
/* 1325 */       this.enumMapTypeField = locateField(EnumMap.class, "elementType", Class.class);
/*      */     }
/*      */     
/*      */ 
/*      */     public Class<? extends Enum<?>> enumTypeFor(EnumSet<?> set)
/*      */     {
/* 1331 */       if (this.enumSetTypeField != null) {
/* 1332 */         return (Class)get(set, this.enumSetTypeField);
/*      */       }
/* 1334 */       throw new IllegalStateException("Cannot figure out type for EnumSet (odd JDK platform?)");
/*      */     }
/*      */     
/*      */ 
/*      */     public Class<? extends Enum<?>> enumTypeFor(EnumMap<?, ?> set)
/*      */     {
/* 1340 */       if (this.enumMapTypeField != null) {
/* 1341 */         return (Class)get(set, this.enumMapTypeField);
/*      */       }
/* 1343 */       throw new IllegalStateException("Cannot figure out type for EnumMap (odd JDK platform?)");
/*      */     }
/*      */     
/*      */     private Object get(Object bean, Field field)
/*      */     {
/*      */       try {
/* 1349 */         return field.get(bean);
/*      */       } catch (Exception e) {
/* 1351 */         throw new IllegalArgumentException(e);
/*      */       }
/*      */     }
/*      */     
/*      */     private static Field locateField(Class<?> fromClass, String expectedName, Class<?> type)
/*      */     {
/* 1357 */       Field found = null;
/*      */       
/* 1359 */       Field[] fields = fromClass.getDeclaredFields();
/* 1360 */       for (Field f : fields) {
/* 1361 */         if ((expectedName.equals(f.getName())) && (f.getType() == type)) {
/* 1362 */           found = f;
/* 1363 */           break;
/*      */         }
/*      */       }
/*      */       
/* 1367 */       if (found == null) {
/* 1368 */         for (Field f : fields) {
/* 1369 */           if (f.getType() == type)
/*      */           {
/* 1371 */             if (found != null) return null;
/* 1372 */             found = f;
/*      */           }
/*      */         }
/*      */       }
/* 1376 */       if (found != null) {
/*      */         try {
/* 1378 */           found.setAccessible(true);
/*      */         } catch (Throwable localThrowable1) {}
/*      */       }
/* 1381 */       return found;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final class Ctor
/*      */   {
/*      */     public final Constructor<?> _ctor;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private transient Annotation[] _annotations;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private transient Annotation[][] _paramAnnotations;
/*      */     
/*      */ 
/*      */ 
/* 1405 */     private int _paramCount = -1;
/*      */     
/*      */     public Ctor(Constructor<?> ctor) {
/* 1408 */       this._ctor = ctor;
/*      */     }
/*      */     
/*      */     public Constructor<?> getConstructor() {
/* 1412 */       return this._ctor;
/*      */     }
/*      */     
/*      */     public int getParamCount() {
/* 1416 */       int c = this._paramCount;
/* 1417 */       if (c < 0) {
/* 1418 */         c = this._ctor.getParameterTypes().length;
/* 1419 */         this._paramCount = c;
/*      */       }
/* 1421 */       return c;
/*      */     }
/*      */     
/*      */     public Class<?> getDeclaringClass() {
/* 1425 */       return this._ctor.getDeclaringClass();
/*      */     }
/*      */     
/*      */     public Annotation[] getDeclaredAnnotations() {
/* 1429 */       Annotation[] result = this._annotations;
/* 1430 */       if (result == null) {
/* 1431 */         result = this._ctor.getDeclaredAnnotations();
/* 1432 */         this._annotations = result;
/*      */       }
/* 1434 */       return result;
/*      */     }
/*      */     
/*      */     public Annotation[][] getParameterAnnotations() {
/* 1438 */       Annotation[][] result = this._paramAnnotations;
/* 1439 */       if (result == null) {
/* 1440 */         result = this._ctor.getParameterAnnotations();
/* 1441 */         this._paramAnnotations = result;
/*      */       }
/* 1443 */       return result;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\util\ClassUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */