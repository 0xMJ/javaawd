/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.util.JsonParserSequence;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsPropertyTypeDeserializer
/*     */   extends AsArrayTypeDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JsonTypeInfo.As _inclusion;
/*  32 */   protected final String _msgForMissingId = this._property == null ? 
/*  33 */     String.format("missing type id property '%s'", new Object[] { this._typePropertyName }) : 
/*  34 */     String.format("missing type id property '%s' (for POJO property '%s')", new Object[] { this._typePropertyName, this._property.getName() });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsPropertyTypeDeserializer(JavaType bt, TypeIdResolver idRes, String typePropertyName, boolean typeIdVisible, JavaType defaultImpl)
/*     */   {
/*  42 */     this(bt, idRes, typePropertyName, typeIdVisible, defaultImpl, JsonTypeInfo.As.PROPERTY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsPropertyTypeDeserializer(JavaType bt, TypeIdResolver idRes, String typePropertyName, boolean typeIdVisible, JavaType defaultImpl, JsonTypeInfo.As inclusion)
/*     */   {
/*  52 */     super(bt, idRes, typePropertyName, typeIdVisible, defaultImpl);
/*  53 */     this._inclusion = inclusion;
/*     */   }
/*     */   
/*     */   public AsPropertyTypeDeserializer(AsPropertyTypeDeserializer src, BeanProperty property) {
/*  57 */     super(src, property);
/*  58 */     this._inclusion = src._inclusion;
/*     */   }
/*     */   
/*     */   public TypeDeserializer forProperty(BeanProperty prop)
/*     */   {
/*  63 */     return prop == this._property ? this : new AsPropertyTypeDeserializer(this, prop);
/*     */   }
/*     */   
/*     */   public JsonTypeInfo.As getTypeInclusion() {
/*  67 */     return this._inclusion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object deserializeTypedFromObject(JsonParser p, DeserializationContext ctxt)
/*     */     throws IOException
/*     */   {
/*  77 */     if (p.canReadTypeId()) {
/*  78 */       Object typeId = p.getTypeId();
/*  79 */       if (typeId != null) {
/*  80 */         return _deserializeWithNativeTypeId(p, ctxt, typeId);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  85 */     JsonToken t = p.currentToken();
/*  86 */     if (t == JsonToken.START_OBJECT) {
/*  87 */       t = p.nextToken();
/*  88 */     } else if (t != JsonToken.FIELD_NAME)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */       return _deserializeTypedUsingDefaultImpl(p, ctxt, null, this._msgForMissingId);
/*     */     }
/*     */     
/*  99 */     TokenBuffer tb = null;
/* 100 */     boolean ignoreCase = ctxt.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
/* 102 */     for (; 
/* 102 */         t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 103 */       String name = p.currentName();
/* 104 */       p.nextToken();
/* 105 */       if ((name.equals(this._typePropertyName)) || ((ignoreCase) && 
/* 106 */         (name.equalsIgnoreCase(this._typePropertyName)))) {
/* 107 */         return _deserializeTypedForId(p, ctxt, tb, p.getText());
/*     */       }
/* 109 */       if (tb == null) {
/* 110 */         tb = new TokenBuffer(p, ctxt);
/*     */       }
/* 112 */       tb.writeFieldName(name);
/* 113 */       tb.copyCurrentStructure(p);
/*     */     }
/* 115 */     return _deserializeTypedUsingDefaultImpl(p, ctxt, tb, this._msgForMissingId);
/*     */   }
/*     */   
/*     */   protected Object _deserializeTypedForId(JsonParser p, DeserializationContext ctxt, TokenBuffer tb, String typeId) throws IOException
/*     */   {
/* 120 */     JsonDeserializer<Object> deser = _findDeserializer(ctxt, typeId);
/* 121 */     if (this._typeIdVisible) {
/* 122 */       if (tb == null) {
/* 123 */         tb = new TokenBuffer(p, ctxt);
/*     */       }
/* 125 */       tb.writeFieldName(p.currentName());
/* 126 */       tb.writeString(typeId);
/*     */     }
/* 128 */     if (tb != null)
/*     */     {
/*     */ 
/* 131 */       p.clearCurrentToken();
/* 132 */       p = JsonParserSequence.createFlattened(false, tb.asParser(p), p);
/*     */     }
/* 134 */     if (p.currentToken() != JsonToken.END_OBJECT)
/*     */     {
/* 136 */       p.nextToken();
/*     */     }
/*     */     
/* 139 */     return deser.deserialize(p, ctxt);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected Object _deserializeTypedUsingDefaultImpl(JsonParser p, DeserializationContext ctxt, TokenBuffer tb) throws IOException
/*     */   {
/* 145 */     return _deserializeTypedUsingDefaultImpl(p, ctxt, tb, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object _deserializeTypedUsingDefaultImpl(JsonParser p, DeserializationContext ctxt, TokenBuffer tb, String priorFailureMsg)
/*     */     throws IOException
/*     */   {
/* 157 */     if (!hasDefaultImpl())
/*     */     {
/* 159 */       Object result = TypeDeserializer.deserializeIfNatural(p, ctxt, this._baseType);
/* 160 */       if (result != null) {
/* 161 */         return result;
/*     */       }
/*     */       
/* 164 */       if (p.isExpectedStartArrayToken()) {
/* 165 */         return super.deserializeTypedFromAny(p, ctxt);
/*     */       }
/* 167 */       if ((p.hasToken(JsonToken.VALUE_STRING)) && 
/* 168 */         (ctxt.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT))) {
/* 169 */         String str = p.getText().trim();
/* 170 */         if (str.isEmpty()) {
/* 171 */           return null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 178 */     JsonDeserializer<Object> deser = _findDefaultImplDeserializer(ctxt);
/* 179 */     if (deser == null) {
/* 180 */       JavaType t = _handleMissingTypeId(ctxt, priorFailureMsg);
/* 181 */       if (t == null)
/*     */       {
/* 183 */         return null;
/*     */       }
/*     */       
/* 186 */       deser = ctxt.findContextualValueDeserializer(t, this._property);
/*     */     }
/* 188 */     if (tb != null) {
/* 189 */       tb.writeEndObject();
/* 190 */       p = tb.asParser(p);
/*     */       
/* 192 */       p.nextToken();
/*     */     }
/* 194 */     return deser.deserialize(p, ctxt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object deserializeTypedFromAny(JsonParser p, DeserializationContext ctxt)
/*     */     throws IOException
/*     */   {
/* 205 */     if (p.hasToken(JsonToken.START_ARRAY)) {
/* 206 */       return super.deserializeTypedFromArray(p, ctxt);
/*     */     }
/* 208 */     return deserializeTypedFromObject(p, ctxt);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\jsontype\impl\AsPropertyTypeDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */