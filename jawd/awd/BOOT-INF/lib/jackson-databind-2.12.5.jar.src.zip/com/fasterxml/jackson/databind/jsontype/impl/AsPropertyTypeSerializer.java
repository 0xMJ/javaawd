/*    */ package com.fasterxml.jackson.databind.jsontype.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
/*    */ import com.fasterxml.jackson.databind.BeanProperty;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AsPropertyTypeSerializer
/*    */   extends AsArrayTypeSerializer
/*    */ {
/*    */   protected final String _typePropertyName;
/*    */   
/*    */   public AsPropertyTypeSerializer(TypeIdResolver idRes, BeanProperty property, String propName)
/*    */   {
/* 22 */     super(idRes, property);
/* 23 */     this._typePropertyName = propName;
/*    */   }
/*    */   
/*    */   public AsPropertyTypeSerializer forProperty(BeanProperty prop)
/*    */   {
/* 28 */     return this._property == prop ? this : new AsPropertyTypeSerializer(this._idResolver, prop, this._typePropertyName);
/*    */   }
/*    */   
/*    */   public String getPropertyName()
/*    */   {
/* 33 */     return this._typePropertyName;
/*    */   }
/*    */   
/* 36 */   public JsonTypeInfo.As getTypeInclusion() { return JsonTypeInfo.As.PROPERTY; }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\jsontype\impl\AsPropertyTypeSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */