/*    */ package com.fasterxml.jackson.databind.deser.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedTypeDeserializer
/*    */   extends StdDeserializer<Object>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final JavaType _type;
/*    */   protected final String _message;
/*    */   
/*    */   public UnsupportedTypeDeserializer(JavaType t, String m)
/*    */   {
/* 29 */     super(t);
/* 30 */     this._type = t;
/* 31 */     this._message = m;
/*    */   }
/*    */   
/*    */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException
/*    */   {
/* 36 */     ctxt.reportBadDefinition(this._type, this._message);
/* 37 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\impl\UnsupportedTypeDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */