/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.StdDateFormat;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class DateDeserializers
/*     */ {
/*  27 */   private static final HashSet<String> _utilClasses = new HashSet();
/*     */   
/*  29 */   static { _utilClasses.add("java.util.Calendar");
/*  30 */     _utilClasses.add("java.util.GregorianCalendar");
/*  31 */     _utilClasses.add("java.util.Date");
/*     */   }
/*     */   
/*     */   public static JsonDeserializer<?> find(Class<?> rawType, String clsName)
/*     */   {
/*  36 */     if (_utilClasses.contains(clsName))
/*     */     {
/*  38 */       if (rawType == Calendar.class) {
/*  39 */         return new CalendarDeserializer();
/*     */       }
/*  41 */       if (rawType == java.util.Date.class) {
/*  42 */         return DateDeserializer.instance;
/*     */       }
/*  44 */       if (rawType == GregorianCalendar.class) {
/*  45 */         return new CalendarDeserializer(GregorianCalendar.class);
/*     */       }
/*     */     }
/*  48 */     return null;
/*     */   }
/*     */   
/*     */   public static boolean hasDeserializerFor(Class<?> rawType)
/*     */   {
/*  53 */     return _utilClasses.contains(rawType.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static abstract class DateBasedDeserializer<T>
/*     */     extends StdScalarDeserializer<T>
/*     */     implements ContextualDeserializer
/*     */   {
/*     */     protected final DateFormat _customFormat;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected final String _formatString;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected DateBasedDeserializer(Class<?> clz)
/*     */     {
/*  78 */       super();
/*  79 */       this._customFormat = null;
/*  80 */       this._formatString = null;
/*     */     }
/*     */     
/*     */     protected DateBasedDeserializer(DateBasedDeserializer<T> base, DateFormat format, String formatStr)
/*     */     {
/*  85 */       super();
/*  86 */       this._customFormat = format;
/*  87 */       this._formatString = formatStr;
/*     */     }
/*     */     
/*     */     protected abstract DateBasedDeserializer<T> withDateFormat(DateFormat paramDateFormat, String paramString);
/*     */     
/*     */     public LogicalType logicalType()
/*     */     {
/*  94 */       return LogicalType.DateTime;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property)
/*     */       throws com.fasterxml.jackson.databind.JsonMappingException
/*     */     {
/* 102 */       JsonFormat.Value format = findFormatOverrides(ctxt, property, 
/* 103 */         handledType());
/*     */       
/* 105 */       if (format != null) {
/* 106 */         TimeZone tz = format.getTimeZone();
/* 107 */         Boolean lenient = format.getLenient();
/*     */         
/*     */ 
/* 110 */         if (format.hasPattern()) {
/* 111 */           String pattern = format.getPattern();
/* 112 */           Locale loc = format.hasLocale() ? format.getLocale() : ctxt.getLocale();
/* 113 */           SimpleDateFormat df = new SimpleDateFormat(pattern, loc);
/* 114 */           if (tz == null) {
/* 115 */             tz = ctxt.getTimeZone();
/*     */           }
/* 117 */           df.setTimeZone(tz);
/* 118 */           if (lenient != null) {
/* 119 */             df.setLenient(lenient.booleanValue());
/*     */           }
/* 121 */           return withDateFormat(df, pattern);
/*     */         }
/*     */         
/* 124 */         if (tz != null) {
/* 125 */           DateFormat df = ctxt.getConfig().getDateFormat();
/*     */           
/* 127 */           if (df.getClass() == StdDateFormat.class) {
/* 128 */             Locale loc = format.hasLocale() ? format.getLocale() : ctxt.getLocale();
/* 129 */             StdDateFormat std = (StdDateFormat)df;
/* 130 */             std = std.withTimeZone(tz);
/* 131 */             std = std.withLocale(loc);
/* 132 */             if (lenient != null) {
/* 133 */               std = std.withLenient(lenient);
/*     */             }
/* 135 */             df = std;
/*     */           }
/*     */           else {
/* 138 */             df = (DateFormat)df.clone();
/* 139 */             df.setTimeZone(tz);
/* 140 */             if (lenient != null) {
/* 141 */               df.setLenient(lenient.booleanValue());
/*     */             }
/*     */           }
/* 144 */           return withDateFormat(df, this._formatString);
/*     */         }
/*     */         
/* 147 */         if (lenient != null) {
/* 148 */           DateFormat df = ctxt.getConfig().getDateFormat();
/* 149 */           String pattern = this._formatString;
/*     */           
/* 151 */           if (df.getClass() == StdDateFormat.class) {
/* 152 */             StdDateFormat std = (StdDateFormat)df;
/* 153 */             std = std.withLenient(lenient);
/* 154 */             df = std;
/* 155 */             pattern = std.toPattern();
/*     */           }
/*     */           else {
/* 158 */             df = (DateFormat)df.clone();
/* 159 */             df.setLenient(lenient.booleanValue());
/* 160 */             if ((df instanceof SimpleDateFormat)) {
/* 161 */               ((SimpleDateFormat)df).toPattern();
/*     */             }
/*     */           }
/* 164 */           if (pattern == null) {
/* 165 */             pattern = "[unknown]";
/*     */           }
/* 167 */           return withDateFormat(df, pattern);
/*     */         }
/*     */       }
/* 170 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */     protected java.util.Date _parseDate(JsonParser p, DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/* 177 */       if ((this._customFormat != null) && 
/* 178 */         (p.hasToken(com.fasterxml.jackson.core.JsonToken.VALUE_STRING))) {
/* 179 */         String str = p.getText().trim();
/* 180 */         if (str.isEmpty()) {
/* 181 */           com.fasterxml.jackson.databind.cfg.CoercionAction act = _checkFromStringCoercion(ctxt, str);
/* 182 */           switch (DateDeserializers.1.$SwitchMap$com$fasterxml$jackson$databind$cfg$CoercionAction[act.ordinal()]) {
/*     */           case 1: 
/* 184 */             return new java.util.Date(0L);
/*     */           }
/*     */           
/*     */           
/*     */ 
/* 189 */           return null;
/*     */         }
/* 191 */         synchronized (this._customFormat) {
/*     */           try {
/* 193 */             return this._customFormat.parse(str);
/*     */           } catch (ParseException e) {
/* 195 */             return (java.util.Date)ctxt.handleWeirdStringValue(handledType(), str, "expected format \"%s\"", new Object[] { this._formatString });
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 201 */       return super._parseDate(p, ctxt);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static class CalendarDeserializer
/*     */     extends DateDeserializers.DateBasedDeserializer<Calendar>
/*     */   {
/*     */     protected final Constructor<Calendar> _defaultCtor;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public CalendarDeserializer()
/*     */     {
/* 223 */       super();
/* 224 */       this._defaultCtor = null;
/*     */     }
/*     */     
/*     */     public CalendarDeserializer(Class<? extends Calendar> cc)
/*     */     {
/* 229 */       super();
/* 230 */       this._defaultCtor = com.fasterxml.jackson.databind.util.ClassUtil.findConstructor(cc, false);
/*     */     }
/*     */     
/*     */     public CalendarDeserializer(CalendarDeserializer src, DateFormat df, String formatString) {
/* 234 */       super(df, formatString);
/* 235 */       this._defaultCtor = src._defaultCtor;
/*     */     }
/*     */     
/*     */     protected CalendarDeserializer withDateFormat(DateFormat df, String formatString)
/*     */     {
/* 240 */       return new CalendarDeserializer(this, df, formatString);
/*     */     }
/*     */     
/*     */     public Object getEmptyValue(DeserializationContext ctxt)
/*     */     {
/* 245 */       GregorianCalendar cal = new GregorianCalendar();
/* 246 */       cal.setTimeInMillis(0L);
/* 247 */       return cal;
/*     */     }
/*     */     
/*     */     public Calendar deserialize(JsonParser p, DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/* 253 */       java.util.Date d = _parseDate(p, ctxt);
/* 254 */       if (d == null) {
/* 255 */         return null;
/*     */       }
/* 257 */       if (this._defaultCtor == null) {
/* 258 */         return ctxt.constructCalendar(d);
/*     */       }
/*     */       try {
/* 261 */         Calendar c = (Calendar)this._defaultCtor.newInstance(new Object[0]);
/* 262 */         c.setTimeInMillis(d.getTime());
/* 263 */         TimeZone tz = ctxt.getTimeZone();
/* 264 */         if (tz != null) {
/* 265 */           c.setTimeZone(tz);
/*     */         }
/* 267 */         return c;
/*     */       } catch (Exception e) {
/* 269 */         return (Calendar)ctxt.handleInstantiationProblem(handledType(), d, e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @JacksonStdImpl
/*     */   public static class DateDeserializer
/*     */     extends DateDeserializers.DateBasedDeserializer<java.util.Date>
/*     */   {
/* 284 */     public static final DateDeserializer instance = new DateDeserializer();
/*     */     
/* 286 */     public DateDeserializer() { super(); }
/*     */     
/* 288 */     public DateDeserializer(DateDeserializer base, DateFormat df, String formatString) { super(df, formatString); }
/*     */     
/*     */ 
/*     */     protected DateDeserializer withDateFormat(DateFormat df, String formatString)
/*     */     {
/* 293 */       return new DateDeserializer(this, df, formatString);
/*     */     }
/*     */     
/*     */     public Object getEmptyValue(DeserializationContext ctxt)
/*     */     {
/* 298 */       return new java.util.Date(0L);
/*     */     }
/*     */     
/*     */     public java.util.Date deserialize(JsonParser p, DeserializationContext ctxt) throws IOException
/*     */     {
/* 303 */       return _parseDate(p, ctxt);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SqlDateDeserializer
/*     */     extends DateDeserializers.DateBasedDeserializer<java.sql.Date>
/*     */   {
/* 314 */     public SqlDateDeserializer() { super(); }
/*     */     
/* 316 */     public SqlDateDeserializer(SqlDateDeserializer src, DateFormat df, String formatString) { super(df, formatString); }
/*     */     
/*     */ 
/*     */     protected SqlDateDeserializer withDateFormat(DateFormat df, String formatString)
/*     */     {
/* 321 */       return new SqlDateDeserializer(this, df, formatString);
/*     */     }
/*     */     
/*     */     public Object getEmptyValue(DeserializationContext ctxt)
/*     */     {
/* 326 */       return new java.sql.Date(0L);
/*     */     }
/*     */     
/*     */     public java.sql.Date deserialize(JsonParser p, DeserializationContext ctxt) throws IOException
/*     */     {
/* 331 */       java.util.Date d = _parseDate(p, ctxt);
/* 332 */       return d == null ? null : new java.sql.Date(d.getTime());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class TimestampDeserializer
/*     */     extends DateDeserializers.DateBasedDeserializer<Timestamp>
/*     */   {
/* 345 */     public TimestampDeserializer() { super(); }
/*     */     
/* 347 */     public TimestampDeserializer(TimestampDeserializer src, DateFormat df, String formatString) { super(df, formatString); }
/*     */     
/*     */ 
/*     */     protected TimestampDeserializer withDateFormat(DateFormat df, String formatString)
/*     */     {
/* 352 */       return new TimestampDeserializer(this, df, formatString);
/*     */     }
/*     */     
/*     */     public Object getEmptyValue(DeserializationContext ctxt)
/*     */     {
/* 357 */       return new Timestamp(0L);
/*     */     }
/*     */     
/*     */     public Timestamp deserialize(JsonParser p, DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/* 363 */       java.util.Date d = _parseDate(p, ctxt);
/* 364 */       return d == null ? null : new Timestamp(d.getTime());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\std\DateDeserializers.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */