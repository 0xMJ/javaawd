/*    */ package com.fasterxml.jackson.databind.ext;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.PropertyName;
/*    */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*    */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*    */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Java7Support
/*    */ {
/*    */   private static final Java7Support IMPL;
/*    */   
/*    */   static
/*    */   {
/* 20 */     Java7Support impl = null;
/*    */     try {
/* 22 */       Class<?> cls = Class.forName("com.fasterxml.jackson.databind.ext.Java7SupportImpl");
/* 23 */       impl = (Java7Support)ClassUtil.createInstance(cls, false);
/*    */     }
/*    */     catch (Throwable localThrowable) {}
/*    */     
/*    */ 
/*    */ 
/* 29 */     IMPL = impl; }
/*    */   public abstract PropertyName findConstructorName(AnnotatedParameter paramAnnotatedParameter);
/*    */   public abstract Boolean hasCreatorAnnotation(Annotated paramAnnotated);
/*    */   public abstract Boolean findTransient(Annotated paramAnnotated);
/* 33 */   public static Java7Support instance() { return IMPL; }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\ext\Java7Support.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */