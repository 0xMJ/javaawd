/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer.None;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.std.StdDelegatingDeserializer;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.type.ArrayType;
/*     */ import com.fasterxml.jackson.databind.type.CollectionLikeType;
/*     */ import com.fasterxml.jackson.databind.type.CollectionType;
/*     */ import com.fasterxml.jackson.databind.type.MapLikeType;
/*     */ import com.fasterxml.jackson.databind.type.MapType;
/*     */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import com.fasterxml.jackson.databind.util.LRUMap;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DeserializerCache
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final LRUMap<JavaType, JsonDeserializer<Object>> _cachedDeserializers;
/*  44 */   protected final HashMap<JavaType, JsonDeserializer<Object>> _incompleteDeserializers = new HashMap(8);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DeserializerCache()
/*     */   {
/*  54 */     this(2000);
/*     */   }
/*     */   
/*     */   public DeserializerCache(int maxSize) {
/*  58 */     int initial = Math.min(64, maxSize >> 2);
/*  59 */     this._cachedDeserializers = new LRUMap(initial, maxSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object writeReplace()
/*     */   {
/*  70 */     this._incompleteDeserializers.clear();
/*  71 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int cachedDeserializersCount()
/*     */   {
/*  93 */     return this._cachedDeserializers.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flushCachedDeserializers()
/*     */   {
/* 104 */     this._cachedDeserializers.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonDeserializer<Object> findValueDeserializer(DeserializationContext ctxt, DeserializerFactory factory, JavaType propertyType)
/*     */     throws JsonMappingException
/*     */   {
/* 139 */     JsonDeserializer<Object> deser = _findCachedDeserializer(propertyType);
/* 140 */     if (deser == null)
/*     */     {
/* 142 */       deser = _createAndCacheValueDeserializer(ctxt, factory, propertyType);
/* 143 */       if (deser == null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 148 */         deser = _handleUnknownValueDeserializer(ctxt, propertyType);
/*     */       }
/*     */     }
/* 151 */     return deser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyDeserializer findKeyDeserializer(DeserializationContext ctxt, DeserializerFactory factory, JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/* 166 */     KeyDeserializer kd = factory.createKeyDeserializer(ctxt, type);
/* 167 */     if (kd == null) {
/* 168 */       return _handleUnknownKeyDeserializer(ctxt, type);
/*     */     }
/*     */     
/* 171 */     if ((kd instanceof ResolvableDeserializer)) {
/* 172 */       ((ResolvableDeserializer)kd).resolve(ctxt);
/*     */     }
/* 174 */     return kd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasValueDeserializerFor(DeserializationContext ctxt, DeserializerFactory factory, JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/* 189 */     JsonDeserializer<Object> deser = _findCachedDeserializer(type);
/* 190 */     if (deser == null) {
/* 191 */       deser = _createAndCacheValueDeserializer(ctxt, factory, type);
/*     */     }
/* 193 */     return deser != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonDeserializer<Object> _findCachedDeserializer(JavaType type)
/*     */   {
/* 204 */     if (type == null) {
/* 205 */       throw new IllegalArgumentException("Null JavaType passed");
/*     */     }
/* 207 */     if (_hasCustomHandlers(type)) {
/* 208 */       return null;
/*     */     }
/* 210 */     return (JsonDeserializer)this._cachedDeserializers.get(type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonDeserializer<Object> _createAndCacheValueDeserializer(DeserializationContext ctxt, DeserializerFactory factory, JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/* 228 */     synchronized (this._incompleteDeserializers)
/*     */     {
/* 230 */       JsonDeserializer<Object> deser = _findCachedDeserializer(type);
/* 231 */       if (deser != null) {
/* 232 */         return deser;
/*     */       }
/* 234 */       int count = this._incompleteDeserializers.size();
/*     */       
/* 236 */       if (count > 0) {
/* 237 */         deser = (JsonDeserializer)this._incompleteDeserializers.get(type);
/* 238 */         if (deser != null) {
/* 239 */           return deser;
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 244 */         JsonDeserializer localJsonDeserializer = _createAndCache2(ctxt, factory, type);
/*     */         
/*     */ 
/* 247 */         if ((count == 0) && (this._incompleteDeserializers.size() > 0)) {
/* 248 */           this._incompleteDeserializers.clear();
/*     */         }
/* 244 */         return localJsonDeserializer;
/*     */       }
/*     */       finally {
/* 247 */         if ((count == 0) && (this._incompleteDeserializers.size() > 0)) {
/* 248 */           this._incompleteDeserializers.clear();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonDeserializer<Object> _createAndCache2(DeserializationContext ctxt, DeserializerFactory factory, JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/*     */     try
/*     */     {
/* 264 */       deser = _createDeserializer(ctxt, factory, type);
/*     */     }
/*     */     catch (IllegalArgumentException iae) {
/*     */       JsonDeserializer<Object> deser;
/* 268 */       throw JsonMappingException.from(ctxt, ClassUtil.exceptionMessage(iae), iae); }
/*     */     JsonDeserializer<Object> deser;
/* 270 */     if (deser == null) {
/* 271 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 277 */     boolean addToCache = (!_hasCustomHandlers(type)) && (deser.isCachable());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 291 */     if ((deser instanceof ResolvableDeserializer)) {
/* 292 */       this._incompleteDeserializers.put(type, deser);
/* 293 */       ((ResolvableDeserializer)deser).resolve(ctxt);
/* 294 */       this._incompleteDeserializers.remove(type);
/*     */     }
/* 296 */     if (addToCache) {
/* 297 */       this._cachedDeserializers.put(type, deser);
/*     */     }
/* 299 */     return deser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonDeserializer<Object> _createDeserializer(DeserializationContext ctxt, DeserializerFactory factory, JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/* 318 */     DeserializationConfig config = ctxt.getConfig();
/*     */     
/*     */ 
/* 321 */     if ((type.isAbstract()) || (type.isMapLikeType()) || (type.isCollectionLikeType())) {
/* 322 */       type = factory.mapAbstractType(config, type);
/*     */     }
/* 324 */     BeanDescription beanDesc = config.introspect(type);
/*     */     
/* 326 */     JsonDeserializer<Object> deser = findDeserializerFromAnnotation(ctxt, beanDesc
/* 327 */       .getClassInfo());
/* 328 */     if (deser != null) {
/* 329 */       return deser;
/*     */     }
/*     */     
/*     */ 
/* 333 */     JavaType newType = modifyTypeByAnnotation(ctxt, beanDesc.getClassInfo(), type);
/* 334 */     if (newType != type) {
/* 335 */       type = newType;
/* 336 */       beanDesc = config.introspect(newType);
/*     */     }
/*     */     
/*     */ 
/* 340 */     Class<?> builder = beanDesc.findPOJOBuilder();
/* 341 */     if (builder != null) {
/* 342 */       return factory.createBuilderBasedDeserializer(ctxt, type, beanDesc, builder);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 347 */     Converter<Object, Object> conv = beanDesc.findDeserializationConverter();
/* 348 */     if (conv == null) {
/* 349 */       return _createDeserializer2(ctxt, factory, type, beanDesc);
/*     */     }
/*     */     
/* 352 */     JavaType delegateType = conv.getInputType(ctxt.getTypeFactory());
/*     */     
/* 354 */     if (!delegateType.hasRawClass(type.getRawClass())) {
/* 355 */       beanDesc = config.introspect(delegateType);
/*     */     }
/* 357 */     return new StdDelegatingDeserializer(conv, delegateType, 
/* 358 */       _createDeserializer2(ctxt, factory, delegateType, beanDesc));
/*     */   }
/*     */   
/*     */ 
/*     */   protected JsonDeserializer<?> _createDeserializer2(DeserializationContext ctxt, DeserializerFactory factory, JavaType type, BeanDescription beanDesc)
/*     */     throws JsonMappingException
/*     */   {
/* 365 */     DeserializationConfig config = ctxt.getConfig();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 370 */     if (type.isEnumType()) {
/* 371 */       return factory.createEnumDeserializer(ctxt, type, beanDesc);
/*     */     }
/* 373 */     if (type.isContainerType()) {
/* 374 */       if (type.isArrayType()) {
/* 375 */         return factory.createArrayDeserializer(ctxt, (ArrayType)type, beanDesc);
/*     */       }
/* 377 */       if (type.isMapLikeType())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 383 */         JsonFormat.Value format = beanDesc.findExpectedFormat(null);
/* 384 */         if (format.getShape() != JsonFormat.Shape.OBJECT) {
/* 385 */           MapLikeType mlt = (MapLikeType)type;
/* 386 */           if ((mlt instanceof MapType)) {
/* 387 */             return factory.createMapDeserializer(ctxt, (MapType)mlt, beanDesc);
/*     */           }
/* 389 */           return factory.createMapLikeDeserializer(ctxt, mlt, beanDesc);
/*     */         }
/*     */       }
/* 392 */       if (type.isCollectionLikeType())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 398 */         JsonFormat.Value format = beanDesc.findExpectedFormat(null);
/* 399 */         if (format.getShape() != JsonFormat.Shape.OBJECT) {
/* 400 */           CollectionLikeType clt = (CollectionLikeType)type;
/* 401 */           if ((clt instanceof CollectionType)) {
/* 402 */             return factory.createCollectionDeserializer(ctxt, (CollectionType)clt, beanDesc);
/*     */           }
/* 404 */           return factory.createCollectionLikeDeserializer(ctxt, clt, beanDesc);
/*     */         }
/*     */       }
/*     */     }
/* 408 */     if (type.isReferenceType()) {
/* 409 */       return factory.createReferenceDeserializer(ctxt, (ReferenceType)type, beanDesc);
/*     */     }
/* 411 */     if (JsonNode.class.isAssignableFrom(type.getRawClass())) {
/* 412 */       return factory.createTreeDeserializer(config, type, beanDesc);
/*     */     }
/* 414 */     return factory.createBeanDeserializer(ctxt, type, beanDesc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonDeserializer<Object> findDeserializerFromAnnotation(DeserializationContext ctxt, Annotated ann)
/*     */     throws JsonMappingException
/*     */   {
/* 426 */     Object deserDef = ctxt.getAnnotationIntrospector().findDeserializer(ann);
/* 427 */     if (deserDef == null) {
/* 428 */       return null;
/*     */     }
/* 430 */     JsonDeserializer<Object> deser = ctxt.deserializerInstance(ann, deserDef);
/*     */     
/* 432 */     return findConvertingDeserializer(ctxt, ann, deser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonDeserializer<Object> findConvertingDeserializer(DeserializationContext ctxt, Annotated a, JsonDeserializer<Object> deser)
/*     */     throws JsonMappingException
/*     */   {
/* 445 */     Converter<Object, Object> conv = findConverter(ctxt, a);
/* 446 */     if (conv == null) {
/* 447 */       return deser;
/*     */     }
/* 449 */     JavaType delegateType = conv.getInputType(ctxt.getTypeFactory());
/* 450 */     return new StdDelegatingDeserializer(conv, delegateType, deser);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Converter<Object, Object> findConverter(DeserializationContext ctxt, Annotated a)
/*     */     throws JsonMappingException
/*     */   {
/* 457 */     Object convDef = ctxt.getAnnotationIntrospector().findDeserializationConverter(a);
/* 458 */     if (convDef == null) {
/* 459 */       return null;
/*     */     }
/* 461 */     return ctxt.converterInstance(a, convDef);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JavaType modifyTypeByAnnotation(DeserializationContext ctxt, Annotated a, JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/* 483 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 484 */     if (intr == null) {
/* 485 */       return type;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 491 */     if (type.isMapLikeType()) {
/* 492 */       JavaType keyType = type.getKeyType();
/*     */       
/*     */ 
/*     */ 
/* 496 */       if ((keyType != null) && (keyType.getValueHandler() == null)) {
/* 497 */         Object kdDef = intr.findKeyDeserializer(a);
/* 498 */         if (kdDef != null) {
/* 499 */           KeyDeserializer kd = ctxt.keyDeserializerInstance(a, kdDef);
/* 500 */           if (kd != null) {
/* 501 */             type = ((MapLikeType)type).withKeyValueHandler(kd);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 507 */     JavaType contentType = type.getContentType();
/* 508 */     if ((contentType != null) && 
/* 509 */       (contentType.getValueHandler() == null)) {
/* 510 */       Object cdDef = intr.findContentDeserializer(a);
/* 511 */       if (cdDef != null) {
/* 512 */         JsonDeserializer<?> cd = null;
/* 513 */         if ((cdDef instanceof JsonDeserializer)) {
/* 514 */           cd = (JsonDeserializer)cdDef;
/*     */         } else {
/* 516 */           Class<?> cdClass = _verifyAsClass(cdDef, "findContentDeserializer", JsonDeserializer.None.class);
/* 517 */           if (cdClass != null) {
/* 518 */             cd = ctxt.deserializerInstance(a, cdClass);
/*     */           }
/*     */         }
/* 521 */         if (cd != null) {
/* 522 */           type = type.withContentValueHandler(cd);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 530 */     type = intr.refineDeserializationType(ctxt.getConfig(), a, type);
/*     */     
/* 532 */     return type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean _hasCustomHandlers(JavaType t)
/*     */   {
/* 548 */     if (t.isContainerType())
/*     */     {
/* 550 */       JavaType ct = t.getContentType();
/* 551 */       if ((ct != null) && (
/* 552 */         (ct.getValueHandler() != null) || (ct.getTypeHandler() != null))) {
/* 553 */         return true;
/*     */       }
/*     */       
/*     */ 
/* 557 */       if (t.isMapLikeType()) {
/* 558 */         JavaType kt = t.getKeyType();
/* 559 */         if (kt.getValueHandler() != null) {
/* 560 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 564 */     return false;
/*     */   }
/*     */   
/*     */   private Class<?> _verifyAsClass(Object src, String methodName, Class<?> noneClass)
/*     */   {
/* 569 */     if (src == null) {
/* 570 */       return null;
/*     */     }
/* 572 */     if (!(src instanceof Class)) {
/* 573 */       throw new IllegalStateException("AnnotationIntrospector." + methodName + "() returned value of type " + src.getClass().getName() + ": expected type JsonSerializer or Class<JsonSerializer> instead");
/*     */     }
/* 575 */     Class<?> cls = (Class)src;
/* 576 */     if ((cls == noneClass) || (ClassUtil.isBogusClass(cls))) {
/* 577 */       return null;
/*     */     }
/* 579 */     return cls;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonDeserializer<Object> _handleUnknownValueDeserializer(DeserializationContext ctxt, JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/* 592 */     Class<?> rawClass = type.getRawClass();
/* 593 */     if (!ClassUtil.isConcrete(rawClass)) {
/* 594 */       return (JsonDeserializer)ctxt.reportBadDefinition(type, "Cannot find a Value deserializer for abstract type " + type);
/*     */     }
/* 596 */     return (JsonDeserializer)ctxt.reportBadDefinition(type, "Cannot find a Value deserializer for type " + type);
/*     */   }
/*     */   
/*     */   protected KeyDeserializer _handleUnknownKeyDeserializer(DeserializationContext ctxt, JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/* 602 */     return (KeyDeserializer)ctxt.reportBadDefinition(type, "Cannot find a (Map) Key deserializer for type " + type);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\DeserializerCache.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */