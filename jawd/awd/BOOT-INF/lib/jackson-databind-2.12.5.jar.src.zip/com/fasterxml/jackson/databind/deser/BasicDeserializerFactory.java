/*      */ package com.fasterxml.jackson.databind.deser;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JacksonInject.Value;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator.Mode;
/*      */ import com.fasterxml.jackson.annotation.JsonSetter.Value;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanDescription;
/*      */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.cfg.ConstructorDetector;
/*      */ import com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig;
/*      */ import com.fasterxml.jackson.databind.deser.impl.CreatorCandidate;
/*      */ import com.fasterxml.jackson.databind.deser.impl.CreatorCollector;
/*      */ import com.fasterxml.jackson.databind.deser.std.StdKeyDeserializers;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidDefinitionException;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedConstructor;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedWithParams;
/*      */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*      */ import com.fasterxml.jackson.databind.introspect.POJOPropertyBuilder;
/*      */ import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.type.ArrayType;
/*      */ import com.fasterxml.jackson.databind.type.CollectionLikeType;
/*      */ import com.fasterxml.jackson.databind.type.CollectionType;
/*      */ import com.fasterxml.jackson.databind.type.MapLikeType;
/*      */ import com.fasterxml.jackson.databind.type.MapType;
/*      */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ public abstract class BasicDeserializerFactory extends DeserializerFactory implements java.io.Serializable
/*      */ {
/*   49 */   private static final Class<?> CLASS_OBJECT = Object.class;
/*   50 */   private static final Class<?> CLASS_STRING = String.class;
/*   51 */   private static final Class<?> CLASS_CHAR_SEQUENCE = CharSequence.class;
/*   52 */   private static final Class<?> CLASS_ITERABLE = Iterable.class;
/*   53 */   private static final Class<?> CLASS_MAP_ENTRY = java.util.Map.Entry.class;
/*   54 */   private static final Class<?> CLASS_SERIALIZABLE = java.io.Serializable.class;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   60 */   protected static final PropertyName UNWRAPPED_CREATOR_PARAM_NAME = new PropertyName("@JsonUnwrapped");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final DeserializerFactoryConfig _factoryConfig;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BasicDeserializerFactory(DeserializerFactoryConfig config)
/*      */   {
/*   81 */     this._factoryConfig = config;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DeserializerFactoryConfig getFactoryConfig()
/*      */   {
/*   92 */     return this._factoryConfig;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected abstract DeserializerFactory withConfig(DeserializerFactoryConfig paramDeserializerFactoryConfig);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final DeserializerFactory withAdditionalDeserializers(Deserializers additional)
/*      */   {
/*  109 */     return withConfig(this._factoryConfig.withAdditionalDeserializers(additional));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final DeserializerFactory withAdditionalKeyDeserializers(KeyDeserializers additional)
/*      */   {
/*  118 */     return withConfig(this._factoryConfig.withAdditionalKeyDeserializers(additional));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final DeserializerFactory withDeserializerModifier(BeanDeserializerModifier modifier)
/*      */   {
/*  127 */     return withConfig(this._factoryConfig.withDeserializerModifier(modifier));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final DeserializerFactory withAbstractTypeResolver(com.fasterxml.jackson.databind.AbstractTypeResolver resolver)
/*      */   {
/*  136 */     return withConfig(this._factoryConfig.withAbstractTypeResolver(resolver));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final DeserializerFactory withValueInstantiators(ValueInstantiators instantiators)
/*      */   {
/*  145 */     return withConfig(this._factoryConfig.withValueInstantiators(instantiators));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JavaType mapAbstractType(DeserializationConfig config, JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/*      */     for (;;)
/*      */     {
/*  159 */       JavaType next = _mapAbstractType2(config, type);
/*  160 */       if (next == null) {
/*  161 */         return type;
/*      */       }
/*      */       
/*      */ 
/*  165 */       Class<?> prevCls = type.getRawClass();
/*  166 */       Class<?> nextCls = next.getRawClass();
/*  167 */       if ((prevCls == nextCls) || (!prevCls.isAssignableFrom(nextCls))) {
/*  168 */         throw new IllegalArgumentException("Invalid abstract type resolution from " + type + " to " + next + ": latter is not a subtype of former");
/*      */       }
/*  170 */       type = next;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private JavaType _mapAbstractType2(DeserializationConfig config, JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/*  181 */     Class<?> currClass = type.getRawClass();
/*  182 */     if (this._factoryConfig.hasAbstractTypeResolvers()) {
/*  183 */       for (com.fasterxml.jackson.databind.AbstractTypeResolver resolver : this._factoryConfig.abstractTypeResolvers()) {
/*  184 */         JavaType concrete = resolver.findTypeMapping(config, type);
/*  185 */         if ((concrete != null) && (!concrete.hasRawClass(currClass))) {
/*  186 */           return concrete;
/*      */         }
/*      */       }
/*      */     }
/*  190 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ValueInstantiator findValueInstantiator(DeserializationContext ctxt, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/*  209 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*  211 */     ValueInstantiator instantiator = null;
/*      */     
/*  213 */     com.fasterxml.jackson.databind.introspect.AnnotatedClass ac = beanDesc.getClassInfo();
/*  214 */     Object instDef = ctxt.getAnnotationIntrospector().findValueInstantiator(ac);
/*  215 */     if (instDef != null) {
/*  216 */       instantiator = _valueInstantiatorInstance(config, ac, instDef);
/*      */     }
/*  218 */     if (instantiator == null)
/*      */     {
/*      */ 
/*  221 */       instantiator = com.fasterxml.jackson.databind.deser.impl.JDKValueInstantiators.findStdValueInstantiator(config, beanDesc.getBeanClass());
/*  222 */       if (instantiator == null) {
/*  223 */         instantiator = _constructDefaultValueInstantiator(ctxt, beanDesc);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  228 */     if (this._factoryConfig.hasValueInstantiators()) {
/*  229 */       for (ValueInstantiators insts : this._factoryConfig.valueInstantiators()) {
/*  230 */         instantiator = insts.findValueInstantiator(config, beanDesc, instantiator);
/*      */         
/*  232 */         if (instantiator == null) {
/*  233 */           ctxt.reportBadTypeDefinition(beanDesc, "Broken registered ValueInstantiators (of type %s): returned null ValueInstantiator", new Object[] {insts
/*      */           
/*  235 */             .getClass().getName() });
/*      */         }
/*      */       }
/*      */     }
/*  239 */     if (instantiator != null) {
/*  240 */       instantiator = instantiator.createContextual(ctxt, beanDesc);
/*      */     }
/*      */     
/*  243 */     return instantiator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ValueInstantiator _constructDefaultValueInstantiator(DeserializationContext ctxt, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/*  258 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*  260 */     VisibilityChecker<?> vchecker = config.getDefaultVisibilityChecker(beanDesc.getBeanClass(), beanDesc
/*  261 */       .getClassInfo());
/*  262 */     ConstructorDetector ctorDetector = config.getConstructorDetector();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  271 */     CreatorCollector creators = new CreatorCollector(beanDesc, config);
/*  272 */     Map<AnnotatedWithParams, BeanPropertyDefinition[]> creatorDefs = _findCreatorsFromProperties(ctxt, beanDesc);
/*      */     
/*  274 */     CreatorCollectionState ccState = new CreatorCollectionState(ctxt, beanDesc, vchecker, creators, creatorDefs);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  279 */     _addExplicitFactoryCreators(ctxt, ccState, !ctorDetector.requireCtorAnnotation());
/*      */     
/*      */ 
/*  282 */     if (beanDesc.getType().isConcrete())
/*      */     {
/*  284 */       if (beanDesc.getType().isRecordType()) {
/*  285 */         List<String> names = new java.util.ArrayList();
/*      */         
/*  287 */         AnnotatedConstructor canonical = com.fasterxml.jackson.databind.jdk14.JDK14Util.findRecordConstructor(ctxt, beanDesc, names);
/*  288 */         if (canonical != null) {
/*  289 */           _addRecordConstructor(ctxt, ccState, canonical, names);
/*  290 */           return ccState.creators.constructValueInstantiator(ctxt);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  296 */       boolean isNonStaticInnerClass = beanDesc.isNonStaticInnerClass();
/*  297 */       if (!isNonStaticInnerClass)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  303 */         boolean findImplicit = ctorDetector.shouldIntrospectorImplicitConstructors(beanDesc.getBeanClass());
/*  304 */         _addExplicitConstructorCreators(ctxt, ccState, findImplicit);
/*  305 */         if (ccState.hasImplicitConstructorCandidates())
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  311 */           if (!ccState.hasExplicitConstructors()) {
/*  312 */             _addImplicitConstructorCreators(ctxt, ccState, ccState.implicitConstructorCandidates());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  317 */     if ((ccState.hasImplicitFactoryCandidates()) && 
/*  318 */       (!ccState.hasExplicitFactories()) && (!ccState.hasExplicitConstructors())) {
/*  319 */       _addImplicitFactoryCreators(ctxt, ccState, ccState.implicitFactoryCandidates());
/*      */     }
/*  321 */     return ccState.creators.constructValueInstantiator(ctxt);
/*      */   }
/*      */   
/*      */   protected Map<AnnotatedWithParams, BeanPropertyDefinition[]> _findCreatorsFromProperties(DeserializationContext ctxt, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/*  327 */     Map<AnnotatedWithParams, BeanPropertyDefinition[]> result = java.util.Collections.emptyMap();
/*  328 */     for (BeanPropertyDefinition propDef : beanDesc.findProperties()) {
/*  329 */       Iterator<AnnotatedParameter> it = propDef.getConstructorParameters();
/*  330 */       while (it.hasNext()) {
/*  331 */         AnnotatedParameter param = (AnnotatedParameter)it.next();
/*  332 */         AnnotatedWithParams owner = param.getOwner();
/*  333 */         BeanPropertyDefinition[] defs = (BeanPropertyDefinition[])result.get(owner);
/*  334 */         int index = param.getIndex();
/*      */         
/*  336 */         if (defs == null) {
/*  337 */           if (result.isEmpty()) {
/*  338 */             result = new java.util.LinkedHashMap();
/*      */           }
/*  340 */           defs = new BeanPropertyDefinition[owner.getParameterCount()];
/*  341 */           result.put(owner, defs);
/*      */         }
/*  343 */         else if (defs[index] != null) {
/*  344 */           ctxt.reportBadTypeDefinition(beanDesc, "Conflict: parameter #%d of %s bound to more than one property; %s vs %s", new Object[] {
/*      */           
/*  346 */             Integer.valueOf(index), owner, defs[index], propDef });
/*      */         }
/*      */         
/*  349 */         defs[index] = propDef;
/*      */       }
/*      */     }
/*  352 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   public ValueInstantiator _valueInstantiatorInstance(DeserializationConfig config, Annotated annotated, Object instDef)
/*      */     throws JsonMappingException
/*      */   {
/*  359 */     if (instDef == null) {
/*  360 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  365 */     if ((instDef instanceof ValueInstantiator)) {
/*  366 */       return (ValueInstantiator)instDef;
/*      */     }
/*  368 */     if (!(instDef instanceof Class))
/*      */     {
/*  370 */       throw new IllegalStateException("AnnotationIntrospector returned key deserializer definition of type " + instDef.getClass().getName() + "; expected type KeyDeserializer or Class<KeyDeserializer> instead");
/*      */     }
/*      */     
/*  373 */     Class<?> instClass = (Class)instDef;
/*  374 */     if (ClassUtil.isBogusClass(instClass)) {
/*  375 */       return null;
/*      */     }
/*  377 */     if (!ValueInstantiator.class.isAssignableFrom(instClass)) {
/*  378 */       throw new IllegalStateException("AnnotationIntrospector returned Class " + instClass.getName() + "; expected Class<ValueInstantiator>");
/*      */     }
/*      */     
/*  381 */     com.fasterxml.jackson.databind.cfg.HandlerInstantiator hi = config.getHandlerInstantiator();
/*  382 */     if (hi != null) {
/*  383 */       ValueInstantiator inst = hi.valueInstantiatorInstance(config, annotated, instClass);
/*  384 */       if (inst != null) {
/*  385 */         return inst;
/*      */       }
/*      */     }
/*  388 */     return (ValueInstantiator)ClassUtil.createInstance(instClass, config
/*  389 */       .canOverrideAccessModifiers());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _addRecordConstructor(DeserializationContext ctxt, CreatorCollectionState ccState, AnnotatedConstructor canonical, List<String> implicitNames)
/*      */     throws JsonMappingException
/*      */   {
/*  408 */     int argCount = canonical.getParameterCount();
/*  409 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/*  410 */     SettableBeanProperty[] properties = new SettableBeanProperty[argCount];
/*      */     
/*  412 */     for (int i = 0; i < argCount; i++) {
/*  413 */       AnnotatedParameter param = canonical.getParameter(i);
/*  414 */       JacksonInject.Value injectable = intr.findInjectableValue(param);
/*  415 */       PropertyName name = intr.findNameForDeserialization(param);
/*  416 */       if ((name == null) || (name.isEmpty())) {
/*  417 */         name = PropertyName.construct((String)implicitNames.get(i));
/*      */       }
/*  419 */       properties[i] = constructCreatorProperty(ctxt, ccState.beanDesc, name, i, param, injectable);
/*      */     }
/*  421 */     ccState.creators.addPropertyCreator(canonical, false, properties);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _addExplicitConstructorCreators(DeserializationContext ctxt, CreatorCollectionState ccState, boolean findImplicit)
/*      */     throws JsonMappingException
/*      */   {
/*  434 */     BeanDescription beanDesc = ccState.beanDesc;
/*  435 */     CreatorCollector creators = ccState.creators;
/*  436 */     AnnotationIntrospector intr = ccState.annotationIntrospector();
/*  437 */     VisibilityChecker<?> vchecker = ccState.vchecker;
/*  438 */     Map<AnnotatedWithParams, BeanPropertyDefinition[]> creatorParams = ccState.creatorParams;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  443 */     AnnotatedConstructor defaultCtor = beanDesc.findDefaultConstructor();
/*  444 */     if ((defaultCtor != null) && (
/*  445 */       (!creators.hasDefaultCreator()) || (_hasCreatorAnnotation(ctxt, defaultCtor)))) {
/*  446 */       creators.setDefaultCreator(defaultCtor);
/*      */     }
/*      */     
/*      */ 
/*  450 */     for (AnnotatedConstructor ctor : beanDesc.getConstructors()) {
/*  451 */       JsonCreator.Mode creatorMode = intr.findCreatorAnnotation(ctxt.getConfig(), ctor);
/*  452 */       if (JsonCreator.Mode.DISABLED != creatorMode)
/*      */       {
/*      */ 
/*  455 */         if (creatorMode == null)
/*      */         {
/*  457 */           if ((findImplicit) && (vchecker.isCreatorVisible(ctor))) {
/*  458 */             ccState.addImplicitConstructorCandidate(CreatorCandidate.construct(intr, ctor, 
/*  459 */               (BeanPropertyDefinition[])creatorParams.get(ctor)));
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  464 */           switch (creatorMode) {
/*      */           case DELEGATING: 
/*  466 */             _addExplicitDelegatingCreator(ctxt, beanDesc, creators, 
/*  467 */               CreatorCandidate.construct(intr, ctor, null));
/*  468 */             break;
/*      */           case PROPERTIES: 
/*  470 */             _addExplicitPropertyCreator(ctxt, beanDesc, creators, 
/*  471 */               CreatorCandidate.construct(intr, ctor, (BeanPropertyDefinition[])creatorParams.get(ctor)));
/*  472 */             break;
/*      */           default: 
/*  474 */             _addExplicitAnyCreator(ctxt, beanDesc, creators, 
/*  475 */               CreatorCandidate.construct(intr, ctor, (BeanPropertyDefinition[])creatorParams.get(ctor)), ctxt
/*  476 */               .getConfig().getConstructorDetector());
/*      */           }
/*      */           
/*  479 */           ccState.increaseExplicitConstructorCount();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void _addImplicitConstructorCreators(DeserializationContext ctxt, CreatorCollectionState ccState, List<CreatorCandidate> ctorCandidates) throws JsonMappingException
/*      */   {
/*  487 */     DeserializationConfig config = ctxt.getConfig();
/*  488 */     BeanDescription beanDesc = ccState.beanDesc;
/*  489 */     CreatorCollector creators = ccState.creators;
/*  490 */     AnnotationIntrospector intr = ccState.annotationIntrospector();
/*  491 */     VisibilityChecker<?> vchecker = ccState.vchecker;
/*  492 */     List<AnnotatedWithParams> implicitCtors = null;
/*  493 */     boolean preferPropsBased = config.getConstructorDetector().singleArgCreatorDefaultsToProperties();
/*      */     
/*  495 */     for (CreatorCandidate candidate : ctorCandidates) {
/*  496 */       int argCount = candidate.paramCount();
/*  497 */       AnnotatedWithParams ctor = candidate.creator();
/*      */       
/*  499 */       if (argCount == 1) {
/*  500 */         BeanPropertyDefinition propDef = candidate.propertyDef(0);
/*  501 */         boolean useProps = (preferPropsBased) || (_checkIfCreatorPropertyBased(intr, ctor, propDef));
/*      */         
/*  503 */         if (useProps) {
/*  504 */           SettableBeanProperty[] properties = new SettableBeanProperty[1];
/*  505 */           JacksonInject.Value injection = candidate.injection(0);
/*      */           
/*      */ 
/*      */ 
/*  509 */           PropertyName name = candidate.paramName(0);
/*  510 */           if (name == null) {
/*  511 */             name = candidate.findImplicitParamName(0);
/*  512 */             if ((name == null) && (injection == null)) {}
/*      */           }
/*      */           else
/*      */           {
/*  516 */             properties[0] = constructCreatorProperty(ctxt, beanDesc, name, 0, candidate
/*  517 */               .parameter(0), injection);
/*  518 */             creators.addPropertyCreator(ctor, false, properties);
/*      */           }
/*  520 */         } else { _handleSingleArgumentCreator(creators, ctor, false, vchecker
/*      */           
/*  522 */             .isCreatorVisible(ctor));
/*      */           
/*      */ 
/*  525 */           if (propDef != null) {
/*  526 */             ((POJOPropertyBuilder)propDef).removeConstructors();
/*      */ 
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  537 */         int nonAnnotatedParamIndex = -1;
/*  538 */         SettableBeanProperty[] properties = new SettableBeanProperty[argCount];
/*  539 */         int explicitNameCount = 0;
/*  540 */         int implicitWithCreatorCount = 0;
/*  541 */         int injectCount = 0;
/*      */         
/*  543 */         for (int i = 0; i < argCount; i++) {
/*  544 */           AnnotatedParameter param = ctor.getParameter(i);
/*  545 */           BeanPropertyDefinition propDef = candidate.propertyDef(i);
/*  546 */           JacksonInject.Value injectable = intr.findInjectableValue(param);
/*  547 */           PropertyName name = propDef == null ? null : propDef.getFullName();
/*      */           
/*  549 */           if ((propDef != null) && (propDef.isExplicitlyNamed())) {
/*  550 */             explicitNameCount++;
/*  551 */             properties[i] = constructCreatorProperty(ctxt, beanDesc, name, i, param, injectable);
/*      */ 
/*      */           }
/*  554 */           else if (injectable != null) {
/*  555 */             injectCount++;
/*  556 */             properties[i] = constructCreatorProperty(ctxt, beanDesc, name, i, param, injectable);
/*      */           }
/*      */           else {
/*  559 */             com.fasterxml.jackson.databind.util.NameTransformer unwrapper = intr.findUnwrappingNameTransformer(param);
/*  560 */             if (unwrapper != null) {
/*  561 */               _reportUnwrappedCreatorProperty(ctxt, beanDesc, param);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/*  576 */             else if (nonAnnotatedParamIndex < 0) {
/*  577 */               nonAnnotatedParamIndex = i;
/*      */             }
/*      */           }
/*      */         }
/*  581 */         int namedCount = explicitNameCount + implicitWithCreatorCount;
/*      */         
/*  583 */         if ((explicitNameCount > 0) || (injectCount > 0))
/*      */         {
/*  585 */           if (namedCount + injectCount == argCount) {
/*  586 */             creators.addPropertyCreator(ctor, false, properties);
/*  587 */             continue;
/*      */           }
/*  589 */           if ((explicitNameCount == 0) && (injectCount + 1 == argCount))
/*      */           {
/*  591 */             creators.addDelegatingCreator(ctor, false, properties, 0);
/*  592 */             continue;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  597 */           PropertyName impl = candidate.findImplicitParamName(nonAnnotatedParamIndex);
/*  598 */           if ((impl == null) || (impl.isEmpty()))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  607 */             ctxt.reportBadTypeDefinition(beanDesc, "Argument #%d of constructor %s has no property name annotation; must have name when multiple-parameter constructor annotated as Creator", new Object[] {
/*      */             
/*  609 */               Integer.valueOf(nonAnnotatedParamIndex), ctor });
/*      */           }
/*      */         }
/*      */         
/*  613 */         if (!creators.hasDefaultCreator()) {
/*  614 */           if (implicitCtors == null) {
/*  615 */             implicitCtors = new java.util.LinkedList();
/*      */           }
/*  617 */           implicitCtors.add(ctor);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  622 */     if ((implicitCtors != null) && (!creators.hasDelegatingCreator()) && 
/*  623 */       (!creators.hasPropertyBasedCreator())) {
/*  624 */       _checkImplicitlyNamedConstructors(ctxt, beanDesc, vchecker, intr, creators, implicitCtors);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _addExplicitFactoryCreators(DeserializationContext ctxt, CreatorCollectionState ccState, boolean findImplicit)
/*      */     throws JsonMappingException
/*      */   {
/*  639 */     BeanDescription beanDesc = ccState.beanDesc;
/*  640 */     CreatorCollector creators = ccState.creators;
/*  641 */     AnnotationIntrospector intr = ccState.annotationIntrospector();
/*  642 */     VisibilityChecker<?> vchecker = ccState.vchecker;
/*  643 */     Map<AnnotatedWithParams, BeanPropertyDefinition[]> creatorParams = ccState.creatorParams;
/*      */     
/*      */ 
/*  646 */     for (AnnotatedMethod factory : beanDesc.getFactoryMethods()) {
/*  647 */       JsonCreator.Mode creatorMode = intr.findCreatorAnnotation(ctxt.getConfig(), factory);
/*  648 */       int argCount = factory.getParameterCount();
/*  649 */       if (creatorMode == null)
/*      */       {
/*  651 */         if ((findImplicit) && (argCount == 1) && (vchecker.isCreatorVisible(factory))) {
/*  652 */           ccState.addImplicitFactoryCandidate(CreatorCandidate.construct(intr, factory, null));
/*      */         }
/*      */         
/*      */       }
/*  656 */       else if (creatorMode != JsonCreator.Mode.DISABLED)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  661 */         if (argCount == 0) {
/*  662 */           creators.setDefaultCreator(factory);
/*      */         }
/*      */         else
/*      */         {
/*  666 */           switch (creatorMode) {
/*      */           case DELEGATING: 
/*  668 */             _addExplicitDelegatingCreator(ctxt, beanDesc, creators, 
/*  669 */               CreatorCandidate.construct(intr, factory, null));
/*  670 */             break;
/*      */           case PROPERTIES: 
/*  672 */             _addExplicitPropertyCreator(ctxt, beanDesc, creators, 
/*  673 */               CreatorCandidate.construct(intr, factory, (BeanPropertyDefinition[])creatorParams.get(factory)));
/*  674 */             break;
/*      */           case DEFAULT: 
/*      */           default: 
/*  677 */             _addExplicitAnyCreator(ctxt, beanDesc, creators, 
/*  678 */               CreatorCandidate.construct(intr, factory, (BeanPropertyDefinition[])creatorParams.get(factory)), ConstructorDetector.DEFAULT);
/*      */           }
/*      */           
/*      */           
/*      */ 
/*      */ 
/*  684 */           ccState.increaseExplicitFactoryCount();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void _addImplicitFactoryCreators(DeserializationContext ctxt, CreatorCollectionState ccState, List<CreatorCandidate> factoryCandidates) throws JsonMappingException
/*      */   {
/*  692 */     BeanDescription beanDesc = ccState.beanDesc;
/*  693 */     CreatorCollector creators = ccState.creators;
/*  694 */     AnnotationIntrospector intr = ccState.annotationIntrospector();
/*  695 */     VisibilityChecker<?> vchecker = ccState.vchecker;
/*  696 */     Map<AnnotatedWithParams, BeanPropertyDefinition[]> creatorParams = ccState.creatorParams;
/*      */     
/*      */ 
/*  699 */     for (CreatorCandidate candidate : factoryCandidates) {
/*  700 */       int argCount = candidate.paramCount();
/*  701 */       AnnotatedWithParams factory = candidate.creator();
/*  702 */       BeanPropertyDefinition[] propDefs = (BeanPropertyDefinition[])creatorParams.get(factory);
/*      */       
/*  704 */       if (argCount == 1)
/*      */       {
/*      */ 
/*  707 */         BeanPropertyDefinition argDef = candidate.propertyDef(0);
/*  708 */         boolean useProps = _checkIfCreatorPropertyBased(intr, factory, argDef);
/*  709 */         if (!useProps) {
/*  710 */           _handleSingleArgumentCreator(creators, factory, false, vchecker
/*  711 */             .isCreatorVisible(factory));
/*      */           
/*      */ 
/*  714 */           if (argDef != null) {
/*  715 */             ((POJOPropertyBuilder)argDef).removeConstructors();
/*      */           }
/*      */         }
/*      */         else {
/*  719 */           AnnotatedParameter nonAnnotatedParam = null;
/*  720 */           SettableBeanProperty[] properties = new SettableBeanProperty[argCount];
/*  721 */           int implicitNameCount = 0;
/*  722 */           int explicitNameCount = 0;
/*  723 */           int injectCount = 0;
/*      */           
/*  725 */           for (int i = 0; i < argCount; i++) {
/*  726 */             AnnotatedParameter param = factory.getParameter(i);
/*  727 */             BeanPropertyDefinition propDef = propDefs == null ? null : propDefs[i];
/*  728 */             JacksonInject.Value injectable = intr.findInjectableValue(param);
/*  729 */             PropertyName name = propDef == null ? null : propDef.getFullName();
/*      */             
/*  731 */             if ((propDef != null) && (propDef.isExplicitlyNamed())) {
/*  732 */               explicitNameCount++;
/*  733 */               properties[i] = constructCreatorProperty(ctxt, beanDesc, name, i, param, injectable);
/*      */ 
/*      */             }
/*  736 */             else if (injectable != null) {
/*  737 */               injectCount++;
/*  738 */               properties[i] = constructCreatorProperty(ctxt, beanDesc, name, i, param, injectable);
/*      */             }
/*      */             else {
/*  741 */               com.fasterxml.jackson.databind.util.NameTransformer unwrapper = intr.findUnwrappingNameTransformer(param);
/*  742 */               if (unwrapper != null) {
/*  743 */                 _reportUnwrappedCreatorProperty(ctxt, beanDesc, param);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               }
/*  772 */               else if (nonAnnotatedParam == null)
/*  773 */                 nonAnnotatedParam = param;
/*      */             }
/*      */           }
/*  776 */           int namedCount = explicitNameCount + implicitNameCount;
/*      */           
/*      */ 
/*  779 */           if ((explicitNameCount > 0) || (injectCount > 0))
/*      */           {
/*  781 */             if (namedCount + injectCount == argCount) {
/*  782 */               creators.addPropertyCreator(factory, false, properties);
/*  783 */             } else if ((explicitNameCount == 0) && (injectCount + 1 == argCount))
/*      */             {
/*  785 */               creators.addDelegatingCreator(factory, false, properties, 0);
/*      */             } else {
/*  787 */               ctxt.reportBadTypeDefinition(beanDesc, "Argument #%d of factory method %s has no property name annotation; must have name when multiple-parameter constructor annotated as Creator", new Object[] {
/*      */               
/*  789 */                 Integer.valueOf(nonAnnotatedParam.getIndex()), factory });
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _addExplicitDelegatingCreator(DeserializationContext ctxt, BeanDescription beanDesc, CreatorCollector creators, CreatorCandidate candidate)
/*      */     throws JsonMappingException
/*      */   {
/*  814 */     int ix = -1;
/*  815 */     int argCount = candidate.paramCount();
/*  816 */     SettableBeanProperty[] properties = new SettableBeanProperty[argCount];
/*  817 */     for (int i = 0; i < argCount; i++) {
/*  818 */       AnnotatedParameter param = candidate.parameter(i);
/*  819 */       JacksonInject.Value injectId = candidate.injection(i);
/*  820 */       if (injectId != null) {
/*  821 */         properties[i] = constructCreatorProperty(ctxt, beanDesc, null, i, param, injectId);
/*      */ 
/*      */       }
/*  824 */       else if (ix < 0) {
/*  825 */         ix = i;
/*      */       }
/*      */       else
/*      */       {
/*  829 */         ctxt.reportBadTypeDefinition(beanDesc, "More than one argument (#%d and #%d) left as delegating for Creator %s: only one allowed", new Object[] {
/*      */         
/*  831 */           Integer.valueOf(ix), Integer.valueOf(i), candidate });
/*      */       }
/*      */     }
/*  834 */     if (ix < 0) {
/*  835 */       ctxt.reportBadTypeDefinition(beanDesc, "No argument left as delegating for Creator %s: exactly one required", new Object[] { candidate });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  840 */     if (argCount == 1) {
/*  841 */       _handleSingleArgumentCreator(creators, candidate.creator(), true, true);
/*      */       
/*      */ 
/*  844 */       BeanPropertyDefinition paramDef = candidate.propertyDef(0);
/*  845 */       if (paramDef != null) {
/*  846 */         ((POJOPropertyBuilder)paramDef).removeConstructors();
/*      */       }
/*  848 */       return;
/*      */     }
/*  850 */     creators.addDelegatingCreator(candidate.creator(), true, properties, ix);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _addExplicitPropertyCreator(DeserializationContext ctxt, BeanDescription beanDesc, CreatorCollector creators, CreatorCandidate candidate)
/*      */     throws JsonMappingException
/*      */   {
/*  864 */     int paramCount = candidate.paramCount();
/*  865 */     SettableBeanProperty[] properties = new SettableBeanProperty[paramCount];
/*      */     
/*  867 */     for (int i = 0; i < paramCount; i++) {
/*  868 */       JacksonInject.Value injectId = candidate.injection(i);
/*  869 */       AnnotatedParameter param = candidate.parameter(i);
/*  870 */       PropertyName name = candidate.paramName(i);
/*  871 */       if (name == null)
/*      */       {
/*      */ 
/*  874 */         com.fasterxml.jackson.databind.util.NameTransformer unwrapper = ctxt.getAnnotationIntrospector().findUnwrappingNameTransformer(param);
/*  875 */         if (unwrapper != null) {
/*  876 */           _reportUnwrappedCreatorProperty(ctxt, beanDesc, param);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  882 */         name = candidate.findImplicitParamName(i);
/*  883 */         _validateNamedPropertyParameter(ctxt, beanDesc, candidate, i, name, injectId);
/*      */       }
/*      */       
/*  886 */       properties[i] = constructCreatorProperty(ctxt, beanDesc, name, i, param, injectId);
/*      */     }
/*  888 */     creators.addPropertyCreator(candidate.creator(), true, properties);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected void _addExplicitAnyCreator(DeserializationContext ctxt, BeanDescription beanDesc, CreatorCollector creators, CreatorCandidate candidate)
/*      */     throws JsonMappingException
/*      */   {
/*  897 */     _addExplicitAnyCreator(ctxt, beanDesc, creators, candidate, ctxt
/*  898 */       .getConfig().getConstructorDetector());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _addExplicitAnyCreator(DeserializationContext ctxt, BeanDescription beanDesc, CreatorCollector creators, CreatorCandidate candidate, ConstructorDetector ctorDetector)
/*      */     throws JsonMappingException
/*      */   {
/*  913 */     if (1 != candidate.paramCount())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  918 */       if (!ctorDetector.singleArgCreatorDefaultsToProperties()) {
/*  919 */         int oneNotInjected = candidate.findOnlyParamWithoutInjection();
/*  920 */         if (oneNotInjected >= 0)
/*      */         {
/*      */ 
/*  923 */           if ((ctorDetector.singleArgCreatorDefaultsToDelegating()) || 
/*  924 */             (candidate.paramName(oneNotInjected) == null)) {
/*  925 */             _addExplicitDelegatingCreator(ctxt, beanDesc, creators, candidate);
/*  926 */             return;
/*      */           }
/*      */         }
/*      */       }
/*  930 */       _addExplicitPropertyCreator(ctxt, beanDesc, creators, candidate);
/*  931 */       return;
/*      */     }
/*      */     
/*      */ 
/*  935 */     AnnotatedParameter param = candidate.parameter(0);
/*  936 */     JacksonInject.Value injectId = candidate.injection(0);
/*  937 */     PropertyName paramName = null;
/*      */     boolean useProps;
/*      */     boolean useProps;
/*  940 */     switch (ctorDetector.singleArgMode()) {
/*      */     case DELEGATING: 
/*  942 */       useProps = false;
/*  943 */       break;
/*      */     case PROPERTIES: 
/*  945 */       boolean useProps = true;
/*      */       
/*      */ 
/*  948 */       paramName = candidate.paramName(0);
/*      */       
/*  950 */       if (paramName == null) {
/*  951 */         _validateNamedPropertyParameter(ctxt, beanDesc, candidate, 0, paramName, injectId);
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case REQUIRE_MODE: 
/*  957 */       ctxt.reportBadTypeDefinition(beanDesc, "Single-argument constructor (%s) is annotated but no 'mode' defined; `CreatorDetector`configured with `SingleArgConstructor.REQUIRE_MODE`", new Object[] {candidate
/*      */       
/*      */ 
/*  960 */         .creator() });
/*  961 */       return;
/*      */     
/*      */     case HEURISTIC: 
/*      */     default: 
/*  965 */       BeanPropertyDefinition paramDef = candidate.propertyDef(0);
/*      */       
/*  967 */       paramName = candidate.explicitParamName(0);
/*      */       
/*      */ 
/*  970 */       useProps = (paramName != null) || (injectId != null);
/*  971 */       if ((!useProps) && (paramDef != null))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  978 */         paramName = candidate.paramName(0);
/*  979 */         useProps = (paramName != null) && (paramDef.couldSerialize());
/*      */       }
/*      */       break;
/*      */     }
/*      */     
/*  984 */     if (useProps)
/*      */     {
/*  986 */       SettableBeanProperty[] properties = { constructCreatorProperty(ctxt, beanDesc, paramName, 0, param, injectId) };
/*      */       
/*  988 */       creators.addPropertyCreator(candidate.creator(), true, properties);
/*  989 */       return;
/*      */     }
/*      */     
/*  992 */     _handleSingleArgumentCreator(creators, candidate.creator(), true, true);
/*      */     
/*      */ 
/*      */ 
/*  996 */     BeanPropertyDefinition paramDef = candidate.propertyDef(0);
/*  997 */     if (paramDef != null) {
/*  998 */       ((POJOPropertyBuilder)paramDef).removeConstructors();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean _checkIfCreatorPropertyBased(AnnotationIntrospector intr, AnnotatedWithParams creator, BeanPropertyDefinition propDef)
/*      */   {
/* 1006 */     if (((propDef != null) && (propDef.isExplicitlyNamed())) || 
/* 1007 */       (intr.findInjectableValue(creator.getParameter(0)) != null)) {
/* 1008 */       return true;
/*      */     }
/* 1010 */     if (propDef != null)
/*      */     {
/*      */ 
/* 1013 */       String implName = propDef.getName();
/* 1014 */       if ((implName != null) && (!implName.isEmpty()) && 
/* 1015 */         (propDef.couldSerialize())) {
/* 1016 */         return true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1021 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void _checkImplicitlyNamedConstructors(DeserializationContext ctxt, BeanDescription beanDesc, VisibilityChecker<?> vchecker, AnnotationIntrospector intr, CreatorCollector creators, List<AnnotatedWithParams> implicitCtors)
/*      */     throws JsonMappingException
/*      */   {
/* 1029 */     AnnotatedWithParams found = null;
/* 1030 */     SettableBeanProperty[] foundProps = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1037 */     for (Iterator localIterator = implicitCtors.iterator(); localIterator.hasNext();) { ctor = (AnnotatedWithParams)localIterator.next();
/* 1038 */       if (vchecker.isCreatorVisible(ctor))
/*      */       {
/*      */ 
/*      */ 
/* 1042 */         argCount = ctor.getParameterCount();
/* 1043 */         properties = new SettableBeanProperty[argCount];
/* 1044 */         for (int i = 0;; i++) { if (i >= argCount) break label137;
/* 1045 */           AnnotatedParameter param = ctor.getParameter(i);
/* 1046 */           PropertyName name = _findParamName(param, intr);
/*      */           
/*      */ 
/* 1049 */           if ((name == null) || (name.isEmpty())) {
/*      */             break;
/*      */           }
/* 1052 */           properties[i] = constructCreatorProperty(ctxt, beanDesc, name, param.getIndex(), param, null);
/*      */         }
/*      */         
/* 1055 */         if (found != null) {
/* 1056 */           found = null;
/* 1057 */           break;
/*      */         }
/* 1059 */         found = ctor;
/* 1060 */         foundProps = properties; } }
/*      */     AnnotatedWithParams ctor;
/*      */     int argCount;
/* 1063 */     SettableBeanProperty[] properties; label137: if (found != null) {
/* 1064 */       creators.addPropertyCreator(found, false, foundProps);
/* 1065 */       com.fasterxml.jackson.databind.introspect.BasicBeanDescription bbd = (com.fasterxml.jackson.databind.introspect.BasicBeanDescription)beanDesc;
/*      */       
/* 1067 */       ctor = foundProps;argCount = ctor.length; for (properties = 0; properties < argCount; properties++) { SettableBeanProperty prop = ctor[properties];
/* 1068 */         PropertyName pn = prop.getFullName();
/* 1069 */         if (!bbd.hasProperty(pn)) {
/* 1070 */           BeanPropertyDefinition newDef = com.fasterxml.jackson.databind.util.SimpleBeanPropertyDefinition.construct(ctxt
/* 1071 */             .getConfig(), prop.getMember(), pn);
/* 1072 */           bbd.addProperty(newDef);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected boolean _handleSingleArgumentCreator(CreatorCollector creators, AnnotatedWithParams ctor, boolean isCreator, boolean isVisible)
/*      */   {
/* 1082 */     Class<?> type = ctor.getRawParameterType(0);
/* 1083 */     if ((type == String.class) || (type == CLASS_CHAR_SEQUENCE)) {
/* 1084 */       if ((isCreator) || (isVisible)) {
/* 1085 */         creators.addStringCreator(ctor, isCreator);
/*      */       }
/* 1087 */       return true;
/*      */     }
/* 1089 */     if ((type == Integer.TYPE) || (type == Integer.class)) {
/* 1090 */       if ((isCreator) || (isVisible)) {
/* 1091 */         creators.addIntCreator(ctor, isCreator);
/*      */       }
/* 1093 */       return true;
/*      */     }
/* 1095 */     if ((type == Long.TYPE) || (type == Long.class)) {
/* 1096 */       if ((isCreator) || (isVisible)) {
/* 1097 */         creators.addLongCreator(ctor, isCreator);
/*      */       }
/* 1099 */       return true;
/*      */     }
/* 1101 */     if ((type == Double.TYPE) || (type == Double.class)) {
/* 1102 */       if ((isCreator) || (isVisible)) {
/* 1103 */         creators.addDoubleCreator(ctor, isCreator);
/*      */       }
/* 1105 */       return true;
/*      */     }
/* 1107 */     if ((type == Boolean.TYPE) || (type == Boolean.class)) {
/* 1108 */       if ((isCreator) || (isVisible)) {
/* 1109 */         creators.addBooleanCreator(ctor, isCreator);
/*      */       }
/* 1111 */       return true;
/*      */     }
/* 1113 */     if ((type == java.math.BigInteger.class) && (
/* 1114 */       (isCreator) || (isVisible))) {
/* 1115 */       creators.addBigIntegerCreator(ctor, isCreator);
/*      */     }
/*      */     
/* 1118 */     if ((type == java.math.BigDecimal.class) && (
/* 1119 */       (isCreator) || (isVisible))) {
/* 1120 */       creators.addBigDecimalCreator(ctor, isCreator);
/*      */     }
/*      */     
/*      */ 
/* 1124 */     if (isCreator) {
/* 1125 */       creators.addDelegatingCreator(ctor, isCreator, null, 0);
/* 1126 */       return true;
/*      */     }
/* 1128 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _validateNamedPropertyParameter(DeserializationContext ctxt, BeanDescription beanDesc, CreatorCandidate candidate, int paramIndex, PropertyName name, JacksonInject.Value injectId)
/*      */     throws JsonMappingException
/*      */   {
/* 1142 */     if ((name == null) && (injectId == null)) {
/* 1143 */       ctxt.reportBadTypeDefinition(beanDesc, "Argument #%d of constructor %s has no property name (and is not Injectable): can not use as property-based Creator", new Object[] {
/*      */       
/* 1145 */         Integer.valueOf(paramIndex), candidate });
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _reportUnwrappedCreatorProperty(DeserializationContext ctxt, BeanDescription beanDesc, AnnotatedParameter param)
/*      */     throws JsonMappingException
/*      */   {
/* 1155 */     ctxt.reportBadTypeDefinition(beanDesc, "Cannot define Creator parameter %d as `@JsonUnwrapped`: combination not yet supported", new Object[] {
/*      */     
/* 1157 */       Integer.valueOf(param.getIndex()) });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected SettableBeanProperty constructCreatorProperty(DeserializationContext ctxt, BeanDescription beanDesc, PropertyName name, int index, AnnotatedParameter param, JacksonInject.Value injectable)
/*      */     throws JsonMappingException
/*      */   {
/* 1171 */     DeserializationConfig config = ctxt.getConfig();
/* 1172 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/*      */     
/*      */     PropertyMetadata metadata;
/* 1175 */     if (intr == null) {
/* 1176 */       metadata = PropertyMetadata.STD_REQUIRED_OR_OPTIONAL;
/*      */     } else {
/* 1178 */       Boolean b = intr.hasRequiredMarker(param);
/* 1179 */       String desc = intr.findPropertyDescription(param);
/* 1180 */       Integer idx = intr.findPropertyIndex(param);
/* 1181 */       String def = intr.findPropertyDefaultValue(param);
/* 1182 */       metadata = PropertyMetadata.construct(b, desc, idx, def);
/*      */     }
/*      */     
/* 1185 */     JavaType type = resolveMemberAndTypeAnnotations(ctxt, param, param.getType());
/*      */     
/* 1187 */     com.fasterxml.jackson.databind.BeanProperty.Std property = new com.fasterxml.jackson.databind.BeanProperty.Std(name, type, intr.findWrapperName(param), param, metadata);
/*      */     
/* 1189 */     TypeDeserializer typeDeser = (TypeDeserializer)type.getTypeHandler();
/*      */     
/* 1191 */     if (typeDeser == null) {
/* 1192 */       typeDeser = findTypeDeserializer(config, type);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1197 */     PropertyMetadata metadata = _getSetterInfo(ctxt, property, metadata);
/*      */     
/*      */ 
/*      */ 
/* 1201 */     SettableBeanProperty prop = CreatorProperty.construct(name, type, property.getWrapperName(), typeDeser, beanDesc
/* 1202 */       .getClassAnnotations(), param, index, injectable, metadata);
/*      */     
/* 1204 */     JsonDeserializer<?> deser = findDeserializerFromAnnotation(ctxt, param);
/* 1205 */     if (deser == null) {
/* 1206 */       deser = (JsonDeserializer)type.getValueHandler();
/*      */     }
/* 1208 */     if (deser != null)
/*      */     {
/* 1210 */       deser = ctxt.handlePrimaryContextualization(deser, prop, type);
/* 1211 */       prop = prop.withValueDeserializer(deser);
/*      */     }
/* 1213 */     return prop;
/*      */   }
/*      */   
/*      */   private PropertyName _findParamName(AnnotatedParameter param, AnnotationIntrospector intr)
/*      */   {
/* 1218 */     if (intr != null) {
/* 1219 */       PropertyName name = intr.findNameForDeserialization(param);
/* 1220 */       if (name != null)
/*      */       {
/*      */ 
/* 1223 */         if (!name.isEmpty()) {
/* 1224 */           return name;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1230 */       String str = intr.findImplicitPropertyName(param);
/* 1231 */       if ((str != null) && (!str.isEmpty())) {
/* 1232 */         return PropertyName.construct(str);
/*      */       }
/*      */     }
/* 1235 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PropertyMetadata _getSetterInfo(DeserializationContext ctxt, com.fasterxml.jackson.databind.BeanProperty prop, PropertyMetadata metadata)
/*      */   {
/* 1247 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 1248 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/* 1250 */     boolean needMerge = true;
/* 1251 */     com.fasterxml.jackson.annotation.Nulls valueNulls = null;
/* 1252 */     com.fasterxml.jackson.annotation.Nulls contentNulls = null;
/*      */     
/*      */ 
/*      */ 
/* 1256 */     AnnotatedMember prim = prop.getMember();
/*      */     
/* 1258 */     if (prim != null)
/*      */     {
/* 1260 */       if (intr != null) {
/* 1261 */         JsonSetter.Value setterInfo = intr.findSetterInfo(prim);
/* 1262 */         if (setterInfo != null) {
/* 1263 */           valueNulls = setterInfo.nonDefaultValueNulls();
/* 1264 */           contentNulls = setterInfo.nonDefaultContentNulls();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1269 */       if ((needMerge) || (valueNulls == null) || (contentNulls == null)) {
/* 1270 */         com.fasterxml.jackson.databind.cfg.ConfigOverride co = config.getConfigOverride(prop.getType().getRawClass());
/* 1271 */         JsonSetter.Value setterInfo = co.getSetterInfo();
/* 1272 */         if (setterInfo != null) {
/* 1273 */           if (valueNulls == null) {
/* 1274 */             valueNulls = setterInfo.nonDefaultValueNulls();
/*      */           }
/* 1276 */           if (contentNulls == null) {
/* 1277 */             contentNulls = setterInfo.nonDefaultContentNulls();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1282 */     if ((needMerge) || (valueNulls == null) || (contentNulls == null)) {
/* 1283 */       JsonSetter.Value setterInfo = config.getDefaultSetterInfo();
/* 1284 */       if (valueNulls == null) {
/* 1285 */         valueNulls = setterInfo.nonDefaultValueNulls();
/*      */       }
/* 1287 */       if (contentNulls == null) {
/* 1288 */         contentNulls = setterInfo.nonDefaultContentNulls();
/*      */       }
/*      */     }
/* 1291 */     if ((valueNulls != null) || (contentNulls != null)) {
/* 1292 */       metadata = metadata.withNulls(valueNulls, contentNulls);
/*      */     }
/* 1294 */     return metadata;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<?> createArrayDeserializer(DeserializationContext ctxt, ArrayType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 1308 */     DeserializationConfig config = ctxt.getConfig();
/* 1309 */     JavaType elemType = type.getContentType();
/*      */     
/*      */ 
/* 1312 */     JsonDeserializer<Object> contentDeser = (JsonDeserializer)elemType.getValueHandler();
/*      */     
/* 1314 */     TypeDeserializer elemTypeDeser = (TypeDeserializer)elemType.getTypeHandler();
/*      */     
/* 1316 */     if (elemTypeDeser == null) {
/* 1317 */       elemTypeDeser = findTypeDeserializer(config, elemType);
/*      */     }
/*      */     
/* 1320 */     JsonDeserializer<?> deser = _findCustomArrayDeserializer(type, config, beanDesc, elemTypeDeser, contentDeser);
/*      */     Class<?> raw;
/* 1322 */     if (deser == null) {
/* 1323 */       if (contentDeser == null) {
/* 1324 */         raw = elemType.getRawClass();
/* 1325 */         if (elemType.isPrimitive()) {
/* 1326 */           return com.fasterxml.jackson.databind.deser.std.PrimitiveArrayDeserializers.forType(raw);
/*      */         }
/* 1328 */         if (raw == String.class) {
/* 1329 */           return com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer.instance;
/*      */         }
/*      */       }
/* 1332 */       deser = new com.fasterxml.jackson.databind.deser.std.ObjectArrayDeserializer(type, contentDeser, elemTypeDeser);
/*      */     }
/*      */     
/* 1335 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/* 1336 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/* 1337 */         deser = mod.modifyArrayDeserializer(config, type, beanDesc, deser);
/*      */       }
/*      */     }
/* 1340 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<?> createCollectionDeserializer(DeserializationContext ctxt, CollectionType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 1354 */     JavaType contentType = type.getContentType();
/*      */     
/* 1356 */     JsonDeserializer<Object> contentDeser = (JsonDeserializer)contentType.getValueHandler();
/* 1357 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*      */ 
/* 1360 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/*      */     
/* 1362 */     if (contentTypeDeser == null) {
/* 1363 */       contentTypeDeser = findTypeDeserializer(config, contentType);
/*      */     }
/*      */     
/* 1366 */     JsonDeserializer<?> deser = _findCustomCollectionDeserializer(type, config, beanDesc, contentTypeDeser, contentDeser);
/*      */     
/* 1368 */     if (deser == null) {
/* 1369 */       Class<?> collectionClass = type.getRawClass();
/* 1370 */       if (contentDeser == null)
/*      */       {
/* 1372 */         if (java.util.EnumSet.class.isAssignableFrom(collectionClass)) {
/* 1373 */           deser = new com.fasterxml.jackson.databind.deser.std.EnumSetDeserializer(contentType, null);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     ValueInstantiator inst;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1387 */     if (deser == null) {
/* 1388 */       if ((type.isInterface()) || (type.isAbstract())) {
/* 1389 */         CollectionType implType = _mapAbstractCollectionType(type, config);
/* 1390 */         if (implType == null)
/*      */         {
/* 1392 */           if (type.getTypeHandler() == null) {
/* 1393 */             throw new IllegalArgumentException("Cannot find a deserializer for non-concrete Collection type " + type);
/*      */           }
/* 1395 */           deser = AbstractDeserializer.constructForNonPOJO(beanDesc);
/*      */         } else {
/* 1397 */           type = implType;
/*      */           
/* 1399 */           beanDesc = config.introspectForCreation(type);
/*      */         }
/*      */       }
/* 1402 */       if (deser == null) {
/* 1403 */         inst = findValueInstantiator(ctxt, beanDesc);
/* 1404 */         if (!inst.canCreateUsingDefault())
/*      */         {
/* 1406 */           if (type.hasRawClass(java.util.concurrent.ArrayBlockingQueue.class)) {
/* 1407 */             return new com.fasterxml.jackson.databind.deser.std.ArrayBlockingQueueDeserializer(type, contentDeser, contentTypeDeser, inst);
/*      */           }
/*      */           
/* 1410 */           deser = com.fasterxml.jackson.databind.deser.impl.JavaUtilCollectionsDeserializers.findForCollection(ctxt, type);
/* 1411 */           if (deser != null) {
/* 1412 */             return deser;
/*      */           }
/*      */         }
/*      */         
/* 1416 */         if (contentType.hasRawClass(String.class))
/*      */         {
/* 1418 */           deser = new com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer(type, contentDeser, inst);
/*      */         } else {
/* 1420 */           deser = new com.fasterxml.jackson.databind.deser.std.CollectionDeserializer(type, contentDeser, contentTypeDeser, inst);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1425 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/* 1426 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/* 1427 */         deser = mod.modifyCollectionDeserializer(config, type, beanDesc, deser);
/*      */       }
/*      */     }
/* 1430 */     return deser;
/*      */   }
/*      */   
/*      */   protected CollectionType _mapAbstractCollectionType(JavaType type, DeserializationConfig config)
/*      */   {
/* 1435 */     Class<?> collectionClass = ContainerDefaultMappings.findCollectionFallback(type);
/* 1436 */     if (collectionClass != null) {
/* 1437 */       return 
/* 1438 */         (CollectionType)config.getTypeFactory().constructSpecializedType(type, collectionClass, true);
/*      */     }
/* 1440 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<?> createCollectionLikeDeserializer(DeserializationContext ctxt, CollectionLikeType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 1449 */     JavaType contentType = type.getContentType();
/*      */     
/* 1451 */     JsonDeserializer<Object> contentDeser = (JsonDeserializer)contentType.getValueHandler();
/* 1452 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*      */ 
/* 1455 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/*      */     
/* 1457 */     if (contentTypeDeser == null) {
/* 1458 */       contentTypeDeser = findTypeDeserializer(config, contentType);
/*      */     }
/* 1460 */     JsonDeserializer<?> deser = _findCustomCollectionLikeDeserializer(type, config, beanDesc, contentTypeDeser, contentDeser);
/*      */     
/* 1462 */     if (deser != null)
/*      */     {
/* 1464 */       if (this._factoryConfig.hasDeserializerModifiers()) {
/* 1465 */         for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/* 1466 */           deser = mod.modifyCollectionLikeDeserializer(config, type, beanDesc, deser);
/*      */         }
/*      */       }
/*      */     }
/* 1470 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<?> createMapDeserializer(DeserializationContext ctxt, MapType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 1484 */     DeserializationConfig config = ctxt.getConfig();
/* 1485 */     JavaType keyType = type.getKeyType();
/* 1486 */     JavaType contentType = type.getContentType();
/*      */     
/*      */ 
/*      */ 
/* 1490 */     JsonDeserializer<Object> contentDeser = (JsonDeserializer)contentType.getValueHandler();
/*      */     
/*      */ 
/* 1493 */     KeyDeserializer keyDes = (KeyDeserializer)keyType.getValueHandler();
/*      */     
/* 1495 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/*      */     
/* 1497 */     if (contentTypeDeser == null) {
/* 1498 */       contentTypeDeser = findTypeDeserializer(config, contentType);
/*      */     }
/*      */     
/*      */ 
/* 1502 */     JsonDeserializer<?> deser = _findCustomMapDeserializer(type, config, beanDesc, keyDes, contentTypeDeser, contentDeser);
/*      */     
/*      */     Class<?> mapClass;
/* 1505 */     if (deser == null)
/*      */     {
/* 1507 */       mapClass = type.getRawClass();
/* 1508 */       if (java.util.EnumMap.class.isAssignableFrom(mapClass))
/*      */       {
/*      */         ValueInstantiator inst;
/*      */         
/*      */         ValueInstantiator inst;
/* 1513 */         if (mapClass == java.util.EnumMap.class) {
/* 1514 */           inst = null;
/*      */         } else {
/* 1516 */           inst = findValueInstantiator(ctxt, beanDesc);
/*      */         }
/* 1518 */         if (!keyType.isEnumImplType()) {
/* 1519 */           throw new IllegalArgumentException("Cannot construct EnumMap; generic (key) type not available");
/*      */         }
/* 1521 */         deser = new com.fasterxml.jackson.databind.deser.std.EnumMapDeserializer(type, inst, null, contentDeser, contentTypeDeser, null);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1536 */       if (deser == null) {
/* 1537 */         if ((type.isInterface()) || (type.isAbstract())) {
/* 1538 */           MapType fallback = _mapAbstractMapType(type, config);
/* 1539 */           if (fallback != null) {
/* 1540 */             type = fallback;
/* 1541 */             mapClass = type.getRawClass();
/*      */             
/* 1543 */             beanDesc = config.introspectForCreation(type);
/*      */           }
/*      */           else {
/* 1546 */             if (type.getTypeHandler() == null) {
/* 1547 */               throw new IllegalArgumentException("Cannot find a deserializer for non-concrete Map type " + type);
/*      */             }
/* 1549 */             deser = AbstractDeserializer.constructForNonPOJO(beanDesc);
/*      */           }
/*      */         }
/*      */         else {
/* 1553 */           deser = com.fasterxml.jackson.databind.deser.impl.JavaUtilCollectionsDeserializers.findForMap(ctxt, type);
/* 1554 */           if (deser != null) {
/* 1555 */             return deser;
/*      */           }
/*      */         }
/* 1558 */         if (deser == null) {
/* 1559 */           ValueInstantiator inst = findValueInstantiator(ctxt, beanDesc);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 1564 */           com.fasterxml.jackson.databind.deser.std.MapDeserializer md = new com.fasterxml.jackson.databind.deser.std.MapDeserializer(type, inst, keyDes, contentDeser, contentTypeDeser);
/* 1565 */           com.fasterxml.jackson.annotation.JsonIgnoreProperties.Value ignorals = config.getDefaultPropertyIgnorals(Map.class, beanDesc
/* 1566 */             .getClassInfo());
/*      */           
/* 1568 */           java.util.Set<String> ignored = ignorals == null ? null : ignorals.findIgnoredForDeserialization();
/* 1569 */           md.setIgnorableProperties(ignored);
/* 1570 */           com.fasterxml.jackson.annotation.JsonIncludeProperties.Value inclusions = config.getDefaultPropertyInclusions(Map.class, beanDesc
/* 1571 */             .getClassInfo());
/* 1572 */           java.util.Set<String> included = inclusions == null ? null : inclusions.getIncluded();
/* 1573 */           md.setIncludableProperties(included);
/* 1574 */           deser = md;
/*      */         }
/*      */       }
/*      */     }
/* 1578 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/* 1579 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/* 1580 */         deser = mod.modifyMapDeserializer(config, type, beanDesc, deser);
/*      */       }
/*      */     }
/* 1583 */     return deser;
/*      */   }
/*      */   
/*      */   protected MapType _mapAbstractMapType(JavaType type, DeserializationConfig config)
/*      */   {
/* 1588 */     Class<?> mapClass = ContainerDefaultMappings.findMapFallback(type);
/* 1589 */     if (mapClass != null) {
/* 1590 */       return 
/* 1591 */         (MapType)config.getTypeFactory().constructSpecializedType(type, mapClass, true);
/*      */     }
/* 1593 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<?> createMapLikeDeserializer(DeserializationContext ctxt, MapLikeType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 1602 */     JavaType keyType = type.getKeyType();
/* 1603 */     JavaType contentType = type.getContentType();
/* 1604 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*      */ 
/*      */ 
/* 1608 */     JsonDeserializer<Object> contentDeser = (JsonDeserializer)contentType.getValueHandler();
/*      */     
/*      */ 
/* 1611 */     KeyDeserializer keyDes = (KeyDeserializer)keyType.getValueHandler();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1618 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/*      */     
/* 1620 */     if (contentTypeDeser == null) {
/* 1621 */       contentTypeDeser = findTypeDeserializer(config, contentType);
/*      */     }
/* 1623 */     JsonDeserializer<?> deser = _findCustomMapLikeDeserializer(type, config, beanDesc, keyDes, contentTypeDeser, contentDeser);
/*      */     
/* 1625 */     if (deser != null)
/*      */     {
/* 1627 */       if (this._factoryConfig.hasDeserializerModifiers()) {
/* 1628 */         for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/* 1629 */           deser = mod.modifyMapLikeDeserializer(config, type, beanDesc, deser);
/*      */         }
/*      */       }
/*      */     }
/* 1633 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<?> createEnumDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 1650 */     DeserializationConfig config = ctxt.getConfig();
/* 1651 */     Class<?> enumClass = type.getRawClass();
/*      */     
/* 1653 */     JsonDeserializer<?> deser = _findCustomEnumDeserializer(enumClass, config, beanDesc);
/*      */     ValueInstantiator valueInstantiator;
/* 1655 */     if (deser == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1661 */       if (enumClass == Enum.class) {
/* 1662 */         return AbstractDeserializer.constructForNonPOJO(beanDesc);
/*      */       }
/*      */       
/* 1665 */       valueInstantiator = _constructDefaultValueInstantiator(ctxt, beanDesc);
/*      */       
/* 1667 */       SettableBeanProperty[] creatorProps = valueInstantiator == null ? null : valueInstantiator.getFromObjectArguments(ctxt.getConfig());
/*      */       
/* 1669 */       for (AnnotatedMethod factory : beanDesc.getFactoryMethods()) {
/* 1670 */         if (_hasCreatorAnnotation(ctxt, factory)) {
/* 1671 */           if (factory.getParameterCount() == 0) {
/* 1672 */             deser = com.fasterxml.jackson.databind.deser.std.EnumDeserializer.deserializerForNoArgsCreator(config, enumClass, factory);
/* 1673 */             break;
/*      */           }
/* 1675 */           Class<?> returnType = factory.getRawReturnType();
/*      */           
/* 1677 */           if (!returnType.isAssignableFrom(enumClass)) {
/* 1678 */             ctxt.reportBadDefinition(type, String.format("Invalid `@JsonCreator` annotated Enum factory method [%s]: needs to return compatible type", new Object[] {factory
/*      */             
/* 1680 */               .toString() }));
/*      */           }
/* 1682 */           deser = com.fasterxml.jackson.databind.deser.std.EnumDeserializer.deserializerForCreator(config, enumClass, factory, valueInstantiator, creatorProps);
/* 1683 */           break;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1688 */       if (deser == null)
/*      */       {
/*      */ 
/* 1691 */         deser = new com.fasterxml.jackson.databind.deser.std.EnumDeserializer(constructEnumResolver(enumClass, config, beanDesc.findJsonValueAccessor()), Boolean.valueOf(config.isEnabled(com.fasterxml.jackson.databind.MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS)));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1696 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/* 1697 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/* 1698 */         deser = mod.modifyEnumDeserializer(config, type, beanDesc, deser);
/*      */       }
/*      */     }
/* 1701 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<?> createTreeDeserializer(DeserializationConfig config, JavaType nodeType, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 1710 */     Class<? extends com.fasterxml.jackson.databind.JsonNode> nodeClass = nodeType.getRawClass();
/*      */     
/* 1712 */     JsonDeserializer<?> custom = _findCustomTreeNodeDeserializer(nodeClass, config, beanDesc);
/*      */     
/* 1714 */     if (custom != null) {
/* 1715 */       return custom;
/*      */     }
/* 1717 */     return com.fasterxml.jackson.databind.deser.std.JsonNodeDeserializer.getDeserializer(nodeClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<?> createReferenceDeserializer(DeserializationContext ctxt, ReferenceType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 1725 */     JavaType contentType = type.getContentType();
/*      */     
/* 1727 */     JsonDeserializer<Object> contentDeser = (JsonDeserializer)contentType.getValueHandler();
/* 1728 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/* 1730 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/* 1731 */     if (contentTypeDeser == null) {
/* 1732 */       contentTypeDeser = findTypeDeserializer(config, contentType);
/*      */     }
/* 1734 */     JsonDeserializer<?> deser = _findCustomReferenceDeserializer(type, config, beanDesc, contentTypeDeser, contentDeser);
/*      */     
/*      */     Class<?> rawType;
/* 1737 */     if (deser == null)
/*      */     {
/* 1739 */       if (type.isTypeOrSubTypeOf(java.util.concurrent.atomic.AtomicReference.class)) {
/* 1740 */         rawType = type.getRawClass();
/*      */         ValueInstantiator inst;
/* 1742 */         ValueInstantiator inst; if (rawType == java.util.concurrent.atomic.AtomicReference.class) {
/* 1743 */           inst = null;
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/* 1749 */           inst = findValueInstantiator(ctxt, beanDesc);
/*      */         }
/* 1751 */         return new com.fasterxml.jackson.databind.deser.std.AtomicReferenceDeserializer(type, inst, contentTypeDeser, contentDeser);
/*      */       }
/*      */     }
/* 1754 */     if (deser != null)
/*      */     {
/* 1756 */       if (this._factoryConfig.hasDeserializerModifiers()) {
/* 1757 */         for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/* 1758 */           deser = mod.modifyReferenceDeserializer(config, type, beanDesc, deser);
/*      */         }
/*      */       }
/*      */     }
/* 1762 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TypeDeserializer findTypeDeserializer(DeserializationConfig config, JavaType baseType)
/*      */     throws JsonMappingException
/*      */   {
/* 1776 */     BeanDescription bean = config.introspectClassAnnotations(baseType.getRawClass());
/* 1777 */     com.fasterxml.jackson.databind.introspect.AnnotatedClass ac = bean.getClassInfo();
/* 1778 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 1779 */     TypeResolverBuilder<?> b = ai.findTypeResolver(config, ac, baseType);
/*      */     
/*      */ 
/*      */ 
/* 1783 */     Collection<com.fasterxml.jackson.databind.jsontype.NamedType> subtypes = null;
/* 1784 */     if (b == null) {
/* 1785 */       b = config.getDefaultTyper(baseType);
/* 1786 */       if (b == null) {
/* 1787 */         return null;
/*      */       }
/*      */     } else {
/* 1790 */       subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByTypeId(config, ac);
/*      */     }
/*      */     
/*      */ 
/* 1794 */     if ((b.getDefaultImpl() == null) && (baseType.isAbstract())) {
/* 1795 */       JavaType defaultType = mapAbstractType(config, baseType);
/* 1796 */       if ((defaultType != null) && (!defaultType.hasRawClass(baseType.getRawClass()))) {
/* 1797 */         b = b.defaultImpl(defaultType.getRawClass());
/*      */       }
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1803 */       return b.buildTypeDeserializer(config, baseType, subtypes);
/*      */     } catch (IllegalArgumentException|IllegalStateException e0) {
/* 1805 */       InvalidDefinitionException e = InvalidDefinitionException.from((com.fasterxml.jackson.core.JsonParser)null, 
/* 1806 */         ClassUtil.exceptionMessage(e0), baseType);
/* 1807 */       e.initCause(e0);
/* 1808 */       throw e;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<?> findOptionalStdDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 1821 */     return com.fasterxml.jackson.databind.ext.OptionalHandlerFactory.instance.findDeserializer(type, ctxt.getConfig(), beanDesc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public KeyDeserializer createKeyDeserializer(DeserializationContext ctxt, JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/* 1835 */     DeserializationConfig config = ctxt.getConfig();
/* 1836 */     BeanDescription beanDesc = null;
/* 1837 */     KeyDeserializer deser = null;
/* 1838 */     if (this._factoryConfig.hasKeyDeserializers()) {
/* 1839 */       beanDesc = config.introspectClassAnnotations(type);
/* 1840 */       for (KeyDeserializers d : this._factoryConfig.keyDeserializers()) {
/* 1841 */         deser = d.findKeyDeserializer(type, config, beanDesc);
/* 1842 */         if (deser != null) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1849 */     if (deser == null)
/*      */     {
/* 1851 */       if (beanDesc == null) {
/* 1852 */         beanDesc = config.introspectClassAnnotations(type.getRawClass());
/*      */       }
/* 1854 */       deser = findKeyDeserializerFromAnnotation(ctxt, beanDesc.getClassInfo());
/* 1855 */       if (deser == null) {
/* 1856 */         if (type.isEnumType()) {
/* 1857 */           deser = _createEnumKeyDeserializer(ctxt, type);
/*      */         } else {
/* 1859 */           deser = StdKeyDeserializers.findStringBasedKeyDeserializer(config, type);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1864 */     if ((deser != null) && 
/* 1865 */       (this._factoryConfig.hasDeserializerModifiers())) {
/* 1866 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/* 1867 */         deser = mod.modifyKeyDeserializer(config, type, deser);
/*      */       }
/*      */     }
/*      */     
/* 1871 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */   private KeyDeserializer _createEnumKeyDeserializer(DeserializationContext ctxt, JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/* 1878 */     DeserializationConfig config = ctxt.getConfig();
/* 1879 */     Class<?> enumClass = type.getRawClass();
/*      */     
/* 1881 */     BeanDescription beanDesc = config.introspect(type);
/*      */     
/* 1883 */     KeyDeserializer des = findKeyDeserializerFromAnnotation(ctxt, beanDesc.getClassInfo());
/* 1884 */     if (des != null) {
/* 1885 */       return des;
/*      */     }
/*      */     
/* 1888 */     JsonDeserializer<?> custom = _findCustomEnumDeserializer(enumClass, config, beanDesc);
/* 1889 */     if (custom != null) {
/* 1890 */       return StdKeyDeserializers.constructDelegatingKeyDeserializer(config, type, custom);
/*      */     }
/* 1892 */     JsonDeserializer<?> valueDesForKey = findDeserializerFromAnnotation(ctxt, beanDesc.getClassInfo());
/* 1893 */     if (valueDesForKey != null) {
/* 1894 */       return StdKeyDeserializers.constructDelegatingKeyDeserializer(config, type, valueDesForKey);
/*      */     }
/*      */     
/* 1897 */     com.fasterxml.jackson.databind.util.EnumResolver enumRes = constructEnumResolver(enumClass, config, beanDesc.findJsonValueAccessor());
/*      */     
/*      */ 
/* 1900 */     for (AnnotatedMethod factory : beanDesc.getFactoryMethods()) {
/* 1901 */       if (_hasCreatorAnnotation(ctxt, factory)) {
/* 1902 */         int argCount = factory.getParameterCount();
/* 1903 */         if (argCount == 1) {
/* 1904 */           Class<?> returnType = factory.getRawReturnType();
/*      */           
/* 1906 */           if (returnType.isAssignableFrom(enumClass))
/*      */           {
/* 1908 */             if (factory.getRawParameterType(0) != String.class) {
/*      */               continue;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1915 */             if (config.canOverrideAccessModifiers()) {
/* 1916 */               ClassUtil.checkAndFixAccess(factory.getMember(), ctxt
/* 1917 */                 .isEnabled(com.fasterxml.jackson.databind.MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*      */             }
/* 1919 */             return StdKeyDeserializers.constructEnumKeyDeserializer(enumRes, factory);
/*      */           }
/*      */         }
/*      */         
/* 1923 */         throw new IllegalArgumentException("Unsuitable method (" + factory + ") decorated with @JsonCreator (for Enum type " + enumClass.getName() + ")");
/*      */       }
/*      */     }
/*      */     
/* 1927 */     return StdKeyDeserializers.constructEnumKeyDeserializer(enumRes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasExplicitDeserializerFor(DeserializationConfig config, Class<?> valueType)
/*      */   {
/* 1944 */     while (valueType.isArray()) {
/* 1945 */       valueType = valueType.getComponentType();
/*      */     }
/*      */     
/*      */ 
/* 1949 */     if (Enum.class.isAssignableFrom(valueType)) {
/* 1950 */       return true;
/*      */     }
/*      */     
/* 1953 */     String clsName = valueType.getName();
/* 1954 */     if (clsName.startsWith("java.")) {
/* 1955 */       if (Collection.class.isAssignableFrom(valueType)) {
/* 1956 */         return true;
/*      */       }
/* 1958 */       if (Map.class.isAssignableFrom(valueType)) {
/* 1959 */         return true;
/*      */       }
/* 1961 */       if (Number.class.isAssignableFrom(valueType)) {
/* 1962 */         return com.fasterxml.jackson.databind.deser.std.NumberDeserializers.find(valueType, clsName) != null;
/*      */       }
/* 1964 */       if ((com.fasterxml.jackson.databind.deser.std.JdkDeserializers.hasDeserializerFor(valueType)) || (valueType == CLASS_STRING) || (valueType == Boolean.class) || (valueType == java.util.EnumMap.class) || (valueType == java.util.concurrent.atomic.AtomicReference.class))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1970 */         return true;
/*      */       }
/* 1972 */       if (com.fasterxml.jackson.databind.deser.std.DateDeserializers.hasDeserializerFor(valueType))
/* 1973 */         return true;
/*      */     } else {
/* 1975 */       if (clsName.startsWith("com.fasterxml.")) {
/* 1976 */         return (com.fasterxml.jackson.databind.JsonNode.class.isAssignableFrom(valueType)) || (valueType == com.fasterxml.jackson.databind.util.TokenBuffer.class);
/*      */       }
/*      */       
/* 1979 */       return com.fasterxml.jackson.databind.ext.OptionalHandlerFactory.instance.hasDeserializerFor(valueType);
/*      */     }
/* 1981 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TypeDeserializer findPropertyTypeDeserializer(DeserializationConfig config, JavaType baseType, AnnotatedMember annotated)
/*      */     throws JsonMappingException
/*      */   {
/* 2007 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 2008 */     TypeResolverBuilder<?> b = ai.findPropertyTypeResolver(config, annotated, baseType);
/*      */     
/* 2010 */     if (b == null) {
/* 2011 */       return findTypeDeserializer(config, baseType);
/*      */     }
/*      */     
/* 2014 */     Collection<com.fasterxml.jackson.databind.jsontype.NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByTypeId(config, annotated, baseType);
/*      */     try
/*      */     {
/* 2017 */       return b.buildTypeDeserializer(config, baseType, subtypes);
/*      */     } catch (IllegalArgumentException|IllegalStateException e0) {
/* 2019 */       InvalidDefinitionException e = InvalidDefinitionException.from((com.fasterxml.jackson.core.JsonParser)null, 
/* 2020 */         ClassUtil.exceptionMessage(e0), baseType);
/* 2021 */       e.initCause(e0);
/* 2022 */       throw e;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TypeDeserializer findPropertyContentTypeDeserializer(DeserializationConfig config, JavaType containerType, AnnotatedMember propertyEntity)
/*      */     throws JsonMappingException
/*      */   {
/* 2041 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 2042 */     TypeResolverBuilder<?> b = ai.findPropertyContentTypeResolver(config, propertyEntity, containerType);
/* 2043 */     JavaType contentType = containerType.getContentType();
/*      */     
/* 2045 */     if (b == null) {
/* 2046 */       return findTypeDeserializer(config, contentType);
/*      */     }
/*      */     
/* 2049 */     Collection<com.fasterxml.jackson.databind.jsontype.NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByTypeId(config, propertyEntity, contentType);
/*      */     
/* 2051 */     return b.buildTypeDeserializer(config, contentType, subtypes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<?> findDefaultDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 2065 */     Class<?> rawType = type.getRawClass();
/*      */     
/* 2067 */     if ((rawType == CLASS_OBJECT) || (rawType == CLASS_SERIALIZABLE))
/*      */     {
/* 2069 */       DeserializationConfig config = ctxt.getConfig();
/*      */       JavaType mt;
/*      */       JavaType mt;
/* 2072 */       JavaType lt; if (this._factoryConfig.hasAbstractTypeResolvers()) {
/* 2073 */         JavaType lt = _findRemappedType(config, List.class);
/* 2074 */         mt = _findRemappedType(config, Map.class);
/*      */       } else {
/* 2076 */         lt = mt = null;
/*      */       }
/* 2078 */       return new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer(lt, mt);
/*      */     }
/*      */     
/* 2081 */     if ((rawType == CLASS_STRING) || (rawType == CLASS_CHAR_SEQUENCE)) {
/* 2082 */       return com.fasterxml.jackson.databind.deser.std.StringDeserializer.instance;
/*      */     }
/* 2084 */     if (rawType == CLASS_ITERABLE)
/*      */     {
/* 2086 */       TypeFactory tf = ctxt.getTypeFactory();
/* 2087 */       JavaType[] tps = tf.findTypeParameters(type, CLASS_ITERABLE);
/* 2088 */       JavaType elemType = (tps == null) || (tps.length != 1) ? TypeFactory.unknownType() : tps[0];
/* 2089 */       CollectionType ct = tf.constructCollectionType(Collection.class, elemType);
/*      */       
/* 2091 */       return createCollectionDeserializer(ctxt, ct, beanDesc);
/*      */     }
/* 2093 */     if (rawType == CLASS_MAP_ENTRY)
/*      */     {
/* 2095 */       JavaType kt = type.containedTypeOrUnknown(0);
/* 2096 */       JavaType vt = type.containedTypeOrUnknown(1);
/* 2097 */       TypeDeserializer vts = (TypeDeserializer)vt.getTypeHandler();
/* 2098 */       if (vts == null) {
/* 2099 */         vts = findTypeDeserializer(ctxt.getConfig(), vt);
/*      */       }
/* 2101 */       JsonDeserializer<Object> valueDeser = (JsonDeserializer)vt.getValueHandler();
/* 2102 */       KeyDeserializer keyDes = (KeyDeserializer)kt.getValueHandler();
/* 2103 */       return new com.fasterxml.jackson.databind.deser.std.MapEntryDeserializer(type, keyDes, valueDeser, vts);
/*      */     }
/* 2105 */     String clsName = rawType.getName();
/* 2106 */     if ((rawType.isPrimitive()) || (clsName.startsWith("java.")))
/*      */     {
/* 2108 */       JsonDeserializer<?> deser = com.fasterxml.jackson.databind.deser.std.NumberDeserializers.find(rawType, clsName);
/* 2109 */       if (deser == null) {
/* 2110 */         deser = com.fasterxml.jackson.databind.deser.std.DateDeserializers.find(rawType, clsName);
/*      */       }
/* 2112 */       if (deser != null) {
/* 2113 */         return deser;
/*      */       }
/*      */     }
/*      */     
/* 2117 */     if (rawType == com.fasterxml.jackson.databind.util.TokenBuffer.class) {
/* 2118 */       return new com.fasterxml.jackson.databind.deser.std.TokenBufferDeserializer();
/*      */     }
/* 2120 */     JsonDeserializer<?> deser = findOptionalStdDeserializer(ctxt, type, beanDesc);
/* 2121 */     if (deser != null) {
/* 2122 */       return deser;
/*      */     }
/* 2124 */     return com.fasterxml.jackson.databind.deser.std.JdkDeserializers.find(rawType, clsName);
/*      */   }
/*      */   
/*      */   protected JavaType _findRemappedType(DeserializationConfig config, Class<?> rawType) throws JsonMappingException {
/* 2128 */     JavaType type = mapAbstractType(config, config.constructType(rawType));
/* 2129 */     return (type == null) || (type.hasRawClass(rawType)) ? null : type;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomTreeNodeDeserializer(Class<? extends com.fasterxml.jackson.databind.JsonNode> type, DeserializationConfig config, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 2142 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 2143 */       JsonDeserializer<?> deser = d.findTreeNodeDeserializer(type, config, beanDesc);
/* 2144 */       if (deser != null) {
/* 2145 */         return deser;
/*      */       }
/*      */     }
/* 2148 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomReferenceDeserializer(ReferenceType type, DeserializationConfig config, BeanDescription beanDesc, TypeDeserializer contentTypeDeserializer, JsonDeserializer<?> contentDeserializer)
/*      */     throws JsonMappingException
/*      */   {
/* 2156 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 2157 */       JsonDeserializer<?> deser = d.findReferenceDeserializer(type, config, beanDesc, contentTypeDeserializer, contentDeserializer);
/*      */       
/* 2159 */       if (deser != null) {
/* 2160 */         return deser;
/*      */       }
/*      */     }
/* 2163 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> _findCustomBeanDeserializer(JavaType type, DeserializationConfig config, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 2171 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 2172 */       JsonDeserializer<?> deser = d.findBeanDeserializer(type, config, beanDesc);
/* 2173 */       if (deser != null) {
/* 2174 */         return deser;
/*      */       }
/*      */     }
/* 2177 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomArrayDeserializer(ArrayType type, DeserializationConfig config, BeanDescription beanDesc, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer)
/*      */     throws JsonMappingException
/*      */   {
/* 2185 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 2186 */       JsonDeserializer<?> deser = d.findArrayDeserializer(type, config, beanDesc, elementTypeDeserializer, elementDeserializer);
/*      */       
/* 2188 */       if (deser != null) {
/* 2189 */         return deser;
/*      */       }
/*      */     }
/* 2192 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomCollectionDeserializer(CollectionType type, DeserializationConfig config, BeanDescription beanDesc, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer)
/*      */     throws JsonMappingException
/*      */   {
/* 2200 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 2201 */       JsonDeserializer<?> deser = d.findCollectionDeserializer(type, config, beanDesc, elementTypeDeserializer, elementDeserializer);
/*      */       
/* 2203 */       if (deser != null) {
/* 2204 */         return deser;
/*      */       }
/*      */     }
/* 2207 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomCollectionLikeDeserializer(CollectionLikeType type, DeserializationConfig config, BeanDescription beanDesc, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer)
/*      */     throws JsonMappingException
/*      */   {
/* 2215 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 2216 */       JsonDeserializer<?> deser = d.findCollectionLikeDeserializer(type, config, beanDesc, elementTypeDeserializer, elementDeserializer);
/*      */       
/* 2218 */       if (deser != null) {
/* 2219 */         return deser;
/*      */       }
/*      */     }
/* 2222 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomEnumDeserializer(Class<?> type, DeserializationConfig config, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 2229 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 2230 */       JsonDeserializer<?> deser = d.findEnumDeserializer(type, config, beanDesc);
/* 2231 */       if (deser != null) {
/* 2232 */         return deser;
/*      */       }
/*      */     }
/* 2235 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomMapDeserializer(MapType type, DeserializationConfig config, BeanDescription beanDesc, KeyDeserializer keyDeserializer, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer)
/*      */     throws JsonMappingException
/*      */   {
/* 2244 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 2245 */       JsonDeserializer<?> deser = d.findMapDeserializer(type, config, beanDesc, keyDeserializer, elementTypeDeserializer, elementDeserializer);
/*      */       
/* 2247 */       if (deser != null) {
/* 2248 */         return deser;
/*      */       }
/*      */     }
/* 2251 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<?> _findCustomMapLikeDeserializer(MapLikeType type, DeserializationConfig config, BeanDescription beanDesc, KeyDeserializer keyDeserializer, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer)
/*      */     throws JsonMappingException
/*      */   {
/* 2260 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 2261 */       JsonDeserializer<?> deser = d.findMapLikeDeserializer(type, config, beanDesc, keyDeserializer, elementTypeDeserializer, elementDeserializer);
/*      */       
/* 2263 */       if (deser != null) {
/* 2264 */         return deser;
/*      */       }
/*      */     }
/* 2267 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> findDeserializerFromAnnotation(DeserializationContext ctxt, Annotated ann)
/*      */     throws JsonMappingException
/*      */   {
/* 2288 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 2289 */     if (intr != null) {
/* 2290 */       Object deserDef = intr.findDeserializer(ann);
/* 2291 */       if (deserDef != null) {
/* 2292 */         return ctxt.deserializerInstance(ann, deserDef);
/*      */       }
/*      */     }
/* 2295 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected KeyDeserializer findKeyDeserializerFromAnnotation(DeserializationContext ctxt, Annotated ann)
/*      */     throws JsonMappingException
/*      */   {
/* 2307 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 2308 */     if (intr != null) {
/* 2309 */       Object deserDef = intr.findKeyDeserializer(ann);
/* 2310 */       if (deserDef != null) {
/* 2311 */         return ctxt.keyDeserializerInstance(ann, deserDef);
/*      */       }
/*      */     }
/* 2314 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> findContentDeserializerFromAnnotation(DeserializationContext ctxt, Annotated ann)
/*      */     throws JsonMappingException
/*      */   {
/* 2324 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 2325 */     if (intr != null) {
/* 2326 */       Object deserDef = intr.findContentDeserializer(ann);
/* 2327 */       if (deserDef != null) {
/* 2328 */         return ctxt.deserializerInstance(ann, deserDef);
/*      */       }
/*      */     }
/* 2331 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JavaType resolveMemberAndTypeAnnotations(DeserializationContext ctxt, AnnotatedMember member, JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/* 2347 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 2348 */     if (intr == null) {
/* 2349 */       return type;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2355 */     if (type.isMapLikeType()) {
/* 2356 */       JavaType keyType = type.getKeyType();
/* 2357 */       if (keyType != null) {
/* 2358 */         Object kdDef = intr.findKeyDeserializer(member);
/* 2359 */         KeyDeserializer kd = ctxt.keyDeserializerInstance(member, kdDef);
/* 2360 */         if (kd != null) {
/* 2361 */           type = ((MapLikeType)type).withKeyValueHandler(kd);
/* 2362 */           keyType = type.getKeyType();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2367 */     if (type.hasContentType()) {
/* 2368 */       Object cdDef = intr.findContentDeserializer(member);
/* 2369 */       JsonDeserializer<?> cd = ctxt.deserializerInstance(member, cdDef);
/* 2370 */       if (cd != null) {
/* 2371 */         type = type.withContentValueHandler(cd);
/*      */       }
/* 2373 */       TypeDeserializer contentTypeDeser = findPropertyContentTypeDeserializer(ctxt
/* 2374 */         .getConfig(), type, member);
/* 2375 */       if (contentTypeDeser != null) {
/* 2376 */         type = type.withContentTypeHandler(contentTypeDeser);
/*      */       }
/*      */     }
/* 2379 */     TypeDeserializer valueTypeDeser = findPropertyTypeDeserializer(ctxt.getConfig(), type, member);
/*      */     
/* 2381 */     if (valueTypeDeser != null) {
/* 2382 */       type = type.withTypeHandler(valueTypeDeser);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2390 */     type = intr.refineDeserializationType(ctxt.getConfig(), member, type);
/* 2391 */     return type;
/*      */   }
/*      */   
/*      */ 
/*      */   protected com.fasterxml.jackson.databind.util.EnumResolver constructEnumResolver(Class<?> enumClass, DeserializationConfig config, AnnotatedMember jsonValueAccessor)
/*      */   {
/* 2397 */     if (jsonValueAccessor != null) {
/* 2398 */       if (config.canOverrideAccessModifiers()) {
/* 2399 */         ClassUtil.checkAndFixAccess(jsonValueAccessor.getMember(), config
/* 2400 */           .isEnabled(com.fasterxml.jackson.databind.MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*      */       }
/* 2402 */       return com.fasterxml.jackson.databind.util.EnumResolver.constructUsingMethod(config, enumClass, jsonValueAccessor);
/*      */     }
/*      */     
/*      */ 
/* 2406 */     return com.fasterxml.jackson.databind.util.EnumResolver.constructFor(config, enumClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _hasCreatorAnnotation(DeserializationContext ctxt, Annotated ann)
/*      */   {
/* 2414 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 2415 */     if (intr != null) {
/* 2416 */       JsonCreator.Mode mode = intr.findCreatorAnnotation(ctxt.getConfig(), ann);
/* 2417 */       return (mode != null) && (mode != JsonCreator.Mode.DISABLED);
/*      */     }
/* 2419 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected JavaType modifyTypeByAnnotation(DeserializationContext ctxt, Annotated a, JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/* 2439 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 2440 */     if (intr == null) {
/* 2441 */       return type;
/*      */     }
/* 2443 */     return intr.refineDeserializationType(ctxt.getConfig(), a, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected JavaType resolveType(DeserializationContext ctxt, BeanDescription beanDesc, JavaType type, AnnotatedMember member)
/*      */     throws JsonMappingException
/*      */   {
/* 2454 */     return resolveMemberAndTypeAnnotations(ctxt, member, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected AnnotatedMethod _findJsonValueFor(DeserializationConfig config, JavaType enumType)
/*      */   {
/* 2463 */     if (enumType == null) {
/* 2464 */       return null;
/*      */     }
/* 2466 */     BeanDescription beanDesc = config.introspect(enumType);
/* 2467 */     return beanDesc.findJsonValueMethod();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static class ContainerDefaultMappings
/*      */   {
/*      */     static final HashMap<String, Class<? extends Collection>> _collectionFallbacks;
/*      */     
/*      */ 
/*      */     static final HashMap<String, Class<? extends Map>> _mapFallbacks;
/*      */     
/*      */ 
/*      */ 
/*      */     static
/*      */     {
/* 2484 */       HashMap<String, Class<? extends Collection>> fallbacks = new HashMap();
/*      */       
/* 2486 */       Class<? extends Collection> DEFAULT_LIST = java.util.ArrayList.class;
/* 2487 */       Class<? extends Collection> DEFAULT_SET = java.util.HashSet.class;
/*      */       
/* 2489 */       fallbacks.put(Collection.class.getName(), DEFAULT_LIST);
/* 2490 */       fallbacks.put(List.class.getName(), DEFAULT_LIST);
/* 2491 */       fallbacks.put(java.util.Set.class.getName(), DEFAULT_SET);
/* 2492 */       fallbacks.put(java.util.SortedSet.class.getName(), java.util.TreeSet.class);
/* 2493 */       fallbacks.put(java.util.Queue.class.getName(), java.util.LinkedList.class);
/*      */       
/*      */ 
/* 2496 */       fallbacks.put(java.util.AbstractList.class.getName(), DEFAULT_LIST);
/* 2497 */       fallbacks.put(java.util.AbstractSet.class.getName(), DEFAULT_SET);
/*      */       
/*      */ 
/* 2500 */       fallbacks.put(java.util.Deque.class.getName(), java.util.LinkedList.class);
/* 2501 */       fallbacks.put(java.util.NavigableSet.class.getName(), java.util.TreeSet.class);
/*      */       
/* 2503 */       _collectionFallbacks = fallbacks;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2511 */       HashMap<String, Class<? extends Map>> fallbacks = new HashMap();
/*      */       
/* 2513 */       Class<? extends Map> DEFAULT_MAP = java.util.LinkedHashMap.class;
/* 2514 */       fallbacks.put(Map.class.getName(), DEFAULT_MAP);
/* 2515 */       fallbacks.put(java.util.AbstractMap.class.getName(), DEFAULT_MAP);
/* 2516 */       fallbacks.put(java.util.concurrent.ConcurrentMap.class.getName(), java.util.concurrent.ConcurrentHashMap.class);
/* 2517 */       fallbacks.put(java.util.SortedMap.class.getName(), java.util.TreeMap.class);
/*      */       
/* 2519 */       fallbacks.put(java.util.NavigableMap.class.getName(), java.util.TreeMap.class);
/* 2520 */       fallbacks.put(java.util.concurrent.ConcurrentNavigableMap.class.getName(), java.util.concurrent.ConcurrentSkipListMap.class);
/*      */       
/*      */ 
/* 2523 */       _mapFallbacks = fallbacks;
/*      */     }
/*      */     
/*      */     public static Class<?> findCollectionFallback(JavaType type) {
/* 2527 */       return (Class)_collectionFallbacks.get(type.getRawClass().getName());
/*      */     }
/*      */     
/*      */     public static Class<?> findMapFallback(JavaType type) {
/* 2531 */       return (Class)_mapFallbacks.get(type.getRawClass().getName());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static class CreatorCollectionState
/*      */   {
/*      */     public final DeserializationContext context;
/*      */     
/*      */     public final BeanDescription beanDesc;
/*      */     
/*      */     public final VisibilityChecker<?> vchecker;
/*      */     
/*      */     public final CreatorCollector creators;
/*      */     
/*      */     public final Map<AnnotatedWithParams, BeanPropertyDefinition[]> creatorParams;
/*      */     
/*      */     private List<CreatorCandidate> _implicitFactoryCandidates;
/*      */     
/*      */     private int _explicitFactoryCount;
/*      */     
/*      */     private List<CreatorCandidate> _implicitConstructorCandidates;
/*      */     
/*      */     private int _explicitConstructorCount;
/*      */     
/*      */ 
/*      */     public CreatorCollectionState(DeserializationContext ctxt, BeanDescription bd, VisibilityChecker<?> vc, CreatorCollector cc, Map<AnnotatedWithParams, BeanPropertyDefinition[]> cp)
/*      */     {
/* 2559 */       this.context = ctxt;
/* 2560 */       this.beanDesc = bd;
/* 2561 */       this.vchecker = vc;
/* 2562 */       this.creators = cc;
/* 2563 */       this.creatorParams = cp;
/*      */     }
/*      */     
/*      */     public AnnotationIntrospector annotationIntrospector() {
/* 2567 */       return this.context.getAnnotationIntrospector();
/*      */     }
/*      */     
/*      */ 
/*      */     public void addImplicitFactoryCandidate(CreatorCandidate cc)
/*      */     {
/* 2573 */       if (this._implicitFactoryCandidates == null) {
/* 2574 */         this._implicitFactoryCandidates = new java.util.LinkedList();
/*      */       }
/* 2576 */       this._implicitFactoryCandidates.add(cc);
/*      */     }
/*      */     
/*      */     public void increaseExplicitFactoryCount() {
/* 2580 */       this._explicitFactoryCount += 1;
/*      */     }
/*      */     
/*      */     public boolean hasExplicitFactories() {
/* 2584 */       return this._explicitFactoryCount > 0;
/*      */     }
/*      */     
/*      */     public boolean hasImplicitFactoryCandidates() {
/* 2588 */       return this._implicitFactoryCandidates != null;
/*      */     }
/*      */     
/*      */     public List<CreatorCandidate> implicitFactoryCandidates() {
/* 2592 */       return this._implicitFactoryCandidates;
/*      */     }
/*      */     
/*      */ 
/*      */     public void addImplicitConstructorCandidate(CreatorCandidate cc)
/*      */     {
/* 2598 */       if (this._implicitConstructorCandidates == null) {
/* 2599 */         this._implicitConstructorCandidates = new java.util.LinkedList();
/*      */       }
/* 2601 */       this._implicitConstructorCandidates.add(cc);
/*      */     }
/*      */     
/*      */     public void increaseExplicitConstructorCount() {
/* 2605 */       this._explicitConstructorCount += 1;
/*      */     }
/*      */     
/*      */     public boolean hasExplicitConstructors() {
/* 2609 */       return this._explicitConstructorCount > 0;
/*      */     }
/*      */     
/*      */     public boolean hasImplicitConstructorCandidates() {
/* 2613 */       return this._implicitConstructorCandidates != null;
/*      */     }
/*      */     
/*      */     public List<CreatorCandidate> implicitConstructorCandidates() {
/* 2617 */       return this._implicitConstructorCandidates;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\BasicDeserializerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */