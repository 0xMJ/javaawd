/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonCreator.Mode;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude.Value;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector.ReferenceProperty;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import com.fasterxml.jackson.databind.util.Converter.None;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class BasicBeanDescription extends BeanDescription
/*     */ {
/*  31 */   private static final Class<?>[] NO_VIEWS = new Class[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final POJOPropertiesCollector _propCollector;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final MapperConfig<?> _config;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final AnnotationIntrospector _annotationIntrospector;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final AnnotatedClass _classInfo;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?>[] _defaultViews;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean _defaultViewsResolved;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<BeanPropertyDefinition> _properties;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ObjectIdInfo _objectIdInfo;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BasicBeanDescription(POJOPropertiesCollector coll, JavaType type, AnnotatedClass classDef)
/*     */   {
/*  96 */     super(type);
/*  97 */     this._propCollector = coll;
/*  98 */     this._config = coll.getConfig();
/*     */     
/* 100 */     if (this._config == null) {
/* 101 */       this._annotationIntrospector = null;
/*     */     } else {
/* 103 */       this._annotationIntrospector = this._config.getAnnotationIntrospector();
/*     */     }
/* 105 */     this._classInfo = classDef;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BasicBeanDescription(MapperConfig<?> config, JavaType type, AnnotatedClass classDef, List<BeanPropertyDefinition> props)
/*     */   {
/* 115 */     super(type);
/* 116 */     this._propCollector = null;
/* 117 */     this._config = config;
/*     */     
/* 119 */     if (this._config == null) {
/* 120 */       this._annotationIntrospector = null;
/*     */     } else {
/* 122 */       this._annotationIntrospector = this._config.getAnnotationIntrospector();
/*     */     }
/* 124 */     this._classInfo = classDef;
/* 125 */     this._properties = props;
/*     */   }
/*     */   
/*     */   protected BasicBeanDescription(POJOPropertiesCollector coll)
/*     */   {
/* 130 */     this(coll, coll.getType(), coll.getClassDef());
/* 131 */     this._objectIdInfo = coll.getObjectIdInfo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BasicBeanDescription forDeserialization(POJOPropertiesCollector coll)
/*     */   {
/* 139 */     return new BasicBeanDescription(coll);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BasicBeanDescription forSerialization(POJOPropertiesCollector coll)
/*     */   {
/* 147 */     return new BasicBeanDescription(coll);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BasicBeanDescription forOtherUse(MapperConfig<?> config, JavaType type, AnnotatedClass ac)
/*     */   {
/* 158 */     return new BasicBeanDescription(config, type, ac, 
/* 159 */       Collections.emptyList());
/*     */   }
/*     */   
/*     */   protected List<BeanPropertyDefinition> _properties() {
/* 163 */     if (this._properties == null) {
/* 164 */       this._properties = this._propCollector.getProperties();
/*     */     }
/* 166 */     return this._properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean removeProperty(String propName)
/*     */   {
/* 184 */     Iterator<BeanPropertyDefinition> it = _properties().iterator();
/* 185 */     while (it.hasNext()) {
/* 186 */       BeanPropertyDefinition prop = (BeanPropertyDefinition)it.next();
/* 187 */       if (prop.getName().equals(propName)) {
/* 188 */         it.remove();
/* 189 */         return true;
/*     */       }
/*     */     }
/* 192 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean addProperty(BeanPropertyDefinition def)
/*     */   {
/* 198 */     if (hasProperty(def.getFullName())) {
/* 199 */       return false;
/*     */     }
/* 201 */     _properties().add(def);
/* 202 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasProperty(PropertyName name)
/*     */   {
/* 209 */     return findProperty(name) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanPropertyDefinition findProperty(PropertyName name)
/*     */   {
/* 217 */     for (BeanPropertyDefinition prop : _properties()) {
/* 218 */       if (prop.hasName(name)) {
/* 219 */         return prop;
/*     */       }
/*     */     }
/* 222 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotatedClass getClassInfo()
/*     */   {
/* 232 */     return this._classInfo;
/*     */   }
/*     */   
/* 235 */   public ObjectIdInfo getObjectIdInfo() { return this._objectIdInfo; }
/*     */   
/*     */   public List<BeanPropertyDefinition> findProperties()
/*     */   {
/* 239 */     return _properties();
/*     */   }
/*     */   
/*     */   public AnnotatedMember findJsonKeyAccessor()
/*     */   {
/* 244 */     return this._propCollector == null ? null : this._propCollector
/* 245 */       .getJsonKeyAccessor();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public AnnotatedMethod findJsonValueMethod()
/*     */   {
/* 251 */     return this._propCollector == null ? null : this._propCollector
/* 252 */       .getJsonValueMethod();
/*     */   }
/*     */   
/*     */   public AnnotatedMember findJsonValueAccessor()
/*     */   {
/* 257 */     return this._propCollector == null ? null : this._propCollector
/* 258 */       .getJsonValueAccessor();
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<String> getIgnoredPropertyNames()
/*     */   {
/* 264 */     Set<String> ign = this._propCollector == null ? null : this._propCollector.getIgnoredPropertyNames();
/* 265 */     if (ign == null) {
/* 266 */       return Collections.emptySet();
/*     */     }
/* 268 */     return ign;
/*     */   }
/*     */   
/*     */   public boolean hasKnownClassAnnotations()
/*     */   {
/* 273 */     return this._classInfo.hasAnnotations();
/*     */   }
/*     */   
/*     */   public com.fasterxml.jackson.databind.util.Annotations getClassAnnotations()
/*     */   {
/* 278 */     return this._classInfo.getAnnotations();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public com.fasterxml.jackson.databind.type.TypeBindings bindingsForBeanType()
/*     */   {
/* 284 */     return this._type.getBindings();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public JavaType resolveType(Type jdkType)
/*     */   {
/* 292 */     return this._config.getTypeFactory().resolveMemberType(jdkType, this._type.getBindings());
/*     */   }
/*     */   
/*     */   public AnnotatedConstructor findDefaultConstructor()
/*     */   {
/* 297 */     return this._classInfo.getDefaultConstructor();
/*     */   }
/*     */   
/*     */   public AnnotatedMember findAnySetterAccessor()
/*     */     throws IllegalArgumentException
/*     */   {
/* 303 */     if (this._propCollector != null) {
/* 304 */       AnnotatedMethod anyMethod = this._propCollector.getAnySetterMethod();
/* 305 */       if (anyMethod != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 312 */         Class<?> type = anyMethod.getRawParameterType(0);
/* 313 */         if ((type != String.class) && (type != Object.class)) {
/* 314 */           throw new IllegalArgumentException(String.format("Invalid 'any-setter' annotation on method '%s()': first argument not of type String or Object, but %s", new Object[] {anyMethod
/*     */           
/* 316 */             .getName(), type.getName() }));
/*     */         }
/* 318 */         return anyMethod;
/*     */       }
/* 320 */       AnnotatedMember anyField = this._propCollector.getAnySetterField();
/* 321 */       if (anyField != null)
/*     */       {
/*     */ 
/* 324 */         Class<?> type = anyField.getRawType();
/* 325 */         if (!Map.class.isAssignableFrom(type)) {
/* 326 */           throw new IllegalArgumentException(String.format("Invalid 'any-setter' annotation on field '%s': type is not instance of java.util.Map", new Object[] {anyField
/*     */           
/* 328 */             .getName() }));
/*     */         }
/* 330 */         return anyField;
/*     */       }
/*     */     }
/* 333 */     return null;
/*     */   }
/*     */   
/*     */   public Map<Object, AnnotatedMember> findInjectables()
/*     */   {
/* 338 */     if (this._propCollector != null) {
/* 339 */       return this._propCollector.getInjectables();
/*     */     }
/* 341 */     return Collections.emptyMap();
/*     */   }
/*     */   
/*     */   public List<AnnotatedConstructor> getConstructors()
/*     */   {
/* 346 */     return this._classInfo.getConstructors();
/*     */   }
/*     */   
/*     */   public Object instantiateBean(boolean fixAccess)
/*     */   {
/* 351 */     AnnotatedConstructor ac = this._classInfo.getDefaultConstructor();
/* 352 */     if (ac == null) {
/* 353 */       return null;
/*     */     }
/* 355 */     if (fixAccess) {
/* 356 */       ac.fixAccess(this._config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */     }
/*     */     try {
/* 359 */       return ac.getAnnotated().newInstance(new Object[0]);
/*     */     } catch (Exception e) {
/* 361 */       Throwable t = e;
/* 362 */       while (t.getCause() != null) {
/* 363 */         t = t.getCause();
/*     */       }
/* 365 */       ClassUtil.throwIfError(t);
/* 366 */       ClassUtil.throwIfRTE(t);
/*     */       
/*     */ 
/* 369 */       throw new IllegalArgumentException("Failed to instantiate bean of type " + this._classInfo.getAnnotated().getName() + ": (" + t.getClass().getName() + ") " + ClassUtil.exceptionMessage(t), t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotatedMethod findMethod(String name, Class<?>[] paramTypes)
/*     */   {
/* 381 */     return this._classInfo.findMethod(name, paramTypes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonFormat.Value findExpectedFormat(JsonFormat.Value defValue)
/*     */   {
/* 395 */     if (this._annotationIntrospector != null) {
/* 396 */       JsonFormat.Value v = this._annotationIntrospector.findFormat(this._classInfo);
/* 397 */       if (v != null) {
/* 398 */         if (defValue == null) {
/* 399 */           defValue = v;
/*     */         } else {
/* 401 */           defValue = defValue.withOverrides(v);
/*     */         }
/*     */       }
/*     */     }
/* 405 */     JsonFormat.Value v = this._config.getDefaultPropertyFormat(this._classInfo.getRawType());
/* 406 */     if (v != null) {
/* 407 */       if (defValue == null) {
/* 408 */         defValue = v;
/*     */       } else {
/* 410 */         defValue = defValue.withOverrides(v);
/*     */       }
/*     */     }
/* 413 */     return defValue;
/*     */   }
/*     */   
/*     */ 
/*     */   public Class<?>[] findDefaultViews()
/*     */   {
/* 419 */     if (!this._defaultViewsResolved) {
/* 420 */       this._defaultViewsResolved = true;
/*     */       
/* 422 */       Class<?>[] def = this._annotationIntrospector == null ? null : this._annotationIntrospector.findViews(this._classInfo);
/*     */       
/* 424 */       if ((def == null) && 
/* 425 */         (!this._config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION))) {
/* 426 */         def = NO_VIEWS;
/*     */       }
/*     */       
/* 429 */       this._defaultViews = def;
/*     */     }
/* 431 */     return this._defaultViews;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Converter<Object, Object> findSerializationConverter()
/*     */   {
/* 443 */     if (this._annotationIntrospector == null) {
/* 444 */       return null;
/*     */     }
/* 446 */     return _createConverter(this._annotationIntrospector.findSerializationConverter(this._classInfo));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonInclude.Value findPropertyInclusion(JsonInclude.Value defValue)
/*     */   {
/* 457 */     if (this._annotationIntrospector != null) {
/* 458 */       JsonInclude.Value incl = this._annotationIntrospector.findPropertyInclusion(this._classInfo);
/* 459 */       if (incl != null) {
/* 460 */         return defValue == null ? incl : defValue.withOverrides(incl);
/*     */       }
/*     */     }
/* 463 */     return defValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotatedMember findAnyGetter()
/*     */     throws IllegalArgumentException
/*     */   {
/* 475 */     if (this._propCollector != null) {
/* 476 */       AnnotatedMember anyGetter = this._propCollector.getAnyGetterMethod();
/* 477 */       if (anyGetter != null)
/*     */       {
/*     */ 
/* 480 */         Class<?> type = anyGetter.getRawType();
/* 481 */         if (!Map.class.isAssignableFrom(type)) {
/* 482 */           throw new IllegalArgumentException(String.format("Invalid 'any-getter' annotation on method %s(): return type is not instance of java.util.Map", new Object[] {anyGetter
/*     */           
/* 484 */             .getName() }));
/*     */         }
/* 486 */         return anyGetter;
/*     */       }
/*     */       
/* 489 */       AnnotatedMember anyField = this._propCollector.getAnyGetterField();
/* 490 */       if (anyField != null)
/*     */       {
/*     */ 
/* 493 */         Class<?> type = anyField.getRawType();
/* 494 */         if (!Map.class.isAssignableFrom(type)) {
/* 495 */           throw new IllegalArgumentException(String.format("Invalid 'any-getter' annotation on field '%s': type is not instance of java.util.Map", new Object[] {anyField
/*     */           
/* 497 */             .getName() }));
/*     */         }
/* 499 */         return anyField;
/*     */       }
/*     */     }
/* 502 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public List<BeanPropertyDefinition> findBackReferences()
/*     */   {
/* 508 */     List<BeanPropertyDefinition> result = null;
/* 509 */     HashSet<String> names = null;
/* 510 */     for (BeanPropertyDefinition property : _properties()) {
/* 511 */       AnnotationIntrospector.ReferenceProperty refDef = property.findReferenceType();
/* 512 */       if ((refDef != null) && (refDef.isBackReference()))
/*     */       {
/*     */ 
/* 515 */         String refName = refDef.getName();
/* 516 */         if (result == null) {
/* 517 */           result = new ArrayList();
/* 518 */           names = new HashSet();
/* 519 */           names.add(refName);
/*     */         }
/* 521 */         else if (!names.add(refName)) {
/* 522 */           throw new IllegalArgumentException("Multiple back-reference properties with name " + ClassUtil.name(refName));
/*     */         }
/*     */         
/* 525 */         result.add(property);
/*     */       } }
/* 527 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   @Deprecated
/*     */   public Map<String, AnnotatedMember> findBackReferenceProperties()
/*     */   {
/* 534 */     List<BeanPropertyDefinition> props = findBackReferences();
/* 535 */     if (props == null) {
/* 536 */       return null;
/*     */     }
/* 538 */     Map<String, AnnotatedMember> result = new java.util.HashMap();
/* 539 */     for (BeanPropertyDefinition prop : props) {
/* 540 */       result.put(prop.getName(), prop.getMutator());
/*     */     }
/* 542 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<AnnotatedMethod> getFactoryMethods()
/*     */   {
/* 555 */     List<AnnotatedMethod> candidates = this._classInfo.getFactoryMethods();
/* 556 */     if (candidates.isEmpty()) {
/* 557 */       return candidates;
/*     */     }
/* 559 */     List<AnnotatedMethod> result = null;
/* 560 */     for (AnnotatedMethod am : candidates) {
/* 561 */       if (isFactoryMethod(am)) {
/* 562 */         if (result == null) {
/* 563 */           result = new ArrayList();
/*     */         }
/* 565 */         result.add(am);
/*     */       }
/*     */     }
/* 568 */     if (result == null) {
/* 569 */       return Collections.emptyList();
/*     */     }
/* 571 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public Constructor<?> findSingleArgConstructor(Class<?>... argTypes)
/*     */   {
/* 577 */     for (AnnotatedConstructor ac : this._classInfo.getConstructors())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 582 */       if (ac.getParameterCount() == 1) {
/* 583 */         Class<?> actArg = ac.getRawParameterType(0);
/* 584 */         for (Class<?> expArg : argTypes) {
/* 585 */           if (expArg == actArg) {
/* 586 */             return ac.getAnnotated();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 591 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public java.lang.reflect.Method findFactoryMethod(Class<?>... expArgTypes)
/*     */   {
/* 598 */     for (AnnotatedMethod am : this._classInfo.getFactoryMethods())
/*     */     {
/* 600 */       if ((isFactoryMethod(am)) && (am.getParameterCount() == 1))
/*     */       {
/* 602 */         Class<?> actualArgType = am.getRawParameterType(0);
/* 603 */         for (Class<?> expArgType : expArgTypes)
/*     */         {
/* 605 */           if (actualArgType.isAssignableFrom(expArgType)) {
/* 606 */             return am.getAnnotated();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 611 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isFactoryMethod(AnnotatedMethod am)
/*     */   {
/* 618 */     Class<?> rt = am.getRawReturnType();
/* 619 */     if (!getBeanClass().isAssignableFrom(rt)) {
/* 620 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 626 */     JsonCreator.Mode mode = this._annotationIntrospector.findCreatorAnnotation(this._config, am);
/* 627 */     if ((mode != null) && (mode != JsonCreator.Mode.DISABLED)) {
/* 628 */       return true;
/*     */     }
/* 630 */     String name = am.getName();
/*     */     
/* 632 */     if (("valueOf".equals(name)) && 
/* 633 */       (am.getParameterCount() == 1)) {
/* 634 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 638 */     if (("fromString".equals(name)) && 
/* 639 */       (am.getParameterCount() == 1)) {
/* 640 */       Class<?> cls = am.getRawParameterType(0);
/* 641 */       if ((cls == String.class) || (CharSequence.class.isAssignableFrom(cls))) {
/* 642 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 646 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected PropertyName _findCreatorPropertyName(AnnotatedParameter param)
/*     */   {
/* 655 */     PropertyName name = this._annotationIntrospector.findNameForDeserialization(param);
/* 656 */     if ((name == null) || (name.isEmpty())) {
/* 657 */       String str = this._annotationIntrospector.findImplicitPropertyName(param);
/* 658 */       if ((str != null) && (!str.isEmpty())) {
/* 659 */         name = PropertyName.construct(str);
/*     */       }
/*     */     }
/* 662 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> findPOJOBuilder()
/*     */   {
/* 673 */     return this._annotationIntrospector == null ? null : this._annotationIntrospector
/* 674 */       .findPOJOBuilder(this._classInfo);
/*     */   }
/*     */   
/*     */ 
/*     */   public com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder.Value findPOJOBuilderConfig()
/*     */   {
/* 680 */     return this._annotationIntrospector == null ? null : this._annotationIntrospector
/* 681 */       .findPOJOBuilderConfig(this._classInfo);
/*     */   }
/*     */   
/*     */ 
/*     */   public Converter<Object, Object> findDeserializationConverter()
/*     */   {
/* 687 */     if (this._annotationIntrospector == null) {
/* 688 */       return null;
/*     */     }
/* 690 */     return _createConverter(this._annotationIntrospector.findDeserializationConverter(this._classInfo));
/*     */   }
/*     */   
/*     */   public String findClassDescription()
/*     */   {
/* 695 */     return this._annotationIntrospector == null ? null : this._annotationIntrospector
/* 696 */       .findClassDescription(this._classInfo);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public LinkedHashMap<String, AnnotatedField> _findPropertyFields(Collection<String> ignoredProperties, boolean forSerialization)
/*     */   {
/* 721 */     LinkedHashMap<String, AnnotatedField> results = new LinkedHashMap();
/* 722 */     for (BeanPropertyDefinition property : _properties()) {
/* 723 */       AnnotatedField f = property.getField();
/* 724 */       if (f != null) {
/* 725 */         String name = property.getName();
/* 726 */         if ((ignoredProperties == null) || 
/* 727 */           (!ignoredProperties.contains(name)))
/*     */         {
/*     */ 
/*     */ 
/* 731 */           results.put(name, f); }
/*     */       }
/*     */     }
/* 734 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Converter<Object, Object> _createConverter(Object converterDef)
/*     */   {
/* 746 */     if (converterDef == null) {
/* 747 */       return null;
/*     */     }
/* 749 */     if ((converterDef instanceof Converter)) {
/* 750 */       return (Converter)converterDef;
/*     */     }
/* 752 */     if (!(converterDef instanceof Class))
/*     */     {
/* 754 */       throw new IllegalStateException("AnnotationIntrospector returned Converter definition of type " + converterDef.getClass().getName() + "; expected type Converter or Class<Converter> instead");
/*     */     }
/* 756 */     Class<?> converterClass = (Class)converterDef;
/*     */     
/* 758 */     if ((converterClass == Converter.None.class) || (ClassUtil.isBogusClass(converterClass))) {
/* 759 */       return null;
/*     */     }
/* 761 */     if (!Converter.class.isAssignableFrom(converterClass))
/*     */     {
/* 763 */       throw new IllegalStateException("AnnotationIntrospector returned Class " + converterClass.getName() + "; expected Class<Converter>");
/*     */     }
/* 765 */     HandlerInstantiator hi = this._config.getHandlerInstantiator();
/* 766 */     Converter<?, ?> conv = hi == null ? null : hi.converterInstance(this._config, this._classInfo, converterClass);
/* 767 */     if (conv == null) {
/* 768 */       conv = (Converter)ClassUtil.createInstance(converterClass, this._config
/* 769 */         .canOverrideAccessModifiers());
/*     */     }
/* 771 */     return conv;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\introspect\BasicBeanDescription.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */