/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExternalTypeHandler
/*     */ {
/*     */   private final JavaType _beanType;
/*     */   private final ExtTypedProperty[] _properties;
/*     */   private final Map<String, Object> _nameToPropertyIndex;
/*     */   private final String[] _typeIds;
/*     */   private final TokenBuffer[] _tokens;
/*     */   
/*     */   protected ExternalTypeHandler(JavaType beanType, ExtTypedProperty[] properties, Map<String, Object> nameToPropertyIndex, String[] typeIds, TokenBuffer[] tokens)
/*     */   {
/*  41 */     this._beanType = beanType;
/*  42 */     this._properties = properties;
/*  43 */     this._nameToPropertyIndex = nameToPropertyIndex;
/*  44 */     this._typeIds = typeIds;
/*  45 */     this._tokens = tokens;
/*     */   }
/*     */   
/*     */   protected ExternalTypeHandler(ExternalTypeHandler h)
/*     */   {
/*  50 */     this._beanType = h._beanType;
/*  51 */     this._properties = h._properties;
/*  52 */     this._nameToPropertyIndex = h._nameToPropertyIndex;
/*  53 */     int len = this._properties.length;
/*  54 */     this._typeIds = new String[len];
/*  55 */     this._tokens = new TokenBuffer[len];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Builder builder(JavaType beanType)
/*     */   {
/*  62 */     return new Builder(beanType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExternalTypeHandler start()
/*     */   {
/*  70 */     return new ExternalTypeHandler(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean handleTypePropertyValue(JsonParser p, DeserializationContext ctxt, String propName, Object bean)
/*     */     throws IOException
/*     */   {
/*  85 */     Object ob = this._nameToPropertyIndex.get(propName);
/*  86 */     if (ob == null) {
/*  87 */       return false;
/*     */     }
/*  89 */     String typeId = p.getText();
/*     */     
/*  91 */     if ((ob instanceof List)) {
/*  92 */       boolean result = false;
/*  93 */       for (Integer index : (List)ob) {
/*  94 */         if (_handleTypePropertyValue(p, ctxt, propName, bean, typeId, index
/*  95 */           .intValue())) {
/*  96 */           result = true;
/*     */         }
/*     */       }
/*  99 */       return result;
/*     */     }
/* 101 */     return _handleTypePropertyValue(p, ctxt, propName, bean, typeId, ((Integer)ob)
/* 102 */       .intValue());
/*     */   }
/*     */   
/*     */ 
/*     */   private final boolean _handleTypePropertyValue(JsonParser p, DeserializationContext ctxt, String propName, Object bean, String typeId, int index)
/*     */     throws IOException
/*     */   {
/* 109 */     ExtTypedProperty prop = this._properties[index];
/* 110 */     if (!prop.hasTypePropertyName(propName)) {
/* 111 */       return false;
/*     */     }
/*     */     
/* 114 */     boolean canDeserialize = (bean != null) && (this._tokens[index] != null);
/*     */     
/* 116 */     if (canDeserialize) {
/* 117 */       _deserializeAndSet(p, ctxt, bean, index, typeId);
/*     */       
/* 119 */       this._tokens[index] = null;
/*     */     } else {
/* 121 */       this._typeIds[index] = typeId;
/*     */     }
/* 123 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean handlePropertyValue(JsonParser p, DeserializationContext ctxt, String propName, Object bean)
/*     */     throws IOException
/*     */   {
/* 138 */     Object ob = this._nameToPropertyIndex.get(propName);
/* 139 */     if (ob == null) {
/* 140 */       return false;
/*     */     }
/*     */     
/* 143 */     if ((ob instanceof List)) {
/* 144 */       Iterator<Integer> it = ((List)ob).iterator();
/* 145 */       Integer index = (Integer)it.next();
/*     */       
/* 147 */       ExtTypedProperty prop = this._properties[index.intValue()];
/*     */       
/*     */ 
/* 150 */       if (prop.hasTypePropertyName(propName)) {
/* 151 */         String typeId = p.getText();
/* 152 */         p.skipChildren();
/* 153 */         this._typeIds[index.intValue()] = typeId;
/* 154 */         while (it.hasNext()) {
/* 155 */           this._typeIds[((Integer)it.next()).intValue()] = typeId;
/*     */         }
/*     */       }
/*     */       else {
/* 159 */         TokenBuffer tokens = new TokenBuffer(p, ctxt);
/* 160 */         tokens.copyCurrentStructure(p);
/* 161 */         this._tokens[index.intValue()] = tokens;
/* 162 */         while (it.hasNext()) {
/* 163 */           this._tokens[((Integer)it.next()).intValue()] = tokens;
/*     */         }
/*     */       }
/* 166 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 171 */     int index = ((Integer)ob).intValue();
/* 172 */     ExtTypedProperty prop = this._properties[index];
/*     */     boolean canDeserialize;
/* 174 */     boolean canDeserialize; if (prop.hasTypePropertyName(propName))
/*     */     {
/*     */ 
/* 177 */       this._typeIds[index] = p.getValueAsString();
/* 178 */       p.skipChildren();
/* 179 */       canDeserialize = (bean != null) && (this._tokens[index] != null);
/*     */     }
/*     */     else {
/* 182 */       TokenBuffer tokens = new TokenBuffer(p, ctxt);
/* 183 */       tokens.copyCurrentStructure(p);
/* 184 */       this._tokens[index] = tokens;
/* 185 */       canDeserialize = (bean != null) && (this._typeIds[index] != null);
/*     */     }
/*     */     
/*     */ 
/* 189 */     if (canDeserialize) {
/* 190 */       String typeId = this._typeIds[index];
/*     */       
/* 192 */       this._typeIds[index] = null;
/* 193 */       _deserializeAndSet(p, ctxt, bean, index, typeId);
/* 194 */       this._tokens[index] = null;
/*     */     }
/* 196 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object complete(JsonParser p, DeserializationContext ctxt, Object bean)
/*     */     throws IOException
/*     */   {
/* 207 */     int i = 0; for (int len = this._properties.length; i < len; i++) {
/* 208 */       String typeId = this._typeIds[i];
/* 209 */       ExtTypedProperty extProp = this._properties[i];
/* 210 */       if (typeId == null) {
/* 211 */         TokenBuffer tokens = this._tokens[i];
/*     */         
/*     */ 
/* 214 */         if (tokens == null) {
/*     */           continue;
/*     */         }
/*     */         
/*     */ 
/* 219 */         JsonToken t = tokens.firstToken();
/* 220 */         if (t.isScalarValue()) {
/* 221 */           JsonParser buffered = tokens.asParser(p);
/* 222 */           buffered.nextToken();
/* 223 */           SettableBeanProperty prop = extProp.getProperty();
/* 224 */           Object result = TypeDeserializer.deserializeIfNatural(buffered, ctxt, prop.getType());
/* 225 */           if (result != null) {
/* 226 */             prop.set(bean, result);
/* 227 */             continue;
/*     */           }
/*     */         }
/*     */         
/* 231 */         if (!extProp.hasDefaultType()) {
/* 232 */           ctxt.reportPropertyInputMismatch(this._beanType, extProp.getProperty().getName(), "Missing external type id property '%s' (and no 'defaultImpl' specified)", new Object[] {extProp
/*     */           
/* 234 */             .getTypePropertyName() });
/*     */         } else {
/* 236 */           typeId = extProp.getDefaultTypeId();
/* 237 */           if (typeId == null) {
/* 238 */             ctxt.reportPropertyInputMismatch(this._beanType, extProp.getProperty().getName(), "Invalid default type id for property '%s': `null` returned by TypeIdResolver", new Object[] {extProp
/*     */             
/* 240 */               .getTypePropertyName() });
/*     */           }
/*     */         }
/* 243 */       } else if (this._tokens[i] == null) {
/* 244 */         SettableBeanProperty prop = extProp.getProperty();
/*     */         
/* 246 */         if ((prop.isRequired()) || 
/* 247 */           (ctxt.isEnabled(DeserializationFeature.FAIL_ON_MISSING_EXTERNAL_TYPE_ID_PROPERTY))) {
/* 248 */           ctxt.reportPropertyInputMismatch(bean.getClass(), prop.getName(), "Missing property '%s' for external type id '%s'", new Object[] {prop
/*     */           
/* 250 */             .getName(), extProp.getTypePropertyName() });
/*     */         }
/* 252 */         return bean;
/*     */       }
/* 254 */       _deserializeAndSet(p, ctxt, bean, i, typeId);
/*     */     }
/* 256 */     return bean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object complete(JsonParser p, DeserializationContext ctxt, PropertyValueBuffer buffer, PropertyBasedCreator creator)
/*     */     throws IOException
/*     */   {
/* 268 */     int len = this._properties.length;
/* 269 */     Object[] values = new Object[len];
/* 270 */     for (int i = 0; i < len; i++) {
/* 271 */       String typeId = this._typeIds[i];
/* 272 */       ExtTypedProperty extProp = this._properties[i];
/* 273 */       if (typeId == null)
/*     */       {
/* 275 */         TokenBuffer tb = this._tokens[i];
/* 276 */         if (tb == null) {
/*     */           continue;
/*     */         }
/* 279 */         if (tb.firstToken() == JsonToken.VALUE_NULL) {
/*     */           continue;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 285 */         if (!extProp.hasDefaultType()) {
/* 286 */           ctxt.reportPropertyInputMismatch(this._beanType, extProp.getProperty().getName(), "Missing external type id property '%s'", new Object[] {extProp
/*     */           
/* 288 */             .getTypePropertyName() });
/*     */         } else {
/* 290 */           typeId = extProp.getDefaultTypeId();
/*     */         }
/* 292 */       } else if (this._tokens[i] == null) {
/* 293 */         SettableBeanProperty prop = extProp.getProperty();
/* 294 */         if ((prop.isRequired()) || 
/* 295 */           (ctxt.isEnabled(DeserializationFeature.FAIL_ON_MISSING_EXTERNAL_TYPE_ID_PROPERTY))) {
/* 296 */           ctxt.reportPropertyInputMismatch(this._beanType, prop.getName(), "Missing property '%s' for external type id '%s'", new Object[] {prop
/*     */           
/* 298 */             .getName(), this._properties[i].getTypePropertyName() });
/*     */         }
/*     */       }
/* 301 */       if (this._tokens[i] != null) {
/* 302 */         values[i] = _deserialize(p, ctxt, i, typeId);
/*     */       }
/*     */       
/* 305 */       SettableBeanProperty prop = extProp.getProperty();
/*     */       
/* 307 */       if (prop.getCreatorIndex() >= 0) {
/* 308 */         buffer.assignParameter(prop, values[i]);
/*     */         
/*     */ 
/* 311 */         SettableBeanProperty typeProp = extProp.getTypeProperty();
/*     */         
/* 313 */         if ((typeProp != null) && (typeProp.getCreatorIndex() >= 0))
/*     */         {
/*     */           Object v;
/*     */           Object v;
/* 317 */           if (typeProp.getType().hasRawClass(String.class)) {
/* 318 */             v = typeId;
/*     */           } else {
/* 320 */             TokenBuffer tb = new TokenBuffer(p, ctxt);
/* 321 */             tb.writeString(typeId);
/* 322 */             v = typeProp.getValueDeserializer().deserialize(tb.asParserOnFirstToken(), ctxt);
/* 323 */             tb.close();
/*     */           }
/* 325 */           buffer.assignParameter(typeProp, v);
/*     */         }
/*     */       }
/*     */     }
/* 329 */     Object bean = creator.build(ctxt, buffer);
/*     */     
/* 331 */     for (int i = 0; i < len; i++) {
/* 332 */       SettableBeanProperty prop = this._properties[i].getProperty();
/* 333 */       if (prop.getCreatorIndex() < 0) {
/* 334 */         prop.set(bean, values[i]);
/*     */       }
/*     */     }
/* 337 */     return bean;
/*     */   }
/*     */   
/*     */ 
/*     */   protected final Object _deserialize(JsonParser p, DeserializationContext ctxt, int index, String typeId)
/*     */     throws IOException
/*     */   {
/* 344 */     JsonParser p2 = this._tokens[index].asParser(p);
/* 345 */     JsonToken t = p2.nextToken();
/*     */     
/* 347 */     if (t == JsonToken.VALUE_NULL) {
/* 348 */       return null;
/*     */     }
/* 350 */     TokenBuffer merged = new TokenBuffer(p, ctxt);
/* 351 */     merged.writeStartArray();
/* 352 */     merged.writeString(typeId);
/* 353 */     merged.copyCurrentStructure(p2);
/* 354 */     merged.writeEndArray();
/*     */     
/*     */ 
/* 357 */     JsonParser mp = merged.asParser(p);
/* 358 */     mp.nextToken();
/* 359 */     return this._properties[index].getProperty().deserialize(mp, ctxt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final void _deserializeAndSet(JsonParser p, DeserializationContext ctxt, Object bean, int index, String typeId)
/*     */     throws IOException
/*     */   {
/* 367 */     if (typeId == null) {
/* 368 */       ctxt.reportInputMismatch(this._beanType, "Internal error in external Type Id handling: `null` type id passed", new Object[0]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 373 */     JsonParser p2 = this._tokens[index].asParser(p);
/* 374 */     JsonToken t = p2.nextToken();
/*     */     
/* 376 */     if (t == JsonToken.VALUE_NULL) {
/* 377 */       this._properties[index].getProperty().set(bean, null);
/* 378 */       return;
/*     */     }
/* 380 */     TokenBuffer merged = new TokenBuffer(p, ctxt);
/* 381 */     merged.writeStartArray();
/* 382 */     merged.writeString(typeId);
/*     */     
/* 384 */     merged.copyCurrentStructure(p2);
/* 385 */     merged.writeEndArray();
/*     */     
/* 387 */     JsonParser mp = merged.asParser(p);
/* 388 */     mp.nextToken();
/* 389 */     this._properties[index].getProperty().deserializeAndSet(mp, ctxt, bean);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Builder
/*     */   {
/*     */     private final JavaType _beanType;
/*     */     
/*     */ 
/*     */ 
/* 402 */     private final List<ExternalTypeHandler.ExtTypedProperty> _properties = new ArrayList();
/* 403 */     private final Map<String, Object> _nameToPropertyIndex = new HashMap();
/*     */     
/*     */     protected Builder(JavaType t) {
/* 406 */       this._beanType = t;
/*     */     }
/*     */     
/*     */     public void addExternal(SettableBeanProperty property, TypeDeserializer typeDeser)
/*     */     {
/* 411 */       Integer index = Integer.valueOf(this._properties.size());
/* 412 */       this._properties.add(new ExternalTypeHandler.ExtTypedProperty(property, typeDeser));
/* 413 */       _addPropertyIndex(property.getName(), index);
/* 414 */       _addPropertyIndex(typeDeser.getPropertyName(), index);
/*     */     }
/*     */     
/*     */     private void _addPropertyIndex(String name, Integer index) {
/* 418 */       Object ob = this._nameToPropertyIndex.get(name);
/* 419 */       if (ob == null) {
/* 420 */         this._nameToPropertyIndex.put(name, index);
/* 421 */       } else if ((ob instanceof List))
/*     */       {
/* 423 */         List<Object> list = (List)ob;
/* 424 */         list.add(index);
/*     */       } else {
/* 426 */         List<Object> list = new LinkedList();
/* 427 */         list.add(ob);
/* 428 */         list.add(index);
/* 429 */         this._nameToPropertyIndex.put(name, list);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ExternalTypeHandler build(BeanPropertyMap otherProps)
/*     */     {
/* 442 */       int len = this._properties.size();
/* 443 */       ExternalTypeHandler.ExtTypedProperty[] extProps = new ExternalTypeHandler.ExtTypedProperty[len];
/* 444 */       for (int i = 0; i < len; i++) {
/* 445 */         ExternalTypeHandler.ExtTypedProperty extProp = (ExternalTypeHandler.ExtTypedProperty)this._properties.get(i);
/* 446 */         String typePropId = extProp.getTypePropertyName();
/* 447 */         SettableBeanProperty typeProp = otherProps.find(typePropId);
/* 448 */         if (typeProp != null) {
/* 449 */           extProp.linkTypeProperty(typeProp);
/*     */         }
/* 451 */         extProps[i] = extProp;
/*     */       }
/* 453 */       return new ExternalTypeHandler(this._beanType, extProps, this._nameToPropertyIndex, null, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class ExtTypedProperty
/*     */   {
/*     */     private final SettableBeanProperty _property;
/*     */     
/*     */     private final TypeDeserializer _typeDeserializer;
/*     */     
/*     */     private final String _typePropertyName;
/*     */     
/*     */     private SettableBeanProperty _typeProperty;
/*     */     
/*     */ 
/*     */     public ExtTypedProperty(SettableBeanProperty property, TypeDeserializer typeDeser)
/*     */     {
/* 471 */       this._property = property;
/* 472 */       this._typeDeserializer = typeDeser;
/* 473 */       this._typePropertyName = typeDeser.getPropertyName();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void linkTypeProperty(SettableBeanProperty p)
/*     */     {
/* 480 */       this._typeProperty = p;
/*     */     }
/*     */     
/*     */     public boolean hasTypePropertyName(String n) {
/* 484 */       return n.equals(this._typePropertyName);
/*     */     }
/*     */     
/*     */     public boolean hasDefaultType() {
/* 488 */       return this._typeDeserializer.hasDefaultImpl();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getDefaultTypeId()
/*     */     {
/* 497 */       Class<?> defaultType = this._typeDeserializer.getDefaultImpl();
/* 498 */       if (defaultType == null) {
/* 499 */         return null;
/*     */       }
/* 501 */       return this._typeDeserializer.getTypeIdResolver().idFromValueAndType(null, defaultType);
/*     */     }
/*     */     
/* 504 */     public String getTypePropertyName() { return this._typePropertyName; }
/*     */     
/*     */     public SettableBeanProperty getProperty() {
/* 507 */       return this._property;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public SettableBeanProperty getTypeProperty()
/*     */     {
/* 514 */       return this._typeProperty;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\impl\ExternalTypeHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */