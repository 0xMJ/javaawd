/*    */ package com.fasterxml.jackson.databind.util;
/*    */ 
/*    */ import java.text.DateFormat;
/*    */ import java.text.DecimalFormat;
/*    */ import java.text.FieldPosition;
/*    */ import java.text.ParseException;
/*    */ import java.text.ParsePosition;
/*    */ import java.util.Date;
/*    */ import java.util.GregorianCalendar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ISO8601DateFormat
/*    */   extends DateFormat
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ISO8601DateFormat()
/*    */   {
/* 23 */     this.numberFormat = new DecimalFormat();
/* 24 */     this.calendar = new GregorianCalendar();
/*    */   }
/*    */   
/*    */   public StringBuffer format(Date date, StringBuffer toAppendTo, FieldPosition fieldPosition)
/*    */   {
/* 29 */     toAppendTo.append(ISO8601Utils.format(date));
/* 30 */     return toAppendTo;
/*    */   }
/*    */   
/*    */   public Date parse(String source, ParsePosition pos)
/*    */   {
/*    */     try {
/* 36 */       return ISO8601Utils.parse(source, pos);
/*    */     }
/*    */     catch (ParseException e) {}
/* 39 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Date parse(String source)
/*    */     throws ParseException
/*    */   {
/* 47 */     return ISO8601Utils.parse(source, new ParsePosition(0));
/*    */   }
/*    */   
/*    */   public Object clone()
/*    */   {
/* 52 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\util\ISO8601DateFormat.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */