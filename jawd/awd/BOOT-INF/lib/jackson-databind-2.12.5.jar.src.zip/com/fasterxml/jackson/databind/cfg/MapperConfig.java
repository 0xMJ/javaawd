/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties.Value;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude.Value;
/*     */ import com.fasterxml.jackson.annotation.JsonIncludeProperties.Value;
/*     */ import com.fasterxml.jackson.annotation.JsonSetter.Value;
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.io.SerializedString;
/*     */ import com.fasterxml.jackson.core.type.TypeReference;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.introspect.AccessorNamingStrategy.Provider;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*     */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector.MixInResolver;
/*     */ import com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
/*     */ import com.fasterxml.jackson.databind.jsontype.DefaultBaseTypeLimitingValidator;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.jsontype.impl.LaissezFaireSubTypeValidator;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Serializable;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MapperConfig<T extends MapperConfig<T>>
/*     */   implements ClassIntrospector.MixInResolver, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*  49 */   protected static final JsonInclude.Value EMPTY_INCLUDE = ;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  54 */   protected static final JsonFormat.Value EMPTY_FORMAT = JsonFormat.Value.empty();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final int _mapperFeatures;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final BaseSettings _base;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MapperConfig(BaseSettings base, int mapperFeatures)
/*     */   {
/*  74 */     this._base = base;
/*  75 */     this._mapperFeatures = mapperFeatures;
/*     */   }
/*     */   
/*     */   protected MapperConfig(MapperConfig<T> src, int mapperFeatures)
/*     */   {
/*  80 */     this._base = src._base;
/*  81 */     this._mapperFeatures = mapperFeatures;
/*     */   }
/*     */   
/*     */   protected MapperConfig(MapperConfig<T> src, BaseSettings base)
/*     */   {
/*  86 */     this._base = base;
/*  87 */     this._mapperFeatures = src._mapperFeatures;
/*     */   }
/*     */   
/*     */   protected MapperConfig(MapperConfig<T> src)
/*     */   {
/*  92 */     this._base = src._base;
/*  93 */     this._mapperFeatures = src._mapperFeatures;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <F extends Enum<F>,  extends ConfigFeature> int collectFeatureDefaults(Class<F> enumClass)
/*     */   {
/* 102 */     int flags = 0;
/* 103 */     for (F value : (Enum[])enumClass.getEnumConstants()) {
/* 104 */       if (((ConfigFeature)value).enabledByDefault()) {
/* 105 */         flags |= ((ConfigFeature)value).getMask();
/*     */       }
/*     */     }
/* 108 */     return flags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract T with(MapperFeature... paramVarArgs);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract T without(MapperFeature... paramVarArgs);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract T with(MapperFeature paramMapperFeature, boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isEnabled(MapperFeature f)
/*     */   {
/* 145 */     return f.enabledIn(this._mapperFeatures);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean hasMapperFeatures(int featureMask)
/*     */   {
/* 155 */     return (this._mapperFeatures & featureMask) == featureMask;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isAnnotationProcessingEnabled()
/*     */   {
/* 165 */     return isEnabled(MapperFeature.USE_ANNOTATIONS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean canOverrideAccessModifiers()
/*     */   {
/* 180 */     return isEnabled(MapperFeature.CAN_OVERRIDE_ACCESS_MODIFIERS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean shouldSortPropertiesAlphabetically()
/*     */   {
/* 188 */     return isEnabled(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean useRootWrapping();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SerializableString compileString(String src)
/*     */   {
/* 220 */     return new SerializedString(src);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassIntrospector getClassIntrospector()
/*     */   {
/* 230 */     return this._base.getClassIntrospector();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationIntrospector getAnnotationIntrospector()
/*     */   {
/* 240 */     if (isEnabled(MapperFeature.USE_ANNOTATIONS)) {
/* 241 */       return this._base.getAnnotationIntrospector();
/*     */     }
/* 243 */     return NopAnnotationIntrospector.instance;
/*     */   }
/*     */   
/*     */   public final PropertyNamingStrategy getPropertyNamingStrategy() {
/* 247 */     return this._base.getPropertyNamingStrategy();
/*     */   }
/*     */   
/*     */   public final AccessorNamingStrategy.Provider getAccessorNaming()
/*     */   {
/* 252 */     return this._base.getAccessorNaming();
/*     */   }
/*     */   
/*     */   public final HandlerInstantiator getHandlerInstantiator() {
/* 256 */     return this._base.getHandlerInstantiator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final TypeResolverBuilder<?> getDefaultTyper(JavaType baseType)
/*     */   {
/* 272 */     return this._base.getTypeResolverBuilder();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract SubtypeResolver getSubtypeResolver();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PolymorphicTypeValidator getPolymorphicTypeValidator()
/*     */   {
/* 289 */     PolymorphicTypeValidator ptv = this._base.getPolymorphicTypeValidator();
/*     */     
/* 291 */     if ((ptv == LaissezFaireSubTypeValidator.instance) && 
/* 292 */       (isEnabled(MapperFeature.BLOCK_UNSAFE_POLYMORPHIC_BASE_TYPES))) {
/* 293 */       ptv = new DefaultBaseTypeLimitingValidator();
/*     */     }
/*     */     
/* 296 */     return ptv;
/*     */   }
/*     */   
/*     */   public final TypeFactory getTypeFactory() {
/* 300 */     return this._base.getTypeFactory();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JavaType constructType(Class<?> cls)
/*     */   {
/* 312 */     return getTypeFactory().constructType(cls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JavaType constructType(TypeReference<?> valueTypeRef)
/*     */   {
/* 324 */     return getTypeFactory().constructType(valueTypeRef.getType());
/*     */   }
/*     */   
/*     */   public JavaType constructSpecializedType(JavaType baseType, Class<?> subclass)
/*     */   {
/* 329 */     return getTypeFactory().constructSpecializedType(baseType, subclass, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanDescription introspectClassAnnotations(Class<?> cls)
/*     */   {
/* 343 */     return introspectClassAnnotations(constructType(cls));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanDescription introspectClassAnnotations(JavaType type)
/*     */   {
/* 351 */     return getClassIntrospector().forClassAnnotations(this, type, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanDescription introspectDirectClassAnnotations(Class<?> cls)
/*     */   {
/* 360 */     return introspectDirectClassAnnotations(constructType(cls));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final BeanDescription introspectDirectClassAnnotations(JavaType type)
/*     */   {
/* 369 */     return getClassIntrospector().forDirectClassAnnotations(this, type, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ConfigOverride findConfigOverride(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ConfigOverride getConfigOverride(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JsonInclude.Value getDefaultPropertyInclusion();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JsonInclude.Value getDefaultPropertyInclusion(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonInclude.Value getDefaultPropertyInclusion(Class<?> baseType, JsonInclude.Value defaultIncl)
/*     */   {
/* 435 */     JsonInclude.Value v = getConfigOverride(baseType).getInclude();
/* 436 */     if (v != null) {
/* 437 */       return v;
/*     */     }
/* 439 */     return defaultIncl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JsonInclude.Value getDefaultInclusion(Class<?> paramClass1, Class<?> paramClass2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonInclude.Value getDefaultInclusion(Class<?> baseType, Class<?> propertyType, JsonInclude.Value defaultIncl)
/*     */   {
/* 472 */     JsonInclude.Value baseOverride = getConfigOverride(baseType).getInclude();
/* 473 */     JsonInclude.Value propOverride = getConfigOverride(propertyType).getIncludeAsProperty();
/*     */     
/* 475 */     JsonInclude.Value result = JsonInclude.Value.mergeAll(new JsonInclude.Value[] { defaultIncl, baseOverride, propOverride });
/* 476 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JsonFormat.Value getDefaultPropertyFormat(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JsonIgnoreProperties.Value getDefaultPropertyIgnorals(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JsonIgnoreProperties.Value getDefaultPropertyIgnorals(Class<?> paramClass, AnnotatedClass paramAnnotatedClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JsonIncludeProperties.Value getDefaultPropertyInclusions(Class<?> paramClass, AnnotatedClass paramAnnotatedClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract VisibilityChecker<?> getDefaultVisibilityChecker();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract VisibilityChecker<?> getDefaultVisibilityChecker(Class<?> paramClass, AnnotatedClass paramAnnotatedClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JsonSetter.Value getDefaultSetterInfo();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Boolean getDefaultMergeable();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Boolean getDefaultMergeable(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final DateFormat getDateFormat()
/*     */   {
/* 596 */     return this._base.getDateFormat();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final Locale getLocale()
/*     */   {
/* 603 */     return this._base.getLocale();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final TimeZone getTimeZone()
/*     */   {
/* 610 */     return this._base.getTimeZone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasExplicitTimeZone()
/*     */   {
/* 624 */     return this._base.hasExplicitTimeZone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Class<?> getActiveView();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Base64Variant getBase64Variant()
/*     */   {
/* 640 */     return this._base.getBase64Variant();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ContextAttributes getAttributes();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract PropertyName findRootName(JavaType paramJavaType);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract PropertyName findRootName(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeResolverBuilder<?> typeResolverBuilderInstance(Annotated annotated, Class<? extends TypeResolverBuilder<?>> builderClass)
/*     */   {
/* 675 */     HandlerInstantiator hi = getHandlerInstantiator();
/* 676 */     if (hi != null) {
/* 677 */       TypeResolverBuilder<?> builder = hi.typeResolverBuilderInstance(this, annotated, builderClass);
/* 678 */       if (builder != null) {
/* 679 */         return builder;
/*     */       }
/*     */     }
/* 682 */     return (TypeResolverBuilder)ClassUtil.createInstance(builderClass, canOverrideAccessModifiers());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeIdResolver typeIdResolverInstance(Annotated annotated, Class<? extends TypeIdResolver> resolverClass)
/*     */   {
/* 692 */     HandlerInstantiator hi = getHandlerInstantiator();
/* 693 */     if (hi != null) {
/* 694 */       TypeIdResolver builder = hi.typeIdResolverInstance(this, annotated, resolverClass);
/* 695 */       if (builder != null) {
/* 696 */         return builder;
/*     */       }
/*     */     }
/* 699 */     return (TypeIdResolver)ClassUtil.createInstance(resolverClass, canOverrideAccessModifiers());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\cfg\MapperConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */