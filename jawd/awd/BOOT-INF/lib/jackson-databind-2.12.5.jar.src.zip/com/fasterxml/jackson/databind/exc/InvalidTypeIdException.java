/*    */ package com.fasterxml.jackson.databind.exc;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidTypeIdException
/*    */   extends MismatchedInputException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final JavaType _baseType;
/*    */   protected final String _typeId;
/*    */   
/*    */   public InvalidTypeIdException(JsonParser p, String msg, JavaType baseType, String typeId)
/*    */   {
/* 36 */     super(p, msg);
/* 37 */     this._baseType = baseType;
/* 38 */     this._typeId = typeId;
/*    */   }
/*    */   
/*    */   public static InvalidTypeIdException from(JsonParser p, String msg, JavaType baseType, String typeId)
/*    */   {
/* 43 */     return new InvalidTypeIdException(p, msg, baseType, typeId);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 52 */   public JavaType getBaseType() { return this._baseType; }
/* 53 */   public String getTypeId() { return this._typeId; }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\exc\InvalidTypeIdException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */