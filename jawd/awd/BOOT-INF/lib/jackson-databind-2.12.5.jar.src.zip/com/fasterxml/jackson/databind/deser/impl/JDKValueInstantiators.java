/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator.Base;
/*     */ import com.fasterxml.jackson.databind.deser.std.JsonLocationInstantiator;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JDKValueInstantiators
/*     */ {
/*     */   public static ValueInstantiator findStdValueInstantiator(DeserializationConfig config, Class<?> raw)
/*     */   {
/*  29 */     if (raw == JsonLocation.class) {
/*  30 */       return new JsonLocationInstantiator();
/*     */     }
/*     */     
/*     */ 
/*  34 */     if (Collection.class.isAssignableFrom(raw)) {
/*  35 */       if (raw == ArrayList.class) {
/*  36 */         return ArrayListInstantiator.INSTANCE;
/*     */       }
/*  38 */       if (Collections.EMPTY_SET.getClass() == raw) {
/*  39 */         return new ConstantValueInstantiator(Collections.EMPTY_SET);
/*     */       }
/*  41 */       if (Collections.EMPTY_LIST.getClass() == raw) {
/*  42 */         return new ConstantValueInstantiator(Collections.EMPTY_LIST);
/*     */       }
/*  44 */     } else if (Map.class.isAssignableFrom(raw)) {
/*  45 */       if (raw == LinkedHashMap.class) {
/*  46 */         return LinkedHashMapInstantiator.INSTANCE;
/*     */       }
/*  48 */       if (raw == HashMap.class) {
/*  49 */         return HashMapInstantiator.INSTANCE;
/*     */       }
/*  51 */       if (Collections.EMPTY_MAP.getClass() == raw) {
/*  52 */         return new ConstantValueInstantiator(Collections.EMPTY_MAP);
/*     */       }
/*     */     }
/*  55 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ArrayListInstantiator
/*     */     extends ValueInstantiator.Base
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*  64 */     public static final ArrayListInstantiator INSTANCE = new ArrayListInstantiator();
/*     */     
/*  66 */     public ArrayListInstantiator() { super(); }
/*     */     
/*     */     public boolean canInstantiate()
/*     */     {
/*  70 */       return true;
/*     */     }
/*     */     
/*  73 */     public boolean canCreateUsingDefault() { return true; }
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException
/*     */     {
/*  77 */       return new ArrayList();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class HashMapInstantiator
/*     */     extends ValueInstantiator.Base
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*  87 */     public static final HashMapInstantiator INSTANCE = new HashMapInstantiator();
/*     */     
/*     */     public HashMapInstantiator() {
/*  90 */       super();
/*     */     }
/*     */     
/*     */     public boolean canInstantiate() {
/*  94 */       return true;
/*     */     }
/*     */     
/*  97 */     public boolean canCreateUsingDefault() { return true; }
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException
/*     */     {
/* 101 */       return new HashMap();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class LinkedHashMapInstantiator
/*     */     extends ValueInstantiator.Base
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/* 111 */     public static final LinkedHashMapInstantiator INSTANCE = new LinkedHashMapInstantiator();
/*     */     
/*     */     public LinkedHashMapInstantiator() {
/* 114 */       super();
/*     */     }
/*     */     
/*     */     public boolean canInstantiate() {
/* 118 */       return true;
/*     */     }
/*     */     
/* 121 */     public boolean canCreateUsingDefault() { return true; }
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException
/*     */     {
/* 125 */       return new LinkedHashMap();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ConstantValueInstantiator
/*     */     extends ValueInstantiator.Base
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     protected final Object _value;
/*     */     
/*     */     public ConstantValueInstantiator(Object value)
/*     */     {
/* 138 */       super();
/* 139 */       this._value = value;
/*     */     }
/*     */     
/*     */     public boolean canInstantiate() {
/* 143 */       return true;
/*     */     }
/*     */     
/* 146 */     public boolean canCreateUsingDefault() { return true; }
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException
/*     */     {
/* 150 */       return this._value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\impl\JDKValueInstantiators.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */