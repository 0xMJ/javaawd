package com.fasterxml.jackson.databind.util;

public abstract interface LookupCache<K, V>
{
  public abstract int size();
  
  public abstract V get(Object paramObject);
  
  public abstract V put(K paramK, V paramV);
  
  public abstract V putIfAbsent(K paramK, V paramV);
  
  public abstract void clear();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\util\LookupCache.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */