package com.fasterxml.jackson.databind.jsonFormatVisitors;

public abstract interface JsonNullFormatVisitor
{
  public static class Base
    implements JsonNullFormatVisitor
  {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\jsonFormatVisitors\JsonNullFormatVisitor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */