/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoercionConfigs
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  19 */   private static final int TARGET_TYPE_COUNT = LogicalType.values().length;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CoercionAction _defaultAction;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final MutableCoercionConfig _defaultCoercions;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MutableCoercionConfig[] _perTypeCoercions;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map<Class<?>, MutableCoercionConfig> _perClassCoercions;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CoercionConfigs()
/*     */   {
/*  49 */     this(CoercionAction.TryConvert, new MutableCoercionConfig(), null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CoercionConfigs(CoercionAction defaultAction, MutableCoercionConfig defaultCoercions, MutableCoercionConfig[] perTypeCoercions, Map<Class<?>, MutableCoercionConfig> perClassCoercions)
/*     */   {
/*  58 */     this._defaultCoercions = defaultCoercions;
/*  59 */     this._defaultAction = defaultAction;
/*  60 */     this._perTypeCoercions = perTypeCoercions;
/*  61 */     this._perClassCoercions = perClassCoercions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CoercionConfigs copy()
/*     */   {
/*     */     MutableCoercionConfig[] newPerType;
/*     */     
/*     */     MutableCoercionConfig[] newPerType;
/*     */     
/*     */     int i;
/*     */     
/*  74 */     if (this._perTypeCoercions == null) {
/*  75 */       newPerType = null;
/*     */     } else {
/*  77 */       int size = this._perTypeCoercions.length;
/*  78 */       newPerType = new MutableCoercionConfig[size];
/*  79 */       for (i = 0; i < size; i++)
/*  80 */         newPerType[i] = _copy(this._perTypeCoercions[i]);
/*     */     }
/*     */     Map<Class<?>, MutableCoercionConfig> newPerClass;
/*     */     Map<Class<?>, MutableCoercionConfig> newPerClass;
/*  84 */     if (this._perClassCoercions == null) {
/*  85 */       newPerClass = null;
/*     */     } else {
/*  87 */       newPerClass = new HashMap();
/*  88 */       for (Map.Entry<Class<?>, MutableCoercionConfig> entry : this._perClassCoercions.entrySet()) {
/*  89 */         newPerClass.put(entry.getKey(), ((MutableCoercionConfig)entry.getValue()).copy());
/*     */       }
/*     */     }
/*  92 */     return new CoercionConfigs(this._defaultAction, this._defaultCoercions.copy(), newPerType, newPerClass);
/*     */   }
/*     */   
/*     */   private static MutableCoercionConfig _copy(MutableCoercionConfig src)
/*     */   {
/*  97 */     if (src == null) {
/*  98 */       return null;
/*     */     }
/* 100 */     return src.copy();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MutableCoercionConfig defaultCoercions()
/*     */   {
/* 110 */     return this._defaultCoercions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MutableCoercionConfig findOrCreateCoercion(LogicalType type)
/*     */   {
/* 120 */     if (this._perTypeCoercions == null) {
/* 121 */       this._perTypeCoercions = new MutableCoercionConfig[TARGET_TYPE_COUNT];
/*     */     }
/* 123 */     MutableCoercionConfig config = this._perTypeCoercions[type.ordinal()];
/* 124 */     if (config == null) {
/* 125 */       this._perTypeCoercions[type.ordinal()] = (config = new MutableCoercionConfig());
/*     */     }
/* 127 */     return config;
/*     */   }
/*     */   
/*     */   public MutableCoercionConfig findOrCreateCoercion(Class<?> type) {
/* 131 */     if (this._perClassCoercions == null) {
/* 132 */       this._perClassCoercions = new HashMap();
/*     */     }
/* 134 */     MutableCoercionConfig config = (MutableCoercionConfig)this._perClassCoercions.get(type);
/* 135 */     if (config == null) {
/* 136 */       config = new MutableCoercionConfig();
/* 137 */       this._perClassCoercions.put(type, config);
/*     */     }
/* 139 */     return config;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CoercionAction findCoercion(DeserializationConfig config, LogicalType targetType, Class<?> targetClass, CoercionInputShape inputShape)
/*     */   {
/* 166 */     if ((this._perClassCoercions != null) && (targetClass != null)) {
/* 167 */       MutableCoercionConfig cc = (MutableCoercionConfig)this._perClassCoercions.get(targetClass);
/* 168 */       if (cc != null) {
/* 169 */         CoercionAction act = cc.findAction(inputShape);
/* 170 */         if (act != null) {
/* 171 */           return act;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 177 */     if ((this._perTypeCoercions != null) && (targetType != null)) {
/* 178 */       MutableCoercionConfig cc = this._perTypeCoercions[targetType.ordinal()];
/* 179 */       if (cc != null) {
/* 180 */         CoercionAction act = cc.findAction(inputShape);
/* 181 */         if (act != null) {
/* 182 */           return act;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 188 */     CoercionAction act = this._defaultCoercions.findAction(inputShape);
/* 189 */     if (act != null) {
/* 190 */       return act;
/*     */     }
/*     */     
/*     */ 
/* 194 */     switch (inputShape)
/*     */     {
/*     */     case EmptyArray: 
/* 197 */       return config.isEnabled(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT) ? CoercionAction.AsNull : CoercionAction.Fail;
/*     */     
/*     */     case Float: 
/* 200 */       if (targetType == LogicalType.Integer)
/*     */       {
/* 202 */         return config.isEnabled(DeserializationFeature.ACCEPT_FLOAT_AS_INT) ? CoercionAction.TryConvert : CoercionAction.Fail;
/*     */       }
/*     */       
/*     */       break;
/*     */     case Integer: 
/* 207 */       if ((targetType == LogicalType.Enum) && 
/* 208 */         (config.isEnabled(DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS))) {
/* 209 */         return CoercionAction.Fail;
/*     */       }
/*     */       
/*     */ 
/*     */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 218 */     boolean baseScalar = (targetType == LogicalType.Float) || (targetType == LogicalType.Integer) || (targetType == LogicalType.Boolean) || (targetType == LogicalType.DateTime);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 223 */     if (baseScalar)
/*     */     {
/* 225 */       if (!config.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 226 */         return CoercionAction.Fail;
/*     */       }
/*     */     }
/*     */     
/* 230 */     if (inputShape == CoercionInputShape.EmptyString)
/*     */     {
/*     */ 
/* 233 */       if ((baseScalar) || 
/*     */       
/* 235 */         (config.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT))) {
/* 236 */         return CoercionAction.AsNull;
/*     */       }
/*     */       
/*     */ 
/* 240 */       if (targetType == LogicalType.OtherScalar) {
/* 241 */         return CoercionAction.TryConvert;
/*     */       }
/*     */       
/* 244 */       return CoercionAction.Fail;
/*     */     }
/*     */     
/*     */ 
/* 248 */     return this._defaultAction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CoercionAction findCoercionFromBlankString(DeserializationConfig config, LogicalType targetType, Class<?> targetClass, CoercionAction actionIfBlankNotAllowed)
/*     */   {
/* 271 */     Boolean acceptBlankAsEmpty = null;
/* 272 */     CoercionAction action = null;
/*     */     
/*     */ 
/* 275 */     if ((this._perClassCoercions != null) && (targetClass != null)) {
/* 276 */       MutableCoercionConfig cc = (MutableCoercionConfig)this._perClassCoercions.get(targetClass);
/* 277 */       if (cc != null) {
/* 278 */         acceptBlankAsEmpty = cc.getAcceptBlankAsEmpty();
/* 279 */         action = cc.findAction(CoercionInputShape.EmptyString);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 284 */     if ((this._perTypeCoercions != null) && (targetType != null)) {
/* 285 */       MutableCoercionConfig cc = this._perTypeCoercions[targetType.ordinal()];
/* 286 */       if (cc != null) {
/* 287 */         if (acceptBlankAsEmpty == null) {
/* 288 */           acceptBlankAsEmpty = cc.getAcceptBlankAsEmpty();
/*     */         }
/* 290 */         if (action == null) {
/* 291 */           action = cc.findAction(CoercionInputShape.EmptyString);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 297 */     if (acceptBlankAsEmpty == null) {
/* 298 */       acceptBlankAsEmpty = this._defaultCoercions.getAcceptBlankAsEmpty();
/*     */     }
/* 300 */     if (action == null) {
/* 301 */       action = this._defaultCoercions.findAction(CoercionInputShape.EmptyString);
/*     */     }
/*     */     
/*     */ 
/* 305 */     if (!Boolean.TRUE.equals(acceptBlankAsEmpty)) {
/* 306 */       return actionIfBlankNotAllowed;
/*     */     }
/*     */     
/*     */ 
/* 310 */     if (action != null) {
/* 311 */       return action;
/*     */     }
/*     */     
/* 314 */     return config.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT) ? CoercionAction.AsNull : CoercionAction.Fail;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\cfg\CoercionConfigs.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */