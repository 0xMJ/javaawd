/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.core.type.ResolvedType;
/*     */ import com.fasterxml.jackson.databind.type.TypeBindings;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaType
/*     */   extends ResolvedType
/*     */   implements Serializable, Type
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Class<?> _class;
/*     */   protected final int _hash;
/*     */   protected final Object _valueHandler;
/*     */   protected final Object _typeHandler;
/*     */   protected final boolean _asStatic;
/*     */   
/*     */   protected JavaType(Class<?> raw, int additionalHash, Object valueHandler, Object typeHandler, boolean asStatic)
/*     */   {
/*  80 */     this._class = raw;
/*  81 */     this._hash = (raw.getName().hashCode() + additionalHash);
/*  82 */     this._valueHandler = valueHandler;
/*  83 */     this._typeHandler = typeHandler;
/*  84 */     this._asStatic = asStatic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JavaType(JavaType base)
/*     */   {
/*  94 */     this._class = base._class;
/*  95 */     this._hash = base._hash;
/*  96 */     this._valueHandler = base._valueHandler;
/*  97 */     this._typeHandler = base._typeHandler;
/*  98 */     this._asStatic = base._asStatic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JavaType withTypeHandler(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JavaType withContentTypeHandler(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JavaType withValueHandler(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JavaType withContentValueHandler(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JavaType withHandlersFrom(JavaType src)
/*     */   {
/* 142 */     JavaType type = this;
/* 143 */     Object h = src.getTypeHandler();
/* 144 */     if (h != this._typeHandler) {
/* 145 */       type = type.withTypeHandler(h);
/*     */     }
/* 147 */     h = src.getValueHandler();
/* 148 */     if (h != this._valueHandler) {
/* 149 */       type = type.withValueHandler(h);
/*     */     }
/* 151 */     return type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JavaType withContentType(JavaType paramJavaType);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JavaType withStaticTyping();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JavaType refine(Class<?> paramClass, TypeBindings paramTypeBindings, JavaType paramJavaType, JavaType[] paramArrayOfJavaType);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public JavaType forcedNarrowBy(Class<?> subclass)
/*     */   {
/* 212 */     if (subclass == this._class) {
/* 213 */       return this;
/*     */     }
/* 215 */     return _narrow(subclass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected abstract JavaType _narrow(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */   public final Class<?> getRawClass()
/*     */   {
/* 228 */     return this._class;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean hasRawClass(Class<?> clz)
/*     */   {
/* 236 */     return this._class == clz;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasContentType()
/*     */   {
/* 246 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isTypeOrSubTypeOf(Class<?> clz)
/*     */   {
/* 253 */     return (this._class == clz) || (clz.isAssignableFrom(this._class));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isTypeOrSuperTypeOf(Class<?> clz)
/*     */   {
/* 260 */     return (this._class == clz) || (this._class.isAssignableFrom(clz));
/*     */   }
/*     */   
/*     */   public boolean isAbstract()
/*     */   {
/* 265 */     return Modifier.isAbstract(this._class.getModifiers());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isConcrete()
/*     */   {
/* 275 */     int mod = this._class.getModifiers();
/* 276 */     if ((mod & 0x600) == 0) {
/* 277 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 282 */     return this._class.isPrimitive();
/*     */   }
/*     */   
/*     */   public boolean isThrowable() {
/* 286 */     return Throwable.class.isAssignableFrom(this._class);
/*     */   }
/*     */   
/* 289 */   public boolean isArrayType() { return false; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isEnumType()
/*     */   {
/* 302 */     return ClassUtil.isEnumType(this._class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isEnumImplType()
/*     */   {
/* 312 */     return (ClassUtil.isEnumType(this._class)) && (this._class != Enum.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isRecordType()
/*     */   {
/* 319 */     return ClassUtil.isRecordType(this._class);
/*     */   }
/*     */   
/*     */   public final boolean isInterface() {
/* 323 */     return this._class.isInterface();
/*     */   }
/*     */   
/* 326 */   public final boolean isPrimitive() { return this._class.isPrimitive(); }
/*     */   
/*     */   public final boolean isFinal() {
/* 329 */     return Modifier.isFinal(this._class.getModifiers());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean isContainerType();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCollectionLikeType()
/*     */   {
/* 344 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMapLikeType()
/*     */   {
/* 352 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isJavaLangObject()
/*     */   {
/* 363 */     return this._class == Object.class;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean useStaticType()
/*     */   {
/* 373 */     return this._asStatic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasGenericTypes()
/*     */   {
/* 382 */     return containedTypeCount() > 0;
/*     */   }
/*     */   
/* 385 */   public JavaType getKeyType() { return null; }
/*     */   
/*     */   public JavaType getContentType() {
/* 388 */     return null;
/*     */   }
/*     */   
/* 391 */   public JavaType getReferencedType() { return null; }
/*     */   
/*     */ 
/*     */   public abstract int containedTypeCount();
/*     */   
/*     */ 
/*     */   public abstract JavaType containedType(int paramInt);
/*     */   
/*     */ 
/*     */   @Deprecated
/*     */   public abstract String containedTypeName(int paramInt);
/*     */   
/*     */   @Deprecated
/*     */   public Class<?> getParameterSource()
/*     */   {
/* 406 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JavaType containedTypeOrUnknown(int index)
/*     */   {
/* 432 */     JavaType t = containedType(index);
/* 433 */     return t == null ? TypeFactory.unknownType() : t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract TypeBindings getBindings();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JavaType findSuperType(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JavaType getSuperClass();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract List<JavaType> getInterfaces();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JavaType[] findTypeParameters(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T getValueHandler()
/*     */   {
/* 486 */     return (T)this._valueHandler;
/*     */   }
/*     */   
/*     */ 
/*     */   public <T> T getTypeHandler()
/*     */   {
/* 492 */     return (T)this._typeHandler;
/*     */   }
/*     */   
/*     */   public Object getContentValueHandler()
/*     */   {
/* 497 */     return null;
/*     */   }
/*     */   
/*     */   public Object getContentTypeHandler()
/*     */   {
/* 502 */     return null;
/*     */   }
/*     */   
/*     */   public boolean hasValueHandler()
/*     */   {
/* 507 */     return this._valueHandler != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasHandlers()
/*     */   {
/* 518 */     return (this._typeHandler != null) || (this._valueHandler != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getGenericSignature()
/*     */   {
/* 538 */     StringBuilder sb = new StringBuilder(40);
/* 539 */     getGenericSignature(sb);
/* 540 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract StringBuilder getGenericSignature(StringBuilder paramStringBuilder);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getErasedSignature()
/*     */   {
/* 559 */     StringBuilder sb = new StringBuilder(40);
/* 560 */     getErasedSignature(sb);
/* 561 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract StringBuilder getErasedSignature(StringBuilder paramStringBuilder);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String toString();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean equals(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int hashCode()
/*     */   {
/* 590 */     return this._hash;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\JavaType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */