/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Feature;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder.Value;
/*     */ import com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ValueInjector;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.util.Annotations;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanDeserializerBuilder
/*     */ {
/*     */   protected final DeserializationConfig _config;
/*     */   protected final DeserializationContext _context;
/*     */   protected final BeanDescription _beanDesc;
/*  57 */   protected final Map<String, SettableBeanProperty> _properties = new LinkedHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<ValueInjector> _injectables;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HashMap<String, SettableBeanProperty> _backRefProperties;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HashSet<String> _ignorableProps;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HashSet<String> _includableProps;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ValueInstantiator _valueInstantiator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ObjectIdReader _objectIdReader;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SettableAnyProperty _anySetter;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean _ignoreAllUnknown;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AnnotatedMethod _buildMethod;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonPOJOBuilder.Value _builderConfig;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanDeserializerBuilder(BeanDescription beanDesc, DeserializationContext ctxt)
/*     */   {
/* 126 */     this._beanDesc = beanDesc;
/* 127 */     this._context = ctxt;
/* 128 */     this._config = ctxt.getConfig();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BeanDeserializerBuilder(BeanDeserializerBuilder src)
/*     */   {
/* 137 */     this._beanDesc = src._beanDesc;
/* 138 */     this._context = src._context;
/* 139 */     this._config = src._config;
/*     */     
/*     */ 
/* 142 */     this._properties.putAll(src._properties);
/* 143 */     this._injectables = _copy(src._injectables);
/* 144 */     this._backRefProperties = _copy(src._backRefProperties);
/*     */     
/* 146 */     this._ignorableProps = src._ignorableProps;
/* 147 */     this._includableProps = src._includableProps;
/* 148 */     this._valueInstantiator = src._valueInstantiator;
/* 149 */     this._objectIdReader = src._objectIdReader;
/*     */     
/* 151 */     this._anySetter = src._anySetter;
/* 152 */     this._ignoreAllUnknown = src._ignoreAllUnknown;
/*     */     
/* 154 */     this._buildMethod = src._buildMethod;
/* 155 */     this._builderConfig = src._builderConfig;
/*     */   }
/*     */   
/*     */   private static HashMap<String, SettableBeanProperty> _copy(HashMap<String, SettableBeanProperty> src) {
/* 159 */     return src == null ? null : new HashMap(src);
/*     */   }
/*     */   
/*     */   private static <T> List<T> _copy(List<T> src)
/*     */   {
/* 164 */     return src == null ? null : new ArrayList(src);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addOrReplaceProperty(SettableBeanProperty prop, boolean allowOverride)
/*     */   {
/* 177 */     this._properties.put(prop.getName(), prop);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addProperty(SettableBeanProperty prop)
/*     */   {
/* 187 */     SettableBeanProperty old = (SettableBeanProperty)this._properties.put(prop.getName(), prop);
/* 188 */     if ((old != null) && (old != prop)) {
/* 189 */       throw new IllegalArgumentException("Duplicate property '" + prop.getName() + "' for " + this._beanDesc.getType());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addBackReferenceProperty(String referenceName, SettableBeanProperty prop)
/*     */   {
/* 200 */     if (this._backRefProperties == null) {
/* 201 */       this._backRefProperties = new HashMap(4);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 206 */     if (this._config.canOverrideAccessModifiers()) {
/* 207 */       prop.fixAccess(this._config);
/*     */     }
/* 209 */     this._backRefProperties.put(referenceName, prop);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addInjectable(PropertyName propName, JavaType propType, Annotations contextAnnotations, AnnotatedMember member, Object valueId)
/*     */   {
/* 225 */     if (this._injectables == null) {
/* 226 */       this._injectables = new ArrayList();
/*     */     }
/* 228 */     if (this._config.canOverrideAccessModifiers()) {
/* 229 */       member.fixAccess(this._config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */     }
/* 231 */     this._injectables.add(new ValueInjector(propName, propType, member, valueId));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIgnorable(String propName)
/*     */   {
/* 240 */     if (this._ignorableProps == null) {
/* 241 */       this._ignorableProps = new HashSet();
/*     */     }
/* 243 */     this._ignorableProps.add(propName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addIncludable(String propName)
/*     */   {
/* 253 */     if (this._includableProps == null) {
/* 254 */       this._includableProps = new HashSet();
/*     */     }
/* 256 */     this._includableProps.add(propName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCreatorProperty(SettableBeanProperty prop)
/*     */   {
/* 271 */     addProperty(prop);
/*     */   }
/*     */   
/*     */   public void setAnySetter(SettableAnyProperty s)
/*     */   {
/* 276 */     if ((this._anySetter != null) && (s != null)) {
/* 277 */       throw new IllegalStateException("_anySetter already set to non-null");
/*     */     }
/* 279 */     this._anySetter = s;
/*     */   }
/*     */   
/*     */   public void setIgnoreUnknownProperties(boolean ignore) {
/* 283 */     this._ignoreAllUnknown = ignore;
/*     */   }
/*     */   
/*     */   public void setValueInstantiator(ValueInstantiator inst) {
/* 287 */     this._valueInstantiator = inst;
/*     */   }
/*     */   
/*     */   public void setObjectIdReader(ObjectIdReader r) {
/* 291 */     this._objectIdReader = r;
/*     */   }
/*     */   
/*     */   public void setPOJOBuilder(AnnotatedMethod buildMethod, JsonPOJOBuilder.Value config) {
/* 295 */     this._buildMethod = buildMethod;
/* 296 */     this._builderConfig = config;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<SettableBeanProperty> getProperties()
/*     */   {
/* 314 */     return this._properties.values().iterator();
/*     */   }
/*     */   
/*     */   public SettableBeanProperty findProperty(PropertyName propertyName) {
/* 318 */     return (SettableBeanProperty)this._properties.get(propertyName.getSimpleName());
/*     */   }
/*     */   
/*     */   public boolean hasProperty(PropertyName propertyName) {
/* 322 */     return findProperty(propertyName) != null;
/*     */   }
/*     */   
/*     */   public SettableBeanProperty removeProperty(PropertyName name) {
/* 326 */     return (SettableBeanProperty)this._properties.remove(name.getSimpleName());
/*     */   }
/*     */   
/*     */   public SettableAnyProperty getAnySetter() {
/* 330 */     return this._anySetter;
/*     */   }
/*     */   
/*     */   public ValueInstantiator getValueInstantiator() {
/* 334 */     return this._valueInstantiator;
/*     */   }
/*     */   
/*     */   public List<ValueInjector> getInjectables() {
/* 338 */     return this._injectables;
/*     */   }
/*     */   
/*     */   public ObjectIdReader getObjectIdReader() {
/* 342 */     return this._objectIdReader;
/*     */   }
/*     */   
/*     */   public AnnotatedMethod getBuildMethod() {
/* 346 */     return this._buildMethod;
/*     */   }
/*     */   
/*     */   public JsonPOJOBuilder.Value getBuilderConfig() {
/* 350 */     return this._builderConfig;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasIgnorable(String name)
/*     */   {
/* 357 */     return IgnorePropertiesUtil.shouldIgnore(name, this._ignorableProps, this._includableProps);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonDeserializer<?> build()
/*     */   {
/* 372 */     Collection<SettableBeanProperty> props = this._properties.values();
/* 373 */     _fixAccess(props);
/* 374 */     BeanPropertyMap propertyMap = BeanPropertyMap.construct(this._config, props, 
/* 375 */       _collectAliases(props), 
/* 376 */       _findCaseInsensitivity());
/* 377 */     propertyMap.assignIndexes();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 382 */     boolean anyViews = !this._config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION);
/* 383 */     if (!anyViews) {
/* 384 */       for (SettableBeanProperty prop : props) {
/* 385 */         if (prop.hasViews()) {
/* 386 */           anyViews = true;
/* 387 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 393 */     if (this._objectIdReader != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 398 */       ObjectIdValueProperty prop = new ObjectIdValueProperty(this._objectIdReader, PropertyMetadata.STD_REQUIRED);
/* 399 */       propertyMap = propertyMap.withProperty(prop);
/*     */     }
/*     */     
/* 402 */     return new BeanDeserializer(this, this._beanDesc, propertyMap, this._backRefProperties, this._ignorableProps, this._ignoreAllUnknown, this._includableProps, anyViews);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractDeserializer buildAbstract()
/*     */   {
/* 415 */     return new AbstractDeserializer(this, this._beanDesc, this._backRefProperties, this._properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonDeserializer<?> buildBuilderBased(JavaType valueType, String expBuildMethodName)
/*     */     throws JsonMappingException
/*     */   {
/* 426 */     if (this._buildMethod == null)
/*     */     {
/* 428 */       if (!expBuildMethodName.isEmpty()) {
/* 429 */         this._context.reportBadDefinition(this._beanDesc.getType(), 
/* 430 */           String.format("Builder class %s does not have build method (name: '%s')", new Object[] {
/* 431 */           ClassUtil.getTypeDescription(this._beanDesc.getType()), expBuildMethodName }));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 436 */       Class<?> rawBuildType = this._buildMethod.getRawReturnType();
/* 437 */       Class<?> rawValueType = valueType.getRawClass();
/* 438 */       if ((rawBuildType != rawValueType) && 
/* 439 */         (!rawBuildType.isAssignableFrom(rawValueType)) && 
/* 440 */         (!rawValueType.isAssignableFrom(rawBuildType))) {
/* 441 */         this._context.reportBadDefinition(this._beanDesc.getType(), 
/* 442 */           String.format("Build method `%s` has wrong return type (%s), not compatible with POJO type (%s)", new Object[] {this._buildMethod
/* 443 */           .getFullName(), 
/* 444 */           ClassUtil.getClassDescription(rawBuildType), 
/* 445 */           ClassUtil.getTypeDescription(valueType) }));
/*     */       }
/*     */     }
/*     */     
/* 449 */     Collection<SettableBeanProperty> props = this._properties.values();
/* 450 */     _fixAccess(props);
/* 451 */     BeanPropertyMap propertyMap = BeanPropertyMap.construct(this._config, props, 
/* 452 */       _collectAliases(props), 
/* 453 */       _findCaseInsensitivity());
/* 454 */     propertyMap.assignIndexes();
/*     */     
/* 456 */     boolean anyViews = !this._config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION);
/*     */     
/* 458 */     if (!anyViews) {
/* 459 */       for (SettableBeanProperty prop : props) {
/* 460 */         if (prop.hasViews()) {
/* 461 */           anyViews = true;
/* 462 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 467 */     if (this._objectIdReader != null)
/*     */     {
/*     */ 
/* 470 */       ObjectIdValueProperty prop = new ObjectIdValueProperty(this._objectIdReader, PropertyMetadata.STD_REQUIRED);
/*     */       
/* 472 */       propertyMap = propertyMap.withProperty(prop);
/*     */     }
/*     */     
/* 475 */     return createBuilderBasedDeserializer(valueType, propertyMap, anyViews);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonDeserializer<?> createBuilderBasedDeserializer(JavaType valueType, BeanPropertyMap propertyMap, boolean anyViews)
/*     */   {
/* 485 */     return new BuilderBasedDeserializer(this, this._beanDesc, valueType, propertyMap, this._backRefProperties, this._ignorableProps, this._ignoreAllUnknown, this._includableProps, anyViews);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void _fixAccess(Collection<SettableBeanProperty> mainProps)
/*     */   {
/* 514 */     if (this._config.canOverrideAccessModifiers()) {
/* 515 */       for (SettableBeanProperty prop : mainProps)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 522 */         prop.fixAccess(this._config);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 540 */     if (this._anySetter != null) {
/* 541 */       this._anySetter.fixAccess(this._config);
/*     */     }
/* 543 */     if (this._buildMethod != null) {
/* 544 */       this._buildMethod.fixAccess(this._config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */     }
/*     */   }
/*     */   
/*     */   protected Map<String, List<PropertyName>> _collectAliases(Collection<SettableBeanProperty> props)
/*     */   {
/* 550 */     Map<String, List<PropertyName>> mapping = null;
/* 551 */     AnnotationIntrospector intr = this._config.getAnnotationIntrospector();
/* 552 */     if (intr != null)
/* 553 */       for (SettableBeanProperty prop : props) {
/* 554 */         List<PropertyName> aliases = intr.findPropertyAliases(prop.getMember());
/* 555 */         if ((aliases != null) && (!aliases.isEmpty()))
/*     */         {
/*     */ 
/* 558 */           if (mapping == null) {
/* 559 */             mapping = new HashMap();
/*     */           }
/* 561 */           mapping.put(prop.getName(), aliases);
/*     */         }
/*     */       }
/* 564 */     if (mapping == null) {
/* 565 */       return Collections.emptyMap();
/*     */     }
/* 567 */     return mapping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean _findCaseInsensitivity()
/*     */   {
/* 574 */     JsonFormat.Value format = this._beanDesc.findExpectedFormat(null);
/*     */     
/* 576 */     Boolean B = format.getFeature(JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
/* 577 */     return B == null ? this._config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES) : B
/* 578 */       .booleanValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\BeanDeserializerBuilder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */