/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AccessorNamingStrategy
/*     */ {
/*     */   public abstract String findNameForIsGetter(AnnotatedMethod paramAnnotatedMethod, String paramString);
/*     */   
/*     */   public abstract String findNameForRegularGetter(AnnotatedMethod paramAnnotatedMethod, String paramString);
/*     */   
/*     */   public abstract String findNameForMutator(AnnotatedMethod paramAnnotatedMethod, String paramString);
/*     */   
/*     */   public abstract String modifyFieldName(AnnotatedField paramAnnotatedField, String paramString);
/*     */   
/*     */   public static abstract class Provider
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public abstract AccessorNamingStrategy forPOJO(MapperConfig<?> paramMapperConfig, AnnotatedClass paramAnnotatedClass);
/*     */     
/*     */     public abstract AccessorNamingStrategy forBuilder(MapperConfig<?> paramMapperConfig, AnnotatedClass paramAnnotatedClass, BeanDescription paramBeanDescription);
/*     */     
/*     */     public abstract AccessorNamingStrategy forRecord(MapperConfig<?> paramMapperConfig, AnnotatedClass paramAnnotatedClass);
/*     */   }
/*     */   
/*     */   public static class Base
/*     */     extends AccessorNamingStrategy
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public String findNameForIsGetter(AnnotatedMethod method, String name)
/*     */     {
/* 117 */       return null;
/*     */     }
/*     */     
/*     */     public String findNameForRegularGetter(AnnotatedMethod method, String name)
/*     */     {
/* 122 */       return null;
/*     */     }
/*     */     
/*     */     public String findNameForMutator(AnnotatedMethod method, String name)
/*     */     {
/* 127 */       return null;
/*     */     }
/*     */     
/*     */     public String modifyFieldName(AnnotatedField field, String name)
/*     */     {
/* 132 */       return name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\introspect\AccessorNamingStrategy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */