/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.core.FormatFeature;
/*      */ import com.fasterxml.jackson.core.FormatSchema;
/*      */ import com.fasterxml.jackson.core.JsonEncoding;
/*      */ import com.fasterxml.jackson.core.JsonFactory;
/*      */ import com.fasterxml.jackson.core.JsonGenerationException;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*      */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*      */ import com.fasterxml.jackson.core.JsonProcessingException;
/*      */ import com.fasterxml.jackson.core.PrettyPrinter;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.StreamWriteFeature;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.SegmentedStringWriter;
/*      */ import com.fasterxml.jackson.core.type.TypeReference;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.Instantiatable;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.DefaultSerializerProvider;
/*      */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*      */ import com.fasterxml.jackson.databind.ser.impl.TypeWrappedSerializer;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.io.Closeable;
/*      */ import java.io.DataOutput;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.io.Writer;
/*      */ import java.text.DateFormat;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ 
/*      */ public class ObjectWriter implements com.fasterxml.jackson.core.Versioned, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   42 */   protected static final PrettyPrinter NULL_PRETTY_PRINTER = new com.fasterxml.jackson.core.util.MinimalPrettyPrinter();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final SerializationConfig _config;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final DefaultSerializerProvider _serializerProvider;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final com.fasterxml.jackson.databind.ser.SerializerFactory _serializerFactory;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final JsonFactory _generatorFactory;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final GeneratorSettings _generatorSettings;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Prefetch _prefetch;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectWriter(ObjectMapper mapper, SerializationConfig config, JavaType rootType, PrettyPrinter pp)
/*      */   {
/*  100 */     this._config = config;
/*  101 */     this._serializerProvider = mapper._serializerProvider;
/*  102 */     this._serializerFactory = mapper._serializerFactory;
/*  103 */     this._generatorFactory = mapper._jsonFactory;
/*  104 */     this._generatorSettings = (pp == null ? GeneratorSettings.empty : new GeneratorSettings(pp, null, null, null));
/*      */     
/*      */ 
/*  107 */     if (rootType == null) {
/*  108 */       this._prefetch = Prefetch.empty;
/*  109 */     } else if (rootType.hasRawClass(Object.class))
/*      */     {
/*      */ 
/*  112 */       this._prefetch = Prefetch.empty.forRootType(this, rootType);
/*      */     } else {
/*  114 */       this._prefetch = Prefetch.empty.forRootType(this, rootType.withStaticTyping());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectWriter(ObjectMapper mapper, SerializationConfig config)
/*      */   {
/*  123 */     this._config = config;
/*  124 */     this._serializerProvider = mapper._serializerProvider;
/*  125 */     this._serializerFactory = mapper._serializerFactory;
/*  126 */     this._generatorFactory = mapper._jsonFactory;
/*      */     
/*  128 */     this._generatorSettings = GeneratorSettings.empty;
/*  129 */     this._prefetch = Prefetch.empty;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectWriter(ObjectMapper mapper, SerializationConfig config, FormatSchema s)
/*      */   {
/*  138 */     this._config = config;
/*      */     
/*  140 */     this._serializerProvider = mapper._serializerProvider;
/*  141 */     this._serializerFactory = mapper._serializerFactory;
/*  142 */     this._generatorFactory = mapper._jsonFactory;
/*      */     
/*  144 */     this._generatorSettings = (s == null ? GeneratorSettings.empty : new GeneratorSettings(null, s, null, null));
/*      */     
/*  146 */     this._prefetch = Prefetch.empty;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectWriter(ObjectWriter base, SerializationConfig config, GeneratorSettings genSettings, Prefetch prefetch)
/*      */   {
/*  155 */     this._config = config;
/*      */     
/*  157 */     this._serializerProvider = base._serializerProvider;
/*  158 */     this._serializerFactory = base._serializerFactory;
/*  159 */     this._generatorFactory = base._generatorFactory;
/*      */     
/*  161 */     this._generatorSettings = genSettings;
/*  162 */     this._prefetch = prefetch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectWriter(ObjectWriter base, SerializationConfig config)
/*      */   {
/*  170 */     this._config = config;
/*      */     
/*  172 */     this._serializerProvider = base._serializerProvider;
/*  173 */     this._serializerFactory = base._serializerFactory;
/*  174 */     this._generatorFactory = base._generatorFactory;
/*      */     
/*  176 */     this._generatorSettings = base._generatorSettings;
/*  177 */     this._prefetch = base._prefetch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectWriter(ObjectWriter base, JsonFactory f)
/*      */   {
/*  187 */     this._config = ((SerializationConfig)base._config.with(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, f.requiresPropertyOrdering()));
/*      */     
/*  189 */     this._serializerProvider = base._serializerProvider;
/*  190 */     this._serializerFactory = base._serializerFactory;
/*  191 */     this._generatorFactory = f;
/*      */     
/*  193 */     this._generatorSettings = base._generatorSettings;
/*  194 */     this._prefetch = base._prefetch;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public com.fasterxml.jackson.core.Version version()
/*      */   {
/*  203 */     return com.fasterxml.jackson.databind.cfg.PackageVersion.VERSION;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectWriter _new(ObjectWriter base, JsonFactory f)
/*      */   {
/*  218 */     return new ObjectWriter(base, f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectWriter _new(ObjectWriter base, SerializationConfig config)
/*      */   {
/*  227 */     if (config == this._config) {
/*  228 */       return this;
/*      */     }
/*  230 */     return new ObjectWriter(base, config);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectWriter _new(GeneratorSettings genSettings, Prefetch prefetch)
/*      */   {
/*  241 */     if ((this._generatorSettings == genSettings) && (this._prefetch == prefetch)) {
/*  242 */       return this;
/*      */     }
/*  244 */     return new ObjectWriter(this, this._config, genSettings, prefetch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected SequenceWriter _newSequenceWriter(boolean wrapInArray, JsonGenerator gen, boolean managedInput)
/*      */     throws IOException
/*      */   {
/*  258 */     return 
/*      */     
/*  260 */       new SequenceWriter(_serializerProvider(), _configureGenerator(gen), managedInput, this._prefetch).init(wrapInArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(SerializationFeature feature)
/*      */   {
/*  274 */     return _new(this, this._config.with(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(SerializationFeature first, SerializationFeature... other)
/*      */   {
/*  282 */     return _new(this, this._config.with(first, other));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter withFeatures(SerializationFeature... features)
/*      */   {
/*  290 */     return _new(this, this._config.withFeatures(features));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter without(SerializationFeature feature)
/*      */   {
/*  298 */     return _new(this, this._config.without(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter without(SerializationFeature first, SerializationFeature... other)
/*      */   {
/*  306 */     return _new(this, this._config.without(first, other));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter withoutFeatures(SerializationFeature... features)
/*      */   {
/*  314 */     return _new(this, this._config.withoutFeatures(features));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(JsonGenerator.Feature feature)
/*      */   {
/*  327 */     return _new(this, this._config.with(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter withFeatures(JsonGenerator.Feature... features)
/*      */   {
/*  334 */     return _new(this, this._config.withFeatures(features));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter without(JsonGenerator.Feature feature)
/*      */   {
/*  341 */     return _new(this, this._config.without(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter withoutFeatures(JsonGenerator.Feature... features)
/*      */   {
/*  348 */     return _new(this, this._config.withoutFeatures(features));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(StreamWriteFeature feature)
/*      */   {
/*  361 */     return _new(this, this._config.with(feature.mappedFeature()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter without(StreamWriteFeature feature)
/*      */   {
/*  368 */     return _new(this, this._config.without(feature.mappedFeature()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(FormatFeature feature)
/*      */   {
/*  381 */     return _new(this, this._config.with(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter withFeatures(FormatFeature... features)
/*      */   {
/*  388 */     return _new(this, this._config.withFeatures(features));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter without(FormatFeature feature)
/*      */   {
/*  395 */     return _new(this, this._config.without(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter withoutFeatures(FormatFeature... features)
/*      */   {
/*  402 */     return _new(this, this._config.withoutFeatures(features));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter forType(JavaType rootType)
/*      */   {
/*  422 */     return _new(this._generatorSettings, this._prefetch.forRootType(this, rootType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter forType(Class<?> rootType)
/*      */   {
/*  433 */     return forType(this._config.constructType(rootType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter forType(TypeReference<?> rootType)
/*      */   {
/*  444 */     return forType(this._config.getTypeFactory().constructType(rootType.getType()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter withType(JavaType rootType)
/*      */   {
/*  452 */     return forType(rootType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter withType(Class<?> rootType)
/*      */   {
/*  460 */     return forType(rootType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter withType(TypeReference<?> rootType)
/*      */   {
/*  468 */     return forType(rootType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(DateFormat df)
/*      */   {
/*  486 */     return _new(this, this._config.with(df));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter withDefaultPrettyPrinter()
/*      */   {
/*  494 */     return with(this._config.getDefaultPrettyPrinter());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(FilterProvider filterProvider)
/*      */   {
/*  502 */     if (filterProvider == this._config.getFilterProvider()) {
/*  503 */       return this;
/*      */     }
/*  505 */     return _new(this, this._config.withFilters(filterProvider));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(PrettyPrinter pp)
/*      */   {
/*  513 */     return _new(this._generatorSettings.with(pp), this._prefetch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter withRootName(String rootName)
/*      */   {
/*  528 */     return _new(this, (SerializationConfig)this._config.withRootName(rootName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter withRootName(PropertyName rootName)
/*      */   {
/*  535 */     return _new(this, this._config.withRootName(rootName));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter withoutRootName()
/*      */   {
/*  549 */     return _new(this, this._config.withRootName(PropertyName.NO_NAME));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(FormatSchema schema)
/*      */   {
/*  560 */     _verifySchemaType(schema);
/*  561 */     return _new(this._generatorSettings.with(schema), this._prefetch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter withSchema(FormatSchema schema)
/*      */   {
/*  569 */     return with(schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter withView(Class<?> view)
/*      */   {
/*  581 */     return _new(this, this._config.withView(view));
/*      */   }
/*      */   
/*      */   public ObjectWriter with(Locale l) {
/*  585 */     return _new(this, (SerializationConfig)this._config.with(l));
/*      */   }
/*      */   
/*      */   public ObjectWriter with(java.util.TimeZone tz) {
/*  589 */     return _new(this, (SerializationConfig)this._config.with(tz));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(com.fasterxml.jackson.core.Base64Variant b64variant)
/*      */   {
/*  599 */     return _new(this, (SerializationConfig)this._config.with(b64variant));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(CharacterEscapes escapes)
/*      */   {
/*  606 */     return _new(this._generatorSettings.with(escapes), this._prefetch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(JsonFactory f)
/*      */   {
/*  613 */     return f == this._generatorFactory ? this : _new(this, f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter with(ContextAttributes attrs)
/*      */   {
/*  620 */     return _new(this, this._config.with(attrs));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter withAttributes(Map<?, ?> attrs)
/*      */   {
/*  630 */     return _new(this, (SerializationConfig)this._config.withAttributes(attrs));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter withAttribute(Object key, Object value)
/*      */   {
/*  637 */     return _new(this, (SerializationConfig)this._config.withAttribute(key, value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter withoutAttribute(Object key)
/*      */   {
/*  644 */     return _new(this, (SerializationConfig)this._config.withoutAttribute(key));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter withRootValueSeparator(String sep)
/*      */   {
/*  651 */     return _new(this._generatorSettings.withRootValueSeparator(sep), this._prefetch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectWriter withRootValueSeparator(SerializableString sep)
/*      */   {
/*  658 */     return _new(this._generatorSettings.withRootValueSeparator(sep), this._prefetch);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(OutputStream out)
/*      */     throws IOException
/*      */   {
/*  676 */     _assertNotNull("out", out);
/*  677 */     return _configureGenerator(this._generatorFactory.createGenerator(out, JsonEncoding.UTF8));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(OutputStream out, JsonEncoding enc)
/*      */     throws IOException
/*      */   {
/*  689 */     _assertNotNull("out", out);
/*  690 */     return _configureGenerator(this._generatorFactory.createGenerator(out, enc));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(Writer w)
/*      */     throws IOException
/*      */   {
/*  702 */     _assertNotNull("w", w);
/*  703 */     return _configureGenerator(this._generatorFactory.createGenerator(w));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(File outputFile, JsonEncoding enc)
/*      */     throws IOException
/*      */   {
/*  715 */     _assertNotNull("outputFile", outputFile);
/*  716 */     return _configureGenerator(this._generatorFactory.createGenerator(outputFile, enc));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(DataOutput out)
/*      */     throws IOException
/*      */   {
/*  728 */     _assertNotNull("out", out);
/*  729 */     return _configureGenerator(this._generatorFactory.createGenerator(out));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SequenceWriter writeValues(File out)
/*      */     throws IOException
/*      */   {
/*  752 */     return _newSequenceWriter(false, createGenerator(out, JsonEncoding.UTF8), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SequenceWriter writeValues(JsonGenerator g)
/*      */     throws IOException
/*      */   {
/*  771 */     _assertNotNull("g", g);
/*  772 */     return _newSequenceWriter(false, _configureGenerator(g), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SequenceWriter writeValues(Writer out)
/*      */     throws IOException
/*      */   {
/*  789 */     return _newSequenceWriter(false, createGenerator(out), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SequenceWriter writeValues(OutputStream out)
/*      */     throws IOException
/*      */   {
/*  806 */     return _newSequenceWriter(false, createGenerator(out, JsonEncoding.UTF8), true);
/*      */   }
/*      */   
/*      */ 
/*      */   public SequenceWriter writeValues(DataOutput out)
/*      */     throws IOException
/*      */   {
/*  813 */     return _newSequenceWriter(false, createGenerator(out), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SequenceWriter writeValuesAsArray(File out)
/*      */     throws IOException
/*      */   {
/*  832 */     return _newSequenceWriter(true, createGenerator(out, JsonEncoding.UTF8), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SequenceWriter writeValuesAsArray(JsonGenerator gen)
/*      */     throws IOException
/*      */   {
/*  852 */     _assertNotNull("gen", gen);
/*  853 */     return _newSequenceWriter(true, gen, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SequenceWriter writeValuesAsArray(Writer out)
/*      */     throws IOException
/*      */   {
/*  872 */     return _newSequenceWriter(true, createGenerator(out), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SequenceWriter writeValuesAsArray(OutputStream out)
/*      */     throws IOException
/*      */   {
/*  891 */     return _newSequenceWriter(true, createGenerator(out, JsonEncoding.UTF8), true);
/*      */   }
/*      */   
/*      */ 
/*      */   public SequenceWriter writeValuesAsArray(DataOutput out)
/*      */     throws IOException
/*      */   {
/*  898 */     return _newSequenceWriter(true, createGenerator(out), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(SerializationFeature f)
/*      */   {
/*  908 */     return this._config.isEnabled(f);
/*      */   }
/*      */   
/*      */   public boolean isEnabled(MapperFeature f) {
/*  912 */     return this._config.isEnabled(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public boolean isEnabled(JsonParser.Feature f)
/*      */   {
/*  920 */     return this._generatorFactory.isEnabled(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(JsonGenerator.Feature f)
/*      */   {
/*  927 */     return this._generatorFactory.isEnabled(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(StreamWriteFeature f)
/*      */   {
/*  934 */     return this._generatorFactory.isEnabled(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public SerializationConfig getConfig()
/*      */   {
/*  941 */     return this._config;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JsonFactory getFactory()
/*      */   {
/*  948 */     return this._generatorFactory;
/*      */   }
/*      */   
/*      */   public TypeFactory getTypeFactory() {
/*  952 */     return this._config.getTypeFactory();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasPrefetchedSerializer()
/*      */   {
/*  964 */     return this._prefetch.hasSerializer();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ContextAttributes getAttributes()
/*      */   {
/*  971 */     return this._config.getAttributes();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeValue(JsonGenerator g, Object value)
/*      */     throws IOException
/*      */   {
/*  989 */     _assertNotNull("g", g);
/*  990 */     _configureGenerator(g);
/*  991 */     if ((this._config.isEnabled(SerializationFeature.CLOSE_CLOSEABLE)) && ((value instanceof Closeable)))
/*      */     {
/*      */ 
/*  994 */       Closeable toClose = (Closeable)value;
/*      */       try {
/*  996 */         this._prefetch.serialize(g, value, _serializerProvider());
/*  997 */         if (this._config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/*  998 */           g.flush();
/*      */         }
/*      */       } catch (Exception e) {
/* 1001 */         ClassUtil.closeOnFailAndThrowAsIOE(null, toClose, e);
/* 1002 */         return;
/*      */       }
/* 1004 */       toClose.close();
/*      */     } else {
/* 1006 */       this._prefetch.serialize(g, value, _serializerProvider());
/* 1007 */       if (this._config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 1008 */         g.flush();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeValue(File resultFile, Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 1026 */     _writeValueAndClose(createGenerator(resultFile, JsonEncoding.UTF8), value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeValue(OutputStream out, Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 1043 */     _writeValueAndClose(createGenerator(out, JsonEncoding.UTF8), value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeValue(Writer w, Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 1059 */     _writeValueAndClose(createGenerator(w), value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeValue(DataOutput out, Object value)
/*      */     throws IOException
/*      */   {
/* 1068 */     _writeValueAndClose(createGenerator(out), value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String writeValueAsString(Object value)
/*      */     throws JsonProcessingException
/*      */   {
/* 1083 */     SegmentedStringWriter sw = new SegmentedStringWriter(this._generatorFactory._getBufferRecycler());
/*      */     try {
/* 1085 */       _writeValueAndClose(createGenerator(sw), value);
/*      */     } catch (JsonProcessingException e) {
/* 1087 */       throw e;
/*      */     } catch (IOException e) {
/* 1089 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     }
/* 1091 */     return sw.getAndClear();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] writeValueAsBytes(Object value)
/*      */     throws JsonProcessingException
/*      */   {
/* 1106 */     ByteArrayBuilder bb = new ByteArrayBuilder(this._generatorFactory._getBufferRecycler());
/*      */     try {
/* 1108 */       _writeValueAndClose(createGenerator(bb, JsonEncoding.UTF8), value);
/*      */     } catch (JsonProcessingException e) {
/* 1110 */       throw e;
/*      */     } catch (IOException e) {
/* 1112 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     }
/* 1114 */     byte[] result = bb.toByteArray();
/* 1115 */     bb.release();
/* 1116 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void acceptJsonFormatVisitor(JavaType type, JsonFormatVisitorWrapper visitor)
/*      */     throws JsonMappingException
/*      */   {
/* 1139 */     _assertNotNull("type", type);
/* 1140 */     _assertNotNull("visitor", visitor);
/* 1141 */     _serializerProvider().acceptJsonFormatVisitor(type, visitor);
/*      */   }
/*      */   
/*      */ 
/*      */   public void acceptJsonFormatVisitor(Class<?> type, JsonFormatVisitorWrapper visitor)
/*      */     throws JsonMappingException
/*      */   {
/* 1148 */     _assertNotNull("type", type);
/* 1149 */     _assertNotNull("visitor", visitor);
/* 1150 */     acceptJsonFormatVisitor(this._config.constructType(type), visitor);
/*      */   }
/*      */   
/*      */   public boolean canSerialize(Class<?> type) {
/* 1154 */     _assertNotNull("type", type);
/* 1155 */     return _serializerProvider().hasSerializerFor(type, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canSerialize(Class<?> type, java.util.concurrent.atomic.AtomicReference<Throwable> cause)
/*      */   {
/* 1165 */     _assertNotNull("type", type);
/* 1166 */     return _serializerProvider().hasSerializerFor(type, cause);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DefaultSerializerProvider _serializerProvider()
/*      */   {
/* 1180 */     return this._serializerProvider.createInstance(this._config, this._serializerFactory);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _verifySchemaType(FormatSchema schema)
/*      */   {
/* 1194 */     if ((schema != null) && 
/* 1195 */       (!this._generatorFactory.canUseSchema(schema)))
/*      */     {
/* 1197 */       throw new IllegalArgumentException("Cannot use FormatSchema of type " + schema.getClass().getName() + " for format " + this._generatorFactory.getFormatName());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _writeValueAndClose(JsonGenerator gen, Object value)
/*      */     throws IOException
/*      */   {
/* 1210 */     if ((this._config.isEnabled(SerializationFeature.CLOSE_CLOSEABLE)) && ((value instanceof Closeable))) {
/* 1211 */       _writeCloseable(gen, value);
/* 1212 */       return;
/*      */     }
/*      */     try {
/* 1215 */       this._prefetch.serialize(gen, value, _serializerProvider());
/*      */     } catch (Exception e) {
/* 1217 */       ClassUtil.closeOnFailAndThrowAsIOE(gen, e);
/* 1218 */       return;
/*      */     }
/* 1220 */     gen.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeCloseable(JsonGenerator gen, Object value)
/*      */     throws IOException
/*      */   {
/* 1230 */     Closeable toClose = (Closeable)value;
/*      */     try {
/* 1232 */       this._prefetch.serialize(gen, value, _serializerProvider());
/* 1233 */       Closeable tmpToClose = toClose;
/* 1234 */       toClose = null;
/* 1235 */       tmpToClose.close();
/*      */     } catch (Exception e) {
/* 1237 */       ClassUtil.closeOnFailAndThrowAsIOE(gen, toClose, e);
/* 1238 */       return;
/*      */     }
/* 1240 */     gen.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final JsonGenerator _configureGenerator(JsonGenerator gen)
/*      */   {
/* 1253 */     this._config.initialize(gen);
/* 1254 */     this._generatorSettings.initialize(gen);
/* 1255 */     return gen;
/*      */   }
/*      */   
/*      */   protected final void _assertNotNull(String paramName, Object src) {
/* 1259 */     if (src == null) {
/* 1260 */       throw new IllegalArgumentException(String.format("argument \"%s\" is null", new Object[] { paramName }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final class GeneratorSettings
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1282 */     public static final GeneratorSettings empty = new GeneratorSettings(null, null, null, null);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public final PrettyPrinter prettyPrinter;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public final FormatSchema schema;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public final CharacterEscapes characterEscapes;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public final SerializableString rootValueSeparator;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public GeneratorSettings(PrettyPrinter pp, FormatSchema sch, CharacterEscapes esc, SerializableString rootSep)
/*      */     {
/* 1313 */       this.prettyPrinter = pp;
/* 1314 */       this.schema = sch;
/* 1315 */       this.characterEscapes = esc;
/* 1316 */       this.rootValueSeparator = rootSep;
/*      */     }
/*      */     
/*      */     public GeneratorSettings with(PrettyPrinter pp)
/*      */     {
/* 1321 */       if (pp == null) {
/* 1322 */         pp = ObjectWriter.NULL_PRETTY_PRINTER;
/*      */       }
/* 1324 */       return pp == this.prettyPrinter ? this : new GeneratorSettings(pp, this.schema, this.characterEscapes, this.rootValueSeparator);
/*      */     }
/*      */     
/*      */     public GeneratorSettings with(FormatSchema sch)
/*      */     {
/* 1329 */       return this.schema == sch ? this : new GeneratorSettings(this.prettyPrinter, sch, this.characterEscapes, this.rootValueSeparator);
/*      */     }
/*      */     
/*      */     public GeneratorSettings with(CharacterEscapes esc)
/*      */     {
/* 1334 */       return this.characterEscapes == esc ? this : new GeneratorSettings(this.prettyPrinter, this.schema, esc, this.rootValueSeparator);
/*      */     }
/*      */     
/*      */     public GeneratorSettings withRootValueSeparator(String sep)
/*      */     {
/* 1339 */       if (sep == null) {
/* 1340 */         if (this.rootValueSeparator == null) {
/* 1341 */           return this;
/*      */         }
/* 1343 */         return new GeneratorSettings(this.prettyPrinter, this.schema, this.characterEscapes, null);
/*      */       }
/* 1345 */       if (sep.equals(_rootValueSeparatorAsString())) {
/* 1346 */         return this;
/*      */       }
/* 1348 */       return new GeneratorSettings(this.prettyPrinter, this.schema, this.characterEscapes, new com.fasterxml.jackson.core.io.SerializedString(sep));
/*      */     }
/*      */     
/*      */     public GeneratorSettings withRootValueSeparator(SerializableString sep)
/*      */     {
/* 1353 */       if (sep == null) {
/* 1354 */         if (this.rootValueSeparator == null) {
/* 1355 */           return this;
/*      */         }
/* 1357 */         return new GeneratorSettings(this.prettyPrinter, this.schema, this.characterEscapes, null);
/*      */       }
/* 1359 */       if (sep.equals(this.rootValueSeparator)) {
/* 1360 */         return this;
/*      */       }
/* 1362 */       return new GeneratorSettings(this.prettyPrinter, this.schema, this.characterEscapes, sep);
/*      */     }
/*      */     
/*      */     private final String _rootValueSeparatorAsString() {
/* 1366 */       return this.rootValueSeparator == null ? null : this.rootValueSeparator.getValue();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void initialize(JsonGenerator gen)
/*      */     {
/* 1374 */       PrettyPrinter pp = this.prettyPrinter;
/* 1375 */       if (this.prettyPrinter != null) {
/* 1376 */         if (pp == ObjectWriter.NULL_PRETTY_PRINTER) {
/* 1377 */           gen.setPrettyPrinter(null);
/*      */         } else {
/* 1379 */           if ((pp instanceof Instantiatable)) {
/* 1380 */             pp = (PrettyPrinter)((Instantiatable)pp).createInstance();
/*      */           }
/* 1382 */           gen.setPrettyPrinter(pp);
/*      */         }
/*      */       }
/* 1385 */       if (this.characterEscapes != null) {
/* 1386 */         gen.setCharacterEscapes(this.characterEscapes);
/*      */       }
/* 1388 */       if (this.schema != null) {
/* 1389 */         gen.setSchema(this.schema);
/*      */       }
/* 1391 */       if (this.rootValueSeparator != null) {
/* 1392 */         gen.setRootValueSeparator(this.rootValueSeparator);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final class Prefetch
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1409 */     public static final Prefetch empty = new Prefetch(null, null, null);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final JavaType rootType;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final JsonSerializer<Object> valueSerializer;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final TypeSerializer typeSerializer;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private Prefetch(JavaType rootT, JsonSerializer<Object> ser, TypeSerializer typeSer)
/*      */     {
/* 1435 */       this.rootType = rootT;
/* 1436 */       this.valueSerializer = ser;
/* 1437 */       this.typeSerializer = typeSer;
/*      */     }
/*      */     
/*      */     public Prefetch forRootType(ObjectWriter parent, JavaType newType)
/*      */     {
/* 1442 */       if (newType == null) {
/* 1443 */         if ((this.rootType == null) || (this.valueSerializer == null)) {
/* 1444 */           return this;
/*      */         }
/* 1446 */         return new Prefetch(null, null, null);
/*      */       }
/*      */       
/*      */ 
/* 1450 */       if (newType.equals(this.rootType)) {
/* 1451 */         return this;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1456 */       if (newType.isJavaLangObject()) {
/* 1457 */         DefaultSerializerProvider prov = parent._serializerProvider();
/*      */         
/*      */         try
/*      */         {
/* 1461 */           typeSer = prov.findTypeSerializer(newType);
/*      */         }
/*      */         catch (JsonMappingException e) {
/*      */           TypeSerializer typeSer;
/* 1465 */           throw new RuntimeJsonMappingException(e); }
/*      */         TypeSerializer typeSer;
/* 1467 */         return new Prefetch(null, null, typeSer);
/*      */       }
/*      */       
/* 1470 */       if (parent.isEnabled(SerializationFeature.EAGER_SERIALIZER_FETCH)) {
/* 1471 */         DefaultSerializerProvider prov = parent._serializerProvider();
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/* 1477 */           JsonSerializer<Object> ser = prov.findTypedValueSerializer(newType, true, null);
/*      */           
/* 1479 */           if ((ser instanceof TypeWrappedSerializer)) {
/* 1480 */             return new Prefetch(newType, null, ((TypeWrappedSerializer)ser)
/* 1481 */               .typeSerializer());
/*      */           }
/* 1483 */           return new Prefetch(newType, ser, null);
/*      */         }
/*      */         catch (JsonMappingException localJsonMappingException1) {}
/*      */       }
/*      */       
/*      */ 
/* 1489 */       return new Prefetch(newType, null, this.typeSerializer);
/*      */     }
/*      */     
/*      */     public final JsonSerializer<Object> getValueSerializer() {
/* 1493 */       return this.valueSerializer;
/*      */     }
/*      */     
/*      */     public final TypeSerializer getTypeSerializer() {
/* 1497 */       return this.typeSerializer;
/*      */     }
/*      */     
/*      */     public boolean hasSerializer() {
/* 1501 */       return (this.valueSerializer != null) || (this.typeSerializer != null);
/*      */     }
/*      */     
/*      */     public void serialize(JsonGenerator gen, Object value, DefaultSerializerProvider prov)
/*      */       throws IOException
/*      */     {
/* 1507 */       if (this.typeSerializer != null) {
/* 1508 */         prov.serializePolymorphic(gen, value, this.rootType, this.valueSerializer, this.typeSerializer);
/* 1509 */       } else if (this.valueSerializer != null) {
/* 1510 */         prov.serializeValue(gen, value, this.rootType, this.valueSerializer);
/* 1511 */       } else if (this.rootType != null) {
/* 1512 */         prov.serializeValue(gen, value, this.rootType);
/*      */       } else {
/* 1514 */         prov.serializeValue(gen, value);
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\ObjectWriter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */