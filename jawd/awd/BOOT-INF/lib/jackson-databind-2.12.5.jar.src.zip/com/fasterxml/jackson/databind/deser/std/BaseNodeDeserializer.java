/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonParser.NumberType;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.node.ArrayNode;
/*     */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.RawValue;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseNodeDeserializer<T extends JsonNode>
/*     */   extends StdDeserializer<T>
/*     */ {
/*     */   protected final Boolean _supportsUpdates;
/*     */   
/*     */   public BaseNodeDeserializer(Class<T> vc, Boolean supportsUpdates)
/*     */   {
/* 175 */     super(vc);
/* 176 */     this._supportsUpdates = supportsUpdates;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*     */     throws IOException
/*     */   {
/* 185 */     return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*     */   }
/*     */   
/*     */   public LogicalType logicalType()
/*     */   {
/* 190 */     return LogicalType.Untyped;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isCachable()
/*     */   {
/* 197 */     return true;
/*     */   }
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 201 */     return this._supportsUpdates;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void _handleDuplicateField(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory, String fieldName, ObjectNode objectNode, JsonNode oldValue, JsonNode newValue)
/*     */     throws JsonProcessingException
/*     */   {
/* 230 */     if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_READING_DUP_TREE_KEY))
/*     */     {
/*     */ 
/*     */ 
/* 234 */       ctxt.reportInputMismatch(JsonNode.class, "Duplicate field '%s' for `ObjectNode`: not allowed when `DeserializationFeature.FAIL_ON_READING_DUP_TREE_KEY` enabled", new Object[] { fieldName });
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 239 */     if (ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES))
/*     */     {
/*     */ 
/* 242 */       if (oldValue.isArray()) {
/* 243 */         ((ArrayNode)oldValue).add(newValue);
/* 244 */         objectNode.replace(fieldName, oldValue);
/*     */       } else {
/* 246 */         ArrayNode arr = nodeFactory.arrayNode();
/* 247 */         arr.add(oldValue);
/* 248 */         arr.add(newValue);
/* 249 */         objectNode.replace(fieldName, arr);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ObjectNode deserializeObject(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory)
/*     */     throws IOException
/*     */   {
/* 267 */     ObjectNode node = nodeFactory.objectNode();
/* 268 */     for (String key = p.nextFieldName(); 
/* 269 */         key != null; key = p.nextFieldName())
/*     */     {
/* 271 */       JsonToken t = p.nextToken();
/* 272 */       if (t == null)
/* 273 */         t = JsonToken.NOT_AVAILABLE;
/*     */       JsonNode value;
/* 275 */       JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; switch (t.id()) {
/*     */       case 1: 
/* 277 */         value = deserializeObject(p, ctxt, nodeFactory);
/* 278 */         break;
/*     */       case 3: 
/* 280 */         value = deserializeArray(p, ctxt, nodeFactory);
/* 281 */         break;
/*     */       case 12: 
/* 283 */         value = _fromEmbedded(p, ctxt, nodeFactory);
/* 284 */         break;
/*     */       case 6: 
/* 286 */         value = nodeFactory.textNode(p.getText());
/* 287 */         break;
/*     */       case 7: 
/* 289 */         value = _fromInt(p, ctxt, nodeFactory);
/* 290 */         break;
/*     */       case 9: 
/* 292 */         value = nodeFactory.booleanNode(true);
/* 293 */         break;
/*     */       case 10: 
/* 295 */         value = nodeFactory.booleanNode(false);
/* 296 */         break;
/*     */       case 11: 
/* 298 */         value = nodeFactory.nullNode();
/* 299 */         break;
/*     */       case 2: case 4: case 5: case 8: default: 
/* 301 */         value = deserializeAny(p, ctxt, nodeFactory);
/*     */       }
/* 303 */       JsonNode old = node.replace(key, value);
/* 304 */       if (old != null) {
/* 305 */         _handleDuplicateField(p, ctxt, nodeFactory, key, node, old, value);
/*     */       }
/*     */     }
/*     */     
/* 309 */     return node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ObjectNode deserializeObjectAtName(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory)
/*     */     throws IOException
/*     */   {
/* 321 */     ObjectNode node = nodeFactory.objectNode();
/* 322 */     for (String key = p.currentName(); 
/* 323 */         key != null; key = p.nextFieldName())
/*     */     {
/* 325 */       JsonToken t = p.nextToken();
/* 326 */       if (t == null)
/* 327 */         t = JsonToken.NOT_AVAILABLE;
/*     */       JsonNode value;
/* 329 */       JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; switch (t.id()) {
/*     */       case 1: 
/* 331 */         value = deserializeObject(p, ctxt, nodeFactory);
/* 332 */         break;
/*     */       case 3: 
/* 334 */         value = deserializeArray(p, ctxt, nodeFactory);
/* 335 */         break;
/*     */       case 12: 
/* 337 */         value = _fromEmbedded(p, ctxt, nodeFactory);
/* 338 */         break;
/*     */       case 6: 
/* 340 */         value = nodeFactory.textNode(p.getText());
/* 341 */         break;
/*     */       case 7: 
/* 343 */         value = _fromInt(p, ctxt, nodeFactory);
/* 344 */         break;
/*     */       case 9: 
/* 346 */         value = nodeFactory.booleanNode(true);
/* 347 */         break;
/*     */       case 10: 
/* 349 */         value = nodeFactory.booleanNode(false);
/* 350 */         break;
/*     */       case 11: 
/* 352 */         value = nodeFactory.nullNode();
/* 353 */         break;
/*     */       case 2: case 4: case 5: case 8: default: 
/* 355 */         value = deserializeAny(p, ctxt, nodeFactory);
/*     */       }
/* 357 */       JsonNode old = node.replace(key, value);
/* 358 */       if (old != null) {
/* 359 */         _handleDuplicateField(p, ctxt, nodeFactory, key, node, old, value);
/*     */       }
/*     */     }
/*     */     
/* 363 */     return node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final JsonNode updateObject(JsonParser p, DeserializationContext ctxt, ObjectNode node)
/*     */     throws IOException
/*     */   {
/*     */     String key;
/*     */     
/*     */ 
/*     */ 
/* 376 */     if (p.isExpectedStartObjectToken()) {
/* 377 */       key = p.nextFieldName();
/*     */     }
/* 379 */     else if (!p.hasToken(JsonToken.FIELD_NAME)) {
/* 380 */       return (JsonNode)deserialize(p, ctxt);
/*     */     }
/* 382 */     for (String key = p.currentName(); 
/*     */         
/* 384 */         key != null; key = p.nextFieldName())
/*     */     {
/* 386 */       JsonToken t = p.nextToken();
/*     */       
/*     */ 
/* 389 */       JsonNode old = node.get(key);
/* 390 */       if (old != null) {
/* 391 */         if ((old instanceof ObjectNode))
/*     */         {
/*     */ 
/* 394 */           if (t == JsonToken.START_OBJECT) {
/* 395 */             JsonNode newValue = updateObject(p, ctxt, (ObjectNode)old);
/* 396 */             if (newValue == old) continue;
/* 397 */             node.set(key, newValue); continue;
/*     */           }
/*     */           
/*     */         }
/* 401 */         else if ((old instanceof ArrayNode))
/*     */         {
/*     */ 
/* 404 */           if (t == JsonToken.START_ARRAY) {
/* 405 */             JsonNode newValue = updateArray(p, ctxt, (ArrayNode)old);
/* 406 */             if (newValue == old) continue;
/* 407 */             node.set(key, newValue); continue;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 413 */       if (t == null) {
/* 414 */         t = JsonToken.NOT_AVAILABLE;
/*     */       }
/*     */       
/* 417 */       JsonNodeFactory nodeFactory = ctxt.getNodeFactory();
/* 418 */       JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; JsonNode value; switch (t.id()) {
/*     */       case 1: 
/* 420 */         value = deserializeObject(p, ctxt, nodeFactory);
/* 421 */         break;
/*     */       case 3: 
/* 423 */         value = deserializeArray(p, ctxt, nodeFactory);
/* 424 */         break;
/*     */       case 12: 
/* 426 */         value = _fromEmbedded(p, ctxt, nodeFactory);
/* 427 */         break;
/*     */       case 6: 
/* 429 */         value = nodeFactory.textNode(p.getText());
/* 430 */         break;
/*     */       case 7: 
/* 432 */         value = _fromInt(p, ctxt, nodeFactory);
/* 433 */         break;
/*     */       case 9: 
/* 435 */         value = nodeFactory.booleanNode(true);
/* 436 */         break;
/*     */       case 10: 
/* 438 */         value = nodeFactory.booleanNode(false);
/* 439 */         break;
/*     */       case 11: 
/* 441 */         value = nodeFactory.nullNode();
/* 442 */         break;
/*     */       case 2: case 4: case 5: case 8: default: 
/* 444 */         value = deserializeAny(p, ctxt, nodeFactory);
/*     */       }
/*     */       
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 455 */       node.set(key, value);
/*     */     }
/* 457 */     return node;
/*     */   }
/*     */   
/*     */   protected final ArrayNode deserializeArray(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory)
/*     */     throws IOException
/*     */   {
/* 463 */     ArrayNode node = nodeFactory.arrayNode();
/*     */     
/*     */     JsonToken t;
/* 466 */     while ((t = p.nextToken()) != null) {
/* 467 */       switch (t.id()) {
/*     */       case 1: 
/* 469 */         node.add(deserializeObject(p, ctxt, nodeFactory));
/* 470 */         break;
/*     */       case 3: 
/* 472 */         node.add(deserializeArray(p, ctxt, nodeFactory));
/* 473 */         break;
/*     */       case 4: 
/* 475 */         return node;
/*     */       case 12: 
/* 477 */         node.add(_fromEmbedded(p, ctxt, nodeFactory));
/* 478 */         break;
/*     */       case 6: 
/* 480 */         node.add(nodeFactory.textNode(p.getText()));
/* 481 */         break;
/*     */       case 7: 
/* 483 */         node.add(_fromInt(p, ctxt, nodeFactory));
/* 484 */         break;
/*     */       case 9: 
/* 486 */         node.add(nodeFactory.booleanNode(true));
/* 487 */         break;
/*     */       case 10: 
/* 489 */         node.add(nodeFactory.booleanNode(false));
/* 490 */         break;
/*     */       case 11: 
/* 492 */         node.add(nodeFactory.nullNode());
/* 493 */         break;
/*     */       case 2: case 5: case 8: default: 
/* 495 */         node.add(deserializeAny(p, ctxt, nodeFactory));
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 500 */     return node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final JsonNode updateArray(JsonParser p, DeserializationContext ctxt, ArrayNode node)
/*     */     throws IOException
/*     */   {
/* 512 */     JsonNodeFactory nodeFactory = ctxt.getNodeFactory();
/*     */     for (;;) {
/* 514 */       JsonToken t = p.nextToken();
/* 515 */       switch (t.id()) {
/*     */       case 1: 
/* 517 */         node.add(deserializeObject(p, ctxt, nodeFactory));
/* 518 */         break;
/*     */       case 3: 
/* 520 */         node.add(deserializeArray(p, ctxt, nodeFactory));
/* 521 */         break;
/*     */       case 4: 
/* 523 */         return node;
/*     */       case 12: 
/* 525 */         node.add(_fromEmbedded(p, ctxt, nodeFactory));
/* 526 */         break;
/*     */       case 6: 
/* 528 */         node.add(nodeFactory.textNode(p.getText()));
/* 529 */         break;
/*     */       case 7: 
/* 531 */         node.add(_fromInt(p, ctxt, nodeFactory));
/* 532 */         break;
/*     */       case 9: 
/* 534 */         node.add(nodeFactory.booleanNode(true));
/* 535 */         break;
/*     */       case 10: 
/* 537 */         node.add(nodeFactory.booleanNode(false));
/* 538 */         break;
/*     */       case 11: 
/* 540 */         node.add(nodeFactory.nullNode());
/* 541 */         break;
/*     */       case 2: case 5: case 8: default: 
/* 543 */         node.add(deserializeAny(p, ctxt, nodeFactory));
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */   protected final JsonNode deserializeAny(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory)
/*     */     throws IOException
/*     */   {
/* 552 */     switch (p.currentTokenId()) {
/*     */     case 2: 
/* 554 */       return nodeFactory.objectNode();
/*     */     case 5: 
/* 556 */       return deserializeObjectAtName(p, ctxt, nodeFactory);
/*     */     case 12: 
/* 558 */       return _fromEmbedded(p, ctxt, nodeFactory);
/*     */     case 6: 
/* 560 */       return nodeFactory.textNode(p.getText());
/*     */     case 7: 
/* 562 */       return _fromInt(p, ctxt, nodeFactory);
/*     */     case 8: 
/* 564 */       return _fromFloat(p, ctxt, nodeFactory);
/*     */     case 9: 
/* 566 */       return nodeFactory.booleanNode(true);
/*     */     case 10: 
/* 568 */       return nodeFactory.booleanNode(false);
/*     */     case 11: 
/* 570 */       return nodeFactory.nullNode();
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 587 */     return (JsonNode)ctxt.handleUnexpectedToken(handledType(), p);
/*     */   }
/*     */   
/*     */ 
/*     */   protected final JsonNode _fromInt(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory)
/*     */     throws IOException
/*     */   {
/* 594 */     int feats = ctxt.getDeserializationFeatures();
/* 595 */     JsonParser.NumberType nt; JsonParser.NumberType nt; if ((feats & F_MASK_INT_COERCIONS) != 0) { JsonParser.NumberType nt;
/* 596 */       if (DeserializationFeature.USE_BIG_INTEGER_FOR_INTS.enabledIn(feats)) {
/* 597 */         nt = JsonParser.NumberType.BIG_INTEGER; } else { JsonParser.NumberType nt;
/* 598 */         if (DeserializationFeature.USE_LONG_FOR_INTS.enabledIn(feats)) {
/* 599 */           nt = JsonParser.NumberType.LONG;
/*     */         } else
/* 601 */           nt = p.getNumberType();
/*     */       }
/*     */     } else {
/* 604 */       nt = p.getNumberType();
/*     */     }
/* 606 */     if (nt == JsonParser.NumberType.INT) {
/* 607 */       return nodeFactory.numberNode(p.getIntValue());
/*     */     }
/* 609 */     if (nt == JsonParser.NumberType.LONG) {
/* 610 */       return nodeFactory.numberNode(p.getLongValue());
/*     */     }
/* 612 */     return nodeFactory.numberNode(p.getBigIntegerValue());
/*     */   }
/*     */   
/*     */   protected final JsonNode _fromFloat(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory)
/*     */     throws IOException
/*     */   {
/* 618 */     JsonParser.NumberType nt = p.getNumberType();
/* 619 */     if (nt == JsonParser.NumberType.BIG_DECIMAL) {
/* 620 */       return nodeFactory.numberNode(p.getDecimalValue());
/*     */     }
/* 622 */     if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS))
/*     */     {
/*     */ 
/* 625 */       if (p.isNaN()) {
/* 626 */         return nodeFactory.numberNode(p.getDoubleValue());
/*     */       }
/* 628 */       return nodeFactory.numberNode(p.getDecimalValue());
/*     */     }
/* 630 */     if (nt == JsonParser.NumberType.FLOAT) {
/* 631 */       return nodeFactory.numberNode(p.getFloatValue());
/*     */     }
/* 633 */     return nodeFactory.numberNode(p.getDoubleValue());
/*     */   }
/*     */   
/*     */   protected final JsonNode _fromEmbedded(JsonParser p, DeserializationContext ctxt, JsonNodeFactory nodeFactory)
/*     */     throws IOException
/*     */   {
/* 639 */     Object ob = p.getEmbeddedObject();
/* 640 */     if (ob == null) {
/* 641 */       return nodeFactory.nullNode();
/*     */     }
/* 643 */     Class<?> type = ob.getClass();
/* 644 */     if (type == byte[].class) {
/* 645 */       return nodeFactory.binaryNode((byte[])ob);
/*     */     }
/*     */     
/* 648 */     if ((ob instanceof RawValue)) {
/* 649 */       return nodeFactory.rawValueNode((RawValue)ob);
/*     */     }
/* 651 */     if ((ob instanceof JsonNode))
/*     */     {
/* 653 */       return (JsonNode)ob;
/*     */     }
/*     */     
/* 656 */     return nodeFactory.pojoNode(ob);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\std\BaseNodeDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */