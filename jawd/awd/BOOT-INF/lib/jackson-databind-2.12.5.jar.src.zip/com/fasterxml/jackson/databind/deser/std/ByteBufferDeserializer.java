/*    */ package com.fasterxml.jackson.databind.deser.std;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.type.LogicalType;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class ByteBufferDeserializer extends StdScalarDeserializer<ByteBuffer>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected ByteBufferDeserializer()
/*    */   {
/* 15 */     super(ByteBuffer.class);
/*    */   }
/*    */   
/*    */   public LogicalType logicalType() {
/* 19 */     return LogicalType.Binary;
/*    */   }
/*    */   
/*    */   public ByteBuffer deserialize(JsonParser parser, DeserializationContext cx) throws IOException
/*    */   {
/* 24 */     byte[] b = parser.getBinaryValue();
/* 25 */     return ByteBuffer.wrap(b);
/*    */   }
/*    */   
/*    */   public ByteBuffer deserialize(JsonParser jp, DeserializationContext ctxt, ByteBuffer intoValue)
/*    */     throws IOException
/*    */   {
/* 31 */     java.io.OutputStream out = new com.fasterxml.jackson.databind.util.ByteBufferBackedOutputStream(intoValue);
/* 32 */     jp.readBinaryValue(ctxt.getBase64Variant(), out);
/* 33 */     out.close();
/* 34 */     return intoValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\std\ByteBufferDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */