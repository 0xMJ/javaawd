/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect.Value;
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude.Include;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude.Value;
/*      */ import com.fasterxml.jackson.annotation.JsonSetter.Value;
/*      */ import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
/*      */ import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
/*      */ import com.fasterxml.jackson.annotation.PropertyAccessor;
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.Base64Variants;
/*      */ import com.fasterxml.jackson.core.FormatSchema;
/*      */ import com.fasterxml.jackson.core.JsonEncoding;
/*      */ import com.fasterxml.jackson.core.JsonFactory;
/*      */ import com.fasterxml.jackson.core.JsonFactory.Feature;
/*      */ import com.fasterxml.jackson.core.JsonGenerationException;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*      */ import com.fasterxml.jackson.core.JsonProcessingException;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.PrettyPrinter;
/*      */ import com.fasterxml.jackson.core.StreamReadFeature;
/*      */ import com.fasterxml.jackson.core.StreamWriteFeature;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.Versioned;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.SegmentedStringWriter;
/*      */ import com.fasterxml.jackson.core.type.ResolvedType;
/*      */ import com.fasterxml.jackson.core.type.TypeReference;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.databind.cfg.BaseSettings;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionConfigs;
/*      */ import com.fasterxml.jackson.databind.cfg.ConfigOverrides;
/*      */ import com.fasterxml.jackson.databind.cfg.ConstructorDetector;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.cfg.MutableCoercionConfig;
/*      */ import com.fasterxml.jackson.databind.cfg.MutableConfigOverride;
/*      */ import com.fasterxml.jackson.databind.cfg.PackageVersion;
/*      */ import com.fasterxml.jackson.databind.deser.BeanDeserializerFactory;
/*      */ import com.fasterxml.jackson.databind.deser.BeanDeserializerModifier;
/*      */ import com.fasterxml.jackson.databind.deser.DefaultDeserializationContext;
/*      */ import com.fasterxml.jackson.databind.deser.DefaultDeserializationContext.Impl;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializerFactory;
/*      */ import com.fasterxml.jackson.databind.deser.Deserializers;
/*      */ import com.fasterxml.jackson.databind.deser.KeyDeserializers;
/*      */ import com.fasterxml.jackson.databind.deser.ValueInstantiators;
/*      */ import com.fasterxml.jackson.databind.exc.MismatchedInputException;
/*      */ import com.fasterxml.jackson.databind.introspect.AccessorNamingStrategy.Provider;
/*      */ import com.fasterxml.jackson.databind.introspect.BasicClassIntrospector;
/*      */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*      */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector.MixInResolver;
/*      */ import com.fasterxml.jackson.databind.introspect.DefaultAccessorNamingStrategy.Provider;
/*      */ import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.introspect.SimpleMixInResolver;
/*      */ import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
/*      */ import com.fasterxml.jackson.databind.introspect.VisibilityChecker.Std;
/*      */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*      */ import com.fasterxml.jackson.databind.jsonschema.JsonSchema;
/*      */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*      */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*      */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.impl.LaissezFaireSubTypeValidator;
/*      */ import com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver;
/*      */ import com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.node.ArrayNode;
/*      */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*      */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*      */ import com.fasterxml.jackson.databind.node.POJONode;
/*      */ import com.fasterxml.jackson.databind.node.TreeTraversingParser;
/*      */ import com.fasterxml.jackson.databind.ser.BeanSerializerFactory;
/*      */ import com.fasterxml.jackson.databind.ser.BeanSerializerModifier;
/*      */ import com.fasterxml.jackson.databind.ser.DefaultSerializerProvider;
/*      */ import com.fasterxml.jackson.databind.ser.DefaultSerializerProvider.Impl;
/*      */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*      */ import com.fasterxml.jackson.databind.ser.SerializerFactory;
/*      */ import com.fasterxml.jackson.databind.ser.Serializers;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.type.TypeModifier;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.RootNameLookup;
/*      */ import com.fasterxml.jackson.databind.util.StdDateFormat;
/*      */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*      */ import java.io.Closeable;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Type;
/*      */ import java.net.URL;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.text.DateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.ServiceLoader;
/*      */ import java.util.Set;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ObjectMapper
/*      */   extends ObjectCodec
/*      */   implements Versioned, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 2L;
/*      */   
/*      */   public static enum DefaultTyping
/*      */   {
/*  157 */     JAVA_LANG_OBJECT, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  167 */     OBJECT_AND_NON_CONCRETE, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  176 */     NON_CONCRETE_AND_ARRAYS, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  187 */     NON_FINAL, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  212 */     EVERYTHING;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private DefaultTyping() {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class DefaultTypeResolverBuilder
/*      */     extends StdTypeResolverBuilder
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected final ObjectMapper.DefaultTyping _appliesFor;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected final PolymorphicTypeValidator _subtypeValidator;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public DefaultTypeResolverBuilder(ObjectMapper.DefaultTyping t)
/*      */     {
/*  250 */       this(t, LaissezFaireSubTypeValidator.instance);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public DefaultTypeResolverBuilder(ObjectMapper.DefaultTyping t, PolymorphicTypeValidator ptv)
/*      */     {
/*  257 */       this._appliesFor = ((ObjectMapper.DefaultTyping)_requireNonNull(t, "Can not pass `null` DefaultTyping"));
/*  258 */       this._subtypeValidator = ((PolymorphicTypeValidator)_requireNonNull(ptv, "Can not pass `null` PolymorphicTypeValidator"));
/*      */     }
/*      */     
/*      */ 
/*      */     private static <T> T _requireNonNull(T value, String msg)
/*      */     {
/*  264 */       if (value == null) {
/*  265 */         throw new NullPointerException(msg);
/*      */       }
/*  267 */       return value;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public static DefaultTypeResolverBuilder construct(ObjectMapper.DefaultTyping t, PolymorphicTypeValidator ptv)
/*      */     {
/*  275 */       return new DefaultTypeResolverBuilder(t, ptv);
/*      */     }
/*      */     
/*      */     public PolymorphicTypeValidator subTypeValidator(MapperConfig<?> config)
/*      */     {
/*  280 */       return this._subtypeValidator;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public TypeDeserializer buildTypeDeserializer(DeserializationConfig config, JavaType baseType, Collection<NamedType> subtypes)
/*      */     {
/*  287 */       return useForType(baseType) ? super.buildTypeDeserializer(config, baseType, subtypes) : null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public TypeSerializer buildTypeSerializer(SerializationConfig config, JavaType baseType, Collection<NamedType> subtypes)
/*      */     {
/*  294 */       return useForType(baseType) ? super.buildTypeSerializer(config, baseType, subtypes) : null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean useForType(JavaType t)
/*      */     {
/*  309 */       if (t.isPrimitive()) {
/*  310 */         return false;
/*      */       }
/*      */       
/*  313 */       switch (ObjectMapper.3.$SwitchMap$com$fasterxml$jackson$databind$ObjectMapper$DefaultTyping[this._appliesFor.ordinal()]) {
/*      */       case 1: 
/*  315 */         while (t.isArrayType()) {
/*  316 */           t = t.getContentType();
/*      */         }
/*      */       
/*      */ 
/*      */       case 2: 
/*  321 */         while (t.isReferenceType()) {
/*  322 */           t = t.getReferencedType();
/*      */         }
/*  324 */         if (!t.isJavaLangObject()) {
/*  325 */           if (t.isConcrete()) {
/*      */             break label116;
/*      */           }
/*      */         }
/*  324 */         return 
/*      */         
/*      */ 
/*  327 */           !TreeNode.class.isAssignableFrom(t.getRawClass());
/*      */       
/*      */       case 3: 
/*  330 */         while (t.isArrayType()) {
/*  331 */           t = t.getContentType();
/*      */         }
/*      */         
/*  334 */         while (t.isReferenceType()) {
/*  335 */           t = t.getReferencedType();
/*      */         }
/*      */         
/*  338 */         return (!t.isFinal()) && (!TreeNode.class.isAssignableFrom(t.getRawClass()));
/*      */       case 4: 
/*      */         label116:
/*      */         
/*  342 */         return true;
/*      */       }
/*      */       
/*  345 */       return t.isJavaLangObject();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  357 */   protected static final AnnotationIntrospector DEFAULT_ANNOTATION_INTROSPECTOR = new JacksonAnnotationIntrospector();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  363 */   protected static final BaseSettings DEFAULT_BASE = new BaseSettings(null, DEFAULT_ANNOTATION_INTROSPECTOR, null, 
/*      */   
/*      */ 
/*  366 */     TypeFactory.defaultInstance(), null, StdDateFormat.instance, null, 
/*      */     
/*  368 */     Locale.getDefault(), null, 
/*      */     
/*  370 */     Base64Variants.getDefaultVariant(), LaissezFaireSubTypeValidator.instance, new DefaultAccessorNamingStrategy.Provider());
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final JsonFactory _jsonFactory;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected TypeFactory _typeFactory;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InjectableValues _injectableValues;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected SubtypeResolver _subtypeResolver;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final ConfigOverrides _configOverrides;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final CoercionConfigs _coercionConfigs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected SimpleMixInResolver _mixIns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected SerializationConfig _serializationConfig;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DefaultSerializerProvider _serializerProvider;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected SerializerFactory _serializerFactory;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DeserializationConfig _deserializationConfig;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DefaultDeserializationContext _deserializationContext;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Set<Object> _registeredModuleTypes;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  536 */   protected final ConcurrentHashMap<JavaType, JsonDeserializer<Object>> _rootDeserializers = new ConcurrentHashMap(64, 0.6F, 2);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper()
/*      */   {
/*  558 */     this(null, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper(JsonFactory jf)
/*      */   {
/*  567 */     this(jf, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectMapper(ObjectMapper src)
/*      */   {
/*  577 */     this._jsonFactory = src._jsonFactory.copy();
/*  578 */     this._jsonFactory.setCodec(this);
/*  579 */     this._subtypeResolver = src._subtypeResolver.copy();
/*  580 */     this._typeFactory = src._typeFactory;
/*  581 */     this._injectableValues = src._injectableValues;
/*  582 */     this._configOverrides = src._configOverrides.copy();
/*  583 */     this._coercionConfigs = src._coercionConfigs.copy();
/*  584 */     this._mixIns = src._mixIns.copy();
/*      */     
/*  586 */     RootNameLookup rootNames = new RootNameLookup();
/*  587 */     this._serializationConfig = new SerializationConfig(src._serializationConfig, this._subtypeResolver, this._mixIns, rootNames, this._configOverrides);
/*      */     
/*  589 */     this._deserializationConfig = new DeserializationConfig(src._deserializationConfig, this._subtypeResolver, this._mixIns, rootNames, this._configOverrides, this._coercionConfigs);
/*      */     
/*      */ 
/*  592 */     this._serializerProvider = src._serializerProvider.copy();
/*  593 */     this._deserializationContext = src._deserializationContext.copy();
/*      */     
/*      */ 
/*  596 */     this._serializerFactory = src._serializerFactory;
/*      */     
/*      */ 
/*  599 */     Set<Object> reg = src._registeredModuleTypes;
/*  600 */     if (reg == null) {
/*  601 */       this._registeredModuleTypes = null;
/*      */     } else {
/*  603 */       this._registeredModuleTypes = new LinkedHashSet(reg);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper(JsonFactory jf, DefaultSerializerProvider sp, DefaultDeserializationContext dc)
/*      */   {
/*  624 */     if (jf == null) {
/*  625 */       this._jsonFactory = new MappingJsonFactory(this);
/*      */     } else {
/*  627 */       this._jsonFactory = jf;
/*  628 */       if (jf.getCodec() == null) {
/*  629 */         this._jsonFactory.setCodec(this);
/*      */       }
/*      */     }
/*  632 */     this._subtypeResolver = new StdSubtypeResolver();
/*  633 */     RootNameLookup rootNames = new RootNameLookup();
/*      */     
/*  635 */     this._typeFactory = TypeFactory.defaultInstance();
/*      */     
/*  637 */     SimpleMixInResolver mixins = new SimpleMixInResolver(null);
/*  638 */     this._mixIns = mixins;
/*  639 */     BaseSettings base = DEFAULT_BASE.withClassIntrospector(defaultClassIntrospector());
/*  640 */     this._configOverrides = new ConfigOverrides();
/*  641 */     this._coercionConfigs = new CoercionConfigs();
/*  642 */     this._serializationConfig = new SerializationConfig(base, this._subtypeResolver, mixins, rootNames, this._configOverrides);
/*      */     
/*  644 */     this._deserializationConfig = new DeserializationConfig(base, this._subtypeResolver, mixins, rootNames, this._configOverrides, this._coercionConfigs);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  649 */     boolean needOrder = this._jsonFactory.requiresPropertyOrdering();
/*  650 */     if ((needOrder ^ this._serializationConfig.isEnabled(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY))) {
/*  651 */       configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, needOrder);
/*      */     }
/*      */     
/*  654 */     this._serializerProvider = (sp == null ? new DefaultSerializerProvider.Impl() : sp);
/*  655 */     this._deserializationContext = (dc == null ? new DefaultDeserializationContext.Impl(BeanDeserializerFactory.instance) : dc);
/*      */     
/*      */ 
/*      */ 
/*  659 */     this._serializerFactory = BeanSerializerFactory.instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ClassIntrospector defaultClassIntrospector()
/*      */   {
/*  669 */     return new BasicClassIntrospector();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper copy()
/*      */   {
/*  694 */     _checkInvalidCopy(ObjectMapper.class);
/*  695 */     return new ObjectMapper(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _checkInvalidCopy(Class<?> exp)
/*      */   {
/*  703 */     if (getClass() != exp)
/*      */     {
/*      */ 
/*  706 */       throw new IllegalStateException("Failed copy(): " + getClass().getName() + " (version: " + version() + ") does not override copy(); it has to");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectReader _newReader(DeserializationConfig config)
/*      */   {
/*  724 */     return new ObjectReader(this, config);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectReader _newReader(DeserializationConfig config, JavaType valueType, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues)
/*      */   {
/*  736 */     return new ObjectReader(this, config, valueType, valueToUpdate, schema, injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectWriter _newWriter(SerializationConfig config)
/*      */   {
/*  746 */     return new ObjectWriter(this, config);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectWriter _newWriter(SerializationConfig config, FormatSchema schema)
/*      */   {
/*  756 */     return new ObjectWriter(this, config, schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectWriter _newWriter(SerializationConfig config, JavaType rootType, PrettyPrinter pp)
/*      */   {
/*  767 */     return new ObjectWriter(this, config, rootType, pp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Version version()
/*      */   {
/*  782 */     return PackageVersion.VERSION;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper registerModule(Module module)
/*      */   {
/*  800 */     _assertNotNull("module", module);
/*      */     
/*      */ 
/*      */ 
/*  804 */     String name = module.getModuleName();
/*  805 */     if (name == null) {
/*  806 */       throw new IllegalArgumentException("Module without defined name");
/*      */     }
/*  808 */     Version version = module.version();
/*  809 */     if (version == null) {
/*  810 */       throw new IllegalArgumentException("Module without defined version");
/*      */     }
/*      */     
/*      */ 
/*  814 */     for (Module dep : module.getDependencies()) {
/*  815 */       registerModule(dep);
/*      */     }
/*      */     
/*      */ 
/*  819 */     if (isEnabled(MapperFeature.IGNORE_DUPLICATE_MODULE_REGISTRATIONS)) {
/*  820 */       Object typeId = module.getTypeId();
/*  821 */       if (typeId != null) {
/*  822 */         if (this._registeredModuleTypes == null)
/*      */         {
/*      */ 
/*  825 */           this._registeredModuleTypes = new LinkedHashSet();
/*      */         }
/*      */         
/*  828 */         if (!this._registeredModuleTypes.add(typeId)) {
/*  829 */           return this;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  835 */     module.setupModule(new Module.SetupContext()
/*      */     {
/*      */ 
/*      */       public Version getMapperVersion()
/*      */       {
/*      */ 
/*  841 */         return ObjectMapper.this.version();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public <C extends ObjectCodec> C getOwner()
/*      */       {
/*  848 */         return ObjectMapper.this;
/*      */       }
/*      */       
/*      */       public TypeFactory getTypeFactory()
/*      */       {
/*  853 */         return ObjectMapper.this._typeFactory;
/*      */       }
/*      */       
/*      */       public boolean isEnabled(MapperFeature f)
/*      */       {
/*  858 */         return ObjectMapper.this.isEnabled(f);
/*      */       }
/*      */       
/*      */       public boolean isEnabled(DeserializationFeature f)
/*      */       {
/*  863 */         return ObjectMapper.this.isEnabled(f);
/*      */       }
/*      */       
/*      */       public boolean isEnabled(SerializationFeature f)
/*      */       {
/*  868 */         return ObjectMapper.this.isEnabled(f);
/*      */       }
/*      */       
/*      */       public boolean isEnabled(JsonFactory.Feature f)
/*      */       {
/*  873 */         return ObjectMapper.this.isEnabled(f);
/*      */       }
/*      */       
/*      */       public boolean isEnabled(JsonParser.Feature f)
/*      */       {
/*  878 */         return ObjectMapper.this.isEnabled(f);
/*      */       }
/*      */       
/*      */       public boolean isEnabled(JsonGenerator.Feature f)
/*      */       {
/*  883 */         return ObjectMapper.this.isEnabled(f);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public MutableConfigOverride configOverride(Class<?> type)
/*      */       {
/*  890 */         return ObjectMapper.this.configOverride(type);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void addDeserializers(Deserializers d)
/*      */       {
/*  897 */         DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withAdditionalDeserializers(d);
/*  898 */         ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */       }
/*      */       
/*      */       public void addKeyDeserializers(KeyDeserializers d)
/*      */       {
/*  903 */         DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withAdditionalKeyDeserializers(d);
/*  904 */         ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */       }
/*      */       
/*      */       public void addBeanDeserializerModifier(BeanDeserializerModifier modifier)
/*      */       {
/*  909 */         DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withDeserializerModifier(modifier);
/*  910 */         ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void addSerializers(Serializers s)
/*      */       {
/*  917 */         ObjectMapper.this._serializerFactory = ObjectMapper.this._serializerFactory.withAdditionalSerializers(s);
/*      */       }
/*      */       
/*      */       public void addKeySerializers(Serializers s)
/*      */       {
/*  922 */         ObjectMapper.this._serializerFactory = ObjectMapper.this._serializerFactory.withAdditionalKeySerializers(s);
/*      */       }
/*      */       
/*      */       public void addBeanSerializerModifier(BeanSerializerModifier modifier)
/*      */       {
/*  927 */         ObjectMapper.this._serializerFactory = ObjectMapper.this._serializerFactory.withSerializerModifier(modifier);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void addAbstractTypeResolver(AbstractTypeResolver resolver)
/*      */       {
/*  934 */         DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withAbstractTypeResolver(resolver);
/*  935 */         ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */       }
/*      */       
/*      */       public void addTypeModifier(TypeModifier modifier)
/*      */       {
/*  940 */         TypeFactory f = ObjectMapper.this._typeFactory;
/*  941 */         f = f.withModifier(modifier);
/*  942 */         ObjectMapper.this.setTypeFactory(f);
/*      */       }
/*      */       
/*      */       public void addValueInstantiators(ValueInstantiators instantiators)
/*      */       {
/*  947 */         DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withValueInstantiators(instantiators);
/*  948 */         ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */       }
/*      */       
/*      */       public void setClassIntrospector(ClassIntrospector ci)
/*      */       {
/*  953 */         ObjectMapper.this._deserializationConfig = ((DeserializationConfig)ObjectMapper.this._deserializationConfig.with(ci));
/*  954 */         ObjectMapper.this._serializationConfig = ((SerializationConfig)ObjectMapper.this._serializationConfig.with(ci));
/*      */       }
/*      */       
/*      */       public void insertAnnotationIntrospector(AnnotationIntrospector ai)
/*      */       {
/*  959 */         ObjectMapper.this._deserializationConfig = ((DeserializationConfig)ObjectMapper.this._deserializationConfig.withInsertedAnnotationIntrospector(ai));
/*  960 */         ObjectMapper.this._serializationConfig = ((SerializationConfig)ObjectMapper.this._serializationConfig.withInsertedAnnotationIntrospector(ai));
/*      */       }
/*      */       
/*      */       public void appendAnnotationIntrospector(AnnotationIntrospector ai)
/*      */       {
/*  965 */         ObjectMapper.this._deserializationConfig = ((DeserializationConfig)ObjectMapper.this._deserializationConfig.withAppendedAnnotationIntrospector(ai));
/*  966 */         ObjectMapper.this._serializationConfig = ((SerializationConfig)ObjectMapper.this._serializationConfig.withAppendedAnnotationIntrospector(ai));
/*      */       }
/*      */       
/*      */       public void registerSubtypes(Class<?>... subtypes)
/*      */       {
/*  971 */         ObjectMapper.this.registerSubtypes(subtypes);
/*      */       }
/*      */       
/*      */       public void registerSubtypes(NamedType... subtypes)
/*      */       {
/*  976 */         ObjectMapper.this.registerSubtypes(subtypes);
/*      */       }
/*      */       
/*      */       public void registerSubtypes(Collection<Class<?>> subtypes)
/*      */       {
/*  981 */         ObjectMapper.this.registerSubtypes(subtypes);
/*      */       }
/*      */       
/*      */       public void setMixInAnnotations(Class<?> target, Class<?> mixinSource)
/*      */       {
/*  986 */         ObjectMapper.this.addMixIn(target, mixinSource);
/*      */       }
/*      */       
/*      */       public void addDeserializationProblemHandler(DeserializationProblemHandler handler)
/*      */       {
/*  991 */         ObjectMapper.this.addHandler(handler);
/*      */       }
/*      */       
/*      */       public void setNamingStrategy(PropertyNamingStrategy naming)
/*      */       {
/*  996 */         ObjectMapper.this.setPropertyNamingStrategy(naming);
/*      */       }
/*      */       
/*  999 */     });
/* 1000 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper registerModules(Module... modules)
/*      */   {
/* 1016 */     for (Module module : modules) {
/* 1017 */       registerModule(module);
/*      */     }
/* 1019 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper registerModules(Iterable<? extends Module> modules)
/*      */   {
/* 1035 */     _assertNotNull("modules", modules);
/* 1036 */     for (Module module : modules) {
/* 1037 */       registerModule(module);
/*      */     }
/* 1039 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<Object> getRegisteredModuleIds()
/*      */   {
/* 1051 */     return this._registeredModuleTypes == null ? 
/* 1052 */       Collections.emptySet() : Collections.unmodifiableSet(this._registeredModuleTypes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List<Module> findModules()
/*      */   {
/* 1065 */     return findModules(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static List<Module> findModules(ClassLoader classLoader)
/*      */   {
/* 1079 */     ArrayList<Module> modules = new ArrayList();
/* 1080 */     ServiceLoader<Module> loader = secureGetServiceLoader(Module.class, classLoader);
/* 1081 */     for (Module module : loader) {
/* 1082 */       modules.add(module);
/*      */     }
/* 1084 */     return modules;
/*      */   }
/*      */   
/*      */   private static <T> ServiceLoader<T> secureGetServiceLoader(final Class<T> clazz, ClassLoader classLoader) {
/* 1088 */     SecurityManager sm = System.getSecurityManager();
/* 1089 */     if (sm == null) {
/* 1090 */       return classLoader == null ? 
/* 1091 */         ServiceLoader.load(clazz) : ServiceLoader.load(clazz, classLoader);
/*      */     }
/* 1093 */     (ServiceLoader)AccessController.doPrivileged(new PrivilegedAction()
/*      */     {
/*      */       public ServiceLoader<T> run() {
/* 1096 */         return this.val$classLoader == null ? 
/* 1097 */           ServiceLoader.load(clazz) : ServiceLoader.load(clazz, this.val$classLoader);
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper findAndRegisterModules()
/*      */   {
/* 1115 */     return registerModules(findModules());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(OutputStream out)
/*      */     throws IOException
/*      */   {
/* 1133 */     _assertNotNull("out", out);
/* 1134 */     JsonGenerator g = this._jsonFactory.createGenerator(out, JsonEncoding.UTF8);
/* 1135 */     this._serializationConfig.initialize(g);
/* 1136 */     return g;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(OutputStream out, JsonEncoding enc)
/*      */     throws IOException
/*      */   {
/* 1148 */     _assertNotNull("out", out);
/* 1149 */     JsonGenerator g = this._jsonFactory.createGenerator(out, enc);
/* 1150 */     this._serializationConfig.initialize(g);
/* 1151 */     return g;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(Writer w)
/*      */     throws IOException
/*      */   {
/* 1163 */     _assertNotNull("w", w);
/* 1164 */     JsonGenerator g = this._jsonFactory.createGenerator(w);
/* 1165 */     this._serializationConfig.initialize(g);
/* 1166 */     return g;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(File outputFile, JsonEncoding enc)
/*      */     throws IOException
/*      */   {
/* 1178 */     _assertNotNull("outputFile", outputFile);
/* 1179 */     JsonGenerator g = this._jsonFactory.createGenerator(outputFile, enc);
/* 1180 */     this._serializationConfig.initialize(g);
/* 1181 */     return g;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator createGenerator(DataOutput out)
/*      */     throws IOException
/*      */   {
/* 1193 */     _assertNotNull("out", out);
/* 1194 */     JsonGenerator g = this._jsonFactory.createGenerator(out);
/* 1195 */     this._serializationConfig.initialize(g);
/* 1196 */     return g;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(File src)
/*      */     throws IOException
/*      */   {
/* 1214 */     _assertNotNull("src", src);
/* 1215 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(src));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(URL src)
/*      */     throws IOException
/*      */   {
/* 1227 */     _assertNotNull("src", src);
/* 1228 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(src));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(InputStream in)
/*      */     throws IOException
/*      */   {
/* 1240 */     _assertNotNull("in", in);
/* 1241 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(in));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(Reader r)
/*      */     throws IOException
/*      */   {
/* 1253 */     _assertNotNull("r", r);
/* 1254 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(r));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(byte[] content)
/*      */     throws IOException
/*      */   {
/* 1266 */     _assertNotNull("content", content);
/* 1267 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(byte[] content, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 1279 */     _assertNotNull("content", content);
/* 1280 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content, offset, len));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(String content)
/*      */     throws IOException
/*      */   {
/* 1292 */     _assertNotNull("content", content);
/* 1293 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(char[] content)
/*      */     throws IOException
/*      */   {
/* 1305 */     _assertNotNull("content", content);
/* 1306 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(char[] content, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 1318 */     _assertNotNull("content", content);
/* 1319 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content, offset, len));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createParser(DataInput content)
/*      */     throws IOException
/*      */   {
/* 1331 */     _assertNotNull("content", content);
/* 1332 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser createNonBlockingByteArrayParser()
/*      */     throws IOException
/*      */   {
/* 1344 */     return this._deserializationConfig.initialize(this._jsonFactory.createNonBlockingByteArrayParser());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SerializationConfig getSerializationConfig()
/*      */   {
/* 1362 */     return this._serializationConfig;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DeserializationConfig getDeserializationConfig()
/*      */   {
/* 1375 */     return this._deserializationConfig;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DeserializationContext getDeserializationContext()
/*      */   {
/* 1386 */     return this._deserializationContext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setSerializerFactory(SerializerFactory f)
/*      */   {
/* 1400 */     this._serializerFactory = f;
/* 1401 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SerializerFactory getSerializerFactory()
/*      */   {
/* 1412 */     return this._serializerFactory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setSerializerProvider(DefaultSerializerProvider p)
/*      */   {
/* 1421 */     this._serializerProvider = p;
/* 1422 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SerializerProvider getSerializerProvider()
/*      */   {
/* 1433 */     return this._serializerProvider;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SerializerProvider getSerializerProviderInstance()
/*      */   {
/* 1445 */     return _serializerProvider(this._serializationConfig);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setMixIns(Map<Class<?>, Class<?>> sourceMixins)
/*      */   {
/* 1474 */     this._mixIns.setLocalDefinitions(sourceMixins);
/* 1475 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper addMixIn(Class<?> target, Class<?> mixinSource)
/*      */   {
/* 1492 */     this._mixIns.addLocalDefinition(target, mixinSource);
/* 1493 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setMixInResolver(ClassIntrospector.MixInResolver resolver)
/*      */   {
/* 1506 */     SimpleMixInResolver r = this._mixIns.withOverrides(resolver);
/* 1507 */     if (r != this._mixIns) {
/* 1508 */       this._mixIns = r;
/* 1509 */       this._deserializationConfig = new DeserializationConfig(this._deserializationConfig, r);
/* 1510 */       this._serializationConfig = new SerializationConfig(this._serializationConfig, r);
/*      */     }
/* 1512 */     return this;
/*      */   }
/*      */   
/*      */   public Class<?> findMixInClassFor(Class<?> cls) {
/* 1516 */     return this._mixIns.findMixInClassFor(cls);
/*      */   }
/*      */   
/*      */   public int mixInCount()
/*      */   {
/* 1521 */     return this._mixIns.localSize();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setMixInAnnotations(Map<Class<?>, Class<?>> sourceMixins)
/*      */   {
/* 1529 */     setMixIns(sourceMixins);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final void addMixInAnnotations(Class<?> target, Class<?> mixinSource)
/*      */   {
/* 1537 */     addMixIn(target, mixinSource);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public VisibilityChecker<?> getVisibilityChecker()
/*      */   {
/* 1552 */     return this._serializationConfig.getDefaultVisibilityChecker();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setVisibility(VisibilityChecker<?> vc)
/*      */   {
/* 1566 */     this._configOverrides.setDefaultVisibility(vc);
/* 1567 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setVisibility(PropertyAccessor forMethod, JsonAutoDetect.Visibility visibility)
/*      */   {
/* 1596 */     VisibilityChecker<?> vc = this._configOverrides.getDefaultVisibility();
/* 1597 */     vc = vc.withVisibility(forMethod, visibility);
/* 1598 */     this._configOverrides.setDefaultVisibility(vc);
/* 1599 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public SubtypeResolver getSubtypeResolver()
/*      */   {
/* 1606 */     return this._subtypeResolver;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectMapper setSubtypeResolver(SubtypeResolver str)
/*      */   {
/* 1613 */     this._subtypeResolver = str;
/* 1614 */     this._deserializationConfig = this._deserializationConfig.with(str);
/* 1615 */     this._serializationConfig = this._serializationConfig.with(str);
/* 1616 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setAnnotationIntrospector(AnnotationIntrospector ai)
/*      */   {
/* 1630 */     this._serializationConfig = ((SerializationConfig)this._serializationConfig.with(ai));
/* 1631 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.with(ai));
/* 1632 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setAnnotationIntrospectors(AnnotationIntrospector serializerAI, AnnotationIntrospector deserializerAI)
/*      */   {
/* 1652 */     this._serializationConfig = ((SerializationConfig)this._serializationConfig.with(serializerAI));
/* 1653 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.with(deserializerAI));
/* 1654 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectMapper setPropertyNamingStrategy(PropertyNamingStrategy s)
/*      */   {
/* 1661 */     this._serializationConfig = ((SerializationConfig)this._serializationConfig.with(s));
/* 1662 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.with(s));
/* 1663 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public PropertyNamingStrategy getPropertyNamingStrategy()
/*      */   {
/* 1671 */     return this._serializationConfig.getPropertyNamingStrategy();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setAccessorNaming(AccessorNamingStrategy.Provider s)
/*      */   {
/* 1680 */     this._serializationConfig = ((SerializationConfig)this._serializationConfig.with(s));
/* 1681 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.with(s));
/* 1682 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setDefaultPrettyPrinter(PrettyPrinter pp)
/*      */   {
/* 1696 */     this._serializationConfig = this._serializationConfig.withDefaultPrettyPrinter(pp);
/* 1697 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setVisibilityChecker(VisibilityChecker<?> vc)
/*      */   {
/* 1705 */     setVisibility(vc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setPolymorphicTypeValidator(PolymorphicTypeValidator ptv)
/*      */   {
/* 1717 */     BaseSettings s = this._deserializationConfig.getBaseSettings().with(ptv);
/* 1718 */     this._deserializationConfig = this._deserializationConfig._withBase(s);
/* 1719 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PolymorphicTypeValidator getPolymorphicTypeValidator()
/*      */   {
/* 1731 */     return this._deserializationConfig.getBaseSettings().getPolymorphicTypeValidator();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setSerializationInclusion(JsonInclude.Include incl)
/*      */   {
/* 1750 */     setPropertyInclusion(JsonInclude.Value.construct(incl, incl));
/* 1751 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectMapper setPropertyInclusion(JsonInclude.Value incl)
/*      */   {
/* 1760 */     return setDefaultPropertyInclusion(incl);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setDefaultPropertyInclusion(JsonInclude.Value incl)
/*      */   {
/* 1771 */     this._configOverrides.setDefaultInclusion(incl);
/* 1772 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setDefaultPropertyInclusion(JsonInclude.Include incl)
/*      */   {
/* 1784 */     this._configOverrides.setDefaultInclusion(JsonInclude.Value.construct(incl, incl));
/* 1785 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setDefaultSetterInfo(JsonSetter.Value v)
/*      */   {
/* 1796 */     this._configOverrides.setDefaultSetterInfo(v);
/* 1797 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setDefaultVisibility(JsonAutoDetect.Value vis)
/*      */   {
/* 1809 */     this._configOverrides.setDefaultVisibility(VisibilityChecker.Std.construct(vis));
/* 1810 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setDefaultMergeable(Boolean b)
/*      */   {
/* 1821 */     this._configOverrides.setDefaultMergeable(b);
/* 1822 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectMapper setDefaultLeniency(Boolean b)
/*      */   {
/* 1829 */     this._configOverrides.setDefaultLeniency(b);
/* 1830 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerSubtypes(Class<?>... classes)
/*      */   {
/* 1847 */     getSubtypeResolver().registerSubtypes(classes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void registerSubtypes(NamedType... types)
/*      */   {
/* 1859 */     getSubtypeResolver().registerSubtypes(types);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void registerSubtypes(Collection<Class<?>> subtypes)
/*      */   {
/* 1866 */     getSubtypeResolver().registerSubtypes(subtypes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper activateDefaultTyping(PolymorphicTypeValidator ptv)
/*      */   {
/* 1890 */     return activateDefaultTyping(ptv, DefaultTyping.OBJECT_AND_NON_CONCRETE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper activateDefaultTyping(PolymorphicTypeValidator ptv, DefaultTyping applicability)
/*      */   {
/* 1911 */     return activateDefaultTyping(ptv, applicability, JsonTypeInfo.As.WRAPPER_ARRAY);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper activateDefaultTyping(PolymorphicTypeValidator ptv, DefaultTyping applicability, JsonTypeInfo.As includeAs)
/*      */   {
/* 1939 */     if (includeAs == JsonTypeInfo.As.EXTERNAL_PROPERTY) {
/* 1940 */       throw new IllegalArgumentException("Cannot use includeAs of " + includeAs);
/*      */     }
/*      */     
/* 1943 */     TypeResolverBuilder<?> typer = _constructDefaultTypeResolverBuilder(applicability, ptv);
/*      */     
/* 1945 */     typer = typer.init(JsonTypeInfo.Id.CLASS, null);
/* 1946 */     typer = typer.inclusion(includeAs);
/* 1947 */     return setDefaultTyping(typer);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper activateDefaultTypingAsProperty(PolymorphicTypeValidator ptv, DefaultTyping applicability, String propertyName)
/*      */   {
/* 1972 */     TypeResolverBuilder<?> typer = _constructDefaultTypeResolverBuilder(applicability, ptv);
/*      */     
/*      */ 
/* 1975 */     typer = typer.init(JsonTypeInfo.Id.CLASS, null);
/* 1976 */     typer = typer.inclusion(JsonTypeInfo.As.PROPERTY);
/* 1977 */     typer = typer.typeProperty(propertyName);
/* 1978 */     return setDefaultTyping(typer);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper deactivateDefaultTyping()
/*      */   {
/* 1990 */     return setDefaultTyping(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setDefaultTyping(TypeResolverBuilder<?> typer)
/*      */   {
/* 2009 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.with(typer));
/* 2010 */     this._serializationConfig = ((SerializationConfig)this._serializationConfig.with(typer));
/* 2011 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectMapper enableDefaultTyping()
/*      */   {
/* 2025 */     return activateDefaultTyping(getPolymorphicTypeValidator());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectMapper enableDefaultTyping(DefaultTyping dti)
/*      */   {
/* 2033 */     return enableDefaultTyping(dti, JsonTypeInfo.As.WRAPPER_ARRAY);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectMapper enableDefaultTyping(DefaultTyping applicability, JsonTypeInfo.As includeAs)
/*      */   {
/* 2041 */     return activateDefaultTyping(getPolymorphicTypeValidator(), applicability, includeAs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectMapper enableDefaultTypingAsProperty(DefaultTyping applicability, String propertyName)
/*      */   {
/* 2049 */     return activateDefaultTypingAsProperty(getPolymorphicTypeValidator(), applicability, propertyName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectMapper disableDefaultTyping()
/*      */   {
/* 2057 */     return setDefaultTyping(null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MutableConfigOverride configOverride(Class<?> type)
/*      */   {
/* 2084 */     return this._configOverrides.findOrCreateOverride(type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MutableCoercionConfig coercionConfigDefaults()
/*      */   {
/* 2103 */     return this._coercionConfigs.defaultCoercions();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MutableCoercionConfig coercionConfigFor(LogicalType logicalType)
/*      */   {
/* 2113 */     return this._coercionConfigs.findOrCreateCoercion(logicalType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MutableCoercionConfig coercionConfigFor(Class<?> physicalType)
/*      */   {
/* 2123 */     return this._coercionConfigs.findOrCreateCoercion(physicalType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TypeFactory getTypeFactory()
/*      */   {
/* 2136 */     return this._typeFactory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setTypeFactory(TypeFactory f)
/*      */   {
/* 2148 */     this._typeFactory = f;
/* 2149 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.with(f));
/* 2150 */     this._serializationConfig = ((SerializationConfig)this._serializationConfig.with(f));
/* 2151 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JavaType constructType(Type t)
/*      */   {
/* 2160 */     _assertNotNull("t", t);
/* 2161 */     return this._typeFactory.constructType(t);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JavaType constructType(TypeReference<?> typeRef)
/*      */   {
/* 2171 */     _assertNotNull("typeRef", typeRef);
/* 2172 */     return this._typeFactory.constructType(typeRef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonNodeFactory getNodeFactory()
/*      */   {
/* 2192 */     return this._deserializationConfig.getNodeFactory();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setNodeFactory(JsonNodeFactory f)
/*      */   {
/* 2201 */     this._deserializationConfig = this._deserializationConfig.with(f);
/* 2202 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setConstructorDetector(ConstructorDetector cd)
/*      */   {
/* 2214 */     this._deserializationConfig = this._deserializationConfig.with(cd);
/* 2215 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper addHandler(DeserializationProblemHandler h)
/*      */   {
/* 2223 */     this._deserializationConfig = this._deserializationConfig.withHandler(h);
/* 2224 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper clearProblemHandlers()
/*      */   {
/* 2232 */     this._deserializationConfig = this._deserializationConfig.withNoProblemHandlers();
/* 2233 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setConfig(DeserializationConfig config)
/*      */   {
/* 2251 */     _assertNotNull("config", config);
/* 2252 */     this._deserializationConfig = config;
/* 2253 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setFilters(FilterProvider filterProvider)
/*      */   {
/* 2267 */     this._serializationConfig = this._serializationConfig.withFilters(filterProvider);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setFilterProvider(FilterProvider filterProvider)
/*      */   {
/* 2282 */     this._serializationConfig = this._serializationConfig.withFilters(filterProvider);
/* 2283 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setBase64Variant(Base64Variant v)
/*      */   {
/* 2297 */     this._serializationConfig = ((SerializationConfig)this._serializationConfig.with(v));
/* 2298 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.with(v));
/* 2299 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setConfig(SerializationConfig config)
/*      */   {
/* 2317 */     _assertNotNull("config", config);
/* 2318 */     this._serializationConfig = config;
/* 2319 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonFactory tokenStreamFactory()
/*      */   {
/* 2347 */     return this._jsonFactory;
/*      */   }
/*      */   
/* 2350 */   public JsonFactory getFactory() { return this._jsonFactory; }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonFactory getJsonFactory()
/*      */   {
/* 2357 */     return getFactory();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setDateFormat(DateFormat dateFormat)
/*      */   {
/* 2371 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.with(dateFormat));
/* 2372 */     this._serializationConfig = this._serializationConfig.with(dateFormat);
/* 2373 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public DateFormat getDateFormat()
/*      */   {
/* 2381 */     return this._serializationConfig.getDateFormat();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object setHandlerInstantiator(HandlerInstantiator hi)
/*      */   {
/* 2393 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.with(hi));
/* 2394 */     this._serializationConfig = ((SerializationConfig)this._serializationConfig.with(hi));
/* 2395 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setInjectableValues(InjectableValues injectableValues)
/*      */   {
/* 2403 */     this._injectableValues = injectableValues;
/* 2404 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public InjectableValues getInjectableValues()
/*      */   {
/* 2411 */     return this._injectableValues;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setLocale(Locale l)
/*      */   {
/* 2419 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.with(l));
/* 2420 */     this._serializationConfig = ((SerializationConfig)this._serializationConfig.with(l));
/* 2421 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper setTimeZone(TimeZone tz)
/*      */   {
/* 2429 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.with(tz));
/* 2430 */     this._serializationConfig = ((SerializationConfig)this._serializationConfig.with(tz));
/* 2431 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(MapperFeature f)
/*      */   {
/* 2445 */     return this._serializationConfig.isEnabled(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper configure(MapperFeature f, boolean state)
/*      */   {
/* 2453 */     this._serializationConfig = (state ? (SerializationConfig)this._serializationConfig.with(new MapperFeature[] { f }) : (SerializationConfig)this._serializationConfig.without(new MapperFeature[] { f }));
/*      */     
/* 2455 */     this._deserializationConfig = (state ? (DeserializationConfig)this._deserializationConfig.with(new MapperFeature[] { f }) : (DeserializationConfig)this._deserializationConfig.without(new MapperFeature[] { f }));
/* 2456 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectMapper enable(MapperFeature... f)
/*      */   {
/* 2463 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.with(f));
/* 2464 */     this._serializationConfig = ((SerializationConfig)this._serializationConfig.with(f));
/* 2465 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectMapper disable(MapperFeature... f)
/*      */   {
/* 2472 */     this._deserializationConfig = ((DeserializationConfig)this._deserializationConfig.without(f));
/* 2473 */     this._serializationConfig = ((SerializationConfig)this._serializationConfig.without(f));
/* 2474 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(SerializationFeature f)
/*      */   {
/* 2488 */     return this._serializationConfig.isEnabled(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper configure(SerializationFeature f, boolean state)
/*      */   {
/* 2497 */     this._serializationConfig = (state ? this._serializationConfig.with(f) : this._serializationConfig.without(f));
/* 2498 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper enable(SerializationFeature f)
/*      */   {
/* 2506 */     this._serializationConfig = this._serializationConfig.with(f);
/* 2507 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper enable(SerializationFeature first, SerializationFeature... f)
/*      */   {
/* 2516 */     this._serializationConfig = this._serializationConfig.with(first, f);
/* 2517 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper disable(SerializationFeature f)
/*      */   {
/* 2525 */     this._serializationConfig = this._serializationConfig.without(f);
/* 2526 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper disable(SerializationFeature first, SerializationFeature... f)
/*      */   {
/* 2535 */     this._serializationConfig = this._serializationConfig.without(first, f);
/* 2536 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(DeserializationFeature f)
/*      */   {
/* 2550 */     return this._deserializationConfig.isEnabled(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper configure(DeserializationFeature f, boolean state)
/*      */   {
/* 2559 */     this._deserializationConfig = (state ? this._deserializationConfig.with(f) : this._deserializationConfig.without(f));
/* 2560 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper enable(DeserializationFeature feature)
/*      */   {
/* 2568 */     this._deserializationConfig = this._deserializationConfig.with(feature);
/* 2569 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper enable(DeserializationFeature first, DeserializationFeature... f)
/*      */   {
/* 2578 */     this._deserializationConfig = this._deserializationConfig.with(first, f);
/* 2579 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper disable(DeserializationFeature feature)
/*      */   {
/* 2587 */     this._deserializationConfig = this._deserializationConfig.without(feature);
/* 2588 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper disable(DeserializationFeature first, DeserializationFeature... f)
/*      */   {
/* 2597 */     this._deserializationConfig = this._deserializationConfig.without(first, f);
/* 2598 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(JsonParser.Feature f)
/*      */   {
/* 2608 */     return this._deserializationConfig.isEnabled(f, this._jsonFactory);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper configure(JsonParser.Feature f, boolean state)
/*      */   {
/* 2623 */     this._jsonFactory.configure(f, state);
/* 2624 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper enable(JsonParser.Feature... features)
/*      */   {
/* 2640 */     for (JsonParser.Feature f : features) {
/* 2641 */       this._jsonFactory.enable(f);
/*      */     }
/* 2643 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper disable(JsonParser.Feature... features)
/*      */   {
/* 2659 */     for (JsonParser.Feature f : features) {
/* 2660 */       this._jsonFactory.disable(f);
/*      */     }
/* 2662 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(JsonGenerator.Feature f)
/*      */   {
/* 2672 */     return this._serializationConfig.isEnabled(f, this._jsonFactory);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper configure(JsonGenerator.Feature f, boolean state)
/*      */   {
/* 2687 */     this._jsonFactory.configure(f, state);
/* 2688 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper enable(JsonGenerator.Feature... features)
/*      */   {
/* 2704 */     for (JsonGenerator.Feature f : features) {
/* 2705 */       this._jsonFactory.enable(f);
/*      */     }
/* 2707 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectMapper disable(JsonGenerator.Feature... features)
/*      */   {
/* 2723 */     for (JsonGenerator.Feature f : features) {
/* 2724 */       this._jsonFactory.disable(f);
/*      */     }
/* 2726 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(JsonFactory.Feature f)
/*      */   {
/* 2742 */     return this._jsonFactory.isEnabled(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(StreamReadFeature f)
/*      */   {
/* 2755 */     return isEnabled(f.mappedFeature());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(StreamWriteFeature f)
/*      */   {
/* 2762 */     return isEnabled(f.mappedFeature());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(JsonParser p, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 2797 */     _assertNotNull("p", p);
/* 2798 */     return (T)_readValue(getDeserializationConfig(), p, this._typeFactory.constructType(valueType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(JsonParser p, TypeReference<T> valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 2822 */     _assertNotNull("p", p);
/* 2823 */     return (T)_readValue(getDeserializationConfig(), p, this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final <T> T readValue(JsonParser p, ResolvedType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 2846 */     _assertNotNull("p", p);
/* 2847 */     return (T)_readValue(getDeserializationConfig(), p, (JavaType)valueType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(JsonParser p, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 2866 */     _assertNotNull("p", p);
/* 2867 */     return (T)_readValue(getDeserializationConfig(), p, valueType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T extends TreeNode> T readTree(JsonParser p)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 2897 */     _assertNotNull("p", p);
/*      */     
/* 2899 */     DeserializationConfig cfg = getDeserializationConfig();
/* 2900 */     JsonToken t = p.currentToken();
/* 2901 */     if (t == null) {
/* 2902 */       t = p.nextToken();
/* 2903 */       if (t == null) {
/* 2904 */         return null;
/*      */       }
/*      */     }
/*      */     
/* 2908 */     JsonNode n = (JsonNode)_readValue(cfg, p, constructType(JsonNode.class));
/* 2909 */     if (n == null) {
/* 2910 */       n = getNodeFactory().nullNode();
/*      */     }
/*      */     
/* 2913 */     T result = n;
/* 2914 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(JsonParser p, ResolvedType valueType)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 2939 */     return readValues(p, (JavaType)valueType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(JsonParser p, JavaType valueType)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 2953 */     _assertNotNull("p", p);
/* 2954 */     DeserializationConfig config = getDeserializationConfig();
/* 2955 */     DeserializationContext ctxt = createDeserializationContext(p, config);
/* 2956 */     JsonDeserializer<?> deser = _findRootDeserializer(ctxt, valueType);
/*      */     
/* 2958 */     return new MappingIterator(valueType, p, ctxt, deser, false, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(JsonParser p, Class<T> valueType)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 2974 */     return readValues(p, this._typeFactory.constructType(valueType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> MappingIterator<T> readValues(JsonParser p, TypeReference<T> valueTypeRef)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 2984 */     return readValues(p, this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(InputStream in)
/*      */     throws IOException
/*      */   {
/* 3022 */     _assertNotNull("in", in);
/* 3023 */     return _readTreeAndClose(this._jsonFactory.createParser(in));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(Reader r)
/*      */     throws IOException
/*      */   {
/* 3031 */     _assertNotNull("r", r);
/* 3032 */     return _readTreeAndClose(this._jsonFactory.createParser(r));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(String content)
/*      */     throws JsonProcessingException, JsonMappingException
/*      */   {
/* 3040 */     _assertNotNull("content", content);
/*      */     try {
/* 3042 */       return _readTreeAndClose(this._jsonFactory.createParser(content));
/*      */     } catch (JsonProcessingException e) {
/* 3044 */       throw e;
/*      */     } catch (IOException e) {
/* 3046 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(byte[] content)
/*      */     throws IOException
/*      */   {
/* 3055 */     _assertNotNull("content", content);
/* 3056 */     return _readTreeAndClose(this._jsonFactory.createParser(content));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(byte[] content, int offset, int len)
/*      */     throws IOException
/*      */   {
/* 3064 */     _assertNotNull("content", content);
/* 3065 */     return _readTreeAndClose(this._jsonFactory.createParser(content, offset, len));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(File file)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 3075 */     _assertNotNull("file", file);
/* 3076 */     return _readTreeAndClose(this._jsonFactory.createParser(file));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonNode readTree(URL source)
/*      */     throws IOException
/*      */   {
/* 3090 */     _assertNotNull("source", source);
/* 3091 */     return _readTreeAndClose(this._jsonFactory.createParser(source));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeValue(JsonGenerator g, Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 3109 */     _assertNotNull("g", g);
/* 3110 */     SerializationConfig config = getSerializationConfig();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3118 */     if ((config.isEnabled(SerializationFeature.INDENT_OUTPUT)) && 
/* 3119 */       (g.getPrettyPrinter() == null)) {
/* 3120 */       g.setPrettyPrinter(config.constructDefaultPrettyPrinter());
/*      */     }
/*      */     
/* 3123 */     if ((config.isEnabled(SerializationFeature.CLOSE_CLOSEABLE)) && ((value instanceof Closeable))) {
/* 3124 */       _writeCloseableValue(g, value, config);
/*      */     } else {
/* 3126 */       _serializerProvider(config).serializeValue(g, value);
/* 3127 */       if (config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 3128 */         g.flush();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeTree(JsonGenerator g, TreeNode rootNode)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 3143 */     _assertNotNull("g", g);
/* 3144 */     SerializationConfig config = getSerializationConfig();
/* 3145 */     _serializerProvider(config).serializeValue(g, rootNode);
/* 3146 */     if (config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 3147 */       g.flush();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeTree(JsonGenerator g, JsonNode rootNode)
/*      */     throws IOException, JsonProcessingException
/*      */   {
/* 3158 */     _assertNotNull("g", g);
/* 3159 */     SerializationConfig config = getSerializationConfig();
/* 3160 */     _serializerProvider(config).serializeValue(g, rootNode);
/* 3161 */     if (config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 3162 */       g.flush();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectNode createObjectNode()
/*      */   {
/* 3175 */     return this._deserializationConfig.getNodeFactory().objectNode();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ArrayNode createArrayNode()
/*      */   {
/* 3187 */     return this._deserializationConfig.getNodeFactory().arrayNode();
/*      */   }
/*      */   
/*      */   public JsonNode missingNode()
/*      */   {
/* 3192 */     return this._deserializationConfig.getNodeFactory().missingNode();
/*      */   }
/*      */   
/*      */   public JsonNode nullNode()
/*      */   {
/* 3197 */     return this._deserializationConfig.getNodeFactory().nullNode();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser treeAsTokens(TreeNode n)
/*      */   {
/* 3208 */     _assertNotNull("n", n);
/* 3209 */     return new TreeTraversingParser((JsonNode)n, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T treeToValue(TreeNode n, Class<T> valueType)
/*      */     throws IllegalArgumentException, JsonProcessingException
/*      */   {
/* 3234 */     if (n == null) {
/* 3235 */       return null;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 3240 */       if ((TreeNode.class.isAssignableFrom(valueType)) && 
/* 3241 */         (valueType.isAssignableFrom(n.getClass()))) {
/* 3242 */         return n;
/*      */       }
/* 3244 */       JsonToken tt = n.asToken();
/*      */       
/*      */ 
/* 3247 */       if ((tt == JsonToken.VALUE_EMBEDDED_OBJECT) && 
/* 3248 */         ((n instanceof POJONode))) {
/* 3249 */         Object ob = ((POJONode)n).getPojo();
/* 3250 */         if ((ob == null) || (valueType.isInstance(ob))) {
/* 3251 */           return (T)ob;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3261 */       return (T)readValue(treeAsTokens(n), valueType);
/*      */     }
/*      */     catch (JsonProcessingException e)
/*      */     {
/* 3265 */       throw e;
/*      */     } catch (IOException e) {
/* 3267 */       throw new IllegalArgumentException(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T extends JsonNode> T valueToTree(Object fromValue)
/*      */     throws IllegalArgumentException
/*      */   {
/* 3298 */     if (fromValue == null) {
/* 3299 */       return getNodeFactory().nullNode();
/*      */     }
/* 3301 */     TokenBuffer buf = new TokenBuffer(this, false);
/* 3302 */     if (isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 3303 */       buf = buf.forceUseOfBigDecimal(true);
/*      */     }
/*      */     try
/*      */     {
/* 3307 */       writeValue(buf, fromValue);
/* 3308 */       JsonParser p = buf.asParser();
/* 3309 */       JsonNode result = (JsonNode)readTree(p);
/* 3310 */       p.close();
/*      */     } catch (IOException e) {
/* 3312 */       throw new IllegalArgumentException(e.getMessage(), e); }
/*      */     JsonNode result;
/* 3314 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canSerialize(Class<?> type)
/*      */   {
/* 3339 */     return _serializerProvider(getSerializationConfig()).hasSerializerFor(type, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canSerialize(Class<?> type, AtomicReference<Throwable> cause)
/*      */   {
/* 3350 */     return _serializerProvider(getSerializationConfig()).hasSerializerFor(type, cause);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canDeserialize(JavaType type)
/*      */   {
/* 3372 */     return 
/* 3373 */       createDeserializationContext(null, getDeserializationConfig()).hasValueDeserializerFor(type, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canDeserialize(JavaType type, AtomicReference<Throwable> cause)
/*      */   {
/* 3385 */     return 
/* 3386 */       createDeserializationContext(null, getDeserializationConfig()).hasValueDeserializerFor(type, cause);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(File src, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3412 */     _assertNotNull("src", src);
/* 3413 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(File src, TypeReference<T> valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3432 */     _assertNotNull("src", src);
/* 3433 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(File src, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3452 */     _assertNotNull("src", src);
/* 3453 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(URL src, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3478 */     _assertNotNull("src", src);
/* 3479 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(URL src, TypeReference<T> valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3489 */     _assertNotNull("src", src);
/* 3490 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(URL src, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3500 */     _assertNotNull("src", src);
/* 3501 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(String content, Class<T> valueType)
/*      */     throws JsonProcessingException, JsonMappingException
/*      */   {
/* 3515 */     _assertNotNull("content", content);
/* 3516 */     return (T)readValue(content, this._typeFactory.constructType(valueType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(String content, TypeReference<T> valueTypeRef)
/*      */     throws JsonProcessingException, JsonMappingException
/*      */   {
/* 3530 */     _assertNotNull("content", content);
/* 3531 */     return (T)readValue(content, this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T readValue(String content, JavaType valueType)
/*      */     throws JsonProcessingException, JsonMappingException
/*      */   {
/* 3546 */     _assertNotNull("content", content);
/*      */     try {
/* 3548 */       return (T)_readMapAndClose(this._jsonFactory.createParser(content), valueType);
/*      */     } catch (JsonProcessingException e) {
/* 3550 */       throw e;
/*      */     } catch (IOException e) {
/* 3552 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> T readValue(Reader src, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3560 */     _assertNotNull("src", src);
/* 3561 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> T readValue(Reader src, TypeReference<T> valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3568 */     _assertNotNull("src", src);
/* 3569 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> T readValue(Reader src, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3576 */     _assertNotNull("src", src);
/* 3577 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> T readValue(InputStream src, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3584 */     _assertNotNull("src", src);
/* 3585 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> T readValue(InputStream src, TypeReference<T> valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3592 */     _assertNotNull("src", src);
/* 3593 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> T readValue(InputStream src, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3600 */     _assertNotNull("src", src);
/* 3601 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> T readValue(byte[] src, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3608 */     _assertNotNull("src", src);
/* 3609 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> T readValue(byte[] src, int offset, int len, Class<T> valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3617 */     _assertNotNull("src", src);
/* 3618 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src, offset, len), this._typeFactory.constructType(valueType));
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> T readValue(byte[] src, TypeReference<T> valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3625 */     _assertNotNull("src", src);
/* 3626 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> T readValue(byte[] src, int offset, int len, TypeReference<T> valueTypeRef)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3634 */     _assertNotNull("src", src);
/* 3635 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src, offset, len), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */   
/*      */ 
/*      */   public <T> T readValue(byte[] src, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3642 */     _assertNotNull("src", src);
/* 3643 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> T readValue(byte[] src, int offset, int len, JavaType valueType)
/*      */     throws IOException, JsonParseException, JsonMappingException
/*      */   {
/* 3651 */     _assertNotNull("src", src);
/* 3652 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src, offset, len), valueType);
/*      */   }
/*      */   
/*      */   public <T> T readValue(DataInput src, Class<T> valueType)
/*      */     throws IOException
/*      */   {
/* 3658 */     _assertNotNull("src", src);
/* 3659 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory
/* 3660 */       .constructType(valueType));
/*      */   }
/*      */   
/*      */   public <T> T readValue(DataInput src, JavaType valueType)
/*      */     throws IOException
/*      */   {
/* 3666 */     _assertNotNull("src", src);
/* 3667 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeValue(File resultFile, Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 3684 */     _writeValueAndClose(createGenerator(resultFile, JsonEncoding.UTF8), value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeValue(OutputStream out, Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 3701 */     _writeValueAndClose(createGenerator(out, JsonEncoding.UTF8), value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void writeValue(DataOutput out, Object value)
/*      */     throws IOException
/*      */   {
/* 3709 */     _writeValueAndClose(createGenerator(out), value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeValue(Writer w, Object value)
/*      */     throws IOException, JsonGenerationException, JsonMappingException
/*      */   {
/* 3725 */     _writeValueAndClose(createGenerator(w), value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String writeValueAsString(Object value)
/*      */     throws JsonProcessingException
/*      */   {
/* 3740 */     SegmentedStringWriter sw = new SegmentedStringWriter(this._jsonFactory._getBufferRecycler());
/*      */     try {
/* 3742 */       _writeValueAndClose(createGenerator(sw), value);
/*      */     } catch (JsonProcessingException e) {
/* 3744 */       throw e;
/*      */     } catch (IOException e) {
/* 3746 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     }
/* 3748 */     return sw.getAndClear();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] writeValueAsBytes(Object value)
/*      */     throws JsonProcessingException
/*      */   {
/* 3763 */     ByteArrayBuilder bb = new ByteArrayBuilder(this._jsonFactory._getBufferRecycler());
/*      */     try {
/* 3765 */       _writeValueAndClose(createGenerator(bb, JsonEncoding.UTF8), value);
/*      */     } catch (JsonProcessingException e) {
/* 3767 */       throw e;
/*      */     } catch (IOException e) {
/* 3769 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     }
/* 3771 */     byte[] result = bb.toByteArray();
/* 3772 */     bb.release();
/* 3773 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writer()
/*      */   {
/* 3788 */     return _newWriter(getSerializationConfig());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writer(SerializationFeature feature)
/*      */   {
/* 3797 */     return _newWriter(getSerializationConfig().with(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writer(SerializationFeature first, SerializationFeature... other)
/*      */   {
/* 3807 */     return _newWriter(getSerializationConfig().with(first, other));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writer(DateFormat df)
/*      */   {
/* 3816 */     return _newWriter(getSerializationConfig().with(df));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writerWithView(Class<?> serializationView)
/*      */   {
/* 3824 */     return _newWriter(getSerializationConfig().withView(serializationView));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writerFor(Class<?> rootType)
/*      */   {
/* 3839 */     return _newWriter(getSerializationConfig(), rootType == null ? null : this._typeFactory
/* 3840 */       .constructType(rootType), null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writerFor(TypeReference<?> rootType)
/*      */   {
/* 3856 */     return _newWriter(getSerializationConfig(), rootType == null ? null : this._typeFactory
/* 3857 */       .constructType(rootType), null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writerFor(JavaType rootType)
/*      */   {
/* 3873 */     return _newWriter(getSerializationConfig(), rootType, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writer(PrettyPrinter pp)
/*      */   {
/* 3882 */     if (pp == null) {
/* 3883 */       pp = ObjectWriter.NULL_PRETTY_PRINTER;
/*      */     }
/* 3885 */     return _newWriter(getSerializationConfig(), null, pp);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writerWithDefaultPrettyPrinter()
/*      */   {
/* 3893 */     SerializationConfig config = getSerializationConfig();
/* 3894 */     return _newWriter(config, null, config
/* 3895 */       .getDefaultPrettyPrinter());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writer(FilterProvider filterProvider)
/*      */   {
/* 3903 */     return _newWriter(getSerializationConfig().withFilters(filterProvider));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writer(FormatSchema schema)
/*      */   {
/* 3914 */     _verifySchemaType(schema);
/* 3915 */     return _newWriter(getSerializationConfig(), schema);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writer(Base64Variant defaultBase64)
/*      */   {
/* 3925 */     return _newWriter((SerializationConfig)getSerializationConfig().with(defaultBase64));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writer(CharacterEscapes escapes)
/*      */   {
/* 3935 */     return _newWriter(getSerializationConfig()).with(escapes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectWriter writer(ContextAttributes attrs)
/*      */   {
/* 3945 */     return _newWriter(getSerializationConfig().with(attrs));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter writerWithType(Class<?> rootType)
/*      */   {
/* 3953 */     return _newWriter(getSerializationConfig(), rootType == null ? null : this._typeFactory
/*      */     
/* 3955 */       .constructType(rootType), null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter writerWithType(TypeReference<?> rootType)
/*      */   {
/* 3964 */     return _newWriter(getSerializationConfig(), rootType == null ? null : this._typeFactory
/*      */     
/* 3966 */       .constructType(rootType), null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectWriter writerWithType(JavaType rootType)
/*      */   {
/* 3975 */     return _newWriter(getSerializationConfig(), rootType, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader reader()
/*      */   {
/* 3991 */     return _newReader(getDeserializationConfig()).with(this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader reader(DeserializationFeature feature)
/*      */   {
/* 4002 */     return _newReader(getDeserializationConfig().with(feature));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader reader(DeserializationFeature first, DeserializationFeature... other)
/*      */   {
/* 4014 */     return _newReader(getDeserializationConfig().with(first, other));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader readerForUpdating(Object valueToUpdate)
/*      */   {
/* 4028 */     JavaType t = this._typeFactory.constructType(valueToUpdate.getClass());
/* 4029 */     return _newReader(getDeserializationConfig(), t, valueToUpdate, null, this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader readerFor(JavaType type)
/*      */   {
/* 4040 */     return _newReader(getDeserializationConfig(), type, null, null, this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader readerFor(Class<?> type)
/*      */   {
/* 4051 */     return _newReader(getDeserializationConfig(), this._typeFactory.constructType(type), null, null, this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader readerFor(TypeReference<?> type)
/*      */   {
/* 4062 */     return _newReader(getDeserializationConfig(), this._typeFactory.constructType(type), null, null, this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader readerForArrayOf(Class<?> type)
/*      */   {
/* 4077 */     return _newReader(getDeserializationConfig(), this._typeFactory
/* 4078 */       .constructArrayType(type), null, null, this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader readerForListOf(Class<?> type)
/*      */   {
/* 4093 */     return _newReader(getDeserializationConfig(), this._typeFactory
/* 4094 */       .constructCollectionType(List.class, type), null, null, this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader readerForMapOf(Class<?> type)
/*      */   {
/* 4109 */     return _newReader(getDeserializationConfig(), this._typeFactory
/* 4110 */       .constructMapType(Map.class, String.class, type), null, null, this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader reader(JsonNodeFactory f)
/*      */   {
/* 4119 */     return _newReader(getDeserializationConfig()).with(f);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader reader(FormatSchema schema)
/*      */   {
/* 4130 */     _verifySchemaType(schema);
/* 4131 */     return _newReader(getDeserializationConfig(), null, null, schema, this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader reader(InjectableValues injectableValues)
/*      */   {
/* 4142 */     return _newReader(getDeserializationConfig(), null, null, null, injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader readerWithView(Class<?> view)
/*      */   {
/* 4151 */     return _newReader(getDeserializationConfig().withView(view));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader reader(Base64Variant defaultBase64)
/*      */   {
/* 4161 */     return _newReader((DeserializationConfig)getDeserializationConfig().with(defaultBase64));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectReader reader(ContextAttributes attrs)
/*      */   {
/* 4171 */     return _newReader(getDeserializationConfig().with(attrs));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectReader reader(JavaType type)
/*      */   {
/* 4179 */     return _newReader(getDeserializationConfig(), type, null, null, this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectReader reader(Class<?> type)
/*      */   {
/* 4188 */     return _newReader(getDeserializationConfig(), this._typeFactory.constructType(type), null, null, this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ObjectReader reader(TypeReference<?> type)
/*      */   {
/* 4197 */     return _newReader(getDeserializationConfig(), this._typeFactory.constructType(type), null, null, this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T convertValue(Object fromValue, Class<T> toValueType)
/*      */     throws IllegalArgumentException
/*      */   {
/* 4245 */     return (T)_convert(fromValue, this._typeFactory.constructType(toValueType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T convertValue(Object fromValue, TypeReference<T> toValueTypeRef)
/*      */     throws IllegalArgumentException
/*      */   {
/* 4255 */     return (T)_convert(fromValue, this._typeFactory.constructType(toValueTypeRef));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T convertValue(Object fromValue, JavaType toValueType)
/*      */     throws IllegalArgumentException
/*      */   {
/* 4265 */     return (T)_convert(fromValue, toValueType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object _convert(Object fromValue, JavaType toValueType)
/*      */     throws IllegalArgumentException
/*      */   {
/* 4283 */     TokenBuffer buf = new TokenBuffer(this, false);
/* 4284 */     if (isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 4285 */       buf = buf.forceUseOfBigDecimal(true);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 4290 */       SerializationConfig config = getSerializationConfig().without(SerializationFeature.WRAP_ROOT_VALUE);
/*      */       
/* 4292 */       _serializerProvider(config).serializeValue(buf, fromValue);
/*      */       
/*      */ 
/* 4295 */       JsonParser p = buf.asParser();
/*      */       
/*      */ 
/* 4298 */       DeserializationConfig deserConfig = getDeserializationConfig();
/* 4299 */       JsonToken t = _initForReading(p, toValueType);
/* 4300 */       Object result; Object result; if (t == JsonToken.VALUE_NULL) {
/* 4301 */         DeserializationContext ctxt = createDeserializationContext(p, deserConfig);
/* 4302 */         result = _findRootDeserializer(ctxt, toValueType).getNullValue(ctxt); } else { Object result;
/* 4303 */         if ((t == JsonToken.END_ARRAY) || (t == JsonToken.END_OBJECT)) {
/* 4304 */           result = null;
/*      */         } else {
/* 4306 */           DeserializationContext ctxt = createDeserializationContext(p, deserConfig);
/* 4307 */           JsonDeserializer<Object> deser = _findRootDeserializer(ctxt, toValueType);
/*      */           
/* 4309 */           result = deser.deserialize(p, ctxt);
/*      */         } }
/* 4311 */       p.close();
/* 4312 */       return result;
/*      */     } catch (IOException e) {
/* 4314 */       throw new IllegalArgumentException(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T updateValue(T valueToUpdate, Object overrides)
/*      */     throws JsonMappingException
/*      */   {
/* 4357 */     T result = valueToUpdate;
/* 4358 */     if ((valueToUpdate != null) && (overrides != null)) {
/* 4359 */       TokenBuffer buf = new TokenBuffer(this, false);
/* 4360 */       if (isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 4361 */         buf = buf.forceUseOfBigDecimal(true);
/*      */       }
/*      */       try
/*      */       {
/* 4365 */         SerializationConfig config = getSerializationConfig().without(SerializationFeature.WRAP_ROOT_VALUE);
/* 4366 */         _serializerProvider(config).serializeValue(buf, overrides);
/* 4367 */         JsonParser p = buf.asParser();
/* 4368 */         result = readerForUpdating(valueToUpdate).readValue(p);
/* 4369 */         p.close();
/*      */       } catch (IOException e) {
/* 4371 */         if ((e instanceof JsonMappingException)) {
/* 4372 */           throw ((JsonMappingException)e);
/*      */         }
/*      */         
/* 4375 */         throw JsonMappingException.fromUnexpectedIOE(e);
/*      */       }
/*      */     }
/* 4378 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonSchema generateJsonSchema(Class<?> t)
/*      */     throws JsonMappingException
/*      */   {
/* 4400 */     return _serializerProvider(getSerializationConfig()).generateJsonSchema(t);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void acceptJsonFormatVisitor(Class<?> type, JsonFormatVisitorWrapper visitor)
/*      */     throws JsonMappingException
/*      */   {
/* 4417 */     acceptJsonFormatVisitor(this._typeFactory.constructType(type), visitor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void acceptJsonFormatVisitor(JavaType type, JsonFormatVisitorWrapper visitor)
/*      */     throws JsonMappingException
/*      */   {
/* 4435 */     if (type == null) {
/* 4436 */       throw new IllegalArgumentException("type must be provided");
/*      */     }
/* 4438 */     _serializerProvider(getSerializationConfig()).acceptJsonFormatVisitor(type, visitor);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected TypeResolverBuilder<?> _constructDefaultTypeResolverBuilder(DefaultTyping applicability, PolymorphicTypeValidator ptv)
/*      */   {
/* 4455 */     return DefaultTypeResolverBuilder.construct(applicability, ptv);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DefaultSerializerProvider _serializerProvider(SerializationConfig config)
/*      */   {
/* 4469 */     return this._serializerProvider.createInstance(config, this._serializerFactory);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _writeValueAndClose(JsonGenerator g, Object value)
/*      */     throws IOException
/*      */   {
/* 4481 */     SerializationConfig cfg = getSerializationConfig();
/* 4482 */     if ((cfg.isEnabled(SerializationFeature.CLOSE_CLOSEABLE)) && ((value instanceof Closeable))) {
/* 4483 */       _writeCloseable(g, value, cfg);
/* 4484 */       return;
/*      */     }
/*      */     try {
/* 4487 */       _serializerProvider(cfg).serializeValue(g, value);
/*      */     } catch (Exception e) {
/* 4489 */       ClassUtil.closeOnFailAndThrowAsIOE(g, e);
/* 4490 */       return;
/*      */     }
/* 4492 */     g.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeCloseable(JsonGenerator g, Object value, SerializationConfig cfg)
/*      */     throws IOException
/*      */   {
/* 4502 */     Closeable toClose = (Closeable)value;
/*      */     try {
/* 4504 */       _serializerProvider(cfg).serializeValue(g, value);
/* 4505 */       Closeable tmpToClose = toClose;
/* 4506 */       toClose = null;
/* 4507 */       tmpToClose.close();
/*      */     } catch (Exception e) {
/* 4509 */       ClassUtil.closeOnFailAndThrowAsIOE(g, toClose, e);
/* 4510 */       return;
/*      */     }
/* 4512 */     g.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void _writeCloseableValue(JsonGenerator g, Object value, SerializationConfig cfg)
/*      */     throws IOException
/*      */   {
/* 4522 */     Closeable toClose = (Closeable)value;
/*      */     try {
/* 4524 */       _serializerProvider(cfg).serializeValue(g, value);
/* 4525 */       if (cfg.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 4526 */         g.flush();
/*      */       }
/*      */     } catch (Exception e) {
/* 4529 */       ClassUtil.closeOnFailAndThrowAsIOE(null, toClose, e);
/* 4530 */       return;
/*      */     }
/* 4532 */     toClose.close();
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   protected final void _configAndWriteValue(JsonGenerator g, Object value)
/*      */     throws IOException
/*      */   {
/* 4540 */     getSerializationConfig().initialize(g);
/* 4541 */     _writeValueAndClose(g, value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object _readValue(DeserializationConfig cfg, JsonParser p, JavaType valueType)
/*      */     throws IOException
/*      */   {
/* 4561 */     JsonToken t = _initForReading(p, valueType);
/* 4562 */     DefaultDeserializationContext ctxt = createDeserializationContext(p, cfg);
/* 4563 */     Object result; Object result; if (t == JsonToken.VALUE_NULL)
/*      */     {
/* 4565 */       result = _findRootDeserializer(ctxt, valueType).getNullValue(ctxt); } else { Object result;
/* 4566 */       if ((t == JsonToken.END_ARRAY) || (t == JsonToken.END_OBJECT)) {
/* 4567 */         result = null;
/*      */       } else {
/* 4569 */         result = ctxt.readRootValue(p, valueType, _findRootDeserializer(ctxt, valueType), null);
/*      */       }
/*      */     }
/* 4572 */     p.clearCurrentToken();
/* 4573 */     if (cfg.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 4574 */       _verifyNoTrailingTokens(p, ctxt, valueType);
/*      */     }
/* 4576 */     return result;
/*      */   }
/*      */   
/*      */   protected Object _readMapAndClose(JsonParser p0, JavaType valueType)
/*      */     throws IOException
/*      */   {
/* 4582 */     JsonParser p = p0;Throwable localThrowable3 = null;
/*      */     try {
/* 4584 */       DeserializationConfig cfg = getDeserializationConfig();
/* 4585 */       DefaultDeserializationContext ctxt = createDeserializationContext(p, cfg);
/* 4586 */       JsonToken t = _initForReading(p, valueType);
/* 4587 */       Object result; Object result; if (t == JsonToken.VALUE_NULL)
/*      */       {
/* 4589 */         result = _findRootDeserializer(ctxt, valueType).getNullValue(ctxt); } else { Object result;
/* 4590 */         if ((t == JsonToken.END_ARRAY) || (t == JsonToken.END_OBJECT)) {
/* 4591 */           result = null;
/*      */         } else {
/* 4593 */           result = ctxt.readRootValue(p, valueType, 
/* 4594 */             _findRootDeserializer(ctxt, valueType), null);
/* 4595 */           ctxt.checkUnresolvedObjectId();
/*      */         } }
/* 4597 */       if (cfg.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 4598 */         _verifyNoTrailingTokens(p, ctxt, valueType);
/*      */       }
/* 4600 */       return result;
/*      */     }
/*      */     catch (Throwable localThrowable1)
/*      */     {
/* 4582 */       localThrowable3 = localThrowable1;throw localThrowable1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4601 */       if (p != null) { if (localThrowable3 != null) try { p.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else { p.close();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected JsonNode _readTreeAndClose(JsonParser p0)
/*      */     throws IOException
/*      */   {
/* 4612 */     JsonParser p = p0;Throwable localThrowable4 = null;
/* 4613 */     try { JavaType valueType = constructType(JsonNode.class);
/*      */       
/* 4615 */       DeserializationConfig cfg = getDeserializationConfig();
/*      */       
/*      */ 
/*      */ 
/* 4619 */       cfg.initialize(p);
/* 4620 */       JsonToken t = p.currentToken();
/* 4621 */       if (t == null) {
/* 4622 */         t = p.nextToken();
/* 4623 */         if (t == null)
/*      */         {
/*      */ 
/* 4626 */           return cfg.getNodeFactory().missingNode();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 4631 */       DefaultDeserializationContext ctxt = createDeserializationContext(p, cfg);
/* 4632 */       Object resultNode; JsonNode resultNode; if (t == JsonToken.VALUE_NULL) {
/* 4633 */         resultNode = cfg.getNodeFactory().nullNode();
/*      */       } else {
/* 4635 */         resultNode = (JsonNode)ctxt.readRootValue(p, valueType, 
/* 4636 */           _findRootDeserializer(ctxt, valueType), null);
/*      */       }
/*      */       
/*      */ 
/* 4640 */       if (cfg.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 4641 */         _verifyNoTrailingTokens(p, ctxt, valueType);
/*      */       }
/* 4643 */       return resultNode;
/*      */     }
/*      */     catch (Throwable localThrowable2)
/*      */     {
/* 4612 */       localThrowable4 = localThrowable2;throw localThrowable2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4644 */       if (p != null) { if (localThrowable4 != null) try { p.close(); } catch (Throwable localThrowable3) { localThrowable4.addSuppressed(localThrowable3); } else { p.close();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DefaultDeserializationContext createDeserializationContext(JsonParser p, DeserializationConfig cfg)
/*      */   {
/* 4656 */     return this._deserializationContext.createInstance(cfg, p, this._injectableValues);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonToken _initForReading(JsonParser p, JavaType targetType)
/*      */     throws IOException
/*      */   {
/* 4676 */     this._deserializationConfig.initialize(p);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4681 */     JsonToken t = p.currentToken();
/* 4682 */     if (t == null)
/*      */     {
/* 4684 */       t = p.nextToken();
/* 4685 */       if (t == null)
/*      */       {
/*      */ 
/* 4688 */         throw MismatchedInputException.from(p, targetType, "No content to map due to end-of-input");
/*      */       }
/*      */     }
/*      */     
/* 4692 */     return t;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected JsonToken _initForReading(JsonParser p) throws IOException {
/* 4697 */     return _initForReading(p, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _verifyNoTrailingTokens(JsonParser p, DeserializationContext ctxt, JavaType bindType)
/*      */     throws IOException
/*      */   {
/* 4707 */     JsonToken t = p.nextToken();
/* 4708 */     if (t != null) {
/* 4709 */       Class<?> bt = ClassUtil.rawClass(bindType);
/* 4710 */       ctxt.reportTrailingTokens(bt, p, t);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> _findRootDeserializer(DeserializationContext ctxt, JavaType valueType)
/*      */     throws JsonMappingException
/*      */   {
/* 4728 */     JsonDeserializer<Object> deser = (JsonDeserializer)this._rootDeserializers.get(valueType);
/* 4729 */     if (deser != null) {
/* 4730 */       return deser;
/*      */     }
/*      */     
/* 4733 */     deser = ctxt.findRootValueDeserializer(valueType);
/* 4734 */     if (deser == null) {
/* 4735 */       return (JsonDeserializer)ctxt.reportBadDefinition(valueType, "Cannot find a deserializer for type " + valueType);
/*      */     }
/*      */     
/* 4738 */     this._rootDeserializers.put(valueType, deser);
/* 4739 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _verifySchemaType(FormatSchema schema)
/*      */   {
/* 4747 */     if ((schema != null) && 
/* 4748 */       (!this._jsonFactory.canUseSchema(schema)))
/*      */     {
/* 4750 */       throw new IllegalArgumentException("Cannot use FormatSchema of type " + schema.getClass().getName() + " for format " + this._jsonFactory.getFormatName());
/*      */     }
/*      */   }
/*      */   
/*      */   protected final void _assertNotNull(String paramName, Object src)
/*      */   {
/* 4756 */     if (src == null) {
/* 4757 */       throw new IllegalArgumentException(String.format("argument \"%s\" is null", new Object[] { paramName }));
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\ObjectMapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */