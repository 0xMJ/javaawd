/*    */ package com.fasterxml.jackson.databind.ser.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.ser.std.StdSerializer;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedTypeSerializer
/*    */   extends StdSerializer<Object>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final JavaType _type;
/*    */   protected final String _message;
/*    */   
/*    */   public UnsupportedTypeSerializer(JavaType t, String msg)
/*    */   {
/* 28 */     super(Object.class);
/* 29 */     this._type = t;
/* 30 */     this._message = msg;
/*    */   }
/*    */   
/*    */   public void serialize(Object value, JsonGenerator g, SerializerProvider ctxt) throws IOException
/*    */   {
/* 35 */     ctxt.reportBadDefinition(this._type, this._message);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\ser\impl\UnsupportedTypeSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */