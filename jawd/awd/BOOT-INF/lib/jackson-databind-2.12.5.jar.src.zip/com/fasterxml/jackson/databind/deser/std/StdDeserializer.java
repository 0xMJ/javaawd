/*      */ package com.fasterxml.jackson.databind.deser.std;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonFormat.Feature;
/*      */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*      */ import com.fasterxml.jackson.annotation.Nulls;
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonParser.NumberType;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.exc.InputCoercionException;
/*      */ import com.fasterxml.jackson.core.exc.StreamReadException;
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*      */ import com.fasterxml.jackson.databind.deser.BeanDeserializerBase;
/*      */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*      */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*      */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*      */ import com.fasterxml.jackson.databind.deser.ValueInstantiator.Gettable;
/*      */ import com.fasterxml.jackson.databind.deser.impl.NullsAsEmptyProvider;
/*      */ import com.fasterxml.jackson.databind.deser.impl.NullsConstantProvider;
/*      */ import com.fasterxml.jackson.databind.deser.impl.NullsFailProvider;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.Converter;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Map;
/*      */ 
/*      */ public abstract class StdDeserializer<T>
/*      */   extends JsonDeserializer<T> implements Serializable, ValueInstantiator.Gettable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   51 */   protected static final int F_MASK_INT_COERCIONS = DeserializationFeature.USE_BIG_INTEGER_FOR_INTS
/*   52 */     .getMask() | DeserializationFeature.USE_LONG_FOR_INTS
/*   53 */     .getMask();
/*      */   
/*      */   @Deprecated
/*   56 */   protected static final int F_MASK_ACCEPT_ARRAYS = DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS
/*   57 */     .getMask() | DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT
/*   58 */     .getMask();
/*      */   
/*      */ 
/*      */ 
/*      */   protected final Class<?> _valueClass;
/*      */   
/*      */ 
/*      */   protected final JavaType _valueType;
/*      */   
/*      */ 
/*      */ 
/*      */   protected StdDeserializer(Class<?> vc)
/*      */   {
/*   71 */     this._valueClass = vc;
/*   72 */     this._valueType = null;
/*      */   }
/*      */   
/*      */   protected StdDeserializer(JavaType valueType)
/*      */   {
/*   77 */     this._valueClass = (valueType == null ? Object.class : valueType.getRawClass());
/*   78 */     this._valueType = valueType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected StdDeserializer(StdDeserializer<?> src)
/*      */   {
/*   88 */     this._valueClass = src._valueClass;
/*   89 */     this._valueType = src._valueType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Class<?> handledType()
/*      */   {
/*   99 */     return this._valueClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final Class<?> getValueClass()
/*      */   {
/*  111 */     return this._valueClass;
/*      */   }
/*      */   
/*      */   public JavaType getValueType()
/*      */   {
/*  116 */     return this._valueType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JavaType getValueType(DeserializationContext ctxt)
/*      */   {
/*  132 */     if (this._valueType != null) {
/*  133 */       return this._valueType;
/*      */     }
/*  135 */     return ctxt.constructType(this._valueClass);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ValueInstantiator getValueInstantiator()
/*      */   {
/*  142 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isDefaultDeserializer(JsonDeserializer<?> deserializer)
/*      */   {
/*  151 */     return ClassUtil.isJacksonStdImpl(deserializer);
/*      */   }
/*      */   
/*      */   protected boolean isDefaultKeyDeserializer(KeyDeserializer keyDeser) {
/*  155 */     return ClassUtil.isJacksonStdImpl(keyDeser);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*      */     throws IOException
/*      */   {
/*  172 */     return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected T _deserializeFromArray(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/*  200 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/*  201 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*      */     
/*  203 */     if ((unwrap) || (act != CoercionAction.Fail)) {
/*  204 */       JsonToken t = p.nextToken();
/*  205 */       if (t == JsonToken.END_ARRAY) {
/*  206 */         switch (act) {
/*      */         case AsEmpty: 
/*  208 */           return (T)getEmptyValue(ctxt);
/*      */         case AsNull: 
/*      */         case TryConvert: 
/*  211 */           return (T)getNullValue(ctxt);
/*      */         }
/*      */       }
/*  214 */       else if (unwrap) {
/*  215 */         T parsed = _deserializeWrappedValue(p, ctxt);
/*  216 */         if (p.nextToken() != JsonToken.END_ARRAY) {
/*  217 */           handleMissingEndArrayForSingle(p, ctxt);
/*      */         }
/*  219 */         return parsed;
/*      */       }
/*      */     }
/*  222 */     return (T)ctxt.handleUnexpectedToken(getValueType(ctxt), JsonToken.START_ARRAY, p, null, new Object[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected T _deserializeFromEmpty(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/*  238 */     if ((p.hasToken(JsonToken.START_ARRAY)) && 
/*  239 */       (ctxt.isEnabled(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT))) {
/*  240 */       JsonToken t = p.nextToken();
/*  241 */       if (t == JsonToken.END_ARRAY) {
/*  242 */         return null;
/*      */       }
/*  244 */       return (T)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */     }
/*      */     
/*  247 */     return (T)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected T _deserializeFromString(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/*  260 */     ValueInstantiator inst = getValueInstantiator();
/*  261 */     Class<?> rawTargetType = handledType();
/*  262 */     String value = p.getValueAsString();
/*      */     
/*  264 */     if ((inst != null) && (inst.canCreateFromString())) {
/*  265 */       return (T)inst.createFromString(ctxt, value);
/*      */     }
/*  267 */     if (value.isEmpty()) {
/*  268 */       CoercionAction act = ctxt.findCoercionAction(logicalType(), rawTargetType, CoercionInputShape.EmptyString);
/*      */       
/*  270 */       return (T)_deserializeFromEmptyString(p, ctxt, act, rawTargetType, "empty String (\"\")");
/*      */     }
/*      */     
/*  273 */     if (_isBlank(value)) {
/*  274 */       CoercionAction act = ctxt.findCoercionFromBlankString(logicalType(), rawTargetType, CoercionAction.Fail);
/*      */       
/*  276 */       return (T)_deserializeFromEmptyString(p, ctxt, act, rawTargetType, "blank String (all whitespace)");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  283 */     if (inst != null) {
/*  284 */       value = value.trim();
/*  285 */       if ((inst.canCreateFromInt()) && 
/*  286 */         (ctxt.findCoercionAction(LogicalType.Integer, Integer.class, CoercionInputShape.String) == CoercionAction.TryConvert))
/*      */       {
/*  288 */         return (T)inst.createFromInt(ctxt, _parseIntPrimitive(ctxt, value));
/*      */       }
/*      */       
/*  291 */       if ((inst.canCreateFromLong()) && 
/*  292 */         (ctxt.findCoercionAction(LogicalType.Integer, Long.class, CoercionInputShape.String) == CoercionAction.TryConvert))
/*      */       {
/*  294 */         return (T)inst.createFromLong(ctxt, _parseLongPrimitive(ctxt, value));
/*      */       }
/*      */       
/*  297 */       if (inst.canCreateFromBoolean())
/*      */       {
/*  299 */         if (ctxt.findCoercionAction(LogicalType.Boolean, Boolean.class, CoercionInputShape.String) == CoercionAction.TryConvert)
/*      */         {
/*  301 */           String str = value.trim();
/*  302 */           if ("true".equals(str)) {
/*  303 */             return (T)inst.createFromBoolean(ctxt, true);
/*      */           }
/*  305 */           if ("false".equals(str)) {
/*  306 */             return (T)inst.createFromBoolean(ctxt, false);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  311 */     return (T)ctxt.handleMissingInstantiator(rawTargetType, inst, ctxt.getParser(), "no String-argument constructor/factory method to deserialize from String value ('%s')", new Object[] { value });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object _deserializeFromEmptyString(JsonParser p, DeserializationContext ctxt, CoercionAction act, Class<?> rawTargetType, String desc)
/*      */     throws IOException
/*      */   {
/*  320 */     switch (act) {
/*      */     case AsEmpty: 
/*  322 */       return getEmptyValue(ctxt);
/*      */     
/*      */     case Fail: 
/*  325 */       _checkCoercionFail(ctxt, act, rawTargetType, "", "empty String (\"\")");
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*  331 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected T _deserializeWrappedValue(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/*  359 */     if (p.hasToken(JsonToken.START_ARRAY)) {
/*  360 */       String msg = String.format("Cannot deserialize instance of %s out of %s token: nested Arrays not allowed with %s", new Object[] {
/*      */       
/*  362 */         ClassUtil.nameOf(this._valueClass), JsonToken.START_ARRAY, "DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS" });
/*      */       
/*      */ 
/*  365 */       T result = ctxt.handleUnexpectedToken(getValueType(ctxt), p.currentToken(), p, msg, new Object[0]);
/*  366 */       return result;
/*      */     }
/*  368 */     return (T)deserialize(p, ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected final boolean _parseBooleanPrimitive(DeserializationContext ctxt, JsonParser p, Class<?> targetType)
/*      */     throws IOException
/*      */   {
/*  382 */     return _parseBooleanPrimitive(p, ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */   protected final boolean _parseBooleanPrimitive(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/*      */     String text;
/*      */     
/*      */     String text;
/*      */     
/*  393 */     switch (p.currentTokenId()) {
/*      */     case 6: 
/*  395 */       text = p.getText();
/*  396 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 7: 
/*  401 */       return Boolean.TRUE.equals(_coerceBooleanFromInt(p, ctxt, Boolean.TYPE));
/*      */     case 9: 
/*  403 */       return true;
/*      */     case 10: 
/*  405 */       return false;
/*      */     case 11: 
/*  407 */       _verifyNullForPrimitive(ctxt);
/*  408 */       return false;
/*      */     
/*      */     case 1: 
/*  411 */       text = ctxt.extractScalarFromObject(p, this, Boolean.TYPE);
/*  412 */       break;
/*      */     
/*      */     case 3: 
/*  415 */       if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  416 */         p.nextToken();
/*  417 */         boolean parsed = _parseBooleanPrimitive(p, ctxt);
/*  418 */         _verifyEndArrayForSingle(p, ctxt);
/*  419 */         return parsed;
/*      */       }
/*      */       break;
/*      */     }
/*  423 */     return ((Boolean)ctxt.handleUnexpectedToken(Boolean.TYPE, p)).booleanValue();
/*      */     
/*      */ 
/*  426 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Boolean, Boolean.TYPE);
/*      */     
/*  428 */     if (act == CoercionAction.AsNull) {
/*  429 */       _verifyNullForPrimitive(ctxt);
/*  430 */       return false;
/*      */     }
/*  432 */     if (act == CoercionAction.AsEmpty) {
/*  433 */       return false;
/*      */     }
/*  435 */     String text = text.trim();
/*  436 */     int len = text.length();
/*      */     
/*      */ 
/*      */ 
/*  440 */     if (len == 4) {
/*  441 */       if (_isTrue(text)) {
/*  442 */         return true;
/*      */       }
/*  444 */     } else if ((len == 5) && 
/*  445 */       (_isFalse(text))) {
/*  446 */       return false;
/*      */     }
/*      */     
/*  449 */     if (_hasTextualNull(text)) {
/*  450 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  451 */       return false;
/*      */     }
/*  453 */     Boolean b = (Boolean)ctxt.handleWeirdStringValue(Boolean.TYPE, text, "only \"true\"/\"True\"/\"TRUE\" or \"false\"/\"False\"/\"FALSE\" recognized", new Object[0]);
/*      */     
/*  455 */     return Boolean.TRUE.equals(b);
/*      */   }
/*      */   
/*      */   protected boolean _isTrue(String text)
/*      */   {
/*  460 */     char c = text.charAt(0);
/*  461 */     if (c == 't') {
/*  462 */       return "true".equals(text);
/*      */     }
/*  464 */     if (c == 'T') {
/*  465 */       return ("TRUE".equals(text)) || ("True".equals(text));
/*      */     }
/*  467 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean _isFalse(String text) {
/*  471 */     char c = text.charAt(0);
/*  472 */     if (c == 'f') {
/*  473 */       return "false".equals(text);
/*      */     }
/*  475 */     if (c == 'F') {
/*  476 */       return ("FALSE".equals(text)) || ("False".equals(text));
/*      */     }
/*  478 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Boolean _parseBoolean(JsonParser p, DeserializationContext ctxt, Class<?> targetType)
/*      */     throws IOException
/*      */   {
/*      */     String text;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     String text;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  504 */     switch (p.currentTokenId()) {
/*      */     case 6: 
/*  506 */       text = p.getText();
/*  507 */       break;
/*      */     
/*      */     case 7: 
/*  510 */       return _coerceBooleanFromInt(p, ctxt, targetType);
/*      */     case 9: 
/*  512 */       return Boolean.valueOf(true);
/*      */     case 10: 
/*  514 */       return Boolean.valueOf(false);
/*      */     case 11: 
/*  516 */       return null;
/*      */     
/*      */     case 1: 
/*  519 */       text = ctxt.extractScalarFromObject(p, this, targetType);
/*  520 */       break;
/*      */     case 3: 
/*  522 */       return (Boolean)_deserializeFromArray(p, ctxt);
/*      */     case 2: case 4: case 5: case 8: default: 
/*  524 */       return (Boolean)ctxt.handleUnexpectedToken(targetType, p);
/*      */     }
/*      */     
/*  527 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Boolean, targetType);
/*      */     
/*  529 */     if (act == CoercionAction.AsNull) {
/*  530 */       return null;
/*      */     }
/*  532 */     if (act == CoercionAction.AsEmpty) {
/*  533 */       return Boolean.valueOf(false);
/*      */     }
/*  535 */     String text = text.trim();
/*  536 */     int len = text.length();
/*      */     
/*      */ 
/*      */ 
/*  540 */     if (len == 4) {
/*  541 */       if (_isTrue(text)) {
/*  542 */         return Boolean.valueOf(true);
/*      */       }
/*  544 */     } else if ((len == 5) && 
/*  545 */       (_isFalse(text))) {
/*  546 */       return Boolean.valueOf(false);
/*      */     }
/*      */     
/*  549 */     if (_checkTextualNull(ctxt, text)) {
/*  550 */       return null;
/*      */     }
/*  552 */     return (Boolean)ctxt.handleWeirdStringValue(targetType, text, "only \"true\" or \"false\" recognized", new Object[0]);
/*      */   }
/*      */   
/*      */   protected final byte _parseBytePrimitive(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/*      */     String text;
/*      */     String text;
/*  560 */     switch (p.currentTokenId()) {
/*      */     case 6: 
/*  562 */       text = p.getText();
/*  563 */       break;
/*      */     case 8: 
/*  565 */       CoercionAction act = _checkFloatToIntCoercion(p, ctxt, Byte.TYPE);
/*  566 */       if (act == CoercionAction.AsNull) {
/*  567 */         return 0;
/*      */       }
/*  569 */       if (act == CoercionAction.AsEmpty) {
/*  570 */         return 0;
/*      */       }
/*  572 */       return p.getByteValue();
/*      */     case 7: 
/*  574 */       return p.getByteValue();
/*      */     case 11: 
/*  576 */       _verifyNullForPrimitive(ctxt);
/*  577 */       return 0;
/*      */     
/*      */     case 1: 
/*  580 */       text = ctxt.extractScalarFromObject(p, this, Byte.TYPE);
/*  581 */       break;
/*      */     
/*      */     case 3: 
/*  584 */       if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  585 */         p.nextToken();
/*  586 */         byte parsed = _parseBytePrimitive(p, ctxt);
/*  587 */         _verifyEndArrayForSingle(p, ctxt);
/*  588 */         return parsed;
/*      */       }
/*      */       break;
/*      */     }
/*  592 */     return ((Byte)ctxt.handleUnexpectedToken(ctxt.constructType(Byte.TYPE), p)).byteValue();
/*      */     
/*      */ 
/*      */ 
/*  596 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, Byte.TYPE);
/*      */     
/*  598 */     if (act == CoercionAction.AsNull) {
/*  599 */       return 0;
/*      */     }
/*  601 */     if (act == CoercionAction.AsEmpty) {
/*  602 */       return 0;
/*      */     }
/*  604 */     String text = text.trim();
/*  605 */     if (_hasTextualNull(text)) {
/*  606 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  607 */       return 0;
/*      */     }
/*      */     try
/*      */     {
/*  611 */       value = NumberInput.parseInt(text);
/*      */     } catch (IllegalArgumentException iae) { int value;
/*  613 */       return ((Byte)ctxt.handleWeirdStringValue(this._valueClass, text, "not a valid `byte` value", new Object[0])).byteValue();
/*      */     }
/*      */     
/*      */     int value;
/*  617 */     if (_byteOverflow(value)) {
/*  618 */       return ((Byte)ctxt.handleWeirdStringValue(this._valueClass, text, "overflow, value cannot be represented as 8-bit value", new Object[0])).byteValue();
/*      */     }
/*      */     
/*  621 */     return (byte)value;
/*      */   }
/*      */   
/*      */   protected final short _parseShortPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException
/*      */   {
/*      */     String text;
/*      */     String text;
/*  628 */     switch (p.currentTokenId()) {
/*      */     case 6: 
/*  630 */       text = p.getText();
/*  631 */       break;
/*      */     case 8: 
/*  633 */       CoercionAction act = _checkFloatToIntCoercion(p, ctxt, Short.TYPE);
/*  634 */       if (act == CoercionAction.AsNull) {
/*  635 */         return 0;
/*      */       }
/*  637 */       if (act == CoercionAction.AsEmpty) {
/*  638 */         return 0;
/*      */       }
/*  640 */       return p.getShortValue();
/*      */     case 7: 
/*  642 */       return p.getShortValue();
/*      */     case 11: 
/*  644 */       _verifyNullForPrimitive(ctxt);
/*  645 */       return 0;
/*      */     
/*      */     case 1: 
/*  648 */       text = ctxt.extractScalarFromObject(p, this, Short.TYPE);
/*  649 */       break;
/*      */     
/*      */     case 3: 
/*  652 */       if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  653 */         p.nextToken();
/*  654 */         short parsed = _parseShortPrimitive(p, ctxt);
/*  655 */         _verifyEndArrayForSingle(p, ctxt);
/*  656 */         return parsed;
/*      */       }
/*      */       break;
/*      */     }
/*  660 */     return ((Short)ctxt.handleUnexpectedToken(ctxt.constructType(Short.TYPE), p)).shortValue();
/*      */     
/*      */ 
/*  663 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, Short.TYPE);
/*      */     
/*  665 */     if (act == CoercionAction.AsNull) {
/*  666 */       return 0;
/*      */     }
/*  668 */     if (act == CoercionAction.AsEmpty) {
/*  669 */       return 0;
/*      */     }
/*  671 */     String text = text.trim();
/*  672 */     if (_hasTextualNull(text)) {
/*  673 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  674 */       return 0;
/*      */     }
/*      */     try
/*      */     {
/*  678 */       value = NumberInput.parseInt(text);
/*      */     } catch (IllegalArgumentException iae) { int value;
/*  680 */       return ((Short)ctxt.handleWeirdStringValue(Short.TYPE, text, "not a valid `short` value", new Object[0])).shortValue();
/*      */     }
/*      */     int value;
/*  683 */     if (_shortOverflow(value)) {
/*  684 */       return ((Short)ctxt.handleWeirdStringValue(Short.TYPE, text, "overflow, value cannot be represented as 16-bit value", new Object[0])).shortValue();
/*      */     }
/*      */     
/*  687 */     return (short)value;
/*      */   }
/*      */   
/*      */   protected final int _parseIntPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException
/*      */   {
/*      */     String text;
/*      */     String text;
/*  694 */     switch (p.currentTokenId()) {
/*      */     case 6: 
/*  696 */       text = p.getText();
/*  697 */       break;
/*      */     case 8: 
/*  699 */       CoercionAction act = _checkFloatToIntCoercion(p, ctxt, Integer.TYPE);
/*  700 */       if (act == CoercionAction.AsNull) {
/*  701 */         return 0;
/*      */       }
/*  703 */       if (act == CoercionAction.AsEmpty) {
/*  704 */         return 0;
/*      */       }
/*  706 */       return p.getValueAsInt();
/*      */     case 7: 
/*  708 */       return p.getIntValue();
/*      */     case 11: 
/*  710 */       _verifyNullForPrimitive(ctxt);
/*  711 */       return 0;
/*      */     
/*      */     case 1: 
/*  714 */       text = ctxt.extractScalarFromObject(p, this, Integer.TYPE);
/*  715 */       break;
/*      */     case 3: 
/*  717 */       if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  718 */         p.nextToken();
/*  719 */         int parsed = _parseIntPrimitive(p, ctxt);
/*  720 */         _verifyEndArrayForSingle(p, ctxt);
/*  721 */         return parsed;
/*      */       }
/*      */       break;
/*      */     }
/*  725 */     return ((Number)ctxt.handleUnexpectedToken(Integer.TYPE, p)).intValue();
/*      */     
/*      */ 
/*  728 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, Integer.TYPE);
/*      */     
/*  730 */     if (act == CoercionAction.AsNull) {
/*  731 */       return 0;
/*      */     }
/*  733 */     if (act == CoercionAction.AsEmpty) {
/*  734 */       return 0;
/*      */     }
/*  736 */     String text = text.trim();
/*  737 */     if (_hasTextualNull(text)) {
/*  738 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  739 */       return 0;
/*      */     }
/*  741 */     return _parseIntPrimitive(ctxt, text);
/*      */   }
/*      */   
/*      */ 
/*      */   protected final int _parseIntPrimitive(DeserializationContext ctxt, String text)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  750 */       if (text.length() > 9) {
/*  751 */         long l = Long.parseLong(text);
/*  752 */         if (_intOverflow(l)) {
/*  753 */           Number v = (Number)ctxt.handleWeirdStringValue(Integer.TYPE, text, "Overflow: numeric value (%s) out of range of int (%d -%d)", new Object[] { text, 
/*      */           
/*  755 */             Integer.valueOf(Integer.MIN_VALUE), Integer.valueOf(Integer.MAX_VALUE) });
/*  756 */           return _nonNullNumber(v).intValue();
/*      */         }
/*  758 */         return (int)l;
/*      */       }
/*  760 */       return NumberInput.parseInt(text);
/*      */     } catch (IllegalArgumentException iae) {
/*  762 */       Number v = (Number)ctxt.handleWeirdStringValue(Integer.TYPE, text, "not a valid `int` value", new Object[0]);
/*      */       
/*  764 */       return _nonNullNumber(v).intValue();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected final Integer _parseInteger(JsonParser p, DeserializationContext ctxt, Class<?> targetType)
/*      */     throws IOException
/*      */   {
/*      */     String text;
/*      */     
/*      */     String text;
/*      */     
/*  776 */     switch (p.currentTokenId()) {
/*      */     case 6: 
/*  778 */       text = p.getText();
/*  779 */       break;
/*      */     case 8: 
/*  781 */       CoercionAction act = _checkFloatToIntCoercion(p, ctxt, targetType);
/*  782 */       if (act == CoercionAction.AsNull) {
/*  783 */         return (Integer)getNullValue(ctxt);
/*      */       }
/*  785 */       if (act == CoercionAction.AsEmpty) {
/*  786 */         return (Integer)getEmptyValue(ctxt);
/*      */       }
/*  788 */       return Integer.valueOf(p.getValueAsInt());
/*      */     case 7: 
/*  790 */       return Integer.valueOf(p.getIntValue());
/*      */     case 11: 
/*  792 */       return (Integer)getNullValue(ctxt);
/*      */     
/*      */     case 1: 
/*  795 */       text = ctxt.extractScalarFromObject(p, this, targetType);
/*  796 */       break;
/*      */     case 3: 
/*  798 */       return (Integer)_deserializeFromArray(p, ctxt);
/*      */     case 2: case 4: case 5: case 9: case 10: default: 
/*  800 */       return (Integer)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */     }
/*      */     
/*  803 */     CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  804 */     if (act == CoercionAction.AsNull) {
/*  805 */       return (Integer)getNullValue(ctxt);
/*      */     }
/*  807 */     if (act == CoercionAction.AsEmpty) {
/*  808 */       return (Integer)getEmptyValue(ctxt);
/*      */     }
/*  810 */     String text = text.trim();
/*  811 */     if (_checkTextualNull(ctxt, text)) {
/*  812 */       return (Integer)getNullValue(ctxt);
/*      */     }
/*  814 */     return Integer.valueOf(_parseIntPrimitive(ctxt, text));
/*      */   }
/*      */   
/*      */   protected final long _parseLongPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException
/*      */   {
/*      */     String text;
/*      */     String text;
/*  821 */     switch (p.currentTokenId()) {
/*      */     case 6: 
/*  823 */       text = p.getText();
/*  824 */       break;
/*      */     case 8: 
/*  826 */       CoercionAction act = _checkFloatToIntCoercion(p, ctxt, Long.TYPE);
/*  827 */       if (act == CoercionAction.AsNull) {
/*  828 */         return 0L;
/*      */       }
/*  830 */       if (act == CoercionAction.AsEmpty) {
/*  831 */         return 0L;
/*      */       }
/*  833 */       return p.getValueAsLong();
/*      */     case 7: 
/*  835 */       return p.getLongValue();
/*      */     case 11: 
/*  837 */       _verifyNullForPrimitive(ctxt);
/*  838 */       return 0L;
/*      */     
/*      */     case 1: 
/*  841 */       text = ctxt.extractScalarFromObject(p, this, Long.TYPE);
/*  842 */       break;
/*      */     case 3: 
/*  844 */       if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  845 */         p.nextToken();
/*  846 */         long parsed = _parseLongPrimitive(p, ctxt);
/*  847 */         _verifyEndArrayForSingle(p, ctxt);
/*  848 */         return parsed;
/*      */       }
/*      */       break;
/*      */     }
/*  852 */     return ((Number)ctxt.handleUnexpectedToken(Long.TYPE, p)).longValue();
/*      */     
/*      */ 
/*  855 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, Long.TYPE);
/*      */     
/*  857 */     if (act == CoercionAction.AsNull) {
/*  858 */       return 0L;
/*      */     }
/*  860 */     if (act == CoercionAction.AsEmpty) {
/*  861 */       return 0L;
/*      */     }
/*  863 */     String text = text.trim();
/*  864 */     if (_hasTextualNull(text)) {
/*  865 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  866 */       return 0L;
/*      */     }
/*  868 */     return _parseLongPrimitive(ctxt, text);
/*      */   }
/*      */   
/*      */ 
/*      */   protected final long _parseLongPrimitive(DeserializationContext ctxt, String text)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  877 */       return NumberInput.parseLong(text);
/*      */     }
/*      */     catch (IllegalArgumentException localIllegalArgumentException) {
/*  880 */       Number v = (Number)ctxt.handleWeirdStringValue(Long.TYPE, text, "not a valid `long` value", new Object[0]);
/*      */       
/*  882 */       return _nonNullNumber(v).longValue();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected final Long _parseLong(JsonParser p, DeserializationContext ctxt, Class<?> targetType)
/*      */     throws IOException
/*      */   {
/*      */     String text;
/*      */     
/*      */     String text;
/*      */     
/*  894 */     switch (p.currentTokenId()) {
/*      */     case 6: 
/*  896 */       text = p.getText();
/*  897 */       break;
/*      */     case 8: 
/*  899 */       CoercionAction act = _checkFloatToIntCoercion(p, ctxt, targetType);
/*  900 */       if (act == CoercionAction.AsNull) {
/*  901 */         return (Long)getNullValue(ctxt);
/*      */       }
/*  903 */       if (act == CoercionAction.AsEmpty) {
/*  904 */         return (Long)getEmptyValue(ctxt);
/*      */       }
/*  906 */       return Long.valueOf(p.getValueAsLong());
/*      */     case 11: 
/*  908 */       return (Long)getNullValue(ctxt);
/*      */     case 7: 
/*  910 */       return Long.valueOf(p.getLongValue());
/*      */     
/*      */     case 1: 
/*  913 */       text = ctxt.extractScalarFromObject(p, this, targetType);
/*  914 */       break;
/*      */     case 3: 
/*  916 */       return (Long)_deserializeFromArray(p, ctxt);
/*      */     case 2: case 4: case 5: case 9: case 10: default: 
/*  918 */       return (Long)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */     }
/*      */     
/*  921 */     CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  922 */     if (act == CoercionAction.AsNull) {
/*  923 */       return (Long)getNullValue(ctxt);
/*      */     }
/*  925 */     if (act == CoercionAction.AsEmpty) {
/*  926 */       return (Long)getEmptyValue(ctxt);
/*      */     }
/*  928 */     String text = text.trim();
/*  929 */     if (_checkTextualNull(ctxt, text)) {
/*  930 */       return (Long)getNullValue(ctxt);
/*      */     }
/*      */     
/*  933 */     return Long.valueOf(_parseLongPrimitive(ctxt, text));
/*      */   }
/*      */   
/*      */   protected final float _parseFloatPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException
/*      */   {
/*      */     String text;
/*      */     String text;
/*  940 */     switch (p.currentTokenId()) {
/*      */     case 6: 
/*  942 */       text = p.getText();
/*  943 */       break;
/*      */     case 7: 
/*      */     case 8: 
/*  946 */       return p.getFloatValue();
/*      */     case 11: 
/*  948 */       _verifyNullForPrimitive(ctxt);
/*  949 */       return 0.0F;
/*      */     
/*      */     case 1: 
/*  952 */       text = ctxt.extractScalarFromObject(p, this, Float.TYPE);
/*  953 */       break;
/*      */     case 3: 
/*  955 */       if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  956 */         p.nextToken();
/*  957 */         float parsed = _parseFloatPrimitive(p, ctxt);
/*  958 */         _verifyEndArrayForSingle(p, ctxt);
/*  959 */         return parsed;
/*      */       }
/*      */       break;
/*      */     }
/*  963 */     return ((Number)ctxt.handleUnexpectedToken(Float.TYPE, p)).floatValue();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  970 */     Float nan = _checkFloatSpecialValue(text);
/*  971 */     if (nan != null) {
/*  972 */       return nan.floatValue();
/*      */     }
/*      */     
/*      */ 
/*  976 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, Float.TYPE);
/*      */     
/*  978 */     if (act == CoercionAction.AsNull) {
/*  979 */       return 0.0F;
/*      */     }
/*  981 */     if (act == CoercionAction.AsEmpty) {
/*  982 */       return 0.0F;
/*      */     }
/*  984 */     String text = text.trim();
/*  985 */     if (_hasTextualNull(text)) {
/*  986 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  987 */       return 0.0F;
/*      */     }
/*  989 */     return _parseFloatPrimitive(ctxt, text);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final float _parseFloatPrimitive(DeserializationContext ctxt, String text)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/*  999 */       return Float.parseFloat(text);
/*      */     } catch (IllegalArgumentException localIllegalArgumentException) {
/* 1001 */       Number v = (Number)ctxt.handleWeirdStringValue(Float.TYPE, text, "not a valid `float` value", new Object[0]);
/*      */       
/* 1003 */       return _nonNullNumber(v).floatValue();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Float _checkFloatSpecialValue(String text)
/*      */   {
/* 1020 */     if (!text.isEmpty()) {
/* 1021 */       switch (text.charAt(0)) {
/*      */       case 'I': 
/* 1023 */         if (_isPosInf(text)) {
/* 1024 */           return Float.valueOf(Float.POSITIVE_INFINITY);
/*      */         }
/*      */         break;
/*      */       case 'N': 
/* 1028 */         if (_isNaN(text)) return Float.valueOf(NaN.0F);
/*      */         break;
/*      */       case '-': 
/* 1031 */         if (_isNegInf(text)) {
/* 1032 */           return Float.valueOf(Float.NEGATIVE_INFINITY);
/*      */         }
/*      */         break;
/*      */       }
/*      */       
/*      */     }
/* 1038 */     return null;
/*      */   }
/*      */   
/*      */   protected final double _parseDoublePrimitive(JsonParser p, DeserializationContext ctxt) throws IOException
/*      */   {
/*      */     String text;
/*      */     String text;
/* 1045 */     switch (p.currentTokenId()) {
/*      */     case 6: 
/* 1047 */       text = p.getText();
/* 1048 */       break;
/*      */     case 7: 
/*      */     case 8: 
/* 1051 */       return p.getDoubleValue();
/*      */     case 11: 
/* 1053 */       _verifyNullForPrimitive(ctxt);
/* 1054 */       return 0.0D;
/*      */     
/*      */     case 1: 
/* 1057 */       text = ctxt.extractScalarFromObject(p, this, Double.TYPE);
/* 1058 */       break;
/*      */     case 3: 
/* 1060 */       if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/* 1061 */         p.nextToken();
/* 1062 */         double parsed = _parseDoublePrimitive(p, ctxt);
/* 1063 */         _verifyEndArrayForSingle(p, ctxt);
/* 1064 */         return parsed;
/*      */       }
/*      */       break;
/*      */     }
/* 1068 */     return ((Number)ctxt.handleUnexpectedToken(Double.TYPE, p)).doubleValue();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1075 */     Double nan = _checkDoubleSpecialValue(text);
/* 1076 */     if (nan != null) {
/* 1077 */       return nan.doubleValue();
/*      */     }
/*      */     
/*      */ 
/* 1081 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, Double.TYPE);
/*      */     
/* 1083 */     if (act == CoercionAction.AsNull) {
/* 1084 */       return 0.0D;
/*      */     }
/* 1086 */     if (act == CoercionAction.AsEmpty) {
/* 1087 */       return 0.0D;
/*      */     }
/* 1089 */     String text = text.trim();
/* 1090 */     if (_hasTextualNull(text)) {
/* 1091 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/* 1092 */       return 0.0D;
/*      */     }
/* 1094 */     return _parseDoublePrimitive(ctxt, text);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final double _parseDoublePrimitive(DeserializationContext ctxt, String text)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/* 1104 */       return _parseDouble(text);
/*      */     } catch (IllegalArgumentException localIllegalArgumentException) {
/* 1106 */       Number v = (Number)ctxt.handleWeirdStringValue(Double.TYPE, text, "not a valid `double` value (as String to convert)", new Object[0]);
/*      */       
/* 1108 */       return _nonNullNumber(v).doubleValue();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final double _parseDouble(String numStr)
/*      */     throws NumberFormatException
/*      */   {
/* 1118 */     if ("2.2250738585072012e-308".equals(numStr)) {
/* 1119 */       return 2.2250738585072014E-308D;
/*      */     }
/* 1121 */     return Double.parseDouble(numStr);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Double _checkDoubleSpecialValue(String text)
/*      */   {
/* 1138 */     if (!text.isEmpty()) {
/* 1139 */       switch (text.charAt(0)) {
/*      */       case 'I': 
/* 1141 */         if (_isPosInf(text)) {
/* 1142 */           return Double.valueOf(Double.POSITIVE_INFINITY);
/*      */         }
/*      */         break;
/*      */       case 'N': 
/* 1146 */         if (_isNaN(text)) {
/* 1147 */           return Double.valueOf(NaN.0D);
/*      */         }
/*      */         break;
/*      */       case '-': 
/* 1151 */         if (_isNegInf(text)) {
/* 1152 */           return Double.valueOf(Double.NEGATIVE_INFINITY);
/*      */         }
/*      */         break;
/*      */       }
/*      */       
/*      */     }
/* 1158 */     return null;
/*      */   }
/*      */   
/*      */   protected Date _parseDate(JsonParser p, DeserializationContext ctxt) throws IOException
/*      */   {
/*      */     String text;
/*      */     String text;
/* 1165 */     switch (p.currentTokenId()) {
/*      */     case 6: 
/* 1167 */       text = p.getText();
/* 1168 */       break;
/*      */     case 7: 
/*      */       long ts;
/*      */       try
/*      */       {
/* 1173 */         ts = p.getLongValue();
/*      */       }
/*      */       catch (JsonParseException|InputCoercionException e) {
/*      */         long ts;
/* 1177 */         Number v = (Number)ctxt.handleWeirdNumberValue(this._valueClass, p.getNumberValue(), "not a valid 64-bit `long` for creating `java.util.Date`", new Object[0]);
/*      */         
/* 1179 */         ts = v.longValue();
/*      */       }
/* 1181 */       return new Date(ts);
/*      */     
/*      */     case 11: 
/* 1184 */       return (Date)getNullValue(ctxt);
/*      */     
/*      */     case 1: 
/* 1187 */       text = ctxt.extractScalarFromObject(p, this, this._valueClass);
/* 1188 */       break;
/*      */     case 3: 
/* 1190 */       return _parseDateFromArray(p, ctxt);
/*      */     case 2: case 4: case 5: case 8: case 9: case 10: default: 
/* 1192 */       return (Date)ctxt.handleUnexpectedToken(this._valueClass, p);
/*      */     }
/*      */     String text;
/* 1195 */     return _parseDate(text.trim(), ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */   protected Date _parseDateFromArray(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1202 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/* 1203 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*      */     
/* 1205 */     if ((unwrap) || (act != CoercionAction.Fail)) {
/* 1206 */       JsonToken t = p.nextToken();
/* 1207 */       if (t == JsonToken.END_ARRAY) {
/* 1208 */         switch (act) {
/*      */         case AsEmpty: 
/* 1210 */           return (Date)getEmptyValue(ctxt);
/*      */         case AsNull: 
/*      */         case TryConvert: 
/* 1213 */           return (Date)getNullValue(ctxt);
/*      */         }
/*      */       }
/* 1216 */       else if (unwrap) {
/* 1217 */         Date parsed = _parseDate(p, ctxt);
/* 1218 */         _verifyEndArrayForSingle(p, ctxt);
/* 1219 */         return parsed;
/*      */       }
/*      */     }
/* 1222 */     return (Date)ctxt.handleUnexpectedToken(this._valueClass, JsonToken.START_ARRAY, p, null, new Object[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Date _parseDate(String value, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/*      */     try
/*      */     {
/* 1233 */       if (value.isEmpty()) {
/* 1234 */         CoercionAction act = _checkFromStringCoercion(ctxt, value);
/* 1235 */         switch (act) {
/*      */         case AsEmpty: 
/* 1237 */           return new Date(0L);
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 1242 */         return null;
/*      */       }
/*      */       
/* 1245 */       if (_hasTextualNull(value)) {
/* 1246 */         return null;
/*      */       }
/* 1248 */       return ctxt.parseDate(value);
/*      */     } catch (IllegalArgumentException iae) {}
/* 1250 */     return (Date)ctxt.handleWeirdStringValue(this._valueClass, value, "not a valid representation (error: %s)", tmp88_85);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final String _parseString(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1264 */     if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 1265 */       return p.getText();
/*      */     }
/*      */     
/* 1268 */     if (p.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 1269 */       Object ob = p.getEmbeddedObject();
/* 1270 */       if ((ob instanceof byte[])) {
/* 1271 */         return ctxt.getBase64Variant().encode((byte[])ob, false);
/*      */       }
/* 1273 */       if (ob == null) {
/* 1274 */         return null;
/*      */       }
/*      */       
/* 1277 */       return ob.toString();
/*      */     }
/*      */     
/* 1280 */     if (p.hasToken(JsonToken.START_OBJECT)) {
/* 1281 */       return ctxt.extractScalarFromObject(p, this, this._valueClass);
/*      */     }
/*      */     
/* 1284 */     String value = p.getValueAsString();
/* 1285 */     if (value != null) {
/* 1286 */       return value;
/*      */     }
/* 1288 */     return (String)ctxt.handleUnexpectedToken(String.class, p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _hasTextualNull(String value)
/*      */   {
/* 1299 */     return "null".equals(value);
/*      */   }
/*      */   
/*      */   protected final boolean _isNegInf(String text) {
/* 1303 */     return ("-Infinity".equals(text)) || ("-INF".equals(text));
/*      */   }
/*      */   
/*      */   protected final boolean _isPosInf(String text) {
/* 1307 */     return ("Infinity".equals(text)) || ("INF".equals(text));
/*      */   }
/*      */   
/* 1310 */   protected final boolean _isNaN(String text) { return "NaN".equals(text); }
/*      */   
/*      */ 
/*      */   protected static final boolean _isBlank(String text)
/*      */   {
/* 1315 */     int len = text.length();
/* 1316 */     for (int i = 0; i < len; i++) {
/* 1317 */       if (text.charAt(i) > ' ') {
/* 1318 */         return false;
/*      */       }
/*      */     }
/* 1321 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected CoercionAction _checkFromStringCoercion(DeserializationContext ctxt, String value)
/*      */     throws IOException
/*      */   {
/* 1336 */     return _checkFromStringCoercion(ctxt, value, logicalType(), handledType());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected CoercionAction _checkFromStringCoercion(DeserializationContext ctxt, String value, LogicalType logicalType, Class<?> rawTargetType)
/*      */     throws IOException
/*      */   {
/* 1353 */     if (value.isEmpty()) {
/* 1354 */       CoercionAction act = ctxt.findCoercionAction(logicalType, rawTargetType, CoercionInputShape.EmptyString);
/*      */       
/* 1356 */       return _checkCoercionFail(ctxt, act, rawTargetType, value, "empty String (\"\")");
/*      */     }
/* 1358 */     if (_isBlank(value)) {
/* 1359 */       CoercionAction act = ctxt.findCoercionFromBlankString(logicalType, rawTargetType, CoercionAction.Fail);
/* 1360 */       return _checkCoercionFail(ctxt, act, rawTargetType, value, "blank String (all whitespace)");
/*      */     }
/*      */     
/*      */ 
/* 1364 */     if (ctxt.isEnabled(StreamReadCapability.UNTYPED_SCALARS)) {
/* 1365 */       return CoercionAction.TryConvert;
/*      */     }
/* 1367 */     CoercionAction act = ctxt.findCoercionAction(logicalType, rawTargetType, CoercionInputShape.String);
/* 1368 */     if (act == CoercionAction.Fail)
/*      */     {
/* 1370 */       ctxt.reportInputMismatch(this, "Cannot coerce String value (\"%s\") to %s (but might if coercion using `CoercionConfig` was enabled)", new Object[] { value, 
/*      */       
/* 1372 */         _coercedTypeDesc() });
/*      */     }
/*      */     
/* 1375 */     return act;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected CoercionAction _checkFloatToIntCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType)
/*      */     throws IOException
/*      */   {
/* 1385 */     CoercionAction act = ctxt.findCoercionAction(LogicalType.Integer, rawTargetType, CoercionInputShape.Float);
/*      */     
/* 1387 */     if (act == CoercionAction.Fail) {
/* 1388 */       return _checkCoercionFail(ctxt, act, rawTargetType, p.getNumberValue(), "Floating-point value (" + p
/* 1389 */         .getText() + ")");
/*      */     }
/* 1391 */     return act;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Boolean _coerceBooleanFromInt(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType)
/*      */     throws IOException
/*      */   {
/* 1401 */     CoercionAction act = ctxt.findCoercionAction(LogicalType.Boolean, rawTargetType, CoercionInputShape.Integer);
/* 1402 */     switch (act) {
/*      */     case Fail: 
/* 1404 */       _checkCoercionFail(ctxt, act, rawTargetType, p.getNumberValue(), "Integer value (" + p
/* 1405 */         .getText() + ")");
/* 1406 */       return Boolean.FALSE;
/*      */     case AsNull: 
/* 1408 */       return null;
/*      */     case AsEmpty: 
/* 1410 */       return Boolean.FALSE;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/* 1416 */     if (p.getNumberType() == JsonParser.NumberType.INT)
/*      */     {
/* 1418 */       return Boolean.valueOf(p.getIntValue() != 0);
/*      */     }
/* 1420 */     return Boolean.valueOf(!"0".equals(p.getText()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected CoercionAction _checkCoercionFail(DeserializationContext ctxt, CoercionAction act, Class<?> targetType, Object inputValue, String inputDesc)
/*      */     throws IOException
/*      */   {
/* 1431 */     if (act == CoercionAction.Fail) {
/* 1432 */       ctxt.reportBadCoercion(this, targetType, inputValue, "Cannot coerce %s to %s (but could if coercion was enabled using `CoercionConfig`)", new Object[] { inputDesc, 
/*      */       
/* 1434 */         _coercedTypeDesc() });
/*      */     }
/* 1436 */     return act;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _checkTextualNull(DeserializationContext ctxt, String text)
/*      */     throws JsonMappingException
/*      */   {
/* 1449 */     if (_hasTextualNull(text)) {
/* 1450 */       if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1451 */         _reportFailedNullCoerce(ctxt, true, MapperFeature.ALLOW_COERCION_OF_SCALARS, "String \"null\"");
/*      */       }
/* 1453 */       return true;
/*      */     }
/* 1455 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object _coerceIntegral(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1477 */     int feats = ctxt.getDeserializationFeatures();
/* 1478 */     if (DeserializationFeature.USE_BIG_INTEGER_FOR_INTS.enabledIn(feats)) {
/* 1479 */       return p.getBigIntegerValue();
/*      */     }
/* 1481 */     if (DeserializationFeature.USE_LONG_FOR_INTS.enabledIn(feats)) {
/* 1482 */       return Long.valueOf(p.getLongValue());
/*      */     }
/* 1484 */     return p.getNumberValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _verifyNullForPrimitive(DeserializationContext ctxt)
/*      */     throws JsonMappingException
/*      */   {
/* 1497 */     if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)) {
/* 1498 */       ctxt.reportInputMismatch(this, "Cannot coerce `null` to %s (disable `DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES` to allow)", new Object[] {
/*      */       
/* 1500 */         _coercedTypeDesc() });
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _verifyNullForPrimitiveCoercion(DeserializationContext ctxt, String str)
/*      */     throws JsonMappingException
/*      */   {
/*      */     boolean enable;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1517 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1518 */       Enum<?> feat = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1519 */       enable = true; } else { boolean enable;
/* 1520 */       if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)) {
/* 1521 */         Enum<?> feat = DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES;
/* 1522 */         enable = false;
/*      */       } else { return; } }
/*      */     boolean enable;
/*      */     Enum<?> feat;
/* 1526 */     String strDesc = str.isEmpty() ? "empty String (\"\")" : String.format("String \"%s\"", new Object[] { str });
/* 1527 */     _reportFailedNullCoerce(ctxt, enable, feat, strDesc);
/*      */   }
/*      */   
/*      */   protected void _reportFailedNullCoerce(DeserializationContext ctxt, boolean state, Enum<?> feature, String inputDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 1533 */     String enableDesc = state ? "enable" : "disable";
/* 1534 */     ctxt.reportInputMismatch(this, "Cannot coerce %s to Null value as %s (%s `%s.%s` to allow)", new Object[] { inputDesc, 
/* 1535 */       _coercedTypeDesc(), enableDesc, feature.getDeclaringClass().getSimpleName(), feature.name() });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String _coercedTypeDesc()
/*      */   {
/* 1551 */     JavaType t = getValueType();
/* 1552 */     String typeDesc; boolean structured; String typeDesc; if ((t != null) && (!t.isPrimitive())) {
/* 1553 */       boolean structured = (t.isContainerType()) || (t.isReferenceType());
/* 1554 */       typeDesc = ClassUtil.getTypeDescription(t);
/*      */     } else {
/* 1556 */       Class<?> cls = handledType();
/*      */       
/* 1558 */       structured = (cls.isArray()) || (Collection.class.isAssignableFrom(cls)) || (Map.class.isAssignableFrom(cls));
/* 1559 */       typeDesc = ClassUtil.getClassDescription(cls);
/*      */     }
/* 1561 */     if (structured) {
/* 1562 */       return "element of " + typeDesc;
/*      */     }
/* 1564 */     return typeDesc + " value";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected boolean _parseBooleanFromInt(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1581 */     _verifyNumberForScalarCoercion(ctxt, p);
/*      */     
/*      */ 
/* 1584 */     return !"0".equals(p.getText());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected void _verifyStringForScalarCoercion(DeserializationContext ctxt, String str)
/*      */     throws JsonMappingException
/*      */   {
/* 1593 */     MapperFeature feat = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1594 */     if (!ctxt.isEnabled(feat)) {
/* 1595 */       ctxt.reportInputMismatch(this, "Cannot coerce String \"%s\" to %s (enable `%s.%s` to allow)", new Object[] { str, 
/* 1596 */         _coercedTypeDesc(), feat.getDeclaringClass().getSimpleName(), feat.name() });
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected Object _coerceEmptyString(DeserializationContext ctxt, boolean isPrimitive)
/*      */     throws JsonMappingException
/*      */   {
/*      */     boolean enable;
/*      */     
/*      */ 
/*      */ 
/* 1611 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1612 */       Enum<?> feat = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1613 */       enable = true; } else { boolean enable;
/* 1614 */       if ((isPrimitive) && (ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES))) {
/* 1615 */         Enum<?> feat = DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES;
/* 1616 */         enable = false;
/*      */       } else {
/* 1618 */         return getNullValue(ctxt); } }
/*      */     boolean enable;
/* 1620 */     Enum<?> feat; _reportFailedNullCoerce(ctxt, enable, feat, "empty String (\"\")");
/* 1621 */     return null;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected void _failDoubleToIntCoercion(JsonParser p, DeserializationContext ctxt, String type)
/*      */     throws IOException
/*      */   {
/* 1628 */     ctxt.reportInputMismatch(handledType(), "Cannot coerce a floating-point value ('%s') into %s (enable `DeserializationFeature.ACCEPT_FLOAT_AS_INT` to allow)", new Object[] {p
/*      */     
/* 1630 */       .getValueAsString(), type });
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected final void _verifyNullForScalarCoercion(DeserializationContext ctxt, String str) throws JsonMappingException
/*      */   {
/* 1636 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1637 */       String strDesc = str.isEmpty() ? "empty String (\"\")" : String.format("String \"%s\"", new Object[] { str });
/* 1638 */       _reportFailedNullCoerce(ctxt, true, MapperFeature.ALLOW_COERCION_OF_SCALARS, strDesc);
/*      */     }
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected void _verifyNumberForScalarCoercion(DeserializationContext ctxt, JsonParser p) throws IOException
/*      */   {
/* 1645 */     MapperFeature feat = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1646 */     if (!ctxt.isEnabled(feat))
/*      */     {
/*      */ 
/* 1649 */       String valueDesc = p.getText();
/* 1650 */       ctxt.reportInputMismatch(this, "Cannot coerce Number (%s) to %s (enable `%s.%s` to allow)", new Object[] { valueDesc, 
/* 1651 */         _coercedTypeDesc(), feat.getDeclaringClass().getSimpleName(), feat.name() });
/*      */     }
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected Object _coerceNullToken(DeserializationContext ctxt, boolean isPrimitive) throws JsonMappingException
/*      */   {
/* 1658 */     if (isPrimitive) {
/* 1659 */       _verifyNullForPrimitive(ctxt);
/*      */     }
/* 1661 */     return getNullValue(ctxt);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected Object _coerceTextualNull(DeserializationContext ctxt, boolean isPrimitive) throws JsonMappingException {
/* 1666 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1667 */       _reportFailedNullCoerce(ctxt, true, MapperFeature.ALLOW_COERCION_OF_SCALARS, "String \"null\"");
/*      */     }
/* 1669 */     return getNullValue(ctxt);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected boolean _isEmptyOrTextualNull(String value) {
/* 1674 */     return (value.isEmpty()) || ("null".equals(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> findDeserializer(DeserializationContext ctxt, JavaType type, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/* 1696 */     return ctxt.findContextualValueDeserializer(type, property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean _isIntNumber(String text)
/*      */   {
/* 1708 */     int len = text.length();
/* 1709 */     if (len > 0) {
/* 1710 */       char c = text.charAt(0);
/*      */       
/*      */       int i;
/*      */       
/* 1714 */       if ((c == '-') || (c == '+')) {
/* 1715 */         if (len == 1) {
/* 1716 */           return false;
/*      */         }
/* 1718 */         i = 1;
/*      */       }
/* 1720 */       for (int i = 0; 
/*      */           
/*      */ 
/* 1723 */           i < len; i++) {
/* 1724 */         int ch = text.charAt(i);
/* 1725 */         if ((ch > 57) || (ch < 48)) {
/* 1726 */           return false;
/*      */         }
/*      */       }
/* 1729 */       return true;
/*      */     }
/* 1731 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<?> findConvertingContentDeserializer(DeserializationContext ctxt, BeanProperty prop, JsonDeserializer<?> existingDeserializer)
/*      */     throws JsonMappingException
/*      */   {
/* 1754 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 1755 */     if (_neitherNull(intr, prop)) {
/* 1756 */       AnnotatedMember member = prop.getMember();
/* 1757 */       if (member != null) {
/* 1758 */         Object convDef = intr.findDeserializationContentConverter(member);
/* 1759 */         if (convDef != null) {
/* 1760 */           Converter<Object, Object> conv = ctxt.converterInstance(prop.getMember(), convDef);
/* 1761 */           JavaType delegateType = conv.getInputType(ctxt.getTypeFactory());
/* 1762 */           if (existingDeserializer == null) {
/* 1763 */             existingDeserializer = ctxt.findContextualValueDeserializer(delegateType, prop);
/*      */           }
/* 1765 */           return new StdDelegatingDeserializer(conv, delegateType, existingDeserializer);
/*      */         }
/*      */       }
/*      */     }
/* 1769 */     return existingDeserializer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonFormat.Value findFormatOverrides(DeserializationContext ctxt, BeanProperty prop, Class<?> typeForDefaults)
/*      */   {
/* 1790 */     if (prop != null) {
/* 1791 */       return prop.findPropertyFormat(ctxt.getConfig(), typeForDefaults);
/*      */     }
/*      */     
/* 1794 */     return ctxt.getDefaultPropertyFormat(typeForDefaults);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Boolean findFormatFeature(DeserializationContext ctxt, BeanProperty prop, Class<?> typeForDefaults, JsonFormat.Feature feat)
/*      */   {
/* 1810 */     JsonFormat.Value format = findFormatOverrides(ctxt, prop, typeForDefaults);
/* 1811 */     if (format != null) {
/* 1812 */       return format.getFeature(feat);
/*      */     }
/* 1814 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final NullValueProvider findValueNullProvider(DeserializationContext ctxt, SettableBeanProperty prop, PropertyMetadata propMetadata)
/*      */     throws JsonMappingException
/*      */   {
/* 1828 */     if (prop != null) {
/* 1829 */       return _findNullProvider(ctxt, prop, propMetadata.getValueNulls(), prop
/* 1830 */         .getValueDeserializer());
/*      */     }
/* 1832 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected NullValueProvider findContentNullProvider(DeserializationContext ctxt, BeanProperty prop, JsonDeserializer<?> valueDeser)
/*      */     throws JsonMappingException
/*      */   {
/* 1847 */     Nulls nulls = findContentNullStyle(ctxt, prop);
/* 1848 */     if (nulls == Nulls.SKIP) {
/* 1849 */       return NullsConstantProvider.skipper();
/*      */     }
/*      */     
/*      */ 
/* 1853 */     if (nulls == Nulls.FAIL) {
/* 1854 */       if (prop == null) {
/* 1855 */         JavaType type = ctxt.constructType(valueDeser.handledType());
/*      */         
/* 1857 */         if (type.isContainerType()) {
/* 1858 */           type = type.getContentType();
/*      */         }
/* 1860 */         return NullsFailProvider.constructForRootValue(type);
/*      */       }
/* 1862 */       return NullsFailProvider.constructForProperty(prop, prop.getType().getContentType());
/*      */     }
/*      */     
/* 1865 */     NullValueProvider prov = _findNullProvider(ctxt, prop, nulls, valueDeser);
/* 1866 */     if (prov != null) {
/* 1867 */       return prov;
/*      */     }
/* 1869 */     return valueDeser;
/*      */   }
/*      */   
/*      */   protected Nulls findContentNullStyle(DeserializationContext ctxt, BeanProperty prop)
/*      */     throws JsonMappingException
/*      */   {
/* 1875 */     if (prop != null) {
/* 1876 */       return prop.getMetadata().getContentNulls();
/*      */     }
/* 1878 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final NullValueProvider _findNullProvider(DeserializationContext ctxt, BeanProperty prop, Nulls nulls, JsonDeserializer<?> valueDeser)
/*      */     throws JsonMappingException
/*      */   {
/* 1886 */     if (nulls == Nulls.FAIL) {
/* 1887 */       if (prop == null) {
/* 1888 */         return NullsFailProvider.constructForRootValue(ctxt.constructType(valueDeser.handledType()));
/*      */       }
/* 1890 */       return NullsFailProvider.constructForProperty(prop);
/*      */     }
/* 1892 */     if (nulls == Nulls.AS_EMPTY)
/*      */     {
/*      */ 
/* 1895 */       if (valueDeser == null) {
/* 1896 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1902 */       if ((valueDeser instanceof BeanDeserializerBase)) {
/* 1903 */         ValueInstantiator vi = ((BeanDeserializerBase)valueDeser).getValueInstantiator();
/* 1904 */         if (!vi.canCreateUsingDefault()) {
/* 1905 */           JavaType type = prop.getType();
/* 1906 */           ctxt.reportBadDefinition(type, 
/* 1907 */             String.format("Cannot create empty instance of %s, no default Creator", new Object[] { type }));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1912 */       AccessPattern access = valueDeser.getEmptyAccessPattern();
/* 1913 */       if (access == AccessPattern.ALWAYS_NULL) {
/* 1914 */         return NullsConstantProvider.nuller();
/*      */       }
/* 1916 */       if (access == AccessPattern.CONSTANT) {
/* 1917 */         return NullsConstantProvider.forValue(valueDeser.getEmptyValue(ctxt));
/*      */       }
/*      */       
/* 1920 */       return new NullsAsEmptyProvider(valueDeser);
/*      */     }
/* 1922 */     if (nulls == Nulls.SKIP) {
/* 1923 */       return NullsConstantProvider.skipper();
/*      */     }
/* 1925 */     return null;
/*      */   }
/*      */   
/*      */   protected CoercionAction _findCoercionFromEmptyString(DeserializationContext ctxt)
/*      */   {
/* 1930 */     return ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyString);
/*      */   }
/*      */   
/*      */ 
/*      */   protected CoercionAction _findCoercionFromEmptyArray(DeserializationContext ctxt)
/*      */   {
/* 1936 */     return ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyArray);
/*      */   }
/*      */   
/*      */ 
/*      */   protected CoercionAction _findCoercionFromBlankString(DeserializationContext ctxt)
/*      */   {
/* 1942 */     return ctxt.findCoercionFromBlankString(logicalType(), handledType(), CoercionAction.Fail);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void handleUnknownProperty(JsonParser p, DeserializationContext ctxt, Object instanceOrClass, String propName)
/*      */     throws IOException
/*      */   {
/* 1970 */     if (instanceOrClass == null) {
/* 1971 */       instanceOrClass = handledType();
/*      */     }
/*      */     
/* 1974 */     if (ctxt.handleUnknownProperty(p, this, instanceOrClass, propName)) {
/* 1975 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1980 */     p.skipChildren();
/*      */   }
/*      */   
/*      */   protected void handleMissingEndArrayForSingle(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1986 */     ctxt.reportWrongTokenException(this, JsonToken.END_ARRAY, "Attempted to unwrap '%s' value from an array (with `DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS`) but it contains more than one value", new Object[] {
/*      */     
/* 1988 */       handledType().getName() });
/*      */   }
/*      */   
/*      */ 
/*      */   protected void _verifyEndArrayForSingle(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/* 1995 */     JsonToken t = p.nextToken();
/* 1996 */     if (t != JsonToken.END_ARRAY) {
/* 1997 */       handleMissingEndArrayForSingle(p, ctxt);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final boolean _neitherNull(Object a, Object b)
/*      */   {
/* 2011 */     return (a != null) && (b != null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean _byteOverflow(int value)
/*      */   {
/* 2020 */     return (value < -128) || (value > 255);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final boolean _shortOverflow(int value)
/*      */   {
/* 2027 */     return (value < 32768) || (value > 32767);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final boolean _intOverflow(long value)
/*      */   {
/* 2034 */     return (value < -2147483648L) || (value > 2147483647L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Number _nonNullNumber(Number n)
/*      */   {
/* 2041 */     if (n == null) {
/* 2042 */       n = Integer.valueOf(0);
/*      */     }
/* 2044 */     return n;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\std\StdDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */