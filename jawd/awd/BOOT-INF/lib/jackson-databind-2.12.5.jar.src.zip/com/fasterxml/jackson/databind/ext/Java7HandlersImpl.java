/*    */ package com.fasterxml.jackson.databind.ext;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import java.nio.file.Path;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Java7HandlersImpl
/*    */   extends Java7Handlers
/*    */ {
/*    */   private final Class<?> _pathClass;
/*    */   
/*    */   public Java7HandlersImpl()
/*    */   {
/* 18 */     this._pathClass = Path.class;
/*    */   }
/*    */   
/*    */   public Class<?> getClassJavaNioFilePath()
/*    */   {
/* 23 */     return this._pathClass;
/*    */   }
/*    */   
/*    */   public JsonDeserializer<?> getDeserializerForJavaNioFilePath(Class<?> rawType)
/*    */   {
/* 28 */     if (rawType == this._pathClass) {
/* 29 */       return new NioPathDeserializer();
/*    */     }
/* 31 */     return null;
/*    */   }
/*    */   
/*    */   public JsonSerializer<?> getSerializerForJavaNioFilePath(Class<?> rawType)
/*    */   {
/* 36 */     if (this._pathClass.isAssignableFrom(rawType)) {
/* 37 */       return new NioPathSerializer();
/*    */     }
/* 39 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\ext\Java7HandlersImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */