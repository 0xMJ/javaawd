/*     */ package com.fasterxml.jackson.databind.util;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnumResolver
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Class<Enum<?>> _enumClass;
/*     */   protected final Enum<?>[] _enums;
/*     */   protected final HashMap<String, Enum<?>> _enumsById;
/*     */   protected final Enum<?> _defaultValue;
/*     */   protected final boolean _isIgnoreCase;
/*     */   
/*     */   protected EnumResolver(Class<Enum<?>> enumClass, Enum<?>[] enums, HashMap<String, Enum<?>> map, Enum<?> defaultValue, boolean isIgnoreCase)
/*     */   {
/*  38 */     this._enumClass = enumClass;
/*  39 */     this._enums = enums;
/*  40 */     this._enumsById = map;
/*  41 */     this._defaultValue = defaultValue;
/*  42 */     this._isIgnoreCase = isIgnoreCase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static EnumResolver constructFor(DeserializationConfig config, Class<?> enumCls)
/*     */   {
/*  53 */     return _constructFor(enumCls, config.getAnnotationIntrospector(), config
/*  54 */       .isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static EnumResolver _constructFor(Class<?> enumCls0, AnnotationIntrospector ai, boolean isIgnoreCase)
/*     */   {
/*  63 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/*  64 */     Enum<?>[] enumConstants = _enumConstants(enumCls0);
/*  65 */     String[] names = ai.findEnumValues(enumCls, enumConstants, new String[enumConstants.length]);
/*  66 */     String[][] allAliases = new String[names.length][];
/*  67 */     ai.findEnumAliases(enumCls, enumConstants, allAliases);
/*  68 */     HashMap<String, Enum<?>> map = new HashMap();
/*  69 */     int i = 0; for (int len = enumConstants.length; i < len; i++) {
/*  70 */       Enum<?> enumValue = enumConstants[i];
/*  71 */       String name = names[i];
/*  72 */       if (name == null) {
/*  73 */         name = enumValue.name();
/*     */       }
/*  75 */       map.put(name, enumValue);
/*  76 */       String[] aliases = allAliases[i];
/*  77 */       if (aliases != null) {
/*  78 */         for (String alias : aliases)
/*     */         {
/*     */ 
/*  81 */           if (!map.containsKey(alias)) {
/*  82 */             map.put(alias, enumValue);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  87 */     return new EnumResolver(enumCls, enumConstants, map, 
/*  88 */       _enumDefault(ai, enumCls), isIgnoreCase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static EnumResolver constructUsingToString(DeserializationConfig config, Class<?> enumCls)
/*     */   {
/*  99 */     return _constructUsingToString(enumCls, config.getAnnotationIntrospector(), config
/* 100 */       .isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static EnumResolver _constructUsingToString(Class<?> enumCls0, AnnotationIntrospector ai, boolean isIgnoreCase)
/*     */   {
/* 109 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 110 */     Enum<?>[] enumConstants = _enumConstants(enumCls0);
/* 111 */     HashMap<String, Enum<?>> map = new HashMap();
/* 112 */     String[][] allAliases = new String[enumConstants.length][];
/* 113 */     ai.findEnumAliases(enumCls, enumConstants, allAliases);
/*     */     
/*     */ 
/* 116 */     int i = enumConstants.length; for (;;) { i--; if (i < 0) break;
/* 117 */       Enum<?> enumValue = enumConstants[i];
/* 118 */       map.put(enumValue.toString(), enumValue);
/* 119 */       String[] aliases = allAliases[i];
/* 120 */       if (aliases != null) {
/* 121 */         for (String alias : aliases)
/*     */         {
/*     */ 
/* 124 */           if (!map.containsKey(alias)) {
/* 125 */             map.put(alias, enumValue);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 130 */     return new EnumResolver(enumCls, enumConstants, map, 
/* 131 */       _enumDefault(ai, enumCls), isIgnoreCase);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static EnumResolver constructUsingMethod(DeserializationConfig config, Class<?> enumCls, AnnotatedMember accessor)
/*     */   {
/* 142 */     return _constructUsingMethod(enumCls, accessor, config.getAnnotationIntrospector(), config
/* 143 */       .isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static EnumResolver _constructUsingMethod(Class<?> enumCls0, AnnotatedMember accessor, AnnotationIntrospector ai, boolean isIgnoreCase)
/*     */   {
/* 152 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 153 */     Enum<?>[] enumConstants = _enumConstants(enumCls0);
/* 154 */     HashMap<String, Enum<?>> map = new HashMap();
/*     */     
/* 156 */     int i = enumConstants.length; for (;;) { i--; if (i < 0) break;
/* 157 */       Enum<?> en = enumConstants[i];
/*     */       try {
/* 159 */         Object o = accessor.getValue(en);
/* 160 */         if (o != null) {
/* 161 */           map.put(o.toString(), en);
/*     */         }
/*     */       } catch (Exception e) {
/* 164 */         throw new IllegalArgumentException("Failed to access @JsonValue of Enum value " + en + ": " + e.getMessage());
/*     */       }
/*     */     }
/* 167 */     return new EnumResolver(enumCls, enumConstants, map, 
/* 168 */       _enumDefault(ai, enumCls), isIgnoreCase);
/*     */   }
/*     */   
/*     */   public CompactStringObjectMap constructLookup() {
/* 172 */     return CompactStringObjectMap.construct(this._enumsById);
/*     */   }
/*     */   
/*     */   protected static Class<Enum<?>> _enumClass(Class<?> enumCls0)
/*     */   {
/* 177 */     return enumCls0;
/*     */   }
/*     */   
/*     */   protected static Enum<?>[] _enumConstants(Class<?> enumCls) {
/* 181 */     Enum<?>[] enumValues = (Enum[])_enumClass(enumCls).getEnumConstants();
/* 182 */     if (enumValues == null) {
/* 183 */       throw new IllegalArgumentException("No enum constants for class " + enumCls.getName());
/*     */     }
/* 185 */     return enumValues;
/*     */   }
/*     */   
/*     */   protected static Enum<?> _enumDefault(AnnotationIntrospector intr, Class<?> enumCls) {
/* 189 */     return intr != null ? intr.findDefaultEnumValue(_enumClass(enumCls)) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected EnumResolver(Class<Enum<?>> enumClass, Enum<?>[] enums, HashMap<String, Enum<?>> map, Enum<?> defaultValue)
/*     */   {
/* 204 */     this(enumClass, enums, map, defaultValue, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static EnumResolver constructFor(Class<Enum<?>> enumCls, AnnotationIntrospector ai)
/*     */   {
/* 212 */     return _constructFor(enumCls, ai, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static EnumResolver constructUnsafe(Class<?> rawEnumCls, AnnotationIntrospector ai)
/*     */   {
/* 220 */     return _constructFor(rawEnumCls, ai, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static EnumResolver constructUsingToString(Class<Enum<?>> enumCls, AnnotationIntrospector ai)
/*     */   {
/* 229 */     return _constructUsingToString(enumCls, ai, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static EnumResolver constructUnsafeUsingToString(Class<?> rawEnumCls, AnnotationIntrospector ai)
/*     */   {
/* 239 */     return _constructUsingToString(rawEnumCls, ai, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static EnumResolver constructUsingToString(Class<Enum<?>> enumCls)
/*     */   {
/* 247 */     return _constructUsingToString(enumCls, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static EnumResolver constructUsingMethod(Class<Enum<?>> enumCls, AnnotatedMember accessor, AnnotationIntrospector ai)
/*     */   {
/* 256 */     return _constructUsingMethod(enumCls, accessor, ai, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static EnumResolver constructUnsafeUsingMethod(Class<?> rawEnumCls, AnnotatedMember accessor, AnnotationIntrospector ai)
/*     */   {
/* 266 */     return _constructUsingMethod(rawEnumCls, accessor, ai, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Enum<?> findEnum(String key)
/*     */   {
/* 276 */     Enum<?> en = (Enum)this._enumsById.get(key);
/* 277 */     if ((en == null) && 
/* 278 */       (this._isIgnoreCase)) {
/* 279 */       return _findEnumCaseInsensitive(key);
/*     */     }
/*     */     
/* 282 */     return en;
/*     */   }
/*     */   
/*     */   protected Enum<?> _findEnumCaseInsensitive(String key)
/*     */   {
/* 287 */     for (Map.Entry<String, Enum<?>> entry : this._enumsById.entrySet()) {
/* 288 */       if (key.equalsIgnoreCase((String)entry.getKey())) {
/* 289 */         return (Enum)entry.getValue();
/*     */       }
/*     */     }
/* 292 */     return null;
/*     */   }
/*     */   
/*     */   public Enum<?> getEnum(int index) {
/* 296 */     if ((index < 0) || (index >= this._enums.length)) {
/* 297 */       return null;
/*     */     }
/* 299 */     return this._enums[index];
/*     */   }
/*     */   
/*     */   public Enum<?> getDefaultValue() {
/* 303 */     return this._defaultValue;
/*     */   }
/*     */   
/*     */   public Enum<?>[] getRawEnums() {
/* 307 */     return this._enums;
/*     */   }
/*     */   
/*     */   public List<Enum<?>> getEnums() {
/* 311 */     ArrayList<Enum<?>> enums = new ArrayList(this._enums.length);
/* 312 */     for (Enum<?> e : this._enums) {
/* 313 */       enums.add(e);
/*     */     }
/* 315 */     return enums;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection<String> getEnumIds()
/*     */   {
/* 322 */     return this._enumsById.keySet();
/*     */   }
/*     */   
/* 325 */   public Class<Enum<?>> getEnumClass() { return this._enumClass; }
/*     */   
/* 327 */   public int lastValidIndex() { return this._enums.length - 1; }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\util\EnumResolver.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */