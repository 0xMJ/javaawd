/*     */ package com.fasterxml.jackson.databind.ser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException.Reference;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
/*     */ import com.fasterxml.jackson.databind.ser.std.BeanSerializerBase;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanAsArraySerializer
/*     */   extends BeanSerializerBase
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final BeanSerializerBase _defaultSerializer;
/*     */   
/*     */   public BeanAsArraySerializer(BeanSerializerBase src)
/*     */   {
/*  65 */     super(src, (ObjectIdWriter)null);
/*  66 */     this._defaultSerializer = src;
/*     */   }
/*     */   
/*     */   protected BeanAsArraySerializer(BeanSerializerBase src, Set<String> toIgnore) {
/*  70 */     this(src, toIgnore, null);
/*     */   }
/*     */   
/*     */   protected BeanAsArraySerializer(BeanSerializerBase src, Set<String> toIgnore, Set<String> toInclude) {
/*  74 */     super(src, toIgnore, toInclude);
/*  75 */     this._defaultSerializer = src;
/*     */   }
/*     */   
/*     */   protected BeanAsArraySerializer(BeanSerializerBase src, ObjectIdWriter oiw, Object filterId)
/*     */   {
/*  80 */     super(src, oiw, filterId);
/*  81 */     this._defaultSerializer = src;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonSerializer<Object> unwrappingSerializer(NameTransformer transformer)
/*     */   {
/*  95 */     return this._defaultSerializer.unwrappingSerializer(transformer);
/*     */   }
/*     */   
/*     */   public boolean isUnwrappingSerializer()
/*     */   {
/* 100 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public BeanSerializerBase withObjectIdWriter(ObjectIdWriter objectIdWriter)
/*     */   {
/* 106 */     return this._defaultSerializer.withObjectIdWriter(objectIdWriter);
/*     */   }
/*     */   
/*     */   public BeanSerializerBase withFilterId(Object filterId)
/*     */   {
/* 111 */     return new BeanAsArraySerializer(this, this._objectIdWriter, filterId);
/*     */   }
/*     */   
/*     */   protected BeanAsArraySerializer withByNameInclusion(Set<String> toIgnore, Set<String> toInclude)
/*     */   {
/* 116 */     return new BeanAsArraySerializer(this, toIgnore, toInclude);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BeanSerializerBase withProperties(BeanPropertyWriter[] properties, BeanPropertyWriter[] filteredProperties)
/*     */   {
/* 124 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   protected BeanSerializerBase asArraySerializer()
/*     */   {
/* 130 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void serializeWithType(Object bean, JsonGenerator gen, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException
/*     */   {
/* 148 */     if (this._objectIdWriter != null) {
/* 149 */       _serializeWithObjectId(bean, gen, provider, typeSer);
/* 150 */       return;
/*     */     }
/* 152 */     WritableTypeId typeIdDef = _typeIdDef(typeSer, bean, JsonToken.START_ARRAY);
/* 153 */     typeSer.writeTypePrefix(gen, typeIdDef);
/* 154 */     gen.setCurrentValue(bean);
/* 155 */     serializeAsArray(bean, gen, provider);
/* 156 */     typeSer.writeTypeSuffix(gen, typeIdDef);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void serialize(Object bean, JsonGenerator gen, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/* 168 */     if ((provider.isEnabled(SerializationFeature.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED)) && 
/* 169 */       (hasSingleElement(provider))) {
/* 170 */       serializeAsArray(bean, gen, provider);
/* 171 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 177 */     gen.writeStartArray(bean);
/* 178 */     serializeAsArray(bean, gen, provider);
/* 179 */     gen.writeEndArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean hasSingleElement(SerializerProvider provider)
/*     */   {
/*     */     BeanPropertyWriter[] props;
/*     */     
/*     */     BeanPropertyWriter[] props;
/*     */     
/* 190 */     if ((this._filteredProps != null) && (provider.getActiveView() != null)) {
/* 191 */       props = this._filteredProps;
/*     */     } else {
/* 193 */       props = this._props;
/*     */     }
/* 195 */     return props.length == 1;
/*     */   }
/*     */   
/*     */   protected final void serializeAsArray(Object bean, JsonGenerator gen, SerializerProvider provider) throws IOException
/*     */   {
/*     */     BeanPropertyWriter[] props;
/*     */     BeanPropertyWriter[] props;
/* 202 */     if ((this._filteredProps != null) && (provider.getActiveView() != null)) {
/* 203 */       props = this._filteredProps;
/*     */     } else {
/* 205 */       props = this._props;
/*     */     }
/*     */     
/* 208 */     int i = 0;
/*     */     try {
/* 210 */       for (int len = props.length; i < len; i++) {
/* 211 */         BeanPropertyWriter prop = props[i];
/* 212 */         if (prop == null) {
/* 213 */           gen.writeNull();
/*     */         } else {
/* 215 */           prop.serializeAsElement(bean, gen, provider);
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 223 */       String name = i == props.length ? "[anySetter]" : props[i].getName();
/* 224 */       wrapAndThrow(provider, e, bean, name);
/*     */     } catch (StackOverflowError e) {
/* 226 */       JsonMappingException mapE = JsonMappingException.from(gen, "Infinite recursion (StackOverflowError)", e);
/* 227 */       String name = i == props.length ? "[anySetter]" : props[i].getName();
/* 228 */       mapE.prependPath(new JsonMappingException.Reference(bean, name));
/* 229 */       throw mapE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 240 */     return "BeanAsArraySerializer for " + handledType().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\ser\impl\BeanAsArraySerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */