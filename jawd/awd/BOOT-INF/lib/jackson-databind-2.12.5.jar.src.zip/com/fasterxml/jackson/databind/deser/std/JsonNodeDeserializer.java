/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.node.ArrayNode;
/*     */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonNodeDeserializer
/*     */   extends BaseNodeDeserializer<JsonNode>
/*     */ {
/*  24 */   private static final JsonNodeDeserializer instance = new JsonNodeDeserializer();
/*     */   
/*     */ 
/*     */ 
/*     */   protected JsonNodeDeserializer()
/*     */   {
/*  30 */     super(JsonNode.class, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonDeserializer<? extends JsonNode> getDeserializer(Class<?> nodeClass)
/*     */   {
/*  38 */     if (nodeClass == ObjectNode.class) {
/*  39 */       return ObjectDeserializer.getInstance();
/*     */     }
/*  41 */     if (nodeClass == ArrayNode.class) {
/*  42 */       return ArrayDeserializer.getInstance();
/*     */     }
/*     */     
/*  45 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonNode getNullValue(DeserializationContext ctxt)
/*     */   {
/*  56 */     return ctxt.getNodeFactory().nullNode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonNode deserialize(JsonParser p, DeserializationContext ctxt)
/*     */     throws IOException
/*     */   {
/*  67 */     switch (p.currentTokenId()) {
/*     */     case 1: 
/*  69 */       return deserializeObject(p, ctxt, ctxt.getNodeFactory());
/*     */     case 3: 
/*  71 */       return deserializeArray(p, ctxt, ctxt.getNodeFactory());
/*     */     }
/*     */     
/*  74 */     return deserializeAny(p, ctxt, ctxt.getNodeFactory());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class ObjectDeserializer
/*     */     extends BaseNodeDeserializer<ObjectNode>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */ 
/*     */ 
/*  88 */     protected static final ObjectDeserializer _instance = new ObjectDeserializer();
/*     */     
/*  90 */     protected ObjectDeserializer() { super(Boolean.valueOf(true)); }
/*     */     
/*  92 */     public static ObjectDeserializer getInstance() { return _instance; }
/*     */     
/*     */     public ObjectNode deserialize(JsonParser p, DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/*  97 */       if (p.isExpectedStartObjectToken()) {
/*  98 */         return deserializeObject(p, ctxt, ctxt.getNodeFactory());
/*     */       }
/* 100 */       if (p.hasToken(JsonToken.FIELD_NAME)) {
/* 101 */         return deserializeObjectAtName(p, ctxt, ctxt.getNodeFactory());
/*     */       }
/*     */       
/*     */ 
/* 105 */       if (p.hasToken(JsonToken.END_OBJECT)) {
/* 106 */         return ctxt.getNodeFactory().objectNode();
/*     */       }
/* 108 */       return (ObjectNode)ctxt.handleUnexpectedToken(ObjectNode.class, p);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ObjectNode deserialize(JsonParser p, DeserializationContext ctxt, ObjectNode node)
/*     */       throws IOException
/*     */     {
/* 120 */       if ((p.isExpectedStartObjectToken()) || (p.hasToken(JsonToken.FIELD_NAME))) {
/* 121 */         return (ObjectNode)updateObject(p, ctxt, node);
/*     */       }
/* 123 */       return (ObjectNode)ctxt.handleUnexpectedToken(ObjectNode.class, p);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static final class ArrayDeserializer
/*     */     extends BaseNodeDeserializer<ArrayNode>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/* 132 */     protected static final ArrayDeserializer _instance = new ArrayDeserializer();
/*     */     
/* 134 */     protected ArrayDeserializer() { super(Boolean.valueOf(true)); }
/*     */     
/* 136 */     public static ArrayDeserializer getInstance() { return _instance; }
/*     */     
/*     */     public ArrayNode deserialize(JsonParser p, DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/* 141 */       if (p.isExpectedStartArrayToken()) {
/* 142 */         return deserializeArray(p, ctxt, ctxt.getNodeFactory());
/*     */       }
/* 144 */       return (ArrayNode)ctxt.handleUnexpectedToken(ArrayNode.class, p);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ArrayNode deserialize(JsonParser p, DeserializationContext ctxt, ArrayNode node)
/*     */       throws IOException
/*     */     {
/* 156 */       if (p.isExpectedStartArrayToken()) {
/* 157 */         return (ArrayNode)updateArray(p, ctxt, node);
/*     */       }
/* 159 */       return (ArrayNode)ctxt.handleUnexpectedToken(ArrayNode.class, p);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\std\JsonNodeDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */