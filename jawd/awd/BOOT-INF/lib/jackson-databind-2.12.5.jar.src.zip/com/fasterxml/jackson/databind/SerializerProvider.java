/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude.Value;
/*      */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidDefinitionException;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidTypeIdException;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*      */ import com.fasterxml.jackson.databind.ser.ResolvableSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.SerializerCache;
/*      */ import com.fasterxml.jackson.databind.ser.SerializerFactory;
/*      */ import com.fasterxml.jackson.databind.ser.impl.FailingSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.ReadOnlyClassToSerializerMap;
/*      */ import com.fasterxml.jackson.databind.ser.impl.TypeWrappedSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.UnknownSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.WritableObjectId;
/*      */ import com.fasterxml.jackson.databind.ser.std.NullSerializer;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.io.IOException;
/*      */ import java.text.DateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class SerializerProvider
/*      */   extends DatabindContext
/*      */ {
/*      */   protected static final boolean CACHE_UNKNOWN_MAPPINGS = false;
/*   57 */   public static final JsonSerializer<Object> DEFAULT_NULL_KEY_SERIALIZER = new FailingSerializer("Null key for a Map not allowed in JSON (use a converting NullKeySerializer?)");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   69 */   protected static final JsonSerializer<Object> DEFAULT_UNKNOWN_SERIALIZER = new UnknownSerializer();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final SerializationConfig _config;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Class<?> _serializationView;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final SerializerFactory _serializerFactory;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final SerializerCache _serializerCache;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected transient ContextAttributes _attributes;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  131 */   protected JsonSerializer<Object> _unknownTypeSerializer = DEFAULT_UNKNOWN_SERIALIZER;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonSerializer<Object> _keySerializer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  144 */   protected JsonSerializer<Object> _nullValueSerializer = NullSerializer.instance;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  153 */   protected JsonSerializer<Object> _nullKeySerializer = DEFAULT_NULL_KEY_SERIALIZER;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final ReadOnlyClassToSerializerMap _knownSerializers;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected DateFormat _dateFormat;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean _stdNullValueSerializer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public SerializerProvider()
/*      */   {
/*  194 */     this._config = null;
/*  195 */     this._serializerFactory = null;
/*  196 */     this._serializerCache = new SerializerCache();
/*      */     
/*  198 */     this._knownSerializers = null;
/*      */     
/*  200 */     this._serializationView = null;
/*  201 */     this._attributes = null;
/*      */     
/*      */ 
/*  204 */     this._stdNullValueSerializer = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected SerializerProvider(SerializerProvider src, SerializationConfig config, SerializerFactory f)
/*      */   {
/*  216 */     this._serializerFactory = f;
/*  217 */     this._config = config;
/*      */     
/*  219 */     this._serializerCache = src._serializerCache;
/*  220 */     this._unknownTypeSerializer = src._unknownTypeSerializer;
/*  221 */     this._keySerializer = src._keySerializer;
/*  222 */     this._nullValueSerializer = src._nullValueSerializer;
/*  223 */     this._nullKeySerializer = src._nullKeySerializer;
/*      */     
/*  225 */     this._stdNullValueSerializer = (this._nullValueSerializer == DEFAULT_NULL_KEY_SERIALIZER);
/*      */     
/*  227 */     this._serializationView = config.getActiveView();
/*  228 */     this._attributes = config.getAttributes();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  233 */     this._knownSerializers = this._serializerCache.getReadOnlyLookupMap();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected SerializerProvider(SerializerProvider src)
/*      */   {
/*  244 */     this._config = null;
/*  245 */     this._serializationView = null;
/*  246 */     this._serializerFactory = null;
/*  247 */     this._knownSerializers = null;
/*      */     
/*      */ 
/*  250 */     this._serializerCache = new SerializerCache();
/*      */     
/*  252 */     this._unknownTypeSerializer = src._unknownTypeSerializer;
/*  253 */     this._keySerializer = src._keySerializer;
/*  254 */     this._nullValueSerializer = src._nullValueSerializer;
/*  255 */     this._nullKeySerializer = src._nullKeySerializer;
/*      */     
/*  257 */     this._stdNullValueSerializer = src._stdNullValueSerializer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultKeySerializer(JsonSerializer<Object> ks)
/*      */   {
/*  277 */     if (ks == null) {
/*  278 */       throw new IllegalArgumentException("Cannot pass null JsonSerializer");
/*      */     }
/*  280 */     this._keySerializer = ks;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNullValueSerializer(JsonSerializer<Object> nvs)
/*      */   {
/*  294 */     if (nvs == null) {
/*  295 */       throw new IllegalArgumentException("Cannot pass null JsonSerializer");
/*      */     }
/*  297 */     this._nullValueSerializer = nvs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNullKeySerializer(JsonSerializer<Object> nks)
/*      */   {
/*  307 */     if (nks == null) {
/*  308 */       throw new IllegalArgumentException("Cannot pass null JsonSerializer");
/*      */     }
/*  310 */     this._nullKeySerializer = nks;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final SerializationConfig getConfig()
/*      */   {
/*  323 */     return this._config;
/*      */   }
/*      */   
/*      */   public final AnnotationIntrospector getAnnotationIntrospector() {
/*  327 */     return this._config.getAnnotationIntrospector();
/*      */   }
/*      */   
/*      */   public final TypeFactory getTypeFactory()
/*      */   {
/*  332 */     return this._config.getTypeFactory();
/*      */   }
/*      */   
/*      */ 
/*      */   public JavaType constructSpecializedType(JavaType baseType, Class<?> subclass)
/*      */     throws IllegalArgumentException
/*      */   {
/*  339 */     if (baseType.hasRawClass(subclass)) {
/*  340 */       return baseType;
/*      */     }
/*      */     
/*      */ 
/*  344 */     return getConfig().getTypeFactory().constructSpecializedType(baseType, subclass, true);
/*      */   }
/*      */   
/*      */   public final Class<?> getActiveView() {
/*  348 */     return this._serializationView;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public final Class<?> getSerializationView()
/*      */   {
/*  354 */     return this._serializationView;
/*      */   }
/*      */   
/*      */   public final boolean canOverrideAccessModifiers() {
/*  358 */     return this._config.canOverrideAccessModifiers();
/*      */   }
/*      */   
/*      */   public final boolean isEnabled(MapperFeature feature)
/*      */   {
/*  363 */     return this._config.isEnabled(feature);
/*      */   }
/*      */   
/*      */   public final JsonFormat.Value getDefaultPropertyFormat(Class<?> baseType)
/*      */   {
/*  368 */     return this._config.getDefaultPropertyFormat(baseType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final JsonInclude.Value getDefaultPropertyInclusion(Class<?> baseType)
/*      */   {
/*  375 */     return this._config.getDefaultPropertyInclusion(baseType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Locale getLocale()
/*      */   {
/*  386 */     return this._config.getLocale();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TimeZone getTimeZone()
/*      */   {
/*  397 */     return this._config.getTimeZone();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getAttribute(Object key)
/*      */   {
/*  408 */     return this._attributes.getAttribute(key);
/*      */   }
/*      */   
/*      */ 
/*      */   public SerializerProvider setAttribute(Object key, Object value)
/*      */   {
/*  414 */     this._attributes = this._attributes.withPerCallAttribute(key, value);
/*  415 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isEnabled(SerializationFeature feature)
/*      */   {
/*  433 */     return this._config.isEnabled(feature);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean hasSerializationFeatures(int featureMask)
/*      */   {
/*  443 */     return this._config.hasSerializationFeatures(featureMask);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final FilterProvider getFilterProvider()
/*      */   {
/*  454 */     return this._config.getFilterProvider();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator getGenerator()
/*      */   {
/*  465 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract WritableObjectId findObjectId(Object paramObject, ObjectIdGenerator<?> paramObjectIdGenerator);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findValueSerializer(Class<?> valueType, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  511 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  512 */     if (ser == null)
/*      */     {
/*  514 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  515 */       if (ser == null)
/*      */       {
/*  517 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/*  518 */         if (ser == null)
/*      */         {
/*  520 */           ser = _createAndCacheUntypedSerializer(valueType);
/*      */           
/*  522 */           if (ser == null) {
/*  523 */             ser = getUnknownTypeSerializer(valueType);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  528 */             return ser;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  534 */     return handleSecondaryContextualization(ser, property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findValueSerializer(JavaType valueType, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  553 */     if (valueType == null) {
/*  554 */       reportMappingProblem("Null passed for `valueType` of `findValueSerializer()`", new Object[0]);
/*      */     }
/*      */     
/*  557 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  558 */     if (ser == null) {
/*  559 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  560 */       if (ser == null) {
/*  561 */         ser = _createAndCacheUntypedSerializer(valueType);
/*  562 */         if (ser == null) {
/*  563 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*      */           
/*      */ 
/*      */ 
/*  567 */           return ser;
/*      */         }
/*      */       }
/*      */     }
/*  571 */     return handleSecondaryContextualization(ser, property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findValueSerializer(Class<?> valueType)
/*      */     throws JsonMappingException
/*      */   {
/*  584 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  585 */     if (ser == null) {
/*  586 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  587 */       if (ser == null) {
/*  588 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/*  589 */         if (ser == null) {
/*  590 */           ser = _createAndCacheUntypedSerializer(valueType);
/*  591 */           if (ser == null) {
/*  592 */             ser = getUnknownTypeSerializer(valueType);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  600 */     return ser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findValueSerializer(JavaType valueType)
/*      */     throws JsonMappingException
/*      */   {
/*  614 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  615 */     if (ser == null) {
/*  616 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  617 */       if (ser == null) {
/*  618 */         ser = _createAndCacheUntypedSerializer(valueType);
/*  619 */         if (ser == null) {
/*  620 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  627 */     return ser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findPrimaryPropertySerializer(JavaType valueType, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  647 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  648 */     if (ser == null) {
/*  649 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  650 */       if (ser == null) {
/*  651 */         ser = _createAndCacheUntypedSerializer(valueType);
/*  652 */         if (ser == null) {
/*  653 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  658 */           return ser;
/*      */         }
/*      */       }
/*      */     }
/*  662 */     return handlePrimaryContextualization(ser, property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findPrimaryPropertySerializer(Class<?> valueType, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  675 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  676 */     if (ser == null) {
/*  677 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  678 */       if (ser == null) {
/*  679 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/*  680 */         if (ser == null) {
/*  681 */           ser = _createAndCacheUntypedSerializer(valueType);
/*  682 */           if (ser == null) {
/*  683 */             ser = getUnknownTypeSerializer(valueType);
/*      */             
/*      */ 
/*      */ 
/*  687 */             return ser;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  692 */     return handlePrimaryContextualization(ser, property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findContentValueSerializer(JavaType valueType, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  719 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  720 */     if (ser == null) {
/*  721 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  722 */       if (ser == null) {
/*  723 */         ser = _createAndCacheUntypedSerializer(valueType);
/*  724 */         if (ser == null) {
/*  725 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  730 */           return ser;
/*      */         }
/*      */       }
/*      */     }
/*  734 */     return handleSecondaryContextualization(ser, property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findContentValueSerializer(Class<?> valueType, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  747 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  748 */     if (ser == null) {
/*  749 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  750 */       if (ser == null) {
/*  751 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/*  752 */         if (ser == null) {
/*  753 */           ser = _createAndCacheUntypedSerializer(valueType);
/*  754 */           if (ser == null) {
/*  755 */             ser = getUnknownTypeSerializer(valueType);
/*      */             
/*      */ 
/*      */ 
/*  759 */             return ser;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  764 */     return handleSecondaryContextualization(ser, property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findTypedValueSerializer(Class<?> valueType, boolean cache, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  787 */     JsonSerializer<Object> ser = this._knownSerializers.typedValueSerializer(valueType);
/*  788 */     if (ser != null) {
/*  789 */       return ser;
/*      */     }
/*      */     
/*  792 */     ser = this._serializerCache.typedValueSerializer(valueType);
/*  793 */     if (ser != null) {
/*  794 */       return ser;
/*      */     }
/*      */     
/*      */ 
/*  798 */     ser = findValueSerializer(valueType, property);
/*  799 */     TypeSerializer typeSer = this._serializerFactory.createTypeSerializer(this._config, this._config
/*  800 */       .constructType(valueType));
/*  801 */     if (typeSer != null) {
/*  802 */       typeSer = typeSer.forProperty(property);
/*  803 */       ser = new TypeWrappedSerializer(typeSer, ser);
/*      */     }
/*  805 */     if (cache) {
/*  806 */       this._serializerCache.addTypedSerializer(valueType, ser);
/*      */     }
/*  808 */     return ser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findTypedValueSerializer(JavaType valueType, boolean cache, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  832 */     JsonSerializer<Object> ser = this._knownSerializers.typedValueSerializer(valueType);
/*  833 */     if (ser != null) {
/*  834 */       return ser;
/*      */     }
/*      */     
/*  837 */     ser = this._serializerCache.typedValueSerializer(valueType);
/*  838 */     if (ser != null) {
/*  839 */       return ser;
/*      */     }
/*      */     
/*      */ 
/*  843 */     ser = findValueSerializer(valueType, property);
/*  844 */     TypeSerializer typeSer = this._serializerFactory.createTypeSerializer(this._config, valueType);
/*  845 */     if (typeSer != null) {
/*  846 */       typeSer = typeSer.forProperty(property);
/*  847 */       ser = new TypeWrappedSerializer(typeSer, ser);
/*      */     }
/*  849 */     if (cache) {
/*  850 */       this._serializerCache.addTypedSerializer(valueType, ser);
/*      */     }
/*  852 */     return ser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TypeSerializer findTypeSerializer(JavaType javaType)
/*      */     throws JsonMappingException
/*      */   {
/*  863 */     return this._serializerFactory.createTypeSerializer(this._config, javaType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findKeySerializer(JavaType keyType, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  879 */     JsonSerializer<Object> ser = this._serializerFactory.createKeySerializer(this, keyType, this._keySerializer);
/*      */     
/*  881 */     return _handleContextualResolvable(ser, property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findKeySerializer(Class<?> rawKeyType, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  890 */     return findKeySerializer(this._config.constructType(rawKeyType), property);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> getDefaultNullKeySerializer()
/*      */   {
/*  903 */     return this._nullKeySerializer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> getDefaultNullValueSerializer()
/*      */   {
/*  910 */     return this._nullValueSerializer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findNullKeySerializer(JavaType serializationType, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  934 */     return this._nullKeySerializer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> findNullValueSerializer(BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  950 */     return this._nullValueSerializer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<Object> getUnknownTypeSerializer(Class<?> unknownType)
/*      */   {
/*  967 */     if (unknownType == Object.class) {
/*  968 */       return this._unknownTypeSerializer;
/*      */     }
/*      */     
/*  971 */     return new UnknownSerializer(unknownType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUnknownTypeSerializer(JsonSerializer<?> ser)
/*      */   {
/*  982 */     if ((ser == this._unknownTypeSerializer) || (ser == null)) {
/*  983 */       return true;
/*      */     }
/*      */     
/*      */ 
/*  987 */     if ((isEnabled(SerializationFeature.FAIL_ON_EMPTY_BEANS)) && 
/*  988 */       (ser.getClass() == UnknownSerializer.class)) {
/*  989 */       return true;
/*      */     }
/*      */     
/*  992 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract JsonSerializer<Object> serializerInstance(Annotated paramAnnotated, Object paramObject)
/*      */     throws JsonMappingException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract Object includeFilterInstance(BeanPropertyDefinition paramBeanPropertyDefinition, Class<?> paramClass)
/*      */     throws JsonMappingException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract boolean includeFilterSuppressNulls(Object paramObject)
/*      */     throws JsonMappingException;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<?> handlePrimaryContextualization(JsonSerializer<?> ser, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/* 1059 */     if ((ser != null) && 
/* 1060 */       ((ser instanceof ContextualSerializer))) {
/* 1061 */       ser = ((ContextualSerializer)ser).createContextual(this, property);
/*      */     }
/*      */     
/* 1064 */     return ser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonSerializer<?> handleSecondaryContextualization(JsonSerializer<?> ser, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/* 1087 */     if ((ser != null) && 
/* 1088 */       ((ser instanceof ContextualSerializer))) {
/* 1089 */       ser = ((ContextualSerializer)ser).createContextual(this, property);
/*      */     }
/*      */     
/* 1092 */     return ser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void defaultSerializeValue(Object value, JsonGenerator gen)
/*      */     throws IOException
/*      */   {
/* 1110 */     if (value == null) {
/* 1111 */       if (this._stdNullValueSerializer) {
/* 1112 */         gen.writeNull();
/*      */       } else {
/* 1114 */         this._nullValueSerializer.serialize(null, gen, this);
/*      */       }
/*      */     } else {
/* 1117 */       Class<?> cls = value.getClass();
/* 1118 */       findTypedValueSerializer(cls, true, null).serialize(value, gen, this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void defaultSerializeField(String fieldName, Object value, JsonGenerator gen)
/*      */     throws IOException
/*      */   {
/* 1130 */     gen.writeFieldName(fieldName);
/* 1131 */     if (value == null)
/*      */     {
/*      */ 
/*      */ 
/* 1135 */       if (this._stdNullValueSerializer) {
/* 1136 */         gen.writeNull();
/*      */       } else {
/* 1138 */         this._nullValueSerializer.serialize(null, gen, this);
/*      */       }
/*      */     } else {
/* 1141 */       Class<?> cls = value.getClass();
/* 1142 */       findTypedValueSerializer(cls, true, null).serialize(value, gen, this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void defaultSerializeDateValue(long timestamp, JsonGenerator gen)
/*      */     throws IOException
/*      */   {
/* 1156 */     if (isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)) {
/* 1157 */       gen.writeNumber(timestamp);
/*      */     } else {
/* 1159 */       gen.writeString(_dateFormat().format(new Date(timestamp)));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void defaultSerializeDateValue(Date date, JsonGenerator gen)
/*      */     throws IOException
/*      */   {
/* 1172 */     if (isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)) {
/* 1173 */       gen.writeNumber(date.getTime());
/*      */     } else {
/* 1175 */       gen.writeString(_dateFormat().format(date));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defaultSerializeDateKey(long timestamp, JsonGenerator gen)
/*      */     throws IOException
/*      */   {
/* 1186 */     if (isEnabled(SerializationFeature.WRITE_DATE_KEYS_AS_TIMESTAMPS)) {
/* 1187 */       gen.writeFieldName(String.valueOf(timestamp));
/*      */     } else {
/* 1189 */       gen.writeFieldName(_dateFormat().format(new Date(timestamp)));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void defaultSerializeDateKey(Date date, JsonGenerator gen)
/*      */     throws IOException
/*      */   {
/* 1200 */     if (isEnabled(SerializationFeature.WRITE_DATE_KEYS_AS_TIMESTAMPS)) {
/* 1201 */       gen.writeFieldName(String.valueOf(date.getTime()));
/*      */     } else {
/* 1203 */       gen.writeFieldName(_dateFormat().format(date));
/*      */     }
/*      */   }
/*      */   
/*      */   public final void defaultSerializeNull(JsonGenerator gen) throws IOException
/*      */   {
/* 1209 */     if (this._stdNullValueSerializer) {
/* 1210 */       gen.writeNull();
/*      */     } else {
/* 1212 */       this._nullValueSerializer.serialize(null, gen, this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reportMappingProblem(String message, Object... args)
/*      */     throws JsonMappingException
/*      */   {
/* 1230 */     throw mappingException(message, args);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T reportBadTypeDefinition(BeanDescription bean, String msg, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1242 */     String beanDesc = "N/A";
/* 1243 */     if (bean != null) {
/* 1244 */       beanDesc = ClassUtil.nameOf(bean.getBeanClass());
/*      */     }
/* 1246 */     msg = String.format("Invalid type definition for type %s: %s", new Object[] { beanDesc, 
/* 1247 */       _format(msg, msgArgs) });
/* 1248 */     throw InvalidDefinitionException.from(getGenerator(), msg, bean, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> T reportBadPropertyDefinition(BeanDescription bean, BeanPropertyDefinition prop, String message, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1260 */     message = _format(message, msgArgs);
/* 1261 */     String propName = "N/A";
/* 1262 */     if (prop != null) {
/* 1263 */       propName = _quotedString(prop.getName());
/*      */     }
/* 1265 */     String beanDesc = "N/A";
/* 1266 */     if (bean != null) {
/* 1267 */       beanDesc = ClassUtil.nameOf(bean.getBeanClass());
/*      */     }
/* 1269 */     message = String.format("Invalid definition for property %s (of type %s): %s", new Object[] { propName, beanDesc, message });
/*      */     
/* 1271 */     throw InvalidDefinitionException.from(getGenerator(), message, bean, prop);
/*      */   }
/*      */   
/*      */   public <T> T reportBadDefinition(JavaType type, String msg) throws JsonMappingException
/*      */   {
/* 1276 */     throw InvalidDefinitionException.from(getGenerator(), msg, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> T reportBadDefinition(JavaType type, String msg, Throwable cause)
/*      */     throws JsonMappingException
/*      */   {
/* 1284 */     InvalidDefinitionException e = InvalidDefinitionException.from(getGenerator(), msg, type);
/* 1285 */     e.initCause(cause);
/* 1286 */     throw e;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public <T> T reportBadDefinition(Class<?> raw, String msg, Throwable cause)
/*      */     throws JsonMappingException
/*      */   {
/* 1294 */     InvalidDefinitionException e = InvalidDefinitionException.from(getGenerator(), msg, constructType(raw));
/* 1295 */     e.initCause(cause);
/* 1296 */     throw e;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reportMappingProblem(Throwable t, String message, Object... msgArgs)
/*      */     throws JsonMappingException
/*      */   {
/* 1307 */     message = _format(message, msgArgs);
/* 1308 */     throw JsonMappingException.from(getGenerator(), message, t);
/*      */   }
/*      */   
/*      */ 
/*      */   public JsonMappingException invalidTypeIdException(JavaType baseType, String typeId, String extraDesc)
/*      */   {
/* 1314 */     String msg = String.format("Could not resolve type id '%s' as a subtype of %s", new Object[] { typeId, 
/* 1315 */       ClassUtil.getTypeDescription(baseType) });
/* 1316 */     return InvalidTypeIdException.from(null, _colonConcat(msg, extraDesc), baseType, typeId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public JsonMappingException mappingException(String message, Object... msgArgs)
/*      */   {
/* 1336 */     return JsonMappingException.from(getGenerator(), _format(message, msgArgs));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected JsonMappingException mappingException(Throwable t, String message, Object... msgArgs)
/*      */   {
/* 1350 */     return JsonMappingException.from(getGenerator(), _format(message, msgArgs), t);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _reportIncompatibleRootType(Object value, JavaType rootType)
/*      */     throws IOException
/*      */   {
/* 1362 */     if (rootType.isPrimitive()) {
/* 1363 */       Class<?> wrapperType = ClassUtil.wrapperType(rootType.getRawClass());
/*      */       
/* 1365 */       if (wrapperType.isAssignableFrom(value.getClass())) {
/* 1366 */         return;
/*      */       }
/*      */     }
/* 1369 */     reportBadDefinition(rootType, String.format("Incompatible types: declared root type (%s) vs %s", new Object[] { rootType, 
/*      */     
/* 1371 */       ClassUtil.classNameOf(value) }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonSerializer<Object> _findExplicitUntypedSerializer(Class<?> runtimeType)
/*      */     throws JsonMappingException
/*      */   {
/* 1385 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(runtimeType);
/* 1386 */     if (ser == null)
/*      */     {
/* 1388 */       ser = this._serializerCache.untypedValueSerializer(runtimeType);
/* 1389 */       if (ser == null) {
/* 1390 */         ser = _createAndCacheUntypedSerializer(runtimeType);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1398 */     if (isUnknownTypeSerializer(ser)) {
/* 1399 */       return null;
/*      */     }
/* 1401 */     return ser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonSerializer<Object> _createAndCacheUntypedSerializer(Class<?> rawType)
/*      */     throws JsonMappingException
/*      */   {
/* 1418 */     JavaType fullType = this._config.constructType(rawType);
/*      */     JsonSerializer<Object> ser;
/*      */     try {
/* 1421 */       ser = _createUntypedSerializer(fullType);
/*      */     }
/*      */     catch (IllegalArgumentException iae) {
/*      */       JsonSerializer<Object> ser;
/* 1425 */       ser = null;
/* 1426 */       reportMappingProblem(iae, ClassUtil.exceptionMessage(iae), new Object[0]);
/*      */     }
/*      */     
/* 1429 */     if (ser != null)
/*      */     {
/* 1431 */       this._serializerCache.addAndResolveNonTypedSerializer(rawType, fullType, ser, this);
/*      */     }
/* 1433 */     return ser;
/*      */   }
/*      */   
/*      */   protected JsonSerializer<Object> _createAndCacheUntypedSerializer(JavaType type) throws JsonMappingException
/*      */   {
/*      */     JsonSerializer<Object> ser;
/*      */     try
/*      */     {
/* 1441 */       ser = _createUntypedSerializer(type);
/*      */     }
/*      */     catch (IllegalArgumentException iae) {
/*      */       JsonSerializer<Object> ser;
/* 1445 */       ser = null;
/* 1446 */       reportMappingProblem(iae, ClassUtil.exceptionMessage(iae), new Object[0]);
/*      */     }
/*      */     
/* 1449 */     if (ser != null)
/*      */     {
/* 1451 */       this._serializerCache.addAndResolveNonTypedSerializer(type, ser, this);
/*      */     }
/* 1453 */     return ser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonSerializer<Object> _createUntypedSerializer(JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/* 1473 */     return this._serializerFactory.createSerializer(this, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonSerializer<Object> _handleContextualResolvable(JsonSerializer<?> ser, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/* 1486 */     if ((ser instanceof ResolvableSerializer)) {
/* 1487 */       ((ResolvableSerializer)ser).resolve(this);
/*      */     }
/* 1489 */     return handleSecondaryContextualization(ser, property);
/*      */   }
/*      */   
/*      */ 
/*      */   protected JsonSerializer<Object> _handleResolvable(JsonSerializer<?> ser)
/*      */     throws JsonMappingException
/*      */   {
/* 1496 */     if ((ser instanceof ResolvableSerializer)) {
/* 1497 */       ((ResolvableSerializer)ser).resolve(this);
/*      */     }
/* 1499 */     return ser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final DateFormat _dateFormat()
/*      */   {
/* 1510 */     if (this._dateFormat != null) {
/* 1511 */       return this._dateFormat;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1517 */     DateFormat df = this._config.getDateFormat();
/* 1518 */     this._dateFormat = (df = (DateFormat)df.clone());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1527 */     return df;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\SerializerProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */