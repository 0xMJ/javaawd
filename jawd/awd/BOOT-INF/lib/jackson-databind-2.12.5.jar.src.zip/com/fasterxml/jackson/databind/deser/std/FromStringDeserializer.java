/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.util.VersionUtil;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.exc.InvalidFormatException;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Currency;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FromStringDeserializer<T>
/*     */   extends StdScalarDeserializer<T>
/*     */ {
/*     */   public static Class<?>[] types()
/*     */   {
/*  60 */     return new Class[] { File.class, URL.class, URI.class, Class.class, JavaType.class, Currency.class, Pattern.class, Locale.class, Charset.class, TimeZone.class, InetAddress.class, InetSocketAddress.class, StringBuilder.class };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FromStringDeserializer(Class<?> vc)
/*     */   {
/*  86 */     super(vc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static FromStringDeserializer<?> findDeserializer(Class<?> rawType)
/*     */   {
/*  95 */     int kind = 0;
/*  96 */     if (rawType == File.class) {
/*  97 */       kind = 1;
/*  98 */     } else if (rawType == URL.class) {
/*  99 */       kind = 2;
/* 100 */     } else if (rawType == URI.class) {
/* 101 */       kind = 3;
/* 102 */     } else if (rawType == Class.class) {
/* 103 */       kind = 4;
/* 104 */     } else if (rawType == JavaType.class) {
/* 105 */       kind = 5;
/* 106 */     } else if (rawType == Currency.class) {
/* 107 */       kind = 6;
/* 108 */     } else if (rawType == Pattern.class) {
/* 109 */       kind = 7;
/* 110 */     } else if (rawType == Locale.class) {
/* 111 */       kind = 8;
/* 112 */     } else if (rawType == Charset.class) {
/* 113 */       kind = 9;
/* 114 */     } else if (rawType == TimeZone.class) {
/* 115 */       kind = 10;
/* 116 */     } else if (rawType == InetAddress.class) {
/* 117 */       kind = 11;
/* 118 */     } else if (rawType == InetSocketAddress.class) {
/* 119 */       kind = 12;
/* 120 */     } else { if (rawType == StringBuilder.class) {
/* 121 */         return new StringBuilderDeserializer();
/*     */       }
/* 123 */       return null;
/*     */     }
/* 125 */     return new Std(rawType, kind);
/*     */   }
/*     */   
/*     */   public LogicalType logicalType()
/*     */   {
/* 130 */     return LogicalType.OtherScalar;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T deserialize(JsonParser p, DeserializationContext ctxt)
/*     */     throws IOException
/*     */   {
/* 144 */     String text = p.getValueAsString();
/* 145 */     if (text == null) {
/* 146 */       JsonToken t = p.currentToken();
/* 147 */       if (t != JsonToken.START_OBJECT) {
/* 148 */         return (T)_deserializeFromOther(p, ctxt, t);
/*     */       }
/*     */       
/* 151 */       text = ctxt.extractScalarFromObject(p, this, this._valueClass);
/*     */     }
/* 153 */     if ((text.isEmpty()) || ((text = text.trim()).isEmpty()))
/*     */     {
/* 155 */       return (T)_deserializeFromEmptyString(ctxt);
/*     */     }
/* 157 */     Exception cause = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 162 */       return (T)_deserialize(text, ctxt);
/*     */     } catch (IllegalArgumentException|MalformedURLException e) {
/* 164 */       cause = e;
/*     */       
/*     */ 
/* 167 */       String msg = "not a valid textual representation";
/* 168 */       String m2 = cause.getMessage();
/* 169 */       if (m2 != null) {
/* 170 */         msg = msg + ", problem: " + m2;
/*     */       }
/*     */       
/* 173 */       JsonMappingException e = ctxt.weirdStringException(text, this._valueClass, msg);
/* 174 */       e.initCause(cause);
/* 175 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract T _deserialize(String paramString, DeserializationContext paramDeserializationContext)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */   protected Object _deserializeFromOther(JsonParser p, DeserializationContext ctxt, JsonToken t)
/*     */     throws IOException
/*     */   {
/* 189 */     if (t == JsonToken.START_ARRAY) {
/* 190 */       return _deserializeFromArray(p, ctxt);
/*     */     }
/* 192 */     if (t == JsonToken.VALUE_EMBEDDED_OBJECT)
/*     */     {
/* 194 */       Object ob = p.getEmbeddedObject();
/* 195 */       if (ob == null) {
/* 196 */         return null;
/*     */       }
/* 198 */       if (this._valueClass.isAssignableFrom(ob.getClass())) {
/* 199 */         return ob;
/*     */       }
/* 201 */       return _deserializeEmbedded(ob, ctxt);
/*     */     }
/* 203 */     return ctxt.handleUnexpectedToken(this._valueClass, p);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected T _deserializeEmbedded(Object ob, DeserializationContext ctxt)
/*     */     throws IOException
/*     */   {
/* 213 */     ctxt.reportInputMismatch(this, "Don't know how to convert embedded Object of type %s into %s", new Object[] {ob
/*     */     
/* 215 */       .getClass().getName(), this._valueClass.getName() });
/* 216 */     return null;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected final T _deserializeFromEmptyString() throws IOException {
/* 221 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object _deserializeFromEmptyString(DeserializationContext ctxt)
/*     */     throws IOException
/*     */   {
/* 228 */     CoercionAction act = ctxt.findCoercionAction(logicalType(), this._valueClass, CoercionInputShape.EmptyString);
/*     */     
/* 230 */     if (act == CoercionAction.Fail) {
/* 231 */       ctxt.reportInputMismatch(this, "Cannot coerce empty String (\"\") to %s (but could if enabling coercion using `CoercionConfig`)", new Object[] {
/*     */       
/* 233 */         _coercedTypeDesc() });
/*     */     }
/* 235 */     if (act == CoercionAction.AsNull) {
/* 236 */       return getNullValue(ctxt);
/*     */     }
/* 238 */     if (act == CoercionAction.AsEmpty) {
/* 239 */       return getEmptyValue(ctxt);
/*     */     }
/*     */     
/*     */ 
/* 243 */     return _deserializeFromEmptyStringDefault(ctxt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Object _deserializeFromEmptyStringDefault(DeserializationContext ctxt)
/*     */     throws IOException
/*     */   {
/* 251 */     return getNullValue(ctxt);
/*     */   }
/*     */   
/*     */ 
/*     */   public static class Std
/*     */     extends FromStringDeserializer<Object>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public static final int STD_FILE = 1;
/*     */     
/*     */     public static final int STD_URL = 2;
/*     */     
/*     */     public static final int STD_URI = 3;
/*     */     
/*     */     public static final int STD_CLASS = 4;
/*     */     
/*     */     public static final int STD_JAVA_TYPE = 5;
/*     */     
/*     */     public static final int STD_CURRENCY = 6;
/*     */     
/*     */     public static final int STD_PATTERN = 7;
/*     */     
/*     */     public static final int STD_LOCALE = 8;
/*     */     
/*     */     public static final int STD_CHARSET = 9;
/*     */     
/*     */     public static final int STD_TIME_ZONE = 10;
/*     */     
/*     */     public static final int STD_INET_ADDRESS = 11;
/*     */     
/*     */     public static final int STD_INET_SOCKET_ADDRESS = 12;
/*     */     
/*     */     protected final int _kind;
/*     */     
/*     */     protected Std(Class<?> valueType, int kind)
/*     */     {
/* 288 */       super();
/* 289 */       this._kind = kind;
/*     */     }
/*     */     
/*     */     protected Object _deserialize(String value, DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/* 295 */       switch (this._kind) {
/*     */       case 1: 
/* 297 */         return new File(value);
/*     */       case 2: 
/* 299 */         return new URL(value);
/*     */       case 3: 
/* 301 */         return URI.create(value);
/*     */       case 4: 
/*     */         try {
/* 304 */           return ctxt.findClass(value);
/*     */         } catch (Exception e) {
/* 306 */           return ctxt.handleInstantiationProblem(this._valueClass, value, 
/* 307 */             ClassUtil.getRootCause(e));
/*     */         }
/*     */       case 5: 
/* 310 */         return ctxt.getTypeFactory().constructFromCanonical(value);
/*     */       
/*     */       case 6: 
/* 313 */         return Currency.getInstance(value);
/*     */       
/*     */       case 7: 
/* 316 */         return Pattern.compile(value);
/*     */       
/*     */       case 8: 
/* 319 */         int ix = _firstHyphenOrUnderscore(value);
/* 320 */         if (ix < 0) {
/* 321 */           return new Locale(value);
/*     */         }
/* 323 */         String first = value.substring(0, ix);
/* 324 */         value = value.substring(ix + 1);
/* 325 */         ix = _firstHyphenOrUnderscore(value);
/* 326 */         if (ix < 0) {
/* 327 */           return new Locale(first, value);
/*     */         }
/* 329 */         String second = value.substring(0, ix);
/* 330 */         return new Locale(first, second, value.substring(ix + 1));
/*     */       
/*     */       case 9: 
/* 333 */         return Charset.forName(value);
/*     */       case 10: 
/* 335 */         return TimeZone.getTimeZone(value);
/*     */       case 11: 
/* 337 */         return InetAddress.getByName(value);
/*     */       case 12: 
/* 339 */         if (value.startsWith("["))
/*     */         {
/*     */ 
/* 342 */           int i = value.lastIndexOf(']');
/* 343 */           if (i == -1) {
/* 344 */             throw new InvalidFormatException(ctxt.getParser(), "Bracketed IPv6 address must contain closing bracket", value, InetSocketAddress.class);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 349 */           int j = value.indexOf(':', i);
/* 350 */           int port = j > -1 ? Integer.parseInt(value.substring(j + 1)) : 0;
/* 351 */           return new InetSocketAddress(value.substring(0, i + 1), port);
/*     */         }
/* 353 */         int ix = value.indexOf(':');
/* 354 */         if ((ix >= 0) && (value.indexOf(':', ix + 1) < 0))
/*     */         {
/* 356 */           int port = Integer.parseInt(value.substring(ix + 1));
/* 357 */           return new InetSocketAddress(value.substring(0, ix), port);
/*     */         }
/*     */         
/* 360 */         return new InetSocketAddress(value, 0);
/*     */       }
/* 362 */       VersionUtil.throwInternal();
/* 363 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */     public Object getEmptyValue(DeserializationContext ctxt)
/*     */       throws JsonMappingException
/*     */     {
/* 370 */       switch (this._kind)
/*     */       {
/*     */       case 3: 
/* 373 */         return URI.create("");
/*     */       
/*     */       case 8: 
/* 376 */         return Locale.ROOT;
/*     */       }
/* 378 */       return super.getEmptyValue(ctxt);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected Object _deserializeFromEmptyStringDefault(DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/* 386 */       return getEmptyValue(ctxt);
/*     */     }
/*     */     
/*     */     protected int _firstHyphenOrUnderscore(String str)
/*     */     {
/* 391 */       int i = 0; for (int end = str.length(); i < end; i++) {
/* 392 */         char c = str.charAt(i);
/* 393 */         if ((c == '_') || (c == '-')) {
/* 394 */           return i;
/*     */         }
/*     */       }
/* 397 */       return -1;
/*     */     }
/*     */   }
/*     */   
/*     */   static class StringBuilderDeserializer
/*     */     extends FromStringDeserializer<Object>
/*     */   {
/*     */     public StringBuilderDeserializer()
/*     */     {
/* 406 */       super();
/*     */     }
/*     */     
/*     */     public LogicalType logicalType()
/*     */     {
/* 411 */       return LogicalType.Textual;
/*     */     }
/*     */     
/*     */ 
/*     */     public Object getEmptyValue(DeserializationContext ctxt)
/*     */       throws JsonMappingException
/*     */     {
/* 418 */       return new StringBuilder();
/*     */     }
/*     */     
/*     */     public Object deserialize(JsonParser p, DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/* 424 */       String text = p.getValueAsString();
/* 425 */       if (text != null) {
/* 426 */         return _deserialize(text, ctxt);
/*     */       }
/* 428 */       return super.deserialize(p, ctxt);
/*     */     }
/*     */     
/*     */ 
/*     */     protected Object _deserialize(String value, DeserializationContext ctxt)
/*     */       throws IOException
/*     */     {
/* 435 */       return new StringBuilder(value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\std\FromStringDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */