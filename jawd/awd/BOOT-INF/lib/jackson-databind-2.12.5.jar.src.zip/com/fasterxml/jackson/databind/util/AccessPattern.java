package com.fasterxml.jackson.databind.util;

public enum AccessPattern
{
  ALWAYS_NULL,  CONSTANT,  DYNAMIC;
  
  private AccessPattern() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\util\AccessPattern.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */