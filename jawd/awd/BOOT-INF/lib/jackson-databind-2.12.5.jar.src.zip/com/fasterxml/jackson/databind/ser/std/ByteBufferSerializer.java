/*    */ package com.fasterxml.jackson.databind.ser.std;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonArrayFormatVisitor;
/*    */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*    */ import com.fasterxml.jackson.databind.util.ByteBufferBackedInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ public class ByteBufferSerializer extends StdScalarSerializer<ByteBuffer>
/*    */ {
/*    */   public ByteBufferSerializer()
/*    */   {
/* 16 */     super(ByteBuffer.class);
/*    */   }
/*    */   
/*    */   public void serialize(ByteBuffer bbuf, JsonGenerator gen, SerializerProvider provider)
/*    */     throws java.io.IOException
/*    */   {
/* 22 */     if (bbuf.hasArray()) {
/* 23 */       int pos = bbuf.position();
/* 24 */       gen.writeBinary(bbuf.array(), bbuf.arrayOffset() + pos, bbuf.limit() - pos);
/* 25 */       return;
/*    */     }
/*    */     
/*    */ 
/* 29 */     ByteBuffer copy = bbuf.asReadOnlyBuffer();
/* 30 */     if (copy.position() > 0) {
/* 31 */       copy.rewind();
/*    */     }
/* 33 */     InputStream in = new ByteBufferBackedInputStream(copy);
/* 34 */     gen.writeBinary(in, copy.remaining());
/* 35 */     in.close();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint)
/*    */     throws com.fasterxml.jackson.databind.JsonMappingException
/*    */   {
/* 43 */     JsonArrayFormatVisitor v2 = visitor.expectArrayFormat(typeHint);
/* 44 */     if (v2 != null) {
/* 45 */       v2.itemsFormat(com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes.INTEGER);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\ser\std\ByteBufferSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */