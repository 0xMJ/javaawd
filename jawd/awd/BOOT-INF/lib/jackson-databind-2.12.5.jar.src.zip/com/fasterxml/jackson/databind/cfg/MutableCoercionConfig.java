/*    */ package com.fasterxml.jackson.databind.cfg;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MutableCoercionConfig
/*    */   extends CoercionConfig
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public MutableCoercionConfig() {}
/*    */   
/*    */   protected MutableCoercionConfig(MutableCoercionConfig src)
/*    */   {
/* 19 */     super(src);
/*    */   }
/*    */   
/*    */   public MutableCoercionConfig copy() {
/* 23 */     return new MutableCoercionConfig(this);
/*    */   }
/*    */   
/*    */   public MutableCoercionConfig setCoercion(CoercionInputShape shape, CoercionAction action)
/*    */   {
/* 28 */     this._coercionsByShape[shape.ordinal()] = action;
/* 29 */     return this;
/*    */   }
/*    */   
/*    */   public MutableCoercionConfig setAcceptBlankAsEmpty(Boolean state) {
/* 33 */     this._acceptBlankAsEmpty = state;
/* 34 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\cfg\MutableCoercionConfig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */