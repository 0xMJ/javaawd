/*      */ package com.fasterxml.jackson.databind.util;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonParser.NumberType;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.StreamWriteCapability;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.base.ParserMinimalBase;
/*      */ import com.fasterxml.jackson.core.json.JsonWriteContext;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.JsonSerializable;
/*      */ import com.fasterxml.jackson.databind.cfg.PackageVersion;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ public class TokenBuffer extends JsonGenerator
/*      */ {
/*   33 */   protected static final int DEFAULT_GENERATOR_FEATURES = ;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ObjectCodec _objectCodec;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonStreamContext _parentContext;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _generatorFeatures;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _closed;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _hasNativeTypeIds;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _hasNativeObjectIds;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _mayHaveNativeIds;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _forceBigDecimal;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Segment _first;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Segment _last;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int _appendAt;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object _typeId;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object _objectId;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  127 */   protected boolean _hasNativeId = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonWriteContext _writeContext;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TokenBuffer(ObjectCodec codec, boolean hasNativeIds)
/*      */   {
/*  152 */     this._objectCodec = codec;
/*  153 */     this._generatorFeatures = DEFAULT_GENERATOR_FEATURES;
/*  154 */     this._writeContext = JsonWriteContext.createRootContext(null);
/*      */     
/*  156 */     this._first = (this._last = new Segment());
/*  157 */     this._appendAt = 0;
/*  158 */     this._hasNativeTypeIds = hasNativeIds;
/*  159 */     this._hasNativeObjectIds = hasNativeIds;
/*      */     
/*  161 */     this._mayHaveNativeIds = ((this._hasNativeTypeIds) || (this._hasNativeObjectIds));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public TokenBuffer(JsonParser p)
/*      */   {
/*  168 */     this(p, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public TokenBuffer(JsonParser p, DeserializationContext ctxt)
/*      */   {
/*  176 */     this._objectCodec = p.getCodec();
/*  177 */     this._parentContext = p.getParsingContext();
/*  178 */     this._generatorFeatures = DEFAULT_GENERATOR_FEATURES;
/*  179 */     this._writeContext = JsonWriteContext.createRootContext(null);
/*      */     
/*  181 */     this._first = (this._last = new Segment());
/*  182 */     this._appendAt = 0;
/*  183 */     this._hasNativeTypeIds = p.canReadTypeId();
/*  184 */     this._hasNativeObjectIds = p.canReadObjectId();
/*  185 */     this._mayHaveNativeIds = ((this._hasNativeTypeIds) || (this._hasNativeObjectIds));
/*      */     
/*  187 */     this._forceBigDecimal = (ctxt == null ? false : ctxt.isEnabled(com.fasterxml.jackson.databind.DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static TokenBuffer asCopyOfValue(JsonParser p)
/*      */     throws IOException
/*      */   {
/*  201 */     TokenBuffer b = new TokenBuffer(p);
/*  202 */     b.copyCurrentStructure(p);
/*  203 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TokenBuffer overrideParentContext(JsonStreamContext ctxt)
/*      */   {
/*  215 */     this._parentContext = ctxt;
/*  216 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public TokenBuffer forceUseOfBigDecimal(boolean b)
/*      */   {
/*  223 */     this._forceBigDecimal = b;
/*  224 */     return this;
/*      */   }
/*      */   
/*      */   public Version version()
/*      */   {
/*  229 */     return PackageVersion.VERSION;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser asParser()
/*      */   {
/*  243 */     return asParser(this._objectCodec);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser asParserOnFirstToken()
/*      */     throws IOException
/*      */   {
/*  257 */     JsonParser p = asParser(this._objectCodec);
/*  258 */     p.nextToken();
/*  259 */     return p;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser asParser(ObjectCodec codec)
/*      */   {
/*  277 */     return new Parser(this._first, codec, this._hasNativeTypeIds, this._hasNativeObjectIds, this._parentContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonParser asParser(JsonParser src)
/*      */   {
/*  286 */     Parser p = new Parser(this._first, src.getCodec(), this._hasNativeTypeIds, this._hasNativeObjectIds, this._parentContext);
/*  287 */     p.setLocation(src.getTokenLocation());
/*  288 */     return p;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonToken firstToken()
/*      */   {
/*  299 */     return this._first.type(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEmpty()
/*      */   {
/*  311 */     return (this._appendAt == 0) && (this._first == this._last);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TokenBuffer append(TokenBuffer other)
/*      */     throws IOException
/*      */   {
/*  330 */     if (!this._hasNativeTypeIds) {
/*  331 */       this._hasNativeTypeIds = other.canWriteTypeId();
/*      */     }
/*  333 */     if (!this._hasNativeObjectIds) {
/*  334 */       this._hasNativeObjectIds = other.canWriteObjectId();
/*      */     }
/*  336 */     this._mayHaveNativeIds = ((this._hasNativeTypeIds) || (this._hasNativeObjectIds));
/*      */     
/*  338 */     JsonParser p = other.asParser();
/*  339 */     while (p.nextToken() != null) {
/*  340 */       copyCurrentStructure(p);
/*      */     }
/*  342 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void serialize(JsonGenerator gen)
/*      */     throws IOException
/*      */   {
/*  357 */     Segment segment = this._first;
/*  358 */     int ptr = -1;
/*      */     
/*  360 */     boolean checkIds = this._mayHaveNativeIds;
/*  361 */     boolean hasIds = (checkIds) && (segment.hasIds());
/*      */     for (;;)
/*      */     {
/*  364 */       ptr++; if (ptr >= 16) {
/*  365 */         ptr = 0;
/*  366 */         segment = segment.next();
/*  367 */         if (segment == null) break;
/*  368 */         hasIds = (checkIds) && (segment.hasIds());
/*      */       }
/*  370 */       JsonToken t = segment.type(ptr);
/*  371 */       if (t == null)
/*      */         break;
/*  373 */       if (hasIds) {
/*  374 */         Object id = segment.findObjectId(ptr);
/*  375 */         if (id != null) {
/*  376 */           gen.writeObjectId(id);
/*      */         }
/*  378 */         id = segment.findTypeId(ptr);
/*  379 */         if (id != null) {
/*  380 */           gen.writeTypeId(id);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  385 */       switch (t) {
/*      */       case START_OBJECT: 
/*  387 */         gen.writeStartObject();
/*  388 */         break;
/*      */       case END_OBJECT: 
/*  390 */         gen.writeEndObject();
/*  391 */         break;
/*      */       case START_ARRAY: 
/*  393 */         gen.writeStartArray();
/*  394 */         break;
/*      */       case END_ARRAY: 
/*  396 */         gen.writeEndArray();
/*  397 */         break;
/*      */       
/*      */ 
/*      */       case FIELD_NAME: 
/*  401 */         Object ob = segment.get(ptr);
/*  402 */         if ((ob instanceof SerializableString)) {
/*  403 */           gen.writeFieldName((SerializableString)ob);
/*      */         } else {
/*  405 */           gen.writeFieldName((String)ob);
/*      */         }
/*      */         
/*  408 */         break;
/*      */       
/*      */       case VALUE_STRING: 
/*  411 */         Object ob = segment.get(ptr);
/*  412 */         if ((ob instanceof SerializableString)) {
/*  413 */           gen.writeString((SerializableString)ob);
/*      */         } else {
/*  415 */           gen.writeString((String)ob);
/*      */         }
/*      */         
/*  418 */         break;
/*      */       
/*      */       case VALUE_NUMBER_INT: 
/*  421 */         Object n = segment.get(ptr);
/*  422 */         if ((n instanceof Integer)) {
/*  423 */           gen.writeNumber(((Integer)n).intValue());
/*  424 */         } else if ((n instanceof BigInteger)) {
/*  425 */           gen.writeNumber((BigInteger)n);
/*  426 */         } else if ((n instanceof Long)) {
/*  427 */           gen.writeNumber(((Long)n).longValue());
/*  428 */         } else if ((n instanceof Short)) {
/*  429 */           gen.writeNumber(((Short)n).shortValue());
/*      */         } else {
/*  431 */           gen.writeNumber(((Number)n).intValue());
/*      */         }
/*      */         
/*  434 */         break;
/*      */       
/*      */       case VALUE_NUMBER_FLOAT: 
/*  437 */         Object n = segment.get(ptr);
/*  438 */         if ((n instanceof Double)) {
/*  439 */           gen.writeNumber(((Double)n).doubleValue());
/*  440 */         } else if ((n instanceof BigDecimal)) {
/*  441 */           gen.writeNumber((BigDecimal)n);
/*  442 */         } else if ((n instanceof Float)) {
/*  443 */           gen.writeNumber(((Float)n).floatValue());
/*  444 */         } else if (n == null) {
/*  445 */           gen.writeNull();
/*  446 */         } else if ((n instanceof String)) {
/*  447 */           gen.writeNumber((String)n);
/*      */         } else {
/*  449 */           throw new com.fasterxml.jackson.core.JsonGenerationException(String.format("Unrecognized value type for VALUE_NUMBER_FLOAT: %s, cannot serialize", new Object[] {n
/*      */           
/*  451 */             .getClass().getName() }), gen);
/*      */         }
/*      */         
/*  454 */         break;
/*      */       case VALUE_TRUE: 
/*  456 */         gen.writeBoolean(true);
/*  457 */         break;
/*      */       case VALUE_FALSE: 
/*  459 */         gen.writeBoolean(false);
/*  460 */         break;
/*      */       case VALUE_NULL: 
/*  462 */         gen.writeNull();
/*  463 */         break;
/*      */       
/*      */       case VALUE_EMBEDDED_OBJECT: 
/*  466 */         Object value = segment.get(ptr);
/*      */         
/*      */ 
/*      */ 
/*  470 */         if ((value instanceof RawValue)) {
/*  471 */           ((RawValue)value).serialize(gen);
/*  472 */         } else if ((value instanceof JsonSerializable)) {
/*  473 */           gen.writeObject(value);
/*      */         } else {
/*  475 */           gen.writeEmbeddedObject(value);
/*      */         }
/*      */         
/*  478 */         break;
/*      */       default: 
/*  480 */         throw new RuntimeException("Internal error: should never end up through this code path");
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public TokenBuffer deserialize(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/*  492 */     if (!p.hasToken(JsonToken.FIELD_NAME)) {
/*  493 */       copyCurrentStructure(p);
/*  494 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  501 */     writeStartObject();
/*      */     JsonToken t;
/*  503 */     do { copyCurrentStructure(p);
/*  504 */     } while ((t = p.nextToken()) == JsonToken.FIELD_NAME);
/*  505 */     if (t != JsonToken.END_OBJECT) {
/*  506 */       ctxt.reportWrongTokenException(TokenBuffer.class, JsonToken.END_OBJECT, "Expected END_OBJECT after copying contents of a JsonParser into TokenBuffer, got " + t, new Object[0]);
/*      */     }
/*      */     
/*      */ 
/*  510 */     writeEndObject();
/*  511 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/*  519 */     int MAX_COUNT = 100;
/*      */     
/*  521 */     StringBuilder sb = new StringBuilder();
/*  522 */     sb.append("[TokenBuffer: ");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  529 */     JsonParser jp = asParser();
/*  530 */     int count = 0;
/*  531 */     boolean hasNativeIds = (this._hasNativeTypeIds) || (this._hasNativeObjectIds);
/*      */     for (;;)
/*      */     {
/*      */       try
/*      */       {
/*  536 */         JsonToken t = jp.nextToken();
/*  537 */         if (t == null)
/*      */           break;
/*  539 */         if (hasNativeIds) {
/*  540 */           _appendNativeIds(sb);
/*      */         }
/*      */         
/*  543 */         if (count < 100) {
/*  544 */           if (count > 0) {
/*  545 */             sb.append(", ");
/*      */           }
/*  547 */           sb.append(t.toString());
/*  548 */           if (t == JsonToken.FIELD_NAME) {
/*  549 */             sb.append('(');
/*  550 */             sb.append(jp.currentName());
/*  551 */             sb.append(')');
/*      */           }
/*      */         }
/*      */       } catch (IOException ioe) {
/*  555 */         throw new IllegalStateException(ioe); }
/*      */       JsonToken t;
/*  557 */       count++;
/*      */     }
/*      */     
/*  560 */     if (count >= 100) {
/*  561 */       sb.append(" ... (truncated ").append(count - 100).append(" entries)");
/*      */     }
/*  563 */     sb.append(']');
/*  564 */     return sb.toString();
/*      */   }
/*      */   
/*      */   private final void _appendNativeIds(StringBuilder sb)
/*      */   {
/*  569 */     Object objectId = this._last.findObjectId(this._appendAt - 1);
/*  570 */     if (objectId != null) {
/*  571 */       sb.append("[objectId=").append(String.valueOf(objectId)).append(']');
/*      */     }
/*  573 */     Object typeId = this._last.findTypeId(this._appendAt - 1);
/*  574 */     if (typeId != null) {
/*  575 */       sb.append("[typeId=").append(String.valueOf(typeId)).append(']');
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonGenerator enable(JsonGenerator.Feature f)
/*      */   {
/*  587 */     this._generatorFeatures |= f.getMask();
/*  588 */     return this;
/*      */   }
/*      */   
/*      */   public JsonGenerator disable(JsonGenerator.Feature f)
/*      */   {
/*  593 */     this._generatorFeatures &= (f.getMask() ^ 0xFFFFFFFF);
/*  594 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isEnabled(JsonGenerator.Feature f)
/*      */   {
/*  601 */     return (this._generatorFeatures & f.getMask()) != 0;
/*      */   }
/*      */   
/*      */   public int getFeatureMask()
/*      */   {
/*  606 */     return this._generatorFeatures;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public JsonGenerator setFeatureMask(int mask)
/*      */   {
/*  612 */     this._generatorFeatures = mask;
/*  613 */     return this;
/*      */   }
/*      */   
/*      */   public JsonGenerator overrideStdFeatures(int values, int mask)
/*      */   {
/*  618 */     int oldState = getFeatureMask();
/*  619 */     this._generatorFeatures = (oldState & (mask ^ 0xFFFFFFFF) | values & mask);
/*  620 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */   public JsonGenerator useDefaultPrettyPrinter()
/*      */   {
/*  626 */     return this;
/*      */   }
/*      */   
/*      */   public JsonGenerator setCodec(ObjectCodec oc)
/*      */   {
/*  631 */     this._objectCodec = oc;
/*  632 */     return this;
/*      */   }
/*      */   
/*      */   public ObjectCodec getCodec() {
/*  636 */     return this._objectCodec;
/*      */   }
/*      */   
/*  639 */   public final JsonWriteContext getOutputContext() { return this._writeContext; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canWriteBinaryNatively()
/*      */   {
/*  652 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JacksonFeatureSet<StreamWriteCapability> getWriteCapabilities()
/*      */   {
/*  661 */     return DEFAULT_WRITE_CAPABILITIES;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void flush()
/*      */     throws IOException
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/*  675 */     this._closed = true;
/*      */   }
/*      */   
/*      */   public boolean isClosed() {
/*  679 */     return this._closed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void writeStartArray()
/*      */     throws IOException
/*      */   {
/*  690 */     this._writeContext.writeValue();
/*  691 */     _appendStartMarker(JsonToken.START_ARRAY);
/*  692 */     this._writeContext = this._writeContext.createChildArrayContext();
/*      */   }
/*      */   
/*      */   public void writeStartArray(Object forValue) throws IOException
/*      */   {
/*  697 */     this._writeContext.writeValue();
/*  698 */     _appendStartMarker(JsonToken.START_ARRAY);
/*  699 */     this._writeContext = this._writeContext.createChildArrayContext(forValue);
/*      */   }
/*      */   
/*      */   public void writeStartArray(Object forValue, int size) throws IOException
/*      */   {
/*  704 */     this._writeContext.writeValue();
/*  705 */     _appendStartMarker(JsonToken.START_ARRAY);
/*  706 */     this._writeContext = this._writeContext.createChildArrayContext(forValue);
/*      */   }
/*      */   
/*      */   public final void writeEndArray()
/*      */     throws IOException
/*      */   {
/*  712 */     _appendEndMarker(JsonToken.END_ARRAY);
/*      */     
/*  714 */     JsonWriteContext c = this._writeContext.getParent();
/*  715 */     if (c != null) {
/*  716 */       this._writeContext = c;
/*      */     }
/*      */   }
/*      */   
/*      */   public final void writeStartObject()
/*      */     throws IOException
/*      */   {
/*  723 */     this._writeContext.writeValue();
/*  724 */     _appendStartMarker(JsonToken.START_OBJECT);
/*  725 */     this._writeContext = this._writeContext.createChildObjectContext();
/*      */   }
/*      */   
/*      */   public void writeStartObject(Object forValue)
/*      */     throws IOException
/*      */   {
/*  731 */     this._writeContext.writeValue();
/*  732 */     _appendStartMarker(JsonToken.START_OBJECT);
/*  733 */     JsonWriteContext ctxt = this._writeContext.createChildObjectContext(forValue);
/*  734 */     this._writeContext = ctxt;
/*      */   }
/*      */   
/*      */   public void writeStartObject(Object forValue, int size)
/*      */     throws IOException
/*      */   {
/*  740 */     this._writeContext.writeValue();
/*  741 */     _appendStartMarker(JsonToken.START_OBJECT);
/*  742 */     JsonWriteContext ctxt = this._writeContext.createChildObjectContext(forValue);
/*  743 */     this._writeContext = ctxt;
/*      */   }
/*      */   
/*      */   public final void writeEndObject()
/*      */     throws IOException
/*      */   {
/*  749 */     _appendEndMarker(JsonToken.END_OBJECT);
/*      */     
/*  751 */     JsonWriteContext c = this._writeContext.getParent();
/*  752 */     if (c != null) {
/*  753 */       this._writeContext = c;
/*      */     }
/*      */   }
/*      */   
/*      */   public final void writeFieldName(String name)
/*      */     throws IOException
/*      */   {
/*  760 */     this._writeContext.writeFieldName(name);
/*  761 */     _appendFieldName(name);
/*      */   }
/*      */   
/*      */   public void writeFieldName(SerializableString name)
/*      */     throws IOException
/*      */   {
/*  767 */     this._writeContext.writeFieldName(name.getValue());
/*  768 */     _appendFieldName(name);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeString(String text)
/*      */     throws IOException
/*      */   {
/*  779 */     if (text == null) {
/*  780 */       writeNull();
/*      */     } else {
/*  782 */       _appendValue(JsonToken.VALUE_STRING, text);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeString(char[] text, int offset, int len) throws IOException
/*      */   {
/*  788 */     writeString(new String(text, offset, len));
/*      */   }
/*      */   
/*      */   public void writeString(SerializableString text) throws IOException
/*      */   {
/*  793 */     if (text == null) {
/*  794 */       writeNull();
/*      */     } else {
/*  796 */       _appendValue(JsonToken.VALUE_STRING, text);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeRawUTF8String(byte[] text, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  804 */     _reportUnsupportedOperation();
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeUTF8String(byte[] text, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  811 */     _reportUnsupportedOperation();
/*      */   }
/*      */   
/*      */   public void writeRaw(String text) throws IOException
/*      */   {
/*  816 */     _reportUnsupportedOperation();
/*      */   }
/*      */   
/*      */   public void writeRaw(String text, int offset, int len) throws IOException
/*      */   {
/*  821 */     _reportUnsupportedOperation();
/*      */   }
/*      */   
/*      */   public void writeRaw(SerializableString text) throws IOException
/*      */   {
/*  826 */     _reportUnsupportedOperation();
/*      */   }
/*      */   
/*      */   public void writeRaw(char[] text, int offset, int len) throws IOException
/*      */   {
/*  831 */     _reportUnsupportedOperation();
/*      */   }
/*      */   
/*      */   public void writeRaw(char c) throws IOException
/*      */   {
/*  836 */     _reportUnsupportedOperation();
/*      */   }
/*      */   
/*      */   public void writeRawValue(String text) throws IOException
/*      */   {
/*  841 */     _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, new RawValue(text));
/*      */   }
/*      */   
/*      */   public void writeRawValue(String text, int offset, int len) throws IOException
/*      */   {
/*  846 */     if ((offset > 0) || (len != text.length())) {
/*  847 */       text = text.substring(offset, offset + len);
/*      */     }
/*  849 */     _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, new RawValue(text));
/*      */   }
/*      */   
/*      */   public void writeRawValue(char[] text, int offset, int len) throws IOException
/*      */   {
/*  854 */     _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, new String(text, offset, len));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeNumber(short i)
/*      */     throws IOException
/*      */   {
/*  865 */     _appendValue(JsonToken.VALUE_NUMBER_INT, Short.valueOf(i));
/*      */   }
/*      */   
/*      */   public void writeNumber(int i) throws IOException
/*      */   {
/*  870 */     _appendValue(JsonToken.VALUE_NUMBER_INT, Integer.valueOf(i));
/*      */   }
/*      */   
/*      */   public void writeNumber(long l) throws IOException
/*      */   {
/*  875 */     _appendValue(JsonToken.VALUE_NUMBER_INT, Long.valueOf(l));
/*      */   }
/*      */   
/*      */   public void writeNumber(double d) throws IOException
/*      */   {
/*  880 */     _appendValue(JsonToken.VALUE_NUMBER_FLOAT, Double.valueOf(d));
/*      */   }
/*      */   
/*      */   public void writeNumber(float f) throws IOException
/*      */   {
/*  885 */     _appendValue(JsonToken.VALUE_NUMBER_FLOAT, Float.valueOf(f));
/*      */   }
/*      */   
/*      */   public void writeNumber(BigDecimal dec) throws IOException
/*      */   {
/*  890 */     if (dec == null) {
/*  891 */       writeNull();
/*      */     } else {
/*  893 */       _appendValue(JsonToken.VALUE_NUMBER_FLOAT, dec);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeNumber(BigInteger v) throws IOException
/*      */   {
/*  899 */     if (v == null) {
/*  900 */       writeNull();
/*      */     } else {
/*  902 */       _appendValue(JsonToken.VALUE_NUMBER_INT, v);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void writeNumber(String encodedValue)
/*      */     throws IOException
/*      */   {
/*  911 */     _appendValue(JsonToken.VALUE_NUMBER_FLOAT, encodedValue);
/*      */   }
/*      */   
/*      */   public void writeBoolean(boolean state) throws IOException
/*      */   {
/*  916 */     _appendValue(state ? JsonToken.VALUE_TRUE : JsonToken.VALUE_FALSE);
/*      */   }
/*      */   
/*      */   public void writeNull() throws IOException
/*      */   {
/*  921 */     _appendValue(JsonToken.VALUE_NULL);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeObject(Object value)
/*      */     throws IOException
/*      */   {
/*  933 */     if (value == null) {
/*  934 */       writeNull();
/*  935 */       return;
/*      */     }
/*  937 */     Class<?> raw = value.getClass();
/*  938 */     if ((raw == byte[].class) || ((value instanceof RawValue))) {
/*  939 */       _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, value);
/*  940 */       return;
/*      */     }
/*  942 */     if (this._objectCodec == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  947 */       _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, value);
/*      */     } else {
/*  949 */       this._objectCodec.writeValue(this, value);
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeTree(TreeNode node)
/*      */     throws IOException
/*      */   {
/*  956 */     if (node == null) {
/*  957 */       writeNull();
/*  958 */       return;
/*      */     }
/*      */     
/*  961 */     if (this._objectCodec == null)
/*      */     {
/*  963 */       _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, node);
/*      */     } else {
/*  965 */       this._objectCodec.writeTree(this, node);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len)
/*      */     throws IOException
/*      */   {
/*  984 */     byte[] copy = new byte[len];
/*  985 */     System.arraycopy(data, offset, copy, 0, len);
/*  986 */     writeObject(copy);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength)
/*      */   {
/*  997 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canWriteTypeId()
/*      */   {
/* 1008 */     return this._hasNativeTypeIds;
/*      */   }
/*      */   
/*      */   public boolean canWriteObjectId()
/*      */   {
/* 1013 */     return this._hasNativeObjectIds;
/*      */   }
/*      */   
/*      */   public void writeTypeId(Object id)
/*      */   {
/* 1018 */     this._typeId = id;
/* 1019 */     this._hasNativeId = true;
/*      */   }
/*      */   
/*      */   public void writeObjectId(Object id)
/*      */   {
/* 1024 */     this._objectId = id;
/* 1025 */     this._hasNativeId = true;
/*      */   }
/*      */   
/*      */   public void writeEmbeddedObject(Object object) throws IOException
/*      */   {
/* 1030 */     _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, object);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copyCurrentEvent(JsonParser p)
/*      */     throws IOException
/*      */   {
/* 1042 */     if (this._mayHaveNativeIds) {
/* 1043 */       _checkNativeIds(p);
/*      */     }
/* 1045 */     switch (p.currentToken()) {
/*      */     case START_OBJECT: 
/* 1047 */       writeStartObject();
/* 1048 */       break;
/*      */     case END_OBJECT: 
/* 1050 */       writeEndObject();
/* 1051 */       break;
/*      */     case START_ARRAY: 
/* 1053 */       writeStartArray();
/* 1054 */       break;
/*      */     case END_ARRAY: 
/* 1056 */       writeEndArray();
/* 1057 */       break;
/*      */     case FIELD_NAME: 
/* 1059 */       writeFieldName(p.currentName());
/* 1060 */       break;
/*      */     case VALUE_STRING: 
/* 1062 */       if (p.hasTextCharacters()) {
/* 1063 */         writeString(p.getTextCharacters(), p.getTextOffset(), p.getTextLength());
/*      */       } else {
/* 1065 */         writeString(p.getText());
/*      */       }
/* 1067 */       break;
/*      */     case VALUE_NUMBER_INT: 
/* 1069 */       switch (p.getNumberType()) {
/*      */       case INT: 
/* 1071 */         writeNumber(p.getIntValue());
/* 1072 */         break;
/*      */       case BIG_INTEGER: 
/* 1074 */         writeNumber(p.getBigIntegerValue());
/* 1075 */         break;
/*      */       default: 
/* 1077 */         writeNumber(p.getLongValue());
/*      */       }
/* 1079 */       break;
/*      */     case VALUE_NUMBER_FLOAT: 
/* 1081 */       if (this._forceBigDecimal)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1086 */         writeNumber(p.getDecimalValue());
/*      */       } else {
/* 1088 */         switch (p.getNumberType()) {
/*      */         case BIG_DECIMAL: 
/* 1090 */           writeNumber(p.getDecimalValue());
/* 1091 */           break;
/*      */         case FLOAT: 
/* 1093 */           writeNumber(p.getFloatValue());
/* 1094 */           break;
/*      */         default: 
/* 1096 */           writeNumber(p.getDoubleValue());
/*      */         }
/*      */       }
/* 1099 */       break;
/*      */     case VALUE_TRUE: 
/* 1101 */       writeBoolean(true);
/* 1102 */       break;
/*      */     case VALUE_FALSE: 
/* 1104 */       writeBoolean(false);
/* 1105 */       break;
/*      */     case VALUE_NULL: 
/* 1107 */       writeNull();
/* 1108 */       break;
/*      */     case VALUE_EMBEDDED_OBJECT: 
/* 1110 */       writeObject(p.getEmbeddedObject());
/* 1111 */       break;
/*      */     default: 
/* 1113 */       throw new RuntimeException("Internal error: unexpected token: " + p.currentToken());
/*      */     }
/*      */   }
/*      */   
/*      */   public void copyCurrentStructure(JsonParser p)
/*      */     throws IOException
/*      */   {
/* 1120 */     JsonToken t = p.currentToken();
/*      */     
/*      */ 
/* 1123 */     if (t == JsonToken.FIELD_NAME) {
/* 1124 */       if (this._mayHaveNativeIds) {
/* 1125 */         _checkNativeIds(p);
/*      */       }
/* 1127 */       writeFieldName(p.currentName());
/* 1128 */       t = p.nextToken();
/*      */     }
/* 1130 */     else if (t == null) {
/* 1131 */       throw new IllegalStateException("No token available from argument `JsonParser`");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1137 */     switch (t) {
/*      */     case START_ARRAY: 
/* 1139 */       if (this._mayHaveNativeIds) {
/* 1140 */         _checkNativeIds(p);
/*      */       }
/* 1142 */       writeStartArray();
/* 1143 */       _copyBufferContents(p);
/* 1144 */       break;
/*      */     case START_OBJECT: 
/* 1146 */       if (this._mayHaveNativeIds) {
/* 1147 */         _checkNativeIds(p);
/*      */       }
/* 1149 */       writeStartObject();
/* 1150 */       _copyBufferContents(p);
/* 1151 */       break;
/*      */     case END_ARRAY: 
/* 1153 */       writeEndArray();
/* 1154 */       break;
/*      */     case END_OBJECT: 
/* 1156 */       writeEndObject();
/* 1157 */       break;
/*      */     default: 
/* 1159 */       _copyBufferValue(p, t);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void _copyBufferContents(JsonParser p) throws IOException
/*      */   {
/* 1165 */     int depth = 1;
/*      */     
/*      */     JsonToken t;
/* 1168 */     while ((t = p.nextToken()) != null) {
/* 1169 */       switch (t) {
/*      */       case FIELD_NAME: 
/* 1171 */         if (this._mayHaveNativeIds) {
/* 1172 */           _checkNativeIds(p);
/*      */         }
/* 1174 */         writeFieldName(p.currentName());
/* 1175 */         break;
/*      */       
/*      */       case START_ARRAY: 
/* 1178 */         if (this._mayHaveNativeIds) {
/* 1179 */           _checkNativeIds(p);
/*      */         }
/* 1181 */         writeStartArray();
/* 1182 */         depth++;
/* 1183 */         break;
/*      */       
/*      */       case START_OBJECT: 
/* 1186 */         if (this._mayHaveNativeIds) {
/* 1187 */           _checkNativeIds(p);
/*      */         }
/* 1189 */         writeStartObject();
/* 1190 */         depth++;
/* 1191 */         break;
/*      */       
/*      */       case END_ARRAY: 
/* 1194 */         writeEndArray();
/* 1195 */         depth--; if (depth == 0) {
/*      */           return;
/*      */         }
/*      */         break;
/*      */       case END_OBJECT: 
/* 1200 */         writeEndObject();
/* 1201 */         depth--; if (depth == 0) {
/*      */           return;
/*      */         }
/*      */         
/*      */         break;
/*      */       default: 
/* 1207 */         _copyBufferValue(p, t);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void _copyBufferValue(JsonParser p, JsonToken t)
/*      */     throws IOException
/*      */   {
/* 1215 */     if (this._mayHaveNativeIds) {
/* 1216 */       _checkNativeIds(p);
/*      */     }
/* 1218 */     switch (t) {
/*      */     case VALUE_STRING: 
/* 1220 */       if (p.hasTextCharacters()) {
/* 1221 */         writeString(p.getTextCharacters(), p.getTextOffset(), p.getTextLength());
/*      */       } else {
/* 1223 */         writeString(p.getText());
/*      */       }
/* 1225 */       break;
/*      */     case VALUE_NUMBER_INT: 
/* 1227 */       switch (p.getNumberType()) {
/*      */       case INT: 
/* 1229 */         writeNumber(p.getIntValue());
/* 1230 */         break;
/*      */       case BIG_INTEGER: 
/* 1232 */         writeNumber(p.getBigIntegerValue());
/* 1233 */         break;
/*      */       default: 
/* 1235 */         writeNumber(p.getLongValue());
/*      */       }
/* 1237 */       break;
/*      */     case VALUE_NUMBER_FLOAT: 
/* 1239 */       if (this._forceBigDecimal) {
/* 1240 */         writeNumber(p.getDecimalValue());
/*      */       }
/*      */       else
/*      */       {
/* 1244 */         Number n = p.getNumberValueExact();
/* 1245 */         _appendValue(JsonToken.VALUE_NUMBER_FLOAT, n);
/*      */       }
/* 1247 */       break;
/*      */     case VALUE_TRUE: 
/* 1249 */       writeBoolean(true);
/* 1250 */       break;
/*      */     case VALUE_FALSE: 
/* 1252 */       writeBoolean(false);
/* 1253 */       break;
/*      */     case VALUE_NULL: 
/* 1255 */       writeNull();
/* 1256 */       break;
/*      */     case VALUE_EMBEDDED_OBJECT: 
/* 1258 */       writeObject(p.getEmbeddedObject());
/* 1259 */       break;
/*      */     default: 
/* 1261 */       throw new RuntimeException("Internal error: unexpected token: " + t);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void _checkNativeIds(JsonParser p) throws IOException
/*      */   {
/* 1267 */     if ((this._typeId = p.getTypeId()) != null) {
/* 1268 */       this._hasNativeId = true;
/*      */     }
/* 1270 */     if ((this._objectId = p.getObjectId()) != null) {
/* 1271 */       this._hasNativeId = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _appendValue(JsonToken type)
/*      */   {
/* 1324 */     this._writeContext.writeValue();
/*      */     Segment next;
/* 1326 */     Segment next; if (this._hasNativeId) {
/* 1327 */       next = this._last.append(this._appendAt, type, this._objectId, this._typeId);
/*      */     } else {
/* 1329 */       next = this._last.append(this._appendAt, type);
/*      */     }
/* 1331 */     if (next == null) {
/* 1332 */       this._appendAt += 1;
/*      */     } else {
/* 1334 */       this._last = next;
/* 1335 */       this._appendAt = 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _appendValue(JsonToken type, Object value)
/*      */   {
/* 1347 */     this._writeContext.writeValue();
/*      */     Segment next;
/* 1349 */     Segment next; if (this._hasNativeId) {
/* 1350 */       next = this._last.append(this._appendAt, type, value, this._objectId, this._typeId);
/*      */     } else {
/* 1352 */       next = this._last.append(this._appendAt, type, value);
/*      */     }
/* 1354 */     if (next == null) {
/* 1355 */       this._appendAt += 1;
/*      */     } else {
/* 1357 */       this._last = next;
/* 1358 */       this._appendAt = 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final void _appendFieldName(Object value)
/*      */   {
/*      */     Segment next;
/*      */     
/*      */ 
/*      */     Segment next;
/*      */     
/*      */ 
/* 1372 */     if (this._hasNativeId) {
/* 1373 */       next = this._last.append(this._appendAt, JsonToken.FIELD_NAME, value, this._objectId, this._typeId);
/*      */     } else {
/* 1375 */       next = this._last.append(this._appendAt, JsonToken.FIELD_NAME, value);
/*      */     }
/* 1377 */     if (next == null) {
/* 1378 */       this._appendAt += 1;
/*      */     } else {
/* 1380 */       this._last = next;
/* 1381 */       this._appendAt = 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final void _appendStartMarker(JsonToken type)
/*      */   {
/*      */     Segment next;
/*      */     
/*      */     Segment next;
/*      */     
/* 1393 */     if (this._hasNativeId) {
/* 1394 */       next = this._last.append(this._appendAt, type, this._objectId, this._typeId);
/*      */     } else {
/* 1396 */       next = this._last.append(this._appendAt, type);
/*      */     }
/* 1398 */     if (next == null) {
/* 1399 */       this._appendAt += 1;
/*      */     } else {
/* 1401 */       this._last = next;
/* 1402 */       this._appendAt = 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void _appendEndMarker(JsonToken type)
/*      */   {
/* 1414 */     Segment next = this._last.append(this._appendAt, type);
/* 1415 */     if (next == null) {
/* 1416 */       this._appendAt += 1;
/*      */     } else {
/* 1418 */       this._last = next;
/* 1419 */       this._appendAt = 1;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void _reportUnsupportedOperation()
/*      */   {
/* 1425 */     throw new UnsupportedOperationException("Called operation not supported for TokenBuffer");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final class Parser
/*      */     extends ParserMinimalBase
/*      */   {
/*      */     protected ObjectCodec _codec;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected final boolean _hasNativeTypeIds;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected final boolean _hasNativeObjectIds;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected final boolean _hasNativeIds;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected TokenBuffer.Segment _segment;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected int _segmentPtr;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected TokenBufferReadContext _parsingContext;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected boolean _closed;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected transient ByteArrayBuilder _byteBuilder;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1483 */     protected JsonLocation _location = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public Parser(TokenBuffer.Segment firstSeg, ObjectCodec codec, boolean hasNativeTypeIds, boolean hasNativeObjectIds)
/*      */     {
/* 1495 */       this(firstSeg, codec, hasNativeTypeIds, hasNativeObjectIds, null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public Parser(TokenBuffer.Segment firstSeg, ObjectCodec codec, boolean hasNativeTypeIds, boolean hasNativeObjectIds, JsonStreamContext parentContext)
/*      */     {
/* 1502 */       super();
/* 1503 */       this._segment = firstSeg;
/* 1504 */       this._segmentPtr = -1;
/* 1505 */       this._codec = codec;
/* 1506 */       this._parsingContext = TokenBufferReadContext.createRootContext(parentContext);
/* 1507 */       this._hasNativeTypeIds = hasNativeTypeIds;
/* 1508 */       this._hasNativeObjectIds = hasNativeObjectIds;
/* 1509 */       this._hasNativeIds = ((hasNativeTypeIds) || (hasNativeObjectIds));
/*      */     }
/*      */     
/*      */     public void setLocation(JsonLocation l) {
/* 1513 */       this._location = l;
/*      */     }
/*      */     
/*      */     public ObjectCodec getCodec() {
/* 1517 */       return this._codec;
/*      */     }
/*      */     
/* 1520 */     public void setCodec(ObjectCodec c) { this._codec = c; }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Version version()
/*      */     {
/* 1530 */       return PackageVersion.VERSION;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public JacksonFeatureSet<com.fasterxml.jackson.core.StreamReadCapability> getReadCapabilities()
/*      */     {
/* 1539 */       return DEFAULT_READ_CAPABILITIES;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public JsonToken peekNextToken()
/*      */       throws IOException
/*      */     {
/* 1551 */       if (this._closed) return null;
/* 1552 */       TokenBuffer.Segment seg = this._segment;
/* 1553 */       int ptr = this._segmentPtr + 1;
/* 1554 */       if (ptr >= 16) {
/* 1555 */         ptr = 0;
/* 1556 */         seg = seg == null ? null : seg.next();
/*      */       }
/* 1558 */       return seg == null ? null : seg.type(ptr);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void close()
/*      */       throws IOException
/*      */     {
/* 1569 */       if (!this._closed) {
/* 1570 */         this._closed = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public JsonToken nextToken()
/*      */       throws IOException
/*      */     {
/* 1584 */       if ((this._closed) || (this._segment == null)) { return null;
/*      */       }
/*      */       
/* 1587 */       if (++this._segmentPtr >= 16) {
/* 1588 */         this._segmentPtr = 0;
/* 1589 */         this._segment = this._segment.next();
/* 1590 */         if (this._segment == null) {
/* 1591 */           return null;
/*      */         }
/*      */       }
/* 1594 */       this._currToken = this._segment.type(this._segmentPtr);
/*      */       
/* 1596 */       if (this._currToken == JsonToken.FIELD_NAME) {
/* 1597 */         Object ob = _currentObject();
/* 1598 */         String name = (ob instanceof String) ? (String)ob : ob.toString();
/* 1599 */         this._parsingContext.setCurrentName(name);
/* 1600 */       } else if (this._currToken == JsonToken.START_OBJECT) {
/* 1601 */         this._parsingContext = this._parsingContext.createChildObjectContext();
/* 1602 */       } else if (this._currToken == JsonToken.START_ARRAY) {
/* 1603 */         this._parsingContext = this._parsingContext.createChildArrayContext();
/* 1604 */       } else if ((this._currToken == JsonToken.END_OBJECT) || (this._currToken == JsonToken.END_ARRAY))
/*      */       {
/*      */ 
/* 1607 */         this._parsingContext = this._parsingContext.parentOrCopy();
/*      */       } else {
/* 1609 */         this._parsingContext.updateForValue();
/*      */       }
/* 1611 */       return this._currToken;
/*      */     }
/*      */     
/*      */ 
/*      */     public String nextFieldName()
/*      */       throws IOException
/*      */     {
/* 1618 */       if ((this._closed) || (this._segment == null)) {
/* 1619 */         return null;
/*      */       }
/*      */       
/* 1622 */       int ptr = this._segmentPtr + 1;
/* 1623 */       if ((ptr < 16) && (this._segment.type(ptr) == JsonToken.FIELD_NAME)) {
/* 1624 */         this._segmentPtr = ptr;
/* 1625 */         this._currToken = JsonToken.FIELD_NAME;
/* 1626 */         Object ob = this._segment.get(ptr);
/* 1627 */         String name = (ob instanceof String) ? (String)ob : ob.toString();
/* 1628 */         this._parsingContext.setCurrentName(name);
/* 1629 */         return name;
/*      */       }
/* 1631 */       return nextToken() == JsonToken.FIELD_NAME ? currentName() : null;
/*      */     }
/*      */     
/*      */     public boolean isClosed() {
/* 1635 */       return this._closed;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public JsonStreamContext getParsingContext()
/*      */     {
/* 1644 */       return this._parsingContext;
/*      */     }
/*      */     
/* 1647 */     public JsonLocation getTokenLocation() { return getCurrentLocation(); }
/*      */     
/*      */     public JsonLocation getCurrentLocation()
/*      */     {
/* 1651 */       return this._location == null ? JsonLocation.NA : this._location;
/*      */     }
/*      */     
/*      */ 
/*      */     public String currentName()
/*      */     {
/* 1657 */       if ((this._currToken == JsonToken.START_OBJECT) || (this._currToken == JsonToken.START_ARRAY)) {
/* 1658 */         JsonStreamContext parent = this._parsingContext.getParent();
/* 1659 */         return parent.getCurrentName();
/*      */       }
/* 1661 */       return this._parsingContext.getCurrentName();
/*      */     }
/*      */     
/*      */     public String getCurrentName() {
/* 1665 */       return currentName();
/*      */     }
/*      */     
/*      */ 
/*      */     public void overrideCurrentName(String name)
/*      */     {
/* 1671 */       JsonStreamContext ctxt = this._parsingContext;
/* 1672 */       if ((this._currToken == JsonToken.START_OBJECT) || (this._currToken == JsonToken.START_ARRAY)) {
/* 1673 */         ctxt = ctxt.getParent();
/*      */       }
/* 1675 */       if ((ctxt instanceof TokenBufferReadContext)) {
/*      */         try {
/* 1677 */           ((TokenBufferReadContext)ctxt).setCurrentName(name);
/*      */         } catch (IOException e) {
/* 1679 */           throw new RuntimeException(e);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String getText()
/*      */     {
/* 1694 */       if ((this._currToken == JsonToken.VALUE_STRING) || (this._currToken == JsonToken.FIELD_NAME))
/*      */       {
/* 1696 */         Object ob = _currentObject();
/* 1697 */         if ((ob instanceof String)) {
/* 1698 */           return (String)ob;
/*      */         }
/* 1700 */         return ClassUtil.nullOrToString(ob);
/*      */       }
/* 1702 */       if (this._currToken == null) {
/* 1703 */         return null;
/*      */       }
/* 1705 */       switch (TokenBuffer.1.$SwitchMap$com$fasterxml$jackson$core$JsonToken[this._currToken.ordinal()]) {
/*      */       case 7: 
/*      */       case 8: 
/* 1708 */         return ClassUtil.nullOrToString(_currentObject());
/*      */       }
/* 1710 */       return this._currToken.asString();
/*      */     }
/*      */     
/*      */ 
/*      */     public char[] getTextCharacters()
/*      */     {
/* 1716 */       String str = getText();
/* 1717 */       return str == null ? null : str.toCharArray();
/*      */     }
/*      */     
/*      */     public int getTextLength()
/*      */     {
/* 1722 */       String str = getText();
/* 1723 */       return str == null ? 0 : str.length();
/*      */     }
/*      */     
/*      */     public int getTextOffset() {
/* 1727 */       return 0;
/*      */     }
/*      */     
/*      */     public boolean hasTextCharacters()
/*      */     {
/* 1732 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isNaN()
/*      */     {
/* 1744 */       if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT) {
/* 1745 */         Object value = _currentObject();
/* 1746 */         if ((value instanceof Double)) {
/* 1747 */           Double v = (Double)value;
/* 1748 */           return (v.isNaN()) || (v.isInfinite());
/*      */         }
/* 1750 */         if ((value instanceof Float)) {
/* 1751 */           Float v = (Float)value;
/* 1752 */           return (v.isNaN()) || (v.isInfinite());
/*      */         }
/*      */       }
/* 1755 */       return false;
/*      */     }
/*      */     
/*      */     public BigInteger getBigIntegerValue()
/*      */       throws IOException
/*      */     {
/* 1761 */       Number n = getNumberValue();
/* 1762 */       if ((n instanceof BigInteger)) {
/* 1763 */         return (BigInteger)n;
/*      */       }
/* 1765 */       if (getNumberType() == JsonParser.NumberType.BIG_DECIMAL) {
/* 1766 */         return ((BigDecimal)n).toBigInteger();
/*      */       }
/*      */       
/* 1769 */       return BigInteger.valueOf(n.longValue());
/*      */     }
/*      */     
/*      */     public BigDecimal getDecimalValue()
/*      */       throws IOException
/*      */     {
/* 1775 */       Number n = getNumberValue();
/* 1776 */       if ((n instanceof BigDecimal)) {
/* 1777 */         return (BigDecimal)n;
/*      */       }
/* 1779 */       switch (TokenBuffer.1.$SwitchMap$com$fasterxml$jackson$core$JsonParser$NumberType[getNumberType().ordinal()]) {
/*      */       case 1: 
/*      */       case 5: 
/* 1782 */         return BigDecimal.valueOf(n.longValue());
/*      */       case 2: 
/* 1784 */         return new BigDecimal((BigInteger)n);
/*      */       }
/*      */       
/*      */       
/* 1788 */       return BigDecimal.valueOf(n.doubleValue());
/*      */     }
/*      */     
/*      */     public double getDoubleValue() throws IOException
/*      */     {
/* 1793 */       return getNumberValue().doubleValue();
/*      */     }
/*      */     
/*      */     public float getFloatValue() throws IOException
/*      */     {
/* 1798 */       return getNumberValue().floatValue();
/*      */     }
/*      */     
/*      */ 
/*      */     public int getIntValue()
/*      */       throws IOException
/*      */     {
/* 1805 */       Number n = this._currToken == JsonToken.VALUE_NUMBER_INT ? (Number)_currentObject() : getNumberValue();
/* 1806 */       if (((n instanceof Integer)) || (_smallerThanInt(n))) {
/* 1807 */         return n.intValue();
/*      */       }
/* 1809 */       return _convertNumberToInt(n);
/*      */     }
/*      */     
/*      */     public long getLongValue()
/*      */       throws IOException
/*      */     {
/* 1815 */       Number n = this._currToken == JsonToken.VALUE_NUMBER_INT ? (Number)_currentObject() : getNumberValue();
/* 1816 */       if (((n instanceof Long)) || (_smallerThanLong(n))) {
/* 1817 */         return n.longValue();
/*      */       }
/* 1819 */       return _convertNumberToLong(n);
/*      */     }
/*      */     
/*      */     public JsonParser.NumberType getNumberType()
/*      */       throws IOException
/*      */     {
/* 1825 */       Number n = getNumberValue();
/* 1826 */       if ((n instanceof Integer)) return JsonParser.NumberType.INT;
/* 1827 */       if ((n instanceof Long)) return JsonParser.NumberType.LONG;
/* 1828 */       if ((n instanceof Double)) return JsonParser.NumberType.DOUBLE;
/* 1829 */       if ((n instanceof BigDecimal)) return JsonParser.NumberType.BIG_DECIMAL;
/* 1830 */       if ((n instanceof BigInteger)) return JsonParser.NumberType.BIG_INTEGER;
/* 1831 */       if ((n instanceof Float)) return JsonParser.NumberType.FLOAT;
/* 1832 */       if ((n instanceof Short)) return JsonParser.NumberType.INT;
/* 1833 */       return null;
/*      */     }
/*      */     
/*      */     public final Number getNumberValue() throws IOException
/*      */     {
/* 1838 */       _checkIsNumber();
/* 1839 */       Object value = _currentObject();
/* 1840 */       if ((value instanceof Number)) {
/* 1841 */         return (Number)value;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1846 */       if ((value instanceof String)) {
/* 1847 */         String str = (String)value;
/* 1848 */         if (str.indexOf('.') >= 0) {
/* 1849 */           return Double.valueOf(Double.parseDouble(str));
/*      */         }
/* 1851 */         return Long.valueOf(Long.parseLong(str));
/*      */       }
/* 1853 */       if (value == null) {
/* 1854 */         return null;
/*      */       }
/*      */       
/* 1857 */       throw new IllegalStateException("Internal error: entry should be a Number, but is of type " + value.getClass().getName());
/*      */     }
/*      */     
/*      */     private final boolean _smallerThanInt(Number n) {
/* 1861 */       return ((n instanceof Short)) || ((n instanceof Byte));
/*      */     }
/*      */     
/*      */     private final boolean _smallerThanLong(Number n) {
/* 1865 */       return ((n instanceof Integer)) || ((n instanceof Short)) || ((n instanceof Byte));
/*      */     }
/*      */     
/*      */ 
/*      */     protected int _convertNumberToInt(Number n)
/*      */       throws IOException
/*      */     {
/* 1872 */       if ((n instanceof Long)) {
/* 1873 */         long l = n.longValue();
/* 1874 */         int result = (int)l;
/* 1875 */         if (result != l) {
/* 1876 */           reportOverflowInt();
/*      */         }
/* 1878 */         return result;
/*      */       }
/* 1880 */       if ((n instanceof BigInteger)) {
/* 1881 */         BigInteger big = (BigInteger)n;
/* 1882 */         if ((BI_MIN_INT.compareTo(big) > 0) || 
/* 1883 */           (BI_MAX_INT.compareTo(big) < 0))
/* 1884 */           reportOverflowInt();
/*      */       } else {
/* 1886 */         if (((n instanceof Double)) || ((n instanceof Float))) {
/* 1887 */           double d = n.doubleValue();
/*      */           
/* 1889 */           if ((d < -2.147483648E9D) || (d > 2.147483647E9D)) {
/* 1890 */             reportOverflowInt();
/*      */           }
/* 1892 */           return (int)d; }
/* 1893 */         if ((n instanceof BigDecimal)) {
/* 1894 */           BigDecimal big = (BigDecimal)n;
/* 1895 */           if ((BD_MIN_INT.compareTo(big) > 0) || 
/* 1896 */             (BD_MAX_INT.compareTo(big) < 0)) {
/* 1897 */             reportOverflowInt();
/*      */           }
/*      */         } else {
/* 1900 */           _throwInternal();
/*      */         } }
/* 1902 */       return n.intValue();
/*      */     }
/*      */     
/*      */     protected long _convertNumberToLong(Number n) throws IOException
/*      */     {
/* 1907 */       if ((n instanceof BigInteger)) {
/* 1908 */         BigInteger big = (BigInteger)n;
/* 1909 */         if ((BI_MIN_LONG.compareTo(big) > 0) || 
/* 1910 */           (BI_MAX_LONG.compareTo(big) < 0))
/* 1911 */           reportOverflowLong();
/*      */       } else {
/* 1913 */         if (((n instanceof Double)) || ((n instanceof Float))) {
/* 1914 */           double d = n.doubleValue();
/*      */           
/* 1916 */           if ((d < -9.223372036854776E18D) || (d > 9.223372036854776E18D)) {
/* 1917 */             reportOverflowLong();
/*      */           }
/* 1919 */           return d; }
/* 1920 */         if ((n instanceof BigDecimal)) {
/* 1921 */           BigDecimal big = (BigDecimal)n;
/* 1922 */           if ((BD_MIN_LONG.compareTo(big) > 0) || 
/* 1923 */             (BD_MAX_LONG.compareTo(big) < 0)) {
/* 1924 */             reportOverflowLong();
/*      */           }
/*      */         } else {
/* 1927 */           _throwInternal();
/*      */         } }
/* 1929 */       return n.longValue();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Object getEmbeddedObject()
/*      */     {
/* 1941 */       if (this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT) {
/* 1942 */         return _currentObject();
/*      */       }
/* 1944 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public byte[] getBinaryValue(Base64Variant b64variant)
/*      */       throws IOException, JsonParseException
/*      */     {
/* 1952 */       if (this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT)
/*      */       {
/* 1954 */         Object ob = _currentObject();
/* 1955 */         if ((ob instanceof byte[])) {
/* 1956 */           return (byte[])ob;
/*      */         }
/*      */       }
/*      */       
/* 1960 */       if (this._currToken != JsonToken.VALUE_STRING) {
/* 1961 */         throw _constructError("Current token (" + this._currToken + ") not VALUE_STRING (or VALUE_EMBEDDED_OBJECT with byte[]), cannot access as binary");
/*      */       }
/* 1963 */       String str = getText();
/* 1964 */       if (str == null) {
/* 1965 */         return null;
/*      */       }
/* 1967 */       ByteArrayBuilder builder = this._byteBuilder;
/* 1968 */       if (builder == null) {
/* 1969 */         this._byteBuilder = (builder = new ByteArrayBuilder(100));
/*      */       } else {
/* 1971 */         this._byteBuilder.reset();
/*      */       }
/* 1973 */       _decodeBase64(str, builder, b64variant);
/* 1974 */       return builder.toByteArray();
/*      */     }
/*      */     
/*      */     public int readBinaryValue(Base64Variant b64variant, OutputStream out)
/*      */       throws IOException
/*      */     {
/* 1980 */       byte[] data = getBinaryValue(b64variant);
/* 1981 */       if (data != null) {
/* 1982 */         out.write(data, 0, data.length);
/* 1983 */         return data.length;
/*      */       }
/* 1985 */       return 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean canReadObjectId()
/*      */     {
/* 1996 */       return this._hasNativeObjectIds;
/*      */     }
/*      */     
/*      */     public boolean canReadTypeId()
/*      */     {
/* 2001 */       return this._hasNativeTypeIds;
/*      */     }
/*      */     
/*      */     public Object getTypeId()
/*      */     {
/* 2006 */       return this._segment.findTypeId(this._segmentPtr);
/*      */     }
/*      */     
/*      */     public Object getObjectId()
/*      */     {
/* 2011 */       return this._segment.findObjectId(this._segmentPtr);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected final Object _currentObject()
/*      */     {
/* 2021 */       return this._segment.get(this._segmentPtr);
/*      */     }
/*      */     
/*      */     protected final void _checkIsNumber() throws JsonParseException
/*      */     {
/* 2026 */       if ((this._currToken == null) || (!this._currToken.isNumeric())) {
/* 2027 */         throw _constructError("Current token (" + this._currToken + ") not numeric, cannot use numeric value accessors");
/*      */       }
/*      */     }
/*      */     
/*      */     protected void _handleEOF() throws JsonParseException
/*      */     {
/* 2033 */       _throwInternal();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final class Segment
/*      */   {
/*      */     public static final int TOKENS_PER_SEGMENT = 16;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2055 */     private static final JsonToken[] TOKEN_TYPES_BY_INDEX = new JsonToken[16];
/* 2056 */     static { JsonToken[] t = JsonToken.values();
/*      */       
/* 2058 */       System.arraycopy(t, 1, TOKEN_TYPES_BY_INDEX, 1, Math.min(15, t.length - 1));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Segment _next;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected long _tokenTypes;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2076 */     protected final Object[] _tokens = new Object[16];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected TreeMap<Integer, Object> _nativeIds;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public JsonToken type(int index)
/*      */     {
/* 2089 */       long l = this._tokenTypes;
/* 2090 */       if (index > 0) {
/* 2091 */         l >>= index << 2;
/*      */       }
/* 2093 */       int ix = (int)l & 0xF;
/* 2094 */       return TOKEN_TYPES_BY_INDEX[ix];
/*      */     }
/*      */     
/*      */     public int rawType(int index)
/*      */     {
/* 2099 */       long l = this._tokenTypes;
/* 2100 */       if (index > 0) {
/* 2101 */         l >>= index << 2;
/*      */       }
/* 2103 */       int ix = (int)l & 0xF;
/* 2104 */       return ix;
/*      */     }
/*      */     
/*      */     public Object get(int index) {
/* 2108 */       return this._tokens[index];
/*      */     }
/*      */     
/* 2111 */     public Segment next() { return this._next; }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean hasIds()
/*      */     {
/* 2118 */       return this._nativeIds != null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public Segment append(int index, JsonToken tokenType)
/*      */     {
/* 2125 */       if (index < 16) {
/* 2126 */         set(index, tokenType);
/* 2127 */         return null;
/*      */       }
/* 2129 */       this._next = new Segment();
/* 2130 */       this._next.set(0, tokenType);
/* 2131 */       return this._next;
/*      */     }
/*      */     
/*      */ 
/*      */     public Segment append(int index, JsonToken tokenType, Object objectId, Object typeId)
/*      */     {
/* 2137 */       if (index < 16) {
/* 2138 */         set(index, tokenType, objectId, typeId);
/* 2139 */         return null;
/*      */       }
/* 2141 */       this._next = new Segment();
/* 2142 */       this._next.set(0, tokenType, objectId, typeId);
/* 2143 */       return this._next;
/*      */     }
/*      */     
/*      */     public Segment append(int index, JsonToken tokenType, Object value)
/*      */     {
/* 2148 */       if (index < 16) {
/* 2149 */         set(index, tokenType, value);
/* 2150 */         return null;
/*      */       }
/* 2152 */       this._next = new Segment();
/* 2153 */       this._next.set(0, tokenType, value);
/* 2154 */       return this._next;
/*      */     }
/*      */     
/*      */ 
/*      */     public Segment append(int index, JsonToken tokenType, Object value, Object objectId, Object typeId)
/*      */     {
/* 2160 */       if (index < 16) {
/* 2161 */         set(index, tokenType, value, objectId, typeId);
/* 2162 */         return null;
/*      */       }
/* 2164 */       this._next = new Segment();
/* 2165 */       this._next.set(0, tokenType, value, objectId, typeId);
/* 2166 */       return this._next;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void set(int index, JsonToken tokenType)
/*      */     {
/* 2220 */       long typeCode = tokenType.ordinal();
/* 2221 */       if (index > 0) {
/* 2222 */         typeCode <<= index << 2;
/*      */       }
/* 2224 */       this._tokenTypes |= typeCode;
/*      */     }
/*      */     
/*      */ 
/*      */     private void set(int index, JsonToken tokenType, Object objectId, Object typeId)
/*      */     {
/* 2230 */       long typeCode = tokenType.ordinal();
/* 2231 */       if (index > 0) {
/* 2232 */         typeCode <<= index << 2;
/*      */       }
/* 2234 */       this._tokenTypes |= typeCode;
/* 2235 */       assignNativeIds(index, objectId, typeId);
/*      */     }
/*      */     
/*      */     private void set(int index, JsonToken tokenType, Object value)
/*      */     {
/* 2240 */       this._tokens[index] = value;
/* 2241 */       long typeCode = tokenType.ordinal();
/* 2242 */       if (index > 0) {
/* 2243 */         typeCode <<= index << 2;
/*      */       }
/* 2245 */       this._tokenTypes |= typeCode;
/*      */     }
/*      */     
/*      */ 
/*      */     private void set(int index, JsonToken tokenType, Object value, Object objectId, Object typeId)
/*      */     {
/* 2251 */       this._tokens[index] = value;
/* 2252 */       long typeCode = tokenType.ordinal();
/* 2253 */       if (index > 0) {
/* 2254 */         typeCode <<= index << 2;
/*      */       }
/* 2256 */       this._tokenTypes |= typeCode;
/* 2257 */       assignNativeIds(index, objectId, typeId);
/*      */     }
/*      */     
/*      */     private final void assignNativeIds(int index, Object objectId, Object typeId)
/*      */     {
/* 2262 */       if (this._nativeIds == null) {
/* 2263 */         this._nativeIds = new TreeMap();
/*      */       }
/* 2265 */       if (objectId != null) {
/* 2266 */         this._nativeIds.put(Integer.valueOf(_objectIdIndex(index)), objectId);
/*      */       }
/* 2268 */       if (typeId != null) {
/* 2269 */         this._nativeIds.put(Integer.valueOf(_typeIdIndex(index)), typeId);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     Object findObjectId(int index)
/*      */     {
/* 2277 */       return this._nativeIds == null ? null : this._nativeIds.get(Integer.valueOf(_objectIdIndex(index)));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     Object findTypeId(int index)
/*      */     {
/* 2284 */       return this._nativeIds == null ? null : this._nativeIds.get(Integer.valueOf(_typeIdIndex(index)));
/*      */     }
/*      */     
/* 2287 */     private final int _typeIdIndex(int i) { return i + i; }
/* 2288 */     private final int _objectIdIndex(int i) { return i + i + 1; }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\util\TokenBuffer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */