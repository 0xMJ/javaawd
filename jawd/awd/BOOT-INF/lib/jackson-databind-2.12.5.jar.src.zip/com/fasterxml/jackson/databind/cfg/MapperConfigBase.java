/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties.Value;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude.Value;
/*     */ import com.fasterxml.jackson.annotation.JsonIncludeProperties.Value;
/*     */ import com.fasterxml.jackson.annotation.JsonSetter.Value;
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.introspect.AccessorNamingStrategy.Provider;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*     */ import com.fasterxml.jackson.databind.introspect.SimpleMixInResolver;
/*     */ import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
/*     */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.RootNameLookup;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public abstract class MapperConfigBase<CFG extends ConfigFeature, T extends MapperConfigBase<CFG, T>> extends MapperConfig<T> implements java.io.Serializable
/*     */ {
/*  31 */   protected static final ConfigOverride EMPTY_OVERRIDE = ;
/*     */   
/*  33 */   private static final int DEFAULT_MAPPER_FEATURES = collectFeatureDefaults(MapperFeature.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  38 */   private static final int AUTO_DETECT_MASK = MapperFeature.AUTO_DETECT_FIELDS
/*  39 */     .getMask() | MapperFeature.AUTO_DETECT_GETTERS
/*  40 */     .getMask() | MapperFeature.AUTO_DETECT_IS_GETTERS
/*  41 */     .getMask() | MapperFeature.AUTO_DETECT_SETTERS
/*  42 */     .getMask() | MapperFeature.AUTO_DETECT_CREATORS
/*  43 */     .getMask();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final SimpleMixInResolver _mixIns;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final SubtypeResolver _subtypeResolver;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final PropertyName _rootName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Class<?> _view;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ContextAttributes _attributes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final RootNameLookup _rootNames;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ConfigOverrides _configOverrides;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MapperConfigBase(BaseSettings base, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides)
/*     */   {
/* 126 */     super(base, DEFAULT_MAPPER_FEATURES);
/* 127 */     this._mixIns = mixins;
/* 128 */     this._subtypeResolver = str;
/* 129 */     this._rootNames = rootNames;
/* 130 */     this._rootName = null;
/* 131 */     this._view = null;
/*     */     
/* 133 */     this._attributes = ContextAttributes.getEmpty();
/* 134 */     this._configOverrides = configOverrides;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides)
/*     */   {
/* 149 */     super(src, src._base.copy());
/* 150 */     this._mixIns = mixins;
/* 151 */     this._subtypeResolver = str;
/* 152 */     this._rootNames = rootNames;
/* 153 */     this._rootName = src._rootName;
/* 154 */     this._view = src._view;
/* 155 */     this._attributes = src._attributes;
/* 156 */     this._configOverrides = configOverrides;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src)
/*     */   {
/* 165 */     super(src);
/* 166 */     this._mixIns = src._mixIns;
/* 167 */     this._subtypeResolver = src._subtypeResolver;
/* 168 */     this._rootNames = src._rootNames;
/* 169 */     this._rootName = src._rootName;
/* 170 */     this._view = src._view;
/* 171 */     this._attributes = src._attributes;
/* 172 */     this._configOverrides = src._configOverrides;
/*     */   }
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, BaseSettings base)
/*     */   {
/* 177 */     super(src, base);
/* 178 */     this._mixIns = src._mixIns;
/* 179 */     this._subtypeResolver = src._subtypeResolver;
/* 180 */     this._rootNames = src._rootNames;
/* 181 */     this._rootName = src._rootName;
/* 182 */     this._view = src._view;
/* 183 */     this._attributes = src._attributes;
/* 184 */     this._configOverrides = src._configOverrides;
/*     */   }
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, int mapperFeatures)
/*     */   {
/* 189 */     super(src, mapperFeatures);
/* 190 */     this._mixIns = src._mixIns;
/* 191 */     this._subtypeResolver = src._subtypeResolver;
/* 192 */     this._rootNames = src._rootNames;
/* 193 */     this._rootName = src._rootName;
/* 194 */     this._view = src._view;
/* 195 */     this._attributes = src._attributes;
/* 196 */     this._configOverrides = src._configOverrides;
/*     */   }
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, SubtypeResolver str) {
/* 200 */     super(src);
/* 201 */     this._mixIns = src._mixIns;
/* 202 */     this._subtypeResolver = str;
/* 203 */     this._rootNames = src._rootNames;
/* 204 */     this._rootName = src._rootName;
/* 205 */     this._view = src._view;
/* 206 */     this._attributes = src._attributes;
/* 207 */     this._configOverrides = src._configOverrides;
/*     */   }
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, PropertyName rootName) {
/* 211 */     super(src);
/* 212 */     this._mixIns = src._mixIns;
/* 213 */     this._subtypeResolver = src._subtypeResolver;
/* 214 */     this._rootNames = src._rootNames;
/* 215 */     this._rootName = rootName;
/* 216 */     this._view = src._view;
/* 217 */     this._attributes = src._attributes;
/* 218 */     this._configOverrides = src._configOverrides;
/*     */   }
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, Class<?> view)
/*     */   {
/* 223 */     super(src);
/* 224 */     this._mixIns = src._mixIns;
/* 225 */     this._subtypeResolver = src._subtypeResolver;
/* 226 */     this._rootNames = src._rootNames;
/* 227 */     this._rootName = src._rootName;
/* 228 */     this._view = view;
/* 229 */     this._attributes = src._attributes;
/* 230 */     this._configOverrides = src._configOverrides;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, SimpleMixInResolver mixins)
/*     */   {
/* 238 */     super(src);
/* 239 */     this._mixIns = mixins;
/* 240 */     this._subtypeResolver = src._subtypeResolver;
/* 241 */     this._rootNames = src._rootNames;
/* 242 */     this._rootName = src._rootName;
/* 243 */     this._view = src._view;
/* 244 */     this._attributes = src._attributes;
/* 245 */     this._configOverrides = src._configOverrides;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, ContextAttributes attr)
/*     */   {
/* 253 */     super(src);
/* 254 */     this._mixIns = src._mixIns;
/* 255 */     this._subtypeResolver = src._subtypeResolver;
/* 256 */     this._rootNames = src._rootNames;
/* 257 */     this._rootName = src._rootName;
/* 258 */     this._view = src._view;
/* 259 */     this._attributes = attr;
/* 260 */     this._configOverrides = src._configOverrides;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract T _withBase(BaseSettings paramBaseSettings);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract T _withMapperFeatures(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T with(MapperFeature... features)
/*     */   {
/* 293 */     int newMapperFlags = this._mapperFeatures;
/* 294 */     for (MapperFeature f : features) {
/* 295 */       newMapperFlags |= f.getMask();
/*     */     }
/* 297 */     if (newMapperFlags == this._mapperFeatures) {
/* 298 */       return this;
/*     */     }
/* 300 */     return _withMapperFeatures(newMapperFlags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T without(MapperFeature... features)
/*     */   {
/* 311 */     int newMapperFlags = this._mapperFeatures;
/* 312 */     for (MapperFeature f : features) {
/* 313 */       newMapperFlags &= (f.getMask() ^ 0xFFFFFFFF);
/*     */     }
/* 315 */     if (newMapperFlags == this._mapperFeatures) {
/* 316 */       return this;
/*     */     }
/* 318 */     return _withMapperFeatures(newMapperFlags);
/*     */   }
/*     */   
/*     */ 
/*     */   public final T with(MapperFeature feature, boolean state)
/*     */   {
/*     */     int newMapperFlags;
/*     */     int newMapperFlags;
/* 326 */     if (state) {
/* 327 */       newMapperFlags = this._mapperFeatures | feature.getMask();
/*     */     } else {
/* 329 */       newMapperFlags = this._mapperFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/*     */     }
/* 331 */     if (newMapperFlags == this._mapperFeatures) {
/* 332 */       return this;
/*     */     }
/* 334 */     return _withMapperFeatures(newMapperFlags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T with(AnnotationIntrospector ai)
/*     */   {
/* 351 */     return _withBase(this._base.withAnnotationIntrospector(ai));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T withAppendedAnnotationIntrospector(AnnotationIntrospector ai)
/*     */   {
/* 359 */     return _withBase(this._base.withAppendedAnnotationIntrospector(ai));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T withInsertedAnnotationIntrospector(AnnotationIntrospector ai)
/*     */   {
/* 367 */     return _withBase(this._base.withInsertedAnnotationIntrospector(ai));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T with(ClassIntrospector ci)
/*     */   {
/* 379 */     return _withBase(this._base.withClassIntrospector(ci));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract T with(ContextAttributes paramContextAttributes);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T withAttributes(Map<?, ?> attributes)
/*     */   {
/* 403 */     return with(getAttributes().withSharedAttributes(attributes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T withAttribute(Object key, Object value)
/*     */   {
/* 413 */     return with(getAttributes().withSharedAttribute(key, value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T withoutAttribute(Object key)
/*     */   {
/* 423 */     return with(getAttributes().withoutSharedAttribute(key));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T with(TypeFactory tf)
/*     */   {
/* 438 */     return _withBase(this._base.withTypeFactory(tf));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T with(TypeResolverBuilder<?> trb)
/*     */   {
/* 446 */     return _withBase(this._base.withTypeResolverBuilder(trb));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T with(PropertyNamingStrategy pns)
/*     */   {
/* 458 */     return _withBase(this._base.withPropertyNamingStrategy(pns));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T with(AccessorNamingStrategy.Provider p)
/*     */   {
/* 469 */     return _withBase(this._base.withAccessorNaming(p));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T with(HandlerInstantiator hi)
/*     */   {
/* 481 */     return _withBase(this._base.withHandlerInstantiator(hi));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T with(Base64Variant base64)
/*     */   {
/* 495 */     return _withBase(this._base.with(base64));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T with(DateFormat df)
/*     */   {
/* 506 */     return _withBase(this._base.withDateFormat(df));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T with(Locale l)
/*     */   {
/* 514 */     return _withBase(this._base.with(l));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final T with(TimeZone tz)
/*     */   {
/* 522 */     return _withBase(this._base.with(tz));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract T withRootName(PropertyName paramPropertyName);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T withRootName(String rootName)
/*     */   {
/* 544 */     if (rootName == null) {
/* 545 */       return withRootName((PropertyName)null);
/*     */     }
/* 547 */     return withRootName(PropertyName.construct(rootName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract T with(SubtypeResolver paramSubtypeResolver);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract T withView(Class<?> paramClass);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final SubtypeResolver getSubtypeResolver()
/*     */   {
/* 579 */     return this._subtypeResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final String getRootName()
/*     */   {
/* 587 */     return this._rootName == null ? null : this._rootName.getSimpleName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final PropertyName getFullRootName()
/*     */   {
/* 594 */     return this._rootName;
/*     */   }
/*     */   
/*     */   public final Class<?> getActiveView()
/*     */   {
/* 599 */     return this._view;
/*     */   }
/*     */   
/*     */   public final ContextAttributes getAttributes()
/*     */   {
/* 604 */     return this._attributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final ConfigOverride getConfigOverride(Class<?> type)
/*     */   {
/* 615 */     ConfigOverride override = this._configOverrides.findOverride(type);
/* 616 */     return override == null ? EMPTY_OVERRIDE : override;
/*     */   }
/*     */   
/*     */   public final ConfigOverride findConfigOverride(Class<?> type)
/*     */   {
/* 621 */     return this._configOverrides.findOverride(type);
/*     */   }
/*     */   
/*     */   public final JsonInclude.Value getDefaultPropertyInclusion()
/*     */   {
/* 626 */     return this._configOverrides.getDefaultInclusion();
/*     */   }
/*     */   
/*     */   public final JsonInclude.Value getDefaultPropertyInclusion(Class<?> baseType)
/*     */   {
/* 631 */     JsonInclude.Value v = getConfigOverride(baseType).getInclude();
/* 632 */     JsonInclude.Value def = getDefaultPropertyInclusion();
/* 633 */     if (def == null) {
/* 634 */       return v;
/*     */     }
/* 636 */     return def.withOverrides(v);
/*     */   }
/*     */   
/*     */ 
/*     */   public final JsonInclude.Value getDefaultInclusion(Class<?> baseType, Class<?> propertyType)
/*     */   {
/* 642 */     JsonInclude.Value v = getConfigOverride(propertyType).getIncludeAsProperty();
/* 643 */     JsonInclude.Value def = getDefaultPropertyInclusion(baseType);
/* 644 */     if (def == null) {
/* 645 */       return v;
/*     */     }
/* 647 */     return def.withOverrides(v);
/*     */   }
/*     */   
/*     */   public final JsonFormat.Value getDefaultPropertyFormat(Class<?> type)
/*     */   {
/* 652 */     return this._configOverrides.findFormatDefaults(type);
/*     */   }
/*     */   
/*     */   public final JsonIgnoreProperties.Value getDefaultPropertyIgnorals(Class<?> type)
/*     */   {
/* 657 */     ConfigOverride overrides = this._configOverrides.findOverride(type);
/* 658 */     if (overrides != null) {
/* 659 */       JsonIgnoreProperties.Value v = overrides.getIgnorals();
/* 660 */       if (v != null) {
/* 661 */         return v;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 666 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final JsonIgnoreProperties.Value getDefaultPropertyIgnorals(Class<?> baseType, AnnotatedClass actualClass)
/*     */   {
/* 673 */     AnnotationIntrospector intr = getAnnotationIntrospector();
/*     */     
/* 675 */     JsonIgnoreProperties.Value base = intr == null ? null : intr.findPropertyIgnoralByName(this, actualClass);
/* 676 */     JsonIgnoreProperties.Value overrides = getDefaultPropertyIgnorals(baseType);
/* 677 */     return JsonIgnoreProperties.Value.merge(base, overrides);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final JsonIncludeProperties.Value getDefaultPropertyInclusions(Class<?> baseType, AnnotatedClass actualClass)
/*     */   {
/* 684 */     AnnotationIntrospector intr = getAnnotationIntrospector();
/* 685 */     return intr == null ? null : intr.findPropertyInclusionByName(this, actualClass);
/*     */   }
/*     */   
/*     */ 
/*     */   public final VisibilityChecker<?> getDefaultVisibilityChecker()
/*     */   {
/* 691 */     VisibilityChecker<?> vchecker = this._configOverrides.getDefaultVisibility();
/*     */     
/*     */ 
/* 694 */     if ((this._mapperFeatures & AUTO_DETECT_MASK) != AUTO_DETECT_MASK) {
/* 695 */       if (!isEnabled(MapperFeature.AUTO_DETECT_FIELDS)) {
/* 696 */         vchecker = vchecker.withFieldVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/* 698 */       if (!isEnabled(MapperFeature.AUTO_DETECT_GETTERS)) {
/* 699 */         vchecker = vchecker.withGetterVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/* 701 */       if (!isEnabled(MapperFeature.AUTO_DETECT_IS_GETTERS)) {
/* 702 */         vchecker = vchecker.withIsGetterVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/* 704 */       if (!isEnabled(MapperFeature.AUTO_DETECT_SETTERS)) {
/* 705 */         vchecker = vchecker.withSetterVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/* 707 */       if (!isEnabled(MapperFeature.AUTO_DETECT_CREATORS)) {
/* 708 */         vchecker = vchecker.withCreatorVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/*     */     }
/* 711 */     return vchecker;
/*     */   }
/*     */   
/*     */ 
/*     */   public final VisibilityChecker<?> getDefaultVisibilityChecker(Class<?> baseType, AnnotatedClass actualClass)
/*     */   {
/* 717 */     VisibilityChecker<?> vc = getDefaultVisibilityChecker();
/* 718 */     AnnotationIntrospector intr = getAnnotationIntrospector();
/* 719 */     if (intr != null) {
/* 720 */       vc = intr.findAutoDetectVisibility(actualClass, vc);
/*     */     }
/* 722 */     ConfigOverride overrides = this._configOverrides.findOverride(baseType);
/* 723 */     if (overrides != null) {
/* 724 */       vc = vc.withOverrides(overrides.getVisibility());
/*     */     }
/* 726 */     return vc;
/*     */   }
/*     */   
/*     */   public final JsonSetter.Value getDefaultSetterInfo()
/*     */   {
/* 731 */     return this._configOverrides.getDefaultSetterInfo();
/*     */   }
/*     */   
/*     */   public Boolean getDefaultMergeable()
/*     */   {
/* 736 */     return this._configOverrides.getDefaultMergeable();
/*     */   }
/*     */   
/*     */ 
/*     */   public Boolean getDefaultMergeable(Class<?> baseType)
/*     */   {
/* 742 */     ConfigOverride cfg = this._configOverrides.findOverride(baseType);
/* 743 */     if (cfg != null) {
/* 744 */       Boolean b = cfg.getMergeable();
/* 745 */       if (b != null) {
/* 746 */         return b;
/*     */       }
/*     */     }
/* 749 */     return this._configOverrides.getDefaultMergeable();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertyName findRootName(JavaType rootType)
/*     */   {
/* 760 */     if (this._rootName != null) {
/* 761 */       return this._rootName;
/*     */     }
/* 763 */     return this._rootNames.findRootName(rootType, this);
/*     */   }
/*     */   
/*     */   public PropertyName findRootName(Class<?> rawRootType)
/*     */   {
/* 768 */     if (this._rootName != null) {
/* 769 */       return this._rootName;
/*     */     }
/* 771 */     return this._rootNames.findRootName(rawRootType, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Class<?> findMixInClassFor(Class<?> cls)
/*     */   {
/* 786 */     return this._mixIns.findMixInClassFor(cls);
/*     */   }
/*     */   
/*     */ 
/*     */   public com.fasterxml.jackson.databind.introspect.ClassIntrospector.MixInResolver copy()
/*     */   {
/* 792 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int mixInCount()
/*     */   {
/* 800 */     return this._mixIns.localSize();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\cfg\MapperConfigBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */