/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedField;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PropertyNamingStrategies
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*  36 */   public static final PropertyNamingStrategy LOWER_CAMEL_CASE = new LowerCamelCaseStrategy();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  45 */   public static final PropertyNamingStrategy UPPER_CAMEL_CASE = new UpperCamelCaseStrategy();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  54 */   public static final PropertyNamingStrategy SNAKE_CASE = new SnakeCaseStrategy();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */   public static final PropertyNamingStrategy LOWER_CASE = new LowerCaseStrategy();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   public static final PropertyNamingStrategy KEBAB_CASE = new KebabCaseStrategy();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */   public static final PropertyNamingStrategy LOWER_DOT_CASE = new LowerDotCaseStrategy();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract class NamingBase
/*     */     extends PropertyNamingStrategy
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String nameForField(MapperConfig<?> config, AnnotatedField field, String defaultName)
/*     */     {
/*  99 */       return translate(defaultName);
/*     */     }
/*     */     
/*     */     public String nameForGetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName)
/*     */     {
/* 104 */       return translate(defaultName);
/*     */     }
/*     */     
/*     */     public String nameForSetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName)
/*     */     {
/* 109 */       return translate(defaultName);
/*     */     }
/*     */     
/*     */ 
/*     */     public String nameForConstructorParameter(MapperConfig<?> config, AnnotatedParameter ctorParam, String defaultName)
/*     */     {
/* 115 */       return translate(defaultName);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public abstract String translate(String paramString);
/*     */     
/*     */ 
/*     */     protected String translateLowerCaseWithSeparator(String input, char separator)
/*     */     {
/* 125 */       if (input == null) {
/* 126 */         return input;
/*     */       }
/* 128 */       int length = input.length();
/* 129 */       if (length == 0) {
/* 130 */         return input;
/*     */       }
/*     */       
/* 133 */       StringBuilder result = new StringBuilder(length + (length >> 1));
/* 134 */       int upperCount = 0;
/* 135 */       for (int i = 0; i < length; i++) {
/* 136 */         char ch = input.charAt(i);
/* 137 */         char lc = Character.toLowerCase(ch);
/*     */         
/* 139 */         if (lc == ch)
/*     */         {
/*     */ 
/* 142 */           if (upperCount > 1)
/*     */           {
/* 144 */             result.insert(result.length() - 1, separator);
/*     */           }
/* 146 */           upperCount = 0;
/*     */         }
/*     */         else {
/* 149 */           if ((upperCount == 0) && (i > 0)) {
/* 150 */             result.append(separator);
/*     */           }
/* 152 */           upperCount++;
/*     */         }
/* 154 */         result.append(lc);
/*     */       }
/* 156 */       return result.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SnakeCaseStrategy
/*     */     extends PropertyNamingStrategies.NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String translate(String input)
/*     */     {
/* 222 */       if (input == null) return input;
/* 223 */       int length = input.length();
/* 224 */       StringBuilder result = new StringBuilder(length * 2);
/* 225 */       int resultLength = 0;
/* 226 */       boolean wasPrevTranslated = false;
/* 227 */       for (int i = 0; i < length; i++)
/*     */       {
/* 229 */         char c = input.charAt(i);
/* 230 */         if ((i > 0) || (c != '_'))
/*     */         {
/* 232 */           if (Character.isUpperCase(c))
/*     */           {
/* 234 */             if ((!wasPrevTranslated) && (resultLength > 0) && (result.charAt(resultLength - 1) != '_'))
/*     */             {
/* 236 */               result.append('_');
/* 237 */               resultLength++;
/*     */             }
/* 239 */             c = Character.toLowerCase(c);
/* 240 */             wasPrevTranslated = true;
/*     */           }
/*     */           else
/*     */           {
/* 244 */             wasPrevTranslated = false;
/*     */           }
/* 246 */           result.append(c);
/* 247 */           resultLength++;
/*     */         }
/*     */       }
/* 250 */       return resultLength > 0 ? result.toString() : input;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class LowerCamelCaseStrategy
/*     */     extends PropertyNamingStrategies.NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/*     */ 
/*     */     public String translate(String input)
/*     */     {
/* 264 */       return input;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class UpperCamelCaseStrategy
/*     */     extends PropertyNamingStrategies.NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String translate(String input)
/*     */     {
/* 296 */       if ((input == null) || (input.isEmpty())) {
/* 297 */         return input;
/*     */       }
/*     */       
/* 300 */       char c = input.charAt(0);
/* 301 */       char uc = Character.toUpperCase(c);
/* 302 */       if (c == uc) {
/* 303 */         return input;
/*     */       }
/* 305 */       StringBuilder sb = new StringBuilder(input);
/* 306 */       sb.setCharAt(0, uc);
/* 307 */       return sb.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class LowerCaseStrategy
/*     */     extends PropertyNamingStrategies.NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/*     */ 
/*     */ 
/*     */     public String translate(String input)
/*     */     {
/* 323 */       return input.toLowerCase();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class KebabCaseStrategy
/*     */     extends PropertyNamingStrategies.NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/*     */ 
/*     */ 
/*     */     public String translate(String input)
/*     */     {
/* 339 */       return translateLowerCaseWithSeparator(input, '-');
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class LowerDotCaseStrategy
/*     */     extends PropertyNamingStrategies.NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/*     */ 
/*     */     public String translate(String input)
/*     */     {
/* 353 */       return translateLowerCaseWithSeparator(input, '.');
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\PropertyNamingStrategies.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */