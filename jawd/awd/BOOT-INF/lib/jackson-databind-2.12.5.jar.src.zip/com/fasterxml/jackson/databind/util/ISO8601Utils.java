/*     */ package com.fasterxml.jackson.databind.util;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.ParsePosition;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ISO8601Utils
/*     */ {
/*  18 */   protected static final int DEF_8601_LEN = "yyyy-MM-ddThh:mm:ss.SSS+00:00".length();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  24 */   private static final TimeZone TIMEZONE_Z = TimeZone.getTimeZone("UTC");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String format(Date date)
/*     */   {
/*  39 */     return format(date, false, TIMEZONE_Z);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String format(Date date, boolean millis)
/*     */   {
/*  50 */     return format(date, millis, TIMEZONE_Z);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static String format(Date date, boolean millis, TimeZone tz) {
/*  55 */     return format(date, millis, tz, Locale.US);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String format(Date date, boolean millis, TimeZone tz, Locale loc)
/*     */   {
/*  69 */     Calendar calendar = new GregorianCalendar(tz, loc);
/*  70 */     calendar.setTime(date);
/*     */     
/*     */ 
/*  73 */     StringBuilder sb = new StringBuilder(30);
/*  74 */     sb.append(String.format("%04d-%02d-%02dT%02d:%02d:%02d", new Object[] {
/*     */     
/*  76 */       Integer.valueOf(calendar.get(1)), 
/*  77 */       Integer.valueOf(calendar.get(2) + 1), 
/*  78 */       Integer.valueOf(calendar.get(5)), 
/*  79 */       Integer.valueOf(calendar.get(11)), 
/*  80 */       Integer.valueOf(calendar.get(12)), 
/*  81 */       Integer.valueOf(calendar.get(13)) }));
/*     */     
/*  83 */     if (millis) {
/*  84 */       sb.append(String.format(".%03d", new Object[] { Integer.valueOf(calendar.get(14)) }));
/*     */     }
/*     */     
/*  87 */     int offset = tz.getOffset(calendar.getTimeInMillis());
/*  88 */     if (offset != 0) {
/*  89 */       int hours = Math.abs(offset / 60000 / 60);
/*  90 */       int minutes = Math.abs(offset / 60000 % 60);
/*  91 */       sb.append(String.format("%c%02d:%02d", new Object[] {
/*  92 */         Character.valueOf(offset < 0 ? 45 : '+'), 
/*  93 */         Integer.valueOf(hours), Integer.valueOf(minutes) }));
/*     */     } else {
/*  95 */       sb.append('Z');
/*     */     }
/*  97 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date parse(String date, ParsePosition pos)
/*     */     throws ParseException
/*     */   {
/* 116 */     Exception fail = null;
/*     */     try {
/* 118 */       int offset = pos.getIndex();
/*     */       
/*     */ 
/* 121 */       int year = parseInt(date, , offset);
/* 122 */       if (checkOffset(date, offset, '-')) {
/* 123 */         offset++;
/*     */       }
/*     */       
/*     */ 
/* 127 */       int month = parseInt(date, , offset);
/* 128 */       if (checkOffset(date, offset, '-')) {
/* 129 */         offset++;
/*     */       }
/*     */       
/*     */ 
/* 133 */       int day = parseInt(date, , offset);
/*     */       
/* 135 */       int hour = 0;
/* 136 */       int minutes = 0;
/* 137 */       int seconds = 0;
/* 138 */       int milliseconds = 0;
/*     */       
/*     */ 
/* 141 */       boolean hasT = checkOffset(date, offset, 'T');
/*     */       
/* 143 */       if ((!hasT) && (date.length() <= offset)) {
/* 144 */         Calendar calendar = new GregorianCalendar(year, month - 1, day);
/*     */         
/* 146 */         pos.setIndex(offset);
/* 147 */         return calendar.getTime();
/*     */       }
/*     */       
/* 150 */       if (hasT)
/*     */       {
/*     */ 
/* 153 */         offset += 2;hour = parseInt(date, ++offset, offset);
/* 154 */         if (checkOffset(date, offset, ':')) {
/* 155 */           offset++;
/*     */         }
/*     */         
/* 158 */         minutes = parseInt(date, , offset);
/* 159 */         if (checkOffset(date, offset, ':')) {
/* 160 */           offset++;
/*     */         }
/*     */         
/* 163 */         if (date.length() > offset) {
/* 164 */           char c = date.charAt(offset);
/* 165 */           if ((c != 'Z') && (c != '+') && (c != '-')) {
/* 166 */             seconds = parseInt(date, , offset);
/* 167 */             if ((seconds > 59) && (seconds < 63)) { seconds = 59;
/*     */             }
/* 169 */             if (checkOffset(date, offset, '.')) {
/* 170 */               offset++;
/* 171 */               int endOffset = indexOfNonDigit(date, offset + 1);
/* 172 */               int parseEndOffset = Math.min(endOffset, offset + 3);
/* 173 */               int fraction = parseInt(date, offset, parseEndOffset);
/*     */               
/* 175 */               switch (parseEndOffset - offset) {
/*     */               case 2: 
/* 177 */                 milliseconds = fraction * 10;
/* 178 */                 break;
/*     */               case 1: 
/* 180 */                 milliseconds = fraction * 100;
/* 181 */                 break;
/*     */               default: 
/* 183 */                 milliseconds = fraction;
/*     */               }
/* 185 */               offset = endOffset;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 192 */       if (date.length() <= offset) {
/* 193 */         throw new IllegalArgumentException("No time zone indicator");
/*     */       }
/*     */       
/* 196 */       TimeZone timezone = null;
/* 197 */       char timezoneIndicator = date.charAt(offset);
/*     */       
/* 199 */       if (timezoneIndicator == 'Z') {
/* 200 */         timezone = TIMEZONE_Z;
/* 201 */         offset++;
/* 202 */       } else if ((timezoneIndicator == '+') || (timezoneIndicator == '-')) {
/* 203 */         String timezoneOffset = date.substring(offset);
/* 204 */         offset += timezoneOffset.length();
/*     */         
/* 206 */         if (("+0000".equals(timezoneOffset)) || ("+00:00".equals(timezoneOffset))) {
/* 207 */           timezone = TIMEZONE_Z;
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 213 */           String timezoneId = "GMT" + timezoneOffset;
/*     */           
/*     */ 
/* 216 */           timezone = TimeZone.getTimeZone(timezoneId);
/*     */           
/* 218 */           String act = timezone.getID();
/* 219 */           if (!act.equals(timezoneId))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 225 */             String cleaned = act.replace(":", "");
/* 226 */             if (!cleaned.equals(timezoneId))
/*     */             {
/* 228 */               throw new IndexOutOfBoundsException("Mismatching time zone indicator: " + timezoneId + " given, resolves to " + timezone.getID());
/*     */             }
/*     */           }
/*     */         }
/*     */       } else {
/* 233 */         throw new IndexOutOfBoundsException("Invalid time zone indicator '" + timezoneIndicator + "'");
/*     */       }
/*     */       
/* 236 */       Calendar calendar = new GregorianCalendar(timezone);
/* 237 */       calendar.setLenient(false);
/* 238 */       calendar.set(1, year);
/* 239 */       calendar.set(2, month - 1);
/* 240 */       calendar.set(5, day);
/* 241 */       calendar.set(11, hour);
/* 242 */       calendar.set(12, minutes);
/* 243 */       calendar.set(13, seconds);
/* 244 */       calendar.set(14, milliseconds);
/*     */       
/* 246 */       pos.setIndex(offset);
/* 247 */       return calendar.getTime();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 251 */       fail = e;
/*     */       
/* 253 */       String input = '"' + date + '"';
/* 254 */       String msg = fail.getMessage();
/* 255 */       if ((msg == null) || (msg.isEmpty())) {
/* 256 */         msg = "(" + fail.getClass().getName() + ")";
/*     */       }
/* 258 */       ParseException ex = new ParseException("Failed to parse date " + input + ": " + msg, pos.getIndex());
/* 259 */       ex.initCause(fail);
/* 260 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean checkOffset(String value, int offset, char expected)
/*     */   {
/* 272 */     return (offset < value.length()) && (value.charAt(offset) == expected);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int parseInt(String value, int beginIndex, int endIndex)
/*     */     throws NumberFormatException
/*     */   {
/* 285 */     if ((beginIndex < 0) || (endIndex > value.length()) || (beginIndex > endIndex)) {
/* 286 */       throw new NumberFormatException(value);
/*     */     }
/*     */     
/* 289 */     int i = beginIndex;
/* 290 */     int result = 0;
/*     */     
/* 292 */     if (i < endIndex) {
/* 293 */       int digit = Character.digit(value.charAt(i++), 10);
/* 294 */       if (digit < 0) {
/* 295 */         throw new NumberFormatException("Invalid number: " + value.substring(beginIndex, endIndex));
/*     */       }
/* 297 */       result = -digit;
/*     */     }
/* 299 */     while (i < endIndex) {
/* 300 */       int digit = Character.digit(value.charAt(i++), 10);
/* 301 */       if (digit < 0) {
/* 302 */         throw new NumberFormatException("Invalid number: " + value.substring(beginIndex, endIndex));
/*     */       }
/* 304 */       result *= 10;
/* 305 */       result -= digit;
/*     */     }
/* 307 */     return -result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static int indexOfNonDigit(String string, int offset)
/*     */   {
/* 314 */     for (int i = offset; i < string.length(); i++) {
/* 315 */       char c = string.charAt(i);
/* 316 */       if ((c < '0') || (c > '9')) return i;
/*     */     }
/* 318 */     return string.length();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\util\ISO8601Utils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */