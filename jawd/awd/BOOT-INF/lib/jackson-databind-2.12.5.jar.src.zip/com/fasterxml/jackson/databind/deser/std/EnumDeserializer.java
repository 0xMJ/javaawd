/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Feature;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.CompactStringObjectMap;
/*     */ import com.fasterxml.jackson.databind.util.EnumResolver;
/*     */ import java.io.IOException;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class EnumDeserializer
/*     */   extends StdScalarDeserializer<Object>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected Object[] _enumsByIndex;
/*     */   private final Enum<?> _enumDefaultValue;
/*     */   protected final CompactStringObjectMap _lookupByName;
/*     */   protected CompactStringObjectMap _lookupByToString;
/*     */   protected final Boolean _caseInsensitive;
/*     */   
/*     */   public EnumDeserializer(EnumResolver byNameResolver, Boolean caseInsensitive)
/*     */   {
/*  61 */     super(byNameResolver.getEnumClass());
/*  62 */     this._lookupByName = byNameResolver.constructLookup();
/*  63 */     this._enumsByIndex = byNameResolver.getRawEnums();
/*  64 */     this._enumDefaultValue = byNameResolver.getDefaultValue();
/*  65 */     this._caseInsensitive = caseInsensitive;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected EnumDeserializer(EnumDeserializer base, Boolean caseInsensitive)
/*     */   {
/*  73 */     super(base);
/*  74 */     this._lookupByName = base._lookupByName;
/*  75 */     this._enumsByIndex = base._enumsByIndex;
/*  76 */     this._enumDefaultValue = base._enumDefaultValue;
/*  77 */     this._caseInsensitive = caseInsensitive;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public EnumDeserializer(EnumResolver byNameResolver)
/*     */   {
/*  85 */     this(byNameResolver, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static JsonDeserializer<?> deserializerForCreator(DeserializationConfig config, Class<?> enumClass, AnnotatedMethod factory)
/*     */   {
/*  94 */     return deserializerForCreator(config, enumClass, factory, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonDeserializer<?> deserializerForCreator(DeserializationConfig config, Class<?> enumClass, AnnotatedMethod factory, ValueInstantiator valueInstantiator, SettableBeanProperty[] creatorProps)
/*     */   {
/* 109 */     if (config.canOverrideAccessModifiers()) {
/* 110 */       ClassUtil.checkAndFixAccess(factory.getMember(), config
/* 111 */         .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */     }
/* 113 */     return new FactoryBasedEnumDeserializer(enumClass, factory, factory
/* 114 */       .getParameterType(0), valueInstantiator, creatorProps);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonDeserializer<?> deserializerForNoArgsCreator(DeserializationConfig config, Class<?> enumClass, AnnotatedMethod factory)
/*     */   {
/* 129 */     if (config.canOverrideAccessModifiers()) {
/* 130 */       ClassUtil.checkAndFixAccess(factory.getMember(), config
/* 131 */         .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */     }
/* 133 */     return new FactoryBasedEnumDeserializer(enumClass, factory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public EnumDeserializer withResolved(Boolean caseInsensitive)
/*     */   {
/* 140 */     if (Objects.equals(this._caseInsensitive, caseInsensitive)) {
/* 141 */       return this;
/*     */     }
/* 143 */     return new EnumDeserializer(this, caseInsensitive);
/*     */   }
/*     */   
/*     */ 
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 150 */     Boolean caseInsensitive = findFormatFeature(ctxt, property, handledType(), JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
/*     */     
/* 152 */     if (caseInsensitive == null) {
/* 153 */       caseInsensitive = this._caseInsensitive;
/*     */     }
/* 155 */     return withResolved(caseInsensitive);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCachable()
/*     */   {
/* 169 */     return true;
/*     */   }
/*     */   
/*     */   public LogicalType logicalType() {
/* 173 */     return LogicalType.Enum;
/*     */   }
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException
/*     */   {
/* 178 */     return this._enumDefaultValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt)
/*     */     throws IOException
/*     */   {
/* 187 */     if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 188 */       return _fromString(p, ctxt, p.getText());
/*     */     }
/*     */     
/*     */ 
/* 192 */     if (p.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/* 193 */       return _fromInteger(p, ctxt, p.getIntValue());
/*     */     }
/*     */     
/*     */ 
/* 197 */     if (p.isExpectedStartObjectToken()) {
/* 198 */       return _fromString(p, ctxt, ctxt
/* 199 */         .extractScalarFromObject(p, this, this._valueClass));
/*     */     }
/* 201 */     return _deserializeOther(p, ctxt);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Object _fromString(JsonParser p, DeserializationContext ctxt, String text)
/*     */     throws IOException
/*     */   {
/* 209 */     CompactStringObjectMap lookup = ctxt.isEnabled(DeserializationFeature.READ_ENUMS_USING_TO_STRING) ? _getToStringLookup(ctxt) : this._lookupByName;
/* 210 */     Object result = lookup.find(text);
/* 211 */     if (result == null) {
/* 212 */       String trimmed = text.trim();
/* 213 */       if ((trimmed == text) || ((result = lookup.find(trimmed)) == null)) {
/* 214 */         return _deserializeAltString(p, ctxt, lookup, trimmed);
/*     */       }
/*     */     }
/* 217 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object _fromInteger(JsonParser p, DeserializationContext ctxt, int index)
/*     */     throws IOException
/*     */   {
/* 224 */     CoercionAction act = ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.Integer);
/*     */     
/*     */ 
/*     */ 
/* 228 */     if (act == CoercionAction.Fail) {
/* 229 */       if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS)) {
/* 230 */         return ctxt.handleWeirdNumberValue(_enumClass(), Integer.valueOf(index), "not allowed to deserialize Enum value out of number: disable DeserializationConfig.DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS to allow", new Object[0]);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 235 */       _checkCoercionFail(ctxt, act, handledType(), Integer.valueOf(index), "Integer value (" + index + ")");
/*     */     }
/*     */     
/* 238 */     switch (act) {
/*     */     case AsNull: 
/* 240 */       return null;
/*     */     case AsEmpty: 
/* 242 */       return getEmptyValue(ctxt);
/*     */     }
/*     */     
/*     */     
/* 246 */     if ((index >= 0) && (index < this._enumsByIndex.length)) {
/* 247 */       return this._enumsByIndex[index];
/*     */     }
/* 249 */     if ((this._enumDefaultValue != null) && 
/* 250 */       (ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE))) {
/* 251 */       return this._enumDefaultValue;
/*     */     }
/* 253 */     if (!ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL)) {
/* 254 */       return ctxt.handleWeirdNumberValue(_enumClass(), Integer.valueOf(index), "index value outside legal index range [0..%s]", new Object[] {
/*     */       
/* 256 */         Integer.valueOf(this._enumsByIndex.length - 1) });
/*     */     }
/* 258 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Object _deserializeAltString(JsonParser p, DeserializationContext ctxt, CompactStringObjectMap lookup, String nameOrig)
/*     */     throws IOException
/*     */   {
/* 274 */     String name = nameOrig.trim();
/* 275 */     if (name.isEmpty())
/*     */     {
/*     */ 
/* 278 */       if ((this._enumDefaultValue != null) && 
/* 279 */         (ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE))) {
/* 280 */         return this._enumDefaultValue;
/*     */       }
/* 282 */       if (ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL)) {
/* 283 */         return null;
/*     */       }
/*     */       
/*     */       CoercionAction act;
/* 287 */       if (nameOrig.isEmpty()) {
/* 288 */         CoercionAction act = _findCoercionFromEmptyString(ctxt);
/* 289 */         act = _checkCoercionFail(ctxt, act, handledType(), nameOrig, "empty String (\"\")");
/*     */       }
/*     */       else {
/* 292 */         act = _findCoercionFromBlankString(ctxt);
/* 293 */         act = _checkCoercionFail(ctxt, act, handledType(), nameOrig, "blank String (all whitespace)");
/*     */       }
/*     */       
/* 296 */       switch (act) {
/*     */       case AsEmpty: 
/*     */       case TryConvert: 
/* 299 */         return getEmptyValue(ctxt);
/*     */       }
/*     */       
/*     */       
/* 303 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 307 */     if (Boolean.TRUE.equals(this._caseInsensitive)) {
/* 308 */       Object match = lookup.findCaseInsensitive(name);
/* 309 */       if (match != null) {
/* 310 */         return match;
/*     */       }
/* 312 */     } else if (!ctxt.isEnabled(DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS))
/*     */     {
/* 314 */       char c = name.charAt(0);
/* 315 */       if ((c >= '0') && (c <= '9')) {
/*     */         try {
/* 317 */           int index = Integer.parseInt(name);
/* 318 */           if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 319 */             return ctxt.handleWeirdStringValue(_enumClass(), name, "value looks like quoted Enum index, but `MapperFeature.ALLOW_COERCION_OF_SCALARS` prevents use", new Object[0]);
/*     */           }
/*     */           
/*     */ 
/* 323 */           if ((index >= 0) && (index < this._enumsByIndex.length)) {
/* 324 */             return this._enumsByIndex[index];
/*     */           }
/*     */         }
/*     */         catch (NumberFormatException localNumberFormatException) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 332 */     if ((this._enumDefaultValue != null) && 
/* 333 */       (ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE))) {
/* 334 */       return this._enumDefaultValue;
/*     */     }
/* 336 */     if (ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL)) {
/* 337 */       return null;
/*     */     }
/* 339 */     return ctxt.handleWeirdStringValue(_enumClass(), name, "not one of the values accepted for Enum class: %s", new Object[] {lookup
/* 340 */       .keys() });
/*     */   }
/*     */   
/*     */   protected Object _deserializeOther(JsonParser p, DeserializationContext ctxt)
/*     */     throws IOException
/*     */   {
/* 346 */     if (p.hasToken(JsonToken.START_ARRAY)) {
/* 347 */       return _deserializeFromArray(p, ctxt);
/*     */     }
/* 349 */     return ctxt.handleUnexpectedToken(_enumClass(), p);
/*     */   }
/*     */   
/*     */   protected Class<?> _enumClass() {
/* 353 */     return handledType();
/*     */   }
/*     */   
/*     */   protected CompactStringObjectMap _getToStringLookup(DeserializationContext ctxt)
/*     */   {
/* 358 */     CompactStringObjectMap lookup = this._lookupByToString;
/*     */     
/*     */ 
/* 361 */     if (lookup == null) {
/* 362 */       synchronized (this)
/*     */       {
/* 364 */         lookup = EnumResolver.constructUsingToString(ctxt.getConfig(), _enumClass()).constructLookup();
/*     */       }
/* 366 */       this._lookupByToString = lookup;
/*     */     }
/* 368 */     return lookup;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\std\EnumDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */