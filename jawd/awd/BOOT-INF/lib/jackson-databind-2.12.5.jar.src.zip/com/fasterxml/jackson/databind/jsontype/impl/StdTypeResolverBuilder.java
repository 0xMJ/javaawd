/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.annotation.NoClass;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator.Validity;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdTypeResolverBuilder
/*     */   implements TypeResolverBuilder<StdTypeResolverBuilder>
/*     */ {
/*     */   protected JsonTypeInfo.Id _idType;
/*     */   protected JsonTypeInfo.As _includeAs;
/*     */   protected String _typeProperty;
/*  33 */   protected boolean _typeIdVisible = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> _defaultImpl;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TypeIdResolver _customIdResolver;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StdTypeResolverBuilder() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected StdTypeResolverBuilder(JsonTypeInfo.Id idType, JsonTypeInfo.As idAs, String propName)
/*     */   {
/*  58 */     this._idType = idType;
/*  59 */     this._includeAs = idAs;
/*  60 */     this._typeProperty = propName;
/*     */   }
/*     */   
/*     */   public static StdTypeResolverBuilder noTypeInfoBuilder() {
/*  64 */     return new StdTypeResolverBuilder().init(JsonTypeInfo.Id.NONE, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public StdTypeResolverBuilder init(JsonTypeInfo.Id idType, TypeIdResolver idRes)
/*     */   {
/*  71 */     if (idType == null) {
/*  72 */       throw new IllegalArgumentException("idType cannot be null");
/*     */     }
/*  74 */     this._idType = idType;
/*  75 */     this._customIdResolver = idRes;
/*     */     
/*  77 */     this._typeProperty = idType.getDefaultPropertyName();
/*  78 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TypeSerializer buildTypeSerializer(SerializationConfig config, JavaType baseType, Collection<NamedType> subtypes)
/*     */   {
/*  85 */     if (this._idType == JsonTypeInfo.Id.NONE) { return null;
/*     */     }
/*     */     
/*  88 */     if (baseType.isPrimitive())
/*     */     {
/*  90 */       if (!allowPrimitiveTypes(config, baseType)) {
/*  91 */         return null;
/*     */       }
/*     */     }
/*     */     
/*  95 */     TypeIdResolver idRes = idResolver(config, baseType, subTypeValidator(config), subtypes, true, false);
/*     */     
/*     */ 
/*  98 */     if (this._idType == JsonTypeInfo.Id.DEDUCTION)
/*     */     {
/* 100 */       return new AsExistingPropertyTypeSerializer(idRes, null, this._typeProperty);
/*     */     }
/*     */     
/* 103 */     switch (this._includeAs) {
/*     */     case WRAPPER_ARRAY: 
/* 105 */       return new AsArrayTypeSerializer(idRes, null);
/*     */     case PROPERTY: 
/* 107 */       return new AsPropertyTypeSerializer(idRes, null, this._typeProperty);
/*     */     case WRAPPER_OBJECT: 
/* 109 */       return new AsWrapperTypeSerializer(idRes, null);
/*     */     case EXTERNAL_PROPERTY: 
/* 111 */       return new AsExternalTypeSerializer(idRes, null, this._typeProperty);
/*     */     
/*     */     case EXISTING_PROPERTY: 
/* 114 */       return new AsExistingPropertyTypeSerializer(idRes, null, this._typeProperty);
/*     */     }
/* 116 */     throw new IllegalStateException("Do not know how to construct standard type serializer for inclusion type: " + this._includeAs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeDeserializer buildTypeDeserializer(DeserializationConfig config, JavaType baseType, Collection<NamedType> subtypes)
/*     */   {
/* 129 */     if (this._idType == JsonTypeInfo.Id.NONE) { return null;
/*     */     }
/*     */     
/* 132 */     if (baseType.isPrimitive())
/*     */     {
/* 134 */       if (!allowPrimitiveTypes(config, baseType)) {
/* 135 */         return null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 141 */     PolymorphicTypeValidator subTypeValidator = verifyBaseTypeValidity(config, baseType);
/*     */     
/* 143 */     TypeIdResolver idRes = idResolver(config, baseType, subTypeValidator, subtypes, false, true);
/*     */     
/* 145 */     JavaType defaultImpl = defineDefaultImpl(config, baseType);
/*     */     
/* 147 */     if (this._idType == JsonTypeInfo.Id.DEDUCTION)
/*     */     {
/* 149 */       return new AsDeductionTypeDeserializer(baseType, idRes, defaultImpl, config, subtypes);
/*     */     }
/*     */     
/*     */ 
/* 153 */     switch (this._includeAs) {
/*     */     case WRAPPER_ARRAY: 
/* 155 */       return new AsArrayTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl);
/*     */     
/*     */     case PROPERTY: 
/*     */     case EXISTING_PROPERTY: 
/* 159 */       return new AsPropertyTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl, this._includeAs);
/*     */     
/*     */     case WRAPPER_OBJECT: 
/* 162 */       return new AsWrapperTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl);
/*     */     
/*     */     case EXTERNAL_PROPERTY: 
/* 165 */       return new AsExternalTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl);
/*     */     }
/*     */     
/* 168 */     throw new IllegalStateException("Do not know how to construct standard type serializer for inclusion type: " + this._includeAs);
/*     */   }
/*     */   
/*     */   protected JavaType defineDefaultImpl(DeserializationConfig config, JavaType baseType) { JavaType defaultImpl;
/*     */     JavaType defaultImpl;
/* 173 */     if (this._defaultImpl == null) { JavaType defaultImpl;
/* 174 */       if ((config.isEnabled(MapperFeature.USE_BASE_TYPE_AS_DEFAULT_IMPL)) && (!baseType.isAbstract())) {
/* 175 */         defaultImpl = baseType;
/*     */       } else {
/* 177 */         defaultImpl = null;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*     */       JavaType defaultImpl;
/*     */       
/*     */ 
/*     */ 
/* 186 */       if ((this._defaultImpl == Void.class) || (this._defaultImpl == NoClass.class))
/*     */       {
/* 188 */         defaultImpl = config.getTypeFactory().constructType(this._defaultImpl);
/*     */       } else { JavaType defaultImpl;
/* 190 */         if (baseType.hasRawClass(this._defaultImpl)) {
/* 191 */           defaultImpl = baseType; } else { JavaType defaultImpl;
/* 192 */           if (baseType.isTypeOrSuperTypeOf(this._defaultImpl))
/*     */           {
/*     */ 
/* 195 */             defaultImpl = config.getTypeFactory().constructSpecializedType(baseType, this._defaultImpl);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */             defaultImpl = null; }
/*     */         }
/*     */       }
/*     */     }
/* 211 */     return defaultImpl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StdTypeResolverBuilder inclusion(JsonTypeInfo.As includeAs)
/*     */   {
/* 222 */     if (includeAs == null) {
/* 223 */       throw new IllegalArgumentException("includeAs cannot be null");
/*     */     }
/* 225 */     this._includeAs = includeAs;
/* 226 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StdTypeResolverBuilder typeProperty(String typeIdPropName)
/*     */   {
/* 236 */     if ((typeIdPropName == null) || (typeIdPropName.isEmpty())) {
/* 237 */       typeIdPropName = this._idType.getDefaultPropertyName();
/*     */     }
/* 239 */     this._typeProperty = typeIdPropName;
/* 240 */     return this;
/*     */   }
/*     */   
/*     */   public StdTypeResolverBuilder defaultImpl(Class<?> defaultImpl)
/*     */   {
/* 245 */     this._defaultImpl = defaultImpl;
/* 246 */     return this;
/*     */   }
/*     */   
/*     */   public StdTypeResolverBuilder typeIdVisibility(boolean isVisible)
/*     */   {
/* 251 */     this._typeIdVisible = isVisible;
/* 252 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 261 */   public Class<?> getDefaultImpl() { return this._defaultImpl; }
/*     */   
/* 263 */   public String getTypeProperty() { return this._typeProperty; }
/* 264 */   public boolean isTypeIdVisible() { return this._typeIdVisible; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TypeIdResolver idResolver(MapperConfig<?> config, JavaType baseType, PolymorphicTypeValidator subtypeValidator, Collection<NamedType> subtypes, boolean forSer, boolean forDeser)
/*     */   {
/* 282 */     if (this._customIdResolver != null) return this._customIdResolver;
/* 283 */     if (this._idType == null) throw new IllegalStateException("Cannot build, 'init()' not yet called");
/* 284 */     switch (this._idType) {
/*     */     case DEDUCTION: 
/*     */     case CLASS: 
/* 287 */       return ClassNameIdResolver.construct(baseType, config, subtypeValidator);
/*     */     case MINIMAL_CLASS: 
/* 289 */       return MinimalClassNameIdResolver.construct(baseType, config, subtypeValidator);
/*     */     case NAME: 
/* 291 */       return TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);
/*     */     case NONE: 
/* 293 */       return null;
/*     */     }
/*     */     
/* 296 */     throw new IllegalStateException("Do not know how to construct standard type id resolver for idType: " + this._idType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PolymorphicTypeValidator subTypeValidator(MapperConfig<?> config)
/*     */   {
/* 315 */     return config.getPolymorphicTypeValidator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PolymorphicTypeValidator verifyBaseTypeValidity(MapperConfig<?> config, JavaType baseType)
/*     */   {
/* 328 */     PolymorphicTypeValidator ptv = subTypeValidator(config);
/* 329 */     if ((this._idType == JsonTypeInfo.Id.CLASS) || (this._idType == JsonTypeInfo.Id.MINIMAL_CLASS)) {
/* 330 */       PolymorphicTypeValidator.Validity validity = ptv.validateBaseType(config, baseType);
/*     */       
/* 332 */       if (validity == PolymorphicTypeValidator.Validity.DENIED) {
/* 333 */         return reportInvalidBaseType(config, baseType, ptv);
/*     */       }
/*     */       
/* 336 */       if (validity == PolymorphicTypeValidator.Validity.ALLOWED) {
/* 337 */         return LaissezFaireSubTypeValidator.instance;
/*     */       }
/*     */     }
/*     */     
/* 341 */     return ptv;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PolymorphicTypeValidator reportInvalidBaseType(MapperConfig<?> config, JavaType baseType, PolymorphicTypeValidator ptv)
/*     */   {
/* 350 */     throw new IllegalArgumentException(String.format("Configured `PolymorphicTypeValidator` (of type %s) denied resolution of all subtypes of base type %s", new Object[] {
/*     */     
/* 352 */       ClassUtil.classNameOf(ptv), ClassUtil.classNameOf(baseType.getRawClass()) }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean allowPrimitiveTypes(MapperConfig<?> config, JavaType baseType)
/*     */   {
/* 380 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\jsontype\impl\StdTypeResolverBuilder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */