/*      */ package com.fasterxml.jackson.databind.deser;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties.Value;
/*      */ import com.fasterxml.jackson.databind.AbstractTypeResolver;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector.ReferenceProperty;
/*      */ import com.fasterxml.jackson.databind.BeanDescription;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.BeanProperty.Std;
/*      */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder.Value;
/*      */ import com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ErrorThrowingDeserializer;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedField;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*      */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*      */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.SimpleBeanPropertyDefinition;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ 
/*      */ public class BeanDeserializerFactory extends BasicDeserializerFactory implements java.io.Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   40 */   private static final Class<?>[] INIT_CAUSE_PARAMS = { Throwable.class };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   52 */   public static final BeanDeserializerFactory instance = new BeanDeserializerFactory(new DeserializerFactoryConfig());
/*      */   
/*      */   public BeanDeserializerFactory(DeserializerFactoryConfig config)
/*      */   {
/*   56 */     super(config);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DeserializerFactory withConfig(DeserializerFactoryConfig config)
/*      */   {
/*   67 */     if (this._factoryConfig == config) {
/*   68 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   76 */     ClassUtil.verifyMustOverride(BeanDeserializerFactory.class, this, "withConfig");
/*   77 */     return new BeanDeserializerFactory(config);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<Object> createBeanDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/*   97 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*   99 */     JsonDeserializer<?> deser = _findCustomBeanDeserializer(type, config, beanDesc);
/*  100 */     if (deser != null)
/*      */     {
/*  102 */       if (this._factoryConfig.hasDeserializerModifiers()) {
/*  103 */         for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  104 */           deser = mod.modifyDeserializer(ctxt.getConfig(), beanDesc, deser);
/*      */         }
/*      */       }
/*  107 */       return deser;
/*      */     }
/*      */     
/*      */ 
/*  111 */     if (type.isThrowable()) {
/*  112 */       return buildThrowableDeserializer(ctxt, type, beanDesc);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  119 */     if ((type.isAbstract()) && (!type.isPrimitive()) && (!type.isEnumType()))
/*      */     {
/*  121 */       JavaType concreteType = materializeAbstractType(ctxt, type, beanDesc);
/*  122 */       if (concreteType != null)
/*      */       {
/*      */ 
/*  125 */         beanDesc = config.introspect(concreteType);
/*  126 */         return buildBeanDeserializer(ctxt, concreteType, beanDesc);
/*      */       }
/*      */     }
/*      */     
/*  130 */     deser = findStdDeserializer(ctxt, type, beanDesc);
/*  131 */     if (deser != null) {
/*  132 */       return deser;
/*      */     }
/*      */     
/*      */ 
/*  136 */     if (!isPotentialBeanType(type.getRawClass())) {
/*  137 */       return null;
/*      */     }
/*      */     
/*  140 */     _validateSubType(ctxt, type, beanDesc);
/*      */     
/*      */ 
/*      */ 
/*  144 */     deser = _findUnsupportedTypeDeserializer(ctxt, type, beanDesc);
/*  145 */     if (deser != null) {
/*  146 */       return deser;
/*      */     }
/*      */     
/*      */ 
/*  150 */     return buildBeanDeserializer(ctxt, type, beanDesc);
/*      */   }
/*      */   
/*      */ 
/*      */   public JsonDeserializer<Object> createBuilderBasedDeserializer(DeserializationContext ctxt, JavaType valueType, BeanDescription valueBeanDesc, Class<?> builderClass)
/*      */     throws JsonMappingException
/*      */   {
/*      */     JavaType builderType;
/*      */     
/*      */     JavaType builderType;
/*      */     
/*  161 */     if (ctxt.isEnabled(MapperFeature.INFER_BUILDER_TYPE_BINDINGS)) {
/*  162 */       builderType = ctxt.getTypeFactory().constructParametricType(builderClass, valueType.getBindings());
/*      */     } else {
/*  164 */       builderType = ctxt.constructType(builderClass);
/*      */     }
/*  166 */     BeanDescription builderDesc = ctxt.getConfig().introspectForBuilder(builderType, valueBeanDesc);
/*      */     
/*      */ 
/*  169 */     return buildBuilderBasedDeserializer(ctxt, valueType, builderDesc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<?> findStdDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/*  182 */     JsonDeserializer<?> deser = findDefaultDeserializer(ctxt, type, beanDesc);
/*      */     
/*  184 */     if ((deser != null) && 
/*  185 */       (this._factoryConfig.hasDeserializerModifiers())) {
/*  186 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  187 */         deser = mod.modifyDeserializer(ctxt.getConfig(), beanDesc, deser);
/*      */       }
/*      */     }
/*      */     
/*  191 */     return deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> _findUnsupportedTypeDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/*  209 */     String errorMsg = com.fasterxml.jackson.databind.util.BeanUtil.checkUnsupportedType(type);
/*  210 */     if (errorMsg != null)
/*      */     {
/*      */ 
/*  213 */       if (ctxt.getConfig().findMixInClassFor(type.getRawClass()) == null) {
/*  214 */         return new com.fasterxml.jackson.databind.deser.impl.UnsupportedTypeDeserializer(type, errorMsg);
/*      */       }
/*      */     }
/*  217 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected JavaType materializeAbstractType(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/*  225 */     for (AbstractTypeResolver r : this._factoryConfig.abstractTypeResolvers()) {
/*  226 */       JavaType concrete = r.resolveAbstractType(ctxt.getConfig(), beanDesc);
/*  227 */       if (concrete != null) {
/*  228 */         return concrete;
/*      */       }
/*      */     }
/*  231 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<Object> buildBeanDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/*      */     try
/*      */     {
/*  261 */       valueInstantiator = findValueInstantiator(ctxt, beanDesc);
/*      */     } catch (NoClassDefFoundError error) { ValueInstantiator valueInstantiator;
/*  263 */       return new ErrorThrowingDeserializer(error);
/*      */ 
/*      */     }
/*      */     catch (IllegalArgumentException e0)
/*      */     {
/*  268 */       JsonMappingException e = com.fasterxml.jackson.databind.exc.InvalidDefinitionException.from(ctxt.getParser(), 
/*  269 */         ClassUtil.exceptionMessage(e0), beanDesc, null);
/*      */       
/*  271 */       e.initCause(e0);
/*  272 */       throw e; }
/*      */     ValueInstantiator valueInstantiator;
/*  274 */     BeanDeserializerBuilder builder = constructBeanDeserializerBuilder(ctxt, beanDesc);
/*  275 */     builder.setValueInstantiator(valueInstantiator);
/*      */     
/*  277 */     addBeanProps(ctxt, beanDesc, builder);
/*  278 */     addObjectIdReader(ctxt, beanDesc, builder);
/*      */     
/*      */ 
/*  281 */     addBackReferenceProperties(ctxt, beanDesc, builder);
/*  282 */     addInjectables(ctxt, beanDesc, builder);
/*      */     
/*  284 */     DeserializationConfig config = ctxt.getConfig();
/*  285 */     Iterator localIterator; if (this._factoryConfig.hasDeserializerModifiers())
/*  286 */       for (localIterator = this._factoryConfig.deserializerModifiers().iterator(); localIterator.hasNext();) { mod = (BeanDeserializerModifier)localIterator.next();
/*  287 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*      */       }
/*      */     BeanDeserializerModifier mod;
/*      */     Object deserializer;
/*      */     Object deserializer;
/*  292 */     if ((type.isAbstract()) && (!valueInstantiator.canInstantiate())) {
/*  293 */       deserializer = builder.buildAbstract();
/*      */     } else {
/*  295 */       deserializer = builder.build();
/*      */     }
/*      */     
/*      */ 
/*  299 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  300 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  301 */         deserializer = mod.modifyDeserializer(config, beanDesc, (JsonDeserializer)deserializer);
/*      */       }
/*      */     }
/*  304 */     return (JsonDeserializer<Object>)deserializer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> buildBuilderBasedDeserializer(DeserializationContext ctxt, JavaType valueType, BeanDescription builderDesc)
/*      */     throws JsonMappingException
/*      */   {
/*      */     try
/*      */     {
/*  322 */       valueInstantiator = findValueInstantiator(ctxt, builderDesc);
/*      */     } catch (NoClassDefFoundError error) { ValueInstantiator valueInstantiator;
/*  324 */       return new ErrorThrowingDeserializer(error);
/*      */ 
/*      */     }
/*      */     catch (IllegalArgumentException e)
/*      */     {
/*  329 */       throw com.fasterxml.jackson.databind.exc.InvalidDefinitionException.from(ctxt.getParser(), 
/*  330 */         ClassUtil.exceptionMessage(e), builderDesc, null);
/*      */     }
/*      */     ValueInstantiator valueInstantiator;
/*  333 */     DeserializationConfig config = ctxt.getConfig();
/*  334 */     BeanDeserializerBuilder builder = constructBeanDeserializerBuilder(ctxt, builderDesc);
/*  335 */     builder.setValueInstantiator(valueInstantiator);
/*      */     
/*  337 */     addBeanProps(ctxt, builderDesc, builder);
/*  338 */     addObjectIdReader(ctxt, builderDesc, builder);
/*      */     
/*      */ 
/*  341 */     addBackReferenceProperties(ctxt, builderDesc, builder);
/*  342 */     addInjectables(ctxt, builderDesc, builder);
/*      */     
/*  344 */     JsonPOJOBuilder.Value builderConfig = builderDesc.findPOJOBuilderConfig();
/*  345 */     String buildMethodName = builderConfig == null ? "build" : builderConfig.buildMethodName;
/*      */     
/*      */ 
/*      */ 
/*  349 */     AnnotatedMethod buildMethod = builderDesc.findMethod(buildMethodName, null);
/*  350 */     if ((buildMethod != null) && 
/*  351 */       (config.canOverrideAccessModifiers())) {
/*  352 */       ClassUtil.checkAndFixAccess(buildMethod.getMember(), config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*      */     }
/*      */     
/*  355 */     builder.setPOJOBuilder(buildMethod, builderConfig);
/*      */     Iterator localIterator;
/*  357 */     if (this._factoryConfig.hasDeserializerModifiers())
/*  358 */       for (localIterator = this._factoryConfig.deserializerModifiers().iterator(); localIterator.hasNext();) { mod = (BeanDeserializerModifier)localIterator.next();
/*  359 */         builder = mod.updateBuilder(config, builderDesc, builder);
/*      */       }
/*      */     BeanDeserializerModifier mod;
/*  362 */     Object deserializer = builder.buildBuilderBased(valueType, buildMethodName);
/*      */     
/*      */ 
/*      */ 
/*  366 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  367 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  368 */         deserializer = mod.modifyDeserializer(config, builderDesc, (JsonDeserializer)deserializer);
/*      */       }
/*      */     }
/*  371 */     return (JsonDeserializer<Object>)deserializer;
/*      */   }
/*      */   
/*      */ 
/*      */   protected void addObjectIdReader(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder)
/*      */     throws JsonMappingException
/*      */   {
/*  378 */     ObjectIdInfo objectIdInfo = beanDesc.getObjectIdInfo();
/*  379 */     if (objectIdInfo == null) {
/*  380 */       return;
/*      */     }
/*  382 */     Class<?> implClass = objectIdInfo.getGeneratorType();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  387 */     com.fasterxml.jackson.annotation.ObjectIdResolver resolver = ctxt.objectIdResolverInstance(beanDesc.getClassInfo(), objectIdInfo);
/*      */     com.fasterxml.jackson.annotation.ObjectIdGenerator<?> gen;
/*      */     JavaType idType;
/*  390 */     SettableBeanProperty idProp; com.fasterxml.jackson.annotation.ObjectIdGenerator<?> gen; if (implClass == com.fasterxml.jackson.annotation.ObjectIdGenerators.PropertyGenerator.class) {
/*  391 */       PropertyName propName = objectIdInfo.getPropertyName();
/*  392 */       SettableBeanProperty idProp = builder.findProperty(propName);
/*  393 */       if (idProp == null) {
/*  394 */         throw new IllegalArgumentException(String.format("Invalid Object Id definition for %s: cannot find property with name %s", new Object[] {
/*      */         
/*  396 */           ClassUtil.getTypeDescription(beanDesc.getType()), 
/*  397 */           ClassUtil.name(propName) }));
/*      */       }
/*  399 */       JavaType idType = idProp.getType();
/*  400 */       gen = new com.fasterxml.jackson.databind.deser.impl.PropertyBasedObjectIdGenerator(objectIdInfo.getScope());
/*      */     } else {
/*  402 */       JavaType type = ctxt.constructType(implClass);
/*  403 */       idType = ctxt.getTypeFactory().findTypeParameters(type, com.fasterxml.jackson.annotation.ObjectIdGenerator.class)[0];
/*  404 */       idProp = null;
/*  405 */       gen = ctxt.objectIdGeneratorInstance(beanDesc.getClassInfo(), objectIdInfo);
/*      */     }
/*      */     
/*  408 */     JsonDeserializer<?> deser = ctxt.findRootValueDeserializer(idType);
/*  409 */     builder.setObjectIdReader(com.fasterxml.jackson.databind.deser.impl.ObjectIdReader.construct(idType, objectIdInfo
/*  410 */       .getPropertyName(), gen, deser, idProp, resolver));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<Object> buildThrowableDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/*  418 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*  420 */     BeanDeserializerBuilder builder = constructBeanDeserializerBuilder(ctxt, beanDesc);
/*  421 */     builder.setValueInstantiator(findValueInstantiator(ctxt, beanDesc));
/*      */     
/*  423 */     addBeanProps(ctxt, beanDesc, builder);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  428 */     AnnotatedMethod am = beanDesc.findMethod("initCause", INIT_CAUSE_PARAMS);
/*  429 */     SimpleBeanPropertyDefinition propDef; if (am != null) {
/*  430 */       propDef = SimpleBeanPropertyDefinition.construct(ctxt.getConfig(), am, new PropertyName("cause"));
/*      */       
/*  432 */       SettableBeanProperty prop = constructSettableProperty(ctxt, beanDesc, propDef, am
/*  433 */         .getParameterType(0));
/*  434 */       if (prop != null)
/*      */       {
/*      */ 
/*  437 */         builder.addOrReplaceProperty(prop, true);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  442 */     builder.addIgnorable("localizedMessage");
/*      */     
/*  444 */     builder.addIgnorable("suppressed");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  451 */     if (this._factoryConfig.hasDeserializerModifiers())
/*  452 */       for (propDef = this._factoryConfig.deserializerModifiers().iterator(); propDef.hasNext();) { mod = (BeanDeserializerModifier)propDef.next();
/*  453 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*      */       }
/*      */     BeanDeserializerModifier mod;
/*  456 */     JsonDeserializer<?> deserializer = builder.build();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  461 */     if ((deserializer instanceof BeanDeserializer)) {
/*  462 */       deserializer = new com.fasterxml.jackson.databind.deser.std.ThrowableDeserializer((BeanDeserializer)deserializer);
/*      */     }
/*      */     
/*      */ 
/*  466 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  467 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  468 */         deserializer = mod.modifyDeserializer(config, beanDesc, deserializer);
/*      */       }
/*      */     }
/*  471 */     return deserializer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BeanDeserializerBuilder constructBeanDeserializerBuilder(DeserializationContext ctxt, BeanDescription beanDesc)
/*      */   {
/*  487 */     return new BeanDeserializerBuilder(beanDesc, ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addBeanProps(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder)
/*      */     throws JsonMappingException
/*      */   {
/*  501 */     boolean isConcrete = !beanDesc.getType().isAbstract();
/*      */     
/*  503 */     SettableBeanProperty[] creatorProps = isConcrete ? builder.getValueInstantiator().getFromObjectArguments(ctxt.getConfig()) : null;
/*      */     
/*  505 */     boolean hasCreatorProps = creatorProps != null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  512 */     JsonIgnoreProperties.Value ignorals = ctxt.getConfig().getDefaultPropertyIgnorals(beanDesc.getBeanClass(), beanDesc
/*  513 */       .getClassInfo());
/*      */     Iterator localIterator1;
/*  515 */     String propName; Set<String> ignored; if (ignorals != null) {
/*  516 */       boolean ignoreAny = ignorals.getIgnoreUnknown();
/*  517 */       builder.setIgnoreUnknownProperties(ignoreAny);
/*      */       
/*  519 */       Set<String> ignored = ignorals.findIgnoredForDeserialization();
/*  520 */       for (localIterator1 = ignored.iterator(); localIterator1.hasNext();) { propName = (String)localIterator1.next();
/*  521 */         builder.addIgnorable(propName);
/*      */       }
/*      */     } else {
/*  524 */       ignored = java.util.Collections.emptySet();
/*      */     }
/*      */     
/*  527 */     com.fasterxml.jackson.annotation.JsonIncludeProperties.Value inclusions = ctxt.getConfig().getDefaultPropertyInclusions(beanDesc.getBeanClass(), beanDesc
/*  528 */       .getClassInfo());
/*  529 */     Object included = null;
/*  530 */     if (inclusions != null) {
/*  531 */       included = inclusions.getIncluded();
/*  532 */       if (included != null) {
/*  533 */         for (String propName : (Set)included) {
/*  534 */           builder.addIncludable(propName);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  540 */     AnnotatedMember anySetter = beanDesc.findAnySetterAccessor();
/*  541 */     Iterator localIterator2; if (anySetter != null) {
/*  542 */       builder.setAnySetter(constructAnySetter(ctxt, beanDesc, anySetter));
/*      */     }
/*      */     else
/*      */     {
/*  546 */       Collection<String> ignored2 = beanDesc.getIgnoredPropertyNames();
/*  547 */       if (ignored2 != null) {
/*  548 */         for (localIterator2 = ignored2.iterator(); localIterator2.hasNext();) { propName = (String)localIterator2.next();
/*      */           
/*      */ 
/*  551 */           builder.addIgnorable(propName);
/*      */         }
/*      */       }
/*      */     }
/*      */     String propName;
/*  556 */     boolean useGettersAsSetters = (ctxt.isEnabled(MapperFeature.USE_GETTERS_AS_SETTERS)) && (ctxt.isEnabled(MapperFeature.AUTO_DETECT_GETTERS));
/*      */     
/*      */ 
/*  559 */     Object propDefs = filterBeanProps(ctxt, beanDesc, builder, beanDesc
/*  560 */       .findProperties(), ignored, (Set)included);
/*      */     
/*  562 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  563 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  564 */         propDefs = mod.updateProperties(ctxt.getConfig(), beanDesc, (List)propDefs);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  569 */     for (BeanPropertyDefinition propDef : (List)propDefs) {
/*  570 */       SettableBeanProperty prop = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  575 */       if (propDef.hasSetter()) {
/*  576 */         AnnotatedMethod setter = propDef.getSetter();
/*  577 */         JavaType propertyType = setter.getParameterType(0);
/*  578 */         prop = constructSettableProperty(ctxt, beanDesc, propDef, propertyType);
/*  579 */       } else if (propDef.hasField()) {
/*  580 */         AnnotatedField field = propDef.getField();
/*  581 */         JavaType propertyType = field.getType();
/*  582 */         prop = constructSettableProperty(ctxt, beanDesc, propDef, propertyType);
/*      */       }
/*      */       else {
/*  585 */         AnnotatedMethod getter = propDef.getGetter();
/*  586 */         if (getter != null) {
/*  587 */           if ((useGettersAsSetters) && (_isSetterlessType(getter.getRawType())))
/*      */           {
/*      */ 
/*  590 */             if (!builder.hasIgnorable(propDef.getName()))
/*      */             {
/*      */ 
/*  593 */               prop = constructSetterlessProperty(ctxt, beanDesc, propDef);
/*      */             }
/*  595 */           } else if (!propDef.hasConstructorParameter()) {
/*  596 */             PropertyMetadata md = propDef.getMetadata();
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  601 */             if (md.getMergeInfo() != null) {
/*  602 */               prop = constructSetterlessProperty(ctxt, beanDesc, propDef);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  610 */       if ((hasCreatorProps) && (propDef.hasConstructorParameter()))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  616 */         String name = propDef.getName();
/*  617 */         CreatorProperty cprop = null;
/*      */         
/*  619 */         SettableBeanProperty[] arrayOfSettableBeanProperty1 = creatorProps;int i = arrayOfSettableBeanProperty1.length; SettableBeanProperty cp; for (SettableBeanProperty localSettableBeanProperty1 = 0; localSettableBeanProperty1 < i; localSettableBeanProperty1++) { cp = arrayOfSettableBeanProperty1[localSettableBeanProperty1];
/*  620 */           if ((name.equals(cp.getName())) && ((cp instanceof CreatorProperty))) {
/*  621 */             cprop = (CreatorProperty)cp;
/*  622 */             break;
/*      */           }
/*      */         }
/*  625 */         if (cprop == null) {
/*  626 */           Object n = new ArrayList();
/*  627 */           SettableBeanProperty[] arrayOfSettableBeanProperty2 = creatorProps;localSettableBeanProperty1 = arrayOfSettableBeanProperty2.length; for (cp = 0; cp < localSettableBeanProperty1; cp++) { SettableBeanProperty cp = arrayOfSettableBeanProperty2[cp];
/*  628 */             ((List)n).add(cp.getName());
/*      */           }
/*  630 */           ctxt.reportBadPropertyDefinition(beanDesc, propDef, "Could not find creator property with name %s (known Creator properties: %s)", new Object[] {
/*      */           
/*  632 */             ClassUtil.name(name), n });
/*      */         }
/*      */         else {
/*  635 */           if (prop != null) {
/*  636 */             cprop.setFallbackSetter(prop);
/*      */           }
/*  638 */           Object views = propDef.findViews();
/*  639 */           if (views == null) {
/*  640 */             views = beanDesc.findDefaultViews();
/*      */           }
/*  642 */           cprop.setViews((Class[])views);
/*  643 */           builder.addCreatorProperty(cprop);
/*      */         }
/*      */       }
/*  646 */       else if (prop != null)
/*      */       {
/*  648 */         Class<?>[] views = propDef.findViews();
/*  649 */         if (views == null) {
/*  650 */           views = beanDesc.findDefaultViews();
/*      */         }
/*  652 */         prop.setViews(views);
/*  653 */         builder.addProperty(prop);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean _isSetterlessType(Class<?> rawType)
/*      */   {
/*  662 */     return (Collection.class.isAssignableFrom(rawType)) || 
/*  663 */       (Map.class.isAssignableFrom(rawType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected List<BeanPropertyDefinition> filterBeanProps(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder, List<BeanPropertyDefinition> propDefsIn, Set<String> ignored)
/*      */     throws JsonMappingException
/*      */   {
/*  681 */     return filterBeanProps(ctxt, beanDesc, builder, propDefsIn, ignored, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected List<BeanPropertyDefinition> filterBeanProps(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder, List<BeanPropertyDefinition> propDefsIn, Set<String> ignored, Set<String> included)
/*      */   {
/*  699 */     ArrayList<BeanPropertyDefinition> result = new ArrayList(Math.max(4, propDefsIn.size()));
/*  700 */     java.util.HashMap<Class<?>, Boolean> ignoredTypes = new java.util.HashMap();
/*      */     
/*  702 */     for (BeanPropertyDefinition property : propDefsIn) {
/*  703 */       String name = property.getName();
/*      */       
/*  705 */       if (!com.fasterxml.jackson.databind.util.IgnorePropertiesUtil.shouldIgnore(name, ignored, included))
/*      */       {
/*      */ 
/*  708 */         if (!property.hasConstructorParameter()) {
/*  709 */           Class<?> rawPropertyType = property.getRawPrimaryType();
/*      */           
/*  711 */           if ((rawPropertyType != null) && 
/*  712 */             (isIgnorableType(ctxt.getConfig(), property, rawPropertyType, ignoredTypes)))
/*      */           {
/*  714 */             builder.addIgnorable(name);
/*  715 */             continue;
/*      */           }
/*      */         }
/*  718 */         result.add(property);
/*      */       } }
/*  720 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addBackReferenceProperties(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder)
/*      */     throws JsonMappingException
/*      */   {
/*  734 */     List<BeanPropertyDefinition> refProps = beanDesc.findBackReferences();
/*  735 */     if (refProps != null) {
/*  736 */       for (BeanPropertyDefinition refProp : refProps)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  753 */         String refName = refProp.findReferenceName();
/*  754 */         builder.addBackReferenceProperty(refName, constructSettableProperty(ctxt, beanDesc, refProp, refProp
/*  755 */           .getPrimaryType()));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   protected void addReferenceProperties(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder)
/*      */     throws JsonMappingException
/*      */   {
/*  765 */     addBackReferenceProperties(ctxt, beanDesc, builder);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void addInjectables(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder)
/*      */     throws JsonMappingException
/*      */   {
/*  776 */     Map<Object, AnnotatedMember> raw = beanDesc.findInjectables();
/*  777 */     if (raw != null) {
/*  778 */       for (Map.Entry<Object, AnnotatedMember> entry : raw.entrySet()) {
/*  779 */         AnnotatedMember m = (AnnotatedMember)entry.getValue();
/*  780 */         builder.addInjectable(PropertyName.construct(m.getName()), m
/*  781 */           .getType(), beanDesc
/*  782 */           .getClassAnnotations(), m, entry.getKey());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected SettableAnyProperty constructAnySetter(DeserializationContext ctxt, BeanDescription beanDesc, AnnotatedMember mutator)
/*      */     throws JsonMappingException
/*      */   {
/*      */     BeanProperty prop;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  805 */     if ((mutator instanceof AnnotatedMethod))
/*      */     {
/*  807 */       AnnotatedMethod am = (AnnotatedMethod)mutator;
/*  808 */       JavaType keyType = am.getParameterType(0);
/*  809 */       JavaType valueType = am.getParameterType(1);
/*  810 */       valueType = resolveMemberAndTypeAnnotations(ctxt, mutator, valueType);
/*  811 */       prop = new BeanProperty.Std(PropertyName.construct(mutator.getName()), valueType, null, mutator, PropertyMetadata.STD_OPTIONAL);
/*      */     }
/*      */     else {
/*      */       BeanProperty prop;
/*  815 */       if ((mutator instanceof AnnotatedField)) {
/*  816 */         AnnotatedField af = (AnnotatedField)mutator;
/*      */         
/*  818 */         JavaType mapType = af.getType();
/*  819 */         mapType = resolveMemberAndTypeAnnotations(ctxt, mutator, mapType);
/*  820 */         JavaType keyType = mapType.getKeyType();
/*  821 */         JavaType valueType = mapType.getContentType();
/*  822 */         prop = new BeanProperty.Std(PropertyName.construct(mutator.getName()), mapType, null, mutator, PropertyMetadata.STD_OPTIONAL);
/*      */       }
/*      */       else {
/*  825 */         return (SettableAnyProperty)ctxt.reportBadDefinition(beanDesc.getType(), String.format("Unrecognized mutator type for any setter: %s", new Object[] {mutator
/*  826 */           .getClass() })); } }
/*      */     JavaType valueType;
/*      */     JavaType keyType;
/*      */     BeanProperty prop;
/*  830 */     KeyDeserializer keyDeser = findKeyDeserializerFromAnnotation(ctxt, mutator);
/*  831 */     if (keyDeser == null) {
/*  832 */       keyDeser = (KeyDeserializer)keyType.getValueHandler();
/*      */     }
/*  834 */     if (keyDeser == null) {
/*  835 */       keyDeser = ctxt.findKeyDeserializer(keyType, prop);
/*      */     }
/*  837 */     else if ((keyDeser instanceof ContextualKeyDeserializer))
/*      */     {
/*  839 */       keyDeser = ((ContextualKeyDeserializer)keyDeser).createContextual(ctxt, prop);
/*      */     }
/*      */     
/*  842 */     JsonDeserializer<Object> deser = findContentDeserializerFromAnnotation(ctxt, mutator);
/*  843 */     if (deser == null) {
/*  844 */       deser = (JsonDeserializer)valueType.getValueHandler();
/*      */     }
/*  846 */     if (deser != null)
/*      */     {
/*  848 */       deser = ctxt.handlePrimaryContextualization(deser, prop, valueType);
/*      */     }
/*  850 */     TypeDeserializer typeDeser = (TypeDeserializer)valueType.getTypeHandler();
/*  851 */     return new SettableAnyProperty(prop, mutator, valueType, keyDeser, deser, typeDeser);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected SettableBeanProperty constructSettableProperty(DeserializationContext ctxt, BeanDescription beanDesc, BeanPropertyDefinition propDef, JavaType propType0)
/*      */     throws JsonMappingException
/*      */   {
/*  868 */     AnnotatedMember mutator = propDef.getNonConstructorMutator();
/*      */     
/*      */ 
/*      */ 
/*  872 */     if (mutator == null) {
/*  873 */       ctxt.reportBadPropertyDefinition(beanDesc, propDef, "No non-constructor mutator available", new Object[0]);
/*      */     }
/*  875 */     JavaType type = resolveMemberAndTypeAnnotations(ctxt, mutator, propType0);
/*      */     
/*  877 */     TypeDeserializer typeDeser = (TypeDeserializer)type.getTypeHandler();
/*      */     SettableBeanProperty prop;
/*  879 */     SettableBeanProperty prop; if ((mutator instanceof AnnotatedMethod))
/*      */     {
/*  881 */       prop = new com.fasterxml.jackson.databind.deser.impl.MethodProperty(propDef, type, typeDeser, beanDesc.getClassAnnotations(), (AnnotatedMethod)mutator);
/*      */     }
/*      */     else
/*      */     {
/*  885 */       prop = new com.fasterxml.jackson.databind.deser.impl.FieldProperty(propDef, type, typeDeser, beanDesc.getClassAnnotations(), (AnnotatedField)mutator);
/*      */     }
/*  887 */     JsonDeserializer<?> deser = findDeserializerFromAnnotation(ctxt, mutator);
/*  888 */     if (deser == null) {
/*  889 */       deser = (JsonDeserializer)type.getValueHandler();
/*      */     }
/*  891 */     if (deser != null) {
/*  892 */       deser = ctxt.handlePrimaryContextualization(deser, prop, type);
/*  893 */       prop = prop.withValueDeserializer(deser);
/*      */     }
/*      */     
/*  896 */     AnnotationIntrospector.ReferenceProperty ref = propDef.findReferenceType();
/*  897 */     if ((ref != null) && (ref.isManagedReference())) {
/*  898 */       prop.setManagedReferenceName(ref.getName());
/*      */     }
/*  900 */     ObjectIdInfo objectIdInfo = propDef.findObjectIdInfo();
/*  901 */     if (objectIdInfo != null) {
/*  902 */       prop.setObjectIdInfo(objectIdInfo);
/*      */     }
/*  904 */     return prop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected SettableBeanProperty constructSetterlessProperty(DeserializationContext ctxt, BeanDescription beanDesc, BeanPropertyDefinition propDef)
/*      */     throws JsonMappingException
/*      */   {
/*  915 */     AnnotatedMethod getter = propDef.getGetter();
/*  916 */     JavaType type = resolveMemberAndTypeAnnotations(ctxt, getter, getter.getType());
/*  917 */     TypeDeserializer typeDeser = (TypeDeserializer)type.getTypeHandler();
/*      */     
/*  919 */     SettableBeanProperty prop = new com.fasterxml.jackson.databind.deser.impl.SetterlessProperty(propDef, type, typeDeser, beanDesc.getClassAnnotations(), getter);
/*  920 */     JsonDeserializer<?> deser = findDeserializerFromAnnotation(ctxt, getter);
/*  921 */     if (deser == null) {
/*  922 */       deser = (JsonDeserializer)type.getValueHandler();
/*      */     }
/*  924 */     if (deser != null) {
/*  925 */       deser = ctxt.handlePrimaryContextualization(deser, prop, type);
/*  926 */       prop = prop.withValueDeserializer(deser);
/*      */     }
/*  928 */     return prop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isPotentialBeanType(Class<?> type)
/*      */   {
/*  947 */     String typeStr = ClassUtil.canBeABeanType(type);
/*  948 */     if (typeStr != null) {
/*  949 */       throw new IllegalArgumentException("Cannot deserialize Class " + type.getName() + " (of type " + typeStr + ") as a Bean");
/*      */     }
/*  951 */     if (ClassUtil.isProxyType(type)) {
/*  952 */       throw new IllegalArgumentException("Cannot deserialize Proxy class " + type.getName() + " as a Bean");
/*      */     }
/*      */     
/*      */ 
/*  956 */     typeStr = ClassUtil.isLocalType(type, true);
/*  957 */     if (typeStr != null) {
/*  958 */       throw new IllegalArgumentException("Cannot deserialize Class " + type.getName() + " (of type " + typeStr + ") as a Bean");
/*      */     }
/*  960 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean isIgnorableType(DeserializationConfig config, BeanPropertyDefinition propDef, Class<?> type, Map<Class<?>, Boolean> ignoredTypes)
/*      */   {
/*  970 */     Boolean status = (Boolean)ignoredTypes.get(type);
/*  971 */     if (status != null) {
/*  972 */       return status.booleanValue();
/*      */     }
/*      */     
/*  975 */     if ((type == String.class) || (type.isPrimitive())) {
/*  976 */       status = Boolean.FALSE;
/*      */     }
/*      */     else {
/*  979 */       status = config.getConfigOverride(type).getIsIgnoredType();
/*  980 */       if (status == null) {
/*  981 */         BeanDescription desc = config.introspectClassAnnotations(type);
/*  982 */         status = config.getAnnotationIntrospector().isIgnorableType(desc.getClassInfo());
/*      */         
/*  984 */         if (status == null) {
/*  985 */           status = Boolean.FALSE;
/*      */         }
/*      */       }
/*      */     }
/*  989 */     ignoredTypes.put(type, status);
/*  990 */     return status.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _validateSubType(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc)
/*      */     throws JsonMappingException
/*      */   {
/* 1000 */     com.fasterxml.jackson.databind.jsontype.impl.SubTypeValidator.instance().validateSubType(ctxt, type, beanDesc);
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\BeanDeserializerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */