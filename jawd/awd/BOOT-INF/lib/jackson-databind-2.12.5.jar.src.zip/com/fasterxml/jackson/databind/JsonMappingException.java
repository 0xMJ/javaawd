/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonIgnore;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonMappingException
/*     */   extends JsonProcessingException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   static final int MAX_REFS_TO_LIST = 1000;
/*     */   protected LinkedList<Reference> _path;
/*     */   protected transient Closeable _processor;
/*     */   
/*     */   public static class Reference
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     protected transient Object _from;
/*     */     protected String _fieldName;
/*  67 */     protected int _index = -1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected String _desc;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected Reference() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  84 */     public Reference(Object from) { this._from = from; }
/*     */     
/*     */     public Reference(Object from, String fieldName) {
/*  87 */       this._from = from;
/*  88 */       if (fieldName == null) {
/*  89 */         throw new NullPointerException("Cannot pass null fieldName");
/*     */       }
/*  91 */       this._fieldName = fieldName;
/*     */     }
/*     */     
/*     */     public Reference(Object from, int index) {
/*  95 */       this._from = from;
/*  96 */       this._index = index;
/*     */     }
/*     */     
/*     */ 
/* 100 */     void setFieldName(String n) { this._fieldName = n; }
/* 101 */     void setIndex(int ix) { this._index = ix; }
/* 102 */     void setDescription(String d) { this._desc = d; }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     @JsonIgnore
/* 115 */     public Object getFrom() { return this._from; }
/*     */     
/* 117 */     public String getFieldName() { return this._fieldName; }
/* 118 */     public int getIndex() { return this._index; }
/*     */     
/* 120 */     public String getDescription() { if (this._desc == null) {
/* 121 */         StringBuilder sb = new StringBuilder();
/*     */         
/* 123 */         if (this._from == null) {
/* 124 */           sb.append("UNKNOWN");
/*     */         } else {
/* 126 */           Class<?> cls = (this._from instanceof Class) ? (Class)this._from : this._from.getClass();
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 131 */           int arrays = 0;
/* 132 */           while (cls.isArray()) {
/* 133 */             cls = cls.getComponentType();
/* 134 */             arrays++;
/*     */           }
/* 136 */           sb.append(cls.getName());
/* 137 */           for (;;) { arrays--; if (arrays < 0) break;
/* 138 */             sb.append("[]");
/*     */           }
/*     */         }
/* 141 */         sb.append('[');
/* 142 */         if (this._fieldName != null) {
/* 143 */           sb.append('"');
/* 144 */           sb.append(this._fieldName);
/* 145 */           sb.append('"');
/* 146 */         } else if (this._index >= 0) {
/* 147 */           sb.append(this._index);
/*     */         } else {
/* 149 */           sb.append('?');
/*     */         }
/* 151 */         sb.append(']');
/* 152 */         this._desc = sb.toString();
/*     */       }
/* 154 */       return this._desc;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 159 */       return getDescription();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     Object writeReplace()
/*     */     {
/* 170 */       getDescription();
/* 171 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public JsonMappingException(String msg)
/*     */   {
/* 207 */     super(msg);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public JsonMappingException(String msg, Throwable rootCause)
/*     */   {
/* 213 */     super(msg, rootCause);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public JsonMappingException(String msg, JsonLocation loc)
/*     */   {
/* 219 */     super(msg, loc);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public JsonMappingException(String msg, JsonLocation loc, Throwable rootCause)
/*     */   {
/* 225 */     super(msg, loc, rootCause);
/*     */   }
/*     */   
/*     */ 
/*     */   public JsonMappingException(Closeable processor, String msg)
/*     */   {
/* 231 */     super(msg);
/* 232 */     this._processor = processor;
/* 233 */     if ((processor instanceof JsonParser))
/*     */     {
/*     */ 
/*     */ 
/* 237 */       this._location = ((JsonParser)processor).getTokenLocation();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JsonMappingException(Closeable processor, String msg, Throwable problem)
/*     */   {
/* 245 */     super(msg, problem);
/* 246 */     this._processor = processor;
/*     */     
/* 248 */     if ((problem instanceof JsonProcessingException)) {
/* 249 */       this._location = ((JsonProcessingException)problem).getLocation();
/* 250 */     } else if ((processor instanceof JsonParser)) {
/* 251 */       this._location = ((JsonParser)processor).getTokenLocation();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JsonMappingException(Closeable processor, String msg, JsonLocation loc)
/*     */   {
/* 259 */     super(msg, loc);
/* 260 */     this._processor = processor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static JsonMappingException from(JsonParser p, String msg)
/*     */   {
/* 267 */     return new JsonMappingException(p, msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static JsonMappingException from(JsonParser p, String msg, Throwable problem)
/*     */   {
/* 274 */     return new JsonMappingException(p, msg, problem);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static JsonMappingException from(JsonGenerator g, String msg)
/*     */   {
/* 281 */     return new JsonMappingException(g, msg, (Throwable)null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static JsonMappingException from(JsonGenerator g, String msg, Throwable problem)
/*     */   {
/* 288 */     return new JsonMappingException(g, msg, problem);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static JsonMappingException from(DeserializationContext ctxt, String msg)
/*     */   {
/* 295 */     return new JsonMappingException(ctxt.getParser(), msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static JsonMappingException from(DeserializationContext ctxt, String msg, Throwable t)
/*     */   {
/* 302 */     return new JsonMappingException(ctxt.getParser(), msg, t);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static JsonMappingException from(SerializerProvider ctxt, String msg)
/*     */   {
/* 309 */     return new JsonMappingException(ctxt.getGenerator(), msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonMappingException from(SerializerProvider ctxt, String msg, Throwable problem)
/*     */   {
/* 319 */     return new JsonMappingException(ctxt.getGenerator(), msg, problem);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonMappingException fromUnexpectedIOE(IOException src)
/*     */   {
/* 333 */     return new JsonMappingException(null, 
/* 334 */       String.format("Unexpected IOException (of type %s): %s", new Object[] {src
/* 335 */       .getClass().getName(), 
/* 336 */       ClassUtil.exceptionMessage(src) }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonMappingException wrapWithPath(Throwable src, Object refFrom, String refFieldName)
/*     */   {
/* 349 */     return wrapWithPath(src, new Reference(refFrom, refFieldName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JsonMappingException wrapWithPath(Throwable src, Object refFrom, int index)
/*     */   {
/* 361 */     return wrapWithPath(src, new Reference(refFrom, index));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static JsonMappingException wrapWithPath(Throwable src, Reference ref)
/*     */   {
/*     */     JsonMappingException jme;
/*     */     
/*     */ 
/*     */     JsonMappingException jme;
/*     */     
/* 373 */     if ((src instanceof JsonMappingException)) {
/* 374 */       jme = (JsonMappingException)src;
/*     */     }
/*     */     else {
/* 377 */       String msg = ClassUtil.exceptionMessage(src);
/*     */       
/* 379 */       if ((msg == null) || (msg.isEmpty())) {
/* 380 */         msg = "(was " + src.getClass().getName() + ")";
/*     */       }
/*     */       
/* 383 */       Closeable proc = null;
/* 384 */       if ((src instanceof JsonProcessingException)) {
/* 385 */         Object proc0 = ((JsonProcessingException)src).getProcessor();
/* 386 */         if ((proc0 instanceof Closeable)) {
/* 387 */           proc = (Closeable)proc0;
/*     */         }
/*     */       }
/* 390 */       jme = new JsonMappingException(proc, msg, src);
/*     */     }
/* 392 */     jme.prependPath(ref);
/* 393 */     return jme;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Reference> getPath()
/*     */   {
/* 408 */     if (this._path == null) {
/* 409 */       return Collections.emptyList();
/*     */     }
/* 411 */     return Collections.unmodifiableList(this._path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPathReference()
/*     */   {
/* 420 */     return getPathReference(new StringBuilder()).toString();
/*     */   }
/*     */   
/*     */   public StringBuilder getPathReference(StringBuilder sb)
/*     */   {
/* 425 */     _appendPathDesc(sb);
/* 426 */     return sb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prependPath(Object referrer, String fieldName)
/*     */   {
/* 435 */     Reference ref = new Reference(referrer, fieldName);
/* 436 */     prependPath(ref);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prependPath(Object referrer, int index)
/*     */   {
/* 444 */     Reference ref = new Reference(referrer, index);
/* 445 */     prependPath(ref);
/*     */   }
/*     */   
/*     */   public void prependPath(Reference r)
/*     */   {
/* 450 */     if (this._path == null) {
/* 451 */       this._path = new LinkedList();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 457 */     if (this._path.size() < 1000) {
/* 458 */       this._path.addFirst(r);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @JsonIgnore
/*     */   public Object getProcessor()
/*     */   {
/* 470 */     return this._processor;
/*     */   }
/*     */   
/*     */   public String getLocalizedMessage() {
/* 474 */     return _buildMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 483 */     return _buildMessage();
/*     */   }
/*     */   
/*     */ 
/*     */   protected String _buildMessage()
/*     */   {
/* 489 */     String msg = super.getMessage();
/* 490 */     if (this._path == null) {
/* 491 */       return msg;
/*     */     }
/* 493 */     StringBuilder sb = msg == null ? new StringBuilder() : new StringBuilder(msg);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 499 */     sb.append(" (through reference chain: ");
/* 500 */     sb = getPathReference(sb);
/* 501 */     sb.append(')');
/* 502 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 508 */     return getClass().getName() + ": " + getMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void _appendPathDesc(StringBuilder sb)
/*     */   {
/* 519 */     if (this._path == null) {
/* 520 */       return;
/*     */     }
/* 522 */     Iterator<Reference> it = this._path.iterator();
/* 523 */     while (it.hasNext()) {
/* 524 */       sb.append(((Reference)it.next()).toString());
/* 525 */       if (it.hasNext()) {
/* 526 */         sb.append("->");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\JsonMappingException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */