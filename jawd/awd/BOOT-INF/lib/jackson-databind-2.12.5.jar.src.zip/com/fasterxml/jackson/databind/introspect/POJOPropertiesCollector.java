/*      */ package com.fasterxml.jackson.databind.introspect;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JacksonInject.Value;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator.Mode;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*      */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class POJOPropertiesCollector
/*      */ {
/*      */   protected final MapperConfig<?> _config;
/*      */   protected final AccessorNamingStrategy _accessorNaming;
/*      */   protected final boolean _forSerialization;
/*      */   protected final JavaType _type;
/*      */   protected final AnnotatedClass _classDef;
/*      */   protected final VisibilityChecker<?> _visibilityChecker;
/*      */   protected final AnnotationIntrospector _annotationIntrospector;
/*      */   protected final boolean _useAnnotations;
/*      */   protected boolean _collected;
/*      */   protected LinkedHashMap<String, POJOPropertyBuilder> _properties;
/*      */   protected LinkedList<POJOPropertyBuilder> _creatorProperties;
/*      */   protected Map<PropertyName, PropertyName> _fieldRenameMappings;
/*      */   protected LinkedList<AnnotatedMember> _anyGetters;
/*      */   protected LinkedList<AnnotatedMember> _anyGetterField;
/*      */   protected LinkedList<AnnotatedMethod> _anySetters;
/*      */   protected LinkedList<AnnotatedMember> _anySetterField;
/*      */   protected LinkedList<AnnotatedMember> _jsonKeyAccessors;
/*      */   protected LinkedList<AnnotatedMember> _jsonValueAccessors;
/*      */   protected HashSet<String> _ignoredPropertyNames;
/*      */   protected LinkedHashMap<Object, AnnotatedMember> _injectables;
/*      */   @Deprecated
/*      */   protected final boolean _stdBeanNaming;
/*      */   @Deprecated
/*  152 */   protected String _mutatorPrefix = "set";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected POJOPropertiesCollector(MapperConfig<?> config, boolean forSerialization, JavaType type, AnnotatedClass classDef, AccessorNamingStrategy accessorNaming)
/*      */   {
/*  168 */     this._config = config;
/*  169 */     this._forSerialization = forSerialization;
/*  170 */     this._type = type;
/*  171 */     this._classDef = classDef;
/*  172 */     if (config.isAnnotationProcessingEnabled()) {
/*  173 */       this._useAnnotations = true;
/*  174 */       this._annotationIntrospector = this._config.getAnnotationIntrospector();
/*      */     } else {
/*  176 */       this._useAnnotations = false;
/*  177 */       this._annotationIntrospector = AnnotationIntrospector.nopInstance();
/*      */     }
/*  179 */     this._visibilityChecker = this._config.getDefaultVisibilityChecker(type.getRawClass(), classDef);
/*      */     
/*  181 */     this._accessorNaming = accessorNaming;
/*      */     
/*      */ 
/*  184 */     this._stdBeanNaming = config.isEnabled(MapperFeature.USE_STD_BEAN_NAMING);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected POJOPropertiesCollector(MapperConfig<?> config, boolean forSerialization, JavaType type, AnnotatedClass classDef, String mutatorPrefix)
/*      */   {
/*  195 */     this(config, forSerialization, type, classDef, 
/*  196 */       _accessorNaming(config, classDef, mutatorPrefix));
/*      */   }
/*      */   
/*      */ 
/*      */   private static AccessorNamingStrategy _accessorNaming(MapperConfig<?> config, AnnotatedClass classDef, String mutatorPrefix)
/*      */   {
/*  202 */     if (mutatorPrefix == null) {
/*  203 */       mutatorPrefix = "set";
/*      */     }
/*  205 */     return 
/*  206 */       new DefaultAccessorNamingStrategy.Provider().withSetterPrefix(mutatorPrefix).forPOJO(config, classDef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MapperConfig<?> getConfig()
/*      */   {
/*  216 */     return this._config;
/*      */   }
/*      */   
/*      */   public JavaType getType() {
/*  220 */     return this._type;
/*      */   }
/*      */   
/*      */   public AnnotatedClass getClassDef() {
/*  224 */     return this._classDef;
/*      */   }
/*      */   
/*      */   public AnnotationIntrospector getAnnotationIntrospector() {
/*  228 */     return this._annotationIntrospector;
/*      */   }
/*      */   
/*      */   public List<BeanPropertyDefinition> getProperties()
/*      */   {
/*  233 */     Map<String, POJOPropertyBuilder> props = getPropertyMap();
/*  234 */     return new ArrayList(props.values());
/*      */   }
/*      */   
/*      */   public Map<Object, AnnotatedMember> getInjectables() {
/*  238 */     if (!this._collected) {
/*  239 */       collectAll();
/*      */     }
/*  241 */     return this._injectables;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public AnnotatedMember getJsonKeyAccessor()
/*      */   {
/*  248 */     if (!this._collected) {
/*  249 */       collectAll();
/*      */     }
/*      */     
/*  252 */     if (this._jsonKeyAccessors != null) {
/*  253 */       if (this._jsonKeyAccessors.size() > 1) {
/*  254 */         reportProblem("Multiple 'as-key' properties defined (%s vs %s)", new Object[] {this._jsonKeyAccessors
/*  255 */           .get(0), this._jsonKeyAccessors
/*  256 */           .get(1) });
/*      */       }
/*      */       
/*  259 */       return (AnnotatedMember)this._jsonKeyAccessors.get(0);
/*      */     }
/*  261 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotatedMember getJsonValueAccessor()
/*      */   {
/*  269 */     if (!this._collected) {
/*  270 */       collectAll();
/*      */     }
/*      */     
/*  273 */     if (this._jsonValueAccessors != null) {
/*  274 */       if (this._jsonValueAccessors.size() > 1) {
/*  275 */         reportProblem("Multiple 'as-value' properties defined (%s vs %s)", new Object[] {this._jsonValueAccessors
/*  276 */           .get(0), this._jsonValueAccessors
/*  277 */           .get(1) });
/*      */       }
/*      */       
/*  280 */       return (AnnotatedMember)this._jsonValueAccessors.get(0);
/*      */     }
/*  282 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public AnnotatedMember getAnyGetter()
/*      */   {
/*  293 */     return getAnyGetterMethod();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotatedMember getAnyGetterField()
/*      */   {
/*  301 */     if (!this._collected) {
/*  302 */       collectAll();
/*      */     }
/*  304 */     if (this._anyGetterField != null) {
/*  305 */       if (this._anyGetterField.size() > 1) {
/*  306 */         reportProblem("Multiple 'any-getter' fields defined (%s vs %s)", new Object[] {this._anyGetterField
/*  307 */           .get(0), this._anyGetterField.get(1) });
/*      */       }
/*  309 */       return (AnnotatedMember)this._anyGetterField.getFirst();
/*      */     }
/*  311 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotatedMember getAnyGetterMethod()
/*      */   {
/*  319 */     if (!this._collected) {
/*  320 */       collectAll();
/*      */     }
/*  322 */     if (this._anyGetters != null) {
/*  323 */       if (this._anyGetters.size() > 1) {
/*  324 */         reportProblem("Multiple 'any-getter' methods defined (%s vs %s)", new Object[] {this._anyGetters
/*  325 */           .get(0), this._anyGetters.get(1) });
/*      */       }
/*  327 */       return (AnnotatedMember)this._anyGetters.getFirst();
/*      */     }
/*  329 */     return null;
/*      */   }
/*      */   
/*      */   public AnnotatedMember getAnySetterField()
/*      */   {
/*  334 */     if (!this._collected) {
/*  335 */       collectAll();
/*      */     }
/*  337 */     if (this._anySetterField != null) {
/*  338 */       if (this._anySetterField.size() > 1) {
/*  339 */         reportProblem("Multiple 'any-setter' fields defined (%s vs %s)", new Object[] {this._anySetterField
/*  340 */           .get(0), this._anySetterField.get(1) });
/*      */       }
/*  342 */       return (AnnotatedMember)this._anySetterField.getFirst();
/*      */     }
/*  344 */     return null;
/*      */   }
/*      */   
/*      */   public AnnotatedMethod getAnySetterMethod()
/*      */   {
/*  349 */     if (!this._collected) {
/*  350 */       collectAll();
/*      */     }
/*  352 */     if (this._anySetters != null) {
/*  353 */       if (this._anySetters.size() > 1) {
/*  354 */         reportProblem("Multiple 'any-setter' methods defined (%s vs %s)", new Object[] {this._anySetters
/*  355 */           .get(0), this._anySetters.get(1) });
/*      */       }
/*  357 */       return (AnnotatedMethod)this._anySetters.getFirst();
/*      */     }
/*  359 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> getIgnoredPropertyNames()
/*      */   {
/*  367 */     return this._ignoredPropertyNames;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectIdInfo getObjectIdInfo()
/*      */   {
/*  376 */     ObjectIdInfo info = this._annotationIntrospector.findObjectIdInfo(this._classDef);
/*  377 */     if (info != null) {
/*  378 */       info = this._annotationIntrospector.findObjectReferenceInfo(this._classDef, info);
/*      */     }
/*  380 */     return info;
/*      */   }
/*      */   
/*      */   protected Map<String, POJOPropertyBuilder> getPropertyMap()
/*      */   {
/*  385 */     if (!this._collected) {
/*  386 */       collectAll();
/*      */     }
/*  388 */     return this._properties;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public AnnotatedMethod getJsonValueMethod() {
/*  393 */     AnnotatedMember m = getJsonValueAccessor();
/*  394 */     if ((m instanceof AnnotatedMethod)) {
/*  395 */       return (AnnotatedMethod)m;
/*      */     }
/*  397 */     return null;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findPOJOBuilderClass() {
/*  402 */     return this._annotationIntrospector.findPOJOBuilder(this._classDef);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void collectAll()
/*      */   {
/*  418 */     LinkedHashMap<String, POJOPropertyBuilder> props = new LinkedHashMap();
/*      */     
/*      */ 
/*  421 */     _addFields(props);
/*  422 */     _addMethods(props);
/*      */     
/*      */ 
/*  425 */     if (!this._classDef.isNonStaticInnerClass()) {
/*  426 */       _addCreators(props);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  431 */     _removeUnwantedProperties(props);
/*      */     
/*  433 */     _removeUnwantedAccessor(props);
/*      */     
/*      */ 
/*  436 */     _renameProperties(props);
/*      */     
/*      */ 
/*      */ 
/*  440 */     _addInjectables(props);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  445 */     for (POJOPropertyBuilder property : props.values()) {
/*  446 */       property.mergeAnnotations(this._forSerialization);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  451 */     for (POJOPropertyBuilder property : props.values()) {
/*  452 */       property.trimByVisibility();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  457 */     PropertyNamingStrategy naming = _findNamingStrategy();
/*  458 */     if (naming != null) {
/*  459 */       _renameUsing(props, naming);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  464 */     if (this._config.isEnabled(MapperFeature.USE_WRAPPER_NAME_AS_PROPERTY_NAME)) {
/*  465 */       _renameWithWrappers(props);
/*      */     }
/*      */     
/*      */ 
/*  469 */     _sortProperties(props);
/*  470 */     this._properties = props;
/*  471 */     this._collected = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _addFields(Map<String, POJOPropertyBuilder> props)
/*      */   {
/*  485 */     AnnotationIntrospector ai = this._annotationIntrospector;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  490 */     boolean pruneFinalFields = (!this._forSerialization) && (!this._config.isEnabled(MapperFeature.ALLOW_FINAL_FIELDS_AS_MUTATORS));
/*  491 */     boolean transientAsIgnoral = this._config.isEnabled(MapperFeature.PROPAGATE_TRANSIENT_MARKER);
/*      */     
/*  493 */     for (AnnotatedField f : this._classDef.fields())
/*      */     {
/*  495 */       if (Boolean.TRUE.equals(ai.hasAsKey(this._config, f))) {
/*  496 */         if (this._jsonKeyAccessors == null) {
/*  497 */           this._jsonKeyAccessors = new LinkedList();
/*      */         }
/*  499 */         this._jsonKeyAccessors.add(f);
/*      */       }
/*      */       
/*  502 */       if (Boolean.TRUE.equals(ai.hasAsValue(f))) {
/*  503 */         if (this._jsonValueAccessors == null) {
/*  504 */           this._jsonValueAccessors = new LinkedList();
/*      */         }
/*  506 */         this._jsonValueAccessors.add(f);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  511 */         boolean anyGetter = Boolean.TRUE.equals(ai.hasAnyGetter(f));
/*  512 */         boolean anySetter = Boolean.TRUE.equals(ai.hasAnySetter(f));
/*  513 */         if ((anyGetter) || (anySetter))
/*      */         {
/*  515 */           if (anyGetter) {
/*  516 */             if (this._anyGetterField == null) {
/*  517 */               this._anyGetterField = new LinkedList();
/*      */             }
/*  519 */             this._anyGetterField.add(f);
/*      */           }
/*      */           
/*  522 */           if (anySetter) {
/*  523 */             if (this._anySetterField == null) {
/*  524 */               this._anySetterField = new LinkedList();
/*      */             }
/*  526 */             this._anySetterField.add(f);
/*      */           }
/*      */         }
/*      */         else {
/*  530 */           String implName = ai.findImplicitPropertyName(f);
/*  531 */           if (implName == null) {
/*  532 */             implName = f.getName();
/*      */           }
/*      */           
/*      */ 
/*  536 */           implName = this._accessorNaming.modifyFieldName(f, implName);
/*  537 */           if (implName != null)
/*      */           {
/*      */ 
/*      */ 
/*  541 */             PropertyName implNameP = _propNameFromSimple(implName);
/*      */             
/*      */ 
/*      */ 
/*  545 */             PropertyName rename = ai.findRenameByField(this._config, f, implNameP);
/*  546 */             if ((rename != null) && (!rename.equals(implNameP))) {
/*  547 */               if (this._fieldRenameMappings == null) {
/*  548 */                 this._fieldRenameMappings = new HashMap();
/*      */               }
/*  550 */               this._fieldRenameMappings.put(rename, implNameP);
/*      */             }
/*      */             
/*      */             PropertyName pn;
/*      */             PropertyName pn;
/*  555 */             if (this._forSerialization)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*  560 */               pn = ai.findNameForSerialization(f);
/*      */             } else {
/*  562 */               pn = ai.findNameForDeserialization(f);
/*      */             }
/*  564 */             boolean hasName = pn != null;
/*  565 */             boolean nameExplicit = hasName;
/*      */             
/*  567 */             if ((nameExplicit) && (pn.isEmpty())) {
/*  568 */               pn = _propNameFromSimple(implName);
/*  569 */               nameExplicit = false;
/*      */             }
/*      */             
/*  572 */             boolean visible = pn != null;
/*  573 */             if (!visible) {
/*  574 */               visible = this._visibilityChecker.isFieldVisible(f);
/*      */             }
/*      */             
/*  577 */             boolean ignored = ai.hasIgnoreMarker(f);
/*      */             
/*      */ 
/*  580 */             if (f.isTransient())
/*      */             {
/*      */ 
/*  583 */               if (!hasName) {
/*  584 */                 visible = false;
/*  585 */                 if (transientAsIgnoral) {
/*  586 */                   ignored = true;
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  595 */             if ((!pruneFinalFields) || (pn != null) || (ignored) || 
/*  596 */               (!Modifier.isFinal(f.getModifiers())))
/*      */             {
/*      */ 
/*  599 */               _property(props, implName).addField(f, pn, nameExplicit, visible, ignored);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void _addCreators(Map<String, POJOPropertyBuilder> props)
/*      */   {
/*  609 */     if (!this._useAnnotations) {
/*  610 */       return;
/*      */     }
/*  612 */     for (AnnotatedConstructor ctor : this._classDef.getConstructors()) {
/*  613 */       if (this._creatorProperties == null) {
/*  614 */         this._creatorProperties = new LinkedList();
/*      */       }
/*  616 */       int i = 0; for (int len = ctor.getParameterCount(); i < len; i++) {
/*  617 */         _addCreatorParam(props, ctor.getParameter(i));
/*      */       }
/*      */     }
/*  620 */     for (AnnotatedMethod factory : this._classDef.getFactoryMethods()) {
/*  621 */       if (this._creatorProperties == null) {
/*  622 */         this._creatorProperties = new LinkedList();
/*      */       }
/*  624 */       int i = 0; for (int len = factory.getParameterCount(); i < len; i++) {
/*  625 */         _addCreatorParam(props, factory.getParameter(i));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _addCreatorParam(Map<String, POJOPropertyBuilder> props, AnnotatedParameter param)
/*      */   {
/*  637 */     String impl = this._annotationIntrospector.findImplicitPropertyName(param);
/*  638 */     if (impl == null) {
/*  639 */       impl = "";
/*      */     }
/*  641 */     PropertyName pn = this._annotationIntrospector.findNameForDeserialization(param);
/*  642 */     boolean expl = (pn != null) && (!pn.isEmpty());
/*  643 */     if (!expl) {
/*  644 */       if (impl.isEmpty())
/*      */       {
/*      */ 
/*  647 */         return;
/*      */       }
/*      */       
/*  650 */       JsonCreator.Mode creatorMode = this._annotationIntrospector.findCreatorAnnotation(this._config, param
/*  651 */         .getOwner());
/*  652 */       if ((creatorMode == null) || (creatorMode == JsonCreator.Mode.DISABLED)) {
/*  653 */         return;
/*      */       }
/*  655 */       pn = PropertyName.construct(impl);
/*      */     }
/*      */     
/*      */ 
/*  659 */     impl = _checkRenameByField(impl);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  669 */     POJOPropertyBuilder prop = (expl) && (impl.isEmpty()) ? _property(props, pn) : _property(props, impl);
/*  670 */     prop.addCtor(param, pn, expl, true, false);
/*  671 */     this._creatorProperties.add(prop);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _addMethods(Map<String, POJOPropertyBuilder> props)
/*      */   {
/*  679 */     for (AnnotatedMethod m : this._classDef.memberMethods())
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  685 */       int argCount = m.getParameterCount();
/*  686 */       if (argCount == 0) {
/*  687 */         _addGetterMethod(props, m, this._annotationIntrospector);
/*  688 */       } else if (argCount == 1) {
/*  689 */         _addSetterMethod(props, m, this._annotationIntrospector);
/*  690 */       } else if ((argCount == 2) && 
/*  691 */         (Boolean.TRUE.equals(this._annotationIntrospector.hasAnySetter(m)))) {
/*  692 */         if (this._anySetters == null) {
/*  693 */           this._anySetters = new LinkedList();
/*      */         }
/*  695 */         this._anySetters.add(m);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _addGetterMethod(Map<String, POJOPropertyBuilder> props, AnnotatedMethod m, AnnotationIntrospector ai)
/*      */   {
/*  707 */     Class<?> rt = m.getRawReturnType();
/*  708 */     if ((rt == Void.TYPE) || ((rt == Void.class) && 
/*  709 */       (!this._config.isEnabled(MapperFeature.ALLOW_VOID_VALUED_PROPERTIES)))) {
/*  710 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  716 */     if (Boolean.TRUE.equals(ai.hasAnyGetter(m))) {
/*  717 */       if (this._anyGetters == null) {
/*  718 */         this._anyGetters = new LinkedList();
/*      */       }
/*  720 */       this._anyGetters.add(m);
/*  721 */       return;
/*      */     }
/*      */     
/*  724 */     if (Boolean.TRUE.equals(ai.hasAsKey(this._config, m))) {
/*  725 */       if (this._jsonKeyAccessors == null) {
/*  726 */         this._jsonKeyAccessors = new LinkedList();
/*      */       }
/*  728 */       this._jsonKeyAccessors.add(m);
/*  729 */       return;
/*      */     }
/*      */     
/*  732 */     if (Boolean.TRUE.equals(ai.hasAsValue(m))) {
/*  733 */       if (this._jsonValueAccessors == null) {
/*  734 */         this._jsonValueAccessors = new LinkedList();
/*      */       }
/*  736 */       this._jsonValueAccessors.add(m);
/*  737 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  742 */     PropertyName pn = ai.findNameForSerialization(m);
/*  743 */     boolean nameExplicit = pn != null;
/*      */     boolean visible;
/*  745 */     boolean visible; if (!nameExplicit) {
/*  746 */       String implName = ai.findImplicitPropertyName(m);
/*  747 */       if (implName == null)
/*  748 */         implName = this._accessorNaming.findNameForRegularGetter(m, m.getName());
/*      */       boolean visible;
/*  750 */       if (implName == null) {
/*  751 */         implName = this._accessorNaming.findNameForIsGetter(m, m.getName());
/*  752 */         if (implName == null) {
/*  753 */           return;
/*      */         }
/*  755 */         visible = this._visibilityChecker.isIsGetterVisible(m);
/*      */       } else {
/*  757 */         visible = this._visibilityChecker.isGetterVisible(m);
/*      */       }
/*      */     }
/*      */     else {
/*  761 */       implName = ai.findImplicitPropertyName(m);
/*  762 */       if (implName == null) {
/*  763 */         implName = this._accessorNaming.findNameForRegularGetter(m, m.getName());
/*  764 */         if (implName == null) {
/*  765 */           implName = this._accessorNaming.findNameForIsGetter(m, m.getName());
/*      */         }
/*      */       }
/*      */       
/*  769 */       if (implName == null) {
/*  770 */         implName = m.getName();
/*      */       }
/*  772 */       if (pn.isEmpty())
/*      */       {
/*  774 */         pn = _propNameFromSimple(implName);
/*  775 */         nameExplicit = false;
/*      */       }
/*  777 */       visible = true;
/*      */     }
/*      */     
/*  780 */     String implName = _checkRenameByField(implName);
/*  781 */     boolean ignore = ai.hasIgnoreMarker(m);
/*  782 */     _property(props, implName).addGetter(m, pn, nameExplicit, visible, ignore);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _addSetterMethod(Map<String, POJOPropertyBuilder> props, AnnotatedMethod m, AnnotationIntrospector ai)
/*      */   {
/*  790 */     PropertyName pn = ai.findNameForDeserialization(m);
/*  791 */     boolean nameExplicit = pn != null;
/*  792 */     boolean visible; boolean visible; if (!nameExplicit) {
/*  793 */       String implName = ai.findImplicitPropertyName(m);
/*  794 */       if (implName == null) {
/*  795 */         implName = this._accessorNaming.findNameForMutator(m, m.getName());
/*      */       }
/*  797 */       if (implName == null) {
/*  798 */         return;
/*      */       }
/*  800 */       visible = this._visibilityChecker.isSetterVisible(m);
/*      */     }
/*      */     else {
/*  803 */       implName = ai.findImplicitPropertyName(m);
/*  804 */       if (implName == null) {
/*  805 */         implName = this._accessorNaming.findNameForMutator(m, m.getName());
/*      */       }
/*      */       
/*  808 */       if (implName == null) {
/*  809 */         implName = m.getName();
/*      */       }
/*  811 */       if (pn.isEmpty())
/*      */       {
/*  813 */         pn = _propNameFromSimple(implName);
/*  814 */         nameExplicit = false;
/*      */       }
/*  816 */       visible = true;
/*      */     }
/*      */     
/*  819 */     String implName = _checkRenameByField(implName);
/*  820 */     boolean ignore = ai.hasIgnoreMarker(m);
/*  821 */     _property(props, implName)
/*  822 */       .addSetter(m, pn, nameExplicit, visible, ignore);
/*      */   }
/*      */   
/*      */ 
/*      */   protected void _addInjectables(Map<String, POJOPropertyBuilder> props)
/*      */   {
/*  828 */     for (AnnotatedField f : this._classDef.fields()) {
/*  829 */       _doAddInjectable(this._annotationIntrospector.findInjectableValue(f), f);
/*      */     }
/*      */     
/*  832 */     for (AnnotatedMethod m : this._classDef.memberMethods())
/*      */     {
/*  834 */       if (m.getParameterCount() == 1)
/*      */       {
/*      */ 
/*  837 */         _doAddInjectable(this._annotationIntrospector.findInjectableValue(m), m);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected void _doAddInjectable(JacksonInject.Value injectable, AnnotatedMember m) {
/*  843 */     if (injectable == null) {
/*  844 */       return;
/*      */     }
/*  846 */     Object id = injectable.getId();
/*  847 */     if (this._injectables == null) {
/*  848 */       this._injectables = new LinkedHashMap();
/*      */     }
/*  850 */     AnnotatedMember prev = (AnnotatedMember)this._injectables.put(id, m);
/*  851 */     if (prev != null)
/*      */     {
/*  853 */       if (prev.getClass() == m.getClass()) {
/*  854 */         String type = id.getClass().getName();
/*  855 */         throw new IllegalArgumentException("Duplicate injectable value with id '" + id + "' (of type " + type + ")");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private PropertyName _propNameFromSimple(String simpleName)
/*      */   {
/*  862 */     return PropertyName.construct(simpleName, null);
/*      */   }
/*      */   
/*      */   private String _checkRenameByField(String implName)
/*      */   {
/*  867 */     if (this._fieldRenameMappings != null) {
/*  868 */       PropertyName p = (PropertyName)this._fieldRenameMappings.get(_propNameFromSimple(implName));
/*  869 */       if (p != null) {
/*  870 */         implName = p.getSimpleName();
/*  871 */         return implName;
/*      */       }
/*      */     }
/*      */     
/*  875 */     return implName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _removeUnwantedProperties(Map<String, POJOPropertyBuilder> props)
/*      */   {
/*  890 */     Iterator<POJOPropertyBuilder> it = props.values().iterator();
/*  891 */     while (it.hasNext()) {
/*  892 */       POJOPropertyBuilder prop = (POJOPropertyBuilder)it.next();
/*      */       
/*      */ 
/*  895 */       if (!prop.anyVisible()) {
/*  896 */         it.remove();
/*      */ 
/*      */ 
/*      */       }
/*  900 */       else if (prop.anyIgnorals())
/*      */       {
/*  902 */         if (!prop.isExplicitlyIncluded()) {
/*  903 */           it.remove();
/*  904 */           _collectIgnorals(prop.getName());
/*      */         }
/*      */         else
/*      */         {
/*  908 */           prop.removeIgnored();
/*  909 */           if (!prop.couldDeserialize()) {
/*  910 */             _collectIgnorals(prop.getName());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _removeUnwantedAccessor(Map<String, POJOPropertyBuilder> props)
/*      */   {
/*  923 */     boolean inferMutators = this._config.isEnabled(MapperFeature.INFER_PROPERTY_MUTATORS);
/*  924 */     Iterator<POJOPropertyBuilder> it = props.values().iterator();
/*      */     
/*  926 */     while (it.hasNext()) {
/*  927 */       POJOPropertyBuilder prop = (POJOPropertyBuilder)it.next();
/*      */       
/*      */ 
/*      */ 
/*  931 */       prop.removeNonVisible(inferMutators, this._forSerialization ? null : this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _collectIgnorals(String name)
/*      */   {
/*  942 */     if ((!this._forSerialization) && (name != null)) {
/*  943 */       if (this._ignoredPropertyNames == null) {
/*  944 */         this._ignoredPropertyNames = new HashSet();
/*      */       }
/*  946 */       this._ignoredPropertyNames.add(name);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _renameProperties(Map<String, POJOPropertyBuilder> props)
/*      */   {
/*  959 */     Iterator<Map.Entry<String, POJOPropertyBuilder>> it = props.entrySet().iterator();
/*  960 */     LinkedList<POJOPropertyBuilder> renamed = null;
/*  961 */     Map.Entry<String, POJOPropertyBuilder> entry; while (it.hasNext()) {
/*  962 */       entry = (Map.Entry)it.next();
/*  963 */       POJOPropertyBuilder prop = (POJOPropertyBuilder)entry.getValue();
/*      */       
/*  965 */       Collection<PropertyName> l = prop.findExplicitNames();
/*      */       
/*      */ 
/*  968 */       if (!l.isEmpty())
/*      */       {
/*      */ 
/*  971 */         it.remove();
/*  972 */         if (renamed == null) {
/*  973 */           renamed = new LinkedList();
/*      */         }
/*      */         
/*  976 */         if (l.size() == 1) {
/*  977 */           PropertyName n = (PropertyName)l.iterator().next();
/*  978 */           renamed.add(prop.withName(n));
/*      */         }
/*      */         else
/*      */         {
/*  982 */           renamed.addAll(prop.explode(l));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  998 */     if (renamed != null) {
/*  999 */       for (POJOPropertyBuilder prop : renamed) {
/* 1000 */         String name = prop.getName();
/* 1001 */         POJOPropertyBuilder old = (POJOPropertyBuilder)props.get(name);
/* 1002 */         if (old == null) {
/* 1003 */           props.put(name, prop);
/*      */         } else {
/* 1005 */           old.addAll(prop);
/*      */         }
/*      */         
/* 1008 */         if (_replaceCreatorProperty(prop, this._creatorProperties))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1019 */           if (this._ignoredPropertyNames != null) {
/* 1020 */             this._ignoredPropertyNames.remove(name);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected void _renameUsing(Map<String, POJOPropertyBuilder> propMap, PropertyNamingStrategy naming)
/*      */   {
/* 1030 */     POJOPropertyBuilder[] props = (POJOPropertyBuilder[])propMap.values().toArray(new POJOPropertyBuilder[propMap.size()]);
/* 1031 */     propMap.clear();
/* 1032 */     for (POJOPropertyBuilder prop : props) {
/* 1033 */       PropertyName fullName = prop.getFullName();
/* 1034 */       String rename = null;
/*      */       
/*      */ 
/* 1037 */       if ((!prop.isExplicitlyNamed()) || (this._config.isEnabled(MapperFeature.ALLOW_EXPLICIT_PROPERTY_RENAMING))) {
/* 1038 */         if (this._forSerialization) {
/* 1039 */           if (prop.hasGetter()) {
/* 1040 */             rename = naming.nameForGetterMethod(this._config, prop.getGetter(), fullName.getSimpleName());
/* 1041 */           } else if (prop.hasField()) {
/* 1042 */             rename = naming.nameForField(this._config, prop.getField(), fullName.getSimpleName());
/*      */           }
/*      */         }
/* 1045 */         else if (prop.hasSetter()) {
/* 1046 */           rename = naming.nameForSetterMethod(this._config, prop.getSetter(), fullName.getSimpleName());
/* 1047 */         } else if (prop.hasConstructorParameter()) {
/* 1048 */           rename = naming.nameForConstructorParameter(this._config, prop.getConstructorParameter(), fullName.getSimpleName());
/* 1049 */         } else if (prop.hasField()) {
/* 1050 */           rename = naming.nameForField(this._config, prop.getField(), fullName.getSimpleName());
/* 1051 */         } else if (prop.hasGetter())
/*      */         {
/*      */ 
/* 1054 */           rename = naming.nameForGetterMethod(this._config, prop.getGetter(), fullName.getSimpleName());
/*      */         }
/*      */       }
/*      */       String simpleName;
/*      */       String simpleName;
/* 1059 */       if ((rename != null) && (!fullName.hasSimpleName(rename))) {
/* 1060 */         prop = prop.withSimpleName(rename);
/* 1061 */         simpleName = rename;
/*      */       } else {
/* 1063 */         simpleName = fullName.getSimpleName();
/*      */       }
/*      */       
/* 1066 */       POJOPropertyBuilder old = (POJOPropertyBuilder)propMap.get(simpleName);
/* 1067 */       if (old == null) {
/* 1068 */         propMap.put(simpleName, prop);
/*      */       } else {
/* 1070 */         old.addAll(prop);
/*      */       }
/*      */       
/*      */ 
/* 1074 */       _replaceCreatorProperty(prop, this._creatorProperties);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void _renameWithWrappers(Map<String, POJOPropertyBuilder> props)
/*      */   {
/* 1082 */     Iterator<Map.Entry<String, POJOPropertyBuilder>> it = props.entrySet().iterator();
/* 1083 */     LinkedList<POJOPropertyBuilder> renamed = null;
/* 1084 */     Map.Entry<String, POJOPropertyBuilder> entry; while (it.hasNext()) {
/* 1085 */       entry = (Map.Entry)it.next();
/* 1086 */       POJOPropertyBuilder prop = (POJOPropertyBuilder)entry.getValue();
/* 1087 */       AnnotatedMember member = prop.getPrimaryMember();
/* 1088 */       if (member != null)
/*      */       {
/*      */ 
/* 1091 */         PropertyName wrapperName = this._annotationIntrospector.findWrapperName(member);
/*      */         
/*      */ 
/*      */ 
/* 1095 */         if ((wrapperName != null) && (wrapperName.hasSimpleName()))
/*      */         {
/*      */ 
/* 1098 */           if (!wrapperName.equals(prop.getFullName())) {
/* 1099 */             if (renamed == null) {
/* 1100 */               renamed = new LinkedList();
/*      */             }
/* 1102 */             prop = prop.withName(wrapperName);
/* 1103 */             renamed.add(prop);
/* 1104 */             it.remove();
/*      */           } }
/*      */       }
/*      */     }
/* 1108 */     if (renamed != null) {
/* 1109 */       for (POJOPropertyBuilder prop : renamed) {
/* 1110 */         String name = prop.getName();
/* 1111 */         POJOPropertyBuilder old = (POJOPropertyBuilder)props.get(name);
/* 1112 */         if (old == null) {
/* 1113 */           props.put(name, prop);
/*      */         } else {
/* 1115 */           old.addAll(prop);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void _sortProperties(Map<String, POJOPropertyBuilder> props)
/*      */   {
/* 1134 */     AnnotationIntrospector intr = this._annotationIntrospector;
/* 1135 */     Boolean alpha = intr.findSerializationSortAlphabetically(this._classDef);
/*      */     
/*      */ 
/* 1138 */     boolean sortAlpha = alpha == null ? this._config.shouldSortPropertiesAlphabetically() : alpha.booleanValue();
/* 1139 */     boolean indexed = _anyIndexed(props.values());
/*      */     
/* 1141 */     String[] propertyOrder = intr.findSerializationPropertyOrder(this._classDef);
/*      */     
/*      */ 
/* 1144 */     if ((!sortAlpha) && (!indexed) && (this._creatorProperties == null) && (propertyOrder == null)) {
/* 1145 */       return;
/*      */     }
/* 1147 */     int size = props.size();
/*      */     Map<String, POJOPropertyBuilder> all;
/*      */     Map<String, POJOPropertyBuilder> all;
/* 1150 */     if (sortAlpha) {
/* 1151 */       all = new TreeMap();
/*      */     } else {
/* 1153 */       all = new LinkedHashMap(size + size);
/*      */     }
/*      */     
/* 1156 */     for (Iterator localIterator1 = props.values().iterator(); localIterator1.hasNext();) { prop = (POJOPropertyBuilder)localIterator1.next();
/* 1157 */       all.put(prop.getName(), prop); }
/*      */     POJOPropertyBuilder prop;
/* 1159 */     Object ordered = new LinkedHashMap(size + size);
/*      */     
/* 1161 */     if (propertyOrder != null) {
/* 1162 */       for (String name : propertyOrder) {
/* 1163 */         POJOPropertyBuilder w = (POJOPropertyBuilder)all.remove(name);
/* 1164 */         if (w == null) {
/* 1165 */           for (POJOPropertyBuilder prop : props.values()) {
/* 1166 */             if (name.equals(prop.getInternalName())) {
/* 1167 */               w = prop;
/*      */               
/* 1169 */               name = prop.getName();
/* 1170 */               break;
/*      */             }
/*      */           }
/*      */         }
/* 1174 */         if (w != null) {
/* 1175 */           ((Map)ordered).put(name, w);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     Object entry;
/* 1181 */     if (indexed) {
/* 1182 */       Map<Integer, POJOPropertyBuilder> byIndex = new TreeMap();
/* 1183 */       Object it = all.entrySet().iterator();
/* 1184 */       while (((Iterator)it).hasNext()) {
/* 1185 */         entry = (Map.Entry)((Iterator)it).next();
/* 1186 */         POJOPropertyBuilder prop = (POJOPropertyBuilder)((Map.Entry)entry).getValue();
/* 1187 */         Integer index = prop.getMetadata().getIndex();
/* 1188 */         if (index != null) {
/* 1189 */           byIndex.put(index, prop);
/* 1190 */           ((Iterator)it).remove();
/*      */         }
/*      */       }
/* 1193 */       for (entry = byIndex.values().iterator(); ((Iterator)entry).hasNext();) { POJOPropertyBuilder prop = (POJOPropertyBuilder)((Iterator)entry).next();
/* 1194 */         ((Map)ordered).put(prop.getName(), prop);
/*      */       }
/*      */     }
/*      */     
/*      */     Object sorted;
/*      */     
/* 1200 */     if ((this._creatorProperties != null) && ((!sortAlpha) || 
/* 1201 */       (this._config.isEnabled(MapperFeature.SORT_CREATOR_PROPERTIES_FIRST))))
/*      */     {
/*      */       Collection<POJOPropertyBuilder> cr;
/*      */       
/*      */ 
/*      */       Collection<POJOPropertyBuilder> cr;
/*      */       
/* 1208 */       if (sortAlpha) {
/* 1209 */         sorted = new TreeMap();
/*      */         
/* 1211 */         for (entry = this._creatorProperties.iterator(); ((Iterator)entry).hasNext();) { POJOPropertyBuilder prop = (POJOPropertyBuilder)((Iterator)entry).next();
/* 1212 */           ((TreeMap)sorted).put(prop.getName(), prop);
/*      */         }
/* 1214 */         cr = ((TreeMap)sorted).values();
/*      */       } else {
/* 1216 */         cr = this._creatorProperties;
/*      */       }
/* 1218 */       for (sorted = cr.iterator(); ((Iterator)sorted).hasNext();) { POJOPropertyBuilder prop = (POJOPropertyBuilder)((Iterator)sorted).next();
/*      */         
/*      */ 
/* 1221 */         String name = prop.getName();
/*      */         
/*      */ 
/* 1224 */         if (all.containsKey(name)) {
/* 1225 */           ((Map)ordered).put(name, prop);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1230 */     ((Map)ordered).putAll(all);
/* 1231 */     props.clear();
/* 1232 */     props.putAll((Map)ordered);
/*      */   }
/*      */   
/*      */   private boolean _anyIndexed(Collection<POJOPropertyBuilder> props) {
/* 1236 */     for (POJOPropertyBuilder prop : props) {
/* 1237 */       if (prop.getMetadata().hasIndex()) {
/* 1238 */         return true;
/*      */       }
/*      */     }
/* 1241 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void reportProblem(String msg, Object... args)
/*      */   {
/* 1251 */     if (args.length > 0) {
/* 1252 */       msg = String.format(msg, args);
/*      */     }
/* 1254 */     throw new IllegalArgumentException("Problem with definition of " + this._classDef + ": " + msg);
/*      */   }
/*      */   
/*      */   protected POJOPropertyBuilder _property(Map<String, POJOPropertyBuilder> props, PropertyName name)
/*      */   {
/* 1259 */     String simpleName = name.getSimpleName();
/* 1260 */     POJOPropertyBuilder prop = (POJOPropertyBuilder)props.get(simpleName);
/* 1261 */     if (prop == null) {
/* 1262 */       prop = new POJOPropertyBuilder(this._config, this._annotationIntrospector, this._forSerialization, name);
/*      */       
/* 1264 */       props.put(simpleName, prop);
/*      */     }
/* 1266 */     return prop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected POJOPropertyBuilder _property(Map<String, POJOPropertyBuilder> props, String implName)
/*      */   {
/* 1273 */     POJOPropertyBuilder prop = (POJOPropertyBuilder)props.get(implName);
/* 1274 */     if (prop == null)
/*      */     {
/* 1276 */       prop = new POJOPropertyBuilder(this._config, this._annotationIntrospector, this._forSerialization, PropertyName.construct(implName));
/* 1277 */       props.put(implName, prop);
/*      */     }
/* 1279 */     return prop;
/*      */   }
/*      */   
/*      */   private PropertyNamingStrategy _findNamingStrategy()
/*      */   {
/* 1284 */     Object namingDef = this._annotationIntrospector.findNamingStrategy(this._classDef);
/* 1285 */     if (namingDef == null) {
/* 1286 */       return this._config.getPropertyNamingStrategy();
/*      */     }
/* 1288 */     if ((namingDef instanceof PropertyNamingStrategy)) {
/* 1289 */       return (PropertyNamingStrategy)namingDef;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1294 */     if (!(namingDef instanceof Class))
/*      */     {
/* 1296 */       throw new IllegalStateException("AnnotationIntrospector returned PropertyNamingStrategy definition of type " + namingDef.getClass().getName() + "; expected type PropertyNamingStrategy or Class<PropertyNamingStrategy> instead");
/*      */     }
/* 1298 */     Class<?> namingClass = (Class)namingDef;
/*      */     
/* 1300 */     if (namingClass == PropertyNamingStrategy.class) {
/* 1301 */       return null;
/*      */     }
/*      */     
/* 1304 */     if (!PropertyNamingStrategy.class.isAssignableFrom(namingClass))
/*      */     {
/* 1306 */       throw new IllegalStateException("AnnotationIntrospector returned Class " + namingClass.getName() + "; expected Class<PropertyNamingStrategy>");
/*      */     }
/* 1308 */     HandlerInstantiator hi = this._config.getHandlerInstantiator();
/* 1309 */     if (hi != null) {
/* 1310 */       PropertyNamingStrategy pns = hi.namingStrategyInstance(this._config, this._classDef, namingClass);
/* 1311 */       if (pns != null) {
/* 1312 */         return pns;
/*      */       }
/*      */     }
/* 1315 */     return (PropertyNamingStrategy)ClassUtil.createInstance(namingClass, this._config
/* 1316 */       .canOverrideAccessModifiers());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected void _updateCreatorProperty(POJOPropertyBuilder prop, List<POJOPropertyBuilder> creatorProperties) {
/* 1321 */     _replaceCreatorProperty(prop, creatorProperties);
/*      */   }
/*      */   
/*      */   protected boolean _replaceCreatorProperty(POJOPropertyBuilder prop, List<POJOPropertyBuilder> creatorProperties) {
/* 1325 */     if (creatorProperties != null) {
/* 1326 */       String intName = prop.getInternalName();
/* 1327 */       int i = 0; for (int len = creatorProperties.size(); i < len; i++) {
/* 1328 */         if (((POJOPropertyBuilder)creatorProperties.get(i)).getInternalName().equals(intName)) {
/* 1329 */           creatorProperties.set(i, prop);
/* 1330 */           return true;
/*      */         }
/*      */       }
/*      */     }
/* 1334 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\introspect\POJOPropertiesCollector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */