/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.std.StdDelegatingDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaUtilCollectionsDeserializers
/*     */ {
/*     */   private static final int TYPE_SINGLETON_SET = 1;
/*     */   private static final int TYPE_SINGLETON_LIST = 2;
/*     */   private static final int TYPE_SINGLETON_MAP = 3;
/*     */   private static final int TYPE_UNMODIFIABLE_SET = 4;
/*     */   private static final int TYPE_UNMODIFIABLE_LIST = 5;
/*     */   private static final int TYPE_UNMODIFIABLE_MAP = 6;
/*     */   private static final int TYPE_SYNC_SET = 7;
/*     */   private static final int TYPE_SYNC_COLLECTION = 8;
/*     */   private static final int TYPE_SYNC_LIST = 9;
/*     */   private static final int TYPE_SYNC_MAP = 10;
/*     */   public static final int TYPE_AS_LIST = 11;
/*     */   private static final String PREFIX_JAVA_UTIL_COLLECTIONS = "java.util.Collections$";
/*  40 */   private static final Class<?> CLASS_AS_ARRAYS_LIST = Arrays.asList(new Object[] { null, null }).getClass();
/*     */   
/*     */   private static final Class<?> CLASS_SINGLETON_SET;
/*     */   
/*     */   private static final Class<?> CLASS_SINGLETON_LIST;
/*     */   
/*     */   private static final Class<?> CLASS_SINGLETON_MAP;
/*     */   
/*     */   private static final Class<?> CLASS_UNMODIFIABLE_SET;
/*     */   private static final Class<?> CLASS_UNMODIFIABLE_LIST;
/*     */   private static final Class<?> CLASS_UNMODIFIABLE_LIST_ALIAS;
/*     */   private static final Class<?> CLASS_UNMODIFIABLE_MAP;
/*     */   
/*     */   static
/*     */   {
/*  55 */     Set<?> set = Collections.singleton(Boolean.TRUE);
/*  56 */     CLASS_SINGLETON_SET = set.getClass();
/*  57 */     CLASS_UNMODIFIABLE_SET = Collections.unmodifiableSet(set).getClass();
/*     */     
/*  59 */     List<?> list = Collections.singletonList(Boolean.TRUE);
/*  60 */     CLASS_SINGLETON_LIST = list.getClass();
/*  61 */     CLASS_UNMODIFIABLE_LIST = Collections.unmodifiableList(list).getClass();
/*     */     
/*  63 */     CLASS_UNMODIFIABLE_LIST_ALIAS = Collections.unmodifiableList(new LinkedList()).getClass();
/*     */     
/*  65 */     Map<?, ?> map = Collections.singletonMap("a", "b");
/*  66 */     CLASS_SINGLETON_MAP = map.getClass();
/*  67 */     CLASS_UNMODIFIABLE_MAP = Collections.unmodifiableMap(map).getClass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static JsonDeserializer<?> findForCollection(DeserializationContext ctxt, JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/*     */     JavaUtilCollectionsConverter conv;
/*     */     
/*  77 */     if (type.hasRawClass(CLASS_AS_ARRAYS_LIST)) {
/*  78 */       conv = converter(11, type, List.class); } else { JavaUtilCollectionsConverter conv;
/*  79 */       if (type.hasRawClass(CLASS_SINGLETON_LIST)) {
/*  80 */         conv = converter(2, type, List.class); } else { JavaUtilCollectionsConverter conv;
/*  81 */         if (type.hasRawClass(CLASS_SINGLETON_SET)) {
/*  82 */           conv = converter(1, type, Set.class);
/*     */         } else { JavaUtilCollectionsConverter conv;
/*  84 */           if ((type.hasRawClass(CLASS_UNMODIFIABLE_LIST)) || (type.hasRawClass(CLASS_UNMODIFIABLE_LIST_ALIAS))) {
/*  85 */             conv = converter(5, type, List.class); } else { JavaUtilCollectionsConverter conv;
/*  86 */             if (type.hasRawClass(CLASS_UNMODIFIABLE_SET)) {
/*  87 */               conv = converter(4, type, Set.class);
/*     */             } else {
/*  89 */               String utilName = _findUtilSyncTypeName(type.getRawClass());
/*     */               JavaUtilCollectionsConverter conv;
/*  91 */               if (utilName.endsWith("Set")) {
/*  92 */                 conv = converter(7, type, Set.class); } else { JavaUtilCollectionsConverter conv;
/*  93 */                 if (utilName.endsWith("List")) {
/*  94 */                   conv = converter(9, type, List.class); } else { JavaUtilCollectionsConverter conv;
/*  95 */                   if (utilName.endsWith("Collection")) {
/*  96 */                     conv = converter(8, type, Collection.class);
/*     */                   } else
/*  98 */                     return null;
/*     */                 } } } } } } }
/*     */     JavaUtilCollectionsConverter conv;
/* 101 */     return new StdDelegatingDeserializer(conv);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static JsonDeserializer<?> findForMap(DeserializationContext ctxt, JavaType type)
/*     */     throws JsonMappingException
/*     */   {
/*     */     JavaUtilCollectionsConverter conv;
/*     */     
/* 111 */     if (type.hasRawClass(CLASS_SINGLETON_MAP)) {
/* 112 */       conv = converter(3, type, Map.class); } else { JavaUtilCollectionsConverter conv;
/* 113 */       if (type.hasRawClass(CLASS_UNMODIFIABLE_MAP)) {
/* 114 */         conv = converter(6, type, Map.class);
/*     */       } else {
/* 116 */         String utilName = _findUtilSyncTypeName(type.getRawClass());
/*     */         JavaUtilCollectionsConverter conv;
/* 118 */         if (utilName.endsWith("Map")) {
/* 119 */           conv = converter(10, type, Map.class);
/*     */         } else
/* 121 */           return null;
/*     */       } }
/*     */     JavaUtilCollectionsConverter conv;
/* 124 */     return new StdDelegatingDeserializer(conv);
/*     */   }
/*     */   
/*     */ 
/*     */   static JavaUtilCollectionsConverter converter(int kind, JavaType concreteType, Class<?> rawSuper)
/*     */   {
/* 130 */     return new JavaUtilCollectionsConverter(kind, concreteType.findSuperType(rawSuper));
/*     */   }
/*     */   
/*     */   private static String _findUtilSyncTypeName(Class<?> raw) {
/* 134 */     String clsName = _findUtilCollectionsTypeName(raw);
/* 135 */     if ((clsName != null) && 
/* 136 */       (clsName.startsWith("Synchronized"))) {
/* 137 */       return clsName.substring(12);
/*     */     }
/*     */     
/* 140 */     return "";
/*     */   }
/*     */   
/*     */   private static String _findUtilCollectionsTypeName(Class<?> raw) {
/* 144 */     String clsName = raw.getName();
/* 145 */     if (clsName.startsWith("java.util.Collections$")) {
/* 146 */       return clsName.substring("java.util.Collections$".length());
/*     */     }
/* 148 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class JavaUtilCollectionsConverter
/*     */     implements Converter<Object, Object>
/*     */   {
/*     */     private final JavaType _inputType;
/*     */     
/*     */     private final int _kind;
/*     */     
/*     */ 
/*     */     JavaUtilCollectionsConverter(int kind, JavaType inputType)
/*     */     {
/* 163 */       this._inputType = inputType;
/* 164 */       this._kind = kind;
/*     */     }
/*     */     
/*     */     public Object convert(Object value)
/*     */     {
/* 169 */       if (value == null) {
/* 170 */         return null;
/*     */       }
/*     */       
/* 173 */       switch (this._kind)
/*     */       {
/*     */       case 1: 
/* 176 */         Set<?> set = (Set)value;
/* 177 */         _checkSingleton(set.size());
/* 178 */         return Collections.singleton(set.iterator().next());
/*     */       
/*     */ 
/*     */       case 2: 
/* 182 */         List<?> list = (List)value;
/* 183 */         _checkSingleton(list.size());
/* 184 */         return Collections.singletonList(list.get(0));
/*     */       
/*     */ 
/*     */       case 3: 
/* 188 */         Map<?, ?> map = (Map)value;
/* 189 */         _checkSingleton(map.size());
/* 190 */         Map.Entry<?, ?> entry = (Map.Entry)map.entrySet().iterator().next();
/* 191 */         return Collections.singletonMap(entry.getKey(), entry.getValue());
/*     */       
/*     */ 
/*     */       case 4: 
/* 195 */         return Collections.unmodifiableSet((Set)value);
/*     */       case 5: 
/* 197 */         return Collections.unmodifiableList((List)value);
/*     */       case 6: 
/* 199 */         return Collections.unmodifiableMap((Map)value);
/*     */       
/*     */       case 7: 
/* 202 */         return Collections.synchronizedSet((Set)value);
/*     */       case 9: 
/* 204 */         return Collections.synchronizedList((List)value);
/*     */       case 8: 
/* 206 */         return Collections.synchronizedCollection((Collection)value);
/*     */       case 10: 
/* 208 */         return Collections.synchronizedMap((Map)value);
/*     */       }
/*     */       
/*     */       
/*     */ 
/* 213 */       return value;
/*     */     }
/*     */     
/*     */ 
/*     */     public JavaType getInputType(TypeFactory typeFactory)
/*     */     {
/* 219 */       return this._inputType;
/*     */     }
/*     */     
/*     */ 
/*     */     public JavaType getOutputType(TypeFactory typeFactory)
/*     */     {
/* 225 */       return this._inputType;
/*     */     }
/*     */     
/*     */     private void _checkSingleton(int size) {
/* 229 */       if (size != 1)
/*     */       {
/* 231 */         throw new IllegalArgumentException("Can not deserialize Singleton container from " + size + " entries");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\impl\JavaUtilCollectionsDeserializers.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */