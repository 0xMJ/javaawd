/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MissingNode
/*     */   extends ValueNode
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  27 */   private static final MissingNode instance = new MissingNode();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object readResolve()
/*     */   {
/*  38 */     return instance;
/*     */   }
/*     */   
/*     */   public boolean isMissingNode()
/*     */   {
/*  43 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  49 */   public <T extends JsonNode> T deepCopy() { return this; }
/*     */   
/*  51 */   public static MissingNode getInstance() { return instance; }
/*     */   
/*     */ 
/*     */   public JsonNodeType getNodeType()
/*     */   {
/*  56 */     return JsonNodeType.MISSING;
/*     */   }
/*     */   
/*  59 */   public JsonToken asToken() { return JsonToken.NOT_AVAILABLE; }
/*     */   
/*  61 */   public String asText() { return ""; }
/*     */   
/*  63 */   public String asText(String defaultValue) { return defaultValue; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void serialize(JsonGenerator g, SerializerProvider provider)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  90 */     g.writeNull();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void serializeWithType(JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException, JsonProcessingException
/*     */   {
/*  98 */     g.writeNull();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonNode require()
/*     */   {
/* 110 */     return (JsonNode)_reportRequiredViolation("require() called on `MissingNode`", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */   public JsonNode requireNonNull()
/*     */   {
/* 116 */     return (JsonNode)_reportRequiredViolation("requireNonNull() called on `MissingNode`", new Object[0]);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 121 */     return JsonNodeType.MISSING.ordinal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 134 */     return "";
/*     */   }
/*     */   
/*     */   public String toPrettyString()
/*     */   {
/* 139 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 151 */     return o == this;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\node\MissingNode.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */