/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.util.RawValue;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ContainerNode<T extends ContainerNode<T>>
/*     */   extends BaseJsonNode
/*     */   implements JsonNodeCreator
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JsonNodeFactory _nodeFactory;
/*     */   
/*     */   protected ContainerNode(JsonNodeFactory nc)
/*     */   {
/*  28 */     this._nodeFactory = nc;
/*     */   }
/*     */   
/*  31 */   protected ContainerNode() { this._nodeFactory = null; }
/*     */   
/*     */ 
/*     */ 
/*     */   public abstract JsonToken asToken();
/*     */   
/*     */ 
/*     */   public String asText()
/*     */   {
/*  40 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int size();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JsonNode get(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract JsonNode get(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final BooleanNode booleanNode(boolean v)
/*     */   {
/*  64 */     return this._nodeFactory.booleanNode(v);
/*     */   }
/*     */   
/*  67 */   public JsonNode missingNode() { return this._nodeFactory.missingNode(); }
/*     */   
/*     */   public final NullNode nullNode()
/*     */   {
/*  71 */     return this._nodeFactory.nullNode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final ArrayNode arrayNode()
/*     */   {
/*  84 */     return this._nodeFactory.arrayNode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final ArrayNode arrayNode(int capacity)
/*     */   {
/*  92 */     return this._nodeFactory.arrayNode(capacity);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final ObjectNode objectNode()
/*     */   {
/*  99 */     return this._nodeFactory.objectNode();
/*     */   }
/*     */   
/* 102 */   public final NumericNode numberNode(byte v) { return this._nodeFactory.numberNode(v); }
/*     */   
/* 104 */   public final NumericNode numberNode(short v) { return this._nodeFactory.numberNode(v); }
/*     */   
/* 106 */   public final NumericNode numberNode(int v) { return this._nodeFactory.numberNode(v); }
/*     */   
/*     */   public final NumericNode numberNode(long v) {
/* 109 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   
/*     */ 
/* 113 */   public final NumericNode numberNode(float v) { return this._nodeFactory.numberNode(v); }
/*     */   
/* 115 */   public final NumericNode numberNode(double v) { return this._nodeFactory.numberNode(v); }
/*     */   
/*     */ 
/* 118 */   public final ValueNode numberNode(BigInteger v) { return this._nodeFactory.numberNode(v); }
/*     */   
/* 120 */   public final ValueNode numberNode(BigDecimal v) { return this._nodeFactory.numberNode(v); }
/*     */   
/*     */ 
/* 123 */   public final ValueNode numberNode(Byte v) { return this._nodeFactory.numberNode(v); }
/*     */   
/* 125 */   public final ValueNode numberNode(Short v) { return this._nodeFactory.numberNode(v); }
/*     */   
/* 127 */   public final ValueNode numberNode(Integer v) { return this._nodeFactory.numberNode(v); }
/*     */   
/* 129 */   public final ValueNode numberNode(Long v) { return this._nodeFactory.numberNode(v); }
/*     */   
/*     */ 
/* 132 */   public final ValueNode numberNode(Float v) { return this._nodeFactory.numberNode(v); }
/*     */   
/* 134 */   public final ValueNode numberNode(Double v) { return this._nodeFactory.numberNode(v); }
/*     */   
/*     */   public final TextNode textNode(String text) {
/* 137 */     return this._nodeFactory.textNode(text);
/*     */   }
/*     */   
/* 140 */   public final BinaryNode binaryNode(byte[] data) { return this._nodeFactory.binaryNode(data); }
/*     */   
/* 142 */   public final BinaryNode binaryNode(byte[] data, int offset, int length) { return this._nodeFactory.binaryNode(data, offset, length); }
/*     */   
/*     */   public final ValueNode pojoNode(Object pojo) {
/* 145 */     return this._nodeFactory.pojoNode(pojo);
/*     */   }
/*     */   
/* 148 */   public final ValueNode rawValueNode(RawValue value) { return this._nodeFactory.rawValueNode(value); }
/*     */   
/*     */   public abstract T removeAll();
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\node\ContainerNode.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */