/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonPointer;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ValueNode
/*     */   extends BaseJsonNode
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   protected JsonNode _at(JsonPointer ptr)
/*     */   {
/*  28 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends JsonNode> T deepCopy()
/*     */   {
/*  37 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public abstract JsonToken asToken();
/*     */   
/*     */   public void serializeWithType(JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException
/*     */   {
/*  46 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  47 */       .typeId(this, asToken()));
/*  48 */     serialize(g, provider);
/*  49 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  59 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JsonNode get(int index)
/*     */   {
/*  68 */     return null;
/*     */   }
/*     */   
/*  71 */   public final JsonNode path(int index) { return MissingNode.getInstance(); }
/*     */   
/*     */   public final boolean has(int index) {
/*  74 */     return false;
/*     */   }
/*     */   
/*  77 */   public final boolean hasNonNull(int index) { return false; }
/*     */   
/*     */   public final JsonNode get(String fieldName) {
/*  80 */     return null;
/*     */   }
/*     */   
/*  83 */   public final JsonNode path(String fieldName) { return MissingNode.getInstance(); }
/*     */   
/*     */   public final boolean has(String fieldName) {
/*  86 */     return false;
/*     */   }
/*     */   
/*  89 */   public final boolean hasNonNull(String fieldName) { return false; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JsonNode findValue(String fieldName)
/*     */   {
/*  99 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public final ObjectNode findParent(String fieldName)
/*     */   {
/* 105 */     return null;
/*     */   }
/*     */   
/*     */   public final List<JsonNode> findValues(String fieldName, List<JsonNode> foundSoFar)
/*     */   {
/* 110 */     return foundSoFar;
/*     */   }
/*     */   
/*     */   public final List<String> findValuesAsText(String fieldName, List<String> foundSoFar)
/*     */   {
/* 115 */     return foundSoFar;
/*     */   }
/*     */   
/*     */   public final List<JsonNode> findParents(String fieldName, List<JsonNode> foundSoFar)
/*     */   {
/* 120 */     return foundSoFar;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\node\ValueNode.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */