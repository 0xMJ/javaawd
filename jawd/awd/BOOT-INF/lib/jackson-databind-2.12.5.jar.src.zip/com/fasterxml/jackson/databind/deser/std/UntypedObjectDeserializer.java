/*      */ package com.fasterxml.jackson.databind.deser.std;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*      */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.ResolvableDeserializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.ObjectBuffer;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ @JacksonStdImpl
/*      */ public class UntypedObjectDeserializer
/*      */   extends StdDeserializer<Object>
/*      */   implements ResolvableDeserializer, ContextualDeserializer
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   35 */   protected static final Object[] NO_OBJECTS = new Object[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> _mapDeserializer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> _listDeserializer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> _stringDeserializer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> _numberDeserializer;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JavaType _listType;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JavaType _mapType;
/*      */   
/*      */ 
/*      */ 
/*      */   protected final boolean _nonMerging;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public UntypedObjectDeserializer()
/*      */   {
/*   77 */     this(null, null);
/*      */   }
/*      */   
/*      */   public UntypedObjectDeserializer(JavaType listType, JavaType mapType) {
/*   81 */     super(Object.class);
/*   82 */     this._listType = listType;
/*   83 */     this._mapType = mapType;
/*   84 */     this._nonMerging = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public UntypedObjectDeserializer(UntypedObjectDeserializer base, JsonDeserializer<?> mapDeser, JsonDeserializer<?> listDeser, JsonDeserializer<?> stringDeser, JsonDeserializer<?> numberDeser)
/*      */   {
/*   92 */     super(Object.class);
/*   93 */     this._mapDeserializer = mapDeser;
/*   94 */     this._listDeserializer = listDeser;
/*   95 */     this._stringDeserializer = stringDeser;
/*   96 */     this._numberDeserializer = numberDeser;
/*   97 */     this._listType = base._listType;
/*   98 */     this._mapType = base._mapType;
/*   99 */     this._nonMerging = base._nonMerging;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected UntypedObjectDeserializer(UntypedObjectDeserializer base, boolean nonMerging)
/*      */   {
/*  108 */     super(Object.class);
/*  109 */     this._mapDeserializer = base._mapDeserializer;
/*  110 */     this._listDeserializer = base._listDeserializer;
/*  111 */     this._stringDeserializer = base._stringDeserializer;
/*  112 */     this._numberDeserializer = base._numberDeserializer;
/*  113 */     this._listType = base._listType;
/*  114 */     this._mapType = base._mapType;
/*  115 */     this._nonMerging = nonMerging;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resolve(DeserializationContext ctxt)
/*      */     throws JsonMappingException
/*      */   {
/*  133 */     JavaType obType = ctxt.constructType(Object.class);
/*  134 */     JavaType stringType = ctxt.constructType(String.class);
/*  135 */     TypeFactory tf = ctxt.getTypeFactory();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  147 */     if (this._listType == null) {
/*  148 */       this._listDeserializer = _clearIfStdImpl(_findCustomDeser(ctxt, tf.constructCollectionType(List.class, obType)));
/*      */     }
/*      */     else {
/*  151 */       this._listDeserializer = _findCustomDeser(ctxt, this._listType);
/*      */     }
/*  153 */     if (this._mapType == null) {
/*  154 */       this._mapDeserializer = _clearIfStdImpl(_findCustomDeser(ctxt, tf.constructMapType(Map.class, stringType, obType)));
/*      */     }
/*      */     else {
/*  157 */       this._mapDeserializer = _findCustomDeser(ctxt, this._mapType);
/*      */     }
/*  159 */     this._stringDeserializer = _clearIfStdImpl(_findCustomDeser(ctxt, stringType));
/*  160 */     this._numberDeserializer = _clearIfStdImpl(_findCustomDeser(ctxt, tf.constructType(Number.class)));
/*      */     
/*      */ 
/*      */ 
/*  164 */     JavaType unknown = TypeFactory.unknownType();
/*  165 */     this._mapDeserializer = ctxt.handleSecondaryContextualization(this._mapDeserializer, null, unknown);
/*  166 */     this._listDeserializer = ctxt.handleSecondaryContextualization(this._listDeserializer, null, unknown);
/*  167 */     this._stringDeserializer = ctxt.handleSecondaryContextualization(this._stringDeserializer, null, unknown);
/*  168 */     this._numberDeserializer = ctxt.handleSecondaryContextualization(this._numberDeserializer, null, unknown);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected JsonDeserializer<Object> _findCustomDeser(DeserializationContext ctxt, JavaType type)
/*      */     throws JsonMappingException
/*      */   {
/*  176 */     return ctxt.findNonContextualValueDeserializer(type);
/*      */   }
/*      */   
/*      */   protected JsonDeserializer<Object> _clearIfStdImpl(JsonDeserializer<Object> deser) {
/*  180 */     return ClassUtil.isJacksonStdImpl(deser) ? null : deser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property)
/*      */     throws JsonMappingException
/*      */   {
/*  193 */     boolean preventMerge = (property == null) && (Boolean.FALSE.equals(ctxt.getConfig().getDefaultMergeable(Object.class)));
/*      */     
/*      */ 
/*  196 */     if ((this._stringDeserializer == null) && (this._numberDeserializer == null) && (this._mapDeserializer == null) && (this._listDeserializer == null))
/*      */     {
/*  198 */       if (getClass() == UntypedObjectDeserializer.class) {
/*  199 */         return Vanilla.instance(preventMerge);
/*      */       }
/*      */     }
/*  202 */     if (preventMerge != this._nonMerging) {
/*  203 */       return new UntypedObjectDeserializer(this, preventMerge);
/*      */     }
/*      */     
/*  206 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCachable()
/*      */   {
/*  225 */     return true;
/*      */   }
/*      */   
/*      */   public LogicalType logicalType()
/*      */   {
/*  230 */     return LogicalType.Untyped;
/*      */   }
/*      */   
/*      */ 
/*      */   public Boolean supportsUpdate(DeserializationConfig config)
/*      */   {
/*  236 */     return null;
/*      */   }
/*      */   
/*      */   public Object deserialize(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/*  242 */     switch (p.currentTokenId())
/*      */     {
/*      */ 
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 5: 
/*  248 */       if (this._mapDeserializer != null) {
/*  249 */         return this._mapDeserializer.deserialize(p, ctxt);
/*      */       }
/*  251 */       return mapObject(p, ctxt);
/*      */     case 3: 
/*  253 */       if (ctxt.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY)) {
/*  254 */         return mapArrayToArray(p, ctxt);
/*      */       }
/*  256 */       if (this._listDeserializer != null) {
/*  257 */         return this._listDeserializer.deserialize(p, ctxt);
/*      */       }
/*  259 */       return mapArray(p, ctxt);
/*      */     case 12: 
/*  261 */       return p.getEmbeddedObject();
/*      */     case 6: 
/*  263 */       if (this._stringDeserializer != null) {
/*  264 */         return this._stringDeserializer.deserialize(p, ctxt);
/*      */       }
/*  266 */       return p.getText();
/*      */     
/*      */     case 7: 
/*  269 */       if (this._numberDeserializer != null) {
/*  270 */         return this._numberDeserializer.deserialize(p, ctxt);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  275 */       if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/*  276 */         return _coerceIntegral(p, ctxt);
/*      */       }
/*  278 */       return p.getNumberValue();
/*      */     
/*      */     case 8: 
/*  281 */       if (this._numberDeserializer != null) {
/*  282 */         return this._numberDeserializer.deserialize(p, ctxt);
/*      */       }
/*      */       
/*  285 */       if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/*  286 */         return p.getDecimalValue();
/*      */       }
/*      */       
/*  289 */       return p.getNumberValue();
/*      */     
/*      */     case 9: 
/*  292 */       return Boolean.TRUE;
/*      */     case 10: 
/*  294 */       return Boolean.FALSE;
/*      */     
/*      */     case 11: 
/*  297 */       return null;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  302 */     return ctxt.handleUnexpectedToken(Object.class, p);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*      */     throws IOException
/*      */   {
/*  309 */     switch (p.currentTokenId())
/*      */     {
/*      */ 
/*      */     case 1: 
/*      */     case 3: 
/*      */     case 5: 
/*  315 */       return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*      */     
/*      */     case 12: 
/*  318 */       return p.getEmbeddedObject();
/*      */     
/*      */ 
/*      */ 
/*      */     case 6: 
/*  323 */       if (this._stringDeserializer != null) {
/*  324 */         return this._stringDeserializer.deserialize(p, ctxt);
/*      */       }
/*  326 */       return p.getText();
/*      */     
/*      */     case 7: 
/*  329 */       if (this._numberDeserializer != null) {
/*  330 */         return this._numberDeserializer.deserialize(p, ctxt);
/*      */       }
/*      */       
/*  333 */       if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/*  334 */         return _coerceIntegral(p, ctxt);
/*      */       }
/*  336 */       return p.getNumberValue();
/*      */     
/*      */     case 8: 
/*  339 */       if (this._numberDeserializer != null) {
/*  340 */         return this._numberDeserializer.deserialize(p, ctxt);
/*      */       }
/*  342 */       if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/*  343 */         return p.getDecimalValue();
/*      */       }
/*  345 */       return p.getNumberValue();
/*      */     
/*      */     case 9: 
/*  348 */       return Boolean.TRUE;
/*      */     case 10: 
/*  350 */       return Boolean.FALSE;
/*      */     
/*      */     case 11: 
/*  353 */       return null;
/*      */     }
/*      */     
/*  356 */     return ctxt.handleUnexpectedToken(Object.class, p);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object intoValue)
/*      */     throws IOException
/*      */   {
/*  364 */     if (this._nonMerging) {
/*  365 */       return deserialize(p, ctxt);
/*      */     }
/*      */     
/*  368 */     switch (p.currentTokenId())
/*      */     {
/*      */ 
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 5: 
/*  374 */       if (this._mapDeserializer != null) {
/*  375 */         return this._mapDeserializer.deserialize(p, ctxt, intoValue);
/*      */       }
/*  377 */       if ((intoValue instanceof Map)) {
/*  378 */         return mapObject(p, ctxt, (Map)intoValue);
/*      */       }
/*  380 */       return mapObject(p, ctxt);
/*      */     case 3: 
/*  382 */       if (this._listDeserializer != null) {
/*  383 */         return this._listDeserializer.deserialize(p, ctxt, intoValue);
/*      */       }
/*  385 */       if ((intoValue instanceof Collection)) {
/*  386 */         return mapArray(p, ctxt, (Collection)intoValue);
/*      */       }
/*  388 */       if (ctxt.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY)) {
/*  389 */         return mapArrayToArray(p, ctxt);
/*      */       }
/*  391 */       return mapArray(p, ctxt);
/*      */     case 12: 
/*  393 */       return p.getEmbeddedObject();
/*      */     case 6: 
/*  395 */       if (this._stringDeserializer != null) {
/*  396 */         return this._stringDeserializer.deserialize(p, ctxt, intoValue);
/*      */       }
/*  398 */       return p.getText();
/*      */     
/*      */     case 7: 
/*  401 */       if (this._numberDeserializer != null) {
/*  402 */         return this._numberDeserializer.deserialize(p, ctxt, intoValue);
/*      */       }
/*  404 */       if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/*  405 */         return _coerceIntegral(p, ctxt);
/*      */       }
/*  407 */       return p.getNumberValue();
/*      */     
/*      */     case 8: 
/*  410 */       if (this._numberDeserializer != null) {
/*  411 */         return this._numberDeserializer.deserialize(p, ctxt, intoValue);
/*      */       }
/*  413 */       if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/*  414 */         return p.getDecimalValue();
/*      */       }
/*  416 */       return p.getNumberValue();
/*      */     case 9: 
/*  418 */       return Boolean.TRUE;
/*      */     case 10: 
/*  420 */       return Boolean.FALSE;
/*      */     
/*      */ 
/*      */     case 11: 
/*  424 */       return null;
/*      */     }
/*      */     
/*      */     
/*  428 */     return deserialize(p, ctxt);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object mapArray(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/*  443 */     if (p.nextToken() == JsonToken.END_ARRAY) {
/*  444 */       return new ArrayList(2);
/*      */     }
/*  446 */     Object value = deserialize(p, ctxt);
/*  447 */     if (p.nextToken() == JsonToken.END_ARRAY) {
/*  448 */       ArrayList<Object> l = new ArrayList(2);
/*  449 */       l.add(value);
/*  450 */       return l;
/*      */     }
/*  452 */     Object value2 = deserialize(p, ctxt);
/*  453 */     if (p.nextToken() == JsonToken.END_ARRAY) {
/*  454 */       ArrayList<Object> l = new ArrayList(2);
/*  455 */       l.add(value);
/*  456 */       l.add(value2);
/*  457 */       return l;
/*      */     }
/*  459 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/*  460 */     Object[] values = buffer.resetAndStart();
/*  461 */     int ptr = 0;
/*  462 */     values[(ptr++)] = value;
/*  463 */     values[(ptr++)] = value2;
/*  464 */     int totalSize = ptr;
/*      */     do {
/*  466 */       value = deserialize(p, ctxt);
/*  467 */       totalSize++;
/*  468 */       if (ptr >= values.length) {
/*  469 */         values = buffer.appendCompletedChunk(values);
/*  470 */         ptr = 0;
/*      */       }
/*  472 */       values[(ptr++)] = value;
/*  473 */     } while (p.nextToken() != JsonToken.END_ARRAY);
/*      */     
/*  475 */     ArrayList<Object> result = new ArrayList(totalSize);
/*  476 */     buffer.completeAndClearBuffer(values, ptr, result);
/*  477 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Object mapArray(JsonParser p, DeserializationContext ctxt, Collection<Object> result)
/*      */     throws IOException
/*      */   {
/*  485 */     while (p.nextToken() != JsonToken.END_ARRAY) {
/*  486 */       result.add(deserialize(p, ctxt));
/*      */     }
/*  488 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object mapObject(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/*  498 */     JsonToken t = p.currentToken();
/*      */     String key1;
/*  500 */     String key1; if (t == JsonToken.START_OBJECT) {
/*  501 */       key1 = p.nextFieldName(); } else { String key1;
/*  502 */       if (t == JsonToken.FIELD_NAME) {
/*  503 */         key1 = p.currentName();
/*      */       } else {
/*  505 */         if (t != JsonToken.END_OBJECT) {
/*  506 */           return ctxt.handleUnexpectedToken(handledType(), p);
/*      */         }
/*  508 */         key1 = null;
/*      */       } }
/*  510 */     if (key1 == null)
/*      */     {
/*  512 */       return new LinkedHashMap(2);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  517 */     p.nextToken();
/*  518 */     Object value1 = deserialize(p, ctxt);
/*  519 */     String key2 = p.nextFieldName();
/*  520 */     if (key2 == null)
/*      */     {
/*  522 */       LinkedHashMap<String, Object> result = new LinkedHashMap(2);
/*  523 */       result.put(key1, value1);
/*  524 */       return result;
/*      */     }
/*  526 */     p.nextToken();
/*  527 */     Object value2 = deserialize(p, ctxt);
/*      */     
/*  529 */     String key = p.nextFieldName();
/*  530 */     if (key == null) {
/*  531 */       LinkedHashMap<String, Object> result = new LinkedHashMap(4);
/*  532 */       result.put(key1, value1);
/*  533 */       if (result.put(key2, value2) != null)
/*      */       {
/*  535 */         return _mapObjectWithDups(p, ctxt, result, key1, value1, value2, key);
/*      */       }
/*  537 */       return result;
/*      */     }
/*      */     
/*  540 */     LinkedHashMap<String, Object> result = new LinkedHashMap();
/*  541 */     result.put(key1, value1);
/*  542 */     if (result.put(key2, value2) != null)
/*      */     {
/*  544 */       return _mapObjectWithDups(p, ctxt, result, key1, value1, value2, key);
/*      */     }
/*      */     do
/*      */     {
/*  548 */       p.nextToken();
/*  549 */       Object newValue = deserialize(p, ctxt);
/*  550 */       Object oldValue = result.put(key, newValue);
/*  551 */       if (oldValue != null) {
/*  552 */         return _mapObjectWithDups(p, ctxt, result, key, oldValue, newValue, p
/*  553 */           .nextFieldName());
/*      */       }
/*  555 */     } while ((key = p.nextFieldName()) != null);
/*  556 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Object _mapObjectWithDups(JsonParser p, DeserializationContext ctxt, Map<String, Object> result, String key, Object oldValue, Object newValue, String nextKey)
/*      */     throws IOException
/*      */   {
/*  564 */     boolean squashDups = ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES);
/*      */     
/*  566 */     if (squashDups) {
/*  567 */       _squashDups(result, key, oldValue, newValue);
/*      */     }
/*      */     
/*  570 */     while (nextKey != null) {
/*  571 */       p.nextToken();
/*  572 */       newValue = deserialize(p, ctxt);
/*  573 */       oldValue = result.put(nextKey, newValue);
/*  574 */       if ((oldValue != null) && (squashDups)) {
/*  575 */         _squashDups(result, key, oldValue, newValue);
/*      */       }
/*  577 */       nextKey = p.nextFieldName();
/*      */     }
/*      */     
/*  580 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void _squashDups(Map<String, Object> result, String key, Object oldValue, Object newValue)
/*      */   {
/*  587 */     if ((oldValue instanceof List)) {
/*  588 */       ((List)oldValue).add(newValue);
/*  589 */       result.put(key, oldValue);
/*      */     } else {
/*  591 */       ArrayList<Object> l = new ArrayList();
/*  592 */       l.add(oldValue);
/*  593 */       l.add(newValue);
/*  594 */       result.put(key, l);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object[] mapArrayToArray(JsonParser p, DeserializationContext ctxt)
/*      */     throws IOException
/*      */   {
/*  604 */     if (p.nextToken() == JsonToken.END_ARRAY) {
/*  605 */       return NO_OBJECTS;
/*      */     }
/*  607 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/*  608 */     Object[] values = buffer.resetAndStart();
/*  609 */     int ptr = 0;
/*      */     do {
/*  611 */       Object value = deserialize(p, ctxt);
/*  612 */       if (ptr >= values.length) {
/*  613 */         values = buffer.appendCompletedChunk(values);
/*  614 */         ptr = 0;
/*      */       }
/*  616 */       values[(ptr++)] = value;
/*  617 */     } while (p.nextToken() != JsonToken.END_ARRAY);
/*  618 */     return buffer.completeAndClearBuffer(values, ptr);
/*      */   }
/*      */   
/*      */   protected Object mapObject(JsonParser p, DeserializationContext ctxt, Map<Object, Object> m)
/*      */     throws IOException
/*      */   {
/*  624 */     JsonToken t = p.currentToken();
/*  625 */     if (t == JsonToken.START_OBJECT) {
/*  626 */       t = p.nextToken();
/*      */     }
/*  628 */     if (t == JsonToken.END_OBJECT) {
/*  629 */       return m;
/*      */     }
/*      */     
/*  632 */     String key = p.currentName();
/*      */     do {
/*  634 */       p.nextToken();
/*      */       
/*  636 */       Object old = m.get(key);
/*      */       Object newV;
/*      */       Object newV;
/*  639 */       if (old != null) {
/*  640 */         newV = deserialize(p, ctxt, old);
/*      */       } else {
/*  642 */         newV = deserialize(p, ctxt);
/*      */       }
/*  644 */       if (newV != old) {
/*  645 */         m.put(key, newV);
/*      */       }
/*  647 */     } while ((key = p.nextFieldName()) != null);
/*  648 */     return m;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @JacksonStdImpl
/*      */   public static class Vanilla
/*      */     extends StdDeserializer<Object>
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  668 */     public static final Vanilla std = new Vanilla();
/*      */     
/*      */ 
/*      */     protected final boolean _nonMerging;
/*      */     
/*      */ 
/*      */ 
/*  675 */     public Vanilla() { this(false); }
/*      */     
/*      */     protected Vanilla(boolean nonMerging) {
/*  678 */       super();
/*  679 */       this._nonMerging = nonMerging;
/*      */     }
/*      */     
/*      */     public static Vanilla instance(boolean nonMerging) {
/*  683 */       if (nonMerging) {
/*  684 */         return new Vanilla(true);
/*      */       }
/*  686 */       return std;
/*      */     }
/*      */     
/*      */     public LogicalType logicalType()
/*      */     {
/*  691 */       return LogicalType.Untyped;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public Boolean supportsUpdate(DeserializationConfig config)
/*      */     {
/*  698 */       return this._nonMerging ? Boolean.FALSE : null;
/*      */     }
/*      */     
/*      */     public Object deserialize(JsonParser p, DeserializationContext ctxt)
/*      */       throws IOException
/*      */     {
/*  704 */       switch (p.currentTokenId())
/*      */       {
/*      */       case 1: 
/*  707 */         JsonToken t = p.nextToken();
/*  708 */         if (t == JsonToken.END_OBJECT) {
/*  709 */           return new LinkedHashMap(2);
/*      */         }
/*      */       
/*      */       case 5: 
/*  713 */         return mapObject(p, ctxt);
/*      */       
/*      */       case 3: 
/*  716 */         JsonToken t = p.nextToken();
/*  717 */         if (t == JsonToken.END_ARRAY) {
/*  718 */           if (ctxt.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY)) {
/*  719 */             return UntypedObjectDeserializer.NO_OBJECTS;
/*      */           }
/*  721 */           return new ArrayList(2);
/*      */         }
/*      */         
/*  724 */         if (ctxt.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY)) {
/*  725 */           return mapArrayToArray(p, ctxt);
/*      */         }
/*  727 */         return mapArray(p, ctxt);
/*      */       case 12: 
/*  729 */         return p.getEmbeddedObject();
/*      */       case 6: 
/*  731 */         return p.getText();
/*      */       
/*      */       case 7: 
/*  734 */         if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/*  735 */           return _coerceIntegral(p, ctxt);
/*      */         }
/*  737 */         return p.getNumberValue();
/*      */       
/*      */       case 8: 
/*  740 */         if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/*  741 */           return p.getDecimalValue();
/*      */         }
/*  743 */         return p.getNumberValue();
/*      */       
/*      */       case 9: 
/*  746 */         return Boolean.TRUE;
/*      */       case 10: 
/*  748 */         return Boolean.FALSE;
/*      */       
/*      */ 
/*      */ 
/*      */       case 2: 
/*  753 */         return new LinkedHashMap(2);
/*      */       
/*      */       case 11: 
/*  756 */         return null;
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  761 */       return ctxt.handleUnexpectedToken(Object.class, p);
/*      */     }
/*      */     
/*      */     public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
/*      */       throws IOException
/*      */     {
/*  767 */       switch (p.currentTokenId()) {
/*      */       case 1: 
/*      */       case 3: 
/*      */       case 5: 
/*  771 */         return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*      */       
/*      */       case 6: 
/*  774 */         return p.getText();
/*      */       
/*      */       case 7: 
/*  777 */         if (ctxt.isEnabled(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS)) {
/*  778 */           return p.getBigIntegerValue();
/*      */         }
/*  780 */         return p.getNumberValue();
/*      */       
/*      */       case 8: 
/*  783 */         if (ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/*  784 */           return p.getDecimalValue();
/*      */         }
/*  786 */         return p.getNumberValue();
/*      */       
/*      */       case 9: 
/*  789 */         return Boolean.TRUE;
/*      */       case 10: 
/*  791 */         return Boolean.FALSE;
/*      */       case 12: 
/*  793 */         return p.getEmbeddedObject();
/*      */       
/*      */       case 11: 
/*  796 */         return null;
/*      */       }
/*      */       
/*  799 */       return ctxt.handleUnexpectedToken(Object.class, p);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public Object deserialize(JsonParser p, DeserializationContext ctxt, Object intoValue)
/*      */       throws IOException
/*      */     {
/*  807 */       if (this._nonMerging) {
/*  808 */         return deserialize(p, ctxt);
/*      */       }
/*      */       
/*  811 */       switch (p.currentTokenId()) {
/*      */       case 2: 
/*      */       case 4: 
/*  814 */         return intoValue;
/*      */       
/*      */       case 1: 
/*  817 */         JsonToken t = p.nextToken();
/*  818 */         if (t == JsonToken.END_OBJECT) {
/*  819 */           return intoValue;
/*      */         }
/*      */       
/*      */       case 5: 
/*  823 */         if ((intoValue instanceof Map)) {
/*  824 */           Map<Object, Object> m = (Map)intoValue;
/*      */           
/*  826 */           String key = p.currentName();
/*      */           do {
/*  828 */             p.nextToken();
/*      */             
/*  830 */             Object old = m.get(key);
/*      */             Object newV;
/*  832 */             Object newV; if (old != null) {
/*  833 */               newV = deserialize(p, ctxt, old);
/*      */             } else {
/*  835 */               newV = deserialize(p, ctxt);
/*      */             }
/*  837 */             if (newV != old) {
/*  838 */               m.put(key, newV);
/*      */             }
/*  840 */           } while ((key = p.nextFieldName()) != null);
/*  841 */           return intoValue;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 3: 
/*  846 */         JsonToken t = p.nextToken();
/*  847 */         if (t == JsonToken.END_ARRAY) {
/*  848 */           return intoValue;
/*      */         }
/*      */         
/*      */ 
/*  852 */         if ((intoValue instanceof Collection)) {
/*  853 */           Collection<Object> c = (Collection)intoValue;
/*      */           do
/*      */           {
/*  856 */             c.add(deserialize(p, ctxt));
/*  857 */           } while (p.nextToken() != JsonToken.END_ARRAY);
/*  858 */           return intoValue;
/*      */         }
/*      */         
/*      */         break;
/*      */       }
/*      */       
/*      */       
/*  865 */       return deserialize(p, ctxt);
/*      */     }
/*      */     
/*      */     protected Object mapArray(JsonParser p, DeserializationContext ctxt) throws IOException
/*      */     {
/*  870 */       Object value = deserialize(p, ctxt);
/*  871 */       if (p.nextToken() == JsonToken.END_ARRAY) {
/*  872 */         ArrayList<Object> l = new ArrayList(2);
/*  873 */         l.add(value);
/*  874 */         return l;
/*      */       }
/*  876 */       Object value2 = deserialize(p, ctxt);
/*  877 */       if (p.nextToken() == JsonToken.END_ARRAY) {
/*  878 */         ArrayList<Object> l = new ArrayList(2);
/*  879 */         l.add(value);
/*  880 */         l.add(value2);
/*  881 */         return l;
/*      */       }
/*  883 */       ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/*  884 */       Object[] values = buffer.resetAndStart();
/*  885 */       int ptr = 0;
/*  886 */       values[(ptr++)] = value;
/*  887 */       values[(ptr++)] = value2;
/*  888 */       int totalSize = ptr;
/*      */       do {
/*  890 */         value = deserialize(p, ctxt);
/*  891 */         totalSize++;
/*  892 */         if (ptr >= values.length) {
/*  893 */           values = buffer.appendCompletedChunk(values);
/*  894 */           ptr = 0;
/*      */         }
/*  896 */         values[(ptr++)] = value;
/*  897 */       } while (p.nextToken() != JsonToken.END_ARRAY);
/*      */       
/*  899 */       ArrayList<Object> result = new ArrayList(totalSize);
/*  900 */       buffer.completeAndClearBuffer(values, ptr, result);
/*  901 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */     protected Object[] mapArrayToArray(JsonParser p, DeserializationContext ctxt)
/*      */       throws IOException
/*      */     {
/*  908 */       ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/*  909 */       Object[] values = buffer.resetAndStart();
/*  910 */       int ptr = 0;
/*      */       do {
/*  912 */         Object value = deserialize(p, ctxt);
/*  913 */         if (ptr >= values.length) {
/*  914 */           values = buffer.appendCompletedChunk(values);
/*  915 */           ptr = 0;
/*      */         }
/*  917 */         values[(ptr++)] = value;
/*  918 */       } while (p.nextToken() != JsonToken.END_ARRAY);
/*  919 */       return buffer.completeAndClearBuffer(values, ptr);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Object mapObject(JsonParser p, DeserializationContext ctxt)
/*      */       throws IOException
/*      */     {
/*  928 */       String key1 = p.getText();
/*  929 */       p.nextToken();
/*  930 */       Object value1 = deserialize(p, ctxt);
/*      */       
/*  932 */       String key2 = p.nextFieldName();
/*  933 */       if (key2 == null) {
/*  934 */         LinkedHashMap<String, Object> result = new LinkedHashMap(2);
/*  935 */         result.put(key1, value1);
/*  936 */         return result;
/*      */       }
/*  938 */       p.nextToken();
/*  939 */       Object value2 = deserialize(p, ctxt);
/*      */       
/*  941 */       String key = p.nextFieldName();
/*  942 */       if (key == null) {
/*  943 */         LinkedHashMap<String, Object> result = new LinkedHashMap(4);
/*  944 */         result.put(key1, value1);
/*  945 */         if (result.put(key2, value2) != null)
/*      */         {
/*  947 */           return _mapObjectWithDups(p, ctxt, result, key1, value1, value2, key);
/*      */         }
/*  949 */         return result;
/*      */       }
/*      */       
/*  952 */       LinkedHashMap<String, Object> result = new LinkedHashMap();
/*  953 */       result.put(key1, value1);
/*  954 */       if (result.put(key2, value2) != null)
/*      */       {
/*  956 */         return _mapObjectWithDups(p, ctxt, result, key1, value1, value2, key);
/*      */       }
/*      */       do
/*      */       {
/*  960 */         p.nextToken();
/*  961 */         Object newValue = deserialize(p, ctxt);
/*  962 */         Object oldValue = result.put(key, newValue);
/*  963 */         if (oldValue != null) {
/*  964 */           return _mapObjectWithDups(p, ctxt, result, key, oldValue, newValue, p
/*  965 */             .nextFieldName());
/*      */         }
/*  967 */       } while ((key = p.nextFieldName()) != null);
/*  968 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Object _mapObjectWithDups(JsonParser p, DeserializationContext ctxt, Map<String, Object> result, String initialKey, Object oldValue, Object newValue, String nextKey)
/*      */       throws IOException
/*      */     {
/*  977 */       boolean squashDups = ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES);
/*      */       
/*  979 */       if (squashDups) {
/*  980 */         _squashDups(result, initialKey, oldValue, newValue);
/*      */       }
/*      */       
/*  983 */       while (nextKey != null) {
/*  984 */         p.nextToken();
/*  985 */         newValue = deserialize(p, ctxt);
/*  986 */         oldValue = result.put(nextKey, newValue);
/*  987 */         if ((oldValue != null) && (squashDups)) {
/*  988 */           _squashDups(result, nextKey, oldValue, newValue);
/*      */         }
/*  990 */         nextKey = p.nextFieldName();
/*      */       }
/*      */       
/*  993 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private void _squashDups(Map<String, Object> result, String key, Object oldValue, Object newValue)
/*      */     {
/* 1001 */       if ((oldValue instanceof List)) {
/* 1002 */         ((List)oldValue).add(newValue);
/* 1003 */         result.put(key, oldValue);
/*      */       } else {
/* 1005 */         ArrayList<Object> l = new ArrayList();
/* 1006 */         l.add(oldValue);
/* 1007 */         l.add(newValue);
/* 1008 */         result.put(key, l);
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\deser\std\UntypedObjectDeserializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */