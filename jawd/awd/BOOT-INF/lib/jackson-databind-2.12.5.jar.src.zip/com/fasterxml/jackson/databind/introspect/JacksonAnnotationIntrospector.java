/*      */ package com.fasterxml.jackson.databind.introspect;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JacksonInject.Value;
/*      */ import com.fasterxml.jackson.annotation.JsonAlias;
/*      */ import com.fasterxml.jackson.annotation.JsonBackReference;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonIdentityInfo;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude.Value;
/*      */ import com.fasterxml.jackson.annotation.JsonManagedReference;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.annotation.JsonPropertyOrder;
/*      */ import com.fasterxml.jackson.annotation.JsonSetter;
/*      */ import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
/*      */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*      */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*      */ import com.fasterxml.jackson.annotation.JsonValue;
/*      */ import com.fasterxml.jackson.annotation.JsonView;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonAppend.Attr;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonAppend.Prop;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.ext.Java7Support;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.lang.reflect.Field;
/*      */ import java.util.List;
/*      */ 
/*      */ public class JacksonAnnotationIntrospector extends com.fasterxml.jackson.databind.AnnotationIntrospector implements java.io.Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   37 */   private static final Class<? extends java.lang.annotation.Annotation>[] ANNOTATIONS_TO_INFER_SER = (Class[])new Class[] { JsonSerialize.class, JsonView.class, com.fasterxml.jackson.annotation.JsonFormat.class, JsonTypeInfo.class, com.fasterxml.jackson.annotation.JsonRawValue.class, JsonUnwrapped.class, JsonBackReference.class, JsonManagedReference.class };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   50 */   private static final Class<? extends java.lang.annotation.Annotation>[] ANNOTATIONS_TO_INFER_DESER = (Class[])new Class[] { JsonDeserialize.class, JsonView.class, com.fasterxml.jackson.annotation.JsonFormat.class, JsonTypeInfo.class, JsonUnwrapped.class, JsonBackReference.class, JsonManagedReference.class, com.fasterxml.jackson.annotation.JsonMerge.class };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final Java7Support _java7Helper;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/*   66 */     Java7Support x = null;
/*      */     try {
/*   68 */       x = Java7Support.instance();
/*      */     } catch (Throwable localThrowable) {}
/*   70 */     _java7Helper = x;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   82 */   protected transient com.fasterxml.jackson.databind.util.LRUMap<Class<?>, Boolean> _annotationsInside = new com.fasterxml.jackson.databind.util.LRUMap(48, 48);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   98 */   protected boolean _cfgConstructorPropertiesImpliesCreator = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public com.fasterxml.jackson.core.Version version()
/*      */   {
/*  110 */     return com.fasterxml.jackson.databind.cfg.PackageVersion.VERSION;
/*      */   }
/*      */   
/*      */   protected Object readResolve() {
/*  114 */     if (this._annotationsInside == null) {
/*  115 */       this._annotationsInside = new com.fasterxml.jackson.databind.util.LRUMap(48, 48);
/*      */     }
/*  117 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JacksonAnnotationIntrospector setConstructorPropertiesImpliesCreator(boolean b)
/*      */   {
/*  138 */     this._cfgConstructorPropertiesImpliesCreator = b;
/*  139 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAnnotationBundle(java.lang.annotation.Annotation ann)
/*      */   {
/*  158 */     Class<?> type = ann.annotationType();
/*  159 */     Boolean b = (Boolean)this._annotationsInside.get(type);
/*  160 */     if (b == null) {
/*  161 */       b = Boolean.valueOf(type.getAnnotation(com.fasterxml.jackson.annotation.JacksonAnnotationsInside.class) != null);
/*  162 */       this._annotationsInside.putIfAbsent(type, b);
/*      */     }
/*  164 */     return b.booleanValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public String findEnumValue(Enum<?> value)
/*      */   {
/*      */     try
/*      */     {
/*  186 */       Field f = value.getDeclaringClass().getField(value.name());
/*  187 */       if (f != null) {
/*  188 */         JsonProperty prop = (JsonProperty)f.getAnnotation(JsonProperty.class);
/*  189 */         if (prop != null) {
/*  190 */           String n = prop.value();
/*  191 */           if ((n != null) && (!n.isEmpty())) {
/*  192 */             return n;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (SecurityException localSecurityException) {}catch (NoSuchFieldException localNoSuchFieldException) {}
/*      */     
/*      */ 
/*      */ 
/*  201 */     return value.name();
/*      */   }
/*      */   
/*      */   public String[] findEnumValues(Class<?> enumType, Enum<?>[] enumValues, String[] names)
/*      */   {
/*  206 */     java.util.HashMap<String, String> expl = null;
/*  207 */     for (Field f : enumType.getDeclaredFields())
/*  208 */       if (f.isEnumConstant())
/*      */       {
/*      */ 
/*  211 */         JsonProperty prop = (JsonProperty)f.getAnnotation(JsonProperty.class);
/*  212 */         if (prop != null)
/*      */         {
/*      */ 
/*  215 */           String n = prop.value();
/*  216 */           if (!n.isEmpty())
/*      */           {
/*      */ 
/*  219 */             if (expl == null) {
/*  220 */               expl = new java.util.HashMap();
/*      */             }
/*  222 */             expl.put(f.getName(), n);
/*      */           }
/*      */         } }
/*  225 */     if (expl != null) {
/*  226 */       int i = 0; for (int end = enumValues.length; i < end; i++) {
/*  227 */         String defName = enumValues[i].name();
/*  228 */         String explValue = (String)expl.get(defName);
/*  229 */         if (explValue != null) {
/*  230 */           names[i] = explValue;
/*      */         }
/*      */       }
/*      */     }
/*  234 */     return names;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void findEnumAliases(Class<?> enumType, Enum<?>[] enumValues, String[][] aliasList)
/*      */   {
/*  242 */     for (Field f : enumType.getDeclaredFields()) {
/*  243 */       if (f.isEnumConstant()) {
/*  244 */         JsonAlias aliasAnnotation = (JsonAlias)f.getAnnotation(JsonAlias.class);
/*  245 */         if (aliasAnnotation != null) {
/*  246 */           String[] aliases = aliasAnnotation.value();
/*  247 */           if (aliases.length != 0) {
/*  248 */             String name = f.getName();
/*      */             
/*  250 */             int i = 0; for (int end = enumValues.length; i < end; i++) {
/*  251 */               if (name.equals(enumValues[i].name())) {
/*  252 */                 aliasList[i] = aliases;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enum<?> findDefaultEnumValue(Class<Enum<?>> enumCls)
/*      */   {
/*  272 */     return ClassUtil.findFirstAnnotatedEnumValue(enumCls, com.fasterxml.jackson.annotation.JsonEnumDefaultValue.class);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PropertyName findRootName(AnnotatedClass ac)
/*      */   {
/*  284 */     com.fasterxml.jackson.annotation.JsonRootName ann = (com.fasterxml.jackson.annotation.JsonRootName)_findAnnotation(ac, com.fasterxml.jackson.annotation.JsonRootName.class);
/*  285 */     if (ann == null) {
/*  286 */       return null;
/*      */     }
/*  288 */     String ns = ann.namespace();
/*  289 */     if ((ns != null) && (ns.isEmpty())) {
/*  290 */       ns = null;
/*      */     }
/*  292 */     return PropertyName.construct(ann.value(), ns);
/*      */   }
/*      */   
/*      */   public Boolean isIgnorableType(AnnotatedClass ac)
/*      */   {
/*  297 */     com.fasterxml.jackson.annotation.JsonIgnoreType ignore = (com.fasterxml.jackson.annotation.JsonIgnoreType)_findAnnotation(ac, com.fasterxml.jackson.annotation.JsonIgnoreType.class);
/*  298 */     return ignore == null ? null : Boolean.valueOf(ignore.value());
/*      */   }
/*      */   
/*      */ 
/*      */   public com.fasterxml.jackson.annotation.JsonIgnoreProperties.Value findPropertyIgnoralByName(MapperConfig<?> config, Annotated a)
/*      */   {
/*  304 */     com.fasterxml.jackson.annotation.JsonIgnoreProperties v = (com.fasterxml.jackson.annotation.JsonIgnoreProperties)_findAnnotation(a, com.fasterxml.jackson.annotation.JsonIgnoreProperties.class);
/*  305 */     if (v == null) {
/*  306 */       return com.fasterxml.jackson.annotation.JsonIgnoreProperties.Value.empty();
/*      */     }
/*  308 */     return com.fasterxml.jackson.annotation.JsonIgnoreProperties.Value.from(v);
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public com.fasterxml.jackson.annotation.JsonIgnoreProperties.Value findPropertyIgnorals(Annotated ac)
/*      */   {
/*  315 */     return findPropertyIgnoralByName(null, ac);
/*      */   }
/*      */   
/*      */ 
/*      */   public com.fasterxml.jackson.annotation.JsonIncludeProperties.Value findPropertyInclusionByName(MapperConfig<?> config, Annotated a)
/*      */   {
/*  321 */     com.fasterxml.jackson.annotation.JsonIncludeProperties v = (com.fasterxml.jackson.annotation.JsonIncludeProperties)_findAnnotation(a, com.fasterxml.jackson.annotation.JsonIncludeProperties.class);
/*  322 */     if (v == null) {
/*  323 */       return com.fasterxml.jackson.annotation.JsonIncludeProperties.Value.all();
/*      */     }
/*  325 */     return com.fasterxml.jackson.annotation.JsonIncludeProperties.Value.from(v);
/*      */   }
/*      */   
/*      */   public Object findFilterId(Annotated a)
/*      */   {
/*  330 */     com.fasterxml.jackson.annotation.JsonFilter ann = (com.fasterxml.jackson.annotation.JsonFilter)_findAnnotation(a, com.fasterxml.jackson.annotation.JsonFilter.class);
/*  331 */     if (ann != null) {
/*  332 */       String id = ann.value();
/*      */       
/*  334 */       if (!id.isEmpty()) {
/*  335 */         return id;
/*      */       }
/*      */     }
/*  338 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object findNamingStrategy(AnnotatedClass ac)
/*      */   {
/*  344 */     com.fasterxml.jackson.databind.annotation.JsonNaming ann = (com.fasterxml.jackson.databind.annotation.JsonNaming)_findAnnotation(ac, com.fasterxml.jackson.databind.annotation.JsonNaming.class);
/*  345 */     return ann == null ? null : ann.value();
/*      */   }
/*      */   
/*      */   public String findClassDescription(AnnotatedClass ac)
/*      */   {
/*  350 */     com.fasterxml.jackson.annotation.JsonClassDescription ann = (com.fasterxml.jackson.annotation.JsonClassDescription)_findAnnotation(ac, com.fasterxml.jackson.annotation.JsonClassDescription.class);
/*  351 */     return ann == null ? null : ann.value();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public VisibilityChecker<?> findAutoDetectVisibility(AnnotatedClass ac, VisibilityChecker<?> checker)
/*      */   {
/*  364 */     com.fasterxml.jackson.annotation.JsonAutoDetect ann = (com.fasterxml.jackson.annotation.JsonAutoDetect)_findAnnotation(ac, com.fasterxml.jackson.annotation.JsonAutoDetect.class);
/*  365 */     return ann == null ? checker : checker.with(ann);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String findImplicitPropertyName(AnnotatedMember m)
/*      */   {
/*  376 */     PropertyName n = _findConstructorName(m);
/*  377 */     return n == null ? null : n.getSimpleName();
/*      */   }
/*      */   
/*      */   public List<PropertyName> findPropertyAliases(Annotated m)
/*      */   {
/*  382 */     JsonAlias ann = (JsonAlias)_findAnnotation(m, JsonAlias.class);
/*  383 */     if (ann == null) {
/*  384 */       return null;
/*      */     }
/*  386 */     String[] strs = ann.value();
/*  387 */     int len = strs.length;
/*  388 */     if (len == 0) {
/*  389 */       return java.util.Collections.emptyList();
/*      */     }
/*  391 */     List<PropertyName> result = new java.util.ArrayList(len);
/*  392 */     for (int i = 0; i < len; i++) {
/*  393 */       result.add(PropertyName.construct(strs[i]));
/*      */     }
/*  395 */     return result;
/*      */   }
/*      */   
/*      */   public boolean hasIgnoreMarker(AnnotatedMember m)
/*      */   {
/*  400 */     return _isIgnorable(m);
/*      */   }
/*      */   
/*      */ 
/*      */   public Boolean hasRequiredMarker(AnnotatedMember m)
/*      */   {
/*  406 */     JsonProperty ann = (JsonProperty)_findAnnotation(m, JsonProperty.class);
/*  407 */     if (ann != null) {
/*  408 */       return Boolean.valueOf(ann.required());
/*      */     }
/*  410 */     return null;
/*      */   }
/*      */   
/*      */   public com.fasterxml.jackson.annotation.JsonProperty.Access findPropertyAccess(Annotated m)
/*      */   {
/*  415 */     JsonProperty ann = (JsonProperty)_findAnnotation(m, JsonProperty.class);
/*  416 */     if (ann != null) {
/*  417 */       return ann.access();
/*      */     }
/*  419 */     return null;
/*      */   }
/*      */   
/*      */   public String findPropertyDescription(Annotated ann)
/*      */   {
/*  424 */     com.fasterxml.jackson.annotation.JsonPropertyDescription desc = (com.fasterxml.jackson.annotation.JsonPropertyDescription)_findAnnotation(ann, com.fasterxml.jackson.annotation.JsonPropertyDescription.class);
/*  425 */     return desc == null ? null : desc.value();
/*      */   }
/*      */   
/*      */   public Integer findPropertyIndex(Annotated ann)
/*      */   {
/*  430 */     JsonProperty prop = (JsonProperty)_findAnnotation(ann, JsonProperty.class);
/*  431 */     if (prop != null) {
/*  432 */       int ix = prop.index();
/*  433 */       if (ix != -1) {
/*  434 */         return Integer.valueOf(ix);
/*      */       }
/*      */     }
/*  437 */     return null;
/*      */   }
/*      */   
/*      */   public String findPropertyDefaultValue(Annotated ann)
/*      */   {
/*  442 */     JsonProperty prop = (JsonProperty)_findAnnotation(ann, JsonProperty.class);
/*  443 */     if (prop == null) {
/*  444 */       return null;
/*      */     }
/*  446 */     String str = prop.defaultValue();
/*      */     
/*  448 */     return str.isEmpty() ? null : str;
/*      */   }
/*      */   
/*      */   public com.fasterxml.jackson.annotation.JsonFormat.Value findFormat(Annotated ann)
/*      */   {
/*  453 */     com.fasterxml.jackson.annotation.JsonFormat f = (com.fasterxml.jackson.annotation.JsonFormat)_findAnnotation(ann, com.fasterxml.jackson.annotation.JsonFormat.class);
/*      */     
/*      */ 
/*  456 */     return f == null ? null : com.fasterxml.jackson.annotation.JsonFormat.Value.from(f);
/*      */   }
/*      */   
/*      */ 
/*      */   public com.fasterxml.jackson.databind.AnnotationIntrospector.ReferenceProperty findReferenceType(AnnotatedMember member)
/*      */   {
/*  462 */     JsonManagedReference ref1 = (JsonManagedReference)_findAnnotation(member, JsonManagedReference.class);
/*  463 */     if (ref1 != null) {
/*  464 */       return com.fasterxml.jackson.databind.AnnotationIntrospector.ReferenceProperty.managed(ref1.value());
/*      */     }
/*  466 */     JsonBackReference ref2 = (JsonBackReference)_findAnnotation(member, JsonBackReference.class);
/*  467 */     if (ref2 != null) {
/*  468 */       return com.fasterxml.jackson.databind.AnnotationIntrospector.ReferenceProperty.back(ref2.value());
/*      */     }
/*  470 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public com.fasterxml.jackson.databind.util.NameTransformer findUnwrappingNameTransformer(AnnotatedMember member)
/*      */   {
/*  476 */     JsonUnwrapped ann = (JsonUnwrapped)_findAnnotation(member, JsonUnwrapped.class);
/*      */     
/*      */ 
/*  479 */     if ((ann == null) || (!ann.enabled())) {
/*  480 */       return null;
/*      */     }
/*  482 */     String prefix = ann.prefix();
/*  483 */     String suffix = ann.suffix();
/*  484 */     return com.fasterxml.jackson.databind.util.NameTransformer.simpleTransformer(prefix, suffix);
/*      */   }
/*      */   
/*      */   public JacksonInject.Value findInjectableValue(AnnotatedMember m)
/*      */   {
/*  489 */     com.fasterxml.jackson.annotation.JacksonInject ann = (com.fasterxml.jackson.annotation.JacksonInject)_findAnnotation(m, com.fasterxml.jackson.annotation.JacksonInject.class);
/*  490 */     if (ann == null) {
/*  491 */       return null;
/*      */     }
/*      */     
/*  494 */     JacksonInject.Value v = JacksonInject.Value.from(ann);
/*  495 */     if (!v.hasId()) {
/*      */       Object id;
/*      */       Object id;
/*  498 */       if (!(m instanceof AnnotatedMethod)) {
/*  499 */         id = m.getRawType().getName();
/*      */       } else {
/*  501 */         AnnotatedMethod am = (AnnotatedMethod)m;
/*  502 */         Object id; if (am.getParameterCount() == 0) {
/*  503 */           id = m.getRawType().getName();
/*      */         } else {
/*  505 */           id = am.getRawParameterType(0).getName();
/*      */         }
/*      */       }
/*  508 */       v = v.withId(id);
/*      */     }
/*  510 */     return v;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public Object findInjectableValueId(AnnotatedMember m)
/*      */   {
/*  516 */     JacksonInject.Value v = findInjectableValue(m);
/*  517 */     return v == null ? null : v.getId();
/*      */   }
/*      */   
/*      */ 
/*      */   public Class<?>[] findViews(Annotated a)
/*      */   {
/*  523 */     JsonView ann = (JsonView)_findAnnotation(a, JsonView.class);
/*  524 */     return ann == null ? null : ann.value();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public AnnotatedMethod resolveSetterConflict(MapperConfig<?> config, AnnotatedMethod setter1, AnnotatedMethod setter2)
/*      */   {
/*  531 */     Class<?> cls1 = setter1.getRawParameterType(0);
/*  532 */     Class<?> cls2 = setter2.getRawParameterType(0);
/*      */     
/*      */ 
/*      */ 
/*  536 */     if (cls1.isPrimitive()) {
/*  537 */       if (!cls2.isPrimitive()) {
/*  538 */         return setter1;
/*      */       }
/*  540 */     } else if (cls2.isPrimitive()) {
/*  541 */       return setter2;
/*      */     }
/*      */     
/*  544 */     if (cls1 == String.class) {
/*  545 */       if (cls2 != String.class) {
/*  546 */         return setter1;
/*      */       }
/*  548 */     } else if (cls2 == String.class) {
/*  549 */       return setter2;
/*      */     }
/*      */     
/*  552 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public PropertyName findRenameByField(MapperConfig<?> config, AnnotatedField f, PropertyName implName)
/*      */   {
/*  559 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TypeResolverBuilder<?> findTypeResolver(MapperConfig<?> config, AnnotatedClass ac, JavaType baseType)
/*      */   {
/*  572 */     return _findTypeResolver(config, ac, baseType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TypeResolverBuilder<?> findPropertyTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType baseType)
/*      */   {
/*  583 */     if ((baseType.isContainerType()) || (baseType.isReferenceType())) {
/*  584 */       return null;
/*      */     }
/*      */     
/*  587 */     return _findTypeResolver(config, am, baseType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TypeResolverBuilder<?> findPropertyContentTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType containerType)
/*      */   {
/*  596 */     if (containerType.getContentType() == null) {
/*  597 */       throw new IllegalArgumentException("Must call method with a container or reference type (got " + containerType + ")");
/*      */     }
/*  599 */     return _findTypeResolver(config, am, containerType);
/*      */   }
/*      */   
/*      */ 
/*      */   public List<com.fasterxml.jackson.databind.jsontype.NamedType> findSubtypes(Annotated a)
/*      */   {
/*  605 */     com.fasterxml.jackson.annotation.JsonSubTypes t = (com.fasterxml.jackson.annotation.JsonSubTypes)_findAnnotation(a, com.fasterxml.jackson.annotation.JsonSubTypes.class);
/*  606 */     if (t == null) return null;
/*  607 */     JsonSubTypes.Type[] types = t.value();
/*  608 */     java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType> result = new java.util.ArrayList(types.length);
/*  609 */     for (JsonSubTypes.Type type : types) {
/*  610 */       result.add(new com.fasterxml.jackson.databind.jsontype.NamedType(type.value(), type.name()));
/*      */       
/*  612 */       for (String name : type.names()) {
/*  613 */         result.add(new com.fasterxml.jackson.databind.jsontype.NamedType(type.value(), name));
/*      */       }
/*      */     }
/*  616 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   public String findTypeName(AnnotatedClass ac)
/*      */   {
/*  622 */     com.fasterxml.jackson.annotation.JsonTypeName tn = (com.fasterxml.jackson.annotation.JsonTypeName)_findAnnotation(ac, com.fasterxml.jackson.annotation.JsonTypeName.class);
/*  623 */     return tn == null ? null : tn.value();
/*      */   }
/*      */   
/*      */   public Boolean isTypeId(AnnotatedMember member)
/*      */   {
/*  628 */     return Boolean.valueOf(_hasAnnotation(member, com.fasterxml.jackson.annotation.JsonTypeId.class));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ObjectIdInfo findObjectIdInfo(Annotated ann)
/*      */   {
/*  639 */     JsonIdentityInfo info = (JsonIdentityInfo)_findAnnotation(ann, JsonIdentityInfo.class);
/*  640 */     if ((info == null) || (info.generator() == com.fasterxml.jackson.annotation.ObjectIdGenerators.None.class)) {
/*  641 */       return null;
/*      */     }
/*      */     
/*  644 */     PropertyName name = PropertyName.construct(info.property());
/*  645 */     return new ObjectIdInfo(name, info.scope(), info.generator(), info.resolver());
/*      */   }
/*      */   
/*      */   public ObjectIdInfo findObjectReferenceInfo(Annotated ann, ObjectIdInfo objectIdInfo)
/*      */   {
/*  650 */     com.fasterxml.jackson.annotation.JsonIdentityReference ref = (com.fasterxml.jackson.annotation.JsonIdentityReference)_findAnnotation(ann, com.fasterxml.jackson.annotation.JsonIdentityReference.class);
/*  651 */     if (ref == null) {
/*  652 */       return objectIdInfo;
/*      */     }
/*  654 */     if (objectIdInfo == null) {
/*  655 */       objectIdInfo = ObjectIdInfo.empty();
/*      */     }
/*  657 */     return objectIdInfo.withAlwaysAsId(ref.alwaysAsId());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object findSerializer(Annotated a)
/*      */   {
/*  669 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  670 */     if (ann != null)
/*      */     {
/*  672 */       Class<? extends com.fasterxml.jackson.databind.JsonSerializer> serClass = ann.using();
/*  673 */       if (serClass != com.fasterxml.jackson.databind.JsonSerializer.None.class) {
/*  674 */         return serClass;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  682 */     com.fasterxml.jackson.annotation.JsonRawValue annRaw = (com.fasterxml.jackson.annotation.JsonRawValue)_findAnnotation(a, com.fasterxml.jackson.annotation.JsonRawValue.class);
/*  683 */     if ((annRaw != null) && (annRaw.value()))
/*      */     {
/*  685 */       Class<?> cls = a.getRawType();
/*  686 */       return new com.fasterxml.jackson.databind.ser.std.RawSerializer(cls);
/*      */     }
/*  688 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object findKeySerializer(Annotated a)
/*      */   {
/*  694 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  695 */     if (ann != null)
/*      */     {
/*  697 */       Class<? extends com.fasterxml.jackson.databind.JsonSerializer> serClass = ann.keyUsing();
/*  698 */       if (serClass != com.fasterxml.jackson.databind.JsonSerializer.None.class) {
/*  699 */         return serClass;
/*      */       }
/*      */     }
/*  702 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object findContentSerializer(Annotated a)
/*      */   {
/*  708 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  709 */     if (ann != null)
/*      */     {
/*  711 */       Class<? extends com.fasterxml.jackson.databind.JsonSerializer> serClass = ann.contentUsing();
/*  712 */       if (serClass != com.fasterxml.jackson.databind.JsonSerializer.None.class) {
/*  713 */         return serClass;
/*      */       }
/*      */     }
/*  716 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object findNullSerializer(Annotated a)
/*      */   {
/*  722 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  723 */     if (ann != null)
/*      */     {
/*  725 */       Class<? extends com.fasterxml.jackson.databind.JsonSerializer> serClass = ann.nullsUsing();
/*  726 */       if (serClass != com.fasterxml.jackson.databind.JsonSerializer.None.class) {
/*  727 */         return serClass;
/*      */       }
/*      */     }
/*  730 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public JsonInclude.Value findPropertyInclusion(Annotated a)
/*      */   {
/*  736 */     com.fasterxml.jackson.annotation.JsonInclude inc = (com.fasterxml.jackson.annotation.JsonInclude)_findAnnotation(a, com.fasterxml.jackson.annotation.JsonInclude.class);
/*  737 */     JsonInclude.Value value = inc == null ? JsonInclude.Value.empty() : JsonInclude.Value.from(inc);
/*      */     
/*      */ 
/*  740 */     if (value.getValueInclusion() == com.fasterxml.jackson.annotation.JsonInclude.Include.USE_DEFAULTS) {
/*  741 */       value = _refinePropertyInclusion(a, value);
/*      */     }
/*  743 */     return value;
/*      */   }
/*      */   
/*      */   private JsonInclude.Value _refinePropertyInclusion(Annotated a, JsonInclude.Value value)
/*      */   {
/*  748 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  749 */     if (ann != null) {
/*  750 */       switch (ann.include()) {
/*      */       case ALWAYS: 
/*  752 */         return value.withValueInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.ALWAYS);
/*      */       case NON_NULL: 
/*  754 */         return value.withValueInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
/*      */       case NON_DEFAULT: 
/*  756 */         return value.withValueInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_DEFAULT);
/*      */       case NON_EMPTY: 
/*  758 */         return value.withValueInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_EMPTY);
/*      */       }
/*      */       
/*      */     }
/*      */     
/*  763 */     return value;
/*      */   }
/*      */   
/*      */ 
/*      */   public com.fasterxml.jackson.databind.annotation.JsonSerialize.Typing findSerializationTyping(Annotated a)
/*      */   {
/*  769 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  770 */     return ann == null ? null : ann.typing();
/*      */   }
/*      */   
/*      */   public Object findSerializationConverter(Annotated a)
/*      */   {
/*  775 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  776 */     return ann == null ? null : _classIfExplicit(ann.converter(), com.fasterxml.jackson.databind.util.Converter.None.class);
/*      */   }
/*      */   
/*      */   public Object findSerializationContentConverter(AnnotatedMember a)
/*      */   {
/*  781 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  782 */     return ann == null ? null : _classIfExplicit(ann.contentConverter(), com.fasterxml.jackson.databind.util.Converter.None.class);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JavaType refineSerializationType(MapperConfig<?> config, Annotated a, JavaType baseType)
/*      */     throws JsonMappingException
/*      */   {
/*  795 */     JavaType type = baseType;
/*  796 */     TypeFactory tf = config.getTypeFactory();
/*      */     
/*  798 */     JsonSerialize jsonSer = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*      */     
/*      */ 
/*      */ 
/*  802 */     Class<?> serClass = jsonSer == null ? null : _classIfExplicit(jsonSer.as());
/*  803 */     if (serClass != null) {
/*  804 */       if (type.hasRawClass(serClass))
/*      */       {
/*      */ 
/*  807 */         type = type.withStaticTyping();
/*      */       } else {
/*  809 */         Class<?> currRaw = type.getRawClass();
/*      */         
/*      */         try
/*      */         {
/*  813 */           if (serClass.isAssignableFrom(currRaw)) {
/*  814 */             type = tf.constructGeneralizedType(type, serClass);
/*  815 */           } else if (currRaw.isAssignableFrom(serClass)) {
/*  816 */             type = tf.constructSpecializedType(type, serClass);
/*  817 */           } else if (_primitiveAndWrapper(currRaw, serClass))
/*      */           {
/*  819 */             type = type.withStaticTyping();
/*      */           }
/*      */           else {
/*  822 */             throw new JsonMappingException(null, String.format("Cannot refine serialization type %s into %s; types not related", new Object[] { type, serClass
/*  823 */               .getName() }));
/*      */           }
/*      */         }
/*      */         catch (IllegalArgumentException iae) {
/*  827 */           throw new JsonMappingException(null, String.format("Failed to widen type %s with annotation (value %s), from '%s': %s", new Object[] { type, serClass
/*  828 */             .getName(), a.getName(), iae.getMessage() }), iae);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  836 */     if (type.isMapLikeType()) {
/*  837 */       JavaType keyType = type.getKeyType();
/*  838 */       Class<?> keyClass = jsonSer == null ? null : _classIfExplicit(jsonSer.keyAs());
/*  839 */       if (keyClass != null) {
/*  840 */         if (keyType.hasRawClass(keyClass)) {
/*  841 */           keyType = keyType.withStaticTyping();
/*      */         } else {
/*  843 */           Class<?> currRaw = keyType.getRawClass();
/*      */           
/*      */ 
/*      */           try
/*      */           {
/*  848 */             if (keyClass.isAssignableFrom(currRaw)) {
/*  849 */               keyType = tf.constructGeneralizedType(keyType, keyClass);
/*  850 */             } else if (currRaw.isAssignableFrom(keyClass)) {
/*  851 */               keyType = tf.constructSpecializedType(keyType, keyClass);
/*  852 */             } else if (_primitiveAndWrapper(currRaw, keyClass))
/*      */             {
/*  854 */               keyType = keyType.withStaticTyping();
/*      */             }
/*      */             else {
/*  857 */               throw new JsonMappingException(null, String.format("Cannot refine serialization key type %s into %s; types not related", new Object[] { keyType, keyClass
/*  858 */                 .getName() }));
/*      */             }
/*      */           }
/*      */           catch (IllegalArgumentException iae) {
/*  862 */             throw new JsonMappingException(null, String.format("Failed to widen key type of %s with concrete-type annotation (value %s), from '%s': %s", new Object[] { type, keyClass
/*  863 */               .getName(), a.getName(), iae.getMessage() }), iae);
/*      */           }
/*      */         }
/*      */         
/*  867 */         type = ((com.fasterxml.jackson.databind.type.MapLikeType)type).withKeyType(keyType);
/*      */       }
/*      */     }
/*      */     
/*  871 */     JavaType contentType = type.getContentType();
/*  872 */     if (contentType != null)
/*      */     {
/*  874 */       Class<?> contentClass = jsonSer == null ? null : _classIfExplicit(jsonSer.contentAs());
/*  875 */       if (contentClass != null) {
/*  876 */         if (contentType.hasRawClass(contentClass)) {
/*  877 */           contentType = contentType.withStaticTyping();
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  882 */           Class<?> currRaw = contentType.getRawClass();
/*      */           try {
/*  884 */             if (contentClass.isAssignableFrom(currRaw)) {
/*  885 */               contentType = tf.constructGeneralizedType(contentType, contentClass);
/*  886 */             } else if (currRaw.isAssignableFrom(contentClass)) {
/*  887 */               contentType = tf.constructSpecializedType(contentType, contentClass);
/*  888 */             } else if (_primitiveAndWrapper(currRaw, contentClass))
/*      */             {
/*  890 */               contentType = contentType.withStaticTyping();
/*      */             }
/*      */             else {
/*  893 */               throw new JsonMappingException(null, String.format("Cannot refine serialization content type %s into %s; types not related", new Object[] { contentType, contentClass
/*  894 */                 .getName() }));
/*      */             }
/*      */           }
/*      */           catch (IllegalArgumentException iae) {
/*  898 */             throw new JsonMappingException(null, String.format("Internal error: failed to refine value type of %s with concrete-type annotation (value %s), from '%s': %s", new Object[] { type, contentClass
/*  899 */               .getName(), a.getName(), iae.getMessage() }), iae);
/*      */           }
/*      */         }
/*      */         
/*  903 */         type = type.withContentType(contentType);
/*      */       }
/*      */     }
/*  906 */     return type;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findSerializationType(Annotated am)
/*      */   {
/*  912 */     return null;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findSerializationKeyType(Annotated am, JavaType baseType)
/*      */   {
/*  918 */     return null;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findSerializationContentType(Annotated am, JavaType baseType)
/*      */   {
/*  924 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] findSerializationPropertyOrder(AnnotatedClass ac)
/*      */   {
/*  935 */     JsonPropertyOrder order = (JsonPropertyOrder)_findAnnotation(ac, JsonPropertyOrder.class);
/*  936 */     return order == null ? null : order.value();
/*      */   }
/*      */   
/*      */   public Boolean findSerializationSortAlphabetically(Annotated ann)
/*      */   {
/*  941 */     return _findSortAlpha(ann);
/*      */   }
/*      */   
/*      */   private final Boolean _findSortAlpha(Annotated ann) {
/*  945 */     JsonPropertyOrder order = (JsonPropertyOrder)_findAnnotation(ann, JsonPropertyOrder.class);
/*      */     
/*      */ 
/*  948 */     if ((order != null) && (order.alphabetic())) {
/*  949 */       return Boolean.TRUE;
/*      */     }
/*  951 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public void findAndAddVirtualProperties(MapperConfig<?> config, AnnotatedClass ac, List<BeanPropertyWriter> properties)
/*      */   {
/*  957 */     com.fasterxml.jackson.databind.annotation.JsonAppend ann = (com.fasterxml.jackson.databind.annotation.JsonAppend)_findAnnotation(ac, com.fasterxml.jackson.databind.annotation.JsonAppend.class);
/*  958 */     if (ann == null) {
/*  959 */       return;
/*      */     }
/*  961 */     boolean prepend = ann.prepend();
/*  962 */     JavaType propType = null;
/*      */     
/*      */ 
/*  965 */     JsonAppend.Attr[] attrs = ann.attrs();
/*  966 */     int i = 0; for (int len = attrs.length; i < len; i++) {
/*  967 */       if (propType == null) {
/*  968 */         propType = config.constructType(Object.class);
/*      */       }
/*  970 */       BeanPropertyWriter bpw = _constructVirtualProperty(attrs[i], config, ac, propType);
/*      */       
/*  972 */       if (prepend) {
/*  973 */         properties.add(i, bpw);
/*      */       } else {
/*  975 */         properties.add(bpw);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  980 */     JsonAppend.Prop[] props = ann.props();
/*  981 */     int i = 0; for (int len = props.length; i < len; i++) {
/*  982 */       BeanPropertyWriter bpw = _constructVirtualProperty(props[i], config, ac);
/*      */       
/*  984 */       if (prepend) {
/*  985 */         properties.add(i, bpw);
/*      */       } else {
/*  987 */         properties.add(bpw);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected BeanPropertyWriter _constructVirtualProperty(JsonAppend.Attr attr, MapperConfig<?> config, AnnotatedClass ac, JavaType type)
/*      */   {
/*  995 */     com.fasterxml.jackson.databind.PropertyMetadata metadata = attr.required() ? com.fasterxml.jackson.databind.PropertyMetadata.STD_REQUIRED : com.fasterxml.jackson.databind.PropertyMetadata.STD_OPTIONAL;
/*      */     
/*      */ 
/*  998 */     String attrName = attr.value();
/*      */     
/*      */ 
/* 1001 */     PropertyName propName = _propertyName(attr.propName(), attr.propNamespace());
/* 1002 */     if (!propName.hasSimpleName()) {
/* 1003 */       propName = PropertyName.construct(attrName);
/*      */     }
/*      */     
/* 1006 */     AnnotatedMember member = new VirtualAnnotatedMember(ac, ac.getRawType(), attrName, type);
/*      */     
/*      */ 
/* 1009 */     com.fasterxml.jackson.databind.util.SimpleBeanPropertyDefinition propDef = com.fasterxml.jackson.databind.util.SimpleBeanPropertyDefinition.construct(config, member, propName, metadata, attr
/* 1010 */       .include());
/*      */     
/* 1012 */     return com.fasterxml.jackson.databind.ser.impl.AttributePropertyWriter.construct(attrName, propDef, ac
/* 1013 */       .getAnnotations(), type);
/*      */   }
/*      */   
/*      */ 
/*      */   protected BeanPropertyWriter _constructVirtualProperty(JsonAppend.Prop prop, MapperConfig<?> config, AnnotatedClass ac)
/*      */   {
/* 1019 */     com.fasterxml.jackson.databind.PropertyMetadata metadata = prop.required() ? com.fasterxml.jackson.databind.PropertyMetadata.STD_REQUIRED : com.fasterxml.jackson.databind.PropertyMetadata.STD_OPTIONAL;
/*      */     
/* 1021 */     PropertyName propName = _propertyName(prop.name(), prop.namespace());
/* 1022 */     JavaType type = config.constructType(prop.type());
/*      */     
/*      */ 
/* 1025 */     AnnotatedMember member = new VirtualAnnotatedMember(ac, ac.getRawType(), propName.getSimpleName(), type);
/*      */     
/* 1027 */     com.fasterxml.jackson.databind.util.SimpleBeanPropertyDefinition propDef = com.fasterxml.jackson.databind.util.SimpleBeanPropertyDefinition.construct(config, member, propName, metadata, prop
/* 1028 */       .include());
/*      */     
/* 1030 */     Class<?> implClass = prop.value();
/*      */     
/* 1032 */     com.fasterxml.jackson.databind.cfg.HandlerInstantiator hi = config.getHandlerInstantiator();
/*      */     
/* 1034 */     com.fasterxml.jackson.databind.ser.VirtualBeanPropertyWriter bpw = hi == null ? null : hi.virtualPropertyWriterInstance(config, implClass);
/* 1035 */     if (bpw == null) {
/* 1036 */       bpw = (com.fasterxml.jackson.databind.ser.VirtualBeanPropertyWriter)ClassUtil.createInstance(implClass, config
/* 1037 */         .canOverrideAccessModifiers());
/*      */     }
/*      */     
/*      */ 
/* 1041 */     return bpw.withConfig(config, ac, propDef, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PropertyName findNameForSerialization(Annotated a)
/*      */   {
/* 1053 */     boolean useDefault = false;
/* 1054 */     com.fasterxml.jackson.annotation.JsonGetter jg = (com.fasterxml.jackson.annotation.JsonGetter)_findAnnotation(a, com.fasterxml.jackson.annotation.JsonGetter.class);
/* 1055 */     if (jg != null) {
/* 1056 */       String s = jg.value();
/*      */       
/* 1058 */       if (!s.isEmpty()) {
/* 1059 */         return PropertyName.construct(s);
/*      */       }
/* 1061 */       useDefault = true;
/*      */     }
/* 1063 */     JsonProperty pann = (JsonProperty)_findAnnotation(a, JsonProperty.class);
/* 1064 */     if (pann != null)
/*      */     {
/* 1066 */       String ns = pann.namespace();
/* 1067 */       if ((ns != null) && (ns.isEmpty())) {
/* 1068 */         ns = null;
/*      */       }
/* 1070 */       return PropertyName.construct(pann.value(), ns);
/*      */     }
/* 1072 */     if ((useDefault) || (_hasOneOf(a, ANNOTATIONS_TO_INFER_SER))) {
/* 1073 */       return PropertyName.USE_DEFAULT;
/*      */     }
/* 1075 */     return null;
/*      */   }
/*      */   
/*      */   public Boolean hasAsKey(MapperConfig<?> config, Annotated a)
/*      */   {
/* 1080 */     com.fasterxml.jackson.annotation.JsonKey ann = (com.fasterxml.jackson.annotation.JsonKey)_findAnnotation(a, com.fasterxml.jackson.annotation.JsonKey.class);
/* 1081 */     if (ann == null) {
/* 1082 */       return null;
/*      */     }
/* 1084 */     return Boolean.valueOf(ann.value());
/*      */   }
/*      */   
/*      */   public Boolean hasAsValue(Annotated a)
/*      */   {
/* 1089 */     JsonValue ann = (JsonValue)_findAnnotation(a, JsonValue.class);
/* 1090 */     if (ann == null) {
/* 1091 */       return null;
/*      */     }
/* 1093 */     return Boolean.valueOf(ann.value());
/*      */   }
/*      */   
/*      */   public Boolean hasAnyGetter(Annotated a)
/*      */   {
/* 1098 */     com.fasterxml.jackson.annotation.JsonAnyGetter ann = (com.fasterxml.jackson.annotation.JsonAnyGetter)_findAnnotation(a, com.fasterxml.jackson.annotation.JsonAnyGetter.class);
/* 1099 */     if (ann == null) {
/* 1100 */       return null;
/*      */     }
/* 1102 */     return Boolean.valueOf(ann.enabled());
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public boolean hasAnyGetterAnnotation(AnnotatedMethod am)
/*      */   {
/* 1109 */     return _hasAnnotation(am, com.fasterxml.jackson.annotation.JsonAnyGetter.class);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public boolean hasAsValueAnnotation(AnnotatedMethod am)
/*      */   {
/* 1115 */     JsonValue ann = (JsonValue)_findAnnotation(am, JsonValue.class);
/*      */     
/* 1117 */     return (ann != null) && (ann.value());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object findDeserializer(Annotated a)
/*      */   {
/* 1129 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1130 */     if (ann != null)
/*      */     {
/* 1132 */       Class<? extends com.fasterxml.jackson.databind.JsonDeserializer> deserClass = ann.using();
/* 1133 */       if (deserClass != com.fasterxml.jackson.databind.JsonDeserializer.None.class) {
/* 1134 */         return deserClass;
/*      */       }
/*      */     }
/* 1137 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object findKeyDeserializer(Annotated a)
/*      */   {
/* 1143 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1144 */     if (ann != null) {
/* 1145 */       Class<? extends com.fasterxml.jackson.databind.KeyDeserializer> deserClass = ann.keyUsing();
/* 1146 */       if (deserClass != com.fasterxml.jackson.databind.KeyDeserializer.None.class) {
/* 1147 */         return deserClass;
/*      */       }
/*      */     }
/* 1150 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object findContentDeserializer(Annotated a)
/*      */   {
/* 1156 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1157 */     if (ann != null)
/*      */     {
/* 1159 */       Class<? extends com.fasterxml.jackson.databind.JsonDeserializer> deserClass = ann.contentUsing();
/* 1160 */       if (deserClass != com.fasterxml.jackson.databind.JsonDeserializer.None.class) {
/* 1161 */         return deserClass;
/*      */       }
/*      */     }
/* 1164 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object findDeserializationConverter(Annotated a)
/*      */   {
/* 1170 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1171 */     return ann == null ? null : _classIfExplicit(ann.converter(), com.fasterxml.jackson.databind.util.Converter.None.class);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object findDeserializationContentConverter(AnnotatedMember a)
/*      */   {
/* 1177 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1178 */     return ann == null ? null : _classIfExplicit(ann.contentConverter(), com.fasterxml.jackson.databind.util.Converter.None.class);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JavaType refineDeserializationType(MapperConfig<?> config, Annotated a, JavaType baseType)
/*      */     throws JsonMappingException
/*      */   {
/* 1191 */     JavaType type = baseType;
/* 1192 */     TypeFactory tf = config.getTypeFactory();
/*      */     
/* 1194 */     JsonDeserialize jsonDeser = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/*      */     
/*      */ 
/* 1197 */     Class<?> valueClass = jsonDeser == null ? null : _classIfExplicit(jsonDeser.as());
/* 1198 */     if ((valueClass != null) && (!type.hasRawClass(valueClass)) && 
/* 1199 */       (!_primitiveAndWrapper(type, valueClass))) {
/*      */       try {
/* 1201 */         type = tf.constructSpecializedType(type, valueClass);
/*      */       }
/*      */       catch (IllegalArgumentException iae) {
/* 1204 */         throw new JsonMappingException(null, String.format("Failed to narrow type %s with annotation (value %s), from '%s': %s", new Object[] { type, valueClass
/* 1205 */           .getName(), a.getName(), iae.getMessage() }), iae);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1212 */     if (type.isMapLikeType()) {
/* 1213 */       JavaType keyType = type.getKeyType();
/* 1214 */       Class<?> keyClass = jsonDeser == null ? null : _classIfExplicit(jsonDeser.keyAs());
/* 1215 */       if ((keyClass != null) && 
/* 1216 */         (!_primitiveAndWrapper(keyType, keyClass))) {
/*      */         try {
/* 1218 */           keyType = tf.constructSpecializedType(keyType, keyClass);
/* 1219 */           type = ((com.fasterxml.jackson.databind.type.MapLikeType)type).withKeyType(keyType);
/*      */         }
/*      */         catch (IllegalArgumentException iae) {
/* 1222 */           throw new JsonMappingException(null, String.format("Failed to narrow key type of %s with concrete-type annotation (value %s), from '%s': %s", new Object[] { type, keyClass
/* 1223 */             .getName(), a.getName(), iae.getMessage() }), iae);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1228 */     JavaType contentType = type.getContentType();
/* 1229 */     if (contentType != null)
/*      */     {
/* 1231 */       Class<?> contentClass = jsonDeser == null ? null : _classIfExplicit(jsonDeser.contentAs());
/* 1232 */       if ((contentClass != null) && 
/* 1233 */         (!_primitiveAndWrapper(contentType, contentClass))) {
/*      */         try {
/* 1235 */           contentType = tf.constructSpecializedType(contentType, contentClass);
/* 1236 */           type = type.withContentType(contentType);
/*      */         }
/*      */         catch (IllegalArgumentException iae) {
/* 1239 */           throw new JsonMappingException(null, String.format("Failed to narrow value type of %s with concrete-type annotation (value %s), from '%s': %s", new Object[] { type, contentClass
/* 1240 */             .getName(), a.getName(), iae.getMessage() }), iae);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1245 */     return type;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findDeserializationContentType(Annotated am, JavaType baseContentType)
/*      */   {
/* 1251 */     return null;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findDeserializationType(Annotated am, JavaType baseType)
/*      */   {
/* 1257 */     return null;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public Class<?> findDeserializationKeyType(Annotated am, JavaType baseKeyType)
/*      */   {
/* 1263 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object findValueInstantiator(AnnotatedClass ac)
/*      */   {
/* 1275 */     com.fasterxml.jackson.databind.annotation.JsonValueInstantiator ann = (com.fasterxml.jackson.databind.annotation.JsonValueInstantiator)_findAnnotation(ac, com.fasterxml.jackson.databind.annotation.JsonValueInstantiator.class);
/*      */     
/* 1277 */     return ann == null ? null : ann.value();
/*      */   }
/*      */   
/*      */ 
/*      */   public Class<?> findPOJOBuilder(AnnotatedClass ac)
/*      */   {
/* 1283 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(ac, JsonDeserialize.class);
/* 1284 */     return ann == null ? null : _classIfExplicit(ann.builder());
/*      */   }
/*      */   
/*      */ 
/*      */   public com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder.Value findPOJOBuilderConfig(AnnotatedClass ac)
/*      */   {
/* 1290 */     com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder ann = (com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder)_findAnnotation(ac, com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder.class);
/* 1291 */     return ann == null ? null : new com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder.Value(ann);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PropertyName findNameForDeserialization(Annotated a)
/*      */   {
/* 1305 */     boolean useDefault = false;
/* 1306 */     JsonSetter js = (JsonSetter)_findAnnotation(a, JsonSetter.class);
/* 1307 */     if (js != null) {
/* 1308 */       String s = js.value();
/*      */       
/* 1310 */       if (s.isEmpty()) {
/* 1311 */         useDefault = true;
/*      */       } else {
/* 1313 */         return PropertyName.construct(s);
/*      */       }
/*      */     }
/* 1316 */     JsonProperty pann = (JsonProperty)_findAnnotation(a, JsonProperty.class);
/* 1317 */     if (pann != null)
/*      */     {
/* 1319 */       String ns = pann.namespace();
/* 1320 */       if ((ns != null) && (ns.isEmpty())) {
/* 1321 */         ns = null;
/*      */       }
/* 1323 */       return PropertyName.construct(pann.value(), ns);
/*      */     }
/* 1325 */     if ((useDefault) || (_hasOneOf(a, ANNOTATIONS_TO_INFER_DESER))) {
/* 1326 */       return PropertyName.USE_DEFAULT;
/*      */     }
/* 1328 */     return null;
/*      */   }
/*      */   
/*      */   public Boolean hasAnySetter(Annotated a)
/*      */   {
/* 1333 */     com.fasterxml.jackson.annotation.JsonAnySetter ann = (com.fasterxml.jackson.annotation.JsonAnySetter)_findAnnotation(a, com.fasterxml.jackson.annotation.JsonAnySetter.class);
/* 1334 */     return ann == null ? null : Boolean.valueOf(ann.enabled());
/*      */   }
/*      */   
/*      */   public com.fasterxml.jackson.annotation.JsonSetter.Value findSetterInfo(Annotated a)
/*      */   {
/* 1339 */     return com.fasterxml.jackson.annotation.JsonSetter.Value.from((JsonSetter)_findAnnotation(a, JsonSetter.class));
/*      */   }
/*      */   
/*      */   public Boolean findMergeInfo(Annotated a)
/*      */   {
/* 1344 */     com.fasterxml.jackson.annotation.JsonMerge ann = (com.fasterxml.jackson.annotation.JsonMerge)_findAnnotation(a, com.fasterxml.jackson.annotation.JsonMerge.class);
/* 1345 */     return ann == null ? null : ann.value().asBoolean();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public boolean hasAnySetterAnnotation(AnnotatedMethod am)
/*      */   {
/* 1351 */     return _hasAnnotation(am, com.fasterxml.jackson.annotation.JsonAnySetter.class);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public boolean hasCreatorAnnotation(Annotated a)
/*      */   {
/* 1361 */     JsonCreator ann = (JsonCreator)_findAnnotation(a, JsonCreator.class);
/* 1362 */     if (ann != null) {
/* 1363 */       return ann.mode() != com.fasterxml.jackson.annotation.JsonCreator.Mode.DISABLED;
/*      */     }
/*      */     
/*      */ 
/* 1367 */     if ((this._cfgConstructorPropertiesImpliesCreator) && 
/* 1368 */       ((a instanceof AnnotatedConstructor)) && 
/* 1369 */       (_java7Helper != null)) {
/* 1370 */       Boolean b = _java7Helper.hasCreatorAnnotation(a);
/* 1371 */       if (b != null) {
/* 1372 */         return b.booleanValue();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1377 */     return false;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public com.fasterxml.jackson.annotation.JsonCreator.Mode findCreatorBinding(Annotated a)
/*      */   {
/* 1383 */     JsonCreator ann = (JsonCreator)_findAnnotation(a, JsonCreator.class);
/* 1384 */     return ann == null ? null : ann.mode();
/*      */   }
/*      */   
/*      */   public com.fasterxml.jackson.annotation.JsonCreator.Mode findCreatorAnnotation(MapperConfig<?> config, Annotated a)
/*      */   {
/* 1389 */     JsonCreator ann = (JsonCreator)_findAnnotation(a, JsonCreator.class);
/* 1390 */     if (ann != null) {
/* 1391 */       return ann.mode();
/*      */     }
/* 1393 */     if ((this._cfgConstructorPropertiesImpliesCreator) && 
/* 1394 */       (config.isEnabled(com.fasterxml.jackson.databind.MapperFeature.INFER_CREATOR_FROM_CONSTRUCTOR_PROPERTIES)))
/*      */     {
/* 1396 */       if (((a instanceof AnnotatedConstructor)) && 
/* 1397 */         (_java7Helper != null)) {
/* 1398 */         Boolean b = _java7Helper.hasCreatorAnnotation(a);
/* 1399 */         if ((b != null) && (b.booleanValue()))
/*      */         {
/*      */ 
/* 1402 */           return com.fasterxml.jackson.annotation.JsonCreator.Mode.PROPERTIES;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1407 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean _isIgnorable(Annotated a)
/*      */   {
/* 1418 */     com.fasterxml.jackson.annotation.JsonIgnore ann = (com.fasterxml.jackson.annotation.JsonIgnore)_findAnnotation(a, com.fasterxml.jackson.annotation.JsonIgnore.class);
/* 1419 */     if (ann != null) {
/* 1420 */       return ann.value();
/*      */     }
/* 1422 */     if (_java7Helper != null) {
/* 1423 */       Boolean b = _java7Helper.findTransient(a);
/* 1424 */       if (b != null) {
/* 1425 */         return b.booleanValue();
/*      */       }
/*      */     }
/* 1428 */     return false;
/*      */   }
/*      */   
/*      */   protected Class<?> _classIfExplicit(Class<?> cls) {
/* 1432 */     if ((cls == null) || (ClassUtil.isBogusClass(cls))) {
/* 1433 */       return null;
/*      */     }
/* 1435 */     return cls;
/*      */   }
/*      */   
/*      */   protected Class<?> _classIfExplicit(Class<?> cls, Class<?> implicit) {
/* 1439 */     cls = _classIfExplicit(cls);
/* 1440 */     return (cls == null) || (cls == implicit) ? null : cls;
/*      */   }
/*      */   
/*      */   protected PropertyName _propertyName(String localName, String namespace) {
/* 1444 */     if (localName.isEmpty()) {
/* 1445 */       return PropertyName.USE_DEFAULT;
/*      */     }
/* 1447 */     if ((namespace == null) || (namespace.isEmpty())) {
/* 1448 */       return PropertyName.construct(localName);
/*      */     }
/* 1450 */     return PropertyName.construct(localName, namespace);
/*      */   }
/*      */   
/*      */   protected PropertyName _findConstructorName(Annotated a)
/*      */   {
/* 1455 */     if ((a instanceof AnnotatedParameter)) {
/* 1456 */       AnnotatedParameter p = (AnnotatedParameter)a;
/* 1457 */       AnnotatedWithParams ctor = p.getOwner();
/*      */       
/* 1459 */       if ((ctor != null) && 
/* 1460 */         (_java7Helper != null)) {
/* 1461 */         PropertyName name = _java7Helper.findConstructorName(p);
/* 1462 */         if (name != null) {
/* 1463 */           return name;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1468 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected TypeResolverBuilder<?> _findTypeResolver(MapperConfig<?> config, Annotated ann, JavaType baseType)
/*      */   {
/* 1481 */     JsonTypeInfo info = (JsonTypeInfo)_findAnnotation(ann, JsonTypeInfo.class);
/* 1482 */     com.fasterxml.jackson.databind.annotation.JsonTypeResolver resAnn = (com.fasterxml.jackson.databind.annotation.JsonTypeResolver)_findAnnotation(ann, com.fasterxml.jackson.databind.annotation.JsonTypeResolver.class);
/*      */     TypeResolverBuilder<?> b;
/* 1484 */     if (resAnn != null) {
/* 1485 */       if (info == null) {
/* 1486 */         return null;
/*      */       }
/*      */       
/*      */ 
/* 1490 */       b = config.typeResolverBuilderInstance(ann, resAnn.value());
/*      */     } else {
/* 1492 */       if (info == null) {
/* 1493 */         return null;
/*      */       }
/*      */       
/* 1496 */       if (info.use() == com.fasterxml.jackson.annotation.JsonTypeInfo.Id.NONE) {
/* 1497 */         return _constructNoTypeResolverBuilder();
/*      */       }
/* 1499 */       b = _constructStdTypeResolverBuilder();
/*      */     }
/*      */     
/* 1502 */     com.fasterxml.jackson.databind.annotation.JsonTypeIdResolver idResInfo = (com.fasterxml.jackson.databind.annotation.JsonTypeIdResolver)_findAnnotation(ann, com.fasterxml.jackson.databind.annotation.JsonTypeIdResolver.class);
/*      */     
/* 1504 */     com.fasterxml.jackson.databind.jsontype.TypeIdResolver idRes = idResInfo == null ? null : config.typeIdResolverInstance(ann, idResInfo.value());
/* 1505 */     if (idRes != null) {
/* 1506 */       idRes.init(baseType);
/*      */     }
/* 1508 */     TypeResolverBuilder<?> b = b.init(info.use(), idRes);
/*      */     
/*      */ 
/*      */ 
/* 1512 */     com.fasterxml.jackson.annotation.JsonTypeInfo.As inclusion = info.include();
/* 1513 */     if ((inclusion == com.fasterxml.jackson.annotation.JsonTypeInfo.As.EXTERNAL_PROPERTY) && ((ann instanceof AnnotatedClass))) {
/* 1514 */       inclusion = com.fasterxml.jackson.annotation.JsonTypeInfo.As.PROPERTY;
/*      */     }
/* 1516 */     b = b.inclusion(inclusion);
/* 1517 */     b = b.typeProperty(info.property());
/* 1518 */     Class<?> defaultImpl = info.defaultImpl();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1524 */     if ((defaultImpl != com.fasterxml.jackson.annotation.JsonTypeInfo.None.class) && (!defaultImpl.isAnnotation())) {
/* 1525 */       b = b.defaultImpl(defaultImpl);
/*      */     }
/* 1527 */     b = b.typeIdVisibility(info.visible());
/* 1528 */     return b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder _constructStdTypeResolverBuilder()
/*      */   {
/* 1536 */     return new com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder _constructNoTypeResolverBuilder()
/*      */   {
/* 1544 */     return com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder.noTypeInfoBuilder();
/*      */   }
/*      */   
/*      */   private boolean _primitiveAndWrapper(Class<?> baseType, Class<?> refinement)
/*      */   {
/* 1549 */     if (baseType.isPrimitive()) {
/* 1550 */       return baseType == ClassUtil.primitiveType(refinement);
/*      */     }
/* 1552 */     if (refinement.isPrimitive()) {
/* 1553 */       return refinement == ClassUtil.primitiveType(baseType);
/*      */     }
/* 1555 */     return false;
/*      */   }
/*      */   
/*      */   private boolean _primitiveAndWrapper(JavaType baseType, Class<?> refinement)
/*      */   {
/* 1560 */     if (baseType.isPrimitive()) {
/* 1561 */       return baseType.hasRawClass(ClassUtil.primitiveType(refinement));
/*      */     }
/* 1563 */     if (refinement.isPrimitive()) {
/* 1564 */       return refinement == ClassUtil.primitiveType(baseType.getRawClass());
/*      */     }
/* 1566 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\introspect\JacksonAnnotationIntrospector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */