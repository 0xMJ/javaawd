/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties.Value;
/*     */ import com.fasterxml.jackson.annotation.JsonIncludeProperties.Value;
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerators.PropertyGenerator;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector.ReferenceProperty;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.BeanProperty.Std;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.cfg.ConfigOverride;
/*     */ import com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedField;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.FilteredBeanPropertyWriter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.ObjectIdWriter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertyBasedObjectIdGenerator;
/*     */ import com.fasterxml.jackson.databind.ser.impl.UnsupportedTypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.MapSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer;
/*     */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*     */ import com.fasterxml.jackson.databind.util.BeanUtil;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanSerializerFactory
/*     */   extends BasicSerializerFactory
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  68 */   public static final BeanSerializerFactory instance = new BeanSerializerFactory(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BeanSerializerFactory(SerializerFactoryConfig config)
/*     */   {
/*  81 */     super(config);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SerializerFactory withConfig(SerializerFactoryConfig config)
/*     */   {
/*  93 */     if (this._factoryConfig == config) {
/*  94 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */     if (getClass() != BeanSerializerFactory.class) {
/* 103 */       throw new IllegalStateException("Subtype of BeanSerializerFactory (" + getClass().getName() + ") has not properly overridden method 'withAdditionalSerializers': cannot instantiate subtype with additional serializer definitions");
/*     */     }
/*     */     
/*     */ 
/* 107 */     return new BeanSerializerFactory(config);
/*     */   }
/*     */   
/*     */   protected Iterable<Serializers> customSerializers()
/*     */   {
/* 112 */     return this._factoryConfig.serializers();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonSerializer<Object> createSerializer(SerializerProvider prov, JavaType origType)
/*     */     throws JsonMappingException
/*     */   {
/* 138 */     SerializationConfig config = prov.getConfig();
/* 139 */     BeanDescription beanDesc = config.introspect(origType);
/* 140 */     JsonSerializer<?> ser = findSerializerFromAnnotation(prov, beanDesc.getClassInfo());
/* 141 */     if (ser != null) {
/* 142 */       return ser;
/*     */     }
/*     */     
/*     */ 
/* 146 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/*     */     
/*     */     JavaType type;
/* 149 */     if (intr == null) {
/* 150 */       type = origType;
/*     */     } else
/*     */       try {
/* 153 */         type = intr.refineSerializationType(config, beanDesc.getClassInfo(), origType);
/*     */       } catch (JsonMappingException e) { JavaType type;
/* 155 */         return (JsonSerializer)prov.reportBadTypeDefinition(beanDesc, e.getMessage(), new Object[0]); }
/*     */     JavaType type;
/*     */     boolean staticTyping;
/* 158 */     boolean staticTyping; if (type == origType) {
/* 159 */       staticTyping = false;
/*     */     } else {
/* 161 */       staticTyping = true;
/* 162 */       if (!type.hasRawClass(origType.getRawClass())) {
/* 163 */         beanDesc = config.introspect(type);
/*     */       }
/*     */     }
/*     */     
/* 167 */     Converter<Object, Object> conv = beanDesc.findSerializationConverter();
/* 168 */     if (conv == null) {
/* 169 */       return _createSerializer2(prov, type, beanDesc, staticTyping);
/*     */     }
/* 171 */     JavaType delegateType = conv.getOutputType(prov.getTypeFactory());
/*     */     
/*     */ 
/* 174 */     if (!delegateType.hasRawClass(type.getRawClass())) {
/* 175 */       beanDesc = config.introspect(delegateType);
/*     */       
/* 177 */       ser = findSerializerFromAnnotation(prov, beanDesc.getClassInfo());
/*     */     }
/*     */     
/* 180 */     if ((ser == null) && (!delegateType.isJavaLangObject())) {
/* 181 */       ser = _createSerializer2(prov, delegateType, beanDesc, true);
/*     */     }
/* 183 */     return new StdDelegatingSerializer(conv, delegateType, ser);
/*     */   }
/*     */   
/*     */ 
/*     */   protected JsonSerializer<?> _createSerializer2(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping)
/*     */     throws JsonMappingException
/*     */   {
/* 190 */     JsonSerializer<?> ser = null;
/* 191 */     SerializationConfig config = prov.getConfig();
/*     */     
/*     */ 
/*     */ 
/* 195 */     if (type.isContainerType()) {
/* 196 */       if (!staticTyping) {
/* 197 */         staticTyping = usesStaticTyping(config, beanDesc, null);
/*     */       }
/*     */       
/* 200 */       ser = buildContainerSerializer(prov, type, beanDesc, staticTyping);
/*     */       
/* 202 */       if (ser != null) {
/* 203 */         return ser;
/*     */       }
/*     */     } else {
/* 206 */       if (type.isReferenceType()) {
/* 207 */         ser = findReferenceSerializer(prov, (ReferenceType)type, beanDesc, staticTyping);
/*     */       }
/*     */       else {
/* 210 */         for (Serializers serializers : customSerializers()) {
/* 211 */           ser = serializers.findSerializer(config, type, beanDesc);
/* 212 */           if (ser != null) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 219 */       if (ser == null) {
/* 220 */         ser = findSerializerByAnnotations(prov, type, beanDesc);
/*     */       }
/*     */     }
/*     */     
/* 224 */     if (ser == null)
/*     */     {
/*     */ 
/*     */ 
/* 228 */       ser = findSerializerByLookup(type, config, beanDesc, staticTyping);
/* 229 */       if (ser == null) {
/* 230 */         ser = findSerializerByPrimaryType(prov, type, beanDesc, staticTyping);
/* 231 */         if (ser == null)
/*     */         {
/*     */ 
/*     */ 
/* 235 */           ser = findBeanOrAddOnSerializer(prov, type, beanDesc, staticTyping);
/*     */           
/*     */ 
/*     */ 
/* 239 */           if (ser == null) {
/* 240 */             ser = prov.getUnknownTypeSerializer(beanDesc.getBeanClass());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 245 */     if (ser != null)
/*     */     {
/* 247 */       if (this._factoryConfig.hasSerializerModifiers()) {
/* 248 */         for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 249 */           ser = mod.modifySerializer(config, beanDesc, ser);
/*     */         }
/*     */       }
/*     */     }
/* 253 */     return ser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public JsonSerializer<Object> findBeanSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc)
/*     */     throws JsonMappingException
/*     */   {
/* 268 */     return findBeanOrAddOnSerializer(prov, type, beanDesc, prov.isEnabled(MapperFeature.USE_STATIC_TYPING));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonSerializer<Object> findBeanOrAddOnSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping)
/*     */     throws JsonMappingException
/*     */   {
/* 283 */     if (!isPotentialBeanType(type.getRawClass()))
/*     */     {
/*     */ 
/* 286 */       if (!ClassUtil.isEnumType(type.getRawClass())) {
/* 287 */         return null;
/*     */       }
/*     */     }
/* 290 */     return constructBeanOrAddOnSerializer(prov, type, beanDesc, staticTyping);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeSerializer findPropertyTypeSerializer(JavaType baseType, SerializationConfig config, AnnotatedMember accessor)
/*     */     throws JsonMappingException
/*     */   {
/* 307 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 308 */     TypeResolverBuilder<?> b = ai.findPropertyTypeResolver(config, accessor, baseType);
/*     */     
/*     */     TypeSerializer typeSer;
/*     */     TypeSerializer typeSer;
/* 312 */     if (b == null) {
/* 313 */       typeSer = createTypeSerializer(config, baseType);
/*     */     } else {
/* 315 */       Collection<NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByClass(config, accessor, baseType);
/*     */       
/* 317 */       typeSer = b.buildTypeSerializer(config, baseType, subtypes);
/*     */     }
/* 319 */     return typeSer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypeSerializer findPropertyContentTypeSerializer(JavaType containerType, SerializationConfig config, AnnotatedMember accessor)
/*     */     throws JsonMappingException
/*     */   {
/* 336 */     JavaType contentType = containerType.getContentType();
/* 337 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 338 */     TypeResolverBuilder<?> b = ai.findPropertyContentTypeResolver(config, accessor, containerType);
/*     */     
/*     */     TypeSerializer typeSer;
/*     */     TypeSerializer typeSer;
/* 342 */     if (b == null) {
/* 343 */       typeSer = createTypeSerializer(config, contentType);
/*     */     } else {
/* 345 */       Collection<NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByClass(config, accessor, contentType);
/*     */       
/* 347 */       typeSer = b.buildTypeSerializer(config, contentType, subtypes);
/*     */     }
/* 349 */     return typeSer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected JsonSerializer<Object> constructBeanSerializer(SerializerProvider prov, BeanDescription beanDesc)
/*     */     throws JsonMappingException
/*     */   {
/* 363 */     return constructBeanOrAddOnSerializer(prov, beanDesc.getType(), beanDesc, prov.isEnabled(MapperFeature.USE_STATIC_TYPING));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonSerializer<Object> constructBeanOrAddOnSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping)
/*     */     throws JsonMappingException
/*     */   {
/* 379 */     if (beanDesc.getBeanClass() == Object.class) {
/* 380 */       return prov.getUnknownTypeSerializer(Object.class);
/*     */     }
/*     */     
/*     */ 
/* 384 */     JsonSerializer<?> ser = _findUnsupportedTypeSerializer(prov, type, beanDesc);
/* 385 */     if (ser != null) {
/* 386 */       return ser;
/*     */     }
/*     */     
/* 389 */     SerializationConfig config = prov.getConfig();
/* 390 */     BeanSerializerBuilder builder = constructBeanSerializerBuilder(beanDesc);
/* 391 */     builder.setConfig(config);
/*     */     
/*     */ 
/* 394 */     List<BeanPropertyWriter> props = findBeanProperties(prov, beanDesc, builder);
/* 395 */     if (props == null) {
/* 396 */       props = new ArrayList();
/*     */     } else {
/* 398 */       props = removeOverlappingTypeIds(prov, beanDesc, builder, props);
/*     */     }
/*     */     
/*     */ 
/* 402 */     prov.getAnnotationIntrospector().findAndAddVirtualProperties(config, beanDesc.getClassInfo(), props);
/*     */     
/*     */ 
/* 405 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 406 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 407 */         props = mod.changeProperties(config, beanDesc, props);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 412 */     props = filterBeanProperties(config, beanDesc, props);
/*     */     
/*     */ 
/* 415 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 416 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 417 */         props = mod.orderProperties(config, beanDesc, props);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 424 */     builder.setObjectIdWriter(constructObjectIdHandler(prov, beanDesc, props));
/*     */     
/* 426 */     builder.setProperties(props);
/* 427 */     builder.setFilterId(findFilterId(config, beanDesc));
/*     */     
/* 429 */     AnnotatedMember anyGetter = beanDesc.findAnyGetter();
/* 430 */     JavaType anyType; if (anyGetter != null) {
/* 431 */       anyType = anyGetter.getType();
/*     */       
/* 433 */       JavaType valueType = anyType.getContentType();
/* 434 */       TypeSerializer typeSer = createTypeSerializer(config, valueType);
/*     */       
/*     */ 
/* 437 */       JsonSerializer<?> anySer = findSerializerFromAnnotation(prov, anyGetter);
/* 438 */       if (anySer == null)
/*     */       {
/* 440 */         anySer = MapSerializer.construct((Set)null, anyType, config
/* 441 */           .isEnabled(MapperFeature.USE_STATIC_TYPING), typeSer, null, null, null);
/*     */       }
/*     */       
/*     */ 
/* 445 */       PropertyName name = PropertyName.construct(anyGetter.getName());
/* 446 */       BeanProperty.Std anyProp = new BeanProperty.Std(name, valueType, null, anyGetter, PropertyMetadata.STD_OPTIONAL);
/*     */       
/* 448 */       builder.setAnyGetter(new AnyGetterWriter(anyProp, anyGetter, anySer));
/*     */     }
/*     */     
/* 451 */     processViews(config, builder);
/*     */     
/*     */ 
/* 454 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 455 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 456 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 461 */       ser = builder.build();
/*     */     } catch (RuntimeException e) {
/* 463 */       return (JsonSerializer)prov.reportBadTypeDefinition(beanDesc, "Failed to construct BeanSerializer for %s: (%s) %s", new Object[] {beanDesc
/* 464 */         .getType(), e.getClass().getName(), e.getMessage() });
/*     */     }
/* 466 */     if (ser == null)
/*     */     {
/* 468 */       if (type.isRecordType()) {
/* 469 */         return builder.createDummy();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 474 */       ser = findSerializerByAddonType(config, type, beanDesc, staticTyping);
/* 475 */       if (ser == null)
/*     */       {
/*     */ 
/*     */ 
/* 479 */         if (beanDesc.hasKnownClassAnnotations()) {
/* 480 */           return builder.createDummy();
/*     */         }
/*     */       }
/*     */     }
/* 484 */     return ser;
/*     */   }
/*     */   
/*     */ 
/*     */   protected ObjectIdWriter constructObjectIdHandler(SerializerProvider prov, BeanDescription beanDesc, List<BeanPropertyWriter> props)
/*     */     throws JsonMappingException
/*     */   {
/* 491 */     ObjectIdInfo objectIdInfo = beanDesc.getObjectIdInfo();
/* 492 */     if (objectIdInfo == null) {
/* 493 */       return null;
/*     */     }
/*     */     
/* 496 */     Class<?> implClass = objectIdInfo.getGeneratorType();
/*     */     
/*     */ 
/* 499 */     if (implClass == ObjectIdGenerators.PropertyGenerator.class) {
/* 500 */       String propName = objectIdInfo.getPropertyName().getSimpleName();
/* 501 */       BeanPropertyWriter idProp = null;
/*     */       
/* 503 */       int i = 0; for (int len = props.size();; i++) {
/* 504 */         if (i == len) {
/* 505 */           throw new IllegalArgumentException(String.format("Invalid Object Id definition for %s: cannot find property with name %s", new Object[] {
/*     */           
/* 507 */             ClassUtil.getTypeDescription(beanDesc.getType()), ClassUtil.name(propName) }));
/*     */         }
/* 509 */         BeanPropertyWriter prop = (BeanPropertyWriter)props.get(i);
/* 510 */         if (propName.equals(prop.getName())) {
/* 511 */           idProp = prop;
/*     */           
/*     */ 
/* 514 */           if (i <= 0) break;
/* 515 */           props.remove(i);
/* 516 */           props.add(0, idProp); break;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 521 */       JavaType idType = idProp.getType();
/* 522 */       ObjectIdGenerator<?> gen = new PropertyBasedObjectIdGenerator(objectIdInfo, idProp);
/*     */       
/* 524 */       return ObjectIdWriter.construct(idType, (PropertyName)null, gen, objectIdInfo.getAlwaysAsId());
/*     */     }
/*     */     
/*     */ 
/* 528 */     JavaType type = prov.constructType(implClass);
/*     */     
/* 530 */     JavaType idType = prov.getTypeFactory().findTypeParameters(type, ObjectIdGenerator.class)[0];
/* 531 */     ObjectIdGenerator<?> gen = prov.objectIdGeneratorInstance(beanDesc.getClassInfo(), objectIdInfo);
/* 532 */     return ObjectIdWriter.construct(idType, objectIdInfo.getPropertyName(), gen, objectIdInfo
/* 533 */       .getAlwaysAsId());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BeanPropertyWriter constructFilteredBeanWriter(BeanPropertyWriter writer, Class<?>[] inViews)
/*     */   {
/* 544 */     return FilteredBeanPropertyWriter.constructViewBased(writer, inViews);
/*     */   }
/*     */   
/*     */ 
/*     */   protected PropertyBuilder constructPropertyBuilder(SerializationConfig config, BeanDescription beanDesc)
/*     */   {
/* 550 */     return new PropertyBuilder(config, beanDesc);
/*     */   }
/*     */   
/*     */   protected BeanSerializerBuilder constructBeanSerializerBuilder(BeanDescription beanDesc) {
/* 554 */     return new BeanSerializerBuilder(beanDesc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isPotentialBeanType(Class<?> type)
/*     */   {
/* 573 */     return (ClassUtil.canBeABeanType(type) == null) && (!ClassUtil.isProxyType(type));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<BeanPropertyWriter> findBeanProperties(SerializerProvider prov, BeanDescription beanDesc, BeanSerializerBuilder builder)
/*     */     throws JsonMappingException
/*     */   {
/* 584 */     List<BeanPropertyDefinition> properties = beanDesc.findProperties();
/* 585 */     SerializationConfig config = prov.getConfig();
/*     */     
/*     */ 
/* 588 */     removeIgnorableTypes(config, beanDesc, properties);
/*     */     
/*     */ 
/* 591 */     if (config.isEnabled(MapperFeature.REQUIRE_SETTERS_FOR_GETTERS)) {
/* 592 */       removeSetterlessGetters(config, beanDesc, properties);
/*     */     }
/*     */     
/*     */ 
/* 596 */     if (properties.isEmpty()) {
/* 597 */       return null;
/*     */     }
/*     */     
/* 600 */     boolean staticTyping = usesStaticTyping(config, beanDesc, null);
/* 601 */     PropertyBuilder pb = constructPropertyBuilder(config, beanDesc);
/*     */     
/* 603 */     ArrayList<BeanPropertyWriter> result = new ArrayList(properties.size());
/* 604 */     for (BeanPropertyDefinition property : properties) {
/* 605 */       AnnotatedMember accessor = property.getAccessor();
/*     */       
/* 607 */       if (property.isTypeId()) {
/* 608 */         if (accessor != null) {
/* 609 */           builder.setTypeId(accessor);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 614 */         AnnotationIntrospector.ReferenceProperty refType = property.findReferenceType();
/* 615 */         if ((refType == null) || (!refType.isBackReference()))
/*     */         {
/*     */ 
/* 618 */           if ((accessor instanceof AnnotatedMethod)) {
/* 619 */             result.add(_constructWriter(prov, property, pb, staticTyping, (AnnotatedMethod)accessor));
/*     */           } else
/* 621 */             result.add(_constructWriter(prov, property, pb, staticTyping, (AnnotatedField)accessor)); }
/*     */       }
/*     */     }
/* 624 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<BeanPropertyWriter> filterBeanProperties(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyWriter> props)
/*     */   {
/* 644 */     JsonIgnoreProperties.Value ignorals = config.getDefaultPropertyIgnorals(beanDesc.getBeanClass(), beanDesc
/* 645 */       .getClassInfo());
/* 646 */     Set<String> ignored = null;
/* 647 */     if (ignorals != null) {
/* 648 */       ignored = ignorals.findIgnoredForSerialization();
/*     */     }
/* 650 */     JsonIncludeProperties.Value inclusions = config.getDefaultPropertyInclusions(beanDesc.getBeanClass(), beanDesc
/* 651 */       .getClassInfo());
/* 652 */     Set<String> included = null;
/* 653 */     if (inclusions != null) {
/* 654 */       included = inclusions.getIncluded();
/*     */     }
/* 656 */     if ((included != null) || ((ignored != null) && (!ignored.isEmpty()))) {
/* 657 */       Iterator<BeanPropertyWriter> it = props.iterator();
/* 658 */       while (it.hasNext()) {
/* 659 */         if (IgnorePropertiesUtil.shouldIgnore(((BeanPropertyWriter)it.next()).getName(), ignored, included)) {
/* 660 */           it.remove();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 665 */     return props;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void processViews(SerializationConfig config, BeanSerializerBuilder builder)
/*     */   {
/* 680 */     List<BeanPropertyWriter> props = builder.getProperties();
/* 681 */     boolean includeByDefault = config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION);
/* 682 */     int propCount = props.size();
/* 683 */     int viewsFound = 0;
/* 684 */     BeanPropertyWriter[] filtered = new BeanPropertyWriter[propCount];
/*     */     
/* 686 */     for (int i = 0; i < propCount; i++) {
/* 687 */       BeanPropertyWriter bpw = (BeanPropertyWriter)props.get(i);
/* 688 */       Class<?>[] views = bpw.getViews();
/* 689 */       if ((views == null) || (views.length == 0))
/*     */       {
/*     */ 
/* 692 */         if (includeByDefault) {
/* 693 */           filtered[i] = bpw;
/*     */         }
/*     */       } else {
/* 696 */         viewsFound++;
/* 697 */         filtered[i] = constructFilteredBeanWriter(bpw, views);
/*     */       }
/*     */     }
/*     */     
/* 701 */     if ((includeByDefault) && (viewsFound == 0)) {
/* 702 */       return;
/*     */     }
/* 704 */     builder.setFilteredProperties(filtered);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void removeIgnorableTypes(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyDefinition> properties)
/*     */   {
/* 716 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 717 */     HashMap<Class<?>, Boolean> ignores = new HashMap();
/* 718 */     Iterator<BeanPropertyDefinition> it = properties.iterator();
/* 719 */     while (it.hasNext()) {
/* 720 */       BeanPropertyDefinition property = (BeanPropertyDefinition)it.next();
/* 721 */       AnnotatedMember accessor = property.getAccessor();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 726 */       if (accessor == null) {
/* 727 */         it.remove();
/*     */       }
/*     */       else {
/* 730 */         Class<?> type = property.getRawPrimaryType();
/* 731 */         Boolean result = (Boolean)ignores.get(type);
/* 732 */         if (result == null)
/*     */         {
/* 734 */           result = config.getConfigOverride(type).getIsIgnoredType();
/* 735 */           if (result == null) {
/* 736 */             BeanDescription desc = config.introspectClassAnnotations(type);
/* 737 */             AnnotatedClass ac = desc.getClassInfo();
/* 738 */             result = intr.isIgnorableType(ac);
/*     */             
/* 740 */             if (result == null) {
/* 741 */               result = Boolean.FALSE;
/*     */             }
/*     */           }
/* 744 */           ignores.put(type, result);
/*     */         }
/*     */         
/* 747 */         if (result.booleanValue()) {
/* 748 */           it.remove();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void removeSetterlessGetters(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyDefinition> properties)
/*     */   {
/* 759 */     Iterator<BeanPropertyDefinition> it = properties.iterator();
/* 760 */     while (it.hasNext()) {
/* 761 */       BeanPropertyDefinition property = (BeanPropertyDefinition)it.next();
/*     */       
/*     */ 
/* 764 */       if ((!property.couldDeserialize()) && (!property.isExplicitlyIncluded())) {
/* 765 */         it.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<BeanPropertyWriter> removeOverlappingTypeIds(SerializerProvider prov, BeanDescription beanDesc, BeanSerializerBuilder builder, List<BeanPropertyWriter> props)
/*     */   {
/* 780 */     int i = 0; BeanPropertyWriter bpw; PropertyName typePropName; for (int end = props.size(); i < end; i++) {
/* 781 */       bpw = (BeanPropertyWriter)props.get(i);
/* 782 */       TypeSerializer td = bpw.getTypeSerializer();
/* 783 */       if ((td != null) && (td.getTypeInclusion() == JsonTypeInfo.As.EXTERNAL_PROPERTY))
/*     */       {
/*     */ 
/* 786 */         String n = td.getPropertyName();
/* 787 */         typePropName = PropertyName.construct(n);
/*     */         
/* 789 */         for (BeanPropertyWriter w2 : props)
/* 790 */           if ((w2 != bpw) && (w2.wouldConflictWithName(typePropName))) {
/* 791 */             bpw.assignTypeSerializer(null);
/* 792 */             break;
/*     */           }
/*     */       }
/*     */     }
/* 796 */     return props;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BeanPropertyWriter _constructWriter(SerializerProvider prov, BeanPropertyDefinition propDef, PropertyBuilder pb, boolean staticTyping, AnnotatedMember accessor)
/*     */     throws JsonMappingException
/*     */   {
/* 814 */     PropertyName name = propDef.getFullName();
/* 815 */     JavaType type = accessor.getType();
/*     */     
/* 817 */     BeanProperty.Std property = new BeanProperty.Std(name, type, propDef.getWrapperName(), accessor, propDef.getMetadata());
/*     */     
/*     */ 
/* 820 */     JsonSerializer<?> annotatedSerializer = findSerializerFromAnnotation(prov, accessor);
/*     */     
/*     */ 
/*     */ 
/* 824 */     if ((annotatedSerializer instanceof ResolvableSerializer)) {
/* 825 */       ((ResolvableSerializer)annotatedSerializer).resolve(prov);
/*     */     }
/*     */     
/* 828 */     annotatedSerializer = prov.handlePrimaryContextualization(annotatedSerializer, property);
/*     */     
/* 830 */     TypeSerializer contentTypeSer = null;
/*     */     
/* 832 */     if ((type.isContainerType()) || (type.isReferenceType())) {
/* 833 */       contentTypeSer = findPropertyContentTypeSerializer(type, prov.getConfig(), accessor);
/*     */     }
/*     */     
/* 836 */     TypeSerializer typeSer = findPropertyTypeSerializer(type, prov.getConfig(), accessor);
/* 837 */     return pb.buildWriter(prov, propDef, type, annotatedSerializer, typeSer, contentTypeSer, accessor, staticTyping);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonSerializer<?> _findUnsupportedTypeSerializer(SerializerProvider ctxt, JavaType type, BeanDescription beanDesc)
/*     */     throws JsonMappingException
/*     */   {
/* 847 */     String errorMsg = BeanUtil.checkUnsupportedType(type);
/* 848 */     if (errorMsg != null)
/*     */     {
/*     */ 
/* 851 */       if (ctxt.getConfig().findMixInClassFor(type.getRawClass()) == null) {
/* 852 */         return new UnsupportedTypeSerializer(type, errorMsg);
/*     */       }
/*     */     }
/* 855 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\ser\BeanSerializerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */