/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnnotatedMethod
/*     */   extends AnnotatedWithParams
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final transient Method _method;
/*     */   protected Class<?>[] _paramClasses;
/*     */   protected Serialization _serialization;
/*     */   
/*     */   public AnnotatedMethod(TypeResolutionContext ctxt, Method method, AnnotationMap classAnn, AnnotationMap[] paramAnnotations)
/*     */   {
/*  37 */     super(ctxt, classAnn, paramAnnotations);
/*  38 */     if (method == null) {
/*  39 */       throw new IllegalArgumentException("Cannot construct AnnotatedMethod with null Method");
/*     */     }
/*  41 */     this._method = method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AnnotatedMethod(Serialization ser)
/*     */   {
/*  50 */     super(null, null, null);
/*  51 */     this._method = null;
/*  52 */     this._serialization = ser;
/*     */   }
/*     */   
/*     */   public AnnotatedMethod withAnnotations(AnnotationMap ann)
/*     */   {
/*  57 */     return new AnnotatedMethod(this._typeContext, this._method, ann, this._paramAnnotations);
/*     */   }
/*     */   
/*     */   public Method getAnnotated() {
/*  61 */     return this._method;
/*     */   }
/*     */   
/*  64 */   public int getModifiers() { return this._method.getModifiers(); }
/*     */   
/*     */   public String getName() {
/*  67 */     return this._method.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JavaType getType()
/*     */   {
/*  76 */     return this._typeContext.resolveType(this._method.getGenericReturnType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getRawType()
/*     */   {
/*  86 */     return this._method.getReturnType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Object call()
/*     */     throws Exception
/*     */   {
/*  97 */     return this._method.invoke(null, new Object[0]);
/*     */   }
/*     */   
/*     */   public final Object call(Object[] args) throws Exception
/*     */   {
/* 102 */     return this._method.invoke(null, args);
/*     */   }
/*     */   
/*     */   public final Object call1(Object arg) throws Exception
/*     */   {
/* 107 */     return this._method.invoke(null, new Object[] { arg });
/*     */   }
/*     */   
/*     */   public final Object callOn(Object pojo) throws Exception {
/* 111 */     return this._method.invoke(pojo, (Object[])null);
/*     */   }
/*     */   
/*     */   public final Object callOnWith(Object pojo, Object... args) throws Exception {
/* 115 */     return this._method.invoke(pojo, args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getParameterCount()
/*     */   {
/* 126 */     return getRawParameterTypes().length;
/*     */   }
/*     */   
/*     */ 
/*     */   public Class<?> getRawParameterType(int index)
/*     */   {
/* 132 */     Class<?>[] types = getRawParameterTypes();
/* 133 */     return index >= types.length ? null : types[index];
/*     */   }
/*     */   
/*     */   public JavaType getParameterType(int index)
/*     */   {
/* 138 */     Type[] types = this._method.getGenericParameterTypes();
/* 139 */     if (index >= types.length) {
/* 140 */       return null;
/*     */     }
/* 142 */     return this._typeContext.resolveType(types[index]);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Type getGenericParameterType(int index)
/*     */   {
/* 148 */     Type[] types = getGenericParameterTypes();
/* 149 */     if (index >= types.length) {
/* 150 */       return null;
/*     */     }
/* 152 */     return types[index];
/*     */   }
/*     */   
/*     */   public Class<?> getDeclaringClass() {
/* 156 */     return this._method.getDeclaringClass();
/*     */   }
/*     */   
/* 159 */   public Method getMember() { return this._method; }
/*     */   
/*     */   public void setValue(Object pojo, Object value) throws IllegalArgumentException
/*     */   {
/*     */     try
/*     */     {
/* 165 */       this._method.invoke(pojo, new Object[] { value });
/*     */     }
/*     */     catch (IllegalAccessException|InvocationTargetException e) {
/* 168 */       throw new IllegalArgumentException("Failed to setValue() with method " + getFullName() + ": " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getValue(Object pojo) throws IllegalArgumentException
/*     */   {
/*     */     try
/*     */     {
/* 176 */       return this._method.invoke(pojo, (Object[])null);
/*     */     }
/*     */     catch (IllegalAccessException|InvocationTargetException e) {
/* 179 */       throw new IllegalArgumentException("Failed to getValue() with method " + getFullName() + ": " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFullName()
/*     */   {
/* 191 */     String methodName = super.getFullName();
/* 192 */     switch (getParameterCount()) {
/*     */     case 0: 
/* 194 */       return methodName + "()";
/*     */     case 1: 
/* 196 */       return methodName + "(" + getRawParameterType(0).getName() + ")";
/*     */     }
/*     */     
/* 199 */     return String.format("%s(%d params)", new Object[] { super.getFullName(), Integer.valueOf(getParameterCount()) });
/*     */   }
/*     */   
/*     */   public Class<?>[] getRawParameterTypes()
/*     */   {
/* 204 */     if (this._paramClasses == null) {
/* 205 */       this._paramClasses = this._method.getParameterTypes();
/*     */     }
/* 207 */     return this._paramClasses;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Type[] getGenericParameterTypes() {
/* 212 */     return this._method.getGenericParameterTypes();
/*     */   }
/*     */   
/*     */   public Class<?> getRawReturnType() {
/* 216 */     return this._method.getReturnType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public boolean hasReturnType()
/*     */   {
/* 230 */     Class<?> rt = getRawReturnType();
/*     */     
/* 232 */     return rt != Void.TYPE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 243 */     return "[method " + getFullName() + "]";
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 248 */     return this._method.getName().hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 253 */     if (o == this) return true;
/* 254 */     return (ClassUtil.hasClass(o, getClass())) && (((AnnotatedMethod)o)._method == this._method);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Object writeReplace()
/*     */   {
/* 265 */     return new AnnotatedMethod(new Serialization(this._method));
/*     */   }
/*     */   
/*     */   Object readResolve() {
/* 269 */     Class<?> clazz = this._serialization.clazz;
/*     */     try {
/* 271 */       Method m = clazz.getDeclaredMethod(this._serialization.name, this._serialization.args);
/*     */       
/*     */ 
/* 274 */       if (!m.isAccessible()) {
/* 275 */         ClassUtil.checkAndFixAccess(m, false);
/*     */       }
/* 277 */       return new AnnotatedMethod(null, m, null, null);
/*     */     }
/*     */     catch (Exception e) {
/* 280 */       throw new IllegalArgumentException("Could not find method '" + this._serialization.name + "' from Class '" + clazz.getName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class Serialization
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     protected Class<?> clazz;
/*     */     
/*     */     protected String name;
/*     */     
/*     */     protected Class<?>[] args;
/*     */     
/*     */     public Serialization(Method setter)
/*     */     {
/* 298 */       this.clazz = setter.getDeclaringClass();
/* 299 */       this.name = setter.getName();
/* 300 */       this.args = setter.getParameterTypes();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\introspect\AnnotatedMethod.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */