/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.RuntimeJsonMappingException;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitable;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonStringFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonschema.JsonSchema;
/*     */ import com.fasterxml.jackson.databind.jsonschema.SchemaAware;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap.SerializerAndMapResult;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class JsonValueSerializer
/*     */   extends StdSerializer<Object>
/*     */   implements ContextualSerializer, JsonFormatVisitable, SchemaAware
/*     */ {
/*     */   protected final AnnotatedMember _accessor;
/*     */   protected final TypeSerializer _valueTypeSerializer;
/*     */   protected final JsonSerializer<Object> _valueSerializer;
/*     */   protected final BeanProperty _property;
/*     */   protected final JavaType _valueType;
/*     */   protected final boolean _forceTypeInformation;
/*     */   protected transient PropertySerializerMap _dynamicSerializers;
/*     */   
/*     */   public JsonValueSerializer(AnnotatedMember accessor, TypeSerializer vts, JsonSerializer<?> ser)
/*     */   {
/* 101 */     super(accessor.getType());
/* 102 */     this._accessor = accessor;
/* 103 */     this._valueType = accessor.getType();
/* 104 */     this._valueTypeSerializer = vts;
/* 105 */     this._valueSerializer = ser;
/* 106 */     this._property = null;
/* 107 */     this._forceTypeInformation = true;
/* 108 */     this._dynamicSerializers = PropertySerializerMap.emptyForProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public JsonValueSerializer(AnnotatedMember accessor, JsonSerializer<?> ser)
/*     */   {
/* 116 */     this(accessor, null, ser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonValueSerializer(JsonValueSerializer src, BeanProperty property, TypeSerializer vts, JsonSerializer<?> ser, boolean forceTypeInfo)
/*     */   {
/* 124 */     super(_notNullClass(src.handledType()));
/* 125 */     this._accessor = src._accessor;
/* 126 */     this._valueType = src._valueType;
/* 127 */     this._valueTypeSerializer = vts;
/* 128 */     this._valueSerializer = ser;
/* 129 */     this._property = property;
/* 130 */     this._forceTypeInformation = forceTypeInfo;
/* 131 */     this._dynamicSerializers = PropertySerializerMap.emptyForProperties();
/*     */   }
/*     */   
/*     */   private static final Class<Object> _notNullClass(Class<?> cls)
/*     */   {
/* 136 */     return cls == null ? Object.class : cls;
/*     */   }
/*     */   
/*     */ 
/*     */   protected JsonValueSerializer withResolved(BeanProperty property, TypeSerializer vts, JsonSerializer<?> ser, boolean forceTypeInfo)
/*     */   {
/* 142 */     if ((this._property == property) && (this._valueTypeSerializer == vts) && (this._valueSerializer == ser) && (forceTypeInfo == this._forceTypeInformation))
/*     */     {
/*     */ 
/* 145 */       return this;
/*     */     }
/* 147 */     return new JsonValueSerializer(this, property, vts, ser, forceTypeInfo);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty(SerializerProvider ctxt, Object bean)
/*     */   {
/* 160 */     Object referenced = this._accessor.getValue(bean);
/* 161 */     if (referenced == null) {
/* 162 */       return true;
/*     */     }
/* 164 */     JsonSerializer<Object> ser = this._valueSerializer;
/* 165 */     if (ser == null) {
/*     */       try {
/* 167 */         ser = _findDynamicSerializer(ctxt, referenced.getClass());
/*     */       } catch (JsonMappingException e) {
/* 169 */         throw new RuntimeJsonMappingException(e);
/*     */       }
/*     */     }
/* 172 */     return ser.isEmpty(ctxt, referenced);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonSerializer<?> createContextual(SerializerProvider ctxt, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 190 */     TypeSerializer typeSer = this._valueTypeSerializer;
/* 191 */     if (typeSer != null) {
/* 192 */       typeSer = typeSer.forProperty(property);
/*     */     }
/* 194 */     JsonSerializer<?> ser = this._valueSerializer;
/* 195 */     if (ser == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 200 */       if ((ctxt.isEnabled(MapperFeature.USE_STATIC_TYPING)) || (this._valueType.isFinal()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 206 */         ser = ctxt.findPrimaryPropertySerializer(this._valueType, property);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 211 */         boolean forceTypeInformation = isNaturalTypeWithStdHandling(this._valueType.getRawClass(), ser);
/* 212 */         return withResolved(property, typeSer, ser, forceTypeInformation);
/*     */       }
/*     */       
/* 215 */       if (property != this._property) {
/* 216 */         return withResolved(property, typeSer, ser, this._forceTypeInformation);
/*     */       }
/*     */     }
/*     */     else {
/* 220 */       ser = ctxt.handlePrimaryContextualization(ser, property);
/* 221 */       return withResolved(property, typeSer, ser, this._forceTypeInformation);
/*     */     }
/* 223 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void serialize(Object bean, JsonGenerator gen, SerializerProvider ctxt)
/*     */     throws IOException
/*     */   {
/*     */     Object value;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 237 */       value = this._accessor.getValue(bean);
/*     */     } catch (Exception e) { Object value;
/* 239 */       value = null;
/* 240 */       wrapAndThrow(ctxt, e, bean, this._accessor.getName() + "()");
/*     */     }
/*     */     
/* 243 */     if (value == null) {
/* 244 */       ctxt.defaultSerializeNull(gen);
/*     */     } else {
/* 246 */       JsonSerializer<Object> ser = this._valueSerializer;
/* 247 */       if (ser == null) {
/* 248 */         ser = _findDynamicSerializer(ctxt, value.getClass());
/*     */       }
/* 250 */       if (this._valueTypeSerializer != null) {
/* 251 */         ser.serializeWithType(value, gen, ctxt, this._valueTypeSerializer);
/*     */       } else {
/* 253 */         ser.serialize(value, gen, ctxt);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void serializeWithType(Object bean, JsonGenerator gen, SerializerProvider ctxt, TypeSerializer typeSer0)
/*     */     throws IOException
/*     */   {
/*     */     Object value;
/*     */     try
/*     */     {
/* 265 */       value = this._accessor.getValue(bean);
/*     */     } catch (Exception e) { Object value;
/* 267 */       value = null;
/* 268 */       wrapAndThrow(ctxt, e, bean, this._accessor.getName() + "()");
/*     */     }
/*     */     
/*     */ 
/* 272 */     if (value == null) {
/* 273 */       ctxt.defaultSerializeNull(gen);
/* 274 */       return;
/*     */     }
/* 276 */     JsonSerializer<Object> ser = this._valueSerializer;
/* 277 */     if (ser == null) {
/* 278 */       ser = _findDynamicSerializer(ctxt, value.getClass());
/*     */ 
/*     */ 
/*     */     }
/* 282 */     else if (this._forceTypeInformation)
/*     */     {
/* 284 */       WritableTypeId typeIdDef = typeSer0.writeTypePrefix(gen, typeSer0
/* 285 */         .typeId(bean, JsonToken.VALUE_STRING));
/* 286 */       ser.serialize(value, gen, ctxt);
/* 287 */       typeSer0.writeTypeSuffix(gen, typeIdDef);
/*     */       
/* 289 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 295 */     TypeSerializerRerouter rr = new TypeSerializerRerouter(typeSer0, bean);
/* 296 */     ser.serializeWithType(value, gen, ctxt, rr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonNode getSchema(SerializerProvider ctxt, Type typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 310 */     if ((this._valueSerializer instanceof SchemaAware)) {
/* 311 */       return ((SchemaAware)this._valueSerializer).getSchema(ctxt, null);
/*     */     }
/* 313 */     return JsonSchema.getDefaultSchemaNode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 329 */     Class<?> declaring = this._accessor.getDeclaringClass();
/* 330 */     if ((declaring != null) && (ClassUtil.isEnumType(declaring)) && 
/* 331 */       (_acceptJsonFormatVisitorForEnum(visitor, typeHint, declaring))) {
/* 332 */       return;
/*     */     }
/*     */     
/* 335 */     JsonSerializer<Object> ser = this._valueSerializer;
/* 336 */     if (ser == null) {
/* 337 */       ser = visitor.getProvider().findTypedValueSerializer(this._valueType, false, this._property);
/* 338 */       if (ser == null) {
/* 339 */         visitor.expectAnyFormat(typeHint);
/* 340 */         return;
/*     */       }
/*     */     }
/* 343 */     ser.acceptJsonFormatVisitor(visitor, this._valueType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean _acceptJsonFormatVisitorForEnum(JsonFormatVisitorWrapper visitor, JavaType typeHint, Class<?> enumType)
/*     */     throws JsonMappingException
/*     */   {
/* 360 */     JsonStringFormatVisitor stringVisitor = visitor.expectStringFormat(typeHint);
/* 361 */     if (stringVisitor != null) {
/* 362 */       Set<String> enums = new LinkedHashSet();
/* 363 */       for (Object en : enumType.getEnumConstants())
/*     */       {
/*     */         try
/*     */         {
/*     */ 
/* 368 */           enums.add(String.valueOf(this._accessor.getValue(en)));
/*     */         } catch (Exception e) {
/* 370 */           Throwable t = e;
/* 371 */           while (((t instanceof InvocationTargetException)) && (t.getCause() != null)) {
/* 372 */             t = t.getCause();
/*     */           }
/* 374 */           ClassUtil.throwIfError(t);
/* 375 */           throw JsonMappingException.wrapWithPath(t, en, this._accessor.getName() + "()");
/*     */         }
/*     */       }
/* 378 */       stringVisitor.enumTypes(enums);
/*     */     }
/* 380 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isNaturalTypeWithStdHandling(Class<?> rawType, JsonSerializer<?> ser)
/*     */   {
/* 392 */     if (rawType.isPrimitive()) {
/* 393 */       if ((rawType != Integer.TYPE) && (rawType != Boolean.TYPE) && (rawType != Double.TYPE)) {
/* 394 */         return false;
/*     */       }
/*     */     }
/* 397 */     else if ((rawType != String.class) && (rawType != Integer.class) && (rawType != Boolean.class) && (rawType != Double.class))
/*     */     {
/* 399 */       return false;
/*     */     }
/*     */     
/* 402 */     return isDefaultSerializer(ser);
/*     */   }
/*     */   
/*     */ 
/*     */   protected JsonSerializer<Object> _findDynamicSerializer(SerializerProvider ctxt, Class<?> valueClass)
/*     */     throws JsonMappingException
/*     */   {
/* 409 */     JsonSerializer<Object> serializer = this._dynamicSerializers.serializerFor(valueClass);
/* 410 */     if (serializer == null) {
/* 411 */       if (this._valueType.hasGenericTypes()) {
/* 412 */         JavaType fullType = ctxt.constructSpecializedType(this._valueType, valueClass);
/* 413 */         serializer = ctxt.findPrimaryPropertySerializer(fullType, this._property);
/* 414 */         PropertySerializerMap.SerializerAndMapResult result = this._dynamicSerializers.addSerializer(fullType, serializer);
/* 415 */         this._dynamicSerializers = result.map;
/*     */       } else {
/* 417 */         serializer = ctxt.findPrimaryPropertySerializer(valueClass, this._property);
/* 418 */         PropertySerializerMap.SerializerAndMapResult result = this._dynamicSerializers.addSerializer(valueClass, serializer);
/* 419 */         this._dynamicSerializers = result.map;
/*     */       }
/*     */     }
/* 422 */     return serializer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 452 */     return "(@JsonValue serializer for method " + this._accessor.getDeclaringClass() + "#" + this._accessor.getName() + ")";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class TypeSerializerRerouter
/*     */     extends TypeSerializer
/*     */   {
/*     */     protected final TypeSerializer _typeSerializer;
/*     */     
/*     */ 
/*     */ 
/*     */     protected final Object _forObject;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public TypeSerializerRerouter(TypeSerializer ts, Object ob)
/*     */     {
/* 473 */       this._typeSerializer = ts;
/* 474 */       this._forObject = ob;
/*     */     }
/*     */     
/*     */     public TypeSerializer forProperty(BeanProperty prop)
/*     */     {
/* 479 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public JsonTypeInfo.As getTypeInclusion()
/*     */     {
/* 484 */       return this._typeSerializer.getTypeInclusion();
/*     */     }
/*     */     
/*     */     public String getPropertyName()
/*     */     {
/* 489 */       return this._typeSerializer.getPropertyName();
/*     */     }
/*     */     
/*     */     public TypeIdResolver getTypeIdResolver()
/*     */     {
/* 494 */       return this._typeSerializer.getTypeIdResolver();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public WritableTypeId writeTypePrefix(JsonGenerator g, WritableTypeId typeId)
/*     */       throws IOException
/*     */     {
/* 503 */       typeId.forValue = this._forObject;
/* 504 */       return this._typeSerializer.writeTypePrefix(g, typeId);
/*     */     }
/*     */     
/*     */ 
/*     */     public WritableTypeId writeTypeSuffix(JsonGenerator g, WritableTypeId typeId)
/*     */       throws IOException
/*     */     {
/* 511 */       return this._typeSerializer.writeTypeSuffix(g, typeId);
/*     */     }
/*     */     
/*     */ 
/*     */     @Deprecated
/*     */     public void writeTypePrefixForScalar(Object value, JsonGenerator gen)
/*     */       throws IOException
/*     */     {
/* 519 */       this._typeSerializer.writeTypePrefixForScalar(this._forObject, gen);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypePrefixForObject(Object value, JsonGenerator gen) throws IOException
/*     */     {
/* 525 */       this._typeSerializer.writeTypePrefixForObject(this._forObject, gen);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypePrefixForArray(Object value, JsonGenerator gen) throws IOException
/*     */     {
/* 531 */       this._typeSerializer.writeTypePrefixForArray(this._forObject, gen);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypeSuffixForScalar(Object value, JsonGenerator gen) throws IOException
/*     */     {
/* 537 */       this._typeSerializer.writeTypeSuffixForScalar(this._forObject, gen);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypeSuffixForObject(Object value, JsonGenerator gen) throws IOException
/*     */     {
/* 543 */       this._typeSerializer.writeTypeSuffixForObject(this._forObject, gen);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypeSuffixForArray(Object value, JsonGenerator gen) throws IOException
/*     */     {
/* 549 */       this._typeSerializer.writeTypeSuffixForArray(this._forObject, gen);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypePrefixForScalar(Object value, JsonGenerator gen, Class<?> type) throws IOException
/*     */     {
/* 555 */       this._typeSerializer.writeTypePrefixForScalar(this._forObject, gen, type);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypePrefixForObject(Object value, JsonGenerator gen, Class<?> type) throws IOException
/*     */     {
/* 561 */       this._typeSerializer.writeTypePrefixForObject(this._forObject, gen, type);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypePrefixForArray(Object value, JsonGenerator gen, Class<?> type) throws IOException
/*     */     {
/* 567 */       this._typeSerializer.writeTypePrefixForArray(this._forObject, gen, type);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     @Deprecated
/*     */     public void writeCustomTypePrefixForScalar(Object value, JsonGenerator gen, String typeId)
/*     */       throws IOException
/*     */     {
/* 580 */       this._typeSerializer.writeCustomTypePrefixForScalar(this._forObject, gen, typeId);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeCustomTypePrefixForObject(Object value, JsonGenerator gen, String typeId) throws IOException
/*     */     {
/* 586 */       this._typeSerializer.writeCustomTypePrefixForObject(this._forObject, gen, typeId);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeCustomTypePrefixForArray(Object value, JsonGenerator gen, String typeId) throws IOException
/*     */     {
/* 592 */       this._typeSerializer.writeCustomTypePrefixForArray(this._forObject, gen, typeId);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeCustomTypeSuffixForScalar(Object value, JsonGenerator gen, String typeId) throws IOException
/*     */     {
/* 598 */       this._typeSerializer.writeCustomTypeSuffixForScalar(this._forObject, gen, typeId);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeCustomTypeSuffixForObject(Object value, JsonGenerator gen, String typeId) throws IOException
/*     */     {
/* 604 */       this._typeSerializer.writeCustomTypeSuffixForObject(this._forObject, gen, typeId);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public void writeCustomTypeSuffixForArray(Object value, JsonGenerator gen, String typeId) throws IOException
/*     */     {
/* 610 */       this._typeSerializer.writeCustomTypeSuffixForArray(this._forObject, gen, typeId);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\ser\std\JsonValueSerializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */