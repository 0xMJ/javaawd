/*    */ package com.fasterxml.jackson.databind.node;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.core.JsonToken;
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullNode
/*    */   extends ValueNode
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 21 */   public static final NullNode instance = new NullNode();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Object readResolve()
/*    */   {
/* 31 */     return instance;
/*    */   }
/*    */   
/* 34 */   public static NullNode getInstance() { return instance; }
/*    */   
/*    */   public JsonNodeType getNodeType()
/*    */   {
/* 38 */     return JsonNodeType.NULL;
/*    */   }
/*    */   
/* 41 */   public JsonToken asToken() { return JsonToken.VALUE_NULL; }
/*    */   
/* 43 */   public String asText(String defaultValue) { return defaultValue; }
/* 44 */   public String asText() { return "null"; }
/*    */   
/*    */ 
/*    */   public JsonNode requireNonNull()
/*    */   {
/* 49 */     return (JsonNode)_reportRequiredViolation("requireNonNull() called on `NullNode`", new Object[0]);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final void serialize(JsonGenerator g, SerializerProvider provider)
/*    */     throws IOException
/*    */   {
/* 65 */     provider.defaultSerializeNull(g);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 72 */     return (o == this) || ((o instanceof NullNode));
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 77 */     return JsonNodeType.NULL.ordinal();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\node\NullNode.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */