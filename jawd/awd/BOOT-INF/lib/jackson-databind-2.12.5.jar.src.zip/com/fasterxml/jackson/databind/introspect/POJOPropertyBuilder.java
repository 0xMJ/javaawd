/*      */ package com.fasterxml.jackson.databind.introspect;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonInclude.Value;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty.Access;
/*      */ import com.fasterxml.jackson.annotation.JsonSetter.Value;
/*      */ import com.fasterxml.jackson.annotation.Nulls;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector.ReferenceProperty;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata.MergeInfo;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.cfg.ConfigOverride;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ public class POJOPropertyBuilder
/*      */   extends BeanPropertyDefinition
/*      */   implements Comparable<POJOPropertyBuilder>
/*      */ {
/*   31 */   private static final AnnotationIntrospector.ReferenceProperty NOT_REFEFERENCE_PROP = AnnotationIntrospector.ReferenceProperty.managed("");
/*      */   
/*      */ 
/*      */ 
/*      */   protected final boolean _forSerialization;
/*      */   
/*      */ 
/*      */ 
/*      */   protected final MapperConfig<?> _config;
/*      */   
/*      */ 
/*      */ 
/*      */   protected final AnnotationIntrospector _annotationIntrospector;
/*      */   
/*      */ 
/*      */ 
/*      */   protected final PropertyName _name;
/*      */   
/*      */ 
/*      */ 
/*      */   protected final PropertyName _internalName;
/*      */   
/*      */ 
/*      */ 
/*      */   protected Linked<AnnotatedField> _fields;
/*      */   
/*      */ 
/*      */   protected Linked<AnnotatedParameter> _ctorParameters;
/*      */   
/*      */ 
/*      */   protected Linked<AnnotatedMethod> _getters;
/*      */   
/*      */ 
/*      */   protected Linked<AnnotatedMethod> _setters;
/*      */   
/*      */ 
/*      */   protected transient PropertyMetadata _metadata;
/*      */   
/*      */ 
/*      */   protected transient AnnotationIntrospector.ReferenceProperty _referenceInfo;
/*      */   
/*      */ 
/*      */ 
/*      */   public POJOPropertyBuilder(MapperConfig<?> config, AnnotationIntrospector ai, boolean forSerialization, PropertyName internalName)
/*      */   {
/*   76 */     this(config, ai, forSerialization, internalName, internalName);
/*      */   }
/*      */   
/*      */ 
/*      */   protected POJOPropertyBuilder(MapperConfig<?> config, AnnotationIntrospector ai, boolean forSerialization, PropertyName internalName, PropertyName name)
/*      */   {
/*   82 */     this._config = config;
/*   83 */     this._annotationIntrospector = ai;
/*   84 */     this._internalName = internalName;
/*   85 */     this._name = name;
/*   86 */     this._forSerialization = forSerialization;
/*      */   }
/*      */   
/*      */ 
/*      */   protected POJOPropertyBuilder(POJOPropertyBuilder src, PropertyName newName)
/*      */   {
/*   92 */     this._config = src._config;
/*   93 */     this._annotationIntrospector = src._annotationIntrospector;
/*   94 */     this._internalName = src._internalName;
/*   95 */     this._name = newName;
/*   96 */     this._fields = src._fields;
/*   97 */     this._ctorParameters = src._ctorParameters;
/*   98 */     this._getters = src._getters;
/*   99 */     this._setters = src._setters;
/*  100 */     this._forSerialization = src._forSerialization;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public POJOPropertyBuilder withName(PropertyName newName)
/*      */   {
/*  111 */     return new POJOPropertyBuilder(this, newName);
/*      */   }
/*      */   
/*      */ 
/*      */   public POJOPropertyBuilder withSimpleName(String newSimpleName)
/*      */   {
/*  117 */     PropertyName newName = this._name.withSimpleName(newSimpleName);
/*  118 */     return newName == this._name ? this : new POJOPropertyBuilder(this, newName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int compareTo(POJOPropertyBuilder other)
/*      */   {
/*  133 */     if (this._ctorParameters != null) {
/*  134 */       if (other._ctorParameters == null) {
/*  135 */         return -1;
/*      */       }
/*  137 */     } else if (other._ctorParameters != null) {
/*  138 */       return 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  143 */     return getName().compareTo(other.getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  154 */     return this._name == null ? null : this._name.getSimpleName();
/*      */   }
/*      */   
/*      */   public PropertyName getFullName()
/*      */   {
/*  159 */     return this._name;
/*      */   }
/*      */   
/*      */   public boolean hasName(PropertyName name)
/*      */   {
/*  164 */     return this._name.equals(name);
/*      */   }
/*      */   
/*      */   public String getInternalName() {
/*  168 */     return this._internalName.getSimpleName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PropertyName getWrapperName()
/*      */   {
/*  177 */     AnnotatedMember member = getPrimaryMember();
/*  178 */     return (member == null) || (this._annotationIntrospector == null) ? null : this._annotationIntrospector
/*  179 */       .findWrapperName(member);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isExplicitlyIncluded()
/*      */   {
/*  192 */     return (_anyExplicits(this._fields)) || 
/*  193 */       (_anyExplicits(this._getters)) || 
/*  194 */       (_anyExplicits(this._setters)) || 
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  199 */       (_anyExplicitNames(this._ctorParameters));
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isExplicitlyNamed()
/*      */   {
/*  205 */     return (_anyExplicitNames(this._fields)) || 
/*  206 */       (_anyExplicitNames(this._getters)) || 
/*  207 */       (_anyExplicitNames(this._setters)) || 
/*  208 */       (_anyExplicitNames(this._ctorParameters));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public PropertyMetadata getMetadata()
/*      */   {
/*  221 */     if (this._metadata == null)
/*      */     {
/*      */ 
/*  224 */       AnnotatedMember prim = getPrimaryMemberUnchecked();
/*      */       
/*  226 */       if (prim == null) {
/*  227 */         this._metadata = PropertyMetadata.STD_REQUIRED_OR_OPTIONAL;
/*      */       } else {
/*  229 */         Boolean b = this._annotationIntrospector.hasRequiredMarker(prim);
/*  230 */         String desc = this._annotationIntrospector.findPropertyDescription(prim);
/*  231 */         Integer idx = this._annotationIntrospector.findPropertyIndex(prim);
/*  232 */         String def = this._annotationIntrospector.findPropertyDefaultValue(prim);
/*      */         
/*  234 */         if ((b == null) && (idx == null) && (def == null))
/*      */         {
/*  236 */           this._metadata = (desc == null ? PropertyMetadata.STD_REQUIRED_OR_OPTIONAL : PropertyMetadata.STD_REQUIRED_OR_OPTIONAL.withDescription(desc));
/*      */         } else {
/*  238 */           this._metadata = PropertyMetadata.construct(b, desc, idx, def);
/*      */         }
/*  240 */         if (!this._forSerialization) {
/*  241 */           this._metadata = _getSetterInfo(this._metadata, prim);
/*      */         }
/*      */       }
/*      */     }
/*  245 */     return this._metadata;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PropertyMetadata _getSetterInfo(PropertyMetadata metadata, AnnotatedMember primary)
/*      */   {
/*  257 */     boolean needMerge = true;
/*  258 */     Nulls valueNulls = null;
/*  259 */     Nulls contentNulls = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  264 */     AnnotatedMember acc = getAccessor();
/*      */     
/*  266 */     if (primary != null)
/*      */     {
/*  268 */       if (this._annotationIntrospector != null) {
/*  269 */         if (acc != null) {
/*  270 */           Boolean b = this._annotationIntrospector.findMergeInfo(primary);
/*  271 */           if (b != null) {
/*  272 */             needMerge = false;
/*  273 */             if (b.booleanValue()) {
/*  274 */               metadata = metadata.withMergeInfo(PropertyMetadata.MergeInfo.createForPropertyOverride(acc));
/*      */             }
/*      */           }
/*      */         }
/*  278 */         JsonSetter.Value setterInfo = this._annotationIntrospector.findSetterInfo(primary);
/*  279 */         if (setterInfo != null) {
/*  280 */           valueNulls = setterInfo.nonDefaultValueNulls();
/*  281 */           contentNulls = setterInfo.nonDefaultContentNulls();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  286 */       if ((needMerge) || (valueNulls == null) || (contentNulls == null))
/*      */       {
/*      */ 
/*      */ 
/*  290 */         Class<?> rawType = _rawTypeOf(primary);
/*  291 */         ConfigOverride co = this._config.getConfigOverride(rawType);
/*  292 */         JsonSetter.Value setterInfo = co.getSetterInfo();
/*  293 */         if (setterInfo != null) {
/*  294 */           if (valueNulls == null) {
/*  295 */             valueNulls = setterInfo.nonDefaultValueNulls();
/*      */           }
/*  297 */           if (contentNulls == null) {
/*  298 */             contentNulls = setterInfo.nonDefaultContentNulls();
/*      */           }
/*      */         }
/*  301 */         if ((needMerge) && (acc != null)) {
/*  302 */           Boolean b = co.getMergeable();
/*  303 */           if (b != null) {
/*  304 */             needMerge = false;
/*  305 */             if (b.booleanValue()) {
/*  306 */               metadata = metadata.withMergeInfo(PropertyMetadata.MergeInfo.createForTypeOverride(acc));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  312 */     if ((needMerge) || (valueNulls == null) || (contentNulls == null)) {
/*  313 */       JsonSetter.Value setterInfo = this._config.getDefaultSetterInfo();
/*  314 */       if (valueNulls == null) {
/*  315 */         valueNulls = setterInfo.nonDefaultValueNulls();
/*      */       }
/*  317 */       if (contentNulls == null) {
/*  318 */         contentNulls = setterInfo.nonDefaultContentNulls();
/*      */       }
/*  320 */       if (needMerge) {
/*  321 */         Boolean b = this._config.getDefaultMergeable();
/*  322 */         if ((Boolean.TRUE.equals(b)) && (acc != null)) {
/*  323 */           metadata = metadata.withMergeInfo(PropertyMetadata.MergeInfo.createForDefaults(acc));
/*      */         }
/*      */       }
/*      */     }
/*  327 */     if ((valueNulls != null) || (contentNulls != null)) {
/*  328 */       metadata = metadata.withNulls(valueNulls, contentNulls);
/*      */     }
/*  330 */     return metadata;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JavaType getPrimaryType()
/*      */   {
/*  340 */     if (this._forSerialization) {
/*  341 */       AnnotatedMember m = getGetter();
/*  342 */       if (m == null) {
/*  343 */         m = getField();
/*  344 */         if (m == null)
/*      */         {
/*  346 */           return TypeFactory.unknownType();
/*      */         }
/*      */       }
/*  349 */       return m.getType();
/*      */     }
/*  351 */     AnnotatedMember m = getConstructorParameter();
/*  352 */     if (m == null) {
/*  353 */       m = getSetter();
/*      */       
/*      */ 
/*  356 */       if (m != null) {
/*  357 */         return ((AnnotatedMethod)m).getParameterType(0);
/*      */       }
/*  359 */       m = getField();
/*      */     }
/*      */     
/*  362 */     if (m == null) {
/*  363 */       m = getGetter();
/*  364 */       if (m == null) {
/*  365 */         return TypeFactory.unknownType();
/*      */       }
/*      */     }
/*  368 */     return m.getType();
/*      */   }
/*      */   
/*      */   public Class<?> getRawPrimaryType()
/*      */   {
/*  373 */     return getPrimaryType().getRawClass();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasGetter()
/*      */   {
/*  383 */     return this._getters != null;
/*      */   }
/*      */   
/*  386 */   public boolean hasSetter() { return this._setters != null; }
/*      */   
/*      */   public boolean hasField() {
/*  389 */     return this._fields != null;
/*      */   }
/*      */   
/*  392 */   public boolean hasConstructorParameter() { return this._ctorParameters != null; }
/*      */   
/*      */   public boolean couldDeserialize()
/*      */   {
/*  396 */     return (this._ctorParameters != null) || (this._setters != null) || (this._fields != null);
/*      */   }
/*      */   
/*      */   public boolean couldSerialize()
/*      */   {
/*  401 */     return (this._getters != null) || (this._fields != null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public AnnotatedMethod getGetter()
/*      */   {
/*  408 */     Linked<AnnotatedMethod> curr = this._getters;
/*  409 */     if (curr == null) {
/*  410 */       return null;
/*      */     }
/*  412 */     Linked<AnnotatedMethod> next = curr.next;
/*  413 */     if (next == null) {
/*  414 */       return (AnnotatedMethod)curr.value;
/*      */     }
/*  417 */     for (; 
/*  417 */         next != null; next = next.next)
/*      */     {
/*      */ 
/*      */ 
/*  421 */       Class<?> currClass = ((AnnotatedMethod)curr.value).getDeclaringClass();
/*  422 */       Class<?> nextClass = ((AnnotatedMethod)next.value).getDeclaringClass();
/*  423 */       if (currClass != nextClass) {
/*  424 */         if (currClass.isAssignableFrom(nextClass)) {
/*  425 */           curr = next;
/*      */ 
/*      */         }
/*  428 */         else if (nextClass.isAssignableFrom(currClass)) {}
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  438 */         int priNext = _getterPriority((AnnotatedMethod)next.value);
/*  439 */         int priCurr = _getterPriority((AnnotatedMethod)curr.value);
/*      */         
/*  441 */         if (priNext != priCurr) {
/*  442 */           if (priNext < priCurr) {
/*  443 */             curr = next;
/*      */           }
/*      */           
/*      */         }
/*      */         else
/*  448 */           throw new IllegalArgumentException("Conflicting getter definitions for property \"" + getName() + "\": " + ((AnnotatedMethod)curr.value).getFullName() + " vs " + ((AnnotatedMethod)next.value).getFullName());
/*      */       }
/*      */     }
/*  451 */     this._getters = curr.withoutNext();
/*  452 */     return (AnnotatedMethod)curr.value;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public AnnotatedMethod getSetter()
/*      */   {
/*  459 */     Linked<AnnotatedMethod> curr = this._setters;
/*  460 */     if (curr == null) {
/*  461 */       return null;
/*      */     }
/*  463 */     Linked<AnnotatedMethod> next = curr.next;
/*  464 */     if (next == null) {
/*  465 */       return (AnnotatedMethod)curr.value;
/*      */     }
/*  468 */     for (; 
/*  468 */         next != null; next = next.next)
/*      */     {
/*  470 */       Class<?> currClass = ((AnnotatedMethod)curr.value).getDeclaringClass();
/*  471 */       Class<?> nextClass = ((AnnotatedMethod)next.value).getDeclaringClass();
/*  472 */       if (currClass != nextClass) {
/*  473 */         if (currClass.isAssignableFrom(nextClass)) {
/*  474 */           curr = next;
/*      */ 
/*      */         }
/*  477 */         else if (nextClass.isAssignableFrom(currClass)) {}
/*      */       }
/*      */       else
/*      */       {
/*  481 */         AnnotatedMethod nextM = (AnnotatedMethod)next.value;
/*  482 */         AnnotatedMethod currM = (AnnotatedMethod)curr.value;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  489 */         int priNext = _setterPriority(nextM);
/*  490 */         int priCurr = _setterPriority(currM);
/*      */         
/*  492 */         if (priNext != priCurr) {
/*  493 */           if (priNext < priCurr) {
/*  494 */             curr = next;
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  499 */           if (this._annotationIntrospector != null) {
/*  500 */             AnnotatedMethod pref = this._annotationIntrospector.resolveSetterConflict(this._config, currM, nextM);
/*      */             
/*      */ 
/*      */ 
/*  504 */             if (pref == currM) {
/*      */               continue;
/*      */             }
/*  507 */             if (pref == nextM) {
/*  508 */               curr = next;
/*  509 */               continue;
/*      */             }
/*      */           }
/*  512 */           throw new IllegalArgumentException(String.format("Conflicting setter definitions for property \"%s\": %s vs %s", new Object[] {
/*      */           
/*  514 */             getName(), ((AnnotatedMethod)curr.value).getFullName(), ((AnnotatedMethod)next.value).getFullName() }));
/*      */         }
/*      */       } }
/*  517 */     this._setters = curr.withoutNext();
/*  518 */     return (AnnotatedMethod)curr.value;
/*      */   }
/*      */   
/*      */ 
/*      */   public AnnotatedField getField()
/*      */   {
/*  524 */     if (this._fields == null) {
/*  525 */       return null;
/*      */     }
/*      */     
/*  528 */     AnnotatedField field = (AnnotatedField)this._fields.value;
/*  529 */     for (Linked<AnnotatedField> next = this._fields.next; 
/*  530 */         next != null; next = next.next) {
/*  531 */       AnnotatedField nextField = (AnnotatedField)next.value;
/*  532 */       Class<?> fieldClass = field.getDeclaringClass();
/*  533 */       Class<?> nextClass = nextField.getDeclaringClass();
/*  534 */       if (fieldClass != nextClass) {
/*  535 */         if (fieldClass.isAssignableFrom(nextClass)) {
/*  536 */           field = nextField;
/*      */ 
/*      */         }
/*  539 */         else if (nextClass.isAssignableFrom(fieldClass)) {}
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  544 */         throw new IllegalArgumentException("Multiple fields representing property \"" + getName() + "\": " + field.getFullName() + " vs " + nextField.getFullName()); }
/*      */     }
/*  546 */     return field;
/*      */   }
/*      */   
/*      */ 
/*      */   public AnnotatedParameter getConstructorParameter()
/*      */   {
/*  552 */     if (this._ctorParameters == null) {
/*  553 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  563 */     Linked<AnnotatedParameter> curr = this._ctorParameters;
/*      */     do {
/*  565 */       if ((((AnnotatedParameter)curr.value).getOwner() instanceof AnnotatedConstructor)) {
/*  566 */         return (AnnotatedParameter)curr.value;
/*      */       }
/*  568 */       curr = curr.next;
/*  569 */     } while (curr != null);
/*  570 */     return (AnnotatedParameter)this._ctorParameters.value;
/*      */   }
/*      */   
/*      */   public Iterator<AnnotatedParameter> getConstructorParameters()
/*      */   {
/*  575 */     if (this._ctorParameters == null) {
/*  576 */       return ClassUtil.emptyIterator();
/*      */     }
/*  578 */     return new MemberIterator(this._ctorParameters);
/*      */   }
/*      */   
/*      */   public AnnotatedMember getPrimaryMember()
/*      */   {
/*  583 */     if (this._forSerialization) {
/*  584 */       return getAccessor();
/*      */     }
/*  586 */     AnnotatedMember m = getMutator();
/*      */     
/*  588 */     if (m == null) {
/*  589 */       m = getAccessor();
/*      */     }
/*  591 */     return m;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected AnnotatedMember getPrimaryMemberUnchecked()
/*      */   {
/*  599 */     if (this._forSerialization)
/*      */     {
/*  601 */       if (this._getters != null) {
/*  602 */         return (AnnotatedMember)this._getters.value;
/*      */       }
/*      */       
/*  605 */       if (this._fields != null) {
/*  606 */         return (AnnotatedMember)this._fields.value;
/*      */       }
/*  608 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  614 */     if (this._ctorParameters != null) {
/*  615 */       return (AnnotatedMember)this._ctorParameters.value;
/*      */     }
/*      */     
/*  618 */     if (this._setters != null) {
/*  619 */       return (AnnotatedMember)this._setters.value;
/*      */     }
/*      */     
/*  622 */     if (this._fields != null) {
/*  623 */       return (AnnotatedMember)this._fields.value;
/*      */     }
/*      */     
/*      */ 
/*  627 */     if (this._getters != null) {
/*  628 */       return (AnnotatedMember)this._getters.value;
/*      */     }
/*  630 */     return null;
/*      */   }
/*      */   
/*      */   protected int _getterPriority(AnnotatedMethod m)
/*      */   {
/*  635 */     String name = m.getName();
/*      */     
/*  637 */     if ((name.startsWith("get")) && (name.length() > 3))
/*      */     {
/*  639 */       return 1;
/*      */     }
/*  641 */     if ((name.startsWith("is")) && (name.length() > 2)) {
/*  642 */       return 2;
/*      */     }
/*  644 */     return 3;
/*      */   }
/*      */   
/*      */   protected int _setterPriority(AnnotatedMethod m)
/*      */   {
/*  649 */     String name = m.getName();
/*  650 */     if ((name.startsWith("set")) && (name.length() > 3))
/*      */     {
/*  652 */       return 1;
/*      */     }
/*  654 */     return 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Class<?>[] findViews()
/*      */   {
/*  665 */     (Class[])fromMemberAnnotations(new WithMember()
/*      */     {
/*      */       public Class<?>[] withMember(AnnotatedMember member) {
/*  668 */         return POJOPropertyBuilder.this._annotationIntrospector.findViews(member);
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public AnnotationIntrospector.ReferenceProperty findReferenceType()
/*      */   {
/*  677 */     AnnotationIntrospector.ReferenceProperty result = this._referenceInfo;
/*  678 */     if (result != null) {
/*  679 */       if (result == NOT_REFEFERENCE_PROP) {
/*  680 */         return null;
/*      */       }
/*  682 */       return result;
/*      */     }
/*  684 */     result = (AnnotationIntrospector.ReferenceProperty)fromMemberAnnotations(new WithMember()
/*      */     {
/*      */       public AnnotationIntrospector.ReferenceProperty withMember(AnnotatedMember member) {
/*  687 */         return POJOPropertyBuilder.this._annotationIntrospector.findReferenceType(member);
/*      */       }
/*  689 */     });
/*  690 */     this._referenceInfo = (result == null ? NOT_REFEFERENCE_PROP : result);
/*  691 */     return result;
/*      */   }
/*      */   
/*      */   public boolean isTypeId()
/*      */   {
/*  696 */     Boolean b = (Boolean)fromMemberAnnotations(new WithMember()
/*      */     {
/*      */       public Boolean withMember(AnnotatedMember member) {
/*  699 */         return POJOPropertyBuilder.this._annotationIntrospector.isTypeId(member);
/*      */       }
/*  701 */     });
/*  702 */     return (b != null) && (b.booleanValue());
/*      */   }
/*      */   
/*      */   public ObjectIdInfo findObjectIdInfo()
/*      */   {
/*  707 */     (ObjectIdInfo)fromMemberAnnotations(new WithMember()
/*      */     {
/*      */       public ObjectIdInfo withMember(AnnotatedMember member) {
/*  710 */         ObjectIdInfo info = POJOPropertyBuilder.this._annotationIntrospector.findObjectIdInfo(member);
/*  711 */         if (info != null) {
/*  712 */           info = POJOPropertyBuilder.this._annotationIntrospector.findObjectReferenceInfo(member, info);
/*      */         }
/*  714 */         return info;
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */   public JsonInclude.Value findInclusion()
/*      */   {
/*  721 */     AnnotatedMember a = getAccessor();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  727 */     JsonInclude.Value v = this._annotationIntrospector == null ? null : this._annotationIntrospector.findPropertyInclusion(a);
/*  728 */     return v == null ? JsonInclude.Value.empty() : v;
/*      */   }
/*      */   
/*      */   public JsonProperty.Access findAccess() {
/*  732 */     (JsonProperty.Access)fromMemberAnnotationsExcept(new WithMember()
/*      */     {
/*      */ 
/*  735 */       public JsonProperty.Access withMember(AnnotatedMember member) { return POJOPropertyBuilder.this._annotationIntrospector.findPropertyAccess(member); } }, JsonProperty.Access.AUTO);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addField(AnnotatedField a, PropertyName name, boolean explName, boolean visible, boolean ignored)
/*      */   {
/*  747 */     this._fields = new Linked(a, this._fields, name, explName, visible, ignored);
/*      */   }
/*      */   
/*      */   public void addCtor(AnnotatedParameter a, PropertyName name, boolean explName, boolean visible, boolean ignored) {
/*  751 */     this._ctorParameters = new Linked(a, this._ctorParameters, name, explName, visible, ignored);
/*      */   }
/*      */   
/*      */   public void addGetter(AnnotatedMethod a, PropertyName name, boolean explName, boolean visible, boolean ignored) {
/*  755 */     this._getters = new Linked(a, this._getters, name, explName, visible, ignored);
/*      */   }
/*      */   
/*      */   public void addSetter(AnnotatedMethod a, PropertyName name, boolean explName, boolean visible, boolean ignored) {
/*  759 */     this._setters = new Linked(a, this._setters, name, explName, visible, ignored);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAll(POJOPropertyBuilder src)
/*      */   {
/*  768 */     this._fields = merge(this._fields, src._fields);
/*  769 */     this._ctorParameters = merge(this._ctorParameters, src._ctorParameters);
/*  770 */     this._getters = merge(this._getters, src._getters);
/*  771 */     this._setters = merge(this._setters, src._setters);
/*      */   }
/*      */   
/*      */   private static <T> Linked<T> merge(Linked<T> chain1, Linked<T> chain2)
/*      */   {
/*  776 */     if (chain1 == null) {
/*  777 */       return chain2;
/*      */     }
/*  779 */     if (chain2 == null) {
/*  780 */       return chain1;
/*      */     }
/*  782 */     return chain1.append(chain2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeIgnored()
/*      */   {
/*  797 */     this._fields = _removeIgnored(this._fields);
/*  798 */     this._getters = _removeIgnored(this._getters);
/*  799 */     this._setters = _removeIgnored(this._setters);
/*  800 */     this._ctorParameters = _removeIgnored(this._ctorParameters);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public JsonProperty.Access removeNonVisible(boolean inferMutators) {
/*  805 */     return removeNonVisible(inferMutators, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JsonProperty.Access removeNonVisible(boolean inferMutators, POJOPropertiesCollector parent)
/*      */   {
/*  821 */     JsonProperty.Access acc = findAccess();
/*  822 */     if (acc == null) {
/*  823 */       acc = JsonProperty.Access.AUTO;
/*      */     }
/*  825 */     switch (acc)
/*      */     {
/*      */ 
/*      */ 
/*      */     case READ_ONLY: 
/*  830 */       if (parent != null) {
/*  831 */         parent._collectIgnorals(getName());
/*  832 */         for (PropertyName pn : findExplicitNames()) {
/*  833 */           parent._collectIgnorals(pn.getSimpleName());
/*      */         }
/*      */       }
/*      */       
/*  837 */       this._setters = null;
/*  838 */       this._ctorParameters = null;
/*  839 */       if (!this._forSerialization) {
/*  840 */         this._fields = null;
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case READ_WRITE: 
/*      */       break;
/*      */     case WRITE_ONLY: 
/*  848 */       this._getters = null;
/*  849 */       if (this._forSerialization) {
/*  850 */         this._fields = null;
/*      */       }
/*      */       break;
/*      */     case AUTO: 
/*      */     default: 
/*  855 */       this._getters = _removeNonVisible(this._getters);
/*  856 */       this._ctorParameters = _removeNonVisible(this._ctorParameters);
/*      */       
/*  858 */       if ((!inferMutators) || (this._getters == null)) {
/*  859 */         this._fields = _removeNonVisible(this._fields);
/*  860 */         this._setters = _removeNonVisible(this._setters);
/*      */       }
/*      */       break; }
/*  863 */     return acc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeConstructors()
/*      */   {
/*  872 */     this._ctorParameters = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void trimByVisibility()
/*      */   {
/*  882 */     this._fields = _trimByVisibility(this._fields);
/*  883 */     this._getters = _trimByVisibility(this._getters);
/*  884 */     this._setters = _trimByVisibility(this._setters);
/*  885 */     this._ctorParameters = _trimByVisibility(this._ctorParameters);
/*      */   }
/*      */   
/*      */ 
/*      */   public void mergeAnnotations(boolean forSerialization)
/*      */   {
/*  891 */     if (forSerialization) {
/*  892 */       if (this._getters != null) {
/*  893 */         AnnotationMap ann = _mergeAnnotations(0, new Linked[] { this._getters, this._fields, this._ctorParameters, this._setters });
/*  894 */         this._getters = _applyAnnotations(this._getters, ann);
/*  895 */       } else if (this._fields != null) {
/*  896 */         AnnotationMap ann = _mergeAnnotations(0, new Linked[] { this._fields, this._ctorParameters, this._setters });
/*  897 */         this._fields = _applyAnnotations(this._fields, ann);
/*      */       }
/*      */     }
/*  900 */     else if (this._ctorParameters != null) {
/*  901 */       AnnotationMap ann = _mergeAnnotations(0, new Linked[] { this._ctorParameters, this._setters, this._fields, this._getters });
/*  902 */       this._ctorParameters = _applyAnnotations(this._ctorParameters, ann);
/*  903 */     } else if (this._setters != null) {
/*  904 */       AnnotationMap ann = _mergeAnnotations(0, new Linked[] { this._setters, this._fields, this._getters });
/*  905 */       this._setters = _applyAnnotations(this._setters, ann);
/*  906 */     } else if (this._fields != null) {
/*  907 */       AnnotationMap ann = _mergeAnnotations(0, new Linked[] { this._fields, this._getters });
/*  908 */       this._fields = _applyAnnotations(this._fields, ann);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private AnnotationMap _mergeAnnotations(int index, Linked<? extends AnnotatedMember>... nodes)
/*      */   {
/*  916 */     AnnotationMap ann = _getAllAnnotations(nodes[index]);
/*  917 */     do { index++; if (index >= nodes.length) break;
/*  918 */     } while (nodes[index] == null);
/*  919 */     return AnnotationMap.merge(ann, _mergeAnnotations(index, nodes));
/*      */     
/*      */ 
/*  922 */     return ann;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private <T extends AnnotatedMember> AnnotationMap _getAllAnnotations(Linked<T> node)
/*      */   {
/*  935 */     AnnotationMap ann = ((AnnotatedMember)node.value).getAllAnnotations();
/*  936 */     if (node.next != null) {
/*  937 */       ann = AnnotationMap.merge(ann, _getAllAnnotations(node.next));
/*      */     }
/*  939 */     return ann;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private <T extends AnnotatedMember> Linked<T> _applyAnnotations(Linked<T> node, AnnotationMap ann)
/*      */   {
/*  953 */     T value = (AnnotatedMember)((AnnotatedMember)node.value).withAnnotations(ann);
/*  954 */     if (node.next != null) {
/*  955 */       node = node.withNext(_applyAnnotations(node.next, ann));
/*      */     }
/*  957 */     return node.withValue(value);
/*      */   }
/*      */   
/*      */   private <T> Linked<T> _removeIgnored(Linked<T> node)
/*      */   {
/*  962 */     if (node == null) {
/*  963 */       return node;
/*      */     }
/*  965 */     return node.withoutIgnored();
/*      */   }
/*      */   
/*      */   private <T> Linked<T> _removeNonVisible(Linked<T> node)
/*      */   {
/*  970 */     if (node == null) {
/*  971 */       return node;
/*      */     }
/*  973 */     return node.withoutNonVisible();
/*      */   }
/*      */   
/*      */   private <T> Linked<T> _trimByVisibility(Linked<T> node)
/*      */   {
/*  978 */     if (node == null) {
/*  979 */       return node;
/*      */     }
/*  981 */     return node.trimByVisibility();
/*      */   }
/*      */   
/*      */   private <T> boolean _anyExplicits(Linked<T> n)
/*      */   {
/*  992 */     for (; 
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  992 */         n != null; n = n.next) {
/*  993 */       if ((n.name != null) && (n.name.hasSimpleName())) {
/*  994 */         return true;
/*      */       }
/*      */     }
/*  997 */     return false;
/*      */   }
/*      */   
/*      */   private <T> boolean _anyExplicitNames(Linked<T> n)
/*      */   {
/* 1002 */     for (; n != null; n = n.next) {
/* 1003 */       if ((n.name != null) && (n.isNameExplicit)) {
/* 1004 */         return true;
/*      */       }
/*      */     }
/* 1007 */     return false;
/*      */   }
/*      */   
/*      */   public boolean anyVisible() {
/* 1011 */     return (_anyVisible(this._fields)) || 
/* 1012 */       (_anyVisible(this._getters)) || 
/* 1013 */       (_anyVisible(this._setters)) || 
/* 1014 */       (_anyVisible(this._ctorParameters));
/*      */   }
/*      */   
/*      */   private <T> boolean _anyVisible(Linked<T> n)
/*      */   {
/* 1020 */     for (; 
/* 1020 */         n != null; n = n.next) {
/* 1021 */       if (n.isVisible) {
/* 1022 */         return true;
/*      */       }
/*      */     }
/* 1025 */     return false;
/*      */   }
/*      */   
/*      */   public boolean anyIgnorals() {
/* 1029 */     return (_anyIgnorals(this._fields)) || 
/* 1030 */       (_anyIgnorals(this._getters)) || 
/* 1031 */       (_anyIgnorals(this._setters)) || 
/* 1032 */       (_anyIgnorals(this._ctorParameters));
/*      */   }
/*      */   
/*      */   private <T> boolean _anyIgnorals(Linked<T> n)
/*      */   {
/* 1038 */     for (; 
/* 1038 */         n != null; n = n.next) {
/* 1039 */       if (n.isMarkedIgnored) {
/* 1040 */         return true;
/*      */       }
/*      */     }
/* 1043 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<PropertyName> findExplicitNames()
/*      */   {
/* 1054 */     Set<PropertyName> renamed = null;
/* 1055 */     renamed = _findExplicitNames(this._fields, renamed);
/* 1056 */     renamed = _findExplicitNames(this._getters, renamed);
/* 1057 */     renamed = _findExplicitNames(this._setters, renamed);
/* 1058 */     renamed = _findExplicitNames(this._ctorParameters, renamed);
/* 1059 */     if (renamed == null) {
/* 1060 */       return Collections.emptySet();
/*      */     }
/* 1062 */     return renamed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Collection<POJOPropertyBuilder> explode(Collection<PropertyName> newNames)
/*      */   {
/* 1075 */     HashMap<PropertyName, POJOPropertyBuilder> props = new HashMap();
/* 1076 */     _explode(newNames, props, this._fields);
/* 1077 */     _explode(newNames, props, this._getters);
/* 1078 */     _explode(newNames, props, this._setters);
/* 1079 */     _explode(newNames, props, this._ctorParameters);
/* 1080 */     return props.values();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void _explode(Collection<PropertyName> newNames, Map<PropertyName, POJOPropertyBuilder> props, Linked<?> accessors)
/*      */   {
/* 1088 */     Linked<?> firstAcc = accessors;
/* 1089 */     for (Linked<?> node = accessors; node != null; node = node.next) {
/* 1090 */       PropertyName name = node.name;
/* 1091 */       if ((!node.isNameExplicit) || (name == null))
/*      */       {
/* 1093 */         if (node.isVisible)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1098 */           throw new IllegalStateException("Conflicting/ambiguous property name definitions (implicit name " + ClassUtil.name(this._name) + "): found multiple explicit names: " + newNames + ", but also implicit accessor: " + node);
/*      */         }
/*      */       } else {
/* 1101 */         POJOPropertyBuilder prop = (POJOPropertyBuilder)props.get(name);
/* 1102 */         if (prop == null) {
/* 1103 */           prop = new POJOPropertyBuilder(this._config, this._annotationIntrospector, this._forSerialization, this._internalName, name);
/*      */           
/* 1105 */           props.put(name, prop);
/*      */         }
/*      */         
/* 1108 */         if (firstAcc == this._fields) {
/* 1109 */           Linked<AnnotatedField> n2 = node;
/* 1110 */           prop._fields = n2.withNext(prop._fields);
/* 1111 */         } else if (firstAcc == this._getters) {
/* 1112 */           Linked<AnnotatedMethod> n2 = node;
/* 1113 */           prop._getters = n2.withNext(prop._getters);
/* 1114 */         } else if (firstAcc == this._setters) {
/* 1115 */           Linked<AnnotatedMethod> n2 = node;
/* 1116 */           prop._setters = n2.withNext(prop._setters);
/* 1117 */         } else if (firstAcc == this._ctorParameters) {
/* 1118 */           Linked<AnnotatedParameter> n2 = node;
/* 1119 */           prop._ctorParameters = n2.withNext(prop._ctorParameters);
/*      */         } else {
/* 1121 */           throw new IllegalStateException("Internal error: mismatched accessors, property: " + this);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private Set<PropertyName> _findExplicitNames(Linked<? extends AnnotatedMember> node, Set<PropertyName> renamed)
/*      */   {
/* 1129 */     for (; node != null; node = node.next)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1136 */       if ((node.isNameExplicit) && (node.name != null))
/*      */       {
/*      */ 
/* 1139 */         if (renamed == null) {
/* 1140 */           renamed = new HashSet();
/*      */         }
/* 1142 */         renamed.add(node.name);
/*      */       } }
/* 1144 */     return renamed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1151 */     StringBuilder sb = new StringBuilder();
/* 1152 */     sb.append("[Property '").append(this._name)
/* 1153 */       .append("'; ctors: ").append(this._ctorParameters)
/* 1154 */       .append(", field(s): ").append(this._fields)
/* 1155 */       .append(", getter(s): ").append(this._getters)
/* 1156 */       .append(", setter(s): ").append(this._setters);
/*      */     
/* 1158 */     sb.append("]");
/* 1159 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected <T> T fromMemberAnnotations(WithMember<T> func)
/*      */   {
/* 1174 */     T result = null;
/* 1175 */     if (this._annotationIntrospector != null) {
/* 1176 */       if (this._forSerialization) {
/* 1177 */         if (this._getters != null) {
/* 1178 */           result = func.withMember((AnnotatedMember)this._getters.value);
/*      */         }
/*      */       } else {
/* 1181 */         if (this._ctorParameters != null) {
/* 1182 */           result = func.withMember((AnnotatedMember)this._ctorParameters.value);
/*      */         }
/* 1184 */         if ((result == null) && (this._setters != null)) {
/* 1185 */           result = func.withMember((AnnotatedMember)this._setters.value);
/*      */         }
/*      */       }
/* 1188 */       if ((result == null) && (this._fields != null)) {
/* 1189 */         result = func.withMember((AnnotatedMember)this._fields.value);
/*      */       }
/*      */     }
/* 1192 */     return result;
/*      */   }
/*      */   
/*      */   protected <T> T fromMemberAnnotationsExcept(WithMember<T> func, T defaultValue)
/*      */   {
/* 1197 */     if (this._annotationIntrospector == null) {
/* 1198 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1203 */     if (this._forSerialization) {
/* 1204 */       if (this._getters != null) {
/* 1205 */         T result = func.withMember((AnnotatedMember)this._getters.value);
/* 1206 */         if ((result != null) && (result != defaultValue)) {
/* 1207 */           return result;
/*      */         }
/*      */       }
/* 1210 */       if (this._fields != null) {
/* 1211 */         T result = func.withMember((AnnotatedMember)this._fields.value);
/* 1212 */         if ((result != null) && (result != defaultValue)) {
/* 1213 */           return result;
/*      */         }
/*      */       }
/* 1216 */       if (this._ctorParameters != null) {
/* 1217 */         T result = func.withMember((AnnotatedMember)this._ctorParameters.value);
/* 1218 */         if ((result != null) && (result != defaultValue)) {
/* 1219 */           return result;
/*      */         }
/*      */       }
/* 1222 */       if (this._setters != null) {
/* 1223 */         T result = func.withMember((AnnotatedMember)this._setters.value);
/* 1224 */         if ((result != null) && (result != defaultValue)) {
/* 1225 */           return result;
/*      */         }
/*      */       }
/* 1228 */       return null;
/*      */     }
/* 1230 */     if (this._ctorParameters != null) {
/* 1231 */       T result = func.withMember((AnnotatedMember)this._ctorParameters.value);
/* 1232 */       if ((result != null) && (result != defaultValue)) {
/* 1233 */         return result;
/*      */       }
/*      */     }
/* 1236 */     if (this._setters != null) {
/* 1237 */       T result = func.withMember((AnnotatedMember)this._setters.value);
/* 1238 */       if ((result != null) && (result != defaultValue)) {
/* 1239 */         return result;
/*      */       }
/*      */     }
/* 1242 */     if (this._fields != null) {
/* 1243 */       T result = func.withMember((AnnotatedMember)this._fields.value);
/* 1244 */       if ((result != null) && (result != defaultValue)) {
/* 1245 */         return result;
/*      */       }
/*      */     }
/* 1248 */     if (this._getters != null) {
/* 1249 */       T result = func.withMember((AnnotatedMember)this._getters.value);
/* 1250 */       if ((result != null) && (result != defaultValue)) {
/* 1251 */         return result;
/*      */       }
/*      */     }
/* 1254 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Class<?> _rawTypeOf(AnnotatedMember m)
/*      */   {
/* 1264 */     if ((m instanceof AnnotatedMethod)) {
/* 1265 */       AnnotatedMethod meh = (AnnotatedMethod)m;
/* 1266 */       if (meh.getParameterCount() > 0)
/*      */       {
/*      */ 
/* 1269 */         return meh.getParameterType(0).getRawClass();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1274 */     return m.getType().getRawClass();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static abstract interface WithMember<T>
/*      */   {
/*      */     public abstract T withMember(AnnotatedMember paramAnnotatedMember);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static class MemberIterator<T extends AnnotatedMember>
/*      */     implements Iterator<T>
/*      */   {
/*      */     private POJOPropertyBuilder.Linked<T> next;
/*      */     
/*      */ 
/*      */ 
/*      */     public MemberIterator(POJOPropertyBuilder.Linked<T> first)
/*      */     {
/* 1296 */       this.next = first;
/*      */     }
/*      */     
/*      */     public boolean hasNext()
/*      */     {
/* 1301 */       return this.next != null;
/*      */     }
/*      */     
/*      */     public T next()
/*      */     {
/* 1306 */       if (this.next == null) throw new NoSuchElementException();
/* 1307 */       T result = (AnnotatedMember)this.next.value;
/* 1308 */       this.next = this.next.next;
/* 1309 */       return result;
/*      */     }
/*      */     
/*      */     public void remove()
/*      */     {
/* 1314 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected static final class Linked<T>
/*      */   {
/*      */     public final T value;
/*      */     
/*      */     public final Linked<T> next;
/*      */     
/*      */     public final PropertyName name;
/*      */     
/*      */     public final boolean isNameExplicit;
/*      */     
/*      */     public final boolean isVisible;
/*      */     
/*      */     public final boolean isMarkedIgnored;
/*      */     
/*      */ 
/*      */     public Linked(T v, Linked<T> n, PropertyName name, boolean explName, boolean visible, boolean ignored)
/*      */     {
/* 1336 */       this.value = v;
/* 1337 */       this.next = n;
/*      */       
/* 1339 */       this.name = ((name == null) || (name.isEmpty()) ? null : name);
/*      */       
/* 1341 */       if (explName) {
/* 1342 */         if (this.name == null) {
/* 1343 */           throw new IllegalArgumentException("Cannot pass true for 'explName' if name is null/empty");
/*      */         }
/*      */         
/*      */ 
/* 1347 */         if (!name.hasSimpleName()) {
/* 1348 */           explName = false;
/*      */         }
/*      */       }
/*      */       
/* 1352 */       this.isNameExplicit = explName;
/* 1353 */       this.isVisible = visible;
/* 1354 */       this.isMarkedIgnored = ignored;
/*      */     }
/*      */     
/*      */     public Linked<T> withoutNext() {
/* 1358 */       if (this.next == null) {
/* 1359 */         return this;
/*      */       }
/* 1361 */       return new Linked(this.value, null, this.name, this.isNameExplicit, this.isVisible, this.isMarkedIgnored);
/*      */     }
/*      */     
/*      */     public Linked<T> withValue(T newValue) {
/* 1365 */       if (newValue == this.value) {
/* 1366 */         return this;
/*      */       }
/* 1368 */       return new Linked(newValue, this.next, this.name, this.isNameExplicit, this.isVisible, this.isMarkedIgnored);
/*      */     }
/*      */     
/*      */     public Linked<T> withNext(Linked<T> newNext) {
/* 1372 */       if (newNext == this.next) {
/* 1373 */         return this;
/*      */       }
/* 1375 */       return new Linked(this.value, newNext, this.name, this.isNameExplicit, this.isVisible, this.isMarkedIgnored);
/*      */     }
/*      */     
/*      */     public Linked<T> withoutIgnored() {
/* 1379 */       if (this.isMarkedIgnored) {
/* 1380 */         return this.next == null ? null : this.next.withoutIgnored();
/*      */       }
/* 1382 */       if (this.next != null) {
/* 1383 */         Linked<T> newNext = this.next.withoutIgnored();
/* 1384 */         if (newNext != this.next) {
/* 1385 */           return withNext(newNext);
/*      */         }
/*      */       }
/* 1388 */       return this;
/*      */     }
/*      */     
/*      */     public Linked<T> withoutNonVisible() {
/* 1392 */       Linked<T> newNext = this.next == null ? null : this.next.withoutNonVisible();
/* 1393 */       return this.isVisible ? withNext(newNext) : newNext;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Linked<T> append(Linked<T> appendable)
/*      */     {
/* 1401 */       if (this.next == null) {
/* 1402 */         return withNext(appendable);
/*      */       }
/* 1404 */       return withNext(this.next.append(appendable));
/*      */     }
/*      */     
/*      */     public Linked<T> trimByVisibility() {
/* 1408 */       if (this.next == null) {
/* 1409 */         return this;
/*      */       }
/* 1411 */       Linked<T> newNext = this.next.trimByVisibility();
/* 1412 */       if (this.name != null) {
/* 1413 */         if (newNext.name == null) {
/* 1414 */           return withNext(null);
/*      */         }
/*      */         
/* 1417 */         return withNext(newNext);
/*      */       }
/* 1419 */       if (newNext.name != null) {
/* 1420 */         return newNext;
/*      */       }
/*      */       
/* 1423 */       if (this.isVisible == newNext.isVisible) {
/* 1424 */         return withNext(newNext);
/*      */       }
/* 1426 */       return this.isVisible ? withNext(null) : newNext;
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/* 1431 */       String msg = String.format("%s[visible=%b,ignore=%b,explicitName=%b]", new Object[] {this.value
/* 1432 */         .toString(), Boolean.valueOf(this.isVisible), Boolean.valueOf(this.isMarkedIgnored), Boolean.valueOf(this.isNameExplicit) });
/* 1433 */       if (this.next != null) {
/* 1434 */         msg = msg + ", " + this.next.toString();
/*      */       }
/* 1436 */       return msg;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\introspect\POJOPropertyBuilder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */