/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException.Reference;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonschema.JsonSerializableSchema;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.ser.AnyGetterWriter;
/*     */ import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
/*     */ import com.fasterxml.jackson.databind.ser.BeanSerializerBuilder;
/*     */ import com.fasterxml.jackson.databind.ser.ContainerSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.PropertyFilter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.ObjectIdWriter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.WritableObjectId;
/*     */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public abstract class BeanSerializerBase extends StdSerializer<Object> implements com.fasterxml.jackson.databind.ser.ContextualSerializer, com.fasterxml.jackson.databind.ser.ResolvableSerializer, com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitable, com.fasterxml.jackson.databind.jsonschema.SchemaAware
/*     */ {
/*  45 */   protected static final PropertyName NAME_FOR_OBJECT_REF = new PropertyName("#object-ref");
/*     */   
/*  47 */   protected static final BeanPropertyWriter[] NO_PROPS = new BeanPropertyWriter[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final JavaType _beanType;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final BeanPropertyWriter[] _props;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final BeanPropertyWriter[] _filteredProps;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final AnyGetterWriter _anyGetterWriter;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Object _propertyFilterId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final AnnotatedMember _typeId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ObjectIdWriter _objectIdWriter;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final JsonFormat.Shape _serializationShape;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BeanSerializerBase(JavaType type, BeanSerializerBuilder builder, BeanPropertyWriter[] properties, BeanPropertyWriter[] filteredProperties)
/*     */   {
/* 116 */     super(type);
/* 117 */     this._beanType = type;
/* 118 */     this._props = properties;
/* 119 */     this._filteredProps = filteredProperties;
/* 120 */     if (builder == null)
/*     */     {
/*     */ 
/* 123 */       this._typeId = null;
/* 124 */       this._anyGetterWriter = null;
/* 125 */       this._propertyFilterId = null;
/* 126 */       this._objectIdWriter = null;
/* 127 */       this._serializationShape = null;
/*     */     } else {
/* 129 */       this._typeId = builder.getTypeId();
/* 130 */       this._anyGetterWriter = builder.getAnyGetter();
/* 131 */       this._propertyFilterId = builder.getFilterId();
/* 132 */       this._objectIdWriter = builder.getObjectIdWriter();
/* 133 */       JsonFormat.Value format = builder.getBeanDescription().findExpectedFormat(null);
/* 134 */       this._serializationShape = format.getShape();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected BeanSerializerBase(BeanSerializerBase src, BeanPropertyWriter[] properties, BeanPropertyWriter[] filteredProperties)
/*     */   {
/* 141 */     super(src._handledType);
/* 142 */     this._beanType = src._beanType;
/* 143 */     this._props = properties;
/* 144 */     this._filteredProps = filteredProperties;
/*     */     
/* 146 */     this._typeId = src._typeId;
/* 147 */     this._anyGetterWriter = src._anyGetterWriter;
/* 148 */     this._objectIdWriter = src._objectIdWriter;
/* 149 */     this._propertyFilterId = src._propertyFilterId;
/* 150 */     this._serializationShape = src._serializationShape;
/*     */   }
/*     */   
/*     */ 
/*     */   protected BeanSerializerBase(BeanSerializerBase src, ObjectIdWriter objectIdWriter)
/*     */   {
/* 156 */     this(src, objectIdWriter, src._propertyFilterId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BeanSerializerBase(BeanSerializerBase src, ObjectIdWriter objectIdWriter, Object filterId)
/*     */   {
/* 165 */     super(src._handledType);
/* 166 */     this._beanType = src._beanType;
/* 167 */     this._props = src._props;
/* 168 */     this._filteredProps = src._filteredProps;
/*     */     
/* 170 */     this._typeId = src._typeId;
/* 171 */     this._anyGetterWriter = src._anyGetterWriter;
/* 172 */     this._objectIdWriter = objectIdWriter;
/* 173 */     this._propertyFilterId = filterId;
/* 174 */     this._serializationShape = src._serializationShape;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected BeanSerializerBase(BeanSerializerBase src, String[] toIgnore)
/*     */   {
/* 180 */     this(src, ArrayBuilders.arrayToSet(toIgnore), null);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected BeanSerializerBase(BeanSerializerBase src, Set<String> toIgnore) {
/* 185 */     this(src, toIgnore, null);
/*     */   }
/*     */   
/*     */   protected BeanSerializerBase(BeanSerializerBase src, Set<String> toIgnore, Set<String> toInclude)
/*     */   {
/* 190 */     super(src._handledType);
/*     */     
/* 192 */     this._beanType = src._beanType;
/* 193 */     BeanPropertyWriter[] propsIn = src._props;
/* 194 */     BeanPropertyWriter[] fpropsIn = src._filteredProps;
/* 195 */     int len = propsIn.length;
/*     */     
/* 197 */     ArrayList<BeanPropertyWriter> propsOut = new ArrayList(len);
/* 198 */     ArrayList<BeanPropertyWriter> fpropsOut = fpropsIn == null ? null : new ArrayList(len);
/*     */     
/* 200 */     for (int i = 0; i < len; i++) {
/* 201 */       BeanPropertyWriter bpw = propsIn[i];
/*     */       
/* 203 */       if (!com.fasterxml.jackson.databind.util.IgnorePropertiesUtil.shouldIgnore(bpw.getName(), toIgnore, toInclude))
/*     */       {
/*     */ 
/* 206 */         propsOut.add(bpw);
/* 207 */         if (fpropsIn != null)
/* 208 */           fpropsOut.add(fpropsIn[i]);
/*     */       }
/*     */     }
/* 211 */     this._props = ((BeanPropertyWriter[])propsOut.toArray(new BeanPropertyWriter[propsOut.size()]));
/* 212 */     this._filteredProps = (fpropsOut == null ? null : (BeanPropertyWriter[])fpropsOut.toArray(new BeanPropertyWriter[fpropsOut.size()]));
/*     */     
/* 214 */     this._typeId = src._typeId;
/* 215 */     this._anyGetterWriter = src._anyGetterWriter;
/* 216 */     this._objectIdWriter = src._objectIdWriter;
/* 217 */     this._propertyFilterId = src._propertyFilterId;
/* 218 */     this._serializationShape = src._serializationShape;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract BeanSerializerBase withObjectIdWriter(ObjectIdWriter paramObjectIdWriter);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected BeanSerializerBase withIgnorals(Set<String> toIgnore)
/*     */   {
/* 238 */     return withByNameInclusion(toIgnore, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract BeanSerializerBase withByNameInclusion(Set<String> paramSet1, Set<String> paramSet2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected BeanSerializerBase withIgnorals(String[] toIgnore)
/*     */   {
/* 258 */     return withIgnorals(ArrayBuilders.arrayToSet(toIgnore));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract BeanSerializerBase asArraySerializer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract BeanSerializerBase withFilterId(Object paramObject);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract BeanSerializerBase withProperties(BeanPropertyWriter[] paramArrayOfBeanPropertyWriter1, BeanPropertyWriter[] paramArrayOfBeanPropertyWriter2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BeanSerializerBase(BeanSerializerBase src)
/*     */   {
/* 296 */     this(src, src._props, src._filteredProps);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BeanSerializerBase(BeanSerializerBase src, NameTransformer unwrapper)
/*     */   {
/* 304 */     this(src, rename(src._props, unwrapper), rename(src._filteredProps, unwrapper));
/*     */   }
/*     */   
/*     */ 
/*     */   private static final BeanPropertyWriter[] rename(BeanPropertyWriter[] props, NameTransformer transformer)
/*     */   {
/* 310 */     if ((props == null) || (props.length == 0) || (transformer == null) || (transformer == NameTransformer.NOP)) {
/* 311 */       return props;
/*     */     }
/* 313 */     int len = props.length;
/* 314 */     BeanPropertyWriter[] result = new BeanPropertyWriter[len];
/* 315 */     for (int i = 0; i < len; i++) {
/* 316 */       BeanPropertyWriter bpw = props[i];
/* 317 */       if (bpw != null) {
/* 318 */         result[i] = bpw.rename(transformer);
/*     */       }
/*     */     }
/* 321 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resolve(SerializerProvider provider)
/*     */     throws JsonMappingException
/*     */   {
/* 338 */     int filteredCount = this._filteredProps == null ? 0 : this._filteredProps.length;
/* 339 */     int i = 0; for (int len = this._props.length; i < len; i++) {
/* 340 */       BeanPropertyWriter prop = this._props[i];
/*     */       
/* 342 */       if ((!prop.willSuppressNulls()) && (!prop.hasNullSerializer())) {
/* 343 */         JsonSerializer<Object> nullSer = provider.findNullValueSerializer(prop);
/* 344 */         if (nullSer != null) {
/* 345 */           prop.assignNullSerializer(nullSer);
/*     */           
/* 347 */           if (i < filteredCount) {
/* 348 */             BeanPropertyWriter w2 = this._filteredProps[i];
/* 349 */             if (w2 != null) {
/* 350 */               w2.assignNullSerializer(nullSer);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 356 */       if (!prop.hasSerializer())
/*     */       {
/*     */ 
/*     */ 
/* 360 */         JsonSerializer<Object> ser = findConvertingSerializer(provider, prop);
/* 361 */         if (ser == null)
/*     */         {
/* 363 */           JavaType type = prop.getSerializationType();
/*     */           
/*     */ 
/*     */ 
/* 367 */           if (type == null) {
/* 368 */             type = prop.getType();
/* 369 */             if (!type.isFinal()) {
/* 370 */               if ((!type.isContainerType()) && (type.containedTypeCount() <= 0)) continue;
/* 371 */               prop.setNonTrivialBaseType(type); continue;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 376 */           ser = provider.findValueSerializer(type, prop);
/*     */           
/*     */ 
/* 379 */           if (type.isContainerType()) {
/* 380 */             TypeSerializer typeSer = (TypeSerializer)type.getContentType().getTypeHandler();
/* 381 */             if (typeSer != null)
/*     */             {
/* 383 */               if ((ser instanceof ContainerSerializer))
/*     */               {
/*     */ 
/* 386 */                 JsonSerializer<Object> ser2 = ((ContainerSerializer)ser).withValueTypeSerializer(typeSer);
/* 387 */                 ser = ser2;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 393 */         if (i < filteredCount) {
/* 394 */           BeanPropertyWriter w2 = this._filteredProps[i];
/* 395 */           if (w2 != null) {
/* 396 */             w2.assignSerializer(ser);
/*     */             
/*     */ 
/*     */ 
/* 400 */             continue;
/*     */           }
/*     */         }
/* 403 */         prop.assignSerializer(ser);
/*     */       }
/*     */     }
/*     */     
/* 407 */     if (this._anyGetterWriter != null)
/*     */     {
/* 409 */       this._anyGetterWriter.resolve(provider);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JsonSerializer<Object> findConvertingSerializer(SerializerProvider provider, BeanPropertyWriter prop)
/*     */     throws JsonMappingException
/*     */   {
/* 424 */     AnnotationIntrospector intr = provider.getAnnotationIntrospector();
/* 425 */     if (intr != null) {
/* 426 */       AnnotatedMember m = prop.getMember();
/* 427 */       if (m != null) {
/* 428 */         Object convDef = intr.findSerializationConverter(m);
/* 429 */         if (convDef != null) {
/* 430 */           Converter<Object, Object> conv = provider.converterInstance(prop.getMember(), convDef);
/* 431 */           JavaType delegateType = conv.getOutputType(provider.getTypeFactory());
/*     */           
/*     */ 
/* 434 */           JsonSerializer<?> ser = delegateType.isJavaLangObject() ? null : provider.findValueSerializer(delegateType, prop);
/* 435 */           return new StdDelegatingSerializer(conv, delegateType, ser);
/*     */         }
/*     */       }
/*     */     }
/* 439 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonSerializer<?> createContextual(SerializerProvider provider, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 448 */     AnnotationIntrospector intr = provider.getAnnotationIntrospector();
/*     */     
/* 450 */     AnnotatedMember accessor = (property == null) || (intr == null) ? null : property.getMember();
/* 451 */     SerializationConfig config = provider.getConfig();
/*     */     
/*     */ 
/*     */ 
/* 455 */     JsonFormat.Value format = findFormatOverrides(provider, property, this._handledType);
/* 456 */     JsonFormat.Shape shape = null;
/* 457 */     if ((format != null) && (format.hasShape())) {
/* 458 */       shape = format.getShape();
/*     */       
/* 460 */       if ((shape != JsonFormat.Shape.ANY) && (shape != this._serializationShape)) {
/* 461 */         if (this._beanType.isEnumType()) {
/* 462 */           switch (shape)
/*     */           {
/*     */ 
/*     */           case STRING: 
/*     */           case NUMBER: 
/*     */           case NUMBER_INT: 
/* 468 */             BeanDescription desc = config.introspectClassAnnotations(this._beanType);
/* 469 */             JsonSerializer<?> ser = EnumSerializer.construct(this._beanType.getRawClass(), provider
/* 470 */               .getConfig(), desc, format);
/* 471 */             return provider.handlePrimaryContextualization(ser, property);
/*     */           }
/*     */           
/* 474 */         } else if ((shape == JsonFormat.Shape.NATURAL) && (
/* 475 */           (!this._beanType.isMapLikeType()) || (!java.util.Map.class.isAssignableFrom(this._handledType))))
/*     */         {
/* 477 */           if (Map.Entry.class.isAssignableFrom(this._handledType)) {
/* 478 */             JavaType mapEntryType = this._beanType.findSuperType(Map.Entry.class);
/*     */             
/* 480 */             JavaType kt = mapEntryType.containedTypeOrUnknown(0);
/* 481 */             JavaType vt = mapEntryType.containedTypeOrUnknown(1);
/*     */             
/*     */ 
/*     */ 
/* 485 */             JsonSerializer<?> ser = new com.fasterxml.jackson.databind.ser.impl.MapEntrySerializer(this._beanType, kt, vt, false, null, property);
/*     */             
/* 487 */             return provider.handlePrimaryContextualization(ser, property);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 493 */     ObjectIdWriter oiw = this._objectIdWriter;
/*     */     
/*     */ 
/*     */ 
/* 497 */     int idPropOrigIndex = 0;
/* 498 */     Set<String> ignoredProps = null;
/* 499 */     Set<String> includedProps = null;
/* 500 */     Object newFilterId = null;
/*     */     
/*     */ 
/* 503 */     if (accessor != null) {
/* 504 */       ignoredProps = intr.findPropertyIgnoralByName(config, accessor).findIgnoredForSerialization();
/* 505 */       includedProps = intr.findPropertyInclusionByName(config, accessor).getIncluded();
/* 506 */       ObjectIdInfo objectIdInfo = intr.findObjectIdInfo(accessor);
/* 507 */       if (objectIdInfo == null)
/*     */       {
/* 509 */         if (oiw != null) {
/* 510 */           objectIdInfo = intr.findObjectReferenceInfo(accessor, null);
/* 511 */           if (objectIdInfo != null) {
/* 512 */             oiw = this._objectIdWriter.withAlwaysAsId(objectIdInfo.getAlwaysAsId());
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 520 */         objectIdInfo = intr.findObjectReferenceInfo(accessor, objectIdInfo);
/* 521 */         Class<?> implClass = objectIdInfo.getGeneratorType();
/* 522 */         JavaType type = provider.constructType(implClass);
/* 523 */         JavaType idType = provider.getTypeFactory().findTypeParameters(type, ObjectIdGenerator.class)[0];
/*     */         
/* 525 */         if (implClass == com.fasterxml.jackson.annotation.ObjectIdGenerators.PropertyGenerator.class) {
/* 526 */           String propName = objectIdInfo.getPropertyName().getSimpleName();
/* 527 */           BeanPropertyWriter idProp = null;
/*     */           
/* 529 */           int i = 0; for (int len = this._props.length;; i++) {
/* 530 */             if (i == len) {
/* 531 */               provider.reportBadDefinition(this._beanType, String.format("Invalid Object Id definition for %s: cannot find property with name %s", new Object[] {
/*     */               
/* 533 */                 ClassUtil.nameOf(handledType()), ClassUtil.name(propName) }));
/*     */             }
/* 535 */             BeanPropertyWriter prop = this._props[i];
/* 536 */             if (propName.equals(prop.getName())) {
/* 537 */               idProp = prop;
/*     */               
/*     */ 
/* 540 */               idPropOrigIndex = i;
/* 541 */               break;
/*     */             }
/*     */           }
/* 544 */           idType = idProp.getType();
/* 545 */           ObjectIdGenerator<?> gen = new com.fasterxml.jackson.databind.ser.impl.PropertyBasedObjectIdGenerator(objectIdInfo, idProp);
/* 546 */           oiw = ObjectIdWriter.construct(idType, (PropertyName)null, gen, objectIdInfo.getAlwaysAsId());
/*     */         } else {
/* 548 */           ObjectIdGenerator<?> gen = provider.objectIdGeneratorInstance(accessor, objectIdInfo);
/* 549 */           oiw = ObjectIdWriter.construct(idType, objectIdInfo.getPropertyName(), gen, objectIdInfo
/* 550 */             .getAlwaysAsId());
/*     */         }
/*     */       }
/*     */       
/* 554 */       Object filterId = intr.findFilterId(accessor);
/* 555 */       if (filterId != null)
/*     */       {
/* 557 */         if ((this._propertyFilterId == null) || (!filterId.equals(this._propertyFilterId))) {
/* 558 */           newFilterId = filterId;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 563 */     BeanSerializerBase contextual = this;
/*     */     
/*     */ 
/* 566 */     if (idPropOrigIndex > 0) {
/* 567 */       BeanPropertyWriter[] newProps = (BeanPropertyWriter[])Arrays.copyOf(this._props, this._props.length);
/* 568 */       BeanPropertyWriter bpw = newProps[idPropOrigIndex];
/* 569 */       System.arraycopy(newProps, 0, newProps, 1, idPropOrigIndex);
/* 570 */       newProps[0] = bpw;
/*     */       BeanPropertyWriter[] newFiltered;
/* 572 */       BeanPropertyWriter[] newFiltered; if (this._filteredProps == null) {
/* 573 */         newFiltered = null;
/*     */       } else {
/* 575 */         newFiltered = (BeanPropertyWriter[])Arrays.copyOf(this._filteredProps, this._filteredProps.length);
/* 576 */         bpw = newFiltered[idPropOrigIndex];
/* 577 */         System.arraycopy(newFiltered, 0, newFiltered, 1, idPropOrigIndex);
/* 578 */         newFiltered[0] = bpw;
/*     */       }
/* 580 */       contextual = contextual.withProperties(newProps, newFiltered);
/*     */     }
/*     */     
/* 583 */     if (oiw != null) {
/* 584 */       JsonSerializer<?> ser = provider.findValueSerializer(oiw.idType, property);
/* 585 */       oiw = oiw.withSerializer(ser);
/* 586 */       if (oiw != this._objectIdWriter) {
/* 587 */         contextual = contextual.withObjectIdWriter(oiw);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 592 */     if (((ignoredProps != null) && (!ignoredProps.isEmpty())) || (includedProps != null))
/*     */     {
/* 594 */       contextual = contextual.withByNameInclusion(ignoredProps, includedProps);
/*     */     }
/* 596 */     if (newFilterId != null) {
/* 597 */       contextual = contextual.withFilterId(newFilterId);
/*     */     }
/*     */     
/* 600 */     if (shape == null) {
/* 601 */       shape = this._serializationShape;
/*     */     }
/*     */     
/* 604 */     if (shape == JsonFormat.Shape.ARRAY) {
/* 605 */       return contextual.asArraySerializer();
/*     */     }
/* 607 */     return contextual;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public java.util.Iterator<com.fasterxml.jackson.databind.ser.PropertyWriter> properties()
/*     */   {
/* 618 */     return Arrays.asList(this._props).iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean usesObjectId()
/*     */   {
/* 629 */     return this._objectIdWriter != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void serialize(Object paramObject, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */   public void serializeWithType(Object bean, JsonGenerator gen, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException
/*     */   {
/* 643 */     if (this._objectIdWriter != null) {
/* 644 */       gen.setCurrentValue(bean);
/* 645 */       _serializeWithObjectId(bean, gen, provider, typeSer);
/* 646 */       return;
/*     */     }
/*     */     
/* 649 */     gen.setCurrentValue(bean);
/* 650 */     WritableTypeId typeIdDef = _typeIdDef(typeSer, bean, JsonToken.START_OBJECT);
/* 651 */     typeSer.writeTypePrefix(gen, typeIdDef);
/* 652 */     if (this._propertyFilterId != null) {
/* 653 */       serializeFieldsFiltered(bean, gen, provider);
/*     */     } else {
/* 655 */       serializeFields(bean, gen, provider);
/*     */     }
/* 657 */     typeSer.writeTypeSuffix(gen, typeIdDef);
/*     */   }
/*     */   
/*     */   protected final void _serializeWithObjectId(Object bean, JsonGenerator gen, SerializerProvider provider, boolean startEndObject)
/*     */     throws IOException
/*     */   {
/* 663 */     ObjectIdWriter w = this._objectIdWriter;
/* 664 */     WritableObjectId objectId = provider.findObjectId(bean, w.generator);
/*     */     
/* 666 */     if (objectId.writeAsId(gen, provider, w)) {
/* 667 */       return;
/*     */     }
/*     */     
/* 670 */     Object id = objectId.generateId(bean);
/* 671 */     if (w.alwaysAsId) {
/* 672 */       w.serializer.serialize(id, gen, provider);
/* 673 */       return;
/*     */     }
/* 675 */     if (startEndObject) {
/* 676 */       gen.writeStartObject(bean);
/*     */     }
/* 678 */     objectId.writeAsField(gen, provider, w);
/* 679 */     if (this._propertyFilterId != null) {
/* 680 */       serializeFieldsFiltered(bean, gen, provider);
/*     */     } else {
/* 682 */       serializeFields(bean, gen, provider);
/*     */     }
/* 684 */     if (startEndObject) {
/* 685 */       gen.writeEndObject();
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void _serializeWithObjectId(Object bean, JsonGenerator gen, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException
/*     */   {
/* 692 */     ObjectIdWriter w = this._objectIdWriter;
/* 693 */     WritableObjectId objectId = provider.findObjectId(bean, w.generator);
/*     */     
/* 695 */     if (objectId.writeAsId(gen, provider, w)) {
/* 696 */       return;
/*     */     }
/*     */     
/* 699 */     Object id = objectId.generateId(bean);
/* 700 */     if (w.alwaysAsId) {
/* 701 */       w.serializer.serialize(id, gen, provider);
/* 702 */       return;
/*     */     }
/* 704 */     _serializeObjectId(bean, gen, provider, typeSer, objectId);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void _serializeObjectId(Object bean, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer, WritableObjectId objectId)
/*     */     throws IOException
/*     */   {
/* 711 */     ObjectIdWriter w = this._objectIdWriter;
/* 712 */     WritableTypeId typeIdDef = _typeIdDef(typeSer, bean, JsonToken.START_OBJECT);
/*     */     
/* 714 */     typeSer.writeTypePrefix(g, typeIdDef);
/* 715 */     objectId.writeAsField(g, provider, w);
/* 716 */     if (this._propertyFilterId != null) {
/* 717 */       serializeFieldsFiltered(bean, g, provider);
/*     */     } else {
/* 719 */       serializeFields(bean, g, provider);
/*     */     }
/* 721 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final WritableTypeId _typeIdDef(TypeSerializer typeSer, Object bean, JsonToken valueShape)
/*     */   {
/* 729 */     if (this._typeId == null) {
/* 730 */       return typeSer.typeId(bean, valueShape);
/*     */     }
/* 732 */     Object typeId = this._typeId.getValue(bean);
/* 733 */     if (typeId == null)
/*     */     {
/* 735 */       typeId = "";
/*     */     }
/* 737 */     return typeSer.typeId(bean, valueShape, typeId);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected final String _customTypeId(Object bean)
/*     */   {
/* 743 */     Object typeId = this._typeId.getValue(bean);
/* 744 */     if (typeId == null) {
/* 745 */       return "";
/*     */     }
/* 747 */     return (typeId instanceof String) ? (String)typeId : typeId.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void serializeFields(Object bean, JsonGenerator gen, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/*     */     BeanPropertyWriter[] props;
/*     */     
/*     */ 
/*     */     BeanPropertyWriter[] props;
/*     */     
/* 760 */     if ((this._filteredProps != null) && (provider.getActiveView() != null)) {
/* 761 */       props = this._filteredProps;
/*     */     } else {
/* 763 */       props = this._props;
/*     */     }
/* 765 */     int i = 0;
/*     */     try {
/* 767 */       for (int len = props.length; i < len; i++) {
/* 768 */         BeanPropertyWriter prop = props[i];
/* 769 */         if (prop != null) {
/* 770 */           prop.serializeAsField(bean, gen, provider);
/*     */         }
/*     */       }
/* 773 */       if (this._anyGetterWriter != null) {
/* 774 */         this._anyGetterWriter.getAndSerialize(bean, gen, provider);
/*     */       }
/*     */     } catch (Exception e) {
/* 777 */       String name = i == props.length ? "[anySetter]" : props[i].getName();
/* 778 */       wrapAndThrow(provider, e, bean, name);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (StackOverflowError e)
/*     */     {
/*     */ 
/* 785 */       JsonMappingException mapE = new JsonMappingException(gen, "Infinite recursion (StackOverflowError)", e);
/*     */       
/* 787 */       String name = i == props.length ? "[anySetter]" : props[i].getName();
/* 788 */       mapE.prependPath(new JsonMappingException.Reference(bean, name));
/* 789 */       throw mapE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void serializeFieldsFiltered(Object bean, JsonGenerator gen, SerializerProvider provider)
/*     */     throws IOException, com.fasterxml.jackson.core.JsonGenerationException
/*     */   {
/*     */     BeanPropertyWriter[] props;
/*     */     
/*     */ 
/*     */ 
/*     */     BeanPropertyWriter[] props;
/*     */     
/*     */ 
/* 806 */     if ((this._filteredProps != null) && (provider.getActiveView() != null)) {
/* 807 */       props = this._filteredProps;
/*     */     } else {
/* 809 */       props = this._props;
/*     */     }
/* 811 */     PropertyFilter filter = findPropertyFilter(provider, this._propertyFilterId, bean);
/*     */     
/* 813 */     if (filter == null) {
/* 814 */       serializeFields(bean, gen, provider);
/* 815 */       return;
/*     */     }
/* 817 */     int i = 0;
/*     */     try {
/* 819 */       for (int len = props.length; i < len; i++) {
/* 820 */         BeanPropertyWriter prop = props[i];
/* 821 */         if (prop != null) {
/* 822 */           filter.serializeAsField(bean, gen, provider, prop);
/*     */         }
/*     */       }
/* 825 */       if (this._anyGetterWriter != null) {
/* 826 */         this._anyGetterWriter.getAndFilter(bean, gen, provider, filter);
/*     */       }
/*     */     } catch (Exception e) {
/* 829 */       String name = i == props.length ? "[anySetter]" : props[i].getName();
/* 830 */       wrapAndThrow(provider, e, bean, name);
/*     */     }
/*     */     catch (StackOverflowError e)
/*     */     {
/* 834 */       JsonMappingException mapE = new JsonMappingException(gen, "Infinite recursion (StackOverflowError)", e);
/* 835 */       String name = i == props.length ? "[anySetter]" : props[i].getName();
/* 836 */       mapE.prependPath(new JsonMappingException.Reference(bean, name));
/* 837 */       throw mapE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @Deprecated
/*     */   public com.fasterxml.jackson.databind.JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 846 */     ObjectNode o = createSchemaNode("object", true);
/*     */     
/*     */ 
/* 849 */     JsonSerializableSchema ann = (JsonSerializableSchema)this._handledType.getAnnotation(JsonSerializableSchema.class);
/* 850 */     if (ann != null) {
/* 851 */       String id = ann.id();
/* 852 */       if ((id != null) && (!id.isEmpty())) {
/* 853 */         o.put("id", id);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 859 */     ObjectNode propertiesNode = o.objectNode();
/*     */     PropertyFilter filter;
/* 861 */     PropertyFilter filter; if (this._propertyFilterId != null) {
/* 862 */       filter = findPropertyFilter(provider, this._propertyFilterId, null);
/*     */     } else {
/* 864 */       filter = null;
/*     */     }
/*     */     
/* 867 */     for (int i = 0; i < this._props.length; i++) {
/* 868 */       BeanPropertyWriter prop = this._props[i];
/* 869 */       if (filter == null) {
/* 870 */         prop.depositSchemaProperty(propertiesNode, provider);
/*     */       } else {
/* 872 */         filter.depositSchemaProperty(prop, propertiesNode, provider);
/*     */       }
/*     */     }
/*     */     
/* 876 */     o.set("properties", propertiesNode);
/* 877 */     return o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 885 */     if (visitor == null) {
/* 886 */       return;
/*     */     }
/* 888 */     com.fasterxml.jackson.databind.jsonFormatVisitors.JsonObjectFormatVisitor objectVisitor = visitor.expectObjectFormat(typeHint);
/* 889 */     if (objectVisitor == null) {
/* 890 */       return;
/*     */     }
/* 892 */     SerializerProvider provider = visitor.getProvider();
/* 893 */     if (this._propertyFilterId != null) {
/* 894 */       PropertyFilter filter = findPropertyFilter(visitor.getProvider(), this._propertyFilterId, null);
/*     */       
/* 896 */       int i = 0; for (int end = this._props.length; i < end; i++) {
/* 897 */         filter.depositSchemaProperty(this._props[i], objectVisitor, provider);
/*     */       }
/*     */     }
/*     */     else {
/* 901 */       Class<?> view = (this._filteredProps == null) || (provider == null) ? null : provider.getActiveView();
/*     */       BeanPropertyWriter[] props;
/* 903 */       BeanPropertyWriter[] props; if (view != null) {
/* 904 */         props = this._filteredProps;
/*     */       } else {
/* 906 */         props = this._props;
/*     */       }
/*     */       
/* 909 */       int i = 0; for (int end = props.length; i < end; i++) {
/* 910 */         BeanPropertyWriter prop = props[i];
/* 911 */         if (prop != null) {
/* 912 */           prop.depositSchemaProperty(objectVisitor, provider);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-databind-2.12.5.jar!\com\fasterxml\jackson\databind\ser\std\BeanSerializerBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */