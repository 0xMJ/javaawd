/*    */ package org.apache.commons.logging.impl;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class SimpleLog
/*    */   extends NoOpLog
/*    */ {
/*    */   public SimpleLog(String name)
/*    */   {
/* 35 */     super(name);
/* 36 */     System.out.println(SimpleLog.class.getName() + " is deprecated and equivalent to NoOpLog in spring-jcl. Use a standard LogFactory.getLog(Class/String) call instead.");
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-jcl-5.3.12.jar!\org\apache\commons\logging\impl\SimpleLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */