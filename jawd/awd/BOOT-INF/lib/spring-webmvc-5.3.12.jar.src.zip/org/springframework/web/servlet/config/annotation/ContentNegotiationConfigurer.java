/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.accept.ContentNegotiationManagerFactoryBean;
/*     */ import org.springframework.web.accept.ContentNegotiationStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentNegotiationConfigurer
/*     */ {
/*  99 */   private final ContentNegotiationManagerFactoryBean factory = new ContentNegotiationManagerFactoryBean();
/*     */   
/* 101 */   private final Map<String, MediaType> mediaTypes = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer(@Nullable ServletContext servletContext)
/*     */   {
/* 108 */     if (servletContext != null) {
/* 109 */       this.factory.setServletContext(servletContext);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void strategies(@Nullable List<ContentNegotiationStrategy> strategies)
/*     */   {
/* 123 */     this.factory.setStrategies(strategies);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer favorParameter(boolean favorParameter)
/*     */   {
/* 134 */     this.factory.setFavorParameter(favorParameter);
/* 135 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer parameterName(String parameterName)
/*     */   {
/* 143 */     this.factory.setParameterName(parameterName);
/* 144 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public ContentNegotiationConfigurer favorPathExtension(boolean favorPathExtension)
/*     */   {
/* 157 */     this.factory.setFavorPathExtension(favorPathExtension);
/* 158 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer mediaType(String extension, MediaType mediaType)
/*     */   {
/* 177 */     this.mediaTypes.put(extension, mediaType);
/* 178 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer mediaTypes(@Nullable Map<String, MediaType> mediaTypes)
/*     */   {
/* 187 */     if (mediaTypes != null) {
/* 188 */       this.mediaTypes.putAll(mediaTypes);
/*     */     }
/* 190 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer replaceMediaTypes(Map<String, MediaType> mediaTypes)
/*     */   {
/* 199 */     this.mediaTypes.clear();
/* 200 */     mediaTypes(mediaTypes);
/* 201 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public ContentNegotiationConfigurer ignoreUnknownPathExtensions(boolean ignore)
/*     */   {
/* 214 */     this.factory.setIgnoreUnknownPathExtensions(ignore);
/* 215 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public ContentNegotiationConfigurer useJaf(boolean useJaf)
/*     */   {
/* 227 */     return useRegisteredExtensionsOnly(!useJaf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer useRegisteredExtensionsOnly(boolean useRegisteredExtensionsOnly)
/*     */   {
/* 238 */     this.factory.setUseRegisteredExtensionsOnly(useRegisteredExtensionsOnly);
/* 239 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer ignoreAcceptHeader(boolean ignoreAcceptHeader)
/*     */   {
/* 247 */     this.factory.setIgnoreAcceptHeader(ignoreAcceptHeader);
/* 248 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer defaultContentType(MediaType... defaultContentTypes)
/*     */   {
/* 260 */     this.factory.setDefaultContentTypes(Arrays.asList(defaultContentTypes));
/* 261 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentNegotiationConfigurer defaultContentTypeStrategy(ContentNegotiationStrategy defaultStrategy)
/*     */   {
/* 272 */     this.factory.setDefaultContentTypeStrategy(defaultStrategy);
/* 273 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ContentNegotiationManager buildContentNegotiationManager()
/*     */   {
/* 283 */     this.factory.addMediaTypes(this.mediaTypes);
/* 284 */     return this.factory.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\annotation\ContentNegotiationConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */