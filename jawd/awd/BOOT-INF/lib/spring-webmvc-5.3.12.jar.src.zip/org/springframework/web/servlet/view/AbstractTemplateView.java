/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTemplateView
/*     */   extends AbstractUrlBasedView
/*     */ {
/*     */   public static final String SPRING_MACRO_REQUEST_CONTEXT_ATTRIBUTE = "springMacroRequestContext";
/*  55 */   private boolean exposeRequestAttributes = false;
/*     */   
/*  57 */   private boolean allowRequestOverride = false;
/*     */   
/*  59 */   private boolean exposeSessionAttributes = false;
/*     */   
/*  61 */   private boolean allowSessionOverride = false;
/*     */   
/*  63 */   private boolean exposeSpringMacroHelpers = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExposeRequestAttributes(boolean exposeRequestAttributes)
/*     */   {
/*  71 */     this.exposeRequestAttributes = exposeRequestAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowRequestOverride(boolean allowRequestOverride)
/*     */   {
/*  81 */     this.allowRequestOverride = allowRequestOverride;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExposeSessionAttributes(boolean exposeSessionAttributes)
/*     */   {
/*  89 */     this.exposeSessionAttributes = exposeSessionAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowSessionOverride(boolean allowSessionOverride)
/*     */   {
/*  99 */     this.allowSessionOverride = allowSessionOverride;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExposeSpringMacroHelpers(boolean exposeSpringMacroHelpers)
/*     */   {
/* 111 */     this.exposeSpringMacroHelpers = exposeSpringMacroHelpers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 119 */     if (this.exposeRequestAttributes) {
/* 120 */       Map<String, Object> exposed = null;
/* 121 */       for (Enumeration<String> en = request.getAttributeNames(); en.hasMoreElements();) {
/* 122 */         String attribute = (String)en.nextElement();
/* 123 */         if ((model.containsKey(attribute)) && (!this.allowRequestOverride)) {
/* 124 */           throw new ServletException("Cannot expose request attribute '" + attribute + "' because of an existing model object of the same name");
/*     */         }
/*     */         
/* 127 */         Object attributeValue = request.getAttribute(attribute);
/* 128 */         if (this.logger.isDebugEnabled()) {
/* 129 */           exposed = exposed != null ? exposed : new LinkedHashMap();
/* 130 */           exposed.put(attribute, attributeValue);
/*     */         }
/* 132 */         model.put(attribute, attributeValue);
/*     */       }
/* 134 */       if ((this.logger.isTraceEnabled()) && (exposed != null)) {
/* 135 */         this.logger.trace("Exposed request attributes to model: " + exposed);
/*     */       }
/*     */     }
/*     */     
/* 139 */     if (this.exposeSessionAttributes) {
/* 140 */       HttpSession session = request.getSession(false);
/* 141 */       if (session != null) {
/* 142 */         Map<String, Object> exposed = null;
/* 143 */         for (Enumeration<String> en = session.getAttributeNames(); en.hasMoreElements();) {
/* 144 */           String attribute = (String)en.nextElement();
/* 145 */           if ((model.containsKey(attribute)) && (!this.allowSessionOverride)) {
/* 146 */             throw new ServletException("Cannot expose session attribute '" + attribute + "' because of an existing model object of the same name");
/*     */           }
/*     */           
/* 149 */           Object attributeValue = session.getAttribute(attribute);
/* 150 */           if (this.logger.isDebugEnabled()) {
/* 151 */             exposed = exposed != null ? exposed : new LinkedHashMap();
/* 152 */             exposed.put(attribute, attributeValue);
/*     */           }
/* 154 */           model.put(attribute, attributeValue);
/*     */         }
/* 156 */         if ((this.logger.isTraceEnabled()) && (exposed != null)) {
/* 157 */           this.logger.trace("Exposed session attributes to model: " + exposed);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 162 */     if (this.exposeSpringMacroHelpers) {
/* 163 */       if (model.containsKey("springMacroRequestContext")) {
/* 164 */         throw new ServletException("Cannot expose bind macro helper 'springMacroRequestContext' because of an existing model object of the same name");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 169 */       model.put("springMacroRequestContext", new RequestContext(request, response, 
/* 170 */         getServletContext(), model));
/*     */     }
/*     */     
/* 173 */     applyContentType(response);
/*     */     
/* 175 */     if (this.logger.isDebugEnabled()) {
/* 176 */       this.logger.debug("Rendering [" + getUrl() + "]");
/*     */     }
/*     */     
/* 179 */     renderMergedTemplateModel(model, request, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void applyContentType(HttpServletResponse response)
/*     */   {
/* 192 */     if (response.getContentType() == null) {
/* 193 */       response.setContentType(getContentType());
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void renderMergedTemplateModel(Map<String, Object> paramMap, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*     */     throws Exception;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\AbstractTemplateView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */