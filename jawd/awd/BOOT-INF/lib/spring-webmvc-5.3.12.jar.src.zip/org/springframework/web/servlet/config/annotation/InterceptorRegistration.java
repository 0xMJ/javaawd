/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.handler.MappedInterceptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterceptorRegistration
/*     */ {
/*     */   private final HandlerInterceptor interceptor;
/*     */   @Nullable
/*     */   private List<String> includePatterns;
/*     */   @Nullable
/*     */   private List<String> excludePatterns;
/*     */   @Nullable
/*     */   private PathMatcher pathMatcher;
/*  53 */   private int order = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InterceptorRegistration(HandlerInterceptor interceptor)
/*     */   {
/*  60 */     Assert.notNull(interceptor, "Interceptor is required");
/*  61 */     this.interceptor = interceptor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InterceptorRegistration addPathPatterns(String... patterns)
/*     */   {
/*  73 */     return addPathPatterns(Arrays.asList(patterns));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InterceptorRegistration addPathPatterns(List<String> patterns)
/*     */   {
/*  82 */     this.includePatterns = (this.includePatterns != null ? this.includePatterns : new ArrayList(patterns.size()));
/*  83 */     this.includePatterns.addAll(patterns);
/*  84 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InterceptorRegistration excludePathPatterns(String... patterns)
/*     */   {
/*  95 */     return excludePathPatterns(Arrays.asList(patterns));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InterceptorRegistration excludePathPatterns(List<String> patterns)
/*     */   {
/* 104 */     this.excludePatterns = (this.excludePatterns != null ? this.excludePatterns : new ArrayList(patterns.size()));
/* 105 */     this.excludePatterns.addAll(patterns);
/* 106 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InterceptorRegistration pathMatcher(PathMatcher pathMatcher)
/*     */   {
/* 121 */     this.pathMatcher = pathMatcher;
/* 122 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InterceptorRegistration order(int order)
/*     */   {
/* 130 */     this.order = order;
/* 131 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int getOrder()
/*     */   {
/* 138 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getInterceptor()
/*     */   {
/* 147 */     if ((this.includePatterns == null) && (this.excludePatterns == null)) {
/* 148 */       return this.interceptor;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 153 */     MappedInterceptor mappedInterceptor = new MappedInterceptor(StringUtils.toStringArray(this.includePatterns), StringUtils.toStringArray(this.excludePatterns), this.interceptor);
/*     */     
/*     */ 
/* 156 */     if (this.pathMatcher != null) {
/* 157 */       mappedInterceptor.setPathMatcher(this.pathMatcher);
/*     */     }
/*     */     
/* 160 */     return mappedInterceptor;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\annotation\InterceptorRegistration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */