/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleMappingExceptionResolver
/*     */   extends AbstractHandlerExceptionResolver
/*     */ {
/*     */   public static final String DEFAULT_EXCEPTION_ATTRIBUTE = "exception";
/*     */   @Nullable
/*     */   private Properties exceptionMappings;
/*     */   @Nullable
/*     */   private Class<?>[] excludedExceptions;
/*     */   @Nullable
/*     */   private String defaultErrorView;
/*     */   @Nullable
/*     */   private Integer defaultStatusCode;
/*  64 */   private Map<String, Integer> statusCodes = new HashMap();
/*     */   @Nullable
/*  66 */   private String exceptionAttribute = "exception";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExceptionMappings(Properties mappings)
/*     */   {
/*  85 */     this.exceptionMappings = mappings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExcludedExceptions(Class<?>... excludedExceptions)
/*     */   {
/*  95 */     this.excludedExceptions = excludedExceptions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultErrorView(String defaultErrorView)
/*     */   {
/* 104 */     this.defaultErrorView = defaultErrorView;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatusCodes(Properties statusCodes)
/*     */   {
/* 117 */     for (Enumeration<?> enumeration = statusCodes.propertyNames(); enumeration.hasMoreElements();) {
/* 118 */       String viewName = (String)enumeration.nextElement();
/* 119 */       Integer statusCode = Integer.valueOf(statusCodes.getProperty(viewName));
/* 120 */       this.statusCodes.put(viewName, statusCode);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addStatusCode(String viewName, int statusCode)
/*     */   {
/* 129 */     this.statusCodes.put(viewName, Integer.valueOf(statusCode));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Integer> getStatusCodesAsMap()
/*     */   {
/* 137 */     return Collections.unmodifiableMap(this.statusCodes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultStatusCode(int defaultStatusCode)
/*     */   {
/* 153 */     this.defaultStatusCode = Integer.valueOf(defaultStatusCode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExceptionAttribute(@Nullable String exceptionAttribute)
/*     */   {
/* 164 */     this.exceptionAttribute = exceptionAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, @Nullable Object handler, Exception ex)
/*     */   {
/* 189 */     String viewName = determineViewName(ex, request);
/* 190 */     if (viewName != null)
/*     */     {
/*     */ 
/* 193 */       Integer statusCode = determineStatusCode(request, viewName);
/* 194 */       if (statusCode != null) {
/* 195 */         applyStatusCodeIfPossible(request, response, statusCode.intValue());
/*     */       }
/* 197 */       return getModelAndView(viewName, ex, request);
/*     */     }
/*     */     
/* 200 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String determineViewName(Exception ex, HttpServletRequest request)
/*     */   {
/* 215 */     String viewName = null;
/* 216 */     if (this.excludedExceptions != null) {
/* 217 */       for (Class<?> excludedEx : this.excludedExceptions) {
/* 218 */         if (excludedEx.equals(ex.getClass())) {
/* 219 */           return null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 224 */     if (this.exceptionMappings != null) {
/* 225 */       viewName = findMatchingViewName(this.exceptionMappings, ex);
/*     */     }
/*     */     
/* 228 */     if ((viewName == null) && (this.defaultErrorView != null)) {
/* 229 */       if (this.logger.isDebugEnabled()) {
/* 230 */         this.logger.debug("Resolving to default view '" + this.defaultErrorView + "'");
/*     */       }
/* 232 */       viewName = this.defaultErrorView;
/*     */     }
/* 234 */     return viewName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String findMatchingViewName(Properties exceptionMappings, Exception ex)
/*     */   {
/* 246 */     String viewName = null;
/* 247 */     String dominantMapping = null;
/* 248 */     int deepest = Integer.MAX_VALUE;
/* 249 */     for (Enumeration<?> names = exceptionMappings.propertyNames(); names.hasMoreElements();) {
/* 250 */       String exceptionMapping = (String)names.nextElement();
/* 251 */       int depth = getDepth(exceptionMapping, ex);
/* 252 */       if ((depth >= 0) && ((depth < deepest) || ((depth == deepest) && (dominantMapping != null) && 
/* 253 */         (exceptionMapping.length() > dominantMapping.length())))) {
/* 254 */         deepest = depth;
/* 255 */         dominantMapping = exceptionMapping;
/* 256 */         viewName = exceptionMappings.getProperty(exceptionMapping);
/*     */       }
/*     */     }
/* 259 */     if ((viewName != null) && (this.logger.isDebugEnabled())) {
/* 260 */       this.logger.debug("Resolving to view '" + viewName + "' based on mapping [" + dominantMapping + "]");
/*     */     }
/* 262 */     return viewName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getDepth(String exceptionMapping, Exception ex)
/*     */   {
/* 271 */     return getDepth(exceptionMapping, ex.getClass(), 0);
/*     */   }
/*     */   
/*     */   private int getDepth(String exceptionMapping, Class<?> exceptionClass, int depth) {
/* 275 */     if (exceptionClass.getName().contains(exceptionMapping))
/*     */     {
/* 277 */       return depth;
/*     */     }
/*     */     
/* 280 */     if (exceptionClass == Throwable.class) {
/* 281 */       return -1;
/*     */     }
/* 283 */     return getDepth(exceptionMapping, exceptionClass.getSuperclass(), depth + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Integer determineStatusCode(HttpServletRequest request, String viewName)
/*     */   {
/* 301 */     if (this.statusCodes.containsKey(viewName)) {
/* 302 */       return (Integer)this.statusCodes.get(viewName);
/*     */     }
/* 304 */     return this.defaultStatusCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void applyStatusCodeIfPossible(HttpServletRequest request, HttpServletResponse response, int statusCode)
/*     */   {
/* 318 */     if (!WebUtils.isIncludeRequest(request)) {
/* 319 */       if (this.logger.isDebugEnabled()) {
/* 320 */         this.logger.debug("Applying HTTP status " + statusCode);
/*     */       }
/* 322 */       response.setStatus(statusCode);
/* 323 */       request.setAttribute("javax.servlet.error.status_code", Integer.valueOf(statusCode));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView getModelAndView(String viewName, Exception ex, HttpServletRequest request)
/*     */   {
/* 336 */     return getModelAndView(viewName, ex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView getModelAndView(String viewName, Exception ex)
/*     */   {
/* 349 */     ModelAndView mv = new ModelAndView(viewName);
/* 350 */     if (this.exceptionAttribute != null) {
/* 351 */       mv.addObject(this.exceptionAttribute, ex);
/*     */     }
/* 353 */     return mv;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\handler\SimpleMappingExceptionResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */