/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.core.SpringProperties;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.method.ControllerAdviceBean;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.method.annotation.ExceptionHandlerMethodResolver;
/*     */ import org.springframework.web.method.annotation.MapMethodProcessor;
/*     */ import org.springframework.web.method.annotation.ModelMethodProcessor;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolverComposite;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.FlashMap;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.handler.AbstractHandlerMethodExceptionResolver;
/*     */ import org.springframework.web.servlet.mvc.support.RedirectAttributes;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionHandlerExceptionResolver
/*     */   extends AbstractHandlerMethodExceptionResolver
/*     */   implements ApplicationContextAware, InitializingBean
/*     */ {
/*  85 */   private static final boolean shouldIgnoreXml = SpringProperties.getFlag("spring.xml.ignore");
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private List<HandlerMethodArgumentResolver> customArgumentResolvers;
/*     */   
/*     */   @Nullable
/*     */   private HandlerMethodArgumentResolverComposite argumentResolvers;
/*     */   
/*     */   @Nullable
/*     */   private List<HandlerMethodReturnValueHandler> customReturnValueHandlers;
/*     */   
/*     */   @Nullable
/*     */   private HandlerMethodReturnValueHandlerComposite returnValueHandlers;
/*     */   
/*     */   private List<HttpMessageConverter<?>> messageConverters;
/*     */   
/* 102 */   private ContentNegotiationManager contentNegotiationManager = new ContentNegotiationManager();
/*     */   
/* 104 */   private final List<Object> responseBodyAdvice = new ArrayList();
/*     */   
/*     */   @Nullable
/*     */   private ApplicationContext applicationContext;
/*     */   
/* 109 */   private final Map<Class<?>, ExceptionHandlerMethodResolver> exceptionHandlerCache = new ConcurrentHashMap(64);
/*     */   
/*     */ 
/* 112 */   private final Map<ControllerAdviceBean, ExceptionHandlerMethodResolver> exceptionHandlerAdviceCache = new LinkedHashMap();
/*     */   
/*     */ 
/*     */   public ExceptionHandlerExceptionResolver()
/*     */   {
/* 117 */     this.messageConverters = new ArrayList();
/* 118 */     this.messageConverters.add(new ByteArrayHttpMessageConverter());
/* 119 */     this.messageConverters.add(new StringHttpMessageConverter());
/* 120 */     if (!shouldIgnoreXml) {
/*     */       try {
/* 122 */         this.messageConverters.add(new SourceHttpMessageConverter());
/*     */       }
/*     */       catch (Error localError) {}
/*     */     }
/*     */     
/*     */ 
/* 128 */     this.messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCustomArgumentResolvers(@Nullable List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/* 138 */     this.customArgumentResolvers = argumentResolvers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public List<HandlerMethodArgumentResolver> getCustomArgumentResolvers()
/*     */   {
/* 146 */     return this.customArgumentResolvers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setArgumentResolvers(@Nullable List<HandlerMethodArgumentResolver> argumentResolvers)
/*     */   {
/* 154 */     if (argumentResolvers == null) {
/* 155 */       this.argumentResolvers = null;
/*     */     }
/*     */     else {
/* 158 */       this.argumentResolvers = new HandlerMethodArgumentResolverComposite();
/* 159 */       this.argumentResolvers.addResolvers(argumentResolvers);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public HandlerMethodArgumentResolverComposite getArgumentResolvers()
/*     */   {
/* 169 */     return this.argumentResolvers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCustomReturnValueHandlers(@Nullable List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/* 178 */     this.customReturnValueHandlers = returnValueHandlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public List<HandlerMethodReturnValueHandler> getCustomReturnValueHandlers()
/*     */   {
/* 186 */     return this.customReturnValueHandlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReturnValueHandlers(@Nullable List<HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/* 194 */     if (returnValueHandlers == null) {
/* 195 */       this.returnValueHandlers = null;
/*     */     }
/*     */     else {
/* 198 */       this.returnValueHandlers = new HandlerMethodReturnValueHandlerComposite();
/* 199 */       this.returnValueHandlers.addHandlers(returnValueHandlers);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public HandlerMethodReturnValueHandlerComposite getReturnValueHandlers()
/*     */   {
/* 209 */     return this.returnValueHandlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 217 */     this.messageConverters = messageConverters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 224 */     return this.messageConverters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager)
/*     */   {
/* 232 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ContentNegotiationManager getContentNegotiationManager()
/*     */   {
/* 239 */     return this.contentNegotiationManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResponseBodyAdvice(@Nullable List<ResponseBodyAdvice<?>> responseBodyAdvice)
/*     */   {
/* 249 */     if (responseBodyAdvice != null) {
/* 250 */       this.responseBodyAdvice.addAll(responseBodyAdvice);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setApplicationContext(@Nullable ApplicationContext applicationContext)
/*     */   {
/* 256 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public ApplicationContext getApplicationContext() {
/* 261 */     return this.applicationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 268 */     initExceptionHandlerAdviceCache();
/*     */     
/* 270 */     if (this.argumentResolvers == null) {
/* 271 */       List<HandlerMethodArgumentResolver> resolvers = getDefaultArgumentResolvers();
/* 272 */       this.argumentResolvers = new HandlerMethodArgumentResolverComposite().addResolvers(resolvers);
/*     */     }
/* 274 */     if (this.returnValueHandlers == null) {
/* 275 */       List<HandlerMethodReturnValueHandler> handlers = getDefaultReturnValueHandlers();
/* 276 */       this.returnValueHandlers = new HandlerMethodReturnValueHandlerComposite().addHandlers(handlers);
/*     */     }
/*     */   }
/*     */   
/*     */   private void initExceptionHandlerAdviceCache() {
/* 281 */     if (getApplicationContext() == null) {
/* 282 */       return;
/*     */     }
/*     */     
/* 285 */     List<ControllerAdviceBean> adviceBeans = ControllerAdviceBean.findAnnotatedBeans(getApplicationContext());
/* 286 */     for (ControllerAdviceBean adviceBean : adviceBeans) {
/* 287 */       Class<?> beanType = adviceBean.getBeanType();
/* 288 */       if (beanType == null) {
/* 289 */         throw new IllegalStateException("Unresolvable type for ControllerAdviceBean: " + adviceBean);
/*     */       }
/* 291 */       ExceptionHandlerMethodResolver resolver = new ExceptionHandlerMethodResolver(beanType);
/* 292 */       if (resolver.hasExceptionMappings()) {
/* 293 */         this.exceptionHandlerAdviceCache.put(adviceBean, resolver);
/*     */       }
/* 295 */       if (ResponseBodyAdvice.class.isAssignableFrom(beanType)) {
/* 296 */         this.responseBodyAdvice.add(adviceBean);
/*     */       }
/*     */     }
/*     */     
/* 300 */     if (this.logger.isDebugEnabled()) {
/* 301 */       int handlerSize = this.exceptionHandlerAdviceCache.size();
/* 302 */       int adviceSize = this.responseBodyAdvice.size();
/* 303 */       if ((handlerSize == 0) && (adviceSize == 0)) {
/* 304 */         this.logger.debug("ControllerAdvice beans: none");
/*     */       }
/*     */       else {
/* 307 */         this.logger.debug("ControllerAdvice beans: " + handlerSize + " @ExceptionHandler, " + adviceSize + " ResponseBodyAdvice");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<ControllerAdviceBean, ExceptionHandlerMethodResolver> getExceptionHandlerAdviceCache()
/*     */   {
/* 320 */     return Collections.unmodifiableMap(this.exceptionHandlerAdviceCache);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<HandlerMethodArgumentResolver> getDefaultArgumentResolvers()
/*     */   {
/* 328 */     List<HandlerMethodArgumentResolver> resolvers = new ArrayList();
/*     */     
/*     */ 
/* 331 */     resolvers.add(new SessionAttributeMethodArgumentResolver());
/* 332 */     resolvers.add(new RequestAttributeMethodArgumentResolver());
/*     */     
/*     */ 
/* 335 */     resolvers.add(new ServletRequestMethodArgumentResolver());
/* 336 */     resolvers.add(new ServletResponseMethodArgumentResolver());
/* 337 */     resolvers.add(new RedirectAttributesMethodArgumentResolver());
/* 338 */     resolvers.add(new ModelMethodProcessor());
/*     */     
/*     */ 
/* 341 */     if (getCustomArgumentResolvers() != null) {
/* 342 */       resolvers.addAll(getCustomArgumentResolvers());
/*     */     }
/*     */     
/*     */ 
/* 346 */     resolvers.add(new PrincipalMethodArgumentResolver());
/*     */     
/* 348 */     return resolvers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<HandlerMethodReturnValueHandler> getDefaultReturnValueHandlers()
/*     */   {
/* 356 */     List<HandlerMethodReturnValueHandler> handlers = new ArrayList();
/*     */     
/*     */ 
/* 359 */     handlers.add(new ModelAndViewMethodReturnValueHandler());
/* 360 */     handlers.add(new ModelMethodProcessor());
/* 361 */     handlers.add(new ViewMethodReturnValueHandler());
/* 362 */     handlers.add(new HttpEntityMethodProcessor(
/* 363 */       getMessageConverters(), this.contentNegotiationManager, this.responseBodyAdvice));
/*     */     
/*     */ 
/* 366 */     handlers.add(new ServletModelAttributeMethodProcessor(false));
/* 367 */     handlers.add(new RequestResponseBodyMethodProcessor(
/* 368 */       getMessageConverters(), this.contentNegotiationManager, this.responseBodyAdvice));
/*     */     
/*     */ 
/* 371 */     handlers.add(new ViewNameMethodReturnValueHandler());
/* 372 */     handlers.add(new MapMethodProcessor());
/*     */     
/*     */ 
/* 375 */     if (getCustomReturnValueHandlers() != null) {
/* 376 */       handlers.addAll(getCustomReturnValueHandlers());
/*     */     }
/*     */     
/*     */ 
/* 380 */     handlers.add(new ServletModelAttributeMethodProcessor(true));
/*     */     
/* 382 */     return handlers;
/*     */   }
/*     */   
/*     */   protected boolean hasGlobalExceptionHandlers()
/*     */   {
/* 387 */     return !this.exceptionHandlerAdviceCache.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected ModelAndView doResolveHandlerMethodException(HttpServletRequest request, HttpServletResponse response, @Nullable HandlerMethod handlerMethod, Exception exception)
/*     */   {
/* 398 */     ServletInvocableHandlerMethod exceptionHandlerMethod = getExceptionHandlerMethod(handlerMethod, exception);
/* 399 */     if (exceptionHandlerMethod == null) {
/* 400 */       return null;
/*     */     }
/*     */     
/* 403 */     if (this.argumentResolvers != null) {
/* 404 */       exceptionHandlerMethod.setHandlerMethodArgumentResolvers(this.argumentResolvers);
/*     */     }
/* 406 */     if (this.returnValueHandlers != null) {
/* 407 */       exceptionHandlerMethod.setHandlerMethodReturnValueHandlers(this.returnValueHandlers);
/*     */     }
/*     */     
/* 410 */     ServletWebRequest webRequest = new ServletWebRequest(request, response);
/* 411 */     ModelAndViewContainer mavContainer = new ModelAndViewContainer();
/*     */     
/* 413 */     ArrayList<Throwable> exceptions = new ArrayList();
/*     */     try {
/* 415 */       if (this.logger.isDebugEnabled()) {
/* 416 */         this.logger.debug("Using @ExceptionHandler " + exceptionHandlerMethod);
/*     */       }
/*     */       
/* 419 */       Throwable exToExpose = exception;
/* 420 */       while (exToExpose != null) {
/* 421 */         exceptions.add(exToExpose);
/* 422 */         Throwable cause = exToExpose.getCause();
/* 423 */         exToExpose = cause != exToExpose ? cause : null;
/*     */       }
/* 425 */       Object[] arguments = new Object[exceptions.size() + 1];
/* 426 */       exceptions.toArray(arguments);
/* 427 */       arguments[(arguments.length - 1)] = handlerMethod;
/* 428 */       exceptionHandlerMethod.invokeAndHandle(webRequest, mavContainer, arguments);
/*     */ 
/*     */     }
/*     */     catch (Throwable invocationEx)
/*     */     {
/* 433 */       if ((!exceptions.contains(invocationEx)) && (this.logger.isWarnEnabled())) {
/* 434 */         this.logger.warn("Failure in @ExceptionHandler " + exceptionHandlerMethod, invocationEx);
/*     */       }
/*     */       
/* 437 */       return null;
/*     */     }
/*     */     
/* 440 */     if (mavContainer.isRequestHandled()) {
/* 441 */       return new ModelAndView();
/*     */     }
/*     */     
/* 444 */     ModelMap model = mavContainer.getModel();
/* 445 */     HttpStatus status = mavContainer.getStatus();
/* 446 */     ModelAndView mav = new ModelAndView(mavContainer.getViewName(), model, status);
/* 447 */     mav.setViewName(mavContainer.getViewName());
/* 448 */     if (!mavContainer.isViewReference()) {
/* 449 */       mav.setView((View)mavContainer.getView());
/*     */     }
/* 451 */     if ((model instanceof RedirectAttributes)) {
/* 452 */       Map<String, ?> flashAttributes = ((RedirectAttributes)model).getFlashAttributes();
/* 453 */       RequestContextUtils.getOutputFlashMap(request).putAll(flashAttributes);
/*     */     }
/* 455 */     return mav;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected ServletInvocableHandlerMethod getExceptionHandlerMethod(@Nullable HandlerMethod handlerMethod, Exception exception)
/*     */   {
/* 473 */     Class<?> handlerType = null;
/*     */     ExceptionHandlerMethodResolver resolver;
/* 475 */     if (handlerMethod != null)
/*     */     {
/*     */ 
/* 478 */       handlerType = handlerMethod.getBeanType();
/* 479 */       resolver = (ExceptionHandlerMethodResolver)this.exceptionHandlerCache.get(handlerType);
/* 480 */       if (resolver == null) {
/* 481 */         resolver = new ExceptionHandlerMethodResolver(handlerType);
/* 482 */         this.exceptionHandlerCache.put(handlerType, resolver);
/*     */       }
/* 484 */       Method method = resolver.resolveMethod(exception);
/* 485 */       if (method != null) {
/* 486 */         return new ServletInvocableHandlerMethod(handlerMethod.getBean(), method, this.applicationContext);
/*     */       }
/*     */       
/*     */ 
/* 490 */       if (Proxy.isProxyClass(handlerType)) {
/* 491 */         handlerType = AopUtils.getTargetClass(handlerMethod.getBean());
/*     */       }
/*     */     }
/*     */     
/* 495 */     for (Map.Entry<ControllerAdviceBean, ExceptionHandlerMethodResolver> entry : this.exceptionHandlerAdviceCache.entrySet()) {
/* 496 */       ControllerAdviceBean advice = (ControllerAdviceBean)entry.getKey();
/* 497 */       if (advice.isApplicableToBeanType(handlerType)) {
/* 498 */         ExceptionHandlerMethodResolver resolver = (ExceptionHandlerMethodResolver)entry.getValue();
/* 499 */         Method method = resolver.resolveMethod(exception);
/* 500 */         if (method != null) {
/* 501 */           return new ServletInvocableHandlerMethod(advice.resolveBean(), method, this.applicationContext);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 506 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ExceptionHandlerExceptionResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */