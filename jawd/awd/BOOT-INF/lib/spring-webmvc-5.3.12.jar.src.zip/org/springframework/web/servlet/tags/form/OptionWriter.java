/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OptionWriter
/*     */ {
/*     */   private final Object optionSource;
/*     */   private final BindStatus bindStatus;
/*     */   @Nullable
/*     */   private final String valueProperty;
/*     */   @Nullable
/*     */   private final String labelProperty;
/*     */   private final boolean htmlEscape;
/*     */   
/*     */   public OptionWriter(Object optionSource, BindStatus bindStatus, @Nullable String valueProperty, @Nullable String labelProperty, boolean htmlEscape)
/*     */   {
/* 118 */     Assert.notNull(optionSource, "'optionSource' must not be null");
/* 119 */     Assert.notNull(bindStatus, "'bindStatus' must not be null");
/* 120 */     this.optionSource = optionSource;
/* 121 */     this.bindStatus = bindStatus;
/* 122 */     this.valueProperty = valueProperty;
/* 123 */     this.labelProperty = labelProperty;
/* 124 */     this.htmlEscape = htmlEscape;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeOptions(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 133 */     if (this.optionSource.getClass().isArray()) {
/* 134 */       renderFromArray(tagWriter);
/*     */     }
/* 136 */     else if ((this.optionSource instanceof Collection)) {
/* 137 */       renderFromCollection(tagWriter);
/*     */     }
/* 139 */     else if ((this.optionSource instanceof Map)) {
/* 140 */       renderFromMap(tagWriter);
/*     */     }
/* 142 */     else if (((this.optionSource instanceof Class)) && (((Class)this.optionSource).isEnum())) {
/* 143 */       renderFromEnum(tagWriter);
/*     */     }
/*     */     else
/*     */     {
/* 147 */       throw new JspException("Type [" + this.optionSource.getClass().getName() + "] is not valid for option items");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void renderFromArray(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 156 */     doRenderFromCollection(CollectionUtils.arrayToList(this.optionSource), tagWriter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void renderFromMap(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 165 */     Map<?, ?> optionMap = (Map)this.optionSource;
/* 166 */     for (Map.Entry<?, ?> entry : optionMap.entrySet()) {
/* 167 */       Object mapKey = entry.getKey();
/* 168 */       Object mapValue = entry.getValue();
/*     */       
/* 170 */       Object renderValue = this.valueProperty != null ? PropertyAccessorFactory.forBeanPropertyAccess(mapKey).getPropertyValue(this.valueProperty) : mapKey;
/*     */       
/*     */ 
/* 173 */       Object renderLabel = this.labelProperty != null ? PropertyAccessorFactory.forBeanPropertyAccess(mapValue).getPropertyValue(this.labelProperty) : mapValue;
/*     */       
/* 175 */       renderOption(tagWriter, mapKey, renderValue, renderLabel);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void renderFromCollection(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 184 */     doRenderFromCollection((Collection)this.optionSource, tagWriter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void renderFromEnum(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 192 */     doRenderFromCollection(CollectionUtils.arrayToList(((Class)this.optionSource).getEnumConstants()), tagWriter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void doRenderFromCollection(Collection<?> optionCollection, TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 202 */     for (Object item : optionCollection) {
/* 203 */       BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(item);
/*     */       Object value;
/* 205 */       Object value; if (this.valueProperty != null) {
/* 206 */         value = wrapper.getPropertyValue(this.valueProperty);
/*     */       } else { Object value;
/* 208 */         if ((item instanceof Enum)) {
/* 209 */           value = ((Enum)item).name();
/*     */         }
/*     */         else
/* 212 */           value = item;
/*     */       }
/* 214 */       Object label = this.labelProperty != null ? wrapper.getPropertyValue(this.labelProperty) : item;
/* 215 */       renderOption(tagWriter, item, value, label);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void renderOption(TagWriter tagWriter, Object item, @Nullable Object value, @Nullable Object label)
/*     */     throws JspException
/*     */   {
/* 226 */     tagWriter.startTag("option");
/* 227 */     writeCommonAttributes(tagWriter);
/*     */     
/* 229 */     String valueDisplayString = getDisplayString(value);
/* 230 */     String labelDisplayString = getDisplayString(label);
/*     */     
/* 232 */     valueDisplayString = processOptionValue(valueDisplayString);
/*     */     
/*     */ 
/* 235 */     tagWriter.writeAttribute("value", valueDisplayString);
/*     */     
/* 237 */     if ((isOptionSelected(value)) || ((value != item) && (isOptionSelected(item)))) {
/* 238 */       tagWriter.writeAttribute("selected", "selected");
/*     */     }
/* 240 */     if (isOptionDisabled()) {
/* 241 */       tagWriter.writeAttribute("disabled", "disabled");
/*     */     }
/* 243 */     tagWriter.appendValue(labelDisplayString);
/* 244 */     tagWriter.endTag();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getDisplayString(@Nullable Object value)
/*     */   {
/* 252 */     PropertyEditor editor = value != null ? this.bindStatus.findEditor(value.getClass()) : null;
/* 253 */     return ValueFormatter.getDisplayString(value, editor, this.htmlEscape);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String processOptionValue(String resolvedValue)
/*     */   {
/* 261 */     return resolvedValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isOptionSelected(@Nullable Object resolvedValue)
/*     */   {
/* 269 */     return SelectedValueComparator.isSelected(this.bindStatus, resolvedValue);
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean isOptionDisabled()
/*     */     throws JspException
/*     */   {
/* 276 */     return false;
/*     */   }
/*     */   
/*     */   protected void writeCommonAttributes(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\form\OptionWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */