/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.tagext.BodyContent;
/*     */ import javax.servlet.jsp.tagext.BodyTag;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.util.JavaScriptUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscapeBodyTag
/*     */   extends HtmlEscapingAwareTag
/*     */   implements BodyTag
/*     */ {
/*  77 */   private boolean javaScriptEscape = false;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private BodyContent bodyContent;
/*     */   
/*     */ 
/*     */ 
/*     */   public void setJavaScriptEscape(boolean javaScriptEscape)
/*     */     throws JspException
/*     */   {
/*  88 */     this.javaScriptEscape = javaScriptEscape;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int doStartTagInternal()
/*     */   {
/*  95 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void doInitBody() {}
/*     */   
/*     */ 
/*     */   public void setBodyContent(BodyContent bodyContent)
/*     */   {
/* 105 */     this.bodyContent = bodyContent;
/*     */   }
/*     */   
/*     */   public int doAfterBody() throws JspException
/*     */   {
/*     */     try {
/* 111 */       String content = readBodyContent();
/*     */       
/* 113 */       content = htmlEscape(content);
/* 114 */       content = this.javaScriptEscape ? JavaScriptUtils.javaScriptEscape(content) : content;
/* 115 */       writeBodyContent(content);
/*     */     }
/*     */     catch (IOException ex) {
/* 118 */       throw new JspException("Could not write escaped body", ex);
/*     */     }
/* 120 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String readBodyContent()
/*     */     throws IOException
/*     */   {
/* 129 */     Assert.state(this.bodyContent != null, "No BodyContent set");
/* 130 */     return this.bodyContent.getString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeBodyContent(String content)
/*     */     throws IOException
/*     */   {
/* 140 */     Assert.state(this.bodyContent != null, "No BodyContent set");
/* 141 */     this.bodyContent.getEnclosingWriter().print(content);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\EscapeBodyTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */