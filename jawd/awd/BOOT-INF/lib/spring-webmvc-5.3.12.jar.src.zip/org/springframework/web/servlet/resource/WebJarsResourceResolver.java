/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.webjars.WebJarAssetLocator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebJarsResourceResolver
/*     */   extends AbstractResourceResolver
/*     */ {
/*     */   private static final String WEBJARS_LOCATION = "META-INF/resources/webjars/";
/*  51 */   private static final int WEBJARS_LOCATION_LENGTH = "META-INF/resources/webjars/".length();
/*     */   
/*     */ 
/*     */ 
/*     */   private final WebJarAssetLocator webJarAssetLocator;
/*     */   
/*     */ 
/*     */ 
/*     */   public WebJarsResourceResolver()
/*     */   {
/*  61 */     this(new WebJarAssetLocator());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebJarsResourceResolver(WebJarAssetLocator webJarAssetLocator)
/*     */   {
/*  70 */     this.webJarAssetLocator = webJarAssetLocator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Resource resolveResourceInternal(@Nullable HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain)
/*     */   {
/*  78 */     Resource resolved = chain.resolveResource(request, requestPath, locations);
/*  79 */     if (resolved == null) {
/*  80 */       String webJarResourcePath = findWebJarResourcePath(requestPath);
/*  81 */       if (webJarResourcePath != null) {
/*  82 */         return chain.resolveResource(request, webJarResourcePath, locations);
/*     */       }
/*     */     }
/*  85 */     return resolved;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String resolveUrlPathInternal(String resourceUrlPath, List<? extends Resource> locations, ResourceResolverChain chain)
/*     */   {
/*  92 */     String path = chain.resolveUrlPath(resourceUrlPath, locations);
/*  93 */     if (path == null) {
/*  94 */       String webJarResourcePath = findWebJarResourcePath(resourceUrlPath);
/*  95 */       if (webJarResourcePath != null) {
/*  96 */         return chain.resolveUrlPath(webJarResourcePath, locations);
/*     */       }
/*     */     }
/*  99 */     return path;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected String findWebJarResourcePath(String path) {
/* 104 */     int startOffset = path.startsWith("/") ? 1 : 0;
/* 105 */     int endOffset = path.indexOf('/', 1);
/* 106 */     if (endOffset != -1) {
/* 107 */       String webjar = path.substring(startOffset, endOffset);
/* 108 */       String partialPath = path.substring(endOffset + 1);
/* 109 */       String webJarPath = this.webJarAssetLocator.getFullPathExact(webjar, partialPath);
/* 110 */       if (webJarPath != null) {
/* 111 */         return webJarPath.substring(WEBJARS_LOCATION_LENGTH);
/*     */       }
/*     */     }
/* 114 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\WebJarsResourceResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */