/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import java.security.Principal;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrincipalMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 43 */     return Principal.class.isAssignableFrom(parameter.getParameterType());
/*    */   }
/*    */   
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, @Nullable ModelAndViewContainer mavContainer, NativeWebRequest webRequest, @Nullable WebDataBinderFactory binderFactory)
/*    */     throws Exception
/*    */   {
/* 50 */     HttpServletRequest request = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 51 */     if (request == null) {
/* 52 */       throw new IllegalStateException("Current request is not of type HttpServletRequest: " + webRequest);
/*    */     }
/*    */     
/* 55 */     Principal principal = request.getUserPrincipal();
/* 56 */     if ((principal != null) && (!parameter.getParameterType().isInstance(principal)))
/*    */     {
/* 58 */       throw new IllegalStateException("Current user principal is not of type [" + parameter.getParameterType().getName() + "]: " + principal);
/*    */     }
/*    */     
/* 61 */     return principal;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\PrincipalMethodArgumentResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */