/*    */ package org.springframework.web.servlet.mvc.condition;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.StringJoiner;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractRequestCondition<T extends AbstractRequestCondition<T>>
/*    */   implements RequestCondition<T>
/*    */ {
/*    */   public boolean isEmpty()
/*    */   {
/* 41 */     return getContent().isEmpty();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected abstract Collection<?> getContent();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected abstract String getToStringInfix();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean equals(@Nullable Object other)
/*    */   {
/* 61 */     if (this == other) {
/* 62 */       return true;
/*    */     }
/* 64 */     if ((other == null) || (getClass() != other.getClass())) {
/* 65 */       return false;
/*    */     }
/* 67 */     return getContent().equals(((AbstractRequestCondition)other).getContent());
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 72 */     return getContent().hashCode();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 77 */     String infix = getToStringInfix();
/* 78 */     StringJoiner joiner = new StringJoiner(infix, "[", "]");
/* 79 */     for (Object expression : getContent()) {
/* 80 */       joiner.add(expression.toString());
/*    */     }
/* 82 */     return joiner.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\condition\AbstractRequestCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */