/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ import org.springframework.web.util.pattern.PathPattern.PathMatchInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestMatchResult
/*     */ {
/*     */   @Nullable
/*     */   private final PathPattern pathPattern;
/*     */   @Nullable
/*     */   private final PathContainer lookupPathContainer;
/*     */   @Nullable
/*     */   private final String pattern;
/*     */   @Nullable
/*     */   private final String lookupPath;
/*     */   @Nullable
/*     */   private final PathMatcher pathMatcher;
/*     */   
/*     */   public RequestMatchResult(PathPattern pathPattern, PathContainer lookupPath)
/*     */   {
/*  61 */     Assert.notNull(pathPattern, "PathPattern is required");
/*  62 */     Assert.notNull(pathPattern, "PathContainer is required");
/*     */     
/*  64 */     this.pattern = null;
/*  65 */     this.lookupPath = null;
/*  66 */     this.pathMatcher = null;
/*     */     
/*  68 */     this.pathPattern = pathPattern;
/*  69 */     this.lookupPathContainer = lookupPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestMatchResult(String pattern, String lookupPath, PathMatcher pathMatcher)
/*     */   {
/*  80 */     Assert.hasText(pattern, "'matchingPattern' is required");
/*  81 */     Assert.hasText(lookupPath, "'lookupPath' is required");
/*  82 */     Assert.notNull(pathMatcher, "PathMatcher is required");
/*     */     
/*  84 */     this.pattern = pattern;
/*  85 */     this.lookupPath = lookupPath;
/*  86 */     this.pathMatcher = pathMatcher;
/*     */     
/*  88 */     this.pathPattern = null;
/*  89 */     this.lookupPathContainer = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, String> extractUriTemplateVariables()
/*     */   {
/*  99 */     return this.pathPattern != null ? this.pathPattern
/* 100 */       .matchAndExtract(this.lookupPathContainer).getUriVariables() : this.pathMatcher
/* 101 */       .extractUriTemplateVariables(this.pattern, this.lookupPath);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\handler\RequestMatchResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */