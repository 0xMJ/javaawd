/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParamsRequestCondition
/*     */   extends AbstractRequestCondition<ParamsRequestCondition>
/*     */ {
/*     */   private final Set<ParamExpression> expressions;
/*     */   
/*     */   public ParamsRequestCondition(String... params)
/*     */   {
/*  51 */     this.expressions = parseExpressions(params);
/*     */   }
/*     */   
/*     */   private static Set<ParamExpression> parseExpressions(String... params) {
/*  55 */     if (ObjectUtils.isEmpty(params)) {
/*  56 */       return Collections.emptySet();
/*     */     }
/*  58 */     Set<ParamExpression> expressions = new LinkedHashSet(params.length);
/*  59 */     for (String param : params) {
/*  60 */       expressions.add(new ParamExpression(param));
/*     */     }
/*  62 */     return expressions;
/*     */   }
/*     */   
/*     */   private ParamsRequestCondition(Set<ParamExpression> conditions) {
/*  66 */     this.expressions = conditions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<NameValueExpression<String>> getExpressions()
/*     */   {
/*  74 */     return new LinkedHashSet(this.expressions);
/*     */   }
/*     */   
/*     */   protected Collection<ParamExpression> getContent()
/*     */   {
/*  79 */     return this.expressions;
/*     */   }
/*     */   
/*     */   protected String getToStringInfix()
/*     */   {
/*  84 */     return " && ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParamsRequestCondition combine(ParamsRequestCondition other)
/*     */   {
/*  93 */     if ((isEmpty()) && (other.isEmpty())) {
/*  94 */       return this;
/*     */     }
/*  96 */     if (other.isEmpty()) {
/*  97 */       return this;
/*     */     }
/*  99 */     if (isEmpty()) {
/* 100 */       return other;
/*     */     }
/* 102 */     Set<ParamExpression> set = new LinkedHashSet(this.expressions);
/* 103 */     set.addAll(other.expressions);
/* 104 */     return new ParamsRequestCondition(set);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public ParamsRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 114 */     for (ParamExpression expression : this.expressions) {
/* 115 */       if (!expression.match(request)) {
/* 116 */         return null;
/*     */       }
/*     */     }
/* 119 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(ParamsRequestCondition other, HttpServletRequest request)
/*     */   {
/* 135 */     int result = other.expressions.size() - this.expressions.size();
/* 136 */     if (result != 0) {
/* 137 */       return result;
/*     */     }
/* 139 */     return (int)(getValueMatchCount(other.expressions) - getValueMatchCount(this.expressions));
/*     */   }
/*     */   
/*     */   private long getValueMatchCount(Set<ParamExpression> expressions) {
/* 143 */     long count = 0L;
/* 144 */     for (ParamExpression e : expressions) {
/* 145 */       if ((e.getValue() != null) && (!e.isNegated())) {
/* 146 */         count += 1L;
/*     */       }
/*     */     }
/* 149 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static class ParamExpression
/*     */     extends AbstractNameValueExpression<String>
/*     */   {
/* 158 */     private final Set<String> namesToMatch = new HashSet(WebUtils.SUBMIT_IMAGE_SUFFIXES.length + 1);
/*     */     
/*     */     ParamExpression(String expression)
/*     */     {
/* 162 */       super();
/* 163 */       this.namesToMatch.add(getName());
/* 164 */       for (String suffix : WebUtils.SUBMIT_IMAGE_SUFFIXES) {
/* 165 */         this.namesToMatch.add(getName() + suffix);
/*     */       }
/*     */     }
/*     */     
/*     */     protected boolean isCaseSensitiveName()
/*     */     {
/* 171 */       return true;
/*     */     }
/*     */     
/*     */     protected String parseValue(String valueExpression)
/*     */     {
/* 176 */       return valueExpression;
/*     */     }
/*     */     
/*     */     protected boolean matchName(HttpServletRequest request)
/*     */     {
/* 181 */       for (String current : this.namesToMatch) {
/* 182 */         if (request.getParameterMap().get(current) != null) {
/* 183 */           return true;
/*     */         }
/*     */       }
/* 186 */       return request.getParameterMap().containsKey(this.name);
/*     */     }
/*     */     
/*     */     protected boolean matchValue(HttpServletRequest request)
/*     */     {
/* 191 */       return ObjectUtils.nullSafeEquals(this.value, request.getParameter(this.name));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\condition\ParamsRequestCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */