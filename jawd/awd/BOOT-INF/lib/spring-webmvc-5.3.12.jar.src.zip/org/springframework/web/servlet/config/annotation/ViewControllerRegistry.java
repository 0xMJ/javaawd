/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.mvc.ParameterizableViewController;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewControllerRegistry
/*     */ {
/*     */   @Nullable
/*     */   private ApplicationContext applicationContext;
/*  44 */   private final List<ViewControllerRegistration> registrations = new ArrayList(4);
/*     */   
/*  46 */   private final List<RedirectViewControllerRegistration> redirectRegistrations = new ArrayList(10);
/*     */   
/*  48 */   private int order = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ViewControllerRegistry(@Nullable ApplicationContext applicationContext)
/*     */   {
/*  56 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ViewControllerRegistration addViewController(String urlPathOrPattern)
/*     */   {
/*  74 */     ViewControllerRegistration registration = new ViewControllerRegistration(urlPathOrPattern);
/*  75 */     registration.setApplicationContext(this.applicationContext);
/*  76 */     this.registrations.add(registration);
/*  77 */     return registration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RedirectViewControllerRegistration addRedirectViewController(String urlPath, String redirectUrl)
/*     */   {
/*  92 */     RedirectViewControllerRegistration registration = new RedirectViewControllerRegistration(urlPath, redirectUrl);
/*  93 */     registration.setApplicationContext(this.applicationContext);
/*  94 */     this.redirectRegistrations.add(registration);
/*  95 */     return registration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addStatusController(String urlPath, HttpStatus statusCode)
/*     */   {
/* 108 */     ViewControllerRegistration registration = new ViewControllerRegistration(urlPath);
/* 109 */     registration.setApplicationContext(this.applicationContext);
/* 110 */     registration.setStatusCode(statusCode);
/* 111 */     registration.getViewController().setStatusOnly(true);
/* 112 */     this.registrations.add(registration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/* 122 */     this.order = order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected SimpleUrlHandlerMapping buildHandlerMapping()
/*     */   {
/* 133 */     if ((this.registrations.isEmpty()) && (this.redirectRegistrations.isEmpty())) {
/* 134 */       return null;
/*     */     }
/*     */     
/* 137 */     Map<String, Object> urlMap = new LinkedHashMap();
/* 138 */     for (ViewControllerRegistration registration : this.registrations) {
/* 139 */       urlMap.put(registration.getUrlPath(), registration.getViewController());
/*     */     }
/* 141 */     for (RedirectViewControllerRegistration registration : this.redirectRegistrations) {
/* 142 */       urlMap.put(registration.getUrlPath(), registration.getViewController());
/*     */     }
/*     */     
/* 145 */     return new SimpleUrlHandlerMapping(urlMap, this.order);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\annotation\ViewControllerRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */