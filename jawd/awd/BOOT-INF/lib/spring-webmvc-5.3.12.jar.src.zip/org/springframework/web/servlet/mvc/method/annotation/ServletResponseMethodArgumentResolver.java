/*    */ package org.springframework.web.servlet.mvc.method.annotation;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Writer;
/*    */ import javax.servlet.ServletResponse;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletResponseMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 50 */     Class<?> paramType = parameter.getParameterType();
/* 51 */     return (ServletResponse.class.isAssignableFrom(paramType)) || 
/* 52 */       (OutputStream.class.isAssignableFrom(paramType)) || 
/* 53 */       (Writer.class.isAssignableFrom(paramType));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, @Nullable ModelAndViewContainer mavContainer, NativeWebRequest webRequest, @Nullable WebDataBinderFactory binderFactory)
/*    */     throws Exception
/*    */   {
/* 66 */     if (mavContainer != null) {
/* 67 */       mavContainer.setRequestHandled(true);
/*    */     }
/*    */     
/* 70 */     Class<?> paramType = parameter.getParameterType();
/*    */     
/*    */ 
/* 73 */     if (ServletResponse.class.isAssignableFrom(paramType)) {
/* 74 */       return resolveNativeResponse(webRequest, paramType);
/*    */     }
/*    */     
/*    */ 
/* 78 */     return resolveArgument(paramType, (ServletResponse)resolveNativeResponse(webRequest, ServletResponse.class));
/*    */   }
/*    */   
/*    */   private <T> T resolveNativeResponse(NativeWebRequest webRequest, Class<T> requiredType) {
/* 82 */     T nativeResponse = webRequest.getNativeResponse(requiredType);
/* 83 */     if (nativeResponse == null)
/*    */     {
/* 85 */       throw new IllegalStateException("Current response is not of type [" + requiredType.getName() + "]: " + webRequest);
/*    */     }
/* 87 */     return nativeResponse;
/*    */   }
/*    */   
/*    */   private Object resolveArgument(Class<?> paramType, ServletResponse response) throws IOException {
/* 91 */     if (OutputStream.class.isAssignableFrom(paramType)) {
/* 92 */       return response.getOutputStream();
/*    */     }
/* 94 */     if (Writer.class.isAssignableFrom(paramType)) {
/* 95 */       return response.getWriter();
/*    */     }
/*    */     
/*    */ 
/* 99 */     throw new UnsupportedOperationException("Unknown parameter type: " + paramType);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ServletResponseMethodArgumentResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */