/*    */ package org.springframework.web.servlet.config.annotation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ import org.springframework.web.cors.CorsConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CorsRegistry
/*    */ {
/* 37 */   private final List<CorsRegistration> registrations = new ArrayList();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CorsRegistration addMapping(String pathPattern)
/*    */   {
/* 49 */     CorsRegistration registration = new CorsRegistration(pathPattern);
/* 50 */     this.registrations.add(registration);
/* 51 */     return registration;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Map<String, CorsConfiguration> getCorsConfigurations()
/*    */   {
/* 59 */     Map<String, CorsConfiguration> configs = CollectionUtils.newLinkedHashMap(this.registrations.size());
/* 60 */     for (CorsRegistration registration : this.registrations) {
/* 61 */       configs.put(registration.getPathPattern(), registration.getCorsConfiguration());
/*    */     }
/* 63 */     return configs;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\annotation\CorsRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */