/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.DynamicAttributes;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHtmlElementTag
/*     */   extends AbstractDataBoundFormElementTag
/*     */   implements DynamicAttributes
/*     */ {
/*     */   public static final String CLASS_ATTRIBUTE = "class";
/*     */   public static final String STYLE_ATTRIBUTE = "style";
/*     */   public static final String LANG_ATTRIBUTE = "lang";
/*     */   public static final String TITLE_ATTRIBUTE = "title";
/*     */   public static final String DIR_ATTRIBUTE = "dir";
/*     */   public static final String TABINDEX_ATTRIBUTE = "tabindex";
/*     */   public static final String ONCLICK_ATTRIBUTE = "onclick";
/*     */   public static final String ONDBLCLICK_ATTRIBUTE = "ondblclick";
/*     */   public static final String ONMOUSEDOWN_ATTRIBUTE = "onmousedown";
/*     */   public static final String ONMOUSEUP_ATTRIBUTE = "onmouseup";
/*     */   public static final String ONMOUSEOVER_ATTRIBUTE = "onmouseover";
/*     */   public static final String ONMOUSEMOVE_ATTRIBUTE = "onmousemove";
/*     */   public static final String ONMOUSEOUT_ATTRIBUTE = "onmouseout";
/*     */   public static final String ONKEYPRESS_ATTRIBUTE = "onkeypress";
/*     */   public static final String ONKEYUP_ATTRIBUTE = "onkeyup";
/*     */   public static final String ONKEYDOWN_ATTRIBUTE = "onkeydown";
/*     */   @Nullable
/*     */   private String cssClass;
/*     */   @Nullable
/*     */   private String cssErrorClass;
/*     */   @Nullable
/*     */   private String cssStyle;
/*     */   @Nullable
/*     */   private String lang;
/*     */   @Nullable
/*     */   private String title;
/*     */   @Nullable
/*     */   private String dir;
/*     */   @Nullable
/*     */   private String tabindex;
/*     */   @Nullable
/*     */   private String onclick;
/*     */   @Nullable
/*     */   private String ondblclick;
/*     */   @Nullable
/*     */   private String onmousedown;
/*     */   @Nullable
/*     */   private String onmouseup;
/*     */   @Nullable
/*     */   private String onmouseover;
/*     */   @Nullable
/*     */   private String onmousemove;
/*     */   @Nullable
/*     */   private String onmouseout;
/*     */   @Nullable
/*     */   private String onkeypress;
/*     */   @Nullable
/*     */   private String onkeyup;
/*     */   @Nullable
/*     */   private String onkeydown;
/*     */   @Nullable
/*     */   private Map<String, Object> dynamicAttributes;
/*     */   
/*     */   public void setCssClass(String cssClass)
/*     */   {
/* 141 */     this.cssClass = cssClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getCssClass()
/*     */   {
/* 150 */     return this.cssClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCssErrorClass(String cssErrorClass)
/*     */   {
/* 158 */     this.cssErrorClass = cssErrorClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getCssErrorClass()
/*     */   {
/* 167 */     return this.cssErrorClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCssStyle(String cssStyle)
/*     */   {
/* 175 */     this.cssStyle = cssStyle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getCssStyle()
/*     */   {
/* 184 */     return this.cssStyle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLang(String lang)
/*     */   {
/* 192 */     this.lang = lang;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getLang()
/*     */   {
/* 201 */     return this.lang;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTitle(String title)
/*     */   {
/* 209 */     this.title = title;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getTitle()
/*     */   {
/* 218 */     return this.title;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDir(String dir)
/*     */   {
/* 226 */     this.dir = dir;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getDir()
/*     */   {
/* 235 */     return this.dir;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTabindex(String tabindex)
/*     */   {
/* 243 */     this.tabindex = tabindex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getTabindex()
/*     */   {
/* 252 */     return this.tabindex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnclick(String onclick)
/*     */   {
/* 260 */     this.onclick = onclick;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOnclick()
/*     */   {
/* 269 */     return this.onclick;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOndblclick(String ondblclick)
/*     */   {
/* 277 */     this.ondblclick = ondblclick;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOndblclick()
/*     */   {
/* 286 */     return this.ondblclick;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnmousedown(String onmousedown)
/*     */   {
/* 294 */     this.onmousedown = onmousedown;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOnmousedown()
/*     */   {
/* 303 */     return this.onmousedown;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnmouseup(String onmouseup)
/*     */   {
/* 311 */     this.onmouseup = onmouseup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOnmouseup()
/*     */   {
/* 320 */     return this.onmouseup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnmouseover(String onmouseover)
/*     */   {
/* 328 */     this.onmouseover = onmouseover;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOnmouseover()
/*     */   {
/* 337 */     return this.onmouseover;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnmousemove(String onmousemove)
/*     */   {
/* 345 */     this.onmousemove = onmousemove;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOnmousemove()
/*     */   {
/* 354 */     return this.onmousemove;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnmouseout(String onmouseout)
/*     */   {
/* 362 */     this.onmouseout = onmouseout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOnmouseout()
/*     */   {
/* 370 */     return this.onmouseout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnkeypress(String onkeypress)
/*     */   {
/* 378 */     this.onkeypress = onkeypress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOnkeypress()
/*     */   {
/* 387 */     return this.onkeypress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnkeyup(String onkeyup)
/*     */   {
/* 395 */     this.onkeyup = onkeyup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOnkeyup()
/*     */   {
/* 404 */     return this.onkeyup;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnkeydown(String onkeydown)
/*     */   {
/* 412 */     this.onkeydown = onkeydown;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOnkeydown()
/*     */   {
/* 421 */     return this.onkeydown;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Map<String, Object> getDynamicAttributes()
/*     */   {
/* 429 */     return this.dynamicAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDynamicAttribute(String uri, String localName, Object value)
/*     */     throws JspException
/*     */   {
/* 437 */     if (this.dynamicAttributes == null) {
/* 438 */       this.dynamicAttributes = new HashMap();
/*     */     }
/* 440 */     if (!isValidDynamicAttribute(localName, value)) {
/* 441 */       throw new IllegalArgumentException("Attribute " + localName + "=\"" + value + "\" is not allowed");
/*     */     }
/*     */     
/* 444 */     this.dynamicAttributes.put(localName, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isValidDynamicAttribute(String localName, Object value)
/*     */   {
/* 451 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeDefaultAttributes(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 460 */     super.writeDefaultAttributes(tagWriter);
/* 461 */     writeOptionalAttributes(tagWriter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeOptionalAttributes(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 470 */     tagWriter.writeOptionalAttributeValue("class", resolveCssClass());
/* 471 */     tagWriter.writeOptionalAttributeValue("style", 
/* 472 */       ObjectUtils.getDisplayString(evaluate("cssStyle", getCssStyle())));
/* 473 */     writeOptionalAttribute(tagWriter, "lang", getLang());
/* 474 */     writeOptionalAttribute(tagWriter, "title", getTitle());
/* 475 */     writeOptionalAttribute(tagWriter, "dir", getDir());
/* 476 */     writeOptionalAttribute(tagWriter, "tabindex", getTabindex());
/* 477 */     writeOptionalAttribute(tagWriter, "onclick", getOnclick());
/* 478 */     writeOptionalAttribute(tagWriter, "ondblclick", getOndblclick());
/* 479 */     writeOptionalAttribute(tagWriter, "onmousedown", getOnmousedown());
/* 480 */     writeOptionalAttribute(tagWriter, "onmouseup", getOnmouseup());
/* 481 */     writeOptionalAttribute(tagWriter, "onmouseover", getOnmouseover());
/* 482 */     writeOptionalAttribute(tagWriter, "onmousemove", getOnmousemove());
/* 483 */     writeOptionalAttribute(tagWriter, "onmouseout", getOnmouseout());
/* 484 */     writeOptionalAttribute(tagWriter, "onkeypress", getOnkeypress());
/* 485 */     writeOptionalAttribute(tagWriter, "onkeyup", getOnkeyup());
/* 486 */     writeOptionalAttribute(tagWriter, "onkeydown", getOnkeydown());
/*     */     
/* 488 */     if (!CollectionUtils.isEmpty(this.dynamicAttributes)) {
/* 489 */       for (Map.Entry<String, Object> entry : this.dynamicAttributes.entrySet()) {
/* 490 */         tagWriter.writeOptionalAttributeValue((String)entry.getKey(), getDisplayString(entry.getValue()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String resolveCssClass()
/*     */     throws JspException
/*     */   {
/* 500 */     if ((getBindStatus().isError()) && (StringUtils.hasText(getCssErrorClass()))) {
/* 501 */       return ObjectUtils.getDisplayString(evaluate("cssErrorClass", getCssErrorClass()));
/*     */     }
/*     */     
/* 504 */     return ObjectUtils.getDisplayString(evaluate("cssClass", getCssClass()));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\form\AbstractHtmlElementTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */