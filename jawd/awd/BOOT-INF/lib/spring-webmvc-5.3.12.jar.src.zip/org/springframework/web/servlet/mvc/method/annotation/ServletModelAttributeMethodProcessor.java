/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletRequest;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.validation.DataBinder;
/*     */ import org.springframework.web.bind.ServletRequestDataBinder;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.annotation.ModelAttributeMethodProcessor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletModelAttributeMethodProcessor
/*     */   extends ModelAttributeMethodProcessor
/*     */ {
/*     */   public ServletModelAttributeMethodProcessor(boolean annotationNotRequired)
/*     */   {
/*  61 */     super(annotationNotRequired);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Object createAttribute(String attributeName, MethodParameter parameter, WebDataBinderFactory binderFactory, NativeWebRequest request)
/*     */     throws Exception
/*     */   {
/*  76 */     String value = getRequestValueForAttribute(attributeName, request);
/*  77 */     if (value != null) {
/*  78 */       Object attribute = createAttributeFromRequestValue(value, attributeName, parameter, binderFactory, request);
/*     */       
/*  80 */       if (attribute != null) {
/*  81 */         return attribute;
/*     */       }
/*     */     }
/*     */     
/*  85 */     return super.createAttribute(attributeName, parameter, binderFactory, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getRequestValueForAttribute(String attributeName, NativeWebRequest request)
/*     */   {
/*  99 */     Map<String, String> variables = getUriTemplateVariables(request);
/* 100 */     String variableValue = (String)variables.get(attributeName);
/* 101 */     if (StringUtils.hasText(variableValue)) {
/* 102 */       return variableValue;
/*     */     }
/* 104 */     String parameterValue = request.getParameter(attributeName);
/* 105 */     if (StringUtils.hasText(parameterValue)) {
/* 106 */       return parameterValue;
/*     */     }
/* 108 */     return null;
/*     */   }
/*     */   
/*     */   protected final Map<String, String> getUriTemplateVariables(NativeWebRequest request)
/*     */   {
/* 113 */     Map<String, String> variables = (Map)request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE, 0);
/*     */     
/* 115 */     return variables != null ? variables : Collections.emptyMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object createAttributeFromRequestValue(String sourceValue, String attributeName, MethodParameter parameter, WebDataBinderFactory binderFactory, NativeWebRequest request)
/*     */     throws Exception
/*     */   {
/* 136 */     DataBinder binder = binderFactory.createBinder(request, null, attributeName);
/* 137 */     ConversionService conversionService = binder.getConversionService();
/* 138 */     if (conversionService != null) {
/* 139 */       TypeDescriptor source = TypeDescriptor.valueOf(String.class);
/* 140 */       TypeDescriptor target = new TypeDescriptor(parameter);
/* 141 */       if (conversionService.canConvert(source, target)) {
/* 142 */         return binder.convertIfNecessary(sourceValue, parameter.getParameterType(), parameter);
/*     */       }
/*     */     }
/* 145 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void bindRequestParameters(WebDataBinder binder, NativeWebRequest request)
/*     */   {
/* 155 */     ServletRequest servletRequest = (ServletRequest)request.getNativeRequest(ServletRequest.class);
/* 156 */     Assert.state(servletRequest != null, "No ServletRequest");
/* 157 */     ServletRequestDataBinder servletBinder = (ServletRequestDataBinder)binder;
/* 158 */     servletBinder.bind(servletRequest);
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   public Object resolveConstructorArgument(String paramName, Class<?> paramType, NativeWebRequest request)
/*     */     throws Exception
/*     */   {
/* 166 */     Object value = super.resolveConstructorArgument(paramName, paramType, request);
/* 167 */     if (value != null) {
/* 168 */       return value;
/*     */     }
/* 170 */     ServletRequest servletRequest = (ServletRequest)request.getNativeRequest(ServletRequest.class);
/* 171 */     if (servletRequest != null) {
/* 172 */       String attr = HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE;
/*     */       
/* 174 */       Map<String, String> uriVars = (Map)servletRequest.getAttribute(attr);
/* 175 */       return uriVars.get(paramName);
/*     */     }
/* 177 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ServletModelAttributeMethodProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */