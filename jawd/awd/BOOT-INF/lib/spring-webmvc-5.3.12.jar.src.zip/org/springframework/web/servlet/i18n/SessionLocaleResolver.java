/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionLocaleResolver
/*     */   extends AbstractLocaleContextResolver
/*     */ {
/*  71 */   public static final String LOCALE_SESSION_ATTRIBUTE_NAME = SessionLocaleResolver.class.getName() + ".LOCALE";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */   public static final String TIME_ZONE_SESSION_ATTRIBUTE_NAME = SessionLocaleResolver.class.getName() + ".TIME_ZONE";
/*     */   
/*     */ 
/*  84 */   private String localeAttributeName = LOCALE_SESSION_ATTRIBUTE_NAME;
/*     */   
/*  86 */   private String timeZoneAttributeName = TIME_ZONE_SESSION_ATTRIBUTE_NAME;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocaleAttributeName(String localeAttributeName)
/*     */   {
/*  96 */     this.localeAttributeName = localeAttributeName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeZoneAttributeName(String timeZoneAttributeName)
/*     */   {
/* 106 */     this.timeZoneAttributeName = timeZoneAttributeName;
/*     */   }
/*     */   
/*     */ 
/*     */   public Locale resolveLocale(HttpServletRequest request)
/*     */   {
/* 112 */     Locale locale = (Locale)WebUtils.getSessionAttribute(request, this.localeAttributeName);
/* 113 */     if (locale == null) {
/* 114 */       locale = determineDefaultLocale(request);
/*     */     }
/* 116 */     return locale;
/*     */   }
/*     */   
/*     */   public LocaleContext resolveLocaleContext(final HttpServletRequest request)
/*     */   {
/* 121 */     new TimeZoneAwareLocaleContext()
/*     */     {
/*     */       public Locale getLocale() {
/* 124 */         Locale locale = (Locale)WebUtils.getSessionAttribute(request, SessionLocaleResolver.this.localeAttributeName);
/* 125 */         if (locale == null) {
/* 126 */           locale = SessionLocaleResolver.this.determineDefaultLocale(request);
/*     */         }
/* 128 */         return locale;
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public TimeZone getTimeZone() {
/* 133 */         TimeZone timeZone = (TimeZone)WebUtils.getSessionAttribute(request, SessionLocaleResolver.this.timeZoneAttributeName);
/* 134 */         if (timeZone == null) {
/* 135 */           timeZone = SessionLocaleResolver.this.determineDefaultTimeZone(request);
/*     */         }
/* 137 */         return timeZone;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLocaleContext(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable LocaleContext localeContext)
/*     */   {
/* 146 */     Locale locale = null;
/* 147 */     TimeZone timeZone = null;
/* 148 */     if (localeContext != null) {
/* 149 */       locale = localeContext.getLocale();
/* 150 */       if ((localeContext instanceof TimeZoneAwareLocaleContext)) {
/* 151 */         timeZone = ((TimeZoneAwareLocaleContext)localeContext).getTimeZone();
/*     */       }
/*     */     }
/* 154 */     WebUtils.setSessionAttribute(request, this.localeAttributeName, locale);
/* 155 */     WebUtils.setSessionAttribute(request, this.timeZoneAttributeName, timeZone);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Locale determineDefaultLocale(HttpServletRequest request)
/*     */   {
/* 170 */     Locale defaultLocale = getDefaultLocale();
/* 171 */     if (defaultLocale == null) {
/* 172 */       defaultLocale = request.getLocale();
/*     */     }
/* 174 */     return defaultLocale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected TimeZone determineDefaultTimeZone(HttpServletRequest request)
/*     */   {
/* 188 */     return getDefaultTimeZone();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\i18n\SessionLocaleResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */