/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JspAwareRequestContext
/*     */   extends RequestContext
/*     */ {
/*     */   private PageContext pageContext;
/*     */   
/*     */   public JspAwareRequestContext(PageContext pageContext)
/*     */   {
/*  52 */     this(pageContext, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JspAwareRequestContext(PageContext pageContext, @Nullable Map<String, Object> model)
/*     */   {
/*  63 */     super((HttpServletRequest)pageContext.getRequest(), (HttpServletResponse)pageContext.getResponse(), pageContext
/*  64 */       .getServletContext(), model);
/*  65 */     this.pageContext = pageContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final PageContext getPageContext()
/*     */   {
/*  74 */     return this.pageContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Locale getFallbackLocale()
/*     */   {
/*  84 */     if (jstlPresent) {
/*  85 */       Locale locale = JstlPageLocaleResolver.getJstlLocale(getPageContext());
/*  86 */       if (locale != null) {
/*  87 */         return locale;
/*     */       }
/*     */     }
/*  90 */     return getRequest().getLocale();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TimeZone getFallbackTimeZone()
/*     */   {
/*  99 */     if (jstlPresent) {
/* 100 */       TimeZone timeZone = JstlPageLocaleResolver.getJstlTimeZone(getPageContext());
/* 101 */       if (timeZone != null) {
/* 102 */         return timeZone;
/*     */       }
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class JstlPageLocaleResolver
/*     */   {
/*     */     @Nullable
/*     */     public static Locale getJstlLocale(PageContext pageContext)
/*     */     {
/* 117 */       Object localeObject = Config.find(pageContext, "javax.servlet.jsp.jstl.fmt.locale");
/* 118 */       return (localeObject instanceof Locale) ? (Locale)localeObject : null;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public static TimeZone getJstlTimeZone(PageContext pageContext) {
/* 123 */       Object timeZoneObject = Config.find(pageContext, "javax.servlet.jsp.jstl.fmt.timeZone");
/* 124 */       return (timeZoneObject instanceof TimeZone) ? (TimeZone)timeZoneObject : null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\support\JspAwareRequestContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */