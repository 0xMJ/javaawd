/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.LocaleResolver;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocaleChangeInterceptor
/*     */   implements HandlerInterceptor
/*     */ {
/*     */   public static final String DEFAULT_PARAM_NAME = "locale";
/*  52 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  54 */   private String paramName = "locale";
/*     */   
/*     */   @Nullable
/*     */   private String[] httpMethods;
/*     */   
/*  59 */   private boolean ignoreInvalidLocale = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParamName(String paramName)
/*     */   {
/*  67 */     this.paramName = paramName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getParamName()
/*     */   {
/*  75 */     return this.paramName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHttpMethods(@Nullable String... httpMethods)
/*     */   {
/*  84 */     this.httpMethods = httpMethods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public String[] getHttpMethods()
/*     */   {
/*  93 */     return this.httpMethods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreInvalidLocale(boolean ignoreInvalidLocale)
/*     */   {
/* 101 */     this.ignoreInvalidLocale = ignoreInvalidLocale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isIgnoreInvalidLocale()
/*     */   {
/* 109 */     return this.ignoreInvalidLocale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setLanguageTagCompliant(boolean languageTagCompliant)
/*     */   {
/* 124 */     if (!languageTagCompliant) {
/* 125 */       throw new IllegalArgumentException("LocaleChangeInterceptor always accepts BCP 47 language tags");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public boolean isLanguageTagCompliant()
/*     */   {
/* 137 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     throws ServletException
/*     */   {
/* 145 */     String newLocale = request.getParameter(getParamName());
/* 146 */     if ((newLocale != null) && 
/* 147 */       (checkHttpMethod(request.getMethod()))) {
/* 148 */       LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
/* 149 */       if (localeResolver == null) {
/* 150 */         throw new IllegalStateException("No LocaleResolver found: not in a DispatcherServlet request?");
/*     */       }
/*     */       try
/*     */       {
/* 154 */         localeResolver.setLocale(request, response, parseLocaleValue(newLocale));
/*     */       }
/*     */       catch (IllegalArgumentException ex) {
/* 157 */         if (isIgnoreInvalidLocale()) {
/* 158 */           if (this.logger.isDebugEnabled()) {
/* 159 */             this.logger.debug("Ignoring invalid locale value [" + newLocale + "]: " + ex.getMessage());
/*     */           }
/*     */         }
/*     */         else {
/* 163 */           throw ex;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 169 */     return true;
/*     */   }
/*     */   
/*     */   private boolean checkHttpMethod(String currentMethod) {
/* 173 */     String[] configuredMethods = getHttpMethods();
/* 174 */     if (ObjectUtils.isEmpty(configuredMethods)) {
/* 175 */       return true;
/*     */     }
/* 177 */     for (String configuredMethod : configuredMethods) {
/* 178 */       if (configuredMethod.equalsIgnoreCase(currentMethod)) {
/* 179 */         return true;
/*     */       }
/*     */     }
/* 182 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Locale parseLocaleValue(String localeValue)
/*     */   {
/* 195 */     return StringUtils.parseLocale(localeValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\i18n\LocaleChangeInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */