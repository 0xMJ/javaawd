/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.Principal;
/*     */ import java.time.Instant;
/*     */ import java.util.List;
/*     */ import java.util.Locale.LanguageRange;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.OptionalLong;
/*     */ import java.util.function.Consumer;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.Part;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpRange;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.UriBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface ServerRequest
/*     */ {
/*     */   @Nullable
/*     */   public HttpMethod method()
/*     */   {
/*  71 */     return HttpMethod.resolve(methodName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String methodName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract URI uri();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract UriBuilder uriBuilder();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String path()
/*     */   {
/*  96 */     return requestPath().pathWithinApplication().value();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public PathContainer pathContainer()
/*     */   {
/* 105 */     return requestPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestPath requestPath()
/*     */   {
/* 113 */     return ServletRequestPathUtils.getParsedRequestPath(servletRequest());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Headers headers();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract MultiValueMap<String, Cookie> cookies();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Optional<InetSocketAddress> remoteAddress();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract List<HttpMessageConverter<?>> messageConverters();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract <T> T body(Class<T> paramClass)
/*     */     throws ServletException, IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract <T> T body(ParameterizedTypeReference<T> paramParameterizedTypeReference)
/*     */     throws ServletException, IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Optional<Object> attribute(String name)
/*     */   {
/* 158 */     Map<String, Object> attributes = attributes();
/* 159 */     if (attributes.containsKey(name)) {
/* 160 */       return Optional.of(attributes.get(name));
/*     */     }
/*     */     
/* 163 */     return Optional.empty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Map<String, Object> attributes();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Optional<String> param(String name)
/*     */   {
/* 181 */     List<String> paramValues = (List)params().get(name);
/* 182 */     if (CollectionUtils.isEmpty(paramValues)) {
/* 183 */       return Optional.empty();
/*     */     }
/*     */     
/* 186 */     String value = (String)paramValues.get(0);
/* 187 */     if (value == null) {
/* 188 */       value = "";
/*     */     }
/* 190 */     return Optional.of(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract MultiValueMap<String, String> params();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract MultiValueMap<String, Part> multipartData()
/*     */     throws IOException, ServletException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String pathVariable(String name)
/*     */   {
/* 219 */     Map<String, String> pathVariables = pathVariables();
/* 220 */     if (pathVariables.containsKey(name)) {
/* 221 */       return (String)pathVariables().get(name);
/*     */     }
/*     */     
/* 224 */     throw new IllegalArgumentException("No path variable with name \"" + name + "\" available");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Map<String, String> pathVariables();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract HttpSession session();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract Optional<Principal> principal();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract HttpServletRequest servletRequest();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Optional<ServerResponse> checkNotModified(Instant lastModified)
/*     */   {
/* 282 */     Assert.notNull(lastModified, "LastModified must not be null");
/* 283 */     return DefaultServerRequest.checkNotModified(servletRequest(), lastModified, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Optional<ServerResponse> checkNotModified(String etag)
/*     */   {
/* 317 */     Assert.notNull(etag, "Etag must not be null");
/* 318 */     return DefaultServerRequest.checkNotModified(servletRequest(), null, etag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Optional<ServerResponse> checkNotModified(Instant lastModified, String etag)
/*     */   {
/* 350 */     Assert.notNull(lastModified, "LastModified must not be null");
/* 351 */     Assert.notNull(etag, "Etag must not be null");
/* 352 */     return DefaultServerRequest.checkNotModified(servletRequest(), lastModified, etag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServerRequest create(HttpServletRequest servletRequest, List<HttpMessageConverter<?>> messageReaders)
/*     */   {
/* 366 */     return new DefaultServerRequest(servletRequest, messageReaders);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Builder from(ServerRequest other)
/*     */   {
/* 375 */     return new DefaultServerRequestBuilder(other);
/*     */   }
/*     */   
/*     */ 
/*     */   public static abstract interface Builder
/*     */   {
/*     */     public abstract Builder method(HttpMethod paramHttpMethod);
/*     */     
/*     */ 
/*     */     public abstract Builder uri(URI paramURI);
/*     */     
/*     */ 
/*     */     public abstract Builder header(String paramString, String... paramVarArgs);
/*     */     
/*     */ 
/*     */     public abstract Builder headers(Consumer<HttpHeaders> paramConsumer);
/*     */     
/*     */ 
/*     */     public abstract Builder cookie(String paramString, String... paramVarArgs);
/*     */     
/*     */ 
/*     */     public abstract Builder cookies(Consumer<MultiValueMap<String, Cookie>> paramConsumer);
/*     */     
/*     */ 
/*     */     public abstract Builder body(byte[] paramArrayOfByte);
/*     */     
/*     */ 
/*     */     public abstract Builder body(String paramString);
/*     */     
/*     */ 
/*     */     public abstract Builder attribute(String paramString, Object paramObject);
/*     */     
/*     */ 
/*     */     public abstract Builder attributes(Consumer<Map<String, Object>> paramConsumer);
/*     */     
/*     */ 
/*     */     public abstract Builder param(String paramString, String... paramVarArgs);
/*     */     
/*     */ 
/*     */     public abstract Builder params(Consumer<MultiValueMap<String, String>> paramConsumer);
/*     */     
/*     */ 
/*     */     public abstract Builder remoteAddress(InetSocketAddress paramInetSocketAddress);
/*     */     
/*     */ 
/*     */     public abstract ServerRequest build();
/*     */   }
/*     */   
/*     */ 
/*     */   public static abstract interface Headers
/*     */   {
/*     */     public abstract List<MediaType> accept();
/*     */     
/*     */ 
/*     */     public abstract List<Charset> acceptCharset();
/*     */     
/*     */     public abstract List<Locale.LanguageRange> acceptLanguage();
/*     */     
/*     */     public abstract OptionalLong contentLength();
/*     */     
/*     */     public abstract Optional<MediaType> contentType();
/*     */     
/*     */     @Nullable
/*     */     public abstract InetSocketAddress host();
/*     */     
/*     */     public abstract List<HttpRange> range();
/*     */     
/*     */     public abstract List<String> header(String paramString);
/*     */     
/*     */     @Nullable
/*     */     public String firstHeader(String headerName)
/*     */     {
/* 447 */       List<String> list = header(headerName);
/* 448 */       return list.isEmpty() ? null : (String)list.get(0);
/*     */     }
/*     */     
/*     */     public abstract HttpHeaders asHttpHeaders();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\ServerRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */