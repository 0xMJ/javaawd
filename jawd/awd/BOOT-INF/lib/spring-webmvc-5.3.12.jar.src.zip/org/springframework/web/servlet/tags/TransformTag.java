/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.io.IOException;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.util.TagUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformTag
/*     */   extends HtmlEscapingAwareTag
/*     */ {
/*     */   @Nullable
/*     */   private Object value;
/*     */   @Nullable
/*     */   private String var;
/*  99 */   private String scope = "page";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(Object value)
/*     */   {
/* 110 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVar(String var)
/*     */   {
/* 120 */     this.var = var;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScope(String scope)
/*     */   {
/* 131 */     this.scope = scope;
/*     */   }
/*     */   
/*     */   protected final int doStartTagInternal()
/*     */     throws JspException
/*     */   {
/* 137 */     if (this.value != null)
/*     */     {
/* 139 */       EditorAwareTag tag = (EditorAwareTag)TagSupport.findAncestorWithClass(this, EditorAwareTag.class);
/* 140 */       if (tag == null) {
/* 141 */         throw new JspException("TransformTag can only be used within EditorAwareTag (e.g. BindTag)");
/*     */       }
/*     */       
/*     */ 
/* 145 */       String result = null;
/* 146 */       PropertyEditor editor = tag.getEditor();
/* 147 */       if (editor != null)
/*     */       {
/* 149 */         editor.setValue(this.value);
/* 150 */         result = editor.getAsText();
/*     */       }
/*     */       else
/*     */       {
/* 154 */         result = this.value.toString();
/*     */       }
/* 156 */       result = htmlEscape(result);
/* 157 */       if (this.var != null) {
/* 158 */         this.pageContext.setAttribute(this.var, result, TagUtils.getScope(this.scope));
/*     */       }
/*     */       else {
/*     */         try
/*     */         {
/* 163 */           this.pageContext.getOut().print(result);
/*     */         }
/*     */         catch (IOException ex) {
/* 166 */           throw new JspException(ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 171 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\TransformTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */