/*    */ package org.springframework.web.servlet.function;
/*    */ 
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public abstract interface RequestPredicate
/*    */ {
/*    */   public abstract boolean test(ServerRequest paramServerRequest);
/*    */   
/*    */   public RequestPredicate and(RequestPredicate other)
/*    */   {
/* 50 */     return new RequestPredicates.AndRequestPredicate(this, other);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public RequestPredicate negate()
/*    */   {
/* 58 */     return new RequestPredicates.NegateRequestPredicate(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RequestPredicate or(RequestPredicate other)
/*    */   {
/* 69 */     return new RequestPredicates.OrRequestPredicate(this, other);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Optional<ServerRequest> nest(ServerRequest request)
/*    */   {
/* 84 */     return test(request) ? Optional.of(request) : Optional.empty();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void accept(RequestPredicates.Visitor visitor)
/*    */   {
/* 95 */     visitor.unknown(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\RequestPredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */