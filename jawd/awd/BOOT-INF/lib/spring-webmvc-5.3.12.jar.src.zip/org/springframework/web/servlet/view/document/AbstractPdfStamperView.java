/*    */ package org.springframework.web.servlet.view.document;
/*    */ 
/*    */ import com.lowagie.text.pdf.PdfReader;
/*    */ import com.lowagie.text.pdf.PdfStamper;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractPdfStamperView
/*    */   extends AbstractUrlBasedView
/*    */ {
/*    */   public AbstractPdfStamperView()
/*    */   {
/* 53 */     setContentType("application/pdf");
/*    */   }
/*    */   
/*    */ 
/*    */   protected boolean generatesDownloadContent()
/*    */   {
/* 59 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected final void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*    */     throws Exception
/*    */   {
/* 67 */     ByteArrayOutputStream baos = createTemporaryOutputStream();
/*    */     
/* 69 */     PdfReader reader = readPdfResource();
/* 70 */     PdfStamper stamper = new PdfStamper(reader, baos);
/* 71 */     mergePdfDocument(model, stamper, request, response);
/* 72 */     stamper.close();
/*    */     
/*    */ 
/* 75 */     writeToResponse(response, baos);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected PdfReader readPdfResource()
/*    */     throws IOException
/*    */   {
/* 87 */     String url = getUrl();
/* 88 */     Assert.state(url != null, "'url' not set");
/* 89 */     return new PdfReader(obtainApplicationContext().getResource(url).getInputStream());
/*    */   }
/*    */   
/*    */   protected abstract void mergePdfDocument(Map<String, Object> paramMap, PdfStamper paramPdfStamper, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*    */     throws Exception;
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\document\AbstractPdfStamperView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */