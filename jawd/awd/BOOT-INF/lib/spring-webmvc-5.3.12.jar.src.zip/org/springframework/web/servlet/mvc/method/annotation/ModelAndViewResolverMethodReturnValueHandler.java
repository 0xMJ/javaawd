/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.ui.ExtendedModelMap;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.annotation.ModelAttributeMethodProcessor;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ import org.springframework.web.servlet.mvc.annotation.ModelAndViewResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelAndViewResolverMethodReturnValueHandler
/*     */   implements HandlerMethodReturnValueHandler
/*     */ {
/*     */   @Nullable
/*     */   private final List<ModelAndViewResolver> mavResolvers;
/*  61 */   private final ModelAttributeMethodProcessor modelAttributeProcessor = new ServletModelAttributeMethodProcessor(true);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModelAndViewResolverMethodReturnValueHandler(@Nullable List<ModelAndViewResolver> mavResolvers)
/*     */   {
/*  69 */     this.mavResolvers = mavResolvers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/*  78 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleReturnValue(@Nullable Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/*  85 */     if (this.mavResolvers != null) {
/*  86 */       for (ModelAndViewResolver mavResolver : this.mavResolvers) {
/*  87 */         Class<?> handlerType = returnType.getContainingClass();
/*  88 */         Method method = returnType.getMethod();
/*  89 */         Assert.state(method != null, "No handler method");
/*  90 */         ExtendedModelMap model = (ExtendedModelMap)mavContainer.getModel();
/*  91 */         ModelAndView mav = mavResolver.resolveModelAndView(method, handlerType, returnValue, model, webRequest);
/*  92 */         if (mav != ModelAndViewResolver.UNRESOLVED) {
/*  93 */           mavContainer.addAllAttributes(mav.getModel());
/*  94 */           mavContainer.setViewName(mav.getViewName());
/*  95 */           if (!mav.isReference()) {
/*  96 */             mavContainer.setView(mav.getView());
/*     */           }
/*  98 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 104 */     if (this.modelAttributeProcessor.supportsReturnType(returnType)) {
/* 105 */       this.modelAttributeProcessor.handleReturnValue(returnValue, returnType, mavContainer, webRequest);
/*     */     }
/*     */     else
/*     */     {
/* 109 */       throw new UnsupportedOperationException("Unexpected return type: " + returnType.getParameterType().getName() + " in method: " + returnType.getMethod());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ModelAndViewResolverMethodReturnValueHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */