/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindTag
/*     */   extends HtmlEscapingAwareTag
/*     */   implements EditorAwareTag
/*     */ {
/*     */   public static final String STATUS_VARIABLE_NAME = "status";
/*  96 */   private String path = "";
/*     */   
/*  98 */   private boolean ignoreNestedPath = false;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private BindStatus status;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Object previousPageStatus;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Object previousRequestStatus;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPath(String path)
/*     */   {
/* 120 */     this.path = path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getPath()
/*     */   {
/* 127 */     return this.path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIgnoreNestedPath(boolean ignoreNestedPath)
/*     */   {
/* 135 */     this.ignoreNestedPath = ignoreNestedPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isIgnoreNestedPath()
/*     */   {
/* 142 */     return this.ignoreNestedPath;
/*     */   }
/*     */   
/*     */   protected final int doStartTagInternal()
/*     */     throws Exception
/*     */   {
/* 148 */     String resolvedPath = getPath();
/* 149 */     if (!isIgnoreNestedPath()) {
/* 150 */       String nestedPath = (String)this.pageContext.getAttribute("nestedPath", 2);
/*     */       
/*     */ 
/* 153 */       if ((nestedPath != null) && (!resolvedPath.startsWith(nestedPath)) && 
/* 154 */         (!resolvedPath.equals(nestedPath.substring(0, nestedPath.length() - 1)))) {
/* 155 */         resolvedPath = nestedPath + resolvedPath;
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 160 */       this.status = new BindStatus(getRequestContext(), resolvedPath, isHtmlEscape());
/*     */     }
/*     */     catch (IllegalStateException ex) {
/* 163 */       throw new JspTagException(ex.getMessage());
/*     */     }
/*     */     
/*     */ 
/* 167 */     this.previousPageStatus = this.pageContext.getAttribute("status", 1);
/* 168 */     this.previousRequestStatus = this.pageContext.getAttribute("status", 2);
/*     */     
/*     */ 
/*     */ 
/* 172 */     this.pageContext.removeAttribute("status", 1);
/* 173 */     this.pageContext.setAttribute("status", this.status, 2);
/*     */     
/* 175 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public int doEndTag()
/*     */   {
/* 181 */     if (this.previousPageStatus != null) {
/* 182 */       this.pageContext.setAttribute("status", this.previousPageStatus, 1);
/*     */     }
/* 184 */     if (this.previousRequestStatus != null) {
/* 185 */       this.pageContext.setAttribute("status", this.previousRequestStatus, 2);
/*     */     }
/*     */     else {
/* 188 */       this.pageContext.removeAttribute("status", 2);
/*     */     }
/* 190 */     return 6;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private BindStatus getStatus()
/*     */   {
/* 198 */     Assert.state(this.status != null, "No current BindStatus");
/* 199 */     return this.status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public final String getProperty()
/*     */   {
/* 211 */     return getStatus().getExpression();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public final Errors getErrors()
/*     */   {
/* 221 */     return getStatus().getErrors();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public final PropertyEditor getEditor()
/*     */   {
/* 227 */     return getStatus().getEditor();
/*     */   }
/*     */   
/*     */ 
/*     */   public void doFinally()
/*     */   {
/* 233 */     super.doFinally();
/* 234 */     this.status = null;
/* 235 */     this.previousPageStatus = null;
/* 236 */     this.previousRequestStatus = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\BindTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */