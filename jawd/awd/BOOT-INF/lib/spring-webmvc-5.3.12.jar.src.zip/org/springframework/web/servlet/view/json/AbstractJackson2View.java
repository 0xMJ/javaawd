/*     */ package org.springframework.web.servlet.view.json;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonView;
/*     */ import com.fasterxml.jackson.core.JsonEncoding;
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.ObjectWriter;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.http.converter.json.MappingJacksonValue;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.view.AbstractView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJackson2View
/*     */   extends AbstractView
/*     */ {
/*     */   private ObjectMapper objectMapper;
/*  57 */   private JsonEncoding encoding = JsonEncoding.UTF8;
/*     */   
/*     */   @Nullable
/*     */   private Boolean prettyPrint;
/*     */   
/*  62 */   private boolean disableCaching = true;
/*     */   
/*  64 */   protected boolean updateContentLength = false;
/*     */   
/*     */   protected AbstractJackson2View(ObjectMapper objectMapper, String contentType)
/*     */   {
/*  68 */     this.objectMapper = objectMapper;
/*  69 */     configurePrettyPrint();
/*  70 */     setContentType(contentType);
/*  71 */     setExposePathVariables(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/*  82 */     this.objectMapper = objectMapper;
/*  83 */     configurePrettyPrint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final ObjectMapper getObjectMapper()
/*     */   {
/*  90 */     return this.objectMapper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncoding(JsonEncoding encoding)
/*     */   {
/*  98 */     Assert.notNull(encoding, "'encoding' must not be null");
/*  99 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final JsonEncoding getEncoding()
/*     */   {
/* 106 */     return this.encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrettyPrint(boolean prettyPrint)
/*     */   {
/* 119 */     this.prettyPrint = Boolean.valueOf(prettyPrint);
/* 120 */     configurePrettyPrint();
/*     */   }
/*     */   
/*     */   private void configurePrettyPrint() {
/* 124 */     if (this.prettyPrint != null) {
/* 125 */       this.objectMapper.configure(SerializationFeature.INDENT_OUTPUT, this.prettyPrint.booleanValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDisableCaching(boolean disableCaching)
/*     */   {
/* 134 */     this.disableCaching = disableCaching;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUpdateContentLength(boolean updateContentLength)
/*     */   {
/* 144 */     this.updateContentLength = updateContentLength;
/*     */   }
/*     */   
/*     */   protected void prepareResponse(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 149 */     setResponseContentType(request, response);
/* 150 */     response.setCharacterEncoding(this.encoding.getJavaName());
/* 151 */     if (this.disableCaching) {
/* 152 */       response.addHeader("Cache-Control", "no-store");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 160 */     ByteArrayOutputStream temporaryStream = null;
/*     */     OutputStream stream;
/*     */     OutputStream stream;
/* 163 */     if (this.updateContentLength) {
/* 164 */       temporaryStream = createTemporaryOutputStream();
/* 165 */       stream = temporaryStream;
/*     */     }
/*     */     else {
/* 168 */       stream = response.getOutputStream();
/*     */     }
/*     */     
/* 171 */     Object value = filterAndWrapModel(model, request);
/* 172 */     writeContent(stream, value);
/*     */     
/* 174 */     if (temporaryStream != null) {
/* 175 */       writeToResponse(response, temporaryStream);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object filterAndWrapModel(Map<String, Object> model, HttpServletRequest request)
/*     */   {
/* 186 */     Object value = filterModel(model);
/* 187 */     Class<?> serializationView = (Class)model.get(JsonView.class.getName());
/* 188 */     FilterProvider filters = (FilterProvider)model.get(FilterProvider.class.getName());
/* 189 */     if ((serializationView != null) || (filters != null)) {
/* 190 */       MappingJacksonValue container = new MappingJacksonValue(value);
/* 191 */       if (serializationView != null) {
/* 192 */         container.setSerializationView(serializationView);
/*     */       }
/* 194 */       if (filters != null) {
/* 195 */         container.setFilters(filters);
/*     */       }
/* 197 */       value = container;
/*     */     }
/* 199 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeContent(OutputStream stream, Object object)
/*     */     throws IOException
/*     */   {
/* 209 */     JsonGenerator generator = this.objectMapper.getFactory().createGenerator(stream, this.encoding);Throwable localThrowable3 = null;
/* 210 */     try { writePrefix(generator, object);
/*     */       
/* 212 */       Object value = object;
/* 213 */       Class<?> serializationView = null;
/* 214 */       FilterProvider filters = null;
/*     */       
/* 216 */       if ((value instanceof MappingJacksonValue)) {
/* 217 */         MappingJacksonValue container = (MappingJacksonValue)value;
/* 218 */         value = container.getValue();
/* 219 */         serializationView = container.getSerializationView();
/* 220 */         filters = container.getFilters();
/*     */       }
/*     */       
/*     */ 
/* 224 */       ObjectWriter objectWriter = serializationView != null ? this.objectMapper.writerWithView(serializationView) : this.objectMapper.writer();
/* 225 */       if (filters != null) {
/* 226 */         objectWriter = objectWriter.with(filters);
/*     */       }
/* 228 */       objectWriter.writeValue(generator, value);
/*     */       
/* 230 */       writeSuffix(generator, object);
/* 231 */       generator.flush();
/*     */     }
/*     */     catch (Throwable localThrowable1)
/*     */     {
/* 209 */       localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 232 */       if (generator != null) if (localThrowable3 != null) try { generator.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else generator.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public abstract void setModelKey(String paramString);
/*     */   
/*     */   protected abstract Object filterModel(Map<String, Object> paramMap);
/*     */   
/*     */   protected void writePrefix(JsonGenerator generator, Object object)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */   protected void writeSuffix(JsonGenerator generator, Object object)
/*     */     throws IOException
/*     */   {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\json\AbstractJackson2View.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */