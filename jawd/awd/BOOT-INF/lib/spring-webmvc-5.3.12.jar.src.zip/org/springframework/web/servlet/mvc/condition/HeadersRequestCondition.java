/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.cors.CorsUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HeadersRequestCondition
/*     */   extends AbstractRequestCondition<HeadersRequestCondition>
/*     */ {
/*  45 */   private static final HeadersRequestCondition PRE_FLIGHT_MATCH = new HeadersRequestCondition(new String[0]);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Set<HeaderExpression> expressions;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeadersRequestCondition(String... headers)
/*     */   {
/*  59 */     this.expressions = parseExpressions(headers);
/*     */   }
/*     */   
/*     */   private static Set<HeaderExpression> parseExpressions(String... headers) {
/*  63 */     Set<HeaderExpression> result = null;
/*  64 */     if (!ObjectUtils.isEmpty(headers))
/*  65 */       for (String header : headers) {
/*  66 */         HeaderExpression expr = new HeaderExpression(header);
/*  67 */         if ((!"Accept".equalsIgnoreCase(expr.name)) && (!"Content-Type".equalsIgnoreCase(expr.name)))
/*     */         {
/*     */ 
/*  70 */           result = result != null ? result : new LinkedHashSet(headers.length);
/*  71 */           result.add(expr);
/*     */         }
/*     */       }
/*  74 */     return result != null ? result : Collections.emptySet();
/*     */   }
/*     */   
/*     */   private HeadersRequestCondition(Set<HeaderExpression> conditions) {
/*  78 */     this.expressions = conditions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<NameValueExpression<String>> getExpressions()
/*     */   {
/*  86 */     return new LinkedHashSet(this.expressions);
/*     */   }
/*     */   
/*     */   protected Collection<HeaderExpression> getContent()
/*     */   {
/*  91 */     return this.expressions;
/*     */   }
/*     */   
/*     */   protected String getToStringInfix()
/*     */   {
/*  96 */     return " && ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HeadersRequestCondition combine(HeadersRequestCondition other)
/*     */   {
/* 105 */     if ((isEmpty()) && (other.isEmpty())) {
/* 106 */       return this;
/*     */     }
/* 108 */     if (other.isEmpty()) {
/* 109 */       return this;
/*     */     }
/* 111 */     if (isEmpty()) {
/* 112 */       return other;
/*     */     }
/* 114 */     Set<HeaderExpression> set = new LinkedHashSet(this.expressions);
/* 115 */     set.addAll(other.expressions);
/* 116 */     return new HeadersRequestCondition(set);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public HeadersRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 126 */     if (CorsUtils.isPreFlightRequest(request)) {
/* 127 */       return PRE_FLIGHT_MATCH;
/*     */     }
/* 129 */     for (HeaderExpression expression : this.expressions) {
/* 130 */       if (!expression.match(request)) {
/* 131 */         return null;
/*     */       }
/*     */     }
/* 134 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(HeadersRequestCondition other, HttpServletRequest request)
/*     */   {
/* 150 */     int result = other.expressions.size() - this.expressions.size();
/* 151 */     if (result != 0) {
/* 152 */       return result;
/*     */     }
/* 154 */     return (int)(getValueMatchCount(other.expressions) - getValueMatchCount(this.expressions));
/*     */   }
/*     */   
/*     */   private long getValueMatchCount(Set<HeaderExpression> expressions) {
/* 158 */     long count = 0L;
/* 159 */     for (HeaderExpression e : expressions) {
/* 160 */       if ((e.getValue() != null) && (!e.isNegated())) {
/* 161 */         count += 1L;
/*     */       }
/*     */     }
/* 164 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class HeaderExpression
/*     */     extends AbstractNameValueExpression<String>
/*     */   {
/*     */     HeaderExpression(String expression)
/*     */     {
/* 174 */       super();
/*     */     }
/*     */     
/*     */     protected boolean isCaseSensitiveName()
/*     */     {
/* 179 */       return false;
/*     */     }
/*     */     
/*     */     protected String parseValue(String valueExpression)
/*     */     {
/* 184 */       return valueExpression;
/*     */     }
/*     */     
/*     */     protected boolean matchName(HttpServletRequest request)
/*     */     {
/* 189 */       return request.getHeader(this.name) != null;
/*     */     }
/*     */     
/*     */     protected boolean matchValue(HttpServletRequest request)
/*     */     {
/* 194 */       return ObjectUtils.nullSafeEquals(this.value, request.getHeader(this.name));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\condition\HeadersRequestCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */