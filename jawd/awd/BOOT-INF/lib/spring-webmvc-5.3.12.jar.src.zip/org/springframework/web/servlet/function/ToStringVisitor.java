/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ToStringVisitor
/*     */   implements RouterFunctions.Visitor, RequestPredicates.Visitor
/*     */ {
/*  36 */   private final StringBuilder builder = new StringBuilder();
/*     */   
/*  38 */   private int indent = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startNested(RequestPredicate predicate)
/*     */   {
/*  45 */     indent();
/*  46 */     predicate.accept(this);
/*  47 */     this.builder.append(" => {\n");
/*  48 */     this.indent += 1;
/*     */   }
/*     */   
/*     */   public void endNested(RequestPredicate predicate)
/*     */   {
/*  53 */     this.indent -= 1;
/*  54 */     indent();
/*  55 */     this.builder.append("}\n");
/*     */   }
/*     */   
/*     */   public void route(RequestPredicate predicate, HandlerFunction<?> handlerFunction)
/*     */   {
/*  60 */     indent();
/*  61 */     predicate.accept(this);
/*  62 */     this.builder.append(" -> ");
/*  63 */     this.builder.append(handlerFunction).append('\n');
/*     */   }
/*     */   
/*     */   public void resources(Function<ServerRequest, Optional<Resource>> lookupFunction)
/*     */   {
/*  68 */     indent();
/*  69 */     this.builder.append(lookupFunction).append('\n');
/*     */   }
/*     */   
/*     */ 
/*     */   public void attributes(Map<String, Object> attributes) {}
/*     */   
/*     */ 
/*     */   public void unknown(RouterFunction<?> routerFunction)
/*     */   {
/*  78 */     indent();
/*  79 */     this.builder.append(routerFunction);
/*     */   }
/*     */   
/*     */   private void indent() {
/*  83 */     for (int i = 0; i < this.indent; i++) {
/*  84 */       this.builder.append(' ');
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void method(Set<HttpMethod> methods)
/*     */   {
/*  93 */     if (methods.size() == 1) {
/*  94 */       this.builder.append(methods.iterator().next());
/*     */     }
/*     */     else {
/*  97 */       this.builder.append(methods);
/*     */     }
/*     */   }
/*     */   
/*     */   public void path(String pattern)
/*     */   {
/* 103 */     this.builder.append(pattern);
/*     */   }
/*     */   
/*     */   public void pathExtension(String extension)
/*     */   {
/* 108 */     this.builder.append(String.format("*.%s", new Object[] { extension }));
/*     */   }
/*     */   
/*     */   public void header(String name, String value)
/*     */   {
/* 113 */     this.builder.append(String.format("%s: %s", new Object[] { name, value }));
/*     */   }
/*     */   
/*     */   public void param(String name, String value)
/*     */   {
/* 118 */     this.builder.append(String.format("?%s == %s", new Object[] { name, value }));
/*     */   }
/*     */   
/*     */   public void startAnd()
/*     */   {
/* 123 */     this.builder.append('(');
/*     */   }
/*     */   
/*     */   public void and()
/*     */   {
/* 128 */     this.builder.append(" && ");
/*     */   }
/*     */   
/*     */   public void endAnd()
/*     */   {
/* 133 */     this.builder.append(')');
/*     */   }
/*     */   
/*     */   public void startOr()
/*     */   {
/* 138 */     this.builder.append('(');
/*     */   }
/*     */   
/*     */   public void or()
/*     */   {
/* 143 */     this.builder.append(" || ");
/*     */   }
/*     */   
/*     */ 
/*     */   public void endOr()
/*     */   {
/* 149 */     this.builder.append(')');
/*     */   }
/*     */   
/*     */   public void startNegate()
/*     */   {
/* 154 */     this.builder.append("!(");
/*     */   }
/*     */   
/*     */   public void endNegate()
/*     */   {
/* 159 */     this.builder.append(')');
/*     */   }
/*     */   
/*     */   public void unknown(RequestPredicate predicate)
/*     */   {
/* 164 */     this.builder.append(predicate);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 169 */     String result = this.builder.toString();
/* 170 */     if (result.endsWith("\n")) {
/* 171 */       result = result.substring(0, result.length() - 1);
/*     */     }
/* 173 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\ToStringVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */