/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.event.ContextRefreshedEvent;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceUrlProvider
/*     */   implements ApplicationListener<ContextRefreshedEvent>, ApplicationContextAware
/*     */ {
/*  57 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private ApplicationContext applicationContext;
/*     */   
/*  62 */   private UrlPathHelper urlPathHelper = UrlPathHelper.defaultInstance;
/*     */   
/*  64 */   private PathMatcher pathMatcher = new AntPathMatcher();
/*     */   
/*  66 */   private final Map<String, ResourceHttpRequestHandler> handlerMap = new LinkedHashMap();
/*     */   
/*  68 */   private boolean autodetect = true;
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */     throws BeansException
/*     */   {
/*  73 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/*  82 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public UrlPathHelper getUrlPathHelper()
/*     */   {
/*  90 */     return this.urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPathMatcher(PathMatcher pathMatcher)
/*     */   {
/*  98 */     this.pathMatcher = pathMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PathMatcher getPathMatcher()
/*     */   {
/* 105 */     return this.pathMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHandlerMap(@Nullable Map<String, ResourceHttpRequestHandler> handlerMap)
/*     */   {
/* 115 */     if (handlerMap != null) {
/* 116 */       this.handlerMap.clear();
/* 117 */       this.handlerMap.putAll(handlerMap);
/* 118 */       this.autodetect = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, ResourceHttpRequestHandler> getHandlerMap()
/*     */   {
/* 127 */     return this.handlerMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAutodetect()
/*     */   {
/* 135 */     return this.autodetect;
/*     */   }
/*     */   
/*     */ 
/*     */   public void onApplicationEvent(ContextRefreshedEvent event)
/*     */   {
/* 141 */     if ((event.getApplicationContext() == this.applicationContext) && (isAutodetect())) {
/* 142 */       this.handlerMap.clear();
/* 143 */       detectResourceHandlers(this.applicationContext);
/* 144 */       if (!this.handlerMap.isEmpty()) {
/* 145 */         this.autodetect = false;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void detectResourceHandlers(ApplicationContext appContext) {
/* 151 */     Map<String, SimpleUrlHandlerMapping> beans = appContext.getBeansOfType(SimpleUrlHandlerMapping.class);
/* 152 */     List<SimpleUrlHandlerMapping> mappings = new ArrayList(beans.values());
/* 153 */     AnnotationAwareOrderComparator.sort(mappings);
/*     */     
/* 155 */     for (Iterator localIterator1 = mappings.iterator(); localIterator1.hasNext();) { mapping = (SimpleUrlHandlerMapping)localIterator1.next();
/* 156 */       for (String pattern : mapping.getHandlerMap().keySet()) {
/* 157 */         Object handler = mapping.getHandlerMap().get(pattern);
/* 158 */         if ((handler instanceof ResourceHttpRequestHandler)) {
/* 159 */           ResourceHttpRequestHandler resourceHandler = (ResourceHttpRequestHandler)handler;
/* 160 */           this.handlerMap.put(pattern, resourceHandler);
/*     */         }
/*     */       }
/*     */     }
/*     */     SimpleUrlHandlerMapping mapping;
/* 165 */     if (this.handlerMap.isEmpty()) {
/* 166 */       this.logger.trace("No resource handling mappings found");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public final String getForRequestUrl(HttpServletRequest request, String requestUrl)
/*     */   {
/* 180 */     int prefixIndex = getLookupPathIndex(request);
/* 181 */     int suffixIndex = getEndPathIndex(requestUrl);
/* 182 */     if (prefixIndex >= suffixIndex) {
/* 183 */       return null;
/*     */     }
/* 185 */     String prefix = requestUrl.substring(0, prefixIndex);
/* 186 */     String suffix = requestUrl.substring(suffixIndex);
/* 187 */     String lookupPath = requestUrl.substring(prefixIndex, suffixIndex);
/* 188 */     String resolvedLookupPath = getForLookupPath(lookupPath);
/* 189 */     return resolvedLookupPath != null ? prefix + resolvedLookupPath + suffix : null;
/*     */   }
/*     */   
/*     */   private int getLookupPathIndex(HttpServletRequest request) {
/* 193 */     UrlPathHelper pathHelper = getUrlPathHelper();
/* 194 */     if (request.getAttribute(UrlPathHelper.PATH_ATTRIBUTE) == null) {
/* 195 */       pathHelper.resolveAndCacheLookupPath(request);
/*     */     }
/* 197 */     String requestUri = pathHelper.getRequestUri(request);
/* 198 */     String lookupPath = UrlPathHelper.getResolvedLookupPath(request);
/* 199 */     return requestUri.indexOf(lookupPath);
/*     */   }
/*     */   
/*     */   private int getEndPathIndex(String lookupPath) {
/* 203 */     int suffixIndex = lookupPath.length();
/* 204 */     int queryIndex = lookupPath.indexOf('?');
/* 205 */     if (queryIndex > 0) {
/* 206 */       suffixIndex = queryIndex;
/*     */     }
/* 208 */     int hashIndex = lookupPath.indexOf('#');
/* 209 */     if (hashIndex > 0) {
/* 210 */       suffixIndex = Math.min(suffixIndex, hashIndex);
/*     */     }
/* 212 */     return suffixIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public final String getForLookupPath(String lookupPath)
/*     */   {
/*     */     String previous;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     do
/*     */     {
/* 232 */       previous = lookupPath;
/* 233 */       lookupPath = StringUtils.replace(lookupPath, "//", "/");
/* 234 */     } while (!lookupPath.equals(previous));
/*     */     
/* 236 */     List<String> matchingPatterns = new ArrayList();
/* 237 */     for (Iterator localIterator = this.handlerMap.keySet().iterator(); localIterator.hasNext();) { pattern = (String)localIterator.next();
/* 238 */       if (getPathMatcher().match(pattern, lookupPath)) {
/* 239 */         matchingPatterns.add(pattern);
/*     */       }
/*     */     }
/*     */     String pattern;
/* 243 */     if (!matchingPatterns.isEmpty()) {
/* 244 */       Object patternComparator = getPathMatcher().getPatternComparator(lookupPath);
/* 245 */       matchingPatterns.sort((Comparator)patternComparator);
/* 246 */       for (String pattern : matchingPatterns) {
/* 247 */         String pathWithinMapping = getPathMatcher().extractPathWithinPattern(pattern, lookupPath);
/* 248 */         String pathMapping = lookupPath.substring(0, lookupPath.indexOf(pathWithinMapping));
/* 249 */         ResourceHttpRequestHandler handler = (ResourceHttpRequestHandler)this.handlerMap.get(pattern);
/* 250 */         ResourceResolverChain chain = new DefaultResourceResolverChain(handler.getResourceResolvers());
/* 251 */         String resolved = chain.resolveUrlPath(pathWithinMapping, handler.getLocations());
/* 252 */         if (resolved != null)
/*     */         {
/*     */ 
/* 255 */           return pathMapping + resolved;
/*     */         }
/*     */       }
/*     */     }
/* 259 */     if (this.logger.isTraceEnabled()) {
/* 260 */       this.logger.trace("No match for \"" + lookupPath + "\"");
/*     */     }
/*     */     
/* 263 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\ResourceUrlProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */