/*     */ package org.springframework.web.servlet.view.xml;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.oxm.Marshaller;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.servlet.view.AbstractView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarshallingView
/*     */   extends AbstractView
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "application/xml";
/*     */   @Nullable
/*     */   private Marshaller marshaller;
/*     */   @Nullable
/*     */   private String modelKey;
/*     */   
/*     */   public MarshallingView()
/*     */   {
/*  67 */     setContentType("application/xml");
/*  68 */     setExposePathVariables(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public MarshallingView(Marshaller marshaller)
/*     */   {
/*  75 */     this();
/*  76 */     Assert.notNull(marshaller, "Marshaller must not be null");
/*  77 */     this.marshaller = marshaller;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMarshaller(Marshaller marshaller)
/*     */   {
/*  85 */     this.marshaller = marshaller;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setModelKey(String modelKey)
/*     */   {
/*  94 */     this.modelKey = modelKey;
/*     */   }
/*     */   
/*     */   protected void initApplicationContext()
/*     */   {
/*  99 */     Assert.notNull(this.marshaller, "Property 'marshaller' is required");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 107 */     Object toBeMarshalled = locateToBeMarshalled(model);
/* 108 */     if (toBeMarshalled == null) {
/* 109 */       throw new IllegalStateException("Unable to locate object to be marshalled in model: " + model);
/*     */     }
/*     */     
/* 112 */     Assert.state(this.marshaller != null, "No Marshaller set");
/* 113 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(1024);
/* 114 */     this.marshaller.marshal(toBeMarshalled, new StreamResult(baos));
/*     */     
/* 116 */     setResponseContentType(request, response);
/* 117 */     response.setContentLength(baos.size());
/* 118 */     baos.writeTo(response.getOutputStream());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object locateToBeMarshalled(Map<String, Object> model)
/*     */     throws IllegalStateException
/*     */   {
/* 134 */     if (this.modelKey != null) {
/* 135 */       value = model.get(this.modelKey);
/* 136 */       if (value == null) {
/* 137 */         throw new IllegalStateException("Model contains no object with key [" + this.modelKey + "]");
/*     */       }
/* 139 */       if (!isEligibleForMarshalling(this.modelKey, value)) {
/* 140 */         throw new IllegalStateException("Model object [" + value + "] retrieved via key [" + this.modelKey + "] is not supported by the Marshaller");
/*     */       }
/*     */       
/* 143 */       return value;
/*     */     }
/* 145 */     for (Object value = model.entrySet().iterator(); ((Iterator)value).hasNext();) { Map.Entry<String, Object> entry = (Map.Entry)((Iterator)value).next();
/* 146 */       Object value = entry.getValue();
/* 147 */       if ((value != null) && ((model.size() == 1) || (!(value instanceof BindingResult))) && 
/* 148 */         (isEligibleForMarshalling((String)entry.getKey(), value))) {
/* 149 */         return value;
/*     */       }
/*     */     }
/* 152 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isEligibleForMarshalling(String modelKey, Object value)
/*     */   {
/* 166 */     Assert.state(this.marshaller != null, "No Marshaller set");
/* 167 */     Class<?> classToCheck = value.getClass();
/* 168 */     if ((value instanceof JAXBElement)) {
/* 169 */       classToCheck = ((JAXBElement)value).getDeclaredType();
/*     */     }
/* 171 */     return this.marshaller.supports(classToCheck);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\xml\MarshallingView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */