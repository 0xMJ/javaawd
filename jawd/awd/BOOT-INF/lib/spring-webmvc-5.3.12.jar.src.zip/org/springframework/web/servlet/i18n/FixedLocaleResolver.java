/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FixedLocaleResolver
/*     */   extends AbstractLocaleContextResolver
/*     */ {
/*     */   public FixedLocaleResolver()
/*     */   {
/*  51 */     setDefaultLocale(Locale.getDefault());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FixedLocaleResolver(Locale locale)
/*     */   {
/*  59 */     setDefaultLocale(locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FixedLocaleResolver(Locale locale, TimeZone timeZone)
/*     */   {
/*  68 */     setDefaultLocale(locale);
/*  69 */     setDefaultTimeZone(timeZone);
/*     */   }
/*     */   
/*     */ 
/*     */   public Locale resolveLocale(HttpServletRequest request)
/*     */   {
/*  75 */     Locale locale = getDefaultLocale();
/*  76 */     if (locale == null) {
/*  77 */       locale = Locale.getDefault();
/*     */     }
/*  79 */     return locale;
/*     */   }
/*     */   
/*     */   public LocaleContext resolveLocaleContext(HttpServletRequest request)
/*     */   {
/*  84 */     new TimeZoneAwareLocaleContext()
/*     */     {
/*     */       @Nullable
/*     */       public Locale getLocale() {
/*  88 */         return FixedLocaleResolver.this.getDefaultLocale();
/*     */       }
/*     */       
/*     */       public TimeZone getTimeZone() {
/*  92 */         return FixedLocaleResolver.this.getDefaultTimeZone();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLocaleContext(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable LocaleContext localeContext)
/*     */   {
/* 101 */     throw new UnsupportedOperationException("Cannot change fixed locale - use a different locale resolution strategy");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\i18n\FixedLocaleResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */