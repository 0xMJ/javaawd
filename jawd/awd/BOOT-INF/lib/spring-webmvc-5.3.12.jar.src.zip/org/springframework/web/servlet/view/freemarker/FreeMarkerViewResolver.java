/*    */ package org.springframework.web.servlet.view.freemarker;
/*    */ 
/*    */ import org.springframework.web.servlet.view.AbstractTemplateViewResolver;
/*    */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FreeMarkerViewResolver
/*    */   extends AbstractTemplateViewResolver
/*    */ {
/*    */   public FreeMarkerViewResolver()
/*    */   {
/* 49 */     setViewClass(requiredViewClass());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FreeMarkerViewResolver(String prefix, String suffix)
/*    */   {
/* 60 */     this();
/* 61 */     setPrefix(prefix);
/* 62 */     setSuffix(suffix);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Class<?> requiredViewClass()
/*    */   {
/* 71 */     return FreeMarkerView.class;
/*    */   }
/*    */   
/*    */   protected AbstractUrlBasedView instantiateView()
/*    */   {
/* 76 */     return getViewClass() == FreeMarkerView.class ? new FreeMarkerView() : super.instantiateView();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\freemarker\FreeMarkerViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */