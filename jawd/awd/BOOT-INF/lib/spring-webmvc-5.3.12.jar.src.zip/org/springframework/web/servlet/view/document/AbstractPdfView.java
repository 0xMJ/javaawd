/*     */ package org.springframework.web.servlet.view.document;
/*     */ 
/*     */ import com.lowagie.text.Document;
/*     */ import com.lowagie.text.DocumentException;
/*     */ import com.lowagie.text.PageSize;
/*     */ import com.lowagie.text.pdf.PdfWriter;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.web.servlet.view.AbstractView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPdfView
/*     */   extends AbstractView
/*     */ {
/*     */   public AbstractPdfView()
/*     */   {
/*  61 */     setContentType("application/pdf");
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean generatesDownloadContent()
/*     */   {
/*  67 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*  75 */     ByteArrayOutputStream baos = createTemporaryOutputStream();
/*     */     
/*     */ 
/*  78 */     Document document = newDocument();
/*  79 */     PdfWriter writer = newWriter(document, baos);
/*  80 */     prepareWriter(model, writer, request);
/*  81 */     buildPdfMetadata(model, document, request);
/*     */     
/*     */ 
/*  84 */     document.open();
/*  85 */     buildPdfDocument(model, document, writer, request, response);
/*  86 */     document.close();
/*     */     
/*     */ 
/*  89 */     writeToResponse(response, baos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Document newDocument()
/*     */   {
/* 100 */     return new Document(PageSize.A4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PdfWriter newWriter(Document document, OutputStream os)
/*     */     throws DocumentException
/*     */   {
/* 111 */     return PdfWriter.getInstance(document, os);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prepareWriter(Map<String, Object> model, PdfWriter writer, HttpServletRequest request)
/*     */     throws DocumentException
/*     */   {
/* 132 */     writer.setViewerPreferences(getViewerPreferences());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getViewerPreferences()
/*     */   {
/* 146 */     return 2053;
/*     */   }
/*     */   
/*     */   protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {}
/*     */   
/*     */   protected abstract void buildPdfDocument(Map<String, Object> paramMap, Document paramDocument, PdfWriter paramPdfWriter, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*     */     throws Exception;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\document\AbstractPdfView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */