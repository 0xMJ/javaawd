/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.web.servlet.View;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UrlBasedViewResolver
/*     */   extends AbstractCachingViewResolver
/*     */   implements Ordered
/*     */ {
/*     */   public static final String REDIRECT_URL_PREFIX = "redirect:";
/*     */   public static final String FORWARD_URL_PREFIX = "forward:";
/*     */   @Nullable
/*     */   private Class<?> viewClass;
/* 110 */   private String prefix = "";
/*     */   
/* 112 */   private String suffix = "";
/*     */   
/*     */   @Nullable
/*     */   private String contentType;
/*     */   
/* 117 */   private boolean redirectContextRelative = true;
/*     */   
/* 119 */   private boolean redirectHttp10Compatible = true;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private String[] redirectHosts;
/*     */   
/*     */   @Nullable
/*     */   private String requestContextAttribute;
/*     */   
/* 128 */   private final Map<String, Object> staticAttributes = new HashMap();
/*     */   
/*     */   @Nullable
/*     */   private Boolean exposePathVariables;
/*     */   
/*     */   @Nullable
/*     */   private Boolean exposeContextBeansAsAttributes;
/*     */   
/*     */   @Nullable
/*     */   private String[] exposedContextBeanNames;
/*     */   
/*     */   @Nullable
/*     */   private String[] viewNames;
/*     */   
/* 142 */   private int order = Integer.MAX_VALUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setViewClass(@Nullable Class<?> viewClass)
/*     */   {
/* 154 */     if ((viewClass != null) && (!requiredViewClass().isAssignableFrom(viewClass)))
/*     */     {
/* 156 */       throw new IllegalArgumentException("Given view class [" + viewClass.getName() + "] is not of type [" + requiredViewClass().getName() + "]");
/*     */     }
/* 158 */     this.viewClass = viewClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Class<?> getViewClass()
/*     */   {
/* 167 */     return this.viewClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPrefix(@Nullable String prefix)
/*     */   {
/* 174 */     this.prefix = (prefix != null ? prefix : "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getPrefix()
/*     */   {
/* 181 */     return this.prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSuffix(@Nullable String suffix)
/*     */   {
/* 188 */     this.suffix = (suffix != null ? suffix : "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getSuffix()
/*     */   {
/* 195 */     return this.suffix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentType(@Nullable String contentType)
/*     */   {
/* 204 */     this.contentType = contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getContentType()
/*     */   {
/* 212 */     return this.contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRedirectContextRelative(boolean redirectContextRelative)
/*     */   {
/* 228 */     this.redirectContextRelative = redirectContextRelative;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isRedirectContextRelative()
/*     */   {
/* 237 */     return this.redirectContextRelative;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRedirectHttp10Compatible(boolean redirectHttp10Compatible)
/*     */   {
/* 255 */     this.redirectHttp10Compatible = redirectHttp10Compatible;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isRedirectHttp10Compatible()
/*     */   {
/* 262 */     return this.redirectHttp10Compatible;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRedirectHosts(@Nullable String... redirectHosts)
/*     */   {
/* 276 */     this.redirectHosts = redirectHosts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public String[] getRedirectHosts()
/*     */   {
/* 285 */     return this.redirectHosts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRequestContextAttribute(@Nullable String requestContextAttribute)
/*     */   {
/* 294 */     this.requestContextAttribute = requestContextAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getRequestContextAttribute()
/*     */   {
/* 302 */     return this.requestContextAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttributes(Properties props)
/*     */   {
/* 317 */     CollectionUtils.mergePropertiesIntoMap(props, this.staticAttributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttributesMap(@Nullable Map<String, ?> attributes)
/*     */   {
/* 328 */     if (attributes != null) {
/* 329 */       this.staticAttributes.putAll(attributes);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getAttributesMap()
/*     */   {
/* 341 */     return this.staticAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExposePathVariables(@Nullable Boolean exposePathVariables)
/*     */   {
/* 359 */     this.exposePathVariables = exposePathVariables;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Boolean getExposePathVariables()
/*     */   {
/* 367 */     return this.exposePathVariables;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExposeContextBeansAsAttributes(boolean exposeContextBeansAsAttributes)
/*     */   {
/* 380 */     this.exposeContextBeansAsAttributes = Boolean.valueOf(exposeContextBeansAsAttributes);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected Boolean getExposeContextBeansAsAttributes() {
/* 385 */     return this.exposeContextBeansAsAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExposedContextBeanNames(@Nullable String... exposedContextBeanNames)
/*     */   {
/* 395 */     this.exposedContextBeanNames = exposedContextBeanNames;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected String[] getExposedContextBeanNames() {
/* 400 */     return this.exposedContextBeanNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setViewNames(@Nullable String... viewNames)
/*     */   {
/* 411 */     this.viewNames = viewNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String[] getViewNames()
/*     */   {
/* 420 */     return this.viewNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/* 429 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 434 */     return this.order;
/*     */   }
/*     */   
/*     */   protected void initApplicationContext()
/*     */   {
/* 439 */     super.initApplicationContext();
/* 440 */     if (getViewClass() == null) {
/* 441 */       throw new IllegalArgumentException("Property 'viewClass' is required");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getCacheKey(String viewName, Locale locale)
/*     */   {
/* 452 */     return viewName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected View createView(String viewName, Locale locale)
/*     */     throws Exception
/*     */   {
/* 467 */     if (!canHandle(viewName, locale)) {
/* 468 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 472 */     if (viewName.startsWith("redirect:")) {
/* 473 */       String redirectUrl = viewName.substring("redirect:".length());
/*     */       
/* 475 */       RedirectView view = new RedirectView(redirectUrl, isRedirectContextRelative(), isRedirectHttp10Compatible());
/* 476 */       String[] hosts = getRedirectHosts();
/* 477 */       if (hosts != null) {
/* 478 */         view.setHosts(hosts);
/*     */       }
/* 480 */       return applyLifecycleMethods("redirect:", view);
/*     */     }
/*     */     
/*     */ 
/* 484 */     if (viewName.startsWith("forward:")) {
/* 485 */       String forwardUrl = viewName.substring("forward:".length());
/* 486 */       InternalResourceView view = new InternalResourceView(forwardUrl);
/* 487 */       return applyLifecycleMethods("forward:", view);
/*     */     }
/*     */     
/*     */ 
/* 491 */     return super.createView(viewName, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean canHandle(String viewName, Locale locale)
/*     */   {
/* 505 */     String[] viewNames = getViewNames();
/* 506 */     return (viewNames == null) || (PatternMatchUtils.simpleMatch(viewNames, viewName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> requiredViewClass()
/*     */   {
/* 516 */     return AbstractUrlBasedView.class;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractUrlBasedView instantiateView()
/*     */   {
/* 527 */     Class<?> viewClass = getViewClass();
/* 528 */     Assert.state(viewClass != null, "No view class");
/* 529 */     return (AbstractUrlBasedView)BeanUtils.instantiateClass(viewClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected View loadView(String viewName, Locale locale)
/*     */     throws Exception
/*     */   {
/* 549 */     AbstractUrlBasedView view = buildView(viewName);
/* 550 */     View result = applyLifecycleMethods(viewName, view);
/* 551 */     return view.checkResource(locale) ? result : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractUrlBasedView buildView(String viewName)
/*     */     throws Exception
/*     */   {
/* 569 */     AbstractUrlBasedView view = instantiateView();
/* 570 */     view.setUrl(getPrefix() + viewName + getSuffix());
/* 571 */     view.setAttributesMap(getAttributesMap());
/*     */     
/* 573 */     String contentType = getContentType();
/* 574 */     if (contentType != null) {
/* 575 */       view.setContentType(contentType);
/*     */     }
/*     */     
/* 578 */     String requestContextAttribute = getRequestContextAttribute();
/* 579 */     if (requestContextAttribute != null) {
/* 580 */       view.setRequestContextAttribute(requestContextAttribute);
/*     */     }
/*     */     
/* 583 */     Boolean exposePathVariables = getExposePathVariables();
/* 584 */     if (exposePathVariables != null) {
/* 585 */       view.setExposePathVariables(exposePathVariables.booleanValue());
/*     */     }
/* 587 */     Boolean exposeContextBeansAsAttributes = getExposeContextBeansAsAttributes();
/* 588 */     if (exposeContextBeansAsAttributes != null) {
/* 589 */       view.setExposeContextBeansAsAttributes(exposeContextBeansAsAttributes.booleanValue());
/*     */     }
/* 591 */     String[] exposedContextBeanNames = getExposedContextBeanNames();
/* 592 */     if (exposedContextBeanNames != null) {
/* 593 */       view.setExposedContextBeanNames(exposedContextBeanNames);
/*     */     }
/*     */     
/* 596 */     return view;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected View applyLifecycleMethods(String viewName, AbstractUrlBasedView view)
/*     */   {
/* 613 */     ApplicationContext context = getApplicationContext();
/* 614 */     if (context != null) {
/* 615 */       Object initialized = context.getAutowireCapableBeanFactory().initializeBean(view, viewName);
/* 616 */       if ((initialized instanceof View)) {
/* 617 */         return (View)initialized;
/*     */       }
/*     */     }
/* 620 */     return view;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\UrlBasedViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */