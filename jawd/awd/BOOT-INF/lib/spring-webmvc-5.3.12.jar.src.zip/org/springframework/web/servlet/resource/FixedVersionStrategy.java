/*    */ package org.springframework.web.servlet.resource;
/*    */ 
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixedVersionStrategy
/*    */   extends AbstractVersionStrategy
/*    */ {
/*    */   private final String version;
/*    */   
/*    */   public FixedVersionStrategy(String version)
/*    */   {
/* 44 */     super(new AbstractVersionStrategy.PrefixVersionPathStrategy(version));
/* 45 */     this.version = version;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getResourceVersion(Resource resource)
/*    */   {
/* 51 */     return this.version;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\FixedVersionStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */