/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Scanner;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.DigestUtils;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class AppCacheManifestTransformer
/*     */   extends ResourceTransformerSupport
/*     */ {
/*     */   private static final String MANIFEST_HEADER = "CACHE MANIFEST";
/*     */   private static final String CACHE_HEADER = "CACHE:";
/*  75 */   private static final Collection<String> MANIFEST_SECTION_HEADERS = Arrays.asList(new String[] { "CACHE MANIFEST", "NETWORK:", "FALLBACK:", "CACHE:" });
/*     */   
/*  77 */   private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */   
/*  79 */   private static final Log logger = LogFactory.getLog(AppCacheManifestTransformer.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private final String fileExtension;
/*     */   
/*     */ 
/*     */ 
/*     */   public AppCacheManifestTransformer()
/*     */   {
/*  89 */     this("appcache");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AppCacheManifestTransformer(String fileExtension)
/*     */   {
/*  97 */     this.fileExtension = fileExtension;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Resource transform(HttpServletRequest request, Resource resource, ResourceTransformerChain chain)
/*     */     throws IOException
/*     */   {
/* 105 */     resource = chain.transform(request, resource);
/* 106 */     if (!this.fileExtension.equals(StringUtils.getFilenameExtension(resource.getFilename()))) {
/* 107 */       return resource;
/*     */     }
/*     */     
/* 110 */     byte[] bytes = FileCopyUtils.copyToByteArray(resource.getInputStream());
/* 111 */     String content = new String(bytes, DEFAULT_CHARSET);
/*     */     
/* 113 */     if (!content.startsWith("CACHE MANIFEST")) {
/* 114 */       if (logger.isTraceEnabled()) {
/* 115 */         logger.trace("Skipping " + resource + ": Manifest does not start with 'CACHE MANIFEST'");
/*     */       }
/* 117 */       return resource;
/*     */     }
/*     */     
/*     */ 
/* 121 */     Scanner scanner = new Scanner(content);
/* 122 */     LineInfo previous = null;
/* 123 */     LineAggregator aggregator = new LineAggregator(resource, content);
/*     */     
/* 125 */     while (scanner.hasNext()) {
/* 126 */       String line = scanner.nextLine();
/* 127 */       LineInfo current = new LineInfo(line, previous);
/* 128 */       LineOutput lineOutput = processLine(current, request, resource, chain);
/* 129 */       aggregator.add(lineOutput);
/* 130 */       previous = current;
/*     */     }
/*     */     
/* 133 */     return aggregator.createResource();
/*     */   }
/*     */   
/*     */   private static byte[] getResourceBytes(Resource resource) throws IOException {
/* 137 */     return FileCopyUtils.copyToByteArray(resource.getInputStream());
/*     */   }
/*     */   
/*     */ 
/*     */   private LineOutput processLine(LineInfo info, HttpServletRequest request, Resource resource, ResourceTransformerChain transformerChain)
/*     */   {
/* 143 */     if (!info.isLink()) {
/* 144 */       return new LineOutput(info.getLine(), null);
/*     */     }
/*     */     
/*     */ 
/* 148 */     Resource appCacheResource = transformerChain.getResolverChain().resolveResource(null, info.getLine(), Collections.singletonList(resource));
/*     */     
/* 150 */     String path = info.getLine();
/* 151 */     String absolutePath = toAbsolutePath(path, request);
/* 152 */     String newPath = resolveUrlPath(absolutePath, request, resource, transformerChain);
/*     */     
/* 154 */     return new LineOutput(newPath != null ? newPath : path, appCacheResource);
/*     */   }
/*     */   
/*     */ 
/*     */   private static class LineInfo
/*     */   {
/*     */     private final String line;
/*     */     
/*     */     private final boolean cacheSection;
/*     */     private final boolean link;
/*     */     
/*     */     public LineInfo(String line, @Nullable LineInfo previous)
/*     */     {
/* 167 */       this.line = line;
/* 168 */       this.cacheSection = initCacheSectionFlag(line, previous);
/* 169 */       this.link = iniLinkFlag(line, this.cacheSection);
/*     */     }
/*     */     
/*     */     private static boolean initCacheSectionFlag(String line, @Nullable LineInfo previousLine) {
/* 173 */       String trimmedLine = line.trim();
/* 174 */       if (AppCacheManifestTransformer.MANIFEST_SECTION_HEADERS.contains(trimmedLine)) {
/* 175 */         return trimmedLine.equals("CACHE:");
/*     */       }
/* 177 */       if (previousLine != null) {
/* 178 */         return previousLine.isCacheSection();
/*     */       }
/* 180 */       throw new IllegalStateException("Manifest does not start with CACHE MANIFEST: " + line);
/*     */     }
/*     */     
/*     */     private static boolean iniLinkFlag(String line, boolean isCacheSection)
/*     */     {
/* 185 */       return (isCacheSection) && (StringUtils.hasText(line)) && (!line.startsWith("#")) && 
/* 186 */         (!line.startsWith("//")) && (!hasScheme(line));
/*     */     }
/*     */     
/*     */     private static boolean hasScheme(String line) {
/* 190 */       int index = line.indexOf(':');
/* 191 */       return (line.startsWith("//")) || ((index > 0) && (!line.substring(0, index).contains("/")));
/*     */     }
/*     */     
/*     */     public String getLine() {
/* 195 */       return this.line;
/*     */     }
/*     */     
/*     */     public boolean isCacheSection() {
/* 199 */       return this.cacheSection;
/*     */     }
/*     */     
/*     */     public boolean isLink() {
/* 203 */       return this.link;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class LineOutput
/*     */   {
/*     */     private final String line;
/*     */     @Nullable
/*     */     private final Resource resource;
/*     */     
/*     */     public LineOutput(String line, @Nullable Resource resource)
/*     */     {
/* 216 */       this.line = line;
/* 217 */       this.resource = resource;
/*     */     }
/*     */     
/*     */     public String getLine() {
/* 221 */       return this.line;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Resource getResource() {
/* 226 */       return this.resource;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class LineAggregator
/*     */   {
/* 233 */     private final StringWriter writer = new StringWriter();
/*     */     
/*     */     private final ByteArrayOutputStream baos;
/*     */     private final Resource resource;
/*     */     
/*     */     public LineAggregator(Resource resource, String content)
/*     */     {
/* 240 */       this.resource = resource;
/* 241 */       this.baos = new ByteArrayOutputStream(content.length());
/*     */     }
/*     */     
/*     */     public void add(AppCacheManifestTransformer.LineOutput lineOutput) throws IOException {
/* 245 */       this.writer.write(lineOutput.getLine() + "\n");
/*     */       
/*     */ 
/* 248 */       byte[] bytes = lineOutput.getResource() != null ? DigestUtils.md5Digest(AppCacheManifestTransformer.getResourceBytes(lineOutput.getResource())) : lineOutput.getLine().getBytes(AppCacheManifestTransformer.DEFAULT_CHARSET);
/* 249 */       this.baos.write(bytes);
/*     */     }
/*     */     
/*     */     public TransformedResource createResource() {
/* 253 */       String hash = DigestUtils.md5DigestAsHex(this.baos.toByteArray());
/* 254 */       this.writer.write("\n# Hash: " + hash);
/* 255 */       byte[] bytes = this.writer.toString().getBytes(AppCacheManifestTransformer.DEFAULT_CHARSET);
/* 256 */       return new TransformedResource(this.resource, bytes);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\AppCacheManifestTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */