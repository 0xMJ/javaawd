/*     */ package org.springframework.web.servlet;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandlerExecutionChain
/*     */ {
/*  43 */   private static final Log logger = LogFactory.getLog(HandlerExecutionChain.class);
/*     */   
/*     */   private final Object handler;
/*     */   
/*  47 */   private final List<HandlerInterceptor> interceptorList = new ArrayList();
/*     */   
/*  49 */   private int interceptorIndex = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HandlerExecutionChain(Object handler)
/*     */   {
/*  57 */     this(handler, (HandlerInterceptor[])null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HandlerExecutionChain(Object handler, @Nullable HandlerInterceptor... interceptors)
/*     */   {
/*  67 */     this(handler, interceptors != null ? Arrays.asList(interceptors) : Collections.emptyList());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HandlerExecutionChain(Object handler, List<HandlerInterceptor> interceptorList)
/*     */   {
/*  78 */     if ((handler instanceof HandlerExecutionChain)) {
/*  79 */       HandlerExecutionChain originalChain = (HandlerExecutionChain)handler;
/*  80 */       this.handler = originalChain.getHandler();
/*  81 */       this.interceptorList.addAll(originalChain.interceptorList);
/*     */     }
/*     */     else {
/*  84 */       this.handler = handler;
/*     */     }
/*  86 */     this.interceptorList.addAll(interceptorList);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getHandler()
/*     */   {
/*  94 */     return this.handler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addInterceptor(HandlerInterceptor interceptor)
/*     */   {
/* 101 */     this.interceptorList.add(interceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addInterceptor(int index, HandlerInterceptor interceptor)
/*     */   {
/* 109 */     this.interceptorList.add(index, interceptor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addInterceptors(HandlerInterceptor... interceptors)
/*     */   {
/* 116 */     CollectionUtils.mergeArrayIntoCollection(interceptors, this.interceptorList);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public HandlerInterceptor[] getInterceptors()
/*     */   {
/* 125 */     return !this.interceptorList.isEmpty() ? (HandlerInterceptor[])this.interceptorList.toArray(new HandlerInterceptor[0]) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<HandlerInterceptor> getInterceptorList()
/*     */   {
/* 134 */     return !this.interceptorList.isEmpty() ? Collections.unmodifiableList(this.interceptorList) : 
/* 135 */       Collections.emptyList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean applyPreHandle(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 146 */     for (int i = 0; i < this.interceptorList.size(); i++) {
/* 147 */       HandlerInterceptor interceptor = (HandlerInterceptor)this.interceptorList.get(i);
/* 148 */       if (!interceptor.preHandle(request, response, this.handler)) {
/* 149 */         triggerAfterCompletion(request, response, null);
/* 150 */         return false;
/*     */       }
/* 152 */       this.interceptorIndex = i;
/*     */     }
/* 154 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void applyPostHandle(HttpServletRequest request, HttpServletResponse response, @Nullable ModelAndView mv)
/*     */     throws Exception
/*     */   {
/* 163 */     for (int i = this.interceptorList.size() - 1; i >= 0; i--) {
/* 164 */       HandlerInterceptor interceptor = (HandlerInterceptor)this.interceptorList.get(i);
/* 165 */       interceptor.postHandle(request, response, this.handler, mv);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void triggerAfterCompletion(HttpServletRequest request, HttpServletResponse response, @Nullable Exception ex)
/*     */   {
/* 175 */     for (int i = this.interceptorIndex; i >= 0; i--) {
/* 176 */       HandlerInterceptor interceptor = (HandlerInterceptor)this.interceptorList.get(i);
/*     */       try {
/* 178 */         interceptor.afterCompletion(request, response, this.handler, ex);
/*     */       }
/*     */       catch (Throwable ex2) {
/* 181 */         logger.error("HandlerInterceptor.afterCompletion threw exception", ex2);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void applyAfterConcurrentHandlingStarted(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 190 */     for (int i = this.interceptorList.size() - 1; i >= 0; i--) {
/* 191 */       HandlerInterceptor interceptor = (HandlerInterceptor)this.interceptorList.get(i);
/* 192 */       if ((interceptor instanceof AsyncHandlerInterceptor)) {
/*     */         try {
/* 194 */           AsyncHandlerInterceptor asyncInterceptor = (AsyncHandlerInterceptor)interceptor;
/* 195 */           asyncInterceptor.afterConcurrentHandlingStarted(request, response, this.handler);
/*     */         }
/*     */         catch (Throwable ex) {
/* 198 */           if (logger.isErrorEnabled()) {
/* 199 */             logger.error("Interceptor [" + interceptor + "] failed in afterConcurrentHandlingStarted", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 212 */     return "HandlerExecutionChain with [" + getHandler() + "] and " + this.interceptorList.size() + " interceptors";
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\HandlerExecutionChain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */