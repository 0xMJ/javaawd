/*    */ package org.springframework.web.servlet.resource;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.ListIterator;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultResourceTransformerChain
/*    */   implements ResourceTransformerChain
/*    */ {
/*    */   private final ResourceResolverChain resolverChain;
/*    */   @Nullable
/*    */   private final ResourceTransformer transformer;
/*    */   @Nullable
/*    */   private final ResourceTransformerChain nextChain;
/*    */   
/*    */   public DefaultResourceTransformerChain(ResourceResolverChain resolverChain, @Nullable List<ResourceTransformer> transformers)
/*    */   {
/* 51 */     Assert.notNull(resolverChain, "ResourceResolverChain is required");
/* 52 */     this.resolverChain = resolverChain;
/* 53 */     transformers = transformers != null ? transformers : Collections.emptyList();
/* 54 */     DefaultResourceTransformerChain chain = initTransformerChain(resolverChain, new ArrayList(transformers));
/* 55 */     this.transformer = chain.transformer;
/* 56 */     this.nextChain = chain.nextChain;
/*    */   }
/*    */   
/*    */ 
/*    */   private DefaultResourceTransformerChain initTransformerChain(ResourceResolverChain resolverChain, ArrayList<ResourceTransformer> transformers)
/*    */   {
/* 62 */     DefaultResourceTransformerChain chain = new DefaultResourceTransformerChain(resolverChain, null, null);
/* 63 */     ListIterator<? extends ResourceTransformer> it = transformers.listIterator(transformers.size());
/* 64 */     while (it.hasPrevious()) {
/* 65 */       chain = new DefaultResourceTransformerChain(resolverChain, (ResourceTransformer)it.previous(), chain);
/*    */     }
/* 67 */     return chain;
/*    */   }
/*    */   
/*    */ 
/*    */   public DefaultResourceTransformerChain(ResourceResolverChain resolverChain, @Nullable ResourceTransformer transformer, @Nullable ResourceTransformerChain chain)
/*    */   {
/* 73 */     Assert.isTrue(((transformer == null) && (chain == null)) || ((transformer != null) && (chain != null)), "Both transformer and transformer chain must be null, or neither is");
/*    */     
/*    */ 
/* 76 */     this.resolverChain = resolverChain;
/* 77 */     this.transformer = transformer;
/* 78 */     this.nextChain = chain;
/*    */   }
/*    */   
/*    */ 
/*    */   public ResourceResolverChain getResolverChain()
/*    */   {
/* 84 */     return this.resolverChain;
/*    */   }
/*    */   
/*    */   public Resource transform(HttpServletRequest request, Resource resource) throws IOException
/*    */   {
/* 89 */     return (this.transformer != null) && (this.nextChain != null) ? this.transformer
/* 90 */       .transform(request, resource, this.nextChain) : resource;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\DefaultResourceTransformerChain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */