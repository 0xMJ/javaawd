/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ import org.springframework.web.cors.CorsUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RequestMethodsRequestCondition
/*     */   extends AbstractRequestCondition<RequestMethodsRequestCondition>
/*     */ {
/*  51 */   private static final Map<String, RequestMethodsRequestCondition> requestMethodConditionCache = CollectionUtils.newHashMap(RequestMethod.values().length);
/*  52 */   static { for (RequestMethod method : RequestMethod.values()) {
/*  53 */       requestMethodConditionCache.put(method.name(), new RequestMethodsRequestCondition(new RequestMethod[] { method }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestMethodsRequestCondition(RequestMethod... requestMethods)
/*     */   {
/*  68 */     this.methods = (ObjectUtils.isEmpty(requestMethods) ? Collections.emptySet() : new LinkedHashSet(Arrays.asList(requestMethods)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private RequestMethodsRequestCondition(Set<RequestMethod> methods)
/*     */   {
/*  75 */     this.methods = methods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<RequestMethod> getMethods()
/*     */   {
/*  83 */     return this.methods;
/*     */   }
/*     */   
/*     */   protected Collection<RequestMethod> getContent()
/*     */   {
/*  88 */     return this.methods;
/*     */   }
/*     */   
/*     */   protected String getToStringInfix()
/*     */   {
/*  93 */     return " || ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestMethodsRequestCondition combine(RequestMethodsRequestCondition other)
/*     */   {
/* 102 */     if ((isEmpty()) && (other.isEmpty())) {
/* 103 */       return this;
/*     */     }
/* 105 */     if (other.isEmpty()) {
/* 106 */       return this;
/*     */     }
/* 108 */     if (isEmpty()) {
/* 109 */       return other;
/*     */     }
/* 111 */     Set<RequestMethod> set = new LinkedHashSet(this.methods);
/* 112 */     set.addAll(other.methods);
/* 113 */     return new RequestMethodsRequestCondition(set);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public RequestMethodsRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 128 */     if (CorsUtils.isPreFlightRequest(request)) {
/* 129 */       return matchPreFlight(request);
/*     */     }
/*     */     
/* 132 */     if (getMethods().isEmpty()) {
/* 133 */       if ((RequestMethod.OPTIONS.name().equals(request.getMethod())) && 
/* 134 */         (!DispatcherType.ERROR.equals(request.getDispatcherType())))
/*     */       {
/* 136 */         return null;
/*     */       }
/* 138 */       return this;
/*     */     }
/*     */     
/* 141 */     return matchRequestMethod(request.getMethod());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private RequestMethodsRequestCondition matchPreFlight(HttpServletRequest request)
/*     */   {
/* 151 */     if (getMethods().isEmpty()) {
/* 152 */       return this;
/*     */     }
/* 154 */     String expectedMethod = request.getHeader("Access-Control-Request-Method");
/* 155 */     return matchRequestMethod(expectedMethod);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private RequestMethodsRequestCondition matchRequestMethod(String httpMethodValue)
/*     */   {
/*     */     try {
/* 162 */       RequestMethod requestMethod = RequestMethod.valueOf(httpMethodValue);
/* 163 */       if (getMethods().contains(requestMethod)) {
/* 164 */         return (RequestMethodsRequestCondition)requestMethodConditionCache.get(httpMethodValue);
/*     */       }
/* 166 */       if ((requestMethod.equals(RequestMethod.HEAD)) && (getMethods().contains(RequestMethod.GET))) {
/* 167 */         return (RequestMethodsRequestCondition)requestMethodConditionCache.get(HttpMethod.GET.name());
/*     */       }
/*     */     }
/*     */     catch (IllegalArgumentException localIllegalArgumentException) {}
/*     */     
/*     */ 
/* 173 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Set<RequestMethod> methods;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(RequestMethodsRequestCondition other, HttpServletRequest request)
/*     */   {
/* 189 */     if (other.methods.size() != this.methods.size()) {
/* 190 */       return other.methods.size() - this.methods.size();
/*     */     }
/* 192 */     if (this.methods.size() == 1) {
/* 193 */       if ((this.methods.contains(RequestMethod.HEAD)) && (other.methods.contains(RequestMethod.GET))) {
/* 194 */         return -1;
/*     */       }
/* 196 */       if ((this.methods.contains(RequestMethod.GET)) && (other.methods.contains(RequestMethod.HEAD))) {
/* 197 */         return 1;
/*     */       }
/*     */     }
/* 200 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\condition\RequestMethodsRequestCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */