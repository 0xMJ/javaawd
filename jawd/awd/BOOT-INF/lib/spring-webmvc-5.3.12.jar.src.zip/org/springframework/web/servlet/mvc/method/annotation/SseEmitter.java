/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SseEmitter
/*     */   extends ResponseBodyEmitter
/*     */ {
/*  43 */   private static final MediaType TEXT_PLAIN = new MediaType("text", "plain", StandardCharsets.UTF_8);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SseEmitter() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SseEmitter(Long timeout)
/*     */   {
/*  61 */     super(timeout);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void extendResponse(ServerHttpResponse outputMessage)
/*     */   {
/*  67 */     super.extendResponse(outputMessage);
/*     */     
/*  69 */     HttpHeaders headers = outputMessage.getHeaders();
/*  70 */     if (headers.getContentType() == null) {
/*  71 */       headers.setContentType(MediaType.TEXT_EVENT_STREAM);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void send(Object object)
/*     */     throws IOException
/*     */   {
/*  91 */     send(object, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void send(Object object, @Nullable MediaType mediaType)
/*     */     throws IOException
/*     */   {
/* 110 */     send(event().data(object, mediaType));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void send(SseEventBuilder builder)
/*     */     throws IOException
/*     */   {
/* 124 */     Set<ResponseBodyEmitter.DataWithMediaType> dataToSend = builder.build();
/* 125 */     synchronized (this) {
/* 126 */       for (ResponseBodyEmitter.DataWithMediaType entry : dataToSend) {
/* 127 */         super.send(entry.getData(), entry.getMediaType());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 134 */     return "SseEmitter@" + ObjectUtils.getIdentityHexString(this);
/*     */   }
/*     */   
/*     */   public static SseEventBuilder event()
/*     */   {
/* 139 */     return new SseEventBuilderImpl(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class SseEventBuilderImpl
/*     */     implements SseEmitter.SseEventBuilder
/*     */   {
/* 192 */     private final Set<ResponseBodyEmitter.DataWithMediaType> dataToSend = new LinkedHashSet(4);
/*     */     
/*     */     @Nullable
/*     */     private StringBuilder sb;
/*     */     
/*     */     public SseEmitter.SseEventBuilder id(String id)
/*     */     {
/* 199 */       append("id:").append(id).append('\n');
/* 200 */       return this;
/*     */     }
/*     */     
/*     */     public SseEmitter.SseEventBuilder name(String name)
/*     */     {
/* 205 */       append("event:").append(name).append('\n');
/* 206 */       return this;
/*     */     }
/*     */     
/*     */     public SseEmitter.SseEventBuilder reconnectTime(long reconnectTimeMillis)
/*     */     {
/* 211 */       append("retry:").append(String.valueOf(reconnectTimeMillis)).append('\n');
/* 212 */       return this;
/*     */     }
/*     */     
/*     */     public SseEmitter.SseEventBuilder comment(String comment)
/*     */     {
/* 217 */       append(':').append(comment).append('\n');
/* 218 */       return this;
/*     */     }
/*     */     
/*     */     public SseEmitter.SseEventBuilder data(Object object)
/*     */     {
/* 223 */       return data(object, null);
/*     */     }
/*     */     
/*     */     public SseEmitter.SseEventBuilder data(Object object, @Nullable MediaType mediaType)
/*     */     {
/* 228 */       append("data:");
/* 229 */       saveAppendedText();
/* 230 */       this.dataToSend.add(new ResponseBodyEmitter.DataWithMediaType(object, mediaType));
/* 231 */       append('\n');
/* 232 */       return this;
/*     */     }
/*     */     
/*     */     SseEventBuilderImpl append(String text) {
/* 236 */       if (this.sb == null) {
/* 237 */         this.sb = new StringBuilder();
/*     */       }
/* 239 */       this.sb.append(text);
/* 240 */       return this;
/*     */     }
/*     */     
/*     */     SseEventBuilderImpl append(char ch) {
/* 244 */       if (this.sb == null) {
/* 245 */         this.sb = new StringBuilder();
/*     */       }
/* 247 */       this.sb.append(ch);
/* 248 */       return this;
/*     */     }
/*     */     
/*     */     public Set<ResponseBodyEmitter.DataWithMediaType> build()
/*     */     {
/* 253 */       if ((!StringUtils.hasLength(this.sb)) && (this.dataToSend.isEmpty())) {
/* 254 */         return Collections.emptySet();
/*     */       }
/* 256 */       append('\n');
/* 257 */       saveAppendedText();
/* 258 */       return this.dataToSend;
/*     */     }
/*     */     
/*     */     private void saveAppendedText() {
/* 262 */       if (this.sb != null) {
/* 263 */         this.dataToSend.add(new ResponseBodyEmitter.DataWithMediaType(this.sb.toString(), SseEmitter.TEXT_PLAIN));
/* 264 */         this.sb = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface SseEventBuilder
/*     */   {
/*     */     public abstract SseEventBuilder id(String paramString);
/*     */     
/*     */     public abstract SseEventBuilder name(String paramString);
/*     */     
/*     */     public abstract SseEventBuilder reconnectTime(long paramLong);
/*     */     
/*     */     public abstract SseEventBuilder comment(String paramString);
/*     */     
/*     */     public abstract SseEventBuilder data(Object paramObject);
/*     */     
/*     */     public abstract SseEventBuilder data(Object paramObject, @Nullable MediaType paramMediaType);
/*     */     
/*     */     public abstract Set<ResponseBodyEmitter.DataWithMediaType> build();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\SseEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */