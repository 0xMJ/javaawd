/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceHandlerRegistration
/*     */ {
/*     */   private final String[] pathPatterns;
/*  43 */   private final List<String> locationValues = new ArrayList();
/*     */   
/*  45 */   private final List<Resource> locationsResources = new ArrayList();
/*     */   
/*     */   @Nullable
/*     */   private Integer cachePeriod;
/*     */   
/*     */   @Nullable
/*     */   private CacheControl cacheControl;
/*     */   
/*     */   @Nullable
/*     */   private ResourceChainRegistration resourceChainRegistration;
/*     */   
/*  56 */   private boolean useLastModified = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHandlerRegistration(String... pathPatterns)
/*     */   {
/*  64 */     Assert.notEmpty(pathPatterns, "At least one path pattern is required for resource handling.");
/*  65 */     this.pathPatterns = pathPatterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHandlerRegistration addResourceLocations(String... locations)
/*     */   {
/*  88 */     this.locationValues.addAll(Arrays.asList(locations));
/*  89 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHandlerRegistration addResourceLocations(Resource... locations)
/*     */   {
/* 101 */     this.locationsResources.addAll(Arrays.asList(locations));
/* 102 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHandlerRegistration setCachePeriod(Integer cachePeriod)
/*     */   {
/* 113 */     this.cachePeriod = cachePeriod;
/* 114 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHandlerRegistration setCacheControl(CacheControl cacheControl)
/*     */   {
/* 126 */     this.cacheControl = cacheControl;
/* 127 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceHandlerRegistration setUseLastModified(boolean useLastModified)
/*     */   {
/* 138 */     this.useLastModified = useLastModified;
/* 139 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceChainRegistration resourceChain(boolean cacheResources)
/*     */   {
/* 155 */     this.resourceChainRegistration = new ResourceChainRegistration(cacheResources);
/* 156 */     return this.resourceChainRegistration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResourceChainRegistration resourceChain(boolean cacheResources, Cache cache)
/*     */   {
/* 177 */     this.resourceChainRegistration = new ResourceChainRegistration(cacheResources, cache);
/* 178 */     return this.resourceChainRegistration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String[] getPathPatterns()
/*     */   {
/* 186 */     return this.pathPatterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected ResourceHttpRequestHandler getRequestHandler()
/*     */   {
/* 193 */     ResourceHttpRequestHandler handler = new ResourceHttpRequestHandler();
/* 194 */     if (this.resourceChainRegistration != null) {
/* 195 */       handler.setResourceResolvers(this.resourceChainRegistration.getResourceResolvers());
/* 196 */       handler.setResourceTransformers(this.resourceChainRegistration.getResourceTransformers());
/*     */     }
/* 198 */     handler.setLocationValues(this.locationValues);
/* 199 */     handler.setLocations(this.locationsResources);
/* 200 */     if (this.cacheControl != null) {
/* 201 */       handler.setCacheControl(this.cacheControl);
/*     */     }
/* 203 */     else if (this.cachePeriod != null) {
/* 204 */       handler.setCacheSeconds(this.cachePeriod.intValue());
/*     */     }
/* 206 */     handler.setUseLastModified(this.useLastModified);
/* 207 */     return handler;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\annotation\ResourceHandlerRegistration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */