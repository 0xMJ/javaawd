/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.resource.DefaultServletHttpRequestHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultServletHandlerConfigurer
/*     */ {
/*     */   private final ServletContext servletContext;
/*     */   @Nullable
/*     */   private DefaultServletHttpRequestHandler handler;
/*     */   
/*     */   public DefaultServletHandlerConfigurer(ServletContext servletContext)
/*     */   {
/*  58 */     Assert.notNull(servletContext, "ServletContext is required");
/*  59 */     this.servletContext = servletContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enable()
/*     */   {
/*  71 */     enable(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enable(@Nullable String defaultServletName)
/*     */   {
/*  81 */     this.handler = new DefaultServletHttpRequestHandler();
/*  82 */     if (defaultServletName != null) {
/*  83 */       this.handler.setDefaultServletName(defaultServletName);
/*     */     }
/*  85 */     this.handler.setServletContext(this.servletContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected SimpleUrlHandlerMapping buildHandlerMapping()
/*     */   {
/*  98 */     if (this.handler == null) {
/*  99 */       return null;
/*     */     }
/* 101 */     return new SimpleUrlHandlerMapping(Collections.singletonMap("/**", this.handler), Integer.MAX_VALUE);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\annotation\DefaultServletHandlerConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */