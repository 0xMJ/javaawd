/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.servlet.HandlerMapping;
/*    */ import org.springframework.web.util.pattern.PathPatternParser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface MatchableHandlerMapping
/*    */   extends HandlerMapping
/*    */ {
/*    */   @Nullable
/*    */   public PathPatternParser getPatternParser()
/*    */   {
/* 43 */     return null;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public abstract RequestMatchResult match(HttpServletRequest paramHttpServletRequest, String paramString);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\handler\MatchableHandlerMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */