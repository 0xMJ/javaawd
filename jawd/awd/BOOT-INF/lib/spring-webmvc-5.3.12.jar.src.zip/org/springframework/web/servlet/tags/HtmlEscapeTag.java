/*    */ package org.springframework.web.servlet.tags;
/*    */ 
/*    */ import javax.servlet.jsp.JspException;
/*    */ import org.springframework.web.servlet.support.RequestContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HtmlEscapeTag
/*    */   extends RequestContextAwareTag
/*    */ {
/*    */   private boolean defaultHtmlEscape;
/*    */   
/*    */   public void setDefaultHtmlEscape(boolean defaultHtmlEscape)
/*    */   {
/* 65 */     this.defaultHtmlEscape = defaultHtmlEscape;
/*    */   }
/*    */   
/*    */   protected int doStartTagInternal()
/*    */     throws JspException
/*    */   {
/* 71 */     getRequestContext().setDefaultHtmlEscape(this.defaultHtmlEscape);
/* 72 */     return 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\HtmlEscapeTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */