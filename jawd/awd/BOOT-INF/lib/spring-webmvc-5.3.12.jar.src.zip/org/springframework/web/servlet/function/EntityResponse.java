/*    */ package org.springframework.web.servlet.function;
/*    */ 
/*    */ import java.net.URI;
/*    */ import java.time.Instant;
/*    */ import java.time.ZonedDateTime;
/*    */ import java.util.Set;
/*    */ import java.util.function.Consumer;
/*    */ import javax.servlet.http.Cookie;
/*    */ import org.springframework.core.ParameterizedTypeReference;
/*    */ import org.springframework.http.CacheControl;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface EntityResponse<T>
/*    */   extends ServerResponse
/*    */ {
/*    */   public abstract T entity();
/*    */   
/*    */   public static <T> Builder<T> fromObject(T t)
/*    */   {
/* 59 */     return DefaultEntityResponseBuilder.fromObject(t);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static <T> Builder<T> fromObject(T t, ParameterizedTypeReference<T> entityType)
/*    */   {
/* 70 */     return DefaultEntityResponseBuilder.fromObject(t, entityType);
/*    */   }
/*    */   
/*    */   public static abstract interface Builder<T>
/*    */   {
/*    */     public abstract Builder<T> header(String paramString, String... paramVarArgs);
/*    */     
/*    */     public abstract Builder<T> headers(Consumer<HttpHeaders> paramConsumer);
/*    */     
/*    */     public abstract Builder<T> status(HttpStatus paramHttpStatus);
/*    */     
/*    */     public abstract Builder<T> status(int paramInt);
/*    */     
/*    */     public abstract Builder<T> cookie(Cookie paramCookie);
/*    */     
/*    */     public abstract Builder<T> cookies(Consumer<MultiValueMap<String, Cookie>> paramConsumer);
/*    */     
/*    */     public abstract Builder<T> allow(HttpMethod... paramVarArgs);
/*    */     
/*    */     public abstract Builder<T> allow(Set<HttpMethod> paramSet);
/*    */     
/*    */     public abstract Builder<T> eTag(String paramString);
/*    */     
/*    */     public abstract Builder<T> lastModified(ZonedDateTime paramZonedDateTime);
/*    */     
/*    */     public abstract Builder<T> lastModified(Instant paramInstant);
/*    */     
/*    */     public abstract Builder<T> location(URI paramURI);
/*    */     
/*    */     public abstract Builder<T> cacheControl(CacheControl paramCacheControl);
/*    */     
/*    */     public abstract Builder<T> varyBy(String... paramVarArgs);
/*    */     
/*    */     public abstract Builder<T> contentLength(long paramLong);
/*    */     
/*    */     public abstract Builder<T> contentType(MediaType paramMediaType);
/*    */     
/*    */     public abstract EntityResponse<T> build();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\EntityResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */