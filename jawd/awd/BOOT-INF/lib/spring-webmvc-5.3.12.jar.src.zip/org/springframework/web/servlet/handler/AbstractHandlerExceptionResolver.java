/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.log.LogFormatUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHandlerExceptionResolver
/*     */   implements HandlerExceptionResolver, Ordered
/*     */ {
/*     */   private static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*  52 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  54 */   private int order = Integer.MAX_VALUE;
/*     */   
/*     */   @Nullable
/*     */   private Set<?> mappedHandlers;
/*     */   
/*     */   @Nullable
/*     */   private Class<?>[] mappedHandlerClasses;
/*     */   
/*     */   @Nullable
/*     */   private Log warnLogger;
/*     */   
/*  65 */   private boolean preventResponseCaching = false;
/*     */   
/*     */   public void setOrder(int order)
/*     */   {
/*  69 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  74 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMappedHandlers(Set<?> mappedHandlers)
/*     */   {
/*  86 */     this.mappedHandlers = mappedHandlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMappedHandlerClasses(Class<?>... mappedHandlerClasses)
/*     */   {
/*  99 */     this.mappedHandlerClasses = mappedHandlerClasses;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWarnLogCategory(String loggerName)
/*     */   {
/* 115 */     this.warnLogger = (StringUtils.hasLength(loggerName) ? LogFactory.getLog(loggerName) : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPreventResponseCaching(boolean preventResponseCaching)
/*     */   {
/* 125 */     this.preventResponseCaching = preventResponseCaching;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, @Nullable Object handler, Exception ex)
/*     */   {
/* 140 */     if (shouldApplyTo(request, handler)) {
/* 141 */       prepareResponse(ex, response);
/* 142 */       ModelAndView result = doResolveException(request, response, handler, ex);
/* 143 */       if (result != null)
/*     */       {
/* 145 */         if ((this.logger.isDebugEnabled()) && ((this.warnLogger == null) || (!this.warnLogger.isWarnEnabled()))) {
/* 146 */           this.logger.debug(buildLogMessage(ex, request) + (result.isEmpty() ? "" : new StringBuilder().append(" to ").append(result).toString()));
/*     */         }
/*     */         
/* 149 */         logException(ex, request);
/*     */       }
/* 151 */       return result;
/*     */     }
/*     */     
/* 154 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean shouldApplyTo(HttpServletRequest request, @Nullable Object handler)
/*     */   {
/* 172 */     if (handler != null) {
/* 173 */       if ((this.mappedHandlers != null) && (this.mappedHandlers.contains(handler))) {
/* 174 */         return true;
/*     */       }
/* 176 */       if (this.mappedHandlerClasses != null) {
/* 177 */         for (Class<?> handlerClass : this.mappedHandlerClasses) {
/* 178 */           if (handlerClass.isInstance(handler)) {
/* 179 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 184 */     return !hasHandlerMappings();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean hasHandlerMappings()
/*     */   {
/* 193 */     return (this.mappedHandlers != null) || (this.mappedHandlerClasses != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void logException(Exception ex, HttpServletRequest request)
/*     */   {
/* 207 */     if ((this.warnLogger != null) && (this.warnLogger.isWarnEnabled())) {
/* 208 */       this.warnLogger.warn(buildLogMessage(ex, request));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String buildLogMessage(Exception ex, HttpServletRequest request)
/*     */   {
/* 219 */     return "Resolved [" + LogFormatUtils.formatValue(ex, -1, true) + "]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void prepareResponse(Exception ex, HttpServletResponse response)
/*     */   {
/* 232 */     if (this.preventResponseCaching) {
/* 233 */       preventCaching(response);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void preventCaching(HttpServletResponse response)
/*     */   {
/* 243 */     response.addHeader("Cache-Control", "no-store");
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected abstract ModelAndView doResolveException(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, @Nullable Object paramObject, Exception paramException);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\handler\AbstractHandlerExceptionResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */