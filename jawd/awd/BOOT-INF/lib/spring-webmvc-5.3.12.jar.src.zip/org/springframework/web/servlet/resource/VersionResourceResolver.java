/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.io.AbstractResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionResourceResolver
/*     */   extends AbstractResourceResolver
/*     */ {
/*  68 */   private AntPathMatcher pathMatcher = new AntPathMatcher();
/*     */   
/*     */ 
/*  71 */   private final Map<String, VersionStrategy> versionStrategyMap = new LinkedHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStrategyMap(Map<String, VersionStrategy> map)
/*     */   {
/*  81 */     this.versionStrategyMap.clear();
/*  82 */     this.versionStrategyMap.putAll(map);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, VersionStrategy> getStrategyMap()
/*     */   {
/*  89 */     return this.versionStrategyMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public VersionResourceResolver addContentVersionStrategy(String... pathPatterns)
/*     */   {
/* 105 */     addVersionStrategy(new ContentVersionStrategy(), pathPatterns);
/* 106 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public VersionResourceResolver addFixedVersionStrategy(String version, String... pathPatterns)
/*     */   {
/* 128 */     List<String> patternsList = Arrays.asList(pathPatterns);
/* 129 */     List<String> prefixedPatterns = new ArrayList(pathPatterns.length);
/* 130 */     String versionPrefix = "/" + version;
/* 131 */     for (String pattern : patternsList) {
/* 132 */       prefixedPatterns.add(pattern);
/* 133 */       if ((!pattern.startsWith(versionPrefix)) && (!patternsList.contains(versionPrefix + pattern))) {
/* 134 */         prefixedPatterns.add(versionPrefix + pattern);
/*     */       }
/*     */     }
/* 137 */     return addVersionStrategy(new FixedVersionStrategy(version), StringUtils.toStringArray(prefixedPatterns));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public VersionResourceResolver addVersionStrategy(VersionStrategy strategy, String... pathPatterns)
/*     */   {
/* 150 */     for (String pattern : pathPatterns) {
/* 151 */       getStrategyMap().put(pattern, strategy);
/*     */     }
/* 153 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Resource resolveResourceInternal(@Nullable HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain)
/*     */   {
/* 161 */     Resource resolved = chain.resolveResource(request, requestPath, locations);
/* 162 */     if (resolved != null) {
/* 163 */       return resolved;
/*     */     }
/*     */     
/* 166 */     VersionStrategy versionStrategy = getStrategyForPath(requestPath);
/* 167 */     if (versionStrategy == null) {
/* 168 */       return null;
/*     */     }
/*     */     
/* 171 */     String candidateVersion = versionStrategy.extractVersion(requestPath);
/* 172 */     if (!StringUtils.hasLength(candidateVersion)) {
/* 173 */       return null;
/*     */     }
/*     */     
/* 176 */     String simplePath = versionStrategy.removeVersion(requestPath, candidateVersion);
/* 177 */     Resource baseResource = chain.resolveResource(request, simplePath, locations);
/* 178 */     if (baseResource == null) {
/* 179 */       return null;
/*     */     }
/*     */     
/* 182 */     String actualVersion = versionStrategy.getResourceVersion(baseResource);
/* 183 */     if (candidateVersion.equals(actualVersion)) {
/* 184 */       return new FileNameVersionedResource(baseResource, candidateVersion);
/*     */     }
/*     */     
/* 187 */     if (this.logger.isTraceEnabled()) {
/* 188 */       this.logger.trace("Found resource for \"" + requestPath + "\", but version [" + candidateVersion + "] does not match");
/*     */     }
/*     */     
/* 191 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String resolveUrlPathInternal(String resourceUrlPath, List<? extends Resource> locations, ResourceResolverChain chain)
/*     */   {
/* 199 */     String baseUrl = chain.resolveUrlPath(resourceUrlPath, locations);
/* 200 */     if (StringUtils.hasText(baseUrl)) {
/* 201 */       VersionStrategy versionStrategy = getStrategyForPath(resourceUrlPath);
/* 202 */       if (versionStrategy == null) {
/* 203 */         return baseUrl;
/*     */       }
/* 205 */       Resource resource = chain.resolveResource(null, baseUrl, locations);
/* 206 */       Assert.state(resource != null, "Unresolvable resource");
/* 207 */       String version = versionStrategy.getResourceVersion(resource);
/* 208 */       return versionStrategy.addVersion(baseUrl, version);
/*     */     }
/* 210 */     return baseUrl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected VersionStrategy getStrategyForPath(String requestPath)
/*     */   {
/* 219 */     String path = "/".concat(requestPath);
/* 220 */     List<String> matchingPatterns = new ArrayList();
/* 221 */     for (String pattern : this.versionStrategyMap.keySet()) {
/* 222 */       if (this.pathMatcher.match(pattern, path)) {
/* 223 */         matchingPatterns.add(pattern);
/*     */       }
/*     */     }
/* 226 */     if (!matchingPatterns.isEmpty()) {
/* 227 */       Object comparator = this.pathMatcher.getPatternComparator(path);
/* 228 */       matchingPatterns.sort((Comparator)comparator);
/* 229 */       return (VersionStrategy)this.versionStrategyMap.get(matchingPatterns.get(0));
/*     */     }
/* 231 */     return null;
/*     */   }
/*     */   
/*     */   private class FileNameVersionedResource
/*     */     extends AbstractResource implements HttpResource
/*     */   {
/*     */     private final Resource original;
/*     */     private final String version;
/*     */     
/*     */     public FileNameVersionedResource(Resource original, String version)
/*     */     {
/* 242 */       this.original = original;
/* 243 */       this.version = version;
/*     */     }
/*     */     
/*     */     public boolean exists()
/*     */     {
/* 248 */       return this.original.exists();
/*     */     }
/*     */     
/*     */     public boolean isReadable()
/*     */     {
/* 253 */       return this.original.isReadable();
/*     */     }
/*     */     
/*     */     public boolean isOpen()
/*     */     {
/* 258 */       return this.original.isOpen();
/*     */     }
/*     */     
/*     */     public boolean isFile()
/*     */     {
/* 263 */       return this.original.isFile();
/*     */     }
/*     */     
/*     */     public URL getURL() throws IOException
/*     */     {
/* 268 */       return this.original.getURL();
/*     */     }
/*     */     
/*     */     public URI getURI() throws IOException
/*     */     {
/* 273 */       return this.original.getURI();
/*     */     }
/*     */     
/*     */     public File getFile() throws IOException
/*     */     {
/* 278 */       return this.original.getFile();
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public String getFilename()
/*     */     {
/* 284 */       return this.original.getFilename();
/*     */     }
/*     */     
/*     */     public long contentLength() throws IOException
/*     */     {
/* 289 */       return this.original.contentLength();
/*     */     }
/*     */     
/*     */     public long lastModified() throws IOException
/*     */     {
/* 294 */       return this.original.lastModified();
/*     */     }
/*     */     
/*     */     public Resource createRelative(String relativePath) throws IOException
/*     */     {
/* 299 */       return this.original.createRelative(relativePath);
/*     */     }
/*     */     
/*     */     public String getDescription()
/*     */     {
/* 304 */       return this.original.getDescription();
/*     */     }
/*     */     
/*     */     public InputStream getInputStream() throws IOException
/*     */     {
/* 309 */       return this.original.getInputStream();
/*     */     }
/*     */     
/*     */ 
/*     */     public HttpHeaders getResponseHeaders()
/*     */     {
/* 315 */       HttpHeaders headers = (this.original instanceof HttpResource) ? ((HttpResource)this.original).getResponseHeaders() : new HttpHeaders();
/* 316 */       headers.setETag("W/\"" + this.version + "\"");
/* 317 */       return headers;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\VersionResourceResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */