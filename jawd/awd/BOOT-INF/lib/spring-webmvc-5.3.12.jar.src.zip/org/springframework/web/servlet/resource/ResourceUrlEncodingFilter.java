/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.filter.GenericFilterBean;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceUrlEncodingFilter
/*     */   extends GenericFilterBean
/*     */ {
/*  51 */   private static final Log logger = LogFactory.getLog(ResourceUrlEncodingFilter.class);
/*     */   
/*     */ 
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/*  58 */     if ((!(request instanceof HttpServletRequest)) || (!(response instanceof HttpServletResponse))) {
/*  59 */       throw new ServletException("ResourceUrlEncodingFilter only supports HTTP requests");
/*     */     }
/*     */     
/*  62 */     ResourceUrlEncodingRequestWrapper wrappedRequest = new ResourceUrlEncodingRequestWrapper((HttpServletRequest)request);
/*     */     
/*  64 */     ResourceUrlEncodingResponseWrapper wrappedResponse = new ResourceUrlEncodingResponseWrapper(wrappedRequest, (HttpServletResponse)response);
/*     */     
/*     */ 
/*  67 */     filterChain.doFilter(wrappedRequest, wrappedResponse);
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ResourceUrlEncodingRequestWrapper
/*     */     extends HttpServletRequestWrapper
/*     */   {
/*     */     @Nullable
/*     */     private ResourceUrlProvider resourceUrlProvider;
/*     */     
/*     */     @Nullable
/*     */     private Integer indexLookupPath;
/*  79 */     private String prefixLookupPath = "";
/*     */     
/*     */     ResourceUrlEncodingRequestWrapper(HttpServletRequest request) {
/*  82 */       super();
/*     */     }
/*     */     
/*     */     public void setAttribute(String name, Object value)
/*     */     {
/*  87 */       super.setAttribute(name, value);
/*  88 */       if ((ResourceUrlProviderExposingInterceptor.RESOURCE_URL_PROVIDER_ATTR.equals(name)) && 
/*  89 */         ((value instanceof ResourceUrlProvider))) {
/*  90 */         initLookupPath((ResourceUrlProvider)value);
/*     */       }
/*     */     }
/*     */     
/*     */     private void initLookupPath(ResourceUrlProvider urlProvider)
/*     */     {
/*  96 */       this.resourceUrlProvider = urlProvider;
/*  97 */       if (this.indexLookupPath == null) {
/*  98 */         UrlPathHelper pathHelper = this.resourceUrlProvider.getUrlPathHelper();
/*  99 */         String requestUri = pathHelper.getRequestUri(this);
/* 100 */         String lookupPath = pathHelper.getLookupPathForRequest(this);
/* 101 */         this.indexLookupPath = Integer.valueOf(requestUri.lastIndexOf(lookupPath));
/* 102 */         if (this.indexLookupPath.intValue() == -1) {
/* 103 */           throw new ResourceUrlEncodingFilter.LookupPathIndexException(lookupPath, requestUri);
/*     */         }
/* 105 */         this.prefixLookupPath = requestUri.substring(0, this.indexLookupPath.intValue());
/* 106 */         if ((StringUtils.matchesCharacter(lookupPath, '/')) && (!StringUtils.matchesCharacter(requestUri, '/'))) {
/* 107 */           String contextPath = pathHelper.getContextPath(this);
/* 108 */           if (requestUri.equals(contextPath)) {
/* 109 */             this.indexLookupPath = Integer.valueOf(requestUri.length());
/* 110 */             this.prefixLookupPath = requestUri;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public String resolveUrlPath(String url) {
/* 118 */       if (this.resourceUrlProvider == null) {
/* 119 */         ResourceUrlEncodingFilter.logger.trace("ResourceUrlProvider not available via request attribute " + ResourceUrlProviderExposingInterceptor.RESOURCE_URL_PROVIDER_ATTR);
/*     */         
/* 121 */         return null;
/*     */       }
/* 123 */       if ((this.indexLookupPath != null) && (url.startsWith(this.prefixLookupPath))) {
/* 124 */         int suffixIndex = getEndPathIndex(url);
/* 125 */         String suffix = url.substring(suffixIndex);
/* 126 */         String lookupPath = url.substring(this.indexLookupPath.intValue(), suffixIndex);
/* 127 */         lookupPath = this.resourceUrlProvider.getForLookupPath(lookupPath);
/* 128 */         if (lookupPath != null) {
/* 129 */           return this.prefixLookupPath + lookupPath + suffix;
/*     */         }
/*     */       }
/* 132 */       return null;
/*     */     }
/*     */     
/*     */     private int getEndPathIndex(String path) {
/* 136 */       int end = path.indexOf('?');
/* 137 */       int fragmentIndex = path.indexOf('#');
/* 138 */       if ((fragmentIndex != -1) && ((end == -1) || (fragmentIndex < end))) {
/* 139 */         end = fragmentIndex;
/*     */       }
/* 141 */       if (end == -1) {
/* 142 */         end = path.length();
/*     */       }
/* 144 */       return end;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ResourceUrlEncodingResponseWrapper extends HttpServletResponseWrapper
/*     */   {
/*     */     private final ResourceUrlEncodingFilter.ResourceUrlEncodingRequestWrapper request;
/*     */     
/*     */     ResourceUrlEncodingResponseWrapper(ResourceUrlEncodingFilter.ResourceUrlEncodingRequestWrapper request, HttpServletResponse wrapped)
/*     */     {
/* 154 */       super();
/* 155 */       this.request = request;
/*     */     }
/*     */     
/*     */     public String encodeURL(String url)
/*     */     {
/* 160 */       String urlPath = this.request.resolveUrlPath(url);
/* 161 */       if (urlPath != null) {
/* 162 */         return super.encodeURL(urlPath);
/*     */       }
/* 164 */       return super.encodeURL(url);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class LookupPathIndexException
/*     */     extends IllegalArgumentException
/*     */   {
/*     */     LookupPathIndexException(String lookupPath, String requestUri)
/*     */     {
/* 178 */       super();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\ResourceUrlEncodingFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */