/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.RequestParam;
/*     */ import org.springframework.web.bind.annotation.RequestPart;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.support.MissingServletRequestPartException;
/*     */ import org.springframework.web.multipart.support.MultipartResolutionDelegate;
/*     */ import org.springframework.web.multipart.support.RequestPartServletServerHttpRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestPartMethodArgumentResolver
/*     */   extends AbstractMessageConverterMethodArgumentResolver
/*     */ {
/*     */   public RequestPartMethodArgumentResolver(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  79 */     super(messageConverters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestPartMethodArgumentResolver(List<HttpMessageConverter<?>> messageConverters, List<Object> requestResponseBodyAdvice)
/*     */   {
/*  89 */     super(messageConverters, requestResponseBodyAdvice);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/* 105 */     if (parameter.hasParameterAnnotation(RequestPart.class)) {
/* 106 */       return true;
/*     */     }
/*     */     
/* 109 */     if (parameter.hasParameterAnnotation(RequestParam.class)) {
/* 110 */       return false;
/*     */     }
/* 112 */     return MultipartResolutionDelegate.isMultipartArgument(parameter.nestedIfOptional());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object resolveArgument(MethodParameter parameter, @Nullable ModelAndViewContainer mavContainer, NativeWebRequest request, @Nullable WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/* 121 */     HttpServletRequest servletRequest = (HttpServletRequest)request.getNativeRequest(HttpServletRequest.class);
/* 122 */     Assert.state(servletRequest != null, "No HttpServletRequest");
/*     */     
/* 124 */     RequestPart requestPart = (RequestPart)parameter.getParameterAnnotation(RequestPart.class);
/* 125 */     boolean isRequired = ((requestPart == null) || (requestPart.required())) && (!parameter.isOptional());
/*     */     
/* 127 */     String name = getPartName(parameter, requestPart);
/* 128 */     parameter = parameter.nestedIfOptional();
/* 129 */     Object arg = null;
/*     */     
/* 131 */     Object mpArg = MultipartResolutionDelegate.resolveMultipartArgument(name, parameter, servletRequest);
/* 132 */     if (mpArg != MultipartResolutionDelegate.UNRESOLVABLE) {
/* 133 */       arg = mpArg;
/*     */     } else {
/*     */       try
/*     */       {
/* 137 */         HttpInputMessage inputMessage = new RequestPartServletServerHttpRequest(servletRequest, name);
/* 138 */         arg = readWithMessageConverters(inputMessage, parameter, parameter.getNestedGenericParameterType());
/* 139 */         if (binderFactory != null) {
/* 140 */           WebDataBinder binder = binderFactory.createBinder(request, arg, name);
/* 141 */           if (arg != null) {
/* 142 */             validateIfApplicable(binder, parameter);
/* 143 */             if ((binder.getBindingResult().hasErrors()) && (isBindExceptionRequired(binder, parameter))) {
/* 144 */               throw new MethodArgumentNotValidException(parameter, binder.getBindingResult());
/*     */             }
/*     */           }
/* 147 */           if (mavContainer != null) {
/* 148 */             mavContainer.addAttribute(BindingResult.MODEL_KEY_PREFIX + name, binder.getBindingResult());
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (MissingServletRequestPartException|MultipartException ex) {
/* 153 */         if (isRequired) {
/* 154 */           throw ex;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 159 */     if ((arg == null) && (isRequired)) {
/* 160 */       if (!MultipartResolutionDelegate.isMultipartRequest(servletRequest)) {
/* 161 */         throw new MultipartException("Current request is not a multipart request");
/*     */       }
/*     */       
/* 164 */       throw new MissingServletRequestPartException(name);
/*     */     }
/*     */     
/* 167 */     return adaptArgumentIfNecessary(arg, parameter);
/*     */   }
/*     */   
/*     */   private String getPartName(MethodParameter methodParam, @Nullable RequestPart requestPart) {
/* 171 */     String partName = requestPart != null ? requestPart.name() : "";
/* 172 */     if (partName.isEmpty()) {
/* 173 */       partName = methodParam.getParameterName();
/* 174 */       if (partName == null)
/*     */       {
/* 176 */         throw new IllegalArgumentException("Request part name for argument type [" + methodParam.getNestedParameterType().getName() + "] not specified, and parameter name information not found in class file either.");
/*     */       }
/*     */     }
/*     */     
/* 180 */     return partName;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\RequestPartMethodArgumentResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */