/*    */ package org.springframework.web.servlet.function;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.util.pattern.PathPatternParser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ChangePathPatternParserVisitor
/*    */   implements RouterFunctions.Visitor
/*    */ {
/*    */   private final PathPatternParser parser;
/*    */   
/*    */   public ChangePathPatternParserVisitor(PathPatternParser parser)
/*    */   {
/* 41 */     Assert.notNull(parser, "Parser must not be null");
/* 42 */     this.parser = parser;
/*    */   }
/*    */   
/*    */   public void startNested(RequestPredicate predicate)
/*    */   {
/* 47 */     changeParser(predicate);
/*    */   }
/*    */   
/*    */ 
/*    */   public void endNested(RequestPredicate predicate) {}
/*    */   
/*    */ 
/*    */   public void route(RequestPredicate predicate, HandlerFunction<?> handlerFunction)
/*    */   {
/* 56 */     changeParser(predicate);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void resources(Function<ServerRequest, Optional<Resource>> lookupFunction) {}
/*    */   
/*    */ 
/*    */   public void attributes(Map<String, Object> attributes) {}
/*    */   
/*    */ 
/*    */   public void unknown(RouterFunction<?> routerFunction) {}
/*    */   
/*    */ 
/*    */   private void changeParser(RequestPredicate predicate)
/*    */   {
/* 72 */     if ((predicate instanceof Target)) {
/* 73 */       Target target = (Target)predicate;
/* 74 */       target.changeParser(this.parser);
/*    */     }
/*    */   }
/*    */   
/*    */   public static abstract interface Target
/*    */   {
/*    */     public abstract void changeParser(PathPatternParser paramPathPatternParser);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\ChangePathPatternParserVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */