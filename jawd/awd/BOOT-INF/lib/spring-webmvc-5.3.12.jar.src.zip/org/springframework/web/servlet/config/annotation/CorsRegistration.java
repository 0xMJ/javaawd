/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CorsRegistration
/*     */ {
/*     */   private final String pathPattern;
/*     */   private CorsConfiguration config;
/*     */   
/*     */   public CorsRegistration(String pathPattern)
/*     */   {
/*  43 */     this.pathPattern = pathPattern;
/*     */     
/*  45 */     this.config = new CorsConfiguration().applyPermitDefaultValues();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CorsRegistration allowedOrigins(String... origins)
/*     */   {
/*  60 */     this.config.setAllowedOrigins(Arrays.asList(origins));
/*  61 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CorsRegistration allowedOriginPatterns(String... patterns)
/*     */   {
/*  74 */     this.config.setAllowedOriginPatterns(Arrays.asList(patterns));
/*  75 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CorsRegistration allowedMethods(String... methods)
/*     */   {
/*  85 */     this.config.setAllowedMethods(Arrays.asList(methods));
/*  86 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CorsRegistration allowedHeaders(String... headers)
/*     */   {
/*  99 */     this.config.setAllowedHeaders(Arrays.asList(headers));
/* 100 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CorsRegistration exposedHeaders(String... headers)
/*     */   {
/* 113 */     this.config.setExposedHeaders(Arrays.asList(headers));
/* 114 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CorsRegistration allowCredentials(boolean allowCredentials)
/*     */   {
/* 131 */     this.config.setAllowCredentials(Boolean.valueOf(allowCredentials));
/* 132 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CorsRegistration maxAge(long maxAge)
/*     */   {
/* 141 */     this.config.setMaxAge(Long.valueOf(maxAge));
/* 142 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CorsRegistration combine(CorsConfiguration other)
/*     */   {
/* 153 */     this.config = this.config.combine(other);
/* 154 */     return this;
/*     */   }
/*     */   
/*     */   protected String getPathPattern() {
/* 158 */     return this.pathPattern;
/*     */   }
/*     */   
/*     */   protected CorsConfiguration getCorsConfiguration() {
/* 162 */     return this.config;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\annotation\CorsRegistration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */