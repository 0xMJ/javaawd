/*    */ package org.springframework.web.servlet.resource;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.bind.ServletRequestBindingException;
/*    */ import org.springframework.web.servlet.HandlerInterceptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceUrlProviderExposingInterceptor
/*    */   implements HandlerInterceptor
/*    */ {
/* 38 */   public static final String RESOURCE_URL_PROVIDER_ATTR = ResourceUrlProvider.class.getName();
/*    */   
/*    */   private final ResourceUrlProvider resourceUrlProvider;
/*    */   
/*    */   public ResourceUrlProviderExposingInterceptor(ResourceUrlProvider resourceUrlProvider)
/*    */   {
/* 44 */     Assert.notNull(resourceUrlProvider, "ResourceUrlProvider is required");
/* 45 */     this.resourceUrlProvider = resourceUrlProvider;
/*    */   }
/*    */   
/*    */   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*    */     throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 53 */       request.setAttribute(RESOURCE_URL_PROVIDER_ATTR, this.resourceUrlProvider);
/*    */     }
/*    */     catch (ResourceUrlEncodingFilter.LookupPathIndexException ex) {
/* 56 */       throw new ServletRequestBindingException(ex.getMessage(), ex);
/*    */     }
/* 58 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\ResourceUrlProviderExposingInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */