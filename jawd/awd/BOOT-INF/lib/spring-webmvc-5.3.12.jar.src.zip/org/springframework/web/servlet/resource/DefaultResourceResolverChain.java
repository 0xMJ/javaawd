/*    */ package org.springframework.web.servlet.resource;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.ListIterator;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultResourceResolverChain
/*    */   implements ResourceResolverChain
/*    */ {
/*    */   @Nullable
/*    */   private final ResourceResolver resolver;
/*    */   @Nullable
/*    */   private final ResourceResolverChain nextChain;
/*    */   
/*    */   public DefaultResourceResolverChain(@Nullable List<? extends ResourceResolver> resolvers)
/*    */   {
/* 46 */     resolvers = resolvers != null ? resolvers : Collections.emptyList();
/* 47 */     DefaultResourceResolverChain chain = initChain(new ArrayList(resolvers));
/* 48 */     this.resolver = chain.resolver;
/* 49 */     this.nextChain = chain.nextChain;
/*    */   }
/*    */   
/*    */   private static DefaultResourceResolverChain initChain(ArrayList<? extends ResourceResolver> resolvers) {
/* 53 */     DefaultResourceResolverChain chain = new DefaultResourceResolverChain(null, null);
/* 54 */     ListIterator<? extends ResourceResolver> it = resolvers.listIterator(resolvers.size());
/* 55 */     while (it.hasPrevious()) {
/* 56 */       chain = new DefaultResourceResolverChain((ResourceResolver)it.previous(), chain);
/*    */     }
/* 58 */     return chain;
/*    */   }
/*    */   
/*    */   private DefaultResourceResolverChain(@Nullable ResourceResolver resolver, @Nullable ResourceResolverChain chain) {
/* 62 */     Assert.isTrue(((resolver == null) && (chain == null)) || ((resolver != null) && (chain != null)), "Both resolver and resolver chain must be null, or neither is");
/*    */     
/* 64 */     this.resolver = resolver;
/* 65 */     this.nextChain = chain;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   public Resource resolveResource(@Nullable HttpServletRequest request, String requestPath, List<? extends Resource> locations)
/*    */   {
/* 74 */     return (this.resolver != null) && (this.nextChain != null) ? this.resolver
/* 75 */       .resolveResource(request, requestPath, locations, this.nextChain) : null;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public String resolveUrlPath(String resourcePath, List<? extends Resource> locations)
/*    */   {
/* 81 */     return (this.resolver != null) && (this.nextChain != null) ? this.resolver
/* 82 */       .resolveUrlPath(resourcePath, locations, this.nextChain) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\DefaultResourceResolverChain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */