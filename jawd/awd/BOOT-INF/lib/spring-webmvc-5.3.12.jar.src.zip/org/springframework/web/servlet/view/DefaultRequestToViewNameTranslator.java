/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.RequestToViewNameTranslator;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultRequestToViewNameTranslator
/*     */   implements RequestToViewNameTranslator
/*     */ {
/*     */   private static final String SLASH = "/";
/*  63 */   private String prefix = "";
/*     */   
/*  65 */   private String suffix = "";
/*     */   
/*  67 */   private String separator = "/";
/*     */   
/*  69 */   private boolean stripLeadingSlash = true;
/*     */   
/*  71 */   private boolean stripTrailingSlash = true;
/*     */   
/*  73 */   private boolean stripExtension = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrefix(@Nullable String prefix)
/*     */   {
/*  81 */     this.prefix = (prefix != null ? prefix : "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSuffix(@Nullable String suffix)
/*     */   {
/*  89 */     this.suffix = (suffix != null ? suffix : "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSeparator(String separator)
/*     */   {
/*  98 */     this.separator = separator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStripLeadingSlash(boolean stripLeadingSlash)
/*     */   {
/* 106 */     this.stripLeadingSlash = stripLeadingSlash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStripTrailingSlash(boolean stripTrailingSlash)
/*     */   {
/* 114 */     this.stripTrailingSlash = stripTrailingSlash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStripExtension(boolean stripExtension)
/*     */   {
/* 122 */     this.stripExtension = stripExtension;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setAlwaysUseFullPath(boolean alwaysUseFullPath) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setUrlDecode(boolean urlDecode) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setRemoveSemicolonContent(boolean removeSemicolonContent) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getViewName(HttpServletRequest request)
/*     */   {
/* 178 */     String path = ServletRequestPathUtils.getCachedPathValue(request);
/* 179 */     return this.prefix + transformPath(path) + this.suffix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String transformPath(String lookupPath)
/*     */   {
/* 192 */     String path = lookupPath;
/* 193 */     if ((this.stripLeadingSlash) && (path.startsWith("/"))) {
/* 194 */       path = path.substring(1);
/*     */     }
/* 196 */     if ((this.stripTrailingSlash) && (path.endsWith("/"))) {
/* 197 */       path = path.substring(0, path.length() - 1);
/*     */     }
/* 199 */     if (this.stripExtension) {
/* 200 */       path = StringUtils.stripFilenameExtension(path);
/*     */     }
/* 202 */     if (!"/".equals(this.separator)) {
/* 203 */       path = StringUtils.replace(path, "/", this.separator);
/*     */     }
/* 205 */     return path;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\DefaultRequestToViewNameTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */