/*    */ package org.springframework.web.servlet.resource;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachingResourceTransformer
/*    */   implements ResourceTransformer
/*    */ {
/* 42 */   private static final Log logger = LogFactory.getLog(CachingResourceTransformer.class);
/*    */   
/*    */   private final Cache cache;
/*    */   
/*    */   public CachingResourceTransformer(Cache cache)
/*    */   {
/* 48 */     Assert.notNull(cache, "Cache is required");
/* 49 */     this.cache = cache;
/*    */   }
/*    */   
/*    */   public CachingResourceTransformer(CacheManager cacheManager, String cacheName) {
/* 53 */     Cache cache = cacheManager.getCache(cacheName);
/* 54 */     if (cache == null) {
/* 55 */       throw new IllegalArgumentException("Cache '" + cacheName + "' not found");
/*    */     }
/* 57 */     this.cache = cache;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Cache getCache()
/*    */   {
/* 65 */     return this.cache;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Resource transform(HttpServletRequest request, Resource resource, ResourceTransformerChain transformerChain)
/*    */     throws IOException
/*    */   {
/* 73 */     Resource transformed = (Resource)this.cache.get(resource, Resource.class);
/* 74 */     if (transformed != null) {
/* 75 */       logger.trace("Resource resolved from cache");
/* 76 */       return transformed;
/*    */     }
/*    */     
/* 79 */     transformed = transformerChain.transform(request, resource);
/* 80 */     this.cache.put(resource, transformed);
/*    */     
/* 82 */     return transformed;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\CachingResourceTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */