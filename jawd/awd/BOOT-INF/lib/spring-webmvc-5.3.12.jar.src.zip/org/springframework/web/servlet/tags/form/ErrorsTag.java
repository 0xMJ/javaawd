/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTag;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorsTag
/*     */   extends AbstractHtmlElementBodyTag
/*     */   implements BodyTag
/*     */ {
/*     */   public static final String MESSAGES_ATTRIBUTE = "messages";
/*     */   public static final String SPAN_TAG = "span";
/* 207 */   private String element = "span";
/*     */   
/* 209 */   private String delimiter = "<br/>";
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Object oldMessages;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean errorMessagesWereExposed;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setElement(String element)
/*     */   {
/* 225 */     Assert.hasText(element, "'element' cannot be null or blank");
/* 226 */     this.element = element;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getElement()
/*     */   {
/* 233 */     return this.element;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDelimiter(String delimiter)
/*     */   {
/* 241 */     this.delimiter = delimiter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDelimiter()
/*     */   {
/* 248 */     return this.delimiter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String autogenerateId()
/*     */     throws JspException
/*     */   {
/* 262 */     String path = getPropertyPath();
/* 263 */     if ((!StringUtils.hasLength(path)) || ("*".equals(path))) {
/* 264 */       path = (String)this.pageContext.getAttribute(FormTag.MODEL_ATTRIBUTE_VARIABLE_NAME, 2);
/*     */     }
/*     */     
/* 267 */     return StringUtils.deleteAny(path, "[]") + ".errors";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getName()
/*     */     throws JspException
/*     */   {
/* 278 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean shouldRender()
/*     */     throws JspException
/*     */   {
/*     */     try
/*     */     {
/* 289 */       return getBindStatus().isError();
/*     */     }
/*     */     catch (IllegalStateException ex) {}
/*     */     
/* 293 */     return false;
/*     */   }
/*     */   
/*     */   protected void renderDefaultContent(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 299 */     tagWriter.startTag(getElement());
/* 300 */     writeDefaultAttributes(tagWriter);
/* 301 */     String delimiter = ObjectUtils.getDisplayString(evaluate("delimiter", getDelimiter()));
/* 302 */     String[] errorMessages = getBindStatus().getErrorMessages();
/* 303 */     for (int i = 0; i < errorMessages.length; i++) {
/* 304 */       String errorMessage = errorMessages[i];
/* 305 */       if (i > 0) {
/* 306 */         tagWriter.appendValue(delimiter);
/*     */       }
/* 308 */       tagWriter.appendValue(getDisplayString(errorMessage));
/*     */     }
/* 310 */     tagWriter.endTag();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void exposeAttributes()
/*     */     throws JspException
/*     */   {
/* 321 */     List<String> errorMessages = new ArrayList(Arrays.asList(getBindStatus().getErrorMessages()));
/* 322 */     this.oldMessages = this.pageContext.getAttribute("messages", 1);
/* 323 */     this.pageContext.setAttribute("messages", errorMessages, 1);
/* 324 */     this.errorMessagesWereExposed = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void removeAttributes()
/*     */   {
/* 334 */     if (this.errorMessagesWereExposed) {
/* 335 */       if (this.oldMessages != null) {
/* 336 */         this.pageContext.setAttribute("messages", this.oldMessages, 1);
/* 337 */         this.oldMessages = null;
/*     */       }
/*     */       else {
/* 340 */         this.pageContext.removeAttribute("messages", 1);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\form\ErrorsTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */