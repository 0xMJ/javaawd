/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.ConversionNotSupportedException;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.MissingPathVariableException;
/*     */ import org.springframework.web.bind.MissingServletRequestParameterException;
/*     */ import org.springframework.web.bind.ServletRequestBindingException;
/*     */ import org.springframework.web.bind.annotation.ExceptionHandler;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
/*     */ import org.springframework.web.multipart.support.MissingServletRequestPartException;
/*     */ import org.springframework.web.servlet.NoHandlerFoundException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResponseEntityExceptionHandler
/*     */ {
/*     */   public static final String PAGE_NOT_FOUND_LOG_CATEGORY = "org.springframework.web.servlet.PageNotFound";
/*  93 */   protected static final Log pageNotFoundLogger = LogFactory.getLog("org.springframework.web.servlet.PageNotFound");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  98 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @ExceptionHandler({HttpRequestMethodNotSupportedException.class, HttpMediaTypeNotSupportedException.class, HttpMediaTypeNotAcceptableException.class, MissingPathVariableException.class, MissingServletRequestParameterException.class, ServletRequestBindingException.class, ConversionNotSupportedException.class, TypeMismatchException.class, HttpMessageNotReadableException.class, HttpMessageNotWritableException.class, MethodArgumentNotValidException.class, MissingServletRequestPartException.class, BindException.class, NoHandlerFoundException.class, AsyncRequestTimeoutException.class})
/*     */   @Nullable
/*     */   public final ResponseEntity<Object> handleException(Exception ex, WebRequest request)
/*     */     throws Exception
/*     */   {
/* 125 */     HttpHeaders headers = new HttpHeaders();
/*     */     
/* 127 */     if ((ex instanceof HttpRequestMethodNotSupportedException)) {
/* 128 */       HttpStatus status = HttpStatus.METHOD_NOT_ALLOWED;
/* 129 */       return handleHttpRequestMethodNotSupported((HttpRequestMethodNotSupportedException)ex, headers, status, request);
/*     */     }
/* 131 */     if ((ex instanceof HttpMediaTypeNotSupportedException)) {
/* 132 */       HttpStatus status = HttpStatus.UNSUPPORTED_MEDIA_TYPE;
/* 133 */       return handleHttpMediaTypeNotSupported((HttpMediaTypeNotSupportedException)ex, headers, status, request);
/*     */     }
/* 135 */     if ((ex instanceof HttpMediaTypeNotAcceptableException)) {
/* 136 */       HttpStatus status = HttpStatus.NOT_ACCEPTABLE;
/* 137 */       return handleHttpMediaTypeNotAcceptable((HttpMediaTypeNotAcceptableException)ex, headers, status, request);
/*     */     }
/* 139 */     if ((ex instanceof MissingPathVariableException)) {
/* 140 */       HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
/* 141 */       return handleMissingPathVariable((MissingPathVariableException)ex, headers, status, request);
/*     */     }
/* 143 */     if ((ex instanceof MissingServletRequestParameterException)) {
/* 144 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 145 */       return handleMissingServletRequestParameter((MissingServletRequestParameterException)ex, headers, status, request);
/*     */     }
/* 147 */     if ((ex instanceof ServletRequestBindingException)) {
/* 148 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 149 */       return handleServletRequestBindingException((ServletRequestBindingException)ex, headers, status, request);
/*     */     }
/* 151 */     if ((ex instanceof ConversionNotSupportedException)) {
/* 152 */       HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
/* 153 */       return handleConversionNotSupported((ConversionNotSupportedException)ex, headers, status, request);
/*     */     }
/* 155 */     if ((ex instanceof TypeMismatchException)) {
/* 156 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 157 */       return handleTypeMismatch((TypeMismatchException)ex, headers, status, request);
/*     */     }
/* 159 */     if ((ex instanceof HttpMessageNotReadableException)) {
/* 160 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 161 */       return handleHttpMessageNotReadable((HttpMessageNotReadableException)ex, headers, status, request);
/*     */     }
/* 163 */     if ((ex instanceof HttpMessageNotWritableException)) {
/* 164 */       HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
/* 165 */       return handleHttpMessageNotWritable((HttpMessageNotWritableException)ex, headers, status, request);
/*     */     }
/* 167 */     if ((ex instanceof MethodArgumentNotValidException)) {
/* 168 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 169 */       return handleMethodArgumentNotValid((MethodArgumentNotValidException)ex, headers, status, request);
/*     */     }
/* 171 */     if ((ex instanceof MissingServletRequestPartException)) {
/* 172 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 173 */       return handleMissingServletRequestPart((MissingServletRequestPartException)ex, headers, status, request);
/*     */     }
/* 175 */     if ((ex instanceof BindException)) {
/* 176 */       HttpStatus status = HttpStatus.BAD_REQUEST;
/* 177 */       return handleBindException((BindException)ex, headers, status, request);
/*     */     }
/* 179 */     if ((ex instanceof NoHandlerFoundException)) {
/* 180 */       HttpStatus status = HttpStatus.NOT_FOUND;
/* 181 */       return handleNoHandlerFoundException((NoHandlerFoundException)ex, headers, status, request);
/*     */     }
/* 183 */     if ((ex instanceof AsyncRequestTimeoutException)) {
/* 184 */       HttpStatus status = HttpStatus.SERVICE_UNAVAILABLE;
/* 185 */       return handleAsyncRequestTimeoutException((AsyncRequestTimeoutException)ex, headers, status, request);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */     throw ex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 209 */     pageNotFoundLogger.warn(ex.getMessage());
/*     */     
/* 211 */     Set<HttpMethod> supportedMethods = ex.getSupportedHttpMethods();
/* 212 */     if (!CollectionUtils.isEmpty(supportedMethods)) {
/* 213 */       headers.setAllow(supportedMethods);
/*     */     }
/* 215 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 231 */     List<MediaType> mediaTypes = ex.getSupportedMediaTypes();
/* 232 */     if (!CollectionUtils.isEmpty(mediaTypes)) {
/* 233 */       headers.setAccept(mediaTypes);
/* 234 */       if ((request instanceof ServletWebRequest)) {
/* 235 */         ServletWebRequest servletWebRequest = (ServletWebRequest)request;
/* 236 */         if (HttpMethod.PATCH.equals(servletWebRequest.getHttpMethod())) {
/* 237 */           headers.setAcceptPatch(mediaTypes);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 242 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpMediaTypeNotAcceptable(HttpMediaTypeNotAcceptableException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 257 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleMissingPathVariable(MissingPathVariableException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 273 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 288 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleServletRequestBindingException(ServletRequestBindingException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 303 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleConversionNotSupported(ConversionNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 318 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleTypeMismatch(TypeMismatchException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 333 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 348 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleHttpMessageNotWritable(HttpMessageNotWritableException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 363 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 378 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleMissingServletRequestPart(MissingServletRequestPartException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 393 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleBindException(BindException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 408 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 424 */     return handleExceptionInternal(ex, null, headers, status, request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected ResponseEntity<Object> handleAsyncRequestTimeoutException(AsyncRequestTimeoutException ex, HttpHeaders headers, HttpStatus status, WebRequest webRequest)
/*     */   {
/* 441 */     if ((webRequest instanceof ServletWebRequest)) {
/* 442 */       ServletWebRequest servletWebRequest = (ServletWebRequest)webRequest;
/* 443 */       HttpServletResponse response = servletWebRequest.getResponse();
/* 444 */       if ((response != null) && (response.isCommitted())) {
/* 445 */         if (this.logger.isWarnEnabled()) {
/* 446 */           this.logger.warn("Async request timed out");
/*     */         }
/* 448 */         return null;
/*     */       }
/*     */     }
/*     */     
/* 452 */     return handleExceptionInternal(ex, null, headers, status, webRequest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResponseEntity<Object> handleExceptionInternal(Exception ex, @Nullable Object body, HttpHeaders headers, HttpStatus status, WebRequest request)
/*     */   {
/* 469 */     if (HttpStatus.INTERNAL_SERVER_ERROR.equals(status)) {
/* 470 */       request.setAttribute("javax.servlet.error.exception", ex, 0);
/*     */     }
/* 472 */     return new ResponseEntity(body, headers, status);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ResponseEntityExceptionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */