/*     */ package org.springframework.web.servlet.config.annotation;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathMatchConfigurer
/*     */ {
/*     */   @Nullable
/*     */   private PathPatternParser patternParser;
/*     */   @Nullable
/*     */   private Boolean trailingSlashMatch;
/*     */   @Nullable
/*     */   private Map<String, Predicate<Class<?>>> pathPrefixes;
/*     */   @Nullable
/*     */   private Boolean suffixPatternMatch;
/*     */   @Nullable
/*     */   private Boolean registeredSuffixPatternMatch;
/*     */   @Nullable
/*     */   private UrlPathHelper urlPathHelper;
/*     */   @Nullable
/*     */   private PathMatcher pathMatcher;
/*     */   @Nullable
/*     */   private PathPatternParser defaultPatternParser;
/*     */   @Nullable
/*     */   private UrlPathHelper defaultUrlPathHelper;
/*     */   @Nullable
/*     */   private PathMatcher defaultPathMatcher;
/*     */   
/*     */   public PathMatchConfigurer setPatternParser(PathPatternParser patternParser)
/*     */   {
/*  87 */     this.patternParser = patternParser;
/*  88 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathMatchConfigurer setUseTrailingSlashMatch(Boolean trailingSlashMatch)
/*     */   {
/*  97 */     this.trailingSlashMatch = trailingSlashMatch;
/*  98 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathMatchConfigurer addPathPrefix(String prefix, Predicate<Class<?>> predicate)
/*     */   {
/* 113 */     if (this.pathPrefixes == null) {
/* 114 */       this.pathPrefixes = new LinkedHashMap();
/*     */     }
/* 116 */     this.pathPrefixes.put(prefix, predicate);
/* 117 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public PathMatchConfigurer setUseSuffixPatternMatch(Boolean suffixPatternMatch)
/*     */   {
/* 134 */     this.suffixPatternMatch = suffixPatternMatch;
/* 135 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public PathMatchConfigurer setUseRegisteredSuffixPatternMatch(Boolean registeredSuffixPatternMatch)
/*     */   {
/* 153 */     this.registeredSuffixPatternMatch = registeredSuffixPatternMatch;
/* 154 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathMatchConfigurer setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/* 163 */     this.urlPathHelper = urlPathHelper;
/* 164 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathMatchConfigurer setPathMatcher(PathMatcher pathMatcher)
/*     */   {
/* 174 */     this.pathMatcher = pathMatcher;
/* 175 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public PathPatternParser getPatternParser()
/*     */   {
/* 185 */     return this.patternParser;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public Boolean isUseTrailingSlashMatch() {
/* 191 */     return this.trailingSlashMatch;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected Map<String, Predicate<Class<?>>> getPathPrefixes() {
/* 196 */     return this.pathPrefixes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public Boolean isUseRegisteredSuffixPatternMatch()
/*     */   {
/* 207 */     return this.registeredSuffixPatternMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public Boolean isUseSuffixPatternMatch()
/*     */   {
/* 218 */     return this.suffixPatternMatch;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public UrlPathHelper getUrlPathHelper() {
/* 223 */     return this.urlPathHelper;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public PathMatcher getPathMatcher() {
/* 228 */     return this.pathMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UrlPathHelper getUrlPathHelperOrDefault()
/*     */   {
/* 236 */     if (this.urlPathHelper != null) {
/* 237 */       return this.urlPathHelper;
/*     */     }
/* 239 */     if (this.defaultUrlPathHelper == null) {
/* 240 */       this.defaultUrlPathHelper = new UrlPathHelper();
/*     */     }
/* 242 */     return this.defaultUrlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PathMatcher getPathMatcherOrDefault()
/*     */   {
/* 250 */     if (this.pathMatcher != null) {
/* 251 */       return this.pathMatcher;
/*     */     }
/* 253 */     if (this.defaultPathMatcher == null) {
/* 254 */       this.defaultPathMatcher = new AntPathMatcher();
/*     */     }
/* 256 */     return this.defaultPathMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathPatternParser getPatternParserOrDefault()
/*     */   {
/* 264 */     if (this.patternParser != null) {
/* 265 */       return this.patternParser;
/*     */     }
/* 267 */     if (this.defaultPatternParser == null) {
/* 268 */       this.defaultPatternParser = new PathPatternParser();
/*     */     }
/* 270 */     return this.defaultPatternParser;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\annotation\PathMatchConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */