/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TagWriter
/*     */ {
/*     */   private final SafeWriter writer;
/*  50 */   private final Deque<TagStateEntry> tagState = new ArrayDeque();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TagWriter(PageContext pageContext)
/*     */   {
/*  59 */     Assert.notNull(pageContext, "PageContext must not be null");
/*  60 */     this.writer = new SafeWriter(pageContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TagWriter(Writer writer)
/*     */   {
/*  69 */     Assert.notNull(writer, "Writer must not be null");
/*  70 */     this.writer = new SafeWriter(writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startTag(String tagName)
/*     */     throws JspException
/*     */   {
/*  80 */     if (inTag()) {
/*  81 */       closeTagAndMarkAsBlock();
/*     */     }
/*  83 */     push(tagName);
/*  84 */     this.writer.append("<").append(tagName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeAttribute(String attributeName, String attributeValue)
/*     */     throws JspException
/*     */   {
/*  94 */     if (currentState().isBlockTag()) {
/*  95 */       throw new IllegalStateException("Cannot write attributes after opening tag is closed.");
/*     */     }
/*     */     
/*  98 */     this.writer.append(" ").append(attributeName).append("=\"").append(attributeValue).append("\"");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeOptionalAttributeValue(String attributeName, @Nullable String attributeValue)
/*     */     throws JspException
/*     */   {
/* 107 */     if (StringUtils.hasText(attributeValue)) {
/* 108 */       writeAttribute(attributeName, attributeValue);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void appendValue(String value)
/*     */     throws JspException
/*     */   {
/* 118 */     if (!inTag()) {
/* 119 */       throw new IllegalStateException("Cannot write tag value. No open tag available.");
/*     */     }
/* 121 */     closeTagAndMarkAsBlock();
/* 122 */     this.writer.append(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void forceBlock()
/*     */     throws JspException
/*     */   {
/* 133 */     if (currentState().isBlockTag()) {
/* 134 */       return;
/*     */     }
/* 136 */     closeTagAndMarkAsBlock();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void endTag()
/*     */     throws JspException
/*     */   {
/* 145 */     endTag(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void endTag(boolean enforceClosingTag)
/*     */     throws JspException
/*     */   {
/* 156 */     if (!inTag()) {
/* 157 */       throw new IllegalStateException("Cannot write end of tag. No open tag available.");
/*     */     }
/* 159 */     boolean renderClosingTag = true;
/* 160 */     if (!currentState().isBlockTag())
/*     */     {
/* 162 */       if (enforceClosingTag) {
/* 163 */         this.writer.append(">");
/*     */       }
/*     */       else {
/* 166 */         this.writer.append("/>");
/* 167 */         renderClosingTag = false;
/*     */       }
/*     */     }
/* 170 */     if (renderClosingTag) {
/* 171 */       this.writer.append("</").append(currentState().getTagName()).append(">");
/*     */     }
/* 173 */     this.tagState.pop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void push(String tagName)
/*     */   {
/* 181 */     this.tagState.push(new TagStateEntry(tagName));
/*     */   }
/*     */   
/*     */ 
/*     */   private void closeTagAndMarkAsBlock()
/*     */     throws JspException
/*     */   {
/* 188 */     if (!currentState().isBlockTag()) {
/* 189 */       currentState().markAsBlockTag();
/* 190 */       this.writer.append(">");
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean inTag() {
/* 195 */     return !this.tagState.isEmpty();
/*     */   }
/*     */   
/*     */   private TagStateEntry currentState() {
/* 199 */     return (TagStateEntry)this.tagState.element();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class TagStateEntry
/*     */   {
/*     */     private final String tagName;
/*     */     
/*     */     private boolean blockTag;
/*     */     
/*     */ 
/*     */     public TagStateEntry(String tagName)
/*     */     {
/* 213 */       this.tagName = tagName;
/*     */     }
/*     */     
/*     */     public String getTagName() {
/* 217 */       return this.tagName;
/*     */     }
/*     */     
/*     */     public void markAsBlockTag() {
/* 221 */       this.blockTag = true;
/*     */     }
/*     */     
/*     */     public boolean isBlockTag() {
/* 225 */       return this.blockTag;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class SafeWriter
/*     */   {
/*     */     @Nullable
/*     */     private PageContext pageContext;
/*     */     
/*     */ 
/*     */     @Nullable
/*     */     private Writer writer;
/*     */     
/*     */ 
/*     */     public SafeWriter(PageContext pageContext)
/*     */     {
/* 243 */       this.pageContext = pageContext;
/*     */     }
/*     */     
/*     */     public SafeWriter(Writer writer) {
/* 247 */       this.writer = writer;
/*     */     }
/*     */     
/*     */     public SafeWriter append(String value) throws JspException {
/*     */       try {
/* 252 */         getWriterToUse().write(String.valueOf(value));
/* 253 */         return this;
/*     */       }
/*     */       catch (IOException ex) {
/* 256 */         throw new JspException("Unable to write to JspWriter", ex);
/*     */       }
/*     */     }
/*     */     
/*     */     private Writer getWriterToUse() {
/* 261 */       Writer writer = this.pageContext != null ? this.pageContext.getOut() : this.writer;
/* 262 */       Assert.state(writer != null, "No Writer available");
/* 263 */       return writer;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\form\TagWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */