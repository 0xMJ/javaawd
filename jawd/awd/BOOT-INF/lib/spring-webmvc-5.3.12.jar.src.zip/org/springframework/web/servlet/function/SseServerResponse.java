/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.time.Duration;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.DelegatingServerHttpResponse;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.context.request.async.DeferredResult;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SseServerResponse
/*     */   extends AbstractServerResponse
/*     */ {
/*     */   private final Consumer<ServerResponse.SseBuilder> sseConsumer;
/*     */   @Nullable
/*     */   private final Duration timeout;
/*     */   
/*     */   private SseServerResponse(Consumer<ServerResponse.SseBuilder> sseConsumer, @Nullable Duration timeout)
/*     */   {
/*  62 */     super(200, createHeaders(), emptyCookies());
/*  63 */     this.sseConsumer = sseConsumer;
/*  64 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */   private static HttpHeaders createHeaders() {
/*  68 */     HttpHeaders headers = new HttpHeaders();
/*  69 */     headers.setContentType(MediaType.TEXT_EVENT_STREAM);
/*  70 */     headers.setCacheControl(CacheControl.noCache());
/*  71 */     return headers;
/*     */   }
/*     */   
/*     */   private static MultiValueMap<String, Cookie> emptyCookies() {
/*  75 */     return CollectionUtils.toMultiValueMap(Collections.emptyMap());
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   protected ModelAndView writeToInternal(HttpServletRequest request, HttpServletResponse response, ServerResponse.Context context)
/*     */     throws ServletException, IOException
/*     */   {
/*     */     DeferredResult<?> result;
/*     */     DeferredResult<?> result;
/*  85 */     if (this.timeout != null) {
/*  86 */       result = new DeferredResult(Long.valueOf(this.timeout.toMillis()));
/*     */     }
/*     */     else {
/*  89 */       result = new DeferredResult();
/*     */     }
/*     */     
/*  92 */     DefaultAsyncServerResponse.writeAsync(request, response, result);
/*  93 */     this.sseConsumer.accept(new DefaultSseBuilder(response, context, result));
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   public static ServerResponse create(Consumer<ServerResponse.SseBuilder> sseConsumer, @Nullable Duration timeout)
/*     */   {
/*  99 */     Assert.notNull(sseConsumer, "SseConsumer must not be null");
/*     */     
/* 101 */     return new SseServerResponse(sseConsumer, timeout);
/*     */   }
/*     */   
/*     */   private static final class DefaultSseBuilder
/*     */     implements ServerResponse.SseBuilder
/*     */   {
/* 107 */     private static final byte[] NL_NL = { 10, 10 };
/*     */     
/*     */ 
/*     */     private final ServerHttpResponse outputMessage;
/*     */     
/*     */     private final DeferredResult<?> deferredResult;
/*     */     
/*     */     private final List<HttpMessageConverter<?>> messageConverters;
/*     */     
/* 116 */     private final StringBuilder builder = new StringBuilder();
/*     */     
/*     */     private boolean sendFailed;
/*     */     
/*     */     public DefaultSseBuilder(HttpServletResponse response, ServerResponse.Context context, DeferredResult<?> deferredResult)
/*     */     {
/* 122 */       this.outputMessage = new ServletServerHttpResponse(response);
/* 123 */       this.deferredResult = deferredResult;
/* 124 */       this.messageConverters = context.messageConverters();
/*     */     }
/*     */     
/*     */     public void send(Object object) throws IOException
/*     */     {
/* 129 */       data(object);
/*     */     }
/*     */     
/*     */     public ServerResponse.SseBuilder id(String id)
/*     */     {
/* 134 */       Assert.hasLength(id, "Id must not be empty");
/* 135 */       return field("id", id);
/*     */     }
/*     */     
/*     */     public ServerResponse.SseBuilder event(String eventName)
/*     */     {
/* 140 */       Assert.hasLength(eventName, "Name must not be empty");
/* 141 */       return field("event", eventName);
/*     */     }
/*     */     
/*     */     public ServerResponse.SseBuilder retry(Duration duration)
/*     */     {
/* 146 */       Assert.notNull(duration, "Duration must not be null");
/* 147 */       String millis = Long.toString(duration.toMillis());
/* 148 */       return field("retry", millis);
/*     */     }
/*     */     
/*     */     public ServerResponse.SseBuilder comment(String comment)
/*     */     {
/* 153 */       Assert.hasLength(comment, "Comment must not be empty");
/* 154 */       String[] lines = comment.split("\n");
/* 155 */       for (String line : lines) {
/* 156 */         field("", line);
/*     */       }
/* 158 */       return this;
/*     */     }
/*     */     
/*     */     private ServerResponse.SseBuilder field(String name, String value) {
/* 162 */       this.builder.append(name).append(':').append(value).append('\n');
/* 163 */       return this;
/*     */     }
/*     */     
/*     */     public void data(Object object) throws IOException
/*     */     {
/* 168 */       Assert.notNull(object, "Object must not be null");
/*     */       
/* 170 */       if ((object instanceof String)) {
/* 171 */         writeString((String)object);
/*     */       }
/*     */       else {
/* 174 */         writeObject(object);
/*     */       }
/*     */     }
/*     */     
/*     */     private void writeString(String string) throws IOException {
/* 179 */       String[] lines = string.split("\n");
/* 180 */       for (String line : lines) {
/* 181 */         field("data", line);
/*     */       }
/* 183 */       this.builder.append('\n');
/*     */       try
/*     */       {
/* 186 */         OutputStream body = this.outputMessage.getBody();
/* 187 */         body.write(builderBytes());
/* 188 */         body.flush();
/*     */       }
/*     */       catch (IOException ex) {
/* 191 */         this.sendFailed = true;
/* 192 */         throw ex;
/*     */       }
/*     */       finally {
/* 195 */         this.builder.setLength(0);
/*     */       }
/*     */     }
/*     */     
/*     */     private void writeObject(Object data) throws IOException
/*     */     {
/* 201 */       this.builder.append("data:");
/*     */       try {
/* 203 */         this.outputMessage.getBody().write(builderBytes());
/*     */         
/* 205 */         dataClass = data.getClass();
/* 206 */         for (HttpMessageConverter<?> converter : this.messageConverters) {
/* 207 */           if (converter.canWrite(dataClass, MediaType.APPLICATION_JSON)) {
/* 208 */             HttpMessageConverter<Object> objectConverter = converter;
/* 209 */             ServerHttpResponse response = new MutableHeadersServerHttpResponse(this.outputMessage);
/* 210 */             objectConverter.write(data, MediaType.APPLICATION_JSON, response);
/* 211 */             this.outputMessage.getBody().write(NL_NL);
/* 212 */             this.outputMessage.flush(); return;
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IOException ex) {
/*     */         Class<?> dataClass;
/* 218 */         this.sendFailed = true;
/* 219 */         throw ex;
/*     */       }
/*     */       finally {
/* 222 */         this.builder.setLength(0);
/*     */       }
/*     */     }
/*     */     
/*     */     private byte[] builderBytes() {
/* 227 */       return this.builder.toString().getBytes(StandardCharsets.UTF_8);
/*     */     }
/*     */     
/*     */     public void error(Throwable t)
/*     */     {
/* 232 */       if (this.sendFailed) {
/* 233 */         return;
/*     */       }
/* 235 */       this.deferredResult.setErrorResult(t);
/*     */     }
/*     */     
/*     */     public void complete()
/*     */     {
/* 240 */       if (this.sendFailed) {
/* 241 */         return;
/*     */       }
/*     */       try {
/* 244 */         this.outputMessage.flush();
/* 245 */         this.deferredResult.setResult(null);
/*     */       }
/*     */       catch (IOException ex) {
/* 248 */         this.deferredResult.setErrorResult(ex);
/*     */       }
/*     */     }
/*     */     
/*     */     public ServerResponse.SseBuilder onTimeout(Runnable onTimeout)
/*     */     {
/* 254 */       this.deferredResult.onTimeout(onTimeout);
/* 255 */       return this;
/*     */     }
/*     */     
/*     */     public ServerResponse.SseBuilder onError(Consumer<Throwable> onError)
/*     */     {
/* 260 */       this.deferredResult.onError(onError);
/* 261 */       return this;
/*     */     }
/*     */     
/*     */     public ServerResponse.SseBuilder onComplete(Runnable onCompletion)
/*     */     {
/* 266 */       this.deferredResult.onCompletion(onCompletion);
/* 267 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private static final class MutableHeadersServerHttpResponse
/*     */       extends DelegatingServerHttpResponse
/*     */     {
/* 277 */       private final HttpHeaders mutableHeaders = new HttpHeaders();
/*     */       
/*     */       public MutableHeadersServerHttpResponse(ServerHttpResponse delegate) {
/* 280 */         super();
/* 281 */         this.mutableHeaders.putAll(delegate.getHeaders());
/*     */       }
/*     */       
/*     */       public HttpHeaders getHeaders()
/*     */       {
/* 286 */         return this.mutableHeaders;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\SseServerResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */