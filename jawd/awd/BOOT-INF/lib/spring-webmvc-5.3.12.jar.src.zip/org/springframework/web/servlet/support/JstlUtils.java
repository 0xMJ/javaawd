/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.jsp.jstl.core.Config;
/*     */ import javax.servlet.jsp.jstl.fmt.LocalizationContext;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.support.MessageSourceResourceBundle;
/*     */ import org.springframework.context.support.ResourceBundleMessageSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JstlUtils
/*     */ {
/*     */   public static MessageSource getJstlAwareMessageSource(@Nullable ServletContext servletContext, MessageSource messageSource)
/*     */   {
/*  58 */     if (servletContext != null) {
/*  59 */       String jstlInitParam = servletContext.getInitParameter("javax.servlet.jsp.jstl.fmt.localizationContext");
/*  60 */       if (jstlInitParam != null)
/*     */       {
/*     */ 
/*     */ 
/*  64 */         ResourceBundleMessageSource jstlBundleWrapper = new ResourceBundleMessageSource();
/*  65 */         jstlBundleWrapper.setBasename(jstlInitParam);
/*  66 */         jstlBundleWrapper.setParentMessageSource(messageSource);
/*  67 */         return jstlBundleWrapper;
/*     */       }
/*     */     }
/*  70 */     return messageSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void exposeLocalizationContext(HttpServletRequest request, @Nullable MessageSource messageSource)
/*     */   {
/*  83 */     Locale jstlLocale = RequestContextUtils.getLocale(request);
/*  84 */     Config.set(request, "javax.servlet.jsp.jstl.fmt.locale", jstlLocale);
/*  85 */     TimeZone timeZone = RequestContextUtils.getTimeZone(request);
/*  86 */     if (timeZone != null) {
/*  87 */       Config.set(request, "javax.servlet.jsp.jstl.fmt.timeZone", timeZone);
/*     */     }
/*  89 */     if (messageSource != null) {
/*  90 */       LocalizationContext jstlContext = new SpringLocalizationContext(messageSource, request);
/*  91 */       Config.set(request, "javax.servlet.jsp.jstl.fmt.localizationContext", jstlContext);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void exposeLocalizationContext(RequestContext requestContext)
/*     */   {
/* 103 */     Config.set(requestContext.getRequest(), "javax.servlet.jsp.jstl.fmt.locale", requestContext.getLocale());
/* 104 */     TimeZone timeZone = requestContext.getTimeZone();
/* 105 */     if (timeZone != null) {
/* 106 */       Config.set(requestContext.getRequest(), "javax.servlet.jsp.jstl.fmt.timeZone", timeZone);
/*     */     }
/* 108 */     MessageSource messageSource = getJstlAwareMessageSource(requestContext
/* 109 */       .getServletContext(), requestContext.getMessageSource());
/* 110 */     LocalizationContext jstlContext = new SpringLocalizationContext(messageSource, requestContext.getRequest());
/* 111 */     Config.set(requestContext.getRequest(), "javax.servlet.jsp.jstl.fmt.localizationContext", jstlContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class SpringLocalizationContext
/*     */     extends LocalizationContext
/*     */   {
/*     */     private final MessageSource messageSource;
/*     */     
/*     */     private final HttpServletRequest request;
/*     */     
/*     */ 
/*     */     public SpringLocalizationContext(MessageSource messageSource, HttpServletRequest request)
/*     */     {
/* 126 */       this.messageSource = messageSource;
/* 127 */       this.request = request;
/*     */     }
/*     */     
/*     */     public ResourceBundle getResourceBundle()
/*     */     {
/* 132 */       HttpSession session = this.request.getSession(false);
/* 133 */       if (session != null) {
/* 134 */         Object lcObject = Config.get(session, "javax.servlet.jsp.jstl.fmt.localizationContext");
/* 135 */         if ((lcObject instanceof LocalizationContext)) {
/* 136 */           ResourceBundle lcBundle = ((LocalizationContext)lcObject).getResourceBundle();
/* 137 */           return new MessageSourceResourceBundle(this.messageSource, getLocale(), lcBundle);
/*     */         }
/*     */       }
/* 140 */       return new MessageSourceResourceBundle(this.messageSource, getLocale());
/*     */     }
/*     */     
/*     */     public Locale getLocale()
/*     */     {
/* 145 */       HttpSession session = this.request.getSession(false);
/* 146 */       if (session != null) {
/* 147 */         Object localeObject = Config.get(session, "javax.servlet.jsp.jstl.fmt.locale");
/* 148 */         if ((localeObject instanceof Locale)) {
/* 149 */           return (Locale)localeObject;
/*     */         }
/*     */       }
/* 152 */       return RequestContextUtils.getLocale(this.request);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\support\JstlUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */