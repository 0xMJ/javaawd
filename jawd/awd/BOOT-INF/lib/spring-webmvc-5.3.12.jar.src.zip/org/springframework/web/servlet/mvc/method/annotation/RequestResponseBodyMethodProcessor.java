/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.MethodArgumentNotValidException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.ResponseBody;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestResponseBodyMethodProcessor
/*     */   extends AbstractMessageConverterMethodProcessor
/*     */ {
/*     */   public RequestResponseBodyMethodProcessor(List<HttpMessageConverter<?>> converters)
/*     */   {
/*  73 */     super(converters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestResponseBodyMethodProcessor(List<HttpMessageConverter<?>> converters, @Nullable ContentNegotiationManager manager)
/*     */   {
/*  85 */     super(converters, manager);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestResponseBodyMethodProcessor(List<HttpMessageConverter<?>> converters, @Nullable List<Object> requestResponseBodyAdvice)
/*     */   {
/*  97 */     super(converters, null, requestResponseBodyAdvice);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestResponseBodyMethodProcessor(List<HttpMessageConverter<?>> converters, @Nullable ContentNegotiationManager manager, @Nullable List<Object> requestResponseBodyAdvice)
/*     */   {
/* 107 */     super(converters, manager, requestResponseBodyAdvice);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/* 113 */     return parameter.hasParameterAnnotation(RequestBody.class);
/*     */   }
/*     */   
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/* 118 */     return (AnnotatedElementUtils.hasAnnotation(returnType.getContainingClass(), ResponseBody.class)) || 
/* 119 */       (returnType.hasMethodAnnotation(ResponseBody.class));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, @Nullable ModelAndViewContainer mavContainer, NativeWebRequest webRequest, @Nullable WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/* 132 */     parameter = parameter.nestedIfOptional();
/* 133 */     Object arg = readWithMessageConverters(webRequest, parameter, parameter.getNestedGenericParameterType());
/* 134 */     String name = Conventions.getVariableNameForParameter(parameter);
/*     */     
/* 136 */     if (binderFactory != null) {
/* 137 */       WebDataBinder binder = binderFactory.createBinder(webRequest, arg, name);
/* 138 */       if (arg != null) {
/* 139 */         validateIfApplicable(binder, parameter);
/* 140 */         if ((binder.getBindingResult().hasErrors()) && (isBindExceptionRequired(binder, parameter))) {
/* 141 */           throw new MethodArgumentNotValidException(parameter, binder.getBindingResult());
/*     */         }
/*     */       }
/* 144 */       if (mavContainer != null) {
/* 145 */         mavContainer.addAttribute(BindingResult.MODEL_KEY_PREFIX + name, binder.getBindingResult());
/*     */       }
/*     */     }
/*     */     
/* 149 */     return adaptArgumentIfNecessary(arg, parameter);
/*     */   }
/*     */   
/*     */ 
/*     */   protected <T> Object readWithMessageConverters(NativeWebRequest webRequest, MethodParameter parameter, Type paramType)
/*     */     throws IOException, HttpMediaTypeNotSupportedException, HttpMessageNotReadableException
/*     */   {
/* 156 */     HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/* 157 */     Assert.state(servletRequest != null, "No HttpServletRequest");
/* 158 */     ServletServerHttpRequest inputMessage = new ServletServerHttpRequest(servletRequest);
/*     */     
/* 160 */     Object arg = readWithMessageConverters(inputMessage, parameter, paramType);
/* 161 */     if ((arg == null) && (checkRequired(parameter)))
/*     */     {
/* 163 */       throw new HttpMessageNotReadableException("Required request body is missing: " + parameter.getExecutable().toGenericString(), inputMessage);
/*     */     }
/* 165 */     return arg;
/*     */   }
/*     */   
/*     */   protected boolean checkRequired(MethodParameter parameter) {
/* 169 */     RequestBody requestBody = (RequestBody)parameter.getParameterAnnotation(RequestBody.class);
/* 170 */     return (requestBody != null) && (requestBody.required()) && (!parameter.isOptional());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleReturnValue(@Nullable Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws IOException, HttpMediaTypeNotAcceptableException, HttpMessageNotWritableException
/*     */   {
/* 178 */     mavContainer.setRequestHandled(true);
/* 179 */     ServletServerHttpRequest inputMessage = createInputMessage(webRequest);
/* 180 */     ServletServerHttpResponse outputMessage = createOutputMessage(webRequest);
/*     */     
/*     */ 
/* 183 */     writeWithMessageConverters(returnValue, returnType, inputMessage, outputMessage);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\RequestResponseBodyMethodProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */