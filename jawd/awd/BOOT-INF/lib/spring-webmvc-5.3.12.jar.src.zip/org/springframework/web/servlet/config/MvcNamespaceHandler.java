/*    */ package org.springframework.web.servlet.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MvcNamespaceHandler
/*    */   extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init()
/*    */   {
/* 34 */     registerBeanDefinitionParser("annotation-driven", new AnnotationDrivenBeanDefinitionParser());
/* 35 */     registerBeanDefinitionParser("default-servlet-handler", new DefaultServletHandlerBeanDefinitionParser());
/* 36 */     registerBeanDefinitionParser("interceptors", new InterceptorsBeanDefinitionParser());
/* 37 */     registerBeanDefinitionParser("resources", new ResourcesBeanDefinitionParser());
/* 38 */     registerBeanDefinitionParser("view-controller", new ViewControllerBeanDefinitionParser());
/* 39 */     registerBeanDefinitionParser("redirect-view-controller", new ViewControllerBeanDefinitionParser());
/* 40 */     registerBeanDefinitionParser("status-controller", new ViewControllerBeanDefinitionParser());
/* 41 */     registerBeanDefinitionParser("view-resolvers", new ViewResolversBeanDefinitionParser());
/* 42 */     registerBeanDefinitionParser("tiles-configurer", new TilesConfigurerBeanDefinitionParser());
/* 43 */     registerBeanDefinitionParser("freemarker-configurer", new FreeMarkerConfigurerBeanDefinitionParser());
/* 44 */     registerBeanDefinitionParser("groovy-configurer", new GroovyMarkupConfigurerBeanDefinitionParser());
/* 45 */     registerBeanDefinitionParser("script-template-configurer", new ScriptTemplateConfigurerBeanDefinitionParser());
/* 46 */     registerBeanDefinitionParser("cors", new CorsBeanDefinitionParser());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\MvcNamespaceHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */