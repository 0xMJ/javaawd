/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.servlet.support.RequestDataValueProcessor;
/*     */ import org.springframework.web.servlet.tags.EditorAwareTag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDataBoundFormElementTag
/*     */   extends AbstractFormTag
/*     */   implements EditorAwareTag
/*     */ {
/*     */   protected static final String NESTED_PATH_VARIABLE_NAME = "nestedPath";
/*     */   @Nullable
/*     */   private String path;
/*     */   @Nullable
/*     */   private String id;
/*     */   @Nullable
/*     */   private BindStatus bindStatus;
/*     */   
/*     */   public void setPath(String path)
/*     */   {
/*  80 */     this.path = path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final String getPath()
/*     */     throws JspException
/*     */   {
/*  88 */     String resolvedPath = (String)evaluate("path", this.path);
/*  89 */     return resolvedPath != null ? resolvedPath : "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setId(@Nullable String id)
/*     */   {
/*  99 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public String getId()
/*     */   {
/* 108 */     return this.id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeDefaultAttributes(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 122 */     writeOptionalAttribute(tagWriter, "id", resolveId());
/* 123 */     writeOptionalAttribute(tagWriter, "name", getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String resolveId()
/*     */     throws JspException
/*     */   {
/* 134 */     Object id = evaluate("id", getId());
/* 135 */     if (id != null) {
/* 136 */       String idString = id.toString();
/* 137 */       return StringUtils.hasText(idString) ? idString : null;
/*     */     }
/* 139 */     return autogenerateId();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String autogenerateId()
/*     */     throws JspException
/*     */   {
/* 149 */     String name = getName();
/* 150 */     return name != null ? StringUtils.deleteAny(name, "[]") : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getName()
/*     */     throws JspException
/*     */   {
/* 164 */     return getPropertyPath();
/*     */   }
/*     */   
/*     */ 
/*     */   protected BindStatus getBindStatus()
/*     */     throws JspException
/*     */   {
/* 171 */     if (this.bindStatus == null)
/*     */     {
/* 173 */       String nestedPath = getNestedPath();
/* 174 */       String pathToUse = nestedPath != null ? nestedPath + getPath() : getPath();
/* 175 */       if (pathToUse.endsWith(".")) {
/* 176 */         pathToUse = pathToUse.substring(0, pathToUse.length() - 1);
/*     */       }
/* 178 */       this.bindStatus = new BindStatus(getRequestContext(), pathToUse, false);
/*     */     }
/* 180 */     return this.bindStatus;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getNestedPath()
/*     */   {
/* 189 */     return (String)this.pageContext.getAttribute("nestedPath", 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getPropertyPath()
/*     */     throws JspException
/*     */   {
/* 199 */     String expression = getBindStatus().getExpression();
/* 200 */     return expression != null ? expression : "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected final Object getBoundValue()
/*     */     throws JspException
/*     */   {
/* 209 */     return getBindStatus().getValue();
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   protected PropertyEditor getPropertyEditor()
/*     */     throws JspException
/*     */   {
/* 217 */     return getBindStatus().getEditor();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public final PropertyEditor getEditor()
/*     */     throws JspException
/*     */   {
/* 227 */     return getPropertyEditor();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String convertToDisplayString(@Nullable Object value)
/*     */     throws JspException
/*     */   {
/* 235 */     PropertyEditor editor = value != null ? getBindStatus().findEditor(value.getClass()) : null;
/* 236 */     return getDisplayString(value, editor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String processFieldValue(@Nullable String name, String value, String type)
/*     */   {
/* 244 */     RequestDataValueProcessor processor = getRequestContext().getRequestDataValueProcessor();
/* 245 */     ServletRequest request = this.pageContext.getRequest();
/* 246 */     if ((processor != null) && ((request instanceof HttpServletRequest))) {
/* 247 */       value = processor.processFormFieldValue((HttpServletRequest)request, name, value, type);
/*     */     }
/* 249 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFinally()
/*     */   {
/* 257 */     super.doFinally();
/* 258 */     this.bindStatus = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\form\AbstractDataBoundFormElementTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */