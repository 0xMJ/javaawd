package org.springframework.web.servlet.resource;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import org.springframework.core.io.Resource;

@FunctionalInterface
public abstract interface ResourceTransformer
{
  public abstract Resource transform(HttpServletRequest paramHttpServletRequest, Resource paramResource, ResourceTransformerChain paramResourceTransformerChain)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\ResourceTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */