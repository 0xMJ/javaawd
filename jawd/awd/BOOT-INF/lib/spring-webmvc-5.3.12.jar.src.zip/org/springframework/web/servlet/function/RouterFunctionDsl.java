/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.Optional;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.function.Supplier;
/*     */ import kotlin.Metadata;
/*     */ import kotlin.Unit;
/*     */ import kotlin.jvm.functions.Function0;
/*     */ import kotlin.jvm.functions.Function1;
/*     */ import kotlin.jvm.functions.Function2;
/*     */ import kotlin.jvm.internal.FunctionReference;
/*     */ import kotlin.jvm.internal.Intrinsics;
/*     */ import kotlin.jvm.internal.Lambda;
/*     */ import kotlin.reflect.KDeclarationContainer;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.MediaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Metadata(mv={1, 1, 18}, bv={1, 0, 3}, k=1, d1={"\000\001\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\020\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\002\b\t\n\002\020\021\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\006\n\002\030\002\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\003\n\002\b\n\n\002\030\002\n\002\b\002\n\002\020\b\n\002\030\002\n\002\b\t\030\0002\0020\001B \b\000\022\027\020\002\032\023\022\004\022\0020\000\022\004\022\0020\0040\003¢\006\002\b\005¢\006\002\020\006J\032\020\r\032\0020\0042\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\016\020\r\032\0020\0212\006\020\022\032\0020\023J\"\020\r\032\0020\0042\006\020\022\032\0020\0232\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J*\020\r\032\0020\0042\006\020\022\032\0020\0232\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\"\020\r\032\0020\0042\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\032\020\025\032\0020\0042\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\016\020\025\032\0020\0212\006\020\022\032\0020\023J\"\020\025\032\0020\0042\006\020\022\032\0020\0232\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J*\020\025\032\0020\0042\006\020\022\032\0020\0232\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\"\020\025\032\0020\0042\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\032\020\026\032\0020\0042\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\016\020\026\032\0020\0212\006\020\022\032\0020\023J\"\020\026\032\0020\0042\006\020\022\032\0020\0232\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J*\020\026\032\0020\0042\006\020\022\032\0020\0232\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\"\020\026\032\0020\0042\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\032\020\027\032\0020\0042\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\016\020\027\032\0020\0212\006\020\022\032\0020\023J\"\020\027\032\0020\0042\006\020\022\032\0020\0232\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J*\020\027\032\0020\0042\006\020\022\032\0020\0232\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\"\020\027\032\0020\0042\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\032\020\030\032\0020\0042\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\016\020\030\032\0020\0212\006\020\022\032\0020\023J\"\020\030\032\0020\0042\006\020\022\032\0020\0232\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J*\020\030\032\0020\0042\006\020\022\032\0020\0232\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\"\020\030\032\0020\0042\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\032\020\031\032\0020\0042\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\016\020\031\032\0020\0212\006\020\022\032\0020\023J\"\020\031\032\0020\0042\006\020\022\032\0020\0232\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J*\020\031\032\0020\0042\006\020\022\032\0020\0232\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\"\020\031\032\0020\0042\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\032\020\032\032\0020\0042\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\016\020\032\032\0020\0212\006\020\022\032\0020\023J\"\020\032\032\0020\0042\006\020\022\032\0020\0232\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J*\020\032\032\0020\0042\006\020\022\032\0020\0232\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\"\020\032\032\0020\0042\006\020\024\032\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\037\020\033\032\0020\0212\022\020\034\032\n\022\006\b\001\022\0020\0360\035\"\0020\036¢\006\002\020\037J\"\020\033\032\0020\0042\006\020\034\032\0020\0362\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\006\020 \032\0020!J\024\020\"\032\0020\0042\f\020#\032\b\022\004\022\0020\0200$J \020%\032\0020\0042\030\020&\032\024\022\004\022\0020\017\022\004\022\0020\020\022\004\022\0020\0200'J\006\020(\032\0020!J\032\020)\032\0020\0042\022\020*\032\016\022\004\022\0020\017\022\004\022\0020\0170\003J\023\020+\032\b\022\004\022\0020\0200$H\000¢\006\002\b,J\037\020-\032\0020\0212\022\020.\032\n\022\006\b\001\022\0020\0360\035\"\0020\036¢\006\002\020\037J\"\020-\032\0020\0042\006\020\034\032\0020\0362\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\016\020/\032\0020!2\006\0200\032\00201J,\0202\032\0020\0042$\0203\032 \022\004\022\0020\017\022\020\022\016\022\004\022\0020\017\022\004\022\0020\0200\003\022\004\022\0020\0200'J\016\0204\032\0020!2\006\0205\032\0020\020J\032\0206\032\0020\0212\022\0207\032\016\022\004\022\00208\022\004\022\002090\003J.\0206\032\0020\0042\022\0207\032\016\022\004\022\00208\022\004\022\002090\0032\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\016\020:\032\0020\0212\006\020;\032\0020<J\"\020:\032\0020\0042\006\020;\032\0020<2\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\n\020=\032\006\022\002\b\0030>J\n\020?\032\006\022\002\b\0030>J\006\020@\032\0020!J4\020A\032\0020\0042\022\020\024\032\016\022\004\022\0020B\022\004\022\002090\0032\030\020C\032\024\022\004\022\0020B\022\004\022\0020\017\022\004\022\0020\0200'J1\020A\032\0020\004\"\n\b\000\020D\030\001*\0020B2\032\b\b\020C\032\024\022\004\022\0020B\022\004\022\0020\017\022\004\022\0020\0200'H\bJ\"\020E\032\0020\0212\006\020F\032\0020\0232\022\020\024\032\016\022\004\022\0020\023\022\004\022\002090\003J6\020E\032\0020\0042\006\020F\032\0020\0232\022\020\024\032\016\022\004\022\0020\023\022\004\022\002090\0032\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\016\020G\032\0020\0212\006\020\022\032\0020\023J\"\020G\032\0020\0042\006\020\022\032\0020\0232\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\032\020H\032\0020\0212\022\020\024\032\016\022\004\022\0020\023\022\004\022\002090\003J.\020H\032\0020\0042\022\020\024\032\016\022\004\022\0020\023\022\004\022\002090\0032\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\016\020H\032\0020\0212\006\020I\032\0020\023J\"\020H\032\0020\0042\006\020I\032\0020\0232\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003J\016\020J\032\0020!2\006\0200\032\00201J\034\020K\032\0020\0042\024\020L\032\020\022\004\022\0020\017\022\006\022\004\030\0010M0\003J\026\020K\032\0020\0042\006\020G\032\0020\0232\006\0200\032\0020MJ\016\020N\032\0020!2\006\0200\032\00201J\016\020O\032\0020!2\006\020O\032\0020PJ\016\020O\032\0020!2\006\020O\032\0020QJ\016\020R\032\0020!2\006\0200\032\00201J\006\020S\032\0020!J\025\020T\032\0020\021*\0020\0232\006\0205\032\0020\021H\004J\025\020T\032\0020\021*\0020\0212\006\0205\032\0020\023H\004J\025\020T\032\0020\021*\0020\0212\006\0205\032\0020\021H\004J!\020U\032\0020\004*\0020\0232\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003H\002J!\020U\032\0020\004*\0020\0212\022\020\016\032\016\022\004\022\0020\017\022\004\022\0020\0200\003H\002J#\020V\032\0020\004*\0020\0232\027\020W\032\023\022\004\022\0020\000\022\004\022\0020\0040\003¢\006\002\b\005J#\020V\032\0020\004*\0020\0212\027\020W\032\023\022\004\022\0020\000\022\004\022\0020\0040\003¢\006\002\b\005J\r\020X\032\0020\021*\0020\021H\002J\025\020Y\032\0020\021*\0020\0232\006\0205\032\0020\021H\004J\025\020Y\032\0020\021*\0020\0212\006\0205\032\0020\023H\004J\025\020Y\032\0020\021*\0020\0212\006\0205\032\0020\021H\004R\034\020\007\032\0020\b8\000X\004¢\006\016\n\000\022\004\b\t\020\n\032\004\b\013\020\fR\037\020\002\032\023\022\004\022\0020\000\022\004\022\0020\0040\003¢\006\002\b\005X\004¢\006\002\n\000¨\006Z"}, d2={"Lorg/springframework/web/servlet/function/RouterFunctionDsl;", "", "init", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "(Lkotlin/jvm/functions/Function1;)V", "builder", "Lorg/springframework/web/servlet/function/RouterFunctions$Builder;", "builder$annotations", "()V", "getBuilder", "()Lorg/springframework/web/servlet/function/RouterFunctions$Builder;", "DELETE", "f", "Lorg/springframework/web/servlet/function/ServerRequest;", "Lorg/springframework/web/servlet/function/ServerResponse;", "Lorg/springframework/web/servlet/function/RequestPredicate;", "pattern", "", "predicate", "GET", "HEAD", "OPTIONS", "PATCH", "POST", "PUT", "accept", "mediaType", "", "Lorg/springframework/http/MediaType;", "([Lorg/springframework/http/MediaType;)Lorg/springframework/web/servlet/function/RequestPredicate;", "accepted", "Lorg/springframework/web/servlet/function/ServerResponse$BodyBuilder;", "add", "routerFunction", "Lorg/springframework/web/servlet/function/RouterFunction;", "after", "responseProcessor", "Lkotlin/Function2;", "badRequest", "before", "requestProcessor", "build", "build$spring_webmvc", "contentType", "mediaTypes", "created", "location", "Ljava/net/URI;", "filter", "filterFunction", "from", "other", "headers", "headersPredicate", "Lorg/springframework/web/servlet/function/ServerRequest$Headers;", "", "method", "httpMethod", "Lorg/springframework/http/HttpMethod;", "noContent", "Lorg/springframework/web/servlet/function/ServerResponse$HeadersBuilder;", "notFound", "ok", "onError", "", "responseProvider", "E", "param", "name", "path", "pathExtension", "extension", "permanentRedirect", "resources", "lookupFunction", "Lorg/springframework/core/io/Resource;", "seeOther", "status", "", "Lorg/springframework/http/HttpStatus;", "temporaryRedirect", "unprocessableEntity", "and", "invoke", "nest", "r", "not", "or", "spring-webmvc"})
/*     */ public final class RouterFunctionDsl
/*     */ {
/*     */   @NotNull
/*     */   private final RouterFunctions.Builder builder;
/*     */   private final Function1<RouterFunctionDsl, Unit> init;
/*     */   
/*     */   @NotNull
/*     */   public final RouterFunctions.Builder getBuilder()
/*     */   {
/*  65 */     return this.builder;
/*     */   }
/*     */   
/*     */   public RouterFunctionDsl(@NotNull Function1<? super RouterFunctionDsl, Unit> init)
/*     */   {
/*  62 */     this.init = init; RouterFunctions.Builder 
/*     */     
/*     */ 
/*  65 */       tmp20_17 = RouterFunctions.route();Intrinsics.checkExpressionValueIsNotNull(tmp20_17, "RouterFunctions.route()");this.builder = tmp20_17;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate and(@NotNull RequestPredicate $this$and, @NotNull String other)
/*     */   {
/*  75 */     Intrinsics.checkParameterIsNotNull($this$and, "$this$and");Intrinsics.checkParameterIsNotNull(other, "other"); RequestPredicate tmp23_18 = $this$and.and(path(other));Intrinsics.checkExpressionValueIsNotNull(tmp23_18, "this.and(path(other))");return tmp23_18;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate or(@NotNull RequestPredicate $this$or, @NotNull String other)
/*     */   {
/*  85 */     Intrinsics.checkParameterIsNotNull($this$or, "$this$or");Intrinsics.checkParameterIsNotNull(other, "other"); RequestPredicate tmp23_18 = $this$or.or(path(other));Intrinsics.checkExpressionValueIsNotNull(tmp23_18, "this.or(path(other))");return tmp23_18;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate and(@NotNull String $this$and, @NotNull RequestPredicate other)
/*     */   {
/*  95 */     Intrinsics.checkParameterIsNotNull($this$and, "$this$and");Intrinsics.checkParameterIsNotNull(other, "other"); RequestPredicate tmp23_18 = path($this$and).and(other);Intrinsics.checkExpressionValueIsNotNull(tmp23_18, "path(this).and(other)");return tmp23_18;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate or(@NotNull String $this$or, @NotNull RequestPredicate other)
/*     */   {
/* 105 */     Intrinsics.checkParameterIsNotNull($this$or, "$this$or");Intrinsics.checkParameterIsNotNull(other, "other"); RequestPredicate tmp23_18 = path($this$or).or(other);Intrinsics.checkExpressionValueIsNotNull(tmp23_18, "path(this).or(other)");return tmp23_18;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate and(@NotNull RequestPredicate $this$and, @NotNull RequestPredicate other)
/*     */   {
/* 113 */     Intrinsics.checkParameterIsNotNull($this$and, "$this$and");Intrinsics.checkParameterIsNotNull(other, "other"); RequestPredicate tmp19_14 = $this$and.and(other);Intrinsics.checkExpressionValueIsNotNull(tmp19_14, "this.and(other)");return tmp19_14;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate or(@NotNull RequestPredicate $this$or, @NotNull RequestPredicate other)
/*     */   {
/* 121 */     Intrinsics.checkParameterIsNotNull($this$or, "$this$or");Intrinsics.checkParameterIsNotNull(other, "other"); RequestPredicate tmp19_14 = $this$or.or(other);Intrinsics.checkExpressionValueIsNotNull(tmp19_14, "this.or(other)");return tmp19_14;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final RequestPredicate not(@NotNull RequestPredicate $this$not) {
/* 126 */     Intrinsics.checkParameterIsNotNull($this$not, "$this$not"); RequestPredicate tmp12_7 = $this$not.negate();Intrinsics.checkExpressionValueIsNotNull(tmp12_7, "this.negate()");return tmp12_7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void nest(@NotNull String $this$nest, @NotNull Function1<? super RouterFunctionDsl, Unit> r)
/*     */   {
/* 146 */     Intrinsics.checkParameterIsNotNull($this$nest, "$this$nest");Intrinsics.checkParameterIsNotNull(r, "r");nest(path($this$nest), r);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void GET(@NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 153 */     Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.GET((HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void GET(@NotNull String pattern, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 162 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.GET(pattern, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void GET(@NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 172 */     Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.GET(predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void GET(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 183 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.GET(pattern, predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate GET(@NotNull String pattern)
/*     */   {
/* 191 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern"); RequestPredicate tmp10_7 = RequestPredicates.GET(pattern);Intrinsics.checkExpressionValueIsNotNull(tmp10_7, "RequestPredicates.GET(pattern)");return tmp10_7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void HEAD(@NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 198 */     Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.HEAD((HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void HEAD(@NotNull String pattern, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 207 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.HEAD(pattern, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void HEAD(@NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 217 */     Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.HEAD(predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void HEAD(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 228 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.HEAD(pattern, predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate HEAD(@NotNull String pattern)
/*     */   {
/* 236 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern"); RequestPredicate tmp10_7 = RequestPredicates.HEAD(pattern);Intrinsics.checkExpressionValueIsNotNull(tmp10_7, "RequestPredicates.HEAD(pattern)");return tmp10_7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void POST(@NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 243 */     Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.POST((HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void POST(@NotNull String pattern, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 252 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.POST(pattern, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void POST(@NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 262 */     Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.POST(predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void POST(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 273 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.POST(pattern, predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate POST(@NotNull String pattern)
/*     */   {
/* 281 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern"); RequestPredicate tmp10_7 = RequestPredicates.POST(pattern);Intrinsics.checkExpressionValueIsNotNull(tmp10_7, "RequestPredicates.POST(pattern)");return tmp10_7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void PUT(@NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 288 */     Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.PUT((HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void PUT(@NotNull String pattern, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 297 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.PUT(pattern, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void PUT(@NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 307 */     Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.PUT(predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void PUT(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 318 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.PUT(pattern, predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate PUT(@NotNull String pattern)
/*     */   {
/* 326 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern"); RequestPredicate tmp10_7 = RequestPredicates.PUT(pattern);Intrinsics.checkExpressionValueIsNotNull(tmp10_7, "RequestPredicates.PUT(pattern)");return tmp10_7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void PATCH(@NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 333 */     Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.PATCH((HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void PATCH(@NotNull String pattern, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 342 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.PATCH(pattern, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void PATCH(@NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 352 */     Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.PATCH(predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void PATCH(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 363 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.PATCH(pattern, predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate PATCH(@NotNull String pattern)
/*     */   {
/* 373 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern"); RequestPredicate tmp10_7 = RequestPredicates.PATCH(pattern);Intrinsics.checkExpressionValueIsNotNull(tmp10_7, "RequestPredicates.PATCH(pattern)");return tmp10_7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void DELETE(@NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 380 */     Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.DELETE((HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void DELETE(@NotNull String pattern, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 389 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.DELETE(pattern, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void DELETE(@NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 399 */     Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.DELETE(predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void DELETE(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 410 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.DELETE(pattern, predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate DELETE(@NotNull String pattern)
/*     */   {
/* 420 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern"); RequestPredicate tmp10_7 = RequestPredicates.DELETE(pattern);Intrinsics.checkExpressionValueIsNotNull(tmp10_7, "RequestPredicates.DELETE(pattern)");return tmp10_7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void OPTIONS(@NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 427 */     Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.OPTIONS((HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void OPTIONS(@NotNull String pattern, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 436 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.OPTIONS(pattern, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void OPTIONS(@NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 446 */     Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.OPTIONS(predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void OPTIONS(@NotNull String pattern, @NotNull RequestPredicate predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 457 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.OPTIONS(pattern, predicate, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate OPTIONS(@NotNull String pattern)
/*     */   {
/* 467 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern"); RequestPredicate tmp10_7 = RequestPredicates.OPTIONS(pattern);Intrinsics.checkExpressionValueIsNotNull(tmp10_7, "RequestPredicates.OPTIONS(pattern)");return tmp10_7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void accept(@NotNull MediaType mediaType, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 474 */     Intrinsics.checkParameterIsNotNull(mediaType, "mediaType");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.add(RouterFunctions.route(RequestPredicates.accept(new MediaType[] { mediaType }), (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate accept(@NotNull MediaType... mediaType)
/*     */   {
/* 484 */     Intrinsics.checkParameterIsNotNull(mediaType, "mediaType"); MediaType[] tmp7_6 = mediaType; RequestPredicate tmp18_15 = RequestPredicates.accept((MediaType[])Arrays.copyOf(tmp7_6, tmp7_6.length));Intrinsics.checkExpressionValueIsNotNull(tmp18_15, "RequestPredicates.accept(*mediaType)");return tmp18_15;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void contentType(@NotNull MediaType mediaType, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 491 */     Intrinsics.checkParameterIsNotNull(mediaType, "mediaType");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.add(RouterFunctions.route(RequestPredicates.contentType(new MediaType[] { mediaType }), (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate contentType(@NotNull MediaType... mediaTypes)
/*     */   {
/* 501 */     Intrinsics.checkParameterIsNotNull(mediaTypes, "mediaTypes"); MediaType[] tmp7_6 = mediaTypes; RequestPredicate tmp18_15 = RequestPredicates.contentType((MediaType[])Arrays.copyOf(tmp7_6, tmp7_6.length));Intrinsics.checkExpressionValueIsNotNull(tmp18_15, "RequestPredicates.contentType(*mediaTypes)");return tmp18_15;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void headers(@NotNull Function1<? super ServerRequest.Headers, Boolean> headersPredicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 508 */     Intrinsics.checkParameterIsNotNull(headersPredicate, "headersPredicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = headersPredicate;localFunction1 = f;this.builder.add(RouterFunctions.route(RequestPredicates.headers((Predicate)new RouterFunctionDslKt.sam.java_util_function_Predicate.0(localFunction1)), (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate headers(@NotNull Function1<? super ServerRequest.Headers, Boolean> headersPredicate)
/*     */   {
/* 517 */     Intrinsics.checkParameterIsNotNull(headersPredicate, "headersPredicate");Function1 localFunction1 = headersPredicate; RequestPredicate tmp23_20 = RequestPredicates.headers((Predicate)new RouterFunctionDslKt.sam.java_util_function_Predicate.0(localFunction1));Intrinsics.checkExpressionValueIsNotNull(tmp23_20, "RequestPredicates.headers(headersPredicate)");return tmp23_20;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void method(@NotNull HttpMethod httpMethod, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 524 */     Intrinsics.checkParameterIsNotNull(httpMethod, "httpMethod");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.add(RouterFunctions.route(RequestPredicates.method(httpMethod), (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate method(@NotNull HttpMethod httpMethod)
/*     */   {
/* 532 */     Intrinsics.checkParameterIsNotNull(httpMethod, "httpMethod"); RequestPredicate tmp11_8 = RequestPredicates.method(httpMethod);Intrinsics.checkExpressionValueIsNotNull(tmp11_8, "RequestPredicates.method(httpMethod)");return tmp11_8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void path(@NotNull String pattern, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 539 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.add(RouterFunctions.route(RequestPredicates.path(pattern), (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1)));
/*     */   }
/*     */   
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate path(@NotNull String pattern)
/*     */   {
/* 546 */     Intrinsics.checkParameterIsNotNull(pattern, "pattern"); RequestPredicate tmp10_7 = RequestPredicates.path(pattern);Intrinsics.checkExpressionValueIsNotNull(tmp10_7, "RequestPredicates.path(pattern)");return tmp10_7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void pathExtension(@NotNull String extension, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 553 */     Intrinsics.checkParameterIsNotNull(extension, "extension");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.add(RouterFunctions.route(RequestPredicates.pathExtension(extension), (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate pathExtension(@NotNull String extension)
/*     */   {
/* 561 */     Intrinsics.checkParameterIsNotNull(extension, "extension"); RequestPredicate tmp11_8 = RequestPredicates.pathExtension(extension);Intrinsics.checkExpressionValueIsNotNull(tmp11_8, "RequestPredicates.pathExtension(extension)");return tmp11_8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void pathExtension(@NotNull Function1<? super String, Boolean> predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 568 */     Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = predicate;localFunction1 = f;this.builder.add(RouterFunctions.route(RequestPredicates.pathExtension((Predicate)new RouterFunctionDslKt.sam.java_util_function_Predicate.0(localFunction1)), (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate pathExtension(@NotNull Function1<? super String, Boolean> predicate)
/*     */   {
/* 577 */     Intrinsics.checkParameterIsNotNull(predicate, "predicate");Function1 localFunction1 = predicate; RequestPredicate tmp22_19 = RequestPredicates.pathExtension((Predicate)new RouterFunctionDslKt.sam.java_util_function_Predicate.0(localFunction1));Intrinsics.checkExpressionValueIsNotNull(tmp22_19, "RequestPredicates.pathExtension(predicate)");return tmp22_19;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void param(@NotNull String name, @NotNull Function1<? super String, Boolean> predicate, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 584 */     Intrinsics.checkParameterIsNotNull(name, "name");Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = predicate;localFunction1 = f;this.builder.add(RouterFunctions.route(RequestPredicates.param(name, (Predicate)new RouterFunctionDslKt.sam.java_util_function_Predicate.0(localFunction1)), (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RequestPredicate param(@NotNull String name, @NotNull Function1<? super String, Boolean> predicate)
/*     */   {
/* 596 */     Intrinsics.checkParameterIsNotNull(name, "name");Intrinsics.checkParameterIsNotNull(predicate, "predicate");Function1 localFunction1 = predicate; RequestPredicate tmp30_27 = RequestPredicates.param(name, (Predicate)new RouterFunctionDslKt.sam.java_util_function_Predicate.0(localFunction1));Intrinsics.checkExpressionValueIsNotNull(tmp30_27, "RequestPredicates.param(name, predicate)");return tmp30_27;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void invoke(@NotNull RequestPredicate $this$invoke, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 603 */     Intrinsics.checkParameterIsNotNull($this$invoke, "$this$invoke");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.add(RouterFunctions.route($this$invoke, (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void invoke(@NotNull String $this$invoke, @NotNull Function1<? super ServerRequest, ? extends ServerResponse> f)
/*     */   {
/* 612 */     Intrinsics.checkParameterIsNotNull($this$invoke, "$this$invoke");Intrinsics.checkParameterIsNotNull(f, "f");Function1 localFunction1 = f;this.builder.add(RouterFunctions.route(RequestPredicates.path($this$invoke), (HandlerFunction)new RouterFunctionDslKt.sam.org_springframework_web_servlet_function_HandlerFunction.0(localFunction1)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void resources(@NotNull String path, @NotNull Resource location)
/*     */   {
/* 620 */     Intrinsics.checkParameterIsNotNull(path, "path");Intrinsics.checkParameterIsNotNull(location, "location");this.builder.resources(path, location);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void resources(@NotNull Function1<? super ServerRequest, ? extends Resource> lookupFunction)
/*     */   {
/* 629 */     Intrinsics.checkParameterIsNotNull(lookupFunction, "lookupFunction");this.builder.resources((Function)new Function() { @NotNull
/* 630 */       public final Optional<Resource> apply(ServerRequest it) { ServerRequest tmp5_4 = it;Intrinsics.checkExpressionValueIsNotNull(tmp5_4, "it");return Optional.ofNullable(this.$lookupFunction.invoke(tmp5_4));
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void add(@NotNull RouterFunction<ServerResponse> routerFunction)
/*     */   {
/* 640 */     Intrinsics.checkParameterIsNotNull(routerFunction, "routerFunction");this.builder.add(routerFunction);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void filter(@NotNull Function2<? super ServerRequest, ? super Function1<? super ServerRequest, ? extends ServerResponse>, ? extends ServerResponse> filterFunction)
/*     */   {
/* 651 */     Intrinsics.checkParameterIsNotNull(filterFunction, "filterFunction");this.builder.filter((HandlerFilterFunction)new HandlerFilterFunction() { @NotNull
/* 652 */       public final ServerResponse filter(@NotNull ServerRequest request, @NotNull HandlerFunction<ServerResponse> next) { Intrinsics.checkParameterIsNotNull(request, "request");Intrinsics.checkParameterIsNotNull(next, "next");(ServerResponse)this.$filterFunction.invoke(request, new Lambda(next) { @NotNull
/* 653 */           public final ServerResponse invoke(@NotNull ServerRequest handlerRequest) { Intrinsics.checkParameterIsNotNull(handlerRequest, "handlerRequest"); ServerResponse tmp16_11 = this.$next.handle(handlerRequest);Intrinsics.checkExpressionValueIsNotNull(tmp16_11, "next.handle(handlerRequest)");return tmp16_11;
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void before(@NotNull Function1<? super ServerRequest, ? extends ServerRequest> requestProcessor)
/*     */   {
/* 666 */     Intrinsics.checkParameterIsNotNull(requestProcessor, "requestProcessor");Function1 localFunction1 = requestProcessor;this.builder.before((Function)new RouterFunctionDslKt.sam.java_util_function_Function.0(localFunction1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void after(@NotNull Function2<? super ServerRequest, ? super ServerResponse, ? extends ServerResponse> responseProcessor)
/*     */   {
/* 677 */     Intrinsics.checkParameterIsNotNull(responseProcessor, "responseProcessor");Function2 localFunction2 = responseProcessor;this.builder.after((BiFunction)new RouterFunctionDslKt.sam.java_util_function_BiFunction.0(localFunction2));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void onError(@NotNull Function1<? super Throwable, Boolean> predicate, @NotNull Function2<? super Throwable, ? super ServerRequest, ? extends ServerResponse> responseProvider)
/*     */   {
/* 688 */     Intrinsics.checkParameterIsNotNull(predicate, "predicate");Intrinsics.checkParameterIsNotNull(responseProvider, "responseProvider");Object localObject = predicate;localObject = responseProvider;this.builder.onError((Predicate)new RouterFunctionDslKt.sam.java_util_function_Predicate.0((Function1)localObject), (BiFunction)new RouterFunctionDslKt.sam.java_util_function_BiFunction.0((Function2)localObject));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @NotNull
/*     */   public final RouterFunction<ServerResponse> build$spring_webmvc()
/*     */   {
/* 706 */     this.init.invoke(this); RouterFunction 
/* 707 */       tmp20_15 = this.builder.build();Intrinsics.checkExpressionValueIsNotNull(tmp20_15, "builder.build()");return tmp20_15;
/*     */   }
/*     */   
/*     */ 
/*     */   @NotNull
/*     */   public final ServerResponse.BodyBuilder from(@NotNull ServerResponse other)
/*     */   {
/* 714 */     Intrinsics.checkParameterIsNotNull(other, "other"); ServerResponse.BodyBuilder tmp10_7 = ServerResponse.from(other);Intrinsics.checkExpressionValueIsNotNull(tmp10_7, "ServerResponse.from(other)");return tmp10_7;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ServerResponse.BodyBuilder created(@NotNull URI location)
/*     */   {
/* 720 */     Intrinsics.checkParameterIsNotNull(location, "location"); ServerResponse.BodyBuilder tmp11_8 = ServerResponse.created(location);Intrinsics.checkExpressionValueIsNotNull(tmp11_8, "ServerResponse.created(location)");return tmp11_8;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ServerResponse.BodyBuilder ok() {
/* 725 */     ServerResponse.BodyBuilder tmp3_0 = ServerResponse.ok();Intrinsics.checkExpressionValueIsNotNull(tmp3_0, "ServerResponse.ok()");return tmp3_0;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ServerResponse.HeadersBuilder<?> noContent() {
/* 730 */     ServerResponse.HeadersBuilder tmp3_0 = ServerResponse.noContent();Intrinsics.checkExpressionValueIsNotNull(tmp3_0, "ServerResponse.noContent()");return tmp3_0;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ServerResponse.BodyBuilder accepted() {
/* 735 */     ServerResponse.BodyBuilder tmp3_0 = ServerResponse.accepted();Intrinsics.checkExpressionValueIsNotNull(tmp3_0, "ServerResponse.accepted()");return tmp3_0;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ServerResponse.BodyBuilder permanentRedirect(@NotNull URI location) {
/* 740 */     Intrinsics.checkParameterIsNotNull(location, "location"); ServerResponse.BodyBuilder tmp11_8 = ServerResponse.permanentRedirect(location);Intrinsics.checkExpressionValueIsNotNull(tmp11_8, "ServerResponse.permanentRedirect(location)");return tmp11_8;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ServerResponse.BodyBuilder temporaryRedirect(@NotNull URI location) {
/* 745 */     Intrinsics.checkParameterIsNotNull(location, "location"); ServerResponse.BodyBuilder tmp11_8 = ServerResponse.temporaryRedirect(location);Intrinsics.checkExpressionValueIsNotNull(tmp11_8, "ServerResponse.temporaryRedirect(location)");return tmp11_8;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ServerResponse.BodyBuilder seeOther(@NotNull URI location) {
/* 750 */     Intrinsics.checkParameterIsNotNull(location, "location"); ServerResponse.BodyBuilder tmp11_8 = ServerResponse.seeOther(location);Intrinsics.checkExpressionValueIsNotNull(tmp11_8, "ServerResponse.seeOther(location)");return tmp11_8;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ServerResponse.BodyBuilder badRequest() {
/* 755 */     ServerResponse.BodyBuilder tmp3_0 = ServerResponse.badRequest();Intrinsics.checkExpressionValueIsNotNull(tmp3_0, "ServerResponse.badRequest()");return tmp3_0;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ServerResponse.HeadersBuilder<?> notFound() {
/* 760 */     ServerResponse.HeadersBuilder tmp3_0 = ServerResponse.notFound();Intrinsics.checkExpressionValueIsNotNull(tmp3_0, "ServerResponse.notFound()");return tmp3_0;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ServerResponse.BodyBuilder unprocessableEntity() {
/* 765 */     ServerResponse.BodyBuilder tmp3_0 = ServerResponse.unprocessableEntity();Intrinsics.checkExpressionValueIsNotNull(tmp3_0, "ServerResponse.unprocessableEntity()");return tmp3_0;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ServerResponse.BodyBuilder status(@NotNull HttpStatus status) {
/* 770 */     Intrinsics.checkParameterIsNotNull(status, "status"); ServerResponse.BodyBuilder tmp11_8 = ServerResponse.status(status);Intrinsics.checkExpressionValueIsNotNull(tmp11_8, "ServerResponse.status(status)");return tmp11_8;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public final ServerResponse.BodyBuilder status(int status) {
/* 775 */     ServerResponse.BodyBuilder tmp4_1 = ServerResponse.status(status);Intrinsics.checkExpressionValueIsNotNull(tmp4_1, "ServerResponse.status(status)");return tmp4_1;
/*     */   }
/*     */   
/*     */   public final void nest(@NotNull RequestPredicate $this$nest, @NotNull Function1<? super RouterFunctionDsl, Unit> r)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc 75
/*     */     //   3: invokestatic 26	kotlin/jvm/internal/Intrinsics:checkParameterIsNotNull	(Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: aload_2
/*     */     //   7: ldc 77
/*     */     //   9: invokestatic 26	kotlin/jvm/internal/Intrinsics:checkParameterIsNotNull	(Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   12: aload_0
/*     */     //   13: getfield 14	org/springframework/web/servlet/function/RouterFunctionDsl:builder	Lorg/springframework/web/servlet/function/RouterFunctions$Builder;
/*     */     //   16: aload_1
/*     */     //   17: new 79	org/springframework/web/servlet/function/RouterFunctionDsl$nest$1
/*     */     //   20: dup
/*     */     //   21: new 2	org/springframework/web/servlet/function/RouterFunctionDsl
/*     */     //   24: dup
/*     */     //   25: aload_2
/*     */     //   26: invokespecial 83	org/springframework/web/servlet/function/RouterFunctionDsl:<init>	(Lkotlin/jvm/functions/Function1;)V
/*     */     //   29: invokespecial 86	org/springframework/web/servlet/function/RouterFunctionDsl$nest$1:<init>	(Lorg/springframework/web/servlet/function/RouterFunctionDsl;)V
/*     */     //   32: checkcast 88	kotlin/jvm/functions/Function0
/*     */     //   35: astore_3
/*     */     //   36: new 90	org/springframework/web/servlet/function/RouterFunctionDslKt$sam$java_util_function_Supplier$0
/*     */     //   39: dup
/*     */     //   40: aload_3
/*     */     //   41: invokespecial 93	org/springframework/web/servlet/function/RouterFunctionDslKt$sam$java_util_function_Supplier$0:<init>	(Lkotlin/jvm/functions/Function0;)V
/*     */     //   44: checkcast 95	java/util/function/Supplier
/*     */     //   47: invokeinterface 100 3 0
/*     */     //   52: pop
/*     */     //   53: return
/*     */     // Line number table:
/*     */     //   Java source line #135	-> byte code offset #12
/*     */     //   Java source line #136	-> byte code offset #53
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	54	0	this	RouterFunctionDsl
/*     */     //   0	54	1	$this$nest	RequestPredicate
/*     */     //   0	54	2	r	Function1
/*     */     //   35	6	3	localFunction0	Function0
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\RouterFunctionDsl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */