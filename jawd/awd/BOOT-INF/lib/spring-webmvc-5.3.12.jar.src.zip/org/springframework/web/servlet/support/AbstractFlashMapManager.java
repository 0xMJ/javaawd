/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.FlashMap;
/*     */ import org.springframework.web.servlet.FlashMapManager;
/*     */ import org.springframework.web.util.UriComponents;
/*     */ import org.springframework.web.util.UriComponentsBuilder;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFlashMapManager
/*     */   implements FlashMapManager
/*     */ {
/*  50 */   private static final Object DEFAULT_FLASH_MAPS_MUTEX = new Object();
/*     */   
/*     */ 
/*  53 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  55 */   private int flashMapTimeout = 180;
/*     */   
/*  57 */   private UrlPathHelper urlPathHelper = UrlPathHelper.defaultInstance;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlashMapTimeout(int flashMapTimeout)
/*     */   {
/*  66 */     this.flashMapTimeout = flashMapTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFlashMapTimeout()
/*     */   {
/*  73 */     return this.flashMapTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUrlPathHelper(UrlPathHelper urlPathHelper)
/*     */   {
/*  80 */     Assert.notNull(urlPathHelper, "UrlPathHelper must not be null");
/*  81 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public UrlPathHelper getUrlPathHelper()
/*     */   {
/*  88 */     return this.urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   public final FlashMap retrieveAndUpdate(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  95 */     List<FlashMap> allFlashMaps = retrieveFlashMaps(request);
/*  96 */     if (CollectionUtils.isEmpty(allFlashMaps)) {
/*  97 */       return null;
/*     */     }
/*     */     
/* 100 */     List<FlashMap> mapsToRemove = getExpiredFlashMaps(allFlashMaps);
/* 101 */     FlashMap match = getMatchingFlashMap(allFlashMaps, request);
/* 102 */     if (match != null) {
/* 103 */       mapsToRemove.add(match);
/*     */     }
/*     */     
/* 106 */     if (!mapsToRemove.isEmpty()) {
/* 107 */       Object mutex = getFlashMapsMutex(request);
/* 108 */       if (mutex != null) {
/* 109 */         synchronized (mutex) {
/* 110 */           allFlashMaps = retrieveFlashMaps(request);
/* 111 */           if (allFlashMaps != null) {
/* 112 */             allFlashMaps.removeAll(mapsToRemove);
/* 113 */             updateFlashMaps(allFlashMaps, request, response);
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 118 */         allFlashMaps.removeAll(mapsToRemove);
/* 119 */         updateFlashMaps(allFlashMaps, request, response);
/*     */       }
/*     */     }
/*     */     
/* 123 */     return match;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private List<FlashMap> getExpiredFlashMaps(List<FlashMap> allMaps)
/*     */   {
/* 130 */     List<FlashMap> result = new ArrayList();
/* 131 */     for (FlashMap map : allMaps) {
/* 132 */       if (map.isExpired()) {
/* 133 */         result.add(map);
/*     */       }
/*     */     }
/* 136 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private FlashMap getMatchingFlashMap(List<FlashMap> allMaps, HttpServletRequest request)
/*     */   {
/* 145 */     List<FlashMap> result = new ArrayList();
/* 146 */     for (FlashMap flashMap : allMaps) {
/* 147 */       if (isFlashMapForRequest(flashMap, request)) {
/* 148 */         result.add(flashMap);
/*     */       }
/*     */     }
/* 151 */     if (!result.isEmpty()) {
/* 152 */       Collections.sort(result);
/* 153 */       if (this.logger.isTraceEnabled()) {
/* 154 */         this.logger.trace("Found " + result.get(0));
/*     */       }
/* 156 */       return (FlashMap)result.get(0);
/*     */     }
/* 158 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isFlashMapForRequest(FlashMap flashMap, HttpServletRequest request)
/*     */   {
/* 166 */     String expectedPath = flashMap.getTargetRequestPath();
/* 167 */     if (expectedPath != null) {
/* 168 */       String requestUri = getUrlPathHelper().getOriginatingRequestUri(request);
/* 169 */       if ((!requestUri.equals(expectedPath)) && (!requestUri.equals(expectedPath + "/"))) {
/* 170 */         return false;
/*     */       }
/*     */     }
/* 173 */     MultiValueMap<String, String> actualParams = getOriginatingRequestParams(request);
/* 174 */     MultiValueMap<String, String> expectedParams = flashMap.getTargetRequestParams();
/* 175 */     for (Map.Entry<String, List<String>> entry : expectedParams.entrySet()) {
/* 176 */       actualValues = (List)actualParams.get(entry.getKey());
/* 177 */       if (actualValues == null) {
/* 178 */         return false;
/*     */       }
/* 180 */       for (String expectedValue : (List)entry.getValue()) {
/* 181 */         if (!actualValues.contains(expectedValue))
/* 182 */           return false;
/*     */       }
/*     */     }
/*     */     List<String> actualValues;
/* 186 */     return true;
/*     */   }
/*     */   
/*     */   private MultiValueMap<String, String> getOriginatingRequestParams(HttpServletRequest request) {
/* 190 */     String query = getUrlPathHelper().getOriginatingQueryString(request);
/* 191 */     return ServletUriComponentsBuilder.fromPath("/").query(query).build().getQueryParams();
/*     */   }
/*     */   
/*     */   public final void saveOutputFlashMap(FlashMap flashMap, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 196 */     if (CollectionUtils.isEmpty(flashMap)) {
/* 197 */       return;
/*     */     }
/*     */     
/* 200 */     String path = decodeAndNormalizePath(flashMap.getTargetRequestPath(), request);
/* 201 */     flashMap.setTargetRequestPath(path);
/*     */     
/* 203 */     flashMap.startExpirationPeriod(getFlashMapTimeout());
/*     */     
/* 205 */     Object mutex = getFlashMapsMutex(request);
/* 206 */     if (mutex != null) {
/* 207 */       synchronized (mutex) {
/* 208 */         List<FlashMap> allFlashMaps = retrieveFlashMaps(request);
/* 209 */         allFlashMaps = allFlashMaps != null ? allFlashMaps : new CopyOnWriteArrayList();
/* 210 */         allFlashMaps.add(flashMap);
/* 211 */         updateFlashMaps(allFlashMaps, request, response);
/*     */       }
/*     */     }
/*     */     else {
/* 215 */       List<FlashMap> allFlashMaps = retrieveFlashMaps(request);
/* 216 */       allFlashMaps = allFlashMaps != null ? allFlashMaps : new ArrayList(1);
/* 217 */       allFlashMaps.add(flashMap);
/* 218 */       updateFlashMaps(allFlashMaps, request, response);
/*     */     }
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private String decodeAndNormalizePath(@Nullable String path, HttpServletRequest request) {
/* 224 */     if ((path != null) && (!path.isEmpty())) {
/* 225 */       path = getUrlPathHelper().decodeRequestString(request, path);
/* 226 */       if (path.charAt(0) != '/') {
/* 227 */         String requestUri = getUrlPathHelper().getRequestUri(request);
/* 228 */         path = requestUri.substring(0, requestUri.lastIndexOf('/') + 1) + path;
/* 229 */         path = StringUtils.cleanPath(path);
/*     */       }
/*     */     }
/* 232 */     return path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected abstract List<FlashMap> retrieveFlashMaps(HttpServletRequest paramHttpServletRequest);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void updateFlashMaps(List<FlashMap> paramList, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object getFlashMapsMutex(HttpServletRequest request)
/*     */   {
/* 264 */     return DEFAULT_FLASH_MAPS_MUTEX;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\support\AbstractFlashMapManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */