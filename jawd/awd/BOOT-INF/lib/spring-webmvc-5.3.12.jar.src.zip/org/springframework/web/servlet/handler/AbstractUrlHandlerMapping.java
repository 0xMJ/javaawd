/*     */ package org.springframework.web.servlet.handler;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.HandlerExecutionChain;
/*     */ import org.springframework.web.servlet.HandlerInterceptor;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractUrlHandlerMapping
/*     */   extends AbstractHandlerMapping
/*     */   implements MatchableHandlerMapping
/*     */ {
/*     */   @Nullable
/*     */   private Object rootHandler;
/*  69 */   private boolean useTrailingSlashMatch = false;
/*     */   
/*  71 */   private boolean lazyInitHandlers = false;
/*     */   
/*  73 */   private final Map<String, Object> handlerMap = new LinkedHashMap();
/*     */   
/*  75 */   private final Map<PathPattern, Object> pathPatternHandlerMap = new LinkedHashMap();
/*     */   
/*     */ 
/*     */   public void setPatternParser(PathPatternParser patternParser)
/*     */   {
/*  80 */     Assert.state(this.handlerMap.isEmpty(), "PathPatternParser must be set before the initialization of the handler map via ApplicationContextAware#setApplicationContext.");
/*     */     
/*     */ 
/*  83 */     super.setPatternParser(patternParser);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRootHandler(@Nullable Object rootHandler)
/*     */   {
/*  92 */     this.rootHandler = rootHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object getRootHandler()
/*     */   {
/* 101 */     return this.rootHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseTrailingSlashMatch(boolean useTrailingSlashMatch)
/*     */   {
/* 110 */     this.useTrailingSlashMatch = useTrailingSlashMatch;
/* 111 */     if (getPatternParser() != null) {
/* 112 */       getPatternParser().setMatchOptionalTrailingSeparator(useTrailingSlashMatch);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean useTrailingSlashMatch()
/*     */   {
/* 120 */     return this.useTrailingSlashMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLazyInitHandlers(boolean lazyInitHandlers)
/*     */   {
/* 134 */     this.lazyInitHandlers = lazyInitHandlers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object getHandlerInternal(HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 145 */     String lookupPath = initLookupPath(request);
/*     */     Object handler;
/* 147 */     Object handler; if (usesPathPatterns()) {
/* 148 */       RequestPath path = ServletRequestPathUtils.getParsedRequestPath(request);
/* 149 */       handler = lookupHandler(path, lookupPath, request);
/*     */     }
/*     */     else {
/* 152 */       handler = lookupHandler(lookupPath, request);
/*     */     }
/* 154 */     if (handler == null)
/*     */     {
/*     */ 
/* 157 */       Object rawHandler = null;
/* 158 */       if (StringUtils.matchesCharacter(lookupPath, '/')) {
/* 159 */         rawHandler = getRootHandler();
/*     */       }
/* 161 */       if (rawHandler == null) {
/* 162 */         rawHandler = getDefaultHandler();
/*     */       }
/* 164 */       if (rawHandler != null)
/*     */       {
/* 166 */         if ((rawHandler instanceof String)) {
/* 167 */           String handlerName = (String)rawHandler;
/* 168 */           rawHandler = obtainApplicationContext().getBean(handlerName);
/*     */         }
/* 170 */         validateHandler(rawHandler, request);
/* 171 */         handler = buildPathExposingHandler(rawHandler, lookupPath, lookupPath, null);
/*     */       }
/*     */     }
/* 174 */     return handler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object lookupHandler(RequestPath path, String lookupPath, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 190 */     Object handler = getDirectMatch(lookupPath, request);
/* 191 */     if (handler != null) {
/* 192 */       return handler;
/*     */     }
/*     */     
/*     */ 
/* 196 */     List<PathPattern> matches = null;
/* 197 */     for (PathPattern pattern : this.pathPatternHandlerMap.keySet()) {
/* 198 */       if (pattern.matches(path.pathWithinApplication())) {
/* 199 */         matches = matches != null ? matches : new ArrayList();
/* 200 */         matches.add(pattern);
/*     */       }
/*     */     }
/* 203 */     if (matches == null) {
/* 204 */       return null;
/*     */     }
/* 206 */     if (matches.size() > 1) {
/* 207 */       matches.sort(PathPattern.SPECIFICITY_COMPARATOR);
/* 208 */       if (this.logger.isTraceEnabled()) {
/* 209 */         this.logger.trace("Matching patterns " + matches);
/*     */       }
/*     */     }
/* 212 */     PathPattern pattern = (PathPattern)matches.get(0);
/* 213 */     handler = this.pathPatternHandlerMap.get(pattern);
/* 214 */     if ((handler instanceof String)) {
/* 215 */       String handlerName = (String)handler;
/* 216 */       handler = obtainApplicationContext().getBean(handlerName);
/*     */     }
/* 218 */     validateHandler(handler, request);
/* 219 */     PathContainer pathWithinMapping = pattern.extractPathWithinPattern(path.pathWithinApplication());
/* 220 */     return buildPathExposingHandler(handler, pattern.getPatternString(), pathWithinMapping.value(), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object lookupHandler(String lookupPath, HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/* 234 */     Object handler = getDirectMatch(lookupPath, request);
/* 235 */     if (handler != null) {
/* 236 */       return handler;
/*     */     }
/*     */     
/*     */ 
/* 240 */     List<String> matchingPatterns = new ArrayList();
/* 241 */     for (String registeredPattern : this.handlerMap.keySet()) {
/* 242 */       if (getPathMatcher().match(registeredPattern, lookupPath)) {
/* 243 */         matchingPatterns.add(registeredPattern);
/*     */       }
/* 245 */       else if ((useTrailingSlashMatch()) && 
/* 246 */         (!registeredPattern.endsWith("/")) && (getPathMatcher().match(registeredPattern + "/", lookupPath))) {
/* 247 */         matchingPatterns.add(registeredPattern + "/");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 252 */     String bestMatch = null;
/* 253 */     Comparator<String> patternComparator = getPathMatcher().getPatternComparator(lookupPath);
/* 254 */     if (!matchingPatterns.isEmpty()) {
/* 255 */       matchingPatterns.sort(patternComparator);
/* 256 */       if ((this.logger.isTraceEnabled()) && (matchingPatterns.size() > 1)) {
/* 257 */         this.logger.trace("Matching patterns " + matchingPatterns);
/*     */       }
/* 259 */       bestMatch = (String)matchingPatterns.get(0);
/*     */     }
/* 261 */     if (bestMatch != null) {
/* 262 */       handler = this.handlerMap.get(bestMatch);
/* 263 */       if (handler == null) {
/* 264 */         if (bestMatch.endsWith("/")) {
/* 265 */           handler = this.handlerMap.get(bestMatch.substring(0, bestMatch.length() - 1));
/*     */         }
/* 267 */         if (handler == null) {
/* 268 */           throw new IllegalStateException("Could not find handler for best pattern match [" + bestMatch + "]");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 273 */       if ((handler instanceof String)) {
/* 274 */         String handlerName = (String)handler;
/* 275 */         handler = obtainApplicationContext().getBean(handlerName);
/*     */       }
/* 277 */       validateHandler(handler, request);
/* 278 */       String pathWithinMapping = getPathMatcher().extractPathWithinPattern(bestMatch, lookupPath);
/*     */       
/*     */ 
/*     */ 
/* 282 */       Map<String, String> uriTemplateVariables = new LinkedHashMap();
/* 283 */       for (String matchingPattern : matchingPatterns) {
/* 284 */         if (patternComparator.compare(bestMatch, matchingPattern) == 0) {
/* 285 */           Map<String, String> vars = getPathMatcher().extractUriTemplateVariables(matchingPattern, lookupPath);
/* 286 */           Map<String, String> decodedVars = getUrlPathHelper().decodePathVariables(request, vars);
/* 287 */           uriTemplateVariables.putAll(decodedVars);
/*     */         }
/*     */       }
/* 290 */       if ((this.logger.isTraceEnabled()) && (uriTemplateVariables.size() > 0)) {
/* 291 */         this.logger.trace("URI variables " + uriTemplateVariables);
/*     */       }
/* 293 */       return buildPathExposingHandler(handler, bestMatch, pathWithinMapping, uriTemplateVariables);
/*     */     }
/*     */     
/*     */ 
/* 297 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object getDirectMatch(String urlPath, HttpServletRequest request) throws Exception {
/* 302 */     Object handler = this.handlerMap.get(urlPath);
/* 303 */     if (handler != null)
/*     */     {
/* 305 */       if ((handler instanceof String)) {
/* 306 */         String handlerName = (String)handler;
/* 307 */         handler = obtainApplicationContext().getBean(handlerName);
/*     */       }
/* 309 */       validateHandler(handler, request);
/* 310 */       return buildPathExposingHandler(handler, urlPath, urlPath, null);
/*     */     }
/* 312 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateHandler(Object handler, HttpServletRequest request)
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object buildPathExposingHandler(Object rawHandler, String bestMatchingPattern, String pathWithinMapping, @Nullable Map<String, String> uriTemplateVariables)
/*     */   {
/* 341 */     HandlerExecutionChain chain = new HandlerExecutionChain(rawHandler);
/* 342 */     chain.addInterceptor(new PathExposingHandlerInterceptor(bestMatchingPattern, pathWithinMapping));
/* 343 */     if (!CollectionUtils.isEmpty(uriTemplateVariables)) {
/* 344 */       chain.addInterceptor(new UriTemplateVariablesHandlerInterceptor(uriTemplateVariables));
/*     */     }
/* 346 */     return chain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void exposePathWithinMapping(String bestMatchingPattern, String pathWithinMapping, HttpServletRequest request)
/*     */   {
/* 358 */     request.setAttribute(BEST_MATCHING_PATTERN_ATTRIBUTE, bestMatchingPattern);
/* 359 */     request.setAttribute(PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE, pathWithinMapping);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void exposeUriTemplateVariables(Map<String, String> uriTemplateVariables, HttpServletRequest request)
/*     */   {
/* 369 */     request.setAttribute(URI_TEMPLATE_VARIABLES_ATTRIBUTE, uriTemplateVariables);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public RequestMatchResult match(HttpServletRequest request, String pattern)
/*     */   {
/* 375 */     Assert.isNull(getPatternParser(), "This HandlerMapping uses PathPatterns.");
/* 376 */     String lookupPath = UrlPathHelper.getResolvedLookupPath(request);
/* 377 */     if (getPathMatcher().match(pattern, lookupPath)) {
/* 378 */       return new RequestMatchResult(pattern, lookupPath, getPathMatcher());
/*     */     }
/* 380 */     if ((useTrailingSlashMatch()) && 
/* 381 */       (!pattern.endsWith("/")) && (getPathMatcher().match(pattern + "/", lookupPath))) {
/* 382 */       return new RequestMatchResult(pattern + "/", lookupPath, getPathMatcher());
/*     */     }
/*     */     
/* 385 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerHandler(String[] urlPaths, String beanName)
/*     */     throws BeansException, IllegalStateException
/*     */   {
/* 396 */     Assert.notNull(urlPaths, "URL path array must not be null");
/* 397 */     for (String urlPath : urlPaths) {
/* 398 */       registerHandler(urlPath, beanName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerHandler(String urlPath, Object handler)
/*     */     throws BeansException, IllegalStateException
/*     */   {
/* 411 */     Assert.notNull(urlPath, "URL path must not be null");
/* 412 */     Assert.notNull(handler, "Handler object must not be null");
/* 413 */     Object resolvedHandler = handler;
/*     */     
/*     */ 
/* 416 */     if ((!this.lazyInitHandlers) && ((handler instanceof String))) {
/* 417 */       String handlerName = (String)handler;
/* 418 */       ApplicationContext applicationContext = obtainApplicationContext();
/* 419 */       if (applicationContext.isSingleton(handlerName)) {
/* 420 */         resolvedHandler = applicationContext.getBean(handlerName);
/*     */       }
/*     */     }
/*     */     
/* 424 */     Object mappedHandler = this.handlerMap.get(urlPath);
/* 425 */     if (mappedHandler != null) {
/* 426 */       if (mappedHandler != resolvedHandler)
/*     */       {
/*     */ 
/* 429 */         throw new IllegalStateException("Cannot map " + getHandlerDescription(handler) + " to URL path [" + urlPath + "]: There is already " + getHandlerDescription(mappedHandler) + " mapped.");
/*     */       }
/*     */       
/*     */     }
/* 433 */     else if (urlPath.equals("/")) {
/* 434 */       if (this.logger.isTraceEnabled()) {
/* 435 */         this.logger.trace("Root mapping to " + getHandlerDescription(handler));
/*     */       }
/* 437 */       setRootHandler(resolvedHandler);
/*     */     }
/* 439 */     else if (urlPath.equals("/*")) {
/* 440 */       if (this.logger.isTraceEnabled()) {
/* 441 */         this.logger.trace("Default mapping to " + getHandlerDescription(handler));
/*     */       }
/* 443 */       setDefaultHandler(resolvedHandler);
/*     */     }
/*     */     else {
/* 446 */       this.handlerMap.put(urlPath, resolvedHandler);
/* 447 */       if (getPatternParser() != null) {
/* 448 */         this.pathPatternHandlerMap.put(getPatternParser().parse(urlPath), resolvedHandler);
/*     */       }
/* 450 */       if (this.logger.isTraceEnabled()) {
/* 451 */         this.logger.trace("Mapped [" + urlPath + "] onto " + getHandlerDescription(handler));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private String getHandlerDescription(Object handler)
/*     */   {
/* 458 */     return (handler instanceof String) ? "'" + handler + "'" : handler.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Map<String, Object> getHandlerMap()
/*     */   {
/* 469 */     return Collections.unmodifiableMap(this.handlerMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Map<PathPattern, Object> getPathPatternHandlerMap()
/*     */   {
/* 478 */     return this.pathPatternHandlerMap.isEmpty() ? 
/* 479 */       Collections.emptyMap() : Collections.unmodifiableMap(this.pathPatternHandlerMap);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean supportsTypeLevelMappings()
/*     */   {
/* 486 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class PathExposingHandlerInterceptor
/*     */     implements HandlerInterceptor
/*     */   {
/*     */     private final String bestMatchingPattern;
/*     */     
/*     */ 
/*     */     private final String pathWithinMapping;
/*     */     
/*     */ 
/*     */     public PathExposingHandlerInterceptor(String bestMatchingPattern, String pathWithinMapping)
/*     */     {
/* 502 */       this.bestMatchingPattern = bestMatchingPattern;
/* 503 */       this.pathWithinMapping = pathWithinMapping;
/*     */     }
/*     */     
/*     */     public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     {
/* 508 */       AbstractUrlHandlerMapping.this.exposePathWithinMapping(this.bestMatchingPattern, this.pathWithinMapping, request);
/* 509 */       request.setAttribute(HandlerMapping.BEST_MATCHING_HANDLER_ATTRIBUTE, handler);
/* 510 */       request.setAttribute(HandlerMapping.INTROSPECT_TYPE_LEVEL_MAPPING, Boolean.valueOf(AbstractUrlHandlerMapping.this.supportsTypeLevelMappings()));
/* 511 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class UriTemplateVariablesHandlerInterceptor
/*     */     implements HandlerInterceptor
/*     */   {
/*     */     private final Map<String, String> uriTemplateVariables;
/*     */     
/*     */ 
/*     */ 
/*     */     public UriTemplateVariablesHandlerInterceptor()
/*     */     {
/* 526 */       this.uriTemplateVariables = uriTemplateVariables;
/*     */     }
/*     */     
/*     */     public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*     */     {
/* 531 */       AbstractUrlHandlerMapping.this.exposeUriTemplateVariables(this.uriTemplateVariables, request);
/* 532 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\handler\AbstractUrlHandlerMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */