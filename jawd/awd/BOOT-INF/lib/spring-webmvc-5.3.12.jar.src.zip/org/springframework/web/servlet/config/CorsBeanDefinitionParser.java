/*    */ package org.springframework.web.servlet.config;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.util.xml.DomUtils;
/*    */ import org.springframework.web.cors.CorsConfiguration;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CorsBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   @Nullable
/*    */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*    */   {
/* 49 */     Map<String, CorsConfiguration> corsConfigurations = new LinkedHashMap();
/* 50 */     List<Element> mappings = DomUtils.getChildElementsByTagName(element, "mapping");
/*    */     CorsConfiguration config;
/* 52 */     if (mappings.isEmpty()) {
/* 53 */       config = new CorsConfiguration().applyPermitDefaultValues();
/* 54 */       corsConfigurations.put("/**", config);
/*    */     }
/*    */     else {
/* 57 */       for (Element mapping : mappings) {
/* 58 */         CorsConfiguration config = new CorsConfiguration();
/* 59 */         if (mapping.hasAttribute("allowed-origins")) {
/* 60 */           String[] allowedOrigins = StringUtils.tokenizeToStringArray(mapping.getAttribute("allowed-origins"), ",");
/* 61 */           config.setAllowedOrigins(Arrays.asList(allowedOrigins));
/*    */         }
/* 63 */         if (mapping.hasAttribute("allowed-origin-patterns")) {
/* 64 */           String[] patterns = StringUtils.tokenizeToStringArray(mapping.getAttribute("allowed-origin-patterns"), ",");
/* 65 */           config.setAllowedOriginPatterns(Arrays.asList(patterns));
/*    */         }
/* 67 */         if (mapping.hasAttribute("allowed-methods")) {
/* 68 */           String[] allowedMethods = StringUtils.tokenizeToStringArray(mapping.getAttribute("allowed-methods"), ",");
/* 69 */           config.setAllowedMethods(Arrays.asList(allowedMethods));
/*    */         }
/* 71 */         if (mapping.hasAttribute("allowed-headers")) {
/* 72 */           String[] allowedHeaders = StringUtils.tokenizeToStringArray(mapping.getAttribute("allowed-headers"), ",");
/* 73 */           config.setAllowedHeaders(Arrays.asList(allowedHeaders));
/*    */         }
/* 75 */         if (mapping.hasAttribute("exposed-headers")) {
/* 76 */           String[] exposedHeaders = StringUtils.tokenizeToStringArray(mapping.getAttribute("exposed-headers"), ",");
/* 77 */           config.setExposedHeaders(Arrays.asList(exposedHeaders));
/*    */         }
/* 79 */         if (mapping.hasAttribute("allow-credentials")) {
/* 80 */           config.setAllowCredentials(Boolean.valueOf(Boolean.parseBoolean(mapping.getAttribute("allow-credentials"))));
/*    */         }
/* 82 */         if (mapping.hasAttribute("max-age")) {
/* 83 */           config.setMaxAge(Long.valueOf(Long.parseLong(mapping.getAttribute("max-age"))));
/*    */         }
/* 85 */         config.applyPermitDefaultValues();
/* 86 */         config.validateAllowCredentials();
/* 87 */         corsConfigurations.put(mapping.getAttribute("path"), config);
/*    */       }
/*    */     }
/*    */     
/* 91 */     MvcNamespaceUtils.registerCorsConfigurations(corsConfigurations, parserContext, parserContext
/* 92 */       .extractSource(element));
/* 93 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\CorsBeanDefinitionParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */