/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternalResourceViewResolver
/*     */   extends UrlBasedViewResolver
/*     */ {
/*  51 */   private static final boolean jstlPresent = ClassUtils.isPresent("javax.servlet.jsp.jstl.core.Config", InternalResourceViewResolver.class
/*  52 */     .getClassLoader());
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Boolean alwaysInclude;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InternalResourceViewResolver()
/*     */   {
/*  64 */     Class<?> viewClass = requiredViewClass();
/*  65 */     if ((InternalResourceView.class == viewClass) && (jstlPresent)) {
/*  66 */       viewClass = JstlView.class;
/*     */     }
/*  68 */     setViewClass(viewClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InternalResourceViewResolver(String prefix, String suffix)
/*     */   {
/*  79 */     this();
/*  80 */     setPrefix(prefix);
/*  81 */     setSuffix(suffix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlwaysInclude(boolean alwaysInclude)
/*     */   {
/*  92 */     this.alwaysInclude = Boolean.valueOf(alwaysInclude);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Class<?> requiredViewClass()
/*     */   {
/*  98 */     return InternalResourceView.class;
/*     */   }
/*     */   
/*     */   protected AbstractUrlBasedView instantiateView()
/*     */   {
/* 103 */     return 
/* 104 */       getViewClass() == JstlView.class ? new JstlView() : getViewClass() == InternalResourceView.class ? new InternalResourceView() : super.instantiateView();
/*     */   }
/*     */   
/*     */   protected AbstractUrlBasedView buildView(String viewName) throws Exception
/*     */   {
/* 109 */     InternalResourceView view = (InternalResourceView)super.buildView(viewName);
/* 110 */     if (this.alwaysInclude != null) {
/* 111 */       view.setAlwaysInclude(this.alwaysInclude.booleanValue());
/*     */     }
/* 113 */     view.setPreventDispatchLoop(true);
/* 114 */     return view;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\InternalResourceViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */