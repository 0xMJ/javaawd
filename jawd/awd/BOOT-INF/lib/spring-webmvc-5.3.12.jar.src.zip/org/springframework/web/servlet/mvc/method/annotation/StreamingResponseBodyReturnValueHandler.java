/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.util.concurrent.Callable;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.http.server.ServletServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.filter.ShallowEtagHeaderFilter;
/*     */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamingResponseBodyReturnValueHandler
/*     */   implements HandlerMethodReturnValueHandler
/*     */ {
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/*  50 */     if (StreamingResponseBody.class.isAssignableFrom(returnType.getParameterType())) {
/*  51 */       return true;
/*     */     }
/*  53 */     if (ResponseEntity.class.isAssignableFrom(returnType.getParameterType())) {
/*  54 */       Class<?> bodyType = ResolvableType.forMethodParameter(returnType).getGeneric(new int[0]).resolve();
/*  55 */       return (bodyType != null) && (StreamingResponseBody.class.isAssignableFrom(bodyType));
/*     */     }
/*  57 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleReturnValue(@Nullable Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/*  65 */     if (returnValue == null) {
/*  66 */       mavContainer.setRequestHandled(true);
/*  67 */       return;
/*     */     }
/*     */     
/*  70 */     HttpServletResponse response = (HttpServletResponse)webRequest.getNativeResponse(HttpServletResponse.class);
/*  71 */     Assert.state(response != null, "No HttpServletResponse");
/*  72 */     ServerHttpResponse outputMessage = new ServletServerHttpResponse(response);
/*     */     
/*  74 */     if ((returnValue instanceof ResponseEntity)) {
/*  75 */       ResponseEntity<?> responseEntity = (ResponseEntity)returnValue;
/*  76 */       response.setStatus(responseEntity.getStatusCodeValue());
/*  77 */       outputMessage.getHeaders().putAll(responseEntity.getHeaders());
/*  78 */       returnValue = responseEntity.getBody();
/*  79 */       if (returnValue == null) {
/*  80 */         mavContainer.setRequestHandled(true);
/*  81 */         outputMessage.flush();
/*  82 */         return;
/*     */       }
/*     */     }
/*     */     
/*  86 */     ServletRequest request = (ServletRequest)webRequest.getNativeRequest(ServletRequest.class);
/*  87 */     Assert.state(request != null, "No ServletRequest");
/*  88 */     ShallowEtagHeaderFilter.disableContentCaching(request);
/*     */     
/*  90 */     Assert.isInstanceOf(StreamingResponseBody.class, returnValue, "StreamingResponseBody expected");
/*  91 */     StreamingResponseBody streamingBody = (StreamingResponseBody)returnValue;
/*     */     
/*  93 */     Callable<Void> callable = new StreamingResponseBodyTask(outputMessage.getBody(), streamingBody);
/*  94 */     WebAsyncUtils.getAsyncManager(webRequest).startCallableProcessing(callable, new Object[] { mavContainer });
/*     */   }
/*     */   
/*     */   private static class StreamingResponseBodyTask
/*     */     implements Callable<Void>
/*     */   {
/*     */     private final OutputStream outputStream;
/*     */     private final StreamingResponseBody streamingBody;
/*     */     
/*     */     public StreamingResponseBodyTask(OutputStream outputStream, StreamingResponseBody streamingBody)
/*     */     {
/* 105 */       this.outputStream = outputStream;
/* 106 */       this.streamingBody = streamingBody;
/*     */     }
/*     */     
/*     */     public Void call() throws Exception
/*     */     {
/* 111 */       this.streamingBody.writeTo(this.outputStream);
/* 112 */       this.outputStream.flush();
/* 113 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\StreamingResponseBodyReturnValueHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */