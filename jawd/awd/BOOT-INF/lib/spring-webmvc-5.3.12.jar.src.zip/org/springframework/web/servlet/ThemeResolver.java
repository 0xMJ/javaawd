package org.springframework.web.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.lang.Nullable;

public abstract interface ThemeResolver
{
  public abstract String resolveThemeName(HttpServletRequest paramHttpServletRequest);
  
  public abstract void setThemeName(HttpServletRequest paramHttpServletRequest, @Nullable HttpServletResponse paramHttpServletResponse, @Nullable String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\ThemeResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */