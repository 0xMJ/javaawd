package org.springframework.web.servlet;

import java.util.Locale;
import org.springframework.lang.Nullable;

public abstract interface ViewResolver
{
  @Nullable
  public abstract View resolveViewName(String paramString, Locale paramLocale)
    throws Exception;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\ViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */