/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.support.PropertiesBeanDefinitionReader;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.context.support.GenericWebApplicationContext;
/*     */ import org.springframework.web.servlet.View;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ResourceBundleViewResolver
/*     */   extends AbstractCachingViewResolver
/*     */   implements Ordered, InitializingBean, DisposableBean
/*     */ {
/*     */   public static final String DEFAULT_BASENAME = "views";
/*  73 */   private String[] basenames = { "views" };
/*     */   
/*  75 */   private ClassLoader bundleClassLoader = Thread.currentThread().getContextClassLoader();
/*     */   
/*     */   @Nullable
/*     */   private String defaultParentView;
/*     */   
/*     */   @Nullable
/*     */   private Locale[] localesToInitialize;
/*     */   
/*  83 */   private int order = Integer.MAX_VALUE;
/*     */   
/*     */ 
/*  86 */   private final Map<Locale, BeanFactory> localeCache = new HashMap();
/*     */   
/*     */ 
/*  89 */   private final Map<List<ResourceBundle>, ConfigurableApplicationContext> bundleCache = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBasename(String basename)
/*     */   {
/* 107 */     setBasenames(new String[] { basename });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBasenames(String... basenames)
/*     */   {
/* 128 */     this.basenames = basenames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBundleClassLoader(ClassLoader classLoader)
/*     */   {
/* 136 */     this.bundleClassLoader = classLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ClassLoader getBundleClassLoader()
/*     */   {
/* 145 */     return this.bundleClassLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultParentView(String defaultParentView)
/*     */   {
/* 162 */     this.defaultParentView = defaultParentView;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocalesToInitialize(Locale... localesToInitialize)
/*     */   {
/* 171 */     this.localesToInitialize = localesToInitialize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/* 180 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 185 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws BeansException
/*     */   {
/* 194 */     if (this.localesToInitialize != null) {
/* 195 */       for (Locale locale : this.localesToInitialize) {
/* 196 */         initFactory(locale);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected View loadView(String viewName, Locale locale)
/*     */     throws Exception
/*     */   {
/* 204 */     BeanFactory factory = initFactory(locale);
/*     */     try {
/* 206 */       return (View)factory.getBean(viewName, View.class);
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {}
/*     */     
/* 210 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized BeanFactory initFactory(Locale locale)
/*     */     throws BeansException
/*     */   {
/* 225 */     if (isCache()) {
/* 226 */       BeanFactory cachedFactory = (BeanFactory)this.localeCache.get(locale);
/* 227 */       if (cachedFactory != null) {
/* 228 */         return cachedFactory;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 233 */     List<ResourceBundle> bundles = new ArrayList(this.basenames.length);
/* 234 */     for (String basename : this.basenames) {
/* 235 */       bundles.add(getBundle(basename, locale));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 240 */     if (isCache()) {
/* 241 */       BeanFactory cachedFactory = (BeanFactory)this.bundleCache.get(bundles);
/* 242 */       if (cachedFactory != null) {
/* 243 */         this.localeCache.put(locale, cachedFactory);
/* 244 */         return cachedFactory;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 249 */     GenericWebApplicationContext factory = new GenericWebApplicationContext();
/* 250 */     factory.setParent(getApplicationContext());
/* 251 */     factory.setServletContext(getServletContext());
/*     */     
/*     */ 
/* 254 */     PropertiesBeanDefinitionReader reader = new PropertiesBeanDefinitionReader(factory);
/*     */     
/* 256 */     reader.setDefaultParentBean(this.defaultParentView);
/* 257 */     for (ResourceBundle bundle : bundles) {
/* 258 */       reader.registerBeanDefinitions(bundle);
/*     */     }
/*     */     
/* 261 */     factory.refresh();
/*     */     
/*     */ 
/* 264 */     if (isCache()) {
/* 265 */       this.localeCache.put(locale, factory);
/* 266 */       this.bundleCache.put(bundles, factory);
/*     */     }
/*     */     
/* 269 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ResourceBundle getBundle(String basename, Locale locale)
/*     */     throws MissingResourceException
/*     */   {
/* 281 */     return ResourceBundle.getBundle(basename, locale, getBundleClassLoader());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */     throws BeansException
/*     */   {
/* 290 */     for (ConfigurableApplicationContext factory : this.bundleCache.values()) {
/* 291 */       factory.close();
/*     */     }
/* 293 */     this.localeCache.clear();
/* 294 */     this.bundleCache.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\ResourceBundleViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */