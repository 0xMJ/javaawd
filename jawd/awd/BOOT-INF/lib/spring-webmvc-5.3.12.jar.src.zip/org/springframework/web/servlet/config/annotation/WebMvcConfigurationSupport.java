/*      */ package org.springframework.web.servlet.config.annotation;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.servlet.ServletContext;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ import org.springframework.beans.factory.BeanFactoryUtils;
/*      */ import org.springframework.beans.factory.BeanInitializationException;
/*      */ import org.springframework.beans.factory.annotation.Qualifier;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.ApplicationContextAware;
/*      */ import org.springframework.context.annotation.Bean;
/*      */ import org.springframework.context.annotation.Lazy;
/*      */ import org.springframework.core.SpringProperties;
/*      */ import org.springframework.format.FormatterRegistry;
/*      */ import org.springframework.format.support.DefaultFormattingConversionService;
/*      */ import org.springframework.format.support.FormattingConversionService;
/*      */ import org.springframework.http.MediaType;
/*      */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*      */ import org.springframework.http.converter.HttpMessageConverter;
/*      */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*      */ import org.springframework.http.converter.ResourceRegionHttpMessageConverter;
/*      */ import org.springframework.http.converter.StringHttpMessageConverter;
/*      */ import org.springframework.http.converter.cbor.MappingJackson2CborHttpMessageConverter;
/*      */ import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
/*      */ import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
/*      */ import org.springframework.http.converter.json.GsonHttpMessageConverter;
/*      */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*      */ import org.springframework.http.converter.json.JsonbHttpMessageConverter;
/*      */ import org.springframework.http.converter.json.KotlinSerializationJsonHttpMessageConverter;
/*      */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*      */ import org.springframework.http.converter.smile.MappingJackson2SmileHttpMessageConverter;
/*      */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*      */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*      */ import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
/*      */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.PathMatcher;
/*      */ import org.springframework.validation.Errors;
/*      */ import org.springframework.validation.MessageCodesResolver;
/*      */ import org.springframework.validation.Validator;
/*      */ import org.springframework.web.accept.ContentNegotiationManager;
/*      */ import org.springframework.web.bind.support.ConfigurableWebBindingInitializer;
/*      */ import org.springframework.web.context.ServletContextAware;
/*      */ import org.springframework.web.cors.CorsConfiguration;
/*      */ import org.springframework.web.method.support.CompositeUriComponentsContributor;
/*      */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*      */ import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
/*      */ import org.springframework.web.servlet.FlashMapManager;
/*      */ import org.springframework.web.servlet.HandlerExceptionResolver;
/*      */ import org.springframework.web.servlet.HandlerMapping;
/*      */ import org.springframework.web.servlet.LocaleResolver;
/*      */ import org.springframework.web.servlet.RequestToViewNameTranslator;
/*      */ import org.springframework.web.servlet.ThemeResolver;
/*      */ import org.springframework.web.servlet.ViewResolver;
/*      */ import org.springframework.web.servlet.function.support.HandlerFunctionAdapter;
/*      */ import org.springframework.web.servlet.function.support.RouterFunctionMapping;
/*      */ import org.springframework.web.servlet.handler.AbstractHandlerMapping;
/*      */ import org.springframework.web.servlet.handler.BeanNameUrlHandlerMapping;
/*      */ import org.springframework.web.servlet.handler.ConversionServiceExposingInterceptor;
/*      */ import org.springframework.web.servlet.handler.HandlerExceptionResolverComposite;
/*      */ import org.springframework.web.servlet.handler.HandlerMappingIntrospector;
/*      */ import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
/*      */ import org.springframework.web.servlet.mvc.HttpRequestHandlerAdapter;
/*      */ import org.springframework.web.servlet.mvc.SimpleControllerHandlerAdapter;
/*      */ import org.springframework.web.servlet.mvc.annotation.ResponseStatusExceptionResolver;
/*      */ import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;
/*      */ import org.springframework.web.servlet.mvc.method.annotation.JsonViewRequestBodyAdvice;
/*      */ import org.springframework.web.servlet.mvc.method.annotation.JsonViewResponseBodyAdvice;
/*      */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*      */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
/*      */ import org.springframework.web.servlet.mvc.support.DefaultHandlerExceptionResolver;
/*      */ import org.springframework.web.servlet.resource.ResourceUrlProvider;
/*      */ import org.springframework.web.servlet.resource.ResourceUrlProviderExposingInterceptor;
/*      */ import org.springframework.web.servlet.support.SessionFlashMapManager;
/*      */ import org.springframework.web.servlet.theme.FixedThemeResolver;
/*      */ import org.springframework.web.servlet.view.DefaultRequestToViewNameTranslator;
/*      */ import org.springframework.web.servlet.view.InternalResourceViewResolver;
/*      */ import org.springframework.web.servlet.view.ViewResolverComposite;
/*      */ import org.springframework.web.util.UrlPathHelper;
/*      */ import org.springframework.web.util.pattern.PathPatternParser;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WebMvcConfigurationSupport
/*      */   implements ApplicationContextAware, ServletContextAware
/*      */ {
/*  198 */   private static final boolean shouldIgnoreXml = SpringProperties.getFlag("spring.xml.ignore");
/*      */   
/*      */   private static final boolean romePresent;
/*      */   
/*      */   private static final boolean jaxb2Present;
/*      */   
/*      */   private static final boolean jackson2Present;
/*      */   
/*      */   private static final boolean jackson2XmlPresent;
/*      */   
/*      */   private static final boolean jackson2SmilePresent;
/*      */   
/*      */   private static final boolean jackson2CborPresent;
/*      */   
/*      */   private static final boolean gsonPresent;
/*      */   
/*      */   private static final boolean jsonbPresent;
/*      */   private static final boolean kotlinSerializationJsonPresent;
/*      */   
/*      */   static
/*      */   {
/*  219 */     ClassLoader classLoader = WebMvcConfigurationSupport.class.getClassLoader();
/*  220 */     romePresent = ClassUtils.isPresent("com.rometools.rome.feed.WireFeed", classLoader);
/*  221 */     jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", classLoader);
/*      */     
/*  223 */     jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", classLoader)) && (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", classLoader));
/*  224 */     jackson2XmlPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.xml.XmlMapper", classLoader);
/*  225 */     jackson2SmilePresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.smile.SmileFactory", classLoader);
/*  226 */     jackson2CborPresent = ClassUtils.isPresent("com.fasterxml.jackson.dataformat.cbor.CBORFactory", classLoader);
/*  227 */     gsonPresent = ClassUtils.isPresent("com.google.gson.Gson", classLoader);
/*  228 */     jsonbPresent = ClassUtils.isPresent("javax.json.bind.Jsonb", classLoader);
/*  229 */     kotlinSerializationJsonPresent = ClassUtils.isPresent("kotlinx.serialization.json.Json", classLoader);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Nullable
/*      */   private ApplicationContext applicationContext;
/*      */   
/*      */ 
/*      */   @Nullable
/*      */   private ServletContext servletContext;
/*      */   
/*      */ 
/*      */   @Nullable
/*      */   private List<Object> interceptors;
/*      */   
/*      */ 
/*      */   @Nullable
/*      */   private PathMatchConfigurer pathMatchConfigurer;
/*      */   
/*      */   @Nullable
/*      */   private ContentNegotiationManager contentNegotiationManager;
/*      */   
/*      */   @Nullable
/*      */   private List<HandlerMethodArgumentResolver> argumentResolvers;
/*      */   
/*      */   @Nullable
/*      */   private List<HandlerMethodReturnValueHandler> returnValueHandlers;
/*      */   
/*      */   @Nullable
/*      */   private List<HttpMessageConverter<?>> messageConverters;
/*      */   
/*      */   @Nullable
/*      */   private Map<String, CorsConfiguration> corsConfigurations;
/*      */   
/*      */   @Nullable
/*      */   private AsyncSupportConfigurer asyncSupportConfigurer;
/*      */   
/*      */   public void setApplicationContext(@Nullable ApplicationContext applicationContext)
/*      */   {
/*  269 */     this.applicationContext = applicationContext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Nullable
/*      */   public final ApplicationContext getApplicationContext()
/*      */   {
/*  278 */     return this.applicationContext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServletContext(@Nullable ServletContext servletContext)
/*      */   {
/*  287 */     this.servletContext = servletContext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Nullable
/*      */   public final ServletContext getServletContext()
/*      */   {
/*  296 */     return this.servletContext;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public RequestMappingHandlerMapping requestMappingHandlerMapping(@Qualifier("mvcContentNegotiationManager") ContentNegotiationManager contentNegotiationManager, @Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcResourceUrlProvider") ResourceUrlProvider resourceUrlProvider)
/*      */   {
/*  311 */     RequestMappingHandlerMapping mapping = createRequestMappingHandlerMapping();
/*  312 */     mapping.setOrder(0);
/*  313 */     mapping.setInterceptors(getInterceptors(conversionService, resourceUrlProvider));
/*  314 */     mapping.setContentNegotiationManager(contentNegotiationManager);
/*  315 */     mapping.setCorsConfigurations(getCorsConfigurations());
/*      */     
/*  317 */     PathMatchConfigurer pathConfig = getPathMatchConfigurer();
/*  318 */     if (pathConfig.getPatternParser() != null) {
/*  319 */       mapping.setPatternParser(pathConfig.getPatternParser());
/*      */     }
/*      */     else {
/*  322 */       mapping.setUrlPathHelper(pathConfig.getUrlPathHelperOrDefault());
/*  323 */       mapping.setPathMatcher(pathConfig.getPathMatcherOrDefault());
/*      */       
/*  325 */       Boolean useSuffixPatternMatch = pathConfig.isUseSuffixPatternMatch();
/*  326 */       if (useSuffixPatternMatch != null) {
/*  327 */         mapping.setUseSuffixPatternMatch(useSuffixPatternMatch.booleanValue());
/*      */       }
/*  329 */       Boolean useRegisteredSuffixPatternMatch = pathConfig.isUseRegisteredSuffixPatternMatch();
/*  330 */       if (useRegisteredSuffixPatternMatch != null) {
/*  331 */         mapping.setUseRegisteredSuffixPatternMatch(useRegisteredSuffixPatternMatch.booleanValue());
/*      */       }
/*      */     }
/*  334 */     Boolean useTrailingSlashMatch = pathConfig.isUseTrailingSlashMatch();
/*  335 */     if (useTrailingSlashMatch != null) {
/*  336 */       mapping.setUseTrailingSlashMatch(useTrailingSlashMatch.booleanValue());
/*      */     }
/*  338 */     if (pathConfig.getPathPrefixes() != null) {
/*  339 */       mapping.setPathPrefixes(pathConfig.getPathPrefixes());
/*      */     }
/*      */     
/*  342 */     return mapping;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected RequestMappingHandlerMapping createRequestMappingHandlerMapping()
/*      */   {
/*  351 */     return new RequestMappingHandlerMapping();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Object[] getInterceptors(FormattingConversionService mvcConversionService, ResourceUrlProvider mvcResourceUrlProvider)
/*      */   {
/*  363 */     if (this.interceptors == null) {
/*  364 */       InterceptorRegistry registry = new InterceptorRegistry();
/*  365 */       addInterceptors(registry);
/*  366 */       registry.addInterceptor(new ConversionServiceExposingInterceptor(mvcConversionService));
/*  367 */       registry.addInterceptor(new ResourceUrlProviderExposingInterceptor(mvcResourceUrlProvider));
/*  368 */       this.interceptors = registry.getInterceptors();
/*      */     }
/*  370 */     return this.interceptors.toArray();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected PathMatchConfigurer getPathMatchConfigurer()
/*      */   {
/*  387 */     if (this.pathMatchConfigurer == null) {
/*  388 */       this.pathMatchConfigurer = new PathMatchConfigurer();
/*  389 */       configurePathMatch(this.pathMatchConfigurer);
/*      */     }
/*  391 */     return this.pathMatchConfigurer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public PathPatternParser mvcPatternParser()
/*      */   {
/*  411 */     return getPathMatchConfigurer().getPatternParserOrDefault();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public UrlPathHelper mvcUrlPathHelper()
/*      */   {
/*  424 */     return getPathMatchConfigurer().getUrlPathHelperOrDefault();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public PathMatcher mvcPathMatcher()
/*      */   {
/*  437 */     return getPathMatchConfigurer().getPathMatcherOrDefault();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public ContentNegotiationManager mvcContentNegotiationManager()
/*      */   {
/*  446 */     if (this.contentNegotiationManager == null) {
/*  447 */       ContentNegotiationConfigurer configurer = new ContentNegotiationConfigurer(this.servletContext);
/*  448 */       configurer.mediaTypes(getDefaultMediaTypes());
/*  449 */       configureContentNegotiation(configurer);
/*  450 */       this.contentNegotiationManager = configurer.buildContentNegotiationManager();
/*      */     }
/*  452 */     return this.contentNegotiationManager;
/*      */   }
/*      */   
/*      */   protected Map<String, MediaType> getDefaultMediaTypes() {
/*  456 */     Map<String, MediaType> map = new HashMap(4);
/*  457 */     if (romePresent) {
/*  458 */       map.put("atom", MediaType.APPLICATION_ATOM_XML);
/*  459 */       map.put("rss", MediaType.APPLICATION_RSS_XML);
/*      */     }
/*  461 */     if ((!shouldIgnoreXml) && ((jaxb2Present) || (jackson2XmlPresent))) {
/*  462 */       map.put("xml", MediaType.APPLICATION_XML);
/*      */     }
/*  464 */     if ((jackson2Present) || (gsonPresent) || (jsonbPresent)) {
/*  465 */       map.put("json", MediaType.APPLICATION_JSON);
/*      */     }
/*  467 */     if (jackson2SmilePresent) {
/*  468 */       map.put("smile", MediaType.valueOf("application/x-jackson-smile"));
/*      */     }
/*  470 */     if (jackson2CborPresent) {
/*  471 */       map.put("cbor", MediaType.APPLICATION_CBOR);
/*      */     }
/*  473 */     return map;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   @Nullable
/*      */   public HandlerMapping viewControllerHandlerMapping(@Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcResourceUrlProvider") ResourceUrlProvider resourceUrlProvider)
/*      */   {
/*  494 */     ViewControllerRegistry registry = new ViewControllerRegistry(this.applicationContext);
/*  495 */     addViewControllers(registry);
/*      */     
/*  497 */     AbstractHandlerMapping handlerMapping = registry.buildHandlerMapping();
/*  498 */     if (handlerMapping == null) {
/*  499 */       return null;
/*      */     }
/*  501 */     PathMatchConfigurer pathConfig = getPathMatchConfigurer();
/*  502 */     if (pathConfig.getPatternParser() != null) {
/*  503 */       handlerMapping.setPatternParser(pathConfig.getPatternParser());
/*      */     }
/*      */     else {
/*  506 */       handlerMapping.setUrlPathHelper(pathConfig.getUrlPathHelperOrDefault());
/*  507 */       handlerMapping.setPathMatcher(pathConfig.getPathMatcherOrDefault());
/*      */     }
/*  509 */     handlerMapping.setInterceptors(getInterceptors(conversionService, resourceUrlProvider));
/*  510 */     handlerMapping.setCorsConfigurations(getCorsConfigurations());
/*  511 */     return handlerMapping;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public BeanNameUrlHandlerMapping beanNameHandlerMapping(@Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcResourceUrlProvider") ResourceUrlProvider resourceUrlProvider)
/*      */   {
/*  530 */     BeanNameUrlHandlerMapping mapping = new BeanNameUrlHandlerMapping();
/*  531 */     mapping.setOrder(2);
/*      */     
/*  533 */     PathMatchConfigurer pathConfig = getPathMatchConfigurer();
/*  534 */     if (pathConfig.getPatternParser() != null) {
/*  535 */       mapping.setPatternParser(pathConfig.getPatternParser());
/*      */     }
/*      */     else {
/*  538 */       mapping.setUrlPathHelper(pathConfig.getUrlPathHelperOrDefault());
/*  539 */       mapping.setPathMatcher(pathConfig.getPathMatcherOrDefault());
/*      */     }
/*      */     
/*  542 */     mapping.setInterceptors(getInterceptors(conversionService, resourceUrlProvider));
/*  543 */     mapping.setCorsConfigurations(getCorsConfigurations());
/*  544 */     return mapping;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public RouterFunctionMapping routerFunctionMapping(@Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcResourceUrlProvider") ResourceUrlProvider resourceUrlProvider)
/*      */   {
/*  564 */     RouterFunctionMapping mapping = new RouterFunctionMapping();
/*  565 */     mapping.setOrder(3);
/*  566 */     mapping.setInterceptors(getInterceptors(conversionService, resourceUrlProvider));
/*  567 */     mapping.setCorsConfigurations(getCorsConfigurations());
/*  568 */     mapping.setMessageConverters(getMessageConverters());
/*      */     
/*  570 */     PathPatternParser patternParser = getPathMatchConfigurer().getPatternParser();
/*  571 */     if (patternParser != null) {
/*  572 */       mapping.setPatternParser(patternParser);
/*      */     }
/*      */     
/*  575 */     return mapping;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   @Nullable
/*      */   public HandlerMapping resourceHandlerMapping(@Qualifier("mvcContentNegotiationManager") ContentNegotiationManager contentNegotiationManager, @Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcResourceUrlProvider") ResourceUrlProvider resourceUrlProvider)
/*      */   {
/*  590 */     Assert.state(this.applicationContext != null, "No ApplicationContext set");
/*  591 */     Assert.state(this.servletContext != null, "No ServletContext set");
/*      */     
/*  593 */     PathMatchConfigurer pathConfig = getPathMatchConfigurer();
/*      */     
/*      */ 
/*  596 */     ResourceHandlerRegistry registry = new ResourceHandlerRegistry(this.applicationContext, this.servletContext, contentNegotiationManager, pathConfig.getUrlPathHelper());
/*  597 */     addResourceHandlers(registry);
/*      */     
/*  599 */     AbstractHandlerMapping handlerMapping = registry.getHandlerMapping();
/*  600 */     if (handlerMapping == null) {
/*  601 */       return null;
/*      */     }
/*  603 */     if (pathConfig.getPatternParser() != null) {
/*  604 */       handlerMapping.setPatternParser(pathConfig.getPatternParser());
/*      */     }
/*      */     else {
/*  607 */       handlerMapping.setUrlPathHelper(pathConfig.getUrlPathHelperOrDefault());
/*  608 */       handlerMapping.setPathMatcher(pathConfig.getPathMatcherOrDefault());
/*      */     }
/*  610 */     handlerMapping.setInterceptors(getInterceptors(conversionService, resourceUrlProvider));
/*  611 */     handlerMapping.setCorsConfigurations(getCorsConfigurations());
/*  612 */     return handlerMapping;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public ResourceUrlProvider mvcResourceUrlProvider()
/*      */   {
/*  628 */     ResourceUrlProvider urlProvider = new ResourceUrlProvider();
/*  629 */     urlProvider.setUrlPathHelper(getPathMatchConfigurer().getUrlPathHelperOrDefault());
/*  630 */     urlProvider.setPathMatcher(getPathMatchConfigurer().getPathMatcherOrDefault());
/*  631 */     return urlProvider;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   @Nullable
/*      */   public HandlerMapping defaultServletHandlerMapping()
/*      */   {
/*  642 */     Assert.state(this.servletContext != null, "No ServletContext set");
/*  643 */     DefaultServletHandlerConfigurer configurer = new DefaultServletHandlerConfigurer(this.servletContext);
/*  644 */     configureDefaultServletHandling(configurer);
/*  645 */     return configurer.buildHandlerMapping();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public RequestMappingHandlerAdapter requestMappingHandlerAdapter(@Qualifier("mvcContentNegotiationManager") ContentNegotiationManager contentNegotiationManager, @Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("mvcValidator") Validator validator)
/*      */   {
/*  671 */     RequestMappingHandlerAdapter adapter = createRequestMappingHandlerAdapter();
/*  672 */     adapter.setContentNegotiationManager(contentNegotiationManager);
/*  673 */     adapter.setMessageConverters(getMessageConverters());
/*  674 */     adapter.setWebBindingInitializer(getConfigurableWebBindingInitializer(conversionService, validator));
/*  675 */     adapter.setCustomArgumentResolvers(getArgumentResolvers());
/*  676 */     adapter.setCustomReturnValueHandlers(getReturnValueHandlers());
/*      */     
/*  678 */     if (jackson2Present) {
/*  679 */       adapter.setRequestBodyAdvice(Collections.singletonList(new JsonViewRequestBodyAdvice()));
/*  680 */       adapter.setResponseBodyAdvice(Collections.singletonList(new JsonViewResponseBodyAdvice()));
/*      */     }
/*      */     
/*  683 */     AsyncSupportConfigurer configurer = getAsyncSupportConfigurer();
/*  684 */     if (configurer.getTaskExecutor() != null) {
/*  685 */       adapter.setTaskExecutor(configurer.getTaskExecutor());
/*      */     }
/*  687 */     if (configurer.getTimeout() != null) {
/*  688 */       adapter.setAsyncRequestTimeout(configurer.getTimeout().longValue());
/*      */     }
/*  690 */     adapter.setCallableInterceptors(configurer.getCallableInterceptors());
/*  691 */     adapter.setDeferredResultInterceptors(configurer.getDeferredResultInterceptors());
/*      */     
/*  693 */     return adapter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected RequestMappingHandlerAdapter createRequestMappingHandlerAdapter()
/*      */   {
/*  702 */     return new RequestMappingHandlerAdapter();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public HandlerFunctionAdapter handlerFunctionAdapter()
/*      */   {
/*  712 */     HandlerFunctionAdapter adapter = new HandlerFunctionAdapter();
/*      */     
/*  714 */     AsyncSupportConfigurer configurer = getAsyncSupportConfigurer();
/*  715 */     if (configurer.getTimeout() != null) {
/*  716 */       adapter.setAsyncRequestTimeout(configurer.getTimeout().longValue());
/*      */     }
/*  718 */     return adapter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ConfigurableWebBindingInitializer getConfigurableWebBindingInitializer(FormattingConversionService mvcConversionService, Validator mvcValidator)
/*      */   {
/*  728 */     ConfigurableWebBindingInitializer initializer = new ConfigurableWebBindingInitializer();
/*  729 */     initializer.setConversionService(mvcConversionService);
/*  730 */     initializer.setValidator(mvcValidator);
/*  731 */     MessageCodesResolver messageCodesResolver = getMessageCodesResolver();
/*  732 */     if (messageCodesResolver != null) {
/*  733 */       initializer.setMessageCodesResolver(messageCodesResolver);
/*      */     }
/*  735 */     return initializer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Nullable
/*      */   protected MessageCodesResolver getMessageCodesResolver()
/*      */   {
/*  743 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public FormattingConversionService mvcConversionService()
/*      */   {
/*  752 */     FormattingConversionService conversionService = new DefaultFormattingConversionService();
/*  753 */     addFormatters(conversionService);
/*  754 */     return conversionService;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public Validator mvcValidator()
/*      */   {
/*  775 */     Validator validator = getValidator();
/*  776 */     if (validator == null) {
/*  777 */       if (ClassUtils.isPresent("javax.validation.Validator", getClass().getClassLoader()))
/*      */       {
/*      */         try {
/*  780 */           String className = "org.springframework.validation.beanvalidation.OptionalValidatorFactoryBean";
/*  781 */           clazz = ClassUtils.forName(className, WebMvcConfigurationSupport.class.getClassLoader());
/*      */         } catch (ClassNotFoundException|LinkageError ex) {
/*      */           Class<?> clazz;
/*  784 */           throw new BeanInitializationException("Failed to resolve default validator class", ex); }
/*      */         Class<?> clazz;
/*  786 */         validator = (Validator)BeanUtils.instantiateClass(clazz);
/*      */       }
/*      */       else {
/*  789 */         validator = new NoOpValidator(null);
/*      */       }
/*      */     }
/*  792 */     return validator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Nullable
/*      */   protected Validator getValidator()
/*      */   {
/*  800 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final List<HandlerMethodArgumentResolver> getArgumentResolvers()
/*      */   {
/*  810 */     if (this.argumentResolvers == null) {
/*  811 */       this.argumentResolvers = new ArrayList();
/*  812 */       addArgumentResolvers(this.argumentResolvers);
/*      */     }
/*  814 */     return this.argumentResolvers;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final List<HandlerMethodReturnValueHandler> getReturnValueHandlers()
/*      */   {
/*  836 */     if (this.returnValueHandlers == null) {
/*  837 */       this.returnValueHandlers = new ArrayList();
/*  838 */       addReturnValueHandlers(this.returnValueHandlers);
/*      */     }
/*  840 */     return this.returnValueHandlers;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final List<HttpMessageConverter<?>> getMessageConverters()
/*      */   {
/*  863 */     if (this.messageConverters == null) {
/*  864 */       this.messageConverters = new ArrayList();
/*  865 */       configureMessageConverters(this.messageConverters);
/*  866 */       if (this.messageConverters.isEmpty()) {
/*  867 */         addDefaultHttpMessageConverters(this.messageConverters);
/*      */       }
/*  869 */       extendMessageConverters(this.messageConverters);
/*      */     }
/*  871 */     return this.messageConverters;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void addDefaultHttpMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*      */   {
/*  902 */     messageConverters.add(new ByteArrayHttpMessageConverter());
/*  903 */     messageConverters.add(new StringHttpMessageConverter());
/*  904 */     messageConverters.add(new ResourceHttpMessageConverter());
/*  905 */     messageConverters.add(new ResourceRegionHttpMessageConverter());
/*  906 */     if (!shouldIgnoreXml) {
/*      */       try {
/*  908 */         messageConverters.add(new SourceHttpMessageConverter());
/*      */       }
/*      */       catch (Throwable localThrowable) {}
/*      */     }
/*      */     
/*      */ 
/*  914 */     messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*      */     
/*  916 */     if (romePresent) {
/*  917 */       messageConverters.add(new AtomFeedHttpMessageConverter());
/*  918 */       messageConverters.add(new RssChannelHttpMessageConverter());
/*      */     }
/*      */     
/*  921 */     if (!shouldIgnoreXml) {
/*  922 */       if (jackson2XmlPresent) {
/*  923 */         Jackson2ObjectMapperBuilder builder = Jackson2ObjectMapperBuilder.xml();
/*  924 */         if (this.applicationContext != null) {
/*  925 */           builder.applicationContext(this.applicationContext);
/*      */         }
/*  927 */         messageConverters.add(new MappingJackson2XmlHttpMessageConverter(builder.build()));
/*      */       }
/*  929 */       else if (jaxb2Present) {
/*  930 */         messageConverters.add(new Jaxb2RootElementHttpMessageConverter());
/*      */       }
/*      */     }
/*      */     
/*  934 */     if (kotlinSerializationJsonPresent) {
/*  935 */       messageConverters.add(new KotlinSerializationJsonHttpMessageConverter());
/*      */     }
/*  937 */     if (jackson2Present) {
/*  938 */       Jackson2ObjectMapperBuilder builder = Jackson2ObjectMapperBuilder.json();
/*  939 */       if (this.applicationContext != null) {
/*  940 */         builder.applicationContext(this.applicationContext);
/*      */       }
/*  942 */       messageConverters.add(new MappingJackson2HttpMessageConverter(builder.build()));
/*      */     }
/*  944 */     else if (gsonPresent) {
/*  945 */       messageConverters.add(new GsonHttpMessageConverter());
/*      */     }
/*  947 */     else if (jsonbPresent) {
/*  948 */       messageConverters.add(new JsonbHttpMessageConverter());
/*      */     }
/*      */     
/*  951 */     if (jackson2SmilePresent) {
/*  952 */       Jackson2ObjectMapperBuilder builder = Jackson2ObjectMapperBuilder.smile();
/*  953 */       if (this.applicationContext != null) {
/*  954 */         builder.applicationContext(this.applicationContext);
/*      */       }
/*  956 */       messageConverters.add(new MappingJackson2SmileHttpMessageConverter(builder.build()));
/*      */     }
/*  958 */     if (jackson2CborPresent) {
/*  959 */       Jackson2ObjectMapperBuilder builder = Jackson2ObjectMapperBuilder.cbor();
/*  960 */       if (this.applicationContext != null) {
/*  961 */         builder.applicationContext(this.applicationContext);
/*      */       }
/*  963 */       messageConverters.add(new MappingJackson2CborHttpMessageConverter(builder.build()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected AsyncSupportConfigurer getAsyncSupportConfigurer()
/*      */   {
/*  973 */     if (this.asyncSupportConfigurer == null) {
/*  974 */       this.asyncSupportConfigurer = new AsyncSupportConfigurer();
/*  975 */       configureAsyncSupport(this.asyncSupportConfigurer);
/*      */     }
/*  977 */     return this.asyncSupportConfigurer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public CompositeUriComponentsContributor mvcUriComponentsContributor(@Qualifier("mvcConversionService") FormattingConversionService conversionService, @Qualifier("requestMappingHandlerAdapter") RequestMappingHandlerAdapter requestMappingHandlerAdapter)
/*      */   {
/*  996 */     return new CompositeUriComponentsContributor(requestMappingHandlerAdapter
/*  997 */       .getArgumentResolvers(), conversionService);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public HttpRequestHandlerAdapter httpRequestHandlerAdapter()
/*      */   {
/* 1006 */     return new HttpRequestHandlerAdapter();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public SimpleControllerHandlerAdapter simpleControllerHandlerAdapter()
/*      */   {
/* 1015 */     return new SimpleControllerHandlerAdapter();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public HandlerExceptionResolver handlerExceptionResolver(@Qualifier("mvcContentNegotiationManager") ContentNegotiationManager contentNegotiationManager)
/*      */   {
/* 1029 */     List<HandlerExceptionResolver> exceptionResolvers = new ArrayList();
/* 1030 */     configureHandlerExceptionResolvers(exceptionResolvers);
/* 1031 */     if (exceptionResolvers.isEmpty()) {
/* 1032 */       addDefaultHandlerExceptionResolvers(exceptionResolvers, contentNegotiationManager);
/*      */     }
/* 1034 */     extendHandlerExceptionResolvers(exceptionResolvers);
/* 1035 */     HandlerExceptionResolverComposite composite = new HandlerExceptionResolverComposite();
/* 1036 */     composite.setOrder(0);
/* 1037 */     composite.setExceptionResolvers(exceptionResolvers);
/* 1038 */     return composite;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void addDefaultHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers, ContentNegotiationManager mvcContentNegotiationManager)
/*      */   {
/* 1078 */     ExceptionHandlerExceptionResolver exceptionHandlerResolver = createExceptionHandlerExceptionResolver();
/* 1079 */     exceptionHandlerResolver.setContentNegotiationManager(mvcContentNegotiationManager);
/* 1080 */     exceptionHandlerResolver.setMessageConverters(getMessageConverters());
/* 1081 */     exceptionHandlerResolver.setCustomArgumentResolvers(getArgumentResolvers());
/* 1082 */     exceptionHandlerResolver.setCustomReturnValueHandlers(getReturnValueHandlers());
/* 1083 */     if (jackson2Present) {
/* 1084 */       exceptionHandlerResolver.setResponseBodyAdvice(
/* 1085 */         Collections.singletonList(new JsonViewResponseBodyAdvice()));
/*      */     }
/* 1087 */     if (this.applicationContext != null) {
/* 1088 */       exceptionHandlerResolver.setApplicationContext(this.applicationContext);
/*      */     }
/* 1090 */     exceptionHandlerResolver.afterPropertiesSet();
/* 1091 */     exceptionResolvers.add(exceptionHandlerResolver);
/*      */     
/* 1093 */     ResponseStatusExceptionResolver responseStatusResolver = new ResponseStatusExceptionResolver();
/* 1094 */     responseStatusResolver.setMessageSource(this.applicationContext);
/* 1095 */     exceptionResolvers.add(responseStatusResolver);
/*      */     
/* 1097 */     exceptionResolvers.add(new DefaultHandlerExceptionResolver());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ExceptionHandlerExceptionResolver createExceptionHandlerExceptionResolver()
/*      */   {
/* 1106 */     return new ExceptionHandlerExceptionResolver();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   public ViewResolver mvcViewResolver(@Qualifier("mvcContentNegotiationManager") ContentNegotiationManager contentNegotiationManager)
/*      */   {
/* 1124 */     ViewResolverRegistry registry = new ViewResolverRegistry(contentNegotiationManager, this.applicationContext);
/*      */     
/* 1126 */     configureViewResolvers(registry);
/*      */     
/* 1128 */     if ((registry.getViewResolvers().isEmpty()) && (this.applicationContext != null)) {
/* 1129 */       String[] names = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(this.applicationContext, ViewResolver.class, true, false);
/*      */       
/* 1131 */       if (names.length == 1) {
/* 1132 */         registry.getViewResolvers().add(new InternalResourceViewResolver());
/*      */       }
/*      */     }
/*      */     
/* 1136 */     ViewResolverComposite composite = new ViewResolverComposite();
/* 1137 */     composite.setOrder(registry.getOrder());
/* 1138 */     composite.setViewResolvers(registry.getViewResolvers());
/* 1139 */     if (this.applicationContext != null) {
/* 1140 */       composite.setApplicationContext(this.applicationContext);
/*      */     }
/* 1142 */     if (this.servletContext != null) {
/* 1143 */       composite.setServletContext(this.servletContext);
/*      */     }
/* 1145 */     return composite;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Map<String, CorsConfiguration> getCorsConfigurations()
/*      */   {
/* 1161 */     if (this.corsConfigurations == null) {
/* 1162 */       CorsRegistry registry = new CorsRegistry();
/* 1163 */       addCorsMappings(registry);
/* 1164 */       this.corsConfigurations = registry.getCorsConfigurations();
/*      */     }
/* 1166 */     return this.corsConfigurations;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Bean
/*      */   @Lazy
/*      */   public HandlerMappingIntrospector mvcHandlerMappingIntrospector()
/*      */   {
/* 1180 */     return new HandlerMappingIntrospector();
/*      */   }
/*      */   
/*      */   @Bean
/*      */   public LocaleResolver localeResolver() {
/* 1185 */     return new AcceptHeaderLocaleResolver();
/*      */   }
/*      */   
/*      */   @Bean
/*      */   public ThemeResolver themeResolver() {
/* 1190 */     return new FixedThemeResolver();
/*      */   }
/*      */   
/*      */   @Bean
/*      */   public FlashMapManager flashMapManager() {
/* 1195 */     return new SessionFlashMapManager();
/*      */   }
/*      */   
/*      */   @Bean
/*      */   public RequestToViewNameTranslator viewNameTranslator() {
/* 1200 */     return new DefaultRequestToViewNameTranslator();
/*      */   }
/*      */   
/*      */   protected void addInterceptors(InterceptorRegistry registry) {}
/*      */   
/*      */   protected void configurePathMatch(PathMatchConfigurer configurer) {}
/*      */   
/*      */   private static final class NoOpValidator implements Validator {
/* 1208 */     public boolean supports(Class<?> clazz) { return false; }
/*      */     
/*      */     public void validate(@Nullable Object target, Errors errors) {}
/*      */   }
/*      */   
/*      */   protected void configureContentNegotiation(ContentNegotiationConfigurer configurer) {}
/*      */   
/*      */   protected void addViewControllers(ViewControllerRegistry registry) {}
/*      */   
/*      */   protected void addResourceHandlers(ResourceHandlerRegistry registry) {}
/*      */   
/*      */   protected void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {}
/*      */   
/*      */   protected void addFormatters(FormatterRegistry registry) {}
/*      */   
/*      */   protected void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {}
/*      */   
/*      */   protected void addReturnValueHandlers(List<HandlerMethodReturnValueHandler> returnValueHandlers) {}
/*      */   
/*      */   protected void configureMessageConverters(List<HttpMessageConverter<?>> converters) {}
/*      */   
/*      */   protected void extendMessageConverters(List<HttpMessageConverter<?>> converters) {}
/*      */   
/*      */   protected void configureAsyncSupport(AsyncSupportConfigurer configurer) {}
/*      */   
/*      */   protected void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {}
/*      */   
/*      */   protected void extendHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {}
/*      */   
/*      */   protected void configureViewResolvers(ViewResolverRegistry registry) {}
/*      */   
/*      */   protected void addCorsMappings(CorsRegistry registry) {}
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\annotation\WebMvcConfigurationSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */