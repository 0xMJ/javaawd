/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.LocaleResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AcceptHeaderLocaleResolver
/*     */   implements LocaleResolver
/*     */ {
/*  46 */   private final List<Locale> supportedLocales = new ArrayList(4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Locale defaultLocale;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSupportedLocales(List<Locale> locales)
/*     */   {
/*  60 */     this.supportedLocales.clear();
/*  61 */     this.supportedLocales.addAll(locales);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Locale> getSupportedLocales()
/*     */   {
/*  69 */     return this.supportedLocales;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultLocale(@Nullable Locale defaultLocale)
/*     */   {
/*  82 */     this.defaultLocale = defaultLocale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Locale getDefaultLocale()
/*     */   {
/*  92 */     return this.defaultLocale;
/*     */   }
/*     */   
/*     */ 
/*     */   public Locale resolveLocale(HttpServletRequest request)
/*     */   {
/*  98 */     Locale defaultLocale = getDefaultLocale();
/*  99 */     if ((defaultLocale != null) && (request.getHeader("Accept-Language") == null)) {
/* 100 */       return defaultLocale;
/*     */     }
/* 102 */     Locale requestLocale = request.getLocale();
/* 103 */     List<Locale> supportedLocales = getSupportedLocales();
/* 104 */     if ((supportedLocales.isEmpty()) || (supportedLocales.contains(requestLocale))) {
/* 105 */       return requestLocale;
/*     */     }
/* 107 */     Locale supportedLocale = findSupportedLocale(request, supportedLocales);
/* 108 */     if (supportedLocale != null) {
/* 109 */       return supportedLocale;
/*     */     }
/* 111 */     return defaultLocale != null ? defaultLocale : requestLocale;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Locale findSupportedLocale(HttpServletRequest request, List<Locale> supportedLocales) {
/* 116 */     Enumeration<Locale> requestLocales = request.getLocales();
/* 117 */     Locale languageMatch = null;
/* 118 */     Locale locale; while (requestLocales.hasMoreElements()) {
/* 119 */       locale = (Locale)requestLocales.nextElement();
/* 120 */       if (supportedLocales.contains(locale)) {
/* 121 */         if ((languageMatch == null) || (languageMatch.getLanguage().equals(locale.getLanguage())))
/*     */         {
/* 123 */           return locale;
/*     */         }
/*     */       }
/* 126 */       else if (languageMatch == null)
/*     */       {
/* 128 */         for (Locale candidate : supportedLocales) {
/* 129 */           if ((!StringUtils.hasLength(candidate.getCountry())) && 
/* 130 */             (candidate.getLanguage().equals(locale.getLanguage()))) {
/* 131 */             languageMatch = candidate;
/* 132 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 137 */     return languageMatch;
/*     */   }
/*     */   
/*     */   public void setLocale(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable Locale locale)
/*     */   {
/* 142 */     throw new UnsupportedOperationException("Cannot change HTTP accept header - use a different locale resolution strategy");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\i18n\AcceptHeaderLocaleResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */