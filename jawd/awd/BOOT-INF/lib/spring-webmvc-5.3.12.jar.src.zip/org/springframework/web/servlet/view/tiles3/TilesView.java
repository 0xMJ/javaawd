/*     */ package org.springframework.web.servlet.view.tiles3;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.tiles.TilesContainer;
/*     */ import org.apache.tiles.access.TilesAccess;
/*     */ import org.apache.tiles.renderer.DefinitionRenderer;
/*     */ import org.apache.tiles.request.AbstractRequest;
/*     */ import org.apache.tiles.request.ApplicationContext;
/*     */ import org.apache.tiles.request.Request;
/*     */ import org.apache.tiles.request.render.Renderer;
/*     */ import org.apache.tiles.request.servlet.ServletRequest;
/*     */ import org.apache.tiles.request.servlet.ServletUtil;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.servlet.support.JstlUtils;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TilesView
/*     */   extends AbstractUrlBasedView
/*     */ {
/*     */   @Nullable
/*     */   private Renderer renderer;
/*  62 */   private boolean exposeJstlAttributes = true;
/*     */   
/*  64 */   private boolean alwaysInclude = false;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRenderer(Renderer renderer)
/*     */   {
/*  75 */     this.renderer = renderer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setExposeJstlAttributes(boolean exposeJstlAttributes)
/*     */   {
/*  83 */     this.exposeJstlAttributes = exposeJstlAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlwaysInclude(boolean alwaysInclude)
/*     */   {
/*  94 */     this.alwaysInclude = alwaysInclude;
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet() throws Exception
/*     */   {
/*  99 */     super.afterPropertiesSet();
/*     */     
/* 101 */     ServletContext servletContext = getServletContext();
/* 102 */     Assert.state(servletContext != null, "No ServletContext");
/* 103 */     this.applicationContext = ServletUtil.getApplicationContext(servletContext);
/*     */     
/* 105 */     if (this.renderer == null) {
/* 106 */       TilesContainer container = TilesAccess.getContainer(this.applicationContext);
/* 107 */       this.renderer = new DefinitionRenderer(container);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean checkResource(final Locale locale)
/*     */     throws Exception
/*     */   {
/* 114 */     Assert.state(this.renderer != null, "No Renderer set");
/*     */     
/* 116 */     HttpServletRequest servletRequest = null;
/* 117 */     RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
/* 118 */     if ((requestAttributes instanceof ServletRequestAttributes)) {
/* 119 */       servletRequest = ((ServletRequestAttributes)requestAttributes).getRequest();
/*     */     }
/*     */     
/* 122 */     Request request = new ServletRequest(this.applicationContext, servletRequest, null)
/*     */     {
/*     */       public Locale getRequestLocale() {
/* 125 */         return locale;
/*     */       }
/*     */       
/* 128 */     };
/* 129 */     return this.renderer.isRenderable(getUrl(), request);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 136 */     Assert.state(this.renderer != null, "No Renderer set");
/*     */     
/* 138 */     exposeModelAsRequestAttributes(model, request);
/* 139 */     if (this.exposeJstlAttributes) {
/* 140 */       JstlUtils.exposeLocalizationContext(new RequestContext(request, getServletContext()));
/*     */     }
/* 142 */     if (this.alwaysInclude) {
/* 143 */       request.setAttribute(AbstractRequest.FORCE_INCLUDE_ATTRIBUTE_NAME, Boolean.valueOf(true));
/*     */     }
/*     */     
/* 146 */     Request tilesRequest = createTilesRequest(request, response);
/* 147 */     this.renderer.render(getUrl(), tilesRequest);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Request createTilesRequest(final HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 158 */     new ServletRequest(this.applicationContext, request, response)
/*     */     {
/*     */       public Locale getRequestLocale() {
/* 161 */         return RequestContextUtils.getLocale(request);
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\tiles3\TilesView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */