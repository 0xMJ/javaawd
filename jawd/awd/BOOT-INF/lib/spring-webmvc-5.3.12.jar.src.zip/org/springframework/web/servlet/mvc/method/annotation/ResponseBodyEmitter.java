/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResponseBodyEmitter
/*     */ {
/*     */   @Nullable
/*     */   private final Long timeout;
/*     */   @Nullable
/*     */   private Handler handler;
/*  73 */   private final Set<DataWithMediaType> earlySendAttempts = new LinkedHashSet(8);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean complete;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Throwable failure;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean sendFailed;
/*     */   
/*     */ 
/*     */ 
/*  92 */   private final DefaultCallback timeoutCallback = new DefaultCallback(null);
/*     */   
/*  94 */   private final ErrorCallback errorCallback = new ErrorCallback(null);
/*     */   
/*  96 */   private final DefaultCallback completionCallback = new DefaultCallback(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResponseBodyEmitter()
/*     */   {
/* 103 */     this.timeout = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ResponseBodyEmitter(Long timeout)
/*     */   {
/* 114 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Long getTimeout()
/*     */   {
/* 123 */     return this.timeout;
/*     */   }
/*     */   
/*     */   synchronized void initialize(Handler handler) throws IOException
/*     */   {
/* 128 */     this.handler = handler;
/*     */     try
/*     */     {
/* 131 */       for (DataWithMediaType sendAttempt : this.earlySendAttempts) {
/* 132 */         sendInternal(sendAttempt.getData(), sendAttempt.getMediaType());
/*     */       }
/*     */     }
/*     */     finally {
/* 136 */       this.earlySendAttempts.clear();
/*     */     }
/*     */     
/* 139 */     if (this.complete) {
/* 140 */       if (this.failure != null) {
/* 141 */         this.handler.completeWithError(this.failure);
/*     */       }
/*     */       else {
/* 144 */         this.handler.complete();
/*     */       }
/*     */     }
/*     */     else {
/* 148 */       this.handler.onTimeout(this.timeoutCallback);
/* 149 */       this.handler.onError(this.errorCallback);
/* 150 */       this.handler.onCompletion(this.completionCallback);
/*     */     }
/*     */   }
/*     */   
/*     */   synchronized void initializeWithError(Throwable ex) {
/* 155 */     this.complete = true;
/* 156 */     this.failure = ex;
/* 157 */     this.earlySendAttempts.clear();
/* 158 */     this.errorCallback.accept(ex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void extendResponse(ServerHttpResponse outputMessage) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void send(Object object)
/*     */     throws IOException
/*     */   {
/* 184 */     send(object, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void send(Object object, @Nullable MediaType mediaType)
/*     */     throws IOException
/*     */   {
/* 196 */     Assert.state(!this.complete, "ResponseBodyEmitter has already completed" + (this.failure != null ? " with error: " + this.failure : ""));
/*     */     
/*     */ 
/* 199 */     sendInternal(object, mediaType);
/*     */   }
/*     */   
/*     */   private void sendInternal(Object object, @Nullable MediaType mediaType) throws IOException {
/* 203 */     if (this.handler != null) {
/*     */       try {
/* 205 */         this.handler.send(object, mediaType);
/*     */       }
/*     */       catch (IOException ex) {
/* 208 */         this.sendFailed = true;
/* 209 */         throw ex;
/*     */       }
/*     */       catch (Throwable ex) {
/* 212 */         this.sendFailed = true;
/* 213 */         throw new IllegalStateException("Failed to send " + object, ex);
/*     */       }
/*     */       
/*     */     } else {
/* 217 */       this.earlySendAttempts.add(new DataWithMediaType(object, mediaType));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void complete()
/*     */   {
/* 231 */     if (this.sendFailed) {
/* 232 */       return;
/*     */     }
/* 234 */     this.complete = true;
/* 235 */     if (this.handler != null) {
/* 236 */       this.handler.complete();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void completeWithError(Throwable ex)
/*     */   {
/* 253 */     if (this.sendFailed) {
/* 254 */       return;
/*     */     }
/* 256 */     this.complete = true;
/* 257 */     this.failure = ex;
/* 258 */     if (this.handler != null) {
/* 259 */       this.handler.completeWithError(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void onTimeout(Runnable callback)
/*     */   {
/* 268 */     this.timeoutCallback.setDelegate(callback);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void onError(Consumer<Throwable> callback)
/*     */   {
/* 278 */     this.errorCallback.setDelegate(callback);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void onCompletion(Runnable callback)
/*     */   {
/* 288 */     this.completionCallback.setDelegate(callback);
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 294 */     return "ResponseBodyEmitter@" + ObjectUtils.getIdentityHexString(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static abstract interface Handler
/*     */   {
/*     */     public abstract void send(Object paramObject, @Nullable MediaType paramMediaType)
/*     */       throws IOException;
/*     */     
/*     */ 
/*     */ 
/*     */     public abstract void complete();
/*     */     
/*     */ 
/*     */     public abstract void completeWithError(Throwable paramThrowable);
/*     */     
/*     */ 
/*     */     public abstract void onTimeout(Runnable paramRunnable);
/*     */     
/*     */ 
/*     */     public abstract void onError(Consumer<Throwable> paramConsumer);
/*     */     
/*     */ 
/*     */     public abstract void onCompletion(Runnable paramRunnable);
/*     */   }
/*     */   
/*     */ 
/*     */   public static class DataWithMediaType
/*     */   {
/*     */     private final Object data;
/*     */     
/*     */     @Nullable
/*     */     private final MediaType mediaType;
/*     */     
/*     */ 
/*     */     public DataWithMediaType(Object data, @Nullable MediaType mediaType)
/*     */     {
/* 332 */       this.data = data;
/* 333 */       this.mediaType = mediaType;
/*     */     }
/*     */     
/*     */     public Object getData() {
/* 337 */       return this.data;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public MediaType getMediaType() {
/* 342 */       return this.mediaType;
/*     */     }
/*     */   }
/*     */   
/*     */   private class DefaultCallback implements Runnable {
/*     */     @Nullable
/*     */     private Runnable delegate;
/*     */     
/*     */     private DefaultCallback() {}
/*     */     
/*     */     public void setDelegate(Runnable delegate) {
/* 353 */       this.delegate = delegate;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 358 */       ResponseBodyEmitter.this.complete = true;
/* 359 */       if (this.delegate != null) {
/* 360 */         this.delegate.run();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class ErrorCallback implements Consumer<Throwable> {
/*     */     @Nullable
/*     */     private Consumer<Throwable> delegate;
/*     */     
/*     */     private ErrorCallback() {}
/*     */     
/*     */     public void setDelegate(Consumer<Throwable> callback) {
/* 372 */       this.delegate = callback;
/*     */     }
/*     */     
/*     */     public void accept(Throwable t)
/*     */     {
/* 377 */       ResponseBodyEmitter.this.complete = true;
/* 378 */       if (this.delegate != null) {
/* 379 */         this.delegate.accept(t);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ResponseBodyEmitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */