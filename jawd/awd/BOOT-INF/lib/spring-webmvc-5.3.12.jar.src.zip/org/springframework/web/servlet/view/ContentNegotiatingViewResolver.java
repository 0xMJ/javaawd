/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.accept.ContentNegotiationManagerFactoryBean;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*     */ import org.springframework.web.servlet.HandlerMapping;
/*     */ import org.springframework.web.servlet.SmartView;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.ViewResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentNegotiatingViewResolver
/*     */   extends WebApplicationObjectSupport
/*     */   implements ViewResolver, Ordered, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private ContentNegotiationManager contentNegotiationManager;
/*  95 */   private final ContentNegotiationManagerFactoryBean cnmFactoryBean = new ContentNegotiationManagerFactoryBean();
/*     */   
/*  97 */   private boolean useNotAcceptableStatusCode = false;
/*     */   
/*     */   @Nullable
/*     */   private List<View> defaultViews;
/*     */   
/*     */   @Nullable
/*     */   private List<ViewResolver> viewResolvers;
/*     */   
/* 105 */   private int order = Integer.MIN_VALUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentNegotiationManager(@Nullable ContentNegotiationManager contentNegotiationManager)
/*     */   {
/* 115 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public ContentNegotiationManager getContentNegotiationManager()
/*     */   {
/* 124 */     return this.contentNegotiationManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseNotAcceptableStatusCode(boolean useNotAcceptableStatusCode)
/*     */   {
/* 137 */     this.useNotAcceptableStatusCode = useNotAcceptableStatusCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isUseNotAcceptableStatusCode()
/*     */   {
/* 144 */     return this.useNotAcceptableStatusCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultViews(List<View> defaultViews)
/*     */   {
/* 152 */     this.defaultViews = defaultViews;
/*     */   }
/*     */   
/*     */   public List<View> getDefaultViews() {
/* 156 */     return this.defaultViews != null ? Collections.unmodifiableList(this.defaultViews) : 
/* 157 */       Collections.emptyList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setViewResolvers(List<ViewResolver> viewResolvers)
/*     */   {
/* 165 */     this.viewResolvers = viewResolvers;
/*     */   }
/*     */   
/*     */   public List<ViewResolver> getViewResolvers() {
/* 169 */     return this.viewResolvers != null ? Collections.unmodifiableList(this.viewResolvers) : 
/* 170 */       Collections.emptyList();
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 174 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 179 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void initServletContext(ServletContext servletContext)
/*     */   {
/* 186 */     Collection<ViewResolver> matchingBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(obtainApplicationContext(), ViewResolver.class).values();
/* 187 */     if (this.viewResolvers == null) {
/* 188 */       this.viewResolvers = new ArrayList(matchingBeans.size());
/* 189 */       for (ViewResolver viewResolver : matchingBeans) {
/* 190 */         if (this != viewResolver) {
/* 191 */           this.viewResolvers.add(viewResolver);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 196 */       for (int i = 0; i < this.viewResolvers.size(); i++) {
/* 197 */         ViewResolver vr = (ViewResolver)this.viewResolvers.get(i);
/* 198 */         if (!matchingBeans.contains(vr))
/*     */         {
/*     */ 
/* 201 */           String name = vr.getClass().getName() + i;
/* 202 */           obtainApplicationContext().getAutowireCapableBeanFactory().initializeBean(vr, name);
/*     */         }
/*     */       }
/*     */     }
/* 206 */     AnnotationAwareOrderComparator.sort(this.viewResolvers);
/* 207 */     this.cnmFactoryBean.setServletContext(servletContext);
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */   {
/* 212 */     if (this.contentNegotiationManager == null) {
/* 213 */       this.contentNegotiationManager = this.cnmFactoryBean.build();
/*     */     }
/* 215 */     if ((this.viewResolvers == null) || (this.viewResolvers.isEmpty())) {
/* 216 */       this.logger.warn("No ViewResolvers configured");
/*     */     }
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public View resolveViewName(String viewName, Locale locale)
/*     */     throws Exception
/*     */   {
/* 224 */     RequestAttributes attrs = RequestContextHolder.getRequestAttributes();
/* 225 */     Assert.state(attrs instanceof ServletRequestAttributes, "No current ServletRequestAttributes");
/* 226 */     List<MediaType> requestedMediaTypes = getMediaTypes(((ServletRequestAttributes)attrs).getRequest());
/* 227 */     if (requestedMediaTypes != null) {
/* 228 */       List<View> candidateViews = getCandidateViews(viewName, locale, requestedMediaTypes);
/* 229 */       View bestView = getBestView(candidateViews, requestedMediaTypes, attrs);
/* 230 */       if (bestView != null) {
/* 231 */         return bestView;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 236 */     String mediaTypeInfo = (this.logger.isDebugEnabled()) && (requestedMediaTypes != null) ? " given " + requestedMediaTypes.toString() : "";
/*     */     
/* 238 */     if (this.useNotAcceptableStatusCode) {
/* 239 */       if (this.logger.isDebugEnabled()) {
/* 240 */         this.logger.debug("Using 406 NOT_ACCEPTABLE" + mediaTypeInfo);
/*     */       }
/* 242 */       return NOT_ACCEPTABLE_VIEW;
/*     */     }
/*     */     
/* 245 */     this.logger.debug("View remains unresolved" + mediaTypeInfo);
/* 246 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected List<MediaType> getMediaTypes(HttpServletRequest request)
/*     */   {
/* 257 */     Assert.state(this.contentNegotiationManager != null, "No ContentNegotiationManager set");
/*     */     try {
/* 259 */       ServletWebRequest webRequest = new ServletWebRequest(request);
/* 260 */       List<MediaType> acceptableMediaTypes = this.contentNegotiationManager.resolveMediaTypes(webRequest);
/* 261 */       List<MediaType> producibleMediaTypes = getProducibleMediaTypes(request);
/* 262 */       Set<MediaType> compatibleMediaTypes = new LinkedHashSet();
/* 263 */       for (Iterator localIterator1 = acceptableMediaTypes.iterator(); localIterator1.hasNext();) { acceptable = (MediaType)localIterator1.next();
/* 264 */         for (MediaType producible : producibleMediaTypes) {
/* 265 */           if (acceptable.isCompatibleWith(producible))
/* 266 */             compatibleMediaTypes.add(getMostSpecificMediaType(acceptable, producible));
/*     */         }
/*     */       }
/*     */       MediaType acceptable;
/* 270 */       Object selectedMediaTypes = new ArrayList(compatibleMediaTypes);
/* 271 */       MediaType.sortBySpecificityAndQuality((List)selectedMediaTypes);
/* 272 */       return (List<MediaType>)selectedMediaTypes;
/*     */     }
/*     */     catch (HttpMediaTypeNotAcceptableException ex) {
/* 275 */       if (this.logger.isDebugEnabled())
/* 276 */         this.logger.debug(ex.getMessage());
/*     */     }
/* 278 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private List<MediaType> getProducibleMediaTypes(HttpServletRequest request)
/*     */   {
/* 285 */     Set<MediaType> mediaTypes = (Set)request.getAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE);
/* 286 */     if (!CollectionUtils.isEmpty(mediaTypes)) {
/* 287 */       return new ArrayList(mediaTypes);
/*     */     }
/*     */     
/* 290 */     return Collections.singletonList(MediaType.ALL);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MediaType getMostSpecificMediaType(MediaType acceptType, MediaType produceType)
/*     */   {
/* 299 */     produceType = produceType.copyQualityValue(acceptType);
/* 300 */     return MediaType.SPECIFICITY_COMPARATOR.compare(acceptType, produceType) < 0 ? acceptType : produceType;
/*     */   }
/*     */   
/*     */   private List<View> getCandidateViews(String viewName, Locale locale, List<MediaType> requestedMediaTypes)
/*     */     throws Exception
/*     */   {
/* 306 */     List<View> candidateViews = new ArrayList();
/* 307 */     Iterator localIterator1; if (this.viewResolvers != null) {
/* 308 */       Assert.state(this.contentNegotiationManager != null, "No ContentNegotiationManager set");
/* 309 */       for (localIterator1 = this.viewResolvers.iterator(); localIterator1.hasNext();) { viewResolver = (ViewResolver)localIterator1.next();
/* 310 */         view = viewResolver.resolveViewName(viewName, locale);
/* 311 */         if (view != null) {
/* 312 */           candidateViews.add(view);
/*     */         }
/* 314 */         for (MediaType requestedMediaType : requestedMediaTypes) {
/* 315 */           List<String> extensions = this.contentNegotiationManager.resolveFileExtensions(requestedMediaType);
/* 316 */           for (String extension : extensions) {
/* 317 */             String viewNameWithExtension = viewName + '.' + extension;
/* 318 */             view = viewResolver.resolveViewName(viewNameWithExtension, locale);
/* 319 */             if (view != null)
/* 320 */               candidateViews.add(view);
/*     */           }
/*     */         }
/*     */       } }
/*     */     ViewResolver viewResolver;
/*     */     View view;
/* 326 */     if (!CollectionUtils.isEmpty(this.defaultViews)) {
/* 327 */       candidateViews.addAll(this.defaultViews);
/*     */     }
/* 329 */     return candidateViews;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private View getBestView(List<View> candidateViews, List<MediaType> requestedMediaTypes, RequestAttributes attrs) {
/* 334 */     for (View candidateView : candidateViews) {
/* 335 */       if ((candidateView instanceof SmartView)) {
/* 336 */         smartView = (SmartView)candidateView;
/* 337 */         if (smartView.isRedirectView())
/* 338 */           return candidateView;
/*     */       }
/*     */     }
/*     */     SmartView smartView;
/* 342 */     for (??? = requestedMediaTypes.iterator(); ???.hasNext();) { mediaType = (MediaType)???.next();
/* 343 */       for (View candidateView : candidateViews)
/* 344 */         if (StringUtils.hasText(candidateView.getContentType())) {
/* 345 */           MediaType candidateContentType = MediaType.parseMediaType(candidateView.getContentType());
/* 346 */           if (mediaType.isCompatibleWith(candidateContentType)) {
/* 347 */             mediaType = mediaType.removeQualityValue();
/* 348 */             if (this.logger.isDebugEnabled()) {
/* 349 */               this.logger.debug("Selected '" + mediaType + "' given " + requestedMediaTypes);
/*     */             }
/* 351 */             attrs.setAttribute(View.SELECTED_CONTENT_TYPE, mediaType, 0);
/* 352 */             return candidateView;
/*     */           }
/*     */         }
/*     */     }
/*     */     MediaType mediaType;
/* 357 */     return null;
/*     */   }
/*     */   
/*     */ 
/* 361 */   private static final View NOT_ACCEPTABLE_VIEW = new View()
/*     */   {
/*     */     @Nullable
/*     */     public String getContentType()
/*     */     {
/* 366 */       return null;
/*     */     }
/*     */     
/*     */     public void render(@Nullable Map<String, ?> model, HttpServletRequest request, HttpServletResponse response)
/*     */     {
/* 371 */       response.setStatus(406);
/*     */     }
/*     */   };
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\ContentNegotiatingViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */