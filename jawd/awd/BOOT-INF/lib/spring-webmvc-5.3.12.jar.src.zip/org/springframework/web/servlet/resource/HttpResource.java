package org.springframework.web.servlet.resource;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;

public abstract interface HttpResource
  extends Resource
{
  public abstract HttpHeaders getResponseHeaders();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\HttpResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */