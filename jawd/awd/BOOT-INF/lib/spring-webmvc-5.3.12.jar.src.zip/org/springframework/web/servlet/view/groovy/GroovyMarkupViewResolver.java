/*    */ package org.springframework.web.servlet.view.groovy;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.springframework.web.servlet.view.AbstractTemplateViewResolver;
/*    */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GroovyMarkupViewResolver
/*    */   extends AbstractTemplateViewResolver
/*    */ {
/*    */   public GroovyMarkupViewResolver()
/*    */   {
/* 47 */     setViewClass(requiredViewClass());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public GroovyMarkupViewResolver(String prefix, String suffix)
/*    */   {
/* 58 */     this();
/* 59 */     setPrefix(prefix);
/* 60 */     setSuffix(suffix);
/*    */   }
/*    */   
/*    */ 
/*    */   protected Class<?> requiredViewClass()
/*    */   {
/* 66 */     return GroovyMarkupView.class;
/*    */   }
/*    */   
/*    */   protected AbstractUrlBasedView instantiateView()
/*    */   {
/* 71 */     return getViewClass() == GroovyMarkupView.class ? new GroovyMarkupView() : super.instantiateView();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Object getCacheKey(String viewName, Locale locale)
/*    */   {
/* 79 */     return viewName + '_' + locale;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\groovy\GroovyMarkupViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */