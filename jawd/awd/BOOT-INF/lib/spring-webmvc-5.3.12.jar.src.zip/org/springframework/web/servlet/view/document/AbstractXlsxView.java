/*    */ package org.springframework.web.servlet.view.document;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.poi.ss.usermodel.Workbook;
/*    */ import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractXlsxView
/*    */   extends AbstractXlsView
/*    */ {
/*    */   public AbstractXlsxView()
/*    */   {
/* 44 */     setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Workbook createWorkbook(Map<String, Object> model, HttpServletRequest request)
/*    */   {
/* 52 */     return new XSSFWorkbook();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\document\AbstractXlsxView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */