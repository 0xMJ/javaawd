package org.springframework.web.servlet.mvc.support;

import java.util.Collection;
import java.util.Map;
import org.springframework.lang.Nullable;
import org.springframework.ui.Model;

public abstract interface RedirectAttributes
  extends Model
{
  public abstract RedirectAttributes addAttribute(String paramString, @Nullable Object paramObject);
  
  public abstract RedirectAttributes addAttribute(Object paramObject);
  
  public abstract RedirectAttributes addAllAttributes(Collection<?> paramCollection);
  
  public abstract RedirectAttributes mergeAttributes(Map<String, ?> paramMap);
  
  public abstract RedirectAttributes addFlashAttribute(String paramString, @Nullable Object paramObject);
  
  public abstract RedirectAttributes addFlashAttribute(Object paramObject);
  
  public abstract Map<String, ?> getFlashAttributes();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\support\RedirectAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */