/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanNameUrlHandlerMapping
/*    */   extends AbstractDetectingUrlHandlerMapping
/*    */ {
/*    */   protected String[] determineUrlsForHandler(String beanName)
/*    */   {
/* 57 */     List<String> urls = new ArrayList();
/* 58 */     if (beanName.startsWith("/")) {
/* 59 */       urls.add(beanName);
/*    */     }
/* 61 */     String[] aliases = obtainApplicationContext().getAliases(beanName);
/* 62 */     for (String alias : aliases) {
/* 63 */       if (alias.startsWith("/")) {
/* 64 */         urls.add(alias);
/*    */       }
/*    */     }
/* 67 */     return StringUtils.toStringArray(urls);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\handler\BeanNameUrlHandlerMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */