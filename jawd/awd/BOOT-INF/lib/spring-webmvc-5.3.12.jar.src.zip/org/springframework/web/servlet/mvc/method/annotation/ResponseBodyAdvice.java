package org.springframework.web.servlet.mvc.method.annotation;

import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.lang.Nullable;

public abstract interface ResponseBodyAdvice<T>
{
  public abstract boolean supports(MethodParameter paramMethodParameter, Class<? extends HttpMessageConverter<?>> paramClass);
  
  @Nullable
  public abstract T beforeBodyWrite(@Nullable T paramT, MethodParameter paramMethodParameter, MediaType paramMediaType, Class<? extends HttpMessageConverter<?>> paramClass, ServerHttpRequest paramServerHttpRequest, ServerHttpResponse paramServerHttpResponse);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ResponseBodyAdvice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */