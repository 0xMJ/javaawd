/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.web.context.request.ServletWebRequest;
/*    */ import org.springframework.web.servlet.support.RequestContextUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DispatcherServletWebRequest
/*    */   extends ServletWebRequest
/*    */ {
/*    */   public DispatcherServletWebRequest(HttpServletRequest request)
/*    */   {
/* 45 */     super(request);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DispatcherServletWebRequest(HttpServletRequest request, HttpServletResponse response)
/*    */   {
/* 54 */     super(request, response);
/*    */   }
/*    */   
/*    */   public Locale getLocale()
/*    */   {
/* 59 */     return RequestContextUtils.getLocale(getRequest());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\handler\DispatcherServletWebRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */