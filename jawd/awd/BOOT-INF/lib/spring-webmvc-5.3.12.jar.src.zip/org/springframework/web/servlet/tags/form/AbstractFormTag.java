/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.servlet.tags.HtmlEscapingAwareTag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFormTag
/*     */   extends HtmlEscapingAwareTag
/*     */ {
/*     */   @Nullable
/*     */   protected Object evaluate(String attributeName, @Nullable Object value)
/*     */     throws JspException
/*     */   {
/*  51 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void writeOptionalAttribute(TagWriter tagWriter, String attributeName, @Nullable String value)
/*     */     throws JspException
/*     */   {
/*  65 */     if (value != null) {
/*  66 */       tagWriter.writeOptionalAttributeValue(attributeName, getDisplayString(evaluate(attributeName, value)));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TagWriter createTagWriter()
/*     */   {
/*  77 */     return new TagWriter(this.pageContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final int doStartTagInternal()
/*     */     throws Exception
/*     */   {
/*  87 */     return writeTagContent(createTagWriter());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDisplayString(@Nullable Object value)
/*     */   {
/*  95 */     return ValueFormatter.getDisplayString(value, isHtmlEscape());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDisplayString(@Nullable Object value, @Nullable PropertyEditor propertyEditor)
/*     */   {
/* 105 */     return ValueFormatter.getDisplayString(value, propertyEditor, isHtmlEscape());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isDefaultHtmlEscape()
/*     */   {
/* 113 */     Boolean defaultHtmlEscape = getRequestContext().getDefaultHtmlEscape();
/* 114 */     return (defaultHtmlEscape == null) || (defaultHtmlEscape.booleanValue());
/*     */   }
/*     */   
/*     */   protected abstract int writeTagContent(TagWriter paramTagWriter)
/*     */     throws JspException;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\form\AbstractFormTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */