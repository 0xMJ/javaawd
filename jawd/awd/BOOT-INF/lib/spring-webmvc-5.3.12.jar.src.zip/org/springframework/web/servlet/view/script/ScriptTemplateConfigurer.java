/*     */ package org.springframework.web.servlet.view.script;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.function.Supplier;
/*     */ import javax.script.ScriptEngine;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScriptTemplateConfigurer
/*     */   implements ScriptTemplateConfig
/*     */ {
/*     */   @Nullable
/*     */   private ScriptEngine engine;
/*     */   @Nullable
/*     */   private Supplier<ScriptEngine> engineSupplier;
/*     */   @Nullable
/*     */   private String engineName;
/*     */   @Nullable
/*     */   private Boolean sharedEngine;
/*     */   @Nullable
/*     */   private String[] scripts;
/*     */   @Nullable
/*     */   private String renderObject;
/*     */   @Nullable
/*     */   private String renderFunction;
/*     */   @Nullable
/*     */   private String contentType;
/*     */   @Nullable
/*     */   private Charset charset;
/*     */   @Nullable
/*     */   private String resourceLoaderPath;
/*     */   
/*     */   public ScriptTemplateConfigurer() {}
/*     */   
/*     */   public ScriptTemplateConfigurer(String engineName)
/*     */   {
/*  95 */     this.engineName = engineName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEngine(@Nullable ScriptEngine engine)
/*     */   {
/* 111 */     this.engine = engine;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public ScriptEngine getEngine()
/*     */   {
/* 117 */     return this.engine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEngineSupplier(@Nullable Supplier<ScriptEngine> engineSupplier)
/*     */   {
/* 130 */     this.engineSupplier = engineSupplier;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Supplier<ScriptEngine> getEngineSupplier()
/*     */   {
/* 136 */     return this.engineSupplier;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEngineName(@Nullable String engineName)
/*     */   {
/* 147 */     this.engineName = engineName;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String getEngineName()
/*     */   {
/* 153 */     return this.engineName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSharedEngine(@Nullable Boolean sharedEngine)
/*     */   {
/* 168 */     this.sharedEngine = sharedEngine;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Boolean isSharedEngine()
/*     */   {
/* 174 */     return this.sharedEngine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScripts(@Nullable String... scriptNames)
/*     */   {
/* 189 */     this.scripts = scriptNames;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String[] getScripts()
/*     */   {
/* 195 */     return this.scripts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRenderObject(@Nullable String renderObject)
/*     */   {
/* 204 */     this.renderObject = renderObject;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String getRenderObject()
/*     */   {
/* 210 */     return this.renderObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRenderFunction(@Nullable String renderFunction)
/*     */   {
/* 225 */     this.renderFunction = renderFunction;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String getRenderFunction()
/*     */   {
/* 231 */     return this.renderFunction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentType(@Nullable String contentType)
/*     */   {
/* 240 */     this.contentType = contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public String getContentType()
/*     */   {
/* 250 */     return this.contentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharset(@Nullable Charset charset)
/*     */   {
/* 258 */     this.charset = charset;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Charset getCharset()
/*     */   {
/* 264 */     return this.charset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceLoaderPath(@Nullable String resourceLoaderPath)
/*     */   {
/* 276 */     this.resourceLoaderPath = resourceLoaderPath;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String getResourceLoaderPath()
/*     */   {
/* 282 */     return this.resourceLoaderPath;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\script\ScriptTemplateConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */