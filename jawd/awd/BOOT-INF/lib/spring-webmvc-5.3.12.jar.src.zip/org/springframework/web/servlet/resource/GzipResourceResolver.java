/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.io.AbstractResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class GzipResourceResolver
/*     */   extends AbstractResourceResolver
/*     */ {
/*     */   protected Resource resolveResourceInternal(@Nullable HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain)
/*     */   {
/*  53 */     Resource resource = chain.resolveResource(request, requestPath, locations);
/*  54 */     if ((resource == null) || ((request != null) && (!isGzipAccepted(request)))) {
/*  55 */       return resource;
/*     */     }
/*     */     try
/*     */     {
/*  59 */       Resource gzipped = new GzippedResource(resource);
/*  60 */       if (gzipped.exists()) {
/*  61 */         return gzipped;
/*     */       }
/*     */     }
/*     */     catch (IOException ex) {
/*  65 */       this.logger.trace("No gzip resource for [" + resource.getFilename() + "]", ex);
/*     */     }
/*     */     
/*  68 */     return resource;
/*     */   }
/*     */   
/*     */   private boolean isGzipAccepted(HttpServletRequest request) {
/*  72 */     String value = request.getHeader("Accept-Encoding");
/*  73 */     return (value != null) && (value.toLowerCase().contains("gzip"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String resolveUrlPathInternal(String resourceUrlPath, List<? extends Resource> locations, ResourceResolverChain chain)
/*     */   {
/*  80 */     return chain.resolveUrlPath(resourceUrlPath, locations);
/*     */   }
/*     */   
/*     */ 
/*     */   static final class GzippedResource
/*     */     extends AbstractResource
/*     */     implements HttpResource
/*     */   {
/*     */     private final Resource original;
/*     */     private final Resource gzipped;
/*     */     
/*     */     public GzippedResource(Resource original)
/*     */       throws IOException
/*     */     {
/*  94 */       this.original = original;
/*  95 */       this.gzipped = original.createRelative(original.getFilename() + ".gz");
/*     */     }
/*     */     
/*     */     public InputStream getInputStream() throws IOException
/*     */     {
/* 100 */       return this.gzipped.getInputStream();
/*     */     }
/*     */     
/*     */     public boolean exists()
/*     */     {
/* 105 */       return this.gzipped.exists();
/*     */     }
/*     */     
/*     */     public boolean isReadable()
/*     */     {
/* 110 */       return this.gzipped.isReadable();
/*     */     }
/*     */     
/*     */     public boolean isOpen()
/*     */     {
/* 115 */       return this.gzipped.isOpen();
/*     */     }
/*     */     
/*     */     public boolean isFile()
/*     */     {
/* 120 */       return this.gzipped.isFile();
/*     */     }
/*     */     
/*     */     public URL getURL() throws IOException
/*     */     {
/* 125 */       return this.gzipped.getURL();
/*     */     }
/*     */     
/*     */     public URI getURI() throws IOException
/*     */     {
/* 130 */       return this.gzipped.getURI();
/*     */     }
/*     */     
/*     */     public File getFile() throws IOException
/*     */     {
/* 135 */       return this.gzipped.getFile();
/*     */     }
/*     */     
/*     */     public long contentLength() throws IOException
/*     */     {
/* 140 */       return this.gzipped.contentLength();
/*     */     }
/*     */     
/*     */     public long lastModified() throws IOException
/*     */     {
/* 145 */       return this.gzipped.lastModified();
/*     */     }
/*     */     
/*     */     public Resource createRelative(String relativePath) throws IOException
/*     */     {
/* 150 */       return this.gzipped.createRelative(relativePath);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public String getFilename()
/*     */     {
/* 156 */       return this.original.getFilename();
/*     */     }
/*     */     
/*     */     public String getDescription()
/*     */     {
/* 161 */       return this.gzipped.getDescription();
/*     */     }
/*     */     
/*     */ 
/*     */     public HttpHeaders getResponseHeaders()
/*     */     {
/* 167 */       HttpHeaders headers = (this.original instanceof HttpResource) ? ((HttpResource)this.original).getResponseHeaders() : new HttpHeaders();
/* 168 */       headers.add("Content-Encoding", "gzip");
/* 169 */       headers.add("Vary", "Accept-Encoding");
/* 170 */       return headers;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\GzipResourceResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */