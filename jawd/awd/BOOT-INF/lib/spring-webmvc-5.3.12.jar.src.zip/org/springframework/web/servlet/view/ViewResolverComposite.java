/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.ViewResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewResolverComposite
/*     */   implements ViewResolver, Ordered, InitializingBean, ApplicationContextAware, ServletContextAware
/*     */ {
/*  47 */   private final List<ViewResolver> viewResolvers = new ArrayList();
/*     */   
/*  49 */   private int order = Integer.MAX_VALUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setViewResolvers(List<ViewResolver> viewResolvers)
/*     */   {
/*  56 */     this.viewResolvers.clear();
/*  57 */     if (!CollectionUtils.isEmpty(viewResolvers)) {
/*  58 */       this.viewResolvers.addAll(viewResolvers);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<ViewResolver> getViewResolvers()
/*     */   {
/*  66 */     return Collections.unmodifiableList(this.viewResolvers);
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/*  70 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  75 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException
/*     */   {
/*  80 */     for (ViewResolver viewResolver : this.viewResolvers) {
/*  81 */       if ((viewResolver instanceof ApplicationContextAware)) {
/*  82 */         ((ApplicationContextAware)viewResolver).setApplicationContext(applicationContext);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/*  89 */     for (ViewResolver viewResolver : this.viewResolvers) {
/*  90 */       if ((viewResolver instanceof ServletContextAware)) {
/*  91 */         ((ServletContextAware)viewResolver).setServletContext(servletContext);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet() throws Exception
/*     */   {
/*  98 */     for (ViewResolver viewResolver : this.viewResolvers) {
/*  99 */       if ((viewResolver instanceof InitializingBean)) {
/* 100 */         ((InitializingBean)viewResolver).afterPropertiesSet();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public View resolveViewName(String viewName, Locale locale) throws Exception
/*     */   {
/* 108 */     for (ViewResolver viewResolver : this.viewResolvers) {
/* 109 */       View view = viewResolver.resolveViewName(viewName, locale);
/* 110 */       if (view != null) {
/* 111 */         return view;
/*     */       }
/*     */     }
/* 114 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\ViewResolverComposite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */