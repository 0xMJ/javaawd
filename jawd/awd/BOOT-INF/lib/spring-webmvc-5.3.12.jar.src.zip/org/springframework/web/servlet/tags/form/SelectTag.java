/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectTag
/*     */   extends AbstractHtmlInputElementTag
/*     */ {
/*     */   public static final String LIST_VALUE_PAGE_ATTRIBUTE = "org.springframework.web.servlet.tags.form.SelectTag.listValue";
/* 256 */   private static final Object EMPTY = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Object items;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private String itemValue;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private String itemLabel;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private String size;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Object multiple;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private TagWriter tagWriter;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setItems(@Nullable Object items)
/*     */   {
/* 311 */     this.items = (items != null ? items : EMPTY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object getItems()
/*     */   {
/* 320 */     return this.items;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setItemValue(String itemValue)
/*     */   {
/* 331 */     this.itemValue = itemValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getItemValue()
/*     */   {
/* 340 */     return this.itemValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setItemLabel(String itemLabel)
/*     */   {
/* 349 */     this.itemLabel = itemLabel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getItemLabel()
/*     */   {
/* 358 */     return this.itemLabel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSize(String size)
/*     */   {
/* 366 */     this.size = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getSize()
/*     */   {
/* 374 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMultiple(Object multiple)
/*     */   {
/* 382 */     this.multiple = multiple;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object getMultiple()
/*     */   {
/* 391 */     return this.multiple;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int writeTagContent(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 404 */     tagWriter.startTag("select");
/* 405 */     writeDefaultAttributes(tagWriter);
/* 406 */     if (isMultiple()) {
/* 407 */       tagWriter.writeAttribute("multiple", "multiple");
/*     */     }
/* 409 */     tagWriter.writeOptionalAttributeValue("size", getDisplayString(evaluate("size", getSize())));
/*     */     
/* 411 */     Object items = getItems();
/* 412 */     if (items != null)
/*     */     {
/* 414 */       if (items != EMPTY) {
/* 415 */         Object itemsObject = evaluate("items", items);
/* 416 */         if (itemsObject != null) {
/* 417 */           final String selectName = getName();
/*     */           
/* 419 */           String valueProperty = getItemValue() != null ? ObjectUtils.getDisplayString(evaluate("itemValue", getItemValue())) : null;
/*     */           
/* 421 */           String labelProperty = getItemLabel() != null ? ObjectUtils.getDisplayString(evaluate("itemLabel", getItemLabel())) : null;
/*     */           
/* 423 */           OptionWriter optionWriter = new OptionWriter(itemsObject, getBindStatus(), valueProperty, labelProperty, isHtmlEscape())
/*     */           {
/*     */             protected String processOptionValue(String resolvedValue)
/*     */             {
/* 426 */               return SelectTag.this.processFieldValue(selectName, resolvedValue, "option");
/*     */             }
/* 428 */           };
/* 429 */           optionWriter.writeOptions(tagWriter);
/*     */         }
/*     */       }
/* 432 */       tagWriter.endTag(true);
/* 433 */       writeHiddenTagIfNecessary(tagWriter);
/* 434 */       return 0;
/*     */     }
/*     */     
/*     */ 
/* 438 */     tagWriter.forceBlock();
/* 439 */     this.tagWriter = tagWriter;
/* 440 */     this.pageContext.setAttribute("org.springframework.web.servlet.tags.form.SelectTag.listValue", getBindStatus());
/* 441 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeHiddenTagIfNecessary(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 451 */     if (isMultiple()) {
/* 452 */       tagWriter.startTag("input");
/* 453 */       tagWriter.writeAttribute("type", "hidden");
/* 454 */       String name = "_" + getName();
/* 455 */       tagWriter.writeAttribute("name", name);
/* 456 */       tagWriter.writeAttribute("value", processFieldValue(name, "1", "hidden"));
/* 457 */       tagWriter.endTag();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isMultiple() throws JspException {
/* 462 */     Object multiple = getMultiple();
/* 463 */     if (multiple != null) {
/* 464 */       String stringValue = multiple.toString();
/* 465 */       return ("multiple".equalsIgnoreCase(stringValue)) || (Boolean.parseBoolean(stringValue));
/*     */     }
/* 467 */     return forceMultiple();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean forceMultiple()
/*     */     throws JspException
/*     */   {
/* 475 */     BindStatus bindStatus = getBindStatus();
/* 476 */     Class<?> valueType = bindStatus.getValueType();
/* 477 */     if ((valueType != null) && (typeRequiresMultiple(valueType))) {
/* 478 */       return true;
/*     */     }
/* 480 */     if (bindStatus.getEditor() != null) {
/* 481 */       Object editorValue = bindStatus.getEditor().getValue();
/* 482 */       if ((editorValue != null) && (typeRequiresMultiple(editorValue.getClass()))) {
/* 483 */         return true;
/*     */       }
/*     */     }
/* 486 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean typeRequiresMultiple(Class<?> type)
/*     */   {
/* 494 */     return (type.isArray()) || (Collection.class.isAssignableFrom(type)) || (Map.class.isAssignableFrom(type));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/* 503 */     if (this.tagWriter != null) {
/* 504 */       this.tagWriter.endTag();
/* 505 */       writeHiddenTagIfNecessary(this.tagWriter);
/*     */     }
/* 507 */     return 6;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFinally()
/*     */   {
/* 516 */     super.doFinally();
/* 517 */     this.tagWriter = null;
/* 518 */     this.pageContext.removeAttribute("org.springframework.web.servlet.tags.form.SelectTag.listValue");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\form\SelectTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */