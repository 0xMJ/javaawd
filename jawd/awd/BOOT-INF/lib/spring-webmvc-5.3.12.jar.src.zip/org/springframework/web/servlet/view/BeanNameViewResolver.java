/*    */ package org.springframework.web.servlet.view;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*    */ import org.springframework.web.servlet.View;
/*    */ import org.springframework.web.servlet.ViewResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanNameViewResolver
/*    */   extends WebApplicationObjectSupport
/*    */   implements ViewResolver, Ordered
/*    */ {
/* 47 */   private int order = Integer.MAX_VALUE;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setOrder(int order)
/*    */   {
/* 56 */     this.order = order;
/*    */   }
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 61 */     return this.order;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public View resolveViewName(String viewName, Locale locale)
/*    */     throws BeansException
/*    */   {
/* 68 */     ApplicationContext context = obtainApplicationContext();
/* 69 */     if (!context.containsBean(viewName))
/*    */     {
/* 71 */       return null;
/*    */     }
/* 73 */     if (!context.isTypeMatch(viewName, View.class)) {
/* 74 */       if (this.logger.isDebugEnabled()) {
/* 75 */         this.logger.debug("Found bean named '" + viewName + "' but it does not implement View");
/*    */       }
/*    */       
/*    */ 
/* 79 */       return null;
/*    */     }
/* 81 */     return (View)context.getBean(viewName, View.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\BeanNameViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */