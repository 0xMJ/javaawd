/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.security.Principal;
/*     */ import java.time.ZoneId;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.PushBuilder;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ import org.springframework.web.multipart.MultipartRequest;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletRequestMethodArgumentResolver
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*     */   @Nullable
/*     */   private static Class<?> pushBuilder;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  76 */       pushBuilder = ClassUtils.forName("javax.servlet.http.PushBuilder", ServletRequestMethodArgumentResolver.class
/*  77 */         .getClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*  81 */       pushBuilder = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*  88 */     Class<?> paramType = parameter.getParameterType();
/*  89 */     return (WebRequest.class.isAssignableFrom(paramType)) || 
/*  90 */       (ServletRequest.class.isAssignableFrom(paramType)) || 
/*  91 */       (MultipartRequest.class.isAssignableFrom(paramType)) || 
/*  92 */       (HttpSession.class.isAssignableFrom(paramType)) || ((pushBuilder != null) && 
/*  93 */       (pushBuilder.isAssignableFrom(paramType))) || 
/*  94 */       ((Principal.class.isAssignableFrom(paramType)) && (!parameter.hasParameterAnnotations())) || 
/*  95 */       (InputStream.class.isAssignableFrom(paramType)) || 
/*  96 */       (Reader.class.isAssignableFrom(paramType)) || (HttpMethod.class == paramType) || (Locale.class == paramType) || (TimeZone.class == paramType) || (ZoneId.class == paramType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, @Nullable ModelAndViewContainer mavContainer, NativeWebRequest webRequest, @Nullable WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/* 107 */     Class<?> paramType = parameter.getParameterType();
/*     */     
/*     */ 
/* 110 */     if (WebRequest.class.isAssignableFrom(paramType)) {
/* 111 */       if (!paramType.isInstance(webRequest))
/*     */       {
/* 113 */         throw new IllegalStateException("Current request is not of type [" + paramType.getName() + "]: " + webRequest);
/*     */       }
/* 115 */       return webRequest;
/*     */     }
/*     */     
/*     */ 
/* 119 */     if ((ServletRequest.class.isAssignableFrom(paramType)) || (MultipartRequest.class.isAssignableFrom(paramType))) {
/* 120 */       return resolveNativeRequest(webRequest, paramType);
/*     */     }
/*     */     
/*     */ 
/* 124 */     return resolveArgument(paramType, (HttpServletRequest)resolveNativeRequest(webRequest, HttpServletRequest.class));
/*     */   }
/*     */   
/*     */   private <T> T resolveNativeRequest(NativeWebRequest webRequest, Class<T> requiredType) {
/* 128 */     T nativeRequest = webRequest.getNativeRequest(requiredType);
/* 129 */     if (nativeRequest == null)
/*     */     {
/* 131 */       throw new IllegalStateException("Current request is not of type [" + requiredType.getName() + "]: " + webRequest);
/*     */     }
/* 133 */     return nativeRequest;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object resolveArgument(Class<?> paramType, HttpServletRequest request) throws IOException {
/* 138 */     if (HttpSession.class.isAssignableFrom(paramType)) {
/* 139 */       HttpSession session = request.getSession();
/* 140 */       if ((session != null) && (!paramType.isInstance(session)))
/*     */       {
/* 142 */         throw new IllegalStateException("Current session is not of type [" + paramType.getName() + "]: " + session);
/*     */       }
/* 144 */       return session;
/*     */     }
/* 146 */     if ((pushBuilder != null) && (pushBuilder.isAssignableFrom(paramType))) {
/* 147 */       return PushBuilderDelegate.resolvePushBuilder(request, paramType);
/*     */     }
/* 149 */     if (InputStream.class.isAssignableFrom(paramType)) {
/* 150 */       InputStream inputStream = request.getInputStream();
/* 151 */       if ((inputStream != null) && (!paramType.isInstance(inputStream)))
/*     */       {
/* 153 */         throw new IllegalStateException("Request input stream is not of type [" + paramType.getName() + "]: " + inputStream);
/*     */       }
/* 155 */       return inputStream;
/*     */     }
/* 157 */     if (Reader.class.isAssignableFrom(paramType)) {
/* 158 */       Reader reader = request.getReader();
/* 159 */       if ((reader != null) && (!paramType.isInstance(reader)))
/*     */       {
/* 161 */         throw new IllegalStateException("Request body reader is not of type [" + paramType.getName() + "]: " + reader);
/*     */       }
/* 163 */       return reader;
/*     */     }
/* 165 */     if (Principal.class.isAssignableFrom(paramType)) {
/* 166 */       Principal userPrincipal = request.getUserPrincipal();
/* 167 */       if ((userPrincipal != null) && (!paramType.isInstance(userPrincipal)))
/*     */       {
/* 169 */         throw new IllegalStateException("Current user principal is not of type [" + paramType.getName() + "]: " + userPrincipal);
/*     */       }
/* 171 */       return userPrincipal;
/*     */     }
/* 173 */     if (HttpMethod.class == paramType) {
/* 174 */       return HttpMethod.resolve(request.getMethod());
/*     */     }
/* 176 */     if (Locale.class == paramType) {
/* 177 */       return RequestContextUtils.getLocale(request);
/*     */     }
/* 179 */     if (TimeZone.class == paramType) {
/* 180 */       TimeZone timeZone = RequestContextUtils.getTimeZone(request);
/* 181 */       return timeZone != null ? timeZone : TimeZone.getDefault();
/*     */     }
/* 183 */     if (ZoneId.class == paramType) {
/* 184 */       TimeZone timeZone = RequestContextUtils.getTimeZone(request);
/* 185 */       return timeZone != null ? timeZone.toZoneId() : ZoneId.systemDefault();
/*     */     }
/*     */     
/*     */ 
/* 189 */     throw new UnsupportedOperationException("Unknown parameter type: " + paramType.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class PushBuilderDelegate
/*     */   {
/*     */     @Nullable
/*     */     public static Object resolvePushBuilder(HttpServletRequest request, Class<?> paramType)
/*     */     {
/* 200 */       PushBuilder pushBuilder = request.newPushBuilder();
/* 201 */       if ((pushBuilder != null) && (!paramType.isInstance(pushBuilder)))
/*     */       {
/* 203 */         throw new IllegalStateException("Current push builder is not of type [" + paramType.getName() + "]: " + pushBuilder);
/*     */       }
/* 205 */       return pushBuilder;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\ServletRequestMethodArgumentResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */