package org.springframework.web.servlet.view.script;

import java.nio.charset.Charset;
import java.util.function.Supplier;
import javax.script.ScriptEngine;
import org.springframework.lang.Nullable;

public abstract interface ScriptTemplateConfig
{
  @Nullable
  public abstract ScriptEngine getEngine();
  
  @Nullable
  public abstract Supplier<ScriptEngine> getEngineSupplier();
  
  @Nullable
  public abstract String getEngineName();
  
  @Nullable
  public abstract Boolean isSharedEngine();
  
  @Nullable
  public abstract String[] getScripts();
  
  @Nullable
  public abstract String getRenderObject();
  
  @Nullable
  public abstract String getRenderFunction();
  
  @Nullable
  public abstract String getContentType();
  
  @Nullable
  public abstract Charset getCharset();
  
  @Nullable
  public abstract String getResourceLoaderPath();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\script\ScriptTemplateConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */