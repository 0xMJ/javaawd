/*    */ package org.springframework.web.servlet.mvc.condition;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractMediaTypeExpression
/*    */   implements MediaTypeExpression, Comparable<AbstractMediaTypeExpression>
/*    */ {
/*    */   private final MediaType mediaType;
/*    */   private final boolean isNegated;
/*    */   
/*    */   AbstractMediaTypeExpression(String expression)
/*    */   {
/* 39 */     if (expression.startsWith("!")) {
/* 40 */       this.isNegated = true;
/* 41 */       expression = expression.substring(1);
/*    */     }
/*    */     else {
/* 44 */       this.isNegated = false;
/*    */     }
/* 46 */     this.mediaType = MediaType.parseMediaType(expression);
/*    */   }
/*    */   
/*    */   AbstractMediaTypeExpression(MediaType mediaType, boolean negated) {
/* 50 */     this.mediaType = mediaType;
/* 51 */     this.isNegated = negated;
/*    */   }
/*    */   
/*    */ 
/*    */   public MediaType getMediaType()
/*    */   {
/* 57 */     return this.mediaType;
/*    */   }
/*    */   
/*    */   public boolean isNegated()
/*    */   {
/* 62 */     return this.isNegated;
/*    */   }
/*    */   
/*    */ 
/*    */   public int compareTo(AbstractMediaTypeExpression other)
/*    */   {
/* 68 */     return MediaType.SPECIFICITY_COMPARATOR.compare(getMediaType(), other.getMediaType());
/*    */   }
/*    */   
/*    */   public boolean equals(@Nullable Object other)
/*    */   {
/* 73 */     if (this == other) {
/* 74 */       return true;
/*    */     }
/* 76 */     if ((other == null) || (getClass() != other.getClass())) {
/* 77 */       return false;
/*    */     }
/* 79 */     AbstractMediaTypeExpression otherExpr = (AbstractMediaTypeExpression)other;
/* 80 */     return (this.mediaType.equals(otherExpr.mediaType)) && (this.isNegated == otherExpr.isNegated);
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 85 */     return this.mediaType.hashCode();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 90 */     if (this.isNegated) {
/* 91 */       return '!' + this.mediaType.toString();
/*    */     }
/* 93 */     return this.mediaType.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\condition\AbstractMediaTypeExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */