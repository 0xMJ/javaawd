/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpRequestHandler;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultServletHttpRequestHandler
/*     */   implements HttpRequestHandler, ServletContextAware
/*     */ {
/*     */   private static final String COMMON_DEFAULT_SERVLET_NAME = "default";
/*     */   private static final String GAE_DEFAULT_SERVLET_NAME = "_ah_default";
/*     */   private static final String RESIN_DEFAULT_SERVLET_NAME = "resin-file";
/*     */   private static final String WEBLOGIC_DEFAULT_SERVLET_NAME = "FileServlet";
/*     */   private static final String WEBSPHERE_DEFAULT_SERVLET_NAME = "SimpleFileServlet";
/*     */   @Nullable
/*     */   private String defaultServletName;
/*     */   @Nullable
/*     */   private ServletContext servletContext;
/*     */   
/*     */   public void setDefaultServletName(String defaultServletName)
/*     */   {
/*  83 */     this.defaultServletName = defaultServletName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/*  93 */     this.servletContext = servletContext;
/*  94 */     if (!StringUtils.hasText(this.defaultServletName)) {
/*  95 */       if (this.servletContext.getNamedDispatcher("default") != null) {
/*  96 */         this.defaultServletName = "default";
/*     */       }
/*  98 */       else if (this.servletContext.getNamedDispatcher("_ah_default") != null) {
/*  99 */         this.defaultServletName = "_ah_default";
/*     */       }
/* 101 */       else if (this.servletContext.getNamedDispatcher("resin-file") != null) {
/* 102 */         this.defaultServletName = "resin-file";
/*     */       }
/* 104 */       else if (this.servletContext.getNamedDispatcher("FileServlet") != null) {
/* 105 */         this.defaultServletName = "FileServlet";
/*     */       }
/* 107 */       else if (this.servletContext.getNamedDispatcher("SimpleFileServlet") != null) {
/* 108 */         this.defaultServletName = "SimpleFileServlet";
/*     */       }
/*     */       else {
/* 111 */         throw new IllegalStateException("Unable to locate the default servlet for serving static content. Please set the 'defaultServletName' property explicitly.");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleRequest(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/* 122 */     Assert.state(this.servletContext != null, "No ServletContext set");
/* 123 */     RequestDispatcher rd = this.servletContext.getNamedDispatcher(this.defaultServletName);
/* 124 */     if (rd == null) {
/* 125 */       throw new IllegalStateException("A RequestDispatcher could not be located for the default servlet '" + this.defaultServletName + "'");
/*     */     }
/*     */     
/* 128 */     rd.forward(request, response);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\DefaultServletHttpRequestHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */