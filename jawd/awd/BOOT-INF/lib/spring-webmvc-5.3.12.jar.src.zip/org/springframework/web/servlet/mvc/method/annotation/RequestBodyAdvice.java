package org.springframework.web.servlet.mvc.method.annotation;

import java.io.IOException;
import java.lang.reflect.Type;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.lang.Nullable;

public abstract interface RequestBodyAdvice
{
  public abstract boolean supports(MethodParameter paramMethodParameter, Type paramType, Class<? extends HttpMessageConverter<?>> paramClass);
  
  public abstract HttpInputMessage beforeBodyRead(HttpInputMessage paramHttpInputMessage, MethodParameter paramMethodParameter, Type paramType, Class<? extends HttpMessageConverter<?>> paramClass)
    throws IOException;
  
  public abstract Object afterBodyRead(Object paramObject, HttpInputMessage paramHttpInputMessage, MethodParameter paramMethodParameter, Type paramType, Class<? extends HttpMessageConverter<?>> paramClass);
  
  @Nullable
  public abstract Object handleEmptyBody(@Nullable Object paramObject, HttpInputMessage paramHttpInputMessage, MethodParameter paramMethodParameter, Type paramType, Class<? extends HttpMessageConverter<?>> paramClass);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\RequestBodyAdvice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */