/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.servlet.handler.BeanNameUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.HandlerMappingIntrospector;
/*     */ import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
/*     */ import org.springframework.web.servlet.mvc.HttpRequestHandlerAdapter;
/*     */ import org.springframework.web.servlet.mvc.SimpleControllerHandlerAdapter;
/*     */ import org.springframework.web.servlet.support.SessionFlashMapManager;
/*     */ import org.springframework.web.servlet.theme.FixedThemeResolver;
/*     */ import org.springframework.web.servlet.view.DefaultRequestToViewNameTranslator;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MvcNamespaceUtils
/*     */ {
/*  55 */   private static final String BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME = BeanNameUrlHandlerMapping.class
/*  56 */     .getName();
/*     */   
/*  58 */   private static final String SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME = SimpleControllerHandlerAdapter.class
/*  59 */     .getName();
/*     */   
/*  61 */   private static final String HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME = HttpRequestHandlerAdapter.class
/*  62 */     .getName();
/*     */   
/*     */   private static final String URL_PATH_HELPER_BEAN_NAME = "mvcUrlPathHelper";
/*     */   
/*     */   private static final String PATH_MATCHER_BEAN_NAME = "mvcPathMatcher";
/*     */   
/*     */   private static final String CORS_CONFIGURATION_BEAN_NAME = "mvcCorsConfigurations";
/*     */   
/*     */   private static final String HANDLER_MAPPING_INTROSPECTOR_BEAN_NAME = "mvcHandlerMappingIntrospector";
/*     */   
/*     */   public static void registerDefaultComponents(ParserContext context, @Nullable Object source)
/*     */   {
/*  74 */     registerBeanNameUrlHandlerMapping(context, source);
/*  75 */     registerHttpRequestHandlerAdapter(context, source);
/*  76 */     registerSimpleControllerHandlerAdapter(context, source);
/*  77 */     registerHandlerMappingIntrospector(context, source);
/*  78 */     registerLocaleResolver(context, source);
/*  79 */     registerThemeResolver(context, source);
/*  80 */     registerViewNameTranslator(context, source);
/*  81 */     registerFlashMapManager(context, source);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RuntimeBeanReference registerUrlPathHelper(@Nullable RuntimeBeanReference urlPathHelperRef, ParserContext context, @Nullable Object source)
/*     */   {
/*  92 */     if (urlPathHelperRef != null) {
/*  93 */       if (context.getRegistry().isAlias("mvcUrlPathHelper")) {
/*  94 */         context.getRegistry().removeAlias("mvcUrlPathHelper");
/*     */       }
/*  96 */       context.getRegistry().registerAlias(urlPathHelperRef.getBeanName(), "mvcUrlPathHelper");
/*     */     }
/*  98 */     else if ((!context.getRegistry().isAlias("mvcUrlPathHelper")) && 
/*  99 */       (!context.getRegistry().containsBeanDefinition("mvcUrlPathHelper"))) {
/* 100 */       RootBeanDefinition urlPathHelperDef = new RootBeanDefinition(UrlPathHelper.class);
/* 101 */       urlPathHelperDef.setSource(source);
/* 102 */       urlPathHelperDef.setRole(2);
/* 103 */       context.getRegistry().registerBeanDefinition("mvcUrlPathHelper", urlPathHelperDef);
/* 104 */       context.registerComponent(new BeanComponentDefinition(urlPathHelperDef, "mvcUrlPathHelper"));
/*     */     }
/* 106 */     return new RuntimeBeanReference("mvcUrlPathHelper");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RuntimeBeanReference registerPathMatcher(@Nullable RuntimeBeanReference pathMatcherRef, ParserContext context, @Nullable Object source)
/*     */   {
/* 117 */     if (pathMatcherRef != null) {
/* 118 */       if (context.getRegistry().isAlias("mvcPathMatcher")) {
/* 119 */         context.getRegistry().removeAlias("mvcPathMatcher");
/*     */       }
/* 121 */       context.getRegistry().registerAlias(pathMatcherRef.getBeanName(), "mvcPathMatcher");
/*     */     }
/* 123 */     else if ((!context.getRegistry().isAlias("mvcPathMatcher")) && 
/* 124 */       (!context.getRegistry().containsBeanDefinition("mvcPathMatcher"))) {
/* 125 */       RootBeanDefinition pathMatcherDef = new RootBeanDefinition(AntPathMatcher.class);
/* 126 */       pathMatcherDef.setSource(source);
/* 127 */       pathMatcherDef.setRole(2);
/* 128 */       context.getRegistry().registerBeanDefinition("mvcPathMatcher", pathMatcherDef);
/* 129 */       context.registerComponent(new BeanComponentDefinition(pathMatcherDef, "mvcPathMatcher"));
/*     */     }
/* 131 */     return new RuntimeBeanReference("mvcPathMatcher");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerBeanNameUrlHandlerMapping(ParserContext context, @Nullable Object source)
/*     */   {
/* 139 */     if (!context.getRegistry().containsBeanDefinition(BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME)) {
/* 140 */       RootBeanDefinition mappingDef = new RootBeanDefinition(BeanNameUrlHandlerMapping.class);
/* 141 */       mappingDef.setSource(source);
/* 142 */       mappingDef.setRole(2);
/* 143 */       mappingDef.getPropertyValues().add("order", Integer.valueOf(2));
/* 144 */       RuntimeBeanReference corsRef = registerCorsConfigurations(null, context, source);
/* 145 */       mappingDef.getPropertyValues().add("corsConfigurations", corsRef);
/* 146 */       context.getRegistry().registerBeanDefinition(BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME, mappingDef);
/* 147 */       context.registerComponent(new BeanComponentDefinition(mappingDef, BEAN_NAME_URL_HANDLER_MAPPING_BEAN_NAME));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerHttpRequestHandlerAdapter(ParserContext context, @Nullable Object source)
/*     */   {
/* 156 */     if (!context.getRegistry().containsBeanDefinition(HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME)) {
/* 157 */       RootBeanDefinition adapterDef = new RootBeanDefinition(HttpRequestHandlerAdapter.class);
/* 158 */       adapterDef.setSource(source);
/* 159 */       adapterDef.setRole(2);
/* 160 */       context.getRegistry().registerBeanDefinition(HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME, adapterDef);
/* 161 */       context.registerComponent(new BeanComponentDefinition(adapterDef, HTTP_REQUEST_HANDLER_ADAPTER_BEAN_NAME));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerSimpleControllerHandlerAdapter(ParserContext context, @Nullable Object source)
/*     */   {
/* 170 */     if (!context.getRegistry().containsBeanDefinition(SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME)) {
/* 171 */       RootBeanDefinition beanDef = new RootBeanDefinition(SimpleControllerHandlerAdapter.class);
/* 172 */       beanDef.setSource(source);
/* 173 */       beanDef.setRole(2);
/* 174 */       context.getRegistry().registerBeanDefinition(SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME, beanDef);
/* 175 */       context.registerComponent(new BeanComponentDefinition(beanDef, SIMPLE_CONTROLLER_HANDLER_ADAPTER_BEAN_NAME));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RuntimeBeanReference registerCorsConfigurations(@Nullable Map<String, CorsConfiguration> corsConfigurations, ParserContext context, @Nullable Object source)
/*     */   {
/* 189 */     if (!context.getRegistry().containsBeanDefinition("mvcCorsConfigurations")) {
/* 190 */       RootBeanDefinition corsDef = new RootBeanDefinition(LinkedHashMap.class);
/* 191 */       corsDef.setSource(source);
/* 192 */       corsDef.setRole(2);
/* 193 */       if (corsConfigurations != null) {
/* 194 */         corsDef.getConstructorArgumentValues().addIndexedArgumentValue(0, corsConfigurations);
/*     */       }
/* 196 */       context.getReaderContext().getRegistry().registerBeanDefinition("mvcCorsConfigurations", corsDef);
/* 197 */       context.registerComponent(new BeanComponentDefinition(corsDef, "mvcCorsConfigurations"));
/*     */     }
/* 199 */     else if (corsConfigurations != null) {
/* 200 */       BeanDefinition corsDef = context.getRegistry().getBeanDefinition("mvcCorsConfigurations");
/* 201 */       corsDef.getConstructorArgumentValues().addIndexedArgumentValue(0, corsConfigurations);
/*     */     }
/* 203 */     return new RuntimeBeanReference("mvcCorsConfigurations");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerHandlerMappingIntrospector(ParserContext context, @Nullable Object source)
/*     */   {
/* 211 */     if (!context.getRegistry().containsBeanDefinition("mvcHandlerMappingIntrospector")) {
/* 212 */       RootBeanDefinition beanDef = new RootBeanDefinition(HandlerMappingIntrospector.class);
/* 213 */       beanDef.setSource(source);
/* 214 */       beanDef.setRole(2);
/* 215 */       beanDef.setLazyInit(true);
/* 216 */       context.getRegistry().registerBeanDefinition("mvcHandlerMappingIntrospector", beanDef);
/* 217 */       context.registerComponent(new BeanComponentDefinition(beanDef, "mvcHandlerMappingIntrospector"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerLocaleResolver(ParserContext context, @Nullable Object source)
/*     */   {
/* 226 */     if (!containsBeanInHierarchy(context, "localeResolver")) {
/* 227 */       RootBeanDefinition beanDef = new RootBeanDefinition(AcceptHeaderLocaleResolver.class);
/* 228 */       beanDef.setSource(source);
/* 229 */       beanDef.setRole(2);
/* 230 */       context.getRegistry().registerBeanDefinition("localeResolver", beanDef);
/* 231 */       context.registerComponent(new BeanComponentDefinition(beanDef, "localeResolver"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerThemeResolver(ParserContext context, @Nullable Object source)
/*     */   {
/* 240 */     if (!containsBeanInHierarchy(context, "themeResolver")) {
/* 241 */       RootBeanDefinition beanDef = new RootBeanDefinition(FixedThemeResolver.class);
/* 242 */       beanDef.setSource(source);
/* 243 */       beanDef.setRole(2);
/* 244 */       context.getRegistry().registerBeanDefinition("themeResolver", beanDef);
/* 245 */       context.registerComponent(new BeanComponentDefinition(beanDef, "themeResolver"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerViewNameTranslator(ParserContext context, @Nullable Object source)
/*     */   {
/* 254 */     if (!containsBeanInHierarchy(context, "viewNameTranslator")) {
/* 255 */       RootBeanDefinition beanDef = new RootBeanDefinition(DefaultRequestToViewNameTranslator.class);
/* 256 */       beanDef.setSource(source);
/* 257 */       beanDef.setRole(2);
/* 258 */       context.getRegistry().registerBeanDefinition("viewNameTranslator", beanDef);
/*     */       
/* 260 */       context.registerComponent(new BeanComponentDefinition(beanDef, "viewNameTranslator"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerFlashMapManager(ParserContext context, @Nullable Object source)
/*     */   {
/* 270 */     if (!containsBeanInHierarchy(context, "flashMapManager")) {
/* 271 */       RootBeanDefinition beanDef = new RootBeanDefinition(SessionFlashMapManager.class);
/* 272 */       beanDef.setSource(source);
/* 273 */       beanDef.setRole(2);
/* 274 */       context.getRegistry().registerBeanDefinition("flashMapManager", beanDef);
/* 275 */       context.registerComponent(new BeanComponentDefinition(beanDef, "flashMapManager"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public static Object getContentNegotiationManager(ParserContext context)
/*     */   {
/* 286 */     String name = AnnotationDrivenBeanDefinitionParser.HANDLER_MAPPING_BEAN_NAME;
/* 287 */     if (context.getRegistry().containsBeanDefinition(name)) {
/* 288 */       BeanDefinition handlerMappingBeanDef = context.getRegistry().getBeanDefinition(name);
/* 289 */       return handlerMappingBeanDef.getPropertyValues().get("contentNegotiationManager");
/*     */     }
/* 291 */     name = "mvcContentNegotiationManager";
/* 292 */     if (context.getRegistry().containsBeanDefinition(name)) {
/* 293 */       return new RuntimeBeanReference(name);
/*     */     }
/* 295 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean containsBeanInHierarchy(ParserContext context, String beanName)
/*     */   {
/* 305 */     BeanDefinitionRegistry registry = context.getRegistry();
/* 306 */     return (registry instanceof BeanFactory) ? ((BeanFactory)registry).containsBean(beanName) : registry
/* 307 */       .containsBeanDefinition(beanName);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\MvcNamespaceUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */