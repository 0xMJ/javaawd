/*     */ package org.springframework.web.servlet.i18n;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.SimpleLocaleContext;
/*     */ import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.LocaleContextResolver;
/*     */ import org.springframework.web.util.CookieGenerator;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CookieLocaleResolver
/*     */   extends CookieGenerator
/*     */   implements LocaleContextResolver
/*     */ {
/*  68 */   public static final String LOCALE_REQUEST_ATTRIBUTE_NAME = CookieLocaleResolver.class.getName() + ".LOCALE";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   public static final String TIME_ZONE_REQUEST_ATTRIBUTE_NAME = CookieLocaleResolver.class.getName() + ".TIME_ZONE";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  84 */   public static final String DEFAULT_COOKIE_NAME = CookieLocaleResolver.class.getName() + ".LOCALE";
/*     */   
/*     */ 
/*  87 */   private boolean languageTagCompliant = true;
/*     */   
/*  89 */   private boolean rejectInvalidCookies = true;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private Locale defaultLocale;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private TimeZone defaultTimeZone;
/*     */   
/*     */ 
/*     */ 
/*     */   public CookieLocaleResolver()
/*     */   {
/* 103 */     setCookieName(DEFAULT_COOKIE_NAME);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLanguageTagCompliant(boolean languageTagCompliant)
/*     */   {
/* 121 */     this.languageTagCompliant = languageTagCompliant;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLanguageTagCompliant()
/*     */   {
/* 130 */     return this.languageTagCompliant;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRejectInvalidCookies(boolean rejectInvalidCookies)
/*     */   {
/* 144 */     this.rejectInvalidCookies = rejectInvalidCookies;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRejectInvalidCookies()
/*     */   {
/* 152 */     return this.rejectInvalidCookies;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDefaultLocale(@Nullable Locale defaultLocale)
/*     */   {
/* 159 */     this.defaultLocale = defaultLocale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Locale getDefaultLocale()
/*     */   {
/* 168 */     return this.defaultLocale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultTimeZone(@Nullable TimeZone defaultTimeZone)
/*     */   {
/* 176 */     this.defaultTimeZone = defaultTimeZone;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected TimeZone getDefaultTimeZone()
/*     */   {
/* 186 */     return this.defaultTimeZone;
/*     */   }
/*     */   
/*     */ 
/*     */   public Locale resolveLocale(HttpServletRequest request)
/*     */   {
/* 192 */     parseLocaleCookieIfNecessary(request);
/* 193 */     return (Locale)request.getAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME);
/*     */   }
/*     */   
/*     */   public LocaleContext resolveLocaleContext(final HttpServletRequest request)
/*     */   {
/* 198 */     parseLocaleCookieIfNecessary(request);
/* 199 */     new TimeZoneAwareLocaleContext()
/*     */     {
/*     */       @Nullable
/*     */       public Locale getLocale() {
/* 203 */         return (Locale)request.getAttribute(CookieLocaleResolver.LOCALE_REQUEST_ATTRIBUTE_NAME);
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       public TimeZone getTimeZone() {
/* 208 */         return (TimeZone)request.getAttribute(CookieLocaleResolver.TIME_ZONE_REQUEST_ATTRIBUTE_NAME);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private void parseLocaleCookieIfNecessary(HttpServletRequest request) {
/* 214 */     if (request.getAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME) == null) {
/* 215 */       Locale locale = null;
/* 216 */       TimeZone timeZone = null;
/*     */       
/*     */ 
/* 219 */       String cookieName = getCookieName();
/* 220 */       if (cookieName != null) {
/* 221 */         Cookie cookie = WebUtils.getCookie(request, cookieName);
/* 222 */         if (cookie != null) {
/* 223 */           String value = cookie.getValue();
/* 224 */           String localePart = value;
/* 225 */           String timeZonePart = null;
/* 226 */           int separatorIndex = localePart.indexOf('/');
/* 227 */           if (separatorIndex == -1)
/*     */           {
/* 229 */             separatorIndex = localePart.indexOf(' ');
/*     */           }
/* 231 */           if (separatorIndex >= 0) {
/* 232 */             localePart = value.substring(0, separatorIndex);
/* 233 */             timeZonePart = value.substring(separatorIndex + 1);
/*     */           }
/*     */           try {
/* 236 */             locale = !"-".equals(localePart) ? parseLocaleValue(localePart) : null;
/* 237 */             if (timeZonePart != null) {
/* 238 */               timeZone = StringUtils.parseTimeZoneString(timeZonePart);
/*     */             }
/*     */           }
/*     */           catch (IllegalArgumentException ex) {
/* 242 */             if ((isRejectInvalidCookies()) && 
/* 243 */               (request.getAttribute("javax.servlet.error.exception") == null))
/*     */             {
/* 245 */               throw new IllegalStateException("Encountered invalid locale cookie '" + cookieName + "': [" + value + "] due to: " + ex.getMessage());
/*     */             }
/*     */             
/*     */ 
/* 249 */             if (this.logger.isDebugEnabled()) {
/* 250 */               this.logger.debug("Ignoring invalid locale cookie '" + cookieName + "': [" + value + "] due to: " + ex
/* 251 */                 .getMessage());
/*     */             }
/*     */           }
/*     */           
/* 255 */           if (this.logger.isTraceEnabled()) {
/* 256 */             this.logger.trace("Parsed cookie value [" + cookie.getValue() + "] into locale '" + locale + "'" + (timeZone != null ? " and time zone '" + timeZone
/* 257 */               .getID() + "'" : ""));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 262 */       request.setAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME, locale != null ? locale : 
/* 263 */         determineDefaultLocale(request));
/* 264 */       request.setAttribute(TIME_ZONE_REQUEST_ATTRIBUTE_NAME, timeZone != null ? timeZone : 
/* 265 */         determineDefaultTimeZone(request));
/*     */     }
/*     */   }
/*     */   
/*     */   public void setLocale(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable Locale locale)
/*     */   {
/* 271 */     setLocaleContext(request, response, locale != null ? new SimpleLocaleContext(locale) : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLocaleContext(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable LocaleContext localeContext)
/*     */   {
/* 278 */     Assert.notNull(response, "HttpServletResponse is required for CookieLocaleResolver");
/*     */     
/* 280 */     Locale locale = null;
/* 281 */     TimeZone timeZone = null;
/* 282 */     if (localeContext != null) {
/* 283 */       locale = localeContext.getLocale();
/* 284 */       if ((localeContext instanceof TimeZoneAwareLocaleContext)) {
/* 285 */         timeZone = ((TimeZoneAwareLocaleContext)localeContext).getTimeZone();
/*     */       }
/* 287 */       addCookie(response, (locale != null ? 
/* 288 */         toLocaleValue(locale) : "-") + (timeZone != null ? '/' + timeZone.getID() : ""));
/*     */     }
/*     */     else {
/* 291 */       removeCookie(response);
/*     */     }
/* 293 */     request.setAttribute(LOCALE_REQUEST_ATTRIBUTE_NAME, locale != null ? locale : 
/* 294 */       determineDefaultLocale(request));
/* 295 */     request.setAttribute(TIME_ZONE_REQUEST_ATTRIBUTE_NAME, timeZone != null ? timeZone : 
/* 296 */       determineDefaultTimeZone(request));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Locale parseLocaleValue(String localeValue)
/*     */   {
/* 311 */     return StringUtils.parseLocale(localeValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String toLocaleValue(Locale locale)
/*     */   {
/* 325 */     return isLanguageTagCompliant() ? locale.toLanguageTag() : locale.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Locale determineDefaultLocale(HttpServletRequest request)
/*     */   {
/* 339 */     Locale defaultLocale = getDefaultLocale();
/* 340 */     if (defaultLocale == null) {
/* 341 */       defaultLocale = request.getLocale();
/*     */     }
/* 343 */     return defaultLocale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected TimeZone determineDefaultTimeZone(HttpServletRequest request)
/*     */   {
/* 357 */     return getDefaultTimeZone();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\i18n\CookieLocaleResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */