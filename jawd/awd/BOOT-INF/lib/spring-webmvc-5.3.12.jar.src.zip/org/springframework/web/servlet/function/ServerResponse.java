/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface ServerResponse
/*     */ {
/*     */   public abstract HttpStatus statusCode();
/*     */   
/*     */   public abstract int rawStatusCode();
/*     */   
/*     */   public abstract HttpHeaders headers();
/*     */   
/*     */   public abstract MultiValueMap<String, Cookie> cookies();
/*     */   
/*     */   @Nullable
/*     */   public abstract ModelAndView writeTo(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Context paramContext)
/*     */     throws ServletException, IOException;
/*     */   
/*     */   public static BodyBuilder from(ServerResponse other)
/*     */   {
/* 108 */     return new DefaultServerResponseBuilder(other);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder status(HttpStatus status)
/*     */   {
/* 117 */     return new DefaultServerResponseBuilder(status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder status(int status)
/*     */   {
/* 126 */     return new DefaultServerResponseBuilder(status);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder ok()
/*     */   {
/* 134 */     return status(HttpStatus.OK);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder created(URI location)
/*     */   {
/* 144 */     BodyBuilder builder = status(HttpStatus.CREATED);
/* 145 */     return (BodyBuilder)builder.location(location);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder accepted()
/*     */   {
/* 153 */     return status(HttpStatus.ACCEPTED);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HeadersBuilder<?> noContent()
/*     */   {
/* 161 */     return status(HttpStatus.NO_CONTENT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder seeOther(URI location)
/*     */   {
/* 171 */     BodyBuilder builder = status(HttpStatus.SEE_OTHER);
/* 172 */     return (BodyBuilder)builder.location(location);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder temporaryRedirect(URI location)
/*     */   {
/* 182 */     BodyBuilder builder = status(HttpStatus.TEMPORARY_REDIRECT);
/* 183 */     return (BodyBuilder)builder.location(location);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder permanentRedirect(URI location)
/*     */   {
/* 193 */     BodyBuilder builder = status(HttpStatus.PERMANENT_REDIRECT);
/* 194 */     return (BodyBuilder)builder.location(location);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder badRequest()
/*     */   {
/* 202 */     return status(HttpStatus.BAD_REQUEST);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HeadersBuilder<?> notFound()
/*     */   {
/* 210 */     return status(HttpStatus.NOT_FOUND);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BodyBuilder unprocessableEntity()
/*     */   {
/* 219 */     return status(HttpStatus.UNPROCESSABLE_ENTITY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServerResponse async(Object asyncResponse)
/*     */   {
/* 239 */     return DefaultAsyncServerResponse.create(asyncResponse, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServerResponse async(Object asyncResponse, Duration timeout)
/*     */   {
/* 260 */     return DefaultAsyncServerResponse.create(asyncResponse, timeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServerResponse sse(Consumer<SseBuilder> consumer)
/*     */   {
/* 289 */     return SseServerResponse.create(consumer, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ServerResponse sse(Consumer<SseBuilder> consumer, Duration timeout)
/*     */   {
/* 319 */     return SseServerResponse.create(consumer, timeout);
/*     */   }
/*     */   
/*     */   public static abstract interface Context
/*     */   {
/*     */     public abstract List<HttpMessageConverter<?>> messageConverters();
/*     */   }
/*     */   
/*     */   public static abstract interface SseBuilder
/*     */   {
/*     */     public abstract void send(Object paramObject)
/*     */       throws IOException;
/*     */     
/*     */     public abstract SseBuilder id(String paramString);
/*     */     
/*     */     public abstract SseBuilder event(String paramString);
/*     */     
/*     */     public abstract SseBuilder retry(Duration paramDuration);
/*     */     
/*     */     public abstract SseBuilder comment(String paramString);
/*     */     
/*     */     public abstract void data(Object paramObject)
/*     */       throws IOException;
/*     */     
/*     */     public abstract void error(Throwable paramThrowable);
/*     */     
/*     */     public abstract void complete();
/*     */     
/*     */     public abstract SseBuilder onTimeout(Runnable paramRunnable);
/*     */     
/*     */     public abstract SseBuilder onError(Consumer<Throwable> paramConsumer);
/*     */     
/*     */     public abstract SseBuilder onComplete(Runnable paramRunnable);
/*     */   }
/*     */   
/*     */   public static abstract interface BodyBuilder
/*     */     extends ServerResponse.HeadersBuilder<BodyBuilder>
/*     */   {
/*     */     public abstract BodyBuilder contentLength(long paramLong);
/*     */     
/*     */     public abstract BodyBuilder contentType(MediaType paramMediaType);
/*     */     
/*     */     public abstract ServerResponse body(Object paramObject);
/*     */     
/*     */     public abstract <T> ServerResponse body(T paramT, ParameterizedTypeReference<T> paramParameterizedTypeReference);
/*     */     
/*     */     public abstract ServerResponse render(String paramString, Object... paramVarArgs);
/*     */     
/*     */     public abstract ServerResponse render(String paramString, Map<String, ?> paramMap);
/*     */   }
/*     */   
/*     */   public static abstract interface HeadersBuilder<B extends HeadersBuilder<B>>
/*     */   {
/*     */     public abstract B header(String paramString, String... paramVarArgs);
/*     */     
/*     */     public abstract B headers(Consumer<HttpHeaders> paramConsumer);
/*     */     
/*     */     public abstract B cookie(Cookie paramCookie);
/*     */     
/*     */     public abstract B cookies(Consumer<MultiValueMap<String, Cookie>> paramConsumer);
/*     */     
/*     */     public abstract B allow(HttpMethod... paramVarArgs);
/*     */     
/*     */     public abstract B allow(Set<HttpMethod> paramSet);
/*     */     
/*     */     public abstract B eTag(String paramString);
/*     */     
/*     */     public abstract B lastModified(ZonedDateTime paramZonedDateTime);
/*     */     
/*     */     public abstract B lastModified(Instant paramInstant);
/*     */     
/*     */     public abstract B location(URI paramURI);
/*     */     
/*     */     public abstract B cacheControl(CacheControl paramCacheControl);
/*     */     
/*     */     public abstract B varyBy(String... paramVarArgs);
/*     */     
/*     */     public abstract ServerResponse build();
/*     */     
/*     */     public abstract ServerResponse build(BiFunction<HttpServletRequest, HttpServletResponse, ModelAndView> paramBiFunction);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\ServerResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */