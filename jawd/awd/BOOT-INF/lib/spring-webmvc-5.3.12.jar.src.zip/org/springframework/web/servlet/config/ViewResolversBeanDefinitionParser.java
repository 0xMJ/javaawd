/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.springframework.web.servlet.view.BeanNameViewResolver;
/*     */ import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
/*     */ import org.springframework.web.servlet.view.InternalResourceViewResolver;
/*     */ import org.springframework.web.servlet.view.ViewResolverComposite;
/*     */ import org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver;
/*     */ import org.springframework.web.servlet.view.groovy.GroovyMarkupViewResolver;
/*     */ import org.springframework.web.servlet.view.script.ScriptTemplateViewResolver;
/*     */ import org.springframework.web.servlet.view.tiles3.TilesViewResolver;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewResolversBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   public static final String VIEW_RESOLVER_BEAN_NAME = "mvcViewResolver";
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext context)
/*     */   {
/*  74 */     Object source = context.extractSource(element);
/*  75 */     context.pushContainingComponent(new CompositeComponentDefinition(element.getTagName(), source));
/*     */     
/*  77 */     ManagedList<Object> resolvers = new ManagedList(4);
/*  78 */     resolvers.setSource(context.extractSource(element));
/*  79 */     String[] names = { "jsp", "tiles", "bean-name", "freemarker", "groovy", "script-template", "bean", "ref" };
/*     */     
/*     */ 
/*  82 */     for (Element resolverElement : DomUtils.getChildElementsByTagName(element, names)) {
/*  83 */       String name = resolverElement.getLocalName();
/*  84 */       if (("bean".equals(name)) || ("ref".equals(name))) {
/*  85 */         resolvers.add(context.getDelegate().parsePropertySubElement(resolverElement, null));
/*     */       }
/*     */       else
/*     */       {
/*  89 */         if ("jsp".equals(name)) {
/*  90 */           RootBeanDefinition resolverBeanDef = new RootBeanDefinition(InternalResourceViewResolver.class);
/*  91 */           resolverBeanDef.getPropertyValues().add("prefix", "/WEB-INF/");
/*  92 */           resolverBeanDef.getPropertyValues().add("suffix", ".jsp");
/*  93 */           addUrlBasedViewResolverProperties(resolverElement, resolverBeanDef);
/*     */         }
/*  95 */         else if ("tiles".equals(name)) {
/*  96 */           RootBeanDefinition resolverBeanDef = new RootBeanDefinition(TilesViewResolver.class);
/*  97 */           addUrlBasedViewResolverProperties(resolverElement, resolverBeanDef);
/*     */         }
/*  99 */         else if ("freemarker".equals(name)) {
/* 100 */           RootBeanDefinition resolverBeanDef = new RootBeanDefinition(FreeMarkerViewResolver.class);
/* 101 */           resolverBeanDef.getPropertyValues().add("suffix", ".ftl");
/* 102 */           addUrlBasedViewResolverProperties(resolverElement, resolverBeanDef);
/*     */         }
/* 104 */         else if ("groovy".equals(name)) {
/* 105 */           RootBeanDefinition resolverBeanDef = new RootBeanDefinition(GroovyMarkupViewResolver.class);
/* 106 */           resolverBeanDef.getPropertyValues().add("suffix", ".tpl");
/* 107 */           addUrlBasedViewResolverProperties(resolverElement, resolverBeanDef);
/*     */         }
/* 109 */         else if ("script-template".equals(name)) {
/* 110 */           RootBeanDefinition resolverBeanDef = new RootBeanDefinition(ScriptTemplateViewResolver.class);
/* 111 */           addUrlBasedViewResolverProperties(resolverElement, resolverBeanDef);
/*     */         } else { RootBeanDefinition resolverBeanDef;
/* 113 */           if ("bean-name".equals(name)) {
/* 114 */             resolverBeanDef = new RootBeanDefinition(BeanNameViewResolver.class);
/*     */           }
/*     */           else
/*     */           {
/* 118 */             throw new IllegalStateException("Unexpected element name: " + name); } }
/*     */         RootBeanDefinition resolverBeanDef;
/* 120 */         resolverBeanDef.setSource(source);
/* 121 */         resolverBeanDef.setRole(2);
/* 122 */         resolvers.add(resolverBeanDef);
/*     */       }
/*     */     }
/* 125 */     String beanName = "mvcViewResolver";
/* 126 */     RootBeanDefinition compositeResolverBeanDef = new RootBeanDefinition(ViewResolverComposite.class);
/* 127 */     compositeResolverBeanDef.setSource(source);
/* 128 */     compositeResolverBeanDef.setRole(2);
/*     */     
/* 130 */     names = new String[] { "content-negotiation" };
/* 131 */     List<Element> contentNegotiationElements = DomUtils.getChildElementsByTagName(element, names);
/* 132 */     if (contentNegotiationElements.isEmpty()) {
/* 133 */       compositeResolverBeanDef.getPropertyValues().add("viewResolvers", resolvers);
/*     */     }
/* 135 */     else if (contentNegotiationElements.size() == 1) {
/* 136 */       BeanDefinition beanDef = createContentNegotiatingViewResolver((Element)contentNegotiationElements.get(0), context);
/* 137 */       beanDef.getPropertyValues().add("viewResolvers", resolvers);
/* 138 */       ManagedList<Object> list = new ManagedList(1);
/* 139 */       list.add(beanDef);
/* 140 */       compositeResolverBeanDef.getPropertyValues().add("order", Integer.valueOf(Integer.MIN_VALUE));
/* 141 */       compositeResolverBeanDef.getPropertyValues().add("viewResolvers", list);
/*     */     }
/*     */     else {
/* 144 */       throw new IllegalArgumentException("Only one <content-negotiation> element is allowed.");
/*     */     }
/*     */     
/* 147 */     if (element.hasAttribute("order")) {
/* 148 */       compositeResolverBeanDef.getPropertyValues().add("order", element.getAttribute("order"));
/*     */     }
/*     */     
/* 151 */     context.getReaderContext().getRegistry().registerBeanDefinition(beanName, compositeResolverBeanDef);
/* 152 */     context.registerComponent(new BeanComponentDefinition(compositeResolverBeanDef, beanName));
/* 153 */     context.popAndRegisterContainingComponent();
/* 154 */     return null;
/*     */   }
/*     */   
/*     */   private void addUrlBasedViewResolverProperties(Element element, RootBeanDefinition beanDefinition) {
/* 158 */     if (element.hasAttribute("prefix")) {
/* 159 */       beanDefinition.getPropertyValues().add("prefix", element.getAttribute("prefix"));
/*     */     }
/* 161 */     if (element.hasAttribute("suffix")) {
/* 162 */       beanDefinition.getPropertyValues().add("suffix", element.getAttribute("suffix"));
/*     */     }
/* 164 */     if (element.hasAttribute("cache-views")) {
/* 165 */       beanDefinition.getPropertyValues().add("cache", element.getAttribute("cache-views"));
/*     */     }
/* 167 */     if (element.hasAttribute("view-class")) {
/* 168 */       beanDefinition.getPropertyValues().add("viewClass", element.getAttribute("view-class"));
/*     */     }
/* 170 */     if (element.hasAttribute("view-names")) {
/* 171 */       beanDefinition.getPropertyValues().add("viewNames", element.getAttribute("view-names"));
/*     */     }
/*     */   }
/*     */   
/*     */   private BeanDefinition createContentNegotiatingViewResolver(Element resolverElement, ParserContext context) {
/* 176 */     RootBeanDefinition beanDef = new RootBeanDefinition(ContentNegotiatingViewResolver.class);
/* 177 */     beanDef.setSource(context.extractSource(resolverElement));
/* 178 */     beanDef.setRole(2);
/* 179 */     MutablePropertyValues values = beanDef.getPropertyValues();
/*     */     
/* 181 */     List<Element> elements = DomUtils.getChildElementsByTagName(resolverElement, "default-views");
/* 182 */     if (!elements.isEmpty()) {
/* 183 */       ManagedList<Object> list = new ManagedList();
/* 184 */       for (Element element : DomUtils.getChildElementsByTagName((Element)elements.get(0), new String[] { "bean", "ref" })) {
/* 185 */         list.add(context.getDelegate().parsePropertySubElement(element, null));
/*     */       }
/* 187 */       values.add("defaultViews", list);
/*     */     }
/* 189 */     if (resolverElement.hasAttribute("use-not-acceptable")) {
/* 190 */       values.add("useNotAcceptableStatusCode", resolverElement.getAttribute("use-not-acceptable"));
/*     */     }
/* 192 */     Object manager = MvcNamespaceUtils.getContentNegotiationManager(context);
/* 193 */     if (manager != null) {
/* 194 */       values.add("contentNegotiationManager", manager);
/*     */     }
/* 196 */     return beanDef;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\ViewResolversBeanDefinitionParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */