package org.springframework.web.servlet.function;

import kotlin.Metadata;
import org.springframework.core.ParameterizedTypeReference;

@Metadata(mv={1, 1, 18}, bv={1, 0, 3}, k=2, d1={"\000\024\n\000\n\002\030\002\n\000\n\002\020\000\n\002\030\002\n\002\b\003\032&\020\000\032\0020\001\"\n\b\000\020\002\030\001*\0020\003*\0020\0042\006\020\005\032\002H\002H\b¢\006\002\020\006¨\006\007"}, d2={"bodyWithType", "Lorg/springframework/web/servlet/function/ServerResponse;", "T", "", "Lorg/springframework/web/servlet/function/ServerResponse$BodyBuilder;", "body", "(Lorg/springframework/web/servlet/function/ServerResponse$BodyBuilder;Ljava/lang/Object;)Lorg/springframework/web/servlet/function/ServerResponse;", "spring-webmvc"})
public final class ServerResponseExtensionsKt {}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\ServerResponseExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */