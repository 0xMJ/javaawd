/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PatternsRequestCondition
/*     */   extends AbstractRequestCondition<PatternsRequestCondition>
/*     */ {
/*  52 */   private static final Set<String> EMPTY_PATH_PATTERN = Collections.singleton("");
/*     */   
/*     */ 
/*     */   private final Set<String> patterns;
/*     */   
/*     */   private final PathMatcher pathMatcher;
/*     */   
/*     */   private final boolean useSuffixPatternMatch;
/*     */   
/*     */   private final boolean useTrailingSlashMatch;
/*     */   
/*  63 */   private final List<String> fileExtensions = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PatternsRequestCondition(String... patterns)
/*     */   {
/*  72 */     this(patterns, true, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PatternsRequestCondition(String[] patterns, boolean useTrailingSlashMatch, @Nullable PathMatcher pathMatcher)
/*     */   {
/*  83 */     this(patterns, null, pathMatcher, useTrailingSlashMatch);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public PatternsRequestCondition(String[] patterns, @Nullable UrlPathHelper urlPathHelper, @Nullable PathMatcher pathMatcher, boolean useTrailingSlashMatch)
/*     */   {
/* 101 */     this(patterns, urlPathHelper, pathMatcher, false, useTrailingSlashMatch);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public PatternsRequestCondition(String[] patterns, @Nullable UrlPathHelper urlPathHelper, @Nullable PathMatcher pathMatcher, boolean useSuffixPatternMatch, boolean useTrailingSlashMatch)
/*     */   {
/* 119 */     this(patterns, urlPathHelper, pathMatcher, useSuffixPatternMatch, useTrailingSlashMatch, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public PatternsRequestCondition(String[] patterns, @Nullable UrlPathHelper urlPathHelper, @Nullable PathMatcher pathMatcher, boolean useSuffixPatternMatch, boolean useTrailingSlashMatch, @Nullable List<String> fileExtensions)
/*     */   {
/* 138 */     this.patterns = initPatterns(patterns);
/* 139 */     this.pathMatcher = (pathMatcher != null ? pathMatcher : new AntPathMatcher());
/* 140 */     this.useSuffixPatternMatch = useSuffixPatternMatch;
/* 141 */     this.useTrailingSlashMatch = useTrailingSlashMatch;
/*     */     
/* 143 */     if (fileExtensions != null) {
/* 144 */       for (String fileExtension : fileExtensions) {
/* 145 */         if (fileExtension.charAt(0) != '.') {
/* 146 */           fileExtension = "." + fileExtension;
/*     */         }
/* 148 */         this.fileExtensions.add(fileExtension);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static Set<String> initPatterns(String[] patterns) {
/* 154 */     if (!hasPattern(patterns)) {
/* 155 */       return EMPTY_PATH_PATTERN;
/*     */     }
/* 157 */     Set<String> result = new LinkedHashSet(patterns.length);
/* 158 */     for (String pattern : patterns) {
/* 159 */       if ((StringUtils.hasLength(pattern)) && (!pattern.startsWith("/"))) {
/* 160 */         pattern = "/" + pattern;
/*     */       }
/* 162 */       result.add(pattern);
/*     */     }
/* 164 */     return result;
/*     */   }
/*     */   
/*     */   private static boolean hasPattern(String[] patterns) {
/* 168 */     if (!ObjectUtils.isEmpty(patterns)) {
/* 169 */       for (String pattern : patterns) {
/* 170 */         if (StringUtils.hasText(pattern)) {
/* 171 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 175 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private PatternsRequestCondition(Set<String> patterns, PatternsRequestCondition other)
/*     */   {
/* 182 */     this.patterns = patterns;
/* 183 */     this.pathMatcher = other.pathMatcher;
/* 184 */     this.useSuffixPatternMatch = other.useSuffixPatternMatch;
/* 185 */     this.useTrailingSlashMatch = other.useTrailingSlashMatch;
/* 186 */     this.fileExtensions.addAll(other.fileExtensions);
/*     */   }
/*     */   
/*     */   public Set<String> getPatterns()
/*     */   {
/* 191 */     return this.patterns;
/*     */   }
/*     */   
/*     */   protected Collection<String> getContent()
/*     */   {
/* 196 */     return this.patterns;
/*     */   }
/*     */   
/*     */   protected String getToStringInfix()
/*     */   {
/* 201 */     return " || ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEmptyPathMapping()
/*     */   {
/* 208 */     return this.patterns == EMPTY_PATH_PATTERN;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> getDirectPaths()
/*     */   {
/* 216 */     if (isEmptyPathMapping()) {
/* 217 */       return EMPTY_PATH_PATTERN;
/*     */     }
/* 219 */     Set<String> result = Collections.emptySet();
/* 220 */     for (String pattern : this.patterns) {
/* 221 */       if (!this.pathMatcher.isPattern(pattern)) {
/* 222 */         result = result.isEmpty() ? new HashSet(1) : result;
/* 223 */         result.add(pattern);
/*     */       }
/*     */     }
/* 226 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PatternsRequestCondition combine(PatternsRequestCondition other)
/*     */   {
/* 241 */     if ((isEmptyPathMapping()) && (other.isEmptyPathMapping())) {
/* 242 */       return this;
/*     */     }
/* 244 */     if (other.isEmptyPathMapping()) {
/* 245 */       return this;
/*     */     }
/* 247 */     if (isEmptyPathMapping()) {
/* 248 */       return other;
/*     */     }
/* 250 */     Set<String> result = new LinkedHashSet();
/* 251 */     Iterator localIterator1; if ((!this.patterns.isEmpty()) && (!other.patterns.isEmpty())) {
/* 252 */       for (localIterator1 = this.patterns.iterator(); localIterator1.hasNext();) { pattern1 = (String)localIterator1.next();
/* 253 */         for (String pattern2 : other.patterns)
/* 254 */           result.add(this.pathMatcher.combine(pattern1, pattern2));
/*     */       }
/*     */     }
/*     */     String pattern1;
/* 258 */     return new PatternsRequestCondition(result, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public PatternsRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 280 */     String lookupPath = UrlPathHelper.getResolvedLookupPath(request);
/* 281 */     List<String> matches = getMatchingPatterns(lookupPath);
/* 282 */     return !matches.isEmpty() ? new PatternsRequestCondition(new LinkedHashSet(matches), this) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getMatchingPatterns(String lookupPath)
/*     */   {
/* 294 */     List<String> matches = null;
/* 295 */     for (String pattern : this.patterns) {
/* 296 */       String match = getMatchingPattern(pattern, lookupPath);
/* 297 */       if (match != null) {
/* 298 */         matches = matches != null ? matches : new ArrayList();
/* 299 */         matches.add(match);
/*     */       }
/*     */     }
/* 302 */     if (matches == null) {
/* 303 */       return Collections.emptyList();
/*     */     }
/* 305 */     if (matches.size() > 1) {
/* 306 */       matches.sort(this.pathMatcher.getPatternComparator(lookupPath));
/*     */     }
/* 308 */     return matches;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private String getMatchingPattern(String pattern, String lookupPath) {
/* 313 */     if (pattern.equals(lookupPath)) {
/* 314 */       return pattern;
/*     */     }
/* 316 */     if (this.useSuffixPatternMatch) {
/* 317 */       if ((!this.fileExtensions.isEmpty()) && (lookupPath.indexOf('.') != -1)) {
/* 318 */         for (String extension : this.fileExtensions) {
/* 319 */           if (this.pathMatcher.match(pattern + extension, lookupPath)) {
/* 320 */             return pattern + extension;
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 325 */         boolean hasSuffix = pattern.indexOf('.') != -1;
/* 326 */         if ((!hasSuffix) && (this.pathMatcher.match(pattern + ".*", lookupPath))) {
/* 327 */           return pattern + ".*";
/*     */         }
/*     */       }
/*     */     }
/* 331 */     if (this.pathMatcher.match(pattern, lookupPath)) {
/* 332 */       return pattern;
/*     */     }
/* 334 */     if ((this.useTrailingSlashMatch) && 
/* 335 */       (!pattern.endsWith("/")) && (this.pathMatcher.match(pattern + "/", lookupPath))) {
/* 336 */       return pattern + "/";
/*     */     }
/*     */     
/* 339 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(PatternsRequestCondition other, HttpServletRequest request)
/*     */   {
/* 355 */     String lookupPath = UrlPathHelper.getResolvedLookupPath(request);
/* 356 */     Comparator<String> patternComparator = this.pathMatcher.getPatternComparator(lookupPath);
/* 357 */     Iterator<String> iterator = this.patterns.iterator();
/* 358 */     Iterator<String> iteratorOther = other.patterns.iterator();
/* 359 */     while ((iterator.hasNext()) && (iteratorOther.hasNext())) {
/* 360 */       int result = patternComparator.compare(iterator.next(), iteratorOther.next());
/* 361 */       if (result != 0) {
/* 362 */         return result;
/*     */       }
/*     */     }
/* 365 */     if (iterator.hasNext()) {
/* 366 */       return -1;
/*     */     }
/* 368 */     if (iteratorOther.hasNext()) {
/* 369 */       return 1;
/*     */     }
/*     */     
/* 372 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\condition\PatternsRequestCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */