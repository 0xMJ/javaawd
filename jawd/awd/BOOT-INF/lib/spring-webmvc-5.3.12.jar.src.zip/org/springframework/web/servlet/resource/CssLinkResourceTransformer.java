/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CssLinkResourceTransformer
/*     */   extends ResourceTransformerSupport
/*     */ {
/*  54 */   private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;
/*     */   
/*  56 */   private static final Log logger = LogFactory.getLog(CssLinkResourceTransformer.class);
/*     */   
/*  58 */   private final List<LinkParser> linkParsers = new ArrayList(2);
/*     */   
/*     */   public CssLinkResourceTransformer()
/*     */   {
/*  62 */     this.linkParsers.add(new ImportStatementLinkParser(null));
/*  63 */     this.linkParsers.add(new UrlFunctionLinkParser(null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource transform(HttpServletRequest request, Resource resource, ResourceTransformerChain transformerChain)
/*     */     throws IOException
/*     */   {
/*  72 */     resource = transformerChain.transform(request, resource);
/*     */     
/*  74 */     String filename = resource.getFilename();
/*  75 */     if ((!"css".equals(StringUtils.getFilenameExtension(filename))) || ((resource instanceof EncodedResourceResolver.EncodedResource)) || ((resource instanceof GzipResourceResolver.GzippedResource)))
/*     */     {
/*     */ 
/*  78 */       return resource;
/*     */     }
/*     */     
/*  81 */     byte[] bytes = FileCopyUtils.copyToByteArray(resource.getInputStream());
/*  82 */     String content = new String(bytes, DEFAULT_CHARSET);
/*     */     
/*  84 */     SortedSet<ContentChunkInfo> links = new TreeSet();
/*  85 */     for (LinkParser parser : this.linkParsers) {
/*  86 */       parser.parse(content, links);
/*     */     }
/*     */     
/*  89 */     if (links.isEmpty()) {
/*  90 */       return resource;
/*     */     }
/*     */     
/*  93 */     int index = 0;
/*  94 */     StringWriter writer = new StringWriter();
/*  95 */     for (ContentChunkInfo linkContentChunkInfo : links) {
/*  96 */       writer.write(content.substring(index, linkContentChunkInfo.getStart()));
/*  97 */       String link = content.substring(linkContentChunkInfo.getStart(), linkContentChunkInfo.getEnd());
/*  98 */       String newLink = null;
/*  99 */       if (!hasScheme(link)) {
/* 100 */         String absolutePath = toAbsolutePath(link, request);
/* 101 */         newLink = resolveUrlPath(absolutePath, request, resource, transformerChain);
/*     */       }
/* 103 */       writer.write(newLink != null ? newLink : link);
/* 104 */       index = linkContentChunkInfo.getEnd();
/*     */     }
/* 106 */     writer.write(content.substring(index));
/*     */     
/* 108 */     return new TransformedResource(resource, writer.toString().getBytes(DEFAULT_CHARSET));
/*     */   }
/*     */   
/*     */   private boolean hasScheme(String link) {
/* 112 */     int schemeIndex = link.indexOf(':');
/* 113 */     return ((schemeIndex > 0) && (!link.substring(0, schemeIndex).contains("/"))) || (link.indexOf("//") == 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @FunctionalInterface
/*     */   protected static abstract interface LinkParser
/*     */   {
/*     */     public abstract void parse(String paramString, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> paramSortedSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static abstract class AbstractLinkParser
/*     */     implements CssLinkResourceTransformer.LinkParser
/*     */   {
/*     */     protected abstract String getKeyword();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void parse(String content, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> result)
/*     */     {
/* 138 */       int position = 0;
/*     */       for (;;) {
/* 140 */         position = content.indexOf(getKeyword(), position);
/* 141 */         if (position == -1) {
/* 142 */           return;
/*     */         }
/* 144 */         position += getKeyword().length();
/* 145 */         while (Character.isWhitespace(content.charAt(position))) {
/* 146 */           position++;
/*     */         }
/* 148 */         if (content.charAt(position) == '\'') {
/* 149 */           position = extractLink(position, "'", content, result);
/*     */         }
/* 151 */         else if (content.charAt(position) == '"') {
/* 152 */           position = extractLink(position, "\"", content, result);
/*     */         }
/*     */         else {
/* 155 */           position = extractLink(position, content, result);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     protected int extractLink(int index, String endKey, String content, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> linksToAdd) {
/* 161 */       int start = index + 1;
/* 162 */       int end = content.indexOf(endKey, start);
/* 163 */       linksToAdd.add(new CssLinkResourceTransformer.ContentChunkInfo(start, end));
/* 164 */       return end + endKey.length();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected abstract int extractLink(int paramInt, String paramString, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> paramSortedSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class ImportStatementLinkParser
/*     */     extends CssLinkResourceTransformer.AbstractLinkParser
/*     */   {
/*     */     protected String getKeyword()
/*     */     {
/* 179 */       return "@import";
/*     */     }
/*     */     
/*     */     protected int extractLink(int index, String content, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> linksToAdd)
/*     */     {
/* 184 */       if (!content.startsWith("url(", index))
/*     */       {
/*     */ 
/* 187 */         if (CssLinkResourceTransformer.logger.isTraceEnabled())
/* 188 */           CssLinkResourceTransformer.logger.trace("Unexpected syntax for @import link at index " + index);
/*     */       }
/* 190 */       return index;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class UrlFunctionLinkParser
/*     */     extends CssLinkResourceTransformer.AbstractLinkParser
/*     */   {
/*     */     protected String getKeyword()
/*     */     {
/* 199 */       return "url(";
/*     */     }
/*     */     
/*     */ 
/*     */     protected int extractLink(int index, String content, SortedSet<CssLinkResourceTransformer.ContentChunkInfo> linksToAdd)
/*     */     {
/* 205 */       return extractLink(index - 1, ")", content, linksToAdd);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ContentChunkInfo
/*     */     implements Comparable<ContentChunkInfo>
/*     */   {
/*     */     private final int start;
/*     */     private final int end;
/*     */     
/*     */     ContentChunkInfo(int start, int end)
/*     */     {
/* 217 */       this.start = start;
/* 218 */       this.end = end;
/*     */     }
/*     */     
/*     */     public int getStart() {
/* 222 */       return this.start;
/*     */     }
/*     */     
/*     */     public int getEnd() {
/* 226 */       return this.end;
/*     */     }
/*     */     
/*     */     public int compareTo(ContentChunkInfo other)
/*     */     {
/* 231 */       return Integer.compare(this.start, other.start);
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other)
/*     */     {
/* 236 */       if (this == other) {
/* 237 */         return true;
/*     */       }
/* 239 */       if (!(other instanceof ContentChunkInfo)) {
/* 240 */         return false;
/*     */       }
/* 242 */       ContentChunkInfo otherCci = (ContentChunkInfo)other;
/* 243 */       return (this.start == otherCci.start) && (this.end == otherCci.end);
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 248 */       return this.start * 31 + this.end;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\CssLinkResourceTransformer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */