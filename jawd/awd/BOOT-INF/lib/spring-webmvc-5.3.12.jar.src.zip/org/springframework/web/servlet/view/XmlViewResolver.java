/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.xml.ResourceEntityResolver;
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.context.support.GenericWebApplicationContext;
/*     */ import org.springframework.web.servlet.View;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class XmlViewResolver
/*     */   extends AbstractCachingViewResolver
/*     */   implements Ordered, InitializingBean, DisposableBean
/*     */ {
/*     */   public static final String DEFAULT_LOCATION = "/WEB-INF/views.xml";
/*     */   @Nullable
/*     */   private Resource location;
/*     */   @Nullable
/*     */   private ConfigurableApplicationContext cachedFactory;
/*  74 */   private int order = Integer.MAX_VALUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocation(Resource location)
/*     */   {
/*  83 */     this.location = location;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrder(int order)
/*     */   {
/*  92 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  97 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws BeansException
/*     */   {
/* 106 */     if (isCache()) {
/* 107 */       initFactory();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getCacheKey(String viewName, Locale locale)
/*     */   {
/* 118 */     return viewName;
/*     */   }
/*     */   
/*     */   protected View loadView(String viewName, Locale locale) throws BeansException
/*     */   {
/* 123 */     BeanFactory factory = initFactory();
/*     */     try {
/* 125 */       return (View)factory.getBean(viewName, View.class);
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {}
/*     */     
/* 129 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected synchronized BeanFactory initFactory()
/*     */     throws BeansException
/*     */   {
/* 139 */     if (this.cachedFactory != null) {
/* 140 */       return this.cachedFactory;
/*     */     }
/*     */     
/* 143 */     ApplicationContext applicationContext = obtainApplicationContext();
/*     */     
/* 145 */     Resource actualLocation = this.location;
/* 146 */     if (actualLocation == null) {
/* 147 */       actualLocation = applicationContext.getResource("/WEB-INF/views.xml");
/*     */     }
/*     */     
/*     */ 
/* 151 */     GenericWebApplicationContext factory = new GenericWebApplicationContext();
/* 152 */     factory.setParent(applicationContext);
/* 153 */     factory.setServletContext(getServletContext());
/*     */     
/*     */ 
/* 156 */     XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(factory);
/* 157 */     reader.setEnvironment(applicationContext.getEnvironment());
/* 158 */     reader.setEntityResolver(new ResourceEntityResolver(applicationContext));
/* 159 */     reader.loadBeanDefinitions(actualLocation);
/*     */     
/* 161 */     factory.refresh();
/*     */     
/* 163 */     if (isCache()) {
/* 164 */       this.cachedFactory = factory;
/*     */     }
/* 166 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */     throws BeansException
/*     */   {
/* 175 */     if (this.cachedFactory != null) {
/* 176 */       this.cachedFactory.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\XmlViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */