/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.servlet.support.RequestDataValueProcessor;
/*     */ import org.springframework.web.util.JavaScriptUtils;
/*     */ import org.springframework.web.util.TagUtils;
/*     */ import org.springframework.web.util.UriUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UrlTag
/*     */   extends HtmlEscapingAwareTag
/*     */   implements ParamAware
/*     */ {
/*     */   private static final String URL_TEMPLATE_DELIMITER_PREFIX = "{";
/*     */   private static final String URL_TEMPLATE_DELIMITER_SUFFIX = "}";
/*     */   private static final String URL_TYPE_ABSOLUTE = "://";
/* 148 */   private List<Param> params = Collections.emptyList();
/*     */   
/* 150 */   private Set<String> templateParams = Collections.emptySet();
/*     */   
/*     */   @Nullable
/*     */   private UrlType type;
/*     */   
/*     */   @Nullable
/*     */   private String value;
/*     */   
/*     */   @Nullable
/*     */   private String context;
/*     */   
/*     */   @Nullable
/*     */   private String var;
/*     */   
/* 164 */   private int scope = 1;
/*     */   
/* 166 */   private boolean javaScriptEscape = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(String value)
/*     */   {
/* 173 */     if (value.contains("://")) {
/* 174 */       this.type = UrlType.ABSOLUTE;
/* 175 */       this.value = value;
/*     */     }
/* 177 */     else if (value.startsWith("/")) {
/* 178 */       this.type = UrlType.CONTEXT_RELATIVE;
/* 179 */       this.value = value;
/*     */     }
/*     */     else {
/* 182 */       this.type = UrlType.RELATIVE;
/* 183 */       this.value = value;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContext(String context)
/*     */   {
/* 192 */     if (context.startsWith("/")) {
/* 193 */       this.context = context;
/*     */     }
/*     */     else {
/* 196 */       this.context = ("/" + context);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVar(String var)
/*     */   {
/* 205 */     this.var = var;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScope(String scope)
/*     */   {
/* 213 */     this.scope = TagUtils.getScope(scope);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setJavaScriptEscape(boolean javaScriptEscape)
/*     */     throws JspException
/*     */   {
/* 221 */     this.javaScriptEscape = javaScriptEscape;
/*     */   }
/*     */   
/*     */   public void addParam(Param param)
/*     */   {
/* 226 */     this.params.add(param);
/*     */   }
/*     */   
/*     */   public int doStartTagInternal()
/*     */     throws JspException
/*     */   {
/* 232 */     this.params = new ArrayList();
/* 233 */     this.templateParams = new HashSet();
/* 234 */     return 1;
/*     */   }
/*     */   
/*     */   public int doEndTag() throws JspException
/*     */   {
/* 239 */     String url = createUrl();
/*     */     
/* 241 */     RequestDataValueProcessor processor = getRequestContext().getRequestDataValueProcessor();
/* 242 */     ServletRequest request = this.pageContext.getRequest();
/* 243 */     if ((processor != null) && ((request instanceof HttpServletRequest))) {
/* 244 */       url = processor.processUrl((HttpServletRequest)request, url);
/*     */     }
/*     */     
/* 247 */     if (this.var == null) {
/*     */       try
/*     */       {
/* 250 */         this.pageContext.getOut().print(url);
/*     */       }
/*     */       catch (IOException ex) {
/* 253 */         throw new JspException(ex);
/*     */       }
/*     */       
/*     */     }
/*     */     else {
/* 258 */       this.pageContext.setAttribute(this.var, url, this.scope);
/*     */     }
/* 260 */     return 6;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   String createUrl()
/*     */     throws JspException
/*     */   {
/* 269 */     Assert.state(this.value != null, "No value set");
/* 270 */     HttpServletRequest request = (HttpServletRequest)this.pageContext.getRequest();
/* 271 */     HttpServletResponse response = (HttpServletResponse)this.pageContext.getResponse();
/*     */     
/* 273 */     StringBuilder url = new StringBuilder();
/* 274 */     if (this.type == UrlType.CONTEXT_RELATIVE)
/*     */     {
/* 276 */       if (this.context == null) {
/* 277 */         url.append(request.getContextPath());
/*     */ 
/*     */       }
/* 280 */       else if (this.context.endsWith("/")) {
/* 281 */         url.append(this.context, 0, this.context.length() - 1);
/*     */       }
/*     */       else {
/* 284 */         url.append(this.context);
/*     */       }
/*     */     }
/*     */     
/* 288 */     if ((this.type != UrlType.RELATIVE) && (this.type != UrlType.ABSOLUTE) && (!this.value.startsWith("/"))) {
/* 289 */       url.append('/');
/*     */     }
/* 291 */     url.append(replaceUriTemplateParams(this.value, this.params, this.templateParams));
/* 292 */     url.append(createQueryString(this.params, this.templateParams, url.indexOf("?") == -1));
/*     */     
/* 294 */     String urlStr = url.toString();
/* 295 */     if (this.type != UrlType.ABSOLUTE)
/*     */     {
/*     */ 
/* 298 */       urlStr = response.encodeURL(urlStr);
/*     */     }
/*     */     
/*     */ 
/* 302 */     urlStr = htmlEscape(urlStr);
/* 303 */     urlStr = this.javaScriptEscape ? JavaScriptUtils.javaScriptEscape(urlStr) : urlStr;
/*     */     
/* 305 */     return urlStr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String createQueryString(List<Param> params, Set<String> usedParams, boolean includeQueryStringDelimiter)
/*     */     throws JspException
/*     */   {
/* 322 */     String encoding = this.pageContext.getResponse().getCharacterEncoding();
/* 323 */     StringBuilder qs = new StringBuilder();
/* 324 */     for (Param param : params) {
/* 325 */       if ((!usedParams.contains(param.getName())) && (StringUtils.hasLength(param.getName()))) {
/* 326 */         if ((includeQueryStringDelimiter) && (qs.length() == 0)) {
/* 327 */           qs.append('?');
/*     */         }
/*     */         else {
/* 330 */           qs.append('&');
/*     */         }
/*     */         try {
/* 333 */           qs.append(UriUtils.encodeQueryParam(param.getName(), encoding));
/* 334 */           if (param.getValue() != null) {
/* 335 */             qs.append('=');
/* 336 */             qs.append(UriUtils.encodeQueryParam(param.getValue(), encoding));
/*     */           }
/*     */         }
/*     */         catch (UnsupportedCharsetException ex) {
/* 340 */           throw new JspException(ex);
/*     */         }
/*     */       }
/*     */     }
/* 344 */     return qs.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String replaceUriTemplateParams(String uri, List<Param> params, Set<String> usedParams)
/*     */     throws JspException
/*     */   {
/* 359 */     String encoding = this.pageContext.getResponse().getCharacterEncoding();
/* 360 */     for (Param param : params) {
/* 361 */       String template = "{" + param.getName() + "}";
/* 362 */       if (uri.contains(template)) {
/* 363 */         usedParams.add(param.getName());
/* 364 */         String value = param.getValue();
/*     */         try {
/* 366 */           uri = StringUtils.replace(uri, template, value != null ? 
/* 367 */             UriUtils.encodePath(value, encoding) : "");
/*     */         }
/*     */         catch (UnsupportedCharsetException ex) {
/* 370 */           throw new JspException(ex);
/*     */         }
/*     */       }
/*     */       else {
/* 374 */         template = "{/" + param.getName() + "}";
/* 375 */         if (uri.contains(template)) {
/* 376 */           usedParams.add(param.getName());
/* 377 */           String value = param.getValue();
/*     */           try {
/* 379 */             uri = StringUtils.replace(uri, template, value != null ? 
/* 380 */               UriUtils.encodePathSegment(value, encoding) : "");
/*     */           }
/*     */           catch (UnsupportedCharsetException ex) {
/* 383 */             throw new JspException(ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 388 */     return uri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static enum UrlType
/*     */   {
/* 397 */     CONTEXT_RELATIVE,  RELATIVE,  ABSOLUTE;
/*     */     
/*     */     private UrlType() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\UrlTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */