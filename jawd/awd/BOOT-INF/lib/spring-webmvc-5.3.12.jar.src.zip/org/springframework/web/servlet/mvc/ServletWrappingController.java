/*     */ package org.springframework.web.servlet.mvc;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletWrappingController
/*     */   extends AbstractController
/*     */   implements BeanNameAware, InitializingBean, DisposableBean
/*     */ {
/*     */   @Nullable
/*     */   private Class<? extends Servlet> servletClass;
/*     */   @Nullable
/*     */   private String servletName;
/*  95 */   private Properties initParameters = new Properties();
/*     */   
/*     */   @Nullable
/*     */   private String beanName;
/*     */   
/*     */   @Nullable
/*     */   private Servlet servletInstance;
/*     */   
/*     */   public ServletWrappingController()
/*     */   {
/* 105 */     super(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServletClass(Class<? extends Servlet> servletClass)
/*     */   {
/* 115 */     this.servletClass = servletClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServletName(String servletName)
/*     */   {
/* 123 */     this.servletName = servletName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInitParameters(Properties initParameters)
/*     */   {
/* 131 */     this.initParameters = initParameters;
/*     */   }
/*     */   
/*     */   public void setBeanName(String name)
/*     */   {
/* 136 */     this.beanName = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 146 */     if (this.servletClass == null) {
/* 147 */       throw new IllegalArgumentException("'servletClass' is required");
/*     */     }
/* 149 */     if (this.servletName == null) {
/* 150 */       this.servletName = this.beanName;
/*     */     }
/* 152 */     this.servletInstance = ((Servlet)ReflectionUtils.accessibleConstructor(this.servletClass, new Class[0]).newInstance(new Object[0]));
/* 153 */     this.servletInstance.init(new DelegatingServletConfig(null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 165 */     Assert.state(this.servletInstance != null, "No Servlet instance");
/* 166 */     this.servletInstance.service(request, response);
/* 167 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 177 */     if (this.servletInstance != null) {
/* 178 */       this.servletInstance.destroy();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class DelegatingServletConfig
/*     */     implements ServletConfig
/*     */   {
/*     */     private DelegatingServletConfig() {}
/*     */     
/*     */ 
/*     */     @Nullable
/*     */     public String getServletName()
/*     */     {
/* 193 */       return ServletWrappingController.this.servletName;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public ServletContext getServletContext()
/*     */     {
/* 199 */       return ServletWrappingController.this.getServletContext();
/*     */     }
/*     */     
/*     */     public String getInitParameter(String paramName)
/*     */     {
/* 204 */       return ServletWrappingController.this.initParameters.getProperty(paramName);
/*     */     }
/*     */     
/*     */ 
/*     */     public Enumeration<String> getInitParameterNames()
/*     */     {
/* 210 */       return ServletWrappingController.this.initParameters.keys();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\ServletWrappingController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */